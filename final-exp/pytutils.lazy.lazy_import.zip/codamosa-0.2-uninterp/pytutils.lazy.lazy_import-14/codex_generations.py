

# Generated at 2022-06-18 04:03:43.170906
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:03:47.346541
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:03:51.754910
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:03:58.229014
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _module_import
    from bzrlib.lazy_import import _module_import_by_name
    from bzrlib.lazy_import import _module_import_by_name_and_attr
    from bzrlib.lazy_import import _module_import_by_name_and_attr_and_value
    from bzrlib.lazy_import import _module_import_by_name_and_attr_and_value_and_attr
    from bzrlib.lazy_import import _module_import_by_name_and_

# Generated at 2022-06-18 04:04:09.206373
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSel

# Generated at 2022-06-18 04:04:12.291577
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:16.816156
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode string"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:27.814865
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            bzrlib.lazy_import.ScopeReplacer.__call__(None)
    Test('test_ScopeReplacer___call__').run()

    def __getitem__(self, key):
        obj = object.__getattribute__(self, '_resolve')()
        return obj[key]

    def __setitem__(self, key, value):
        obj = object.__getattribute__(self, '_resolve')()
        return obj.__setitem__(key, value)

    def __delitem__(self, key):
        obj = object.__getattribute__(self, '_resolve')()


# Generated at 2022-06-18 04:04:32.317771
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        def __init__(self, value):
            self.value = value
    def factory(replacer, scope, name):
        return Foo(name)
    scope = {}
    replacer = ScopeReplacer(scope, factory, 'foo')
    assert replacer.value == 'foo'
    assert scope['foo'].value == 'foo'

# Generated at 2022-06-18 04:04:38.172259
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('attr', 'value')
            self.assertEqual('value', scope_replacer.attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:04:58.889993
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    import bzrlib.tests.test_lazy_import

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            # __setattr__ should set attributes on the real object
            # once it has been created.
            def factory(self, scope, name):
                return object()
            scope = {}
            lazy_import(scope, 'x = bzrlib.lazy_import.ScopeReplacer(scope, factory, "x")')
            scope['x'].foo = 'bar'
            self.assertEqual('bar', scope['x'].foo)

    bzrlib.tests.test_lazy_import.test_suite().addTests

# Generated at 2022-06-18 04:05:06.822756
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    def _factory(self, scope, name):
        return bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__
    bzrlib.lazy_import.ScopeReplacer(globals(), _factory, 'test_ScopeReplacer___call__')
    test_ScopeReplacer___call__()


# Generated at 2022-06-18 04:05:18.082389
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.blackbox
    ''')
    bzrlib.tests.blackbox.run_bzr_subprocess(['selftest', '-v'])

    # Test that the method __call__ of class ScopeReplacer works as expected
    # when called with no arguments.
    #
    # This test is known to fail with Python 2.4.3, but passes with Python
    # 2.5.1.
    #
    # The failure is:
    #
    # Traceback (most recent call last):
    #   File "bzrlib/tests/blackbox/test_selftest.py", line 564, in test_run_

# Generated at 2022-06-18 04:05:21.246585
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:24.594535
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:28.320918
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:35.411807
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestModule
    from bzrlib.tests.test_lazy_import import TestClass
    from bzrlib.tests.test_lazy_import import TestFunction
    from bzrlib.tests.test_lazy_import import TestConstant
    from bzrlib.tests.test_lazy_import import TestException
    from bzrlib.tests.test_lazy_import import TestObject
    from bzrlib.tests.test_lazy_import import TestObject2
    from bzrlib.tests.test_lazy_import import TestObject3

# Generated at 2022-06-18 04:05:39.543832
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:42.561825
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            scope = {}
            def factory(self, scope, name):
                return lambda: 'foo'
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope['ScopeReplacer'](scope, factory, 'foo')
            self.assertEqual('foo', scope['foo']())
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:05:51.387560
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import (
        FakeModule,
        FakeModuleFactory,
        )
    from bzrlib.tests.test_lazy_import import (
        TestCaseWithFakeModule,
        )

    class TestScopeReplacer(TestCaseWithFakeModule):

        def test_setattr_after_replace(self):
            """__setattr__ should raise an exception if the object has already
            been replaced.
            """
            # Create a scope and a fake module
            scope = {}
            fake_module = FakeModule('fake_module')
            # Create a ScopeRepl

# Generated at 2022-06-18 04:06:06.297356
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.script
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import

# Generated at 2022-06-18 04:06:12.996893
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.blackbox
    bzrlib.tests.blackbox.test_suite()

    # Test that calling the object works
    def factory(self, scope, name):
        return lambda: 'called'
    scope = {}
    name = 'test'
    replacer = ScopeReplacer(scope, factory, name)
    assert replacer() == 'called'
    assert scope[name]() == 'called'



# Generated at 2022-06-18 04:06:20.313350
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Dummy(object):
                pass
            dummy = Dummy()
            dummy.attr = None
            scope = {'dummy':dummy}
            def factory(self, scope, name):
                return scope[name]
            replacer = ScopeReplacer(scope, factory, 'dummy')
            replacer.attr = 'value'
            self.assertEqual('value', dummy.attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:06:29.812713
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertIsInstance(scope['errors'], ScopeReplacer)
            self.assertIsInstance(scope['osutils'], ScopeReplacer)
            self.assertIsInstance(scope['branch'], ScopeReplacer)

# Generated at 2022-06-18 04:06:35.626520
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly:" \
        " msg: extra"
    assert repr(e) == "IllegalUseOfScopeReplacer('ScopeReplacer object " \
        "'name' was used incorrectly: msg: extra')"



# Generated at 2022-06-18 04:06:38.541607
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:06:43.266697
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'


# Generated at 2022-06-18 04:06:52.225676
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.foo = None
    class TestCase(TestCase):
        def test_setattr(self):
            obj = TestObj()
            replacer = ScopeReplacer({}, lambda self, scope, name: obj, 'foo')
            replacer.foo = 'bar'
            self.assertEqual('bar', obj.foo)
            replacer.foo = 'baz'
            self.assertEqual('baz', obj.foo)
    TestCase.run_tests()

# Generated at 2022-06-18 04:06:57.609213
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(sys.modules[__name__].__dict__, '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    import sys
    import bzrlib.lazy_import

# Generated at 2022-06-18 04:07:02.034683
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_call(self):
            def factory(self, scope, name):
                return lambda: 42
            lazy_import(locals(), '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            sr = ScopeReplacer({}, factory, 'sr')
            self.assertEqual(42, sr())
    Test().run()



# Generated at 2022-06-18 04:07:12.518904
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:07:16.321528
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:07:22.344381
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            # __setattr__ should raise an exception if the object has already
            # been replaced.
            scope = {}
            def factory(self, scope, name):
                return object()
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            replacer = ScopeReplacer(scope, factory, 'replacer')
            # Disable proxying to check for abuse.
            ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:07:33.695764
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the __call__ method of ScopeReplacer works correctly.
    # This is a bit of a hack, but it's the only way to test it.
    # We use the __call__ method of the bzrlib module to test it.
    # This is because the bzrlib module is a ScopeReplacer object.
    # We can't use the __call__ method of any other ScopeReplacer object
    # because they are all replaced by the time we get here.

# Generated at 2022-06-18 04:07:37.875158
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError('__unicode__ should return a unicode object')


# Generated at 2022-06-18 04:07:45.032119
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import _scope_replacer_factory
    from bzrlib.lazy_import import _scope_replacer_factory_module
    from bzrlib.lazy_import import _scope_replacer_factory_module_constant
    from bzrlib.lazy_import import _scope_replacer_factory_module_function
    from bzrlib.lazy_import import _scope_replacer_factory_module_

# Generated at 2022-06-18 04:07:47.837217
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:55.945645
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    import bzrlib.trace
    import sys
    import unittest
    class TestCase(unittest.TestCase):
        def test_ScopeReplacer___getattribute__(self):
            scope = {}
            bzrlib.lazy_import.lazy_import(scope, '''
            import bzrlib.trace
            ''')
            self.assertEqual(scope['trace'].__class__,
                             bzrlib.lazy_import.ScopeReplacer)
            self.assertEqual(scope['trace']._resolve().__class__,
                             bzrlib.trace.Trace)

# Generated at 2022-06-18 04:08:02.956736
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'bar'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope_replacer())

    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:08:10.265404
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'baz'
            scope = {}
            def factory(self, scope, name):
                return foo
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            scope_replacer.bar = 'qux'
            self.assertEqual('qux', foo.bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:08:21.702054
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        def __init__(self, x):
            self.x = x
        def bar(self):
            return self.x
    def factory(self, scope, name):
        return Foo(42)
    scope = {}
    name = 'foo'
    sr = ScopeReplacer(scope, factory, name)
    assert sr.x == 42
    assert sr.bar() == 42
    assert scope[name] is sr
    assert sr._resolve() is not sr
    assert scope[name] is not sr
    assert scope[name].x == 42
    assert scope[name].bar() == 42
    assert sr._resolve() is scope[name]


# Generated at 2022-06-18 04:08:25.137077
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:35.246237
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope_replacer())
            self.assertEqual(((1, 2), {'a': 'b'}), scope_replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()

# Unit

# Generated at 2022-06-18 04:08:36.675343
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:40.884964
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:43.345825
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:52.416414
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            obj = ScopeReplacer(scope, factory, 'name')
            obj.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope['name'].attr)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:08:58.654174
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_call(self):
            def factory(self, scope, name):
                return lambda: 'called'
            scope = {}
            name = 'test'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('called', obj())
    Test('test_call').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:09:02.383703
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode), \
        'IllegalUseOfScopeReplacer.__unicode__() should return a unicode object'
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra', \
        'IllegalUseOfScopeReplacer.__unicode__() should return a unicode object'

# Generated at 2022-06-18 04:09:10.881659
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return self
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            self.assertRaises(IllegalUseOfScopeReplacer, obj.__setattr__, 'attr', 'value')
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:09:18.704465
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:23.589818
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            # test __setattr__
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('real_obj', obj._resolve())
            self.assertEqual('real_obj', scope[name])
            obj.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope[name].attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()
#

# Generated at 2022-06-18 04:09:26.191272
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:35.022506
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class Test(TestCase):
        def test_getattribute_proxy(self):
            # Test that __getattribute__ proxies to the real object
            # when it is available.
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertEqual(scope['errors'].__class__, ScopeReplacer)
            self.assertEqual(scope['osutils'].__class__, ScopeReplacer)
            self.assertEqual(scope['branch'].__class__, ScopeReplacer)

# Generated at 2022-06-18 04:09:40.496041
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attributes on the real object"""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'


# Generated at 2022-06-18 04:09:50.055956
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            scope = {}
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope_replacer.a, 1)
            self.assertEqual(scope_replacer.b, 2)
            self.assertEqual(scope_replacer.c, 3)
    TestScopeReplacer

# Generated at 2022-06-18 04:09:53.921816
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')
    assert s.endswith(')')


# Generated at 2022-06-18 04:09:59.095668
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:10:02.086674
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:11.600272
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.trace
    import sys
    import unittest
    class TestCase(unittest.TestCase):
        def test_ScopeReplacer___call__(self):
            """Test method __call__ of class ScopeReplacer"""
            bzrlib.trace.set_verbosity_level(0)
            bzrlib.lazy_import.lazy_import(globals(), '''
            import bzrlib.trace
            ''')
            bzrlib.trace.set_verbosity_level(0)
    unittest.main(defaultTest='TestCase.test_ScopeReplacer___call__')

# Generated at 2022-06-18 04:10:19.553782
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:29.240251
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the __call__ method of ScopeReplacer works.
    # This is a bit of a hack, but it is the only way to test that
    # the __call__ method works.
    # The test is that the __call__ method of the object returned
    # by lazy_import is the same as the __call__ method of the
    # object returned by the import statement.
    # This is a bit of a hack, but it is the only way to test that
    # the __call__ method works.
    # The test is that the __call__ method

# Generated at 2022-06-18 04:10:38.925195
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class Test(TestCase):
        def test_call(self):
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            lazy_import(scope, 'foo = foo')
            self.assertEqual(((1, 2), {'a': 'b'}), scope['foo'](1, 2, a='b'))
    test_case = Test('test_call')
    test_case.run()


# Generated at 2022-06-18 04:10:43.549972
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:53.906487
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            sr = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), sr())
            self.assertEqual(((1,), {}), sr(1))
            self.assertEqual(((1,2), {}), sr(1,2))

# Generated at 2022-06-18 04:10:57.344205
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:08.069126
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    class Foo(object):
        pass
    scope = {}
    def factory(self, scope, name):
        return Foo()
    name = 'foo'
    foo = ScopeReplacer(scope, factory, name)
    assert scope[name] is foo
    assert foo._real_obj is None
    foo.bar = 'baz'
    assert foo._real_obj is not None
    assert foo._real_obj.bar == 'baz'
    # Now that the object has been replaced, setting an attribute should
    # raise an exception.
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:11:16.974040
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSel

# Generated at 2022-06-18 04:11:25.363005
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import

# Generated at 2022-06-18 04:11:30.565841
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'


# Generated at 2022-06-18 04:11:50.261129
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.a = 1
            foo = Foo()
            scope = {}
            scope['foo'] = foo
            scope['bar'] = ScopeReplacer(scope, lambda x, y, z: foo, 'foo')
            scope['bar'].a = 2
            self.assertEqual(2, foo.a)

    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:11:53.683916
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:56.317130
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:12:07.569915
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    def factory(self, scope, name):
        return 42
    scope = {}
    name = 'foo'
    x = ScopeReplacer(scope, factory, name)
    # Test that the object is not replaced when an attribute is set.
    x.bar = 'baz'
    # Test that the object is replaced when an attribute is set.
    x.bar = 'baz'
    # Test that the object is replaced when an attribute is set.
    x.bar = 'baz'
    # Test that the object is replaced when an attribute is set.
    x.bar = 'baz'
    # Test that the object is replaced when an attribute is set.

# Generated at 2022-06-18 04:12:10.100381
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msg'

# Generated at 2022-06-18 04:12:18.130616
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_setattr(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = None
            scope = {}
            ScopeReplacer(scope, lambda self, scope, name: foo, 'foo')
            scope['foo'].bar = 'baz'
            self.assertEqual('baz', foo.bar)

    TestScopeReplacer().test_setattr()

# Generated at 2022-06-18 04:12:21.202229
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode string"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:23.329793
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # __setattr__ is not implemented
    pass

# Generated at 2022-06-18 04:12:26.156043
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:30.494160
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    # Test that calling a ScopeReplacer works
    bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__()



# Generated at 2022-06-18 04:12:55.862463
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:13:05.483113
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            ScopeReplacer(scope, lambda self, scope, name: foo, 'foo')
            self.assertEqual('bar', scope['foo'].bar)
            scope['foo'].bar = 'baz'

# Generated at 2022-06-18 04:13:08.986521
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:11.532983
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:13:15.081025
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:13:16.887461
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:13:19.573380
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
