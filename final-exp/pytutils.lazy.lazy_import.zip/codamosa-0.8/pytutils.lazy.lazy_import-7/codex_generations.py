

# Generated at 2022-06-12 07:33:50.288249
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import bzrlib.tests.per_lazy_import
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    bzrlib.tests.per_lazy_import.check_exception(
        "[name] msg: extra",
        (IllegalUseOfScopeReplacer, 'name', 'msg', 'extra'))



# Generated at 2022-06-12 07:33:59.189509
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:34:04.072643
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # .. todo:: Test more.
    class TestClass(object):
        __slots__ = ()
        def __call__(self, *args):
            # ignore args
            return 13
    scope = {}
    scope_replacer = ScopeReplacer(scope,
        lambda scope_replacer: TestClass(), 'test_obj')
    assert scope_replacer() == 13


# Generated at 2022-06-12 07:34:09.956662
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    from bzrlib.tests import TestCase

    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "pattern %(msg)s: %(extra)s"
    e = MyException('name', 'msg', extra='val')

    # __unicode__ must return a unicode object.
    self.assertIsInstance(e.__unicode__(), unicode)

    # It can be called with the unicode() builtin.
    self.assertIsInstance(unicode(e), unicode)



# Generated at 2022-06-12 07:34:13.551869
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method IllegalUseOfScopeReplacer.__unicode__"""
    # test the code of __unicode__
    e = IllegalUseOfScopeReplacer('the_name', 'the message')
    s = e.__unicode__()



# Generated at 2022-06-12 07:34:21.864995
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests import TestCase
    def fake_gettext(string):
        return u"translated " + string
    e1 = IllegalUseOfScopeReplacer("foo", "message")
    e2 = IllegalUseOfScopeReplacer("foo", "message")
    e3 = IllegalUseOfScopeReplacer("bar", "message")
    class FakeGlobalGettext(TestCase):
        """Redirect global _ gettext call to fake_gettext"""
        def setUp(self):
            super(FakeGlobalGettext, self).setUp()
            self._real_gettext = IllegalUseOfScopeReplacer._
            IllegalUseOfScopeReplacer._ = fake_gettext
        def tearDown(self):
            super(FakeGlobalGettext, self).tearDown()
            IllegalUseOfScopeReplacer._ = self._real_get

# Generated at 2022-06-12 07:34:29.189170
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should create a real object on first use and proxy to it.

    This test causes the attribute to be accessed via __getattribute__
    and then sets the attribute via __setattr__.
    """
    class TestObject:
        __slots__ = ('x',)
    class TestScopeReplacer(ScopeReplacer):
        def __init__(self):
            self._factory = lambda self, scope, name: TestObject()
            self._name = 'foo'
            self._scope = {'foo':self}
            self._real_obj = None
    tsr = TestScopeReplacer()
    tsr.x = 3
    asserts.assert_equal(tsr.x, 3)
    # Check that the real object was created
    asserts.assert_true(isinstance(tsr._real_obj, TestObject))

# Generated at 2022-06-12 07:34:38.692573
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        def __call__(self, *args, **kwargs):
            return 42

    def test_factory(obj, scope, name):
        scope[name] = TestCase()
        return scope[name]

    lazy_import(sys.modules['__main__'].__dict__, '''
        import _imported_test_ScopeReplacer___call__
        test_case = _imported_test_ScopeReplacer___call__.ScopeReplacer(
            globals(),
            _imported_test_ScopeReplacer___call__.test_factory,
            'test_case')
    ''')

    # test_case is not actually used here, but this will generate a
    # real object.
    self.assertEqual

# Generated at 2022-06-12 07:34:48.859501
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # test_ScopeReplacer___getattribute__() uses the following locals:
    global scope, name, factory
    scope = {}
    name = 'test'
    factory = lambda scope_replacer, scope, name: scope_replacer
    from bzrlib.lazy_import import ScopeReplacer
    scope_replacer = ScopeReplacer(scope, factory, name)
    scope[name] = scope_replacer
    def check(exc_type, expected):
        try:
            scope_replacer.test
        except exc_type as e:
            if str(e) != expected:
                raise AssertionError('%r != %r' % (e, expected))
        else:
            raise AssertionError("Exception %s not raised" % exc_type)
    # test 1

# Generated at 2022-06-12 07:34:56.865378
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib._mutable_store import MutableStore
    from bzrlib.mutabletree import MutableTree
    # This is a rather high level test that tests that binding a LazyImport
    # object to bzrlib.tree.Tree.mutable_file_id_to_entry_id (which is normally
    # bound after a module is imported) works.
    class TestStore(object):
        def add_inventory(self, inv, units=None):
            pass
        def get_inventory(self, file_id, units=None):
            pass
        def add_file(self, revid, relpath, basename, entry):
            pass
        def get_file(self, revid, relpath, basename, entry):
            pass
        def get_bytes(self, key):
            pass

# Generated at 2022-06-12 07:35:14.181436
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.test_lazy_import as bzrlib_tests_test_lazy_import
    from bzrlib.tests import TestCase
    from subprocess import Popen, PIPE
    module_name = 'bzrlib.tests.test_lazy_import'
    class_name = 'TestLazyImportModule'
    # Required for pickling: save the module and class name to allow
    # reconstructing the class later.
    module_name, class_name = 'bzrlib.tests.test_lazy_import', 'TestLazyImportModule'
    self = bzrlib_tests_test_lazy_import.TestLazyImportModule()
    kwargs = {}
    bzrlib.lazy_import.ScopeReplacer.__call__(object, *())

# Generated at 2022-06-12 07:35:26.034118
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str"""
    # get some exceptions
    import sys
    import StringIO
    import traceback

    # helper function
    def get_exceptions(n):
        """Return a list of n exceptions"""
        exceptions = []
        for i in xrange(1, n+1):
            try:
                raise IllegalUseOfScopeReplacer("name%d" % i, "message%d" % i)
            except IllegalUseOfScopeReplacer as e:
                exceptions.append(e)
        return exceptions

    # Short test.  We display the first 10 exceptions to the screen

# Generated at 2022-06-12 07:35:30.710313
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def factory(self, scope, name):
        def f(x, y=1):
            return x + y
        return f

    scope = {}
    scope['foo'] = ScopeReplacer(scope, factory, 'foo')
    if scope['foo'](2) != 3:
        raise AssertionError
    if scope['foo'](2, y=4) != 6:
        raise AssertionError
    if scope['foo'](2, 4) != 6:
        raise AssertionError



# Generated at 2022-06-12 07:35:31.303334
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__(): pass

# Generated at 2022-06-12 07:35:43.492791
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class _MockScopeReplacer(ScopeReplacer):
        def __init__(self, scope):
            ScopeReplacer.__init__(self, scope, None, None)
        def _resolve(self):
            return self.__class__.__name__
    _global = globals()
    _global['_MockScopeReplacer'] = _MockScopeReplacer

# Generated at 2022-06-12 07:35:48.939573
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import tests; tests.test_ScopeReplacer___call__()

    class Foo(object):
        """Foo."""

        def __call__(self, *args):
            """Foo().__call__(args)"""
            return args

    scope = {}
    foo = ScopeReplacer(scope, lambda: Foo(), name='foo')
    foo(1, 2)
    foo(3, 4)
    assert scope == {'foo': foo}



# Generated at 2022-06-12 07:35:51.669605
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    res = ScopeReplacer(scope={}, factory=lambda x: None, name='name')
    # test return value
    if not isinstance(res, ScopeReplacer):
        raise AssertionError

# Generated at 2022-06-12 07:35:55.511412
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    # Insert your code here to test __setattr__ method of class ScopeReplacer
    raise NotImplementedError("test for __setattr__ not implemented")


# Generated at 2022-06-12 07:36:04.091235
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import testtools

    class TestScopeReplacer(testtools.TestCase):
        """Test case for __setattr__ of class ScopeReplacer."""

        test_method_doc = ("Test __setattr__ of class ScopeReplacer with"
                           " the valid arguments")

        def test___setattr__(self):
            # Test with the valid arguments
            attr = 'random_attr'
            value = 'random_value'
            obj = ScopeReplacer({}, lambda x,y,z:x, {})
            obj.__setattr__(attr, value)
            self.assertEquals(obj.__getattribute__(attr), value)

    from bzrlib.tests import TestUtil
    TestUtil.run_doctest(ScopeReplacer, TestScopeReplacer)



# Generated at 2022-06-12 07:36:10.795294
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unicode representation of IllegalUseOfScopeReplacer."""
    from cStringIO import StringIO
    from bzrlib.i18n import gettext
    gettext('hello')
    u = IllegalUseOfScopeReplacer('you', 'hey').__unicode__()
    sio = StringIO()
    print >> sio, u.encode('utf8')
    assert sio.getvalue() == 'you: hey\n'



# Generated at 2022-06-12 07:36:25.010847
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str, not a unicode object."""
    tb = IllegalUseOfScopeReplacer("abc", "xyz", "foo")
    s = str(tb)
    if not isinstance(s, str):
        raise AssertionError("__str__ of IllegalUseOfScopeReplacer returned "
                             "unicode: %r" % (s,))



# Generated at 2022-06-12 07:36:35.091999
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import osutils
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), 'from bzrlib.osutils import _mod_fileobj')

    # Test call method of class ScopeReplacer
    # Since ScopeReplacer defers calling until first_use
    # we may test the real _mod_fileobj method.
    s = ScopeReplacer('', _mod_fileobj, '_mod_fileobj')
    assert _mod_fileobj('/tmp/foo', 'w') == s('/tmp/foo', 'w')
    # call method of class ScopeReplacer raises error if
    # _should_proxy is set to False.

# Generated at 2022-06-12 07:36:44.519968
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(locals(), '''
from bzrlib import (
    errors,
    osutils,
    )
''')
    # bzrlib.errors is a ScopeReplacer
    # This needs to be a function because lambda is a keyword in Python 3
    def _f(n):
        return n
    f = lambda n: n
    # callable(bzrlib.errors) -> True
    # callable(f) -> True
    # calling bzrlib.errors(5) -> 5
    # calling f(5) -> 5
    # Another way to use ScopeReplacer
    def _f2(n1, n2):
        return n1+n2

# Generated at 2022-06-12 07:36:50.939041
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Testing method IllegalUseOfScopeReplacer.__unicode__"""
    u = unicode(IllegalUseOfScopeReplacer('s', 'm', extra='e'))
    assert u == u'ScopeReplacer object \'s\' was used incorrectly: m: e'



# Generated at 2022-06-12 07:36:54.635443
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    foo = ScopeReplacer(
        scope = None,
        factory = fake_obj_to_return_self,
        name = 'foo')
    foo()
test_ScopeReplacer___call__.expected_exception = IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:37:03.954889
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    from unittest import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            def f(self, scope, name):
                def a(*args, **kwargs):
                    return (args, kwargs)
                return a
            scope = {}
            lazy_import(scope, '''from bzrlib.lazy_import import ScopeReplacer''')
            x = ScopeReplacer(scope, f, 'x')
            self.assertEqual((x(), ((), {})), (((), {}), {}))
            self.assertEqual((x(1, 2), (1, 2), {}), (((1, 2), {}), {}))

# Generated at 2022-06-12 07:37:14.955142
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class C(object):
        def __init__(self):
            self._attr = 'initial'
        def __eq__(self, other):
            return self._attr == other._attr
    class Scope(object):
        def __init__(self, name, value):
            self._name = name
            self._value = value
        def __getitem__(self, key):
            return self._value
        def __setitem__(self, key, value):
            if key != self._name:
                raise AssertionError(key)
            self._value = value
    my_scope = Scope('my_name', 'my_value')
    sr = ScopeReplacer(my_scope, lambda sr, scope, name: C(), 'my_name')
    # test that the value from the scope is returned, and not sr._value


# Generated at 2022-06-12 07:37:19.360049
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class MockObj(object):
        pass

    obj = MockObj()
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda self, scope, name: obj, 'foo')
    assert scope_replacer.__call__(1, k=2) == obj.__call__(1, k=2)



# Generated at 2022-06-12 07:37:30.166305
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    import bzrlib.tests.blackbox
    import sys

    # Populate sys.modules
    import bzrlib
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox as blackbox
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import as test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import as test_lazy_import
    bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import

    # We need

# Generated at 2022-06-12 07:37:38.901613
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test __call__
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class CallableLazyImp(object):
        def __init__(self, val):
            self._val = val
        def __call__(self, *args, **kwargs):
            return self._val
    def factory_cl(lazy, scope, name):
        return CallableLazyImp(scope[name])
    scope = {'cl': 'the value'}
    replacer = ScopeReplacer(scope, factory_cl, 'cl')
    self.assertEqual('the value', replacer())


# Generated at 2022-06-12 07:37:49.613639
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import doctest
    doctest.run_docstring_examples(IllegalUseOfScopeReplacer.__unicode__,
                                   globals(),
                                   {
        'IllegalUseOfScopeReplacer':IllegalUseOfScopeReplacer,
        })



# Generated at 2022-06-12 07:37:57.651548
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests, bzrlib.tests.test_lazy_import
    from bzrlib.tests.test_lazy_import import DummyTestCase
    test = DummyTestCase()
    dummy = object()
    class test_factory:
        """Create a real object when called"""
        def __init__(self):
            self.count = 0
        def __call__(self, scope_replacer, scope, name):
            self.count += 1
            return dummy
    test_factory = test_factory()
    scope = dict()
    scope_replacer = ScopeReplacer(scope, test_factory, 'obj')
    test.assertEquals(0, test_factory.count,
        "Object should not have been created yet")

# Generated at 2022-06-12 07:38:03.289603
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer("foo", "bar")
    assert isinstance(e, Exception)
    assert isinstance(e, IllegalUseOfScopeReplacer)
    assert unicode(e) == (u"ScopeReplacer object u'foo' was used "
                          u"incorrectly: bar")



# Generated at 2022-06-12 07:38:14.302397
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__ we are testing
    from bzrlib.lazy_import import ScopeReplacer
    # __call__ used in __call__
    global object
    global getattr
    global setattr
    global object
    global getattr
    object = object
    getattr = getattr
    setattr = setattr
    object = object
    getattr = getattr

    # __call__ we are testing
    from bzrlib.lazy_import import ScopeReplacer
    # __call__ used in __init__
    global object
    object = object

    # imported in tested module
    global __builtins__
    global object
    global object
    __builtins__ = object
    object = object
    object = object

    # imported in tested module
    global __builtins__
    global object

# Generated at 2022-06-12 07:38:25.011477
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    from bzrlib.lazy_import import lazy_import,ScopeReplacer
    from bzrlib.transform import TransformResult
    assert isinstance(TransformResult,type)
    assert not isinstance(TransformResult,ScopeReplacer)
    assert ScopeReplacer.__call__.__name__ == '__call__'
    assert callable(ScopeReplacer.__call__)
    assert hasattr(ScopeReplacer.__call__,'im_class')
    assert ScopeReplacer.__call__.im_class == ScopeReplacer
    assert hasattr(ScopeReplacer.__call__,'__doc__')
    assert ScopeReplacer.__call__.__doc__ == '''

    '''
    assert not hasattr(ScopeReplacer.__call__,'__get__')
    assert not hasattr

# Generated at 2022-06-12 07:38:29.955773
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    # init __init__
    module = 'bzrlib.lazy_import'
    name = 'foo'
    scope = sys.modules
    factory = ScopeReplacer.__init__
    # call __init__
    x = ScopeReplacer(scope, factory, name)
    # check __getattribute__ and __setattr__
    x.a = 1
    assert(x.a == 1)

# Generated at 2022-06-12 07:38:39.123824
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()

    The __str__ method should recover from gettext failure, and return a
    string that can be evaluated, if there is a problem with formatting
    """
    obj = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(obj)
    assert s.startswith('Unprintable exception')
    obj._preformatted_string = s
    s = str(obj)
    assert s.startswith('Unprintable exception')
test_IllegalUseOfScopeReplacer___str__.unittest = ['.i18n']



# Generated at 2022-06-12 07:38:50.629304
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestObject(object):
        def __call__(self, *args, **kwargs):
            return args, kwargs

    tb_scope = {}
    tb = ScopeReplacer(tb_scope, TestObject, 'tb')
    self.assertEqual(tb_scope, {'tb': tb})
    self.assertEqual(tb.__class__, ScopeReplacer)
    # Call tb as a func
    result = tb('arg1', 'arg2', arg3='foo', arg4='bar')
    self.assertEqual(result, (('arg1', 'arg2'), {'arg3':'foo', 'arg4':'bar'}))
    # tb should still be a ScopeReplacer and so should tb_

# Generated at 2022-06-12 07:38:58.800983
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    def func(r, scope, name):
        class A:
            pass
        return A()
    r = ScopeReplacer(globals(), func, 'func')
    tmp = sys.modules['bzrlib.lazy_import']
    tmp1 = r._factory
    assert tmp1 == tmp.test_ScopeReplacer___setattr__.func
    tmp1 = r._scope
    assert tmp1 == tmp.test_ScopeReplacer___setattr__.__dict__

# Generated at 2022-06-12 07:39:02.505638
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str and never a unicode object"""
    err = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(str(err), str)
    assert not isinstance(str(err), unicode)



# Generated at 2022-06-12 07:39:14.670797
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import __builtin__
    setattr = __builtin__.setattr
    setattr = ScopeReplacer.__setattr__

    class X: pass
    x = X()
    setattr(x, 'x', 1)
    assert x.x == 1

    scope = {'x': 1}
    setattr(scope, 'x', 2)
    assert scope['x'] == 2

    scope = {'x': x}
    setattr(scope, 'x', 1)
    assert scope['x'] == 1



# Generated at 2022-06-12 07:39:18.126563
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import as _mod_lazy_import
    scope = {}
    lazy_obj = _mod_lazy_import.ScopeReplacer(scope, lambda self_, scope_, name_: True, 'obj')
    lazy_obj()

# Generated at 2022-06-12 07:39:21.009011
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return an encoded string."""
    e = IllegalUseOfScopeReplacer("foo", "bar")
    assert isinstance(str(e), str)

# Generated at 2022-06-12 07:39:27.699110
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() does not raise an exception."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # Silently ignore not implemented errors.  Instances of this class have
    # strange __unicode__ methods.  They should not be able to raise an
    # exception, otherwise we would have many uncaught errors in the code.
    try:
        unicode(e)
    except NotImplementedError:
        pass



# Generated at 2022-06-12 07:39:32.549485
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global f
    class f:
        def __init__(self):
            pass
        def __call__(self):
            return 4
    x = ScopeReplacer(globals(), lambda s, scope, name: f(), 'f')
    r = x()
    assert isinstance(r, int)
    assert r == 4
    assert isinstance(x, f)


# Generated at 2022-06-12 07:39:37.110365
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__

    For any IllegalUseOfScopeReplacer instance X, this assertion holds:
        str(X) == unicode(X).encode('utf8')
    """
    # Create an instance
    instance = IllegalUseOfScopeReplacer(1, 2, 3)
    # The assertion
    assert str(instance) == unicode(instance).encode('utf8')



# Generated at 2022-06-12 07:39:48.468581
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib

    # Test with a defined ScopeReplacer._should_proxy
    original_should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-12 07:39:51.488703
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = unicode(e)
    assert isinstance(s, unicode)

# Generated at 2022-06-12 07:40:01.628432
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import unittest
    from bzrlib.lazy_import import illegal_use_of_scope_replacer


    class Test(unittest.TestCase):

        def test_setattr(self):
            from bzrlib.lazy_import import (
                ScopeReplacer,
                )
            scope = {}
            name = "name"
            obj = ScopeReplacer(scope=scope, factory=str, name=name)
            # setting an attribute must succeed because obj is not used yet
            setattr(obj, "attr", "value")
            try:
                obj._resolve()
            except IllegalUseOfScopeReplacer:
                self.fail("IllegalUseOfScopeReplacer was raised.")

    test_suite = unittest.TestLoader().loadTestsFromTestCase(Test)

    return test_su

# Generated at 2022-06-12 07:40:04.844440
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        raise IllegalUseOfScopeReplacer('foo', 'bad')
    except IllegalUseOfScopeReplacer as e:
        s = repr(e)
        assert isinstance(s, str)
        assert isinstance(u'%s' % e, unicode)



# Generated at 2022-06-12 07:40:37.844779
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str, not unicode.

    This is a regression test for
    https://bugs.launchpad.net/bzr/+bug/897296
    """
    # Test __str__ on an exception with a non-ascii string on it.
    e = IllegalUseOfScopeReplacer('name', u'non-ascii -> \x9c')
    s = str(e)
    if isinstance(s, unicode):
        raise AssertionError('str(e) should return a str, not unicode. got %s' % (s,))
    # Test __str__ on an exception with a non-ascii format string on it.
    e._fmt = u'non-ascii format -> %(name)s'
    s = str(e)

# Generated at 2022-06-12 07:40:42.912694
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This method should return a unicode string, independent from the system
    encoding.
    """
    import sys
    import bzrlib

    expected = u'lala'
    instance = bzrlib.lazy_import.IllegalUseOfScopeReplacer(
        name='foo', msg=expected)
    result = instance.__unicode__()
    if result != expected:
        raise AssertionError(
            "__unicode__ returned %r, expected %r" % (result, expected))



# Generated at 2022-06-12 07:40:47.074735
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    Convert to unicode.
    """
    e = IllegalUseOfScopeReplacer("blah", "I did something")
    u = unicode(e)
    s = "IllegalUseOfScopeReplacer object 'blah' was used incorrectly: I did something"
    assert u == s
    # Check that __unicode__() always returns a unicode object.
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:40:57.298160
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase

    class ScopeReplacerTestCase(TestCase):

        def test__setattr__(self):
            scope = {'ScopeReplacer_has_been_replaced': False}
            def factory(self, scope, name):
                scope['ScopeReplacer_has_been_replaced'] = True
                # Return an object with a custom __setattr__ method.
                class Object(object):
                    def __setattr__(self, attr, value):
                        scope[attr] = value
                return Object()
            scope_replacer = ScopeReplacer(scope, factory, 'key')
            scope_replacer.attr = 'value'
            self.assertEqual('value', scope['attr'])

    loader = TestUtil.TestLoader()
    suite = loader.suiteClass()
   

# Generated at 2022-06-12 07:41:07.762003
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    global bzrlib
    bzrlib = None
    class C(object):
        pass
    global C
    C = None
    class D(C):
        pass
    global D
    D = None
    class bzrlib(object):
        class C(object):
            pass
        class D(C):
            pass
    bzrlib = ScopeReplacer(locals(), lambda obj, scope, name: globals()['bzrlib'], 
                           'bzrlib')
    assert bzrlib.C == bzrlib.C
    assert bzrlib.D == bzrlib.D
    assert bzrlib.C == bzrlib.C
    assert bzrlib.D == bzrlib.D



# Generated at 2022-06-12 07:41:10.187335
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Testing method __setattr__ of class ScopeReplacer
    # Initialising arguments
    # Checking if test is ok
    assert True==True


# Generated at 2022-06-12 07:41:21.014534
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Check attribute is set on real object not proxy (only happens when
    real object has already been created)
    """
    from bzrlib.lazy_import import lazy_import
    globals()['test_ScopeReplacer___setattr__'] = 'overridden'
    test = None
    #lazy import will create proxy object
    lazy_import(globals(), '''
    test = test_ScopeReplacer___setattr__
    ''')
    # Call the function so that the proxy will be replaced with a real
    # object.
    test()
    ScopeReplacer._should_proxy = False
    try:
        test.t = 'overridden'
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'test'

# Generated at 2022-06-12 07:41:22.660195
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = IllegalUseOfScopeReplacer('name', 'msg').__unicode__()
    assert isinstance(u, unicode), u

# Generated at 2022-06-12 07:41:26.672208
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def _factory(self, scope, name):
        return lambda x:x+1
    lazy = ScopeReplacer({}, _factory, 'foo')
    assert lazy(1) == 2



# Generated at 2022-06-12 07:41:32.708256
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return unicode.

    This is what is needed for bzrlib test infrastructure.
    """
    e = IllegalUseOfScopeReplacer('a', 'b')
    assert isinstance(unicode(e), unicode)
    assert unicode(e) == 'b: a'
    assert repr(e) == "IllegalUseOfScopeReplacer('a', 'b')"



# Generated at 2022-06-12 07:41:55.614664
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return object repr as unicode"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    if sys.version_info < (3,0):
        cls = "IllegalUseOfScopeReplacer"
    else:
        cls = "bzrlib.lazy_import.IllegalUseOfScopeReplacer" # XXX \u
    e = IllegalUseOfScopeReplacer('name', 'm\xe9ssage', 'extra')
    u = e.__unicode__()
    i = u.find(cls)
    if i==-1:
        raise AssertionError("__unicode__() returned %r which does not"
                             " contain class %r" % (u, cls))

# Generated at 2022-06-12 07:42:02.369834
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() must return a str object"""
    def check(exc):
        s = str(exc)
        if not isinstance(s, str):
            raise AssertionError('type of s is %r' % type(s))
    check(IllegalUseOfScopeReplacer('name', 'message', 'extra'))
    # Also check that the exception is correctly raised

# Generated at 2022-06-12 07:42:10.892037
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    this_module = sys.modules[__name__]
    def factory(self, scope, name):
        return 'lazily loaded'
    lazy = ScopeReplacer(this_module.__dict__, factory, 'lazy')
    # First access to _resolve triggers factory, so attribute _real_obj exists
    # (and resolves to 'lazily loaded'
    assert lazy._resolve() == 'lazily loaded'
    assert ScopeReplacer._should_proxy
    assert lazy._resolve() == 'lazily loaded'
    assert lazy._resolve() == 'lazily loaded'
    assert lazy.__getattribute__('_resolve')() == 'lazily loaded'
    assert lazy.__getattribute__('_resolve') == object.__getattribute__(lazy, '_resolve')


# Generated at 2022-06-12 07:42:18.521632
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__

    In a variation on the old-hpux test case, we want to check that
    IllegalUseOfScopeReplacer behaves reasonably when its format string has
    conversion specifiers in it, but 'self' doesn't have an attribute to
    match it.
    """
    e = IllegalUseOfScopeReplacer('foo', 'message')
    e._fmt = "Hi %(name)s, I have %(number)d messages for you."
    str(e)



# Generated at 2022-06-12 07:42:21.130642
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    obj = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    assert str(obj) == 'ScopeReplacer object \'name\' was used incorrectly:' \
        ' message: extra'



# Generated at 2022-06-12 07:42:24.760373
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    #__unicode__ should return a unicode object.
    s=IllegalUseOfScopeReplacer("them","they")
    assert isinstance(s.__unicode__(), unicode)
    # And it should return the same thing as __str__()
    assert s.__unicode__() == s.__str__()


# Generated at 2022-06-12 07:42:35.865394
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    # test__call__
    factory = lambda : lambda y:y
    lazy_import(globals(), '''
    from bzrlib import (
        lazy_import,
        )
    ''')

# Generated at 2022-06-12 07:42:45.144324
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should convert to UTF-8"""
    import sys
    if sys.version_info < (3, 0):
        base_err = Exception()
    else:
        base_err = object()
    class Test(base_err, IllegalUseOfScopeReplacer):
        def __init__(self, name, msg):
            super(Test, self).__init__(name, msg)
    e = Test('name', 'message')
    s = str(e)
    # Test will either be a Unicode, or a Bytes string.
    if type(s) is not unicode:
        s = s.decode('utf8')
    assert u'name' in s
    assert u'message' in s



# Generated at 2022-06-12 07:42:53.909405
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        )
    import bzrlib.branch
    ''')
    del sys.modules['bzrlib.lazy_import']
    errors
    #Unit test for method __getattribute__ of class ScopeReplacer
    def test_ScopeReplacer___getattribute__():
        import sys
        import bzrlib
        from bzrlib.lazy_import import lazy_import
        lazy_import(globals(), '''
        from bzrlib import (
            errors,
            osutils,
            )
        import bzrlib.branch
        ''')


# Generated at 2022-06-12 07:43:05.395117
# Unit test for method __setattr__ of class ScopeReplacer