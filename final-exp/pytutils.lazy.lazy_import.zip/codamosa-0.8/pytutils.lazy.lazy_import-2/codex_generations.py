

# Generated at 2022-06-12 07:33:49.594846
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import doctest
    global ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    doctest.run_docstring_examples(ScopeReplacer.__setattr__, globals())


# Generated at 2022-06-12 07:33:55.619243
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    expected = 'Unprintable exception IllegalUseOfScopeReplacer: ' \
               'dict={\'name\': \'foo\', \'msg\': \'bar\', \'extra\': \'\'}, ' \
               'fmt=None, error=None'
    actual = e.__unicode__()
    assert isinstance(actual, unicode), repr(actual)
    assert actual == expected, repr(actual)


# Generated at 2022-06-12 07:34:06.375049
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode string for all inputs.

    It should be possible to provide all string kinds (str, unicode,
    subclass of basestring).

    Also provide a test for passing no parameters.
    """

    e = IllegalUseOfScopeReplacer("name", "msg")
    # we use 'is' to make sure a new object is *not* generated
    assert e.__unicode__() is e.__unicode__()

    e = IllegalUseOfScopeReplacer("name", "msg")
    assert e.__unicode__() == u'ScopeReplacer object u\'name\' was used incorrectly: msg'

    e = IllegalUseOfScopeReplacer("name", "msg", "extra")

# Generated at 2022-06-12 07:34:14.594744
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib import (
        errors
        )
    lazy_import(locals(), '''
    from bzrlib import (
        errors,
        )
    ''')
    try:
        # Calling errors should have made the module load.
        errors(1, 2)
    except TypeError:
        # Python 2.6 doesn't let you pass args to errors
        pass



# Generated at 2022-06-12 07:34:24.364324
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from unittest import TestCase

    class T(TestCase):
        def __init__(self, *args, **kwargs):
            TestCase.__init__(self, *args, **kwargs)

            self.__class__.__setattr__ = self.__setattr__

        def __setattr__(self, attr, value):
            self.__class__.__setattr__ = TestCase.__setattr__
            TestCase.__setattr__(self, attr, value)

    test = T("test")
    scope = {}
    scope['test'] = ScopeReplacer(scope, lambda _, __, ___: test, 'test')
    scope['test'].foo = "bar"
    test.assertEqual("bar", test.foo)

# Generated at 2022-06-12 07:34:26.827432
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return the same string as
    str(e) where e is an instance of IllegalUseOfScopeReplacer."""
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    assert str(e) == e.__str__()



# Generated at 2022-06-12 07:34:37.166245
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    class Foo(object):
        def __init__(self):
            self.bar = 1
    def factory(self, scope, name):
        return Foo()
    scope = {}
    # Test that __setattr__ will change the attribute 'bar' of the
    # object on which __setattr__ is called. This is the case
    # because the value of the attribute '_should_proxy' is True.
    lazy_import(scope, 'from bzrlib.lazy_import import ScopeReplacer')

# Generated at 2022-06-12 07:34:44.944309
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    global _unused
    klass = ScopeReplacer
    def _get_klass():
        global _unused
        _unused += 1
        return klass
    class _DummyScope(object):
        pass
    ScopeReplacer._should_proxy = False
    _unused = 0
    dummy = _DummyScope()
    dummy.a = 1
    d = ScopeReplacer(dummy, _get_klass, 'a')
    e = d
    d.x = 1

# Generated at 2022-06-12 07:34:55.632499
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import _bzrlib
    import _bzrlib.branch
    import _bzrlib.config
    import _bzrlib.log
    import _bzrlib.merge
    import _bzrlib.osutils
    import _bzrlib.trace
    import _bzrlib.transport
    for r in ('_bzrlib', '_bzrlib.branch', '_bzrlib.config', '_bzrlib.log',
        '_bzrlib.merge', '_bzrlib.osutils', '_bzrlib.trace',
        '_bzrlib.transport'):
        assert r not in globals()
        global scope
        scope = globals()

# Generated at 2022-06-12 07:34:58.847569
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return the error message (ascii)"""
    e = IllegalUseOfScopeReplacer('spam', 'eggs')
    assert e.__str__() == "eggs"

# Generated at 2022-06-12 07:35:16.891830
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib.errors
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        )
    import bzrlib.errors
    ''')
    obj = errors
    try:
        obj.NoSuchFile()
    except NotImplementedError:
        pass # bzrlib.errors.NoSuchFile is not callable.
    else:
        raise AssertionError("obj.NoSuchFile() has not raised NotImplementedError")


# Generated at 2022-06-12 07:35:26.348833
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Testing IllegalUseOfScopeReplacer.__unicode__()"""
    import sys
    if sys.hexversion < 0x020400F0:
        raise TestSkipped("Python 2.4 needed")
    e = IllegalUseOfScopeReplacer("name", "msg", "extra")
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly:" \
        " msg: extra"
    assert e.__repr__() == \
        "IllegalUseOfScopeReplacer("\
        "\"ScopeReplacer object 'name' was used incorrectly: msg: extra\")"



# Generated at 2022-06-12 07:35:29.712399
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import weakref
    # Test __getattribute__ method of class ScopeReplacer


# Import test suite definitions
from bzrlib.tests import TestCaseWithMemoryTransport


# Generated at 2022-06-12 07:35:38.765153
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """exception objects without a format string are still printable"""
    from bzrlib.tests.test_i18n import unwrap_and_verify
    msg = "something something dark side"
    e = unwrap_and_verify(IllegalUseOfScopeReplacer("dummy", msg), str, "Unprintable exception IllegalUseOfScopeReplacer: dict={'name': 'dummy', 'msg': 'something something dark side', 'extra': ''}, fmt=None, error=None")
# End test_IllegalUseOfScopeReplacer___unicode__


# Generated at 2022-06-12 07:35:45.950292
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib import lazy_import
    class IllegalUseOfScopeReplacer_Unprintable(lazy_import.IllegalUseOfScopeReplacer):
        pass
    x = IllegalUseOfScopeReplacer_Unprintable('x', 'Unprintable')
    # The unicode representation must be ascii (or the test will fail)
    try:
        unicode(x)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError("representation must be ascii")



# Generated at 2022-06-12 07:35:54.363093
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import lazy_import
    scope = globals()
    scope['x'] = None
    sr = lazy_import.ScopeReplacer(scope, lambda s, scope, name: name, 'x')
    if lazy_import.ScopeReplacer._should_proxy:
        if sr != 'x': raise AssertionError
    else:
        try:
            sr != 'x'
        except lazy_import.IllegalUseOfScopeReplacer as e:
            if str(e) != (
                    "ScopeReplacer object 'x' was used incorrectly:"
                    " Object already replaced, did you assign it to another"
                    " variable?"):
                raise AssertionError
        else:
            raise AssertionError


# Generated at 2022-06-12 07:35:59.795277
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class Dummy(object):
        def __setattr__(self, attr, value):
            setattr(self, attr, value)

    f = Dummy()
    f.a = 0
    x = ScopeReplacer({}, lambda _a, _s, _n: f, 'x')
    x.a = 3
    x.a
    x.a
    assert f.a == 3


# Generated at 2022-06-12 07:36:11.265569
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    class A(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def _get_foo(self):
            return self.foo
    class B(A):
        foo = 'bar'
    scope = {}
    name = 'test_obj'
    b1 = B('foo', bar='baz')
    b2 = B('foo', bar='baz')

# Generated at 2022-06-12 07:36:17.418189
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # __str__ should always return a str.
    # We report this by throwing an exception out of __str__
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    """)
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    try:
        str(e)
    except TypeError:
        pass
    else:
        raise AssertionError('str(e) should have raised TypeError')
    # and unicode does the same
    try:
        unicode(e)
    except TypeError:
        pass
    else:
        raise AssertionError('unicode(e) should have raised TypeError')
    # and str(unicode(e))

# Generated at 2022-06-12 07:36:26.183637
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    import sys
    # test with a unicode string
    e1 = IllegalUseOfScopeReplacer('foo', 'un printable', extra='bar')
    e1._fmt = 'this will be a unicode string'
    u = unicode(e1)
    if sys.version_info[0] == 2:
        expected = u'this will be a unicode string: un printable: bar'
    else:
        expected = 'this will be a unicode string: un printable: bar'
    if u != expected:
        raise AssertionError('u=%r, expected=%r' % (u, expected))

    # test with a ascii string that doesn't decode into utf-8
    e2 = IllegalUseOfScopeRepl

# Generated at 2022-06-12 07:36:39.495481
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # This is a test of a method that is not even used. It's mainly here to make
    # the API doc of __setattr__ more readable.
    import bzrlib.lazy_import.scope
    scope = {}
    scope['foo'] = bzrlib.lazy_import.scope.ScopeReplacer(scope, None, 'foo')
    scope['foo'].bar = 42
    assert scope['foo'].bar == 42


# Generated at 2022-06-12 07:36:47.961624
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # test_lazy_import.py::test_ScopeReplacer___setattr__
    import bzrlib.test_lazy_import
    bzrlib.test_lazy_import._test_module_name = 'bzrlib.tests.test_lazy_obj'
    try:
        from bzrlib.tests import test_lazy_obj as _mod_test_lazy_obj
    except ImportError:
        pass
    else:
        _mod_test_lazy_obj.raise_error = '1'
    try:
        from bzrlib.tests import test_lazy_obj as _mod_test_lazy_obj
    except ImportError:
        pass
    else:
        _mod_test_lazy_obj.raise_error = '1'

# Generated at 2022-06-12 07:36:57.631554
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test IllegalUseOfScopeReplacer.__str__"""
    # Calling '__str__' on a IllegalUseOfScopeReplacer object with a 'str' value of
    # '_preformatted_string' should return a 'str' string.
    e = IllegalUseOfScopeReplacer('a', 'b', u'la la la')
    e._preformatted_string = 'c'
    assert isinstance(e.__str__(), str)

    # Calling '__str__' on a IllegalUseOfScopeReplacer object with an 'unicode' value of
    # '_preformatted_string' should return a 'str' string.
    e = IllegalUseOfScopeReplacer('a', 'b', u'la la la')
    e._preformatted_string = u'd'

# Generated at 2022-06-12 07:37:05.676665
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    msg = 'test'
    # the str object should be the same object
    # as the object returned by __str__
    e = IllegalUseOfScopeReplacer('name', msg)
    s = str(e)
    assert s is e.__str__()
    # the str object should be a ascii string
    assert isinstance(s, str)
    # the bytes in the str object must be the same as the bytes in msg
    assert s == msg
    # try a unicode error message
    e = IllegalUseOfScopeReplacer('name', u't\xe9st')
    s = str(e)
    # and it too should be a str
    assert isinstance(s, str)
    # and the bytes in the str should be the same as the utf8 string
   

# Generated at 2022-06-12 07:37:16.635965
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    # actually this test tests the whole class, especially the
    # __unicode__() method.
    class Foo(IllegalUseOfScopeReplacer):
        _fmt = '%(name)r: %(msg)s\n'

    s = 'scoped replacer'
    u = u'\u2020'
    for m in (u'foo bar', '\u2020 baz', u'\u2020 baz'):
        import sys
        # make sure exception percolates all the way up
        try: raise Foo(s, m)
        except Exception as e:
            assert str(e) == s + ': ' + m + '\n'
            ue = unicode(e)
            assert isinstance(ue, unicode)
            assert ue

# Generated at 2022-06-12 07:37:24.462090
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ raises IllegalUseOfScopeReplacer when object already created.
    """
    # Create artificial object mock.
    class MockScopeReplacer:
        def __setattr__(self, attr, value):
            raise AssertionError('Unexpected setattr')
    class MockClass:
        def __setattr__(self, attr, value):
            raise AssertionError('Unexpected setattr')

    import bzrlib.tests.test_lazy_import as test_mod
    import sys
    name = '_test_mod_obj'

# Generated at 2022-06-12 07:37:35.726540
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import warnings
    warnings.simplefilter('ignore', DeprecationWarning)
    import testhelper
    testhelper.initialize()
    import bzrlib.lazy_import
    e = bzrlib.lazy_import.ScopeReplacer.__getattribute__.im_func.func_globals['e']
    e['bzrlib.lazy_import'] = testhelper.lazy_import

# Generated at 2022-06-12 07:37:40.153701
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object if format dict items are also
    unicode objects.
    """
    ex = IllegalUseOfScopeReplacer(u'expected', u'expected', u'expected')
    result = unicode(ex)
    # The string should be unicode:
    assert isinstance(result, unicode), "%r is not unicode" % result


# Generated at 2022-06-12 07:37:50.955695
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class TestClass(object):
        TestClass.x = "y"
    class TestClass(object):
        pass
    class TestClass(object):
        def __init__(self, scope, factory, name):
            object.__setattr__(self, '_scope', scope)
            object.__setattr__(self, '_factory', factory)
            object.__setattr__(self, '_name', name)
            object.__setattr__(self, '_real_obj', None)
            scope[name] = self
        def _resolve(self):
            name = object.__getattribute__(self, '_name')
            real_obj = object.__getattribute__(self, '_real_obj')

# Generated at 2022-06-12 07:37:58.339919
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing IllegalUseOfScopeReplacer.__str__"""
    # We use a scope replacer to test the scope replacer.
    scope_replacer = ScopeReplacer()
    # The scope replacer will be used illegally.
    scope_replacer.illegal_use_caught = True
    scope_replacer.illegal_use_msg = ("The scope replacer %r was used "
                                      "incorrectly.")
    scope_replacer.illegal_use_extra = ("The scope replacer should have been "
                                        "replaced before being used.")
    # Now make an IllegalUseOfScopeReplacer.
    s = IllegalUseOfScopeReplacer('test_replacer', 'test_msg')
    # The text should be:
    # 'ScopeReplacer object 'test_replacer' was used incorrectly: test_msg'

# Generated at 2022-06-12 07:38:17.458822
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """This tests the method __call__ of class ScopeReplacer

    The purpose is to verify that the object replacer behaves like
    the object it replaces when called.
    """
    class ClassToReplace(object):
        def my_method(self):
            return self

    globals_ = globals()
    class_to_replace = ClassToReplace()
    class_to_replace.my_method() # make sure it's callable
    replacer = ScopeReplacer(globals_, lambda r,s,n: class_to_replace, 'class_to_replace')
    result = replacer()
    assert_is(class_to_replace, result)



# Generated at 2022-06-12 07:38:23.599382
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    scope = {}
    import bzrlib.tests
    def factory(replacer, scope, name):
        return bzrlib.tests
    name = 'bzrlib.tests'
    sr = ScopeReplacer(scope, factory, 'bzrlib.tests')
    obj = object.__getattribute__(sr, '_resolve')()
    if not(isinstance(obj, ModuleType)):
        raise AssertionError


# Generated at 2022-06-12 07:38:31.738302
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class myclass:
        def __init__(self, value=None):
            self.value = value
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import _lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    def _factory(self, scope, name):
        return myclass('Hi')
    # Create a ScopeReplacer object
    ScopeReplacer(locals(), _factory, 'myclass')
    # Call method __setattr__
    myclass.__setattr__('value', 42)
    # Check basic assumptions
    assert locals()['myclass'].value == 'Hi'
    # Check that instance attributes are proxied
    assert myclass.value == 42

# Generated at 2022-06-12 07:38:36.516131
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode"""
    example = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(unicode(example), unicode), \
        "IllegalUseOfScopeReplacer.__unicode__() must return a unicode"


# Generated at 2022-06-12 07:38:42.955468
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This code should always raise a UnicodeDecodeError"""
    import sys
    try:
        msg = '\xc3\x28'
        try:
            unicode(msg, 'utf-8')
        except:
            pass # just bind to 'e' for formatting below
        e = sys.exc_info()[1]
        raise IllegalUseOfScopeReplacer(u'module.name', msg, e)
    except IllegalUseOfScopeReplacer as e:
        try:
            unicode(e)
        except:
            pass # just bind to 'e' for formatting below
        e = sys.exc_info()[1]
        assert isinstance(e, UnicodeDecodeError)


# Generated at 2022-06-12 07:38:52.789378
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    def check(instance, expected):
        """Check that instance.__unicode__() == expected"""
        actual = unicode(instance)
        if actual == expected:
            return
        import difflib
        raise AssertionError(
            'Error in IllegalUseOfScopeReplacer.__unicode__: '
            'difference between actual and expected values:\n%s'
            % difflib.unified_diff(expected, actual))
    check(
        IllegalUseOfScopeReplacer('a', 'b'),
        u'IllegalUseOfScopeReplacer(a, b)')
    check(
        IllegalUseOfScopeReplacer('a', 'b', 'c'),
        u'IllegalUseOfScopeReplacer(a, b, c)')


# Generated at 2022-06-12 07:39:03.875749
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    done = False
    import bzrlib
    class DummyScope(object):
        pass
    ds = DummyScope()
    ds.done = False
    sr = ScopeReplacer(ds, lambda ds,s,n: ds, 'bzrlib')
    sr2 = ScopeReplacer(ds, lambda ds,s,n: ds, 'done')
    # Assign the same object to itself and check that this results in a
    # exception.
    sr.bzrlib = sr
    # Check that calling __setattr__ with the same attribute twice performs
    # the assignment twice.
    sr.done = True
    sr2.done = True
    if not done:
        raise AssertionError('sr.done was not True')
    if not ds.done:
        raise AssertionError

# Generated at 2022-06-12 07:39:14.737891
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), """
from bzrlib import (
    contrib,
    errors,
    osutils,
    branch,
    )
""")
    import bzrlib.trace
    def fake_factory(self, scope, name):
        errors.BzrError("This is a BzrError")
        return None
    def fake_factory2(self, scope, name):
        raise Exception("This is an Exception")
    def fake_factory3(self, scope, name):
        return None
    bzrlib.trace.ScopeReplacer(globals(), fake_factory2, 'fake_var_name')

# Generated at 2022-06-12 07:39:17.569737
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ on IllegalUseOfScopeReplacer should encode str attributes."""
    x = IllegalUseOfScopeReplacer('x', 'byte str')
    x._preformatted_string = 'preformatted: x'
    assert type(unicode(x)) is unicode
    assert unicode(x) == u'preformatted: x'



# Generated at 2022-06-12 07:39:22.769783
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns unicode"""
    obj = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(obj)
    assert isinstance(u, unicode)
    assert u.encode('utf8') == str(obj)
test_IllegalUseOfScopeReplacer___unicode__.expected = 2

# Generated at 2022-06-12 07:39:44.413040
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import tests.test_lazy_import
    q = tests.test_lazy_import.LazyImportTests
    # test_ScopeReplacer___call__ test the pass case
    obj = ScopeReplacer(sys.modules, lambda self, scope, name: q, 'q')
    q = obj
    # test_ScopeReplacer___call__ test the exception block
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-12 07:39:52.459926
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    from bzrlib.lazy_import import ScopeReplacer
    globs = globals()
    globs = globs.copy()
    doctest.run_docstring_examples(ScopeReplacer.__call__, globs, verbose=True)
globals()['test_ScopeReplacer___call__'] = test_ScopeReplacer___call__


# Generated at 2022-06-12 07:39:58.968367
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ methods should always return unicode objects."""
    name = 'bzrlib.foo.bar'
    msg = 'some message that needs to convert to utf8'
    extra = 'some extra stuff that needs to convert to utf8'
    exc = IllegalUseOfScopeReplacer(name, msg, extra=extra)
    assert isinstance(exc.__unicode__(), unicode)
    assert isinstance(exc.__str__(), str)



# Generated at 2022-06-12 07:40:06.919341
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    from bzrlib import errors
    global fake_globals
    fake_globals = {'errors':errors}
    lazy_import(fake_globals, '''
    from bzrlib import errors
    ''')
    import bzrlib.errors
    def test_getattr_with_custom_classes():
        # If a ScopeReplacer was used as a base class and then later a class
        # was defined as inheriting from it, we need to make sure that
        # __getattribute__ will still work properly.
        class MyBase(ScopeReplacer):
            pass
        class MyClass(MyBase):
            def __init__(self, value):
                MyBase.__init__(self, value)

# Generated at 2022-06-12 07:40:16.604765
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    from bzrlib.tests import test_lazy_import
    from bzrlib.tests.test_lazy_import import TestScopeReplacer
    return doctest.DocTestSuite(test_lazy_import,
                                test_extraglobs={'TestScopeReplacer':TestScopeReplacer},
                                optionflags=(doctest.ELLIPSIS | doctest.REPORT_UDIFF))

    doctest.DocTestSuite(test_lazy_import,
                         test_extraglobs={'TestScopeReplacer':TestScopeReplacer},
                         optionflags=(doctest.ELLIPSIS | doctest.REPORT_UDIFF))

    import testtools

# Generated at 2022-06-12 07:40:18.641093
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def take_args(obj, scope, name):
        return True
    lazy_object = ScopeReplacer({}, take_args, 'lazy_object')
    lazy_object.x = 1


# Generated at 2022-06-12 07:40:25.091368
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() and __unicode__()

    __str__ should return a str
    __unicode__ should return a unicode
    """
    # Test the __str__ method, which should return a str object.
    e = IllegalUseOfScopeReplacer('test', 'hello')
    s = str(e)
    u = unicode(e)
    assert isinstance(s, str), '%r is not a str' % (s,)
    assert isinstance(u, unicode), '%r is not a unicode' % (u,)
    # Test with extra data
    e = IllegalUseOfScopeReplacer('test', 'hello', 'extra')
    s = str(e)
    u = unicode(e)

# Generated at 2022-06-12 07:40:34.170128
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should always return unicode"""
    class _(Exception):
        _fmt = 'foo'
    u = unicode(_())
    assert isinstance(u, unicode)
    # Now, if the system encoding is not utf-8, and the format string
    # contains a non-ascii char, we will get an exception.
    # Alternatively, the gettext function does not strip the 'u' prefix.
    # In this case, the constructor of class _() will fail with a UnicodeError.
    # There is no way to unit test this but only to run the test suite
    # with different encodings.



# Generated at 2022-06-12 07:40:42.513238
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object.

    __unicode__ should return a unicode object.

    It should work if _fmt is ascii or utf-8 encoded.
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    # Check with an ascii _fmt.
    exc = IllegalUseOfScopeReplacer('foo', 'some message', extra='hello')
    exc._fmt = 'Test: _fmt was ascii'
    u = unicode(exc)
    # u should be a unicode object, not ascii.
    if isinstance(u, str):
        raise AssertionError('u should be a unicode object, not str: %r' % (u,))

    # Check with an utf-8 encoded _fmt.
   

# Generated at 2022-06-12 07:40:48.928908
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    class A:
        def __init__(self):
            self.a = 1
        def getb(self):
            return self.b
    class B:
        def __init__(self):
            self.b = 2
        def geta(self):
            return self.a
    class C(A, B):
        pass
    class D(object):
        def __init__(self, real_obj):
            self.real_obj = real_obj
        def _resolve(self):
            return self.real_obj
    class E(object):
        def __init__(self):
            pass
        def getattr(self, x):
            return x
        def __getattribute__(self, x):
            return super(E, self).__getattribute__

# Generated at 2022-06-12 07:41:22.654671
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test for __unicode__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('foo', 'foobar', 'foobar')
    u = unicode(e)
    # Test that 'u' contains the expected string
    expected = "ScopeReplacer object 'foo' was used incorrectly: foobar: foobar"
    if u != expected:
        raise AssertionError("__unicode__ returned %r instead of %r"
                             % (u, expected))
    # Test that 'u' is a unicode object
    if not isinstance(u, unicode):
        raise AssertionError("__unicode__ returned object of type %s,"
                             " instead of type unicode" % type(u))

# Generated at 2022-06-12 07:41:30.986906
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """function __call__ of class ScopeReplacer."""

    # the function ScopeReplacer.__call__ needs a real object in the
    # attribute _real_obj.
    r = ScopeReplacer({}, lambda s, s2, n: s._real_obj, '')
    # attribute _real_obj is a lambda
    object.__setattr__(r, '_real_obj', lambda: 42)
    # so the function __call__ simply returns 42
    assert r() == 42



# Generated at 2022-06-12 07:41:34.720813
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    obj = ScopeReplacer(bzrlib, id, 'branch')
    obj.a = 1
    bzrlib.branch.a
    obj.b = 2
    bzrlib.branch.b



# Generated at 2022-06-12 07:41:37.697783
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    r = IllegalUseOfScopeReplacer('replacer', 'message')
    s = str(r)
    assert s is not None



# Generated at 2022-06-12 07:41:40.314409
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method IllegalUseOfScopeReplacer.__str__
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:41:51.817047
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # We have to use the valid name for the method '__setattr__' because
    # another python implementation (IronPython) uses 'set' as the name of
    # this method.
    from bzrlib import lazy_import
    #print help(lazy_import)
    #print dir(lazy_import)
    #a1 = 1
    #print a1
    #a1 = 2
    #print a1
    #lazy_import.z = 1
    #print lazy_import.z
    #a1 = lazy_import
    #print a1.z
    #a1.z = 2
    #print lazy_import.z
    #a1 = 1
    #print a1
    #a1 = 2
    #print a1
    #a1 = 3
    #print a1
    #

# Generated at 2022-06-12 07:41:56.373832
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('e', 'message')
    u = e.__unicode__()
    assert isinstance(u, unicode), repr(u)

# Generated at 2022-06-12 07:42:06.751438
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should work in the same way as setattr"""
    import bzrlib
    # Make sure __setattr__ is available
    assert(hasattr(ScopeReplacer, '__setattr__'))
    # Create test instance
    x = ScopeReplacer(bzrlib.__dict__, lambda self, scope, name: self, 'x')
    # Set test attribute
    x.foo = 'bar'
    assert(hasattr(x, 'foo'))
    assert(getattr(x, 'foo') == 'bar')
    # Assign value using setattr
    setattr(x, 'foo2', 'bar2')
    assert(hasattr(x, 'foo2'))
    assert(getattr(x, 'foo2') == 'bar2')



# Generated at 2022-06-12 07:42:14.752742
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """class IllegalUseOfScopeReplacer: __str__"""
    # Single-line repr only needs to be a repr
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    expected = ("%s(%r, %r, %r)" %
        (e.__class__.__name__, e.name, e.msg, e.extra))
    actual = repr(e)
    if expected != actual:
        raise AssertionError("%r != %r" % (expected, actual))



# Generated at 2022-06-12 07:42:21.777972
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    r"""ScopeReplacer.__call__: Unit test for method ScopeReplacer.__call__

    This test ensures that the call method of the ScopeReplacer class
    creates a new object.
    """
    from bzrlib import lazy_import

# Generated at 2022-06-12 07:42:46.336498
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # This method is tested via the lazy_import method
    pass

# Generated at 2022-06-12 07:42:50.813523
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer.

    This method is required because it is used by the
    traceback module.
    """
    error = IllegalUseOfScopeReplacer('name', 'msg')
    str(error)
    unicode(error)

# Generated at 2022-06-12 07:43:01.696379
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """ScopeReplacer.__setattr__ is enabled from 3.2.3 onwards

    As a workaround for http://bugs.python.org/issue1233 we disable the
    __setattr__ hook on ScopeReplacers, which means that if you assign a
    ScopeReplacer to a variable, you can't use that variable to get at the
    object that the ScopeReplacer will eventually resolve to.

    The ScopeReplacer.__getattribute__ hook is still enabled, which means
    that you can use the name that the ScopeReplacer was loaded into to get
    at the object it will resolve to. In other words, you can use the
    imported name but not any local variables you've assigned it to.

    """
    # Test that we can succeed when __setattr__ is enabled.
    ScopeReplacer._should_proxy = True
    foo = {}
    lazy_import

# Generated at 2022-06-12 07:43:06.085214
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib.tests
    scope = sys._getframe(1).f_globals
    scope["Test_ScopeReplacer"] = ScopeReplacer(scope, lambda self, scope, name: bzrlib.tests.TestCase, "Test_ScopeReplacer")
    scope["Test_ScopeReplacer"]()

# Generated at 2022-06-12 07:43:09.534703
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test method __str__ of class IllegalUseOfScopeReplacer """
    e = IllegalUseOfScopeReplacer('foo', "msg", extra='extra')
    str(e)
    unicode(e)


# Generated at 2022-06-12 07:43:12.823362
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    repr(e)
    e.__unicode__()

# Generated at 2022-06-12 07:43:17.491889
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This tests the method IllegalUseOfScopeReplacer.__unicode__."""
    # __unicode__ should return a unicode object
    x = IllegalUseOfScopeReplacer("my_name", "my_msg")
    assert isinstance(x.__unicode__(), unicode)



# Generated at 2022-06-12 07:43:22.054472
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit tests for method __unicode__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('__init__', 'msg', 'extra')
    # Check that IllegalUseOfScopeReplacer has a '__unicode__' method
    unicode(e)
    # Check that IllegalUseOfScopeReplacer has a '__str__' method
    str(e)



# Generated at 2022-06-12 07:43:31.060589
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    # Standard setattr test
    bzrlib.tests.TestCase.addDetail('setattr')
    bzrlib.tests.TestCase.failUnlessRaises(AssertionError,
                                           setattr,
                                           ScopeReplacer, 'foo', 'bar')
    # Method test
    bzrlib.tests.TestCase.addDetail('_resolve')
    bzrlib.tests.TestCase.failUnlessRaises(AttributeError,
                                           setattr,
                                           ScopeReplacer, '_resolve', 'bar')
    # Data test
    bzrlib.tests.TestCase.addDetail('__doc__')