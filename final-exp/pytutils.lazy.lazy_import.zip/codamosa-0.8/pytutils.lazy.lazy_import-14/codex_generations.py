

# Generated at 2022-06-12 07:33:50.329067
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Ensure ImportReplacer handles the constructor arguments correctly"""
    name = 'foo'
    module_path = ['bzrlib', 'foo']
    member = 'bar'
    children = [('foo1', (['bzrlib', 'foo', 'foo1'], None, {})),
                ('foo2', (['bzrlib', 'foo', 'foo2'], None, {}))]

    def _get_ir(member=None, children=None):
        """Return an ImportReplacer instance, either with member or children"""
        if member is not None:
            return ImportReplacer(globals(), name=name,
                                  module_path=module_path, member=member)
        else:
            if children is None:
                children = {}
            children = dict(children)

# Generated at 2022-06-12 07:33:53.783948
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str object."""
    e = IllegalUseOfScopeReplacer(1, 2, 3)
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-12 07:34:05.358695
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    scope = {'a': 1, 'b': 2}
    def factory(self, scope, name):
        return scope.get(name)
    def identity(obj):
        return obj
    def exception(obj):
        raise RuntimeError('unexpected call')
    name = 'a'
    replacer = ScopeReplacer(scope, factory, name)
    # __getattribute__ should raise if the object has already been replaced.
    replacer._should_proxy = False
    replacer._real_obj = 1

# Generated at 2022-06-12 07:34:17.723341
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:34:25.035991
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class A(object):
        def __call__(self, a, b, c):
            return a, b, c
    factory = lambda self, scope, name: A()
    scope = {}
    name = 'A'
    sr = ScopeReplacer(scope, factory, name)
    a = sr(1, 2, 3)
    want = (1, 2, 3)
    try:
        assert a == want
    except AssertionError:
        raise AssertionError("got %r, want %r" % (a, want))


# Generated at 2022-06-12 07:34:36.448067
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests import TestCaseAdaptor

    test = TestCaseAdaptor(IllegalUseOfScopeReplacer)

    test.dummy_implementation('_get_format_string')
    test.dummy_implementation('_format')

    test.assertEqual(
        IllegalUseOfScopeReplacer('name1', 'message1'),
        IllegalUseOfScopeReplacer('name1', 'message1'))
    class SubclassedIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        pass

    test.assertNotEqual(
        IllegalUseOfScopeReplacer('name1', 'message1'),
        SubclassedIllegalUseOfScopeReplacer('name1', 'message1'))

# Generated at 2022-06-12 07:34:40.881137
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode string"""
    class IllegalUseOfScopeReplacer(Exception):
        _fmt = "foo"
    e = IllegalUseOfScopeReplacer(42, "hello")
    # __unicode__ always returns a unicode string
    u = unicode(e)



# Generated at 2022-06-12 07:34:50.551113
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class Foo(object):
        def __call__(self):
            return 42
    scope = {}
    replacer = ScopeReplacer(scope, lambda self: Foo(), 'foo')
    scope['foo']
    scope['foo']()

    # Next, tests for the exception raised by bad use of ScopeReplacer
    import sys
    d = sys._getframe(0).f_globals
    replacer = ScopeReplacer(d, lambda self: replacer, 'replacer')
    try:
        replacer
    except IllegalUseOfScopeReplacer as e:
        assert 'illegal' in str(e)
        assert 'assign' in str(e)
    else:
        raise AssertionError('Bad use did not raise IllegalUse exception')

# Generated at 2022-06-12 07:34:54.599071
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing __str__ of IllegalUseOfScopeReplacer."""
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    expected = ("ScopeReplacer object 'name' was used incorrectly:"
                " msg: extra")
    got = str(e)
    assert_equal_unicode(expected, got)


# Generated at 2022-06-12 07:34:59.431235
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # make sure unicode(e) works
    # make sure str(e) works
    # make sure repr(e) works
    str(e)
    unicode(e)
    repr(e)



# Generated at 2022-06-12 07:35:37.459066
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should handle unicode format strings.

    This test covers __unicode__() of class IllegalUseOfScopeReplacer
    """
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = '\u1234'

    e = MyException('foo', 'bar')
    assert isinstance(unicode(e), unicode), '__unicode__ did not return unicode'
    # __unicode__ should return a unicode object
    assert unicode(e) == u'\u1234'



# Generated at 2022-06-12 07:35:47.105256
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test equality"""
    e1 = IllegalUseOfScopeReplacer("test", "a%s", 3)
    e2 = IllegalUseOfScopeReplacer("test", "a%s", 3)
    e3 = IllegalUseOfScopeReplacer("test", "a%s", 4)
    assert e1 == e2
    assert e1 != e3
    assert e1 != Exception()

    def u(s):
        """Make an ascii string into a unicode string"""
        if isinstance(s, unicode):
            return s
        return unicode(s, 'ascii')
    assert u("IllegalUseOfScopeReplacer(test: a3)") == unicode(e1)


# Generated at 2022-06-12 07:35:49.059301
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Testing method ScopeReplacer.__setattr__ of class ScopeReplacer."""
    # There are no tests yet.
    pass

# Generated at 2022-06-12 07:35:50.847984
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import tests
    tests.SyntheticTestCase.failUnlessRaises(AttributeError, setattr,
        ScopeReplacer({}, lambda self, scope, name: self, 'name'), 'attr',
        None)


# Generated at 2022-06-12 07:35:53.580417
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__ on ScopeReplacer"""
    scope = {'bar': 2}
    scope['foo'] = ScopeReplacer(scope, lambda self, scope, name: scope['bar'], 'foo')
    # Call
    scope['foo']()


# Generated at 2022-06-12 07:35:57.661547
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() -> string"""
    _test_exception_str(IllegalUseOfScopeReplacer,
        {'name':'test_obj', 'msg':'test message'},
        "test_obj was used incorrectly: test message")



# Generated at 2022-06-12 07:36:05.106443
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should raise an error like the error
    raised by the Exception it replaces."""
    # This test is inherently fragile, because while it is testing that the
    # error message being raised by the lazy module being imported is the same
    # as the one being raised by the exception, it is using that error message
    # to make sure the exception is raised. We do the best we can by testing
    # that the error message starts with the expected string.
    e = IllegalUseOfScopeReplacer('spam', 'use of spam')
    s = str(e)
    # Just check for the word 'spam', as that's all we know about the error message.
    expected_start = 'spam'

# Generated at 2022-06-12 07:36:07.789254
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    r"""'Unit test for method __call__ of class ScopeReplacer.\n    '"""
    pass

    # XXX: implement this
    raise AssertionError('not implemented')



# Generated at 2022-06-12 07:36:13.230827
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class DummyError(Exception):
        """a dummy error for testing"""
    error = DummyError()
    e = IllegalUseOfScopeReplacer('x', 'y', error)
    e2 = IllegalUseOfScopeReplacer('x', 'y', error)
    e3 = IllegalUseOfScopeReplacer('x', 'z', error)

    assert e == e2
    assert e != e3



# Generated at 2022-06-12 07:36:20.234063
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() works with unicode input"""

    e = IllegalUseOfScopeReplacer("name", u"msg", u'extra')
    str(e)
    # FIXME: Jam 20060914 This test should check the actual result is
    # correct. Current output is::
    #   IllegalUseOfScopeReplacer("name", u"msg", u'extra')
    #   IllegalUseOfScopeReplacer("name", "msg", 'extra')
    #   IllegalUseOfScopeReplacer("name", u"msg", u'extra')



# Generated at 2022-06-12 07:36:54.985491
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This tests the __unicode__ method of class IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase
    tc = TestCase()
    e = IllegalUseOfScopeReplacer(name='foo', msg='foo')
    try:
        foo = tc.fail('foo')
    except Exception as some_exception:
        foo = some_exception
    # A class that doesn't have a format string assigned to self._fmt (or
    # self._fmt is None) raises an exception while trying to format the
    # message.
    tc.assertRaises(UnicodeError, str, e)
    # A class that has a valid format string assigned to self._fmt doesn't
    # raise an exception.
    e._fmt = "I am a format string"

# Generated at 2022-06-12 07:37:00.386840
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object.

    Principle of least surprise.
    """
    x = IllegalUseOfScopeReplacer('name', 'msg')
    if isinstance(x.__unicode__(), unicode):
        return
    raise AssertionError('%r is not a unicode object' % (x.__unicode__()))

# Generated at 2022-06-12 07:37:12.127923
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    bzrlib.tests.TestCaseWithTransport.tearDown(None)
    bzrlib.tests.TestCaseWithTransport.setUp(None)
    import bzrlib.lazy_import
    import bzrlib.revision
    object.__setattr__(bzrlib.lazy_import.ScopeReplacer,'_should_proxy',False)
    # SetUp and TearDown are called to reset the lazy_import module
    class Test__scope_replacer_with_callable(bzrlib.tests.TestCase):
        def __scope_replacer_with_callable(self):
            def factory(self, scope, name):
                return lambda : "something"
            # Pass 'factory' to ScopeReplacer (which will be
            # called

# Generated at 2022-06-12 07:37:21.559324
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    def dummy(): pass
    def assertRaises(a, b, c): pass
    assertRaises(IllegalUseOfScopeReplacer,
        dummy,
        (errors, '__setattr__', dummy))
    assertRaises(IllegalUseOfScopeReplacer,
        dummy,
        (osutils, '__setattr__', dummy))
    assertRaises(IllegalUseOfScopeReplacer,
        dummy,
        (branch, '__setattr__', dummy))
    assertRaises(IllegalUseOfScopeReplacer,
        dummy,
        (bzrlib, '__setattr__', dummy))


# Generated at 2022-06-12 07:37:32.213026
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import (
        TestCase,
        )

    class TestScopeReplacer(TestCase):

        def setUp(self):
            super(TestScopeReplacer, self).setUp()
            # Setup a clean scope and place a 'ScopeReplacer' object in it.
            self.scope = {}
            self.name = 'Mock'
            self.scope_replacer = ScopeReplacer(self.scope, None, self.name)

        def test___setattr__(self):
            """Test that accessing an unset attribute on the ScopeReplacer
            object results in an exception."""
            self.assertRaises(IllegalUseOfScopeReplacer,
                              self.scope_replacer.__setattr__, 'x', 1)


# Generated at 2022-06-12 07:37:38.236671
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should return unicode object"""
    from bzrlib.tests import TestCase
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "MyException() format"

    exception = MyException('name', 'msg')

    # The __unicode__ method must return a unicode object
    TestCase().assertIsInstance(exception.__unicode__(), unicode)

# Generated at 2022-06-12 07:37:45.195511
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object.

    It should also be able to recover a unicode object at the end and
    return a str object by encoding the unicode one to utf8.
    """
    # this object can't be used but it's enough to test the method
    e1 = IllegalUseOfScopeReplacer(None, None)
    # this one will be used
    e2 = IllegalUseOfScopeReplacer(u"name", u"message", u"extra")
    # if __str__ doesn't return an str, we get an exception here
    str(e1)
    # same here
    str(e2)
    # if __str__ doesn't return a unicode object, we get an exception here
    unicode(e1)
    # same here
    unicode(e2)


# __all__ needs to

# Generated at 2022-06-12 07:37:49.709436
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This test checks that the __unicode__ method returns a unicode object,
    even if the original exception message was a str.
    """
    err = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(err)
    isinstance(u, unicode)



# Generated at 2022-06-12 07:37:57.703910
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # unit test for method __call__ of class ScopeReplacer
    _ = ScopeReplacer(globals(), lambda s, sc, n: None, '_')
    _()
    assert not hasattr(_, '_real_obj')
    _._resolve()
    assert _._real_obj is None
    a = ScopeReplacer(globals(), lambda s, sc, n: n, 'a')
    assert not hasattr(a, '_real_obj')
    assert a() == 'a'
    assert a._real_obj == 'a'
    b = ScopeReplacer(globals(), lambda s, sc, n: n, 'b')
    assert not hasattr(b, '_real_obj')
    assert b.__call__() == 'b'
    assert b._real_obj == 'b'
   

# Generated at 2022-06-12 07:38:06.228408
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_bzr_selftest
    from bzrlib import lazy_import # avoid recursive imports
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        x = bzrlib.tests.blackbox.test_bzr_selftest.dict()
        y = x
        y.foo = 1
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True

# test_ScopeReplacer___setattr__()



# Generated at 2022-06-12 07:38:33.295463
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    import bzrlib
    '''
    )
    bzrlib.errors.BzrError()



# Generated at 2022-06-12 07:38:42.162518
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from operator import eq
    class ClassScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name, init_kwargs={}, init_args=[]):
            self._init_kwargs = init_kwargs
            self._init_args = init_args
            ScopeReplacer.__init__(self, scope, factory, name)
        def _resolve(self):
            ScopeReplacer._resolve(self)
            return Class(**self._init_kwargs)
    class Class(object):
        def __init__(self, **kwargs):
            pass
        def __call__(self, *args, **kwargs):
            return True

# Generated at 2022-06-12 07:38:52.379201
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase

    class TestScopeReplacer(ScopeReplacer):
        def __init__(self, name):
            ScopeReplacer.__init__(self, {}, self._make_obj, name)
        def _make_obj(self, replacer, scope, name):
            return object()
    test = TestCase()
    a = "hi"
    b = TestScopeReplacer("a") # starts out as a ScopeReplacer instance
    test.assertIsInstance(b, ScopeReplacer)
    test.assertEqual(a, "hi")
    test.assertEqual(a, b) # triggers __call__
    test.assertIsInstance(b, object)
    # Make sure that calling on a regular object works
    test.assertEqual(b(5), 5)



# Generated at 2022-06-12 07:39:03.726750
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__"""
    from unittest import TestCase
    class Test(TestCase):
        def test___str__(self):
            e = IllegalUseOfScopeReplacer('foo', 'some message')
            self.assertEqual(
                u'ScopeReplacer object \'foo\' was used incorrectly:'
                ' some message',
                unicode(e))
            self.assertEqual(
                'ScopeReplacer object \'foo\' was used incorrectly:'
                ' some message',
                str(e))
            baz = object()
            e = IllegalUseOfScopeReplacer('foo', 'some message', extra=baz)

# Generated at 2022-06-12 07:39:14.593149
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib
    _expected_stderr = ''
    _stderr_value = []
    import bzrlib.tests.features
    bzrlib.tests.features.Feature.stderr = _stderr_value.append
    _test_data = ('', 'hello', u'', u'hello')
    def _constructor_callable(self, scope, name):
        return 'constructor-return'
    s = ScopeReplacer(globals(), _constructor_callable, 's')
    for _x in _test_data:
        for _y in _test_data:
            for _z in _test_data:
                _obj = s(x=_x, y=_y, z=_z)

# Generated at 2022-06-12 07:39:24.694580
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    r"""Tests for method IllegalUseOfScopeReplacer.__str__."""
    # FIXME: JDH: These tests ought to be combined into a single
    # test_exception_formatting method.
    import bzrlib.lazy_import
    err_cls = bzrlib.lazy_import.IllegalUseOfScopeReplacer

    # Empty cases
    obj = err_cls('name', 'msg')
    assert str(obj) == 'name: msg'

    obj = err_cls('name', 'msg', 'extra')
    assert str(obj) == 'name: msg: extra'

    # Test that encoding errors are passed through
    obj = err_cls('name', 'msg', '\xff')
    assert str(obj) == 'name: msg: \xff'

    # test that non

# Generated at 2022-06-12 07:39:34.590640
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import osutils
    try:
        osutils.lstat('/')
    except OSError:
        # This test is better run on an actual filesystem.
        return

    def factory(scope_replacer, scope, name):
        replacer = scope_replacer
        class ToReplace(object):
            def __call__(self, *args, **kwargs):
                scope[name] = replacer
                return osutils.lstat(*args, **kwargs)
        return ToReplace()

    import __main__
    sr = ScopeReplacer(__main__.__dict__, factory, 'lstat')

    lstat = sr('/')
    from bzrlib import osutils
    assert lstat == osutils.lstat('/')



# Generated at 2022-06-12 07:39:40.052277
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda s, sc, n: 'real_obj',
                                   'real_obj')
    scope_replacer.foo = 'bar'
    assert_equal('bar', scope['real_obj'].foo)
    scope_replacer.foo = 'baz'
    assert_equal('baz', scope['real_obj'].foo)



# Generated at 2022-06-12 07:39:48.631236
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This tests the __str__ method of the IllegalUseOfScopeReplacer class."""
    e = IllegalUseOfScopeReplacer('spam', 'eggs', 'extra')
    s = str(e)
    u = unicode(e)
    # We need some unicode here, but we don't want to care about the
    # default encoding
    assert u == "ScopeReplacer object 'spam' was used incorrectly: eggs: extra"
    # Make sure that __str__ returns a str, not a unicode.
    assert isinstance(s, str)
    assert s == u.encode('utf8')



# Generated at 2022-06-12 07:39:58.392282
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test the return value of IllegalUseOfScopeReplacer.__str__.

    This test should not need to be localized, as the code being tested
    is not localizable.
    """
    e = IllegalUseOfScopeReplacer(
        'foo', 'a message', extra='bar')
    assert str(e) == "ScopeReplacer object 'foo' was used incorrectly: " \
        "a message: bar"
    IllegalUseOfScopeReplacer._fmt = None
    assert str(e) == "Unprintable exception IllegalUseOfScopeReplacer: " \
        "dict={'extra': ': bar', 'name': 'foo', 'msg': 'a message'}, " \
        "fmt=None, error=None"
    del IllegalUseOfScopeReplacer._fmt

# Generated at 2022-06-12 07:40:33.390243
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    old_should_proxy = ScopeReplacer._should_proxy
    ScopeReplacer._should_proxy = True

# Generated at 2022-06-12 07:40:39.035448
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.lazy_import import lazy_import
    _scope = {}
    def _factory(self, scope, name):
        return 'foo'
    _name = 'p0'
    x = ScopeReplacer(_scope, _factory, _name)
    assert getattr(_scope['p0'], '__call__')('s') == 'foo'
    ExternalBase.tearDown()



# Generated at 2022-06-12 07:40:45.997525
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.revision import Revision
    from bzrlib.tests import TestCase
    from bzrlib import errors

    class TestLazyImport(TestCase):
        """Tests for lazy_import."""

        def setUp(self):
            super(TestLazyImport, self).setUp()
            self.real_bzrlib = dict(bzrlib.__dict__)

        def tearDown(self):
            bzrlib.__dict__.clear()
            bzrlib.__dict__.update(self.real_bzrlib)
            super(TestLazyImport, self).tearDown()

        def test_setattr_assignment(self):
            """Assignment to lazy objects should fail."""
           

# Generated at 2022-06-12 07:40:47.570905
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Testing method __setattr__ of class ScopeReplacer."""
    pass



# Generated at 2022-06-12 07:40:57.783575
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from unittest import TestCase
    from bzrlib import lazy_import
    class DummyScopeReplacer(lazy_import.ScopeReplacer):
        def __init__(self):
            self.called = False
        def __call__(self, *args, **kwargs):
            self.called = True
    test_obj = DummyScopeReplacer()
    test_obj()
    TestCase.assertTrue(test_obj.called)

    # Check that resolution continues to work after __call__
    class DummyScopeReplacer2(DummyScopeReplacer):
        called2 = False
        def __call__(self, *args, **kwargs):
            DummyScopeReplacer.__call__(self, *args, **kwargs)
            self.called2 = True
    test_obj = DummyScopeReplacer

# Generated at 2022-06-12 07:41:07.295502
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """An exception should be able to be converted to a unicode string.

    This test is to ensure that if e.g. we see a unicode error when formatting
    an exception message, that we still return something sensible.
    """
    from bzrlib.tests.blackbox import ExternalBase
    output = ExternalBase()
    out, err = output.run_bzr(
        'missing-command', '-v', working_dir='.')
    lines = err.splitlines()
    assert len(lines) > 0
    assert lines[0].startswith('bzr: ERROR: ')
    # check that we can convert the first line to a unicode string.
    unicode(lines[0])

# Generated at 2022-06-12 07:41:10.587741
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should not raise an exception"""
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='something else')
    str(e) # should not raise an exception

# Generated at 2022-06-12 07:41:15.046384
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() can cope with a unicode
    format string and a unicode data.
    """
    ex = IllegalUseOfScopeReplacer('foo', u'bar', u'\xe4\xf6\xfc')
    assert isinstance(ex.__unicode__(), unicode)



# Generated at 2022-06-12 07:41:20.279683
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() for IllegalUseOfScopeReplacer"""
    test = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(test).startswith("IllegalUseOfScopeReplacer('name', 'msg': ")
    assert str(test).endswith("'extra')")

# Generated at 2022-06-12 07:41:22.847517
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test_ScopeReplacer___call__()
    # check that lazy imports can be called
    class MyTestClass(object):
        pass
    scope = {}
    my_test_class = ScopeReplacer(scope, lambda self, scope, name: MyTestClass,
                                  'my_test_class')
    assert scope['my_test_class'] is my_test_class
    res = my_test_class()
    assert type(res) is MyTestClass, res
    assert scope['my_test_class'] is res

# Generated at 2022-06-12 07:42:22.108015
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This test that IllegalUseOfScopeReplacer works correctly

    It is important to test to this class well because it is use in the
    lazy_import framework to detect when a lazy_import has been used
    incorrectly.
    """
    # Note:
    # Any exception that can be raised during the execution of the
    # import framework will use this class. The import framework is
    # partially executed during the import of bzrlib.lazy_import, which
    # is why the import of IllegalUseOfScopeReplacer is in the global
    # namespace.

    # Make sure that we are able to create a simple
    # IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'msg')
    eq = assertEquals
    eq(e.name, 'name')
    eq(e.msg, 'msg')
    eq

# Generated at 2022-06-12 07:42:28.280442
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # VE doesn't mention IllegalUseOfScopeReplacer, so checking that
    # test_IllegalUseOfScopeReplacer___str__() gets a VE is enough for
    # verifying that we have a VE for that class.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # We can't check the output format because it can change, but we can
    # check it's a string.
    s = str(e)



# Generated at 2022-06-12 07:42:33.038584
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer"""
    raise NotImplementedError(
        "Test for method __call__ of class ScopeReplacer not implemented")

    # create ScopeReplacer instance
    # call method __call__ of instance
    # check result
    # check that attributes exist

# Generated at 2022-06-12 07:42:36.177503
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    import doctest
    doctest.run_docstring_examples(ScopeReplacer.__setattr__, globals(), verbose=True)


# Generated at 2022-06-12 07:42:38.040590
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer("name", "message", "extra")
    assert(unicode(e) == u"name was used incorrectly: message: extra")



# Generated at 2022-06-12 07:42:42.187284
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-12 07:42:52.307249
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    from testtools import ExpectedException
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.i18n import gettext
    IllegalUseOfScopeReplacer._fmt = '%(_fmt)s'
    with ExpectedException(IllegalUseOfScopeReplacer, gettext(u"foo")):
        raise IllegalUseOfScopeReplacer('_fmt', 'foo')
    IllegalUseOfScopeReplacer._fmt = '%(name)s'
    with ExpectedException(IllegalUseOfScopeReplacer, 'baz'):
        raise IllegalUseOfScopeReplacer('baz', 'foo')
    IllegalUseOfScopeReplacer._fmt = '%(_fmt)s'
    # Tests that the exception is properly

# Generated at 2022-06-12 07:42:59.809139
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            class Foo(object):
                def __call__(self):
                    return 1
            def test_factory(*unused):
                return Foo()
            x = ScopeReplacer({}, test_factory, 'test')
            self.assertEqual(x(), 1)
    t = TestScopeReplacer('test___call__')
    TestUtil.test_suite().addTest(t)


# Generated at 2022-06-12 07:43:04.662202
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unicode representation of IllegalUseOfScopeReplacer should not raise"""
    e = IllegalUseOfScopeReplacer('myname', 'mymsg', 'myextra')
    u = unicode(e)
    encoded = e.encode('ascii')



# Generated at 2022-06-12 07:43:08.632509
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('x', 'y')
    assert isinstance(e.__unicode__(), unicode)
