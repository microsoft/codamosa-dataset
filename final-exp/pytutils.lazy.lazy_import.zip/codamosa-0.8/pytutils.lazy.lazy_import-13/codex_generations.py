

# Generated at 2022-06-12 07:34:18.371820
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def test_factory(x):
        return x.__class__
    def test_code():
        import bzrlib
        lazy_import(globals(), """
from bzrlib.lazy_import import (
    ScopeReplacer,
    )
from bzrlib.lazy_import import test_factory
""")
        # Call the method(s) you're interested in testing
        test_obj = ScopeReplacer(locals(), test_factory, 'test_obj')
        return test_obj # returned this way to avoid scope issues in tests
    result = test_code()
    expected = ScopeReplacer
    assert result == expected, "Expected %r to be %r" % (result, expected)



# Generated at 2022-06-12 07:34:22.221377
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    r = str(e)
    assert isinstance(r, str)
    assert r == 'name was used incorrectly: msg'


# Generated at 2022-06-12 07:34:29.349633
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import unittest
    class ScopeReplacerTest(unittest.TestCase):
        def test_it(self):
            # test that ScopeReplacer.__setattr__ propagates to the underlying
            # object.
            from bzrlib.lazy_import import lazy_import
            class Foo(object):
                def __init__(self, value):
                    self.bar = value
            def _make(self, scope, name):
                return Foo(scope['value'])
            # get a ScopeReplacer proxy that will replace itself with a Foo
            # object as soon as _resolve is called.
            ret = {'value':0}
            lazy_import(ret, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''', _make)

# Generated at 2022-06-12 07:34:38.771121
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class Factory(object):
        _expected = None
        def __init__(self, *args):
            self._args = args
        def __call__(self, *args):
            self._args = args
            return Factory._expected
    Factory._expected = object()
    def factory(self, scope, name):
        return Factory(scope, name)
    scope = {}
    name = 'name'
    replacer = ScopeReplacer(scope, factory, name)
    result = replacer()
    assert result is Factory._expected, \
           "The callable object should be returned"
    assert type(Factory._expected._args[0]) is ScopeReplacer, \
           "The first argument should be the replacer object"
    assert Factory._expected._args[1] is scope, \
           "The second argument should be the scope"
   

# Generated at 2022-06-12 07:34:48.930415
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import builtins
    import random
    import bzrlib.lazy_import
    # Run tests multiple times to try and trip up issues with order of
    # construction if they arise.
    for x in range(10):
        tmp = {}
        bzrlib.lazy_import.lazy_import(tmp, '''
from bzrlib import (
foo,
bar,
)
''')
        bzrlib.lazy_import.lazy_import(tmp, '''
from bzrlib.foo import bar
''')
        # bzrlib.bar = bzrlib.foo.FooObj
        bzrlib.lazy_import.lazy_import(tmp, '''
from bzrlib.bar import FooObj as bar
''')
        # bzrlib.foo.

# Generated at 2022-06-12 07:34:52.372052
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ must preserve unicode characters"""
    e = IllegalUseOfScopeReplacer('name', 'msg', u'\u1234')
    e.__unicode__()



# Generated at 2022-06-12 07:34:54.454896
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer("foo", "blah")
    unicode(e)



# Generated at 2022-06-12 07:35:04.670028
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import bzrlib.lazy_import
    def test_str(s):
        return bzrlib.lazy_import.IllegalUseOfScopeReplacer('foo', s)

    i1 = test_str('bar')
    i2 = test_str(unicode('bar'))
    i3 = test_str(u'bar')
    i4 = test_str(u'bar'.encode('utf8'))
    i5 = test_str(unicode('bar').encode('utf8'))
    i6 = test_str(u'bar'.decode('utf8'))
    i7 = test_str(unicode('bar').decode('utf8'))

    assert isinstance(unicode(i1), unicode)
    assert unicode(i1) == u'bar'
    assert unic

# Generated at 2022-06-12 07:35:09.627239
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', ('extra',))
    s = str(e)
    assert isinstance(s, str), repr(s)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-12 07:35:10.643869
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__(): pass # TODO


# Generated at 2022-06-12 07:35:31.363780
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ returns a unicode string.

    It should never return a str, even if the exception's text is pure ascii.
    """
    import sys
    if sys.version_info[0] == 3:
        # Python 3 always uses unicode
        return
    # The __unicode__ method of a class should return a unicode object.
    # Not a str object.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    # It should return a unicode object.
    import types
    if not isinstance(u, types.UnicodeType):
        raise AssertionError(
            '__unicode__ should have returned a unicode object, got %r'
            % (u,))
    # It should not return a str object.

# Generated at 2022-06-12 07:35:37.302645
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return unicode object"""
    err = IllegalUseOfScopeReplacer(name='name', msg='msg')
    if not isinstance(unicode(err), unicode):
        raise AssertionError(
            "__unicode__ should return unicode object, not %r" % type(unicode(err)))


# Generated at 2022-06-12 07:35:47.613534
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    class DummyError(IllegalUseOfScopeReplacer):
        _fmt = 'A dummy error: %(msg)s'
    e = DummyError('dummy', 'foo')
    if isinstance(e, unicode):
        print('IllegalUseOfScopeReplacer.__unicode__() returns a unicode')
    elif isinstance(e, str):
        print('IllegalUseOfScopeReplacer.__unicode__() returns a str')
    else:
        print('IllegalUseOfScopeReplacer.__unicode__() does not return an str or unicode')


# TODO:
# * Catch errors on deletion, and propagate them
# * Perhaps use some kind of proxy instead of replacing the object in place
# * Possibly integrate into javabridge at some point



# Generated at 2022-06-12 07:35:50.982591
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # Check that __str__() is callable
    _ = str(obj)
    # Check that __unicode__() is callable.
    _ = unicode(obj)



# Generated at 2022-06-12 07:35:57.621568
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests.blackbox import ExternalBase

    class TestScopeReplacer(ExternalBase):

        def test_should_proxy(self):
            """If _should_proxy is False, object already replaced"""
            # _should_proxy is used to prevent access to members of
            # already-replaced objects, so it's safe to disable it for testing.
            ScopeReplacer._should_proxy = False
            globals = {}
            lazy_import(globals, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope = {}
            scope2 = {}
            def factory1(self, scope, name):
                return 42
            def factory2(self, scope, name):
                return 43
            ScopeReplacer(scope, factory1, 'x')

# Generated at 2022-06-12 07:36:01.863704
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    try:
        raise IllegalUseOfScopeReplacer('name', 'message', 'extra')
    except Exception as exc:
        pass
    try:
        raise IllegalUseOfScopeReplacer('name', 'message', 'extra')
    except Exception as exc:
        pass

# Generated at 2022-06-12 07:36:05.782765
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Make sure that IllegalUseOfScopeReplacer can be rendered as unicode"""
    exc = IllegalUseOfScopeReplacer(
        'name', 'msg', extra='extra')
    assert isinstance(exc.__unicode__(), unicode)



# Generated at 2022-06-12 07:36:15.186585
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.lazy_import import lazy_import_module
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import import_module
    modules = {
        'bzrlib.lazy_import': lazy_import_module,
        'bzrlib.lazy_import.import_module': import_module,
        'bzrlib.lazy_import.ScopeReplacer': ScopeReplacer,
    }
    def do_import(module_name):
        return modules[module_name]
    module = ScopeReplacer('bzrlib.lazy_import', do_import)
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
   

# Generated at 2022-06-12 07:36:23.456593
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestNotApplicable
    try:
        from inspect import getsource
    except ImportError:
        raise TestNotApplicable(
            "inspect.getsource not available on this platform.")
    from bzrlib import (
        branch,
        errors,
        osutils,
        )
    from bzrlib.tests import TestCase
    from StringIO import StringIO
    class TestScopeReplacer(TestCase):
        def test_replaced_call(self):
            called = []
            class CallableDummy(object):
                def __call__(self, *args, **kwargs):
                    called.append((args, kwargs))
                    return called
            # We must use the 'globals()' dict as the scope rather than locals,
            # as locals will not be accessible from other

# Generated at 2022-06-12 07:36:33.436449
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from testtools.matchers import (
        Equals,
        )
    from testtools.content import text_content
    candidate = ScopeReplacer

    class placeholder(object):
        pass
    scope = {}
    scope['placeholder'] = placeholder
    scope['placeholder'].__setattr__('__setattr__', None)

    obj = candidate(scope, lambda a, b, c: placeholder, 'placeholder')
    obj2 = candidate(scope, lambda a, b, c: placeholder, 'placeholder2')
    obj.__setattr__('__setattr__', 'foo')

# Generated at 2022-06-12 07:36:51.808485
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # check that for the basic exception class, the format string is used
    e = IllegalUseOfScopeReplacer('name', 'msg')
    expected = 'ScopeReplacer object \'name\' was used incorrectly: msg'
    str(e) == expected


# Generated at 2022-06-12 07:36:58.779255
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import tempfile
    tmp = tempfile.TemporaryFile()
    import os
    import bzrlib
    try:
        tmp.flush()
        bzrlib.BzrDirMetaFormat1.__setattr__('file', tmp)
        tmp.seek(0)
        tmp.flush()
        bzrlib.osutils.__setattr__('file', tmp)
        tmp.seek(0)
        tmp.flush()
        os.__setattr__('file', tmp)
        tmp.seek(0)
        tmp.flush()
        tmp.close()
    except IOError as e:
        # The exception that was raised
        raise AssertionError("an exception was raised")



# Generated at 2022-06-12 07:37:02.962887
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer class returns a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str), \
        "IllegalUseOfScopeReplacer.__str__ did not return a str object: %r" \
        % (s,)



# Generated at 2022-06-12 07:37:14.240283
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Tests for IllegalUseOfScopeReplacer._format()"""
    class UnicodeException(Exception):
        _fmt = 'test %(value)s'

    class NonAsciiFormatException(Exception):
        _fmt = 'test %(value)s'
        def _get_format_string(self):
            return u'test %(value)s'

    # Create temporary instances and test them
    instances = [
        UnicodeException(value='foo'),
        NonAsciiFormatException(value='bar')]
    for instance in instances:
        # test _format() method
        result = instance._format()
        if isinstance(result, unicode):
            result = result.encode('utf8')
        else:
            result = str(result)

# Generated at 2022-06-12 07:37:20.033143
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Calling ScopeReplacer will call the real object.
    global call_scope
    call_scope = {}
    def call_factory():
        return "call_factory"
    global call_object
    call_object = ScopeReplacer(call_scope, call_factory, "call_object")

    try:
        assert call_object() == "call_factory"
    finally:
        del call_object
        del call_factory
        del call_scope


# Generated at 2022-06-12 07:37:25.489358
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def _factory(self, scope, name):
        return lambda *args, **kwargs: (args, kwargs)
    def _scope_to_use():
        return {}
    # Test that we can call objects created with ScopeReplacer
    to_call = ScopeReplacer(_scope_to_use(), _factory, 'to_call')
    assert to_call(1, 2) == ((1, 2), {})
    assert to_call(1, 2, z=3) == ((1, 2), {'z': 3})
    assert to_call(1, z=3) == ((1,), {'z': 3})


# Generated at 2022-06-12 07:37:36.355953
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from doctest import OutputChecker
    from io import BytesIO
    class Dummy:
        def __init__(self, val):
            self.val = val
    class UnicodeDummy:
        def __init__(self, val):
            self.val = val
        def __unicode__(self):
            return self.val
    class NoUnicodeDummy:
        def __init__(self, val):
            self.val = val
        def __str__(self):
            return self.val
    class NoStrDummy:
        def __init__(self, val):
            self.val = val
        def __unicode__(self):
            return self.val


# Generated at 2022-06-12 07:37:38.070669
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    exc = IllegalUseOfScopeReplacer('name', 'msg')
    unicode(exc)

# Generated at 2022-06-12 07:37:45.097995
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    class Foo(object):
        def __init__(self):
            self.calls = []
        def __setattr__(self, key, val):
            self.calls.append((key, val))
    def foo_factory(scope_replacer, scope, name):
        self = Foo()
        scope[name] = self
        return self
    sr = ScopeReplacer(scope, foo_factory, 'foo')
    scope['foo'].bar = 'baz'
    scope['foo'].bar = 'bam'
    scope['foo'].bar = 'bip'
    expected_calls = [('bar', 'baz'), ('bar', 'bam'), ('bar', 'bip')]
    eq(expected_calls, scope['foo'].calls)

# Unit test

# Generated at 2022-06-12 07:37:55.215853
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from io import StringIO
    from bzrlib.tests import TestCase
    import sys
    import random
    import time
    import threading
    foo_def = """def foo():
    return '%s'"""
    foo_import = """from bzrlib.lazy_import import (
    lazy_import,
    )
lazy_import(globals(), '''
from bzrlib.tests.lazy_import_test import (
    foo,
    )
''')
foo()"""
    good_string = '%s' % (random.random(),)
    class MyReplacer(ScopeReplacer):
        def __init__(self):
            self.calls = 0
            def factory(replacer, scope, name):
                replacer.calls += 1

# Generated at 2022-06-12 07:38:15.970403
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """'%(name)s' attribute value must be returned by method __unicode__"""
    name = 'foo'
    msg = 'bar'
    extra = 'baz' # extra attribute is mandatory
    expected_result = ('ScopeReplacer object %r was used incorrectly:'
                       ' %s: %s' % (name, msg, extra))
    exc = IllegalUseOfScopeReplacer(name, msg, extra)
    result = unicode(exc)
    if result != expected_result:
        raise AssertionError("%r != %r" % (result, expected_result))

# Generated at 2022-06-12 07:38:22.181880
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from cStringIO import StringIO
    expected = 'ScopeReplacer object %r was used incorrectly: msg'
    enc = 'ascii'
    s = IllegalUseOfScopeReplacer('foo', 'msg')
    u = unicode(s)
    assert u == expected % 'foo'
    # Test that __unicode__() always returns a unicode object
    assert isinstance(s.__unicode__(), unicode)



# Generated at 2022-06-12 07:38:24.812335
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # simple test
    x = ScopeReplacer({}, lambda s, sc, n: 10, "x")
    eq(x(), 10)

# Generated at 2022-06-12 07:38:28.676934
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """_IllegalUseOfScopeReplacer___str__

    >>> e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    >>> str(e1) # doctest: +ELLIPSIS
    "ScopeReplacer object 'name' was used incorrectly: msg: extra"
    """



# Generated at 2022-06-12 07:38:39.985964
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test Unicode support of IllegalUseOfScopeReplacer"""
    import sys
    # If the str class is unicode, then the tests on this class are
    # meaningless.
    if sys.version < '3.0':
        assert not isinstance(str, unicode), "Your str is unicode"
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    from bzrlib.i18n import gettext
    if sys.version > '3.0':
        e._fmt = gettext("Scope replacer %(name)r was used incorrectly: %(msg)s%(extra)s")
    e_repr = "IllegalUseOfScopeReplacer(name='name', msg='msg', extra='extra')"
    # Test the repr()

# Generated at 2022-06-12 07:38:43.332748
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Call to __setattr__ raises an AttributeError when attr is None and value is
    # not
    # AssertionError: AttributeError not raised
    pass

# Generated at 2022-06-12 07:38:52.939677
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    class X(object):
        def __call__(self, a, b, c=3):
            return a, b, c
    def test_factory(sr, scope, name):
        return X()
    x_proxy = locals()['x_proxy']
    x = x_proxy()
    assert x == (1,2,3), x
    del x, x_proxy
    try:
        pass
    finally:
        pass
    x_proxy = locals()['x_proxy']
    x = x_proxy(1, 2)
    assert x == (1,2,3), x
    del x, x_proxy
    try:
        pass
    finally:
        pass
    x_proxy = locals()['x_proxy']

# Generated at 2022-06-12 07:38:57.713976
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import sys

    i = IllegalUseOfScopeReplacer("name", "msg", "extra")
    s = str(i)
    if sys.version_info < (3, 0):
        assert isinstance(s, str)
    else:
        assert isinstance(s, bytes)




# Generated at 2022-06-12 07:39:02.593753
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(None, None, None)
    try:
        obj.__setattr__('_should_proxy', False)
        assert False, 'should fail with readonly attribute'
    except AttributeError:
        pass
    obj.__setattr__('_', True)

# Generated at 2022-06-12 07:39:11.300004
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """_format method of IllegalUseOfScopeReplacer should return unicode"""
    import bzrlib
    class TempException(IllegalUseOfScopeReplacer):
        _fmt = "Some unicode"
    e = TempException("name", "msg", {"extra": "value"})
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    assert unicode(e) == u"Some unicode"


# TODO: RBC 20060927 rename to ScopeReplaced.

# Generated at 2022-06-12 07:39:35.422022
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test method __call__ of class ScopeReplacer
    # Creation of scope
    scope = {}
    # Creation of factory
    def factory(self, scope, name):
        return 'abc'
    # Creation of name
    name = 'd'
    # Creation of object
    obj = ScopeReplacer(scope, factory, name)
    # Test
    args = ()
    kwargs = {}
    result = obj(*args, **kwargs)
    assert result == 'abc'



# Generated at 2022-06-12 07:39:46.518121
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # A pair of classes that can be used to check the identity of the
    # object.
    class Check1(object):
        pass
    class Check2(object):
        pass

    # Set up a scope, factory and name. These should be variables from
    # the globals() of the caller, so a real object will be correctly
    # substituted.
    scope = {}
    def create_obj():
        # Create an object to be used for the real object.
        return Check1()
    name = 'my_obj'

    # Create a ScopeReplacer instance, which will be placed in the
    # scope as 'name'.
    ScopeReplacer(scope, create_obj, name)

    # Check that the ScopeReplacer was correctly added to the scope.
    assert scope[name] is not None

    # Check that we got the right object out

# Generated at 2022-06-12 07:39:50.932873
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer("foo", "bar")
    u = e.__unicode__()
    import unicodehelper
    if not isinstance(u, unicodehelper.unicode):
        raise AssertionError("%r.__unicode__() didn't return a unicode object: %r" % (e, u))


# Generated at 2022-06-12 07:40:01.047574
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should always return a 'str' object.

    It should *not* return a 'unicode' object.
    """
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    u = unicode(e)
    # str should not be a unicode object
    if isinstance(s, unicode):
        raise AssertionError(s)
    # unicode should be a unicode object
    if not isinstance(u, unicode):
        raise AssertionError(u)
    # If a unicode object is passed to __str__, it must be utf-8 encoded
    e._preformatted_string = u'foo'
    s = str(e)
    if not isinstance(s, str):
        raise AssertionError(s)

# Generated at 2022-06-12 07:40:04.670562
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() always returns a str object
    Never a unicode object.
    
    """
    o = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(o.__str__(), str), (
        "Should always return a str")

# Generated at 2022-06-12 07:40:11.400975
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    i = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert isinstance(i, Exception)
    i2 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert i == i2
    i3 = IllegalUseOfScopeReplacer('foo1', 'bar', 'baz')
    assert not i == i3


# Generated at 2022-06-12 07:40:11.880206
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__(): pass


# Generated at 2022-06-12 07:40:16.250986
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test for method __str__ of class IllegalUseOfScopeReplacer"""
    class SomeException(IllegalUseOfScopeReplacer):
        """A stub exception class for testing"""
        def __init__(self, msg, extra=None):
            super(SomeException, self).__init__('SomeException', msg, extra)
    e = SomeException('Hello')
    str(e)


# Generated at 2022-06-12 07:40:18.714376
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ uses _format()."""
    class TestError(IllegalUseOfScopeReplacer):
        _fmt = 'foo'

    t = TestError('bar', 'baz')
    assert unicode(t) == 'foo'


# Generated at 2022-06-12 07:40:27.412627
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    _factory = None
    def _factory(self, scope, name):
        return scope[name]
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import (
        _MockClass1,
        _MockClass2,
        _MockClass3,
        _MockClass4,
        )
    from bzrlib.tests.test_lazy_import import (
        _MockClass1 as _MockClass1_alias,
        _MockClass2 as _MockClass2_alias,
        _MockClass3 as _MockClass3_alias,
        _MockClass4 as _MockClass4_alias,
        )
    scope = locals()

# Generated at 2022-06-12 07:40:58.543604
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    import bzrlib.lazy_import
    see = bzrlib.lazy_import.IllegalUseOfScopeReplacer('name', 'msg',
          "extra")
    test_cases = [
        'Unprintable exception IllegalUseOfScopeReplacer: '
        'dict={\'name\': \'name\', \'extra\': \'\', \'msg\': \'msg\'}, '
        'fmt=None, error=None',
        'IllegalUseOfScopeReplacer(\'name\', \'msg\', \'extra\')',
        'ScopeReplacer object \'name\' was used incorrectly: msg: extra',
        ]
    for expected_result in test_cases:
        actual_result = str(see)
        #print(repr

# Generated at 2022-06-12 07:41:09.732025
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer.

    This test is here to ensure that __str__ can be used to format
    exceptions even when the format string is not in the execution
    context. This is because strings are read as ascii.

    Running this test ensures that some heuristics are used to try
    to guess what the encoded bytes really represent.
    """
    # These tests have to be in a list to be executed in a subprocess.
    # This is because exceptions raise in the child process can't be caught
    # from the parent process.

# Generated at 2022-06-12 07:41:20.653425
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class CustomException(Exception):
        pass

    class SimpleObject(object):
        def __init__(self, arg):
            self.attr = arg

    def factory(replacer, scope, name):
        return SimpleObject('factory')

    scope = {}
    scope_replacer = ScopeReplacer(scope, factory, 'obj')
    scope_replacer_attr = scope['obj']

    # Test is proxy is enabled on newly created object
    try:
        scope_replacer_attr.attr
    except IllegalUseOfScopeReplacer:
        raise CustomException('Proxy is disabled')

    # Test is proxy is disabled after object has been generated
    ScopeReplacer._should_proxy = False
    try:
        scope_replacer_attr.attr
    except IllegalUseOfScopeReplacer:
        return
    else:
        raise CustomException

# Generated at 2022-06-12 07:41:25.676218
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer

    This test is supposed to check if __str__ returns the expected
    value.
    """
    test_instance = IllegalUseOfScopeReplacer('fred', 'foo')
    got = str(test_instance)
    expected = 'IllegalUseOfScopeReplacer(fred, foo)'
    #print 'got: %r expected: %r' % (got, expected)
    if not got == expected:
        raise AssertionError(
            'unexpected result:\n    got: %r\n expected: %r\n'
            % (got, expected))

# Generated at 2022-06-12 07:41:36.500049
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__ of ScopeReplacer should behave like getattr.

    This test shows that the method __getattribute__ of the class
    ScopeReplacer behaves like the built-in function getattr.
    """
    class FakeScope(object):
        pass
    scope = FakeScope()
    scope.foo = 'bar'
    scope.foobar = 42
    scope.bar = lambda x:x
    scope.baz = FakeScope()
    scope.baz.qux = 'quux'
    scope.baz.quux = 'corge'
    def factory(scope_replacer, scope, name):
        return scope[name]
    scope_replacer = ScopeReplacer(scope, factory, 'scope_replacer')
    assert scope_replacer.foo == 'bar'
    assert scope_replacer.foobar == 42

# Generated at 2022-06-12 07:41:47.365220
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Called by the def test_lazy_import_3 in bzrlib/tests/test_lazy_import.py

    from bzrlib.lazy_import import ScopeReplacer
    try:
        mym = ScopeReplacer(loc, lambda x,y,z: mymod)
        call_result = mym.__call__(1)
        # Simple test of the result
        if not (call_result == mymod(1)):
            raise AssertionError

        # Check that we called the function
        from bzrlib.tests import test_lazy_import
        test_lazy_import._mymod_called += 1
    finally:
        # Remove the ScopeReplacer
        del(loc["mym"])


# Generated at 2022-06-12 07:41:50.993511
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # XXX: This is a work in progress
    from cStringIO import StringIO
    out = StringIO()
    print >> out, "foo"
    print >> out, "bar"



# Generated at 2022-06-12 07:41:59.505210
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Create the object and test attribute method __setattr__"""
    obj = ScopeReplacer(scope=None, factory=None, name=None)
    # Test there is an attribute _resolve
    try:
        obj._resolve()
    except AttributeError as e:
        raise AssertionError("Attribute _resolve is not defined, "
            "got exception: %r" % e)
    except Exception:
        raise AssertionError("Attribute _resolve is not defined, "
            "got exception: %r" % sys.exc_info()[1])
    else:
        pass
    # Test there is an attribute _resolve

# Generated at 2022-06-12 07:42:08.837826
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ exception"""
    class FooException(IllegalUseOfScopeReplacer):
        _fmt = "Foo %(foo)s"
    ex = FooException('myname', 'mymsg', 'myextra')
    # _format() is the key method to test because it is used to format the
    # exception string
    def _format(self):
        return self._fmt
    saved_format = IllegalUseOfScopeReplacer._format

# Generated at 2022-06-12 07:42:20.042366
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer

    class TestClass(object):
        def __init__(self):
            self.var1 = 10
            self.var2 = 20

        def method1(self):
            return "method1"

    test = TestClass()
    replacer = ScopeReplacer(globals(), lambda r, s, n: test, "test")
    assert replacer.var1 == 10
    replacer.var1 = 20
    assert replacer.var1 == 20
    assert test.var1 == 20
    replacer.var2 = 30
    assert replacer.var2 == 30
    assert test.var2 == 30
    assert replacer.method1() == "method1"
    assert test.method1() == "method1"
    del replacer.var2