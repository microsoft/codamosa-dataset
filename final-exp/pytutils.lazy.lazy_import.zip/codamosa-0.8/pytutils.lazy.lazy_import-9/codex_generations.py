

# Generated at 2022-06-12 07:33:52.363410
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.lazy_import_helper import ScopeReplacerHelper
    obj = ScopeReplacer(None, ScopeReplacerHelper.make_factory, 'name')
    res = obj(1, 2, 3)
    assert res == (1, 2, 3), "Wrong result: %r" % res

# END test_ScopeReplacer___call__

# Generated at 2022-06-12 07:34:00.318413
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method __eq__ of class IllegalUseOfScopeReplacer."""
    from bzrlib import tests
    eq = tests.TestCase.assertEqual

# Generated at 2022-06-12 07:34:01.736229
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # __getattribute__(self, attr)
    raise NotImplementedError(__file__)

# Generated at 2022-06-12 07:34:10.205201
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method __eq__ of class IllegalUseOfScopeReplacer

    Return
    ======

    - ``None`` if test is successful
    - string describing test failure otherwise
    """
    # In Py 2.6, IllegalUseOfScopeReplacer inherits object, and uses the default
    # __eq__ implementation which returns False when comparing against any
    # other object. The explicit override is to test that the proper dict
    # comparison is used.
    error = IllegalUseOfScopeReplacer('foo', 'bar', 'egg')
    other = IllegalUseOfScopeReplacer('foo', 'bar', 'egg')
    if error != other:
        return 'error != other'
    other = IllegalUseOfScopeReplacer('foo', 'bar', 'egg')
    other.foo = 1

# Generated at 2022-06-12 07:34:19.519686
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import re
    if hasattr(Exception, '__unicode__'):
        r = re.compile('Unprintable exception IllegalUseOfScopeReplacer:'
                       ' dict=\{.*\}, fmt=None, error=\(None, None, None\)')
    else:
        r = re.compile('Unprintable exception IllegalUseOfScopeReplacer:'
                       ' dict=\[.*\], fmt=None, error=\(\'None\', \'None\', '
                       '\'None\', \[\], \{\}\), msg=None')
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-12 07:34:24.286651
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__(self)"""
    e = IllegalUseOfScopeReplacer('name', 'text')
    result = str(e)
    assert isinstance(result, str)
    assert result == ("IllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer"
        " object 'name' was used incorrectly: text)")


# Generated at 2022-06-12 07:34:26.969426
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ must return a str object"""
    x = IllegalUseOfScopeReplacer(None, None, None)
    s = x.__str__()
    assert isinstance(s, str), repr(s)
test_IllegalUseOfScopeReplacer___str__.unittest = ['.errors']

# Generated at 2022-06-12 07:34:35.523086
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer returns a str."""
    # Check that the exception object always returns a str from __str__.
    #
    # This method does not use the assertEquals method because that would
    # invoke __str__ of the exception, which is the method under test.
    #
    # The string returned by __str__ must always be a str, and never a unicode.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    # check that s is a str object
    assert isinstance(s, str)

# Generated at 2022-06-12 07:34:40.923520
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ is a simple forwarding method.

    It is worth checking however that its implementation is correct,
    because it handles a special case.
    """
    obj = object()
    obj.attr = None
    s = ScopeReplacer(globals(), lambda x, y, z: None, 'obj')
    # We expect the following to not raise.
    s.attr = None

# Generated at 2022-06-12 07:34:46.906540
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import bzrlib
    class MockedScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            self._real_obj = 'real_object'
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            scope = {}
            factory = lambda x,y,z: x
            name = self.get_url()
            scope[name] = scope_replacer = MockedScopeReplacer(
                scope, factory, name)
            self.assertEquals('real_object', scope[name]())
    test = Test(methodName='test_ScopeReplacer___call__')
    return test

# Generated at 2022-06-12 07:35:05.950646
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a valid unicode object and never raise
    an exception.
    """
    for e in (IllegalUseOfScopeReplacer('foo', 'foo'),
              IllegalUseOfScopeReplacer('foo', 'foo', 'bar'),
              IllegalUseOfScopeReplacer('foo', ''),
              IllegalUseOfScopeReplacer('foo', 'foo', e),
              IllegalUseOfScopeReplacer('foo', 'foo', 1),
              IllegalUseOfScopeReplacer('foo', 'foo', True)):
        unicode(e)

from bzrlib import osutils
from bzrlib._py_compat import _e, _u

# Avoid a circular import
from bzrlib import trace



# Generated at 2022-06-12 07:35:11.517922
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """It should convert text into a bunch of lazy import objects.

    It should take a text string, which should be similar to normal python
    import markup, and convert it into a bunch of lazy import objects.
    """
    import bzrlib.branch
    import bzrlib.commands
    import bzrlib.tsort
    import bzrlib.workingtree
    from bzrlib.bzrdir import BzrDir

    scope = locals()
    # This is a real import string from libbzr (as of 2007-09-13)

# Generated at 2022-06-12 07:35:14.514151
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test the __unicode__ method of IllegalUseOfScopeReplacer"""
    error = IllegalUseOfScopeReplacer('foo', 'hello world')
    assert str(error) == u'hello world'


# Generated at 2022-06-12 07:35:26.438515
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import unittest
    from . import test_lazy_import

    from bzrlib.lazy_import import (
        ScopeReplacer,
        )

    scope = {}

    def factory(scope_replacer, scope, name):
        return lambda x: x

    scope_replacer = ScopeReplacer(scope, factory, 'name')
    name = scope['name']

    # call on a ScopeReplacer should invoke __call__ on the
    # lazy-imported object.
    self = test_lazy_import.TestCase
    self.assertEqual(42, name(42))

    # Check that a lambda passed through a ScopeReplacer preserves
    # its name, as that can be important when debugging.
    f = name(lambda x: x)

# Generated at 2022-06-12 07:35:37.658158
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib import (
        tests,
        )
    from bzrlib.tests import TestCase

    class Test(TestCase):

        def test_unicode(self):
            exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
            unicode(exc)
            exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
            str(exc)

        def test_repr(self):
            exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
            repr(exc)

    tests.TestUtil.test_suite().addTests(
        [Test('test_unicode'),
         Test('test_repr')])



# Generated at 2022-06-12 07:35:48.143866
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # testing attribute __call__ of class ScopeReplacer
    class FooClass(object):
      def __call__(self, x):
        return x + 2
    class_scope = {'__builtins__':__builtins__, '__name__':__name__, 'FooClass':FooClass}
    # FooClass is a defined class in the scope
    def factory(replacer, scope, name):
        return scope[name]
    # factory returns the class FooClass from the scope
    def test():
        obj = ScopeReplacer(class_scope, factory, 'FooClass')
        return obj(4)
    # test calls the method __call__ of the instance obj of class ScopeReplacer
    # and obj is a placeholder for the class FooClass
    # so obj(4) calls the method __call__ of the class FooClass and

# Generated at 2022-06-12 07:35:51.348176
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Method __call__ of class ScopeReplacer.

    Test cases:

        1) XXX
    """
    # Case 1)
    obj = ScopeReplacer({}, lambda self, scope, name: None, 'name')


# Generated at 2022-06-12 07:36:01.538570
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    inst = IllegalUseOfScopeReplacer(name='toto', msg='coucou',
                                     extra='pipi')
    try:
        inst.__unicode__()
    except UnicodeDecodeError:
        if sys.version_info < (2, 6):
            raise TestSkipped("__unicode__ implementation of "
                              "IllegalUseOfScopeReplacer does not work on "
                              "Python < 2.6")
        # TODO be smarter than that for older versions of Python.
        raise TestSkipped("__unicode__ implementation of "
                          "IllegalUseOfScopeReplacer does not work on this "
                          "configuration")

# Generated at 2022-06-12 07:36:05.783090
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def f(x, y):
        return x + y
    # Call the method under test
    s = ScopeReplacer({}, f, 'f')
    s(1, 2)
    # Check the state after the call
    assert s + 1 == 4

# Generated at 2022-06-12 07:36:10.419849
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    instance = IllegalUseOfScopeReplacer('name', 'message')
    result = unicode(instance)
    expected = u"name: message"
    assert result == expected, "%r != %r" % (result, expected)



# Generated at 2022-06-12 07:36:23.997261
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import os
    import sys
    ''')
    assert os() == os
    assert sys() == sys



# Generated at 2022-06-12 07:36:32.932394
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    expect = u"ScopeReplacer object 'foo' was used incorrectly: bar"
    actual = IllegalUseOfScopeReplacer(name='foo', msg='bar')._format()
    assert actual == expect
    expect = u'Unprintable exception IllegalUseOfScopeReplacer: ' \
        u'dict={}, fmt=None, error=None'
    actual = IllegalUseOfScopeReplacer(name='foo', msg='bar')._format()
    assert actual == expect
    # Test __str__ of the class works
    expect = 'ScopeReplacer object \'foo\' was used incorrectly: bar'
    actual = str(IllegalUseOfScopeReplacer(name='foo', msg='bar'))
    assert actual == expect



# Generated at 2022-06-12 07:36:38.853408
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    replacer = ScopeReplacer({'foo': 2}, lambda self, scope, name: scope[name], 'foo')
    # It's a scope replacer
    assert(isinstance(replacer, ScopeReplacer))
    # Getting attribute 'foo' works
    assert(replacer.foo == 2)
    # Getting any other attribute leads to error
    def _getattr_err():
        return replacer.bar
    raises(AttributeError, _getattr_err)

# Generated at 2022-06-12 07:36:47.306845
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test passing arguments to ScopeReplacer
    class Foo(object):
        _called = False
        def __call__(self, *args, **kwargs):
            self._called = True
            return args, kwargs
    foo = Foo()
    lazy_foo = ScopeReplacer({}, lambda *args: foo, 'foo')
    eq = [1, 2], dict(three=3, four=4)
    eq_(eq, lazy_foo(*eq[0], **eq[1]))
    eq_(eq, foo(*eq[0], **eq[1]))
    assert foo._called
# end test_ScopeReplacer___call__


# Generated at 2022-06-12 07:36:53.432921
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    try:
        raise IllegalUseOfScopeReplacer('foo', 'abc %(bar)s')
    except IllegalUseOfScopeReplacer as e:
        # Ensure that the message is using the format string, and is a str
        # rather than a unicode object.
        assert str(e) == 'abc %(bar)s'


# Generated at 2022-06-12 07:37:03.326750
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__ mutates itself and returns the real object when used as a function.

    This is not a test as such, but demonstrates the method behaviour.
    """
    def _str(s):
        return s
    import sys
    old = sys.modules.copy()

# Generated at 2022-06-12 07:37:13.529200
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """A module that needs to be imported was used as an object.

    This exception should maximally be raised in a unicode string context
    (either __repr__ or __str__) to allow further investigation of the problems
    it indicates.
    """
    class Module(object):
        pass
    module = Module()
    exc = IllegalUseOfScopeReplacer('module', 'used as an object', module)
    s = str(exc)
    expected_substr = 'A module that needs to be imported was used as an object'

# Generated at 2022-06-12 07:37:22.631325
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.test_lazy_import import TestCase

    class ScopeReplacerForTest_ScopeReplacer___call__(ScopeReplacer):
        __slots__ = ()

        def _resolve(self):
            def _inner_ScopeReplacer___call__(self, scope, name):
                return (self, scope, name)
            return _inner_ScopeReplacer___call__

    class Test_ScopeReplacer___call__(TestCase):
        def test_simple(self):
            scope = {}
            name = 'test'
            factory = lambda self, scope, name: 1
            obj = ScopeReplacerForTest_ScopeReplacer___call__(scope, factory,
                name)
            self.assertEqual((obj, scope, name), obj())

    # End of test_ScopeReplacer___call__


# Generated at 2022-06-12 07:37:24.213531
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    bzrlib.tests.blackbox_test_module(__name__)

# Generated at 2022-06-12 07:37:35.635403
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # ScopeReplacer.__call__:
    # __call__()
    #     A lazy object that will replace itself in the appropriate scope.
    # This object sits, ready to create the real object the first time it is
    # needed.
    # :param scope: The scope the object should appear in
    # :param factory: A callable that will create the real object.
    # :param name: The variable name in the given scope.
    #     It will be passed (self, scope, name)
    import bzrlib.lazy_import
    bzrlib.lazy_import._test_modified_sys_modules = True
    import sys as _sys

# Generated at 2022-06-12 07:37:53.596258
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = unicode(IllegalUseOfScopeReplacer('name', 'msg', 'extra'))
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-12 07:38:04.203740
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests

    class TestObject(object):

        def __init__(self):
            self.a = 1

    scope = {}
    factory = lambda proxy, scope, name: TestObject()
    name = 'name'
    proxy = ScopeReplacer(scope, factory, name)

    # Check proxy has not yet been resolved
    assert proxy._real_obj is None

    # Check one level of indirection
    proxy.a = 2
    assert proxy.a == 2

    # Check two levels of indirection
    proxy2 = proxy
    proxy2.a = 3
    assert proxy.a == 3

    # Check proxy + indirection resolve real object
    assert proxy2._real_obj is scope[name]
    assert scope[name].a == 3

    # Check disabling of proxy

# Generated at 2022-06-12 07:38:10.788306
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    class TestIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        pass

    e = TestIllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == 'Unprintable exception TestIllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'

    TestIllegalUseOfScopeReplacer._fmt = "hello %(name)r"
    assert str(e) == "hello 'name'"



# Generated at 2022-06-12 07:38:19.168396
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import unittest
    import sys
    from bzrlib.tests import TestCase

    class TestScopeReplacer(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            # Create a dummy function that returns the scope of the caller
            def get_caller_scope():
                a = sys._getframe(1)
                return a.f_locals
            self.get_caller_scope = get_caller_scope

        def test__setattr__(self):
            # Make sure the __getattribute__ method of class ScopeReplacer
            # works properly by testing it with a set attribute.
            scope = self.get_caller_scope()
            scope['test__setattr__'] = ScopeReplacer(scope,
            lambda self, scope, name: scope, 'test__setattr__')

# Generated at 2022-06-12 07:38:25.539136
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from unittest import TestCase
    class test___call__(TestCase):
        def test_simple(self):
            from bzrlib.tests import FooObject
            def foo_object_factory(self, scope, name):
                return FooObject()
            ScopeReplacer(globals(), foo_object_factory, 'foo')
            self.assertEqual(foo(), 'hi')
    return test___call__

# Generated at 2022-06-12 07:38:27.940325
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class A():
        __slots__ = ('attr',)
    a = A()
    a.attr = 1
    a.attr = 2

# Generated at 2022-06-12 07:38:39.403453
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestNotApplicable
    # Test: using __setattr__
    try:
        ScopeReplacer.__setattr__
    except AttributeError:
        raise TestNotApplicable('ScopeReplacer has no attribute __setattr__')
    # Test: 'a' keyword argument
    try:
        setattr(ScopeReplacer, 'a',  0)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError expected')
    # Test: 'attr' keyword argument

# Generated at 2022-06-12 07:38:42.176705
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest, bzrlib.lazy_import
    return doctest.DocTestSuite(bzrlib.lazy_import)


# Generated at 2022-06-12 07:38:52.379938
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    import sys
    # the test fixture
    import bzrlib.tests.per_interpreter
    # the test module itself
    import bzrlib.tests.blackbox.test_lazy_import
    # the test case class
    import bzrlib.tests.blackbox.test_lazy_import.TestLazyImport
    # the test case method
    import bzrlib.tests.blackbox.test_lazy_import.TestLazyImport.test_lazy_import
    # a test method for some other module
    import bzrlib.tests.blackbox.test_errors.TestErrors.test_error_msgs
    # the module being tested
    import bzrlib.lazy_import

    bz

# Generated at 2022-06-12 07:39:01.269956
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should always return a 'str' object
    and never a 'unicode' object.
    """
    class MockScopeReplacer(object):
        _fmt = "Mock message with %(replacer_name)s"
        def __init__(self):
            self.replacer_name = 'inserted name for replacer'
    s = MockScopeReplacer()
    # This should not raise TypeError because __str__() should
    # return a str.
    d = {'replacer': str(s)}



# Generated at 2022-06-12 07:39:16.551345
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ converts the exception message to unicode.

    The exception should be able to be converted to unicode even if the
    error message contains non-ascii characters.
    """
    # You must not use ugettext here, or you will create a dependency on the
    # module gettext, which is not safe to do in this module, because this module
    # is imported by a lot of bzrlib modules, and we want them to be able to
    # import this module without also importing a lot of other modules.
    msg = "This is a non-ascii message: \xc3\xa5\xc3\xa4\xc3\xb6"
    e = IllegalUseOfScopeReplacer('name', msg, '12')
    u = unicode(e)
    # The unicode object should contain the non-ascii

# Generated at 2022-06-12 07:39:25.466275
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys

    class MyClass(object):
        @staticmethod
        def factory(replacer, scope, name):
            return object()
        # Unit test for method __call__ of class MyClass
        def test___call__(self):
            import sys

            _scope = None
            _factory = None
            _name = None
            obj = MyClass(scope=_scope, factory=_factory, name=_name)
            obj(*[], **{})
            return
    _scope = None
    _factory = None
    _name = None
    obj = ScopeReplacer(scope=_scope, factory=_factory, name=_name)
    obj(*[], **{})
    return

# Generated at 2022-06-12 07:39:35.500934
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""

    from bzrlib.tests import TestCase

    class TestException(IllegalUseOfScopeReplacer):
        _fmt = "Test exception %(name)s"
    e = TestException("foo", "bar")
    # Note: we can't do a 'is', this method is fragile, so we just verify
    # that it is a string, and that it's right.
    isinstance(str(e), str)
    e.name == "foo"
    # The same again with unicode
    isinstance(unicode(e), unicode)

    e = TestException("\xe9\xe9\xe9", "\xe9\xe9\xe9")
    isinstance(unicode(e), unicode)



# Generated at 2022-06-12 07:39:39.433957
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Test the case when the object has not been replaced
    obj = ScopeReplacer({}, lambda self, scope, name: None, 'dummy')
    import gc
    gc.collect()
    assert object._getattribute_hook == obj._getattribute_hook


# Generated at 2022-06-12 07:39:44.170017
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ returns unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u"name: msg"

# Generated at 2022-06-12 07:39:45.496525
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    eval("assert False, 'Nothing was evaluated'")

# Generated at 2022-06-12 07:39:49.116182
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # ScopeReplacer.__setattr__ is a function.
    import bzrlib.lazy_import
    assert isinstance(bzrlib.lazy_import.ScopeReplacer.__setattr__, (
        types.FunctionType, types.MethodType))

# Generated at 2022-06-12 07:39:54.012321
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer."""
    # pylint: disable=W0212
    # pylint: enable=W0212
    from bzrlib.tests.lazy_import_scopereplacer import (
        Test__setattr__TestCase,
        )
    return Test__setattr__TestCase.test_ScopeReplacer___setattr__()

# Generated at 2022-06-12 07:40:00.631143
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    __unicode__() should return a unicode object of the same value as
    __str__().
    """
    class X(IllegalUseOfScopeReplacer):
        _fmt = "%(msg)s"

    e = X('bzrlib', u'\u611b\u3059\u308b', None)
    if str(e) != e.__unicode__():
        raise AssertionError()



# Generated at 2022-06-12 07:40:06.903611
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class _UnitTestFactory:
        def __init__(_self):
            _self.__value = None
            return
        def __call__(_self):
            return _self.__value
        def set_value(_self, value):
            _self.__value = value
            return
    scope = {}
    factory = _UnitTestFactory()
    name = 'name'
    scope_replacer = ScopeReplacer(scope, factory, name)
    value = 'value'
    factory.set_value(value)
    actual = scope_replacer()
    assert actual == value, actual
    return



# Generated at 2022-06-12 07:40:17.530835
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import copy
    scope = copy.copy(globals())
    scope['__name__'] = 'bar'

    def set_name(self, scope, name):
        self.name = name
        return name

    lazy = ScopeReplacer(scope, set_name, 'foo')
    lazy.foo = 1
    assert scope['foo'].name == 'foo'


# Generated at 2022-06-12 07:40:26.175352
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys

    class SomeClass(object):
        def __init__(self):
            self.attribute = 'value'

        def __call__(self, *args, **kwargs):
            return args

    globals()['module'] = 'module'
    del sys.modules['module']
    del globals()['module']
    namespace = {'__name__': 'module'}

    replacer = ScopeReplacer(namespace, SomeClass, 'SomeClass')

    instance = SomeClass()

    assert instance.attribute == 'value'
    assert namespace['SomeClass'].attribute == 'value'
    obj = namespace['SomeClass']
    assert obj.attribute == 'value'
    assert obj('arg 1', 2) == ('arg 1', 2)
    del sys.modules['module']
    del globals()['module']
   

# Generated at 2022-06-12 07:40:36.544130
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import __builtin__
    class FauxObject(object):
        "Dummy class for testing"
        __module__ = 'bzrlib.lazy_import'
        _attr = 'attr'
    __builtin__.__dict__['FauxObject'] = FauxObject
    sr = ScopeReplacer(sys.modules[__name__].__dict__,
                       lambda x, y, z: FauxObject(),
                       'FauxObject')
    sr.attr = 'attr2'
    FauxObject._attr = 'attr2'
    def f(): return FauxObject._attr
    assert f() == 'attr2'
    __builtin__.__dict__['FauxObject'] = FauxObject
    del FauxObject
test_ScopeReplacer___setattr__()



# Generated at 2022-06-12 07:40:40.118503
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This tests if the __unicode__() method works.

    It is important that it works, because this method must return a unicode
    object.
    """
    u = unicode(IllegalUseOfScopeReplacer('foo', 'Bar'))
    isinstance(u, unicode)



# Generated at 2022-06-12 07:40:46.334795
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import test_ScopeReplacer__resolve

    class ScopeReplacerTest(TestCase):

        def test___setattr__(self):
            def factory(self, scope, name):
                return self

            class Test:
                pass
            test = Test()
            replacer = ScopeReplacer(test.__dict__, factory, 'this')
            self.assertRaises(
                IllegalUseOfScopeReplacer,
                replacer.__setattr__,
                'this',
                'self')

        def test__resolve(self):
            return test_ScopeReplacer__resolve(self)

    return TestCase



# Generated at 2022-06-12 07:40:56.682828
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import unittest
    class OverrideScopeReplacer(ScopeReplacer):
        def _resolve(self):
            return object.__getattribute__(
                self, '_real_obj') or object.__getattribute__(self, '_name')
    class OverrideScopeReplacer_TestCase(unittest.TestCase):
        def test___getattribute__(self):
            import sys
            lazy_object = OverrideScopeReplacer(
                {},
                lambda replacer, scope, name: name,
                'lazy_object')
            # __getattribute__(attr)  ->  getattr(obj, attr)
            self.assertEqual(
                "lazy_object",
                lazy_object.__getattribute__("__name__"))
            # getattr(obj, attr)  ->  obj.

# Generated at 2022-06-12 07:41:00.661602
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def _test(args, kwargs):
        obj = ScopeReplacer({},
                            lambda self, scope, name: self,
                            'lazy_import')
        obj._resolve = lambda : [0]
        return obj(*args, **kwargs)
    # Call the method with the different classes of arguments
    assert _test((), {}) == [0]

# Generated at 2022-06-12 07:41:12.028143
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # This function was autogenerated by test_lazy_import.py
    # It tests functionality of class ScopeReplacer.
    #
    # It should be safe to delete this function after the unit test passes
    # once.
    #
    # The easiest way to run this unit test is::
    #
    #   bzr selftest --test-plugin=test_lazy_import
    #
    # Note that you can use this syntax to run any selftest from
    # any plugin.

    from test_lazy_import import TestCaseWithLazyImport
    from testtools import TestCase

    class test_ScopeReplacer___getattribute___Test(TestCaseWithLazyImport):

        def setUp(self):
            TestCase.setUp(self)
            self.tearDown()


# Generated at 2022-06-12 07:41:21.053338
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():

    def check(obj, str_value):
        """Check that __str__ of obj is str_value"""
        def split(s):
            if s.startswith("'") and s.endswith("'"):
                return "'" + s[1:-1].replace("'", "\\'") + "'"
            else:
                return repr(s)
        s = split(unicode(obj))
        assert_equal(split(str_value), s)
    check(IllegalUseOfScopeReplacer('obj', 'msg'),
    "IllegalUseOfScopeReplacer(name='obj', msg='msg', extra='')")



# Generated at 2022-06-12 07:41:32.457929
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    # This test checks that __getattribute__ delegates to the resolved object,
    # and also verifies that proxying is disabled.
    import bzrlib.branch
    from bzrlib.lazy_import import lazy_import
    from bzrlib import errors
    from bzrlib.branch import Branch
    from bzrlib.tests import TestCase
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        )
    import bzrlib.branch
    ''')
    try:
        bzrlib.branch.Branch()
    except IllegalUseOfScopeReplacer:
        expected_failure = True
    else:
        expected_failure = False

# Generated at 2022-06-12 07:41:50.378695
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns unicode"""

    import sys
    import bzrlib

    # NB: py3k uses utf8 by default, so this isn't needed
    if sys.version_info[:2] <= (2, 5):
        from bzrlib.lazy_import import set_default_encoding
        set_default_encoding('ascii')

    e = IllegalUseOfScopeReplacer('foo','bar')
    u = e.__unicode__()
    assert isinstance(u, unicode)

    e = IllegalUseOfScopeReplacer('foo','bar',u'ba\u1234z')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-12 07:41:59.006818
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import StringIO
    import sys
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # The scope replacer objects get assigned to these names in
    # lazy_import.
    for name in ['bzrlib', 'errors', 'osutils', 'branch']:
        ex = IllegalUseOfScopeReplacer(name, 'test', None)
        old_stdout = sys.stdout
        try:
            # We need to redirect stdout because doctest will print the
            # output of the __str__ function.
            sys.stdout = StringIO.StringIO()
            result = str(ex)
        finally:
            sys.stdout = old_stdout
        assert result == \
            "%s(IllegalUseOfScopeReplacer object %r was used incorrectly:"

# Generated at 2022-06-12 07:42:08.519131
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Check attribute assignment works properly"""
    import bzrlib.tests.script
    bzrlib.tests.script.script_init()
    class TestClass(object):
        pass
    globals = {}
    lazy_import(globals, '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    import bzrlib.tests.script
    bzrlib.tests.script.script_init()
    globals['testclass'] = TestClass
    assert bzrlib.branch is bzrlib.branch._real_obj
    bzrlib.branch.test_function = lambda self: None
    assert bzrlib.branch.test_function() is None
   

# Generated at 2022-06-12 07:42:13.491842
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ for IllegalUseOfScopeReplacer"""
    exc = IllegalUseOfScopeReplacer('name', 'msg', 5)
    assert str(exc) == exc.__str__()
    assert unicode(exc) == exc.__unicode__()
    assert repr(exc) == exc.__repr__()



# Generated at 2022-06-12 07:42:18.108582
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    s = 'name msg'
    assert isinstance(u, unicode)
    assert isinstance(s, unicode)
    assert u == s


# Generated at 2022-06-12 07:42:19.841402
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__(): obj = ScopeReplacer(scope, factory, name); obj(*args, **kwargs)

# Generated at 2022-06-12 07:42:25.684881
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    # Note that this test is not run standalone.
    #
    # Some versions of python (2.6, 2.7) abort() when an exception is
    # raised in a method invoked by __unicode__() and the exception is
    # not a UnicodeError.
    #
    # This does not happen in some other versions of python.
    #
    # So this test is disabled for now.

    #s = u'\xa3' # £
    #sr = IllegalUseOfScopeReplacer('name', u'x\xa3')
    #u = sr.__unicode__()
    #assert isinstance(u, unicode)
    #assert u == u'x\xa3'
    #
    ## __unicode__ should not allow encoding errors
    #

# Generated at 2022-06-12 07:42:27.181173
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""


# Generated at 2022-06-12 07:42:32.999536
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ must return a unicode object."""
    e = IllegalUseOfScopeReplacer(name='NAME', msg='MESSAGE',
                                  extra='EXTRA INFO')
    u = unicode(e)
    if not isinstance(u, unicode):
        raise AssertionError("%s is not a unicode object" % (u,))



# Generated at 2022-06-12 07:42:40.296102
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__"""
    # Test 1.
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    assert e1 == e2 # str() is not an invariant
    e1 = IllegalUseOfScopeReplacer('name', 'msg1')
    e2 = IllegalUseOfScopeReplacer('name', 'msg2')
    assert e1 != e2 # str() is not an invariant
    # Test 2.
    e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e1 == e2
    assert str(e1) == str(e2)
    assert unicode(e1) == unicode(e2)


# Generated at 2022-06-12 07:42:52.908441
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer returns a unicode object."""
    e = IllegalUseOfScopeReplacer(
        name='foo',
        msg='attempted to use foo before it was set.')
    u = unicode(e)
    s = str(e)
    e1 = IllegalUseOfScopeReplacer(
        name=u'foo',
        msg='attempted to use foo before it was set.')
    u1 = unicode(e1)
    s1 = str(e1)
    assert u == u1
    assert s == s1



# Generated at 2022-06-12 07:43:04.500797
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    from bzrlib.tests import TestCase
    import sys
    import bzrlib.tests.test_lazy_import
    class Test(TestCase):
        def test_bad_assign(self):
            module = sys.modules[__name__]
            lazy_import.lazy_import(module.__dict__,
                '''from bzrlib.dummy import TestObject''')
            test = TestObject()
            # We allow this as it is a common case, and we don't want to
            # have to have a special exception for every assignment
            # between these two variables
            test.simple_attr = test.simple_attr
            test.method_call()
            test.method_call = test.method_call
            # Now with a proxy
            ScopeReplacer

# Generated at 2022-06-12 07:43:06.438568
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    return doctest.DocTestSuite(IllegalUseOfScopeReplacer)

# Generated at 2022-06-12 07:43:17.963086
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Testing method ScopeReplacer.__call__."""
    from bzrlib.tests import TestCase
    import bzrlib
    from bzrlib import (
        branch,
        errors,
        osutils,
        __builtins__,
        )
    from bzrlib.branch import Branch
    from bzrlib.revision import NullRevision

    class TestClass(object):
        def __init__(self):
            self.counter = 0

        def call_me(self):
            self.counter += 1
            return self

    def factory(self, scope, name):
        real = TestClass()
        return real

    ScopeReplacer._should_proxy = True
    test_class = ScopeReplacer(locals(), factory, 'test_class')

# Generated at 2022-06-12 07:43:23.302843
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    globals().pop('called', None)
    lazy_import(globals(), '''
    def called(*args, **kwargs):
        print 'called', args, kwargs
    ''')
    called(1, 2)


# The lazy_import function tries to be as general as possible, so that it can
# be used in various places throughout the code.
# In Python 2.5 and above, exec is a keyword and we can use it with
# locals(), but in earlier Python versions it is not a keyword and we have to
# use globals() instead.

# Generated at 2022-06-12 07:43:25.145464
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
  assert_equal(False, True) # TODO: implement your test here


# Generated at 2022-06-12 07:43:32.396732
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class TestScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            super(TestScopeReplacer, self).__init__(scope, factory, name)
            self._call_count = 0

        def _resolve(self):
            self._call_count += 1
            return self
    scope = {}
    factory = lambda s, sc, n: n
    name1 = "test1"
    name2 = "test2"
    sr1 = TestScopeReplacer(scope, factory, name1)
    sr2 = TestScopeReplacer(scope, factory, name2)
    assert sr1.__call__() == "test1"
    assert sr1._call_count == 1
    assert sr2.__call__() == "test2"
    assert sr2._call_count == 1