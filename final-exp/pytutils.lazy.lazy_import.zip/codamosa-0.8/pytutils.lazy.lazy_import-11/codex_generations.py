

# Generated at 2022-06-12 07:33:50.369293
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test the call method of ScopeReplacer
    class Baz(object):
        def __call__(self, x, y):
            return x+y
    globals = {}
    lazy_import(globals, '''
    from bzrlib.lazy_import import ScopeReplacer
    b = Baz()
    ''')
    b = globals['b']
    assert isinstance(b, ScopeReplacer)
    eq = globals['eq']
    eq(b(1,2), 3)
    assert isinstance(b, Baz)
    eq(b(1,2), 3)

# Generated at 2022-06-12 07:33:59.250152
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('a name', 'a message', 'extra info')
    assert str(e) == 'Unprintable exception IllegalUseOfScopeReplacer:' \
        ' dict={\'msg\': \'a message\', \'extra\': \'extra info\', ' \
            '\'name\': \'a name\'}, ' \
        'fmt=\'%(name)r was used incorrectly: %(msg)s%(extra)s\', ' \
        'error=None'
    e._fmt = '%(name)r was used incorrectly: %(msg)s%(extra)s'
    assert str(e) == 'a name was used incorrectly: a messageextra info'
    e._fmt = None
    e._preformatted_string

# Generated at 2022-06-12 07:34:05.198291
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global _called_count

    def fake_factory(self, scope, name):
        return name

    _called_count = 0
    def fake_scope():
        _called_count += 1

    _lazy_obj = ScopeReplacer(fake_scope, fake_factory, 'name')
    _lazy_obj('a', 'b')
    if _called_count != 1:
        raise AssertionError('_called_count: %d != 1' % _called_count)



# Generated at 2022-06-12 07:34:11.968246
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    scope = {}
    obj = bzrlib.lazy_import.ScopeReplacer(scope, lambda self, scope, name: name, 'foo')
    equals('foo', obj('bar', baz='biz'))
    return # unit test



# Generated at 2022-06-12 07:34:16.825312
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    repl = ScopeReplacer({}, lambda self, scope, name: self, 'name')
    repl._should_proxy = False
    try:
        repl.attr = None
        repl.attr2 = None
    except IllegalUseOfScopeReplacer as e:
        if e.name != 'name':
            raise
    else:
        raise AssertionError

# Generated at 2022-06-12 07:34:26.686214
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import, _resolve_scope, lazy_import_ext
    from bzrlib.lazy_import import _create_lazy_import_scope_replacer, scope_is_safe
    # create a scope we can use
    scope = {}
    # create a package to import
    import bzrlib
    # create an object to import
    _global_var = 'global'
    # test object with a set of modules and objects to be imported

# Generated at 2022-06-12 07:34:37.060098
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of class IllegalUseOfScopeReplacer"""
    x = IllegalUseOfScopeReplacer('name', 'msg')

    # Test with a preformatted string
    x._preformatted_string = 'xyz'
    r = x.__unicode__()
    # The result should be unicode and contain the preformatted string.
    if not isinstance(r, unicode) or r != u'xyz':
        raise AssertionError('%r, %r' % (r, u'xyz'))
    # Test with a non-preformatted string
    x._preformatted_string = None
    r = x.__unicode__()
    # The result should be a unicode string, that contains msg and extra.

# Generated at 2022-06-12 07:34:38.526943
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    return


# Generated at 2022-06-12 07:34:45.668521
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test scope replacement of an existing method on an existing object.

    This test will call the __getattribute__ method on an object that has
    an existing __getattribute__ method.  The existing __getattribute__ method
    will be called, so this test is also a test of the fixup code that the
    lazy_import system uses.
    """
    class TestObj(object):

        def __init__(self):
            self.got_attr = None

        def __getattribute__(self, attr):
            self.got_attr = attr
            return 'funky'

    # Make a scope replacer for a new object in the scope of the immediate
    # environment.  The object will have a __getattribute__ method.
    obj = TestObj()
    scope = {'obj': obj}
    name = 'obj'

# Generated at 2022-06-12 07:34:55.046008
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test method __str__ of class IllegalUseOfScopeReplacer"""

    import sys

    if sys.version_info < (3, 0):
        assert str(IllegalUseOfScopeReplacer("foo", "bar")) == "foo bar"
        assert str(IllegalUseOfScopeReplacer("foo", "baz", extra="zot")) == "foo baz: zot"
    else:
        assert str(IllegalUseOfScopeReplacer("foo", "bar")) == "foo bar"
        assert str(IllegalUseOfScopeReplacer("foo", "baz", extra="zot")) == "foo baz: zot"


# avoid circular imports
from .trace import (
    note,
    )



# Generated at 2022-06-12 07:35:15.086532
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import tests as _tests
    from bzrlib.lazy_import import lazy_import as _lazy_import
    class TestObj(object):
        def __init__(self, x, y=3):
            self.x = x
            self.y = y
    def _lazy_tst_obj_factory(self, scope, name):
        return TestObj(scope[name+'_x'], scope[name+'_y'])

# Generated at 2022-06-12 07:35:16.406239
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass


# Generated at 2022-06-12 07:35:27.283470
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Verify IllegalUseOfScopeReplacer.__unicode__() produces reasonable output"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    expected_value = u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'
    assert e.__unicode__() == expected_value
    # Make sure Unicode exception messages work
    class DummyUnicodeException(IllegalUseOfScopeReplacer):
        _fmt = u"\xa7 ill-formed \u1234"
    e = DummyUnicodeException('name', 'msg')
    assert isinstance(e.__unicode__(), unicode)
    assert '\xa7' in e.__unicode__()


# Generated at 2022-06-12 07:35:39.380568
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return a str object"""

    import sys
    if sys.version_info[0] == 3:
        e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
        # See test_exceptions.py for more tests on the __str__ implementation.
        # assert isinstance(e.__str__(), str)
        return
    else:
        e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
        # See test_exceptions.py for more tests on the __str__ implementation.
        # assert isinstance(e.__str__(), str)
        return
    import warnings

# Generated at 2022-06-12 07:35:44.597356
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('x', "some message", extra='y')
    u = unicode(e)
    assert isinstance(u, unicode)
    u2 = unicode(e)
    assert u == u2


# Generated at 2022-06-12 07:35:45.789082
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # TODO: Pass

    return 'ok'



# Generated at 2022-06-12 07:35:54.901911
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """ Unit test for method __call__ of class ScopeReplacer"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, lazy_class, lazy_function
    import bzrlib.tests.test_lazy_import

    class Foo(object):
        def bar(self):
            return 1
    scope = {}
    lazy_import(scope, '''
    import bzrlib.lazy_import
    ''')
    bzrlib.tests.test_lazy_import = Foo()
    obj = scope['bzrlib'].tests.test_lazy_import.ScopeReplacer(scope, lambda a,b,c:Foo(), 'Foo')
    self.assertEqual(1, obj.bar())



# Generated at 2022-06-12 07:36:00.827515
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This test checks that the method __str__ of class IllegalUseOfScopeReplacer
    returns a str object and not a unicode one. The method is written so that
    it should return a str and not a unicode. However there may be a bug. The
    test checks this by checking the type of the object returned::
    
        >>> type(IllegalUseOfScopeReplacer('hello','there').__str__())
        <type 'str'>
    """


# Generated at 2022-06-12 07:36:05.270279
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    l = lazy_import.ScopeReplacer({}, lambda x,y,z: None, "z")

# Generated at 2022-06-12 07:36:09.521791
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test that ScopeReplacer is callable.
    import bzrlib
    global z
    z = 42
    bzrlib.lazy_import(globals(), """z = z + 1""")
    z()
    assert z == 43



# Generated at 2022-06-12 07:36:24.472225
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ must return a unicode string."""
    er = IllegalUseOfScopeReplacer("foo", "bar")
    u = unicode(er)
    assert isinstance(u, unicode)
    assert u  == u'foo was used incorrectly: bar'


# Unit tests for method _format of class IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:36:27.046490
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer("myvar", "something something")
    u = unicode(e)
    assert type(u) is unicode



# Generated at 2022-06-12 07:36:29.063941
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    inst = IllegalUseOfScopeReplacer("name", "msg", "extra")
    assert isinstance(inst.__unicode__(), unicode)



# Generated at 2022-06-12 07:36:35.394979
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    __tracebackhide__ = True
    class Foo(object):
        def __init__(self):
            pass
        def __call__(self):
            return 1
    class Test(TestCase):
        def test_callable(self):
            foo = Foo()
            a = ScopeReplacer(locals(), lambda *args: foo, 'foo')
            self.assertEqual(1, a())

# Generated at 2022-06-12 07:36:37.235166
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    def _replace_with_int(self, *args):
        return 42
    lazy_import(_replace_with_int, globals(), 'int', factory=_replace_with_int)
    assert int(23) == 42



# Generated at 2022-06-12 07:36:46.179145
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    g = {}
    def factory(self, scope, name):
        return {}
    ScopeReplacer(g, factory, 'a')
    self = g['a']
    obj = self._resolve()
    ScopeReplacer._should_proxy = False
    self.b = ['aaa']
    obj.c = ['bbb']
    self.d = ['ccc']
    try:
        self.e = ['ddd']
    except IllegalUseOfScopeReplacer as e:
        TestCase.assertEqual(
            TestCase,
            str(e),
            "Object already replaced, did you assign it to another variable?")
    else:
        TestCase.fail('should fail')

# Generated at 2022-06-12 07:36:57.286100
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from testresources import OptimisingTestSuite
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.tests import TestCase

    class TestCaseSubclass(TestCase):
        def setUp(self):
            TestCase.setUp(self)
            self._name = '_name'
            self._real_obj = None
            self._scope = {}
            self._factory = None
            self._should_proxy = True

        def tearDown(self):
            del self._name
            del self._real_obj
            del self._scope
            del self._factory
            del self._should_proxy
            TestCase.tearDown(self)

        def test_getattribute_returns_real_obj(self):
            self._factory = lambda self, scope, name: str('foo')


# Generated at 2022-06-12 07:37:05.505593
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import tests, lazy_import
    l = lazy_import.lazy_import
    l(globals(), '''
from bzrlib import (
    errors,
    osutils,
    tests,
    )
''')

    class A(object):
        # The following line is needed, otherwise the method under test is
        # never called and the test is meaningless.
        def __init__(self):
            self.b = 1

    class B(object):
        def b(self):
            "Some doc string to test that it's passed through."
            return 2
    def c():
        pass

    def is_ScopeReplacer(x):
        return isinstance(x, ScopeReplacer)

    # Test __setattr__ for each type of object it should proxy

# Generated at 2022-06-12 07:37:16.076095
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from testresources import TestResourceManager
    from bzrlib.lazy_import import lazy_import
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    lazy_import(locals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    if ScopeReplacer._should_proxy:
        with TestResourceManager('') as resources:
            bzrlib.branch = resources.get_managed_resource(
                                'BzrBranchResource')
            bzrlib.branch.BzrBranch.__setattr__()

# Generated at 2022-06-12 07:37:25.735936
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should work"""
    # __unicode__ must return a unicode object (unicode subclasses are fine)
    # cannot contain non-unicode strings.
    err = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(err)
    from bzrlib.i18n import gettext
    msg = gettext("ScopeReplacer object '%(name)r' was used incorrectly:"
        " %(msg)s%(extra)s")
    assert u == msg % {'name': 'name', 'msg': 'msg', 'extra': ''}, (
        "expected %r, got %r" % (msg % {'name': 'name', 'msg': 'msg', 'extra': ''}, u))



# Generated at 2022-06-12 07:37:39.004909
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    #__call__ is tested by test_lazy_import_call
    pass # tested by test_lazy_import_call



# Generated at 2022-06-12 07:37:41.731692
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'blah')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:37:53.323980
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    from bzrlib import lazy_import
    from bzrlib.lazy_import import ScopeReplacer, IllegalUseOfScopeReplacer
    from bzrlib.tests import (
        TestCase,
        )
    from bzrlib.tests.features import (
        ModuleAvailableFeature,
        )
    import sys

    class _TestCall(TestCase):

        def test_scope_replacer_call_fails_when_scope_replaced(self):
            def create_replaced_method(replacer, scope, name):
                return 1

# Generated at 2022-06-12 07:37:56.542054
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    def foo():
        return 3
    a = bzrlib.lazy_import.ScopeReplacer({}, foo, 'foo')
    assert a() == 3


# Generated at 2022-06-12 07:38:00.131794
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = e.__str__()
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')



# Generated at 2022-06-12 07:38:11.698901
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import tests

    def test(obj, attr, value, expected):
        obj.__setattr__(attr, value)
        tests.TestCase.assertEqual(None, expected, obj.__dict__[attr])

    t = ScopeReplacer('..', '..', '..')
    t.__dict__['attr'] = value = object()
    test(t, 'attr', value, value)
    test(t, 'attr2', value, value)
    test(t, None, value, value)
    test(t, '', value, value)

    class MyObject(object):
        def __setattr__(self, attr, value):
            super(MyObject, self).__setattr__(attr, 'x')


# Generated at 2022-06-12 07:38:15.851222
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class foo(object):
        pass
    scope = {}
    scope['foo'] = ScopeReplacer(scope, foo, 'foo')
    scope['foo'].attr = 'xyz'
    assert scope['foo'].attr == 'xyz'
    assert scope['foo'].__class__ is foo 

# Generated at 2022-06-12 07:38:26.763947
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object.

    The __unicode__ method should return a unicode object, so that when it is
    printed as %s, or %r, or as a '%(msg)s' in a format string, it behaves
    as a unicode object.
    """
    class TestException(Exception):
        _fmt = 'Test exception'
    e = TestException()
    if isinstance(e.__unicode__(), unicode):
        pass
    elif isinstance(e.__str__(), unicode):
        raise AssertionError("IllegalUseOfScopeReplacer.__str__() should not"
            " return a unicode object.")

# Generated at 2022-06-12 07:38:39.163594
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    import bzrlib.branch
    import bzrlib.urlutils
    import bzrlib.workingtree
    class Foo(object):
        def __init__(self, name, factory):
            self._name = name
            self._factory = factory
            self._attr = 'foo'
        def __getattribute__(self, name):
            if name.startswith('_'):
                return object.__getattribute__(self, name)
            else:
                self._factory(self, self._name, name)
                return object.__getattribute__(self, name)
        def bar(self, name):
            if name == '__getattribute__':
                return object.__get

# Generated at 2022-06-12 07:38:47.978442
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    import re

    lazy_import(globals(), '''
    from bzrlib import (
        config,
        )
    ''')

    def test(regex):
        r = re.compile(regex)
        return r.search('xxx') is not None
    test('xxx') # no error
    assert test(r'xxx') # no error
    assert test(re.compile(r'xxx')) # no error

    test(config.GlobalConfig()) # error



# Generated at 2022-06-12 07:38:59.733244
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-12 07:39:03.875593
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    x = IllegalUseOfScopeReplacer('bad_name', 'bad_msg', extra='extra')
    s = str(x)
    assert isinstance(s, str)
    assert s == ("ScopeReplacer object 'bad_name' was used incorrectly:"
                " bad_msg: extra")


# Generated at 2022-06-12 07:39:14.732173
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Method __getattribute__ of class ScopeReplacer"""
    class C_test_ScopeReplacer___getattribute__(object):
        """A class to allow testing of __getattribute__"""
        def __getattribute__(self, attr):
            return "__getattribute__ %s" % attr
    c = C_test_ScopeReplacer___getattribute__()
    r = ScopeReplacer(locals(), lambda self, scope, name: c, 'c')
    # r should proxy calls to c.__getattribute__
    eq(c.__getattribute__('foo'), '__getattribute__ foo')
    eq(r.__getattribute__('foo'), '__getattribute__ foo')
    # __getattribute__ is a bit of a special case, as it is used to access
    # all other attributes, even __getattr__.


# Generated at 2022-06-12 07:39:16.719155
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """
    TODO: remove this
    """
    __tracebackhide__ = True
    raise NotImplementedError(
        "test test_ScopeReplacer___setattr__ still not implemented")



# Generated at 2022-06-12 07:39:19.224474
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object (not unicode)"""
    e = IllegalUseOfScopeReplacer('foo', 'hello')
    assert isinstance(e.__str__(), str)


# Generated at 2022-06-12 07:39:21.304084
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.trace
    bzrlib.trace.mutter('foo')

# Generated at 2022-06-12 07:39:23.540669
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    instance = ScopeReplacer({}, lambda:True, 'n')
    assert instance.__call__() == True


# Generated at 2022-06-12 07:39:33.926762
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """_setattr__()

    Note that this is currently a 'sugar' test, as it only looks for the
    exception, rather than checking the values of the object
    """
    from bzrlib.tests import decorators
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    import sys
    sr = bzrlib.lazy_import.ScopeReplacer({}, lambda a,b,c:4, 'foo')
    try:
        sr.foo = 5
    except bzrlib.lazy_import.IllegalUseOfScopeReplacer as e:
        decorators.expect_exception_message(e, "Object already replaced")
        sr.foo = 3
        # Proxy mode should still be disabled
        decorators.expect

# Generated at 2022-06-12 07:39:41.009118
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__"""
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    exc.foo = 'bar'
    s = str(exc)
    assert "IllegalUseOfScopeReplacer('name', 'msg', 'extra')" == repr(exc)
    assert "msg: 'extra'" in s
    assert "Unprintable exception IllegalUseOfScopeReplacer: dict" not in s
    assert "foo" not in s
    assert "bar" not in s
    exc = IllegalUseOfScopeReplacer('name', 'Unprintable exception %s: '
        'dict=%r, fmt=%r, error=%r',
        (exc.__class__.__name__, exc.__dict__, exc._fmt, None))
    s = str(exc)

# Generated at 2022-06-12 07:39:50.966057
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from cStringIO import StringIO

    # test calling a function
    real_obj = StringIO()
    lazy = ScopeReplacer({}, lambda s, sc, n: real_obj, 'real_obj')
    lazy.write("hello world")
    assert real_obj.getvalue() == "hello world"
    assert real_obj is lazy.getvalue() is lazy()

    # test calling a class
    real_obj = object()
    lazy = ScopeReplacer({}, lambda s, sc, n: real_obj, 'real_obj')
    assert real_obj is lazy()

    # test calling a class with args
    real_obj = list
    lazy = ScopeReplacer({}, lambda s, sc, n: real_obj, 'real_obj')
    assert [1,2,3] == lazy([1,2,3])

   

# Generated at 2022-06-12 07:40:29.055882
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This test is not meant to be exhaustive, but merely to show that it
    works for a variety of input types.
    """
    lus = IllegalUseOfScopeReplacer('lus', 'lus')
    u = unicode(lus)
    s = str(lus)
    assert isinstance(u, unicode)
    assert isinstance(s, str)
    assert '...IllegalUseOfScopeReplacer(...' in u
    assert '...IllegalUseOfScopeReplacer(...' in s

    # Now, try unicode argument
    lus = IllegalUseOfScopeReplacer('lus', u'\x7f')
    u = unicode(lus)
    s = str(lus)
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:40:32.149827
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    a = ScopeReplacer(globals(), lambda x,y,z: lambda x,y: x+y, 'a')
    assert a(1,2) == 3



# Generated at 2022-06-12 07:40:38.688065
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import unittest


    class TestScopeReplacer(unittest.TestCase):
        def test_simple(self):
            import bzrlib.trace
            bzrlib.trace.set_verbosity(0)
            scope = {}
            def factory(self, scope, name):
                return lambda: 'ok'
            def make_replacer():
                return ScopeReplacer(scope, factory, 'only_name')
            test_replacer = make_replacer()
            self.assertEqual('ok', test_replacer())

    unittest.main()



# Generated at 2022-06-12 07:40:46.489289
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.trace import mutter # imported from bzrlib
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer # imported from bzrlib
    import sys # imported from bzrlib
    scope_replacer = bzrlib.lazy_import.ScopeReplacer(scope=sys.modules, 
        factory=lambda self, scope, name: getattr(bzrlib, name), 
        name='errors')
    assert scope_replacer is scope_replacer._resolve()
    scope_replacer = bzrlib.lazy_import.ScopeReplacer(scope=sys.modules, 
        factory=lambda self, scope, name: getattr(bzrlib, name), 
        name='errors')

# Generated at 2022-06-12 07:40:55.538391
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, args, kwargs)"""
    class C(object):
        def __init__(self, x):
            self.x = x
        # Unit test for method __call__ of class C
        def test_C___call__(self):
            """__call__(self, *args, **kwargs)"""
            return

    def factory(self, scope, name):
        return C(3)

    scope = dict()
    name = 'x'
    obj = ScopeReplacer(scope, factory, name)
    retval = obj(4)
    assert type(retval) == int, 'call failed'



# Generated at 2022-06-12 07:40:58.047994
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return str (unicode)"""
    exc = IllegalUseOfScopeReplacer('foo', 'bar')
    s = unicode(exc)
    assert isinstance(s, unicode)



# Generated at 2022-06-12 07:41:09.130787
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should not raise exceptions, and should always return unicode

    A UnicodeDecodeError will be raised if the default encoding can not
    decode a message.  This is a bug in the default encoding, and
    perhaps the default encoding should be checked when imported.

    A UnicodeEncodeError will be raised if the default encoding can not
    encode a message.  This is a bug in the default encoding, and
    perhaps the default encoding should be checked when imported.

    """
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', u'msg')
    e3 = IllegalUseOfScopeReplacer('name', u'msg', 'extra')
    e4 = IllegalUseOfScopeReplacer('name', 'msg', u'extra')
    import bzrlib.i18n

# Generated at 2022-06-12 07:41:15.090762
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ converts the message to unicode in case it is a str.

    In case of an unprintable exception, it tries to build a unicode string
    from the dict, fmt and error fields.
    """
    class Foo(Exception):
        _fmt = "A %(name)s message %(extra)s"
    foo = Foo("toto")
    foo.name = "foo"
    foo.extra = "for testing"
    unicode(foo)


# Generated at 2022-06-12 07:41:19.974376
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-12 07:41:23.596459
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer(name=u'f1', msg=u'foo')
    s = str(e)
    assert isinstance(s, str), "__str__ of IllegalUseOfScopeReplacer did not return a str: returned %r: %r" % (type(s), s)


# Generated at 2022-06-12 07:42:09.825018
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """
    """
    o = ScopeReplacer('scope', 'factory', 'name')
    o.__setattr__('attr', 'value')



# Generated at 2022-06-12 07:42:20.595295
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    lazy_import(globals(), '''
    import bzrlib.proxy
    ''')

    class Foo(object):
        def __init__(self):
            self.a = 1
        def foo(self):
            return 2
        def __cmp__(self, other):
            return cmp(self.__class__, other.__class__)

    def get_foo():
        return Foo()

    foo = ScopeReplacer(globals(), get_foo, 'foo')

    # Tests that __call__ works correctly to the underlying object.
    eq = bzrlib.proxy.ProxyObjectTest.eq
    eq(foo.foo(), 2)
    eq(foo.a, 1)
    foo.a = 3
    eq(foo.a, 3)



# Generated at 2022-06-12 07:42:29.760328
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should be equivalent to __str__.

    There is a bit of extra machinery in __unicode__ to handle non-utf8
    strings:

    - we assume strings are encoded in utf8 (this is a bug, but one that
      cannot be fixed for now);
    - if we get a non-utf8 string, we try to convert it to unicode;
    - if we still get a non-utf8 string (which happens with python versions
      that do not support unicode), we fallback on the generic code.

    So __unicode__ should be equivalent to __str__ when all strings are in
    utf8, and is less likely to be equivalent when they are not.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg', {'foo': 'bar'})
    assert str(e) == unicode

# Generated at 2022-06-12 07:42:34.865774
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    from bzrlib.tests import TestCase
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    self.assertIsInstance(u, unicode)
    self.assertEndsWith(u, 'unicode')



# Generated at 2022-06-12 07:42:41.003668
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ of class IllegalUseOfScopeReplacer works."""
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    e3 = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    e4 = IllegalUseOfScopeReplacer('othername', 'msg')
    e5 = IllegalUseOfScopeReplacer('name', 'othermsg')
    # Test 'e1 == e2'
    assert e1 == e2
    # Test 'e1 != e3'
    assert e1 != e3
    # Test 'e1 != e4'
    assert e1 != e4
    # Test 'e1 != e5'
    assert e1 != e5




# Generated at 2022-06-12 07:42:44.093296
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should produce a string"""
    import doctest
    doctest.run_docstring_examples(
        IllegalUseOfScopeReplacer.__str__, globals())



# Generated at 2022-06-12 07:42:53.549498
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib._lazy_import import _ModuleReplacer
    from bzrlib._lazy_import import _AttributeReplacer
    from bzrlib._lazy_import import _ObjectReplacer
    from bzrlib._lazy_import import _ImportReplacer

    # This test has been automatically generated from
    # "test__lazy_import.py"
    # by
    # $ bzr double-horse revisit-test-generator --directory . --to test__lazy_import.py
    # See http://doc.bazaar.canonical.com/testing.html#double-horse
    # for details.
    # FIXME: Write real tests instead of using auto-generated ones.

    replacer = None # set by test
    replacer2 = None # set by test
    replacer3 = None # set

# Generated at 2022-06-12 07:43:05.090865
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method IllegalUseOfScopeReplacer.__str__

    If the exception's message has been preformatted in .__init__, then
    it should be returned by .__str__.
    """
    e = IllegalUseOfScopeReplacer(
        'exception_name', 'exception_msg', 'exception_extra')
    e._preformatted_string = 'preformatted_msg'
    assert str(e) == 'preformatted_msg'

    e = IllegalUseOfScopeReplacer(
        'exception_name', 'exception_msg', 'exception_extra')
    e._fmt = "exception_fmt"
    e._preformatted_string = 'preformatted_msg'
    assert str(e) == 'preformatted_msg'



# Generated at 2022-06-12 07:43:16.773211
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This tests the IllegalUseOfScopeReplacer.__str__ method.

    XXX: This is not very good, it doesn't really test anything, but it should
    at least be a start.
    """

    def _test(kwargs):
        """Helper function to test IllegalUseOfScopeReplacer"""

# Generated at 2022-06-12 07:43:23.715754
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Make sure that code that implements __str__ and __unicode__
    doesn't throw exceptions when trying to display exceptions
    that haven't been marked for translation yet.

    If the subclass does not have a _fmt attribute, then it should
    not be displayed.

    If the subclass has a _fmt attribute, then it should be displayed
    when there is no translation available.

    """
    class FooBarException(Exception):
        pass
    class TranslatableException1(IllegalUseOfScopeReplacer):
        _fmt = "Translation %(foo)s."
    class TranslatableException2(IllegalUseOfScopeReplacer):
        _fmt = "Translation %(foo)s."
        def _get_format_string(self):
            return None
    class TranslatableException3(IllegalUseOfScopeReplacer):
        _fmt