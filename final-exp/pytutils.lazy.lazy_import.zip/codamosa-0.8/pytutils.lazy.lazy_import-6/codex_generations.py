

# Generated at 2022-06-12 07:33:54.810597
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Ensure that IllegalUseOfScopeReplacer.__str__ returns a str."""
    import sys
    from breezy.tests import TestCase
    TestCase.assertIsInstance(IllegalUseOfScopeReplacer('name', 'msg').__str__(), str)
    # Test that UnicodeEncodeError does not get raised

# Generated at 2022-06-12 07:34:05.702737
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object, no matter what."""
    e = IllegalUseOfScopeReplacer('foo', u'bar')
    u = e.__unicode__()
    # First level: __unicode__ must return a unicode object, not a str
    # object.
    # Then, we test if the returned object is really a unicode object.
    # If it's not, we try to make a unicode object from it, because
    # __unicode__ must return a unicode object.
    # If this method still fails, the test fails too, no matter what.
    if not isinstance(u, unicode):
        u = unicode(u)
    assert isinstance(u, unicode)
    assert u.encode('utf8') == u'foo: bar'



# Generated at 2022-06-12 07:34:08.340222
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    return ConcreteScopeReplacer(None, None, None)()

# Generated at 2022-06-12 07:34:12.715873
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest, testresources.testsupport
    doctest.DocTestSuite(testresources.testsupport).run()

    # Now all the other methods...
    # (since r15797, we don't have any other non-dunders)



# Generated at 2022-06-12 07:34:21.435430
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__()

    This method should return a unicode object.
    """
    import bzrlib.trace
    bzrlib.trace.set_verbosity(1)
    e = IllegalUseOfScopeReplacer('name', u'A unicode message')
    u = unicode(e) # method __unicode__() must return a unicode object
    s = str(e)
    bzrlib.trace.note(u + s)

    # The returned string should be in the default encoding (utf8):
    if isinstance(u, unicode):
        raise AssertionError('method __unicode__() should return a str object,'
                             ' but returned a unicode object')
    # The returned string should have a unicode object:
    if not isinstance(s, unicode):
        raise Assert

# Generated at 2022-06-12 07:34:23.165966
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)
    """


# Generated at 2022-06-12 07:34:28.836392
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class DummyScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            super(DummyScopeReplacer, self).__init__(scope, factory, name)
        def __call__(self, *args, **kwargs):
            return 42
    class ScopeReplacerTestCase(TestCase):
        def test_DummyScopeReplacer(self):
            dummy_globals = {}
            def dummy_factory(self, scope, name):
                return 'hello'
            obj_in_scope = DummyScopeReplacer(dummy_globals, dummy_factory,
                'obj_in_scope')
            self.assertEqual(42, obj_in_scope())

# Generated at 2022-06-12 07:34:37.233612
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():

    # Test with a unicode _fmt
    e = IllegalUseOfScopeReplacer('name', 'msg', 'info')
    e._fmt = u"%(name)s: %(msg)s"
    result = str(e)
    expected_result = "name: msg"
    assert(result == expected_result)

    # Test with a str _fmt
    e = IllegalUseOfScopeReplacer('name', 'msg', 'info')
    e._fmt = "%(name)s: %(msg)s"
    result = str(e)
    expected_result = "name: msg"
    assert(result == expected_result)


# Generated at 2022-06-12 07:34:43.937516
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """ScopeReplacer.__setattr__ should not raise"""
    from bzrlib import lazy_import
    lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    ''')
    for name in ['errors', 'osutils', 'branch']:
        obj = globals()[name]
        assert isinstance(obj, ScopeReplacer)
        obj.foo = 'bar'
    import bzrlib
    assert isinstance(bzrlib, ScopeReplacer)
    bzrlib.foo = 'bar'



# Generated at 2022-06-12 07:34:51.091290
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ returns a str

    A UnicodeDecodeError should be avoided in
    bzrlib/lazy_import.py:IllegalUseOfScopeReplacer.__str__.
    """
    e = IllegalUseOfScopeReplacer('\xf0', '\xf0')
    str(e)



# Generated at 2022-06-12 07:35:09.338968
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    class Example(object):
        def method(self, a, b=None, **kwargs):
            return a, b, kwargs
        def __call__(self, *args, **kwargs):
            return args, kwargs
    def factory(self, globals, name):
        obj = Example()
        obj.self = self
        obj.name = name
        obj.globals = globals
        return obj

    class TestScopeReplacer(TestCase):
        def test_replace(self):
            globals = {}
            ScopeReplacer(globals, factory, 'foo')
            if 'foo' in globals:
                raise AssertionError("globals should not yet contain foo")
            foo = globals['foo']
            # Test before getting a

# Generated at 2022-06-12 07:35:10.830978
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""



# Generated at 2022-06-12 07:35:18.030631
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class UnitTestScopeReplacer(ScopeReplacer):
        def __init__(self, scope):
            super(UnitTestScopeReplacer, self).__init__(scope, UnitTestScopeReplacer, 'UnitTestScopeReplacer')
            scope['balance'] = 0
        def _factory(self, scope, name):
            scope[name] = object.__getattribute__(self, '_resolver')
            return scope['balance']
        def _resolver(self, deposit=0):
            scope = object.__getattribute__(self, '_scope')
            scope['balance'] += deposit
            return scope['balance']
    scope = {}
    #
    # TODO: This doesn't test the proxy.
    #
    r = UnitTestScopeReplacer(scope)

# Generated at 2022-06-12 07:35:28.718866
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class foo(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __call__(self, *args, **kwargs):
            return [self.x, self.y, args, kwargs]

    import sys

    scope = {}
    replacer = ScopeReplacer(scope, lambda s, sc, n:
        foo(1,2), "foo")

    # Check that the real object can be called
    result1 = scope['foo'](3,4)
    expected1 = [1,2,(3,4),{}]
    if result1 != expected1:
        raise AssertionError('result1 != expected1:\n%r\n!=\n%r' % (
            result1, expected1))

    # Check that it

# Generated at 2022-06-12 07:35:33.816722
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of IllegalUseOfScopeReplacer"""
    # Test that __unicode__ works on error classes that do not define
    # _get_format_string.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    foo = unicode(e)



# Generated at 2022-06-12 07:35:37.752222
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This exception must be able to format itself no matter what"""
    instance = Exception()
    instance.__unicode__ = None
    e = IllegalUseOfScopeReplacer('name', 'msg', instance)
    repr(e)



# Generated at 2022-06-12 07:35:45.949946
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)

    If you to do x = y, setting this to False will disallow access to
    members from the second variable (i.e. x). This should normally
    be enabled for reasons of thread safety and documentation, but
    will be disabled during the selftest command to check for abuse.
    """
    enabled=True
    ScopeReplacer._should_proxy = enabled
    from bzrlib import lazy_import
    lazy_import.ScopeReplacer._should_proxy = enabled
# end test_ScopeReplacer___setattr__

# Generated at 2022-06-12 07:35:50.350336
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__"""

# Generated at 2022-06-12 07:35:53.563636
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # do it this way to make it doctest safe
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer.__call__(None)



# Generated at 2022-06-12 07:35:56.418894
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    e = IllegalUseOfScopeReplacer(u'name', 'msg')
    assert unicode(e) == u'name: msg'

# Generated at 2022-06-12 07:36:12.240582
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return the str of the result of __unicode__"""
    e = IllegalUseOfScopeReplacer("foo", "bar")
    # We don't care about the exact value, just that it's a string
    assert isinstance(str(e), str)
    assert str(e) == unicode(e).encode("UTF-8")



# Generated at 2022-06-12 07:36:21.513419
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    u = unicode(e)
    # If we add this test, Python 2.6 will fail because str is not unicode.
    #if isinstance(s, unicode):
    #    raise AssertionError('str(%r) is a unicode object' % (e,))
    if isinstance(u, str):
        raise AssertionError('unicode(%r) is a str object' % (e,))
    if not isinstance(s, str):
        raise AssertionError('str(%r) is not a str object' % (e,))

# Generated at 2022-06-12 07:36:28.750110
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests as tests_module
        # It is an error to access a module level object before the test
        # framework is initialised.
    import bzrlib.tests.blackbox as blackbox_module
        # It is an error to access a module level object before the test
        # framework is initialised.
    from bzrlib.tests.blackbox import TestCase
        # It is an error to access a module level object before the test
        # framework is initialised.
    import bzrlib.tests.features
        # It is an error to access a module level object before the test
        # framework is initialised.
    import bzrlib.tests.script
        # It is an error to access a module level object before the test
        # framework is initialised.
    from bzrlib.tests import TestSkipped

# Generated at 2022-06-12 07:36:35.846977
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer.

    Ensure that __str__ on a class that uses __unicode__ works just fine
    (it  does not crash and does return a valid string).

    This is needed for Python 2.4.
    """
    u = u'foo'
    e = IllegalUseOfScopeReplacer('bar', u)
    s = str(e) # this should not crash and should return a valid string.
    assert isinstance(u, unicode)
    assert isinstance(s, str)



# Generated at 2022-06-12 07:36:41.839197
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    globals_ = {}
    lazy_import(globals_, '''
    from bzrlib import (
        osutils,
        )
    ''')
    osutils_lazy = globals_['osutils']
    assert isinstance(osutils_lazy, ScopeReplacer)
    # Invoke osutils_lazy, because otherwise the real osutils module
    # will not be imported.
    osutils_lazy().fstat()



# Generated at 2022-06-12 07:36:44.437656
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import tests
    expected = 5
    class Foo(object):
        def __call__(self, *args, **kwargs):
            return expected
    d = {}
    foo = ScopeReplacer(d, lambda obj, scope, name: Foo(), 'foo')
    actual = foo()
    tests.TestCase.assertEqual(tests.TestCase, expected, actual)


# Generated at 2022-06-12 07:36:53.636268
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import os
    import sys
    scope = locals()
    scope.update(globals())
    scope_replacer = ScopeReplacer(scope,
        lambda self, scope, name: os.dup(0), 'os_dup')
    scope_replacer.__call__()
    if os_dup is not scope_replacer:
        raise AssertionError
    if type(os_dup) is not type(os.dup):
        raise AssertionError



# Generated at 2022-06-12 07:37:03.418644
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() works"""
    e1 = IllegalUseOfScopeReplacer(
        'name', 'further information\nfor you')
    e2 = IllegalUseOfScopeReplacer(
        'name', 'further\ninformation\nfor you')
    e3 = IllegalUseOfScopeReplacer(
        'name', 'further information\nfor you')
    e4 = IllegalUseOfScopeReplacer(
        'name', 'further\ninformation\nfor you')
    assert e1 != e2
    assert e2 != e1
    assert e1 == e3
    assert e3 == e1
    assert e2 == e4
    assert e4 == e2
    # Check that we are doing a deep comparison
    e2.extra = '\nand something extra'


# Generated at 2022-06-12 07:37:04.027280
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
  pass

# Generated at 2022-06-12 07:37:14.949140
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib import errors, tests
    from bzrlib import (
        tests,
        )
    from bzrlib.tests import TestCase
    # This code was automatically generated by a compiler
    # It is not very readable, but it should run almost as fast
    # as the original code.
    # Please do not edit this code unless you know what you are doing.
    real_obj = object()
    scope = { }
    class Factory:
        _real_obj = real_obj
        def __call__(self, *args, **kwargs):
            return self._real_obj
    import bzrlib
    factory = Factory()
    name

# Generated at 2022-06-12 07:37:29.486162
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """test method __unicode__() of class IllegalUseOfScopeReplacer"""
    from bzrlib import (
        osutils,
        )
    from bzrlib.tests import TestCase
    e = IllegalUseOfScopeReplacer('foo', 'bar', osutils)
    # Just assert that __unicode__ does not raise an exception.
    e.__unicode__()

# Generated at 2022-06-12 07:37:34.899315
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer""" # $NON-NLS-1$
    import doctest
    doctest.run_docstring_examples(
        IllegalUseOfScopeReplacer.__str__,
        globals(),
        verbose=False,
        name="IllegalUseOfScopeReplacer.__str__")



# Generated at 2022-06-12 07:37:39.922523
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing IllegalUseOfScopeReplacer._format"""
    from bzrlib.tests import TestCase

    class TestException(TestCase.TestCase):

        def test_format(self):
            e = IllegalUseOfScopeReplacer('x', 'y')
            self.assertEqual('Illegal use of scope replacer x: y', e._format())

    TestException().test_format()



# Generated at 2022-06-12 07:37:45.141334
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() is idempotent"""
    x = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = unicode(x)
    t = unicode(x)
    assert s == t
    assert isinstance(s, unicode)
    assert isinstance(t, unicode)


# Generated at 2022-06-12 07:37:54.665473
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Method __call__ of class ScopeReplacer"""
    import operator
    # Assume zero-parameter function:
    assert ScopeReplacer(globals(), operator.truth, 'truth').__call__() is True
    # Assume one-parameter function:
    assert ScopeReplacer(globals(), operator.isCallable, 'isCallable').__call__(ScopeReplacer)
    # Assume two-parameter function:
    assert ScopeReplacer(globals(), operator.mod, 'mod').__call__(12, 7) == 5
    # Assume no-parameter function that returns function:
    assert ScopeReplacer(globals(), lambda x: operator.add, 'add').__call__()(3, 4) == 7



# Generated at 2022-06-12 07:38:02.551103
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str"""
    from . import lazy_import
    lazy_import(globals(), '''
    from bzrlib.errors import IllegalUseOfScopeReplacer
    ''')
    try:
        raise IllegalUseOfScopeReplacer("foo", "msg")
    except IllegalUseOfScopeReplacer as e:
        assert isinstance(str(e), str)
        assert isinstance(unicode(e), unicode)
        assert isinstance(repr(e), str)


# Generated at 2022-06-12 07:38:08.220774
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import (
        osutils,
        )
    import bzrlib.osutils
    assert osutils is not bzrlib.osutils
    assert osutils.__class__ is bzrlib.osutils.__class__
    # Normally this is already replaced by lazy_import()
    assert osutils.pathjoin is bzrlib.osutils.pathjoin



# Generated at 2022-06-12 07:38:17.941563
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    ''')
    errors._ScopeReplacer._should_proxy = False

# Generated at 2022-06-12 07:38:21.937665
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    instance = IllegalUseOfScopeReplacer('a', 'b', 'c')
    str(instance)
    try:
        instance._fmt = None
        str(instance)
    except:
        pass
    instance._fmt = '%(name)s'


# Generated at 2022-06-12 07:38:30.947147
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.per_lazy_import import TestCaseWithMemoryTransport

    class TestScopeReplacer(TestCaseWithMemoryTransport):

        def test_call_after_replacement(self):
            global scope_replacer_test_scope
            scope_replacer_test_scope = {}
            scope = scope_replacer_test_scope

            def factory(self, scope, name):
                def get_self():
                    return self
                self._factory_made_object = get_self
                return get_self()

            self.scope_replacer = ScopeReplacer(scope, factory, 'self')
            self.assertEqual(self.scope_replacer, scope['self'])
            # The scope_replacer should be replaced by the factory on the
            # first call

# Generated at 2022-06-12 07:38:54.361498
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ is not allowed to raise UnicodeDecodeError."""
    e = IllegalUseOfScopeReplacer('a', 'b')
    # Following line must not raise UnicodeDecodeError.
    u = unicode(e)
    s = str(e) # also must not raise UnicodeDecodeError



# Generated at 2022-06-12 07:39:04.683370
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Tests for IllegalUseOfScopeReplacer.__unicode__"""
    e = IllegalUseOfScopeReplacer("object_name", "original message",
                                  "original extra data")
    # Due to the use of gettext(), the message and extra data cannot be given
    # at instantiation, but they can be modified afterwards.
    e._fmt = ("IllegalUseOfScopeReplacer object %(name)r was used incorrectly:"
              " %(msg)s%(extra)s")
    e.msg = "translated message"
    e.extra = u"translated extra data"
    assert unicode(e) == u"IllegalUseOfScopeReplacer object 'object_name' was " \
        "used incorrectly: translated message: translated extra data"



# Generated at 2022-06-12 07:39:07.185320
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    pass



# Generated at 2022-06-12 07:39:16.211773
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of ScopeReplacer"""
    _scope = { }
    def _factory(resolve, scope, name):
        return None
    _name = '_name'
    _x = ScopeReplacer(_scope, _factory, _name)
    assert(_x._real_obj is None)
    _attr = '_attr'

    # Call __setattr__ of ScopeReplacer.
    # Result is correct.
    _resolve = _x._resolve
    _x._resolve = lambda : _x
    try:
        _x.__setattr__(_attr, '_value')
    except Exception as e:
        if not isinstance(e, IllegalUseOfScopeReplacer):
            raise

# Generated at 2022-06-12 07:39:24.183183
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    v = IllegalUseOfScopeReplacer(
        name='test',
        msg='test',
        extra='test')
    str(v)
    # If a _fmt would exist in the exception class, it would be formatted.
    v._fmt = "test %(name)s"
    str(v)
    assert IllegalUseOfScopeReplacer('test', 'test', extra="test") == \
           IllegalUseOfScopeReplacer('test', 'test', extra="test")
    assert IllegalUseOfScopeReplacer('test', 'test') != \
           IllegalUseOfScopeReplacer('test', 'test', extra="test")



# Generated at 2022-06-12 07:39:30.087336
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    obj = IllegalUseOfScopeReplacer('my_name', 'my_msg', 'extra')
    assert isinstance(obj.__unicode__(), unicode)
    obj = IllegalUseOfScopeReplacer('my_name', 'my_msg')
    assert isinstance(obj.__unicode__(), unicode)

# Generated at 2022-06-12 07:39:34.277340
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Ensure we can generate a good error string"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    result = str(e)
    # f9a268b8f0bba7f5b5e08c5b5d5f5f7b
    # 8ec99ad1a8e33b067280f2e1b614dbb2
    expected = "ScopeReplacer object 'name' was used incorrectly: msg"
    eq = (result == expected)

# Generated at 2022-06-12 07:39:35.904275
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    msg = 'this is a test exception'
    e = IllegalUseOfScopeReplacer(msg)
    assert str(e) == msg


# Generated at 2022-06-12 07:39:42.553277
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ gives a user-friendly string."""
    e = IllegalUseOfScopeReplacer(
        'name', 'msg', extra='extra')
    # Note that the value of e.extra contains the extra ": "
    # and that extra itself contains the extra ": ".
    u_expected = u"ScopeReplacer object 'name' was used incorrectly: msg: extra"
    u = unicode(e)
    u_expected == u



# Generated at 2022-06-12 07:39:47.023896
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object, not a unicode object"""
    e = IllegalUseOfScopeReplacer('obj', 'msg', 'extra')
    s = str(e)
    u = unicode(e)
    assert isinstance(s, str)
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:40:22.231094
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import (
        lazy_import,
        )
    from bzrlib.tests import TestSkipped
    from bzrlib.tests.test_lazy_import import TestLazyImport

    try:
        # To test the call method is working we're going to check
        # the class generated is TestLazyImport, we are doing this
        # by using a scope that is not the scope of the TestLazyImport
        # class
        scope = {}
        lazy_import(scope, '''
        from bzrlib.tests.test_lazy_import import TestLazyImport
        ''')
        cls = scope['TestLazyImport']
    except TestSkipped as e:
        raise TestSkipped('Unable to import TestLazyImport: ' + str(e))
    # Check class is a

# Generated at 2022-06-12 07:40:29.389569
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    def factory(self, scope, name):
        # If a factory returns the ScopeReplacer without setting self._real_obj
        # it will trigger an error
        return self
    name = "my_name"
    sr = _mod_lazy_import.ScopeReplacer(scope, factory, name)
    # invoking __setattr__ on the ScopeReplacer before _real_obj is set
    # should not raise exceptions
    sr.__setattr__("foo", "bar")



# Generated at 2022-06-12 07:40:38.999086
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    sep = '\n' + ' ' * 78
    class DummyModule(object):
        """a dummy module for testing"""
    module = DummyModule()
    def check_str(module, **kwargs):
        err = IllegalUseOfScopeReplacer(module, **kwargs)
        expected = '''Module %r has not yet been loaded.''' % (module,)
        if 'extra' in kwargs:
            expected += sep + 'extra=' + repr(kwargs['extra'])
        if 'msg' in kwargs:
            expected += sep + 'msg=' + repr(kwargs['msg'])
        s = err.__str__()

# Generated at 2022-06-12 07:40:42.215601
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer."""
    import doctest
    doctest.run_docstring_examples(
        IllegalUseOfScopeReplacer.__str__, globals())


# Generated at 2022-06-12 07:40:43.633508
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():

    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    assert str(e1) == 'bar', str(e1)



# Generated at 2022-06-12 07:40:47.528137
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() formats Exception.

    This is a manual test, because a unit test doesn't catch the UnicodeError.
    """
    try:
        raise IllegalUseOfScopeReplacer(
            None, 'IllegalUseOfScopeReplacer.',
            extra='A unicode string: \xe0\x80\x80')
    except Exception as e:
        u = unicode(e)



# Generated at 2022-06-12 07:40:53.260979
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    global sys
    def mycallable(*args, **kwargs):
        return args, kwargs
    import sys
    global sys
    test = ScopeReplacer(sys.modules, mycallable, 'test')
    test.__class__
    assert test(1, 2, 3, test=5) == ((1, 2, 3), {'test':5})



# Generated at 2022-06-12 07:40:58.146910
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer"""
    # TODO: Implement this test
    raise NotImplementedError('test not implemented')

    def test_suite():
        """Return the test suite for this module"""
        import unittest
        suite = unittest.TestSuite()
        suite.addTest(unittest.TestLoader().loadTestsFromName(__name__))
        return suite



# Generated at 2022-06-12 07:41:03.054891
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer class: __str__ method"""
    e = IllegalUseOfScopeReplacer('myname', 'mymsg')
    assert str(e) == 'IllegalUseOfScopeReplacer(myname): mymsg', \
        "__str__() returns unexpected result: %r" % str(e)



# Generated at 2022-06-12 07:41:04.778151
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # tested via test_ScopeReplacer__resolve



# Generated at 2022-06-12 07:41:38.792259
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    # NOTE: These tests only work if ScopeReplacer is for some reason
    #       left in the module, so that it does not replace itself
    #       before being used.
    class Foo(object):
        pass
    class Other(object):
        pass
    class TestScopeReplacer(TestCase):
        def setUp(self):
            super(TestScopeReplacer, self).setUp()
            # Prepare objects
            self.scope = {}
            self.replacer = ScopeReplacer(self.scope, lambda self, scope, name: Foo(), 'myobj')
            self.other = Other()
            self.other.other = True
            # Make sure that __setattr__ on a ScopeReplacer instance returns
            # correctly

# Generated at 2022-06-12 07:41:41.292636
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # this is here for coverage
    e = IllegalUseOfScopeReplacer(u'lala', u'lala')
    print(str(e))

# Generated at 2022-06-12 07:41:45.481271
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should always return a unicode string."""
    i = IllegalUseOfScopeReplacer('name', 'msg')
    u = i.__str__()
    assert isinstance(u, unicode), "__str__ should return unicode."



# Generated at 2022-06-12 07:41:48.576910
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ must return a str."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == (u'IllegalUseOfScopeReplacer object %(name)r was used '
                 'incorrectly: %(msg)s%(extra)s')

# Generated at 2022-06-12 07:41:57.555554
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    _SCOPED_METHOD = object()
    class _SCOPED_CLASS(object):
        def _SCOPED_METHOD(self, *args, **kwargs):
            return (self, args, kwargs)
    _SCOPED_OBJ = _SCOPED_CLASS()
    def _SCOPED_FUNC(*args, **kwargs):
        return (None, args, kwargs)

    def _SCOPE_FACTORY(replacer, scope, name):
        if name == '_SCOPED_METHOD':
            return _SCOPED_METHOD
        elif name == '_SCOPED_CLASS':
            return _SCOPED_CLASS
        elif name == '_SCOPED_OBJ':
            return _SCOPED_OBJ

# Generated at 2022-06-12 07:42:01.186290
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'extra')
    u = unicode(e)
    # Code should not produce UnicodeDecodeErrors
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:42:08.079798
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # No modules loaded via the lazy import mechanism, so 'import x' should
    # work just fine.
    try:
        import x
    except ImportError:
        pass
    else:
        raise AssertionError("Should not have been able to import 'x'")
    def _factory(self, scope, name):
        return x
lazy_import_fake_scope = {}
x = ScopeReplacer(lazy_import_fake_scope, _factory, 'x')
# Check that an exception is raised when trying to assign to the newly
# fake-loaded module.

# Generated at 2022-06-12 07:42:19.560827
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    # check that ScopeReplacer doesn't override __setattr__ of an object
    class SomeClass():
        def __init__(self):
            self.a = 1
    def factory(self, scope, name):
        return SomeClass()
    def callback(lazy):
        # override the _should_proxy flag to prevent races with other threads
        lazy._should_proxy = False
        # trigger the ScopeReplacer initialisation.
        lazy.a
        return lazy
    # Find out if sys.modules already has bzrlib_lazy_import_test_module
    sys_modules = sys.modules

# Generated at 2022-06-12 07:42:24.569072
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    
    def test_func():
        a = ScopeReplacer(sys.modules, lambda self, scope, name: scope[name], 'bzrlib')
        return a
    lazy_import(globals(), 'bzrlib')
    a = test_func()
    expected_result = bzrlib
    assert isinstance(a, ScopeReplacer)
    assert a == expected_result, "Expected %s, got %s" % (expected_result, a)

# Generated at 2022-06-12 07:42:35.665296
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class MyException(Exception):

        def __init__(self, message, important_thing):
            Exception.__init__(self, message)
            self.important_thing = important_thing

    name = "foo"
    scope = {}
    real_obj = object()

    def factory(self, scope, name):
        return real_obj

    replacer = ScopeReplacer(scope, factory, name)
    # Check that the replacer can be accessed.
    # Also checks that ScopeReplacer._resolve() isn't called when calling
    # __getattribute__
    assert replacer is scope[name], "replacer should be available in scope"
    assert replacer is not real_obj, "replacer should not be real_obj"