

# Generated at 2022-06-12 07:34:00.422619
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method IllegalUseOfScopeReplacer.__unicode__."""
    import sys
    # Create the exception
    e = IllegalUseOfScopeReplacer(name='illegal_use', msg='illegal_use')
    if sys.version_info[0] < 3:
        # Python 2.x
        # Intercept builtin unicode
        __builtin__.unicode = str
        # Get __unicode__ -- returns a str
        u = e.__unicode__()
        # Reinstate builtin unicode
        __builtin__.unicode = unicode
        # Get __str__ -- returns a str
        s = e.__str__()
    else:
        # Python 3.x
        # Get __str__ -- returns a str
        s = e.__str__()
        # Get __unicode__ -- returns a str

# Generated at 2022-06-12 07:34:09.179302
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    doctest.run_docstring_examples(
        IllegalUseOfScopeReplacer.__str__, globals())

    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar')
    except IllegalUseOfScopeReplacer as e:
        s = str(e)
    assert s == ("ScopeReplacer object 'foo' was used incorrectly: bar")

    class Foo(Exception):
        def __str__(self):
            return '<Foo>'

    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar', extra=Foo())
    except IllegalUseOfScopeReplacer as e:
        s = str(e)
    assert s == ("ScopeReplacer object 'foo' was used incorrectly: bar: "
                 "<Foo>")
        # This is the error message for Python 2.

# Generated at 2022-06-12 07:34:14.595198
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Show that __str__ works:
    class A(IllegalUseOfScopeReplacer):
        pass

    a = A(1, 2, 3)
    u = unicode(a)
    s = str(a)
    assert type(u) is unicode
    assert type(s) is str
    assert u is not s
    assert u == s



# Generated at 2022-06-12 07:34:20.211906
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ makes unicode strings"""
    class UnicodeSub(IllegalUseOfScopeReplacer):
        _fmt = 'ascii with %(name)s and %(msg)s'
    exc = UnicodeSub("a", "b")
    if not isinstance(exc.__unicode__(), unicode):
        raise AssertionError("__unicode__ did not return unicode")



# Generated at 2022-06-12 07:34:28.441616
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    import bzrlib.branch
    lazy_import(globals(), '''
    import bzrlib.branch
    ''')
    class _Dummy: pass
    a = _Dummy()
    a.b = 'test'
    def null(a, b, c):
        a.b = 'test'
        return a.b
    a = ScopeReplacer(globals(), null, 'a')
    assert a.b == 'test'
    a(a, 1, 2)
    assert a.b == 'test'
    x = bzrlib.branch
    assert x is a
    assert bzrlib.branch is x



# Generated at 2022-06-12 07:34:35.220720
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    o = ScopeReplacer({}, lambda self, scope, name: self, 'dummy')
    o.blah = 'blah'
    o.blah2 = 'blah'
    o.blah = 'blah'
    o.dummy = {}
    o.dummy['blah'] = 'blah'
    o.dummy['blah2'] = 'blah'
    o.dummy['blah'] = 'blah'


# Generated at 2022-06-12 07:34:40.501247
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer.

    Test if __str__ handles all kinds of errors for formatting the string,
    like KeyErrors or TypeErrors.
    """
    e = IllegalUseOfScopeReplacer("obj", "msg")
    # Setting fmt to None, gives a KeyError
    e._fmt = None
    str(e)
    # Setting fmt to a non-string object gives a TypeError
    e._fmt = object()
    e.extra = 'arg'
    str(e)



# Generated at 2022-06-12 07:34:48.927930
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('a name', 'a message', 'extra')
    # The following make sure that __str__() returns a str() object.
    # This is important because __str__() should be able to be passed to
    # things like ''.join() or '%s'.
    if isinstance(e, unicode):
        raise AssertionError('%r should return unicode' % (e,))
    if isinstance(str(e), unicode):
        raise AssertionError('%r should return str' % (str(e),))



# Generated at 2022-06-12 07:34:52.039279
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('test', 'testing')
    assert str(e) == "test: testing"



# Generated at 2022-06-12 07:34:55.396077
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test method __str__ of class IllegalUseOfScopeReplacer"""
    # No test for an exception without arguments
    # No test for an exception with arguments
    # No test for an exception with a preformatted string
    pass # no test



# Generated at 2022-06-12 07:35:17.394175
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import traceback
    from cStringIO import StringIO
    buf = StringIO()
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "%(msg)s"

# Generated at 2022-06-12 07:35:28.686760
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    local_var = object()
    def get_local():
        return local_var

    class Dummy(object):
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return "<%s %r>" % (self.__class__.__name__, self.name)
        def __eq__(self, other):
            return self.__class__ is other.__class__ and \
                self.name == other.name
        def __ne__(self, other):
            return not self.__eq__(other)

    class DummyScopeReplacer(ScopeReplacer):
        def _resolve(self):
            return Dummy(self._name)


# Generated at 2022-06-12 07:35:40.585536
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test_ScopeReplacer___call__()
    # Unit test for method __call__ of class ScopeReplacer
    import bzrlib._lazy_import
    reload(bzrlib._lazy_import)
    from bzrlib._lazy_import import ScopeReplacer
    global test_var
    def test_callable(replacer, scope, name):
        # test_callable()
        # Unit test for method __call__ of class ScopeReplacer
        # A callable used by the unit test.
        return 'expected'
    global_dict = globals()
    replacer = ScopeReplacer(global_dict, test_callable, 'test_var')
    replacer() # trigger replacement
    # Check that calling the replacer returns the expected object.
    expected = 'expected'
    result = replacer()


# Generated at 2022-06-12 07:35:43.592307
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    unicode(e)



# Generated at 2022-06-12 07:35:50.988822
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    import bzrlib.branch
    import bzrlib.lazy_import
    import bzrlib.workingtree
    prv_branch = bzrlib.branch
    prv_workingtree = bzrlib.workingtree
    # The following lines are just used to generate the callgraph test
    # coverage.
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    prv_workingtree.WorkingTree.uncommit()
    bzrlib.branch.Branch.last_revision_info()
    prv_branch.Branch.last_revision_info()
    bzrlib.WorkingTree3()
    prv_workingtree.WorkingTree3()
    fake

# Generated at 2022-06-12 07:35:54.769285
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class C(object):
        def __init__(self, x):
            self._x = x
    c = C(1)
    c.__setattr__('_x', 3)
    assert c._x == 3



# Generated at 2022-06-12 07:36:03.540901
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('foo.bar',
                                  'Baz is not yet imported.',
                                  "Baz is lark's." )

# Generated at 2022-06-12 07:36:14.091135
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__(self, name, value)
    # test the cases:
    #
    # 1 - attribute is a slot attribute
    # 2 - attribute is an internal attribute
    # 3 - attribute is a public attribute
    #
    # test setting attributes on object and on proxy object

    class Foo(object):
        __slots__ = 'a'

        def __init__(self, a):
            self.a = a

        def get_a(self):
            return self.a

    class LazyFoo(ScopeReplacer):
        def _create(self, scope, name):
            return Foo(10)

    global_scope = globals()
    object_name = 'lazy_foo'

    lazy_foo = LazyFoo(global_scope, LazyFoo._create, object_name)
    #

# Generated at 2022-06-12 07:36:22.569758
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase
    import bzrlib
    bzrlib._unicode_encoding = 'utf-8'

# Generated at 2022-06-12 07:36:24.586232
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # This test is pretty much impossible to write accurately
    pass

    # TODO(jelmer): The test above is missing, and a better one would be
    # good to write.



# Generated at 2022-06-12 07:36:42.367883
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should always return a str, not a unicode"""

    # Verify there are no code paths that return a unicode string.
    import sys, cStringIO
    orig_stdout = sys.stdout

# Generated at 2022-06-12 07:36:51.337714
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    class Foo(IllegalUseOfScopeReplacer):
        pass

    a = Foo('one', 'two', 'three')
    b = Foo('one', 'two', 'three')
    assert a == b
    a = Foo('one', 'two', 'three')
    b = Foo('one', 'two', 'XX')
    assert a != b
    # This test is more of a check - we expect it to return a unicode object,
    # but we can't test it in the normal way.
    assert isinstance(unicode(a), unicode)

# Generated at 2022-06-12 07:36:59.200304
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class Foo(object):
        def __call__(self, *args, **kwargs):
            return 'Foo.__call__(%r)' % args
    f = Foo()
    # Create a scope replacer for the Foo object, which should behave
    # the same way as Foo.
    scope = {}
    sr = ScopeReplacer(scope, lambda self, scope, name: f, 'f')
    # Check that sr behaves the same way as f
    def f_identity(x):
        return f(x)
    def sr_identity(x):
        return sr(x)
    assert f_identity(3) == 'Foo.__call__((3,))'
    assert sr_identity(3) == 'Foo.__call__((3,))'
    sr = scope['f']

# Generated at 2022-06-12 07:37:06.172448
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    from bzrlib.lazy_import import lazy_import, ScopeReplacer

    try:
        # Make sure the test environment is pristine
        reload(sys.modules['lazy_import_test_obj'])
    except KeyError:
        import lazy_import_test_obj
        sys.modules['lazy_import_test_obj'] = lazy_import_test_obj

    # Disable proxying to cause use-after-replacement to raise
    ScopeReplacer._should_proxy = False

    # Import a function from a module that is not imported until used.
    # Check we can use the function without a problem.
    lazy_import(globals(), """
    from lazy_import_test_obj import foo
    """)


# Generated at 2022-06-12 07:37:11.644149
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    from bzrlib.i18n import gettext
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    s = gettext(unicode(e))
    assert isinstance(s, unicode)
# end unit test for method __unicode__ of class IllegalUseOfScopeReplacer


# Generated at 2022-06-12 07:37:21.595931
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return unicode."""
    from bzrlib.tests import TestCase
    class UnicodeSubclass(IllegalUseOfScopeReplacer):
        # This is a copy of _fmt from IllegalUseOfScopeReplacer
        _fmt = ("ScopeReplacer object %(name)r was used incorrectly:"
                " %(msg)s%(extra)s")
    u = u'unicode-\xf3\xa9'
    latin1 = 'latin1-\xf3\xc9'
    # testing str instances is tricky because str is a subtype of unicode.
    ex = UnicodeSubclass(u, u, latin1)
    self.assertIsInstance(str(ex), str)
    self.assertIsInstance(unicode(ex), unicode)



# Generated at 2022-06-12 07:37:32.258887
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    import gc

    class FooBar:
        def __init__(self):
            self.zap = 1
    class BazQuux(FooBar):
        pass
    lazy_import.lazy_import(globals(), "_baz_quux", "bzrlib.tests.lazy_import:BazQuux")
    ScopeReplacer._should_proxy = False
    try:
        baz_quux = _baz_quux
        raise TestNotApplicable("baz_quux was already replaced.")
    except IllegalUseOfScopeReplacer:
        pass
    # Set an attribute
    baz_quux.zap = 4
    del _baz_quux
    gc.collect()

# Generated at 2022-06-12 07:37:41.743581
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():

    # Assert that if the _factory method of an instance of class ScopeReplacer
    # returns another instance of class ScopeReplacer, a
    # IllegalUseOfScopeReplacer will be raised.
    global _unused_a
    def _factory(self, scope, name):
        global _unused_a
        _unused_a = self
        return self

# Generated at 2022-06-12 07:37:53.322509
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test the __setattr__ method of the ScopeReplacer class."""
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    import bzrlib
    scope = {}
    scope['bzrlib'] = bzrlib
    lazy_import(scope, '''
    import bzrlib
    ''')
    # The code above should create a ScopeReplacer object in scope['bzrlib'].
    assert isinstance(scope['bzrlib'], ScopeReplacer)
    # The code below should assign attributes to that ScopeReplacer object.
    scope['bzrlib'].__setattr__('foo', 'bar')
    scope['bzrlib'].foo = 'baz'
    scope['bzrlib'].foo = scope['bzrlib'].foo


# Generated at 2022-06-12 07:37:54.104570
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass # tested in other unit tests

# Generated at 2022-06-12 07:38:04.622008
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # __str__() must return a str object
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-12 07:38:07.123252
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-12 07:38:08.993336
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = ScopeReplacer(None, None, None)
    obj.__call__()



# Generated at 2022-06-12 07:38:18.304542
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method IllegalUseOfScopeReplacer.__str__"""
    # The following code is generated by the following snippet:
    # >>> generate_IllegalUseOfScopeReplacer_test_cases()
    # The difference is that the formatting is made in the test function,
    # not in the class.  This is because the formatting strings are
    # preferences-dependent, and as such need to be generated each time the
    # test is run.
    class DummyClass(object):
        """Dummy class to test exception"""
        def __init__(self, **kwargs):
            pass

    def _test_case(name, msg, extra=None):
        if extra is not None:
            if isinstance(extra, dict):
                args = extra['args']
                kwargs = extra['kwargs']
                extra = DummyClass

# Generated at 2022-06-12 07:38:28.789527
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ works.

    The method returns a unicode string. If the format string is a unicode string
    it is used directly. Else it is decoded using the default encoding. If the
    decoded string is not a unicode object another decode is attempted with the
    default encoding. Lastly if the function can't make a unicode object it
    returns a unicode object of the string returned by str() of the exception.
    """
    # only use format strings that can be decoded with the default encoding
    e1 = IllegalUseOfScopeReplacer('foo','does not exist',
                                   extra='XYZ')
    # unicode format string
    e2 = IllegalUseOfScopeReplacer(u'foo',u'does not exist',
                                   extra=u'XYZ')
    # not unicode format string


# Generated at 2022-06-12 07:38:34.523985
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('a', 'b', extra='c')
    if e._format() != 'IllegalUseOfScopeReplacer object a was used incorrectly: b: c':
        raise AssertionError('format was %r' % e._format())


# Generated at 2022-06-12 07:38:39.245120
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method IllegalUseOfScopeReplacer.__unicode__."""
    # Just check that we don't have a stack overflow, no need to check the
    # exception content.

# Generated at 2022-06-12 07:38:44.110999
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import as _mod_lazy_import
    tests = [
        ('bzrlib.lazy_import', (
                ('ScopeReplacer', _mod_lazy_import.ScopeReplacer),
               )
        ),
        ]
    return tests

# Generated at 2022-06-12 07:38:51.798812
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer"""
    from bzrlib.lazy_import import lazy_import
    lazy_import(locals(), '''
    from bzrlib import (
        branch,
        )
    ''')
    branch  # make this import not be unused
    actual_obj = branch
    # Test that the actual object is returned by __call__.
    assert ScopeReplacer.__call__(ScopeReplacer(locals(),
        lambda self, scope, name: branch, 'branch')) is actual_obj



# Generated at 2022-06-12 07:39:03.651449
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    def _make_scope():
        scope = dict()
        scope['bzrlib'] = bzrlib
        scope['lazy_import'] = lazy_import
        return scope
    scope = _make_scope()
    from bzrlib.lazy_import import (
        lazy_import,
        lazy_class,
        lazy_module,
        )
    def _make_fake_bzrlib(scope, name):
        mod = object()
        scope[name] = mod
        return mod
    scope['bzrlib'] = ScopeReplacer(scope, _make_fake_bzrlib, 'bzrlib')

# Generated at 2022-06-12 07:39:40.060507
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class FakeBranch(object):
        def __init__(self, *args, **kwargs):
            self.called = args
            self.called_kwargs = kwargs
        def __setattr__(self, attr, value):
            object.__setattr__(self, attr, value)
    scope = {}
    def branch_factory(*args):
        return FakeBranch(*args)
    sr = ScopeReplacer(scope, branch_factory, 'branch')
    # call method __setattr__ of class ScopeReplacer
    sr.__setattr__('foo', 'bar')
    # call method __getattribute__ of class ScopeReplacer
    real_branch = sr.__getattribute__('_real_obj')
    test_branch = scope['branch']
    # verify that method __setattr

# Generated at 2022-06-12 07:39:50.426285
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__ of class ScopeReplacer
    # calling object
    import bzrlib.testing.test__fake_mod as test__fake_mod
    def __init__(self, scope, factory, name):
        self._scope = scope
        self._factory = factory
        self._name = name
        self._real_obj = None
        scope[name] = self
    ScopeReplacer.__init__ = __init__
    def _resolve(self):
        name = self._name
        real_obj = self._real_obj
        if real_obj is None:
            factory = self._factory
            scope = self._scope
            obj = factory(self, scope, name)

# Generated at 2022-06-12 07:39:54.104856
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test for 'IllegalUseOfScopeReplacer.__str__' class."""
    # prepare mocks
    sr = IllegalUseOfScopeReplacer('name','msg','extra')

    # run unit-test
    actualResult = str(sr)


# Generated at 2022-06-12 07:39:58.158246
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ returns a str"""
    err = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(err)
    assert type(s) is str, "%r is not a str" % (s,)

# Generated at 2022-06-12 07:40:06.446240
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should always return a str object, not unicode."""
    # Setup error message
    e = IllegalUseOfScopeReplacer("foo", "bar")

    # Test __str__ when unicode(s) works.
    # In this case, it must return unicode
    class unicode_utf8:
        # Pretend to be unicode
        def __str__(self):
            return unicode("str\xc3")
        def __repr__(self):
            return '<unicode_utf8>'
    e.extra = unicode_utf8()
    s = str(e)
    if not isinstance(s, str):
        raise AssertionError(
            '__str__ must return a str not %r (instance of %s)'
            % (s, type(s)))

    # Test __

# Generated at 2022-06-12 07:40:16.329514
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            class Foo(object):
                def __call__(self):
                    return 1
            saved_globals = {
                'Foo': Foo,
                'scope_replacer': ScopeReplacer,
                }

# Generated at 2022-06-12 07:40:18.629633
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test method ScopeReplacer.__setattr__ of class ScopeReplacer
    """
    # XXX: Test disabled due to lack of implementation
    pass

# Generated at 2022-06-12 07:40:25.068585
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase

    class MockScopeReplacer(ScopeReplacer):
        """A mock scope replacer that doesn't need a scope."""

        def __init__(self):
            self.__dict__['_scope'] = {}
            self.__dict__['_factory'] = lambda self, scope, name: self
            self.__dict__['_name'] = 'b'
            self.__dict__['_real_obj'] = None

    class TestScopeReplacer(TestCase):

        def test_setattr_with_proxy(self):
            # If a class has a setattr method, that setattr is called. If the
            # class allows proxying (the default) then ScopeReplacer
            # allows members to be set.
            ScopeReplacer._should_proxy = True
            r = MockScopeRepl

# Generated at 2022-06-12 07:40:35.766889
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method IllegalUseOfScopeReplacer.__str__

    Testing for UnicodeEncodeError is a bit tricky because different Python
    versions behave differently. The easiest way seems to be to raise an
    exception that fails to convert to a unicode string.

    Python 2.4 and 2.5 should raise a UnicodeEncodeError. It's not clear
    what 2.6 will do.
    """
    # raise UnicodeError to force a UnicodeEncodeError
    class UnicodeError(Exception):
        def __unicode__(self):
            raise UnicodeError()

    try:
        raise IllegalUseOfScopeReplacer(
            'name',
            'msg',
            extra=UnicodeError())
    except IllegalUseOfScopeReplacer as exc:
        # should not raise UnicodeEncodeError
        str(exc)


_lazy_imports

# Generated at 2022-06-12 07:40:40.116927
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """If this will not raise an exception, all is well."""
    class TestException(IllegalUseOfScopeReplacer):
        _fmt = "This is a %(name)s%(extra)s"
    exc = TestException("name", "", None)
    unicode(exc)
    exc = TestException("name", "", "extra")
    unicode(exc)



# Generated at 2022-06-12 07:40:58.801839
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This test is a little bit silly, everyone would think that calling the
    unicode() function on the object would be enough to test this method. But
    it's not, since in python2 the unicode() function calls __str__ on the
    object.
    """
    msg = u'exceptions should always be unicode strings'
    e = IllegalUseOfScopeReplacer('base', msg)
    # The __unicode__ method should always return unicode objects.
    assert isinstance(unicode(e), unicode)
    # Check the message is actually the one set
    assert unicode(e) == msg



# Generated at 2022-06-12 07:41:10.037037
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda x,y,z: None, 'name')
    assert scope_replacer._scope == scope, scope_replacer._scope
    assert scope_replacer._factory == (lambda x,y,z: None), scope_replacer._factory
    assert scope_replacer._name == 'name', scope_replacer._name
    assert scope_replacer._real_obj == None, scope_replacer._real_obj
    obj = object.__getattribute__(scope_replacer, '__getattribute__')
    assert obj.__class__ == object.__getattribute__.__class__, (obj.__class__, object.__getattribute__.__class__)

# Generated at 2022-06-12 07:41:20.894716
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # The function __setattr__() is a method of class ScopeReplacer.
    from bzrlib.lazy_import import (
        ScopeReplacer,
        )
    from bzrlib.tests.test_lazy_import import (
        make_ScopeReplacer,
        )
    x = make_ScopeReplacer('x', lambda self, scope, name: self)
    y = make_ScopeReplacer('y', lambda self, scope, name: self)
    try:
        x.a = 7
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Did not detect illegal use of'
            ' x.__setattr__()')
    x.b = 8
    Element = y.ElementTree.Element

# Generated at 2022-06-12 07:41:24.768156
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a utf-8 string."""
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    assert isinstance(unicode(e), unicode)

# Generated at 2022-06-12 07:41:31.720326
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(locals(), '''
from bzrlib import (
    errors,
    osutils,
    branch,
    )
import bzrlib.branch
''')
    errors.BzrError(branch.Branch.open.__doc__)
    osutils.abspath(None)
    return locals()

# Generated at 2022-06-12 07:41:39.080231
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    def _make_ScopeReplacer():
        ScopeReplacer._should_proxy = True
        try:
            return ScopeReplacer(globals(), _importer, 'bzrlib')
        finally:
            ScopeReplacer._should_proxy = False
    def _importer(self, scope, name):
        if name == 'bzrlib':
            return bzrlib
    bzrlib = _make_ScopeReplacer()
    import bzrlib.hooks
    # The following should pass, under the condition that the __setattr__ of
    # ScopeReplacer is unit tested, otherwise it will fail on setattr.
    bzrlib.hooks.install_lazy_named_hook('foo', 'bar', 'junk')



# Generated at 2022-06-12 07:41:48.048198
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests.test_i18n import TranslationTestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestString(TranslationTestCase):
        def test_str(self):
            e = IllegalUseOfScopeReplacer('a', 'msg')
            self.assertEqual('msg', str(e))
            self.assertEqual('msg', unicode(e))

    from bzrlib.tests import TestUtil
    TestUtil.build_test_suite(
        [TestString],
        ).run(TestUtil.unittest_main)



# Generated at 2022-06-12 07:41:57.422653
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    # IllegalUseOfScopeReplacer inherits from Exception
    s = IllegalUseOfScopeReplacer("name", "msg", "extra")
    assert s.name == "name"
    assert s.msg == "msg"
    assert s.extra == "extra"

    assert unicode(s) == u'ScopeReplacer object name was used incorrectly: msg'
    assert str(s) == 'ScopeReplacer object name was used incorrectly: msg'

    from bzrlib.i18n import gettext
    s._fmt = '''ScopeReplacer object %(name)r was used incorrectly: %(msg)s'''
    gettext('')
    assert unicode(s) == u'ScopeReplacer object name was used incorrectly: msg'
    assert str(s)

# Generated at 2022-06-12 07:42:00.484205
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def f(s, sc, n):
        def f2(s, sc, n):
            return 3
        return ScopeReplacer(sc, f2, n)
    s = ScopeReplacer({}, f, 'f')
    assert s() == 3



# Generated at 2022-06-12 07:42:02.025041
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = object
    t = obj.__setattr__
    t(obj, '', None)


# Generated at 2022-06-12 07:42:20.827342
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Really this is more a test of _format()
    class TestIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        _fmt = "Error: %(msg)s"
    sr = TestIllegalUseOfScopeReplacer("xx", "abc")
    s = str(sr)
    assert s == "Error: abc"
    sr.foo = "bar"
    sr._preformatted_string = "foo bar"
    s = str(sr)
    assert s == "foo bar"



# Generated at 2022-06-12 07:42:30.174611
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    class Foo(ScopeReplacer):
        def __init__(self, scope, name):
            class test_ScopeReplacer___call___F(object):
                pass
            self.scope = scope
            self.name = name
            self.obj = test_ScopeReplacer___call___F()
            object.__setattr__(self, '_factory', self.get_factory)
            scope[self.name] = self
        class _Replacer(object):
            def __init__(self, name):
                self.name = name
            def __call__(self):
                return self.name
            test_ScopeReplacer___call___F = _Replacer('f')
        def get_factory(self, scope, name):
            return self

# Generated at 2022-06-12 07:42:36.626955
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    str(e)
    str(e) # repeated call should not fail
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'fud')
    str(e)
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    e._preformatted_string = 'baz'
    str(e)



# Generated at 2022-06-12 07:42:44.490593
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__()"""
    import bzrlib.errors as _mod_errors
    # This is a bad way to create an exception, but so is the example code
    # in the docstring.
    except_obj = _mod_errors.IllegalUseOfScopeReplacer('name',
                                                        'msg', 'extra')
    str_obj = str(except_obj)
    # The string doesn't have to look exactly like this, but it is a
    # representative example.
    assert str_obj == ("IllegalUseOfScopeReplacer('name', 'msg', 'extra')")



# Generated at 2022-06-12 07:42:50.071495
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), """
    import bzrlib.ui
    """)
    obj = bzrlib.ui.ui_factory.initialize('.')
    obj.frobnicator = None

# Generated at 2022-06-12 07:42:54.509334
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from testtools import TestCase
    class test_ScopeReplacer___call__(TestCase):
        def test__resolve_called(self):
            done = []
            def _resolve(self):
                done.append(1)
                return 1
            class Ob:
                _resolve = _resolve
            o = Ob()
            self.assertEqual(1, o())
            self.assertEqual(1, len(done))
# end test_ScopeReplacer___call__

    return test_ScopeReplacer___call__



# Generated at 2022-06-12 07:42:58.018351
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test method __getattribute__ of class ScopeReplacer"""
    import doctest
    doctest.run_docstring_examples(ScopeReplacer.__getattribute__.im_func, globals())

# Generated at 2022-06-12 07:43:00.302101
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.blackbox # imports osutils.
    return bzrlib.tests.blackbox.test_suite()



# Generated at 2022-06-12 07:43:08.265069
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    class_ = IllegalUseOfScopeReplacer
    import copy
    forbidden_attributes = set(['_preformatted_string', '_fmt'])
    forbidden_keys = set(['name', 'msg', 'extra'])
    # classes should not define __unicode__() or __str__() methods
    for meth_name in ['__unicode__', '__str__']:
        if meth_name in class_.__dict__:
            raise AssertionError('class %s must not define method %s, use'
                                 ' method %s instead.'
                                 % (class_.__name__, meth_name,
                                    '_get_format_string'))
    # classes should not inherit from a class with a __unicode__() method

# Generated at 2022-06-12 07:43:16.250770
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    from bzrlib import lazy_import
    import bzrlib.lazy_import

    scope, module_name, name = (globals(), 'bzrlib', 'lazy_import')
    bzrlib.lazy_import = 'not a real module'
    replacer = lazy_import.ScopeReplacer(scope, name)
    error = replacer.illegal_use('not a module', 'testing')
    try:
        str(error)
    finally:
        replacer.restore()

