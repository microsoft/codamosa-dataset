

# Generated at 2022-06-12 07:33:56.016502
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        osutils,
        )
    ''')
    _expected_rename_errors = {'win32': ['Access is denied',
                                              'The process cannot access the file because it is being used by another process'],
                                   'posix': ['Permission denied',
                                             'Is a directory',
                                             'File exists',
                                             'No such file or directory']}
    def assertRaisesEnvironmentError(func, env_error, *args, **kwargs):
        import sys
        if sys.platform == 'win32':
            import errno
            error_codes = [errno.EACCES, errno.EEXIST]

# Generated at 2022-06-12 07:34:06.557572
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Imports
    from bzrlib.lazy_import import lazy_import
    # Declaration of variables and objects
    scope = {}
    name = 'test'
    # Definition of functions
    def factory(self, scope, name):
        return TestReplacer()
    # Creation of objects
    rep = ScopeReplacer(scope = scope, factory = factory, name = name)
    # Definition of functions
    def func2(self):
        return 'func2'
    # Definition of classes
    class TestReplacer(object):
        def func1(self):
            return 'func1'
        func2 = func2
    # Calling functions
    test_obj = scope['test']
    assert test_obj.func1() == 'func1'
    assert test_obj.func2() == 'func2'



# Generated at 2022-06-12 07:34:18.261548
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from . import lazy_import
    lazy_import(globals(), '''
import sys
''')
    def _factory(replacer, scope, name):
        scope[name] = 3
    sr = ScopeReplacer(sys.modules, _factory, 'test')
    # Unit test: __call__(self, *args, **kwargs)
    eq = assert_equal
    eq(sr.__call__(), 3)
    eq(sr(), 3)
    # other signatures:
    def _factory2(replacer, scope, name):
        scope[name] = lambda a,b: a*b
    sr = ScopeReplacer(sys.modules, _factory2, 'test2')
    eq(sr(2, 3), 6)
    eq(sr(2), TypeError)



# Generated at 2022-06-12 07:34:27.530544
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    import bzrlib
    def func():
        return 1
    lazy_import(locals(), '''
    from bzrlib.lazy_import import test_ScopeReplacer___setattr__
    ''')

    # quick check

# Generated at 2022-06-12 07:34:33.261927
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    o = ScopeReplacer(None, None, None)
    def f(self, *args, **kwargs):
        return 1
    class Foo(object):
        pass
    Foo.f = f
    object.__setattr__(o, '_real_obj', Foo)
    assert o() == 1


# Generated at 2022-06-12 07:34:44.241105
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test if two exceptions are equal."""
    e1 = IllegalUseOfScopeReplacer(name='lazy',
                                   msg='oops',
                                   extra="badness")
    e2 = IllegalUseOfScopeReplacer(name='lazy',
                                   msg='oops',
                                   extra="badness")
    e3 = IllegalUseOfScopeReplacer(name='not lazy',
                                   msg='oops',
                                   extra="badness")
    e4 = IllegalUseOfScopeReplacer(name='lazy',
                                   msg='oops',
                                   extra="goodness")
    e5 = IllegalUseOfScopeReplacer(name='lazy',
                                   msg='non oops',
                                   extra="badness")
    assert e1 == e2
    assert e1 != e3
    assert e1 != e4

# Generated at 2022-06-12 07:34:55.575196
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for IllegalUseOfScopeReplacer.__unicode__"""
    illegal_use = IllegalUseOfScopeReplacer('abc', 'def')
    expected_text = 'IllegalUseOfScopeReplacer(%s)' % repr('Illegal use of abc: def')
    # We can't compare the repr of an exception with a string because we can't
    # know for sure what the repr of an exception is.
    assert repr(illegal_use) == expected_text, repr(illegal_use)
    assert str(illegal_use) == 'Illegal use of abc: def', str(illegal_use)

# Generated at 2022-06-12 07:35:01.044779
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    import sys
    import __builtin__
    def callable_object(arg1, arg2):
        return arg1+arg2
    obj = lazy_import.ScopeReplacer(globals(), callable_object, 'callable_object')
    result = obj(1, 2)
    assert result == 3
    assert callable_object == obj



# Generated at 2022-06-12 07:35:08.705733
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def a_factory(replacer, scope, name):
        return "Hello %s" % (name,)
    s = {'a': 1} # scope
    a = ScopeReplacer(s, a_factory, 'a')
    # No real object created yet, so this should be identical to
    # the scopeReplacer
    e = "Hello a"
    a.__getattribute__('__getattribute__') # should not raise
    a.__getattribute__('_resolve') # should not raise
    assert a == e



# Generated at 2022-06-12 07:35:14.247928
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    if (hasattr(bzrlib.tests.blackbox.test_lazy_import, 'test_ScopeReplacer___setattr__')):
        bzrlib.tests.blackbox.test_lazy_import.test_ScopeReplacer___setattr__(
            )

# Generated at 2022-06-12 07:35:25.121835
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return an str"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str), "__str__ did not return a str"

# Generated at 2022-06-12 07:35:34.467447
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    locals_ = {}
    globals_ = globals()
    def _test_helper_factory1(scope_replacer, scope, name):
        return bzrlib
    object_ = ScopeReplacer(locals_, _test_helper_factory1, 'bzrlib')
    assert object_.__getattribute__('__name__') == 'bzrlib'
    assert object_.__getattribute__('__doc__') == bzrlib.__doc__
    assert object_.__getattribute__('__version__') == bzrlib.__version__




# Generated at 2022-06-12 07:35:46.070503
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import re
    import sys
    import os
    import time
    import __builtin__

    class TestImportReplacer(ImportReplacer):
        def __init__(self, *args, **kwargs):
            self._instantiated_name = kwargs.pop('name')
            self._instantiated_scope = kwargs.pop('scope')
            self._instantiated_module_path = kwargs.pop('module_path')
            self._instantiated_member = kwargs.pop('member')
            self._instantiated_children = kwargs.pop('children')
            ImportReplacer.__init__(self, *args, **kwargs)

        def _import(self, scope, name):
            self._copy_check('_instantiated_scope', scope, dict)
            self._copy

# Generated at 2022-06-12 07:35:50.813702
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer

    This test is needed because the method __str__ of
    IllegalUseOfScopeReplacer uses %-formatting on a Unicode string,
    which can lead to a UnicodeDecodeError, if the arguments to
    __str__ are not all Unicode strings.
    """
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'additional info')
    assert str(obj) == 'name', str(obj)
    assert str(obj.__dict__) == "{'msg': 'msg', " \
        "'name': 'name', 'extra': ': additional info'}", \
        str(obj.__dict__)
    assert repr(obj) == 'IllegalUseOfScopeReplacer({...})'



# Generated at 2022-06-12 07:35:57.537892
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import test_ScopeReplacer_resolve
    test_ScopeReplacer_resolve()
    class TestObject(object):
        def __call__(self, *args, **kwargs):
            return args, kwargs
    class TestCase(TestCase):
        def setUp(self):
            self.scope = {}
            self.obj = TestObject()
            self.stub = ScopeReplacer(self.scope, lambda x,y,z:self.obj, 'name')
    test = TestCase()
    test.setUp()
    self = test
    #test a call without args
    self.assertEqual(((), {}), self.stub())
    #test a call with 1 positional argument

# Generated at 2022-06-12 07:36:03.939319
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    import doctest
    from bzrlib.lazy_import import (_FakeModule,
        IllegalUseOfScopeReplacer, make_decorator)
    module_lookup = {
        'bzrlib.lazy_import': _FakeModule(
            'bzrlib.lazy_import', __name__, __file__)
        }
    decorator = make_decorator(module_lookup)
    tested_class = decorator(IllegalUseOfScopeReplacer)
    return doctest.DocTestSuite(tested_class)



# Generated at 2022-06-12 07:36:07.368170
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    exc = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(exc)
    assert type(s) is str



# Generated at 2022-06-12 07:36:11.957862
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('e1', 'msg', 'extra')
    s = unicode(e)
    assert isinstance(s, unicode), "%s is not a unicode object" % s



# Generated at 2022-06-12 07:36:21.447570
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer:
    1. If _format() returns a str, it must be decoded.
    2. If _format() returns bytes, it must be converted to str.
    3. If _format() returns a unicode, it must be returned unchanged.
    4. If _format() returns unknown type, it must be converted to unicode.
    """
    import sys
    if sys.version >= '3':
        str_type = 'str'
        bytes_type = 'bytes'
        unicode_type = 'str'
        x = 'abc'
        x.encode('utf8')
    else:
        str_type = 'str'
        bytes_type = 'str'
        unicode_type = 'unicode'
        x = 'abc'

# Generated at 2022-06-12 07:36:28.695706
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class A(object):
        pass

    class B(A):
        pass

    b = B()
    b.C = 'D'
    def test_func(a):
        return a(b, {}, 'C')
    # Test the behavior when _should_proxy is True.
    ScopeReplacer._should_proxy = True
    assert test_func(ScopeReplacer) == 'D'
    # Test the behavior when _should_proxy is False.
    ScopeReplacer._should_proxy = False
    assert test_func(ScopeReplacer) == 'D'
    # Try to do some illegal things.
    def test_func(a):
        return a._resolve()

    class Nasty(object):
        def __getattribute__(self, attr):
            raise Exception("Nastiness" + attr)
    n

# Generated at 2022-06-12 07:36:45.055665
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    class Dummy(Exception):
        _fmt = "Some message"

    # __init__(self, *args, **kwargs)
    e = Dummy()
    u = unicode(e)
    # test.test_exception.test_IllegalUseOfScopeReplacer___unicode__:
    # u == 'Some message\n'
    e = Dummy(u'foo')
    u = unicode(e)
    # test.test_exception.test_IllegalUseOfScopeReplacer___unicode__:
    # u == 'Some message: foo'
    e = Dummy(u'foo', u'bar', u'baz')
    u = unicode(e)
    # test.test_exception.test_IllegalUseOfScopeReplacer___unicode__:
    # u == 'Some

# Generated at 2022-06-12 07:36:56.745661
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should be defined exactly because it is used in
    many places."""
    def f(s):
        """Make sure str(s) == s"""
        return str(s) == s
    o = IllegalUseOfScopeReplacer(None, None)
    assert f(IllegalUseOfScopeReplacer(None, None))
    o = IllegalUseOfScopeReplacer(None, None)
    assert f(IllegalUseOfScopeReplacer(None, None))
    o = IllegalUseOfScopeReplacer(None, None, None)
    assert f(IllegalUseOfScopeReplacer(None, None, None))
    o = IllegalUseOfScopeReplacer('u', 'a', 'b')
    assert f(IllegalUseOfScopeReplacer('u', 'a', 'b'))
    # and now some tests that should always

# Generated at 2022-06-12 07:37:02.048238
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests.blackbox import ExternalBase

    class TestCase(ExternalBase):
        """Testing for method __getattribute__ of class ScopeReplacer."""

        def test_simple(self):
            """Simple test."""
            # TODO: Write the test.
            self.assertEqual(False, True)


# A function that will create a ScopeReplacer that can replace itself in a
# scope.

# Generated at 2022-06-12 07:37:12.128935
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Tests for IllegalUseOfScopeReplacer.__unicode__"""
    u = IllegalUseOfScopeReplacer(u'foo', u'bar').__unicode__()
    # Check that a unicode object is always returned
    if not isinstance(u, unicode):
        raise AssertionError('IllegalUseOfScopeReplacer returns a %s, not an '
                             'unicode.' % type(u))
    # Check that the returned unicode object is correct
    if u != u'foo was used incorrectly: bar':
        raise AssertionError('IllegalUseOfScopeReplacer returns %r, not %r.' %
                             (u, u'foo was used incorrectly: bar'))


# Generated at 2022-06-12 07:37:21.844130
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    # IllegalUseOfScopeReplacer.__unicode__
    # IllegalUseOfScopeReplacer.__unicode__: No preformatted string
    # IllegalUseOfScopeReplacer.__unicode__: _get_format_string is None
    # IllegalUseOfScopeReplacer.__unicode__: _get_format_string is not None
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class Tester(TestCase):
        def setUp(self):
            self.exception = IllegalUseOfScopeReplacer('obj', 'msg')
            self.exception._preformatted_string = None
            self.exception._get_format_string = None

# Generated at 2022-06-12 07:37:32.533112
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """
    Test that __eq__ works at all and handles all the attributes and
    non-attributes it should.
    """
    def test_eq(a, b, test, **kwargs):
        e = IllegalUseOfScopeReplacer(a, b, **kwargs)
        test.assertEqual(e, e)
        f = IllegalUseOfScopeReplacer(a, b, **kwargs)
        test.assertEqual(e, f)
        test.assertEqual(f, e)

    class TestIllegalUseOfScopeReplacer(object):
        def test_eq(self):
            test_eq('a', 'b', self)
        def test_attrs(self):
            test_eq('a', 'b', self, extra='c')

# Generated at 2022-06-12 07:37:38.586266
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Check __str__ method of IllegalUseOfScopeReplacer."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # Check __str__ method.
    s = str(e)
    # Check that the exact string returned is known to be correct.
    if s != 'name was used incorrectly: msg':
        raise AssertionError('"%s" != "%s"' % (s, 'name was used incorrectly: msg'))



# Generated at 2022-06-12 07:37:49.089464
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Testing ImportProcessor.lazy_import"""

    import sys
    import sys
    import os
    import os.path
    import shutil
    from os.path import join
    import os.path as path
    import tempfile
    from os.path import join as j
    from bzrlib import errors
    from bzrlib import osutils
    from bzrlib import trace
    from bzrlib.osutils import getcwd
    from bzrlib import tests

    from gettext import gettext as _
    from os import environ
    from bzrlib.symbol_versioning import one_two
    from bzrlib.symbol_versioning import one_two

    # TODO: jam 20060912 We are very strict about duplicate imports now,
    #       because we need to be able to resolve

# Generated at 2022-06-12 07:37:57.383177
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:38:07.714087
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer returns utf-8 encoded string"""
    local_name = "Errors"
    msg = "Some important message"
    obj = IllegalUseOfScopeReplacer(local_name, msg)
    str_obj = str(obj)
    assert isinstance(str_obj, str), "str(IllegalUseOfScopeReplacer()) should return str, not unicode"
    assert local_name.upper().encode('utf-8') in str_obj, "IllegalUseOfScopeReplacer.__str__() should contain local name in uppercase"
    assert msg.encode('utf-8') in str_obj, "IllegalUseOfScopeReplacer.__str__() should contain message"



# Generated at 2022-06-12 07:38:30.836559
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import types
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.inter import InterObject
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestFoo

    class SetattrTest(TestCase):

        def test_proxy_interface(self):
            # Ensure __setattr__ proxies correctly.
            self.assertRaises(IllegalUseOfScopeReplacer,
                              ScopeReplacer.__setattr__,
                              'foo', None)

            namespace = {}
            def generate_foo(self, scope, name):
                return namespace[name]

            foo = ScopeReplacer(namespace, generate_foo, 'foo')

# Generated at 2022-06-12 07:38:41.067513
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    scope = {}
    class Foo(object):
        def __init__(self):
            pass
        def foo(self):
            return 1
    def factory_foo():
        return Foo()
    my_foo = ScopeReplacer(scope, factory_foo, 'my_foo')
    class Bar(object):
        def __init__(self):
            pass
        def bar(self):
            return 2
    def factory_bar():
        return Bar()
    my_bar = ScopeReplacer(scope, factory_bar, 'my_bar')
    class FooBar(object):
        def __init__(self):
            pass
        def foo(self):
            return 3
        def bar(self):
            return

# Generated at 2022-06-12 07:38:45.112730
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    doctest.run_docstring_examples(IllegalUseOfScopeReplacer.__str__,
                                   {},
                                   'IllegalUseOfScopeReplacer.__str__',
                                   __name__)



# Generated at 2022-06-12 07:38:53.988697
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import random
    import testtools
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import per_interpreter_def

    def _factory(scope, locals_, name):
        def _return_random_numbers():
            return random.randint(1, 1000), random.randint(1, 1000)
        return _return_random_numbers
    def _test():
        scope = locals()
        lazy_import(scope, '''
        _return_random_numbers = ScopeReplacer(locals(), _factory, '_return_random_numbers')
        ''')
        a = scope['_return_random_numbers']()
        # The function should be transparently called as though it were already
        # in scope.

# Generated at 2022-06-12 07:39:04.680822
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should return a unicode object.

    If there is an error while formatting, it should also return a unicode
    object.

    XXX: This doesn't check that formatting actually works as expected,
    because we're not sure how to best test that yet.
    """
    import bzrlib.tests
    bzrlib.tests.simple_class_method_test(IllegalUseOfScopeReplacer,
        '__unicode__')
    e = IllegalUseOfScopeReplacer('name', 'message')
    assert isinstance(unicode(e), unicode)
    e._fmt = None
    assert isinstance(unicode(e), unicode)
    e._fmt = u'unicode_fmt'
    assert isinstance(unicode(e), unicode)
   

# Generated at 2022-06-12 07:39:10.992919
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test for method lazy_import of class ImportProcessor"""
    scope = {}
    import_str = """
    import bzrlib
    import bzrlib.commands
    from bzrlib import foo
    import bzrlib.plugin
    from bzrlib.plugins.fastimport import (
        commands,
        options,
    )
    from bzrlib.plugins import aliased
    from bzrlib.plugins.whoami.whoami import (
        get_whoami_string,
    )
    """
    ip = ImportProcessor()
    ip.lazy_import(scope, import_str)

# Generated at 2022-06-12 07:39:17.938382
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import

    class Foo(object):
        _foo = lazy_import.ScopeReplacer(globals(), lambda _,s,n:s[n], '_foo')
        _bar = None

    f = Foo()

# Generated at 2022-06-12 07:39:28.950528
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # No '_fmt'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == 'Unprintable exception IllegalUseOfScopeReplacer: ' \
        'dict={"msg": "bar", "name": "foo", "extra": ": baz"}, fmt=None, ' \
        'error=None'

    # '_fmt' which is not a str
    e._fmt = None
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:39:37.741480
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""

    class SomethingElse(IllegalUseOfScopeReplacer):
        _fmt = "Sorry %(name)r you are confused: %(msg)s%(extra)s"
        def __init__(self, name, msg, extra=None):
            super(SomethingElse, self).__init__(name, msg, extra)

    inst = SomethingElse('foo', 'bar')
    s = str(inst)
    assert isinstance(s, str)
    assert s == "Sorry 'foo' you are confused: 'bar'"
    s = unicode(inst)
    assert isinstance(s, unicode)
    assert s == u"Sorry 'foo' you are confused: 'bar'"

# Generated at 2022-06-12 07:39:40.005307
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    r = ScopeReplacer(globals(), lambda p,s,n:n,)
    assert(r(1, 2) == 1)


# Generated at 2022-06-12 07:39:51.126987
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda s, sc, n: {}, 'name')
    class DummyClass(object):
        """docstring for DummyClass"""
        def foo(self):
            """docstring for foo"""
            pass
    dummy = DummyClass()
    scope_replacer.__setattr__('new_attr', dummy)
    assert scope['name']['new_attr'] == dummy

# Generated at 2022-06-12 07:40:00.972541
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    t = bzrlib.tests.TestCase()
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import lazy_import
    # test illegal use
    ScopeReplacer._should_proxy = False
    d = {}
    lazy_import(d, '''
    x = 0
    ''')
    # assignment is OK
    d['x'] = 1
    # recursive assignment should fail
    t.assertRaises(IllegalUseOfScopeReplacer,
    d['x'].foo, 'bar')
    # test legal use
    ScopeReplacer._should_proxy = True
    d['x'] = 1
    d['x'].foo('bar')
    return t



# Generated at 2022-06-12 07:40:08.004242
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import copy

    class MyScopeReplacer(ScopeReplacer):

        def __init__(self, *args):
            # Redefine the method __setattr__ of the class ScopeReplacer
            # This is done to disable proxying, that is the normal behavior
            ScopeReplacer.__setattr__ = ScopeReplacer.__setattr
            ScopeReplacer.__init__(self, *args)

    class TestScopeReplacer(TestCase):
        def test_assign_to_other_var_before_use(self):
            """Test the case:
                lazy_obj.name = 'my_name'
                other_obj = lazy_obj
            """
            def test_scope_replacer_func(lazy_obj, scope, name):
                value = lazy_obj.name

# Generated at 2022-06-12 07:40:17.482611
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), """
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    """)

    b = bzrlib.branch.Branch.open('.')

    # test the result type
    r = b.repository
    if r.__class__.__name__ not in ('_MemoryRepository',):
        raise AssertionError
    # test the result content
    if not bzrlib.branch.Branch.open('.').repository.controldir.root_transport.has('.'):
        raise AssertionError
    # test the number of call

# Generated at 2022-06-12 07:40:24.374078
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        # Module bzrlib.tests.test_lazy_import.test_ScopeReplacer___setattr__ was
        # already imported, so we use reload
        from importlib import reload
        reload(test_ScopeReplacer___setattr__)
    except NameError:
        del test_ScopeReplacer___setattr__
        from bzrlib.tests.test_lazy_import import test_ScopeReplacer___setattr__
    import sys
    import types
    import unittest
    __tracebackhide__ = True

    class TestCase(unittest.TestCase):

        def test_set_object_attributes_proxy(self):
            """Test that attributes are proxied to the actual object correctly."""
            scope = {}

# Generated at 2022-06-12 07:40:35.543259
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit tests for IllegalUseOfScopeReplacer.__str__'"""

    import sys
    assert sys.getdefaultencoding() == 'ascii', \
        "This test is only valid when defaultencoding=='" + 'ascii' + "'"
    for text in ['', 'a', 'aa', '\xa1']:
        str_value = str(text)
        assert str_value == text
        unicode_value = unicode(text, 'ascii')
        assert unicode_value == text
        try:
            str_value = str(unicode_value)
        except UnicodeDecodeError as e:
            str_value = str(e)
        # On python2.6, str(UnicodeEncodeError("aa", "ascii", 0, 1,
        # "'ascii' codec

# Generated at 2022-06-12 07:40:38.814082
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    global ScopeReplacer
    if ScopeReplacer is None:
        import bzrlib.lazy_import
        ScopeReplacer = bzrlib.lazy_import.ScopeReplacer
    ScopeReplacer(__name__, 0, 1).__call__()

# Generated at 2022-06-12 07:40:46.582335
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    from bzrlib.lazy_import import ScopeReplacer
    scope = sys._getframe(1).f_locals
    scope['obj'] = object()
    # Make sure that _real_obj is not assigned to obj for the below
    # test or an AttributeError will be raised instead of the
    # IllegalUseOfScopeReplacer exception.
    test_ScopeReplacer___setattr__.__test__ = False
    try:
        obj = ScopeReplacer(scope, lambda lazy_obj, scope, name: None, 'obj')
        obj.foo = 'bar'
    except IllegalUseOfScopeReplacer as e:
        assert str(e) == "ScopeReplacer object'obj' was used incorrectly:" \
            " Object already replaced, did you assign it to another variable?"

# Generated at 2022-06-12 07:40:49.111639
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    r = ScopeReplacer({}, 'factory', 'name')
    try:
        r.__getattribute__('x')
    except AttributeError:
        pass


# Generated at 2022-06-12 07:40:51.560414
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = IllegalUseOfScopeReplacer('name', 'msg')
    u.__unicode__()

# Generated at 2022-06-12 07:40:58.851585
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    import lazy_import
    return doctest.DocTestSuite(lazy_import)

# Generated at 2022-06-12 07:41:10.081420
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str.

    This test makes sure that __str__() always returns a str and not
    a unicode object.

    This is needed for compatibility with python 2.4.
    """
    x = IllegalUseOfScopeReplacer('aa', 'b')
    s = str(x)


    from bzrlib.tests.per_interpreter import TestCaseWithInterpreter
    class TestIllegalUseOfScopeReplacer(TestCaseWithInterpreter):

        _test_needs_features = [TestCaseWithInterpreter.UnicodeFeature]


# Generated at 2022-06-12 07:41:20.935694
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Ensure that IllegalUseOfScopeReplacer.__unicode__ works as expected."""
    __tracebackhide__ = True
    e = IllegalUseOfScopeReplacer('name', 'message')
    assert isinstance(e, Exception)
    assert e.name == 'name'
    assert e.msg == 'message'
    assert e.extra == ''
    assert isinstance(e, Exception)
    assert str(e) == 'message'
    assert unicode(e) == u'message'
    repr(e)
    # check that passing extra does not change the unicode output
    e = IllegalUseOfScopeReplacer('name', 'message', extra='extra')
    assert isinstance(e, Exception)
    assert e.name == 'name'
    assert e.msg == 'message'
    assert e.extra == 'extra'


# Generated at 2022-06-12 07:41:25.123023
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Test that no exception are raised when calling __str__
    # on an IllegalUseOfScopeReplacer object.
    try:
        raise IllegalUseOfScopeReplacer('my_name', 'my_message', 'additional')
    except IllegalUseOfScopeReplacer as e:
        str(e)

# Generated at 2022-06-12 07:41:36.251452
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer, lazy_import
    from bzrlib.tests.script import RunScriptTestCase, ShellScriptTestsMixin
    from bzrlib.tests.test_lazy_import import DummyLazyImportTestModule
    import sys
    import bzrlib

    class Test(ShellScriptTestsMixin, RunScriptTestCase):
        script_name = "just-import-lazy-import-test"

        def test_lazy_import_in_script(self):
            # RunScriptTestCase imported a script that uses lazy_import,
            # and we need to check that it imported correctly
            self.assertTrue(
                bzrlib.__dict__.get("lazy_import_test_module") is
                DummyLazyImportTestModule)
            self

# Generated at 2022-06-12 07:41:38.883911
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    bzrlib.tests.blackbox.test_ScopeReplacer___call__(ScopeReplacer)



# Generated at 2022-06-12 07:41:49.610142
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Calls the method under test and compares expectations to actual results.
    # _resolve
    module_name = 'bzrlib.lazy_import'
    class_name = 'ScopeReplacer'
    method_name = '__call__'
    scope = {}
    name = 'test'
    scope[name] = ScopeReplacer(scope, lambda self, scope, name: 'foo', name)
    actual_result = scope[name]()
    expected_result = 'foo'
    assert actual_result == expected_result, (
        '%s.%s(%s, %s): %s != %s' % (module_name, class_name,
            name, method_name, actual_result, expected_result))


# Generated at 2022-06-12 07:41:54.310614
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer."""
    def test0(self, scope, name):
        return 42
    globals_ = {'__name__':'__main__'}
    thing = ScopeReplacer(globals_, test0, 'test')
    assert thing() == 42
    assert 'test' in globals_
    assert globals_['test'] == 42


# Generated at 2022-06-12 07:42:05.628565
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.lazy_import import TestModule
    from bzrlib.tests import TestCase, TestCaseWithTransport
    import sys
    test_dict = {'TestModule':TestModule}
    _test_module_to_test_case = ScopeReplacer(test_dict, 
                                              TestModule.__init__, 
                                              'TestModule')
    try:
        _test_module_to_test_case.imported
    except NotImplementedError:
        pass
    else: raise AssertionError
    # Should be unusable before being called
    
    class TestCaseWithTransport(TestCaseWithTransport):
        def test_case_with_transport(self):
            return 'hello, world'

    test_case_with_transport = TestCaseWithTransport

# Generated at 2022-06-12 07:42:12.564761
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import types
    scope = {}
    scope['a'] = object()
    scope['b'] = 'foo'
    scope['c'] = 42
    scope['d'] = 3.14
    scope['e'] = (1, 2, 3)
    scope['f'] = [4, 5, 6]
    scope['g'] = {'a':1, 'b':2}
    class MysteryObject():
        def __init__(self, *args):
            self.args = args
        def __getattribute__(self, attr):
            if attr == 'args':
                return object.__getattribute__(self, attr)
            return scope[attr]
    scope['h'] = MysteryObject('h')
    names = 'abcdefgh'

# Generated at 2022-06-12 07:42:39.974739
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase

    class TestScopeReplacer(TestCase):

        def test___setattr__(self):
            from bzrlib.tests.matchers import HasAttributes

            class Foo(object):
                __slots__ = ('myattr',)
                def __init__(self):
                    self.myattr = 0
                def x(self, i):
                    self.myattr = i

            foo = Foo()
            sr = ScopeReplacer(globals(), lambda _, __, ___: foo, 'foo')
            sr.myattr = 1
            self.assertThat(sr, HasAttributes(myattr=1))
            name = sr._name
            foo.x(2)
            self.assertThat(sr, HasAttributes(myattr=2))
            sr.myattr = 3
            self

# Generated at 2022-06-12 07:42:46.432085
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Ensure that IllegalUseOfScopeReplacer.__unicode__ produces correct
    output.
    """
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert u.startswith('IllegalUseOfScopeReplacer(foo')
    assert u.endswith('bar)')
    assert 'IllegalUseOfScopeReplacer(foo' in str(e)



# Generated at 2022-06-12 07:42:51.487686
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    # This test exercises __unicode__(), but we can't check the result because
    # it depends on the current LANG, which we don't want to set.
    c = IllegalUseOfScopeReplacer(
        name="name", msg="msg", extra="extra")
    unicode(c)



# Generated at 2022-06-12 07:42:53.592560
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # TODO: implement test for
    # def __setattr__(self, attr, value):
    return

# Generated at 2022-06-12 07:42:59.893573
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    from bzrlib import config
    # Call the method under test
    result = IllegalUseOfScopeReplacer('foo', 'bar').__unicode__()
    # Check outcome
    assert type(result) == config.unicode

    result = IllegalUseOfScopeReplacer('foo', 'bar').__str__()
    assert type(result) == str



# Generated at 2022-06-12 07:43:06.269847
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer

    """
    e = IllegalUseOfScopeReplacer("x", "y")
    assert isinstance(str(e), str)

# Generated at 2022-06-12 07:43:17.655222
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Calling str() on IllegalUseOfScopeReplacer instance should return
    an utf8 encoded string with the information of the exception.
    """
    # Tests calling str() on exception objects.
    e1 = IllegalUseOfScopeReplacer("testexception", "The real exception!")
    str(e1)
    e2 = IllegalUseOfScopeReplacer("testexception", "The real exception!",
                                   "Extra data.")
    str(e2)


# The ScopeReplacer class is used to implement lazy import. In
# general, a ScopeReplacer object for an imported object is passed to the
# lazy_import function, which will insert this object into the
# specified namespace. The ScopeReplacer object is then replaced with
# a real object on first use.
#
# The ScopeReplacer can be used as a weak replacement for the real object
#

# Generated at 2022-06-12 07:43:27.937938
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test the method IllegalUseOfScopeReplacer.__unicode__ (utf-8)"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    import locale
    try:
        locale.setlocale(locale.LC_ALL, "en_US.utf-8")
    except locale.Error:
        # Ignore error on platforms that do not support utf-8.
        sys.stderr.write("Unable to use english locale with UTF-8 encoding.\n")
        return
    s = IllegalUseOfScopeReplacer('name', 'msg')