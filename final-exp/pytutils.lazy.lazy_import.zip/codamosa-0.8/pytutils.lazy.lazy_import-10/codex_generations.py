

# Generated at 2022-06-12 07:33:54.849897
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e1 = IllegalUseOfScopeReplacer('a', 'b', ['c', 1])
    assert str(e1) == ("ScopeReplacer object 'a' was used incorrectly:"
                       " b: ['c', 1]")
    e2 = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert str(e2) == ("ScopeReplacer object 'a' was used incorrectly:"
                       " b: c")
    e3 = IllegalUseOfScopeReplacer('a', 'b')
    assert str(e3) == ("ScopeReplacer object 'a' was used incorrectly:"
                       " b")
    e4 = IllegalUseOfScopeReplacer('a', 'b', {'c': 1})

# Generated at 2022-06-12 07:34:05.739956
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import pickle

    class Foo():
        def __init__(self, name):
            self.name = name
        def __call__(self, *args, **kwargs):
            return self.name, args, kwargs

    name = 'spam'
    args = (1, 2, 3)
    kwargs = {'kwarg1': 1, 'kwarg2': 2}
    scope = {name: None}
    lazy = ScopeReplacer(scope, lambda self, scope, name: Foo(name), name)
    obj = lazy()
    # verify that the object is being pickled and unpickled correctly
    pickled_obj = pickle.loads(pickle.dumps(obj))
    expected_return = (name, args, kwargs)
    actual_return = obj(*args, **kwargs)


# Generated at 2022-06-12 07:34:17.136123
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() of IllegalUseOfScopeReplacer should return unicode"""
    class X(IllegalUseOfScopeReplacer):
        _fmt = "This is a %(name)s test"
    x = X('unicode', 'This is a unicode test')
    xu = unicode(x)
    xs = str(x)
    isinstance(xu, unicode)
    isinstance(xs, str)
    if unicode != str:
        # __unicode__() and __str__() are not the same, then make sure that
        # __unicode__ is the identity function and __str__ is the str()
        # function.
        xu is x
        xs == str(x)



# Generated at 2022-06-12 07:34:26.355526
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This function tests method __unicode__ of class IllegalUseOfScopeReplacer.

    Methods tested:
        IllegalUseOfScopeReplacer.__unicode__
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    test_cases = [
        ('errors', 'msg', None),
        ('errors', 'msg', 'extra'),
        ]
    for name, msg, extra in test_cases:
        e = IllegalUseOfScopeReplacer(name, msg, extra)
        repr(e)
        unicode(e)
        str(e)
        str(e) == unicode(e).encode('utf8')
# end test_IllegalUseOfScopeReplacer___unicode__



# Generated at 2022-06-12 07:34:35.334780
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ tests."""
    # __eq__ doesn't care about the attributes of the objects when they are the
    # same object
    class Foo(IllegalUseOfScopeReplacer):
        _fmt = 'foobar'
    f1 = f2 = Foo(name='toto', msg='msg', extra='extra')
    assert f1 == f2

    # __eq__ is not fooled by a subclass
    class Bar(Foo):
        pass
    b = Bar(name='tutu', msg='msg2', extra='extra2')
    assert not f1 == b

    assert not f1 == {}



# Generated at 2022-06-12 07:34:45.876049
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import sys
    msg = "no dice"
    extra = "and I mean it"
    testee = IllegalUseOfScopeReplacer(sys, msg, extra=extra)
    result = str(testee)
    assert result.startswith("ScopeReplacer object")
    assert msg in result
    assert extra in result
    assert "Unprintable exception" not in result
    assert str(testee) == str(testee)
    assert str(testee) == unicode(testee)
    assert not '\ufffd' in unicode(testee)
    # Try a broken utf8 str as the exception message
    # This is not working from Python 2.5, because with Python 2.5
    # IllegalUseOfScopeReplacer._get_format_

# Generated at 2022-06-12 07:34:47.857719
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import known_failure
    known_failure(ScopeReplacer)



# Generated at 2022-06-12 07:34:56.466371
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class Subclass(IllegalUseOfScopeReplacer):
        _fmt = "the format"
    class OtherSubclass(IllegalUseOfScopeReplacer):
        _fmt = "other format"
    a1 = Subclass("foo", "msg", 42)
    a2 = Subclass("foo", "msg", 42)
    b1 = Subclass("notfoo", "msg", 42)
    assert a1 == a2
    assert a1 != b1
    assert a1 != a1.__dict__
    assert a1 != "a1"
    assert a1 != 42
    assert a1 != object()
    assert a1 != OtherSubclass("foo", "msg", 42)
    assert a1 != Subclass("foo", "notmsg", 42)
    assert a1 != Subclass("foo", "msg", 43)
   

# Generated at 2022-06-12 07:34:59.293194
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    if str(e) != "name was used incorrectly: msg":
        raise ValueError



# Generated at 2022-06-12 07:35:06.367493
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    # Simple example
    # Tests that method __str__ works with variables that are in
    # __init__, but not in _fmt.
    # (IllegalUseOfScopeReplacer, PQMClient, Message)
    a = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    if str(a) != "ScopeReplacer object 'name' was used incorrectly: " \
        "msg: extra":
        raise AssertionError



# Generated at 2022-06-12 07:35:29.269828
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__ should proxy the attribute in an equivalent object."""
    class Equivalent(object):

        def __init__(self, val):
            self.value = val

        def __eq__(self, other):
            return self.value == other.value

    sr = ScopeReplacer(dict(), lambda self, scope, name: Equivalent(42),
                       'foo')
    obj = sr._resolve()
    eq_(obj.value, 42)
    obj2 = sr._resolve()
    eq_(obj2.value, 42)
    eq_(id(obj), id(obj2))
    del obj, obj2
    # Check equality
    sr2 = ScopeReplacer(dict(), lambda self, scope, name: Equivalent(42),
                        'foo')
    eq_(sr, sr2)

# Generated at 2022-06-12 07:35:36.833250
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Testing ScopeReplacer.__call__"""
    from bzrlib.tests.blackbox import ExternalBase
    class impl_ScopeReplacer___call__(ExternalBase):
        """Blackbox test case for ScopeReplacer.__call__."""
        def test_known_values(self):
            self.run_bzr_error(
                ['The requested object is not yet available'],
                'selftest --load ScopeReplacer___call__')
    


# Generated at 2022-06-12 07:35:47.575709
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.per_lazy_import import TestCaseWithMemoryTransport
    from bzrlib.lazy_import import lazy_import
    import bzrlib

    class TestScopeReplacer(TestCaseWithMemoryTransport):

        def test___call__(self):
            # Test that calling the object eventually calls the object inside
            scope = {}
            lazy_import(scope, '''
            TestObject = object()
            ''')
            self.assertEqual('bzrlib.tests.per_lazy_import.TestObject',
                             TestObject.__module__ + '.' + TestObject.__name__)
            self.assertIsInstance(TestObject, ScopeReplacer)
            TestObject()

    test_scope_replacer = TestScopeReplacer('__call__')
    result = test_

# Generated at 2022-06-12 07:35:49.612277
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(scope=None, factory=None, name='foo')
    obj.__setattr__('foo', 'bar')

# Generated at 2022-06-12 07:35:51.537328
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    assert False # Implemented as a mix-in for ScopeReplacer


__all__ = ['ScopeReplacer', 'lazy_import']


# Generated at 2022-06-12 07:35:55.203229
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys

    x = ScopeReplacer(sys.modules, lambda self, s, n: None, 'foo')
    x.bar = 5
    if x.bar != 5:
        raise AssertionError

# Generated at 2022-06-12 07:36:01.389517
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ must return a str object.
    """
    x = IllegalUseOfScopeReplacer('foo', 'danger', 'use extra care')
    s = str(x)
    if not isinstance(s, str):
        raise TestNotApplicable('s was not a str: %r' % (s,))
test_IllegalUseOfScopeReplacer___str__.__doc__ = \
        IllegalUseOfScopeReplacer.__str__.__doc__



# Generated at 2022-06-12 07:36:05.987849
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class C(object):
        pass
    c = C()
    sr = ScopeReplacer(locals(), lambda obj, scope, name: c, 'c')
    eq(c, sr)
    eq(c, sr.foo)
    eq(c.bar, sr.bar)

# Generated at 2022-06-12 07:36:14.785633
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib._lazy_import_test_support_module import _scope_replacer
    new_scope = {}
    name = 'foo'
    replacer = _scope_replacer.ScopeReplacer(new_scope, name)
    replacer.scope_changed = True
    # call the function being tested:
    output = replacer.__str__()
    # check the output:
    expected_output = "%r was used incorrectly: scope changed%s" % (name, "")
    if not (output == expected_output):
        raise AssertionError(
            "%r != %r" % (output, expected_output))



# Generated at 2022-06-12 07:36:19.145898
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    s = ScopeReplacer({}, lambda o, scope, name: o, "my_name")
    def f(x): return x+1
    s._real_obj = f
    assert s(42) == 43
    s._real_obj = None
    assert s(42) == 43


# Generated at 2022-06-12 07:36:44.830314
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from StringIO import StringIO
    from bzrlib import (
        config,
        osutils,
        tests,
        )
    class TestCase(tests.TestCaseWithTransport):
        """Testing the __setattr__() method of class ScopeReplacer"""
        def get_text(self, s):
            """Return the textual content of file 's' in the test
            repository"""
            return self.get_transport().get_bytes(s).decode('utf-8')
        def test_silly(self):
            """Test that assigning to a ScopeReplacer object fails"""
            # This function is used as a factory to create another object
            # that replaces the ScopeReplacer.
            def _factory(self, scope, name):
                from bzrlib.builtins import selftest

# Generated at 2022-06-12 07:36:56.705437
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Check that attr setting works on ScopeReplacer objects

    A ScopeReplacer object is an object that will be replaced by its factory
    callable in the scope it was created in, the first time it is used.
    Setting attributes on it is a bit tricky, so this test checks that
    it works well.

    These checks rely on the proper functioning of the ScopeReplacer
    class internals, so they should not be used in normal operation.
    """
    # build a ScopeReplacer object.
    # Any ScopeReplacer will do...
    o = ScopeReplacer({}, lambda obj, scope, name: obj, 'foo')
    # ... but we need it to be not yet resolved.
    o._real_obj = True
    # We also need proxying to be disabled, otherwise the setattr would
    # be allowed to pass through.
    ScopeReplacer

# Generated at 2022-06-12 07:37:02.010851
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ of class IllegalUseOfScopeReplacer."""
    n = 'foo'
    m = 'msg'
    e = 'extra'
    obj = IllegalUseOfScopeReplacer(n, m, e)
    expected = "'ScopeReplacer object 'foo' was used incorrectly: " \
        "msg: extra'"
    observed = str(obj)
    assert observed == expected, observed


# Generated at 2022-06-12 07:37:13.479924
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    # Executed once, before any of the test cases are run
    import sys
    import inspect

    scope = {}
    name = 'foo'

    # Construct a real object from which we can get the attribute values
    # when the lazy object is replaced
    class RealObj(object):

        def __init__(self):
            self.attr1 = 3
            self.attr2 = 5

    real_obj = RealObj()
    # Fake a factory function for lazy_import to use
    def factory(self, scope, name):
        return real_obj

    # Construct a lazy object
    lazy_obj = ScopeReplacer(scope, factory, name)

    # Proxy through to the real object, and set the attribute 'attr1'
    lazy_obj.attr1 = 4



# Generated at 2022-06-12 07:37:18.487120
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from cStringIO import StringIO
    from bzrlib.lazy_import import (
        IllegalUseOfScopeReplacer,
        )
    stream = StringIO()
    e = IllegalUseOfScopeReplacer('a name', 'a message')
    stream.write(u'%s' % (e,))
    result = stream.getvalue()



# Generated at 2022-06-12 07:37:22.778267
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """https://bugs.launchpad.net/bzr/+bug/491245"""
    # Tests the bug is fixed, we shouldn't raise exception because
    # there is no _get_format_string method.
    e1 = IllegalUseOfScopeReplacer('name', 'message')
    unicode(e1)



# Generated at 2022-06-12 07:37:30.073029
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """When str() is called on an IllegalUseOfScopeReplacer it should return
    a str.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    # the following will fail if the string returned is unicode
    s = s.encode('utf8')
    # the following will fail if the string returned is unicode
    s = s.encode('ascii')



# Generated at 2022-06-12 07:37:34.222477
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert str(e) == 'IllegalUseOfScopeReplacer object a was used incorrectly:'\
        ' b: c'



# Generated at 2022-06-12 07:37:42.858996
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
  # From test lazy_import_gadget.py and test lazy_import_import.py
  class Class(object):
    def f(self):
      return 42
  def make_class():
    return Class()
  class Attr(object):
    def __get__(self, obj, cls):
      return 42
    def __set__(self, obj, val):
      raise AssertionError()
  # Make sure we can use __setattr__ to replace the real object on some other
  # namespace. This used to be an issue when the namespace wasn't a module, but
  # we now detect the module and it works.
  ns = {}
  x = ScopeReplacer(ns, make_class, 'Class')
  # x is a ScopeReplacer, but if we call it, it will turn into a real object
  cl

# Generated at 2022-06-12 07:37:47.160787
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = IllegalUseOfScopeReplacer('name', 'msg').__unicode__()
    assert isinstance(u, unicode)
    u = IllegalUseOfScopeReplacer('name', 'msg', 'extra').__unicode__()
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:37:57.864243
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass

# Generated at 2022-06-12 07:38:03.159809
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Method __call__ on class ScopeReplacer"""
    # TODO: implement
    pass

    # TODO: do some more tests
    # Perhaps, test if they are only called once?
    # Perhaps, test if they can be used in functions and methods?
    # Perhaps, test if it can be pickled?
    # How? Why not?



# Generated at 2022-06-12 07:38:08.051011
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value) -> None.

    Create a temporary object in the specified scope. Once used, a real
    object will be placed in the scope.
    """
    obj = ScopeReplacer({}, lambda self, scope, name: object(), 'name')
    obj.attr = 'value'
    return

# Generated at 2022-06-12 07:38:17.804953
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IlllegalUseOfScopeReplacer.__unicode__()

    This test expects the default encoding to be utf8.
    """
    from bzrlib import lazy_import
    obj = lazy_import.IllegalUseOfScopeReplacer(
        'some_name', 'a message', 'extras')
    # __str__() must convert to unicode using the default encoding.
    expected_str = 'Unprintable exception IllegalUseOfScopeReplacer: ' \
        'dict={\'msg\': \'a message\', \'extra\': \'extras\', \'name\': \'some_name\'}, ' \
        'fmt=\'%(name)r was used incorrectly: %(msg)s%(extra)s\', error=None'

    # str(obj) must return a str object.
    obj_str = unicode

# Generated at 2022-06-12 07:38:24.050021
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from unittest import TestCase
    class ScopeReplacer___setattr__Tests(TestCase):
        def test_success(self):
            from bzrlib import lazy_import
            self.assertRaises(AttributeError, getattr, lazy_import, 'test_attr')
            lazy_import.test_attr = 42
            self.assertEqual(42, lazy_import.test_attr)
    return ScopeReplacer___setattr__Tests



# Generated at 2022-06-12 07:38:32.155066
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns unicode"""

# Generated at 2022-06-12 07:38:41.510727
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """The str() of an IllegalUseOfScopeReplacer is a (possibly truncated)
    unicode string."""
    # This is a bit weird, but we want to test the code path that pulls the utf8
    # out of the exception's dict, but we don't want to actually have non-ascii
    # characters in the code, so make up some non-ascii characters to use.
    my_u = u'\u1234\u5678'
    __u = u'\ufffd\ufffd'
    try:
        raise IllegalUseOfScopeReplacer('foo', my_u, extra=my_u)
    except IllegalUseOfScopeReplacer as e:
        s = str(e)
        # The string should be a utf8 string
        u = unicode(s, 'utf8', 'replace')

# Generated at 2022-06-12 07:38:49.219468
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """test __getattribute__ of class ScopeReplacer"""
    class FooBar(object):
        def __init__(self, bar):
            self.bar = bar
    obj = ScopeReplacer({}, lambda self, scope, name: FooBar('foo'), 'bar')
    assert not hasattr(obj, 'foo')
    assert obj.bar == 'foo'
    assert not hasattr(obj, 'foo')
    assert obj.bar == 'foo'


# Generated at 2022-06-12 07:39:00.872712
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.per_lazy_import._imported_module as m
    m.__setattr__('a', 1)
    m._bzrlib_tests_per_lazy_import__imported_module__a = 'spam'
    m.a = 1
    m.m.a = 1
    m.m.m.a = 1
    m.a.m = 1
    m.m.m.a = 1
    m.a.m.m = 1
    m.m.m.a.m = 1
    m.a.m.m.m = 1
    m.m.m.a.m.m = 1
    m.m.m.a.m.m.m = 1
    m.a.m.m.m.m.m = 1
#

# Generated at 2022-06-12 07:39:06.591044
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ returns unicode

    This is also a regression test for bug #1183814.
    """
    s = u'\xff'
    e = IllegalUseOfScopeReplacer('name', s)
    e_u = unicode(e)
    # Make sure we get back what we put in.
    eq = (e_u == s)
    assert eq
    # Make sure we get back a unicode object.
    assert isinstance(e_u, unicode)

# Generated at 2022-06-12 07:39:47.228475
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() standardizes the string form of
    exceptions, and re-encodes them to utf-8 when a caller requests a non-unicode
    string. It handles exceptions that have no format string to use.
    """
    import sys
    # Create an exception that does not have a _fmt attribute
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    # The string value of the exception is ascii. Make sure that we get a unicode
    # value out.
    if not isinstance(e.__str__(), unicode):
        raise AssertionError('__str__ does not return a unicode object')
    # The string representation always includes the class name and message

# Generated at 2022-06-12 07:39:53.823145
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests import TestCase
    from bzrlib.i18n import gettext
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = u'foobar'
    t = TestCase()
    ex = MyException(u'hello world!', u'use the foo')
    # Test string conversion with gettext translation
    old_gettext = gettext

# Generated at 2022-06-12 07:39:59.450189
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()

    The __str__() method implements the default conversion to string.
    """

    # It must return a str
    exc = IllegalUseOfScopeReplacer('name', 'msg')
    str(exc)
    # It must call __unicode__()
    exc.__unicode__ = lambda: "unicode test string"
    str(exc)



# Generated at 2022-06-12 07:40:04.096812
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()
    
    This method is typically used during string formatting in which
    case the __unicode__() method must never return a unicode object
    or the format string will be converted to unicode as well. Instead
    it must return a utf8-encoded string which will be converted to
    unicode before formatting by the format operator.
    """
    err = IllegalUseOfScopeReplacer('name', 'message')
    assert isinstance(unicode(err), unicode)
    assert not isinstance(str(err), unicode)


# Generated at 2022-06-12 07:40:13.755008
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    class dummy1:
        def __str__(self):
            # raising something different
            raise ValueError('should not be printed')
    try:
        raise IllegalUseOfScopeReplacer('name', 'msg', dummy1())
    except IllegalUseOfScopeReplacer:
        e = str(sys.exc_info()[1])
    # should have printed the exception
    assert e.find('ValueError: should not be printed') > -1
    # should have printed the fake exception
    assert e.find('name=name') > -1
    # should have printed the fake exception
    assert e.find('msg=msg') > -1



# Generated at 2022-06-12 07:40:19.760828
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This test is for ensuring that the formatting code is robust"""
    r = IllegalUseOfScopeReplacer(1, 2, extra=3)
    try:
        r.__unicode__()
    except Exception as e:
        # we should never get an exception during exception formatting
        raise AssertionError('__unicode__ generated an exception: %r' %
                             e)

test_IllegalUseOfScopeReplacer___unicode__.unittest_skip = (
    "unicode(IllegalUseOfScopeReplacer) not implemented")

# Generated at 2022-06-12 07:40:27.685859
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        def bar(self):
            return "bar"

        def baz(self, a):
            return "baz(%r)" % (a,)

    class SubFoo(Foo):
        pass

    scope = {}
    foo = ScopeReplacer(scope, lambda self, scope, name: Foo(), "foo")
    subfoo = ScopeReplacer(scope, lambda self, scope, name: SubFoo(),
                           "subfoo")
    # there is no bar/baz attr in foo
    try:
        foo.bar
    except AttributeError:
        pass
    else:
        raise AssertionError("bar attribute should be absent")
    try:
        foo.baz
    except AttributeError:
        pass

# Generated at 2022-06-12 07:40:32.199941
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    s = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert str(s) == 'ScopeReplacer object \'foo\' was used incorrectly: bar: baz'



# Generated at 2022-06-12 07:40:35.009445
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'A message')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-12 07:40:39.728006
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    object_to_call = object()
    object_to_call.__call__ = lambda self, *args, **kwargs: (self, args, kwargs)
    sr = ScopeReplacer({}, lambda self, scope, name: object_to_call, None)
    assert (object_to_call, (1, 2, 3), {'a': 'b'}) == sr(1, 2, 3, a='b')
    return



# Generated at 2022-06-12 07:41:33.549117
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from unittest import TestCase
    import sys
    class TestClass(TestCase):
        def __init__(self, *args, **kwargs):
            TestCase.__init__(self, *args, **kwargs)
            def _factory(self, scope, name):
                return _factory
            ScopeReplacer(sys.modules['bzrlib.tests.lazy_import'].__dict__,
                _factory, '_getattr_replacer')
    test_instance = TestClass()
    def _getattr_replacer():
        pass
    test_instance.assertRaises(IllegalUseOfScopeReplacer,
                               _getattr_replacer)

# Generated at 2022-06-12 07:41:40.108619
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __call__(self, *args, **kwargs):
            return "foo_call"
    foobar = Foo()
    obj = ScopeReplacer([], lambda x,y,z: foobar, "foobar")
    obj._should_proxy = False
    assert obj() == "foo_call"
    assert obj(1) == "foo_call"
    assert obj(1, 2) == "foo_call"
    assert obj(1, 2, 3) == "foo_call"
    assert obj(1, 2, 3, 4) == "foo_call"
    assert obj(1, 2, 3, 4, 5) == "foo_call"

# Generated at 2022-06-12 07:41:51.579108
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__(self: bzrlib.lazy_import.ScopeReplacer, *args: object, **kwargs: object) -> object
    # Raises NotImplementedError if not overridden or from a
    # @abstractmethod-decorated method.
    raise NotImplementedError

    class FakeParent(object):
        def __init__(self, name):
            self.name = name
    # Get instance of class
    obj = ScopeReplacer(get_any_scope(), get_any_callable(), get_any_string())
    # Call __call__ method
    # obj()
    # TODO: assert something

    # Get instance of class
    obj = ScopeReplacer(get_any_scope(), get_any_callable(), get_any_string())
    # Call __call__ method
    #

# Generated at 2022-06-12 07:42:02.894422
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """to_unicode(IllegalUseOfScopeReplacer) should support unicode
    
    This tests that the IllegalUseOfScopeReplacer.__str__() method
    supports unicode arguments
    """
    class FooException(IllegalUseOfScopeReplacer):
        _fmt = '%(msg)s %(extra)s'

    e = FooException('a', 'b', 'c')
    u = unicode(e)
    # Since we don't know what encoding the gettext will use, we don't
    # know what the u'\u03b1' will look like.  But we do know that it
    # won't have the 'u' in front of it.
    assert u'\u03b1' in u



# Generated at 2022-06-12 07:42:07.310105
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return an unicode object for IllegalUseOfScopeReplacer"""
    inst = IllegalUseOfScopeReplacer('name', 'msg')
    if isinstance(inst.__str__(), unicode):
        raise AssertionError("IllegalUseOfScopeReplacer.__str__() returns a unicode object.")

# Generated at 2022-06-12 07:42:17.198140
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__ of ScopeReplacer
    # Assignment to instance attribute.
    # Bound to an object that has not been resolved, the attribute should be
    # assigned directly to the object.
    class TestClass(object):
        def __init__(self, name):
            self.name = name
        def set_attr(self, v):
            self.attr = v

    scope = {}
    factory = lambda replacer, scope, name: TestClass(name)
    t = ScopeReplacer(scope, factory, "t")
    t.set_attr("value")
    expected = "value"
    actual = t.attr
    assert expected == actual

# Generated at 2022-06-12 07:42:24.567717
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:42:35.624898
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCaseInTempDir
    from bzrlib import lazy_import

    # make sure that __getattribute__ is transparent, and does not return
    # a copy of the object, or return a new object for module level members
    # each time getattribute is called.
    _test_dict = {}
    _test_dict['test'] = lazy_import.ScopeReplacer(
            _test_dict, lambda _,x,y: x[y],'test')
    test_object = _test_dict['test']

    # try the same attribute again
    self.assertEqual(test_object, test_object.test)

    # try another attribute
    self.assertEqual(test_object, test_object._test_dict['test'])

    # call it

# Generated at 2022-06-12 07:42:40.587705
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    scope = {None: None}
    # Test that the lambda can be called.
    f = lambda obj, scope, name: (obj, scope, name)
    obj = ScopeReplacer(scope, f, None)
    r = obj(1, 2, 3)
    expected = (obj, scope, None)
    TestCase.assertEqual(r, expected)



# Generated at 2022-06-12 07:42:51.278089
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    bzrlib.tests.TestCaseWithMemoryTransport.todo = '''
    Unfortunately the __call__ mehod of a class cannot be tested as
    it is used by the interpreter as __get__ of the class.
    '''
    import bzrlib.tests.blackbox.test_selftest
    # Create a class that is a scope replacer for test_selfest.
    class TestClass:
        pass
    t = TestClass()
    t.branch = ScopeReplacer(bzrlib.tests.blackbox.test_selftest.__dict__,
      bzrlib.tests.blackbox.test_selftest.self, 'self')
    # This should fail.
    self.assertRaises(IllegalUseOfScopeReplacer, t.branch)