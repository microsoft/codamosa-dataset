

# Generated at 2022-06-12 07:33:50.724338
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import os.path
    import bzrlib

    ip = ImportProcessor()
    ip.lazy_import(globals(), text='import os.path, bzrlib.foo.bar')
    os.path
    bzrlib.foo.bar

    ip = ImportProcessor()
    ip.lazy_import(globals(), text='from os.path import join, join(asdf)')
    join
    join(1)

    ip = ImportProcessor()
    ip.lazy_import(globals(), text='from bzrlib import osutils')
    osutils



# Generated at 2022-06-12 07:33:59.573138
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ returns correct results for IllegalUseOfScopeReplacer instances

    The test data is taken from what happens when a ScopeReplacer
    object is used incorrectly.
    """
    # (expected, actual) pairs
    test_data = [
        # Different classes
        (False, IllegalUseOfScopeReplacer(_name, 'msg')),
        (False, object()),
        # Different instances
        (False, IllegalUseOfScopeReplacer(_name, 'different message')),
        (False, IllegalUseOfScopeReplacer('different name', 'msg')),
        (False, IllegalUseOfScopeReplacer('different name',
                                          'different message')),
        # Equal instances
        (True, IllegalUseOfScopeReplacer(_name, 'msg')),
        ]

# Generated at 2022-06-12 07:34:03.934486
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class DummyClass(object):
        def __init__(self):
            self.x = 1
    scope = {}
    replacer = ScopeReplacer(scope, lambda self, scope, name: DummyClass(), 'x')
    scope['x'] = replacer
    scope['x'].x

# Generated at 2022-06-12 07:34:05.521276
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
# You can insert your code here


# Generated at 2022-06-12 07:34:14.115870
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class C():
        def __init__(self, arg):
            self.arg = arg
        def __call__(self, *args, **kwargs):
            return self.arg, args, kwargs
    dct = {'a': ScopeReplacer(dct, lambda obj, scope, name: C(name), 'a')}
    val = dct['a']
    assert(val('hello') == ('a', ('hello',), {}))
    return



# Generated at 2022-06-12 07:34:22.212811
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    # Place a object in the scope, and then replace it with a ScopeReplacer
    # that will report the original object, then check that the object can
    # still be used.
    bzrlib.lazy_imports_report = "original object in scope"

    def factory(self, scope, name):
        return scope[name]

    bzrlib.lazy_imports_report = ScopeReplacer(
        bzrlib.__dict__, factory, 'lazy_imports_report')
    # This should return the original object
    actual = bzrlib.lazy_imports_report
    expected = "original object in scope"
    assert actual == expected, "Wrong object returned: got %r" % actual
    # Now test that we can get a member off the returned object
   

# Generated at 2022-06-12 07:34:25.784194
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Simple unit test for method __unicode__ of class IllegalUseOfScopeReplacer."""
    e = IllegalUseOfScopeReplacer('name', msg='message', extra='extra')
    assert (unicode(e) ==
            u"ScopeReplacer object 'name' was used incorrectly: message: extra")



# Generated at 2022-06-12 07:34:33.736325
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    x = ScopeReplacer(None, None, 'x')
    x.y = 2
    try: ScopeReplacer._should_proxy = False
    except NotImplementedError: ScopeReplacer._should_proxy = 2
    try:
        x.z = 3
        raise AssertionError('IllegalUseOfScopeReplacer not raised')
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('IllegalUseOfScopeReplacer not raised')

# Generated at 2022-06-12 07:34:39.909548
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() of IllegalUseOfScopeReplacer should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # UnicodeError should not happen when calling __str__()
    s = str(e)
    # __str__() should return a 'str' object, never a 'unicode' object
    assert isinstance(s, str)


# Generated at 2022-06-12 07:34:48.378968
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str object with the same format as
    __unicode__"""
    for kw in [dict(name='foo', msg='bar'),
               dict(name='foo', msg='bar', extra=['baz']),
               ]:
        e1 = IllegalUseOfScopeReplacer(**kw)
        e2 = IllegalUseOfScopeReplacer(**kw)
        u1 = unicode(e1)
        s1 = str(e1)
        u2 = unicode(e2)
        s2 = str(e2)
        assert u1 == u2
        assert s1 == s2



# Generated at 2022-06-12 07:35:16.980521
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # calling __str__ on an instance
    expected = "ScopeReplacer object 'foo' was used incorrectly: bar"
    instance = IllegalUseOfScopeReplacer('foo', 'bar')
    str_ = instance.__str__()
    assert str_ == expected
    # calling __str__ on a class
    str_ = IllegalUseOfScopeReplacer.__str__(instance)
    assert str_ == expected
    # calling str() on an instance
    str_ = str(instance)
    assert str_ == expected

# Generated at 2022-06-12 07:35:28.391157
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ of class IllegalUseOfScopeReplacer."""
    import sys
    if sys.version_info < (2,7):
        return
    e1 = IllegalUseOfScopeReplacer('a', "msg")
    e2 = IllegalUseOfScopeReplacer('a', "msg")
    assert str(e1) == 'a was used incorrectly: msg'
    assert str(e2) == 'a was used incorrectly: msg'
    assert e1 == e2
    assert e1 != "hello"
    assert str(e1) == str(e2)
    assert e1 != IllegalUseOfScopeReplacer('b', "msg")
    assert e1 != IllegalUseOfScopeReplacer('b', "msg", "extra")
    assert e1 != IllegalUseOfScopeReplacer('a', "other")

# Generated at 2022-06-12 07:35:39.061956
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # this is pretty ugly, and could use some improvement
    global called
    called = False
    def factory(replacer, scope, name):
        def func(*args, **kwargs):
            global called
            called = True
            return 'called'
        return func

    replacer = ScopeReplacer({}, factory, 'func')

# Generated at 2022-06-12 07:35:42.890983
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib
    def foo():
        pass
    scope = {}
    scope['foo'] = ScopeReplacer(scope, lambda s, sc, n: foo, 'foo')
    scope['foo']()

# Generated at 2022-06-12 07:35:48.543202
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    scope = sys._getframe(1).f_globals
    def factory(self, scope, name):
        return lambda x: x
    name = 'myfunc'
    obj = ScopeReplacer(scope, factory, name)
    # This fails, because the object is replaced when resolved.
    # self.assertRaises(IllegalUseOfScopeReplacer, lambda: obj(1))
    # Check that the call works
    assert obj(1) == 1



# Generated at 2022-06-12 07:35:56.327912
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from contextlib import contextmanager
    from StringIO import StringIO
    from bzrlib.tests import TestCase
    from bzrlib._scope_replacer import ScopeReplacer
    from bzrlib._scope_replacer import IllegalUseOfScopeReplacer
    from bzrlib.tests.features import require_docstring_decorations
    @contextmanager
    def fake_stdout():
        '''Context manager to replace sys.stdout with a string buffer.'''
        orig_stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            yield
        finally:
            sys.stdout = orig_stdout
    def factory(self, scope, name):
        '''Factory to create a ScopeReplacer.'''
        # XXX: Should we really allow a factory to return self??
        return self

# Generated at 2022-06-12 07:36:02.949089
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Make sure unicode output of IllegalUseOfScopeReplacer is ascii"""
    x = IllegalUseOfScopeReplacer('foo', 'bar')
    ascii_output = str(x)
    if 'Traceback' in ascii_output:
        raise AssertionError('%s has no traceback (when it should)'
            % repr(ascii_output))
    if '\n' in ascii_output:
        raise AssertionError('%s contains a newline (when it should not)'
            % repr(ascii_output))



# Generated at 2022-06-12 07:36:13.614118
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import os
    import time
    import bzrlib
    import bzrlib.lazy_import
    import bzrlib.lazy_import_test_helper
    import traceback
    from bzrlib import ( errors, )
    from bzrlib.lazy_import_test_helper import ( DummyModuleImporter, )

    # Run the following tests for each of the two possible values of
    # ScopeReplacer._should_proxy.
    for should_proxy in [ False, True ]:
        _test = bzrlib.tests.TestCaseInTempDir()

# Generated at 2022-06-12 07:36:22.293117
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__()
    #
    # Check that calling a proxy causes it to be resolved, and then calls
    # through to the real object.
    def proxy_factory(proxy, scope, name):
        class _Class(object):
            def _run(self, *args, **kwargs):
                return (type(self), args, kwargs)
            def __call__(self, *args, **kwargs):
                return self._run(*args, **kwargs)
        instance = _Class()
        scope[name] = instance
        return instance

    scope = {}
    proxy = ScopeReplacer(scope, proxy_factory, 'name')
    args = (1, 2, 3)
    kwargs = {'abc':'def', 'ghi':'jkl'}

# Generated at 2022-06-12 07:36:28.539141
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() works as expected"""
    # This test is in its own function because the exception has to be the
    # root exception and cannot be masked by another exception to test it.
    import sys
    s = str(
        IllegalUseOfScopeReplacer("foo", "bar", "baz"))
    assert s == ("ScopeReplacer object 'foo' was used incorrectly:"
                 " bar: baz")
    if sys.version_info[0] < 3:
        u = unicode(
            IllegalUseOfScopeReplacer("foo", "bar", "baz"))
        assert u == ("ScopeReplacer object 'foo' was used incorrectly:"
                     " bar: baz")



# Generated at 2022-06-12 07:36:47.422611
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer"""
    import sys
    import bzrlib.branch # this is added to sys.modules
    globals()['my_class'] = ScopeReplacer(globals(),
                                          lazy_eval_function,
                                          'my_class')
    globals()['funct'] = ScopeReplacer(globals(),
                                       lazy_eval_function,
                                       'funct')
    globals()['obj'] = ScopeReplacer(globals(),
                                     lazy_eval_function,
                                     'obj')
    x = my_class()
    if not isinstance(x, bzrlib.branch.BzrBranch6):
        raise AssertionError()
    x = funct()

# Generated at 2022-06-12 07:36:56.810842
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class TestScopeReplacer(ScopeReplacer):
        """A test class for unit testing of ScopeReplacer."""
        def __init__(self, scope, factory, name):
            ScopeReplacer.__init__(self, scope, factory, name)
            self.x = 1
            self.y = 2
    def factory(replacer, scope, name):
        class Scope(object):
            pass
        scope = Scope()
        return scope
    import sys
    s = TestScopeReplacer(sys.modules, factory, 'bzrlib')
    s.y = 3
    s.x = 2
    assert s.x == 2
    assert s.y == 3

# End unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-12 07:37:05.242154
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test ScopeReplacer.__getattribute__"""
    from TestCaseWithTransport import TestCaseWithTransport
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # ImportError because foo is not really a module
    # Even when using this method to fetch the real_obj
    testcase = TestCaseWithTransport()
    testcase.make_branch_and_tree('.')
    try:
        lazy_import(globals(), '''
        from foo import baz
        ''')
    except ImportError:
        pass
    else:
        testcase.fail('Should raise an import error')

# Generated at 2022-06-12 07:37:13.379044
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.test_lazy_import import FakeScope
    scope = FakeScope()
    x = scope['x'] = []
    scope['fake'] = ScopeReplacer(scope, scope['fake'], 'fake')
    scope['fake'] = lambda self, scope, name: x
    scope['fake'](1,2,3)
    scope['fake'](4,5,6)
    scope['fake'](7,8,9)
    assert scope['x'] == [1,2,3,4,5,6,7,8,9]



# Generated at 2022-06-12 07:37:22.541706
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from cStringIO import StringIO
    from bzrlib.lazy_import import lazy_import
    from bzrlib import (
        symbol_versioning,
        )
    v_factory = symbol_versioning.deprecated_function(lambda: None)

    def real_func():
        raise AssertionError("tried to call real function")
    lazy_func = ScopeReplacer(locals(), v_factory, 'lazy_func')
    locals()['lazy_func'] = lazy_func
    v_factory(lazy_func, locals(), 'lazy_func')

    old_out = symbol_versioning.set_output_encoding(StringIO(), 'ascii')
    try:
        real_func()
    except AssertionError:
        pass
    else:
        raise Ass

# Generated at 2022-06-12 07:37:27.851571
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test lazy_import of ImportProcessor"""

    # This is a regression test for bug #331099: when there are spaces
    # in the import path, the spaces must be quoted (e.g. 'bzrlib.foo bar').
    # This test will fail on a system that doesn't have a bzrlib.foo bar
    # directory in the PYTHONPATH.
    text = """
    import bzrlib.foo bar
    """
    ip = ImportProcessor()
    ip.lazy_import(globals(), text)

    # This is a regression test for bug #332290

# Generated at 2022-06-12 07:37:38.441618
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Calling __unicode__ should not fail, even when used with a subclass that
    # does not have a _fmt member.
    class TestException(Exception):
        pass
    class TestSubclass(IllegalUseOfScopeReplacer):
        pass
    e1 = TestException()
    s1 = TestSubclass('foo', e1)
    unicode(s1)
    # And there should be no regression on 'str' conversion.
    str(s1)
    # And this should be a pure python code path.
    import __builtin__
    try:
        del __builtin__.unicode
        unicode(s1)
        del __builtin__.str
        str(s1)
    finally:
        __builtin__.unicode = unicode
        __builtin__.str = str



# Generated at 2022-06-12 07:37:48.840962
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # verify that a ScopeReplacer can be called
    #
    # a ScopeReplacer is a temporary object that will replace itself in the
    # appropriate scope. This object sits, ready to create the real object the
    # first time it is needed.
    # 
    # __call__(self, *args, **kwargs)
    # 
    # Call the underlying object
    #
    # SEE ALSO
    # ScopeReplacer.__init__()
    # 
    # __call__ is defined in class ScopeReplacer
    f = lambda : 'f-return'
    g = lambda x: 'g-return'
    def g2(x, y=2):
        return 'g2-return'
    h = lambda : None
    sr = ScopeReplacer(locals(), lambda self, scope, name: f, 'f')


# Generated at 2022-06-12 07:37:53.281775
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test method __setattr__ of class ScopeReplacer"""
    class Test(object):
        def __setattr__(self, attr, value):
            return setattr(self, attr, value)
    t = Test()
    t.foo = 42
    assert t.foo == 42

# Generated at 2022-06-12 07:37:59.113019
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Ensure that __setattr__ raises an exception after lazy load"""
    mod = __import__(__name__)
    repl = ScopeReplacer(mod.__dict__, lambda o,s,n: o, 'repl')
    repl.x = 12
    repl.y = 13
    repl._resolve()
    try:
        repl.z = 13
        raise Exception("expected exception")
    except IllegalUseOfScopeReplacer:
        pass

# Generated at 2022-06-12 07:38:09.611669
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """TODO"""
    # TODO write this unit test
    raise NotImplementedError(
        "Test for ScopeReplacer.__setattr__() not implemented")



# Generated at 2022-06-12 07:38:15.210305
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() needs to build a unicode string.

    This method does not test whether the returned string is sane, just that it
    is safe to call.
    """
    try:
        raise IllegalUseOfScopeReplacer('foo', 'something')
    except IllegalUseOfScopeReplacer as e:
        u = unicode(e)


# Generated at 2022-06-12 07:38:26.075053
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    '''Test the method ScopeReplacer.__call__.

    This tests the type of arguments an instance of the ScopeReplacer class
    accepts in method __call__ and the type of object it returns.
    '''
    from bzrlib import lazy_import
    from bzrlib.branch import Branch
    from bzrlib.revision import NULL_REVISION
    from bzrlib.tests import TestCase
    from bzrlib.trace import mutter
    import sys


































    lazy_import(globals(), """
from bzrlib.tests import TestCase
from bzrlib.trace import mutter
""")


# Generated at 2022-06-12 07:38:32.829726
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This method should be tested in isolation because it does a lot."""
    # Exercise the unicode() path, the _fmt path, the _format() path,
    # and the second _format() path.
    class C(IllegalUseOfScopeReplacer):
        _fmt = '%(name)s'
    e = C('foo', 'bar')
    u = unicode(e)
    str(e) # __str__() is covered in the next unit test
    # _format() is covered in the next unit test
    e = C(b'\xe9', 'bar', e)
    str(e) # __str__() is covered in the next unit test
    # _format() is covered in the next unit test
    e = C('foo', b'bar')
    u = unicode(e)

# Generated at 2022-06-12 07:38:41.881255
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    def call_with_bad_encoding(c):
        return IllegalUseOfScopeReplacer(
            c, 'msg', 'Русский text'.decode('ascii'))

    # If the exception string cannot be decoded, then repr() is
    # used.
    e = call_with_bad_encoding(object())
    assert str(e) == "Unprintable exception IllegalUseOfScopeReplacer: dict=%r" \
                     % {'name': object(), 'msg': 'msg', 'extra': ': u\'\\u0420\\u0443\\u0441\\u0441\\u043a\\u0438\\u0439 text\''}
    # If the exception string is decodable as utf

# Generated at 2022-06-12 07:38:51.497105
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import sys
    import bzrlib
    class _Test1(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.tests as tests
            def _mock_factory(obj, scope, name):
                return obj
            tests.test_lazy_import = ScopeReplacer(
                sys.modules[__name__].__dict__,
                _mock_factory,
                'tests_test_lazy_import')
            self.assertRaises(IllegalUseOfScopeReplacer,
                tests.test_lazy_import)
    _Test1().test_ScopeReplacer___call__()



# Generated at 2022-06-12 07:39:00.999501
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    try:
        1/0
    except ZeroDivisionError:
        e = e.__class__(e.name, e.msg, *sys.exc_info())
    user_unicode = unicode(e)
    # Check that the unicode conversion succeeded.
    assert isinstance(user_unicode, unicode)
    # Check that the unicode conversion had some effect.
    assert user_unicode.strip()



# Generated at 2022-06-12 07:39:07.975629
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ handles non-ascii attribute values"""
    # This is based on the example in the bzrlib doc for the
    # 'exceptions' module.
    u = u'\u1234' # a unicode string with a non-ascii character
    class TestException(IllegalUseOfScopeReplacer):
        _fmt = '%(name)s'
    e = TestException(u, 'Should be unicode')
    result = unicode(e) # should not raise UnicodeDecodeError
    # The result should have the non-ascii character in it
    result.index(u) # should not raise ValueError: substring not found


# TODO: Maybe we should add a docstring to this function?

# Generated at 2022-06-12 07:39:13.261077
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        ScopeReplacer._should_proxy = False
        ScopeReplacer({}, lambda self, scope, name: 'good', 'good')
    except Exception as e:
        import traceback

# Generated at 2022-06-12 07:39:23.288940
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() and __unicode__() should return a str object."""
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = u"the message with '%(msg)s' and '%(extra)s'"
    import six.moves.cStringIO as StringIO
    # capture stderr
    stderr = StringIO.StringIO()
    import sys
    saved_stderr = sys.stderr
    sys.stderr = stderr

# Generated at 2022-06-12 07:39:43.512622
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer(u"myname",
                                  u"my message",
                                  u"my extra message")
    s = e.__str__()
    assert isinstance(s, str)



# Generated at 2022-06-12 07:39:52.124768
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import __builtin__
    from bzrlib import lazy_import
    lazy_import.lazy_import(globals(), '''
    import os
    ''')
    # test_setattr_proxying
    # test that ScopeReplacer avoids overwriting an existing obj
    # it should use the existing obj instead.
    os_sr = os
    _should_proxy_save = ScopeReplacer._should_proxy
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-12 07:39:55.742872
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e1 = IllegalUseOfScopeReplacer('e1', 'msg', extra=None)
    e2 = IllegalUseOfScopeReplacer('e2', 'msg', extra=None)
    assert str(e1) == str(e2)



# Generated at 2022-06-12 07:39:59.756865
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Testing IllegalUseOfScopeReplacer.__unicode__."""
    import doctest
    doctest.testmod(
        verbose=False, optionflags=doctest.ELLIPSIS,
        name="IllegalUseOfScopeReplacer.__unicode__")

# Generated at 2022-06-12 07:40:00.644366
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""


# Generated at 2022-06-12 07:40:08.663564
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.tests.test_scope_replacer
    reload(bzrlib.tests.test_scope_replacer)
    module = sys.modules['bzrlib.tests.test_scope_replacer']
    globals()['bzrlib.tests.test_scope_replacer'] = module
    def test_func(arg1, arg2=2):
        return arg1 * arg2
    module.ScopeReplacer.__getattribute__(3, '_resolve')
    def factory(replacer, scope, name):
        return test_func
    name = 'foo'
    module.ScopeReplacer(globals(), factory, name)
    module.ScopeReplacer.__getattribute__(foo, '_resolve')

# Generated at 2022-06-12 07:40:14.458074
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Ensure that IllegalUseOfScopeReplacer.__unicode__ coerces to a unicode
    string.
    """
    # Test IllegalUseOfScopeReplacer.__unicode__ coerces to a unicode string.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:40:16.597592
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    #raise NotImplementedError(self.__class__.__name__ + '.__call__')

# Generated at 2022-06-12 07:40:19.217065
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    a = IllegalUseOfScopeReplacer("a", "b")
    assert str(a) == "ScopeReplacer object 'a' was used incorrectly: b"



# Generated at 2022-06-12 07:40:27.580930
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from __future__ import print_function
    import sys
    import bzrlib
    from bzrlib.lazy_import import ScopeReplacer
    # construct object without a default
    obj = ScopeReplacer(globals(), lambda r,s,n: r, 'bzrlib')
    # __setattr__ accesses bzrlib.__init__.__setattr__
    try:
        v = sys.version_info
    except AttributeError:
        print('hello') # silences pychecker warning.
        raise TestSkipped("No sys.version_info in this Python")
    obj.version_info = v
    # __getattribute__ accesses bzrlib.version_info

# Generated at 2022-06-12 07:41:24.029215
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    scope = {}
    def factory(placeholder, scope, name):
        return lambda: 'the real object'
    name = 'myplaceholder'
    placeholder = ScopeReplacer(scope, factory, name)
    assert scope[name] is placeholder
    assert placeholder() == 'the real object'
    assert scope[name]() == 'the real object'
    assert scope[name] is placeholder._real_obj


# Generated at 2022-06-12 07:41:35.082325
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """A unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""

# Generated at 2022-06-12 07:41:47.216514
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    s = {'foo':ScopeReplacer(s, lambda sr,s,n: 42, 'foo')}
    # We have not yet caused the post-import of foo, so it should still be
    # a replacement object.
    assert isinstance(s['foo'], ScopeReplacer)
    # Attempting to access an attribute should fail because it has not been
    # created yet.

# Generated at 2022-06-12 07:41:56.826918
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class FakeScope:
        _name = None
        def __init__(self):
            self._obj = None
        def __setitem__(self, name, obj):
            assert name == self._name
            self._obj = obj
        def __getitem__(self, name):
            assert name == self._name
            return self._obj

    def fake_factory(_self, scope, name):
        return 'fake import'

    scope = FakeScope()
    scope._name = 'test_name'
    replacer = ScopeReplacer(scope, fake_factory, scope._name)
    orig = replacer._real_obj
    assert orig is None
    replacer.__setattr__('spam', 2)
    assert scope['test_name'] is replacer # Not replaced yet

# Generated at 2022-06-12 07:42:03.453845
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    r = ScopeReplacer(globals(), lambda s,sc,n:None, 'test_ScopeReplacer___setattr___r')
    tmp = r
    r._should_proxy = False
    r.foo = 'bar'

# Generated at 2022-06-12 07:42:07.194483
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """:py:meth:`IllegalUseOfScopeReplacer.__str__` should return a str object
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-12 07:42:14.464134
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.blackbox import ExternalBase

    class TestCase(ExternalBase):
        """Test for method __setattr__ of class ScopeReplacer"""

        def test_setattr(self):
            tree = self.make_branch_and_tree('.')
            self.build_tree(['a'])
            tree.add('a')

            tree.commit('wibble')
            self.assertLength(1, tree.branch.repository.all_revision_ids())

# Generated at 2022-06-12 07:42:17.729777
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # The class has __unicode__ so no need to check that
    e = IllegalUseOfScopeReplacer('name', 'msg')
    unicode(e)



# Generated at 2022-06-12 07:42:24.060436
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    scope = {}
    factory = lambda self, scope, name: None
    name = 'foo'
    obj = ScopeReplacer(scope, factory, name)
    def setattr(attr, value):
        return object.__setattr__(obj, attr, value)
    try:
        setattr('_factory', setattr)
        setattr('_real_obj', obj)
        setattr('_name', 'name')
        setattr('_scope', scope)
    except AttributeError:
        pass
    else:
        raise AssertionError('Attribute assignment to ScopeReplacer should be'
            ' forbidden')

# Generated at 2022-06-12 07:42:31.884610
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import re
    r = re.compile('^Unprintable exception IllegalUseOfScopeReplacer: ',
                  re.DOTALL)
    s = IllegalUseOfScopeReplacer(
        'test_IllegalUseOfScopeReplacer___str__', '')
    s.__dict__['foo'] = 'bar'
    s.__dict__['baz'] = 'qux'
    a = str(s)
    assert r.match(a), a
