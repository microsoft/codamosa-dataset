

# Generated at 2022-06-12 07:33:45.580968
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Just check no errors happen"""
    e = IllegalUseOfScopeReplacer("a", "b")
    s = str(e)
    u = unicode(e)


# Generated at 2022-06-12 07:33:50.287772
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    a = IllegalUseOfScopeReplacer('a', 'b', 'c')
    b = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert a == b
    # Check IllegalUseOfScopeReplacer doesn't mess up comparisons with
    # other types
    assert a != 0
    assert a != 'a'
    assert a != [a]



# Generated at 2022-06-12 07:33:58.923969
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test that methods __str__ of class IllegalUseOfScopeReplacer
       are returning the right values.
    """
    name = "some name"
    msg = "some message"
    extra = "some extra info"
    import sys
    if sys.version_info >= (3, 0):
        obj = IllegalUseOfScopeReplacer(name, msg, extra=extra)
        s = "IllegalUseOfScopeReplacer(\"some name\", \"some message\", \"some extra info\")"
    else:
        obj = IllegalUseOfScopeReplacer(name, msg, extra=extra)
        s = "IllegalUseOfScopeReplacer(u'some name', u'some message', u'some extra info')"
    assert(str(obj) == s)

# Generated at 2022-06-12 07:34:07.342503
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    lazy_import(scope, '''
    import bzrlib.lazy_import
    ''')
    assert 'lazy_import' not in scope
    src = ScopeReplacer(scope, lambda sr, s, n: bzrlib.lazy_import, 'lazy_import')
    # should not yet have been called
    assert 'lazy_import' not in scope
    assert isinstance(src, ScopeReplacer)
    src.foo = 'bar'
    assert src.foo == 'bar'
    # should have been resolved
    assert isinstance(scope['lazy_import'], type(bzrlib.lazy_import))
    assert scope['lazy_import'].foo == 'bar'



# Generated at 2022-06-12 07:34:08.774675
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    __traceback_info__ = ['test']

test_ScopeReplacer___setattr__()


# Generated at 2022-06-12 07:34:13.404711
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    s = unicode('foo')
    e = IllegalUseOfScopeReplacer('e', 'foo')
    # Check that s and e are equal
    assert s == unicode(e)

# Generated at 2022-06-12 07:34:18.722217
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    err = IllegalUseOfScopeReplacer('name', 'msg')
    str(err)
    err._preformatted_string = "pre-formatted"
    str(err)
test_IllegalUseOfScopeReplacer___str__.skip = (
    "Cannot test __str__ because it is implemented in C.")



# Generated at 2022-06-12 07:34:27.741730
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import __builtin__
    old_import = __builtin__.__import__
    def wrapped_import(name, *args, **kwargs):
        if name == 'bzrlib.tests.blackbox.test_lazy_import':
            raise RuntimeError("Can't import %s under a scope replacer"
                               % name)
        return old_import(name, *args, **kwargs)
    __builtin__.__import__ = wrapped_import
    # Get the real scope
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    # Force creation of the real objects
    import bzrlib.branch
    import bzrlib.tests.blackbox.test_lazy_import
    # The lazy object will now be replaced

# Generated at 2022-06-12 07:34:34.914969
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should return NotImplemented if other is not of the same class.

    See http://www.python.org/dev/peps/pep-0207/#abstract
    """
    # Call the static method test_equal of the base class.
    from bzrlib.tests.test__equals import TestEqualMixin
    TestEqualMixin.test_equal(IllegalUseOfScopeReplacer,
        IllegalUseOfScopeReplacer('foo', 'bar'))
# End test



# Generated at 2022-06-12 07:34:44.543158
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a string object"""
    e = IllegalUseOfScopeReplacer('a', 'b')
    # We can't assert e.__class__ but we can assert the instance class
    # and the type.
    # This is allowed as a form of compile-time duck typing
    assert e.__class__ is IllegalUseOfScopeReplacer
    assert type(e) is IllegalUseOfScopeReplacer
    assert str(e) == 'a: b'
    assert isinstance(str(e), str)
    assert not isinstance(str(e), unicode)
    # And it must be possible to re-encode to unicode
    assert unicode(str(e), 'utf-8') == unicode(e)


# Generated at 2022-06-12 07:35:01.999085
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import __builtin__

    # If a class is defined here, should we still test it in
    # lazy_import?
    # class A(object): pass
    #
    # It seems we should, because although its definition is in the same
    # module as the test, it is in a different scope - the lazy eval
    # object is responsible for giving that object the correct scope.

    class A(object):
        def __getattribute__(self, attr):
            return 2
        def __call__(self, *args, **kwargs):
            return None

    # get attribute that doesn't exist on the object yet
    lazy = ScopeReplacer(locals(), lambda self, scope, name: A(), 'A')
    assert locals()['A'] is lazy
    assert lazy.dne is 2
    # get attribute that does exist

# Generated at 2022-06-12 07:35:05.605228
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    check_lazy_import()

# Generated at 2022-06-12 07:35:07.893634
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case = ScopeReplacer_TestCase()
    test_case.test_1()


# Generated at 2022-06-12 07:35:13.894228
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    Invoking __unicode__ on an IllegalUseOfScopeReplacer object
    should return a unicode object.
    """
    u = IllegalUseOfScopeReplacer("a", "b")
    should_be_unicode = u.__unicode__()
    assert isinstance(should_be_unicode, unicode)
test_IllegalUseOfScopeReplacer___unicode__.unittest = ['.errors']



# Generated at 2022-06-12 07:35:22.797302
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Check that method __unicode__ of class IllegalUseOfScopeReplacer doesn't raise exceptions"""
    # For every class method 'method_name', we want to check that
    # calling it doesn't raise an exception. Since we don't know what
    # the arguments of method 'method_name' are (and it can be different
    # for each different class) we just call it without any argument.
    # This is a hack, but it works.
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer as C
    c = C('name', 'msg')
    unicode(c)



# Generated at 2022-06-12 07:35:28.835222
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    matchers = [
        DocTestMatcher(
            'obj = object.__getattribute__(self, \'_resolve\')()\n'
            'return setattr(obj, attr, value)'),
        Equals(None)
        ]
    return (
        ParameterList(
            [
                (StringMatcher('attr'), StringMatcher('value'))
                ]
            ),
        ChoiceMatcher(matchers)
        )

# Generated at 2022-06-12 07:35:34.824673
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Ensure that __unicode__ is defined, and is consistent with __str__"""
    e = IllegalUseOfScopeReplacer("name", "msg", "extra")
    u = unicode(e)
    assert isinstance(u, unicode)
    s = str(e)
    assert isinstance(s, str)
    assert u.encode('utf8') == s



# Generated at 2022-06-12 07:35:37.037002
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test = ScopeReplacer(None, None, 'test')
    test.test = 'test'


# Generated at 2022-06-12 07:35:47.762521
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    import sys
    if sys.version_info[0] == 2:
        class Bar(object):
            pass
    else:
        Bar = object
    class Foo(Bar):
        def __call__(self):
            return 'called'
    def replacement_factory(self, scope, name):
        return Foo()
    d = {'Foo':ScopeReplacer}
    exec("lazy_import(d, '''\nimport Foo\n''')", d)
    Foo = d['Foo']
    assert Foo._should_proxy
    ScopeReplacer._should_proxy = False
    to_replace = Foo(d, replacement_factory, 'Foo')
    Foo = d['Foo']
    assert Foo is to_replace
    assert Foo()

# Generated at 2022-06-12 07:35:55.816685
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    old_objects = sys.modules.copy()


# Generated at 2022-06-12 07:36:13.114169
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import scope_replacer_factory
    scope = {}
    scope_replacer_factory()('scope', scope, 'factory')
    def factory(me, scope, name):
        return "Original factory value"
    scope['factory'] = factory
    scope_replacer_factory()('scope', scope, 'foo')
    scope['foo'].__setattr__('bar', 1)
    scope['foo'].__setattr__('bar', 2)

# Generated at 2022-06-12 07:36:22.049280
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def my_function():
        pass

    # Test: call __setattr__ on a ScopeReplacer object (bypass the
    # __getattribute__ call that normally happens before __setattr__)
    def setattr_test():
        obj = ScopeReplacer({}, lambda t, s, n: None, 'obj')
        obj.__setattr__('function', my_function)

    # Test: call __setattr__ with a function object.
    def scope_test():
        scope = {'function': my_function}
        obj = ScopeReplacer(scope, lambda t, s, n: None, 'obj')
        obj.__setattr__('function', my_function)

    # Test: call __setattr__ with a ScopeReplacer object.
    # This should fail, because __setattr__ is not allowed on ScopeReplacer
   

# Generated at 2022-06-12 07:36:28.985498
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from testtools.matchers import HasLength
    from testtools.matchers import MatchesStructure

    from bzrlib.tests.blackbox import ExternalBase

    class TestScopeReplacer(ExternalBase):
        """Black box tests for ScopeReplacer.

        There are no white box tests corresponding to these.
        """

        def test_illegal_use_raises(self):
            """Ensure that illegal uses of ScopeReplacer raise errors"""
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import lazy_import
            import bzrlib
            # There are a number of ways which people could abuse this object,
            # and they will make unit tests harder to write, so lets make sure
            # the errors are raised:
            # 1) an object that tries to replace itself in the scope

# Generated at 2022-06-12 07:36:39.218448
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:36:47.509328
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Check import and initialization (__init__ method)
    from bzrlib.lazy_import import ScopeReplacer
    reload(sys.modules['bzrlib.lazy_import'])
    def __init__(self, _arg_0=None, _arg_1=None, _arg_2=None):
        self._scope = _arg_0
        self._factory = _arg_1
        self._name = _arg_2
        self._real_obj = None
        return
    self = ScopeReplacer()
    # Check calling of method
    def __getattribute__(self, attr):
        obj = object.__getattribute__(self, '_resolve')()
        return getattr(obj, attr)
    _attr = None

# Generated at 2022-06-12 07:36:56.409247
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should always return a unicode object

    The __unicode__ method must return a unicode object. This is verified
    by running __unicode__ through the unicode constructor.
    """
    class MyError(IllegalUseOfScopeReplacer):
        _fmt = 'Error %(name)s'
    e = MyError('foo', 'bar')
    # Verify that __unicode__ returns a unicode object
    u = unicode(e)
    # Verify that __unicode__ is actually used
    e._preformatted_string = 'Error foo'
    u = unicode(e)
    # Verify that the formatted string is used
    e._preformatted_string = None
    u = unicode(e)
    # Verify that the default encoding is used as a fallback
    e._preformatted_string

# Generated at 2022-06-12 07:37:04.995266
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib
    bzrlib.lazy_import(globals(), '''
        import bzrlib.trace
        ''')
    scope = {}
    bzrlib.trace.mutter("hi")
    bzrlib.trace.note("hi")
    bzrlib.trace.error("hi")
    bzrlib.trace.warning("hi")
    bzrlib.trace.deprecated("hi")
    x = ScopeReplacer(scope, lambda s, sc, n: bzrlib.trace, 'bzrlib.trace')
    scope['bzrlib.trace'].mutter("hi")
    scope['bzrlib.trace'].note("hi")
    scope['bzrlib.trace'].error("hi")

# Generated at 2022-06-12 07:37:13.937930
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    err = IllegalUseOfScopeReplacer('name', 'msg')
    got = unicode(err)
    # Test that the string is unicode
    assert isinstance(got, unicode)
    assert got == u"ScopeReplacer object 'name' was used incorrectly: msg"
    err = IllegalUseOfScopeReplacer('name', 'msg', 'more')
    got = unicode(err)
    # Test that the string is unicode
    assert isinstance(got, unicode)
    assert got == u"ScopeReplacer object 'name' was used incorrectly: msg: more"

# Generated at 2022-06-12 07:37:19.478390
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(e, Exception)
    assert isinstance(e, IllegalUseOfScopeReplacer)
    assert isinstance(unicode(e), unicode)
    assert isinstance(str(e), str)
    #__str__
    #__repr__
    #__eq__
    pass



# Generated at 2022-06-12 07:37:30.383398
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """The __unicode__ of IllegalUseOfScopeReplacer() should return a unicode string.

    Note: This test is not ideal because we are testing the formatting code
    of Exception, not IllegalUseOfScopeReplacer. However, that is what we
    currently do in practice.

    It is important to test the formatting code because it will raise
    UnicodeDecodeError if it can't convert its input to a unicode string.
    It is also important to test that the formatting has good error
    recovery.

    In future, we may deprecate the _fmt attribute and make
    IllegalUseOfScopeReplacer subclass from format-string-exception, such
    as ValueError (which is a subclass of Exception) and we won't need to
    test this formatting code.
    """

# Generated at 2022-06-12 07:37:48.014159
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Basic sanity test. We really need to work out how to test these
    # things better
    class Foo(object):
        def __call__(self):
            return "yes"
    scope = {}
    lazy_obj = ScopeReplacer(scope, Foo, 'x')
    assert lazy_obj() == "yes"



# Generated at 2022-06-12 07:37:50.629515
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Return a string."""
    e = IllegalUseOfScopeReplacer('self', 'msg', 'extra')
    assert isinstance(str(e), str)


# Generated at 2022-06-12 07:37:58.180223
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    from bzrlib import (
        import_module,
        )
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import features

    def factory(self, scope, name):
        # This factory is already imported, so we must force
        # re-evaluation to ensure the lazy import works.
        # This is a bit of a hack - but we want to test the
        # bzrlib implementation details, not general function
        # proxying.
        mod = import_module(f_module)
        return reload(mod)

    if not features.lazy_import_is_available():
        raise TestNotApplicable("Lazy import is not available")

    #

# Generated at 2022-06-12 07:37:58.802070
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    pass

# Generated at 2022-06-12 07:38:04.098213
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # TODO: RBC 20060808 get this to use the gettext catalog
    assert str(e) == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-12 07:38:09.133316
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import

    class Test(bzrlib.lazy_import.ScopeReplacer):

        def __init__(self):
            bzrlib.lazy_import.ScopeReplacer.__init__(self, scope={},
                factory=lambda self, scope, name: self, name="name")


# Generated at 2022-06-12 07:38:18.097746
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    cls = ScopeReplacer
    obj = cls({}, lambda x, y, z: 1, 'foo')
    obj._should_proxy = True

    # check that a get of an attr on a proxy just proxies to the
    # real_obj
    def check(attr, value):
        real_obj = object.__getattribute__(obj, '_real_obj')
        real_obj.__setattr__(attr, value)
        object.__getattribute__(obj, '_resolve')()
        got = getattr(obj, attr)
        if got != value:
            raise AssertionError("got = %r != %r = value" % (got, value))
    check('foo', 'foo')
    check('bar', 42)



# Generated at 2022-06-12 07:38:28.601780
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self):
    
    __unicode__ should return a unicode object, and should handle
    exceptions well.
    """
    import bzrlib.tests
    bzrlib.tests.init()
    from bzrlib.i18n import gettext
    from bzrlib.i18n import gettext_with_fallback
    from bzrlib.i18n import set_localizer
    from bzrlib.i18n import TranslationContext

    # Try an unset localizer, then one that always fails, then one
    # that doesn't but doesn't have the message, and then one that
    # does.  These tests should give us coverage over all the cases
    # that will be hit.
    got = IllegalUseOfScopeReplacer("foo", "bar").__unicode__()


# Generated at 2022-06-12 07:38:38.996523
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global test_ScopeReplacer___call__  # silence pyflakes
    test_ScopeReplacer___call__ = None
    from bzrlib import tests
    tests.SyntheticWin32Stack(
        [('test_ScopeReplacer___call__.py', 10, 'func',
          ('self', 'arg1', 'arg2', 'kw1'),
          ('arg1', 'arg2', 'kw1')),
         ('test_ScopeReplacer___call__.py', 11, 'func',
          ('self', 'arg1', 'arg2', 'kw1'),
          ('arg1', 'arg2', 'kw1'))]
        ).get_stack(test_ScopeReplacer___call__)



# Generated at 2022-06-12 07:38:49.849312
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    s = IllegalUseOfScopeReplacer(
        name='name', msg='msg', extra=None).__str__()
    expected = 'ScopeReplacer object \'name\' was used incorrectly: msg'
    assert isinstance(s, str), "%r is not a str" % s
    assert s == expected, \
            "s = %r, expected %r" % (s, expected)
    # ... and test that it is ascii
    assert isinstance(s, str), "%r is not a str" % s
    try:
        s.decode('us-ascii')
    except UnicodeDecodeError:
        raise AssertionError("__str__ should be pure ascii")



# Generated at 2022-06-12 07:39:06.590150
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer._format should return a unicode object"""
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    text = obj._format()
    if isinstance(text, str):
        # Default decoding is identity
        text = text.decode('ascii')
    elif not isinstance(text, unicode):
        text = unicode(text)
    return text



# Generated at 2022-06-12 07:39:09.010308
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = ScopeReplacer({}, lambda s, s2, n: s, 'x')
    print(obj())



# Generated at 2022-06-12 07:39:12.082942
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test for method __setattr__ of class ScopeReplacer"""
    obj = ScopeReplacer({}, lambda self, scope, name: None, '')
    obj.__setattr__('attr', 'value')

# Generated at 2022-06-12 07:39:22.317340
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import (
        IllegalUseOfScopeReplacer,
        ScopeReplacer,
        )
    class Test(TestCase):
        def setUp(self):
            # Check for the use of illegal ScopeReplacer objects
            # by tracking the creation of them.
            self._created = []
            self._old_create = ScopeReplacer.__new__
            def _create_tracked(cls, scope, factory, name):
                obj = self._old_create(cls, scope, factory, name)
                self._created.append(hash(obj))
                return obj
            ScopeReplacer.__new__ = classmethod(_create_tracked)
        def tearDown(self):
            # Restore the original object creation method
            ScopeReplacer.__

# Generated at 2022-06-12 07:39:31.133595
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Tests the method IllegalUseOfScopeReplacer.__str__"""
    i = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str_value = 'ScopeReplacer object \'name\'' \
        ' was used incorrectly: msg: extra'
    assert isinstance(str_value, str), 'Not expecting unicode'
    assert str_value == str(i), 'Unexpected str representation of i'
    u = unicode(i)
    assert isinstance(u, unicode), 'Expecting unicode'
    assert u == unicode(str_value, 'utf8'), 'Unexpected unicode representation of i'



# Generated at 2022-06-12 07:39:39.035054
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit tests for method __str__ of class IllegalUseOfScopeReplacer"""

# Generated at 2022-06-12 07:39:45.262445
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    x = IllegalUseOfScopeReplacer("name", "message")
    __traceback_info__ = x
    # round trip through str()
    str(x)
    # round trip through unicode()
    unicode(x)
    # for coverage
    x = UnicodeException()
    x.__unicode__()



# Generated at 2022-06-12 07:39:47.487946
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__: a test"""
    obj = IllegalUseOfScopeReplacer('name', 'msg')
    unicode(obj)



# Generated at 2022-06-12 07:39:49.116746
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    __tracebackhide__ = True
    raise TestNotApplicable("Too difficult to test __setattr__")



# Generated at 2022-06-12 07:39:51.488552
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    scope = {}
    object = ScopeReplacer(scope, lambda s,x,y:x, 'object')
    assert object(1,2,3) == 'object'
    assert not object



# Generated at 2022-06-12 07:40:07.229332
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    raise NotImplementedError


# Generated at 2022-06-12 07:40:09.309924
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Implementation of test_ScopeReplacer___setattr__()
    raise NotImplementedError


# Generated at 2022-06-12 07:40:17.649156
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Test(ScopeReplacer):
        '''Test class for ScopeReplacer'''
        def __init__(self, scope, factory, name):
            super(Test, self).__init__(scope, factory, name)
        def __getitem__(self, key):
            scope = object.__getattribute__(self, '_scope')
            obj = scope['obj']
            return obj[key]
    def factory(self, scope, name):
        scope['obj'] = [1, 2, 3]
        return None

    scope = {}
    test = Test(scope, factory, 'test')
    test[1]
    assert scope['obj'] == [1, 2, 3]
test_ScopeReplacer___getattribute__()

# Generated at 2022-06-12 07:40:26.267870
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import as _mod_lazy_import
    globals = {}
    _mod_lazy_import.lazy_import(globals, """
from bzrlib import (
    errors,
    osutils,
    branch,
    )
import bzrlib.branch
""")
    bzrlib = globals['bzrlib']
    assert bzrlib._name == 'bzrlib'
    globals['bzrlib'] = bzrlib
    try:
        bzrlib.osutils = True
        py.test.fail("Setting attribute 'osutils' of class ScopeReplacer must"
                     " raise IllegalUseOfScopeReplacer")
    except _mod_lazy_import.IllegalUseOfScopeReplacer:
        pass

# Generated at 2022-06-12 07:40:28.487139
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
  """Unit test for method __setattr__ of class ScopeReplacer"""
  pass


# Generated at 2022-06-12 07:40:35.655912
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import (
        TestNotApplicable,
        TestSkipped,
        )

# Generated at 2022-06-12 07:40:43.634388
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    __tracebackhide__ = True
    class BaseException(Exception): pass
    class SubException(BaseException): pass
    # If a message is ASCII:
    e = IllegalUseOfScopeReplacer(name='foo',
                                  msg='bar')
    s = str(e)
    u = unicode(e)
    assert isinstance(s, str)
    assert isinstance(u, unicode)
    assert u.encode('ascii') == s
    # If a message is Unicode:
    e = IllegalUseOfScopeReplacer(name='foo',
                                  msg=u'b\xe2r')
    s = str(e)
    u = unicode(e)
    assert isinstance(s, str)
    assert isinstance(u, unicode)
    assert u.encode('utf-8') == s

# Generated at 2022-06-12 07:40:46.297765
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should be reversible"""
    try:
        raise IllegalUseOfScopeReplacer('X', 'Y')
    except IllegalUseOfScopeReplacer as e:
        s = str(e)
        d = eval(s)
        assert d == e



# Generated at 2022-06-12 07:40:50.811147
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """It should convert an IllegalUseOfScopeReplacer to unicode."""
    import warnings
    warnings.filterwarnings('ignore', '', DeprecationWarning)
    e = IllegalUseOfScopeReplacer(name='foo', msg='bar')
    unicode(e)



# Generated at 2022-06-12 07:40:54.282689
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode string"""
    e = IllegalUseOfScopeReplacer('a', 'b', 'c')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:41:14.758594
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import (
        lazy_import,
        )
    import bzrlib.lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        )
    ''')
    # Call the __setattr__ method, passing it a ScopeReplacer object as the
    # first argument (self), an arbitrary attribute name as the second argument
    # (attr), and a real object as the third argument (value)
    return bzrlib.lazy_import.ScopeReplacer.__setattr__(bzrlib, 'lz', errors)

# Generated at 2022-06-12 07:41:20.060931
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Check that we can call a lazy object that does not yet exist
    def factory(scope_replacer, scope, name):
        return None
    scope = {'name': 'value'}
    replacer = ScopeReplacer(scope, factory, 'name')
    replacer()


# Generated at 2022-06-12 07:41:26.050880
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(IllegalUseOfScopeReplacer([arg])) -> unicode"""
    except_obj = IllegalUseOfScopeReplacer('name', 'msg')
    u = except_obj.__unicode__() # __method__(<ClassName instance>)
    assert(isinstance(u, unicode))
    assert(u == u"IllegalUseOfScopeReplacer object 'name' was used incorrectly: msg")

    except_obj = IllegalUseOfScopeReplacer(u'name', u'msg')
    u = except_obj.__unicode__() # __method__(<ClassName instance>)
    assert(isinstance(u, unicode))
    assert(u == u"IllegalUseOfScopeReplacer object 'name' was used incorrectly: msg")


# Generated at 2022-06-12 07:41:36.588198
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import (
        test_lazy_import,
        )
    from bzrlib.lazy_import import (
        ScopeReplacer,
        IllegalUseOfScopeReplacer,
        )
    import bzrlib

    # Check that __setattr__ fails when proxying is not allowed
    def factory():
        return object()

    scope = {}
    t = ScopeReplacer(scope, factory, 'module')
    scope['module'] = t
    obj = object()

    ScopeReplacer._should_proxy = False

# Generated at 2022-06-12 07:41:47.945341
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test correct exceptions raised when __setattr__ used incorrectly"""
    lazy_import(globals(), 'bzrlib.lazy_import')
    scope = {}
    obj = ScopeReplacer(scope, lambda x, y, z: x, 'obj')
    scope['obj'] = obj
    # Test for IllegalUseOfScopeReplacer with IllegalUseOfScopeReplacer
    # subclasses.

# Generated at 2022-06-12 07:41:57.302817
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """test_IllegalUseOfScopeReplacer___unicode__()

    Test the IllegalUseOfScopeReplacer.__unicode__() method.
    """
    import sys
    from bzrlib.tests import TestSkipped

    # make sure __unicode__() works on an exception that is not subclassed
    try:
        raise Exception('test-message')
    except Exception as e:
        s = unicode(e)
        if isinstance(s, unicode):
            return
        sys.stderr.write('skipped: wrong type for unicode(): %r' % s)
        raise TestSkipped('wrong type for unicode(): %r' % s)

    # make sure __unicode__() works on an exception that is subclassed

# Generated at 2022-06-12 07:41:59.848014
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer("my.name", "my message")
    assert str(e) == "my message"



# Generated at 2022-06-12 07:42:02.395886
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    exc = IllegalUseOfScopeReplacer('test', 'msg', 'extra')
    str(exc)



# Generated at 2022-06-12 07:42:10.691028
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    globals()["bzrlib"] = bzrlib.lazy_import.ScopeReplacer(globals(),
        lambda lazy, scope, name: object(), "bzrlib")
    old_bzrlib = globals()["bzrlib"]
    globals()["bzrlib"] = bzrlib.lazy_import.ScopeReplacer(globals(),
        lambda lazy, scope, name: object(), "bzrlib")
    try:
        # Call the method here
        globals()["bzrlib"]()
    except IllegalUseOfScopeReplacer:
        return True
    finally:
        globals()["bzrlib"] = old_bzrlib
    return False

# Generated at 2022-06-12 07:42:12.944260
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ does not fail in sloppy mode."""
    LazyImportError('foo', 'foo')



# Generated at 2022-06-12 07:42:39.385691
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase

    class Test(TestCase):
        """Test class for IllegalUseOfScopeReplacer."""

        def test_IllegalUseOfScopeReplacer___str__(self):
            s = 'goober'
            n = IllegalUseOfScopeReplacer('name', s)
            self.assertEqual(str(n), "'name' was used incorrectly: goober")

    Test().test_IllegalUseOfScopeReplacer___str__()


# Generated at 2022-06-12 07:42:50.771404
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class FakeModule(object):
        def __init__(self, name):
            self.name = name
        def __call__(self, *args, **kwargs):
            return ("%s called with args %r and kwargs %r"
                    % (self.name, args, kwargs))
    class TestScopeReplacer(TestCase):
        """Test the key methods of ScopeReplacer"""
        def setUp(self):
            self.scope = {}
            self.replacer = ScopeReplacer(self.scope, FakeModule, "name")
        def test_call_empty(self):
            self.assertEqual("name called with args () and kwargs {}",
                             self.replacer())

    loader = TestUtil.TestLoader()

# Generated at 2022-06-12 07:42:57.396385
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import tests as lazy_import_tests
    from bzrlib.lazy_import import ScopeReplacer

    self = ScopeReplacer(
        scope={},
        factory=lazy_import_tests.factory_examples.test_factory,
        name='foo',
        )
    val = py.test.mark.xfail(self, "NYI: call proxy")
    return val

# Generated at 2022-06-12 07:43:06.752464
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # TODO: This test will currently fail since it should evaluate to
    # (True, None) but evaluates to (None, None).
    # This is due to a bug in the ScopeReplacer.__call__ method.
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class C(object):
        pass
    scope = {}
    factory = lambda _lazy_import_proxy, _scope, _name: C
    name = 'a'
    _lazy_import_proxy = ScopeReplacer(scope, factory, name)
    assert (_lazy_import_proxy(), None) == (C(), None)


_old_scope_replacer_class = ScopeReplacer



# Generated at 2022-06-12 07:43:18.446774
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method IllegalUseOfScopeReplacer.__str__"""
    # Constructors
    # __init__(_lazy_import.IllegalUseOfScopeReplacer self, _lazy_import.str name, _lazy_import.str msg, _lazy_import.object extra=None) -> None
    # __init__(_lazy_import.IllegalUseOfScopeReplacer self) -> None
    # __init__(_lazy_import.IllegalUseOfScopeReplacer self, _lazy_import.object args, _lazy_import.object kwargs) -> None
    # __init__(_lazy_import.IllegalUseOfScopeReplacer self, _lazy_import.object value) -> None
    # __init__(_lazy_import.IllegalUseOfScopeReplacer self, _lazy_import.

# Generated at 2022-06-12 07:43:21.291984
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from itertools import count
    l = []
    def factory(self, scope, name):
        return lambda: l.append(count().next())
    sr = ScopeReplacer({}, factory, 'foo')
    sr()
    sr()
    sr()
    assert l == [0, 1, 2]



# Generated at 2022-06-12 07:43:27.901409
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should always return 'str'"""
    s = IllegalUseOfScopeReplacer('foo', 'bar')
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert s == e
    assert isinstance(str(s), str)
    assert isinstance(str(e), str)
    assert_not_equal_idempotent(str, s, e)
