

# Generated at 2022-06-12 07:34:00.467789
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    s1 = IllegalUseOfScopeReplacer('name', 'msg')
    s2 = IllegalUseOfScopeReplacer('name', 'msg')
    assert (s1 == s2) is True
    assert (s1 != s2) is False

# Generated at 2022-06-12 07:34:09.213000
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Tests of IllegalUseOfScopeReplacer._get_format_string
    and __unicode__
    """
    x = IllegalUseOfScopeReplacer('deadbeef', 'I forgot to change the gear')

    # class variable
    assert isinstance(x._fmt, str)
    assert isinstance(x._get_format_string(), unicode)

    # instance variable
    x._fmt = 'We should have taken the %(name)s to %(city)s instead'
    x.city = 'Brisbane'
    assert x._get_format_string() == u'We should have taken the %(name)s to %(city)s instead'

    # __str__ and __unicode__
    assert x.__str__() == 'We should have taken the deadbeef to Brisbane instead'
    assert x.__

# Generated at 2022-06-12 07:34:15.708351
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer

    __str__ must return a str object, not a unicode object.
    """
    # bzr: ERROR: IllegalUseOfScopeReplacer object 'str' was used incorrectly: foo
    e = IllegalUseOfScopeReplacer('str', 'foo')
    s = str(e)
    assert isinstance(s, str)
    assert s.decode('ascii') == unicode(e)



# Generated at 2022-06-12 07:34:24.038407
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """When you pass the following unicode string to the constructor for
    IllegalUseOfScopeReplacer, the __unicode__ method should return::
        u'ScopeReplacer object u\'bzr/revisiontree\' was used incorrectly: check_not_reserved'
    """
    s = u'bzr/revisiontree'
    e = IllegalUseOfScopeReplacer(s, u'check_not_reserved')
    # Because we are overriding __unicode__, __str__ is not called
    # automatically.

# Generated at 2022-06-12 07:34:27.034609
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    instance = IllegalUseOfScopeReplacer('name', 'msg')
    # The __str__ method of IllegalUseOfScopeReplacer should return a str
    # instance
    str(instance)


# Generated at 2022-06-12 07:34:37.349294
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class StringAdder(object):
        def __init__(self, offset):
            self.offset = offset
        def add_offset(self, value):
            return value + self.offset
    scope = {}
    name = 'adder'
    scope_replacer = ScopeReplacer(scope, StringAdder, name)
    self.assertEqual(None, scope_replacer._real_obj)
    self.assertEqual(None, scope[name])
    self.assertIs(scope_replacer, scope[name])
    self.assertEqual(3, scope_replacer.add_offset(1))
    self.assertEqual(3, scope_replacer(2))
    self.assertIs(scope[name], scope_replacer._real_obj)

# Generated at 2022-06-12 07:34:42.198310
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def dummy_factory(temp_obj, scope, name):
        return True
    scope = {}
    name = 'test_ScopeReplacer___getattribute__'
    obj = ScopeReplacer(scope, dummy_factory, name)
    assert scope == {name: obj}
    assert not scope[name]
    assert scope[name] is True
    assert scope == {name: True}

# Generated at 2022-06-12 07:34:51.101903
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test method __setattr__ of class ScopeReplacer"""
    from bzrlib.tests import TestCase
    from StringIO import StringIO
    from bzrlib.config import ConfigObj
    from bzrlib.config import _ConfigObj_patched_for_testing
    from bzrlib.config import _ConfigObj_patched_for_testing2
    from bzrlib.tests.per_config import TestCaseWithConfig

    class TestScopeReplacer(TestCase):

        def setUp(self):
            super(TestScopeReplacer, self).setUp()

            # Set up a test object
            self.obj = _ConfigObj_patched_for_testing()

            # Set up a scope
            self.scope = {}

# Generated at 2022-06-12 07:34:58.569919
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class C(object):
        def __init__(self, value):
            self._value = value

    class Factory(object):
        def __init__(self, value):
            self._value = value

        def __call__(self, obj, scope, name):
            return C(self._value)

    class Imp:
        pass

    f = Factory(7)
    s = ScopeReplacer(Imp.__dict__, f, 'c')
    # does it return the expected value?
    assert s._value == 7
    # does it resolve to a new object.
    assert s is not Imp.c


# Generated at 2022-06-12 07:35:00.729502
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    import doctest
    doctest.DocTestSuite(IllegalUseOfScopeReplacer._get_format_string)



# Generated at 2022-06-12 07:35:25.122873
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class Foo(object):
        def __init__(self):
            self.a = 0
        def __setattr__(self, attr, value):
            self.a = 1
            return setattr(self, attr, value)
    def factory(self, scope, name):
        return Foo()
    var_name = 'test_var'
    local_namespace = dict()
    # var should be replaced by itself on first setattr
    var = ScopeReplacer(local_namespace, factory, var_name)
    # We can't test for importing stuff here, as we're not sure what our
    # current module is.
    # should raise because it is a real object now.

# Generated at 2022-06-12 07:35:32.072183
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    class Test:
        def __init__(self, n):
            self.n = n

        def __call__(self, x, y, z=3):
            return self.n + x + y + int(z)

    def factory(proxy, scope, name):
        # Test should be the same as the Test class defined above.
        Test = Test
        return Test(2)

    results = []
    # Test basic operation
    sr = ScopeReplacer(results, factory, 'Test')
    assert results == []
    assert results == [sr]
    assert results == [sr]
    assert results[0].n == 2
    assert results[0](1, 1) == 5
    assert results[0](1, 1, 2) == 6
    # perform all the above checks again to make sure the object is become
    # real at

# Generated at 2022-06-12 07:35:36.038561
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """test_IllegalUseOfScopeReplacer___unicode__"""
    import warnings
    warnings.warn("Tests for method __unicode__ of class IllegalUseOfScopeReplacer are not written")

# Generated at 2022-06-12 07:35:40.199666
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should return a unicode object.
    """
    ex = IllegalUseOfScopeReplacer('name', 'oops')
    u = unicode(ex)
    isinstance(u, unicode)
    ex = IllegalUseOfScopeReplacer('name', 'oops', 'test')
    u = unicode(ex)
    isinstance(u, unicode)
    ex = IllegalUseOfScopeReplacer('name', u'oops\xf8')
    isinstance(unicode(ex), unicode)



# Generated at 2022-06-12 07:35:49.599352
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    import sys
    import os


    # Assign ScopeReplacer to locals
    ScopeReplacer = bzrlib.lazy_import.ScopeReplacer

    # Assign IllegalUseOfScopeReplacer to locals
    IllegalUseOfScopeReplacer = bzrlib.lazy_import.IllegalUseOfScopeReplacer

    # Assign osutils to locals
    osutils = bzrlib.osutils

    # Assign sys to locals
    sys = sys

    # Assign os to locals
    os = os

# Generated at 2022-06-12 07:35:56.885263
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def my_test_function():
        return 42
    class MyClass(object):
        @staticmethod
        def my_test_function():
            return 42
    x = ScopeReplacer(globals(), lambda o, g, n: my_test_function,
        'my_test_function')
    y = ScopeReplacer(globals(), lambda o, g, n: MyClass.my_test_function,
        'MyClass_my_test_function')

# Generated at 2022-06-12 07:36:04.840394
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    '''Unit test for method __setattr__ of class ScopeReplacer'''
    # This test is failing - it's not meant to be run in isolation.
    # See the ScopeReplacer docstring for why.
    # The bzr selftest command tests this interactively by disabling
    # _should_proxy in the ScopeReplace class.
    # If a new exception is added, write a test here.
    # If a new exception is added, and it has custom logic, write a test here.
    # If a new exception is added, and it has no custom logic, do not write a
    # test here. Just adding a bit of text isn't worth unit testing.
    return None
    # from bzrlib.lazy_import import ScopeReplacer
    # def simple_factory(s_r, scope, name):
    #     return

# Generated at 2022-06-12 07:36:08.908517
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # This tests that IllegalUseOfScopeReplacer.__unicode__ works.
    iuosr = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    # The string must be unicode.
    u = iuosr.__unicode__()


# Generated at 2022-06-12 07:36:16.055094
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # As documented in the class docstring, the intent here is to wrap a
    # the given scope in a lazy object, so the following test of setting to
    # a real object should be valid.
    ScopeReplacer._should_proxy = False
    try:
        test_scope = {}
        def test_factory(self, scope, name):
            return 1
        ScopeReplacer(test_scope, test_factory, 'foo')
        test_scope['foo'] = ScopeReplacer(test_scope, test_factory, 'bar')
        test_scope['foo'].bar = 5
        test_scope['foo'].bar == 5
    finally:
        ScopeReplacer._should_proxy = True

# Generated at 2022-06-12 07:36:17.326434
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass


# Generated at 2022-06-12 07:36:37.026401
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    class Factory():
        def __init__(self, scope_replacer, scope, name):
            return (self, scope_replacer, scope, name)
        def __call__(self, *args, **kwargs):
            return (self, args, kwargs)
    scope = {}
    factory = Factory
    name = "a"
    x = ScopeReplacer(scope, factory, name)
    try:
        retval_1 = x('test_0_arg', test='test_1_kw')
        retval_2 = Factory(x, scope, name)('test_0_arg', test='test_1_kw')
    except:
        import traceback
        traceback.print_exc()
        raise

# Generated at 2022-06-12 07:36:46.008225
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    class Error(Exception):
        pass
    class IllegalUseOfScopeReplacerSubclass(IllegalUseOfScopeReplacer):
        pass

    # Use with a format string, with no values other than the default
    e = IllegalUseOfScopeReplacerSubclass(1234, 'error')
    expected = None
    # Check for correct type
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError('Expected %s to return a unicode object'
                             ', but it returned a %s!'
                             % (e.__unicode__, type(u)))
    # Check for a non-default value
    if expected is not None:
        if u != expected:
            raise Assertion

# Generated at 2022-06-12 07:36:57.222978
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class FakeObj(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.called = 0
        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.called += 1
            return 42
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            o = FakeObj()
            scope = {}
            scope['fakeobj'] = o
            scope_replacer = ScopeReplacer(scope, None, 'fakeobj')
            self.assertEqual(42, scope_replacer(7, 12, x=3, y=4))

# Generated at 2022-06-12 07:37:01.161881
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__

    The default implementation of __str__ returns a utf8 encoded string.
    """
    s = IllegalUseOfScopeReplacer('spam', 'eggs').__str__()
    assert isinstance(s, str)



# Generated at 2022-06-12 07:37:07.916734
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """The string representation of an IllegalUseOfScopeReplacer must be
    usable by eval.
    """
    # The string representation of an IllegalUseOfScopeReplacer should be the
    # class name followed by a constructor argument.
    u = IllegalUseOfScopeReplacer('name', 'msg')
    x = eval(str(u))
    assert type(u) is type(x)
    assert u.__dict__ == x.__dict__



# Generated at 2022-06-12 07:37:18.487877
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test for IllegalUseOfScopeReplacer.__str__"""
    import bzrlib
    e = bzrlib.lazy_import.IllegalUseOfScopeReplacer('f', 'q')
    class DerivedException(bzrlib.lazy_import.IllegalUseOfScopeReplacer):
        pass
    d = DerivedException('f2', 'q2')
    e.__dict__['_fmt'] = '%(f)s: %(q)s'
    d.__dict__['_fmt'] = '%(f2)s: %(q2)s'
    assert str(e) == 'f: q'
    assert str(d) == 'f2: q2'
    # Test that attributes that aren't in _fmt are not used

# Generated at 2022-06-12 07:37:29.233995
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    test_scope = locals()
    test_scope['errors'] = ScopeReplacer(test_scope, lambda self, scope, name: \
        errors, 'errors')
    test_scope['osutils'] = ScopeReplacer(test_scope, lambda self, scope, name: \
        osutils, 'osutils')
    test_scope['branch'] = ScopeReplacer(test_scope, lambda self, scope, name: \
        branch, 'branch')
    test_scope['bzrlib'] = ScopeReplacer(test_scope, lambda self, scope, name: \
        bzrlib, 'bzrlib')

# Generated at 2022-06-12 07:37:33.079823
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str object, not unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = e.__str__()
    assert isinstance(s, str), "%s is unicode not str" % (s,)

# Generated at 2022-06-12 07:37:42.381732
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    # test_ScopeReplacer___call__ {{{
    class Foo(object):
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name
    lazy_import(globals(), '''
    from bzrlib.lazy_import import ScopeReplacer
    ''')
    class Test(TestCase):
        def test_basic(self):
            scope = {}
            replacer = ScopeReplacer(scope, lambda self, _scope, _name:
                Foo('Foo'), 'foo')
            self.assertEqual(scope['foo'].get_name(), 'Foo')

# Generated at 2022-06-12 07:37:44.581951
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    raise NotImplementedError

    # test __call__ of ScopeReplacer



# Generated at 2022-06-12 07:38:09.972468
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    test_cases = [
        ("lazy_import(globals(), '''\nfrom bzrlib import (\nerrors,\nosutils,\nbranch,\n)\nimport bzrlib.branch\n''')\n", 'from bzrlib import (\nerrors,\nosutils,\nbranch,\n)\nimport bzrlib.branch\n'),
        ]
    for example, expected_value in test_cases:
        assert(expected_value == encode_ascii(example)), (example,
                                                         expected_value)


# Generated at 2022-06-12 07:38:18.804814
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class _Example(object):
        def _meth(self, arg, kwarg1=None, kwarg2=None, kwarg3=1):
            return (arg, kwarg1, kwarg2, kwarg3)

    scope = {}
    def _factory(self, scope, name):
        return _Example()

    sr = ScopeReplacer(scope, _factory, 'sr')
    self.assertEqual(sr._meth('arg'), ('arg',None,None,1))
    self.assertEqual(sr._meth('arg', kwarg1=2), ('arg',2,None,1))
    self.assertEqual(sr._meth('arg', kwarg2=2), ('arg',None,2,1))

# Generated at 2022-06-12 07:38:29.109298
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.scope as _mod_scope
    _test_ScopeReplacer___setattr___local_scope = {'_mod_scope': _mod_scope}
    def __test__(self, scope, name):
        """Inline factory to replace self."""
        if not name in scope:
            raise IllegalUseOfScopeReplacer(name, "A new name was"
                " expected, double check the name and order of"
                " parameters")
        return scope[name]
    _test_ScopeReplacer___setattr___local_scope['__test__'] = __test__
    _test_ScopeReplacer___setattr___local_scope['__test__'].__dict__

# Generated at 2022-06-12 07:38:33.485757
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test of IllegalUseOfScopeReplacer.__unicode__
    """
    exc = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    # This should not raise an exception
    unicode(exc)



# Generated at 2022-06-12 07:38:35.106103
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    a = ScopeReplacer(
        None,
        None,
        None,
        )

# Generated at 2022-06-12 07:38:39.403225
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    name = 'name'
    value = 'value'
    globals_ = {name: value}
    replacer = ScopeReplacer(globals_, lambda self, scope, varname: value,
                             name)
    assert replacer.__getattribute__(name) == value

# Generated at 2022-06-12 07:38:43.080554
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer should return a printable string"""
    e = IllegalUseOfScopeReplacer('my_name', 'my_msg', 'my_extra')
    str(e)



# Generated at 2022-06-12 07:38:52.813747
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    locals = {'scope':None, 'factory':None, 'name':None}
    def real_obj_called(scope, name):
        locals['scope'] = scope
        locals['name'] = name
        return locals['factory'](scope, name)
    def factory(scope, name):
        locals['scope'] = scope
        locals['name'] = name
        return locals['factory'](scope, name)
    locals['factory'] = lambda scope, name: None
    obj = ScopeReplacer(locals, factory, 'x')
    result = obj(1, 2, 3)
    expected = None
    assert locals['scope'] == locals
    assert locals['name'] == 'x'
    assert result == expected
    locals['factory'] = lambda scope, name: 7

# Generated at 2022-06-12 07:38:54.829027
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    replacer = ScopeReplacer(globals(),
        lambda self, scope, name: self, 'bzrlib')
    setattr(bzrlib, 'errors', 'foo')


# Unit test case for class ScopeReplacer

# Generated at 2022-06-12 07:39:02.170996
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    doctest.run_docstring_examples(ScopeReplacer.__call__, globals())

    def _factory(replacer, scope, name):
        return 2*3

    class Scope(object):

        def __init__(self):
            self.__dict__ = self
    r = ScopeReplacer(Scope(), _factory, 'foo')
    s = Scope()
    assert r(s) == 6
    assert s.foo == r


# Generated at 2022-06-12 07:39:33.529826
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.features import Feature

    feature = Feature()
    feature.load_feature()

    with feature.lock:
        feature.scope[feature.name] = feature.replacer
        setattr(replacer, 'foo', 'bar')



# Generated at 2022-06-12 07:39:38.206638
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    x = IllegalUseOfScopeReplacer("test-value", "this is the message", 42)
    u = x.__unicode__()
    eq = 'ScopeReplacer object "test-value" was used incorrectly: this ' \
         'is the message: 42'
    assert u == eq, '%r != %r' % (u, eq)

# Generated at 2022-06-12 07:39:49.077750
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import trace
    ''')
    global called_flag, trace_attr
    called_flag = False
    def factory(self, scope, name):
        global called_flag, trace_attr
        called_flag = True
        return scope[name]
    scope = {}
    scope['trace'] = ScopeReplacer(scope, factory, 'trace')
    scope['trace']._resolve()
    assert(called_flag == False)
    called_flag = False
    trace_attr = scope['trace']
    assert(called_flag == False)
    called_flag = False
    scope['trace']._resolve()
    assert(called_flag == False)
    return None



# Generated at 2022-06-12 07:39:54.675368
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Default case
    import bzrlib
    def bzrlib_builtin(__self, __scope, __name):
        import bzrlib; return bzrlib.builtin
    foo = ScopeReplacer(globals(), bzrlib_builtin, 'foo')
    bzrlib.__dict__['builtin'] = 42
    assert foo.__dict__['_resolve']() == bzrlib.__dict__['builtin']



# Generated at 2022-06-12 07:40:04.307931
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class mock_object:
        def __init__(self):
            self.called = []
        def __getattribute__(self, attr):
            obj = getattr(super(mock_object, self), attr)
            self.called += [('__getattribute__', attr)]
            return obj
        def __getattr__(self, attr):
            self.called += [('__getattr__', attr)]
    class mock_factory:
        def __init__(self, obj):
            self.obj = obj
        def __call__(self, replacer, scope, name):
            return self.obj
    obj1 = mock_object()
    obj2 = mock_object()
    obj1.attr1 = obj2
    obj2.attr2 = 'bar'
    scope = {}

# Generated at 2022-06-12 07:40:15.645082
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import bzrlib
    from bzrlib.tests.lazy_import_helper import (
        FakeModule,
        FakeMethod,
        )

    class DummyClass(object):
        def __init__(self, n):
            self.n = n

    class TestScopeReplacer(TestCase):

        def test___call__(self):
            fake_mod = FakeModule('lazy_import_helper',
                {'DummyClass':DummyClass})
            replacer = ScopeReplacer(bzrlib.__dict__, fake_mod,
                                     'lazy_import_helper')
            dc = replacer(1)
            self.assertEqual(dc.n, 1)

    # Unit test for method __getattribute__ of class ScopeRepl

# Generated at 2022-06-12 07:40:22.030161
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    r"""__unicode__ should return a unicode object if __str__ is a str object

    >>> IllegalUseOfScopeReplacer('', '', '')
    IllegalUseOfScopeReplacer('')

    >>> IllegalUseOfScopeReplacer('abc', 'abcdef', '')
    IllegalUseOfScopeReplacer('abc')

    >>> IllegalUseOfScopeReplacer('abc', 'abcdef', 'abcdefghi')
    IllegalUseOfScopeReplacer('abc')

    >>> try: raise IllegalUseOfScopeReplacer('abc', 'abcdef', 'abcdefghi')
    ... except IllegalUseOfScopeReplacer: pass

    """


# Generated at 2022-06-12 07:40:24.805919
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestSkipped
    raise TestSkipped("Needs to be written")

# Generated at 2022-06-12 07:40:30.029040
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Calling __str__ on IllegalUseOfScopeReplacer works"""
    x = IllegalUseOfScopeReplacer('foo', 'bar')
    str(x)
    unicode(x)
    repr(x)


__all__ = ['lazy_import', 'scope_replacer', 'lazy_wrapper']



# Generated at 2022-06-12 07:40:35.655267
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test that IllegalUseOfScopeReplacer.__unicode__() works."""
    e = IllegalUseOfScopeReplacer('name', "msg", extra="extra")
    u = unicode(e)
    assert isinstance(u, unicode), "__unicode__ returned a %s, a str." \
        % type(u)
    assert u == u"ScopeReplacer object 'name' was used incorrectly:" \
                    " msg: extra"

# Generated at 2022-06-12 07:41:39.537740
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from random import randint

    from bzrlib.tests import (
        TestCase,
        )
    from bzrlib.lazy_import import lazy_import

    class FakeModule(object):

        def __init__(self):
            self.counter = 0

        def counter_incr(self, *args, **kwargs):
            self.counter += 1
            return self.counter

    def module_factory(self, scope, name):
        """Fake module factory."""
        fake_module = object.__getattribute__(self, '_real_obj')
        if fake_module is None:
            fake_module = FakeModule()
            object.__setattr__(self, '_real_obj', fake_module)
        return fake_module


# Generated at 2022-06-12 07:41:42.354540
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global x
    x = 1
    lazy_import(globals(), 'x = 2')
    assert x == 2
    x = x + 1
    assert x == 3
    assert x == 3



# Generated at 2022-06-12 07:41:53.584851
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """_ScopeReplacer__setattr__ tests

    XXX: This code is untested, and the primary reason for
    not testing it is that it is not clear how to test it.
    This is because we need to test that the object is being
    set on the correct place, and that place is the globals
    object, and we want to test that this happens in the
    real bzrlib package, not in some other place.
    """
    class LazyInitObject(LazyImportObject):
        """Simple class for use by lazy init tests.

        This class does not have to be related to lazy_import, except
        that it is referenced by the tests below.
        """
        def __init__(self):
            pass
    from bzrlib import lazy_import
    # XXX: None of this works yet, because the tests are not being run

# Generated at 2022-06-12 07:41:59.670330
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import _get_lazy_import_scope_replacer
    try:
        _get_lazy_import_scope_replacer('a').b
    except IllegalUseOfScopeReplacer as e:
        str(e)
        unicode(e)
        e.__str__()
        e.__unicode__()



# Generated at 2022-06-12 07:42:08.976064
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import tempfile
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 07:42:11.940471
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    l = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(l)
    assert isinstance(s, str)

# Generated at 2022-06-12 07:42:17.682441
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('e', 'msg', None)
    u = u'e was used incorrectly: msg'
    assert_equal(unicode(e), u)
    e = IllegalUseOfScopeReplacer('e', 'msg', 'extra')
    u = u'e was used incorrectly: msg: extra'
    assert_equal(unicode(e), u)


# Generated at 2022-06-12 07:42:21.094514
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """ScopeReplacer.__call__: invokes function"""
    def the_func():
        return "the_func"
    obj = ScopeReplacer({}, lambda r: r, "the_func")
    result = obj()
    assert result == "the_func", result


# Generated at 2022-06-12 07:42:23.422402
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import types
    def f(): pass
    scope = {}
    scope_replacer = ScopeReplacer(scope, types.FunctionType, 'f')
    scope_replacer()


# Generated at 2022-06-12 07:42:28.940966
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() returns a byte string"""
    e = IllegalUseOfScopeReplacer("name", "msg")
    s = str(e)
    # Check that __str__() returns a byte string.
    assert(isinstance(s, str))
    # Check that __str__() returns a str, not a unicode.
    assert(not isinstance(s, unicode))