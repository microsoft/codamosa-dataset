

# Generated at 2022-06-12 07:33:48.381855
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # 'IllegalUseOfScopeReplacer' objects do not implement __unicode__, so the
    # superclass's implementation is used.
    obj = IllegalUseOfScopeReplacer('a', 'b', 'c')
    result = unicode(obj)
    # We can't do too much here, just make sure the prefix and suffix are
    # present.
    assert result.startswith('Unprintable exception IllegalUseOfScopeReplacer:')
    assert result.endswith('dict={\'extra\': \'c\', \'msg\': \'b\', \'name\': \'a\'}')


# Generated at 2022-06-12 07:33:57.585771
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer() constructor for the module 'bzrlib.foo.bar'"""
    path = module_path = ['bzrlib', 'foo', 'bar']
    name = 'bar'
    scope = {}
    member = None
    children = {}
    # Normal constructor (used for top level module)
    class test_class(ImportReplacer):
        pass
    replacer = test_class(scope, name, module_path, member, children)
    assert scope[name] is replacer
    # Ensure it behaves like an import replacer
    replacer = scope[name]
    assert replacer._import_replacer_children is children
    assert replacer._member is member
    assert replacer._module_path is path
    assert replacer._scope is scope
    assert replacer._name == name

# Unit test

# Generated at 2022-06-12 07:34:07.150317
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import (
        lazy_import,
        )
    class DummyClass(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
        def method(self, *args, **kwargs):
            return (args, kwargs)
    def make_instance(x, scope, name):
        return DummyClass()
    # Test that we can set attributes onScopeReplacer objects
    scope = {}
    lazy_import(scope, 'x', make_instance)
    scope['x'].method(1, 2, three='four')
    scope['x'](1, 2, three='four')
    scope['x'].__setattr__('xyz', 123)
    scope['x'].__setattr__('abc', 123)

# Generated at 2022-06-12 07:34:12.944450
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def dummy_factory(self, scope, name):
        return lambda x, y: (x, y)
    scope = {}
    import tests.blackbox.test_lazy_import as self_module
    s = ScopeReplacer(scope, dummy_factory, 's')
    e = AssertionError
    try: s(22, 33)
    except e: raise TestNotApplicable('Test not applicable in this Python version')
    x, y = s(22, 33)
    if x is not 22: raise TestFailed('%r != 22' % x)
    if y is not 33: raise TestFailed('%r != 33' % y)
    try: s.foo
    except e: raise TestNotApplicable('Test not applicable in this Python version')
    # test_lazy_import.py has no 'foo

# Generated at 2022-06-12 07:34:17.398708
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return unicode or raise exception"""
    s = "message"
    e = IllegalUseOfScopeReplacer("name", s)
    assert isinstance(e.__unicode__(), unicode)

    e.msg = u"\xc3\xa9"
    assert isinstance(e.__unicode__(), unicode)



# Generated at 2022-06-12 07:34:21.938957
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer("name", "msg", "extra")
    # Test __str__
    str(e)
    # Test __repr__
    repr(e)



# Generated at 2022-06-12 07:34:29.231320
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class MyModule(object):
        def __init__(self):
            self.foo = 'bar'
            self.bar = 'baz'
    class MySubModule(object):
        def __init__(self):
            self.blah = 'blah'

    globs = {}
    lazy_import(globs, '''
        MyModule
    ''')

    assert globs['MyModule']()['foo'] == 'bar'
    globs['MyModule'].foo = 'baz'
    assert globs['MyModule']().foo == 'baz'

    globs['MyModule']()['foo'] = 'foo'
    assert globs['MyModule'].foo == 'foo'

    globs['MyModule'].bar = 'bar'
    assert globs['MyModule'].bar == 'bar'

# Generated at 2022-06-12 07:34:39.240887
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # calling instance method __setattr__ of ScopeReplacer
    # __setattr__ on class ScopeReplacer is actually a wrapper function,
    # which sets the value to the internal __setattr__ method.
    # This is because __setattr__ is a special method.
    # [Here is how it is done](http://docs.python.org/reference/datamodel.html#slots)
    # So, we must test the value of the internal __setattr__ method
    # and not test ScopeReplacer.__setattr__ wrapper
    s = ScopeReplacer(None, None, None)
    def test_func(): return s
    test_func.__name__ = 'test_func'
    test_func.__module__ = 'module'
    s.__setattr__('__module__', 'module')
    # testing instance attribute

# Generated at 2022-06-12 07:34:49.239391
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    lazy_import.lazy_import(globals(), '''
from bzrlib import test_lazy_import_helpers
''')
    # Setup:
    # Create the mock object to be returned; obj generates None when
    # setattr is called with 'attr' as the attribute (to avoid side-effects).
    # Create a ScopeReplacer with a factory that generates obj.
    obj = test_lazy_import_helpers.MockObject()
    def _factory(self, ignore1, ignore2):
        return obj
    o = ScopeReplacer(ScopeReplacer.__dict__, _factory, 'o')
    attr = 'x'
    value = 'value'
    # Exercise:
    # Set the attribute.

# Generated at 2022-06-12 07:34:57.006403
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    mergetest_skip_conditions = {}
    bzrlib.lazy_import.lazy_import(
        mergetest_skip_conditions, '''
    from bzrlib.tests import (
        multiply_skip_conditions,
        )
    ''')
    def make_scope():
        scope = {}
        bzrlib.lazy_import.lazy_import(
            scope, '''
        from bzrlib.tests import (
            multiply_skip_conditions,
            )
        ''')
        return scope
    # Call ScopeReplacer.__call__ as if it is called from a different module.
    globals()['bzrlib'] = bzrlib

# Generated at 2022-06-12 07:35:15.423440
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    class DummyModule(object):
        pass
    dummy_module = DummyModule()

    from bzrlib.trace import mutter
    try:
        mutter('foo')
    except Exception as e:
        pass
    else:
        raise AssertionError()
    if not isinstance(e, IllegalUseOfScopeReplacer):
        raise AssertionError()
    if e.__class__ is not IllegalUseOfScopeReplacer:
        raise AssertionError()
    if e.name is not dummy_module:
        raise AssertionError()
    if e.msg != 'foo':
        raise AssertionError()
    if e.extra != '':
        raise AssertionError()
    if not isinstance(e, Exception):
        raise AssertionError()

# Generated at 2022-06-12 07:35:26.948575
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from collections import namedtuple
    original = namedtuple('original', ['a', 'b'])
    scope = {}
    def _factory(sr, scope, name):
        return original(sr, scope)

    def test_func(obj):
        return obj[0]

    scope['x'] = ScopeReplacer(scope, _factory, 'x')
    # Test that the original is accessible
    x = scope['x']
    assert isinstance(x, ScopeReplacer)
    assert test_func(x) is x
    assert test_func(x) is scope['x']
    # Test that it gets replaced the 2nd time
    x = scope['x']
    assert isinstance(x, original)
    assert test_func(x) is x



# Generated at 2022-06-12 07:35:35.035513
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str not unicode

    I.e. it must not return a unicode object.
    """
    e = IllegalUseOfScopeReplacer('name', 'message')
    s = str(e)
    if isinstance(s, unicode):
        raise AssertionError('Returns "%s" which is a unicode object.' % s)
    if not isinstance(s, str):
        raise AssertionError('Returns "%s" which is not a str object.' % s)

# Generated at 2022-06-12 07:35:37.655804
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Call ScopeReplacer.__getattribute__(self, attr)
    assert True # TODO: implement your test here



# Generated at 2022-06-12 07:35:48.141491
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """_unicode_ handles the case of a unicode message"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # Test a message that is already a unicode object
    e = IllegalUseOfScopeReplacer("unicode", u'message')
    # Test a message that is a str, but that can be converted to unicode
    e = IllegalUseOfScopeReplacer("unicode", 'message')


try:
    from os import getcwd as _getcwd
except ImportError:
    # python-2.2.2 on windows seems to not have getcwd
    # (cwd is not set correctly on startup)
    # getcwd is documented to fail with ENOENT (which we can't catch)
    # or EACCES.
    import os.path as _path
    import win32api

# Generated at 2022-06-12 07:35:56.053306
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    
    import sys
    import bzrlib.tests
    import bzrlib.lazy_import

    # test calling a real object
    class test_ScopeReplacer___call___class(object):
        def __call__(self):
            return 'class method'

    
    
    
    
    def test_ScopeReplacer___call___factory(scope_replacer, scope, name):
        return test_ScopeReplacer___call___class()
    
    
    
    
    
    scope = {}
    name = 'a_name_for_the_lazy_import'
    scope_replacer = bzrlib.lazy_import.ScopeReplacer(scope,
        test_ScopeReplacer___call___factory, name)
    returned = scope_replacer()
    # test calling a

# Generated at 2022-06-12 07:35:59.116247
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)


# Generated at 2022-06-12 07:36:05.750715
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import glob
    import os
    import sys
    import time
    from bzrlib import (
        symbol_versioning,
        )
    from bzrlib.lazy_import import (
        lazy_import,
        _make_scope_replacer,
        )
    from bzrlib.tests.script import (
        test_script,
        )

# Generated at 2022-06-12 07:36:15.187866
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import (
        IllegalUseOfScopeReplacer,
        )
    from io import BytesIO
    from bzrlib.trace import mutter
    from bzrlib.ui import ui_factory
    # test that unicode output is formed correctly

# Generated at 2022-06-12 07:36:19.539341
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class DerivedException(IllegalUseOfScopeReplacer):
        pass
    e1 = DerivedException(1, 2, 3)
    e2 = DerivedException(1, 2, 3)
    e1 == e2
test_IllegalUseOfScopeReplacer___eq__()


# Generated at 2022-06-12 07:36:39.000140
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    assert True==True, 'Calling module_name with no args should return None'
    def fn(self, *args, **kwargs):
        pass
    class Foo(object): pass
    foo = Foo()
    foo.__class__.__setattr__ = fn
    assert True==True, 'Calling module_name with no args should return None'
    assert True==True, 'Calling module_name with no args should return None'
    assert True==True, 'Calling module_name with no args should return None'

# Generated at 2022-06-12 07:36:45.451695
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    # illegal_use_of_scope_replacer.__unicode__() should return a unicode object
    # so that str(illegal_use_of_scope_replacer) on Python 2.x returns a str
    # object.
    e = IllegalUseOfScopeReplacer(u'test', u'test error')
    u = unicode(e)
    assert type(u) is unicode
test_IllegalUseOfScopeReplacer___unicode__()


# Generated at 2022-06-12 07:36:56.817584
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.lazy_import import lazy_import
    class TestLazyImporter(TestCaseWithTransport):
        def test_call_lazy_importer(self):
            # Lazy importer should stay a ScopeReplacer in the same scope
            # if used as a function.
            test_obj = object()
            test_obj_2 = object()
            def factory(replacer, scope, name):
                self.assertEqual(replacer, scope[name])
                self.assertEqual(args, (1,2))
                self.assertEqual(kwargs, {'arg':'argument'})
                return test_obj_2
            lazy_import(locals(), '''
            import some_module
            ''')

# Generated at 2022-06-12 07:37:01.161879
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__

    >>> s = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    >>> str(s) # doctest: +ELLIPSIS
    'IllegalUseOfScopeReplacer object ... was used incorrectly: msg: extra'
    """



# Generated at 2022-06-12 07:37:09.120158
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.osutils as m_osutils
    m_osutils.pathjoin = lambda a,b: 'expected'
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    import bzrlib.tests
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    import bzrlib
    import sys
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True




# Generated at 2022-06-12 07:37:19.439463
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Setting items into a ScopeReplacer should write to the final object."""

    # testing: Setting items into a ScopeReplacer should write to the final object.
    class SomeClassThatWeCanRead(object):
        def __init__(self):
            self._attr = None
        def __getattr__(self, attr):
            if attr != 'foo':
                raise AssertionError('we want to get foo, not %r'
                                     % (attr,))
            return self._attr
    final_class = SomeClassThatWeCanRead()
    # Tests are allowed to set attributes onto themselves in this way
    # We avoid doing this in production code as it is not allowed in
    # general
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-12 07:37:23.460823
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__

    This test ensures that the __str__ method of
    IllegalUseOfScopeReplacer will produce an ASCII string object.
    """
    s = str(IllegalUseOfScopeReplacer(None, None))
    assert isinstance(s, str)

# Generated at 2022-06-12 07:37:30.893165
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import mock
    l = lazy_import.ScopeReplacer(globals(), lambda: mock.Mock(), 'l')
    l.a = 1
    l.b = 2
    l.c = 3
    l._resolve.assert_called_with()
    l().a = 1
    l().b = 2
    l().c = 3
    l()._resolve().a = 1
    l()._resolve().b = 2
    l()._resolve().c = 3

# Generated at 2022-06-12 07:37:36.221161
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('n', 'm', 'o')
    assert str(e) == unicode(e)
    assert repr(e) == 'IllegalUseOfScopeReplacer(n)'
    assert unicode(e) == u'ScopeReplacer object \'n\' was used incorrectly: m: o'



# Generated at 2022-06-12 07:37:39.004770
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer"""
    pass # FIXME: caller_locals needs to be implemented

    # FIXME: Implement tests for ScopeReplacer.__call__



# Generated at 2022-06-12 07:37:59.620777
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should always return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'a message')
    u = unicode(e)
    assert isinstance(u, unicode)
    # the string below must be ascii on purpose
    # to test the decoding of the message in __unicode__.
    e = IllegalUseOfScopeReplacer('name', 'a message f\xe9\xe9')
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:38:03.371398
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a bytestring"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = e.__str__()
    assert isinstance(s, str)


# Generated at 2022-06-12 07:38:07.882279
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    f = ScopeReplacer
    i = lambda : 1
    vars = {'bzrlib':ScopeReplacer}
    f(vars, i, 'bzrlib')
    getattr(vars['bzrlib'],'__setattr__')('a', 1)
    pass

# Generated at 2022-06-12 07:38:09.097565
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = ScopeReplacer



# Generated at 2022-06-12 07:38:18.304363
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    import sys
    import os
    def lazy_import_os():
        import os

# Generated at 2022-06-12 07:38:20.585711
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # There is no simple way to test this in isolation.
    # See the tests for 'test_lazy_import' for tests.
    pass

# Generated at 2022-06-12 07:38:30.295803
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.branch import _mod_revision

    globals = {}
    ScopeReplacer(globals, lambda x, scope, name: x, 'test')
    assert globals['test'] is not None
    try:
        globals['test']._should_proxy = False
        globals['test'] = _mod_revision.NULL_REVISION
        # this shouldn't have replaced us.
        assert globals['test'] is not _mod_revision.NULL_REVISION
    finally:
        del globals['test']._should_proxy
        globals['test'] = None
        assert globals['test'] is None
    globals['test'] = _mod_revision.NULL_REVISION
    assert globals['test'] is _mod_revision.NULL_REVISION




# Generated at 2022-06-12 07:38:33.927601
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """For IllegalUseOfScopeReplacer method __unicode__
    """
    err = IllegalUseOfScopeReplacer('abc', 'xyz')
    unicode(err)



# Generated at 2022-06-12 07:38:39.882593
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer."""
    replacer = ScopeReplacer(locals(), None, 'foo')
    replacer.__setattr__('name', 'good')
    try:
        replacer.__setattr__('name', 'bad')
    except AttributeError:
        pass
    else:
        raise AssertionError("Assigning name twice didn't fail")
    return 0

# Generated at 2022-06-12 07:38:48.026755
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer."""
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "a message"
    # Create an instance of MyException.
    exc = MyException(1, 2, 3)
    # Check that str() returns a string.
    s = str(exc)
    assert isinstance(s, str), \
        "%r is not a string but a %r" % (s, type(s))



# Generated at 2022-06-12 07:39:25.044633
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode for any 'fmt'"""
    # .__unicode__() should return unicode for any fmt
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # a simple str
    e = IllegalUseOfScopeReplacer('a', 'b', 5)
    u = unicode(e) # .__unicode__()
    assert isinstance(u, unicode)
    # a unicode str
    e = IllegalUseOfScopeReplacer(u'a', u'b', 5)
    u = unicode(e) # .__unicode__()
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:39:29.375137
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer.

    Should not raise exceptions, but must return a unicode object.
    """
    x = IllegalUseOfScopeReplacer("x", "y", "z")
    unicode(x)


# Generated at 2022-06-12 07:39:37.488191
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    from bzrlib.lazy_import import ScopeReplacer
    globs = globals()
    doctest.run_docstring_examples(ScopeReplacer.__call__, globs, verbose=True)

    # We need to replace the callable 'scope' with something that returns
    # a dict, since we cannot execute 'nonlocal' in Python 2.4
    def _scope():
        return globs
    old_scope = globs['scope']
    globs['scope'] = _scope
    try:
        doctest.run_docstring_examples(ScopeReplacer.__call__, globs,
                                       verbose=True)
    finally:
        globs['scope'] = old_scope



# Generated at 2022-06-12 07:39:48.507882
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import traceback
    from StringIO import StringIO
    from _pyio import StringIO as StringIO_pyio
    from bzrlib import lazy_import
    # Create a test object
    class TestObj(object):
        def __call__(self, arg1, arg2):
            return arg1 + arg2
    # Make sure ScopeReplacer is not yet defined.
    try:
        ScopeReplacer
    except NameError:
        pass

# Generated at 2022-06-12 07:39:51.939926
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """It tests the default value of the attribute _fmt."""
    instance = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert instance._fmt == "ScopeReplacer object %(name)r was used incorrectly:" \
        " %(msg)s%(extra)s"


# Generated at 2022-06-12 07:39:57.721610
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer.

    This test confirms that, if the format string contains only
    characters that can be encoded by the default ascii codec, the
    returned value is a str.
    """
    e = e = IllegalUseOfScopeReplacer('name', 'msg')
    # __str__ must return a str.
    s = str(e)



# Generated at 2022-06-12 07:40:04.599695
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__"""
    __tracebackhide__ = True
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

# Generated at 2022-06-12 07:40:15.845352
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """method __call__ of class ScopeReplacer with generic arguments.

    This test checks that calling ScopeReplacer.__call__ with
    generic arguments does not raise any exception.
    """
    def __init__(self, scope, factory, name):
        """Create a temporary object in the specified scope.
        Once used, a real object will be placed in the scope.

        :param scope: The scope the object should appear in
        :param factory: A callable that will create the real object.
            It will be passed (self, scope, name)
        :param name: The variable name in the given scope.
        """
        object.__setattr__(self, '_scope', scope)
        object.__setattr__(self, '_factory', factory)
        object.__setattr__(self, '_name', name)
        object

# Generated at 2022-06-12 07:40:18.485843
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Class IllegalUseOfScopeReplacer has method __str__"""
    o = IllegalUseOfScopeReplacer('name','msg','extra')
    repr(o)
    str(o)


# Generated at 2022-06-12 07:40:24.995881
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    if sys.version < '3':
        from breezy.tests import TestCase

        class TestIllegalUseOfScopeReplacer(TestCase):
            def test__str__(self):
                x = IllegalUseOfScopeReplacer('name', 'msg')
                self.assertContainsRe(x, '^Unprintable exception')
    else:
        class TestIllegalUseOfScopeReplacer:
            def test__str__(self):
                x = IllegalUseOfScopeReplacer('name', 'msg')
                self.assertEqual('Unprintable exception IllegalUseOfScopeReplacer: dict={\'extra\': \'\', \'msg\': \'msg\', \'name\': \'name\'}, fmt=None, error=None', str(x))

# Generated at 2022-06-12 07:41:20.188664
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of an object

    This is just a smoke test for the __setattr__ method of the ScopeReplacer
    class.

    We do not do a sophisticated test because it should be method __setattr__
    of the object that is really used, not the one from class ScopeReplacer.
    """
    # We do not test for bypassing for obvious reasons.
    scope = {'a': 1, 'b': 2}
    scope_replacer = ScopeReplacer(scope, None, 'b')
    scope_replacer.__setattr__('test', 'a')



# Generated at 2022-06-12 07:41:21.927523
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(e.__unicode__(), unicode)

# Generated at 2022-06-12 07:41:33.692833
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import osutils
    # At this point ScopeReplacer._should_proxy is true.
    try:
        # Try assigning osutils to a new variable, which is not allowed - from
        # the ScopeReplacer docstring: "This is especially true for constants,"
        import osutils as osutils2
    except IllegalUseOfScopeReplacer as e:
        e.msg == "Object already replaced, did you assign it to another " \
            "variable?"
    else:
        raise AssertionError("should have raised IllegalUseOfScopeReplacer")
    # Switch off proxying to check for abuse
    ScopeReplacer._should_proxy = False
    # At this point ScopeReplacer._should_proxy is false.

# Generated at 2022-06-12 07:41:37.547484
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.per_lazy_import
    from bzrlib.tests import TestCase

    # Calling __setattr__ of class ScopeReplacer with no args must raise
    # TypeError
    try:
        bzrlib.tests.per_lazy_import.ScopeReplacer.__setattr__()
    except TypeError:
        pass


# Generated at 2022-06-12 07:41:42.732272
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(unicode(e), unicode)
    assert isinstance(str(e), str)
    assert isinstance(repr(e), str)

# Generated at 2022-06-12 07:41:48.352518
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return an str object"""
    e = IllegalUseOfScopeReplacer("lazy_import",
        "Module was accessed before import took place.", "Module was x")
    s = str(e)
    assert isinstance(s, str)
    assert s == 'Module was accessed before import took place.: Module was x'


# Generated at 2022-06-12 07:41:54.310170
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    uni_e = unicode(e)
    assert isinstance(uni_e, unicode), 'isinstance(%r, unicode)' % (uni_e,)
    uni_e = str(e)
    assert isinstance(uni_e, str), 'isinstance(%r, str)' % (uni_e,)



# Generated at 2022-06-12 07:42:05.628074
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    class TestScopeReplacer(ScopeReplacer):
        class foo:
            @staticmethod
            def method(self, scope, name):
                raise TestSkipped(
                    "Method 'method' cannot be tested because it is a static method")
    test_scope = {}
    test_factory = TestScopeReplacer.foo.method
    # __getattribute__
    test_name = 'test_name'
    test_scopeReplacer = TestScopeReplacer(
        test_scope, test_factory, test_name)
    test_attr = '__getattribute__'
    bzrlib.lazy_import.ScopeReplacer.__getattribute__(
    test_scopeReplacer, test_attr)
    # __setattribute__
    test_attr = '__setattribute__'
    test_

# Generated at 2022-06-12 07:42:11.151251
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test passing string does not maintain identity
    from bzrlib.lazy_import import lazy_import

    globa = {}
    lazy_import(globa, "from bzrlib.tests import a_mod")
    b_mod = globa['a_mod'].b_mod

    globa['b_mod'].s = 'b_mod'
    globa['b_mod'].inner.s = 'inner'
    assert b_mod.s == 'b_mod'
    assert b_mod.inner.s == 'inner'

# Generated at 2022-06-12 07:42:15.901014
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    class E(IllegalUseOfScopeReplacer):
        _fmt = '%(name)r %(msg)r %(extra)r'
    e = E('foo', 'bar', 'baz')
    assert e.__unicode__() == u'foo bar baz'
