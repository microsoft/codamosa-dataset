

# Generated at 2022-06-12 07:33:47.549541
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ must return a unicode string."""
    s = IllegalUseOfScopeReplacer('f1', 'g1')
    u = unicode(s)
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:33:56.319761
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the method ImportProcessor.lazy_import."""
    # Test the method ImportProcessor.lazy_import.
    # This test should be run with a module named test_module defined,
    # in the same directory as import_lazy.py. It should define a class
    # Foo with members 'd' and 'e' and a function 'f'.
    from test_module import Foo
    from test_module import g
    from test_module import h

    # Test that the trivial import is OK and doesn't crash.
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(), 'import foo')
    # Test that the trivial from import is OK and doesn't crash.
    import_processor.lazy_import(globals(), 'from foo import bar')
    # Test that the semi-

# Generated at 2022-06-12 07:34:06.729797
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer.

    This may be a bit overkill for a single line of code, but it tests for
    regressions, and putting it here allows us to just grep for
    'test_IllegalUseOfScopeReplacer___str__()' to find this test.
    """
    def check(self, expected):
        s = self.__str__()
        if s != expected:
            raise AssertionError('%r != %r' % (s, expected))
        u = self.__unicode__()
        if u != expected.decode('utf8'):
            raise AssertionError('%r != %r' % (u, expected.decode('utf8')))
        r = self.__repr__()

# Generated at 2022-06-12 07:34:14.554372
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return str objects

    This is a special case test.
    __unicode__() always returns unicode objects, so it is only useful
    when __str__() is not defined.
    """
    e = IllegalUseOfScopeReplacer('self', 'a', 'b')
    s = e.__unicode__()
    if s != u'self a b':
        raise AssertionError(s)



# Generated at 2022-06-12 07:34:22.609169
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    if True :
        scope,factory,name,self,attr,value,obj,setattr = [],[],[],[],[],[],[],setattr
        obj = object()
        setattr(obj, 'attr', None)
        from bzrlib.tests.blackbox import test_setattr
        test_setattr.assertRaises(
                getattr(obj, '__setattr__'),
                attr, value)
    if True :
        scope,factory,name,self,attr,value,obj,setattr = [],[],[],[],[],[],[],setattr
        obj = object()
        setattr(obj, 'attr', None)
        from bzrlib.tests.blackbox import test_setattr

# Generated at 2022-06-12 07:34:26.718897
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def func_test_ScopeReplacer___call__(self, scope, name):
        return lambda: None
    class FakeModule(object):
        def __setitem__(self, name, value):
            pass
    lazy_object = ScopeReplacer(FakeModule(), func_test_ScopeReplacer___call__, 'fake_name')
    lazy_object()

# Generated at 2022-06-12 07:34:30.477552
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test __str__ method of class IllegalUseOfScopeReplacer"""

    sl = IllegalUseOfScopeReplacer("name", "msg")
    assert isinstance(sl.__str__(), str)



# Generated at 2022-06-12 07:34:39.614135
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import inspect
    import bzrlib
    import bzrlib.trace
    import bzrlib.workingtree
    class ImportReplacer_surrogate(object):
        def __init__(self, scope, name, module_path, member=None, children={}):
            pass
    processor = ImportProcessor(lazy_import_class=ImportReplacer_surrogate)
    processor.lazy_import(globals(),
            "import inspect, bzrlib, bzrlib.trace, bzrlib.workingtree, bzrlib.trace, bzrlib.trace")
    processor.lazy_import(globals(),
            "from foo import bar")
    processor.lazy_import(globals(),
            "from foo import bar, baz")
    processor.lazy_import

# Generated at 2022-06-12 07:34:46.707712
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer("name", "msg")
    # check it returns unicode if self._fmt is unicode
    e._fmt = u"abc %(name)s def"
    u = u"abc name def"
    assert e.__unicode__() == u
    # check it returns str if self._fmt is ascii
    e._fmt = "abc %(name)s def"
    u = u"abc name def"
    assert e.__unicode__() == u



# Generated at 2022-06-12 07:34:55.336471
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Unit tests for method lazy_import in class ImportProcessor"""
    import sys
    ip = ImportProcessor()
    ip.lazy_import(sys.modules, """from bzrlib import (
    revision as _mod_revision,
    option,
    errors,
    )""")
    import bzrlib.revision as revision
    import bzrlib.option
    import bzrlib.errors
    assert revision is _mod_revision
    assert isinstance(revision, ImportReplacer)
    assert isinstance(bzrlib.option, ImportReplacer)
    assert isinstance(bzrlib.errors, ImportReplacer)



# Generated at 2022-06-12 07:35:05.604814
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test for method __setattr__ of class ScopeReplacer"""
    # XXX: Test for unexpected cases not yet written
    pass

# Generated at 2022-06-12 07:35:15.458997
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import (
        errors,
        osutils,
        branch,
        )

    def func():
        pass

    _names = [
        'func',
        'errors',
        'osutils',
        'branch',
        ]

    _func_names = [
        'errors',
        'osutils',
        'branch',
        ]

    _class_names = [
        'errors',
        'osutils',
        'branch',
        ]

    _module_names = [
    ]

    import bzrlib

    def check_import(name, value):

        def factory(replacer, scope, name):
            if name in _func_names:
                return func
            if name in _class_names:
                return replacer

# Generated at 2022-06-12 07:35:27.283594
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    __tracebackhide__ = True
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    scope = {}
    def factory(self, scope, name):
        return 2
    scope_replacer = ScopeReplacer(scope, factory, "foo")
    scope_replacer.x = 42
    self.assertEqual(42, scope_replacer.x)
    e = self.assertRaises(IllegalUseOfScopeReplacer, scope_replacer.__setattr__,
        'x', 43)
    self.assertEqual('foo', e.name)
    self.assertEqual('Object already replaced, did you assign it to another variable?',
        e.msg)
    self

# Generated at 2022-06-12 07:35:39.380413
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():

    class X: pass
    from contextlib import contextmanager
    from bzrlib import i18n
    @contextmanager
    def _():
        try:
            old = i18n._translation_target
            try:
                i18n._translation_target = X
                yield
            finally:
                i18n._translation_target = old
        except:
            import traceback
            traceback.print_exc()
            raise

    class FooException(IllegalUseOfScopeReplacer):
        _fmt = 'Foo'

    class BarException(IllegalUseOfScopeReplacer):
        _fmt = 'Bar'

    def check(expected_repr, expected_str, expected_unicode, instance):
        instance_repr = repr(instance)

# Generated at 2022-06-12 07:35:45.071975
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ returns an unicode object."""
    e = IllegalUseOfScopeReplacer(None, None)
    u = unicode(e)
    assert isinstance(u, unicode)
    e.msg = 'foo'
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:35:49.770948
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # setup
    from bzrlib.lazy_import import lazy_import
    def _f(self, globals, name):
        return _f
    globals = {'name': 'value'}
    lazy_import(globals, '_f = None')
    s = globals['_f']
    # execution
    result = s._f(s, globals, '_f')
    # verification
    assert result is _f, repr(result)


# Generated at 2022-06-12 07:35:53.737675
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() works without errors."""
    r = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # This is the bare minimum test that __unicode__ works
    unicode(r)



# Generated at 2022-06-12 07:35:55.588393
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
# No class definition provided.

# Generated at 2022-06-12 07:36:04.189070
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import (SymlinkFeature, TestCaseWithTransport)
    from bzrlib import symbol_versioning
    from bzrlib.symbol_versioning import (deprecated_in,
        deprecated_method,
        )
    t = TestCaseWithTransport()
    t.build_tree_contents([('a/',), ('a/b', 'b\n'), ('a/d/',), ('a/d/f', 'f\n')])
    t.transport.mkdir('a/c')
    def f(self, scope, name):
        return 'blam'
    scope = {}
    lazy_import(scope, 'x = ScopeReplacer(scope, f, "x")')
    self.assertEqual('blam', scope['x']())



# Generated at 2022-06-12 07:36:11.641834
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This method must return a unicode object.
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'message')
    u = unicode(e)
    assert isinstance(u, unicode)
    e._preformatted_string = 'preformatted string'
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:36:29.529036
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should return a unicode object
    and should accept both unicode and str objects as arguments.
    """
    i = IllegalUseOfScopeReplacer(name='name', msg='msg')
    assert isinstance(i.__unicode__(), unicode)


# Generated at 2022-06-12 07:36:33.639929
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ produces str on scope replacer."""
    class Foo(Exception):
        _fmt = 'some %(foo)s string'
    f = Foo('bar')
    assert isinstance(f.__str__(), str)

# Generated at 2022-06-12 07:36:36.889080
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert str(e) == 'bar: baz'
test_IllegalUseOfScopeReplacer___str__.unittest = ['test_i18n']



# Generated at 2022-06-12 07:36:40.613288
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode."""
    e = IllegalUseOfScopeReplacer('', '', None)
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-12 07:36:46.950449
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    def my_factory(scope_replacer, scope, name):
        return lambda: 'hello'
    my_replacer = bzrlib.lazy_import.ScopeReplacer({}, my_factory, 'foo')
    # The callable my_replacer should have been replaced with a lambda
    # that returns 'hello'
    assert my_replacer() == 'hello'
    # It should cache the real object
    assert my_replacer is my_replacer()
# End unit test for method __call__ of class ScopeReplacer


# Generated at 2022-06-12 07:36:57.375490
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """We should disallow assignment to a scope replacer.

    In particular this is a problem if an object in a lazy_import'd
    module has a .py file that is executable directly, and
    reassigns the object to something different. For example
    bzrlib.builtins does 'from bzrlib import commands = commands.Commands()'
    (via lazy_import) but that means that if bzrlib.builtins is run
    directly, instead of via bzr, it will have a different commands
    instance to the one bzr uses.
    """

    class TestScope(object):

        def __init__(self):
            self._contents = {}

        def __getitem__(self, a):
            return self._contents[a]

        def __setitem__(self, a, b):
            self

# Generated at 2022-06-12 07:37:05.532675
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib.workingtree import WorkingTreeFormat2, WorkingTree
    ''')
    scope = globals()
    scope['tree'] = WorkingTreeFormat2()
    tree_factory = lambda replacer, scope, name: scope[name]
    tree = ScopeReplacer(scope, tree_factory, 'tree')
    workingtree = WorkingTree(tree)
    def selftest():
        # Just two tests are needed here:
        #  - Will create the working tree if it is not there
        #  - Will not allow an access to a replaced tree.
        assert isinstance(workingtree.uncommitted_merges(), list)

# Generated at 2022-06-12 07:37:10.983534
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ method of IllegalUseOfScopeReplacer should work properly"""
    e1 = IllegalUseOfScopeReplacer('myname', 'mymessage', 'myextra')
    e2 = eval(repr(e1))
    assert e1 == e2
    assert str(e1) == 'IllegalUseOfScopeReplacer(myname): mymessage: myextra'



# Generated at 2022-06-12 07:37:20.965270
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This test checks that the __str__ method of
    IllegalUseOfScopeReplacer behaves as expected."""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # Test the case with a unicode string and no extra parameter.
    e = IllegalUseOfScopeReplacer(u"foo", u"bar")
    str(e)
    # Test the case with a byte string, no extra parameter and no
    # gettext
    e = IllegalUseOfScopeReplacer("foo", "bar")
    str(e)
    # Regression test for bug #754411: Test the case with a byte string, no
    # extra parameter and a gettext translating the message.
    e = IllegalUseOfScopeReplacer("foo", "bar")
    from bzrlib.i18n import gettext

# Generated at 2022-06-12 07:37:22.013156
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # XXX: implement
    pass


# Generated at 2022-06-12 07:37:35.628592
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    exc = IllegalUseOfScopeReplacer(
        'name',
        'msg',
        extra='extra'
        )
    u = unicode(exc)
    # Correctness of output is not tested here, this is just to make sure
    # no exceptions are raised.
    u.encode('utf8')



# Generated at 2022-06-12 07:37:42.956983
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Ensure __str__ works on all of the IllegalUseOfScopeReplacer subclasses.

    This is a test for the test_suite. We can't place the test in the module
    that defines the classes, because those unit tests have not been run
    yet. Consequently, this test is in the wrong place, but we have to put it
    somewhere, so it is here.
    """
    from bzrlib import lazy_import

    # all defined by lazy_import
    for attr in ('UninitializedAttribute', 'AttributeNotInitialized',
                 'AttributeInitializedInWrongScope', 'AttributeReinitialized'):
        # ensure we get a string, not unicode:
        str(getattr(lazy_import, attr))


# Generated at 2022-06-12 07:37:53.906752
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Test method __call__ of class ScopeReplacer."""
    class PassThru(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
    test_values = {
        'factory': lambda self, scope, name: PassThru(),
        'scope': {},
        'name': '',
        'args': (1,2.0),
        'kwargs': {'x':1,'y':2}
    }
    def get_obj():
        return ScopeReplacer(scope=test_values['scope'],
                             factory=test_values['factory'],
                             name=test_values['name'])

# Generated at 2022-06-12 07:38:04.751262
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    def factory(self, scope, name):
        return scope.get(name, None)
    scope = {}
    name = 'testdir'
    scope[name] = 'expected'
    scope_replacer = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)
    result = scope_replacer()
    assert result == 'expected'
# end test_ScopeReplacer___call__

    def __getitem__(self, item):
        obj = object.__getattribute__(self, '_resolve')()
        return obj.__getitem__(item)

    def __setitem__(self, item, value):
        obj = object.__getattribute__(self, '_resolve')()

# Generated at 2022-06-12 07:38:10.106376
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This method tests the __unicode__ method of IllegalUseOfScopeReplacer.

    It tests the case when the message is a unicode string.
    """
    # setup
    e = IllegalUseOfScopeReplacer('name', 'message')

    # execute
    result = unicode(e)

    # verify
    assert isinstance(result, unicode)


# Generated at 2022-06-12 07:38:12.741929
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import inspect
    from bzrlib.tests import TestCase
    if inspect.getdoc(ScopeReplacer.__call__) is None:
        raise AssertionError



# Generated at 2022-06-12 07:38:20.862551
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import symbol_versioning
    from bzrlib._errors import (
        InvalidConstantValue,
        InvalidSymbol,
        )
    from bzrlib.symbol_versioning import (
        deprecated_function,
        deprecated_in,
        deprecated_method,
        deprecated_passed,
        )
    from bzrlib.tests import (
        TestCase,
        TestCaseInTempDir,
        )


# Generated at 2022-06-12 07:38:23.138277
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestSkipped
    raise TestSkipped("Autogenerated test for ScopeReplacer.__call__")

# Generated at 2022-06-12 07:38:30.295851
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer"""
    import bzrlib.lazy_import

    def callback(self, scope, name):
        return 'baz'

    class Foo(object):
        def __init__(self, val):
            self.bar = val

    g = {}
    bzrlib.lazy_import.lazy_import(
        g, 'foo = bzrlib.lazy_import.ScopeReplacer(foo, callback, "foo")')
    foo = Foo('bar')
    g['foo']
    g['foo']()



# Generated at 2022-06-12 07:38:35.929359
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer class __unicode__ should return a unicode object"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    ie = IllegalUseOfScopeReplacer('foo', 'bar')
    ie.__unicode__() # shouldn't raise UnicodeEncodeError



# Generated at 2022-06-12 07:38:50.429521
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # ScopeReplacer.__call__() -> <whatever ScopeReplacer._factory returns>
    # (at the time it is called)
    # _factory takes arguments (self, scope, name)
    self = ScopeReplacer(None, None, None)
    scope = {'self': self}
    scope['self']._factory = lambda self, scope, name: scope[name]
    scope['self'](scope) == scope['self']



# Generated at 2022-06-12 07:39:02.407888
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import test_lazy_import as _mod_test_lazy_import
    from bzrlib.tests import TestCaseWithTransport
    # set up
    import bzrlib
    tmp_scope = {
        'bzrlib': bzrlib,
        }
    _mod_test_lazy_import.TestScopeReplacer(
        tmp_scope,
        _mod_test_lazy_import.TestScopeReplacer,
        'TestScopeReplacer')
    _mod_test_lazy_import.TestScopeReplacer(
        tmp_scope,
        _mod_test_lazy_import.TestScopeReplacer,
        'TestScopeReplacer2')
    # run
    obj = tmp_scope['TestScopeReplacer2']
    # verify
    TestCaseWith

# Generated at 2022-06-12 07:39:06.232585
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method IllegalUseOfScopeReplacer.__unicode__

    Test method IllegalUseOfScopeReplacer.__unicode__
    """
    # test __unicode__, with only _fmt specified
    msg = 'test'
    err = IllegalUseOfScopeReplacer('A', msg, 'extra')
    assert isinstance(err.__unicode__(), unicode)


# Generated at 2022-06-12 07:39:11.991616
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """
    IllegalUseOfScopeReplacer.__unicode__()
    """
    x = IllegalUseOfScopeReplacer('lazy_import', 'called before use')
    method = x.__unicode__
    assert type(method()) is unicode
    assert unicode(x) == u"ScopeReplacer object 'lazy_import' was used incorrectly: called before use"



# Generated at 2022-06-12 07:39:22.231250
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    import os
    ''')
    # TESTME: add code here to test that to be implemented method really
    # works as expected and document the name of this method in the list of
    # tested methods above.
    os.chdir('/home')


    def setUp(self):
        """Set up test fixture."""
        import os
        os.chdir('/home')

    def test_ScopeReplacer___call__(self):
        """Test ScopeReplacer.__call__()."""
        # TESTME: add code here to test that to be implemented method really
        # works as expected and document the name of this method in the list of
        # tested methods above.
        os.chdir('/home')



# Generated at 2022-06-12 07:39:32.796522
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    import doctest
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import (SymlinkFeature, TestCaseWithTransport)
    if not SymlinkFeature.available():
        # TODO: investigate why this test doesn't pass on windows
        return
    tc = TestCaseWithTransport()
    def test_f():
        """return u'\\u3042\\u3044'"""
        return u'あい'
    def test_g():
        """return u'\\u3044\\u3046'"""
        return u'\u3044\u3046'

# Generated at 2022-06-12 07:39:40.367585
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method `ScopeReplacer.__setattr__`

    Test for the following cases:
        - object not assigned (no `_real_obj`)
        - object already assigned (`_real_obj` not None)
    """

    class Foo(object):
        def __init__(self):
            self.x = None

    # We don't need to test for the case where `should_proxy` is
    # True because when the object is not assigned that's the only
    # case that works.
    ScopeReplacer._should_proxy = False
    # object not assigned
    f = Foo()
    sr = ScopeReplacer({}, lambda s, scope, name: f, 'foo')

# Generated at 2022-06-12 07:39:45.072633
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ must return a unicode object"""
    e = IllegalUseOfScopeReplacer('x', 'y', extra='z')
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-12 07:39:52.829940
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    def factory(self, s, n):
        return self
    class C(object):
        pass
    s = {}
    def f(n):
        r = ScopeReplacer(s, factory, n)
        r.x = C()
    f('r')
    r = s['r']
    try:
        r.x = 'y'
    except IllegalUseOfScopeReplacer as e:
        if (e.name != 'r' or
            e.msg != "Object already replaced, did you assign it to another"
                " variable?"):
            raise AssertionError(e)
    else:
        raise AssertionError('r.x = y did not raise IllegalUseOfScopeReplacer')
    # make sure this doesn't raise
    r.x = 'y'
test_ScopeReplacer___

# Generated at 2022-06-12 07:39:54.547905
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    foo = ScopeReplacer(locals(), lambda self, scope, name: None, 'foo')
    foo()



# Generated at 2022-06-12 07:40:21.803940
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.matchers import HasCallCount
    from bzrlib.tests.test_lazy_import import _make_module_for_test

    class Dummy(object):
        pass

    dummy = Dummy()
    dummy.foo = HasCallCount(0)
    dummy.bar = HasCallCount(0)
    specs = {'foo': dummy.foo,
             'bar': dummy.bar}
    module = _make_module_for_test(**specs)
    globals = {'module': ScopeReplacer({}, lambda x, y, z: module, 'module')}
    globals['__name__'] = 'bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__'


# Generated at 2022-06-12 07:40:25.763860
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    if sys.version_info[0] == 3:
        # In py3k this is tested in test_reprlib
        return
    e = IllegalUseOfScopeReplacer("scope", "use was illegal")
    u = unicode(e)
    assert u.startswith("Use of 'scope' imported via lazy_import")



# Generated at 2022-06-12 07:40:36.224264
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class C(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    a = 1
    b = 2
    c = 3
    d = 4
    class _CallWrapper(object):
        called = False
    def _call_wrapper(*args, **kwargs):
        _CallWrapper.called = True
        return C(a, b, c)
    global_scope = {}
    _sr = ScopeReplacer(global_scope, _call_wrapper, 'x')
    def test_call():
        return x(4, 5, c)
    _CallWrapper.called = True
    test_call()

# Generated at 2022-06-12 07:40:39.222008
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should produce a Python-syntax representation of exception

    >>> str(IllegalUseOfScopeReplacer("foo", "bar"))
    "IllegalUseOfScopeReplacer('foo', 'bar')"
    """



# Generated at 2022-06-12 07:40:46.112941
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should work as expected"""
    inst = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(inst.__str__(), str)
    assert inst.__str__() == 'bar'
    inst.__dict__['extra'] = '- this is a further message'
    assert isinstance(inst.__str__(), str)
    assert inst.__str__() == "bar- this is a further message"
    inst.__dict__['_preformatted_string'] = "preformatted"
    assert isinstance(inst.__str__(), str)
    assert inst.__str__() == "preformatted"
    inst.__dict__['_preformatted_string'] = u"preformatted"
    assert isinstance(inst.__str__(), str)

# Generated at 2022-06-12 07:40:53.166858
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer
    """
    from bzrlib.tests.test_i18n import i18n_stub
    i18n_stub.install()
    x = IllegalUseOfScopeReplacer(
        'name',
        'msg',
        extra='extra')
    assert str(x) == "ScopeReplacer object 'name' was used incorrectly: " \
        "msg: extra"
    i18n_stub.uninstall()



# Generated at 2022-06-12 07:41:00.402309
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    import bzrlib.lazy_import_tests

    ScopeReplacer._should_proxy = False

    # Provide a factory method that will always return 1
    def factory(obj, scope, name):
        return 1

    # This should raise
    try:
        lazy_import_tests.test_ScopeReplacer___call__\
            = ScopeReplacer(locals(), factory, 'test_ScopeReplacer___call__')
    except Exception:
        pass
    else:
        raise AssertionError('Retrieving function before replacement'
                             ' was allowed')

    # Register the function
    lazy_import_tests.test_ScopeReplacer___call__\
        = ScopeReplacer(locals(), factory, 'test_ScopeReplacer___call__')


# Generated at 2022-06-12 07:41:11.731106
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    import warnings
    warnings.filterwarnings('ignore', '*', DeprecationWarning, '*bzrlib*')
    loader = bzrlib.lazy_import.LazyModuleLoader()
    globals_ = {'__name__' : 'bzrlib'}
    globals_['__dict__'] = globals_
    def test_ScopeReplacer_Module(replacer, scope, name):
        del scope[name]
        return Module(globals_)
    globals_['bzrlib'] = loader.load_module(
        "bzrlib", globals_, test_ScopeReplacer_Module)
    import bzrlib.lazy_import
    bzrlib = reload(bzrlib)

# Generated at 2022-06-12 07:41:19.797596
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    msg = 'foo'
    exception = IllegalUseOfScopeReplacer('replacer', msg)
    result = str(exception)
    expected = 'IllegalUseOfScopeReplacer: replacer was used incorrectly: ' \
               'foo'
    assert type(result) is str, \
        '__str__ returned %r instead of str' % (type(result),)
    assert result == expected, ('__str__ returned %r instead of %r'
                                % (result, expected))


# Generated at 2022-06-12 07:41:22.988978
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str not a unicode."""
    test = IllegalUseOfScopeReplacer("name", "message")
    if not isinstance(test.__str__(), str):
        raise AssertionError("'%s' is not a string." % test.__str__())



# Generated at 2022-06-12 07:41:47.513691
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    a = IllegalUseOfScopeReplacer('attr', 'msg', 'extramsg')
    assert str(a) == "ScopeReplacer object 'attr' was used incorrectly: msg: extramsg"



# Generated at 2022-06-12 07:41:57.085130
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    # The __unicode__ function returns a unicode object.
    exc = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(exc.__unicode__(), unicode)
    # The __unicode__ function returns a string containing the error message
    # in the exception.
    exc = IllegalUseOfScopeReplacer('name', 'msg')
    u = exc.__unicode__()
    assert u.find(u'ScopeReplacer') >= 0
    assert u.find(u'msg') >= 0
    # The __unicode__ function should be able to handle unicode strings.
    exc = IllegalUseOfScopeReplacer(u'\u00df', u'\u00df')
    u = exc.__unicode__()


# Generated at 2022-06-12 07:42:04.756203
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This test method tests IllegalUseOfScopeReplacer.__str__()"""
    # To make this test work even if we don't run it through the test
    # suite, we define some variables that we use below to simulate
    # imported modules.
    class illegal_use_of_scope_replacer:
        def _format(self):
            return 'illegal_use_of_scope_replacer._format()'
    def gettext(s):
        return s.encode('utf-8')
    #
    # Create a new subclass of IllegalUseOfScopeReplacer
    class my_class(IllegalUseOfScopeReplacer):
        _fmt = "my_class: %(name)s: %(msg)s"
    #
    # Create an object from our new class

# Generated at 2022-06-12 07:42:12.167627
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    # unicode -> unicode
    w = IllegalUseOfScopeReplacer(u"foo bar", u"oh foo bar",
        extra=IllegalUseOfScopeReplacer(u"baz", u"oh baz"))
    assert isinstance(w.name, unicode)
    assert isinstance(w.msg, unicode)
    assert isinstance(w.extra, unicode)
    assert isinstance(w.__unicode__(), unicode)
    assert isinstance(w.__str__(), str)

    # str -> unicode
    s = IllegalUseOfScopeReplacer(u"foo bar", u"oh foo bar",
        extra=IllegalUseOfScopeReplacer(u"baz", u"oh baz"))

# Generated at 2022-06-12 07:42:20.475981
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # This function tests the __str__ method of the class IllegalUseOfScopeReplacer
    obj = IllegalUseOfScopeReplacer(u'foo', u'bar', u'baz')
    # The __str__ method of IllegalUseOfScopeReplacer should return a string
    from bzrlib.lazy_import import tests
    s = obj.__str__()
    tests.assertIsInstance(s, str)
    # The string returned by __str__ should equal the value of obj.__unicode__()
    tests.assertEqual(s, obj.__unicode__().encode('utf8'))



# Generated at 2022-06-12 07:42:29.591746
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.branch
    def _factory(replacer, scope, name):
        return bzrlib.branch
    _attr_name = '_attributes'
    _attr_value = [1,2,3]
    _arguments = [1,2,3]
    _self = ScopeReplacer({}, _factory, _attr_name)
    _self._resolve = lambda:_self
    setattr(_self, _attr_name, _attr_value)
    _ret = _self(*_arguments)
    assert _ret is _attr_value, \
        'Expected: %(expected)s\n' \
        'Received: %(received)s' % {
        'expected': _attr_value,
        'received': _ret,
        }



# Generated at 2022-06-12 07:42:38.069924
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() returns a string"""
    # __str__ must always return a str object.
    # In python3 it would raise a TypeError when returning a unicode object.
    # In python2, it is written so that we cannot return a unicode object.
    obj = IllegalUseOfScopeReplacer('name', 'msg')
    result__str__ = obj.__str__()
    result_type = type(result__str__)
    assert isinstance(result_type, type)
    assertissubclass(result_type, str)
    assert result_type() is not None
    assert result_type() == ''
    assert result_type(42) == '42'



# Generated at 2022-06-12 07:42:46.905644
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    a = IllegalUseOfScopeReplacer("scope", "msg", extra=("extra", "stuff"))
    assert(isinstance(a.__unicode__(), unicode))
    assert(a.__unicode__() == a.__str__())
    assert(a.__unicode__().startswith("ScopeReplacer object 'scope' was used "
        "incorrectly: msg"))
    assert(a.__unicode__().endswith(": extra"))
test_IllegalUseOfScopeReplacer___unicode__()



# Generated at 2022-06-12 07:42:49.989993
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    doctest.run_docstring_examples(ScopeReplacer.__call__, globals(),
                                   verbose=True)



# Generated at 2022-06-12 07:42:55.936284
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class MyClass(object):  # mock
        def __init__(self): pass
        def foo(self): pass
    self = MyClass()
    self.x = 7
    self.m = MyClass()
    self.m.z = 8
    self.y = self.x + 42

    rs1 = ScopeReplacer(globals(), lambda *args: self, 'self')
    rs2 = ScopeReplacer(globals(), lambda *args: self.m, 'self.m')

    try:
        t = self
        assert t.__class__ == MyClass
        assert t.x == 7
        assert t.y == 49

        t = self.m
        assert t.__class__ == MyClass
        assert t.z == 8
    finally:
        del self, self.m



# Generated at 2022-06-12 07:43:13.984861
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'extra')
    assert unicode(e) == u'ScopeReplacer object foo was used incorrectly:' \
        ' bar: extra'


# Generated at 2022-06-12 07:43:22.363508
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """ScopeReplacer.__call__ must behave as documented"""
    import bzrlib.tests.per_lazy_import
    from bzrlib import lazy_import
    lazy_import(bzrlib.tests.per_lazy_import.__dict__, """
    import bzrlib.tests.per_lazy_import
    """)
    # The next line is an abuse of ScopeReplacer as it would be dangerous to
    # use this technique in real code.
    bzrlib.tests.per_lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-12 07:43:27.902113
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib import lazy_import
    scope = {}
    def factory(dummy_replacer, scope, name):
        return name
    replacer = lazy_import.ScopeReplacer(scope, factory, name='bob')
    self = TestCase()
    self.assertEqual('bob', replacer())