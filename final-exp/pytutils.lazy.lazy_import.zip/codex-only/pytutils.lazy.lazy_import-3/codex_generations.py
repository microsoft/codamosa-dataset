

# Generated at 2022-06-24 02:43:14.521534
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test construction of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('foo', 'bar', None)
    assert str(e) == 'foo was used incorrectly: bar'
    # unicode
    assert unicode(e) == u'foo was used incorrectly: bar'

    e = IllegalUseOfScopeReplacer('bzrlib', 'broken', 'the sky is falling')
    assert str(e) == 'bzrlib was used incorrectly: broken: the sky is falling'
    # unicode
    assert unicode(e) == u'bzrlib was used incorrectly: broken: the sky is falling'



# Generated at 2022-06-24 02:43:24.674919
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Method __getattribute__ of class ScopeReplacer"""
    from bzrlib._lazy_import import (
        IllegalUseOfScopeReplacer,
        ScopeReplacer,
        )
    from bzrlib.tests import TestCase
    global _a
    global _b
    _a = 1
    def _factory(self, scope, name):
        return scope[name]
    obj = ScopeReplacer(globals(), _factory, '_a')
    e = self.assertRaises(IllegalUseOfScopeReplacer, obj._resolve)
    self.assertEqual(
        e.name,
        '_a'
        )
    self.assertEqual(
        e.msg,
        "Object tried to replace itself, check it's not using its own scope."
        )

# Generated at 2022-06-24 02:43:34.186228
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    pass

    # Set up a scope
    s = Scope()
    # Create two scope replacer objects and check for equality
    obj1 = ScopeReplacer(s, 'foo', 'bar')
    obj1.__name__ = 'foo'
    obj2 = ScopeReplacer(s, 'foo', 'baz')
    obj2.__name__ = 'foo'
    check_equal(obj1, obj2)
    # Create a scope replacer object and a different type and check
    # for inequality
    check_not_equal(obj1, 'bar')
    # Create another scope replacer object and check for inequality
    obj2 = ScopeReplacer(s, 'foo', 'bar')
    obj2.__name__ = 'foo'
    check_equal(obj1, obj2)
test_IllegalUseOfScopeReplacer___eq

# Generated at 2022-06-24 02:43:39.691492
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from doctest import ELLIPSIS
    # run_doctest, for some reason, does not pass ELLIPSIS
    # automatically when running the tests. So we pass it explicitly
    # through the args.
    args = {'checker': ELLIPSIS}
    import doctest
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    doctest.run_docstring_examples(
        IllegalUseOfScopeReplacer.__repr__, None, args)



# Generated at 2022-06-24 02:43:50.082993
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class FakeException(IllegalUseOfScopeReplacer):
        pass
    e1 = FakeException('e1', 'm1')
    e2 = FakeException('e2', 'm2')
    e3 = FakeException('e3', 'm1')
    e4 = IllegalUseOfScopeReplacer('e4', 'm1')
    assert(e1 == e1)
    assert(not (e1 == e2))
    assert(not (e1 == e3))
    assert(not (e1 == e4))
    assert(not ('Not a Exception' == e1))
    assert(not (e1 == 'Not a Exception'))



# Generated at 2022-06-24 02:43:55.568564
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    assert issubclass(IllegalUseOfScopeReplacer, Exception)
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = u"ScopeReplacer object 'name' was used incorrectly: msg: extra"
    assert_equals(unicode(e), u)



# Generated at 2022-06-24 02:43:59.495738
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda this, scope, name: name, 'x')
    scope_replacer.__setattr__('y', 'z')
    return scope == {'x': 'x', 'y': 'z'}



# Generated at 2022-06-24 02:44:03.363274
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Method __setattr__ of class ScopeReplacer"""
    pass

# Generated at 2022-06-24 02:44:10.742083
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Testing ScopeReplacer object"""
    from bzrlib.tests import multiply_tests
    t = {}
    s = ScopeReplacer(t, lambda self, scope, name: name, 'name')
    a = t['name']
    del t

# Generated at 2022-06-24 02:44:19.298797
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode

    Check that the unicode method returns a unicode object and that
    it can be converted to a unicode object.
    """
    fmt = u'a unicode message'
    e = IllegalUseOfScopeReplacer(u'name', fmt)
    u = unicode(e) # skip gettext
    assert isinstance(u, unicode)
    u = str(u) # skip gettext
    assert isinstance(u, unicode)
    e._preformatted_string = fmt
    u = unicode(e) # skip gettext
    assert isinstance(u, unicode)
    u = str(u) # skip gettext
    assert isinstance(u, unicode)

# Generated at 2022-06-24 02:44:27.149523
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__(): # unit test for ScopeReplacer.__getattribute__
    """Unit test for method '__getattribute__' of class 'ScopeReplacer'."""
    # g = ScopeReplacer({}, lambda self, scope, name: 'abc', 'x')
    # self.assertEquals(g.__getattribute__('upper'), 'ABC')
    # self.assertEquals(g.upper, 'ABC')
    # self.assertEquals(g._resolve, 'abc')
    raise NotImplementedError('please implement this method')

# Generated at 2022-06-24 02:44:37.412725
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    def _get_import_replacer_children(obj):
        return object.__getattribute__(
            obj, '_import_replacer_children')

    class ImportReplacerSubclass(ImportReplacer):
        pass

    # Child tests
    import_def = \
        (['import_replacer', 'test', 'test_lazy_import'],
         'ImportReplacer',
         {'ImportReplacerSubclass': (
             ['import_replacer', 'test', 'test_lazy_import'],
             'ImportReplacerSubclass',
             {}
         )})
    scope = {}
    replacer = ImportReplacerSubclass(scope, *import_def)
    assert _get_import_replacer_children(replacer)['ImportReplacerSubclass']


# Generated at 2022-06-24 02:44:45.236710
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test for __getattribute__"""
    from bzrlib.tests import TestCase
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-24 02:44:52.557122
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() should return a string that when
    eval'd, creates the same object and doesn't throw an error.
    """
    e = IllegalUseOfScopeReplacer('name', 'message')
    # eval will throw a SyntaxError if the repr is not valid Python
    e2 = eval(repr(e))
    # the repr ctor should create the same object
    assert e == e2



# Generated at 2022-06-24 02:45:03.176212
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # call function to test __getattribute__
    from bzrlib.lazy_import import ScopeReplacer as _ScopeReplacer
    from bzrlib.tests.test_lazy_import import ScopeReplacer as _testScopeReplacer
    from bzrlib.tests.test_lazy_import import TestScopeReplacer as _TestScopeReplacer
    scope = {}
    name = 'new_one'
    replacer = _ScopeReplacer(scope, _testScopeReplacer, name)
    replacer2 = _ScopeReplacer(scope, _TestScopeReplacer, name)
    assert_raises(IllegalUseOfScopeReplacer, replacer.__getattribute__, ('_resolve'))
    assert_raises(IllegalUseOfScopeReplacer, replacer.__call__, replacer, scope, name)
   

# Generated at 2022-06-24 02:45:09.620100
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the lazy_import method of ImportProcessor"""

    old_imports = list(sys.modules.keys())

# Generated at 2022-06-24 02:45:15.096948
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    def _factory(proxy, scope, name): return proxy
    sl_scope = {}
    sl = ScopeReplacer(sl_scope, _factory, 'sl')
    sl.attr = 1
    # called __setattr__
    return sl_scope == {'sl': 1}


# Generated at 2022-06-24 02:45:24.815585
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    class FakeLazyImport(object):
        def __init__(self, scope, name, module_path, member=None,
                     children={}):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children
            self.call_count = getattr(self, 'call_count', 0) + 1

    global_map = {}
    processor = ImportProcessor(lazy_import_class=FakeLazyImport)
    processor.lazy_import(global_map, "import foo")
    mock_foo = FakeLazyImport(global_map, name='foo', module_path=['foo'],
                              member=None, children={})
    assert global_map['foo'] is mock_foo

    processor.lazy_import

# Generated at 2022-06-24 02:45:29.721214
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should name the exception class and the exception message,
    and nothing else."""
    raise IllegalUseOfScopeReplacer(
        'name',
        'msg',
        'extra',
        )


# Generated at 2022-06-24 02:45:39.006955
# Unit test for function lazy_import
def test_lazy_import():

    # The method should work without an __file__
    imports = {}
    old_globals = globals().copy()
    lazy_import(globals(), '''
    from bzrlib import tests
    ''')
    new_globals = globals().copy()
    # This is our only new global, check to make sure it is correct
    old_globals.pop('__builtins__', None)
    new_globals.pop('__builtins__', None)
    if old_globals != new_globals:
        raise TestNotApplicable('lazy_imports do not work without __file__')
    # All it should have imported is 'tests'
    if 'tests' not in globals():
        raise TestNotApplicable('lazy_imports do not work without __file__')

# Generated at 2022-06-24 02:45:48.159039
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test function disallow_proxying.

    In particular, check that it works for imports done before it is
    called.
    """
    # First, define a lazy_import function that we can override later.
    # This is necessary to test the behaviour of disallow_proxying on
    # imports that have already happened.
    def lazy_import(scope, imports):
        return ScopeReplacer(scope, lambda obj, scope, name: None, 'test')

    # Check that we cannot call _resolve before it has been replaced
    test = lazy_import({}, '')
    try:
        test._resolve()
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('_resolve should fail before the object is'
                             ' replaced')

    # Check that we cannot proxy before it has

# Generated at 2022-06-24 02:45:55.708125
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class TestScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            ScopeReplacer.__init__(self, scope, factory, name)
            self.x = "abcd"
            self.y = 1234

    # Test Case: __getattribute__ - with valid subclass
    scope = {}
    obj = TestScopeReplacer(scope, lambda self, scope, name: self, "test")
    # Test Case: __getattribute__ - with valid subclass
    assert obj.__getattribute__("y") == 1234

    # Test Case: __getattribute__ - with valid subclass

# Generated at 2022-06-24 02:46:07.092222
# Unit test for constructor of class ScopeReplacer

# Generated at 2022-06-24 02:46:17.135870
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that proxying is disallowed when the function is called."""
    disallow_proxying()
    import bzrlib.lazy_import
    # bzrlib.lazy_import should already exist as an object.
    import bzrlib.branch
    # After running disallow_proxying, assigning the module to a variable is
    # an error.

# Generated at 2022-06-24 02:46:29.547297
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from .tests.test_lazy_import import TestCase

    class TestException(IllegalUseOfScopeReplacer):
        pass

    e = TestException('foo', 'bar', 'baz')
    e2 = TestException('foo', 'bar', None)
    e3 = TestException('foo', 'bar', 'baz')
    e4 = TestException('foo', 'baz', 'baz')
    e5 = TestException('bar', 'bar', 'baz')
    TestCase().assertNotEqual(e, e2)
    TestCase().assertEqual(e, e3)
    TestCase().assertNotEqual(e, e4)
    TestCase().assertNotEqual(e, e5)
    self = e
    TestCase().assertEqual(self, e)
    TestCase().assertEqual

# Generated at 2022-06-24 02:46:37.335460
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test the disallow_proxying function"""
    import sys

    v = 42
    lazy_import(sys.modules[__name__].__dict__, '''
    import sys
    import os
    ''')
    # lazy_import
    disallow_proxying()
    try:
        # Make sure the error is raised
        os.path
        raise AssertionError("indirection not detected")
    except IllegalUseOfScopeReplacer:
        pass
    try:
        sys.exc_clear()
    except AttributeError:
        pass
    # lazy_import
    lazy_import(sys.modules[__name__].__dict__, '''
    from bzrlib import (
        _mod_version,
        )
    ''')
    # lazy_import

# Generated at 2022-06-24 02:46:49.732635
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # This test is a bit of a mess to test that __getattribute__ can
    # be called on a basic class, while we are subclassing it.
    class Foo(object):
        def __init__(self, name):
            self.name = name
        def __getattribute__(self, attr):
            attr_dict = object.__getattribute__(self, '__dict__')
            return attr_dict[attr]
    class FooBar(Foo, ScopeReplacer):
        def __init__(self, name):
            Foo.__init__(self, name)
            ScopeReplacer.__init__(self, {}, lambda s,sc,n: s, 'foo')
    foo = FooBar('Francis')
    assert foo.name == 'Francis'

# Generated at 2022-06-24 02:46:53.639690
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() must return a unicode object"""
    e = IllegalUseOfScopeReplacer('a', 'b')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert e.__unicode__() == u


# Generated at 2022-06-24 02:47:03.403992
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from functools import partial
    import inspect
    import sys
    # For this to even run, the general replacer must work
    globals_dict = {'foo':'bar'}
    ScopeReplacer(scope=globals_dict, name='foo',
                  factory=partial(eval, 'foo'))
    if globals_dict['foo'] != 'bar':
        raise AssertionError('Replacer did not act as a direct reference')
    if globals_dict is not sys._getframe(1).f_globals:
        raise AssertionError('Replacer did not use the caller scope')
    # Use the import replacer to import a module

# Generated at 2022-06-24 02:47:09.779840
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that a ScopeReplacer can be created in a scope

    This tests the constructor and __setattr__
    """
    scope = {}
    name = 'foo'
    def factory(*args):
        return object()
    ScopeReplacer(scope, factory, name)
    # Check that the object is in the scope
    return scope[name]


# Generated at 2022-06-24 02:47:16.775922
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import as _mod_lazy_import
    import sys
    mod = _mod_lazy_import.ModuleToLoad('bzrlib.lazy_import', [], None, ('foo',), ('bar',), None, None)
    def get_foo(self, scope, name):
        mod.load_module()
        return scope[name]
    scope = {'foo':_mod_lazy_import.ScopeReplacer(sys.modules, get_foo, 'foo')}
    scope['foo']()
    __tracebackhide__ = True



# Generated at 2022-06-24 02:47:20.453857
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # Test the constructor
    from bzrlib import tests
    import bzrlib.tests, bzrlib
    ImportProcessor(ImportReplacer)
    ImportProcessor(ImportReplacer)



# Generated at 2022-06-24 02:47:25.997830
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ is tested"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert repr(e) == ("IllegalUseOfScopeReplacer('"
                       "name', 'msg', 'extra')")



# Generated at 2022-06-24 02:47:29.749309
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('test', 'something broke')
    res = unicode(e)
    assert isinstance(res, unicode)


# Generated at 2022-06-24 02:47:40.656700
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase

    class foo(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)

    class bar(object):
        pass
    bar._factory = lambda replacer, scope, name: foo()
    bar._should_proxy = False
    bar._name = 'bar'
    bar._real_obj = None
    bar._scope = None

    # we test this by directly setting attribute _resolve
    # (usually it's done by ScopeReplacer.__init__)
    bar._resolve = ScopeReplacer._resolve.__get__(bar)

    # case: ScopeReplacer.__call__ works
    result = bar(1, 'x', y=1, z=2)

# Generated at 2022-06-24 02:47:45.511089
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer

    This unit test is only testing that method __unicode__ does not raise
    any exception.  It does not test if the returned string is acceptable.
    """
    error = IllegalUseOfScopeReplacer('foo', 'Exception happened.')
    unicode(error)



# Generated at 2022-06-24 02:47:57.580565
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """__init__() for IllegalUseOfScopeReplacer"""
    assert (IllegalUseOfScopeReplacer('foo', '__getattr__', 'bar') ==
            IllegalUseOfScopeReplacer('foo', '__getattr__', 'bar'))
    assert ('IllegalUseOfScopeReplacer(foo, __getattr__: bar)'
            == repr(IllegalUseOfScopeReplacer('foo', '__getattr__', 'bar')))
    assert (IllegalUseOfScopeReplacer(None, '__getattr__', 'bar') ==
            IllegalUseOfScopeReplacer(None, '__getattr__', 'bar'))
    assert ('IllegalUseOfScopeReplacer(None, __getattr__: bar)'
            == repr(IllegalUseOfScopeReplacer(None, '__getattr__', 'bar')))



# Generated at 2022-06-24 02:48:05.450070
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    import unittest
    import warnings
    ScopeReplacer._should_proxy = False
    class Test(unittest.TestCase):
        def test(self):
            scope = {}
            def factory(self1, scope1, name1):
                self1.scope = scope1
                self1.name = name1
                return self1
            ScopeReplacer(scope, factory, 'name')
            self.assertRaises(IllegalUseOfScopeReplacer, setattr,
                              scope['name'], 'attr', 3)
    unittest.main(defaultTest='test_ScopeReplacer___setattr__.Test.test',
                  argv=[''])



# Generated at 2022-06-24 02:48:12.503757
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    scope = {}
    ip = ImportProcessor()
    ip.lazy_import(scope=scope, text="""
import bzrlib
from bzrlib import osutils
import (bzrlib.diff,
        bzrlib.lsprof as lsprof)
from bzrlib.tests import TestUtil
from bzrlib.tests.blackbox import TestCaseWithTransport
""")
    # The import processor produces a map of the items to be imported.

# Generated at 2022-06-24 02:48:16.959292
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import) # force a reload of the module to run the selftest
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import osutils
    ''')
    osutils.cwd('.') # will trigger ScopeReplacer.__call__



# Generated at 2022-06-24 02:48:25.935233
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib import lazy_import
    old_should_proxy = lazy_import.ScopeReplacer._should_proxy
    try:
        lazy_import.disallow_proxying()
        try:
            lazy_import.ScopeReplacer._should_proxy
        except AttributeError:
            pass
        else:
            raise AssertionError("_should_proxy still available")
    finally:
        # Reset so other tests don't have a problem
        lazy_import.ScopeReplacer._should_proxy = old_should_proxy



# Generated at 2022-06-24 02:48:31.397823
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = u'xyzzy'
    i = IllegalUseOfScopeReplacer('a', u)
    s = unicode(i)
    # gettext returns unicode, so this will be a plain 'unicode' object
    if isinstance(s, str):
        raise AssertionError(s)
    if not isinstance(s, unicode):
        raise AssertionError(s)
    if s != u:
        raise AssertionError(s)



# Generated at 2022-06-24 02:48:41.397444
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert 'IllegalUseOfScopeReplacer' in repr(e)
    assert 'foo' in repr(e)
    assert 'bar' in repr(e)
    assert e ==  IllegalUseOfScopeReplacer('foo', 'bar')
    assert not e == IllegalUseOfScopeReplacer('foo', 'bar', 'extrathing')
    assert not e == IllegalUseOfScopeReplacer('foo', 'baz')
    assert not e == IllegalUseOfScopeReplacer('foobar', 'baz')
    assert not e == IllegalUseOfScopeReplacer('foobar', 'baz', 'extrathing')



# Generated at 2022-06-24 02:48:47.945389
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # scope = {'name' : 'value'}
    scope = {'name': 'value'}
    # lazy = ScopeReplacer(scope, lambda self, scope, name: scope[name], 'name')
    lazy = ScopeReplacer(scope, lambda self, scope, name: scope[name], 'name')
    # lazy.name = 'value2'
    lazy.name = 'value2'
    # assert lazy.name == 'value2'
    assert lazy.name == 'value2'
    # assert scope['name'] == 'value'
    assert scope['name'] == 'value'

# Generated at 2022-06-24 02:48:58.897331
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that the constructor of class ImportReplacer is working correctly

    We test the documentation in the docstring of __init__ of class
    ImportReplacer.

    i.e. check:
        import foo => name='foo' module_path='foo',
                      member=None, children={}
        import foo.bar => name='foo' module_path='foo', member=None,
                          children={'bar':(['foo', 'bar'], None, {}}
        from foo import bar => name='bar' module_path='foo', member='bar'
                               children={}
        from foo import bar, baz would get translated into 2 import
        requests. On for 'name=bar' and one for 'name=baz'
    """
    class MockScope(object):
        pass
    class MockModule(object):
        pass

    #

# Generated at 2022-06-24 02:49:10.327922
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Ensure that __str__ works without crashing."""
    import sys
    import types
    import bzrlib
    exception_class = bzrlib.lazy_import._get_exception_class()
    if (exception_class is IllegalUseOfScopeReplacer
        and hasattr(sys, 'gettotalrefcount')):
        # This is a CPython interpreter that has refcount debugging
        # available.  We can run some extra tests.
        import gc
        t = IllegalUseOfScopeReplacer('foo', 'bar')
        # Check that the reference count of t and its contents does
        # not leak:
        tn = sys.gettotalrefcount()
        t.__str__()
        tn1 = sys.gettotalrefcount()
        t.__str__()
        tn2 = sys.get

# Generated at 2022-06-24 02:49:22.111920
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test function for method __call__ of class ScopeReplacer
    # __call__(self, *args, **kwargs)
    # Test that the ScopeReplacer can be called
    assert self.__call__() == self._resolve()

    # Test when the real object is a class
    class TestObject(object):
        def __init__(self):
            pass
    o = self.__class__(globals(), lambda s, g, n: TestObject, 'TestObject')

# Generated at 2022-06-24 02:49:31.909193
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import (
        explorer,
        osutils,
        )
    from bzrlib.__init__ import *
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        explorer,
        osutils,
        )
    import bzrlib.__init__
    import bzrlib.explorer
    import bzrlib.osutils
    ''')
    # Make sure the replacement process is not broken by other changes
    # in the program's global state.
    # (LP #1114556)
    from bzrlib import debug

# Generated at 2022-06-24 02:49:36.093742
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_obj = ScopeReplacer(None, None, None)
    test_obj.attr = 'value'
    test_obj.attr
    test_obj.attr = 'new value'
    test_obj._resolve().attr

# Generated at 2022-06-24 02:49:47.822370
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.lazy_import import (
        ScopeReplacer,
        ImportReplacer,
        ImportProcessor,
        )
    mod = DeferredModule()
    d = {'mod':mod}

# Generated at 2022-06-24 02:49:56.414077
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the lazy_import method of the ImportProcessor class."""
    local_scope = {}
    imports = """
import foo
from foo import bar
import foo.bar.baz as q
from foo import *
import foo.bing, foo.baz.bar
    """
    ip = ImportProcessor()
    ip.lazy_import(local_scope, imports)
    # Now lets check the children of the top level imports.
    assert_equals(2, len(local_scope['foo']._import_replacer_children))
    assert 'bar' in local_scope['foo']._import_replacer_children
    assert 'bing' in local_scope['foo']._import_replacer_children

    assert_equals(1, len(local_scope['q']._import_replacer_children))
   

# Generated at 2022-06-24 02:50:08.967724
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Constructor for IllegalUseOfScopeReplacer exceptions."""
    import re
    from bzrlib.transport.http import _mod_ssl

# Generated at 2022-06-24 02:50:12.351565
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test_IllegalUseOfScopeReplacer___str__ - Test method __str__ of class
    IllegalUseOfScopeReplacer.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # Test that __str__() returns a 'str' object.
    assert isinstance(e.__str__(), str)

# Generated at 2022-06-24 02:50:21.212042
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}

    scope['foo'] = ImportReplacer(scope=scope, name='foo', module_path=['foo'],
                                  member=None, children={})

    scope['foo'].bar = ImportReplacer(scope=scope, name='bar',
                                      module_path=['foo', 'bar'],
                                      member=None, children={})

    scope['foo'].bar.baz = ImportReplacer(scope=scope, name='baz',
                                          module_path=['foo', 'bar', 'baz'],
                                          member=None, children={})

    scope['foo'].bar.baz.fn = ImportReplacer(scope=scope, name='fn',
                                             module_path=['foo', 'bar', 'baz'],
                                             member='fn', children={})

   

# Generated at 2022-06-24 02:50:25.836042
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    l = []
    def f(x):
        l.append(x)
    s = ScopeReplacer({}, lambda x,y,z: f, 'f')
    s(1)
    assert l == [1]

# Generated at 2022-06-24 02:50:36.156067
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ the same as for the underlying object"""
    class DummyClass(object):
        def __init__(self):
            self.attr1 = None
        def __setattr__(self, attr, value):
            if attr == 'attr2':
                raise RuntimeError('__setattr__ called with: %s, %s'
                                   % (attr, value))
            else:
                object.__setattr__(self, attr, value)
    dummy = DummyClass()
    scope = {}
    lazy_obj = ScopeReplacer(scope, lambda x, s, n: dummy, 'name')
    lazy_obj.attr1 = 1
    dummy.attr1 = 2
    assert_equal(lazy_obj.attr1, 2)
    lazy_obj.attr2 = 3
    assert_ra

# Generated at 2022-06-24 02:50:44.726244
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import re
    scope = globals()
    scope['foo'] = 'baz'
    def string_factory(self, scope, name):
        return scope[name]
    try:
        a = ScopeReplacer(scope, string_factory, 'foo')
    except re.error:
        raise AssertionError('ScopeReplacer raises re.error on legit input')
    try:
        b = ScopeReplacer(scope, string_factory, 'foobar')
        raise AssertionError('ScopeReplacer should prevent overwriting'
                             ' existing keys')
    except KeyError:
        pass



# Generated at 2022-06-24 02:50:55.187857
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Create IllegalUseOfScopeReplacer and test it is initialized correctly."""
    # Check that the class can be instantiated
    example = IllegalUseOfScopeReplacer('a', 'b', 'c')
    # Check that the instance is initialized correctly
    assert example.name == 'a'
    assert example.msg == 'b'
    assert example.extra == ': c'
    # Check that the format string has been set
    assert example._fmt == ("ScopeReplacer object %(name)r was used incorrectly:"
                            " %(msg)s%(extra)s")
    # Check that the object is formatted correctly
    assert str(example) == ("ScopeReplacer object 'a' was used incorrectly:"
                            " b: c")



# Generated at 2022-06-24 02:51:04.852772
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method IllegalUseOfScopeReplacer.__eq__

    This class is a subclass of Exception, but has a special equality test.
    """
    # check that the comparison is implemented
    e1 = IllegalUseOfScopeReplacer('name', 'message')
    e1.attr1 = 'attr1'
    e1.attr2 = 'attr2'
    e2 = IllegalUseOfScopeReplacer('name', 'message')
    e2.attr1 = 'attr1'
    e2.attr2 = 'attr2'
    assert e1 == e2
    assert e2 == e1
    del e2.attr2
    assert e1 != e2
    assert e2 != e1
    e2.attr2 = 'attr2'
    e2.attr1 = 'attr1x'
    assert e1 != e

# Generated at 2022-06-24 02:51:06.763197
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import __builtin__
    assert __builtin__.__dict__.items() == __builtin__.__dict__.items()

# Generated at 2022-06-24 02:51:19.389908
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from cStringIO import StringIO
    from bzrlib.tests import TestCase
    import pprint
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test___setattr__(self):
            _scope = locals()
            _factory = None
            _name = 't'
            _real_obj = None
            __slots__ = ('_scope', '_factory', '_name', '_real_obj')
            _should_proxy = True
            t = ScopeReplacer(_scope, _factory, _name)
            s = StringIO()
            pprint.pprint(t.__dict__, s)

# Generated at 2022-06-24 02:51:29.697293
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    ScopeReplacer._should_proxy = True
    try:
        lazy_import(globals(), '''
        from bzrlib import (
            diff as real_diff,
            )
        ''')
        assert diff is not real_diff
        diff.diff = 'hello'
        assert real_diff.diff == 'hello'
        ScopeReplacer._should_proxy = False
        try:
            diff.diff = 'goodbye'
        except IllegalUseOfScopeReplacer as e:
            assert e._name == 'diff'
            assert e.msg.startswith('Object already replaced')
        else:
            raise AssertionError()
    finally:
        ScopeReplacer._should_proxy = True
        del bzrlib.diff
        del diff



# Generated at 2022-06-24 02:51:39.209096
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ on IllegalUseOfScopeReplacer should pretty print"""

    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import pprint
    def compare(expected, got):
        if expected != got:
            raise AssertionError("Expected %r, got %r" % (expected, got))

    e = IllegalUseOfScopeReplacer("foo", "bar")
    compare("IllegalUseOfScopeReplacer('foo', 'bar')",
               repr(e))
    e = IllegalUseOfScopeReplacer("foo", "bar", "baz\nbaz")
    compare("IllegalUseOfScopeReplacer('foo', 'bar', 'baz\\nbaz')",
               repr(e))
    e = IllegalUseOfScopeReplacer("foo", "bar", "baz\nbaz\n")

# Generated at 2022-06-24 02:51:43.059012
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    # There doesn't seem to be a way to implement a test for this method
    # without defining a class ExceptionWithUnicodeDefinedForTesting so
    # we don't define it.
    # This method is only tested through test_exception.py
    pass



# Generated at 2022-06-24 02:51:54.635847
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global _test_ScopeReplacer_scope
    global _test_ScopeReplacer_factory
    global _test_ScopeReplacer_name
    _test_ScopeReplacer_scope = {}

    def _test_ScopeReplacer_factory(self, scope, name):
        obj = _test_ScopeReplacer_scope[name](*self.__call_args,
                                              **self.__call_kwargs)
        return obj

    _test_ScopeReplacer_name = '_test_ScopeReplacer_name'
    _test_ScopeReplacer_scope[_test_ScopeReplacer_name] = lambda x, y: x + y
    obj = ScopeReplacer(_test_ScopeReplacer_scope,
                        _test_ScopeReplacer_factory,
                        _test_ScopeReplacer_name)
    obj.__call_

# Generated at 2022-06-24 02:51:58.116539
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer.
    """
    iuossre = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert repr(iuossre) == (
        "IllegalUseOfScopeReplacer('name', 'msg', 'extra')")



# Generated at 2022-06-24 02:52:05.668940
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Method test: __repr__"""
    # See https://bugs.launchpad.net/bzr/+bug/511524
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e1 = IllegalUseOfScopeReplacer("foo", 'bar', 'baz')
    e1_repr = repr(e1)
    exec('e2 = %s' % e1_repr)
    if e1 != e2:
        raise AssertionError("%r != %r" % (e1, e2))


test_IllegalUseOfScopeReplacer___repr__.__test__ = False



# Generated at 2022-06-24 02:52:14.645794
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # test __setattr__ of ScopeReplacer
    # __setattr__ of ScopeReplacer: Calls setattr on the object that this
    # object is a proxy for.
    # Calling __setattr__ must resolve object.
    attr = 'an_attribute'
    value = object()
    class Concrete(object):
        pass
    obj = object()
    scope = {}
    name = 'name'
    factory_called = []
    def factory(self, scope, name):
        factory_called.append((self, scope, name))
        return obj
    scope_replacer = ScopeReplacer(scope, factory, name)
    scope_replacer.__setattr__(attr, value)
    eq(len(factory_called), 1)

# Generated at 2022-06-24 02:52:21.749297
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__() should return the expected string

    This test is for the method '__repr__' of the class
    'IllegalUseOfScopeReplacer' in the module 'bzrlib.lazy_import'.
    """
    # This test can not be implemented as it's not possible to create
    # an instance of type IllegalUseOfScopeReplacer without calling
    # one of the constructors __init__.
    # The method __init__ can not be tested as it is a constructor
    # and it's not possible to create an instance of the class
    # under test.
    # return

# Generated at 2022-06-24 02:52:29.739160
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should convert any object to a string"""
    obj = IllegalUseOfScopeReplacer('name', 'message')

# Generated at 2022-06-24 02:52:40.459094
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    import bzrlib.trace
    import bzrlib.ui
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.commands
    import bzrlib.plugins.selftest.__init__
    ''')
    # test target ScopeReplacer.__getattribute__
    bzrlib.plugins.selftest.__init__.scope_replacer_func = bzrlib.lazy_import.ScopeReplacer
    bzrlib.ui.ui_factory = bzrlib.commands.Command.ui_factory
    bzrlib.trace.note('test_ScopeReplacer___getattribute__')
    return

# Generated at 2022-06-24 02:52:49.656940
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # The class is not public, but we want to test it.
    old_should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-24 02:52:55.918209
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object containing str

    As an exception that is never seen, it does not need to be
    translated, just formatted properly.
    """
    e = IllegalUseOfScopeReplacer('obj', 'message')
    result = unicode(e)
    expected = 'obj was used incorrectly: message'
    if result != expected:
        raise AssertionError('%r != %r' % (result, expected))



# Generated at 2022-06-24 02:53:04.501403
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import gc
    # A dummy scope which holds any values set.
    scope = {}
    def factory(sr, scope, name):
        return 42

    # create a ScopeReplacer
    x = ScopeReplacer(scope, factory, 'x')
    # check that the scopereplacer is being used instead of the real
    # object
    assert x == 42
    # check that scope was populated as expected
    assert scope['x'] is x
    # force a gc cycle to ensure that we don't leak the reference to
    # the scope
    gc.collect()



# Generated at 2022-06-24 02:53:09.343997
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # What happens if the module is imported before the import happens?
    a = ScopeReplacer(globals(), __test_ScopeReplacer_gen, 'a')
    from bzrlib.tests import test_lazy_import
    test_lazy_import.__test_ScopeReplacer_gen(a, globals(), 'a')