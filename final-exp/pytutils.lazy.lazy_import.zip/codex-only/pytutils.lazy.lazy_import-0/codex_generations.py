

# Generated at 2022-06-24 02:43:15.847281
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test __eq__ of class IllegalUseOfScopeReplacer"""
    from sys import exc_info
    import bzrlib.lazy_import as lazy_import
    # Recreate the exception here because if this was run from the cmdline,
    # the exception object won't have the __dict__ attribute (this is a bug
    # in Python).
    e = lazy_import.IllegalUseOfScopeReplacer('fname', 'msg', 'extra')
    e2 = lazy_import.IllegalUseOfScopeReplacer('fname', 'msg', 'extra')
    e3 = lazy_import.IllegalUseOfScopeReplacer('fname2', 'msg', 'extra')
    e4 = lazy_import.IllegalUseOfScopeReplacer('fname', 'msg2', 'extra')
    assert e == e2
    assert not e

# Generated at 2022-06-24 02:43:28.950681
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of ImportReplacer (and its helper function)."""
    def check(name, module_path, member, children, expect_exception):
        try:
            cls = object.__getattribute__(ImportReplacer, '__class__')
            cls(scope={}, name=name, module_path=module_path, member=member,
                children=children)
        except (ValueError, TypeError):
            if expect_exception:
                pass
            else:
                raise

    # Check invalid inputs
    check('foo', ['foo'], None, {}, expect_exception=True)
    check('foo', ['foo'], 'bar', {}, expect_exception=True)

# Generated at 2022-06-24 02:43:39.690365
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for __eq__ method of class IllegalUseOfScopeReplacer"""
    # Test that __eq__ works and that it doesn't check the instance
    # attribute _preformatted_string.  This is especially important in
    # order to support pickling.
    a = IllegalUseOfScopeReplacer('name', 'msg')
    b = IllegalUseOfScopeReplacer('name', 'msg')
    assert a == b
    assert not a != b
    c = IllegalUseOfScopeReplacer('name', 'msg2')
    assert a != c
    assert not a == c
    d = IllegalUseOfScopeReplacer('name2', 'msg')
    assert a != d
    assert not a == d


from bzrlib import (
    symbol_versioning,
    )


from bzrlib.lazy_import import lazy

# Generated at 2022-06-24 02:43:51.857260
# Unit test for function lazy_import
def test_lazy_import():
    import os
    import sys


# Generated at 2022-06-24 02:44:01.381258
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    class Testable(object):
        def __setattr__(self, name, value):
            self.name = name
            self.value = value
    testable = Testable()
    testable2 = Testable()
    ScopeReplacer._should_proxy = True
    x = ScopeReplacer({}, lambda self,a,b: testable, 'zz')
    x.blah = 'blah'
    ScopeReplacer._should_proxy = False
    try:
        x.blah2 = 'blah2'
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('setting attr on replaced obj should fail')
    # If we were able to set an attribute on the object, then check it
    # was actually set

# Generated at 2022-06-24 02:44:08.505548
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():

    # slotted attribute
    scope = {}
    obj = ScopeReplacer(scope, lambda: 1, 'a')
    assert obj._real_obj is None
    assert obj._scope == scope
    assert obj._factory(None, None, None) == 1
    assert obj._name == 'a'
    assert obj._scope is scope
    assert obj._resolve() == 1
    assert obj._real_obj == 1
    assert scope['a'] == 1
    assert obj._name == 'a'
    assert obj._factory(None, None, None) == 1
    assert obj._scope is scope

    # normal attribute
    scope = {}
    obj = ScopeReplacer(scope, lambda: 2, 'b')
    assert obj.b == 2
    assert scope['b'] == 2

    # normal attribute with __setattr__
    scope

# Generated at 2022-06-24 02:44:17.957416
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import testtools
    from testtools import TestCase
    from testtools.matchers import Equals

    class TestScopeReplacer(TestCase):

        def test_setattr_once_resolved(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Tracker(object):
                def __eq__(self, other):
                    return self.__class__ is other.__class__
            class Resolved(object):
                __slots__ = ['x']
            resolved_obj = Resolved()
            resolved_obj.x = Tracker()
            def factory(self, scope, name):
                return resolved_obj
            scope = {}
            replacer = ScopeReplacer(scope, factory, 'y')
            def set_x():
                replacer.x = Tracker()

# Generated at 2022-06-24 02:44:24.776789
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """This tests the ImportProcessor class"""
    importer = ImportProcessor()
    importer.lazy_import({}, text=dedent("""\
        import foo
        from foo import bar
        import foo.bar
        import foo.bar.baz, foo.bar.bing
        from foo.bar import fred, bob
        import foo.bar as barry, barry as bar
        from foo.bar.baz import bing, bing as bong, bing, bing, bing as baz
        """))

# Generated at 2022-06-24 02:44:31.424393
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {'var': None}
    factory = lambda self, scope, name: scope[name]

    def fails():
        ScopeReplacer(scope, factory, 'var')

    def succeeds():
        # ScopeReplacer(scope, lambda self, scope, name: self, 'var')
        scope['var'] = ScopeReplacer(scope, factory, 'var')

    import bzrlib.tests as tests
    tests.TestSkipped('assertRaises not working in pycurl.py')
    #tests.assertRaises(TODO, fails)
    succeeds()



# Generated at 2022-06-24 02:44:41.135070
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib import (
        errors,
        osutils,
        urlutils,
        branch,
        )
    import bzrlib.branch
    import testtools.matchers as M

    d = {'errors':errors, 'osutils':osutils, 'urlutils':urlutils, 'branch':branch, 'bzrlib':bzrlib}
    d = {k:v.__module__.split('.')[-1] for k,v in d.iteritems()}
    M.assert_that(d, M.Equals({'errors': 'errors', 'osutils': 'osutils', 'urlutils': 'urlutils', 'branch': 'branch', 'bzrlib': 'branch'}))
# Unit test

# Generated at 2022-06-24 02:44:48.912846
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ must return a boolean value"""
    instance1 = IllegalUseOfScopeReplacer("name", "msg")
    instance2 = IllegalUseOfScopeReplacer("name", "msg")
    instance3 = IllegalUseOfScopeReplacer("name", "msg", "extra")
    instance4 = IllegalUseOfScopeReplacer("other", "msg", "extra")
    instance5 = IllegalUseOfScopeReplacer("other", "other", "extra")
    class Dummy: pass
    instance6 = Dummy()
    #__eq__ is missing
    assert instance1 is not instance2
    assert instance1 == instance2
    assert instance2 == instance1
    assert instance2 != instance3
    assert instance3 != instance4
    assert instance4 != instance5
    assert instance5 != instance6
    assert instance6 != instance1



# Generated at 2022-06-24 02:44:52.919113
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """The equality method for IllegalUseOfScopeReplacer is correct."""
    # This test is designed to protect against regressions.
    from operator import eq
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    a = IllegalUseOfScopeReplacer("n", "m")
    b = IllegalUseOfScopeReplacer("n", "m")
    c = IllegalUseOfScopeReplacer("n", "mm")
    assert eq(a, b)
    assert not eq(a, c)
    assert not eq(b, c)
    assert not eq(1, a)


# Generated at 2022-06-24 02:44:54.417799
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """`IllegalUseOfScopeReplacer.__str__` function has no unit test."""
    pass



# Generated at 2022-06-24 02:45:04.159221
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy_import"""

    # Need this to access the real module
    import sys

    # This is used to register globals for the module
    global_map = {}
    # We need this so that importing a module doesn't actually import it
    class DummyImportProcessor(ImportProcessor):
        def _convert_imports(self, scope):
            global_map[scope['__name__']] = scope

    # This is the text that we will be importing
    import_text = '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    '''
    # Do the import
    proc = DummyImportProcessor()

# Generated at 2022-06-24 02:45:10.285155
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.per_lazy_import import TestCaseWithLazyImport

    class TestObject(object):
        some_field = 42
        def some_method(self):
            pass

    test_scope = {}
    def test_factory(scope_replacer, scope, name):
        return TestObject()

    def test_factory_with_self(scope_replacer, scope, name):
        return scope_replacer

    def test_factory_with_self_ref(scope_replacer, scope, name):
        return scope_replacer, scope_replacer

    def test_factory_with_scope_ref(scope_replacer, scope, name):
        return scope, scope


# Generated at 2022-06-24 02:45:13.922360
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.test_lazy_import import Stub

    obj = ScopeReplacer(globals(), lambda o,s,n: Stub(), 'x')
    obj.a = 1
    assert obj.a == 1


# Generated at 2022-06-24 02:45:18.533376
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    e = IllegalUseOfScopeReplacer(None, None)
    repr(e)


# Generated at 2022-06-24 02:45:22.551383
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import doctest
    # FIXME: It is too risky to run these doctests on a production
    # machine (they contain '__setattr__' and try to abuse it, so they
    # can very easily hang your machine)
    # doctest.testmod(scope_replacer, verbose=True)
    pass


# Generated at 2022-06-24 02:45:26.064353
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Method __setattr__ of class ScopeReplacer"""
    # get the class
    cls = ScopeReplacer
    # because of inheritance, this method might be overwritten
    assert cls.__setattr__.im_func is not object.__setattr__.im_func


# Generated at 2022-06-24 02:45:37.209485
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import, ModuleNotFound
    lazy_import(globals(), 'bar', 'baz')
    # This should work without any problem.
    __ = globals()['bar']
    globals()['bar'] = 25
    disallow_proxying()
    def set_and_get_bad():
        globals()['bar'] = __
        __ = globals()['bar']
    def set_bad():
        globals()['bar'] = __
    def get_bad():
        __ = globals()['bar']
    e = None
    try:
        set_and_get_bad()
    except IllegalUseOfScopeReplacer as e:
        pass

# Generated at 2022-06-24 02:45:43.689642
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    class MyIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        _fmt = "Test message for %(int_arg)d, %(str_arg)s"
        def __init__(self, int_arg, str_arg):
            self.int_arg = int_arg
            self.str_arg = str_arg
    e = MyIllegalUseOfScopeReplacer(1, 'hello')

# Generated at 2022-06-24 02:45:51.596736
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # NOTE: Not directly testing ImportProcessor, as it is used during the
    #       setup of the tests. This is still testing the low level
    #       conversion process, so is still valid.

    scope = {}

    def test(text, imports):
        """Process the given text and make sure the imports match"""
        importer = ImportProcessor(lazy_import_class=MockImportReplacer)
        importer.lazy_import(scope, text)
        # Inject the new imports into the scope
        scope.update(importer.imports)
        # Make sure they all get resolved to something
        scope_copy = scope.copy()
        scope_copy['ImportProcessor'] = ImportProcessor
        scope_copy['MockImportReplacer'] = MockImportReplacer

# Generated at 2022-06-24 02:46:02.572556
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of ImportReplacer"""
    # This function is allowed to use property_set; not all tests can
    # TODO: make it so that the tests in constructors.py can use property_set
    from bzrlib.tests import TestCase
    # Cannot do this with setUpClass, as setUpClass is not available in
    # Python 2.4
    from bzrlib.lazy_import import property_set
    _orig_property_set = property_set

    # Subclass to access protected methods
    class _Test(ImportReplacer):
        def _test_constructor(self):
            return self._import(self._scope, self._name)

    class TestImportReplacer(TestCase):

        def test_constructor_member(self):
            """Test ImportReplacer constructor with a member"""

# Generated at 2022-06-24 02:46:13.488519
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('e', 'm', 'extra')
    str(e)
    repr(e)
    if e != e:
        raise AssertionError('exception not equal to itself')
    ne = IllegalUseOfScopeReplacer('e', 'm', 'extra')
    if e != ne:
        raise AssertionError('2 exceptions with same attributes not ==')
    ne = IllegalUseOfScopeReplacer('e', 'm', 'xextra')
    if e == ne:
        raise AssertionError('2 exceptions with different attributes are ==')
    ne = IllegalUseOfScopeReplacer('e', 'mm', 'extra')
    if e == ne:
        raise AssertionError('2 exceptions with different attributes are ==')
    ne = IllegalUseOfScopeReplacer('ee', 'm', 'extra')


# Generated at 2022-06-24 02:46:20.951201
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the lazy_import method of ImportProcessor class.

    This test checks that the lazy_import method can handle imports in
    different forms (only the root module, a module and a submodule,
    importing a module under a different name and importing several
    modules in the same statement).
    """
    import bzrlib

    # Import a module
    scope = {'__name__': '__main__'}
    ImportProcessor().lazy_import(scope, 'import bzrlib')
    # Check that bzrlib is not imported, but replaced with a ScopeReplacer
    # object and that it can be successfully imported
    assert isinstance(scope['bzrlib'], ScopeReplacer)
    assert scope['bzrlib'] is not bzrlib
    scope_bzrlib = scope['bzrlib']

# Generated at 2022-06-24 02:46:28.279040
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError('IllegalUseOfScopeReplacer.__unicode__ must '
           'return a unicode object, not a %r.' % (type(u),))



# Generated at 2022-06-24 02:46:39.269908
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class TestClass(object):
        def __call__(self, *args, **kwargs):
            return args, kwargs
    scope = {}
    lazy_import(scope, "from bzrlib.lazy_import import ScopeReplacer")
    scope['TestClass'] = TestClass
    scope['obj'] = None
    scope['obj'] = ScopeReplacer(scope, lambda self, scope, name: scope['TestClass'](), 'obj')
    args = (1, 2, 3)
    kwargs = {'foo': 'bar'}
    value = scope['obj'](*args, **kwargs)
    if (value != (args, kwargs)):
        return False
    return True

# Generated at 2022-06-24 02:46:47.145887
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ for ScopeReplacer"""
    scope = {}
    name = 'bar'
    # DocTest uses a single ScopeReplacer variable, so we can't use
    # a factory that creates anything that could be confused with a
    # ScopeReplacer variable.
    def factory(self, scope, name):
        return object()
    obj = ScopeReplacer(scope, factory, name)
    assert scope['bar'] is obj


# Generated at 2022-06-24 02:46:55.079156
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib.tests.blackbox.test_lazy_import import TestImportReplacer
    testobj = TestImportReplacer()
    testprocessor = ImportProcessor(TestImportReplacer)
    testprocessor.lazy_import(testobj.__dict__,
        'from bzrlib.foo import (Bar, BzrError, Foo)\n')
    testprocessor.lazy_import(testobj.__dict__,
        'import bzrlib.foo\n')
    testprocessor.lazy_import(testobj.__dict__,
        'from bzrlib import foo\n')
    testprocessor.lazy_import(testobj.__dict__,
        'import bzrlib.foo.bar as bing\n')

# Generated at 2022-06-24 02:47:02.181385
# Unit test for function disallow_proxying
def test_disallow_proxying():
    global x, y
    x = "original"
    y = "original"
    disallow_proxying()
    scope = globals()
    scope['x'] = ScopeReplacer(scope, lambda o, s, n: s[n], 'x')
    scope['y'] = ScopeReplacer(scope, lambda o, s, n: s[n], 'y')

# Generated at 2022-06-24 02:47:04.978251
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import doctest
    return doctest.run_docstring_examples(ScopeReplacer.__setattr__, globals())


# Generated at 2022-06-24 02:47:15.817965
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Testing ImportProcessor.lazy_import"""
    # Works with an empty scope
    scope = {}
    processor = ImportProcessor()
    processor.lazy_import(scope, 'import foo')
    processor.lazy_import(scope, 'import bzrlib.foo')
    assert scope['foo'] is scope['bzrlib'].foo

    # From style imports work
    scope = {}
    processor = ImportProcessor()
    processor.lazy_import(scope, 'from foo import bar')
    assert scope['bar'] is scope['foo'].bar

    # as style renaming works
    scope = {}
    processor = ImportProcessor()
    processor.lazy_import(scope, 'import foo.bar as bing')
    assert scope['bing'] is scope['foo'].bar

    # Imports that conflict result

# Generated at 2022-06-24 02:47:21.018551
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    t = ScopeReplacer(object() ,object() ,object())
    def test_func ():
        try:
            t.__setattr__(object() ,object())
        except TypeError:
            return True
        else:
            return False
    return test_func()

# Generated at 2022-06-24 02:47:26.410451
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()

    __str__() should return the encoded unicode object.
    """
    inst = IllegalUseOfScopeReplacer('a', 'b', 'c')

# Generated at 2022-06-24 02:47:35.592454
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method __eq__ of class IllegalUseOfScopeReplacer
    """
    def test_one(foo=None, bar=None, msg=None, extra=None):
        obj1 = IllegalUseOfScopeReplacer(foo, bar, extra)
        obj2 = IllegalUseOfScopeReplacer(foo, bar, extra)
        obj3 = IllegalUseOfScopeReplacer(foo, bar, 'extra')
        obj4 = IllegalUseOfScopeReplacer('foo', 'bar', 'extra')
        assert obj1 == obj2, 'Objects: %r, %r' % (obj1, obj2)
        assert obj1 != obj3, 'Objects: %r, %r' % (obj1, obj3)
        assert obj1 != obj4, 'Objects: %r, %r' % (obj1, obj4)
   

# Generated at 2022-06-24 02:47:45.612751
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for constructor of class ScopeReplacer."""
    # Stuff for the scope that we'll create
    scope1 = {}
    scope2 = {}
    scope1['scope2'] = scope2
    scope3 = {}
    scope2['scope3'] = scope3

    # The factory function
    def factory(self, scope, name):
        return scope

    # Test for case when the scope is the local scope
    ScopeReplacer(locals(), factory, 'scope1')
    assert scope1 is locals()['scope1'], "Wrong scope in ScopeReplacer"

    # Test for case when the scope is a scope 2 levels deep
    ScopeReplacer(locals(), factory, 'scope3')
    assert scope3 is scope2['scope3'], "Wrong scope in ScopeReplacer"



# Generated at 2022-06-24 02:47:57.776847
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ returns utf-8 encoded message"""
    # 1. Verify that a standard message is correctly encoded
    e = IllegalUseOfScopeReplacer(u'foo', u'bar')
    # We can't compare the encoded object directly with a unicode object
    # because they have different types. The str builtin performs the equivalent
    # of the following:
    #    return unicode(e).encode('utf-8')
    # so we use it to do the conversion and then compare.
    assert str(e) == unicode(e).encode('utf-8')

    # 2. Verify that a message with a unicode object in it is correctly encoded
    e = IllegalUseOfScopeReplacer(u'foo', u'bar', u'baz')

# Generated at 2022-06-24 02:48:04.488628
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Construction and assignment of attributes of a ScopeReplacer object
    # should work and appear to set attributes on the underlying object.
    #
    # See http://pad.lv/273573 and http://pad.lv/273580
    #
    # This test was added in response to a bug in ThreadedResolver, where
    # the threading.local implementation in some Python versions fails
    # silently to store attributes on objects used as values in a
    # threading.local dict.
    result = []
    def factory(self, scope, name):
        result.append(self._factory)
        return self._factory
    scope = {}
    ScopeReplacer(scope, factory, 'foo')
    scope['foo'].x = 1
    scope['foo']
    scope['foo'] = 1
    scope['foo'].y = 2

# Generated at 2022-06-24 02:48:16.584315
# Unit test for function disallow_proxying
def test_disallow_proxying():
    _test_dir = 'a_string_that_must_not_exist'
    import bzrlib.tests
    scope = locals()
    lazy_import(scope, 'from bzrlib.tests import TestCase')
    lazy_import(scope, 'from bzrlib.tests import test_case')
    disallow_proxying()
    # Before the import, both variables should point to
    # bzrlib.lazy_import.ScopeReplacer, after the import they should
    # point to the real module.
    try:
        TestCase.__module__
    except IllegalUseOfScopeReplacer:
        # scope['TestCase'] is the scope replacer, and thus the check
        # for its module was disallowed. This is the expected result.
        pass

# Generated at 2022-06-24 02:48:25.901183
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of class ImportReplacer"""
    import bzrlib.tests.test_lazy_import as test_module
    module = test_module.ImportReplacer(
            globals(),
            name='test_module',
            module_path=['bzrlib', 'tests', 'test_lazy_import'],
            member=None,
            children={})
    assert module._import_replacer_children == {}
    assert module._member is None
    assert module._module_path == ['bzrlib', 'tests', 'test_lazy_import']
    assert module._name == 'test_module'
    assert module._scope == globals()
    assert module._real_obj is None
    assert module._resolve() is test_module

    # The following is not supported.
    # TODO: Provide a

# Generated at 2022-06-24 02:48:36.502502
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib.tests import TestCase

    class TestCaseWithLazyImport(TestCase):
        """A TestCase that knows how to construct scope_replacers."""

        def _scope_replacer(self, name, msg, extra=None):
            return IllegalUseOfScopeReplacer(name, msg, extra)

    # see tests/test_errors.py for coverage of IllegalUseOfScopeReplacer in
    # general.

    # This function is itself a unit test.
    t = TestCaseWithLazyImport('test_equals')
    exc = t._scope_replacer('name', 'msg', 'extra')
    other = t._scope_replacer('name', 'msg', 'extra')
    self.assertEqual(exc, other)



# Generated at 2022-06-24 02:48:43.360588
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    global foo
    scope = {'foo': 'bar'}
    factory = lambda self, scope, name: 'baz'
    replacer = ScopeReplacer(scope, factory, 'foo')
    if not isinstance(replacer, ScopeReplacer):
        raise AssertionError('%r is not a ScopeReplacer' % (replacer,))
    if scope['foo'] is not replacer:
        raise AssertionError(
            'ScopeReplacer did not place itself in scope[foo]')
    if replacer is foo:
        raise AssertionError('ScopeReplacer set foo')



# Generated at 2022-06-24 02:48:54.148623
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from StringIO import StringIO
    from bzrlib import logger
    mock_logger = logger.Logger(name='bzrlib.lazy_import')
    old_out_f = mock_logger.output_stream
    mock_logger.output_stream = out = StringIO()

# Generated at 2022-06-24 02:49:01.819496
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test that IllegalUseOfScopeReplacer has a working __eq__ method"""
    import sys
    if sys.version_info[:2] < (2, 7):
        raise TestSkipped('Need at least Python 2.7 to test this method')
    from bzrlib.tests import TestCase
    test1 = IllegalUseOfScopeReplacer('foo', 'bah')
    test2 = IllegalUseOfScopeReplacer('foo', 'bah')
    test3 = IllegalUseOfScopeReplacer('foo', 'bah', 'blah')
    test4 = IllegalUseOfScopeReplacer('foo', 'bar')
    test5 = IllegalUseOfScopeReplacer('bar', 'bah')
    # test equality
    TestCase.assertEqual(test1, test2)
    # test inequality

# Generated at 2022-06-24 02:49:13.077003
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    _o = ImportProcessor()
    _o.lazy_import(None, "import foo.bar")
    _o.lazy_import(None, "import foo.bar as baz")
    _o.lazy_import(None, "import foo.bar, baz")
    _o.lazy_import(None, "import foo.bar, (baz, bing)")
    _o.lazy_import(None, "from bar import (foo)")
    _o.lazy_import(None, "from bar import (foo, a, b, c)")
    _o.lazy_import(None, "from bar import (foo,)")
    _o.lazy_import(None, "from bar import foo, a, b, c")

# Generated at 2022-06-24 02:49:24.761830
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase

    class TestObject(object):
        def __init__(self):
            self.foo = 1
            self.bar = 2

        def get_foo(self):
            return self.foo

        def add(self, value):
            return self.foo + value

    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            lazy_obj = ScopeReplacer(scope, lambda self, scope, name:
                TestObject(), 'test_obj')
            # Try setting an attribute directly.
            lazy_obj.foo = 3
            self.assertEqual(3, lazy_obj.foo)
            self.assertEqual(3, lazy_obj.get_foo())

# Generated at 2022-06-24 02:49:36.254202
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Tests _resolver references are set correctly"""
    import_text = """
    import foo, bar.foo
    from baz import foo, bar.foo
    """
    processor = ImportProcessor()
    processor.lazy_import(globals(), import_text)

    assert isinstance(foo, ImportReplacer)
    assert isinstance(bar, ImportReplacer)

    # __import__ is called and we don't have a real object yet.
    assert foo.__class__.__name__ == 'ModuleType'
    assert bar.__class__.__name__ == 'ModuleType'

    # Now actually access the objects
    assert foo is foo
    assert foo.__class__.__name__ == 'ModuleType'

    assert bar.foo is bar.foo

# Generated at 2022-06-24 02:49:47.933025
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # We need to test the decisions that ImportProcessor makes, but
    # we want to test them without actually importing anything.

    # We need to control the scope that is used for the imports,
    # and to not actually import anything
    trace_class = _TraceImportReplacer

    # We assume that the ImportProcessor works as expected,
    # and just verify that the ImportReplacer objects that it generates
    # are suitable for use.

    # Now let's test a few different cases:
    scope = {}
    # 1) Basic import
    text = "import foo"
    import1 = trace_class(scope,
        name="foo", module_path=['foo'], member=None, children={})
    processor = ImportProcessor(lazy_import_class=trace_class)
    processor.lazy_import(scope, text)


# Generated at 2022-06-24 02:49:56.507146
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer constructor.

    These are broken out into separate tests so that we can properly
    test some of the variations.
    """
    # There is no need to test with real scope, as the scope is never
    # read, and ImportReplacer is never called directly.
    scope = {}

    # Simple import
    replacer = ImportReplacer(scope, name='module_name', module_path=['module'],
                              member=None, children={})
    replacer._import(scope, 'module_name')
    assert 'module_name' in scope
    assert scope['module_name'].__name__ == 'module'

    # Import member
    replacer = ImportReplacer(scope, name='member_name', module_path=['module'],
                              member='a_member', children={})
    replacer._

# Generated at 2022-06-24 02:50:01.145426
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the _import_replacer constructor.

    This doesn't test to see if the import can be performed, at this
    point we just are testing that the class can be constructed as
    expected.

    Test cases:
    ===========

    Test that the constructor takes the name and module_path as simple
    strings::

        import foo => name='foo' module_path='foo', member=None, children={}
    """
    scope = {}
    ImportReplacer(scope=scope, name='foo', module_path='foo', member=None,
                   children={})



# Generated at 2022-06-24 02:50:07.206086
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class A(IllegalUseOfScopeReplacer):
        pass
    e1 = A('foo', 'bar')
    e2 = A('foo', 'bar')
    e3 = A('bar', 'x.x')
    assert e1 == e2
    assert e1 != e3



# Generated at 2022-06-24 02:50:14.821778
# Unit test for function lazy_import
def test_lazy_import():
    text = '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    '''
    scope = globals()
    lazy_import(scope, text)
    # We check that one module works, because they should all use the same
    # factory function
    assert scope['foo'] is not object()
    assert scope['foo'] is scope['bar']
    assert scope['bar'] is scope['baz']



# Generated at 2022-06-24 02:50:21.006453
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    def check_import_text(text, expected_imports):
        processor = ImportProcessor(lazy_import_class=FakeImportReplacer)
        processor.lazy_import(scope={}, text=text)
        imports = processor.imports
        # Check that the expected imports are all present
        for name, (module_path, member, children) in expected_imports.iteritems():
            if name not in imports:
                raise AssertionError('%r not in imports' % name)
            info = imports[name]
            if module_path != info[0]:
                raise AssertionError('bad module_path for %r (%r != %r)'
                    % (name, module_path, info[0]))

# Generated at 2022-06-24 02:50:28.564529
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    name = 'foo'
    module_path = ['foo']
    member = None
    children = {}
    old_replacer = ImportReplacer(scope=scope, name=name,
        module_path=module_path, member=member, children=children)
    assert old_replacer._import_replacer_children == children
    assert old_replacer._member == member
    assert old_replacer._module_path == module_path



# Generated at 2022-06-24 02:50:35.767737
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ should put object in scope"""
    scope = {}
    def factory(self, scope, name):
        scope[name] = 'foo'
        return scope[name]
    o = ScopeReplacer(scope, factory, 'factory')
    assert isinstance(o, ScopeReplacer)
    assert scope['factory'] is o
    assert o._resolve() == 'foo'
    assert scope['factory'] == 'foo'
    assert factory('self', scope, 'factory') == 'foo'


# Generated at 2022-06-24 02:50:40.779389
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer

    IllegalUseOfScopeReplacer.__str__ returns a str
    """
    e = IllegalUseOfScopeReplacer("name", "msg")
    assert isinstance(e.__str__(), str)



# Generated at 2022-06-24 02:50:48.347342
# Unit test for function lazy_import
def test_lazy_import():
    """Unit test for lazy_import()"""
    real_import = __import__
    import_calls = []
    def test_import(name, globals={}, locals={}, fromlist=[], level=-1):
        import_calls.append((name, globals, locals, fromlist, level))
        return real_import(name, globals, locals, fromlist, level)
    __builtin__.__import__ = test_import

    class FakeScope(object):
        def __init__(self):
            self.data = {}
        def __getitem__(self, key):
            return self.data[key]
        def __setitem__(self, key, value):
            self.data[key] = value


# Generated at 2022-06-24 02:50:59.552169
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib import tests
    import sys
    def factory(self, scope, name):
        return "resolved object"
    name = 'scope_replacer_test'
    if name in sys.modules:
        del sys.modules[name]
    r = ScopeReplacer(sys.modules, factory, name)
    tests.TestCase.assertIs(r, sys.modules['scope_replacer_test'])
    obj = sys.modules['scope_replacer_test']
    tests.TestCase.assertEqual('resolved object', obj)
    tests.TestCase.assertIs(obj, sys.modules['scope_replacer_test'])
    # Testing assignment to the module is not currently possible
    # as it is not possible to create a module without executing

# Generated at 2022-06-24 02:51:09.820416
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import lazy_import
    bzrlib.lazy_import._lazy_module_class = ScopeReplacer

    #import StringIO
    #save_stdout = sys.stdout
    #try:
    #    out = StringIO.StringIO()
    #    sys.stdout = out
    #    bzrlib.lazy_import.lazy_import(globals(), '''
    #    from bzrlib import (
    #        errors,
    #        osutils,
    #        branch,
    #        )
    #    import bzrlib.branch
    #

# Generated at 2022-06-24 02:51:22.585779
# Unit test for function lazy_import
def test_lazy_import():
    globs = {}
    lazy_import(globs, '''
    from bzrlib import foo, bar
    import bzrlib
    ''')

    # Now we should be able to get to items in 'foo' and 'bar', but not
    # to 'bzrlib' directly
    def get_to_foo():
        return globs['foo'].Baz

    def get_to_bar():
        return globs['bar'].Foo

    def get_to_bzrlib():
        return globs['bzrlib'].LockDir

    errors.optimizer.stop_tracking_allocations()

# Generated at 2022-06-24 02:51:29.478639
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    msg = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    fmt = msg._get_format_string()
    if fmt is None:
        # we will get None if the locale does not exist - this
        # isn't an error per se.
        return
    # we will get _fmt as ascii but _get_format_string will return
    # utf8 as per the docs above
    assert isinstance(fmt, str)
    assert u'bar' in msg
    assert 'baz' in msg
    # we have no way to know the actual encoding, but we can
    # test that it is valid utf8
    msg.encode('utf8')
    # and that we get a unicode back
    u = unicode(msg)
    assert isinstance(u, unicode)
    #

# Generated at 2022-06-24 02:51:35.559078
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor for the ImportReplacer class."""
    import bzrlib.tests as tests
    scope = {}
    name = 'foo'
    module_path = ['foo', 'bar']
    member = 'baz'
    children = {'thing':(['foo', 'bar'], 'thing', {})}
    replacer = ImportReplacer(scope, name, module_path, member, children)
    replacer._resolve()
    tests.TestSkipped("Needs to be checked")



# Generated at 2022-06-24 02:51:45.645050
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.errors
    def _factory(self, scope, name):
        return bzrlib.errors
    import __builtin__
    sr = ScopeReplacer(__builtin__.__dict__, _factory, 'bzrlib')
    try:
        __builtin__.bzrlib
    except AttributeError:
        pass
    else:
        raise AssertionError
    try:
        sr
    except AttributeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-24 02:51:56.703018
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # __getattribute__(self: bzrlib.lazy_import.ScopeReplacer, attr: str) -> object
    # Calls self._resolve and returns the result of the getattr for attr
    #
    # Test for the following conditions :
    #
    # 1. This method returns the result of the getattr for attr
    # 2. This method raises TypeError if self._resolve returns None

    def scope_replacer_of_attr(attr):
        test_obj = ScopeReplacer(None, None, None)
        test_obj.getattribute = lambda: None
        return getattr(test_obj, attr)

    # 1. This method returns the result of the getattr for attr
    assert scope_replacer_of_attr('getattribute') is None

    # 2. This method raises TypeError if self

# Generated at 2022-06-24 02:52:06.401280
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Construction of an ImportReplacer should work as specified above."""
    global_dict = {}
    class DummyReplacer(ImportReplacer):
        """This is needed because the instrumented ImportReplacer
        doesn't exist at the time of these tests.
        """
        def _import(self, scope, name):
            return scope[name]

    # import foo
    DummyReplacer(global_dict, 'foo', ['foo'])
    assert global_dict['foo']._import_replacer_children == {}
    assert global_dict['foo']._member == None
    assert global_dict['foo']._module_path == ['foo']

    # import foo.bar
    global_dict = {}

# Generated at 2022-06-24 02:52:07.754278
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    doctest.testmod(verbose=False)



# Generated at 2022-06-24 02:52:12.315920
# Unit test for function disallow_proxying
def test_disallow_proxying():
    scope = {}
    lazy_import(scope, """
        import bzrlib.mymodule
        """)
    disallow_proxying()
    try:
        scope['bzrlib'].mymodule
    except IllegalUseOfScopeReplacer:
        return
    else:
        raise AssertionError("bzrlib.mymodule should not be proxyable now")



# Generated at 2022-06-24 02:52:14.561889
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    obj = IllegalUseOfScopeReplacer('Foo', 'msg')
    s = obj.__str__()
    assert isinstance(s, str)



# Generated at 2022-06-24 02:52:23.258121
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import(globals(), text) works."""
    import_text = '''
    import os
    import os.path
    '''
    g = globals()
    initial_dict = g.copy()
    lazy_import(g, import_text)
    for key in initial_dict.keys():
        del g[key]

# test_lazy_import


# This syntax is only supported in python 2.4 or above
if hasattr(__builtins__, '__import__'):
    __builtins__.__import__ = lambda p, g, l, x=None, y=None: real_import(
        p, g, l, x, y)
else:
    __builtins__['__import__'] = lambda p, g, l, x=None, y=None: real

# Generated at 2022-06-24 02:52:29.627621
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('e1', 'message', 'extra')
    e2 = IllegalUseOfScopeReplacer('e1', 'message', 'extra')
    assert e == e2
    # equality is based on __dict__, not _fmt
    e3 = IllegalUseOfScopeReplacer('e1', 'message', 'extra')
    e3._fmt = "different"
    assert e == e3
    # equality is based on __dict__, not _preformatted_string
    e4 = IllegalUseOfScopeReplacer('e1', 'message', 'extra')
    e4._preformatted_string = "different"
    assert e == e4



# Generated at 2022-06-24 02:52:36.766583
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def dummy_factory(self, scope, name):
        return lambda: 42
    scope = {}
    lazy_obj = ScopeReplacer(scope, dummy_factory, 'foo')
    obj = scope['foo']
    try:
        # Check that the ScopeReplacer exposes a method __call__
        # which returns the expected value.
        assert obj() == 42
    finally:
        pass
    return



# Generated at 2022-06-24 02:52:43.971605
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Unit test for method lazy_import of class ImportProcessor"""
    # First create a temporary global scope
    class global_scope(object):
        __slots__ = []
        import os
        import sys

    class Foo(ImportReplacer):
        __slots__ = ['foo']
        def __init__(self, scope, name, module_path, member=None, children={}):
            ImportReplacer.__init__(self, scope=scope, name=name,
                                    module_path=module_path, member=member,
                                    children=children)
            self.foo = 'blah'

    class Bar(ImportReplacer):
        __slots__ = ['bar']

# Generated at 2022-06-24 02:52:50.222178
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import os
    import sys
    import tempfile
    tempdir = tempfile.gettempdir()
    the_module_filename = os.path.join(tempdir, 'the_module.py')
    f = open(the_module_filename, 'w')

# Generated at 2022-06-24 02:52:59.586168
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class FakeModule(object):
        def some_function(self):
            return 'here'
    name = 'fake_module'
    scope = {}
    def factory(self, scope, name):
        return FakeModule()
    def function_caller(obj):
        return obj.some_function()
    test_obj = ScopeReplacer(scope, factory, name)
    result = function_caller(test_obj)
    expected = 'here'
    TestCase.assertEqual(result, expected)

    # if the module has already been loaded, we should still get the result
    result = function_caller(test_obj)
    TestCase.assertEqual(result, expected)

    # If we call it a second time, the proxy should be gone and the
    # object should

# Generated at 2022-06-24 02:53:11.593067
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys, os
    scope = sys.modules[__name__].__dict__

    # This should not trigger any import errors
    ImportProcessor().lazy_import(scope, """
            import bzrlib.errors
            import bzrlib.trace, bzrlib.commands
            from bzrlib.tests import TestCase
            import bzrlib.tests.test_http_response as test_http_response
            from bzrlib.tests.per_errors import TestCaseWithConnectionHooked
    """)
    from bzrlib.tests.per_errors import TestCaseWithConnectionHooked
    from bzrlib.tests import TestCase
    from bzrlib.commands import Command, display_command, get_cmd_object
    from bzrlib.trace import mutter, is_quiet
   