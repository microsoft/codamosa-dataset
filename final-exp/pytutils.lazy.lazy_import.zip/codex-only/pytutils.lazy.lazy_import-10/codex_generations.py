

# Generated at 2022-06-24 02:43:12.087006
# Unit test for function lazy_import
def test_lazy_import():
    def _check_lazy(self, modname, member):
        """Check that 'modname' is lazily loaded and has a member 'member'"""
        self.assertTrue(modname in self.globals)
        self.assertTrue(isinstance(self.globals[modname], 
                                   ScopeReplacer))
        self.assertTrue(hasattr(self.globals[modname], member))

    def setUp(self):
        self.globals = {}  # A dict to act as a scope

    def test_lazy_import(self):
        text = '''
            from bzrlib.tests import TestCase
            import bzrlib.tests
            import bzrlib.commands as cmds
            '''
        lazy_import(self.globals, text)

        _

# Generated at 2022-06-24 02:43:20.297093
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""

    # Test that we can't import something that already exists
    globals()['foo'] = 'abc'

# Generated at 2022-06-24 02:43:26.619739
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import(scope, text) method"""
    import bzrlib.test_lazy_import_module

    # Test simple module import
    lazy_import(globals(), 'import bzrlib.test_lazy_import_module')
    # Now the object should exist
    test_lazy_import_module.func()

    # Test module import with specific name
    lazy_import(globals(), 'import bzrlib.test_lazy_import_module as tlim')
    tlim.func()

    # Test two module imports with different names
    lazy_import(globals(), 'import bzrlib.test_lazy_import_module as one, '
                           'bzrlib.test_lazy_import_module as two')
    one.func()
    two.func

# Generated at 2022-06-24 02:43:29.756416
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    err = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert err.name == 'name'
    assert err.msg == 'msg'
    assert err.extra == ': extra'
    str(err)
    repr(err)



# Generated at 2022-06-24 02:43:38.063040
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import (
        lazy_import,
        ScopeReplacer,
        )

    # Check that it works correctly in a single threaded environment
    d = {}
    lazy_import(d, 'from bzrlib.lazy_import import disallow_proxying')
    disallow_proxying()
    # Check that the module can not be used as a proxy anymore
    obj = d['disallow_proxying']()
    try:
        obj()
    except IllegalUseOfScopeReplacer as e:
        assert e.msg == "Object already replaced, did you assign it" \
                        " to another variable?"
        assert e.name == 'disallow_proxying'
    else:
        assert False, "Disallow_proxying failed to detect proxy usage"

    # Let's check

# Generated at 2022-06-24 02:43:39.318306
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    raise tests.InTestProcess('__str__ needs to be tested')

# Generated at 2022-06-24 02:43:49.311781
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ must be reentrant

    Check that checking equality of an exception doesn't trigger
    __getattr__ and thus lead to infinite recursion.
    """
    eq = IllegalUseOfScopeReplacer.__eq__
    # We don't need to test __ne__, so let's make it a noop
    IllegalUseOfScopeReplacer.__ne__ = lambda *args: NotImplemented
    try:
        eq(IllegalUseOfScopeReplacer(1,2), IllegalUseOfScopeReplacer(1,2))
    finally:
        del IllegalUseOfScopeReplacer.__ne__



# Generated at 2022-06-24 02:44:00.821516
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() returns a valid python expression
    evaluating to an equal value of the original.

    The function is used mainly for debuging and must
    be equivalent to the original value.
    """
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class Test(TestCase):
        def setUp(self):
            self.exception = IllegalUseOfScopeReplacer('my_name',
                                                       'my_message',
                                                       'my_extra')

        def test_repr(self):
            # eval(repr(e)) == e
            e2 = eval(repr(self.exception))
            self.assertIsInstance(e2, IllegalUseOfScopeReplacer)
            self.assertE

# Generated at 2022-06-24 02:44:10.072644
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib.tests, bzrlib.tests.lazy_import
    def _prepare():
        bzrlib.tests.lazy_import.ScopeReplacer._should_proxy = True

# Generated at 2022-06-24 02:44:12.645873
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import bzrlib.tests.per_importreplacer # Circular import
    bzrlib.tests.per_importreplacer  # pyflakes



# Generated at 2022-06-24 02:44:21.324301
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Construct a series of ImportReplacer objects, make sure they have the
    same contents as a dictionary.

    Then, ensure that 'bzrlib.foo.bar' can be resolved from the top member.
    """
    from bzrlib.tests import TestCase
    import sys
    test = TestCase()
    # Use a string here - we want to test _should_proxy, which prevents
    # the __class__ member being accessed.
    test.overrideAttr(ScopeReplacer, '_should_proxy', True)

    def _check_dicts_equal(dict1, dict2):
        test.assertEqual(sorted(dict1.keys()), sorted(dict2.keys()))
        for key in dict1.keys():
            test.assertEqual(dict1[key], dict2[key])

    # Now

# Generated at 2022-06-24 02:44:30.728601
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    my_globals = {}
    ImportReplacer(scope=my_globals,
                   name='foo',
                   module_path=['foo'],
                   member=None,
                   children={})
    try:
        ImportReplacer(scope=my_globals,
                       name='foo',
                       module_path=['foo'],
                       member=None,
                       children={'bar':(['foo', 'bar'], None, {})})
    except ValueError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-24 02:44:38.400183
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class LocalScope(object):
        x = ScopeReplacer(scope, lambda self, scope, name: scope[name], 'x')
        def __setattr__(self, attr, value):
            object.__setattr__(self, attr, value)
    scope = LocalScope()
    scope.x = 5
    assert scope.x == 5
    scope.y = 7
    assert scope.y == 7
    assert scope.__getattribute__('x') == 5
    assert scope.__getattribute__('y') == 7
    scope.x = 'abc'
    scope.y = 'def'
    assert scope.__getattribute__('x') == 'abc'
    assert scope.__getattribute__('y') == 'def'
    scope.x = 4
    scope.y = 6
    assert scope.__getattribute

# Generated at 2022-06-24 02:44:41.656996
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import doctest, sys
    # This failed with version 0.15.0
    doctest.run_docstring_examples(ScopeReplacer.__setattr__, globals(),
                                   verbose=True,
                                   name='ScopeReplacer.__setattr__')

# Generated at 2022-06-24 02:44:47.299942
# Unit test for function lazy_import
def test_lazy_import():

    scope = {}
    lazy_import(scope, '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    ''')

    foo = scope['foo']
    bar = scope['bar']
    baz = scope['baz']
    assert isinstance(foo, ScopeReplacer)
    assert isinstance(bar, ScopeReplacer)
    assert isinstance(baz, ScopeReplacer)
    bzrlib = scope['bzrlib']
    assert isinstance(bzrlib, ScopeReplacer)
    transport = scope['bzrlib.transport']
    assert isinstance(transport, ScopeReplacer)
    branch = scope['bzrlib.branch']
   

# Generated at 2022-06-24 02:44:51.507842
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test constructor of ImportProcessor"""
    import_processor = ImportProcessor()
    assert isinstance(import_processor, ImportProcessor), "Should be an ImportProcessor"
    assert import_processor._lazy_import_class == ImportReplacer, "Should have ImportReplacer as lazy_import_class"
    import_processor = ImportProcessor(ImportReplacer)
    assert isinstance(import_processor, ImportProcessor), "Should be an ImportProcessor"
    assert import_processor._lazy_import_class == ImportReplacer, "Should have ImportReplacer as lazy_import_class"


# Generated at 2022-06-24 02:44:57.351610
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)
    # Check that 'foo' and 'bar' are in the string
    assert 'foo' in u
    assert 'bar' in u



# Generated at 2022-06-24 02:45:04.718557
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__(self, *args, **kwargs) -> unknown
    raise NotImplementedError()

    # If a class is passed in for real_obj we will try to create an instance.
    # But we don't want to accidentally try to pass self in to that
    # constructor.
    def _no_call(self, scope, name):
        raise AssertionError("Should not have instantiated class.")
    _no_call.__name__ = '_no_call'
    scope = {}
    scope['_no_call'] = ScopeReplacer(scope, _no_call, '_no_call')

    class NotActuallyInstantiated(object):
        def __init__(self, *args, **kwargs):
            raise AssertionError("Should not have instantiated class.")
    scope['NotActuallyInstantiated'] = Scope

# Generated at 2022-06-24 02:45:07.302600
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__(other: IllegalUseOfScopeReplacer) -> bool

    Return whether this instance is equal to other.
    """



# Generated at 2022-06-24 02:45:14.623832
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib.lazy_import
    module_dict = bzrlib.lazy_import.__dict__.copy()
    lazy_import(module_dict, """
    from bzrlib import (
        foo,
        bar,
        baz,
    )
    import bzrlib.branch
    import bzrlib.transport
    """)
    # The real objects don't exist yet, so the value should match
    assert module_dict['foo'] is module_dict['bar']
    assert module_dict['bzrlib'].branch is module_dict['baz']
    assert module_dict['bzrlib'] is module_dict['bzrlib'].transport



# Generated at 2022-06-24 02:45:25.378209
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    ''')
    # note: errors is not a lazy_import (unfortunately)
    obj = Branch()
    obj.foo = 'bar'
    def factory(self, scope, name):
        return obj
    sr = ScopeReplacer(locals(), factory, 'branch')
    eq('bar', branch.foo)
    eq('bar', locals()['branch'].foo)
    # Setting an attribute should propagate to the real obj
    branch.foo = 'baz'
    eq('baz', obj.foo)



# Generated at 2022-06-24 02:45:31.352723
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Testing the construction of instances of class ImportProcessor"""
    test_text1 = """
    import foo

    from foo import bar, baz

    from foo.bar import bing

    import foo.bar.mumble as mumble, bar.baz as baz

    from foo.bar.baz import memery all
    (
    )
    """

    expected_data = {'foo': ([u'foo'], None, {'bar': ([u'foo', u'bar'], None,
                      {'mumble': ([u'foo', u'bar', u'mumble'], u'mumble', {})})}), 'bar': ([u'bar'], None,
                      {'baz': ([u'bar', u'baz'], u'baz', {})})}
    processor = ImportProcessor()
    processor._

# Generated at 2022-06-24 02:45:40.861631
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class TestScopeReplacer___setattr__(object):
        def __init__(self, test_obj):
            self.test_obj = test_obj
        def __getattribute__(self, attr):
            if attr == 'test':
                return 'test'
            test_obj = object.__getattribute__(self, 'test_obj')
            return getattr(test_obj, attr)
    class TestScopeReplacer___setattr___subclass(
        TestScopeReplacer___setattr__):
        pass
    class TestScopeReplacer___setattr___subclass_subclass(
        TestScopeReplacer___setattr___subclass):
        pass
    test_obj = TestScopeReplacer___setattr___subclass_subclass(None)

# Generated at 2022-06-24 02:45:49.540163
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ for IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly:' \
               u' msg: extra'
    # We do not test str(e) because it depends on the current encoding.
    # Unit test for method __str__ of class IllegalUseOfScopeReplacer
    def test_IllegalUseOfScopeReplacer___str__():
        """__str__ for IllegalUseOfScopeReplacer"""
        e = IllegalUseOfScopeReplacer(
            'name', 'msg', 'extra')
        s = e.__str__()
        assert isinstance(s, str)

# Generated at 2022-06-24 02:45:55.594219
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    try:
        bad = ImportReplacer({}, 'foo', 'foo', member='bar', children={})
        raise AssertionError('ImportReplacer allowed both a member and children')
    except ValueError:
        pass
    ImportReplacer({}, 'foo', 'foo', member='bar', children=None)


# Unit tests for ImportReplacer - note that much of the logic is
# implicitly tested by existing tests that use this class.
import tests.blackbox

# Generated at 2022-06-24 02:46:07.008076
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Unit test for method lazy_import of class ImportProcessor"""

    # Create a trivial stub class that can be used as a mock ImportReplacer
    class Stub_ImportReplacer(ImportReplacer):

        def __init__(self, scope, name, module_path, member=None, children={}):
            import_replacer_children = '_import_replacer_children'
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children
            self.parent = None
            setattr(self, '_import_replacer_children', children)


# Generated at 2022-06-24 02:46:10.735111
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """This tests the constructor for ImportProcessor.

    This test is fairly trivial, but is good for detecting API breakages
    """
    imp_proc = ImportProcessor()
    # The only thing we really care about here is that it constructed


# Generated at 2022-06-24 02:46:19.573184
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # Unit test for method lazy_import of class ImportProcessor

    global lazy_import_class
    lazy_import_class = None
    # The first thing is to restore the canonical import method to a
    # pristine state
    ImportProcessor._convert_imports = ImportProcessor._convert_imports.im_func
    ImportProcessor._build_map = ImportProcessor._build_map.im_func
    # Now we get to create some mocks
    replacer = object()
    replacer._import_replacer_children = 'dummy-children'
    replacer._member = 'dummy-member'
    replacer._module_path = 'dummy-module-path'
    replacer._factory = lambda a, b, c: replacer

    # Now we get to create some mock modules
    modules = []
    module

# Generated at 2022-06-24 02:46:29.582508
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    msg = 'foo'
    extra = 'bar'
    e = IllegalUseOfScopeReplacer('name', msg, extra)
    assert e.msg == 'foo'
    assert e.extra == ': bar'
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly: foo: bar"
    e = IllegalUseOfScopeReplacer('name', msg)
    assert e.msg == 'foo'
    assert e.extra == ''
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly: foo"
test_IllegalUseOfScopeReplacer()



# Generated at 2022-06-24 02:46:34.891762
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # no '__init__' method in Exception, so cannot create a new-style class
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    assert_equal("ScopeReplacer object 'name' was used incorrectly: message: "
                 "extra", str(e))
    assert_equal("ScopeReplacer object 'name' was used incorrectly: message: "
                 "extra", unicode(e))


# Generated at 2022-06-24 02:46:45.343108
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib
    from bzrlib import ui
    from bzrlib.ui import ui_factory
    from bzrlib.ui import text
    from bzrlib.ui.text import TextUIFactory
    from bzrlib import commands
    import bzrlib.commands
    from bzrlib.commands import *
    from bzrlib.commands import Command
    from bzrlib.commands import cmd_add, cmd_annotate
    from bzrlib import osutils
    from bzrlib import osutils as osutils2
    from osutils import pathjoin
    from osutils import pathjoin as pathjoin2
    import osutils
    import osutils as osutils3
    from osutils import pathjoin as pathjoin3


# Generated at 2022-06-24 02:46:56.809434
# Unit test for function lazy_import
def test_lazy_import():
    def _test_lazy_import(scope, text):
        """Test that the given text can be lazily imported"""
        if not ScopeReplacer._should_proxy:
            pass
        lazy_import(scope, text)
        for line in text.splitlines():
            if line.startswith('from ') and ' import ' in line:
                from_mod = line.split(None, 1)[1]
                from_mod = from_mod.split(' import ')[0]
                from_mod = from_mod.strip()
            elif line.startswith('from '):
                from_mod = line.split(None, 1)[1]
            elif line.startswith('import '):
                from_mod = line.split(None, 1)[1]
                from_mod = from_mod.split(',')

# Generated at 2022-06-24 02:47:04.333771
# Unit test for function disallow_proxying
def test_disallow_proxying():
    class Foo(object):
        pass
    def make_real_obj():
        return Foo()

    # Create a ScopeReplacer
    globals()['foo'] = ScopeReplacer(globals(), make_real_obj, 'foo')
    foo
    assert foo == Foo()

    # Now that proxying is disabled, the following operation must fail
    disallow_proxying()
    try:
        foo
    except IllegalUseOfScopeReplacer as e:
        # the exception was expected
        assert e.msg == "Object already replaced, did you assign it" \
                " to another variable?"
        assert e.extra == ': None'
    else:
        assert False, "Exception expected"



# Generated at 2022-06-24 02:47:08.067763
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    replacer = ImportReplacer(sys.modules, name='foo', module_path='foo',
        member=None, children={})


# Generated at 2022-06-24 02:47:17.494075
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test that __eq__ works"""
    e1 = IllegalUseOfScopeReplacer('alpha', 'beta', 'gamma')
    e2 = IllegalUseOfScopeReplacer('alpha', 'beta', 'gamma')
    e3 = IllegalUseOfScopeReplacer('delta', 'beta', 'gamma')
    e4 = IllegalUseOfScopeReplacer('alpha', 'epsilon', 'gamma')
    e5 = IllegalUseOfScopeReplacer('alpha', 'beta', 'phi')
    e6 = IllegalUseOfScopeReplacer('delta', 'epsilon', 'phi')
    e7 = IllegalUseOfScopeReplacer('delta', 'beta', 'phi')
    e8 = IllegalUseOfScopeReplacer('alpha', 'epsilon', 'phi')
    assert e1 == e2
    assert e2 == e1


# Generated at 2022-06-24 02:47:23.684935
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    scope = {}
    ip = ImportProcessor()
    ip.lazy_import(scope, """
    import sys, os, warnings
    import bzrlib.version, bzrlib.osutils
    import bzrlib.errors as errors
    from bzrlib import (lockdir, trace, config,
                        transport, ui,
                        repository, revision,
                        )
    from bzrlib.tests import (TestCase, TestCaseWithTransport,
                              TestSkipped)
    """)
    # TODO: jam 20060912 Make this assertion better
    # We should be checking for the actual expected import map.
    assert len(ip.imports) == 19, 'There should be 19 expected imports'



# Generated at 2022-06-24 02:47:27.486604
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:47:34.491280
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import re
    lazy = lazy_import
    global_dict = {}
    _ = lazy(global_dict, "import re")
    assert _ is re
    ScopeReplacer._should_proxy = True
    _ = lazy(global_dict, "import re")
    assert _ is re
    disallow_proxying()
    _ = lazy(global_dict, "import re")
    assert _ is re
    _.match
    assert _ is re
    assert global_dict == {'re': re}
    e = None

# Generated at 2022-06-24 02:47:42.924525
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test functionality of disallow_proxying()."""
    import bzrlib.lazy_import

# Generated at 2022-06-24 02:47:45.149504
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert exc.name == 'name'
    assert exc.msg == 'msg'
    assert exc.extra == ': extra'
    assert str(exc) == ("ScopeReplacer object 'name' was used incorrectly:"
                        " msg: extra")



# Generated at 2022-06-24 02:47:51.716822
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for __eq__ method of IllegalUseOfScopeReplacer."""
    from bzrlib.tests import TestCaseWithTransport

    class Foo(TestCaseWithTransport):
        # TODO: remove this class
        def __init__(self, *args, **kwargs):
            super(Foo, self).__init__(*args, **kwargs)

    def check(x, y, want, want_msg):
        """Check that __eq__(x,y) is want, and __eq__(y,x) is want_msg."""
        # check x == y
        got = x == y
        if got is NotImplemented:
            got = False

# Generated at 2022-06-24 02:48:02.797434
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function itself.

    This includes the ImportProcessor class, which is only indirectly
    tested through the ImportReplacer class.
    """
    import sys
# TODO: jam 20060912 These are not safe to do in a multi-threaded environment
#       since multiple threads could be performing imports, and we don't
#       want them to interfere.
#    real_import = builtins.__import__
#    def fail_import(name, scope, scope, scope, scope):
#        raise ImportError('unit test')
#    builtins.__import__ = fail_import


# Generated at 2022-06-24 02:48:14.429814
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib._lazy_import_test_class
    mod = bzrlib._lazy_import_test_class

    # Replace an object with a scope replacer
    scope = {}
    replacer = ScopeReplacer(scope, mod.simple_factory, 'simple')
    # Attempt to use it, which should resolve the object and
    # return the correct result
    result = replacer.sample(1, a=2)
    assert result == 3
    # Attempting to use it again should proxy to the resolved object
    result = replacer.sample(1, a=2)
    assert result == 3

    # Replace an object with a scope replacer and add it to the builtins
    scope = {}
    replacer = ScopeReplacer(scope, mod.simple_factory, 'simple')
    import __builtin__


# Generated at 2022-06-24 02:48:26.022695
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib import (
        tests,
        transport,
        )
    from bzrlib.tests import (
        test_server,
        )

    def foo():
        """This is a function to get accessed from a lazy import"""

    mock = {}
    lazy_import(mock, '''
    from bzrlib import (foo, bzrlib,
                        tests,
                        transport,
                        tests as bzrlib_tests)
    from bzrlib.tests import (
                          test_server,
                          test_server as tests_test_server)
    ''')
    lazy_import(mock, '''
    import bzrlib.tests.test_server
    ''')
    # Note: there are some dependencies on test_server that we don't import
    #      explicitly.

# Generated at 2022-06-24 02:48:33.612006
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying."""
    import sys

    # In practice, 'six' is imported in the bzrlib.tests module, which is
    # imported very early by bzrlib/__init__.py, so it makes more sense to test
    # another module.
    lazy_import(sys.modules[__name__], """
    from bzrlib import (
        lazy_import,
        osutils,
        tests,
        )
    """)

    # Verify that we can use osutils.
    osutils.abspath('.')

    # Check that we can assign modules to variables.
    x = osutils

    # Verify that we can still use x.
    x.abspath('.')

    # Verify that assigning a module to a variable makes it possible to use
    # the

# Generated at 2022-06-24 02:48:43.931364
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer("name", "msg")
    assert e.name == "name"
    assert e.msg == "msg"
    assert e.extra == ''
    e = IllegalUseOfScopeReplacer("name", "msg", "extra")
    assert e.name == "name"
    assert e.msg == "msg"
    assert e.extra == ': extra'

# Generated at 2022-06-24 02:48:54.372687
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import os

    os.environ['BZR_FULL_LOOKUP'] = '1'

    def test_func(scope, name):
        return sys

    before_replacer = sys
    replacer = bzrlib.lazy_import.ScopeReplacer(locals(), test_func, 'sys')
    sys is replacer  # should be true
    replacer.path  # should be a property
    # we are now past the point of no return
    replacer.path  # should be a property, even though we replaced sys

    # we should not be set to ourselves in the calling scope.
    locals()['sys'] is replacer # should be true
    sys is before_replacer # should be true


# Generated at 2022-06-24 02:48:55.988726
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from doctest import DocTestSuite
    return DocTestSuite('bzrlib.lazy_import')


# Generated at 2022-06-24 02:49:02.941827
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class C(IllegalUseOfScopeReplacer):
        def __eq__(self, other):
            if self.__class__ is not other.__class__:
                return NotImplemented
            return self.__dict__ == other.__dict__

    # test class
    s = C('a', 'b', 'c')
    s2 = C('a', 'b', 'c')
    assert s == s2
    s2 = C('a', 'b', 'd')
    assert not (s == s2)
    s2 = C('a', 'c', 'c')
    assert not (s == s2)
    s2 = C('b', 'b', 'c')
    assert not (s == s2)
    s2 = C('a', 'b')
    assert not (s == s2)


# Generated at 2022-06-24 02:49:13.375523
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should work with all legal values of parameters."""
    lu = IllegalUseOfScopeReplacer('foo', 'message')
    assert isinstance(lu, Exception)
    assert isinstance(lu, IllegalUseOfScopeReplacer)
    assert isinstance(lu.name, str)
    assert isinstance(lu.msg, str)
    assert isinstance(lu.extra, str)
    assert isinstance(lu.args, tuple)
    assert 1 == len(lu.args)
    assert 1 == len(lu)
    assert 'foo' == lu.name
    assert 'message' == lu.msg
    assert '' == lu.extra
    assert 'IllegalUseOfScopeReplacer(foo,message)' == repr(lu)
    assert 'foo' == lu.args[0] # name

# Generated at 2022-06-24 02:49:19.298217
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def check(self, obj, r):
            self.assertEquals(repr(obj), r)
    Test().check(IllegalUseOfScopeReplacer('foo', 'msg'),
                 "IllegalUseOfScopeReplacer('foo', 'msg')")



# Generated at 2022-06-24 02:49:26.767828
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    tests = [
        (dict(a=None), TypeError, None),
        (dict(a=1), TypeError, None),
        (dict(a=1.0), TypeError, None),
        (dict(a=''), TypeError, None),
        (dict(a=u''), TypeError, None),
        (dict(a=[]), TypeError, None),
        (dict(a=()), TypeError, None),
        (dict(a={}), TypeError, None),
        ]


# Generated at 2022-06-24 02:49:38.170214
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    from bzrlib.tests.blackbox.test_selftest import TestCaseWithMemoryTransport
    class TestCase(TestCaseWithMemoryTransport):
        def test_resolve_should_replace_self(self):
            # before resolving, self is stored in the scope
            scope = {}
            def factory(replacer, scope, name):
                self.assertIs(scope, scope)
                self.assertEqual(name, 'foo')
                self.assertIs(replacer, scope['foo'])
                return replacer
            ScopeReplacer(scope, factory, 'foo')
            self.assertIs(scope['foo'], scope['foo']._resolve())

        def test_resolve_should_return_real_object(self):
            real_obj = object()
            scope = {}

# Generated at 2022-06-24 02:49:47.293353
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    x = IllegalUseOfScopeReplacer(u'foo', u'bar', u"extra text")
    y = IllegalUseOfScopeReplacer(u'foo', u'bar', u"extra text")
    z = IllegalUseOfScopeReplacer(u'foo', u'bar')
    w = IllegalUseOfScopeReplacer(u'foo', u'wrong')
    assert x == y
    assert x != z
    assert x != w
    assert x == IllegalUseOfScopeReplacer.__new__(IllegalUseOfScopeReplacer, u'foo', u'bar', u"extra text")



# Generated at 2022-06-24 02:49:56.073246
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    cls = ImportReplacer(scope, name='foo', module_path=['foo'])
    cls(scope, name='foo.bar', module_path=['foo', 'bar'], member='baz')
    cls(scope, name='foo.bar.baz', module_path=['foo', 'bar', 'baz'])
    import foo.bar
    cls(scope, name='foo.bar', module_path=['foo', 'bar'], member='baz',
        children={'baz':(['foo', 'bar', 'baz'], None, {})})
    import foo.bar.baz

# Generated at 2022-06-24 02:50:08.637285
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Counter(object):
        count = 0
        def __call__(this):
            this.count += 1
    counter = Counter()
    def create_counter():
        return counter
    sr = ScopeReplacer({}, create_counter, 'test')
    test = sr
    self.assertEqual(0, counter.count)
    test()
    self.assertEqual(1, counter.count)
    test()
    self.assertEqual(2, counter.count)
    sr2 = ScopeReplacer({}, create_counter, 'test2')
    test2 = sr2
    self.assertEqual(0, counter.count)
    test2()

# Generated at 2022-06-24 02:50:12.235144
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    import doctest
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    doctest.testmod(IllegalUseOfScopeReplacer)

# Generated at 2022-06-24 02:50:19.201173
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__ of class ScopeReplacer.
    import testtools
    try:
        testtools.run_unittest_no_warnings(TestScopeReplacer___call__)
    except ImportError:
        import unittest
        unittest.main('test_ScopeReplacer___call__',
                      defaultTest='TestScopeReplacer___call__')
# Class to hold the unit tests.

# Generated at 2022-06-24 02:50:24.675021
# Unit test for function lazy_import
def test_lazy_import():
    glob = {}

# Generated at 2022-06-24 02:50:27.910436
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ should return a string value"""
    e = IllegalUseOfScopeReplacer(
        name='foo',
        msg='bar')
    r = repr(e)



# Generated at 2022-06-24 02:50:33.190032
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    factory = lambda a, b, c: 1
    name = 'name'
    r = ScopeReplacer(scope, factory, name)
    assert scope['name'] is r
    assert r._scope is scope
    assert r._factory is factory
    assert r._name == name
    assert r._real_obj is None


# Generated at 2022-06-24 02:50:40.309748
# Unit test for function lazy_import
def test_lazy_import():
    scope = {}
    lazy_import(scope, """
        from bzrlib import (
            foo,
            bar,
            baz,
            )
        import bzrlib.branch
        import bzrlib.transport
        """)
    obj = scope['bzrlib']



# Generated at 2022-06-24 02:50:46.560798
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class SubClass(IllegalUseOfScopeReplacer):
        pass
    a1 = IllegalUseOfScopeReplacer('name', 'msg')
    a2 = IllegalUseOfScopeReplacer('name', 'msg')
    b1 = SubClass('name', 'msg')
    b2 = SubClass('name', 'msg')
    assert a1 == a2 and b1 == b2
    a2 = IllegalUseOfScopeReplacer('name', 'MSG')
    b2 = SubClass('name', 'MSG')
    assert a1 != a2 and b1 != b2



# Generated at 2022-06-24 02:50:58.108708
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test for ImportProcessor"""
    # Test empty string
    processor = ImportProcessor()
    processor.lazy_import({}, '')
    # Test single line import with no members
    processor = ImportProcessor()
    processor.lazy_import({}, 'import foo')
    # Test single line import with member
    processor = ImportProcessor()
    processor.lazy_import({}, 'import foo.bar')
    # Test single 'as' style import with no members
    processor = ImportProcessor()
    processor.lazy_import({}, 'import foo as bar')
    # Test single 'as' style import with member
    processor = ImportProcessor()
    processor.lazy_import({}, 'import foo.bar as baz')
    # Test a simple 'from' style import
    processor = ImportProcessor()
    processor.l

# Generated at 2022-06-24 02:51:06.731889
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Just test the basic execution of ImportProcessor.lazy_import"""
    # Don't actually import anything
    lazy_import_class = object

    scope = {}
    text = """\
from foo import bar, baz
from foo import bee
import foo, bar
import bar.baz
import bar.baz.bing"""
    processor = ImportProcessor(lazy_import_class=lazy_import_class)
    processor.lazy_import(scope, text)

    # Just check that we got the right member names
    expected_names = ['bar', 'baz', 'bee', 'foo', 'bar', 'baz', 'bing']
    names = scope.keys()
    names.sort()

# Generated at 2022-06-24 02:51:12.489313
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str"""
    msg = "Can't delete a ScopeReplacer object"
    exc = IllegalUseOfScopeReplacer('foo', msg)
    exc_str = str(exc)
    assert isinstance(exc_str, str), \
        "%s is returned by __str__, but is not a str" % exc_str



# Generated at 2022-06-24 02:51:16.405811
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should return true when all attributes and classes are equal"""
    e1 = IllegalUseOfScopeReplacer('f', 'n')
    e2 = IllegalUseOfScopeReplacer('f', 'n')
    assert e1 == e2



# Generated at 2022-06-24 02:51:27.945370
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.errors import BzrError
    # Listing the module here is a bit too eager, but doing it
    # lazily seems to trigger some bugs.
    BzrError  # avoid pyflakes error
    disallow_proxying()
    lazy_import(globals(), '''
    from bzrlib.errors import BzrError
    ''')

# Generated at 2022-06-24 02:51:37.263861
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    try:
        del sys.modules['B']
    except KeyError:
        pass
    try:
        del sys.modules['B.C']
    except KeyError:
        pass
    try:
        del sys.modules['A']
    except KeyError:
        pass
    try:
        del sys.modules['A.B']
    except KeyError:
        pass
    try:
        del sys.modules['A.B.C']
    except KeyError:
        pass
    try:
        del sys.modules['A.B.D']
    except KeyError:
        pass
    try:
        del sys.modules['ast']
    except KeyError:
        pass

    from cStringIO import StringIO
    import A.B.C
    import ast
    old = sys.stdout


# Generated at 2022-06-24 02:51:42.102613
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    l = []
    def callable_factory(replacer, scope, name):
        def callable(*args):
            return list(args)
        return callable
    factory = lambda replacer, scope, name: l
    r = ScopeReplacer(l, factory, 'x')
    assert [1,2,3] == r(1,2,3)



# Generated at 2022-06-24 02:51:53.719912
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Tests to check if the ImportProcessor class can be used to generate 
    lazy imports of modules.
    """
    processor = ImportProcessor()
    def a():
        processor.lazy_import(globals(),
            "import re\nfrom tempfile import mkstemp")
    try:
        a()
    except ImportError:
        pass
    else:
        raise TestNotApplicable("tempfile is present, cannot test")
    assert 're' not in globals()
    assert 'mkstemp' not in globals()
    processor.lazy_import(globals(), "import re")
    assert 're' not in globals()
    assert isinstance(re, ImportReplacer)
    re.search
    assert 're' in globals()



# Generated at 2022-06-24 02:52:03.033689
# Unit test for function lazy_import
def test_lazy_import():
    class TestImportReplacer(ImportReplacer):
        """Helper class to allow testing of lazy_import function"""
        def __init__(self, *args, **kwargs):
            self._data = []
            ImportReplacer.__init__(self, *args, **kwargs)
        def _import(self, scope, name):
            self._data.append((scope, name))
            return scope[name]
    def test_text_to_import(module_names, import_as_names, options=()):
        """This checks that the given text converts correctly"""
        text = "from bzrlib import (%s)" % (', '.join(module_names),)
        if options:
            text += ' # %s' % (' '.join(options),)
        scope = {}

# Generated at 2022-06-24 02:52:13.378711
# Unit test for function lazy_import
def test_lazy_import():
    """Test the function 'lazy_import'"""
    scope = {}
    lazy_import(scope, '''
    import bzrlib.foo
    import bzrlib.branch
    import bzrlib.baz
    ''')
    bzrlib = scope['bzrlib']
    foo = scope['foo']
    lazy_class = object.__getattribute__(foo, '__class__')
    branch = scope['branch']
    baz = scope['baz']

    assert_is_instance(foo, lazy_class)
    assert foo._resolve() is None
    assert_is_instance(bzrlib, lazy_class)
    assert_is_instance(branch, lazy_class)
    assert_is_instance(baz, lazy_class)

    import bzr

# Generated at 2022-06-24 02:52:22.378543
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__()

    This method is provided so that users of lazy_import can test
    whether an exception raised matches an expected exception.
    """
    try:
        import bzrlib.lazy_import
    except ImportError:
        from bzrlib import lazy_import
    mod1 = lazy_import.lazy_import(globals(), '''
from bzrlib.lazy_import import (
    IllegalUseOfScopeReplacer,
    lazy_import,
    )
''')

    # two equivalent exceptions are ==
    exc1 = mod1.IllegalUseOfScopeReplacer('mod1', 'oops')
    exc2 = mod1.IllegalUseOfScopeReplacer('mod1', 'oops')
    assert exc1 == exc2

    # two different exceptions are !=


# Generated at 2022-06-24 02:52:29.974721
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    __tracebackhide__ = True
    try:
        from bzrlib.lazy_import import lazy_import
        lazy_import(globals(), '''
        from bzrlib import (
            errors,
            osutils,
            branch,
            )
        import bzrlib.branch
        ''')
        bzrlib.branch.BzrBranch.open.im_func
        bzrlib.branch.BzrBranch.open.im_func
    except Exception:
        import sys
        raise AssertionError('Caught exception: %r' % sys.exc_info()[1])


# Generated at 2022-06-24 02:52:40.928018
# Unit test for function lazy_import
def test_lazy_import():
    # This test mimics the actual usage of the function to ensure that
    # all of the code paths are tested, and the function does the right
    # thing.
    scope = {}
    lazy_import(scope, '''
        from bzrlib import (
            foo,
            bar,
            baz,
            )
        import bzrlib.branch
        import bzrlib.transport
        ''')
    # Make sure we can import our imports manually
    import bzrlib
    assert 'foo' in bzrlib.__dict__
    assert 'bar' in bzrlib.__dict__
    assert 'baz' in bzrlib.__dict__
    assert 'branch' in bzrlib.__dict__
    assert 'transport' in bzrlib.__dict__



# Generated at 2022-06-24 02:52:49.821738
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib._bzrdir_py as _bzrdir_py
    try:
        del _bzrdir_py.BzrdirFormat
    except (AttributeError, KeyError):
        # Don't have a BzrdirFormat object in scope, so we're good
        pass
    else:
        raise AssertionError("BzrdirFormat was already imported")
    # Test something related to the dict, as that's a proxy object
    scoped_dict = {}
    # Test that the normal py import fails, so that we know we've set things
    # up right
    try:
        _bzrdir_py.BzrdirFormat
    except AttributeError:
        pass
    else:
        raise AssertionError("AttributeError should have been raised")

    import_processor = ImportProcess

# Generated at 2022-06-24 02:52:53.298028
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    try:
        raise IllegalUseOfScopeReplacer("abc", "xyz")
    except IllegalUseOfScopeReplacer as e:
        assert str(e) == 'xyz', repr(str(e))



# Generated at 2022-06-24 02:53:00.122364
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Tests for class IllegalUseOfScopeReplacer."""
    from bzrlib.tests.test_lazy_import import TestCaseWithMemoryTransport

    class TestException(TestCaseWithMemoryTransport):
        """Tests for constructor of class IllegalUseOfScopeReplacer."""

        def test_raises(self):
            from bzrlib.lazy_import import IllegalUseOfScopeReplacer
            try:
                raise IllegalUseOfScopeReplacer('test', 'testing')
            except IllegalUseOfScopeReplacer:
                # IllegalUseOfScopeReplacer raised correctly
                pass
            else:
                self.fail('IllegalUseOfScopeReplacer not raised')



# Generated at 2022-06-24 02:53:11.989700
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    v = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    v.notthemsg = 'notthemsg'
    assert str(v) == "ScopeReplacer object 'name' was used incorrectly:" \
        " msg: extra"
    # 2.6, 2.7 or 3.1+
    # Traceback (most recent call last):
    #   File "C:\Program Files\bazaar\2.4\lib\site-packages\bzrlib\tests\blackbox\test_lazy_import.py", line 28, in IllegalUseOfScopeReplacer_test___unicode__
    #     assert u == u'ScopeReplacer object \'name\' was used incorrectly:' \
    # AssertionError: assert u'ScopeReplacer object \'name\' was used incorrectly: msg: extra' == u'ScopeReplacer object '