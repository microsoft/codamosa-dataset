

# Generated at 2022-06-24 02:43:16.086120
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer constructor"""
    # Constructor requires a scope
    try:
        ImportReplacer(None, 'foo', ['foo'])
    except ValueError:
        pass
    else:
        raise AssertionError('ImportReplacer constructor did not require'
                             ' a scope')
    # Constructor requires a name
    try:
        ImportReplacer({}, None, ['foo'])
    except ValueError:
        pass
    else:
        raise AssertionError('ImportReplacer constructor did not require'
                             ' a name')
    # Constructor requires a list of module path parts
    try:
        ImportReplacer({}, 'foo', None)
    except ValueError:
        pass
    else:
        raise AssertionError('ImportReplacer constructor did not require'
                             ' a module path')


# Generated at 2022-06-24 02:43:24.936622
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer

    See http://bugs.launchpad.net/bzr/+bug/95961
    """
    x = ScopeReplacer({}, lambda obj, scope, name: 42, 'x')
    y = x()
    if y != 42:
        raise AssertionError('%r != 42' % (y,))
# end test_ScopeReplacer___call__

# TODO: Could make this into a decorator?

# Generated at 2022-06-24 02:43:28.190521
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    s = str(IllegalUseOfScopeReplacer("x", "y", "z"))
    u = unicode(IllegalUseOfScopeReplacer("x", "y", "z"))
    assert isinstance(s, str)
    assert isinstance(u, unicode)

# Generated at 2022-06-24 02:43:35.346297
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """ Ensure that the constructor of ScopeReplacer executes correctly """
    scope = {}
    name = "name"
    factory = lambda x,y,z: x
    scope_replacer = ScopeReplacer(scope, factory, name)
    assert scope_replacer._scope == scope
    assert scope_replacer._factory == factory
    assert scope_replacer._name == name
    assert scope_replacer._real_obj == None


# Generated at 2022-06-24 02:43:41.365899
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def f_factory(replacer, scope, name):
        return None
    scope = {}
    replacer = ScopeReplacer(scope, f_factory, 'f')
    assert replacer._real_obj is None
    assert replacer._scope is scope
    assert replacer._factory is f_factory
    assert replacer._name is 'f'
    assert scope['f'] is replacer
    class Dummy(object):
        pass
    dummy = Dummy()
    def f_factory(replaacer, scope, name):
        return dummy
    expected = dummy
    actual = replacer._resolve()
    assert actual is expected
    assert replacer._real_obj is dummy



# Generated at 2022-06-24 02:43:52.514007
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the constructor of ScopeReplacer.

    This is an initialization test which doesn't use any of the
    metaprogramming, it just creates an instance of the object and
    stores it in a local variable to check that it works.
    """
    scope = {}
    import os
    factory = lambda repl, sc, n: os
    name = 'os'
    repl = ScopeReplacer(scope, factory, name)
    try:
        repl.path.join
    except AttributeError:
        pass
    else:
        raise AssertionError("ScopeReplacer should not"
                             " have replaced itself yet.")
    try:
        repl.path.join
    except AttributeError:
        pass
    else:
        raise AssertionError("ScopeReplacer should only"
                             " have replaced itself once.")

# Generated at 2022-06-24 02:44:01.897834
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:44:09.716904
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """This tests the lazy_import method of ImportProcessor

    This is a whitebox test, so it uses an internal part of
    ImportProcessor to validate the output of the function being
    tested.

    This is an example of a test that is better if it doesn't
    happen to make sure the duplication of functionality between
    the test and the test subject is minimized.
    """
    scope = {}

    # Test that a very simple import is handled correctly
    import_processor = ImportProcessor(ImportReplacer)
    import_processor.lazy_import(scope, "import foo")
    import_replacer = scope['foo']
    assert_equal({}, import_replacer._import_replacer_children)
    assert_equal(None, import_replacer._member)
    assert_equal('foo', import_replacer._module_path)

   

# Generated at 2022-06-24 02:44:13.265893
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    # This test only tests as far as the format string
    # assumes that the parameter substitution works.
    assert repr(e) == 'IllegalUseOfScopeReplacer(\'foo\')'



# Generated at 2022-06-24 02:44:20.650281
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return unicode, not raise an error"""
    # U+00B0 DEGREE SIGN
    # U+03B1 GREEK SMALL LETTER ALPHA
    # U+03B2 GREEK SMALL LETTER BETA
    try:
        u'This message should not raise an error: %(msg)s' % {'msg': u'\u00b0\u03b1\u03b2'}
    except UnicodeDecodeError:
        raise AssertionError('UnicodeDecodeError raised when it should not')
test_IllegalUseOfScopeReplacer___unicode__.unittest = ['unit']


# Generated at 2022-06-24 02:44:23.512256
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    from doctest import DocTestSuite
    return DocTestSuite()




# Generated at 2022-06-24 02:44:32.286013
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ must compare class, then dict"""
    # These objects compare the same
    IllegalUseOfScopeReplacer('foo', 'bar') == \
        IllegalUseOfScopeReplacer('foo', 'bar')
    # Different message
    IllegalUseOfScopeReplacer('foo', 'bar') != \
        IllegalUseOfScopeReplacer('foo', 'baz')
    # Different name
    IllegalUseOfScopeReplacer('foo', 'bar') != \
        IllegalUseOfScopeReplacer('boo', 'bar')
    # Different class
    class Foo(Exception):
        pass
    IllegalUseOfScopeReplacer('foo', 'bar') != Foo('foo', 'bar')


# Generated at 2022-06-24 02:44:41.190805
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    def test_scope(dictionary):
        return dictionary
    def create_object(scope_replacer, scope, name):
        return object()
    key = None
    while key is None or key in sys.modules:
        key = 'test'+str(id(scope_replacer))
    test_scope_replacer = ScopeReplacer(test_scope(sys.modules),
        create_object, key)
    test_scope_replacer.test_value = 'test'
    test_scope_replacer._resolve()
    assert test_scope_replacer.test_value == 'test'


# Generated at 2022-06-24 02:44:47.457485
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode

    See also test_exception_unicode_preservation
    """
    exc = IllegalUseOfScopeReplacer('foo', 'bad foo.')
    u = unicode(exc)
    from bzrlib.i18n import gettext
    exp = gettext(u'ScopeReplacer object %(name)r was used incorrectly:'
                  u' %(msg)s%(extra)s') % {
            'msg': u'bad foo.',
            'name': u'foo',
            'extra': u'',
            }
    assert isinstance(u, unicode)
    assert u == exp



# Generated at 2022-06-24 02:44:56.240618
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    doctest.run_docstring_examples(ScopeReplacer.__call__, globals())

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    global __traceback_info__
    __traceback_info__ = 'Unused'
    replacer = ScopeReplacer({}, lambda self, scope, name: [1, 2, 3], '')
    __traceback_info__ = replacer

# Generated at 2022-06-24 02:44:58.843700
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from bzrlib.tests import TestSkipped
    raise TestSkipped("test case for bzrlib.lazy_import.IllegalUseOfScopeReplacer.__repr__")


# Generated at 2022-06-24 02:45:06.693217
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:45:16.452628
# Unit test for function lazy_import
def test_lazy_import():
    class MockImportReplacer(object):
        """A mock ImportReplacer object"""

        def __init__(self, *args, **kwargs):
            pass

        def __call__(self, *args, **kwargs):
            pass

        def __getattribute__(self, attr):
            return MockImportReplacer()

        def __setattr__(self, attr, value):
            pass

    # We want to make sure that the ImportReplacer class is set properly
    # from the function.
    proc = ImportProcessor(MockImportReplacer)
    proc.imports = {'foo':(['foo'], None, {})}
    proc._convert_imports({})
    # This should have replaced 'foo' with the MockImportReplacer
    assert(proc.imports['foo'] is not None)

# Generated at 2022-06-24 02:45:25.898753
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__()

    Two IllegalUseOfScopeReplacer objects are equal if they are instances of
    the same class, and their __dict__ attributes are equal.
    """
    class T(IllegalUseOfScopeReplacer):
        def __init__(self, i, j):
            self.i = i
            self.j = j
    t1 = T(1, 2)
    t2 = T(1, 2)
    t3 = T(3, 4)
    t4 = T(1, 4)
    t5 = T(1, 2)
    t5.fake_attr = 'k'
    t6 = T(1, 2)
    t6.fake_attr = 'k'
    assert t1 == t2
    assert t1 != t3
    assert t

# Generated at 2022-06-24 02:45:33.105963
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer(name, msg, extra=None)
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg')"
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"

# Generated at 2022-06-24 02:45:36.037982
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys

# Generated at 2022-06-24 02:45:44.825229
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit tests for class ScopeReplacer"""
    import bzrlib.lazy_import
    bzrlib.lazy_import._scopereplacer_testing = True

# Generated at 2022-06-24 02:45:53.706559
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() returns a unicode object even if _fmt is a str or unicode
    """
    class FooError(IllegalUseOfScopeReplacer):
        _fmt = u'Some %(name)s error'
    class BarError(IllegalUseOfScopeReplacer):
        _fmt = u'Some %(name)s error'
    f = FooError('foo', 'msg')
    assert f.__unicode__() == u'Some foo error'
    assert type(f.__unicode__()) is unicode
    b = BarError('bar', 'msg')
    assert b.__unicode__() == u'Some bar error'
    assert type(b.__unicode__()) is unicode



# Generated at 2022-06-24 02:46:00.735783
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """ Unit test for method __str__ of class IllegalUseOfScopeReplacer

    test that format string can contain non ascii characters
    """
    r = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r._fmt = u'%(name)r -> %(msg)s %(extra)s'
    # check that the format string is decoded properly
    assert str(r) == 'name -> msg extra'



# Generated at 2022-06-24 02:46:11.061454
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class A:
      def __init__(self, val):
        self.val = val

    # create a ScopeReplacer obj in place of a normal A
    sr = ScopeReplacer({}, A, 'name')
    # test getting a value
    sr.val
    # test setting a value
    sr.val = 2
    try:
      # running this should work under normal circumstances
      # but is disallowed if ScopeReplacer._should_proxy is False
      # as it is in the bzrlib selftest
      sr.val = 2
    except IllegalUseOfScopeReplacer:
      pass
    # test deleting a value
    del sr.val
    # test setting a value when the target object has been replaced
    ScopeReplacer._should_proxy = False
    sr.val = 2
    # cleanup
    del A




# Generated at 2022-06-24 02:46:15.779539
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()

    Ensure that the repr for IllegalUseOfScopeReplacer is unique
    for unique values.
    """
    from bzrlib.tests import make_repr_tests
    tests = make_repr_tests(IllegalUseOfScopeReplacer)
    tests.check()



# Generated at 2022-06-24 02:46:26.686844
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {'__name__':'builtins'}
    cls = ImportReplacer.__class__
    cls(scope, 'foo', ['foo'])
    cls(scope, 'foo', ['foo'], children={})
    cls(scope, 'foo', ['foo'], member='bar')
    cls(scope, 'foo', ['foo'], member='bar', children={})

    # only 1 of member or children can be supplied
    try:
        cls(scope, 'foo', ['foo'], member='bar', children={'a':(['foo', 'a'], None, {})})
    except ValueError:
        pass
    else:
        raise AssertionError('Failure to raise on both member & children')



# Generated at 2022-06-24 02:46:37.199093
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import os
    import bzrlib.tests

    if not ScopeReplacer._should_proxy:
        # Probably in selftest.
        return

    def check(obj, args, kwargs, expected):
        actual = obj(*args, **kwargs)
        if actual != expected:
            bzrlib.tests.TestCase.fail("Actual %r != Expected %r"
                % (actual, expected))

    factory = lambda unused, unused2, unused3: os.path
    scope = locals()
    name = 'os'
    lazy_os = ScopeReplacer(scope, factory, name)
    check(lazy_os, [], {}, os)
    check(lazy_os, ['stat'], {}, os.stat)

    def factory(self, scope, name):
        return scope

   

# Generated at 2022-06-24 02:46:49.240971
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test construction and lazy loading of ScopeReplacer."""
    global test_scope_replacer_obj
    test_scope_replacer_obj = None
    def load_obj(self, scope, name):
        global test_scope_replacer_obj
        return test_scope_replacer_obj

    def fail():
        raise AssertionError('fail')

    try:
        test_scope_replacer_obj = fail
        try:
            ScopeReplacer(locals(), load_obj, 'test_scope_replacer_obj')
        except:
            pass
        else:
            raise AssertionError('fail')
    finally:
        del test_scope_replacer_obj

    test_scope_replacer_obj = None

# Generated at 2022-06-24 02:46:56.269171
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import mock
    from bzrlib.lazy_import import ScopeReplacer

    def a_function(*args, **kwargs):
        pass

    scope = {}
    name = 'a'
    scope_replacer = ScopeReplacer(scope, mock.Mock(return_value=a_function),
                                   name)
    scope[name]()


    assert scope_replacer._factory.called


# Generated at 2022-06-24 02:46:59.763944
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo.py', 'Got %(name)s', 'error')
    assert str(e) == 'Got foo.py: error'
    assert repr(e) == "IllegalUseOfScopeReplacer('Got foo.py: error')"
    e = IllegalUseOfScopeReplacer('foo.py', 'Got %(name)s')
    assert str(e) == 'Got foo.py'


# Generated at 2022-06-24 02:47:11.021186
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test constructor for class ScopeReplacer"""
    # Test that the lazy object is actually allocated in the given scope.
    def test_factory(scope_replacer, scope, name):
        return 'test_factory_result'

    # This is the scope we will pass in - we will add the lazy object to
    # it to make sure this actually happens.
    my_scope = {}

    # Make sure the lazy object is actually created.
    lazy_obj = ScopeReplacer(my_scope, test_factory, 'test_lazy_obj')
    # And that a real object has not been created yet.
    assert(lazy_obj._real_obj is None)
    # Check the object was actually created in the given scope.
    assert('test_lazy_obj' in my_scope)

# Generated at 2022-06-24 02:47:16.578032
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    module_path = ['test_module']
    member = 'test_member'
    replacer = ImportReplacer(sys.modules, 'test_module', module_path,
                              member=member)
    assert replacer._import_replacer_children == {}
    assert replacer._member == member
    assert replacer._module_path == module_path
    assert replacer._scope is sys.modules
    assert replacer._name == 'test_module'


# Generated at 2022-06-24 02:47:19.456264
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    e = IllegalUseOfScopeReplacer('name', 'message', {'extra': 'extra'})
    eq = 'IllegalUseOfScopeReplacer(name, message, {'
    assert repr(e).startswith(eq)
    assert 'extra' in repr(e)



# Generated at 2022-06-24 02:47:23.615044
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    def factory(self, scope, name):
        return 42
    scope = {}
    name = 'name'
    x = ScopeReplacer(scope, factory, name)
    x.attr = 'attr'
    sys.exc_clear()
    return (x.attr, x == 42, scope == {'name': 42}, (x.attr, x == 42, scope == {'name': 42}))

# Generated at 2022-06-24 02:47:29.049263
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    exc = IllegalUseOfScopeReplacer(name='foo', msg='boo', extra=('foo', 'bar'))


# Generated at 2022-06-24 02:47:32.765094
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Constructor ImportProcessor() test."""
    import_processor = ImportProcessor()
    # test attributes initialization
    attributes = ('imports', '_lazy_import_class')
    for attr in attributes:
        if not hasattr(import_processor, attr):
            raise Exception()


# Generated at 2022-06-24 02:47:37.473657
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() should produce a valid repr"""
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    repr(e) # should not raise an exception



# Generated at 2022-06-24 02:47:41.980777
# Unit test for function disallow_proxying
def test_disallow_proxying():
    scope = {}
    def _my_factory(s, scope, name):
        return "real_object"
    lazy_import(scope, '''
    import bzrlib
    ''', _my_factory)
    bzrlib.disallow_proxying()
    x = bzrlib



# Generated at 2022-06-24 02:47:50.362838
# Unit test for function lazy_import
def test_lazy_import():
    """lazy_import should make all the imports lazy"""
    class TestImport(ImportReplacer):
        def __init__(self, *args, **kwargs):
            ImportReplacer.__init__(self, *args, **kwargs)

        def _import(self, scope, name):
            scope[name] = name
            return name

    scope = locals()

# Generated at 2022-06-24 02:48:00.662605
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()

    IllegalUseOfScopeReplacer.__repr__() should return the same value that
    gets printed from str(exc).

    Typically exceptions should implement __str__, the value of which is
    returned by str(exc) and which then gets passed to __repr__.

    We have some exceptions which have __unicode__ instead of __str__, and so
    we need to test that __repr__ works as expected in that case.
    """
    exc = IllegalUseOfScopeReplacer('abc', 'def')
    returned = exc.__repr__()
    expected = str(exc)
    _assert_strings_equal(returned, expected)



# Generated at 2022-06-24 02:48:01.205762
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    i = ImportProcessor()


# Generated at 2022-06-24 02:48:05.295375
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the method ImportProcessor.lazy_import
    
    This test is a little odd, as we can't use lazy import for the
    testing, so we simply test the functionality of the lazy_import
    implementation.
    """
    from bzrlib.tests import fake_mod

    # First we test that imports function correctly
    scope = fake_mod.setup_memory()
    importer = ImportProcessor()
    importer.lazy_import(scope, text='import bzrlib.tests.fake_mod')
    import bzrlib.tests.fake_mod
    assert bzrlib.tests.fake_mod.__name__ == 'bzrlib.tests.fake_mod'

    # And the same thing, but using the 'as' construct

# Generated at 2022-06-24 02:48:17.069884
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import types
    import re
    import inspect
    import six
    class Tester(object):
        __slots__ = ('_scope', '_factory', '_name', '_real_obj')
        def __init__(self, scope, factory, name):
            object.__setattr__(self, '_scope', scope)
            object.__setattr__(self, '_factory', factory)
            object.__setattr__(self, '_name', name)
            object.__setattr__(self, '_real_obj', None)
            scope[name] = self
        def _resolve(self):
            name = object.__getattribute__(self, '_name')
            real_obj = object.__getattribute__(self, '_real_obj')

# Generated at 2022-06-24 02:48:29.279517
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import builtins
    obj_count = len(sys.modules)
    obj_count += len(vars(builtins))
    import re
    import bzrlib
    import bzrlib.trace
    from bzrlib import errors
    import bzrlib.errors as bzrerrors
    reg = ImportProcessor()
    reg.lazy_import(globals(), """
from re import *
import re as regex
import bzrlib
import bzrlib.trace
from bzrlib import errors
from bzrlib import errors as bzrerrors
from bzrlib import (trace, errors)
""")

    # Now ensure that we got all the objects we should
    def count_obj_in(module):
        return len(vars(module))
    assert count_obj

# Generated at 2022-06-24 02:48:41.430974
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import __builtin__
    import sys
    
    __builtin__.__dict__['__import__'] = fake_import


# Generated at 2022-06-24 02:48:49.787505
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor"""
    def recursive_check(left, right):
        if isinstance(left, dict):
            if not isinstance(right, dict) or len(left) != len(right):
                return False
            for key in left:
                if key not in right:
                    return False
                if not recursive_check(left[key], right[key]):
                    return False
            return True
        return left == right

    ip = ImportProcessor()
    ip.lazy_import(None, 'import bzrlib.foo,bzrlib.bar.baz,bzrlib as bzr')

# Generated at 2022-06-24 02:48:56.485983
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object (not unicode)"""
    x = IllegalUseOfScopeReplacer('y', 'z')
    assert isinstance(x.__str__(), str)
    # If the string contains a unicode character, it should
    # still return a str
    x = IllegalUseOfScopeReplacer('y', u'\u1234z')
    assert isinstance(x.__str__(), str)



# Generated at 2022-06-24 02:49:03.264258
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit testing of class ImportProcessor"""
    orig = """
    import foo
    import foo.bar.baz
    import foo, foo.bar.baz, foo.bar.baz.bing
    From foo import bar
    from foo import bar, baz
    from foo import bar as bing
    from foo import bar as bing, baz as bong
    """

# Generated at 2022-06-24 02:49:13.540326
# Unit test for function lazy_import
def test_lazy_import():
    """This tests that lazy_import works as expected.

    Because lazy_import is essentially a big string processor, its
    easy to get the text that it takes wrong.
    """

    # This is essentially a mapping of all possible variations of
    # code that lazy_import supports.

# Generated at 2022-06-24 02:49:25.192098
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that all kinds of valid imports are processed properly"""
    import_processor = ImportProcessor()
    import_processor.imports = {}
    import_processor._build_map('import foo')
    assert import_processor.imports == {'foo': (['foo'], None, {})}

    import_processor.imports = {}
    import_processor._build_map('import foo.bar as thing')
    assert import_processor.imports == {'thing': (['foo', 'bar'], None, {})}

    import_processor.imports = {}
    import_processor._build_map('import foo, bar')
    assert import_processor.imports == {'foo': (['foo'], None, {}),
                                        'bar': (['bar'], None, {})
                                        }

    import_processor.imports = {}

# Generated at 2022-06-24 02:49:36.040404
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    def _test_ImportReplacer(name, module_path, member=None, children={}):
        d = {}
        ImportReplacer(d, name, module_path, member, children)
        return d

    d = _test_ImportReplacer('foo', ['foo'], None, {})
    assert d == {'foo':
        ImportReplacer(scope=d, name='foo', module_path=['foo'],
                       member=None, children={})
        }, d

    d = _test_ImportReplacer('foo', ['foo'], 'bar', {})
    assert d == {'foo':
        ImportReplacer(scope=d, name='foo', module_path=['foo'],
                       member='bar', children={})
        }, d



# Generated at 2022-06-24 02:49:41.059299
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    assert e.name == 'foo'
    assert e.msg == 'msg'
    assert e.extra == ': extra'
    assert str(e) == 'foo: msg: extra'


# Generated at 2022-06-24 02:49:49.729934
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test for method __getattribute__ of class ScopeReplacer"""
    # Test for correct handling of illegal attribute names
    # Test for correct handling of legal names
    # Test for correct handling of nonexistent names
    from bzrlib import lazy_import
    from bzrlib.lazy_import import ScopeReplacer

    class TestClassScopeReplacer(ScopeReplacer):
        def __init__(self):
            self.initialised = False
            def factory(self, scope, name):
                self.initialised = True
                return TestClassScopeReplacer()
            ScopeReplacer.__init__(self, locals(), factory, 'testclass')
    TestClassScopeReplacer()
    # Ensure that the factory was called
    return testclass.initialised

# Generated at 2022-06-24 02:49:55.763251
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() returns a string"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    u = unicode(e)
    assert isinstance(s, str), repr(s)
    assert isinstance(u, unicode), repr(u)
test_IllegalUseOfScopeReplacer___str__.__test__ = False



# Generated at 2022-06-24 02:50:01.060915
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    def factory(self, scope, name):
        return name
    name = "myname"
    sr = ScopeReplacer(scope, factory, name)
    # check factory was not called
    assert sr._real_obj is None
    assert scope[name] is sr

# Unit tests for method _resolve of class ScopeReplacer

# Generated at 2022-06-24 02:50:11.664872
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Avoiding wasteful indirection by using disallow_proxying."""
    import gc
    lazy_import(globals(), """
    import bzrlib.testutils.features
    """)
    disallow_proxying()
    # The test module doesn't actually use any of the features
    # it imports, so the symbolic reference should get cleaned up.
    gc.collect()
    n = len(gc.get_objects())
    bzrlib.testutils.features.lazy_import(globals(), 'import bzrlib')
    # The lazy import should not create any additional objects,
    # because it is forbidden to use the imported objects as proxies.

# Generated at 2022-06-24 02:50:22.665307
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() should always
    return a str, not a unicode

    This was the cause of a crash in Launchpad, see LP #92993.
    """
    import sys
    # Set locale to something Unicode
    try:
        import locale
        locale.setlocale(locale.LC_ALL, 'fr_FR.UTF-8')
    except locale.Error as e:
        print >>sys.stderr, "Cannot set locale:", e

    # Build an IllegalUseOfScopeReplacer exception.
    exception = IllegalUseOfScopeReplacer('foo', 'bar')

    # Try to format the exception into a string.
    # This is the exact sequence that triggered the bug.
    repr(exception)



# Generated at 2022-06-24 02:50:33.865865
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib import workingtree
    from bzrlib import commands
    class DummyModule(object):
        def __init__(self):
            self.__dict__['foo'] = 'foo'
            self.__dict__['bar'] = 'bar'
            self.__dict__['baz'] = 'baz'
            self.__dict__['bing'] = 'bing'
        def __getattribute__(self, item):
            return self.__dict__[item]
        def __setattr__(self, item, value):
            self.__dict__[item] = value

    class DummyReplacer(ImportReplacer):
        _module = DummyModule()
        
        def _import(self, scope, name):
            return DummyReplacer._module
        

# Generated at 2022-06-24 02:50:43.636542
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # Test by constructing an IllegalUseOfScopeReplacer.
    exc = IllegalUseOfScopeReplacer("a", "msg")

    # call __str__ and check that it returns a str object
    s = exc.__str__()
    assert isinstance(s, str)
    # check that s contains the expected value.
    # This should be a string starting with 'a' (the name) and
    # containing the word 'msg'
    assert s.startswith("a")
    assert "msg" in s



# Generated at 2022-06-24 02:50:55.508525
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class TestClass(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
        def __getattribute__(self, attr):
            return object.__getattribute__(self, attr)
        def __setattr__(self, attr, value):
            return object.__setattr__(self, attr, value)

    scope = {}
    sr = ScopeReplacer(scope, lambda myself, scope, name: TestClass(1, 2, 3), 'test_ScopeReplacer___getattribute__')
    assert scope['test_ScopeReplacer___getattribute__'] == sr
    assert sr.a == 1
    assert sr.b == 2
    assert sr.c == 3

# Generated at 2022-06-24 02:51:05.038772
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import TestCaseReplacer, TestCaseLazyImport

    class TestScopeReplacer(TestCaseLazyImport, TestCaseReplacer):

        def test___getattribute__(self):
            from bzrlib.lazy_import import ScopeReplacer, lazy_import
            from bzrlib.tests import TestCase
            lazy_import(locals(), """
            from bzrlib import tests
            """)
            import bzrlib.tests
            class C(tests.TestCase):
                def test_pass(self):
                    pass
            lazy_import(locals(), """
            from bzrlib import tests
            """)
            self.assertIsInstance(tests.TestCase, ScopeReplacer)
            tests.TestCase = C


# Generated at 2022-06-24 02:51:09.714672
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() - sanity test

    This method tests for the most trivial case:
    no parameters set, no format string set.
    """
    e = IllegalUseOfScopeReplacer(None, None)
    # __str__ should return a str
    str(e)



# Generated at 2022-06-24 02:51:22.446968
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__: equality test"""
    # the equality test uses the fields declared in the _fmt string
    # and ignores extra ones, which are not in _fmt.
    # This is needed to preserve the equality test on any extra fields
    # that might be added in derived classes of IllegalUseOfScopeReplacer.
    r1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r2 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r3 = r1.__class__('name', 'msg', 'another extra')
    r4 = r1.__class__('another name', 'msg', 'extra')
    r5 = r1.__class__('name', 'another msg', 'extra')
    r6 = r1.__class__('name', 'msg', 'one more extra')

# Generated at 2022-06-24 02:51:31.103260
# Unit test for function lazy_import
def test_lazy_import():
    import sys
    from StringIO import StringIO
    sys.stderr = StringIO()
    lazy_import = ImportProcessor(lazy_import_class=ImportReplacer).lazy_import

    def check_import(scope, text, expected):
        """Load all modules in text, and ensure they are correctly loaded"""
        lazy_import(scope, text)
        for k in expected:
            assert k in scope
        for k in scope:
            if k[:1] == '_':
                continue
            if k not in expected and k != 'lazy_import':
                raise AssertionError('Unexpected extra key %r in scope' % k)
        # Ensure that we actually got lazy imports
        for k, v in scope.iteritems():
            if k not in expected:
                continue

# Generated at 2022-06-24 02:51:34.723722
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a minimal representation of the object::

    >>> from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    >>> e = IllegalUseOfScopeReplacer('name', 'msg')
    >>> e # doctest: +ELLIPSIS
    IllegalUseOfScopeReplacer('name', 'msg')
    """



# Generated at 2022-06-24 02:51:40.519679
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """A class that tests IllegalUseOfScopeReplacer.__str__"""
    e1 = IllegalUseOfScopeReplacer('foo/file', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer('foo/file', 'msg', 'extra')
    assert e1 == e1 # Test reflexivity
    assert e1 == e2 # Test equality
    assert e1 != 1  # Test inequality
    assert str(e1)   # Test __str__



# Generated at 2022-06-24 02:51:41.564316
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # No unit test possible

    pass

# Generated at 2022-06-24 02:51:46.923286
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import bzrlib
    local_scope = locals()
    def factory(self, scope, name):
        assert self is local_scope[name]
        return 42
    ScopeReplacer(local_scope, factory, 'answer')
    assert local_scope['answer'] == 42
    del local_scope['answer']


# Generated at 2022-06-24 02:51:57.532847
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test for method lazy_import for class ImportProcessor"""

    import bzrlib.plugins
    import os.path
    import bzrlib.trace
    test_base = os.path.dirname(os.path.dirname(bzrlib.trace.__file__))

# Generated at 2022-06-24 02:52:06.702048
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys

# Generated at 2022-06-24 02:52:10.624379
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    from doctest import DocTestSuite
    return DocTestSuite(
        'bzrlib.lazy_import',
        optionflags=doctest.NORMALIZE_WHITESPACE,
        )



# Generated at 2022-06-24 02:52:16.108702
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ must return a unicode object containing the classname, and
    string representation of the exception object.
    """
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    r = repr(e)
    assert isinstance(r, unicode)
    assert r.startswith("IllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer("), r
    assert r.endswith(", 'bar'))")



# Generated at 2022-06-24 02:52:24.100783
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class MyImportReplacer(ImportReplacer):
        def __init__(self, *args, **kwargs):
            super(MyImportReplacer, self).__init__(*args, **kwargs)

    m = {}
    MyImportReplacer(m, 'foo', ['foo'], None, {'bar': (('foo', 'bar'),
        None, {})})
    assert 'foo' in m
    assert isinstance(m['foo'], MyImportReplacer)
    obj = m['foo']._resolve()
    assert isinstance(obj, type(__builtins__))
    assert 'bar' in obj.__dict__
    assert isinstance(obj.bar, MyImportReplacer)
    obj.bar._resolve()
    assert isinstance(obj.bar, type(__builtins__))

    m = {}

# Generated at 2022-06-24 02:52:36.137993
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.lazy_import import lazy_import
    scope = {}
    lazy_import(scope, '''
    from bzrlib import (
        tests,
        )
    ''')
    extern = ExternalBase()
    def add_one(self, scope, name):
        return extern.add_one
    scope["tests"].TestCase.add_one = ScopeReplacer(scope, add_one, "add_one")
    actual = scope["tests"].TestCase.add_one(1)
    expected = 2
    extern.failUnlessEqual(expected, actual,
        "expected %r but actual %r" % (expected, actual))


# Generated at 2022-06-24 02:52:43.606258
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    ImportReplacer(scope, name='foo', module_path=['foo'],
        member=None, children={})
    assert scope == {'foo':ImportReplacer(scope, name='foo',
            module_path=['foo'], member=None, children={})}
    ImportReplacer(scope, name='foo', module_path=['foo'],
        member='bar', children={})
    assert scope == {'foo':ImportReplacer(scope, name='foo',
            module_path=['foo'], member='bar', children={})}
    ImportReplacer(scope, name='foo',
        module_path=['foo'], member=None,
        children={'bar':(['foo', 'bar'], None, {})})

# Generated at 2022-06-24 02:52:46.150555
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert e.name == 'foo'
    assert e.msg == 'bar'
    assert e.extra == ': baz'



# Generated at 2022-06-24 02:52:48.957900
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    err = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(err) == "ScopeReplacer object 'name' was used incorrectly:" \
        " msg: extra"
    # TODO: more?



# Generated at 2022-06-24 02:52:54.054324
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """test for method __getattribute__ of class ScopeReplacer"""
    global __test_ScopeReplacer___getattribute___exception
    global __test_ScopeReplacer___getattribute___obj
    global __test_ScopeReplacer___getattribute___attr
    from bzrlib.lazy_import import ScopeReplacer

    def __test_ScopeReplacer___getattribute___factory(self, scope, name):
        global __test_ScopeReplacer___getattribute___exception
        global __test_ScopeReplacer___getattribute___obj
        global __test_ScopeReplacer___getattribute___attr
        if __test_ScopeReplacer___getattribute___exception:
            raise __test_ScopeReplacer___getattribute___exception
        __test_ScopeReplacer___getattribute___attr = attr
        return __test_ScopeReplacer___getattribute___

# Generated at 2022-06-24 02:53:01.192311
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for class ScopeReplacer, method __call__"""
    from bzrlib.tests import TestCase
    class _DummyScopeReplacer(object):
        def __init__(self, name, scope=None):
            object.__setattr__(self, '_name', name)
            object.__setattr__(self, '_scope', scope or {})
            object.__setattr__(self, '_real_obj', None)
        def _resolve(self):
            name = object.__getattribute__(self, '_name')
            obj = object.__getattribute__(self, '_real_obj')
            if obj is None:
                scope = object.__getattribute__(self, '_scope')
                obj = scope[name]

# Generated at 2022-06-24 02:53:11.954187
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    # We need to use a non-trivial scope, so that the scope dict
    # isn't simple enough to use a direct dict.
    class Scoped(dict):
        pass
    scope = Scoped()
    my_import = ScopeReplacer(scope, lambda self, scope, name: int, 'my_import')
    assert my_import.__class__ is ScopeReplacer
    assert isinstance(scope['my_import'], ScopeReplacer)
    assert scope['my_import'].__class__ is ScopeReplacer
    assert isinstance(my_import, int)
    assert my_import.__class__ is int
    assert isinstance(scope['my_import'], int)
    assert scope['my_import'].__class__ is int

