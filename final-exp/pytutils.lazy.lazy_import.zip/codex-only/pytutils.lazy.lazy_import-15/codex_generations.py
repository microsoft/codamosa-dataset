

# Generated at 2022-06-24 02:43:13.459135
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a string giving the class name and the string representation of the object."""
    # __repr__ always returns str
    expected = "IllegalUseOfScopeReplacer('bzrlib', 'Incorrect use')"
    e = IllegalUseOfScopeReplacer('bzrlib', 'Incorrect use')
    actual = repr(e)
    if actual != expected:
        raise AssertionError("Actual output was %r" % (actual,))
# end test_IllegalUseOfScopeReplacer___repr__


# Generated at 2022-06-24 02:43:24.625249
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Smoke test for ScopeReplacer"""
    d = {}
    def factory(self, scope, name):
        return 42
    ScopeReplacer(d, factory, 'foo')
    def factory2(self, scope, name):
        return self
    try:
        ScopeReplacer(d, factory2, 'foo')
        self.fail('ScopeReplacer re-use should raise an exception.')
    except IllegalUseOfScopeReplacer:
        pass
    # Check that we can use the name, and that the factory has been called.
    self.assertEqual(d['foo'], 42)
    def factory3(self, scope, name):
        raise ValueError('foo')

# Generated at 2022-06-24 02:43:27.038736
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    ob = IllegalUseOfScopeReplacer('name', 'msg', 'foo')
    assert ob.name == 'name'
    assert ob.msg == 'msg'
    assert ob.extra == ': foo'



# Generated at 2022-06-24 02:43:35.804477
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():

    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    def check(cls, expects):
        for k, v in expects.items():
            e = cls(k, 'test')
            got = e.__unicode__()
            if v != got:
                raise AssertionError("expected %r but got %r" % (v, got))
        return True


# Generated at 2022-06-24 02:43:45.151159
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Tests that IllegalUseOfScopeReplacer.__repr__ works.
    """
    def do_test(name, msg, extra=None):
        e = IllegalUseOfScopeReplacer(name, msg, extra=extra)
        expected = '%s(%r)' % (IllegalUseOfScopeReplacer.__name__,
                               str(e))
        actual = repr(e)
        if not actual.startswith(expected):
            raise AssertionError('%r did not start with %r' % (actual,
                                                               expected))
    do_test('name', 'msg')
    do_test('spam', 'eggs', extra=['a', 'b'])



# Generated at 2022-06-24 02:43:49.907159
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ returns a unicode object."""
    x = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(x)
    assert isinstance(u, unicode), repr(u)

# Generated at 2022-06-24 02:44:01.163084
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test basic operation of ImportReplacer objects"""
    # This function needs to be inside this function to avoid a
    # recursive import
    def f(f_scope, f_name):
        return 17

    def test_invalid_member_and_children():
        try:
            ImportReplacer(scope={}, name='f', module_path=['foo'],
                           member='g', children={})
        except ValueError:
            pass
        else:
            raise AssertionError('Should have rejected children+member')

    def test_basic():
        """Test the import replacer can import the named object"""
        scope = {}
        ImportReplacer(scope, name='f', module_path=['foo'], member='g',
                children={})

# Generated at 2022-06-24 02:44:08.377521
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test case for ImportProcessor class.

    This tests that the ImportProcessor correctly converts the import
    statements into a dict of lazy imports.
    """
    from bzrlib import imports as _m_imports

    class TestImportReplacer(_m_imports.ImportReplacer):
        _calls = []

        def _import(self, scope, name):
            self._calls.append((scope, name))

    ip = _m_imports.ImportProcessor(TestImportReplacer)
    scope = {}

    def test_text(text):
        TestImportReplacer._calls = []
        ip.lazy_import(scope, text)
        return TestImportReplacer._calls


# Generated at 2022-06-24 02:44:15.867602
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of ImportProcessor.

    When someone calls the constructor of ImportProcessor, we want
    to call the super-constructor.
    """
    __tracebackhide__ = True
    scope = {}
    p = ImportProcessor(None)
    p.lazy_import(scope, "import a.b, c")
    assert scope == {'a': ImportReplacer(scope, 'a', ['a'], None,
                    {'b': (['a', 'b'], None, {})}),
                    'c': ImportReplacer(scope, 'c', ['c'], None, {})}

# Generated at 2022-06-24 02:44:22.275922
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should always return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    # We store the unicode string to make sure the exception does not get
    # converted to another type of object
    u = unicode(e)
    from bzrlib.trace import mutter
    mutter('object has type: %s', type(u))
    # The string must be unicode
    if not isinstance(u, unicode):
        raise AssertionError('Expected %r to be unicode but got %r', e, u)



# Generated at 2022-06-24 02:44:33.147989
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(), text="import foo")
    import_processor.lazy_import(globals(), text="from foo import bar")
    import_processor.lazy_import(globals(), text="from foo import bar, baz")
    import_processor.lazy_import(globals(), text="from foo import bar as bar")
    import_processor.lazy_import(globals(), text="from foo import bar as bar,"
                                                 "baz as baz")

# Generated at 2022-06-24 02:44:38.041268
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ should return a representation"""
    e = IllegalUseOfScopeReplacer('name', 'something')
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'something')"
    assert '\n' not in repr(e)



# Generated at 2022-06-24 02:44:43.258994
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ must return a string and must not fail"""
    # This class is not meant to be used, and should never be instantiated
    # but __repr__ could still fail.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = repr(e)
    assert isinstance(s, str), '%r should be a str' % (s,)


_trace_scope_replacer = False

# Generated at 2022-06-24 02:44:52.671874
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """class IllegalUseOfScopeReplacer: __repr__()"""
    x = IllegalUseOfScopeReplacer('name', 'message')
    # using assertEquals() instead of assertEqual() because it is used by
    # the test suite, while the other is not.
    # pylint: disable=E1101
    assertEquals('IllegalUseOfScopeReplacer(name)', repr(x))
    # pylint: enable=E1101


# Generated at 2022-06-24 02:45:03.255200
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from six.moves import cStringIO as StringIO
    from bzrlib import trace
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.out = StringIO()
            self.old_out = trace._out
            trace._out = self.out
        def tearDown(self):
            trace._out = self.old_out
        def assertOutput(self, expected):
            actual = self.out.getvalue()
            self.assertEquals(expected, actual)
            self.out.truncate(0)
    import bzrlib.tests
    bzrlib.tests.modules_for_testing.add_lazy('bzrlib.trace')
    from bzrlib.tests import TestCaseInTempDir
    # Test with ScopeReplacer._should_proxy

# Generated at 2022-06-24 02:45:09.197396
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method str defined on class IllegalUseOfScopeReplacer"""
    # no attributes
    e = IllegalUseOfScopeReplacer(None, None)
    s = str(e)
    assert isinstance(s, str)
    # attrs
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-24 02:45:15.098636
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test that IllegalUseOfScopeReplacer.__str__() returns a str object"""
    e = IllegalUseOfScopeReplacer("name", "message")
    s = str(e)
    if not isinstance(s, str):
        raise AssertionError(
            "%r.__str__() returns a %r object, but must return a str object."
            % (e, type(s)))



# Generated at 2022-06-24 02:45:25.416563
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ method of IllegalUseOfScopeReplacer"""
    # make an instance
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "A test exception"
    m = MyException('obj', 'msg', 'extra')
    # check that it is equal to itself
    assert m == m
    # check that it is not equal to other things
    assert m != []
    assert m != 'm'
    # check that it is not equal to a same class instance with different attrs
    n = MyException('obj', 'something else', 'extra')
    assert m != n
    n = MyException('something else', 'msg', 'extra')
    assert m != n
    n = MyException('obj', 'msg', 'something else')
    assert m != n



# Generated at 2022-06-24 02:45:37.124857
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import bzrlib
    class TestableScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            ScopeReplacer.__init__(self, scope, factory, name)
    factory_called = []
    def factory(self, scope, name):
        factory_called.append((self, scope, name))
        return 'testable_scope_replacer'
    scope = {}
    sr = TestableScopeReplacer(scope, factory, 'sr')
    self.assertIs(scope['sr'], sr)
    self.assertEqual([], factory_called)
    result = sr(1, 2)
    self.assertEqual(result, 'testable_scope_replacer')

# Generated at 2022-06-24 02:45:39.874281
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    f = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert f.name == 'name'
    assert f.msg == 'msg'
    assert f.extra == ': extra'



# Generated at 2022-06-24 02:45:48.832473
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__() should compare all instance member variables"""
    # Test class with __eq__
    class TestClassWithEq(IllegalUseOfScopeReplacer):
        pass
    # Test class with no __eq__
    class TestClassWithoutEq(IllegalUseOfScopeReplacer):
        pass
    eq = TestClassWithEq('a', 'b', 'c')
    not_eq = TestClassWithEq('a', 'b', 'c')
    not_eq.extra = 'd'
    assert eq == eq
    assert not eq == not_eq
    assert not eq == IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert not eq == TestClassWithoutEq('a', 'b', 'c')
    # Just for completeness
    assert not_eq == not_eq



# Generated at 2022-06-24 02:46:00.044242
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ for IllegalUseOfScopeReplacer should return str, not unicode.

    Also, it should be possible to encode it to utf8.
    """
    # basic
    e = IllegalUseOfScopeReplacer(name='foo', msg='xyz')
    s = str(e)
    assert isinstance(s, str), \
        "%r must be %r, not %r" % (s, str, type(s))
    s2 = s.encode('utf8')
    assert isinstance(s2, str), \
        "%r must be %r, not %r" % (s2, str, type(s2))
    # unicode message

# Generated at 2022-06-24 02:46:05.534091
# Unit test for function lazy_import
def test_lazy_import():

    # We only test a small subset of the functionality because the
    # ImportProcessor class is unit tested.
    from bzrlib.tests.blackbox import ExternalBase

    class TestLazyImport(ExternalBase):

        def test_simple_import(self):
            import bzrlib
            scope = {}
            lazy_import(scope, '''
            import bzrlib
            ''')
            self.assertTrue(scope['bzrlib'] is not bzrlib)
            self.assertTrue(scope['bzrlib'] is bzrlib)

        def test_multiple_imports(self):
            import bzrlib
            scope = {}
            lazy_import(scope, '''
            import bzrlib, bzrlib.branch as branch
            ''')

# Generated at 2022-06-24 02:46:15.779346
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the method of ImportProcessor that is used to perform the lazy
    import.
    """
    scope = {}
    text = """from bzrlib.commands import Command"""
    ImportProcessor().lazy_import(scope, text)
    module_path, member, children = scope['Command']
    assert module_path == ['bzrlib', 'commands']
    assert member == 'Command'
    assert children == {}
    # This raises a ValueError as bzrlib has not been defined yet.
    # So we know that the command doesn't actually get executed.
    scope['Command']()

    scope = {}
    text = """from bzrlib.commands import Command, quietly"""
    ImportProcessor().lazy_import(scope, text)
    module_path, member, children = scope['Command']
   

# Generated at 2022-06-24 02:46:20.161417
# Unit test for function lazy_import
def test_lazy_import():
    try:
        from bzrlib import foo
    except ImportError:
        pass
    else:
        raise TestNotApplicable('bzrlib.foo already exists')
    try:
        from bzrlib import bar
    except ImportError:
        pass
    else:
        raise TestNotApplicable('bzrlib.bar already exists')
    lazy_import(globals(), '''
    from bzrlib import (
        foo,
        bar,
        )
    ''')
    # The module itself should not be pulled in
    # But if we use it, it should appear
    try:
        import bzrlib
    except ImportError:
        pass
    else:
        raise TestSkipped('bzrlib already exists')
    from bzrlib import foo

# Generated at 2022-06-24 02:46:28.157567
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() must return a str object."""
    from bzrlib.tests import TestCase
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    result = str(e)
    self.assertIsInstance(result, str)
    self.assertNotEqual(result, unicode(e))
    self.assertNotEqual(result, repr(e))
    self.assertNotEqual(result, e._format())


# Generated at 2022-06-24 02:46:30.895390
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class A(object):
        def __init__(self, a):
            self.a = a
    def factory(self, scope, name):
        return A(self)
    scope = {}
    a = ScopeReplacer(scope, factory, 'a')
    assert a.a is a



# Generated at 2022-06-24 02:46:41.399366
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # object.__setattr__ is required to test the constructor because
    #  the constructor sets _module_path = module_path, which will
    #  go through __getattribute__ and loop back to the constructor
    class ImportReplacer(ImportReplacer):
        __slots__ = ['_module_path']
    # Simple test

# Generated at 2022-06-24 02:46:51.119234
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    'Unit test for method __setattr__ of class ScopeReplacer'
    # Needed to make string_io work on python 2.4
    from bzrlib.lazy_import import _disabled_scope_replacer_proxying


# Generated at 2022-06-24 02:46:54.152843
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ returns the formatted message string"""
    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar')
    except IllegalUseOfScopeReplacer as e:
        unicode(e)

# Generated at 2022-06-24 02:47:03.697248
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Use a real scope, and check it gets populated.
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], children={
        'bar':(['foo', 'bar'], None, {})})
    # Now check that foo is an ImportReplacer, and that it is replaced
    # when accessed.
    foo = scope['foo']
    # TODO: Jam 20051216 Need to check that we have a
    # ImportReplacer in scope, but ImportReplacer is private
    # to this module.
    #self.assertIsInstance(foo, ImportReplacer)
    # The following test probably suffices for the above check.
    # See https://bugs.launchpad.net/bzr/+bug/457682
    self.assertEqual('foo', foo._name)
    bar = foo.bar

# Generated at 2022-06-24 02:47:08.407114
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    c = IllegalUseOfScopeReplacer('exceptionname', 'test message')
    str(c)
    unicode(c)
    repr(c)


# Generated at 2022-06-24 02:47:13.308733
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    err = IllegalUseOfScopeReplacer('obj_name', 'msg_text')
    assert err.name == 'obj_name'
    assert err.msg == 'msg_text'
    assert err.extra == ''



# Generated at 2022-06-24 02:47:15.486993
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    foo = {'baz': (['foo', 'baz'], None, {})}
    cls = ImportReplacer(scope={}, name='foo', module_path=['foo'],
                         children=foo)
    assert cls._import_replacer_children == foo



# Generated at 2022-06-24 02:47:22.664825
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ returns NotImplemented if
    the other object isn't an instance of the same class, but if it
    is we return a comparison of the attributes."""
    try:
        IllegalUseOfScopeReplacer('foo', 'bar').__eq__('anything')
    except NotImplementedError:
        pass
    else:
        raise AssertionError('IllegalUseOfScopeReplacer.__eq__ did not'
                             ' raise NotImplementedError')
    first = IllegalUseOfScopeReplacer('foo', 'bar')
    attrs = first.__dict__.copy()
    second = IllegalUseOfScopeReplacer('not_foo', 'bar')
    attrs.update(second.__dict__)

# Generated at 2022-06-24 02:47:32.589310
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ of IllegalUseOfScopeReplacer should produce a str

    There shouldn't be any unusual characters in the repr that might get
    mangled by the repr of its parent class.
    """
    e = IllegalUseOfScopeReplacer(
        "variable_name",
        "message")
    repr(e)



try:
    from threading import local as _tlocal
except ImportError:
    from bzrlib._weaklzr import WeakLZR as _tlocal
    class _tlocal(object):

        __slots__ = ['__dict__', '__weakref__']

        def __init__(self):
            self.__dict__ = {}


# this is necessary to track the module where the 'lazy_import' was called.
_scope_stack = _tlocal()



# Generated at 2022-06-24 02:47:37.715245
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    class ExampleException(IllegalUseOfScopeReplacer):
        _fmt = 'format: %(name)r, %(msg)r, %(extra)r'
    inst = ExampleException('name', 'msg', 'extra')
    unicode(inst)


# Generated at 2022-06-24 02:47:47.454025
# Unit test for function lazy_import
def test_lazy_import():
    class TestImportReplacer(ImportReplacer):
        """A special ImportReplacer that records what is actually imported"""
        def _import(self, scope, name):
            self.imports.append(name)
            return ImportReplacer._import(self, scope, name)
    class TestReplacer(ScopeReplacer):
        """A special ScopeReplacer that records what is actually replaced"""
        def _replace(self, scope, name):
            self.imports.append(name)
            return ScopeReplacer._replace(self, scope, name)
    class TestProcessor(ImportProcessor):
        """A special ImportProcessor that uses special ScopeReplacer"""
        def _lazy_import(self, scope, name):
            return TestReplacer(scope, name, factory=self._factory)

# Generated at 2022-06-24 02:47:59.409992
# Unit test for method __call__ of class ScopeReplacer

# Generated at 2022-06-24 02:48:10.301856
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Initial import replacement with children."""
    import sys
    module_path = ['bzrlib', 'test']
    module_name = module_path[-1]
    module_python_path = '.'.join(module_path)
    children = {'foo':(module_path[:] + ['foo'], None, {}),
                'bar':(module_path[:] + ['bar'], 'bar_attr', {})}
    ImportReplacer(sys.modules, module_name, module_path, children=children)

    # Now try to import bzrlib.test.foo. This should cause the module
    # 'bzrlib.test' to be imported, and children registrations for
    # 'bzrlib.test.foo' and 'bzrlib.test.bar'

# Generated at 2022-06-24 02:48:18.408086
# Unit test for function lazy_import
def test_lazy_import():
    class TestScope(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
        def __getattribute__(self, attr):
            if attr == 'name':
                return object.__getattribute__(self, 'name')
            if attr in self.__dict__:
                return self.__dict__[attr]
            if attr == '_':
                return self.__dict__[attr]
            self._ = TestScope('g.c.d', object.__getattribute__(self, 'value') + 1)
            if attr == 'c':
                return self._
            raise AttributeError('%s' % attr)
    scope = TestScope('a.b', 0)
    scope._ = TestScope('f', 0)
    scope

# Generated at 2022-06-24 02:48:27.058864
# Unit test for function lazy_import
def test_lazy_import():
    # This is a compiled test of the function lazy_import.
    # This is important because lazy_import itself wants to delay
    # loading objects until they are used, so we should be able to verify
    # it works without using the objects it would normally be trying to
    # lazy load.
    from bzrlib.lazy_import import (
        ImportReplacer,
        disallow_proxying,
        )
    disallow_proxying()
    class FakeModule(object):
        # We are not trying to test the module code here,
        # so a fake module will do just fine.
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

# Generated at 2022-06-24 02:48:34.113979
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import traceback
    import StringIO

# Generated at 2022-06-24 02:48:40.887243
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test that we can call a method on a ScopeReplacer

    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    def _factory(self, scope, name):
        return 'Hello'
    global foo
    ScopeReplacer(locals(), _factory, 'foo')
    foo = ScopeReplacer(locals(), _factory, 'foo')
    foo()
    return 0


# Generated at 2022-06-24 02:48:49.292636
# Unit test for function lazy_import
def test_lazy_import():
    module_not_loaded = __name__ + '.module_not_loaded'
    module_loaded = __name__ + '.module_loaded'
    try:
        import module_not_loaded
    except ImportError:
        pass
    else:
        raise TestNotApplicable("module_not_loaded already loaded")
    scope = {}
    lazy_import(scope, '''
    import %s
    from %s import foo
    ''' % (module_not_loaded, module_not_loaded))
    # We haven't loaded the modules yet, so they should be ScopeReplacer
    # objects.
    if module_not_loaded in sys.modules:
        raise TestNotApplicable("module_not_loaded already loaded")
    if module_loaded in sys.modules:
        raise TestNotApplicable("module_loaded already loaded")

# Generated at 2022-06-24 02:48:59.796691
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import unittest
    class TestImportProcessor(unittest.TestCase):

        def test_convert_import_str(self):
            import bzrlib.mapping as mapping
            ip = ImportProcessor()
            ip._convert_import_str("import bzrlib.mapping")
            self.assertEqual(ip.imports, {"bzrlib": ([u"bzrlib"], None, {"mapping": ([u"bzrlib", u"mapping"], None, {})})})

            ip = ImportProcessor()
            ip._convert_import_str("import bzrlib.mapping, bzrlib.transport, bzrlib.trace")
            ip._convert_import_str("import bzrlib.ui")

# Generated at 2022-06-24 02:49:10.624871
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Check the ScopeReplacer constructor works as expected.
    """
    # Make a temporary scope just for this test
    t_scope = {}
    # These should be ok
    name = 'ScopeReplacer'
    factory = lambda self, scope, name: None
    ScopeReplacer(t_scope, factory, name)
    # These should raise exceptions
    for (name, factory) in [
        (None, factory),
        (name, None),
        (None, None),
        ]:
        try:
            ScopeReplacer(t_scope, factory, name)
        except TypeError:
            pass
        else:
            raise AssertionError("%r %r should have raised TypeError" % (name,
                factory))


# Generated at 2022-06-24 02:49:14.852267
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    ex = IllegalUseOfScopeReplacer('a', 'b', 'extra')
    assert str(ex) == ("ScopeReplacer object 'a' was used incorrectly:"
                       " bextra: extra")
    assert repr(ex) == "IllegalUseOfScopeReplacer('a', 'b', 'extra')"


# Generated at 2022-06-24 02:49:22.860394
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    scope = {}
    def factory(*args, **kwargs):
        return lambda x, y: x + y
    CLASS = ScopeReplacer
    # method __call__: instance and class method
    x = CLASS(scope, factory, "x")
    x.__call__(1, 2)
    # method __call__: instance and class method
    x = CLASS(scope, factory, "x")
    x.__call__("1", "2")

# Generated at 2022-06-24 02:49:30.609121
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() includes the class name and its
    attributes."""
    e = IllegalUseOfScopeReplacer(None, 'msg', 'extra')
    s = str(e)
    assert('IllegalUseOfScopeReplacer' in s), \
        'Wrong class name in str(%r)' % (s,)
    for attr in ['name', 'msg', 'extra', '_fmt']:
        quoted = "'%s'" % getattr(e, attr)
        assert(quoted in s), 'Wrong attributes in str(%r)' % s



# Generated at 2022-06-24 02:49:43.457733
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ of IllegalUseOfScopeReplacer"""
    def _test_eq(a, b, c):
        a = IllegalUseOfScopeReplacer(a, b, c)
        b = IllegalUseOfScopeReplacer(a.name, a.msg, a.extra)
        c = IllegalUseOfScopeReplacer('foo', 'bar')
        d = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
        assert a == b
        assert a != c
        assert d != c
        assert a != d
        assert a != None
    _test_eq('x', 'y', 'z')
    _test_eq(u'\u6642', 'y', 'z')
    _test_eq(u'x', '\u6642', 'z')

# Generated at 2022-06-24 02:49:55.060630
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib
    foo = bzrlib.foo
    bzrlib2 = bzrlib.bzrlib2

    scope = {'bzrlib':ImportReplacer(globals(), 'bzrlib', ['bzrlib'])}
    lazy_import(scope, "import bzrlib.foo\nfrom bzrlib import bzrlib2")

    # Smoke test
    import_replacer = scope['bzrlib']
    assert isinstance(import_replacer, ImportReplacer)
    assert import_replacer._resolve() is bzrlib

    foo_replacer = scope['foo']
    assert isinstance(foo_replacer, ScopeReplacer)
    assert foo_replacer._real_obj is None
    # Now call it, and check that it resolves


# Generated at 2022-06-24 02:50:07.701773
# Unit test for function lazy_import
def test_lazy_import():

    # We have to use a real module here instead of a string module
    # because the ImportReplacer class checks to ensure that the
    # module is actually an importable module.
    import sys

    # We used to use {} as a placeholder, but this caused problems because
    # repr(foo) would trigger an import.
    module_placeholder = object()

    # We must make sure that errors.BzrError is in the sys.modules
    # Otherwise, ImportProcessor will refuse to load.
    sys.modules['errors'] = object()
    sys.modules['bzrlib'] = object()
    sys.modules['bzrlib.errors'] = object()
    sys.modules['bzrlib.errors.BzrError'] = object()
    sys.modules['bzrlib.foo'] = object()

# Generated at 2022-06-24 02:50:13.867425
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return an ascii str"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    ex = IllegalUseOfScopeReplacer('foo', 'bar', extra='extra')
    s = str(ex)
    assert isinstance(s, str), \
        "__str__ method must return a str not a %r" % (type(s),)


# Generated at 2022-06-24 02:50:23.571841
# Unit test for function lazy_import
def test_lazy_import():
    def test_import(text, expect):
        """This tests a single import module statement, we check the items
        to ensure that they are all import replacers. Then check that the
        replacer has the right children.
        """
        scope = {}
        lazy_import(scope, text)
        for name, value in scope.iteritems():
            if not isinstance(value, ImportReplacer):
                import pdb
                pdb.set_trace()
            # This is just a way to ensure that we don't accidentally miss
            # tests. If we don't have an expected value, we make sure that
            # the value that we have really isn't expected.
            if name in expect:
                actual = expect[name]
                del expect[name]
            else:
                actual = []
            # Now we walk the import replacer to ensure it has

# Generated at 2022-06-24 02:50:34.513466
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.py_exc = py_exc = sys.modules['bzrlib.pyutils'].py_exc
    py_exc_value = py_exc.ValueError
    py_exc_getattr = py_exc.AttributeError
    class Foo(object):
        def __call__(self, *args, **kwargs):
            assert 0, 'unexpected call %r %r' % (args, kwargs)
    class FooReplacer(bzrlib.lazy_import.ScopeReplacer):
        __slots__ = ('_scope', '_factory', '_name', '_real_obj')
        _should_proxy = False
    f = FooReplacer({}, Foo, 'foo')

# Generated at 2022-06-24 02:50:45.344719
# Unit test for function lazy_import
def test_lazy_import():
    myscope = {}
    lazy_import(myscope, '''
    import foo
    import foo.bar
    import foo.bar.baz
    from foo import bar
    from foo.bar import baz
    ''')
    for k in ['foo', 'foo.bar', 'foo.bar.baz', 'bar', 'baz']:
        obj = myscope[k]
        assert isinstance(obj, ImportReplacer)
        assert obj._resolve() is obj
    for k in ['foo', 'foo.bar', 'foo.bar.baz', 'bar', 'baz']:
        obj = myscope[k]
        assert isinstance(obj, ImportReplacer)
        assert obj._resolve() is not obj



# Generated at 2022-06-24 02:50:47.127492
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    x = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    repr(x)

# Generated at 2022-06-24 02:50:58.623626
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Constructor of IllegalUseOfScopeReplacer is working"""
    exc = IllegalUseOfScopeReplacer("name", "msg")
    assert exc.name == "name"
    assert exc.msg == "msg"
    assert exc.extra == ""
    assert str(exc) == 'name: msg'
    assert repr(exc) == ("<%s at 0x%x>"
                         % (exc.__class__.__name__, id(exc)))

    # extra
    exc = IllegalUseOfScopeReplacer("name2", "msg2", "extra2")
    assert exc.extra == ": extra2"
    assert str(exc) == 'name2: msg2: extra2'

    # preformatted message
    exc = IllegalUseOfScopeReplacer("name3", "msg3")

# Generated at 2022-06-24 02:51:02.186878
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    f = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e == f


# Generated at 2022-06-24 02:51:04.118283
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # Test construction with and without arguments
    p = ImportProcessor()
    p = ImportProcessor(ImportReplacer)



# Generated at 2022-06-24 02:51:12.128319
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests.test_i18n import install_gettext_callables
    install_gettext_callables()
    x = IllegalUseOfScopeReplacer('m', 'msg', 'extra')
    assert x == IllegalUseOfScopeReplacer('m', 'msg', 'extra')
    assert x != IllegalUseOfScopeReplacer('n', 'msg', 'extra')
    assert x != IllegalUseOfScopeReplacer('m', 'nmsg', 'extra')
    assert x != IllegalUseOfScopeReplacer('m', 'msg', 'nextra')



# Generated at 2022-06-24 02:51:24.849300
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # Make sure that no exceptions are raised
    e = IllegalUseOfScopeReplacer(name='some name', msg='some message')
    assert e.name == 'some name'
    assert e.msg == 'some message'
    assert e.extra == ''
    assert str(e) == 'some message'
    assert repr(e) == "IllegalUseOfScopeReplacer('some name', 'some message')"
    e = IllegalUseOfScopeReplacer(name='some name', msg='some message', extra=None)
    assert e.name == 'some name'
    assert e.msg == 'some message'
    assert e.extra == ''
    assert str(e) == 'some message'
    assert repr(e) == "IllegalUseOfScopeReplacer('some name', 'some message')"
    e = IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:51:33.234750
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer: __unicode__ returns a useful string"""
    # Note: This test was added to prevent regression from bug #858279
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('foo', 'msg')
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__str__(), str)
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)



# Generated at 2022-06-24 02:51:44.425418
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys, warnings
    import bzrlib.branch
    import bzrlib.errors
    bzrlib.errors.InternalBzrError = 'test'
    def replace_self(obj, scope, name):
        return obj
    scope = sys.modules[__name__].__dict__
    def repl(scope, attr):
        obj = ScopeReplacer(scope, replace_self, attr)
        return getattr(obj, attr)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        repl_errors = repl(scope, 'errors')
    assert len(w) == 1
    assert w[0].category is IllegalUseOfScopeReplacer
    assert repl_errors is bzrlib.errors

# Generated at 2022-06-24 02:51:54.349931
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""
    test_str = '''
        from bzrlib import (
            foo,
            bar,
            baz,
            )
        import bzrlib.branch
        import bzrlib.bzrdir
        from bzrlib.diff import show_diff_trees
        '''

    scope = {}
    lazy_import(scope, test_str)
    # The scope should contain a bunch of import replacer objects.
    from bzrlib.lazy_import import ImportReplacer
    for name in scope.iterkeys():
        assert isinstance(scope[name], ImportReplacer)



# Generated at 2022-06-24 02:52:03.779332
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return something printable"""
    x = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(unicode(x), unicode) # i.e. not a subclass
    assert x.name == 'foo'
    assert x.msg == 'bar'
    assert x.extra == ''
    assert unicode(x) == u'ScopeReplacer object \'foo\'' \
        ' was used incorrectly: bar'
    x.extra = ' and some extra data'
    assert unicode(x) == u'ScopeReplacer object \'foo\'' \
        ' was used incorrectly: bar and some extra data'
    x.extra = 42
    assert unicode(x) == u'ScopeReplacer object \'foo\'' \
        ' was used incorrectly: bar: 42'


# A scope replacer is a

# Generated at 2022-06-24 02:52:11.430032
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Exception's getattr() doesn't handle unicode."""
    from bzrlib.tests import TestCase
    class TestException(TestCase):
        def test_construction(self):
            """A unicode string can be passed to the exception constructor."""
            class MyTestException(Exception):
                def __init__(self, value):
                    Exception.__init__(self, value)
            e = MyTestException(u"s\u1234")
            self.assertEqual(unicode, type(e))
    TestException('test_construction').run()



# Generated at 2022-06-24 02:52:18.705169
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), '''
    import sys
    ''')
    disallow_proxying()
    sys.modules['foo'] = object()
    lazy_import(globals(), '''
    import foo
    ''')
    try:
        foo.bar
    except IllegalUseOfScopeReplacer as e:
        if str(e) != 'foo: Object already replaced, did you assign it to' \
                ' another variable?':
            raise Exception('Unexpected exception text %r.' % str(e))
    else:
        raise Exception('Expected an exception.')



# Generated at 2022-06-24 02:52:28.563056
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """
    Test of method __call__ of class ScopeReplacer
    """
    # Test with non-lazy object, should raise
    scope = {}
    scope['name'] = object()
    def f(obj, scope, name):
        raise Exception("Should not be called")
    try:
        scope['name'](1, 2, 3)
    except Exception as e:
        assert e.args == ("Should not be called",)
    else:
        raise AssertionError("ScopeReplacer.__call__ did not raise")

    # Test with lazy object, should succeed
    scope = {}
    class O(object):
        def __call__(self, a, b, c):
            return a, b, c
    scope['name'] = ScopeReplacer(scope, lambda obj, scope, name: O(), 'name')
   

# Generated at 2022-06-24 02:52:31.584555
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    bzrlib.osutils.__setattr__('foo', 'bar', 'baz')



# Generated at 2022-06-24 02:52:36.851599
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Str representation of IllegalUseOfScopeReplacer should be non null.

    We don't care what it is because it is just for debugging anyway.
    """
    exc = IllegalUseOfScopeReplacer('a_name', 'a message', 'dummy')
    str(exc)


# Generated at 2022-06-24 02:52:48.285793
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), '''
from bzrlib import lazy_import
''')
    ScopeReplacer._should_proxy = True

# Generated at 2022-06-24 02:52:51.963724
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == 'msg: extra'
    # str(e) returns a str object.
    assert isinstance(str(e), str)


# Generated at 2022-06-24 02:52:55.280801
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer must not raise an exception."""
    exc = IllegalUseOfScopeReplacer('name', 'msg')
    # Should not raise an exception.
    str(exc)


# Generated at 2022-06-24 02:53:06.205032
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # Check that the constructor set the fields correctly
    assert e.name == 'name'
    assert e.msg == 'msg'
    assert e.extra == ': extra'
    # Check that being constructed that way gives the right str()
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly:" \
        " msg: extra"
    # Check that being constructed that way gives the right unicode()
    assert unicode(e) == (u"ScopeReplacer object u'name' was used incorrectly:"
                          u" msg: extra")
    # Check that repr() works
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"



# Generated at 2022-06-24 02:53:15.307542
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ must return True when all __dict__ are equal"""
    def check(one, two, msg):
        """Check for equality"""
        if one != two:
            raise AssertionError("%s != %s\n%s" % (one, two, msg))
    def copy(orig, **kwargs):
        """Copy the IllegalUseOfScopeReplacer and update __dict__"""
        new = IllegalUseOfScopeReplacer(orig.name, orig.msg, orig.extra)
        new.__dict__.update(kwargs)
        return new
    def check_differences(one, two):
        """Check differences"""
        d = dict(one.__dict__)
        d.update(two.__dict__)
        diff = set(one.__dict__) ^ set(two.__dict__)
