

# Generated at 2022-06-24 02:43:10.362874
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import bzrlib.lazy_import
    import doctest
    doctest.run_docstring_examples(bzrlib.lazy_import.ScopeReplacer, globals())



# Generated at 2022-06-24 02:43:19.537736
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy_import function"""

    def check_import(text):
        if not isinstance(text, str):
            text = '\n'.join(text)
        globs = {}
        lazy_import(globs, text)

        for module_name in globs:
            if module_name in ('__builtins__', '__doc__', '__file__',
                               '__name__', '__package__'):
                continue
            module = globs[module_name]
            if isinstance(module, ScopeReplacer):
                # The module didn't get replaced.
                raise AssertionError('Module %r was not replaced'
                    % (module_name,))
        return globs


# Generated at 2022-06-24 02:43:27.643155
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class TestClass(object):
        def __init__(self, value):
            self.value = value
    d = {}
    # Pass a different name to the factory than to the constructor

# Generated at 2022-06-24 02:43:33.285339
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer(
        'name',
        'msg',
        'extra')
    assert e.__repr__() == 'IllegalUseOfScopeReplacer(name: msg: extra)'
    # check that string exceptions don't crash __repr__
    e._fmt = '%s: %s'
    assert e.__repr__() == 'IllegalUseOfScopeReplacer(name: msg: extra)'


# Generated at 2022-06-24 02:43:39.290310
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def _factory(self, scope, name):
        return self
    from bzrlib.tests.blackbox import ExternalBase
    class _BaseTestCase(ExternalBase):
        _test_needs_features = [lambda feature_flags: not feature_flags.
            get('subunit')]
        def test_ScopeReplacer___call__(self):
            scope = {}
            scope['a'] = ScopeReplacer(
                scope,
                _factory,
                'a',
                )
            scope['a'].__call__()

    _BaseTestCase('test_ScopeReplacer___call__').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-24 02:43:51.441907
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Lazily imported modules can be used as proxies.

    If a lazily imported module is used as proxy, accessing members
    through the second name raises an exception.

    If a lazy import is used in a function or method, it should always
    be assigned to a local variable (without 'global' or 'nonlocal').
    """

    code = '''
        from bzrlib.lazy_import import lazy_import
        lazy_import(globals(), '''
    code += '''
        import os')'''
    d = {'__builtins__': __builtins__}
    exec(code, d)
    os = d['os']
    disallow_proxying()

# Generated at 2022-06-24 02:44:01.327006
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    obj1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    obj2 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    obj3 = IllegalUseOfScopeReplacer('name', 'msg')
    obj4 = IllegalUseOfScopeReplacer('name', 'message')
    assert_equals(obj1, obj2)
    assert_not_equals(obj1, obj3)
    assert_not_equals(obj1, obj4)
    assert_not_equals(obj2, obj3)
    assert_not_equals(obj2, obj4)
    assert_not_equals(obj3, obj4)


# Generated at 2022-06-24 02:44:10.093276
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Ensure __getattribute__ calls resolve().

    This test is only run if ScopeReplacer._should_proxy is set to True.
    """
    # 1. Fail to import module
    import imp
    orig_load_module = imp.load_module
    def _broken_load_module(*args, **kwargs):
        raise ImportError("broken")
    imp.load_module = _broken_load_module

# Generated at 2022-06-24 02:44:19.036567
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Testing importer"""
    scope = {}

    # children tests - empty children
    ImportReplacer(scope, 'foo', ['foo'])
    assert scope == {'foo': __import__('foo')}

    # children tests - no children
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], member='bar')
    assert scope == {'foo': __import__('foo').bar}

    # children tests - with children
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'],
                   children={'bar':(['foo', 'bar'], None, {})})
    assert scope == {'foo': __import__('foo')}
    # not loaded yet - scope would be cleared if it was
    assert scope == {'foo': __import__('foo')}

# Generated at 2022-06-24 02:44:24.675575
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.per_lazy_import
    # Test __setattr__ with normal use
    module_lazy_import = lazy_import(globals(), 'bzrlib.tests.per_lazy_import')
    module_lazy_import.test_ScopeReplacer___setattr__(None, None, None)
    # Test __setattr__ with object setting an own member
    # FIXME: write a test for this kind of use
    # Test __setattr__ with object setting another objects member
    module_lazy_import.test_ScopeReplacer___setattr___another_object(None, None, None)



# Generated at 2022-06-24 02:44:26.476211
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    # XXX: test once we can use python 2.7
    return



# Generated at 2022-06-24 02:44:33.538051
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), """
    from bzrlib import lazy_import
    """)
    ScopeReplacer._should_proxy = True
    ScopeReplacer._should_proxy = False
    lazy_import(globals(), """
    import bzrlib
    """)
    try:
        import bzrlib
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("proxy module should not be allowed")


_scope_replacer_class = ScopeReplacer

# TODO: jam 20060717 Rework these to not use eval.



# Generated at 2022-06-24 02:44:42.682032
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """A few tests for ScopeReplacer."""
    def _factory(self, scope, name):
        return 'Hello'
    def _factory2(self, scope, name):
        return self
    scope = {}
    try:
        ScopeReplacer(scope, _factory, 'foo')
        raise AssertionError('ScopeReplacer should raise if obj == self') 
    except IllegalUseOfScopeReplacer:
        pass
    try:
        ScopeReplacer(scope, _factory2, 'bar')
        raise AssertionError('ScopeReplacer should raise if obj == self') 
    except IllegalUseOfScopeReplacer:
        pass
    # No error expected
    ScopeReplacer(scope, _factory2, 'baz')


# Generated at 2022-06-24 02:44:55.668140
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import bzrlib
    from bzrlib import (
        errors,
        osutils,
        _simple_set
        )

    # A simple import
    imports = {}
    ImportReplacer(imports, 'foo', ['foo'])
    __import__('foo', imports, imports)
    __import__('foo', imports, imports, [], level=0)
    try:
        __import__('foo', imports, imports, ['bar'], level=0)
    except ImportError:
        pass
    else:
        raise ValueError('Importing "from foo import bar" while foo '
                         'only contains a module should raise ImportError')
    if 'foo' not in imports:
        raise ValueError('Simple import of foo should have created an'
                         ' entry in imports')

    # From foo import bar, without any child

# Generated at 2022-06-24 02:45:02.584956
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    # Test import no member, no children
    ImportReplacer(scope, 'foo', module_path=['foo'])
    # Check that it imported foo into the scope, with no children

# Generated at 2022-06-24 02:45:08.795000
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from bzrlib._lazy_import import IllegalUseOfScopeReplacer
    for x in [
        "",
        "abc",
        "abc\ndef",
        "a\nb\nc",
        u'\u1234',
        ]:
        try:
            raise IllegalUseOfScopeReplacer('name', x)
        except IllegalUseOfScopeReplacer as e:
            assert eval(repr(e)) == e



# Generated at 2022-06-24 02:45:16.089839
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ converts to unicode before calling _format"""
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = 'should not be called'
        def _format(self, unicode_arg=''):
            return str(type(self)) + ' ' + str(type(unicode_arg))
    s = str(MyException('', ''))
    if s != "<class 'bzrlib.lazy_import.MyException'> <class 'unicode'>":
        raise AssertionError("Wrong output: %r" % s)



# Generated at 2022-06-24 02:45:26.184480
# Unit test for method lazy_import of class ImportProcessor

# Generated at 2022-06-24 02:45:37.290238
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib
    m = bzrlib.memorytree
    scope = {}
    ImportProcessor().lazy_import(scope, 'import bzrlib')
    assert isinstance(scope['bzrlib'], ImportReplacer)
    assert scope['bzrlib']() is bzrlib
    assert scope['bzrlib']._module_path == ['bzrlib']

    scope = {}
    ImportProcessor().lazy_import(scope, 'import bzrlib.memorytree, bzrlib')
    assert scope['memorytree']() is m
    assert scope['memorytree']._module_path == ['bzrlib', 'memorytree']
    assert scope['bzrlib']() is bzrlib

# Generated at 2022-06-24 02:45:39.226865
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # this is a testing harness for __setattr__
    # it doesn't do anything useful
    return not 'implement me'



# Generated at 2022-06-24 02:45:45.363413
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that ScopeReplacer is constructed correctly."""
    scope = {}
    def factory(replacer, scope, name):
        return replacer

    # Create a ScopeReplacer object
    replacer = ScopeReplacer(scope=scope, factory=factory, name='foo')
    assert replacer is scope['foo']
    assert replacer._scope is scope
    assert replacer._factory is factory
    assert replacer._name == 'foo'
    assert replacer._real_obj is None


# Generated at 2022-06-24 02:45:56.410258
# Unit test for function disallow_proxying
def test_disallow_proxying():
    # These are the basic cases where you could use the proxy
    # There might be more cases that do not appear here
    import bzrlib
    assert bzrlib is not None

    lazy_import(locals(), "from bzrlib.reconcile import _mod_reconcile")
    assert _mod_reconcile is not None

    orig_should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-24 02:46:07.480692
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():

    # Test 1: method returned by real object
    class MyClass(object):
        def method(self):
            return 42
    def make_object(replacer, scope, name):
        return MyClass()
    scope = {}
    lazy_replacer = ScopeReplacer(scope, make_object, 'real_object')
    if scope['real_object'] is not lazy_replacer:
        raise AssertionError('scope["real_object"] is not lazy_replacer')
    result = lazy_replacer.method()
    if result != 42:
        raise AssertionError('result != 42: %r' % (result,))
    if scope['real_object'] is lazy_replacer:
        raise AssertionError('scope["real_object"] is still lazy_replacer')

    # Test 2: method replaced by real object


# Generated at 2022-06-24 02:46:17.479746
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    class MockScope(dict):
        def __init__(self, **kwargs):
            super(MockScope, self).__init__(**kwargs)
        def __getitem__(self, item):
            return self.__dict__[item]
        def __setitem__(self, item, value):
            self.__dict__[item] = value
    class MockObj(object):
        def __init__(self, **kwargs):
            super(MockObj, self).__init__()
            self.__dict__.update(kwargs)
        def __repr__(self):
            keys = list(self.__dict__.keys())
            keys.sort()

# Generated at 2022-06-24 02:46:29.828012
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    class Foo(object):
        def __init__(self):
            self.foo = 'foo'
    from bzrlib.lazy_import import ScopeReplacer, disallow_proxying
    disallow_proxying()

# Generated at 2022-06-24 02:46:37.561234
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of ImportReplacer.

    It is tested here because it is hard to test from another scope.
    """
    scope = {}
    
    ImportReplacer(scope, name='foo', module_path='foo', member=None,
                   children={})

    ImportReplacer(scope, name='foo', module_path='foo', member=None,
                   children={'bar':(['foo', 'bar'], None, {})})

    ImportReplacer(scope, name='bar', module_path='foo', member='bar',
                   children={})



# Generated at 2022-06-24 02:46:41.906946
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Ensure that ImportReplacer constructor works as expected"""
    scope = {}
    name = 'foo'
    module_path = ['foo']
    member = None
    children = {}
    foo = ImportReplacer(scope, name, module_path, member, children)
    assert foo._import_replacer_children == children
    assert foo._member is member
    assert foo._module_path == module_path
    assert foo._scope is scope
    assert foo._name == name
    assert foo._real_obj is None
    assert scope == {name:foo}



# Generated at 2022-06-24 02:46:47.189002
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib
    _save_modules = bzrlib.__dict__.copy()
    # start testing
    ip = util.ImportProcessor()
    scope = globals()
    import_str = 'import bzrlib as wibble'
    ip.lazy_import(scope, import_str)
    import bzrlib
    assert isinstance(wibble, util.ScopeReplacer)
    assert isinstance(bzrlib, util.ScopeReplacer)
    assert wibble is bzrlib._real_obj
    # end testing
    bzrlib.__dict__.clear()
    bzrlib.__dict__.update(_save_modules)
    del _save_modules



# Generated at 2022-06-24 02:46:52.158307
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    scope = {}
    imp = ImportProcessor()
    imp.lazy_import(scope, imp_str)
    verify_lazy_imports(scope, imp)
    return 0


# Generated at 2022-06-24 02:46:55.168418
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Testing constructor of ImportProcessor()"""
    p = ImportProcessor()
    # Constructor has no parameters
    p = ImportProcessor(None)


# Generated at 2022-06-24 02:47:02.327948
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__
    # __call__ of ScopeReplacer should work the same as __call__ of the
    # replaced object.
    #
    # This test is included in __main__ to make sure it is not executed
    # when this module is imported.
    class TestClass(object):
        def __init__(self, expected_arg):
            self._expected_arg = expected_arg

        def __call__(self, arg):
            assert arg == self._expected_arg
            return arg

    scope = {}
    replacer = ScopeReplacer(scope, TestClass, 'TestClass')
    assert scope['TestClass'] is replacer
    replacer('arg')
    assert scope['TestClass'] is replacer._real_obj
    assert replacer._real_obj.__class__ is TestClass



# Generated at 2022-06-24 02:47:13.711853
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    __tracebackhide__ = True    # No traceback please

    src = '''
    from bzrlib.lazy_import import lazy_import

    lazy_import(globals(), '''+"'''"+'''
    from bzrlib import errors, osutils, branch, transport, commands, osutils
    import bzrlib
    '''+"'''"+''')
    '''
    # need to make a new module to test in, because
    # globals() is different in each module, so we can't
    # test in this module.
    import imp
    test_module = imp.new_module('test_module')

# Generated at 2022-06-24 02:47:19.368361
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__ of class ScopeReplacer
    # __setattr__(self, attr, value) -> None : assign a new attribute
    pass


# Generated at 2022-06-24 02:47:31.538894
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    import __builtin__
    obj1 = ScopeReplacer(
        {'a':1},
        __builtin__.__import__,
        'bzrlib',
        )
    obj1.__setattr__('a', 2)
    obj1.__setattr__('a', 1)
    obj1.__setattr__('a', 2)
    obj1.__setattr__('a', 1)
    obj1.__setattr__('a', 2)
    obj1.__setattr__('a', 1)
    obj1.__setattr__('a', 2)
    obj1.__setattr__('a', 1)
    obj1.__setattr__('a', 2)

# Generated at 2022-06-24 02:47:42.724148
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # no imports
    ip = ImportProcessor()
    ip.lazy_import(globals(), ' ')
    assert len(ip.imports) == 0

    # module import
    ip = ImportProcessor()
    ip.lazy_import(globals(), 'import bzrlib')
    assert len(ip.imports) == 1
    assert 'bzrlib' in ip.imports

    # a couple module imports
    ip = ImportProcessor()
    ip.lazy_import(globals(), 'import bzrlib\nimport os')
    assert len(ip.imports) == 2
    assert 'bzrlib' in ip.imports
    assert 'os' in ip.imports

    # a couple module imports, then a sub module import
    ip = ImportProcessor()
    ip

# Generated at 2022-06-24 02:47:48.558942
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class TestClass(object):
        pass
    name = 'name'
    factory = lambda self, scope, name: TestClass()
    scope = {name: None}
    replacer = ScopeReplacer(scope, factory, name)
    obj = replacer._resolve()
    assert isinstance(obj, TestClass)
    proxy = replacer.__getattribute__('_resolve')  # call the method
    obj = proxy()
    assert isinstance(obj, TestClass)



# Generated at 2022-06-24 02:48:00.091345
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # Call __str__ on an IllegalUseOfScopeReplacer.
    e = IllegalUseOfScopeReplacer('bar', 'foo', extra=('x', 'y'))
    s = str(e)
    # The string representation should contain the repr of the attributes.
    test_IllegalUseOfScopeReplacer___str__.check(s)
    # __preformatted_string__ can be set to a string to be returned
    # without formatting.
    # This is primarily used to allow the output of py.test to contain
    # the original error message without requiring gettext.
    e._preformatted_string = 'Unformatted IllegalUseOfScopeReplacer: ' \
        'name=bar, msg=foo, extra=x,y'
    s = str(e)
   

# Generated at 2022-06-24 02:48:11.429682
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for constructor of class ScopeReplacer"""
    import sys

    def factory(ignored_self, ignored_scope, ignored_name):
        raise AssertionError('factory should not be called')


# Generated at 2022-06-24 02:48:19.645144
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    scope = {}
    processor = ImportProcessor()
    processor.lazy_import(scope, "import foo")
    processor.lazy_import(scope, "import foo, bar")
    processor.lazy_import(scope, "import foo.bar")
    processor.lazy_import(scope, "import foo.bar.baz as bing")
    processor.lazy_import(scope, "import foo.bar as bing")
    processor.lazy_import(scope, "import foo as bing")
    processor.lazy_import(scope, "from foo import bar")
    processor.lazy_import(scope, "from foo import bar, baz")
    # Importing a name of an already existing class will raise an error
    raised = False

# Generated at 2022-06-24 02:48:25.268123
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() returns valid repr string.
    
    Test if __repr__() returns a string representation of the object which can
    be interpreted by eval().
    """
    try:
        eval(repr(IllegalUseOfScopeReplacer()))
    except SyntaxError:
        raise AssertionError('IllegalUseOfScopeReplacer.__repr__() does not '
                             'return a valid repr string')

# Generated at 2022-06-24 02:48:31.309612
# Unit test for function lazy_import
def test_lazy_import():
    """This tests that lazy_import works"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import disallow_proxying
    orig_bzrlib = bzrlib

    class TestLazyImport(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            # Make sure unit tests don't create proxy objects, because
            # then we can't just ask 'isinstance to see if something
            # was imported by lazy_import
            disallow_proxying()
            # Reset bzrlib to the real one
            bzrlib.bzrlib = orig_bzrlib
            self.real_scope = {'bzrlib': bzrlib}
            # A scope where we can put lazily imported objects
            self.m

# Generated at 2022-06-24 02:48:38.388096
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import doctest
    from bzrlib.lazy_import import ScopeReplacer
    globs = globals()
    globs.update(locals())
    doctest.run_docstring_examples(ScopeReplacer.__getattribute__, globs,
                                   optionflags=doctest.ELLIPSIS,
                                   name='ScopeReplacer.__getattribute__')



# Generated at 2022-06-24 02:48:45.226562
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test that IllegalUseOfScopeReplacer instances compare equal if their
    attributes are equal.
    """
    class Foo(IllegalUseOfScopeReplacer):
        # Subclass to avoid the extra tests in assertRaises.
        def __init__(self, name, msg, extra=None):
            super(Foo, self).__init__(name, msg, extra)

    def _get_exception(name, msg, extra=None):
        return Foo(name, msg, extra)


# Generated at 2022-06-24 02:48:52.521829
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import random
    import bzrlib
    random.seed(bzrlib)
    class TestableScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            ScopeReplacer.__init__(self, scope, factory, name)
        def _resolve(self):
            return self._factory(self, self._scope, self._name)
        def __call__(self, *args, **kwargs):
            return ScopeReplacer.__call__(*args, **kwargs)
    sr = TestableScopeReplacer(
        {},
        lambda self, scope, name: scope,
        'dummy')
    x = random.random()
    sr(x)


# Function to create a new scope replacer

# Generated at 2022-06-24 02:48:57.475476
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    c = IllegalUseOfScopeReplacer('wibble', 'wobble', extra='extra')
    d = IllegalUseOfScopeReplacer('wibble', 'wobble', extra='extra')
    e = IllegalUseOfScopeReplacer('wibble', 'flobble')
    f = IllegalUseOfScopeReplacer('wobble', 'wobble')
    assert c == d
    assert c != e
    assert c != f
    assert c != 'wibble'



# Generated at 2022-06-24 02:49:09.348306
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Tests for the ImportProcessor class"""
    from bzrlib.tests import TestCase

    # TODO: RBC 20060420 This test is lame, do much better
    class DummyReplacer(object):
        """A class that records calls to its constructor."""

        def __init__(self, scope, name, module_path, member, children):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children
            self.other_calls = []

        def foo(self):
            """A function that records calls to itself."""
            self.other_calls.append('foo')

    class TestImportProcessor(TestCase):

        def setUp(self):
            super(TestImportProcessor, self).setUp

# Generated at 2022-06-24 02:49:14.806955
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), """
    import bzrlib.dummy""")
    bzrlib.dummy.dummy_fn()
    disallow_proxying()

# Generated at 2022-06-24 02:49:25.682655
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Method __setattr__ of class ScopeReplacer"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    def replace_with(self, scope, name):
        return replacement
    lazy_import(locals(), '''
    replacement = object()
    ''')
    class A(object):
        pass
    a = A()
    try:
        a.foo = ScopeReplacer(locals(), replace_with, 'a')
        self.fail("IllegalUseOfScopeReplacer not raised")
    except IllegalUseOfScopeReplacer as e:
        self.assertEndsWith(str(e), "tried to assign to an already"
                                    " replaced object.")


# Generated at 2022-06-24 02:49:36.582437
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ImportReplacer
    class MyDummyObject(object):
        pass
    mydummyobject = MyDummyObject()
    class SomeModule(object):
        pass
    some_other_module = SomeModule()

    global_map = {
        '__name__':__name__,
        '__builtins__':__builtins__,
        'MyDummyObject':MyDummyObject,
        'some_other_module':some_other_module,
        }

    lazy_import(scope=global_map, text='''
    from bzrlib.lazy_import import (
        MyDummyObject,
        some_other_module,
        )
    ''')

    # We should now

# Generated at 2022-06-24 02:49:42.487669
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class TestableScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            pass
    testable_instance = TestableScopeReplacer(None, None, None)
    # call the method to test
    testable_instance.__call__()



# Generated at 2022-06-24 02:49:44.859468
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    obj = ScopeReplacer({}, lambda s, scope, name: s, 'name')
    obj.__getattribute__('')



# Generated at 2022-06-24 02:49:55.175418
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class ScopeReplacerTester(ScopeReplacer):
        def _resolve(self):
            super(ScopeReplacerTester, self)._resolve()
            object.__setattr__(self, '_real_obj', 'replaced')
            return object.__getattribute__(self, '_real_obj')

    scope = {}
    def factory(self, scope, name):
        return self

    # First test with scope replacer, we expect it to get replaced
    ScopeReplacerTester(scope, factory, "replacer")
    try:
        assert scope["replacer"] == "replaced", (
            "ScopeReplacer not replaced correctly.")
    except KeyError:
        raise AssertionError("ScopeReplacer did not replace itself.")
    # Second test without scope replacer

# Generated at 2022-06-24 02:50:07.790713
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests.per_class import TestCaseWithMemoizedGlobals

    class FakeModule(object):
        def foo(self):
            return 'foo'

    class GetattributeFromFactory(TestCaseWithMemoizedGlobals):
        # __getattribute__ causes the object to be replaced in scope.
        # This means the object is recreated on each access, so we need
        # a factory that will create different objects each time.
        # The factory will set attributes on the object so we can
        # check it when they should and shouldn't be set.
        def factory(self, replacer, scope, name):
            if name not in scope:
                scope[name] = FakeModule()
            scope[name].accessed = True
            return scope[name]


# Generated at 2022-06-24 02:50:13.542313
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    err = IllegalUseOfScopeReplacer('foo', 'bar')
    expected = ('ScopeReplacer object %r was used incorrectly: %s'
                % ('foo', 'bar'))
    assert str(err) == expected
    assert unicode(err) == unicode(expected)
    assert repr(err) == "IllegalUseOfScopeReplacer('foo', 'bar')"



# Generated at 2022-06-24 02:50:23.347583
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # Create an empty ImportProcessor object
    import_processor = ImportProcessor()
    # Create an empty scope for passing to the object
    scope = {}
    text = """import os, sys
from os import path, path
import bzrlib.lockdir as lockdir
from bzrlib import (
    errors,
    osutils,
    workingtree
)
import bzrlib.tests.blackbox as blackbox
import bzrlib.tests.per_workingtree
import bzrlib.tests.test_diff as test_diff
"""
    import_processor.lazy_import(scope, text)
    assert set(scope.keys()) == set(["os", "sys", 'bzrlib', 'lockdir', 'path'])
    assert isinstance(scope['bzrlib'], ImportReplacer)
   

# Generated at 2022-06-24 02:50:34.344994
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test ImportProcessor.lazy_import"""
    class MockScope:
        def __setitem__(self, key, value):
            self.key_value_pair = (key, value)
    scope = MockScope()
    import_proc = ImportProcessor()
    import_proc.lazy_import(scope, 'import foo')
    # The import is lazily computed so we don't expect to find it there
    # yet.
    assert not hasattr(scope, 'foo')
    # But the lazy import should be registered.
    getattr(scope.key_value_pair[1], '_resolve')()
    assert hasattr(scope, 'foo')

    # We can also construct ImportProcessor to use a different lazy import
    # class.

# Generated at 2022-06-24 02:50:44.409687
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import sys
    exc = IllegalUseOfScopeReplacer('foo', 'bar')
    repr(exc)
    if sys.version_info[0] < 3:
        unicode(exc)
        str(exc)
    else:
        str(exc)
        bytes(exc)
    assert(exc == IllegalUseOfScopeReplacer('foo', 'bar'))
    assert(exc != IllegalUseOfScopeReplacer('foo', 'bar', 'extra'))
    assert(exc != IllegalUseOfScopeReplacer('foo2', 'bar'))
    assert(exc != IllegalUseOfScopeReplacer('foo', 'bar2'))



# Generated at 2022-06-24 02:50:55.775799
# Unit test for function lazy_import
def test_lazy_import():
    def do_test_lazy_import(text, expected):
        # Test that the import string works
        scope = {}
        lazy_import(scope, text)
        for name, module_path in expected:
            replacer = scope[name]
            # Don't allow objects to be replaced with proxies, so
            # we can test that they have been replaced
            disallow_proxying()
            module = replacer._resolve()
            assert_equal(module_path, module.__name__.split('.'))


# Generated at 2022-06-24 02:51:05.229546
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Method __eq__ of class IllegalUseOfScopeReplacer works as expected."""
    import os.path
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import scope_replacer
    from bzrlib.lazy_import import scope_replicated

    class dummy_sr(scope_replacer):
        """Dummy scope replacer."""

    class dummy_sr_eq(scope_replacer):

        def __eq__(self, other):
            return True


    class dummy_sr_ne(scope_replacer):

        def __eq__(self, other):
            return False


# Generated at 2022-06-24 02:51:09.118229
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ must make the object available in the given scope.
    """
    scope = {}
    name = 'foo'
    foo = ScopeReplacer(scope, lambda self, scope, name: 'bar', name)
    return foo



# Generated at 2022-06-24 02:51:21.839125
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    import bzrlib.lazy_import as lazy_import
    sys.modules.pop("foo", None)
    lazy_import.disallow_proxying()

# Generated at 2022-06-24 02:51:24.893634
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer"""
    obj = IllegalUseOfScopeReplacer('name', 'msg')
    assert repr(obj) == 'IllegalUseOfScopeReplacer(msg)'

# Generated at 2022-06-24 02:51:34.508733
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    lazy_import(globals(), """
from bzrlib import lazy_import
from bzrlib.tests import (
    TestCase,
    )
""")
    try:
        lazy_import(globals(), """
from bzrlib import (
    errors,
    osutils,
    branch,
    )
import bzrlib.branch
""")
        disallow_proxying()
        # we should now be able to do this:
        sys.stdout = osutils
        # and this should fail:
        sys.stdout = bzrlib
    finally:
        ScopeReplacer._should_proxy = True



# Generated at 2022-06-24 02:51:44.876461
# Unit test for function lazy_import
def test_lazy_import():
    # Setup
    scope = {}
    # First do some bad things, to make sure we get errors
    text = ''

# Generated at 2022-06-24 02:51:56.085731
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Ensure that method lazy_import of class ImportProcessor works as expected

    Description of test:

    This test is making sure that the lines are being processed ok.
    The _canonicalize_import_text function is being tested as a side effect,
    as well as the _convert_from_str and _convert_import_str.
    """
    import os.path
    import shutil
    import StringIO


# Generated at 2022-06-24 02:52:02.730773
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    bzrlib = ImportReplacer(sys.modules, name='bzrlib',
                            module_path=['bzrlib'],
                            children={'foo': (['bzrlib', 'foo'], None,
                                              {'bar': (['bzrlib', 'foo',
                                                        'bar'], None, {})})})
    import bzrlib
    import bzrlib.foo
    import bzrlib.foo.bar



# Generated at 2022-06-24 02:52:13.338866
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Bar(object):
        pass
    class Foo(Bar):
        def __init__(self, x, y):
            self.x = x
            self.y = y
    class Baz(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
    class Qux(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __call__(self, *args):
            return self.x + self.y + sum(args)
    class Norf(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

# Generated at 2022-06-24 02:52:22.389232
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """This should import a module, and prepare its children for importing."""
    import bzrlib
    global_scope = globals()
    ImportReplacer(scope=global_scope, name='bzrlib', module_path=['bzrlib'],
        member=None, children={'errors':(['bzrlib', 'errors'], None, {})})
    # Should be an ImportReplacer object.
    self.assertIsInstance(global_scope['bzrlib'], ImportReplacer)
    # Now, access it
    global_scope['bzrlib'].NotBranchError
    # Should be replaced with a new object
    self.assertIs(global_scope['bzrlib'].NotBranchError, global_scope['bzrlib'].NotBranchError)

    # Test that accessing the

# Generated at 2022-06-24 02:52:30.002762
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == "Unprintable exception IllegalUseOfScopeReplacer: "  \
           "dict={'msg': 'msg', 'name': 'name', 'extra': ''}, " \
           "fmt='ScopeReplacer object %(name)r was used incorrectly:" \
           " %(msg)s%(extra)s', error=None"

# Generated at 2022-06-24 02:52:40.927877
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """It is an error to use a scope replacer object before it has been
    replaced.
    """
    from bzrlib.lazy_import import lazy_import
    global_map = {}
    lazy_import(global_map, '''
    import bzrlib.tests
    ''')

# Generated at 2022-06-24 02:52:45.264096
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), 'test.test_test_test:Test')
    disallow_proxying()
    Test() # this is ok, it uses the real object in the scope
    T = Test
    Test() # this will fail, 'Test' is a proxy and should not be used as such



# Generated at 2022-06-24 02:52:47.349687
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests.test_lazy_import import TestDisallowProxying
    TestDisallowProxying.test_disallow_proxying()



# Generated at 2022-06-24 02:52:58.245017
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ returns str representation."""
    from bzrlib.tests import TestCase
    t = TestCase()
    s = "Hello %(name)s, %(greeting)s"
    err = IllegalUseOfScopeReplacer('World', 'Can you hear me?',
                                    extra='please answer')
    # See http://mail.python.org/pipermail/python-list/2008-February/485055.html
    # for why we use %(value)s instead of %s in the expected output
    t.assertEqual(
        "IllegalUseOfScopeReplacer(Hello World, Can you hear me?:"
        " please answer)",
        repr(err))

# Generated at 2022-06-24 02:53:04.392670
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib.lazy_import
    a = bzrlib.lazy_import.lazy_import(locals(), '''
import bzrlib.tests.test_lazy_import
    ''')
    test_disallow_proxying.__doc__ = a.test_disallow_proxying.__doc__



# Generated at 2022-06-24 02:53:06.416671
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Method __setattr__ of class ScopeReplacer."""
    pass # TODO



# Generated at 2022-06-24 02:53:14.912449
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should look up object in scope"""
    # TODO This test is not really a good test at all as it doesn't
    # actually test that any ScopeReplacer is created.  rbc 20070822
    global __scope_replacer_called
    class Foo(object):
        __scope_replacer_called = False
    def fake_factory():
        global __scope_replacer_called
        __scope_replacer_called = True
        return Foo()
    # if there was a ScopeReplacer in the scope it would be called by the
    # following line
    Foo().foo = 1
    if not __scope_replacer_called:
        raise AssertionError("the ScopeReplacer wasn't called, the scope was")

