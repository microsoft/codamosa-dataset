

# Generated at 2022-06-24 02:43:15.095821
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from bzrlib.tests import TestCase
    e = IllegalUseOfScopeReplacer('foo', 'foo was used incorrectly')
    assert str(e) == 'foo was used incorrectly'
    assert repr(e) == 'IllegalUseOfScopeReplacer(foo was used incorrectly)'
    e.extra = 'foo was used correctly'
    assert repr(e) == 'IllegalUseOfScopeReplacer(foo was used incorrectly' \
        ': foo was used correctly)'



# Generated at 2022-06-24 02:43:24.699909
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    class _Foo(object):
        def __setattr__(self, attr, value):
            setattr(self, attr, value)
    class Case(TestCase):
        def test_should_proxy(self):
            foo = _Foo()
            foo.bar = 10
            self.assertEquals(foo.bar, 10)
            scope = {}
            scope['foo'] = ScopeReplacer(scope, lambda x,y,z:foo, 'foo')
            scope['foo'].bar = 'a'
            # XXX: Lots of things wrong with this test
            # 1) foo.bar is not even defined at this point, so it is not
            #    possible to call __setattr__
            self.assertEquals(foo.bar, 'a')

# Generated at 2022-06-24 02:43:32.006196
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    from bzrlib.lazy_import import ScopeReplacer
    globs = globals()
    globs.clear()

    # The first test increases the coverage by testing the code when
    # 'ScopeReplacer._real_obj' is set to something different than None
    # The second test is more interesting because it will create the
    # '_real_obj' instance and will need to replace the 'ScopeReplacer'
    # instance with it in the global space.
    doctest.run_docstring_examples(ScopeReplacer.__call__, globs, name="ScopeReplacer.__call__", verbose=True)
    doctest.run_docstring_examples(ScopeReplacer.__call__, globs, name="ScopeReplacer.__call__", verbose=True)
    doctest.run_

# Generated at 2022-06-24 02:43:39.401315
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    lazy_import = ScopeReplacer
    disallow_proxying()
    class Foo(object):
        pass
    foo = Foo()
    foo.bar = lambda: "baz"
    foo.spam = Foo()
    foo.spam.eggs = "ham"
    scope = {}
    lazy_import(scope, lambda: foo, "foo")
    foo_proxy = scope["foo"]
    self.assertEqual(foo_proxy.bar(), "baz")
    self.assertRaises(IllegalUseOfScopeReplacer, getattr, foo_proxy, "bar")
    self.assertEqual(foo_proxy.spam.eggs, "ham")

# Generated at 2022-06-24 02:43:51.632151
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # 1. Test with all fields filled out
    repl = ImportReplacer({}, 'foo', ['foo'], None, {'bar':(['foo', 'bar'], None, {})})
    def get_value(obj, field):
        return object.__getattribute__(obj, field)
    assert get_value(repl, '_import_replacer_children') == {'bar':(['foo', 'bar'], None, {})}
    assert get_value(repl, '_member') is None
    assert get_value(repl, '_module_path') == ['foo']
    assert get_value(repl, '_scope') == {}
    assert get_value(repl, '_name') == 'foo'

    # 2. Test with all fields filled out, accessing children, directly

# Generated at 2022-06-24 02:44:01.498998
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from types import NoneType
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class test_ScopeReplacer___call__(TestCase):

        def test_user_defined(self):
            from types import FunctionType
            from bzrlib.tests import TestCase
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def bar(self, msg): return msg
            scope = {}
            _factory = lambda self, scope, name: Foo()
            _name = 'obj'
            ScopeReplacer_instance = ScopeReplacer(scope, _factory, _name)
            self.assertIsInstance(ScopeReplacer_instance, ScopeReplacer)
            self.assertIsInstance(ScopeReplacer_instance, Foo)
            #

# Generated at 2022-06-24 02:44:04.844252
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    x = IllegalUseOfScopeReplacer('x', '1')
    y = unicode(x)
    # Test that y is the correct type
    import bzrlib.tests
    bzrlib.tests.check_type(unicode, y)
    # Opaque test that y is correct.
    assert y.endswith('1')



# Generated at 2022-06-24 02:44:08.566190
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """The import parser constructor should not blow up"""
    import_processor = ImportProcessor()


# Generated at 2022-06-24 02:44:18.030672
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    global module
    module = ImportReplacer(globals(),
                            name='module',
                            module_path=['bzrlib'],
                            member=None,
                            children={'foo':(['bzrlib', 'foo'], None,
                                             {'bar':(['bzrlib', 'foo', 'bar'],
                                                     None, {})})
                                      })


# We use a try/except here, because I'm not sure that this is always
# possible. It might fail if bzrlib isn't in the path.
try:
    from bzrlib import _mod_instrument
    _mod_instrument.instrument(ImportReplacer)
    _mod_instrument.instrument(ScopeReplacer)
except ImportError:
    pass



# Generated at 2022-06-24 02:44:23.976511
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying works"""
    # We use a function with separate scope to test this;
    # otherwise it would not be possible to call it twice
    globals = {}
    def doit():
        globals = {}
        lazy_import(globals, '''
        import osutils
        ''')
        disallow_proxying()
    doit()
    import osutils
    osutils.path_startswith('/', '/')
    doit()
    # If the test fails, it will raise an IllegalUseOfScopeReplacer
    # exception as a side effect.
    osutils.path_startswith('/', '/')



# Generated at 2022-06-24 02:44:29.977015
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def factory(self, scope, name):
        assert not self._real_obj
        return (self, scope, name)
    scope = {}
    replacer = ScopeReplacer(scope, factory, "name")
    assert replacer() == (replacer, scope, "name")
    assert replacer._real_obj == (replacer, scope, "name")
    assert scope["name"] == (replacer, scope, "name")



# Generated at 2022-06-24 02:44:39.708859
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class FakeModule(object):
        """Fake module object for the purpose of testing ImportReplacer"""
        __slots__ = ('__dict__', '__name__', '__path__', '__package__',
            '__spec__', '__loader__', '__doc__', '__all__', '__file__',
            '__cached__', '__class__', '__getattribute__', '__setattr__',
            '__delattr__', '__init__', '__new__')

    class FakePackage(object):
        """Fake package object for the purpose of testing ImportReplacer"""

# Generated at 2022-06-24 02:44:41.444007
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """"""
    # we do not test this method since it asserts in the method _resolve()
    pass # nothing to test

# Generated at 2022-06-24 02:44:42.944908
# Unit test for function lazy_import
def test_lazy_import():
    _test_lazy_import(ImportReplacer)



# Generated at 2022-06-24 02:44:52.258373
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib.osutils import basename
    msg = "The %(name)s module is not yet imported"
    exception_object = IllegalUseOfScopeReplacer(basename(__file__), msg)
    assert exception_object.name == 'lazy_import.py'
    assert exception_object.msg == msg
    assert exception_object.extra == ''
    assert str(exception_object) == "The " \
        "lazy_import.py module is not yet imported"
    exception_object = IllegalUseOfScopeReplacer(basename(__file__), msg,
                                                 extra="It's broken")
    assert exception_object.name == 'lazy_import.py'
    assert exception_object.msg == msg
    assert exception_object.extra == ": It's broken"

# Generated at 2022-06-24 02:45:02.832926
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests.test_config import TestingConfig

    lazy_import(globals(), """
    from bzrlib.lazy_import import disallow_proxying
    """)

    class TestDisallowProxying(TestCase):

        def test_disallow_proxying(self):
            self.assertRaises(IllegalUseOfScopeReplacer,
                              disallow_proxying)

    other_locals = {}
    lazy_import(other_locals, """
    from bzrlib.lazy_import import ScopeReplacer
    """)
    ScopeReplacer._should_proxy = True


# Generated at 2022-06-24 02:45:10.002454
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the Constructor of class ImportProcessor, which creates
    an internal map.
    """
    from breezy.tests import TestCase
    t = TestCase()

    ip = ImportProcessor()
    ip._build_map("""
    import foo
    import foo.bar
    import foo.bar.baz as bing
    """)
    t.assertEqual(len(ip.imports), 2)
    t.assertEqual(ip.imports['foo'][0], ['foo'])
    t.assertEqual(ip.imports['foo'][1], None)
    t.assertEqual(ip.imports['foo'][2], {'bar': (['foo', 'bar'], None, {})})

# Generated at 2022-06-24 02:45:14.826805
# Unit test for function disallow_proxying
def test_disallow_proxying():
    ScopeReplacer._should_proxy = True
    # If it were True, we would get an IllegalUseOfScopeReplacer
    disallow_proxying()
    ScopeReplacer._should_proxy = True
    # And if we had changed it, we would get an IllegalUseOfScopeReplacer
    disallow_proxying()



# Generated at 2022-06-24 02:45:17.619300
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ should be the same as str(self)"""
    # bug #84307: IllegalUseOfScopeReplacer.__repr__ was different from str(self)
    e = IllegalUseOfScopeReplacer("a", "b")
    assert repr(e) == str(e)



# Generated at 2022-06-24 02:45:24.741631
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    ex1 = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    ex2 = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    ex3 = IllegalUseOfScopeReplacer('name', 'msg', extra='other')
    ex4 = IllegalUseOfScopeReplacer('name', 'msg2', extra='extra')
    ex5 = IllegalUseOfScopeReplacer('name2', 'msg', extra='extra')
    assert ex1 == ex2
    assert not ex1 == ex3
    assert not ex1 == ex4
    assert not ex1 == ex5
    assert not ex1 == 3


# Generated at 2022-06-24 02:45:34.176159
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__

    Assert a single attribute -- msg -- is tested for equality
    """
    class Concrete(IllegalUseOfScopeReplacer):
        _fmt = "a %(msg)s b"
    ex1 = Concrete("name1", "msg1")
    ex2 = Concrete("name2", "msg1")
    ex3 = Concrete("name1", "msg2")
    ex4 = Concrete("name2", "msg2")
    assert ex1 == ex2
    assert ex1 != ex3
    assert ex1 != ex4
    assert ex3 != ex4



# Generated at 2022-06-24 02:45:37.124389
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__() -> (args, kwargs)
    # --
    # unit tested by test_import_lazy
    pass

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-24 02:45:42.205932
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    class DummyObj(object):
        ...
    class DummyScope(object):
        ...
    aScope = DummyScope()
    aScope.name = None
    aScopeReplacer = ScopeReplacer(aScope, ..., ...)
    aScopeReplacer._resolve = lambda: DummyObj()
    aScopeReplacer.__call__(...)

# Generated at 2022-06-24 02:45:48.942002
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert str(e) == 'foo'


# Generated at 2022-06-24 02:46:00.229231
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    global bzrlib
    # remove global references to bzrlib
    del bzrlib
    # ensure that bzrlib is not imported
    import imp
    if 'bzrlib' in sys.modules:
        del sys.modules['bzrlib']
    # set ImportProcessor to only build ImportReplacer objects
    processor = ImportProcessor(lazy_import_class=ImportReplacer)
    # import everything from bzrlib
    processor.lazy_import(globals(), 'from bzrlib import *')
    # ensure that bzrlib is still not imported
    if 'bzrlib' in sys.modules:
        del sys.modules['bzrlib']
    # continue with test
    importer = object.__getattribute__(bzrlib, '_import')
   

# Generated at 2022-06-24 02:46:05.687980
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    import sys
    import bzrlib
    lazy_import = bzrlib.lazy_import.lazy_import
    class TestLazyImport(TestCase):
        def test_calls_disallow_proxying(self):
            class b:
                pass
            # Lazy import bzrlib.tests.TestCase
            lazy_import(b.__dict__, '''
            from bzrlib.tests import TestCase
            ''')
            # Check that the lazily imported module can be accessed
            b.TestCase.assertRaises(None, None)
            # Disable proxying
            disallow_proxying()
            # Check that accessing the imported module raises an exception

# Generated at 2022-06-24 02:46:13.422462
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test that method __unicode__ returns a unicode string.

    Also tests that method __str__ returns an utf8 encoded string.
    """
    e = IllegalUseOfScopeReplacer(None, None, None)
    s = str(e)
    u = unicode(e)
    assert isinstance(s, str)
    assert isinstance(u, unicode)



# Generated at 2022-06-24 02:46:18.424733
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    name = 'foo'
    scope[name] = 1
    class Factory(object):
        def __init__(self):
            self.calls = 0
        def __call__(self, sr, scope, name):
            self.calls += 1
            if self.calls > 1:
                raise AssertionError('Factory called more than once')
            if scope[name] != 1:
                raise AssertionError('Scope was modified before factory called')
            scope[name] = 2
            return scope[name]
    factory = Factory()
    scope_replacer = ScopeReplacer(scope, factory, name)
    if scope[name] is not scope_replacer:
        raise AssertionError('ScopeReplacer did not install in scope')
    # test __getattribute__

# Generated at 2022-06-24 02:46:23.763185
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """When __str__ is called on an IllegalUseOfScopeReplacer object, it
    should return a string.
    """
    e = IllegalUseOfScopeReplacer('a_name', 'a message')
    str(e)



# Generated at 2022-06-24 02:46:30.566213
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Some type checking
    try:
        ImportReplacer(scope=None, name=None, module_path=None,
                       member=None, children=None)
    except TypeError:
        pass
    else:
        raise AssertionError("Should have asked for parameters")
    try:
        ImportReplacer(scope=None, name=None, module_path=None,
                       member=None, children=None)
    except TypeError:
        pass
    else:
        raise AssertionError("Should have asked for parameters")


# Generated at 2022-06-24 02:46:35.198175
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    class MyException(IllegalUseOfScopeReplacer):
        pass

    e1 = MyException('foo', 'bar')
    e2 = MyException('foo', 'bar')
    assert e1 == e2



# Generated at 2022-06-24 02:46:45.377022
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__ is a complicated method, ensure here that it does its job properly."""
    from bzrlib.lazy_import import lazy_import
    import copy
    import sys
    import traceback
    import os

    scope = {'sys':sys}
    scope['sys'].__dict__['platform'] = 'old_platform'
    lazy_import(scope, '''
    import sys
    sys.platform
    ''')
    scope['sys'].__dict__['platform'] = 'new_platform'
    platform = scope['sys'].platform
    sys.platform = 'old_platform'
    if not platform == 'new_platform':
        raise AssertionError("%r should have 'new_platform', but has '%r'" % (scope['sys'].__getattribute__('platform'), platform))

   

# Generated at 2022-06-24 02:46:56.861178
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-24 02:47:04.958646
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib import _lazy_import
    lz = _lazy_import.LazyImport(_lazy_import, 'BzrError',
        'bzrlib.errors.BzrError')
    i = _lazy_import.IllegalUseOfScopeReplacer('foo', 'bar', lz)
    assert str(i) == 'foo was used incorrectly: bar: bzrlib.errors.BzrError'
    assert repr(i) == "IllegalUseOfScopeReplacer('foo was used incorrectly: bar: bzrlib.errors.BzrError')"
    assert i.__dict__ == {
        'name': 'foo',
        'msg': 'bar',
        'extra': ': bzrlib.errors.BzrError'}
    # preserve the dict
    i

# Generated at 2022-06-24 02:47:15.828307
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    out = StringIO()
    ip = ImportProcessor(ImportReplacer)
    globals()['__builtins__']['__import__'] = trace_import(out)
    ip.lazy_import(globals(), """
        import os
        import bzrlib
        import bzrlib.foo
        import bzrlib.foo.bar as baz
        from bzrlib import foo
        from bzrlib import foo as f
        from bzrlib import foo, bar
        from bzrlib import foo as f, bar as b
        from bzrlib.foo import bar
        from bzrlib.foo import bar as b
        from bzrlib.foo import bar, baz
        from bzrlib.foo import bar as b, baz as z
    """)

# Generated at 2022-06-24 02:47:19.288799
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # We're just testing that this doesn't raise any exceptions
    ImportProcessor('foo\n bar\n baz')

# Generated at 2022-06-24 02:47:25.884163
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Tests for the constructor of class ImportProcessor"""
    # Test for valid arguments for creating an instance of class
    # ImportProcessor
    ImportProcessor()
    ImportProcessor(ImportReplacer)
    # Test for arguments other than ImportReplacer class

# Generated at 2022-06-24 02:47:30.383326
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """ScopeReplacer objects should not be able to modify their attributes."""
    lazy = ScopeReplacer({}, lambda self, scope, name: None, None)
    try:
        lazy.foo = 'bar'
    except TypeError:
        return
    raise AssertionError("Setting attributes on ScopeReplacer objects should "
                         "fail")

# Generated at 2022-06-24 02:47:41.725875
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test handling of constructor for ImportReplacer."""
    scope = {}
    member = 'foo'
    module_path = ['bzrlib', 'foo']
    name = 'bzrlib'
    children = {'bar':(['bzrlib', 'foo', 'bar'], None, {})}
    try:
        ImportReplacer(scope=scope, name=name, member=member,
                       module_path=module_path, children=children)
    except ValueError:
        pass
    else:
        raise AssertionError("ImportReplacer doesn't raise an error"
                             " when member and children are both supplied")

    # Test where no member is supplied
    ImportReplacer(scope=scope, name=name,
                   module_path=module_path, children=children)



# Generated at 2022-06-24 02:47:50.181542
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # By default, the ImportProcessor uses ImportReplacer
    imp_proc = ImportProcessor()
    import bzrlib
    import bzrlib.__init__ as mod_bzrlib_init
    import bzrlib.tests as mod_bzrlib_tests

    imp_proc.lazy_import(vars(), """
    import bzrlib.tests
    import bzrlib.__init__ as bzrlib_init
    from bzrlib import ui
    """)

    # Make sure they are in the right places.
    # The ImportReplacer objects should be there instead
    assert 'bzrlib_init' in vars()
    assert 'bzrlib_init' not in dir(bzrlib)
    assert 'mod_bzrlib_tests' not in v

# Generated at 2022-06-24 02:47:56.524643
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import ModuleForTesting
    lazy_import(globals(), '''
    from bzrlib.lazy_import import ModuleForTesting
    ''')
    disallow_proxying()
    # Throws an exception, no proxy should be accepted:
    ModuleForTesting = ModuleForTesting


_lazy_import_hooks = []



# Generated at 2022-06-24 02:48:05.595829
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test for ScopeReplacer.

    This is used for lazy_import, so not all functionality is tested.
    """
    scope = {}
    name = 'obj'
    def factory(replacer, scope, name):
        return object()
    replacer = ScopeReplacer(scope=scope, factory=factory, name=name)
    # It should proxy
    assert not hasattr(replacer, 'method')
    replacer._resolve = lambda: object()
    assert hasattr(replacer, 'method')
    # It should have put itself into scope
    assert scope[name] is replacer
    # It should have created a real object
    assert scope['obj'] is object()
    # It should proxy
    assert hasattr(scope[name], 'method')
    # It should not allow assignment of methods

# Generated at 2022-06-24 02:48:17.340820
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the constructor of class ScopeReplacer."""
    from bzrlib import lazy_import
    from bzrlib.tests import TestCase
    def factory(self, scope, name):
        return object()

    class TestLazyImport(TestCase):

        def test_init(self):
            """Test the constructor of class ScopeReplacer."""
            name = 'bar'
            scope = {'foo': 'foo'}
            replacer = lazy_import.ScopeReplacer(scope, factory, name)
            self.assertEqual(name, replacer._name)
            self.assertEqual(scope, replacer._scope)
            self.assertEqual(factory, replacer._factory)
            self.assertEqual(None, replacer._real_obj)

# Generated at 2022-06-24 02:48:26.434050
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Unit test for method __getattribute__ of class ScopeReplacer"""

    class C(object):
        __slots__ = ('_s')
        def __init__(self, s):
            self._s = s
        def __getattribute__(self, attr):
            if attr == '_s':
                return object.__getattribute__(self, attr)
            return '%s %s %s' % (self._s, attr, object.__getattribute__(self, attr))
    scope = {}
    c = C('hello')
    scope['c'] = c
    lazy_import(scope, 'from bzrlib.lazy_import import (ScopeReplacer, )')
    ScopeReplacer(scope, lambda _, __, ___: c, 'c')

# Generated at 2022-06-24 02:48:30.045699
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()"""
    obj = IllegalUseOfScopeReplacer('name', 'msg')
    assert repr(obj) == 'IllegalUseOfScopeReplacer(Illegal use of ScopeReplacer object \'name\': msg)'



# Generated at 2022-06-24 02:48:35.421041
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
  import bzrlib.lazy_import
  obj = bzrlib.lazy_import.ScopeReplacer({}, None, "")
  try:
    obj.__setattr__("_real_obj", None)
  except bzrlib.lazy_import.IllegalUseOfScopeReplacer:
    pass
  else:
    raise AssertionError()


# Generated at 2022-06-24 02:48:45.087750
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    import sys
    import imp
    import test_lazy_import
    test_lazy_import_mod = imp.load_module(
        'test_lazy_import', *imp.find_module('test_lazy_import',
        [sys.modules[__name__].__path__[0]]))
    # a mock scope to contain the scope replacer
    scope = {}
    scope_replacer = test_lazy_import_mod.ScopeReplacer(scope, 
        test_lazy_import_mod._make_obj, 'x')
    scope_replacer._should_proxy = False
    x_obj = scope_replacer._resolve()
    scope_replacer.x = 1
    scope_replacer.a = 1
    scope_replacer.b

# Generated at 2022-06-24 02:48:52.445252
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import __builtin__
    def import_module(name, *args, **kwargs):
        raise Exception()
    original_import_module = __builtin__.__import__

# Generated at 2022-06-24 02:49:01.211948
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import sys
    import os
    import os.path
    import __builtin__
    import bzrlib.tests

# Generated at 2022-06-24 02:49:12.605190
# Unit test for function lazy_import
def test_lazy_import():
    """Unit test for lazy_import.

    Tests that lazy_import creates the correct objects.
    """
    class SimpleImportReplacer(ImportReplacer):

        def __init__(self, *args, **kwargs):
            ImportReplacer.__init__(self, *args, **kwargs)
            self.calls = []

        def _import(self, scope, name):
            # This needs to be indirected so that ImportReplacer does not
            # try to load the module
            member = object.__getattribute__(self, '_member')
            if member is not None:
                module = object.__getattribute__(self, '_module_path')
                module = '.'.join(module)
                obj = __import__(module, scope, scope, [member], level=0)

# Generated at 2022-06-24 02:49:24.543283
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer

    This method will be called by the exception printing mechanism when a
    IllegalUseOfScopeReplacer is not handled.  We want to ensure that the
    output is meaningful and doesn't raise another exception.

    We expect the output to be in the form

    IllegalUseOfScopeReplacer(message)

    e.g.

    IllegalUseOfScopeReplacer('some message')
    """
    import re
    import sys
    import traceback
    s = str(IllegalUseOfScopeReplacer('some message', 'some other message'))

# Generated at 2022-06-24 02:49:33.885205
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    i = ImportProcessor()
    i.lazy_import(globals(),
        'import foo\n'
        'import foo.bar as baz\n'
        'import foo.bar.baz, foo.bar.baz.bing\n'
        'from bzrlib.foo import bar\n'
        'from bzrlib.foo import bar as baz\n')
    for name, info in i.imports.iteritems():
        globals()[name] = i._lazy_import_class(globals(), name, *info) 

if __name__ == '__main__':
    test_ImportProcessor()

# Generated at 2022-06-24 02:49:46.190157
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__ is a special method which can be used to
    trap attribute access.

    Here we make sure that an object is retrieved from the scope using
    real_obj.attr or real_obj() when using a ScopeReplacer.

    This is an important part of lazy_import, as it allows us to keep
    references to a lazy-loaded object that will behave as the real
    object once the real object is created.

    See https://bug.launchpad.net/bzr/+bug/371733 for more details
    """
    class Real(object):
        def __init__(self, value):
            self.value = value
        def f(self):
            return self.value
    def fake_factory(self, scope, name):
        scope[name] = Real('real')
    scope = {}

# Generated at 2022-06-24 02:49:51.400580
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    scope = {}
    lazy_replacer = ImportProcessor()
    lazy_replacer.lazy_import(scope, """
        import os, sys
        from os import path
    """)
    assert scope['os'] is not None
    assert scope['sys'] is not None
    assert scope['path'] is not None

# Generated at 2022-06-24 02:49:59.014649
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test constructor of class IllegalUseOfScopeReplacer."""

    import random
    import string
    import weakref
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    # construct a random name
    name = ''.join([random.choice(string.ascii_letters) for i in range(10)])
    msg = ''.join([random.choice(string.ascii_letters) for i in range(10)])
    extra = ''.join([random.choice(string.ascii_letters) for i in range(10)])
    e = IllegalUseOfScopeReplacer(name, msg, extra)
    # check attributes
    self.assertEqual(name, e.name)
    self.assertEqual(msg, e.msg)

# Generated at 2022-06-24 02:50:10.418713
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import unittest
    import sys
    import tempfile
    # disable the proxy checking so we can test it
    saved_should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-24 02:50:22.230402
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    global scope
    scope = {'a': None}
    def f(obj, scope, name):
        return scope[name]

    def g(obj, scope, name):
        return obj
    def h(obj, scope, name):
        return obj
    def i(obj, scope, name):
        return obj

    ScopeReplacer(scope, f, 'a')
    scope['a'] = 'b'

# Generated at 2022-06-24 02:50:30.903194
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    import sys
    scope = sys.modules
    def factory(self, scope, name):
        return scope[name].__call__
    name = 'lazy_import'
    self = lazy_import.ScopeReplacer(scope, factory, name)
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    return self(*args, **kwargs)

# Generated at 2022-06-24 02:50:35.045813
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a 'str' object never a 'unicode' object."""
    e = IllegalUseOfScopeReplacer("foo", "bar")
    s = str(e)
    assert isinstance(s, str), "%r is not an instance of %r" % (s, str)


# Generated at 2022-06-24 02:50:45.153941
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    import_processor.lazy_import({},
"""import foo
import bar
from baz import wibble
from baz import wobble
import bing as bong
import bing as ping
""")
    # Sanity check that these are ImportReplacer objects
    assert isinstance(foo, ImportReplacer)
    assert isinstance(bar, ImportReplacer)
    assert isinstance(wibble, ImportReplacer)
    assert isinstance(wobble, ImportReplacer)
    assert isinstance(bong, ImportReplacer)
    assert isinstance(ping, ImportReplacer)
    raise TestSkipped("This test doesn't actually check anything yet")


# Generated at 2022-06-24 02:50:53.904253
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('myname', 'mymsg', 'myextra')
    assert str(e) == ("ScopeReplacer object 'myname' was used incorrectly:"
                      " mymsg: myextra")
    assert repr(e) == "IllegalUseOfScopeReplacer('myname', 'mymsg', 'myextra')"
    assert e._format() == ("ScopeReplacer object 'myname' was used incorrectly:"
                           " mymsg: myextra")
    assert e.name == 'myname'
    assert e.msg == 'mymsg'
    assert e.extra == ': myextra'



# Generated at 2022-06-24 02:51:03.930887
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Testing constructor for ImportReplacer class

    This should not use lazy import itself, as it tests a corner case of the
    lazy import code.
    """
    assert ImportReplacer is ScopeReplacer.__subclasses__()[0]
    # Check that the constants are set to the correct values
    bad_attrs = ['class', '__class__', '_import', '__init__']
    good_attrs = ['_name', '_import_replacer_children', '_member',
                  '_module_path']
    for name in bad_attrs:
        try:
            object.__getattribute__(ImportReplacer, name)
        except AttributeError:
            pass
        else:
            raise AssertionError("%r should not exist as a class attribute"
                % (name,))

# Generated at 2022-06-24 02:51:07.780405
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """method __call__ of class ScopeReplacer"""
    def test_method(self, scope, name):
        return lambda x: x
    o = ScopeReplacer({}, test_method, '')
    e = o('foo')
    assert e == 'foo', repr(e)

# Generated at 2022-06-24 02:51:20.292382
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for IllegalUseOfScopeReplacer.__unicode__

    This test is here to support the coverage tool.
    """
    # We test the Unicode output because it exercises some more
    # code. However, the implementation of str() should be nearly
    # identical.
    def check_unicode(name, msg, extra, expected):
        e = IllegalUseOfScopeReplacer(name, msg, extra)
        s = unicode(e)

# Generated at 2022-06-24 02:51:24.549889
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    import doctest
    doctest.run_docstring_examples(IllegalUseOfScopeReplacer.__repr__,
                                   globals(),
                                   verbose=True)



# Generated at 2022-06-24 02:51:30.390640
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from mock import Mock
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    class Foo(object):
        def __init__(self):
            self.baz = False

    def replace(self, scope, name):
        return Foo()

    scope = {}
    replacer = ScopeReplacer(scope, replace, 'foo')

    replacer.baz = True
    Foo().baz = True
    assert replacer.baz == True

    replacer.baz = False
    Foo().baz = False
    assert replacer.baz == True
    assert replacer.baz == False

    real_obj = replacer._resolve()
    assert real_obj
    real_obj.baz = False
    assert real_obj

# Generated at 2022-06-24 02:51:37.533130
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib.lazy_import  # Avoid circular imports
    bzrlib.lazy_import.disallow_proxying()
    lazy_import(globals(), '''
    from bzrlib import config
    ''')
    import time
    # Allow concurrent importing threads to do their job
    time.sleep(0.1)
    # Now it's safe to check the import was done
    assert config.__name__ is 'bzrlib.config'



# Generated at 2022-06-24 02:51:48.500509
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib import (
        config as _mod_config,
        errors as _mod_errors,
        )
    from bzrlib.tests.blackbox import ExternalBase as _mod_ExternalBase

    class TestImportProcessor(_mod_ExternalBase):

        def test_has_expected_import_errors(self):
            from bzrlib.tests.blackbox import TestImportProcessor

            self.assertEqual([_mod_errors.InvalidImportLine, _mod_errors.ImportNameCollision],
                sorted(TestImportProcessor._module_exports.keys()))
        def test_lazy_import(self):
            self.requireFeature(modules_feature)
            # we don't really care what globals() is, so just send in some
            # object.
            ip = ImportProcessor()
            # make sure

# Generated at 2022-06-24 02:51:51.476604
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    bzrlib.lazy_import._test_ScopeReplacer___getattribute__()


# Generated at 2022-06-24 02:52:00.572646
# Unit test for function lazy_import
def test_lazy_import():
    scope = {}
    lazy_import(scope, '''
    from bzrlib import foo
    from bzrlib import (
        bar,
        baz,
        )
    import bzrlib.bing as bing
    from bzrlib.blah import boom
    from bzrlib.blah import boom as boom2
    ''')

    import bzrlib.foo
    import bzrlib.bar
    import bzrlib.baz
    import bzrlib.bing
    import bzrlib.blah.boom

    # Check that nothing was imported yet

# Generated at 2022-06-24 02:52:12.233497
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Unit test for method 'lazy_import' of class 'ImportProcessor'."""

    # TODO: jam 20060912 This unit test is pretty minimal. We should
    #       test the various errors that can occur.

    from bzrlib import tests
    test_map = {'foo':(['foo'], None, {}),
                'bar':(['foo'], 'bar', {}),
                'bing':(['foo', 'bar'], 'bing', {}),
                'baz':(['foo', 'bar'], 'baz', {}),
                }

    ip = ImportProcessor()
    ip.lazy_import(globals(), '''import foo
                              import foo.bar, foo.bar.baz
                              from foo.bar import bing''')

# Generated at 2022-06-24 02:52:23.153649
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Check the constructor
    global foo_var, foo_var2, foo_bar_var, foo_bar_baz_var
    # name, module_path, member=None, children={}
    ImportReplacer({'foo_var':None}, 'foo_var', ['foo'])
    # Check that we created the right children
    children = ImportReplacer.__dict__['_import_replacer_children']
    assert children == {}
    member = ImportReplacer.__dict__['_member']
    assert member is None
    module_path = ImportReplacer.__dict__['_module_path']
    assert module_path == ['foo']
    assert foo_var is None

    # Test with children

# Generated at 2022-06-24 02:52:27.925458
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__"""
    the_string = "the_string"
    the_int = 42
    e = IllegalUseOfScopeReplacer(the_string, the_string, the_int)
    assert repr(e) == 'IllegalUseOfScopeReplacer("%s", "%s", %s)' % (
        the_string,
        the_string,
        the_int,
        )

# Generated at 2022-06-24 02:52:32.094388
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test that IllegalUseOfScopeReplacer can be constructed."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly: msg"



# Generated at 2022-06-24 02:52:41.053939
# Unit test for function disallow_proxying
def test_disallow_proxying():
    scope = {'__name__': 'bla'}
    lazy_import(scope, '''
    def foo():
        return 42
    ''')
    assert scope['foo']() == 42
    disallow_proxying()
    # It is safe to use the function after it's been imported
    assert scope['foo']() == 42
    # But it is not safe to use it on a variable

# Generated at 2022-06-24 02:52:43.412449
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    doctest.run_docstring_examples(ScopeReplacer, globals())

# Generated at 2022-06-24 02:52:56.095589
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Check that the ScopeReplacer constructor places a lazy object in the
    specified scope.

    This does not check that lazy objects are properly created, just that
    the initial interface works as expected.
    """
    from bzrlib.tests.per_lazy_import import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObject(TestCase):
        """A base class for other tests to run within."""

    var_name = 'foo_bar'
    g = vars(TestObject)
    ScopeReplacer(g, lambda x, y, z: x, var_name)
    self.assertTrue(var_name in g)
    self.assertTrue(isinstance(g[var_name], ScopeReplacer))


# Generated at 2022-06-24 02:53:03.392497
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    class MyException(RuntimeError):

        _fmt = "RuntimeError: %(msg)s"

        def __init__(self, msg):
            self.msg = msg
            super(MyException, self).__init__()

    msg = 'test message'
    e = MyException(msg)
    assert str(e) == 'RuntimeError: test message'

    e = MyException(msg)
    assert str(e) == 'RuntimeError: test message'



# Generated at 2022-06-24 02:53:13.485916
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Unit test for constructor of class ImportReplacer"""
    scope = {}
    replacer = ImportReplacer(scope, name='foo', module_path='foo',
        member=None, children={})
    assert scope == {'foo': replacer}, scope
    replacer = ImportReplacer(scope, name='foo', module_path='foo',
        member=None, children={'bar':(['foo', 'bar'], None, {})})
    assert scope == {'foo': replacer}, scope
    replacer = ImportReplacer(scope, name='bar', module_path='foo',
        member='bar', children={})
    assert scope == {'foo': replacer, 'bar': replacer}, scope

    # A non string module_path is not allowed