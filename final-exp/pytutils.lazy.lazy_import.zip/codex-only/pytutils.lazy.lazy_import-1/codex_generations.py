

# Generated at 2022-06-24 02:43:09.220956
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    ver = sys.version_info
    if ver[0] == 2 and ver[1] < 7:
        return
    x = IllegalUseOfScopeReplacer('foo', 'bar')
    x.__unicode__()


# Generated at 2022-06-24 02:43:16.368893
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    globals_dict = {}
    ImportReplacer(globals_dict, name='foo', module_path=['foo'], member=None,
        children={'bar':(['foo', 'bar'], 'baz', {})})
    assert globals_dict['foo']._import_replacer_children == {
        'bar':(['foo', 'bar'], 'baz', {})}
    assert globals_dict['foo']._member is None
    assert globals_dict['foo']._module_path == ['foo']
    assert globals_dict['foo']._name == 'foo'
    assert globals_dict['foo']._scope == globals_dict
    assert globals_dict['foo']._real_obj is None



# Generated at 2022-06-24 02:43:22.567776
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test the constructor for IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e.name == 'name'
    assert e.msg == 'msg'
    assert e.extra == ': extra'
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert e.name == 'name'
    assert e.msg == 'msg'
    assert e.extra == ''


# Generated at 2022-06-24 02:43:31.168018
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.lazy_import import ImportReplacer
    from bzrlib.tests import TestCase

    class TestImportReplacer(TestCase):

        def test_basic(self):
            ImportReplacer({}, 'foo', ['bzrlib', 'foo'], None, {})

        def test_basic_import(self):
            """__init__ works the same as import"""
            ImportReplacer({}, 'foo', ['bzrlib', 'foo'], None, {})
            import bzrlib.foo

        def test_from_import(self):
            """from_import works"""
            ImportReplacer({}, 'bar', ['bzrlib', 'foo'], 'bar', {})
            from bzrlib.foo import bar


# Generated at 2022-06-24 02:43:39.010773
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ does a deep compare of all elements"""
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    assert e1 == e2
    e3 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert e1 != e3
    # override __eq__ to return something different
    class MyException(IllegalUseOfScopeReplacer):
        def __eq__(self, other):
            return True
    e1 = MyException('foo', 'bar')
    e2 = MyException('qux', 'quux')
    assert e1 == e2



# Generated at 2022-06-24 02:43:46.659460
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(obj) == "ScopeReplacer object 'name' was used incorrectly:" \
        " msg: extra"
    obj = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(obj) == "ScopeReplacer object 'name' was used incorrectly:" \
        " msg"



# Generated at 2022-06-24 02:43:54.050921
# Unit test for function disallow_proxying
def test_disallow_proxying():
    glob = {}
    module_name = 'bzrlib.tests.lazy_import'

    def factory(lazy_import, scope, name):
        assert name == module_name
        from bzrlib.tests import lazy_import
        return lazy_import

    lazy_import = lazy_import(glob, module_name, factory)
    # If we just imported the module using the lazy_import, we should
    # be able to use it as a proxy
    if lazy_import is not lazy_import:
        raise AssertionError("Lazily imported module was not a proxy")
    # Now we disallow proxies, so using the lazily imported module as
    # a proxy should fail
    disallow_proxying()

# Generated at 2022-06-24 02:44:03.082658
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a string that can be used to create an
    equivalent exception.
    """
    test_cases = [
        ('name', 'msg', 'extra', 'extra'),
        ('name', 'msg', None, None),
        ('name', 'msg', '', ''),
        ('name', 'msg', u'extra', u'extra'),
    ]
    # 'extra' is not compared in __eq__, so check it is passed through
    # __repr__
    for name, msg, extra, expected_extra in test_cases:
        original = IllegalUseOfScopeReplacer(name, msg, extra)
        result = eval(repr(original))
        # the repr of the extra value is not compared, because __repr__
        # removes the extra field.

# Generated at 2022-06-24 02:44:06.069260
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    assert e.name == 'name'
    assert e.msg == 'message'
    assert e.extra == ': extra'



# Generated at 2022-06-24 02:44:17.499713
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    global _test_ImportProcessor_test_ran
    _test_ImportProcessor_test_ran = True
    import_processor = ImportProcessor()
    import_processor.lazy_import({}, """
        import foo, bar.baz
        from foo import bar, baz
        import something as else
    """)

    expected_map = {
        'foo': (['foo'], None,
            {'bar': (['foo', 'bar'], None, {}),
             'baz': (['foo', 'baz'], None, {}),
             }),
        'bar': (['bar'], None,
            {'baz': (['bar', 'baz'], None, {}),
            }),
        'something': (['something'], 'else', {})
        }


# Generated at 2022-06-24 02:44:27.026479
# Unit test for function lazy_import
def test_lazy_import():

    class FakeModule(object):

        def __init__(self, name):
            self.name = name

    class FakeModuleReplacer(ScopeReplacer):

        def __init__(self, scope, name, children):
            ScopeReplacer.__init__(self, scope, name,
                                   factory=self._create_module)
            self.children = children

        def _create_module(self, scope, name):
            children = self.children
            module = FakeModule(self.name)
            for child_name in children:
                # Using self.__class__, so that children get children classes
                # instantiated. (This helps with instrumented tests)
                cls = object.__getattribute__(self, '__class__')

# Generated at 2022-06-24 02:44:31.283004
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.mock_scope_replacer import ScopeReplacerTestStub, test_ScopeReplacer___setattr__
    test_ScopeReplacer___setattr__(TestCase(), ScopeReplacer,
            ScopeReplacerTestStub)


# Generated at 2022-06-24 02:44:38.765210
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test ImportReplacer construction

    Can't really test constructor without fixtures.
    """
    from bzrlib.lazy_import import ImportReplacer
    class foo(object):
        pass
    class bar(object):
        pass
    globals = {'foo':foo, 'bar':bar}
    ImportReplacer(globals, 'baz', ['baz'], member='bar')
    ImportReplacer(globals, 'baz', ['baz'], member='bar')
    #import pdb; pdb.set_trace()
    ImportReplacer(globals, 'baz', ['baz'],
                    children={'foo':(['baz'], 'foo', {})})
    # TODO: test that the error raises when member and children are both set



# Generated at 2022-06-24 02:44:42.682900
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    def check(args, expected):
        exception = IllegalUseOfScopeReplacer(*args)
        actual = str(exception)
        assert actual == expected, (actual, expected)
    check(('a', 'b', 'c'), "ScopeReplacer object 'a' was used incorrectly: b: c")



# Generated at 2022-06-24 02:44:53.294468
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def mutation(self, scope, name):
        self.__setattr__('x', 0)
        return None
    v = [1]
    sr = ScopeReplacer(v, mutation, 'z')
    assert v[0] is sr
    sr.__setattr__('y', 1)
    assert v[0] is None
    raises(IllegalUseOfScopeReplacer, setattr, sr, 'y', 2)
    raises(IllegalUseOfScopeReplacer, setattr, sr, 'x', 3)


# Generated at 2022-06-24 02:45:02.172017
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Constructing and using IllegalUseOfScopeReplacer

    The code it tests is in the constructor of IllegalUseOfScopeReplacer.
    """

# Generated at 2022-06-24 02:45:07.426782
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ in IllegalUseOfScopeReplacer should return the repr"""
    e = IllegalUseOfScopeReplacer('scope', 'message')
    expected_repr = "IllegalUseOfScopeReplacer('scope', 'message')"
    actual_repr = repr(e)
    assert expected_repr == actual_repr, (expected_repr, actual_repr)



# Generated at 2022-06-24 02:45:15.209076
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class A(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    scope = {}
    def factory(self, scope, name):
        return A(1, 2, 3)
    test = ScopeReplacer(scope, factory, 'test')
    self.assertEqual(A(1, 2, 3), test())
    self.assertEqual(A(1, 2, 3), scope['test'])



# Generated at 2022-06-24 02:45:25.023015
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # Create a temporary global variable to hold the imports.
    global test_import_processor_lazy_import_map
    try:
        del test_import_processor_lazy_import_map
    except NameError:
        pass
    test_import_processor_lazy_import_map = {}
    
    import os.path
    import os
    import bzrlib.trace
    from bzrlib import osutils
    from bzrlib.commands import plugin_cmds
    from bzrlib.config import BzrConfig
    from bzrlib.config import LocationConfig
    from bzrlib.config import GlobalConfig
    from bzrlib.config import LocationConfig


# Generated at 2022-06-24 02:45:30.853700
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode string and
    using str() on the exception should not fail.
    """
    ex = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(ex)
    s = str(ex)



# Generated at 2022-06-24 02:45:39.658209
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the ScopeReplacer object can be constructed and works.
    
    This is not a complete test of all the functionality, but just
    checks the basic constructor.
    """
    def factory(self, scope, name):
        """Generator for a ScopeReplacer"""
        return self

    scope = {}
    ScopeReplacer(scope, factory, 'x')
    assert 'x' in scope
    # A second call to the same name is an error

# Generated at 2022-06-24 02:45:43.596244
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == 'name: msg: extra'
    assert unicode(e) == u'name: msg: extra'

# Generated at 2022-06-24 02:45:51.507809
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test for disallow_proxying()"""

# Generated at 2022-06-24 02:45:57.494629
# Unit test for method lazy_import of class ImportProcessor

# Generated at 2022-06-24 02:46:03.287686
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """str(IllegalUseOfScopeReplacer(...))"""
    n = 'name'
    m = 'msg'
    x = 'extra'
    s = IllegalUseOfScopeReplacer(n, m)
    assert str(s) == ("ScopeReplacer object 'name' was used incorrectly:"
                      " msg"
                      )
    s = IllegalUseOfScopeReplacer(n, m, x)
    assert str(s) == ("ScopeReplacer object 'name' was used incorrectly:"
                      " msg: extra"
                      )
    assert repr(s) == ("IllegalUseOfScopeReplacer('name', "
                       "'msg', 'extra')"
                       )
    assert repr(IllegalUseOfScopeReplacer(n, m)) == ("IllegalUseOfScopeReplacer"
        "('name', 'msg')")
    s._

# Generated at 2022-06-24 02:46:09.197008
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """ScopeReplacer.__getattribute__()

    >>> class Foo(object):
    ...     def bar(self):
    ...         return 'Foo.bar'
    ...
    >>> d = {}
    >>> foo =ScopeReplacer(d, lambda self, scope, name: Foo(), 'foo')
    >>> Foo.__getattribute__(foo, 'bar')()
    'Foo.bar'
    """



# Generated at 2022-06-24 02:46:18.438508
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    assert IllegalUseOfScopeReplacer('name', "msg", "extra") == \
        IllegalUseOfScopeReplacer('name', "msg", "extra")
    assert IllegalUseOfScopeReplacer('name', "msg", "extra") != \
        IllegalUseOfScopeReplacer('name2', "msg", "extra")
    assert IllegalUseOfScopeReplacer('name', "msg", "extra") != \
        IllegalUseOfScopeReplacer('name', "msg2", "extra")
    assert IllegalUseOfScopeReplacer('name', "msg", "extra") != \
        IllegalUseOfScopeReplacer('name', "msg", "extra2")
    assert IllegalUseOfScopeReplacer('name', "msg", "extra") != \
        IllegalUseOfScopeReplacer('name', "msg", None)

# Generated at 2022-06-24 02:46:30.397808
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import sys

    scope = sys._getframe(1).f_globals
    scope['module'] = None
    scope['name'] = 'module'
    scope['object'] = None
    scope['object_name'] = 'object'

    # Set up a ScopeReplacer which will replace itself with a variable named
    # 'module' with the value of 'name'.
    def factory(self, scope, name):
        return name
    ScopeReplacer(scope, factory, 'module')
    assert isinstance(scope['module'], ScopeReplacer)
    assert scope['module'] is not None
    assert scope['module'] == 'module'
    assert scope['module'] is scope['module']

    # Set up a ScopeReplacer which will replace itself with an object with the
    # value of 'object_name'.

# Generated at 2022-06-24 02:46:38.590786
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test suite for ImportProcessor"""
    import testtools
    import testtools.matchers

    class ImportProcessorTestCase(testtools.TestCase):

        def test_build_map_empty(self):
            ip = ImportProcessor()
            self.assertRaises(ValueError, ip._build_map, '')

        def test_build_map_unknown(self):
            ip = ImportProcessor()
            self.assertRaises(errors.InvalidImportLine, ip._build_map,
                              'foo')

        def test_build_map_import(self):
            ip = ImportProcessor()
            ip._build_map('import foo')
            self.assertThat(ip.imports,
                testtools.matchers.Equals({'foo':(['foo'], None, {})}))


# Generated at 2022-06-24 02:46:44.134785
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test lazy_import method of class ImportProcessor by
    verifying created nested dictionaries
    """
    import_text = """from foo import bar, baz
from foo.bar import bing, bong
from foo.bar.baz import bam, bim
import foo, foo.bar.baz
import foo.bar"""
    importer = ImportProcessor()
    importer.lazy_import(globals(), import_text)

# Generated at 2022-06-24 02:46:47.651931
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__(self): should return a string."""
    e = IllegalUseOfScopeReplacer('name', 'message')
    str(e)



# Generated at 2022-06-24 02:47:00.161997
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class Foo(ImportReplacer):
        pass

    class Bar(ImportReplacer):
        pass

    my_scope = {'Foo': Foo, 'Bar': Bar}
    
    # Basic import foo
    Foo(my_scope, name='foo', module_path=['foo'])
    assert my_scope == {'Foo': Foo, 'Bar': Bar, 'foo': Foo}

    # Import foo and foo.bar
    children = {'bar': (['foo', 'bar'], None, {})}
    baz = Bar(my_scope, name='baz', module_path=['baz'],
              member='baz',
              children={'bar': (['baz', 'bar'], None, {})})

# Generated at 2022-06-24 02:47:11.110069
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib.tests import TestCase
    class TestException(IllegalUseOfScopeReplacer):
        _fmt = 'This is a %(message)s'
    class TestException2(IllegalUseOfScopeReplacer):
        pass

    t = TestCase()
    t.assertEqual(str(TestException('test', 'message', 'extra')),
        'This is a message: extra')
    t.assertEqual(repr(TestException('test', 'message', 'extra')),
        "TestException('test', 'message', 'extra')")

# Generated at 2022-06-24 02:47:14.197805
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    e = IllegalUseOfScopeReplacer('x', 'y', 'z')
    assert str(e) == 'x: y: z'
    assert repr(e) == "IllegalUseOfScopeReplacer('x', 'y', 'z')"



# Generated at 2022-06-24 02:47:21.857338
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test disallow_proxying."""
    import bzrlib.tests as tests
    test_module = tests.module_name_to_bzrdir.tests

    # The test module must not have been imported or a circular import
    # would have already happened.
    assert test_module not in globals()

    disallow_proxying()

    # Import the test module and make sure it has been imported.
    import test_lazy_import_disallow_proxying
    assert test_lazy_import_disallow_proxying is not None
    assert test_module in globals()

    # Make sure it cannot be assigned to a variable anymore.

# Generated at 2022-06-24 02:47:32.348630
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    globals()['_nil'] = None
    def _factory(self, scope, name):
        return 42
    _nil = ScopeReplacer(globals(), _factory, '_nil')
    globals()['_nil'] = 42
    _nil = ScopeReplacer(globals(), _factory, '_nil')
    def _unit_test():
        global _nil
        try:
            _init = _nil
        except NameError as _error:
            if _error is not _nil:
                raise _error
        else:
            _init = 42
        if _init is not None:
            _nil = _init

# Generated at 2022-06-24 02:47:36.263421
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class TestClass:
        pass
    scope = {}
    name = 'test'
    scope[name] = 'test'
    scopeReplacer = ScopeReplacer(scope, TestClass, name)


# Generated at 2022-06-24 02:47:46.526261
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    class Dummy(object):
        message = 'this is %(name)s'
    # simple message
    e = IllegalUseOfScopeReplacer('name', Dummy())
    assert str(e) == 'this is name'
    # subclassed
    class SubClassed(IllegalUseOfScopeReplacer):
        pass
    e = SubClassed('name', Dummy())
    assert str(e) == 'this is name'
    # extended
    class Extra(Dummy):
        extra = 'not so simple'
    e = IllegalUseOfScopeReplacer('name', Extra())
    assert str(e) == 'this is name: not so simple'
    # utf-8
    e = IllegalUseOfScopeReplacer(u'na\u00dfe', Dummy())

# Generated at 2022-06-24 02:47:58.723721
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Simple import of 'bzrlib'
    g = {'bzrlib': ImportReplacer({}, 'bzrlib', ['bzrlib'])}
    assert g['bzrlib'] is not None
    assert g['bzrlib'].__name__ == 'bzrlib'

    # Submodule import

# Generated at 2022-06-24 02:48:08.198472
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import types
    import unittest
    class Foo(object):
        def __init__(self, expect_correct_name):
            self.expect_correct_name = expect_correct_name
        def __getattribute__(self, name):
            got = object.__getattribute__(self, 'expect_correct_name')
            if name != 'fooprop':
                got = False
            object.__setattr__(self, 'expect_correct_name', True)
            return got
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.f = Foo(True)
            self.globals = {'foo': self.f}
        def test_name(self):
            self.f.expect_correct_name = True
            scope_replacer = ScopeRepl

# Generated at 2022-06-24 02:48:19.088759
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Test(object):
        def __init__(self, a_str, arg1, arg2):
            self.a_str = a_str
            self.arg1 = arg1
            self.arg2 = arg2
    def replacer_factory(replacer_obj, scope, name):
        return Test('Obj created', scope, replacer_obj)
    scope = {'a' : 1, 'b' : 2}
    replacer = ScopeReplacer(scope, replacer_factory, 'replacer')
    # Check the factory is not called until _resolve is called
    assert 'replacer_obj' not in scope
    assert replacer.a_str == 'Obj created'
    # Check the factory is not called twice
    assert replacer.a_str == 'Obj created'

# Generated at 2022-06-24 02:48:26.597102
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Tests of _lazy_import method of ImportProcessor class"""
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(), 'import bzrlib')
    globals()['bzrlib']
    return


if __name__ == "__main__":
    test_ImportProcessor_lazy_import()

# Generated at 2022-06-24 02:48:29.965635
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """test_ImportProcessor
    Test the constructor of ImportProcessor
    """
    ip = ImportProcessor()
    eq(ip.imports, {})
    eq(ip._lazy_import_class, ImportReplacer)


# Generated at 2022-06-24 02:48:37.464398
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ of IllegalUseOfScopeReplacer"""
    a = IllegalUseOfScopeReplacer('x', 'xx')
    b = IllegalUseOfScopeReplacer('x', 'xx')
    assert a == b
    b.y = 3
    assert a != b

LEGAL_USE_MESSAGE = ("This function is intended to be used on a scope "
                     "replacer object, and should be used like:\n    "
                     "from bzrlib import %(name)r\n    %(name)r")



# Generated at 2022-06-24 02:48:41.577186
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test for IllegalUseOfScopeReplacer.__str__

    This is mainly to make sure that it succeeds.
    """
    err = IllegalUseOfScopeReplacer('scope', 'error', 'extra')
    str(err)



# Generated at 2022-06-24 02:48:46.408724
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ must return the correct value.

    It must return a string that can be evaluated to recreate the exception,
    containing the class name, and the arguments to the constructor.
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    exc1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    exc2 = eval(repr(exc1))
    assert exc1 == exc2



# Generated at 2022-06-24 02:48:50.854873
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Check that ScopeReplacer does not replace itself in the scope"""
    scope = {'test': None}
    def factory(self, scope, name):
        """Return a dummy object"""
        return True

    replacer = ScopeReplacer(scope, factory, 'test')
    # Check that test is still a ScopeReplacer object
    assert scope['test'] is replacer

# Unit tests for access to members of class ScopeReplacer

# Generated at 2022-06-24 02:49:00.552082
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class Proxy(object):
        def __init__(self, s):
            self.s = s
    class Subclass(ScopeReplacer):
        pass

    d = {}
    s = ScopeReplacer(d, 'foo', lambda proxy, scope, name: Proxy('class'))
    assert s._scope is d
    assert s._name == 'foo'
    s = ScopeReplacer(d, lambda proxy, scope, name: Proxy('lambda'),  'foo')
    assert s._scope is d
    assert s._name == 'foo'
    def proxy(proxy, scope, name):
        return Proxy('function')
    s = ScopeReplacer(d, proxy,  'foo')
    assert s._scope is d
    assert s._name == 'foo'


# Generated at 2022-06-24 02:49:04.374633
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Make sure that __str__ method raises no exception.

    This is a regression test for bug #385945.
    """
    e = IllegalUseOfScopeReplacer("name", "msg")
    str(e)


# Generated at 2022-06-24 02:49:13.286032
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str"""
    e = IllegalUseOfScopeReplacer("name", "msg")
    s = str(e)
    assert isinstance(s, str)
    e = IllegalUseOfScopeReplacer("name", "m\xc3\xa9ssage", 'extra')
    s = str(e)
    assert isinstance(s, str)
    e = IllegalUseOfScopeReplacer("name", "m\xc3\xa9ssage", 'extra')
    e._preformatted_string = "\xc3\xa9\xc3\xa9"
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-24 02:49:20.773935
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__"""
    obj = object()
    scope = {}
    factory = lambda x, y, z: obj
    name = 'name'
    sr = ScopeReplacer(scope, factory, name)
    assert obj is sr._resolve()
    assert obj is scope[name]
    assert obj is sr._real_obj
    assert sr is not scope[name]
    assert sr is not obj

# Test for __getattribute__

# Generated at 2022-06-24 02:49:29.138304
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """This tests the importing of modules.

    This tests the importing of modules, both the ImportProcessor and
    ImportReplacer objects.
    """
    # For now this just tests the handling of various import strings.
    # Later on, we'll actually make sure that the modules are imported
    # when they are called on.
    scope = {}
    imports = """
        import bzrlib, bzrlib.foo.bar, bzrlib.foo.bar.baz as bing
        from bzrlib.foo import orf, zot
    """
    processor = ImportProcessor()
    processor.lazy_import(scope, imports)
    bzrlib = scope['bzrlib']
    # All of these should be import replacers
    # It is assumed that the normal functions are working.

# Generated at 2022-06-24 02:49:41.673509
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Check the following:
    1. If the object contains a preformatted message,
    return it;
    2. Else if the object has a format string _fmt, format
    its message and return it;
    3. Else return a message which indicates the presence of
    an exception.
    """
    # 1. If the object contains a preformatted message, return it.
    preformatted_message = 'Preformatted message'
    example_obj = IllegalUseOfScopeReplacer('test', 'message',
                                            preformatted_message)
    # '_preformatted_string' attribute is set in the object's constructor.
    assert example_obj._preformatted_string == preformatted_message
    example_obj._preformatted_string = preformatted_message
    assert unicode(example_obj) == preform

# Generated at 2022-06-24 02:49:45.861082
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    name = 'the_name'
    scope = {}
    def factory(self, scope, name):
        return 'the_object'
    o = ScopeReplacer(scope, factory, name)
    try:
        o._resolve()
    except AttributeError:
        pass



# Generated at 2022-06-24 02:49:55.884707
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    import operator
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    e3 = IllegalUseOfScopeReplacer('foo', 'bar', 'extra')
    e4 = IllegalUseOfScopeReplacer('foo', 'baz')
    e5 = IllegalUseOfScopeReplacer('baz', 'foo')
    assert e1 == e1
    assert not e1 != e1
    assert e1 == e2
    assert e2 == e1
    assert not e1 != e2
    assert not e2 != e1
    assert e1 != e3
    assert e3 != e1
    assert not e1 == e3
    assert not e3 == e1
    assert e1 != e4
    assert e4 != e1
    assert not e

# Generated at 2022-06-24 02:50:03.787937
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('bzrlib.LazyModule',
                                  "Use of scope replacer in loop")
    ue = unicode(e)
    assert isinstance(ue, unicode)
    assert u'bzrlib.LazyModule' in ue
    assert u'Use of scope replacer' in ue

# Generated at 2022-06-24 02:50:15.034548
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    from bzrlib.tests import TestCase
    from bzrlib.tests import features
    features.start_feature_branching()
    class TestImportProcessor(TestCase):
        def PrepareImports(self, text, expected, lazy_import_class=None):
            """This is a helper test method to test ImportProcessor.

            :param text: This is the text that will be passed to
                ImportProcessor.
            :param expected: The expected result of ImportProcessor. This is a
                list of tuples.
                ::
                
                    [('foo', (['foo'], None, {}))]
            """
            imports = {}
            if lazy_import_class is None:
                import_processor = ImportProcessor()

# Generated at 2022-06-24 02:50:21.893356
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of a specific subclass should return the same content
    as __str__.
    """
    class TestException(IllegalUseOfScopeReplacer):
        _fmt = "fmt"
    e = TestException('name', 'msg', 'extra')
    # __str__() should always return a 'str' object
    # never a 'unicode' object.
    s = str(e)
    assert type(s) is str
    # check that __unicode__() returns the same as __str__
    u = unicode(e)
    assert s == u



# Generated at 2022-06-24 02:50:24.868303
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # test constructor
    e = IllegalUseOfScopeReplacer('lazy_import', 'access')

# Generated at 2022-06-24 02:50:30.325325
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert e == IllegalUseOfScopeReplacer('name', 'msg')
    e1 = IllegalUseOfScopeReplacer('name', 'msg', None)
    assert e1 == IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg', 'more details')
    assert e2 == IllegalUseOfScopeReplacer('name', 'msg', 'more details')
    e3 = IllegalUseOfScopeReplacer('name', 'msg', e2)
    assert e3 == IllegalUseOfScopeReplacer('name', 'msg', e2)
    assert e1 != e
    assert e2 != e
    assert e2 != e1
    assert e3 != e



# Generated at 2022-06-24 02:50:35.247924
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()

    The __repr__ method is used for the string representation of an instance
    and should return a string that when evaluated with eval() will create an
    equivalent instance.
    """
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert eval(repr(obj)) == obj



# Generated at 2022-06-24 02:50:41.484426
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import actually works"""
    scope = {}
    # TODO: Jam 20060912 lazy_import should actually be a test for
    #       ImportProcessor, but for now, ImportProcessor.lazy_import
    #       is not called by anything else which makes it hard to test.
    lazy_import(scope, '''
    from bzrlib import (
        tests,
        )
    from bzrlib.tests import (
        features,
        )
    from bzrlib import branch
    from bzrlib.branch import (
        Branch,
        )
    import bzrlib.errors
    ''')
    # Now use them, and make sure they are really being replaced.
    scope['bzrlib'].__class__.__name__ == 'module'

# Generated at 2022-06-24 02:50:48.681858
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    r"""Function to test method __setattr__ of class ScopeReplacer."""
    from bzrlib import lazy_import
    import bzrlib.tests
    import sys
    import unittest
    class TestScopeReplacer(unittest.TestCase):
        def test__ScopeReplacer___setattr__(self):
            lazy_import.ScopeReplacer._should_proxy = True
            scope = sys.modules['bzrlib.tests'].__dict__
            def my_factory(self, scope, name):
                return name
            obj = lazy_import.ScopeReplacer(scope, my_factory, '_testobj')
            self.assertRaises(AttributeError, obj.__setattr__, '_name', 'old')

# Generated at 2022-06-24 02:50:59.694557
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test for a the case where proxying is disabled.
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import._testing_skip_proxying_check = True

# Generated at 2022-06-24 02:51:09.017349
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing method __str__ of class IllegalUseOfScopeReplacer."""
    from bzrlib.tests import TestCase
    my_class = IllegalUseOfScopeReplacer("foo", "bar")
    TestCase().assertEqual("foo: bar", str(my_class))
    my_class.extra = "Some extra info"
    TestCase().assertEqual("foo: bar: Some extra info", str(my_class))
    my_class._fmt = '''
    This is a complicated message
    with an extra argument: %(extra)s
    '''
    TestCase().assertEqual('''
    This is a complicated message
    with an extra argument: Some extra info
    ''', str(my_class))


# Generated at 2022-06-24 02:51:21.390722
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Create a ScopeReplacer, cause it to create the real object and make sure
    it worked.
    """
    foo_count = [0]
    def create_foo(loader, scope, name):
        """Create a Foo as called by ScopeReplacer"""
        foo_count[0] += 1
        return Foo()

    # Create a ScopeReplacer
    scope = {}
    loader = ScopeReplacer(scope, create_foo, 'foo')

    # Check initial state
    assert type(loader) is ScopeReplacer
    loader_obj = object.__getattribute__(loader, '_real_obj')
    assert hasattr(loader_obj, 'foo_count')
    assert loader_obj.foo_count == 0

    # Check state after real object created.
    foo_obj = loader()

# Generated at 2022-06-24 02:51:27.282697
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    r"""
    >>> import bzrlib.lazy_import
    >>> isinstance(bzrlib.lazy_import.IllegalUseOfScopeReplacer(
    ...     'foo', 'bad', 'too much'),
    ...     bzrlib.lazy_import.IllegalUseOfScopeReplacer)
    True
    >>> e = bzrlib.lazy_import.IllegalUseOfScopeReplacer(
    ...     'foo', 'bad', 'too much')
    >>> e.__repr__()
    "IllegalUseOfScopeReplacer('foo', 'bad', 'too much')"
    """



# Generated at 2022-06-24 02:51:34.250791
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Unit test for IllegalUseOfScopeReplacer constructor."""

    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra', 'preformatted_string')
    eq = 'Unprintable exception IllegalUseOfScopeReplacer: dict=%r, '\
         'fmt=%r, error=%r' % (repr(e.__dict__), e._fmt, None)
    assert str(e) == eq, (str(e), eq)



# Generated at 2022-06-24 02:51:38.047055
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """__init__() works as expected"""
    instance = IllegalUseOfScopeReplacer('name', 'message')
    assert type(instance) is IllegalUseOfScopeReplacer
    assert instance.name == 'name'
    assert instance.msg == 'message'


# Generated at 2022-06-24 02:51:49.391943
# Unit test for function lazy_import
def test_lazy_import():
    """Test the function lazy_import.

    We use a module instead of globals() to test this, because we
    need to be able to access the names to test it.
    """
    # First make sure we are starting with a clear namespace
    import bzrlib.transport as transport
    del transport
    import bzrlib.tests
    del bzrlib.tests
    del bzrlib.tests_i18n

    class _TestModule(object):
        """A simple module-like class which we can use with lazy_import.

        This has the same effect as using globals() with a function.
        """

        def __init__(self):
            self.__dict__['__name__'] = '_TestModule'
            self.__dict__['__package__'] = None


# Generated at 2022-06-24 02:51:55.572914
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that lazy import correctly replaces itself.
    """
    def factory(lazy_obj, scope, name):
        return None

    scope = {}
    lazy_obj = ScopeReplacer(scope, factory, 'lazy_obj')
    name = lazy_obj._name
    assert (name in scope and scope[name] is lazy_obj and
            lazy_obj._factory is factory and lazy_obj._scope is scope)



# Generated at 2022-06-24 02:52:05.268030
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """This tests the IllegalUseOfScopeReplacer.__repr__() method."""
    # IllegalUseOfScopeReplacer.__repr__() is called by the logging system
    # for exceptions emitted by the logging system.  Errors in
    # IllegalUseOfScopeReplacer.__repr__() can then cause a loop if the
    # logging system emits an error from the logging system again.  This
    # is why all tests for IllegalUseOfScopeReplacer.__repr__() must be
    # done using print.
    import sys


# Generated at 2022-06-24 02:52:12.269347
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ obeys its contracts.

    If x == y, then hash(x) == hash(y).
    """
    x = IllegalUseOfScopeReplacer('a', 'b')
    y = IllegalUseOfScopeReplacer('a', 'b')
    if not (x == y):
        raise AssertionError("x != y: x=%r, y=%r" % (x, y))
    if hash(x) != hash(y):
        raise AssertionError("hash(x) != hash(y): x=%r, y=%r" % (x, y))
    # check that x != y evaluates to False,
    # and that doing so doesn't trigger an exception.

# Generated at 2022-06-24 02:52:15.063255
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() must return a unicode string."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-24 02:52:20.415068
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    import gc
    class Foo(object):
        pass
    foo = Foo()
    scope = dict(foo=foo)
    proxy = ScopeReplacer(scope, lambda self, scope, name: scope['foo'],
                          name='foo')
    proxy.foo = 'baz'
    self.assertEqual('baz', foo.foo)

# Generated at 2022-06-24 02:52:23.213461
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import sys
    # IllegalUseOfScopeReplacer.__str__ is implemented to return
    # a str object.
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    str_obj_type = str
    if sys.version_info[0] > 2:
        # Python 3 has no str type, it has bytes type
        str_obj_type = bytes
    assert isinstance(e1.__str__(), str_obj_type)

# Generated at 2022-06-24 02:52:30.612787
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import sys
    try:
        # test with a unicode string
        s = u'a unicode string'
        e = IllegalUseOfScopeReplacer(name='something', msg=s)
        str(e)
    except UnicodeError:
        print >> sys.stderr, ("This test should not have failed, but it did."
                              " You are on a platform which cannot handle"
                              " unicode objects in exceptions. This is a known"
                              " problem and needs to be fixed.")



# Generated at 2022-06-24 02:52:41.208272
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import unittest, bzrlib
    from bzrlib.tests import TestCase
    msg = 'Some message'
    obj = IllegalUseOfScopeReplacer('name', msg)
    s = obj._get_format_string()
    if s is not None:
        # check _fmt can be built.
        msg = s % obj.__dict__
        obj._preformatted_string = msg
    if isinstance(msg, unicode):
        expect = msg
    else:
        expect = msg.decode('utf8')
    if obj.__unicode__() != expect:
        raise AssertionError(
            '%r != %r' % (obj.__unicode__(), expect))

# Generated at 2022-06-24 02:52:44.669955
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ works"""
    import bzrlib.tests.features
    name = 'some_name'
    msg = 'some_message'
    extra = 'some_extra'
    obj = bzrlib.lazy_import._IllegalUseOfScopeReplacer(
        name, msg, extra)
    bzrlib.tests.features.not_using_unicode_repr_python_26(obj)

# Generated at 2022-06-24 02:52:49.978881
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test the disallow_proxying function.

    The docstring is not a real test, but one is not needed, as
    all we need is to know it is called by the selftest command.
    """



# Generated at 2022-06-24 02:52:59.390315
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    this_scope = locals()
    processor = ImportProcessor()
    # This is the text that they provide us to lazy import
    import_text="""
import foo, bar as bing, baz as bang, bing.moo as mee

   import bing.boo as moo
from foo import moo

    from foo import moo, boo as boing
    import foo
    """
    processor.lazy_import(this_scope, import_text)
    assert (this_scope['foo']._module_path == ['foo'])
    assert (this_scope['bing']._module_path == ['bar'])
    assert this_scope['bing']._member == 'bar'

# Generated at 2022-06-24 02:53:11.656136
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test for method ImportProcessor.lazy_import"""
    from bzrlib import bzrdir
    from bzrlib import errors
    from bzrlib import tests

    scope = {}
    text = """
# a comment
import bzrlib.bzrdir
from bzrlib import errors
from bzrlib import (
       branch as branch_pkg,
       errors as error_pkg,
       )
import bzrlib.tests as test_pkg
import sys, os
"""
    processor = ImportProcessor()
    processor.lazy_import(scope, text)
    bzrdir.BzrDirMetaFormat1()
    branch_pkg.Branch()

    # Before the following import text is evaluated, the scope shouldn't
    # have any of the specified names