

# Generated at 2022-06-24 02:43:18.248825
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # Test that the split works:
    ip = ImportProcessor()
    ip._build_map("""
        #Empty line
        import foo
        import foo.bar
        import foo, bar
        #Comment line
        from foo import bar, bing
        from foo.bar import bing
        from foo import bar, bing as bing2
        import (bar,
                   baz)
        from foo import (bar, bing,
                           bing2)
    """)
    import_map = ip.imports
    # This will show up as ('bar', None, {})
    import_map['bar'][0] == ['bar']
    # This will show up as ('baz', None, {})
    import_map['baz'][0] == ['baz']
    # This will show up as ('foo',

# Generated at 2022-06-24 02:43:29.634950
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    from bzrlib import lazy_import
    from bzrlib.trace import mutter

# Generated at 2022-06-24 02:43:39.734374
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def test_pass(x):
        return x**2
    def test_fail(x):
        return x**3
    def factory_pass(replacer, scope, name):
        return test_pass
    def factory_fail(replacer, scope, name):
        return test_fail
    scope = {}
    replacer_pass = ScopeReplacer(scope, factory_pass, 'test_pass')
    replacer_fail = ScopeReplacer(scope, factory_fail, 'test_fail')
    assert replacer_pass(3) == 9
    assert replacer_pass(3) == 9
    # Check that replacer_fail(3) raises TypeError exception
    try:
        replacer_fail(3)
    except TypeError:
        pass
    else:
        raise AssertionError("did not raise exception")




# Generated at 2022-06-24 02:43:47.459953
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import bzrlib.lazy_import as lazy_import
    scope = {}
    lazy_import.ImportReplacer(module_path=['bzrlib'], scope=scope, name='bzrlib')
    lazy_import.ImportReplacer(module_path=['bzrlib', 'foo'], scope=scope,
                            name='foo', member='Bar')



# Generated at 2022-06-24 02:43:54.362066
# Unit test for function disallow_proxying
def test_disallow_proxying():
    ScopeReplacer._should_proxy = True
    try:
        # normal initialization
        lazy_import(locals(), '''
        from bzrlib import lockdir
        ''', force=True)
        lockdir
        disallow_proxying()
        # detection of wasteful indirection
        lazy_import(locals(), '''
        from bzrlib import lockable_files
        ''', force=True)
        # not detected because initialization was already finished
        lockable_files
    finally:
        ScopeReplacer._should_proxy = True



# Generated at 2022-06-24 02:44:03.331506
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from unittest import TestCase
    from testtools.matchers import StartsWith
    from bzrlib.tests import TestCaseWithMemoryTransport
    class TestCaseWithLazyImport(TestCaseWithMemoryTransport, TestCase):
        def setUp(self):
            TestCaseWithMemoryTransport.setUp(self)
            TestCase.setUp(self)
            self.overrideAttr(
                lazy_import, '_scope_replacer_should_proxy', True)
            self.overrideAttr(
                lazy_import, '_non_lazy_import', self.non_lazy_import)
            self.overrideAttr(
                lazy_import, '_lazy_import', self.lazy_import)
            self.reset_calls()
        def reset_calls(self):
            self

# Generated at 2022-06-24 02:44:14.071839
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """make sure ImportProcessor('from foo import bar\nimport baz as bing')
    works as intented.
    """
    importer = ImportProcessor(ImportReplacer)

    class FakeScope(object):

        def __init__(self):
            self.inserts = []

        def __setitem__(self, key, value):
            self.inserts.append((key, value))

    scope = FakeScope()
    importer.lazy_import(scope, 'from foo import bar\nimport baz as bing')

    # Make sure that scope.inserts contains
    # ('bar', ImportReplacer('foo', 'bar', None))
    # ('bing', ImportReplacer('baz', 'bing', None))
    # ('baz', ImportReplacer('baz', 'baz', None))

# Generated at 2022-06-24 02:44:21.156809
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Getting the attribute '_scope' fails
    sr = ScopeReplacer(globals(), lambda x, y, z: None, 'foo')
    try:
        sr._scope
    except IllegalUseOfScopeReplacer as e:
        if e.name != 'foo':
            raise TestNotApplicable('Wrong name %s' % e.name)
    else:
        raise TestNotApplicable('No exception raised')
    try:
        sr.unexistant_attribute_raise_exception
    except AttributeError:
        # Ok
        pass
    else:
        raise TestNotApplicable('Should raise AttributeError')


# Generated at 2022-06-24 02:44:27.415129
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(),
"""import bzrlib
from bzrlib import revision as foo
""")
    import bzrlib
    try:
        revision
    except NameError:
        pass
    else:
        raise Exception('foo should not have imported revision')
    try:
        bzrlib
    except NameError:
        raise Exception('bzrlib should have been imported')

# Generated at 2022-06-24 02:44:34.825955
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    from bzrlib import (
        errors,
        osutils,
        branch,
        )

    disallow_proxying()
    lazy_import(globals(), """
    import bzrlib.branch
    """)
    def check(m):
        try:
            m+m
        except TypeError:
            return False
        except IllegalUseOfScopeReplacer:
            return True
        return False
    assert check(errors)
    assert check(osutils)
    assert check(branch)
    assert check(bzrlib.branch)



# Generated at 2022-06-24 02:44:43.260556
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the constructor of ScopeReplacer.

    The main role is to check the value in the scope.
    """
    scope = {}
    name = 'name'
    factory = lambda self, scope, name: 42
    # The ScopeReplacer is constructed and put into the scope.
    replacer = ScopeReplacer(scope, factory, name)
    # The replacer is present in the scope
    test = scope[name]
    test.is_(replacer)


# Generated at 2022-06-24 02:44:51.648103
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer('name','msg','extra')
    e2 = IllegalUseOfScopeReplacer('name','msg','extra')
    e3 = IllegalUseOfScopeReplacer('name','msg2','extra')
    assert e1 == e2
    assert e1 != e3
    assert e1 != object()
    assert e1 != object()



# Generated at 2022-06-24 02:45:01.243698
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer has a proper __eq__ method"""

    e1 = IllegalUseOfScopeReplacer("foo", "bar", "gar")
    e2 = IllegalUseOfScopeReplacer("foo", "bar", "gar")
    assert e1 == e2

    e1 = IllegalUseOfScopeReplacer("foo", "bar")
    e2 = IllegalUseOfScopeReplacer("foo", "bar")
    assert e1 == e2

    e1 = IllegalUseOfScopeReplacer("foo", "bar")
    e2 = IllegalUseOfScopeReplacer("foo", "bar", "gar")
    assert e1 != e2

    e1 = IllegalUseOfScopeReplacer("foo", "gar")
    e2 = IllegalUseOfScopeReplacer("foo", "bar")
    assert e1 != e2




# Generated at 2022-06-24 02:45:04.467220
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return the message"""
    name = 'name'
    msg = 'msg'
    extra = 'extra'
    e = IllegalUseOfScopeReplacer(name, msg, extra)
    expected = "IllegalUseOfScopeReplacer object 'name' was used incorrectly:" \
               " msg: extra"
    result = str(e)
    assert result == expected, (result, expected)



# Generated at 2022-06-24 02:45:15.457964
# Unit test for function lazy_import
def test_lazy_import():
    def verify_module(module_dict):
        if not isinstance(module_dict, dict):
            raise AssertionError('not a dict %r' % (module_dict,))
        if '_lazy_import_class' not in module_dict:
            raise AssertionError('not a lazy dict %r' % (module_dict,))
        if len(module_dict) != 1:
            raise AssertionError('too much data in dict %r' % module_dict)
        if module_dict['_lazy_import_class'] is not ImportReplacer:
            raise AssertionError('bad lazy dict %r' % (module_dict,))
    module_dict = {}

# Generated at 2022-06-24 02:45:25.763483
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()

    It should return the expected result when called with expected parameters.

    It should return the expected result when called with unexpected
    parameters.
    """
    # create exception
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # check default message
    assert repr(e) == ("IllegalUseOfScopeReplacer('ScopeReplacer object "
                        "'name' was used incorrectly: msg: extra')")
    # check custom message
    e._fmt = "%(name)s (%(msg)s): %(extra)s"
    assert repr(e) == ("IllegalUseOfScopeReplacer('name (msg): extra')")
    # check error message when custom message can't be constructed
    e._fmt = "I can't say %(anything)s"

# Generated at 2022-06-24 02:45:34.646258
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    try:
        ImportReplacer(None, None, None, None, None)
    except ValueError:
        pass
    else:
        raise AssertionError('None should not be accepted')
    try:
        ImportReplacer(None, None, [], None, {})
    except ValueError:
        pass
    else:
        raise AssertionError('Empty path should not be accepted')
    try:
        ImportReplacer(None, None, ['foo'], None, {})
    except ValueError:
        pass
    else:
        raise AssertionError('None should not be accepted')
    try:
        ImportReplacer(None, None, ['foo'], None, {'bar': None})
    except ValueError:
        pass
    else:
        raise AssertionError('None should not be accepted')

# Generated at 2022-06-24 02:45:41.794218
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Creating a ScopeReplacer should leave a placeholder in scope."""
    scope = {}
    factory = lambda r, scope, name: r._real_obj if r._real_obj else r
    def check_placeholder(r, scope, name):
        if scope[name] is not r:
            raise ValueError("placeholder not found")
    name = 'xyz'
    ScopeReplacer(scope, check_placeholder, name)
    obj = scope[name]
    if obj is not scope[name]:
        raise ValueError("placeholder not found")


# Generated at 2022-06-24 02:45:45.827803
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return unicode object
    that contains only ASCII characters.
    """
    import bzrlib.trace
    try:
        raise IllegalUseOfScopeReplacer('a', 'b')
    except IllegalUseOfScopeReplacer as e:
        bzrlib.trace.note(e)



# Generated at 2022-06-24 02:45:53.017124
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """__init__ must take care of self._fmt."""
    import re
    def test_foo(fmt):
        """Test the IllegalUseOfScopeReplacer constructor with _fmt = fmt."""
        e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
        e._fmt = fmt
        s = str(e)
        # Check that the message contains 'name', 'msg', 'extra' and
        # nothing else.  IllegalUseOfScopeReplacer._fmt should not
        # contain translatable strings.
        if re.search(r'%(name|msg|extra)', fmt):
            raise AssertionError('%s must not contain macros' % fmt)
        for t in ('name', 'msg', 'extra'):
            if not re.search(t, s):
                raise Assertion

# Generated at 2022-06-24 02:46:04.459939
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys

    class FakeModule(object):
        __slots__ = ['__dict__']

        def __init__(self):
            self.__dict__ = {}

    # Let's just do a quick end-to-end test to make sure it basically works
    for imp_str in ['import foo',
                    'import foo, bar',
                    'import foo.bar',
                    'import foo.bar, baz']:
        scope = FakeModule()
        imp = ImportProcessor()
        imp.lazy_import(scope.__dict__, imp_str)

        # Now verify that we've imported correctly
        for path in [ p.strip() for p in imp_str.split(',') ]:
            if ' ' in path:
                name, path = path.split(' ', 1)
            else:
                name = path



# Generated at 2022-06-24 02:46:14.855930
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Here is the docstring for test_IllegalUseOfScopeReplacer___str__."""
    # fiddle the string representation to suit situation
    import bzrlib.lazy_import
    bzrlib.lazy_import.__repr__ = lambda self: 'a scope replacer'

# Generated at 2022-06-24 02:46:21.114634
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ for class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    s = str(e)
    u = unicode(e)
    # The default encoding is UTF-8, so the unicode string
    # should not be able to be decoded
    try:
        s.decode()
    except UnicodeError:
        pass
    else:
        raise AssertionError('{} should not be decodable with UTF-8'.format(s))
    # Test that the unicode string has the same content as the str string
    u.encode('UTF-8').decode('UTF-8') == s



# Generated at 2022-06-24 02:46:30.781472
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test for correct behaviour of method __eq__

    Note: This will not detect regressions in subclasses.  Tests for them are
    needed in their own unit tests.
    """
    class TheException(IllegalUseOfScopeReplacer):
        pass
    class OtherException(IllegalUseOfScopeReplacer):
        _fmt = "OtherFormat%(name)s: %(msg)s"
    def get_new_exc():
        return TheException('name', 'message', 'extra')
    exc1 = get_new_exc()
    exc2 = get_new_exc()
    # Check that the two instances created with the same arguments compare
    # equal.

# Generated at 2022-06-24 02:46:40.927220
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from sys import exc_info
    from bzrlib import trace
    import bzrlib.errors

# Generated at 2022-06-24 02:46:47.339623
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    try:
        raise IllegalUseOfScopeReplacer('foo', 'Get bar')
    except Exception as e:
        assert str(e) == 'Illegal use of foo: Get bar'
        assert repr(e) == "IllegalUseOfScopeReplacer('foo', 'Get bar')"



# Generated at 2022-06-24 02:46:59.175719
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import (errors, osutils, branch, bzrlib)

    def import_module(replacer, scope, name):
        assert replacer._real_obj is None
        module = __import__(name, {}, {}, ['__doc__', '__name__'])
        return module

    lazy_import(locals(), '''
    import bzrlib.branch
    ''')
    assert errors.__doc__ == "errors module"
    assert osutils.__name__ == "bzrlib.osutils"
    assert issubclass(branch.Branch, object)
    assert bzrlib.branch.__name__ == "bzrlib.branch"
# class ScopeReplacer



# Generated at 2022-06-24 02:47:03.139229
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    # __str__ should return a str object
    assert isinstance(s, str)
    # __str__ should return a 'str' object
    assert not isinstance(s, unicode)



# Generated at 2022-06-24 02:47:14.198091
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the constructor of ScopeReplacer to catch bad calls."""
    class MockScope(object):
        def __init__(self):
            self.scopemap = {}

        def __getitem__(self, key):
            return self.scopemap[key]

        def __setitem__(self, key, value):
            self.scopemap[key] = value

    def replacer_factory(replacer, scope, name):
        return replacer

    def new_ScopeReplacer(name, should_fail=False):
        scope = MockScope()
        try:
            sr = ScopeReplacer(scope, replacer_factory, name)
        except TypeError as e:
            if not should_fail:
                raise

# Generated at 2022-06-24 02:47:24.610380
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Not a bzrlib.tests.TestCase as we need to poke on the class
    from bzrlib import tests
    from bzrlib import lazy_import
    import bzrlib.tests
    tests.TestCaseWithMemoryTransport.make_controldir
    tests.TestCaseWithMemoryTransport.make_branch_and_tree
    tests.TestCaseWithMemoryTransport._control_files
    tests.TestCaseWithMemoryTransport.make_branch_builder
    tests.TestCaseWithMemoryTransport.is_branch_path
    tests.TestCaseWithMemoryTransport.make_bzrdir
    tests.TestCaseWithMemoryTransport.make_repository
    tests.TestCaseWithMemoryTransport.is_repository_path
    tests.TestCaseWithMemoryTransport.make_working

# Generated at 2022-06-24 02:47:28.125798
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class Foo(object):
        pass

    foo = Foo()
    def factory(self, scope, name):
        return foo
    scope = {}
    sr = ScopeReplacer(scope, factory, 'foo')
    assert scope['foo'] is sr


# Generated at 2022-06-24 02:47:39.104070
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__class__.__call__(args, kwargs) -> obj"""
    from bzrlib.lazy_import import lazy_import
    import bzrlib

    lazy_import(locals(), """
    from bzrlib.tests import TestCase
    """)

# Generated at 2022-06-24 02:47:42.173383
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = e.__str__()
    assert isinstance(s, str)

# Generated at 2022-06-24 02:47:47.562322
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    factory = lambda t,s,n: t
    name = 'name'
    scope_replacer_instance = ScopeReplacer(scope, factory, name)
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    try:
        scope_replacer_instance.__setattr__('attr', 'value')
    except IllegalUseOfScopeReplacer as e:
        pass

# Generated at 2022-06-24 02:47:50.511528
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    r = IllegalUseOfScopeReplacer('name', 'hi')
    assert repr(r) == "IllegalUseOfScopeReplacer('name', 'hi')"



# Generated at 2022-06-24 02:48:01.793327
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ method of ScopeReplacer can set name correctly.

    Also, make sure that name is not used as a __setattr__ attribute.
    """

    def check_setattr(attr, value):
        def my_object(self, scope, name):
            raise AssertionError("Factory function never gets called")
        scope = {}
        name = 'my_name'
        scope_replacer = ScopeReplacer(scope, my_object, name)
        scope_replacer.__setattr__(attr, value)
    check_setattr('name', 'can_not_set_name')
    check_setattr('_name', 'can_not_set__name')
    check_setattr('__name', 'can_not_set___name')

# Generated at 2022-06-24 02:48:13.078515
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Method __eq__ of class IllegalUseOfScopeReplacer"""
    # Calling object has no attributes.
    obj_01 = IllegalUseOfScopeReplacer(None, None)
    # Calling object has one attribute.
    obj_02 = IllegalUseOfScopeReplacer(None, None)
    setattr(obj_02, 'name', 'name')
    # Calling object has two attributes.
    obj_03 = IllegalUseOfScopeReplacer(None, None)
    setattr(obj_03, 'name', 'name')
    # obj_03 has an extra attribute.
    setattr(obj_03, 'msg', 'msg')
    # Called object has no attributes.
    other_01 = IllegalUseOfScopeReplacer(None, None)
    # Called object has one attribute.

# Generated at 2022-06-24 02:48:23.850681
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import __builtin__
    import sys
    import StringIO
    class MockImporter(object):
        def __init__(self):
            self.imports = {}
        def __call__(self, scope, name, module_path, member, children):
            self.imports[name] = (module_path, member, children)
    # test all "from" imports

# Generated at 2022-06-24 02:48:35.549341
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    processor = ImportProcessor()
    processor.lazy_import(scope=None, text='')
    processor.lazy_import(scope=None, text=' ')
    processor.lazy_import(scope=None, text='\n')
    processor.lazy_import(scope=None, text='# some comment')
    processor.lazy_import(scope=None, text='# some comment\n# another\n')
    processor.lazy_import(scope=None, text='import foo # some comment')
    processor.lazy_import(scope=None, text='import foo as a, bar # some comment')
    processor.lazy_import(scope=None, text='from foo import bar as a, bing, baz')

# Generated at 2022-06-24 02:48:39.734436
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """__init__() returns an IllegalUseOfScopeReplacer object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # conversion to str or unicode should be possible
    unicode(e)
    str(e)


# Generated at 2022-06-24 02:48:47.504058
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """A test for method __eq__ of class IllegalUseOfScopeReplacer"""
    assert IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra') == IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra')
    assert IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra') != IllegalUseOfScopeReplacer(
        'name', 'msg2', 'extra')
    assert IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra') != IllegalUseOfScopeReplacer(
        'name2', 'msg', 'extra')
    assert IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra') != IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra2')



# Generated at 2022-06-24 02:48:58.477105
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit tests for disallow_proxying"""
    def check(parallel):
        disallow_proxying()
        import bzrlib
        lazy_import(globals(), '''
        from bzrlib import (
            errors,
            osutils,
            branch,
            )
        import bzrlib.branch
        ''', parallel=parallel)
        # None of the modules that were lazy-imported should be present in the
        # global scope.
        for module_name in ('errors', 'osutils', 'branch', 'bzrlib.branch'):
            obj = globals()[module_name]
            # Test the proxies - should raise IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:49:01.995011
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    ns = {}
    lazy_import(ns, 'from bzrlib import tests')
    tests.foo = 'bar'
    tests.__class__ = ScopeReplacer
    assert ns['tests'].foo == 'bar'


# Generated at 2022-06-24 02:49:10.667754
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test that IllegalUseOfScopeReplacer can be instantiated"""
    try:
        raise IllegalUseOfScopeReplacer('a', 'b', 'c')
    except IllegalUseOfScopeReplacer as e:
        assert isinstance(str(e), str)
        assert isinstance(unicode(e), unicode)
        assert isinstance(repr(e), str)
        assert isinstance(e.msg, str)
        assert isinstance(e.name, str)
        assert isinstance(e.extra, str)



# Generated at 2022-06-24 02:49:22.674631
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Ensure that the ScopeReplacer executes all its code once."""
    called = []
    def factory(self, scope, name):
        called.append((scope, name))
        return 23
    scope = {}
    replacer = ScopeReplacer(scope, factory, 'name')
    # check that we're replacing the right thing
    assert scope == {'name': replacer}
    # check that we didn't generate replacement yet
    assert replacer._real_obj is None
    # check that the object was generated from the factory
    assert replacer == 23
    assert replacer() == 23
    assert replacer._real_obj == 23
    # check that the factory was called
    assert len(called) == 1
    assert called[0] == (scope, 'name')
    # check that we can use the object freely
    replacer = repl

# Generated at 2022-06-24 02:49:28.356827
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This tests the __unicode__ method of IllegalUseOfScopeReplacer."""
    e = IllegalUseOfScopeReplacer(name='foo', msg='bar')
    assert e.name == 'foo'
    assert e.msg == 'bar'
    assert e.extra == ''
    e.extra = 'extra'
    assert e.extra == ': extra'
    ex = unicode(e)
    assert isinstance(ex, unicode)



# Generated at 2022-06-24 02:49:40.692409
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function

    Note that this is not a complete test of lazy import, but it provides
    a basic sanity check.
    """

    # Note that we are using __name__, because the name that is
    # actually used on the module needs to be a name that will be
    # imported when we call things like 'bzrlib.foo'
    # TODO: For proper testing of lazy_import, we should be able to specify
    #       what the children of 'bzrlib' are. This will allow us to test
    #       the full module path by proxy.
    mod_name = 'bzrlib'
    module = __name__

    class FakeModule(object):
        """This is a fake module for testing"""
        __slots__ = ('__module__',)

# Generated at 2022-06-24 02:49:49.327204
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Testing the initializion of ScopeReplacer"""
    from bzrlib.tests import TestCase
    import sys
    test_scope = dict()
    test_factory = lambda x,y,z : None
    test_name = 'alice'
    test_replacer = ScopeReplacer(
        test_scope,
        test_factory,
        test_name)
    self = test_scope[test_name]
    expected = {'_name': test_name,
                '_real_obj': None,
                '_scope': test_scope,
                '_factory': test_factory}
    self.assertEqual(expected, self.__dict__)


# Generated at 2022-06-24 02:49:51.445259
# Unit test for function disallow_proxying
def test_disallow_proxying():
    ScopeReplacer._should_proxy = True
    disallow_proxying()
    assert ScopeReplacer._should_proxy is False



# Generated at 2022-06-24 02:49:59.072333
# Unit test for method lazy_import of class ImportProcessor

# Generated at 2022-06-24 02:50:10.454691
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():

    # We don't want to proxy access once the object has been replaced in
    # the scope so that we can detect incorrect usage.
    ScopeReplacer._should_proxy = False
    scope = {}

    class Foo(object):
        def __setattr__(self, key, value):
            scope['obj_' + key] = value

        def __getattribute__(self, key):
            if key == '__setattr__':
                # This should prevent 'self.obj' from being replaced.
                return object.__getattribute__(self, key)
            return scope['obj_' + key]

    factory = lambda self, scope, name: Foo()

    # Initialise scope replacer
    scope_replacer = ScopeReplacer(scope, factory, 'foo')

    # Using scope replacer should replace the object in scope
    scope_replacer

# Generated at 2022-06-24 02:50:22.233192
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__(self, other) -> bool

    __eq__ must return the same result as == (equality operator)"""
    from bzrlib.tests import TestCase
    tc = TestCase()
    obj = IllegalUseOfScopeReplacer('myname', 'mymsg', 'myextra')
    # test equal
    tc.assertEqual(obj, obj)
    tc.assertEqual(obj.__dict__, obj.__dict__)
    tc.assertEqual(obj.__eq__(obj), True) 
    tc.assertEqual(obj.__eq__(obj), obj.__eq__(obj))
    tc.assertEqual(obj.__eq__(obj), obj == obj) 
    tc.assertEqual(obj == obj.__dict__, obj == obj.__dict__)
    # test

# Generated at 2022-06-24 02:50:27.657843
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that the arguments passed to __init__ are recorded."""
    obj = {}
    a = ScopeReplacer(obj, None, 'a')
    assert obj is a._scope
    assert a._factory is None
    assert a._name == 'a'
    assert a._real_obj is None

# Original tests for class ScopeReplacer

# Generated at 2022-06-24 02:50:37.257902
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests.blackbox import TestCaseWithTransport

    TestCaseWithTransport.tearDown(self)

    class TestEqException(Exception):
        """A test exception we can easily create."""

        _fmt = 'TestEqException: %(errno)d %(msg)s'

        def __init__(self, errno, msg, extra=None):
            self.errno = errno
            self.msg = msg
            if extra:
                self.extra = ': ' + str(extra)
            else:
                self.extra = ''

    first = TestEqException(2, 'os.error')
    second = TestEqException(2, 'os.error')
    self.assertEqual(first, second)


# Generated at 2022-06-24 02:50:46.643383
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests.blackbox import ExternalBase

    tree = ExternalBase()
    tree.build_tree(['a'])
    tree.run_bzr(['add', 'a'], encoding='ascii')
    tree.run_bzr(['ignore', '-r', 'all', '*'])
    tree.run_bzr(['commit', '-m', 'added one file'])
    output = tree.run_bzr(['log'])[0]
    expected_error = "bzr: ERROR: Unable to log unknown:\n  FileNotFoundError: [Errno 2] No such file or directory: u'unknown'\n"
    tree.assertEqualDiff(expected_error, tree.run_bzr(['log', 'unknown'])[1])
   

# Generated at 2022-06-24 02:50:58.159824
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    loader = bzrlib.lazy_import._ModuleLoader()
    scope = {}
    replacer = bzrlib.lazy_import.ScopeReplacer(
        scope, loader._factory, 'bzrlib')
    # We should be able to see attributes of the object we're replacing
    assert replacer.__class__ is bzrlib.lazy_import.ScopeReplacer
    # We should also be able to see attributes of the class
    assert replacer.__dict__ is bzrlib.lazy_import.ScopeReplacer.__dict__
    # We should be able to see attributes on the object
    assert replacer._scope is scope
    # All these should be the same as the real object.
    bzrlib.lazy_import.lazy_import

# Generated at 2022-06-24 02:51:08.037726
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys

    import breezy.tests.test_import_lazy
    import breezy.trace

    # Test cases

# Generated at 2022-06-24 02:51:20.554265
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Create an ImportProcessor object and test the methods in it.

    Example:
      >>> test_ImportProcessor()

    """
    import_str = "import bzrlib, bzrlib.foo, bzrlib.foo.bar as baz"
    expected = {
        'bzrlib': (['bzrlib'], None,
                   {'foo': (['bzrlib', 'foo'], None,
                            {'bar': (['bzrlib', 'foo', 'bar'], 'baz', {})}),
                    }),
        'baz': (['bzrlib', 'foo', 'bar'], 'baz', {}),
        }

    ip = ImportProcessor()
    ip.lazy_import(globals(), import_str)


# Generated at 2022-06-24 02:51:30.361726
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    def check_children(children, names, values):
        """Asserts that children is {name:value} for each name, value pair."""
        assert len(name_value_pairs) == len(children)
        for name, value in names, values:
            assert children[name] == value
    globals_ = {}
    # Bzr is the module 'bzr', with no children
    Bzr = ImportReplacer(globals_, 'bzr', ['bzr'])
    assert Bzr._import_replacer_children == {}
    assert Bzr._member is None
    assert Bzr._module_path == ['bzr']
    # Branch is a child of bzr, which is a module 'bzr.branch'
    # with no children
    Branch = ImportReplacer

# Generated at 2022-06-24 02:51:40.947089
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer

    The test checks that message contains the __repr__ in case
    other exception raised during __str__.

    The test case uses a class that raises an exception during the
    __str__ call.
    """
    class ExceptionWithBadException(Exception):
        def __str__(self):
            raise Exception('something went wrong')
    try:
        raise ExceptionWithBadException()
    except ExceptionWithBadException:
        e_type, e_value, e_tb = sys.exc_info()
        msg = '%s: %s\n' % (e_type.__name__, e_value)
        for line in traceback.format_tb(e_tb):
            msg += line


# Generated at 2022-06-24 02:51:52.790855
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    if bzrlib.tests.per_module_disabled():
        return
    from bzrlib import lazy_import
    lazy_importer = lazy_import.lazy_import_function
    to_import = '''\
import bzrlib.tests
'''
    namespace = dict(lazy_import=lazy_importer,
                     selftest_module_imports=to_import)
    exec(to_import, namespace)
    # on a freshly imported module, ScopeReplacer should work
    assert namespace['bzrlib'].tests is namespace['bzrlib'].tests

    # But once the module has been replaced, it should work
    assert namespace['bzrlib'].tests is namespace['bzrlib'].tests



# Generated at 2022-06-24 02:52:00.709760
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    import bzrlib.lazy_import as lazy_import
    class ScopeReplacerTest(TestCase):
        """Test for ScopeReplacer"""
        def test_ScopeReplacer___getattribute__(self):
            """Test for ScopeReplacer"""
            locals()
            import sys
            lazy_import.lazy_import(
                locals(), '''
                from bzrlib import errors
                ''', globals())
            # it has loaded
            self.assertTrue('errors' in locals())
            # it is not the module
            self.assertNotEquals(errors, sys.modules.get('bzrlib.errors'))
            # doing something with it will cause it to become the module
            errors.Error("foo")

# Generated at 2022-06-24 02:52:07.886645
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import errors
    ''')
    disallow_proxying()
    try:
        import bzrlib.errors
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Unit test for disallow_proxying failed')



# Generated at 2022-06-24 02:52:16.998900
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import._replace_scope = bzrlib.lazy_import._replace_scope_testing
    bzrlib.lazy_import._replace_scope_testing.r = None
    import bzrlib.errors as ModuleError
    assert ModuleError.r is None, "Module bzrlib.errors should not contain 'r' attribute"
    setattr(ModuleError, 'r', 'value')
    assert bzrlib.lazy_import._replace_scope_testing.r == 'value', "Module bzrlib.errors should contain 'r' attribute"
    delattr(ModuleError, 'r')

# Generated at 2022-06-24 02:52:27.852404
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys, os.path
    scope = {'__file__': 'foo.py',
             '__name__': 'foo.py',
             '__package__': None,
             }
    # Single import
    text = 'import os'
    ip = ImportProcessor()
    ip.lazy_import(scope, text)
    assert scope['os'] is ip.imports['os']
    assert scope['os']._factory is ip._lazy_import_class._import
    assert scope['os']._module_path == ['os']
    # Multiple import
    text = 'import os, sys, os.path'
    ip = ImportProcessor()
    ip.lazy_import(scope, text)
    assert scope['os'] is ip.imports['os']
    assert scope['os']._factory

# Generated at 2022-06-24 02:52:29.796590
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass
### End unit test for method __call__ of class ScopeReplacer



# Generated at 2022-06-24 02:52:35.807173
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import pdb; pdb.set_trace()
    scope = {}
    def factory(self, scope, name):
        def fn():
            return "hello"
        return fn
    name = 'name'
    obj = ScopeReplacer(scope, factory, name)
    assert "hello" == obj()


# Generated at 2022-06-24 02:52:43.401584
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import tests
    import bzrlib.lazy_import
    real_obj = bzrlib.tests.SyntheticObject
    class Foo(Exception):
        pass
    fake_obj = bzrlib.lazy_import.ScopeReplacer(
        {}, lambda SR,scope,name: real_obj, 'real_obj')
    # check that func(args, **kwargs) is delegating to the real_obj
    try:
        fake_obj(5, 'foo', val=3)
    except bzrlib.tests.SyntheticObject as e:
        tests.TestCaseWithTransport.assertEqual(e.args, (5, 'foo'))
        tests.TestCaseWithTransport.assertEqual(e.kwargs['val'], 3)

# Generated at 2022-06-24 02:52:56.443107
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Unit test for method lazy_import of class ImportProcessor"""
    import sys

    text = '''
    import foo
    import foo.bar
    import foo.bar.baz
    import foo.bar.baz.bing, foo.bar.bam as boom
    from foo import bar
    from foo import bar, baz
    from foo import bar, baz as crapp
    from foo.bar import bing
    '''

    p = ImportProcessor()
    p.lazy_import(sys.modules, text)
    # The class itself
    mod_foo = sys.modules['foo']
    assert(mod_foo._import_replacer_children)
    # The first child
    child = mod_foo._import_replacer_children['bar']
    assert(child[2])
    # The child of the child

# Generated at 2022-06-24 02:53:05.336870
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ returns a string that can be eval()'ed to create a copy of the exception"""
    try:
        raise IllegalUseOfScopeReplacer('bzrlib', 'An error has occurred')
    except IllegalUseOfScopeReplacer as e:
        r = repr(e)
    # Check that it returns the right class
    eq = (r.split('(', 1)[0], 'IllegalUseOfScopeReplacer')
    # Check that eval(repr(obj))==obj
    from bzrlib.tests import TestCase
    TestCase.failUnlessEvalEqual(e, r)



# Generated at 2022-06-24 02:53:11.507024
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that the ScopeReplacer constructor takes a scope and substitutes
    an instance of the class in place of the passed variable.
    """
    scope = {}
    scope['foo'] = 42
    sr = ScopeReplacer(scope, lambda _: None, 'foo')
    assert isinstance(scope['foo'], ScopeReplacer)
    assert scope['foo'] is sr
