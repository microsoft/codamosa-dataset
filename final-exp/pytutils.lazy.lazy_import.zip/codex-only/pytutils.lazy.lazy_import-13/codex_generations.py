

# Generated at 2022-06-24 02:43:14.447686
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "%(name)s: %(msg)s"
    e = MyException('foo', 'bar')
    assert str(e) == 'foo: bar'
    assert repr(e) == "MyException('foo', 'bar')"
    assert e.__dict__ == {'name': 'foo', 'msg': 'bar', 'extra': ''}



# Generated at 2022-06-24 02:43:25.781804
# Unit test for function lazy_import
def test_lazy_import():
    # Create a new minimal module
    mod = imp.new_module('_mod')

    # Create an object
    class C(object):
        pass
    mod.C = C
    C_obj = C()

    # Create a test object for later verification
    class _VerifyModule(object):
        pass
    mod.VerifyModule = _VerifyModule
    _TestVerifyModule = _VerifyModule()
    _TestVerifyModule.executed = False
    mod.TestVerifyModule = _TestVerifyModule

    # Create a lazy_import_class which uses the module content, instead of
    # the real module.

# Generated at 2022-06-24 02:43:30.016634
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'message')
    assert(str(e) == 'name: message')
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    assert(str(e) == 'name: message: extra')
    e = IllegalUseOfScopeReplacer('name', 'message', 5)
    assert(str(e) == 'name: message: 5')


# Generated at 2022-06-24 02:43:38.346587
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """This tests the constructor of class ImportProcessor"""

    def check_scope(scope, name, module_path, member, children):
        """Check that the entries in scope match the arguments."""
        # Check that the imported object is a ImportReplacer
        obj = scope[name]
        assert isinstance(obj, ImportReplacer)
        assert obj._module_path == module_path
        assert obj._member == member
        assert obj._import_replacer_children == children

    def check_import(import_map, name, module_path, member, children):
        """Check that the entries in the import map are correct."""
        assert import_map[name] == (module_path, member, children)

    # TODO: jam 20060912 This test needs to be expanded for more
    #       complicated import schemas.
    scope = {}


# Generated at 2022-06-24 02:43:50.041797
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    # Test call of lazy object.
    calls, class_name = 0, 'class_name'
    def scope_func(resolver, scope, name):
        global calls
        calls += 1
        return class_name
    class_name = bzrlib.lazy_import.ScopeReplacer({}, scope_func, class_name)
    class_name()
    class_name()
    class_name()
    if calls != 1:
        raise AssertionError
    # Test call of real object.
    calls = 0
    scope_name = 'scope_name'
    scope_name = bzrlib.lazy_import.ScopeReplacer({}, scope_func, scope_name)
    scope_name()
    scope_name()
    scope_name()
   

# Generated at 2022-06-24 02:43:54.499481
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that the ImportProcessor constructor is sane."""
    import test_server
    import_processor = ImportProcessor(test_server.TestImportReplacer)
    return import_processor


# Generated at 2022-06-24 02:44:01.165118
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    module_path = ['bzrlib', 'foo', 'bar']
    globals = {}
    children = {'baz':(['bzrlib', 'foo', 'bar', 'baz'], None, {})}
    replacer = ImportReplacer(globals, 'bar', module_path, children=children)

    # Check that the object has set itself up correctly
    object.__getattribute__(replacer, '_import_replacer_children') == children
    object.__getattribute__(replacer, '_member') == None
    object.__getattribute__(replacer, '_module_path') == module_path
    assert globals['bar'] is replacer



# Generated at 2022-06-24 02:44:09.446097
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import inspect
    import shutil
    import tempfile

    from bzrlib.tests.test_importing import ImportTestCase

    class ImportableObject(object):
        def __init__(self):
            pass
    
    # A package
    class MultiModulePackage(object):
        pass
    
    # content of package/__init__.py
    PACKAGE_INIT = """
import sys
sys.modules['package'] = sys.modules[__name__]
"""

    # content of package/foo.py
    PACKAGE_FOO = """
import sys
fooobj = object()
sys.modules['package.foo'] = sys.modules[__name__]
"""

    # content of package/foo/__init__.py

# Generated at 2022-06-24 02:44:13.620791
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return 'unicode'."""
    m = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    u = unicode(m)
    if isinstance(u, str):
        raise AssertionError('Should not return str, returned %r' % u)



# Generated at 2022-06-24 02:44:16.703625
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a string that can be evaled"""
    err = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')

# Generated at 2022-06-24 02:44:27.571724
# Unit test for function lazy_import
def test_lazy_import():
    # these tests are designed to exercise the ImportProcessor
    global_state = {}
    other_global_state = {}
    # we should be able to import a basic module
    lazy_import(global_state, 'import bzrlib\n')
    self.assertTrue('bzrlib' in global_state)
    self.assertTrue(isinstance(global_state['bzrlib'], ScopeReplacer))
    # now exercise it
    global_state['bzrlib']._resolve()
    self.assertFalse(isinstance(global_state['bzrlib'], ScopeReplacer))
    self.assertTrue(global_state is other_global_state)
    # make sure that we can handle multiple imports on the same line
    lazy_import(global_state, 'import bzrlib.tests\n')

# Generated at 2022-06-24 02:44:36.777689
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    lazy_import(globals(), '''
from bzrlib.lazy_import import ImportReplacer
''')
    import bzrlib
    # This is tricky because when using __import__, we can't make a
    # fake module. Instead we'll test it as if it was in bzrlib.
    scope = bzrlib.__dict__
    scope['_test_module'] = ImportReplacer(scope=scope, name='_test_module',
        module_path=['bzrlib', '_test_module'])
    from bzrlib import _test_module
    # Now _test_module exists as a real module.
    children = {}
    children['foo'] = (['bzrlib', '_test_module', 'foo'], None, {})

# Generated at 2022-06-24 02:44:45.485187
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-24 02:44:55.868168
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    a_dict = {}
    ImportReplacer(a_dict, 'foo.bar', ['foo', 'bar'], member=None, children={})
    assert len(a_dict) == 1
    assert isinstance(a_dict['foo'], ImportReplacer)


# Expose this function to unit tests, in case they want to disable
# proxying. (Useful for detecting abuse of lazy imports)
lazy_import = ImportReplacer

# TODO: RBC20060707 It would be nice to be able to detect when a lazy
# import has been abused, e.g.
# from bzrlib import errors
# def foo():
#     raise errors.BzrError('foo')
# e = errors.BzrError('bar')
# (the bit we don't like is using the 'errors' from this module as a base

# Generated at 2022-06-24 02:45:02.756998
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ should work"""
    e1 = IllegalUseOfScopeReplacer('var', 'err')
    e2 = IllegalUseOfScopeReplacer('var', 'err')
    assert e1 == e2
    assert (IllegalUseOfScopeReplacer('foo', 'bar')
            != IllegalUseOfScopeReplacer('bar', 'foo'))
    assert (IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
            != IllegalUseOfScopeReplacer('bar', 'foo', 'baz'))
    assert (IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
            != IllegalUseOfScopeReplacer('bar', 'foo', 'boz'))

# Generated at 2022-06-24 02:45:14.118287
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test construction of ImportReplacer"""
    import bzrlib.lazy_import
    bzrlib.lazy_import.ImportReplacer({}, name='foo',
        module_path='foo', member=None, children={})
    bzrlib.lazy_import.ImportReplacer({}, name='foo',
        module_path='foo', member='bar', children={})
    bzrlib.lazy_import.ImportReplacer({}, name='foo',
        module_path='foo', member=None,
        children={'bar':(['foo', 'bar'], None, {})})

# Generated at 2022-06-24 02:45:25.651171
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """test ScopeReplacer.__call__(self, *args, **kwargs)"""
    # Placeholder to simulate object replacement
    class Placeholder(object):
        def __init__(self, *args, **kwargs):
            # __call__ must be defined on the real object, so don't do it
            # here - just pass the args to the parent class.
            super(Placeholder, self).__init__(*args, **kwargs)
    # Object creator
    def creator(placeholder, scope, name):
        return Placeholder('foo', bar='baz')
    # 'globals' matching how it is defined in the module being tested
    scope = {'__name__': 'ScopeReplacer'}
    replacer = ScopeReplacer(scope, creator, 'obj')
    # Once the replacer is called, the real object

# Generated at 2022-06-24 02:45:34.093447
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test for method IllegalUseOfScopeReplacer.__eq__"""
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    e3 = IllegalUseOfScopeReplacer('bar', 'foo')
    assert (e1.__eq__(e2), e2.__eq__(e1)) == (True, True)
    assert (e1.__eq__(e3), e3.__eq__(e1)) == (False, False)



# Generated at 2022-06-24 02:45:43.690242
# Unit test for function lazy_import
def test_lazy_import():
    globs = {}
    lazy_import(globs, '''
        import foo.bar.baz as bing
        import foo.bar.bip
        from foo.bar import bah, bin
        from foo import (
            foo,
            bar,
            )

        import (
            foo,
            bar,
            )
        import bzrlib.branch

        import (
            bzrlib.transport,
            )

        import bzrlib.transport.memory
        import bzrlib.transport.local
        import bzrlib.transport.remote
        from bzrlib import urlutils
    ''')
    # Now we need to actually use the modules to have them initialized.
    #
    # Note that we can't try using .__dict__ because that is a
    # pseudo

# Generated at 2022-06-24 02:45:51.567258
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for the class ScopeReplacer.

    We use a special method for that, because we don't want to call
    lazy_import for a test implementation, because that would create
    a scope-replacer for the filename.
    """
    # define a scope
    scope = {}
    # define a factory
    def factory(self, scope, name):
        scope.foo = "new"
        return "new"
    # create a scope replacer
    scope_replacer = ScopeReplacer(scope, factory, "foo")
    # check the value has been replaced
    assert scope.get("foo") == scope_replacer
    # check the object can be used
    assert scope_replacer == "new"
    # check the real value is in scope
    assert scope.get("foo") == "new"



# Generated at 2022-06-24 02:46:02.481887
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This tests that the method __str__ of IllegalUseOfScopeReplacer actually
    returns a str object, because the __str__ method of an exception is
    required to return a str and not a unicode object as __unicode__ does.

    To test that, we use the StringIO function.
    """
    from cStringIO import StringIO
    import sys
    sio = StringIO()
    exc = IllegalUseOfScopeReplacer('foo', 'bar')
    e_type, e_value, e_tb = sys.exc_info()

    # This is what sys.excepthook does internally, except that it prepends
    # the traceback with the filename and line number (here
    # '<string>, line 1'.
    sys.excepthook(e_type, e_value, e_tb)
   

# Generated at 2022-06-24 02:46:13.398373
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """ScopeReplacer constructor"""
    def opener(dummy, scope, name):
        scope[name] = name
        return name

    scope = {'scope': scope}
    name = 'name'
    scope_replacer = ScopeReplacer(scope, opener, name)
    # Should not be replaced yet
    if scope_replacer is not name:
        raise AssertionError("Should not have been replaced yet")
    # Verify that an exception is raised if we try to access members without
    # proxy.
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-24 02:46:15.531029
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import sys
    name = 'ScopeReplacerTestName'
    obj = ScopeReplacer(sys.modules[__name__].__dict__, lambda *args: args[0],
                        name)
    assert obj._name == name
test_ScopeReplacer()



# Generated at 2022-06-24 02:46:21.975473
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Creating ImportReplacer objects should work correctly"""
    scope = {}
    # ImportReplacer(scope, name, module_path, member=None, children={})
    ImportReplacer(scope, 'foo', ['foo'], children={'bar':(['foo', 'bar'],
                                                           None, {})})
    ImportReplacer(scope, 'foo', ['foo'], children={'bar':(['foo', 'bar'],
                                                           None, {})})

    ImportReplacer(scope, 'foo', ['foo'], member='bar')
    ImportReplacer(scope, 'foo', ['foo'], member='bar')

    ImportReplacer(scope, 'foo', ['foo'], )
    ImportReplacer(scope, 'foo', ['foo'], )



# Generated at 2022-06-24 02:46:26.247188
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class X(object):
        def __call__(self, foo, bar):
            return (foo, bar)
    x = X()
    replacer = ScopeReplacer(locals(), lambda self, scope, name: x, 'x')
    assert (32, 'ham') == replacer(32, 'ham')



# Generated at 2022-06-24 02:46:32.957202
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that the ScopeReplacer actually works.

    This is a bit contrived, but we can't really check that the lazy loading
    itself works correctly, because we do not know what we might lazy load,
    and what their __init__ or __call__ or __getattr__ might do. Rather, we
    just check that the immediate actions are correct.
    """

    class Foo(object):
        pass
    class Bar(object):
        pass
    class Baz(object):
        pass
    class TInn(object):
        pass
    class TRes(object):
        pass


# Generated at 2022-06-24 02:46:39.027490
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test for ImportProcessor

    It is important to test the constructor of this class.
    """
    i = ImportProcessor()
    assert i._lazy_import_class is ImportReplacer

    class TestReplacer(ScopeReplacer):
        def __init__(self, *args):
            ScopeReplacer.__init__(self, *args)

    i = ImportProcessor(TestReplacer)
    assert i._lazy_import_class is TestReplacer


# Generated at 2022-06-24 02:46:48.263400
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    e3 = IllegalUseOfScopeReplacer('foo', 'bar', extra=e1)
    e4 = IllegalUseOfScopeReplacer('foo', 'bar', extra=e2)
    assert e1 == e2
    assert e1 != e3
    assert e3 == e4
    assert str(e1) == 'bar'
    assert str(e2) == 'bar'
    assert str(e4) == 'bar: bar'



# Generated at 2022-06-24 02:47:00.200567
# Unit test for function lazy_import
def test_lazy_import():
    """Unit tests for lazy_import helper function."""
    import bzrlib
    # Process just a normal import
    lazy_import(globals(), '''
    import bzrlib''')
    assert 'bzrlib' in globals()
    assert bzrlib is bzrlib

    # Process import with children
    lazy_import(globals(), '''
    import bzrlib.foo.bar''')
    assert 'bzrlib' in globals()
    assert bzrlib.foo.bar is bzrlib.foo.bar
    assert 'bzrlib' not in dir(bzrlib)

    # Process from imports
    lazy_import(globals(), '''
    from bzrlib.foo import bar''')
    assert 'bar' in globals()
   

# Generated at 2022-06-24 02:47:07.486548
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer"""
    # test_repr is a bit flakey as we don't know what version of python we're
    # running in. But this is the basic contract we should check for. We can
    # use repr() if we want to check the full repr, but it is more stable to
    # check this part.
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert str(e) == "'bar', extra='baz'"



# Generated at 2022-06-24 02:47:16.930486
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        foo = 'foo'

    class Bar(Foo):
        bar = 'bar'

    class Baz(Foo):
        baz = 'baz'

    class LazyFoo(ScopeReplacer):
        def __init__(self):
            ScopeReplacer.__init__(self, dict(globals()), LazyFoo.factory, 'x')

        @staticmethod
        def factory(replacer, scope, name):
            if name == 'x':
                return Foo()
            else:
                return Bar()

    class LazyBar(ScopeReplacer):
        def __init__(self):
            ScopeReplacer.__init__(self, dict(globals()), LazyBar.factory, 'z')


# Generated at 2022-06-24 02:47:23.674985
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # ScopeReplacer.__setattr__(self, attr, value)
    # test that when the scope replacer is called before the class
    # has been created, an exception is thrown
    # test that when the scope replacer is called before the class has
    # been created, an exception is thrown.
    from bzrlib import errors

    def test(namespace, original_module_name, original_attr_name):
        """Helper function to simplify test code"""
        lazy_import(namespace, '''
        from bzrlib import (
            errors,
            )
        ''')
        # Ensure the actual bzrlib.errors is not used
        import bzrlib
        old_errors = bzrlib.errors

# Generated at 2022-06-24 02:47:26.934885
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer constructor.

    Even though it is possible to supply member and children, this should
    never happen.
    """
    import bzrlib
    e = ImportReplacer(scope=bzrlib.__dict__, name='bzrlib',
                       module_path=['bzrlib'], member=None,
                       children={'errors': (['bzrlib',
                                            'errors'], None, {})})



# Generated at 2022-06-24 02:47:36.011311
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() -> str

    __str__() must return a str object, never a unicode object.
    """
    # This test doesn't need bzrlib.i18n to test IllegalUseOfScopeReplacer
    # because it doesn't want to test internationalization.
    # If gettext() is used, it should be used with unicode strings.

    def _test(str, expected):
        # This function is a helper for other tests.
        e = IllegalUseOfScopeReplacer(str, str)
        got = str(e)

# Generated at 2022-06-24 02:47:46.317201
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # test normal style imports, with as clauses
    new_map = {}
    lazy_import_class = lambda scope, name, module_path, member, children: new_map.__setitem__(name, (module_path, member, children))
    importer = ImportProcessor(lazy_import_class)
    importer.lazy_import(None,
        """import foo.bar, foo.baz as baz, quux as quuz""")
    expected = {'foo': (['foo'], None,
        {'bar': (['foo', 'bar'], None, {}),
         'baz': (['foo', 'baz'], None, {})}),
        'quux': (['quux'], None, {})}
    new_map == expected
    new_map = {}
    importer.lazy

# Generated at 2022-06-24 02:47:49.853127
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ compares instances"""
    assert IllegalUseOfScopeReplacer("name", "msg") == \
           IllegalUseOfScopeReplacer("name", "msg")




# Generated at 2022-06-24 02:47:53.102100
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests.lazy_import import TestCaseWithLazyImport
    TestCaseWithLazyImport.disallow_proxying()



# Generated at 2022-06-24 02:48:03.314208
# Unit test for function disallow_proxying
def test_disallow_proxying():
    def get_foo():
        return 42
    # The following should be safe even in multithreaded environments
    globals()['foo'] = ScopeReplacer(globals(), get_foo, 'foo')
    value = foo
    try:
        disallow_proxying()
        try:
            # Accessing foo after disallow proxy will raise an exception
            value = foo
        except Exception:
            # Let any exception pass.
            pass
        else:
            raise AssertionError("Access to lazy import was not"
                                 " detected after disallow_proxying()"
                                 " was called")
    finally:
        ScopeReplacer._should_proxy = True
    # After re-enabling, any access to foo should be fine
    value = foo
    # And the value should be 42
    assert value == 42




# Generated at 2022-06-24 02:48:09.774305
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert 'ScopeReplacer' in str(e)
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    assert e == e2
    # different objects should compare unequal
    e3 = IllegalUseOfScopeReplacer('name2', 'msg')
    assert e != e3



# Generated at 2022-06-24 02:48:17.768906
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Create a replacer to import foo
    scope = {}
    ImportReplacer(scope, module_path=['foo'], name='foo')
    # Check that it imported its own module
    import foo
    assert scope['foo'] is foo

    # Create a replacer to import foo.bar.baz
    scope = {}
    ImportReplacer(scope, module_path=['foo', 'bar', 'baz'], name='baz')
    # Check that it imported its own module
    import foo.bar.baz
    assert scope['baz'] is foo.bar.baz

    # Create a replacer to import foo.bar.baz.bang
    # This must be a child of the previous object.
    scope = {}

# Generated at 2022-06-24 02:48:30.179636
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import unittest
    from __main__ import bzrlib

    class TestReplacer(object):

        def __init__(self, scope, name, module_path, member=None, children={}):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children

        def __repr__(self):
            return ("<Replacer scope=%r, name=%r, module_path=%r, member=%r, "
                    "children=%r>" % (
                    self.scope, self.name, self.module_path, self.member,
                    self.children))

    class TestImportProc(ImportProcessor):
        def __init__(self):
            self.test_replaced_

# Generated at 2022-06-24 02:48:40.688863
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing IllegalUseOfScopeReplacer.__str__"""
    import sys
    import traceback

    error = IllegalUseOfScopeReplacer('foo', 'bar')
    error._fmt = 'ScopeReplacer object %(name)r was used incorrectly: %(msg)s'
    # If traceback is used to format exceptions the output is not compatible
    # with both Python versions. Use the exceptions internal formatting.
    tb = sys.exc_info()[2]
    try:
        exc = traceback.format_exception_only(error.__class__, error)
    finally:
        del tb
    exc.append('Traceback (most recent call last):\n')
    exc.extend(traceback.format_list(traceback.extract_stack()))

# Generated at 2022-06-24 02:48:42.742008
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer("foo", "bar", "baz")
    assert str(e) == "'foo' was used incorrectly: bar: baz"


# Generated at 2022-06-24 02:48:48.740426
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method __eq__ of class bzrlib.lazy_import.IllegalUseOfScopeReplacer"""
    try:
        raise IllegalUseOfScopeReplacer('a', 'b', 'c')
    except Exception as e:
        e2 = e
    assert e == e2
    # Test the class equality
    assert type(e) is type(e2)
    try:
        raise IllegalUseOfScopeReplacer('a', 'b', 'd')
    except Exception as e:
        e3 = e
    assert e != e3



# Generated at 2022-06-24 02:48:56.119539
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ converts the class into string format.

    This is done by calling __str__ for all attributes in dict API
    and then formatting the result using a format string.
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    expected = "ScopeReplacer object 'name' was used incorrectly: msg: extra"
    assert s == expected



# Generated at 2022-06-24 02:49:03.370375
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    assert e1 == e2, "Instances with identical member values should be equal"
    e3 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e1 != e3, "Instances with unequal member values should not be equal"
    e4 = IllegalUseOfScopeReplacer('Name', 'Msg')
    assert e1 != e4, "Instances with unequal member values should not be equal"



# Generated at 2022-06-24 02:49:04.370425
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()

# Generated at 2022-06-24 02:49:12.787904
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """ScopeReplacer should work as expected"""
    globs = {}
    name = 'foo'
    factory = lambda self: self
    r = ScopeReplacer(globs, factory, name)
    e = IllegalUseOfScopeReplacer(name, msg='Object tried to replace itself, '
                                  'check it\'s not using its own scope.')

# Generated at 2022-06-24 02:49:17.873780
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.tests.blackbox
    bzrlib.tests.blackbox.selftest_command.run_external_tests(
        "bzrlib.tests.blackbox.test_lazy_import."
        "test_lazy_import", # Left out "test" to avoid test discovery
        )

# Generated at 2022-06-24 02:49:22.674866
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return str object"""
    e = IllegalUseOfScopeReplacer("abc", "message")
    assert isinstance(str(e), str), "str is not an str"



# Generated at 2022-06-24 02:49:32.909301
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():

    from bzrlib.tests.test_errors_looming import TestCaseWithTransport

    class TestError(IllegalUseOfScopeReplacer):
        pass

    class TestError2(IllegalUseOfScopeReplacer):
        pass

    class TestCase(TestCaseWithTransport):
        def setUp(self):
            TestCaseWithTransport.setUp(self)
            self.error = TestError('foo', 'bar')

        def test_eq(self):
            self.assertEqual(self.error, TestError('foo', 'bar'))

        def test_not_eq(self):
            self.assertNotEqual(self.error, TestError('foo', 'bar', 'extra'))
            self.assertNotEqual(self.error, TestError('foo', 'bar', []))
            self.assertNotE

# Generated at 2022-06-24 02:49:45.653396
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    globals_dict = {}
    ImportReplacer(globals_dict, name='a', module_path=['a'],
                   member=None, children={})
    ImportReplacer(globals_dict, name='a', module_path=['a'],
                   member='b', children={})
    ImportReplacer(globals_dict, name='a', module_path=['a', 'c'],
                   member='d', children={})
    from bzrlib.tests import TestUtil

# Generated at 2022-06-24 02:49:55.749301
# Unit test for function lazy_import
def test_lazy_import():
    """This provides unit tests for the lazy_import function"""

    import sys
    # This is our test-only mockup module
    class Mockup(object):
        """This is a mockup object we return as the imported object"""

        __slots__ = ['module_path']

        def __init__(self, module_path):
            self.module_path = module_path

    # This is our test-only mockup scope
    class _MockupScope(object):

        __slots__ = ['__dict__']

        def __init__(self, **kw):
            self.__dict__ = kw

    # This is used to make sure that the replacements happen in the actual
    # scope that the user expects.
    class _MockupScopeProxy(object):

        __slots__ = ['__dict__', '_scope']

# Generated at 2022-06-24 02:50:04.989965
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    try:
        x = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    except TypeError:
        # old version of python
        pass
    else:
        raise Exception('%r should be raise TypeError' % x)
    x = IllegalUseOfScopeReplacer('foo', 'msg', extra='extra')

    # test that unicode(x) works
    unicode(x)
    # test that str(x) works
    str(x)
    # test that repr(x) works
    repr(x)



# Generated at 2022-06-24 02:50:13.071325
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Test normal constructor of ImportReplacer
    scope = {}
    cls = ImportReplacer(scope, name='foo', module_path=['foo'],
                         children={'inner': (['foo', 'inner'], None, {})})
    # Nothing should have been created yet
    assert scope == {}
    assert not cls._import_replacer_children
    assert cls._member is None
    assert cls._module_path == ['foo']

    # Test scope, name, and module_path construction
    scope = {'foo': 'foo'}
    new_cls = ImportReplacer(scope, name='foo', module_path=['foo'],
                             children={})
    assert new_cls._module_path == ['foo']
    assert new_cls._member is None
    assert new_cls._import_

# Generated at 2022-06-24 02:50:17.217000
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib          # delay import of module bzrlib, bzrlib.tests
    bzrlib.tests = None    # suppress a function definition/class definition,


# Generated at 2022-06-24 02:50:20.800548
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    d = {}
    ScopeReplacer(d, lambda self, scope, x: scope[x] + 1, 'value')
    d['value'] = 5
    assert d['value'] == 6
test_ScopeReplacer()



# Generated at 2022-06-24 02:50:29.819532
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer should return a unicode object

    """
    x = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    u = unicode(x)
    assert isinstance(x, unicode)
    # Test that the unicode object has the correct contents
    s = u"ScopeReplacer object 'name' was used incorrectly: msg: extra"
    assert u == s
    # Test that we can decode to the original string
    s = s.encode('utf8')
    assert str(x) == s


# Generated at 2022-06-24 02:50:38.463526
# Unit test for function lazy_import
def test_lazy_import():
    """Tests that lazy_import works as documented"""
    import sys
    import bzrlib.errors

    # Check that the tests pass without doing anything special with
    # ImportReplacer.
    import bzrlib.tests
    assert bzrlib.tests is sys.modules['bzrlib.tests']

    # Now check that imports work as expected.
    from bzrlib.lazy_import import ImportReplacer
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        tests,
        )
    import bzrlib.branch
    import bzrlib.transport
    ''')
    # Check that we are now using ImportReplacer
    assert isinstance(errors, ImportReplacer)
    assert isinstance(tests, ImportReplacer)

# Generated at 2022-06-24 02:50:41.299384
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    globals = {}
    ImportReplacer(globals, 'foo', ['bzrlib', 'foo'], None,
                   {'bar':(['bzrlib', 'foo', 'bar'], None, {})})
    ImportReplacer(globals, 'bar', ['bzrlib', 'foo', 'bar'], 'bar', {})

# Generated at 2022-06-24 02:50:48.616684
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    import_processor.lazy_import({}, text="""
        import bzrlib
        import bzrlib.bzrdir
        import bzrlib.bzrdir as dir
        from bzrlib import errors
        from bzrlib import foo
        from bzrlib.bzrdir import BzrDir
        from bzrlib.bzrdir import BzrDirLock
        """)


# Generated at 2022-06-24 02:50:59.647218
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    # Test the old-style exception message format
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._fmt = '%(name)s: %(msg)s%(extra)s'
    result = str(e)
    expected = 'foo: bar: baz'
    assert result == expected
    result = repr(e)
    expected = "IllegalUseOfScopeReplacer('foo', 'bar', 'baz')"
    assert result == expected

    # Test the new-style exception message format, with null encoding
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._fmt = u'' # force unicode
    result = str(e)

# Generated at 2022-06-24 02:51:07.632596
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for constructor of class ScopeReplacer"""
    # test creating a ScopeReplacer object, and it replacing itself
    # when accessed
    import sys
    import bzrlib
    def _factory(self, scope, name):
        # The factory gets passed the ScopeReplacer object, which
        # must not be returned - it's an error if the factory returns
        # self.
        return sys.modules[__name__]
    # This test demonstrates that you can have the same module imported
    # in two separate namespaces.
    def _factory2(self, scope, name):
        return bzrlib
    class TotalFailure(Exception):
        """Exception for when test fails."""

# Generated at 2022-06-24 02:51:20.181032
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.errors import BzrError
    from bzrlib.errors import errors_module
    from cStringIO import StringIO
    errors_module._fmt = '%(msg)s'
    outf = StringIO()
    def run(test_method):
        def run_test(self):
            try:
                import bzrlib.lazy_import as lazy_import
                # disable tracing while we execute the test method to
                # avoid flooding the trace with expected exceptions
                lazy_import.ScopeReplacer._should_proxy = True
                test_method(self)
            finally:
                lazy_import.ScopeReplacer._should_proxy = False
        run_test.__name__ = test_method.__name__
        return run_

# Generated at 2022-06-24 02:51:26.229639
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer Object"""
    # Only light testing is done here, as the code is actually used in
    # 'lazy_import' and has full test coverage there.
    scope = {}
    ImportReplacer(scope, name='foo', module_path=['foo'])
    ImportReplacer(scope, name='foo', module_path=['foo'], member='bar')



# Generated at 2022-06-24 02:51:29.031557
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test constructor in ImportProcessor class."""
    import_processor = ImportProcessor()
    assert isinstance(import_processor.imports, dict)
    assert import_processor._lazy_import_class == ImportReplacer



# Generated at 2022-06-24 02:51:34.433778
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def factory(self, scope, name):
        return 'the real obj'
    sr = ScopeReplacer(globals(), factory, 'test_ScopeReplacer___call__')
    eq = testtools.TestCase.assertEqual
    # A ScopeReplacer('test_ScopeReplacer___call__') is created here.
    # The __call__ method of that ScopeReplacer object has not been called yet
    eq('test_ScopeReplacer___call__', 'test_ScopeReplacer___call__')

    # Now the call to 'self' - i.e. the placeholder object - will
    # trigger the _resolve() call, and the real object will be returned
    # for the call and for attributes.
    eq('the real obj', sr())
    eq('the real obj', sr.lolcat)


# Generated at 2022-06-24 02:51:35.549852
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    raise NotImplementedError



# Generated at 2022-06-24 02:51:45.645639
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that ImportReplacer constructs what it should"""
    module_root = {}
    ImportReplacer(module_root, name='foo', module_path=['foo'],
                   member=None, children={})
    try:
        ImportReplacer(module_root, name='foo', module_path=['foo'],
                       member='bar', children={})
        raise AssertionError('Should not be able to mix members and children')
    except ValueError:
        pass
    try:
        ImportReplacer(module_root, name='foo', module_path=['foo'],
                       member='bar', children={})
        raise AssertionError('Should not be able to mix members and children')
    except ValueError:
        pass
    assert len(module_root) == 1
    replacer = module_root['foo']

# Generated at 2022-06-24 02:51:52.167061
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test that IllegalUseOfScopeReplacer has the correct constructor"""
    r = IllegalUseOfScopeReplacer('foo', 'bar', 'spam')
    assert (r.name == 'foo'
            and r.msg == 'bar'
            and r.extra == ': spam'), (r.name, r.msg, r.extra)

# End of class IllegalUseOfScopeReplacer definitions



# Generated at 2022-06-24 02:52:00.404108
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import sys

    # Simple test with one function
    def func(x, y):
        return x + y

    lazy_import(sys.modules[__name__].__dict__,
                'from bzrlib.tests import test_scope_replacer')
    test_scope_replacer.func(1, 2)
    x = test_scope_replacer.func
    assert x(1, 2) == 3

    # Simple test with one class
    class MyClass(object):
        def func(self, x, y):
            return x + y

    lazy_import(sys.modules[__name__].__dict__,
                'from bzrlib.tests import test_scope_replacer')
    test_scope_replacer.MyClass().func(1, 2)
    x = test_scope_replacer.My

# Generated at 2022-06-24 02:52:12.144997
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    raiser = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    f = raiser._get_format_string
    assert f() is None
    raiser._fmt = u'%(name)s'
    assert f() == u'%(name)s'
    del raiser._fmt
    assert f() is None
    raiser._fmt = '%(name)s'
    assert f() == '%(name)s'
    assert f() == '%(name)s' # check that gettext is not called twice
    raiser._fmt = u'%s'
    assert f() == u'%s'
    assert f() == u'%s'
    raiser._fmt = u'%(msg)s'
    assert f() == u'%(msg)s'



# Generated at 2022-06-24 02:52:21.840019
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a representation string for the exception"""
    import re
    e = IllegalUseOfScopeReplacer(1, 2)
    assert isinstance(e.__repr__(), str)
    # there must be the correct class name
    assert re.match('^<class .*IllegalUseOfScopeReplacer at .*>$',
                    e.__class__.__repr__()) is not None
    assert e.__class__.__name__ in e.__repr__()
    # there must be the arguments in the result
    assert e.name in e.__repr__()
    assert str(e.msg) in e.__repr__()


# Generated at 2022-06-24 02:52:29.814030
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__ is a classmethod
    assert_raises(TypeError, ScopeReplacer.__setattr__)
    # what happens if we access an attr before the object has been resolved?
    def set_attr(lazy_obj, attr, val):
        setattr(lazy_obj, attr, val)
    actual_obj = []
    class FakeScope(object):
        def __setitem__(self, name, obj):
            actual_obj.append(obj)
    lazy_obj = ScopeReplacer(FakeScope(), lambda obj, scope, name: [], 'name')
    lazy_obj._should_proxy = False
    assert_raises(IllegalUseOfScopeReplacer, set_attr, lazy_obj, 'attr', 'val')
    # and once it's resolved ?
    lazy_obj._should

# Generated at 2022-06-24 02:52:40.828844
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    # Catching this class is the only way that an IllegalUseOfScopeReplacer can
    # be known to have been raised, so the equality tests should be completely
    # faithful.
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    assert e1 == e2
    e3 = IllegalUseOfScopeReplacer(1, 2)
    assert e3 != e1
    e4 = IllegalUseOfScopeReplacer('foo', 'bar', extra='baz')
    assert e4 != e1
    e5 = IllegalUseOfScopeReplacer('foo', 'bar', extra=1)
    assert e5 != e1
test_IllegalUseOfScopeReplacer___eq__.__test__ = False



# Generated at 2022-06-24 02:52:49.741430
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit tests for function disallow_proxying()."""
    def _dummy_factory(replacer, scope, name):
        return None
    import sys
    orig_should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-24 02:52:53.196331
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('test', 'illegal', 'extra')
    assert e.extra == ': extra'
    assert e.name == 'test'
    assert e.msg == 'illegal'



# Generated at 2022-06-24 02:53:01.371844
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib.tests import TestCase
    from bzrlib import tests
    import sys

    class TestImportProcessor(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            self.processor = ImportProcessor()

        def test_import_processor_import_str(self):
            import_str = 'import foo, foo.bar, foo.bar.baz as bing'
            self.processor._convert_import_str(import_str)

# Generated at 2022-06-24 02:53:12.527990
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.tests.blackbox.test_lazy_import as blackbox
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # TODO(jelmer): This is unused by anything.
    # No bug reported.
    # No bug reported.    
    scope_replacer = ScopeReplacer(blackbox.globals, blackbox.lazy_import,
                                   'ScopeReplacer')
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
    # No bug reported.
