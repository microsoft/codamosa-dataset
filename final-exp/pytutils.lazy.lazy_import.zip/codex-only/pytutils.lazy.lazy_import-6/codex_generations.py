

# Generated at 2022-06-24 02:43:15.727804
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib.tests
    def import_a(scope_replacer, scope, name):
        import bzrlib.tests.blackbox.a as a_module
        return a_module
    def import_b(scope_replacer, scope, name):
        import bzrlib.tests.blackbox.b as b_module
        return b_module
    test_str = bzrlib.tests.blackbox.test_str
    a = ScopeReplacer(globals(), import_a, 'a')
    b = ScopeReplacer(globals(), import_b, 'b')
    disallow_proxying()
    test_str(test_a_b, 2, bzrlib.tests.blackbox.test_str(test_a, 1, a.test_a))



# Generated at 2022-06-24 02:43:24.333604
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying() works as documented."""
    lazy_import(globals(), 'bzrlib.lazy_import')
    # The next import should be allowed.
    lazy_import(globals(), 'bzrlib.errors')
    disallow_proxying()
    # The next import should be forbidden.
    lazy_import(globals(), 'bzrlib.errors')
    # But not if it happens in a new scope
    try:
        exec("lazy_import(globals(), 'bzrlib.errors')")
    except ImportError:
        # New scope, so no problem
        pass
    else:
        raise TestNotApplicable("Error was not raised in new scope.")



# Generated at 2022-06-24 02:43:33.543007
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import turns a text blob into real objects

    This test is also slightly odd, because it is testing the
    ImportProcessor class as well.
    """
    import sys
    class Imports(dict):
        def __init__(self, *args, **kwargs):
            dict.__init__(self, *args, **kwargs)
            self.imported = 0

        def __getattribute__(self, name):
            self.imported += 1
            return dict.__getattribute__(self, name)

    imported = Imports()
    lazy_import(imported,
        'from bzrlib.lazy_import import (ImportProcessor, ImportReplacer,\n'
        '    lazy_import)')

    assert imported.imported == 0

# Generated at 2022-06-24 02:43:39.640836
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import testtools
    lazy_import(globals(), '''
    import bzrlib.lazy_import
    ''')
    bzrlib.lazy_import.disallow_proxying()
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        )
    ''')
    testtools.failUnlessRaises(bzrlib.lazy_import.IllegalUseOfScopeReplacer, getattr, errors, 'BzrError')
# End unit test

# Generated at 2022-06-24 02:43:51.845004
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer class"""
    import sys
    # Create a new scope specifically for this test
    test_scope = sys.modules.copy()
    # And create the initial object
    import_replacer = ImportReplacer(scope=test_scope, name='bzrlib',
        module_path=['bzrlib'], member=None, children={})
    # Now trigger the import
    obj = test_scope['bzrlib']
    # Finally check the resulting object
    assert obj is bzrlib, "Expected %r, got %r" % (bzrlib, obj)
    assert test_scope['bzrlib'] is bzrlib, "Wrong value in scope"
    assert 'bzrlib' in test_scope, "Expected 'bzrlib' in scope"


   

# Generated at 2022-06-24 02:43:58.362152
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'spam')
    assert e.name == 'foo'
    assert e.msg == 'bar'
    assert e.extra == ': spam'
    assert repr(e) == "IllegalUseOfScopeReplacer('foo', 'bar', 'spam')"



# Generated at 2022-06-24 02:44:08.493076
# Unit test for function lazy_import
def test_lazy_import():
    global foo, bar, quux
    global bzrlib
    foo = bar = quux = bzrlib = None

    def check_foo():
        # None of the following should raise an error
        global foo, bar, quux
        global bzrlib
        bzrlib.foo
        bzrlib.bar
        bzrlib.quux
        foo
        bar
        quux

    exc_info = None

# Generated at 2022-06-24 02:44:16.616853
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer objects return unicode"""
    global IllegalUseOfScopeReplacer
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = 'A %(msg)s exception'
    e = MyException('name', 'msg')
    assert isinstance(e, Exception)
    assert isinstance(e, IllegalUseOfScopeReplacer)
    assert isinstance(e.__unicode__(), unicode), type(e.__unicode__())
    assert isinstance(e.__unicode__(), basestring)
    assert isinstance(unicode(e), unicode)
    assert isinstance(unicode(e), basestring)

# Generated at 2022-06-24 02:44:27.542152
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test cases for ScopeReplacer"""
    def make_scope(**locals):
        f = lambda: None

# Generated at 2022-06-24 02:44:34.650892
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys as scope
    class Mock(object):
        def __setattr__(self, attr, value):
            if attr == 'illegal':
                raise IllegalUseOfScopeReplacer(attr, 'fake message')
            object.__setattr__(self, attr, value)
    def factory(self, scope, name):
        return Mock()
    name = 'mock'
    repl = ScopeReplacer(scope, factory, name)
    scope['mock'] = repl
    scope['mock'].foo = 'bar'

test_ScopeReplacer___setattr__()



# Generated at 2022-06-24 02:44:38.584344
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor

    The constructor should not accept arguments.
    """
    try:
        ImportProcessor(object())
    except TypeError:
        pass
    else:
        raise AssertionError("ImportProcessor should not accept args")



# Generated at 2022-06-24 02:44:45.784006
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:44:53.942114
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str not a unicode"""
    e = IllegalUseOfScopeReplacer(None, "abc")
    assert isinstance(str(e), str)
    assert type(str(e)) is str
    assert isinstance(unicode(e), unicode)
    assert type(unicode(e)) is unicode
    
try:
    unicode
except NameError:
    # python 3 doesn't have unicode()
    def unicode(value, *args, **kwargs):
        return str(value)

_scope_replacer_counter = 0


# Generated at 2022-06-24 02:44:58.565388
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.tests
    bzrlib.tests.prove_method(lazy_import, 'ScopeReplacer')



# Generated at 2022-06-24 02:45:08.895045
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    # Simple test with all defaults:
    import sys
    def assert_string(expected_string, exception):
        s = exception.__str__()
        if s != expected_string:
            raise AssertionError('expected string %r, got %r'
                % (expected_string, s))

    if sys.platform == 'win32':
        eol = '\r\n'
    else:
        eol = '\n'

    assert_string(
        'Unprintable exception IllegalUseOfScopeReplacer: dict={}, '
        'fmt=None, error=None',
        IllegalUseOfScopeReplacer(None, None))


# Generated at 2022-06-24 02:45:18.313785
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def check(name):
        def mock_getattribute(obj, name):
            # Test that calls do not use obj.__getattribute__() directly,
            # as it is overridden on this class.
            raise ValueError("Calling __getattribute__ directly on obj")
        sr = ScopeReplacer(scope={}, factory=None, name=name)
        # Test that illegal use of sr is detected
        sr._real_obj = sr
        # Patch object.__getattribute__ so that it detects if we use obj
        # directly, which we should not.
        object.__getattribute__orig = object.__getattribute__
        object.__getattribute__ = mock_getattribute

# Generated at 2022-06-24 02:45:27.117482
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that lazy_import doesn't proxy (imported) modules."""
    import bzrlib
    import bzrlib.workingtree
    # The lazy_import mechanism assumes that the objects imported
    # will be treated as read-only, so it usually proxies access
    # to the replaced objects. That is, x = y will work to access
    # members in y for as long as y is a scope replacer.
    # But to check for wasteful indirection, it is possible to
    # disallow that behavior.
    from bzrlib.lazy_import import lazy_import, disallow_proxying
    disallow_proxying()
    lazy_import(bzrlib, 'bzrlib.workingtree')

# Generated at 2022-06-24 02:45:33.884083
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:45:44.203008
# Unit test for function lazy_import
def test_lazy_import():
    """Unit tests for function lazy_import"""

    # Simple test
    scope = {}
    lazy_import(scope, 'from bzrlib import foo; import bzrlib.bar')
    assert 'foo' in scope
    assert 'bar' in scope
    assert not isinstance(scope['foo'], ImportReplacer)
    assert not isinstance(scope['bar'], ImportReplacer)

    # Test with children
    scope = {}
    lazy_import(scope, 'from bzrlib import foo; import bzrlib.bar')
    assert 'foo' in scope
    assert 'bar' in scope
    assert not isinstance(scope['foo'], ImportReplacer)
    assert not isinstance(scope['bar'], ImportReplacer)

    # Test with renaming
    scope = {}

# Generated at 2022-06-24 02:45:53.013839
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ must return a string"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r = repr(e)
    assert isinstance(r, str)
    assert r.startswith('IllegalUseOfScopeReplacer(')
    assert r.endswith(')')
    assert 'name=%r' % 'name' in r
    assert 'msg=%r' % 'msg' in r
    assert 'extra=%r' % 'extra' in r

# Generated at 2022-06-24 02:46:01.410695
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    s1 = IllegalUseOfScopeReplacer(1, "foo", extra=1)
    s1_copy = IllegalUseOfScopeReplacer(1, "foo", extra=1)
    s2 = IllegalUseOfScopeReplacer(2, "foo", extra=2)
    assert s1 == s1_copy
    assert not (s1 != s1_copy)
    assert s1 != s2
    assert not (s1 == s2)
    assert (s1 == 1) == NotImplemented
    assert (s1 != 2) == NotImplemented



# Generated at 2022-06-24 02:46:07.349693
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # This is a rather crude unit test, just to make sure that this method
    # works.
    def import_and_return(self, scope, name):
        from bzrlib.lazy_import import lazy_import
        return lazy_import(scope, 'import bzrlib.lazy_import')
    sr = ScopeReplacer(locals(), import_and_return, 'lazy_import')
    lazy_import


# Generated at 2022-06-24 02:46:17.366582
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Test method '__repr__' of class IllegalUseOfScopeReplacer."""
    from bzrlib.tests.blackbox import ExternalBase

    obj = IllegalUseOfScopeReplacer(name='a', msg='b', extra='c')
    obj1 = IllegalUseOfScopeReplacer(name='a', msg='b', extra='c')
    obj2 = IllegalUseOfScopeReplacer(name='a1', msg='b', extra='c')
    obj3 = IllegalUseOfScopeReplacer(name='a', msg='b1', extra='c')
    obj4 = IllegalUseOfScopeReplacer(name='a', msg='b', extra='c1')
    obj5 = IllegalUseOfScopeReplacer(name='a', msg='b')

    ExternalBase.failUnlessEqual(obj, obj)
    ExternalBase.failIfE

# Generated at 2022-06-24 02:46:23.087834
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # This formatter is invoked by the unicode() builtin and __unicode__.
    unicode(e) # minimal test only



# Generated at 2022-06-24 02:46:30.923866
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy_import's handling of slightly invalid imports."""
    # Make sure that lazy_import can handle slightly invalid imports
    def check_import(text, expected_output):
        text = text.strip()
        expected_output = expected_output.strip()
        out = ImportProcessor()._canonicalize_import_text(text)
        out = '\n'.join(out)
        eq(expected_output, out)

    check_import('import ', '')
    check_import('import  ', '')
    check_import('import a', 'import a')
    check_import('import a,', 'import a')
    check_import('import a, ', 'import a')
    check_import('import a,  ', 'import a')
    check_import('import a, b', 'import a\nimport b')


# Generated at 2022-06-24 02:46:39.716723
# Unit test for function disallow_proxying
def test_disallow_proxying():
    # example: '2to3' has a pyc file with the same name as its py file. It's
    # a very unusual case, but we have at least one occurrence of the problem
    # in practice: bzrlib.tests.run_2to3.
    import bzrlib
    bzrlib.tests.run_2to3.run_2to3  # raises ImportError: No module named 2to3
    # This is bzrlib's lazy proxy, not the '2to3' module, which is the expected
    # behaviour
    bzrlib.tests.run_2to3.run_2to3  # raises IllegalUseOfScopeReplacer



# Generated at 2022-06-24 02:46:44.972014
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    text = """
    import re
    import bzrlib.commands
    import bzrlib.tests.blackbox
    import bzrlib.tests.features

    """
    p = ImportProcessor()
    p.lazy_import({}, text)

# Generated at 2022-06-24 02:46:54.240711
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import sys
    import os

    # By default, we replace imports with ImportReplacer, so our expected
    # results should be ImportReplacer objects
    expected = ImportReplacer

    # Create a new ImportProcessor with an empty map
    processor = ImportProcessor()

    # We should be able to import a module into an empty map
    processor._convert_import_str('import foo')
    assert processor.imports == {'foo':([u'foo'], None, {})}
    # We should be able to import a module with a member into an empty map
    processor.imports = {}
    processor._convert_import_str('import foo.bar')
    assert processor.imports == {'foo':([u'foo'], None, {'bar':(
        [u'foo', u'bar'], None, {})})}


# Generated at 2022-06-24 02:47:01.430739
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():

    class MyImportReplacer(ImportReplacer):
        """A fake ImportReplacer for testing"""

    scope = {}
    MyImportReplacer(scope, 'foo', ['foo'], member=None, children={})

    # Can't import both a member and children
    try:
        MyImportReplacer(scope, 'foo', ['foo'], member='bar', children={'baz':('foo', 'baz', {})})
    except ValueError:
        pass
    else:
        raise AssertionError("Can't import both member and children")



# Generated at 2022-06-24 02:47:06.348789
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib
    scope = locals()
    scope.pop('bzrlib')
    ImportProcessor().lazy_import(
        scope, 'from bzrlib import config\nimport bzrlib.option')
    bzrlib
    config
    from bzrlib.option import Option
    Option()

# Generated at 2022-06-24 02:47:15.105710
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should be reflexive, symmetric and transitive"""
    c = IllegalUseOfScopeReplacer
    s = c('name', 'msg', 'extra')
    t = c('name', 'msg', 'extra')
    u = c('name', 'msg', 'extra')

    # Reflexivity
    assert (s == s)

    # Symmetry
    assert (s == t)
    assert (t == s)

    # Transitivity
    assert (s == t)
    assert (t == u)
    assert (s == u)

    # Inequality
    assert (s != None)
    assert (s != 'something')
    assert (s != Exception())



# Generated at 2022-06-24 02:47:22.437438
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import bzrlib, os, tempfile
    # Testing ImportProcessor class only when it is used for function
    # lazy_import()

    # Testing error cases for the function
    # _build_map() of class ImportProcessor
    import_processor_obj = ImportProcessor()

# Generated at 2022-06-24 02:47:27.776652
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""
    # Note that this test is more of a functional test for the lazy_import
    # helper than a unit test for the functionality of the actual importers
    # themselves, since this tests the interactions between all four of
    # lazy_import, ImportReplacer, ImportProcessor, and _normalize_import_text
    imports = StringIO()
    scope = {}
    lazy_import(scope, imports.getvalue())

# Generated at 2022-06-24 02:47:36.996607
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # call the constructor
    exc = IllegalUseOfScopeReplacer("name", "msg", "extra")
    # now test it
    check_eq(str(exc), "ScopeReplacer object 'name' was used incorrectly: msg: extra")
    check_eq(exc.name, "name")
    check_eq(exc.msg, "msg")
    check_eq(exc.extra, ": extra")

    # test unicode
    check_eq(unicode(exc), u"ScopeReplacer object 'name' was used incorrectly: msg: extra")

    # test equality
    check_eq(exc, IllegalUseOfScopeReplacer("name", "msg", "extra"))
    check_eq(exc, IllegalUseOfScopeReplacer("name", "msg", extra="extra"))

# Generated at 2022-06-24 02:47:46.515515
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Tests for IllegalUseOfScopeReplacer"""
    import sys

    # Check that IllegalUseOfScopeReplacer works (in a trivial way)

    # Try a class that has _fmt defined
    e = IllegalUseOfScopeReplacer(name='fred',
                                  msg='Something nasty happened')
    s = str(e)
    # __str__ and __unicode__ should return the same result
    u = unicode(e)
    if sys.version_info[0] < 3:
        # On Python 2.5 we get '1L' here.
        assert s == str(repr(e))
    else:
        assert s == s
    assert u == u
    assert u == unicode(repr(e))
    assert s == u.encode('utf8')



# Generated at 2022-06-24 02:47:58.723595
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import sys
    import os.path
    import bzrlib.transform


# Generated at 2022-06-24 02:48:03.971956
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ for IllegalUseOfScopeReplacer must decode _fmt using default encoding."""
    class UnicodeException(Exception):
        _fmt = u'Fake message\u1234'
    e = UnicodeException()
    s = str(e)
    # _fmt is a unicode object, so we expect the __str__ to be a str object.
    assert isinstance(s, str)
    assert s == 'Fake message\xe1\x88\xb4'


# Generated at 2022-06-24 02:48:08.430001
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import unittest
    class TestScopeReplacer(unittest.TestCase):
        def test(self):
            self.assertRaises(TypeError,ScopeReplacer,{},None,None)
    unittest.main()


# Generated at 2022-06-24 02:48:13.621868
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    def factory(self, scope, name):
        return "FOO"
    ScopeReplacer(scope, factory, "foo")
    # With the default setting, should not allow accessing members of self
    try:
        real_obj = scope['foo']._resolve()
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("Didn't catch illegal use of scope replacer")



# Generated at 2022-06-24 02:48:19.500590
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method IllegalUseOfScopeReplacer.__eq__"""
    e1 = IllegalUseOfScopeReplacer('name', 'message')
    e2 = IllegalUseOfScopeReplacer('name', 'message')
    assert e1 == e2
    assert e1 != NotImplemented
    assert e1 != '1234'
test_IllegalUseOfScopeReplacer___eq__.todo = "not yet implemented"



# Generated at 2022-06-24 02:48:23.953144
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ returns unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    u = unicode(e)
    assert isinstance(u, unicode)
# !! End of unit test for method __unicode__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:48:35.581371
# Unit test for function lazy_import
def test_lazy_import():
    # TODO: jam 20060912 Improve this test.
    import bzrlib._lazy_import as _lazy_import
    # We use 'lazy_import' because the lazy loading is what we are trying
    # to test here.
    lazy_import(globals(), '''from bzrlib import (
        _lazy_import,
        )''')
    # This is a little bit of a hack, but it's what I did.
    lazy_import(globals(), 'from bzrlib.lazy_import import lazy_import')

    # Now make sure that text can be used to import the 'foo' module
    lazy_import('lazy_import(globals(), "from bzrlib import foo")')
    import bzrlib.foo

    # This is a bit of a cheat. We

# Generated at 2022-06-24 02:48:44.626551
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """lazy_import should build up the internal map."""

    class TestHelper(ImportProcessor):
        def __init__(self):
            self.imports = {}
            self.lazy_import_class = ImportReplacer

        def _build_map(self, text):
            return ImportProcessor._build_map(self, text)

        def _convert_imports(self, scope):
            return True

    t = TestHelper()

    text = """
    import foo, bar
    import foo.bar.baz,
    foo.bar.bing as b, foo.bar.bong
    from foo.bar import baz, bing as b, bong
    """
    t._build_map(text)

# Generated at 2022-06-24 02:48:52.152902
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """test_ImportProcessor"""
    import os
    import bzrlib
    def _get_path_list(obj):
        path = obj.__name__.split('.')
        if obj.__file__ is not None:
            path[-1] = os.path.split(obj.__file__)[-1]
            path.append(path[-1].split('.py')[0])
        return path
    # First create a set of imports
    # Note: This list should be updated for each import we add
    #       to the bzrlib module. bzrlib.__init__ should be the first,
    #       as it will handle the rest of the imports.
    imports = [bzrlib]
    processor = ImportProcessor()
    expected = {}
    for obj in imports:
        name

# Generated at 2022-06-24 02:49:00.868756
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of the class ImportProcessor.

    This is a unit test for the constructor of the class ImportProcessor.
    """
    # This test is to test the main functionalities of the constructor
    # of the class ImportProcessor, i.e., to initialize an empty
    # imports dictionary and to use the default ImportReplacer class when
    # no lazy_import_class is provided.
    ip = ImportProcessor()
    assert ip.imports == {}
    assert ip._lazy_import_class == ImportReplacer

    # Test that if the lazy_import_class argument is provided, the
    # constructor uses this class instead of the default ImportReplacer
    # for the _lazy_import_class attribute.
    ip_1 = ImportProcessor(lazy_import_class=object)
    assert ip_1._lazy_import

# Generated at 2022-06-24 02:49:12.266724
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from doctest import TestCase
    from bzrlib.tests import TestUtil
    class Test_IllegalUseOfScopeReplacer___eq__(TestCase):
        """Test method __eq__ of class IllegalUseOfScopeReplacer

        This tests that the equality test works when different subclasses are
        involved.
        """
        def test_subclass(self):
            class SubException(IllegalUseOfScopeReplacer):
                """A subclass of IllegalUseOfScopeReplacer"""
                pass
            ex1 = SubException('foo', 'bar')
            ex2 = SubException('foo', 'bar')
            self.assertEqual(ex1, ex2)
            # Check that we can spot the difference when we change attributes
            ex3 = SubException('foo', 'bronz')

# Generated at 2022-06-24 02:49:23.996420
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests.test__lazy_import import SampleLazyObject
    from bzrlib.tests.test__lazy_import import SampleLazyObjectFactory
    scope = {}
    obj = SampleLazyObjectFactory(scope)
    # Replace SampleLazyObject with a ScopeReplacer
    obj.SampleLazyObject = ScopeReplacer(scope, SampleLazyObjectFactory,
                                         'SampleLazyObject')
    # Mark the start of the test
    obj._test_count += 1
    # Treat the ScopeReplacer as if it were the real SampleLazyObject
    obj.SampleLazyObject().SampleLazyObject()
    # Check that the real SampleLazyObject was generated
    del obj.SampleLazyObject
    assert obj._test_count == 2


# Generated at 2022-06-24 02:49:30.896403
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying"""
    class TestModule(object):
        pass
    scope = {}
    lazy_import(scope, '''
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy
    ''', reload_module=True)
    bzrlib.lazy_import.disallow_proxying()
    lazy_import(scope, 'foo = bzrlib.lazy_import.TestModule()'
                , reload_module=True)
    try:
        scope['foo'].x = 5
        raise Exception('expected IllegalUseOfScopeReplacer')
    except IllegalUseOfScopeReplacer as e:
        if not e.msg.startswith('Object already replaced'):
            raise
    # get access is safe

# Generated at 2022-06-24 02:49:43.905892
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test lazy_import method of class ImportProcessor"""

    class MyImportReplacer(ImportReplacer):
        def __init__(self, *args, **kwargs):
            ImportReplacer.__init__(self, *args, **kwargs)
            self._args = args
            self._kwargs = kwargs
            self._called = 0
            
        def _import(self, scope, name):
            self._called += 1
            return ImportReplacer._import(self, scope, name)

    # imports
    imp_str = "import foo, bar.bing"
    import_processor = ImportProcessor(MyImportReplacer)
    import_processor.lazy_import({}, imp_str)
    import_processor = ImportProcessor()
    import_processor.lazy_import({}, imp_str)

    # from

# Generated at 2022-06-24 02:49:50.376771
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test object constructor of class ImportProcessor."""
    import_processor = ImportProcessor()

# Generated at 2022-06-24 02:49:55.147909
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__

    Two IllegalUseOfScopeReplacer objects are considered equal if
    they have the same class, and the same attributes have the same values.
    """
# This is required only by the pychecker static analysis tool.
IllegalUseOfScopeReplacer.__init__.im_func.func_code



# Generated at 2022-06-24 02:50:01.481190
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test constructor of class ScopeReplacer."""
    class TestScopeReplacer(ScopeReplacer):
        """A subclass of ScopeReplacer to use in tests.

        This class allows testing of private methods of the ScopeReplacer base
        class without triggering the corresponding runtime error.
        """
        # A method that must be implemented to make sure that
        # the class is really a subclass of ScopeReplacer.
        def __call__(self, *args, **kwargs):
            pass
    test = TestScopeReplacer({}, lambda _: None, '')
    assert isinstance(test, ScopeReplacer)
    assert test._factory == (lambda _: None)
    assert test._real_obj is None
    assert test._scope == {}
    assert test._name == ''
    assert test._should_proxy is True


# Generated at 2022-06-24 02:50:11.930966
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """__str__ should return a str object.

    The str contains the error message, the name of the exception,
    and any extra data that was passed in.
    """
    err = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    s = str(err)
    assert isinstance(s, str)
    assert 'foo' in s
    assert 'bar' in s
    assert 'baz' in s

    err = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(err)
    assert isinstance(s, str)
    assert 'foo' in s
    assert 'bar' in s

    err = IllegalUseOfScopeReplacer('foo', 'bar', '\xe2\x9c\x93')
    s = str(err)
    assert isinstance(s, str)

# Generated at 2022-06-24 02:50:21.143888
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    def factory(self, scope, name):
        """factory"""
        return "Hello World"
    sr = ScopeReplacer(scope, factory, name='foo')
    # Check basic attributes
    assert sr._scope == scope
    assert sr._factory == factory
    assert sr._name == 'foo'
    assert sr._real_obj is None
    # Check scope has been updated
    assert scope['foo'] is sr
    # Check proxy operation
    assert scope['foo'] == 'Hello World'
    assert scope['foo'] == 'Hello World'
    assert scope['foo'] == 'Hello World'



# Generated at 2022-06-24 02:50:33.285238
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:50:45.638165
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():

    class FakeLazyImportClass(object):
        def __init__(self, scope, name=None, module_path=None, member=None,
                     children=None):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children

        def _import(self, scope, name):
            return self
    ip = ImportProcessor(FakeLazyImportClass)
    # The export "foo.bar" is used in the imports
    export = object()

    # Add 'foo' and 'foo.bar' to globals so that ImportProcessor can import
    # them
    globals()['foo'] = object()
    globals()['foo'].bar = export

    # import 'foo' and 'foo.bar' and add both of them

# Generated at 2022-06-24 02:50:57.111944
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(), '''\
    import foo, bar.bing, bar.baz.bung
    ''')
    # Now test that importing any of those variables will trigger
    # the lazy import behavior.
    # Note: We import foo as a module, and a child of a module
    #  from the same import string
    import foo
    import bar.bing
    import bar.baz.bung

    for name in ('foo', 'bar.bing', 'bar.baz.bung'):
        assert isinstance(globals()['lazy_%s' % name],
            ImportReplacer)
    # Make sure that the import processors worked correctly
    assert foo is globals()['lazy_foo']._real_obj
    assert bar

# Generated at 2022-06-24 02:51:06.076407
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def _check_getattribute(Lazy, x):
        Lazy()
        assert x.called
    def _check_getattribute_raises(Lazy, error):
        Lazy()
        try:
            error()
        except Exception as e:
            assert e.__class__.__name__ == 'NameError'
    # Check we can proxy a class object.
    class X(object):
        def __getattribute__(self, attr):
            return attr
        def __setattr__(self, attr, value):
            return
        def __call__(self, *args, **kwargs):
            return
    x = X()
    y = ScopeReplacer(globals(), lambda self, scope, name: x, 'y')
    assert y.a == x.a

# Generated at 2022-06-24 02:51:11.060570
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ of IllegalUseOfScopeReplacer"""
    k = IllegalUseOfScopeReplacer("name", "msg", "extra")
    expected = "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    actual = repr(k)
    assert expected == actual



# Generated at 2022-06-24 02:51:14.495149
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    err = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    expected = "ScopeReplacer object 'foo' was used incorrectly: msg: extra"
    assert str(err) == expected



# Generated at 2022-06-24 02:51:19.023502
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that the ScopeReplacer constructor raises no exceptions."""
    ScopeReplacer({}, None, 'null')
    # one with a non-trivial factory
    ScopeReplacer({}, lambda s, sc, n: 1, 'one')


# Generated at 2022-06-24 02:51:29.465419
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""

    class MyScope(object):
        """Fake scope for testing"""

        def __init__(self):
            self.imported = set()
            self.loaded = set()

        def import_module(self, name, module_path, member=None):
            self.imported.add(name)
            if name == 'reload':
                return ReloadingObject(self, name=name, module_path=module_path,
                                       member=member)
            else:
                return NormalObject(self, name=name, module_path=module_path,
                                    member=member)

    scope = MyScope()

# Generated at 2022-06-24 02:51:37.764710
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import mock
    import sys

    # Mock out original sys.modules[__name__] as _mock_sys_mod to allow for
    # restoring it.
    _mock_sys_mod = mock.Mock()
    sys.modules[__name__] = _mock_sys_mod

    # Mock out the original elements of sys.modules[__name__] to test
    # ScopeReplacer.
    mock_factory = mock.Mock()
    mock_factory.return_value = mock.Mock(__name__='mock_mod')

    # Create a ScopeReplacer object in the current scope and check it is
    # created correctly.
    ScopeReplacer(locals(), mock_factory, '__name__')

# Generated at 2022-06-24 02:51:39.423277
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor"""
    a = ImportProcessor()
    assert a is not None

# Generated at 2022-06-24 02:51:43.735403
# Unit test for function disallow_proxying
def test_disallow_proxying():
    def raise_exception(self, scope, name):
        raise IllegalUseOfScopeReplacer(scope, name)
    scope = {}
    ScopeReplacer(scope, raise_exception, 'foo')
    disallow_proxying()
    try:
        scope['foo']
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("Exception should have happened")



# Generated at 2022-06-24 02:51:55.138851
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__(self, name)

    This object is only used to insert lazy objects into a scope.
    """
    from bzrlib.tests import TestCase
    # Setting this to False will make the tests fail.
    ScopeReplacer._should_proxy = True
    def factory(*args):
        return 'factory'
    scope = {}
    obj = ScopeReplacer(scope, factory, 'name')
    # Should proxy through to 'obj'
    self.assertEqual('factory', obj())
    # Should only be called once
    self.assertEqual('factory', obj._real_obj)
    # Should raise if _should_proxy is False
    ScopeReplacer._should_proxy = False
    self.assertRaises(IllegalUseOfScopeReplacer, getattr, obj, '_real_obj')




# Generated at 2022-06-24 02:52:02.078634
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """An IllegalUseOfScopeReplacer object can be converted back to unicode"""
    for e in [IllegalUseOfScopeReplacer('foo', 'bar'),
              IllegalUseOfScopeReplacer('foo', 'bar', extra='baz')]:
        u = unicode(e)
        try:
            len(u.encode('ascii'))
        except UnicodeEncodeError:
            raise AssertionError("IllegalUseOfScopeReplacer.__unicode__ must "
                                 "return only ascii, not %r" % u)



# Generated at 2022-06-24 02:52:07.287483
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer('a','b')
    e2 = IllegalUseOfScopeReplacer('a','b')
    e3 = IllegalUseOfScopeReplacer('b','b')
    assert e1 == e2
    assert not e1 == e3



# Generated at 2022-06-24 02:52:13.528275
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    e3 = IllegalUseOfScopeReplacer('name1', 'msg')
    e4 = IllegalUseOfScopeReplacer('name', 'msg1')
    from bzrlib.tests import TestCase
    TestCase.assertEqual(e1, e2)
    TestCase.assertNotEqual(e1, e3)
    TestCase.assertNotEqual(e1, e4)



# Generated at 2022-06-24 02:52:22.505329
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from contextlib import contextmanager
    from mock import Mock
    from bzrlib.lazy_import import ScopeReplacer
    obj = ScopeReplacer(None, None, None)
    obj._resolve = lambda:Mock()
    obj._resolve.side_effect = lambda:obj
    obj.__call__.side_effect = lambda:obj
    obj.__call__.return_value = 1
    with mock_isinstance_attrs(obj, lambda *x:x[0] is obj):
        obj.__call__()
    obj._resolve.assert_called_with()
    obj.__call__.assert_called_with()
    obj.__call__.assert_called_with(1, 2, 3)

# Generated at 2022-06-24 02:52:28.803723
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of ImportReplacer"""
    scope = {}
    importer = ImportReplacer(scope=scope,
                              name='foo', module_path='foo', member=None,
                              children={'bar': (['foo', 'bar'], None, {})})
    try:
        ImportReplacer(scope=scope,
                       name='foo', module_path='foo', member='bar',
                       children={'bar': (['foo', 'bar'], None, {})})
    except ValueError:
        pass
    else:
        raise AssertionError('should raise ValueError')
    return importer



# Generated at 2022-06-24 02:52:35.364670
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit tests for constructor of class ImportProcessor.

    This test does not test the lazy_import function, because that
    would mean initialising an ImportProcessor object which might be
    modified by other unit tests.
    """
    import_processor = ImportProcessor()
    assert not import_processor.imports



# Generated at 2022-06-24 02:52:43.134885
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """ScopeReplacer.__setattr__

    A simple test to check that the __splats__ argument handling works. This
    gets called when you do foo.bar = baz.
    """
    class Foo(object):

        def __setattr__(self, attr, value):
            super(Foo, self).__setattr__(attr, value)
    class Bar(object):

        def __setattr__(self, attr, value):
            super(Bar, self).__setattr__(attr, value)
    foo = Foo()
    bar = Bar()
    foo.x = bar
    bar.y = 'y'
    s = ScopeReplacer(foo.__dict__, lambda self, scope, name: self, 'x')
    s.z = 'z'
    assert s._real_obj is s
   

# Generated at 2022-06-24 02:52:56.443712
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__

    Two IllegalUseOfScopeReplacer exceptions are equal if their
    attributes are equal.
    """
    attrs = dict(g='a', h='b', i='c')
    e1 = IllegalUseOfScopeReplacer('a', 'm', attrs)
    e2 = IllegalUseOfScopeReplacer('a', 'm', attrs)
    assert e1 == e2
    for key, value in attrs.items():
        attrs[key] = 'x'
        assert e1 != e2
        attrs[key] = value
    e1 = IllegalUseOfScopeReplacer('y', 'm', attrs)
    assert e1 != e2


# tuple of types that should not be replaced, obj.__class__ must be in this to
# avoid replacement
_

# Generated at 2022-06-24 02:53:00.680828
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return a str, not a unicode"""
    instance = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(instance)
    assert isinstance(s, str), "__str__ should return a 'str', not a 'unicode'"


# Generated at 2022-06-24 02:53:12.370405
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.tests.per_interpreter import TestCase
    from bzrlib import (
        branch,
        errors,
        tests,
        transport,
        )

    class TestLazyImport(TestCase):

        def test_lazy_import_string(self):
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                bucket,
                branch,
                errors,
                tests,
                transport,
                )
            import bzrlib.trace
            ''')
            def check_one(name, obj, import_obj):
                self.assertIsInstance(import_obj, ImportReplacer)
                self.assertFalse(import_obj.has_been_replaced)
                self.assertIs(obj, import_obj)
                self.assertIs