

# Generated at 2022-06-24 02:43:14.382574
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer

    More generally, it tests a class which overrides __eq__ and that defines
    _fmt, msg and extra attributes.
    """
    from bzrlib.tests import TestCase
    from bzrlib._lazy_import import IllegalUseOfScopeReplacer

    class Test(TestCase):

        def test_eq(self):
            e1 = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
            e2 = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
            self.assertTrue(e1 is not e2)
            self.assertEqual(e1, e2)

            e1 = IllegalUseOfScopeReplacer('foo', 'msg', None)

# Generated at 2022-06-24 02:43:19.807387
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__() compares class and dict"""
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = 'hello %(msg)s'
    e1 = MyException('1', '2')
    e2 = MyException('1', '2')
    e3 = MyException('3', '4')
    e4 = MyException('1', '2', '3')
    assert not e1 != e2
    assert e1 != e3
    assert not e1 != e4



# Generated at 2022-06-24 02:43:26.822601
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ of IllegalUseOfScopeReplacer"""
    # Create an instance of IllegalUseOfScopeReplacer
    ir = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # Call IllegalUseOfScopeReplacer.__str__
    s = str(ir)
    assert isinstance(s, str)
    assert s == 'ScopeReplacer object \'name\' was used incorrectly:' + \
        ' msg: extra'



# Generated at 2022-06-24 02:43:35.588789
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    class Test(object):
        def __init__(self):
            self.a = 'a'
    scope = {}
    def factory(replacer, scope, name):
        return Test()
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    assert scope[name] is replacer
    # First use, object not replaced
    assert replacer.a == 'a'
    assert scope[name] is not replacer
    assert scope[name] is replacer._real_obj
    assert scope[name].a == 'a'
    assert scope[name].__class__ is Test
    # Second use, object already replaced
    assert scope[name].a == 'a'
    assert scope[name] is replacer._real_obj



# Generated at 2022-06-24 02:43:45.493650
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase
    class TestException(IllegalUseOfScopeReplacer):
        """A test exception"""

    s = 'Test Message'
    v1 = TestException(1, s, 'extra')
    v2 = TestException(2, s, 'extra')
    v1a = TestException(1, s, 'extra')

    TestCase.assertEqual(v1, v1a)
    TestCase.assertNotEqual(v1, v2)
    TestCase.assertEqual(v1, v1)
    TestCase.assertNotEqual(v1, s)
    TestCase.assertNotEqual(v1, object())



# Generated at 2022-06-24 02:43:53.310372
# Unit test for function lazy_import
def test_lazy_import():
    def check(test_class):
        # This should have set up the lazy imports.
        # So try to import each import, the objects should exist, but not
        # be fully imported.
        non_lazy_import('bzrlib')
        non_lazy_import('bzrlib.foo')
        non_lazy_import('bzrlib.foo.bar')
        non_lazy_import('bzrlib.foo.bar.baz')
        non_lazy_import('bzrlib.branch')
        non_lazy_import('bzrlib.transport')


# Generated at 2022-06-24 02:44:02.644374
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import unittest
    from bzrlib import lazy_import
    import bzrlib

    class TestCase(unittest.TestCase):
        """Tests for lazy_import processing the import string."""

        def setUp(self):
            self.__scope = locals()
            self.__processor = ImportProcessor()

        def tearDown(self):
            if 'bzrlib' in self.__scope:
                del self.__scope['bzrlib']
            if 'osutils' in self.__scope:
                del self.__scope['osutils']

        def _test_regular_import(self, import_text):
            self.__processor.lazy_import(self.__scope, import_text)
            names = self.__scope.keys()
            names.sort()
            self.assertE

# Generated at 2022-06-24 02:44:10.172282
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.testing.features import ModuleAvailableFeature
    from bzrlib.tests import TestCase
    feature_utf8 = ModuleAvailableFeature('codecs')

    class TestScopeReplacer(TestCase):

        def test___setattr__(self):
            # Verify that __setattr__ raises an exception after
            # the object has replaced itself.
            global x
            x = None

# Generated at 2022-06-24 02:44:12.698699
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    s = "some message"
    e = IllegalUseOfScopeReplacer("a", s)
    assert e.msg == s
    assert e.name == "a"



# Generated at 2022-06-24 02:44:21.324597
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:44:32.069599
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying() does what it's supposed to do."""
    try:
        import bzrlib.tests
    except ImportError:
        from bzrlib.lazy_import import lazy_import
        lazy_import(globals(), """
        from bzrlib.lazy_import import disallow_proxying
        """)
    disallow_proxying()
    globals()['bzrlib']._should_proxy = True

# Generated at 2022-06-24 02:44:37.160352
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import doctest
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestLazyImport
    suite = doctest.DocTestSuite(
        TestLazyImport,
        setUp=TestCase.setUp, tearDown=TestCase.tearDown)
    return suite

# Generated at 2022-06-24 02:44:45.293994
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    def _check(name, module_path, member, children):
        replacer = ImportReplacer({}, name=name, module_path=module_path,
                                  member=member, children=children)
        for attr, expected in [(replacer._name, name),
                               (replacer._module_path, module_path),
                               (replacer._member, member),
                               (replacer._import_replacer_children, children)]:
            assert expected == attr, "%r != %r" % (expected, attr)
    _check('foo', ['foo'], None, {})
    _check('foo', ['foo'], 'bar', {})
    _check('foo', ['foo'], None,
           {'bar': (['foo', 'bar'], None, {})})



# Generated at 2022-06-24 02:44:55.072866
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from cStringIO import StringIO
    class Test___call__(TestCase):
        def setUp(self):
            TestCase.setUp(self)
            def factory(self, scope, name):
                return StringIO()
            class MyScope(dict):
                pass
            self.my_scope = MyScope()
            self.replacer = ScopeReplacer(self.my_scope, factory, 'foo')
            self.replacer.write('hello')
        def test(self):
            self.assertEqual('hello', self.replacer.getvalue())
    return Test___call__



# Generated at 2022-06-24 02:44:59.672072
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Make sure __repr__ returns a valid representation of self"""
    exc = IllegalUseOfScopeReplacer("name", "msg", "extra")
    s = repr(exc)
    r = eval(s)
    assert r == exc



# Generated at 2022-06-24 02:45:03.371944
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Creating an IllegalUseOfScopeReplacer should not fail."""
    ex = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    assert str(ex) == 'foo: msg: extra'


# Generated at 2022-06-24 02:45:10.922856
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    name = 'foo'
    module_path = ['foo', 'bar']
    member = 'baz'
    ImportReplacer(scope, name, module_path, member)
    # There should be no foo in scope
    test_mod = scope['foo']
    # There should be no bar in scope
    test_mod = test_mod.bar
    # There should be no baz in scope
    test_baz = test_mod.baz



# Generated at 2022-06-24 02:45:16.272476
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """It should be possible to disable lazy proxies after imports"""
    l = {'m': None}
    lazy_import(l, '''
    import bzrlib.trace
    ''')
    disallow_proxying()
    try:
        bzrlib.trace
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("Disallow_proxying should detect use of"
                             " previously-imported proxy")



# Generated at 2022-06-24 02:45:20.511222
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    m = {}
    ImportReplacer(m, name="foo", module_path=("foo",),
                   member=None, children={})
    ImportReplacer(m, name="bar", module_path=("foo", "bar"),
                   member=None, children={})
    ImportReplacer(m, name="baz", module_path=("foo", "bar"),
                   member="baz", children={})
    assert m['foo']._import_replacer_children == {}
    assert m['bar']._import_replacer_children == {}
    assert isinstance(m['baz'], ImportReplacer)



# Generated at 2022-06-24 02:45:30.654776
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class MyClass(object):
        pass
    def make_myclass(foo, scope, name):
        return MyClass()
    foo = ScopeReplacer(locals(), make_myclass, 'foo')
    def foo_setattr(attrname, attrvalue):
        setattr(foo, attrname, attrvalue)
    foo_setattr('bar', 'baz')
    foo_setattr('bar', 'baz')
    # Verify that we have caught all the errors
    try:
        foo_setattr('bar', 'baz')
    except IllegalUseOfScopeReplacer:
        pass
#

# Generated at 2022-06-24 02:45:40.012234
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit tests for 'disallow_proxying' function.

    The test is done with 'lazy_import' because it is less complicated
    than 'lazy_class', for which testing would require to generate
    classes in advance.
    """
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    global foo, a, b
    ScopeReplacer._should_proxy = True

# Generated at 2022-06-24 02:45:48.950015
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__

    When a class inherits from Exception, the __eq__ operator is not called
    unless it is overridden.  But it is called implicitly when objects
    of a class derived from Exception are compared with ==.  So this method
    is not just a test method, because it also tests that it works as expected.
    """
    # __eq__ is a class method, so create a subclass to be able to call it
    # directly.
    class SubIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        pass
    i1 = SubIllegalUseOfScopeReplacer(
        'x', 'y', 'z')
    i1.__dict__['a'] = 'b'

# Generated at 2022-06-24 02:45:55.355294
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should be defined for IllegalUseOfScopeReplacer"""
    e1 = IllegalUseOfScopeReplacer("name", "msg")
    e2 = IllegalUseOfScopeReplacer("name", "msg")
    e3 = IllegalUseOfScopeReplacer("name2", "msg")
    if not (e1 == e2):
        raise AssertionError("e1 == e2")
    if e1 == e3:
        raise AssertionError("e1 != e3")



# Generated at 2022-06-24 02:46:06.742993
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    a = []
    ScopeReplacer(a, lambda r, s, n: None, 'foo')
    # The object should be accessible.
    a[0]
    # Once used, it should raise an exception
    a[0]._resolve()
    # once used, it should not be possible to proxy.
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-24 02:46:16.854598
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import textwrap
    import sys
    class ImportReplacerTester(object):
        __slots__ = ['scope', 'name', 'module_path', 'member', 'children', 'called']
        def __init__(self, scope, name, module_path, member=None, children=None):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children
            self.called = False
        def __call__(self, scope, name, module_path, member=None, children=None):
            self.called = True
            expected = ImportReplacerTester(scope=scope, name=name,
                module_path=module_path, member=member, children=children)
            self.assertEqual(self, expected)
           

# Generated at 2022-06-24 02:46:22.790092
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method __eq__ from class IllegalUseOfScopeReplacer.

    This method is a simple trivial test method. It is here to ensure
    the method is tested.
    """
    class E1(IllegalUseOfScopeReplacer):
        pass
    class E2(IllegalUseOfScopeReplacer):
        pass
    # Need to use globals() as some classes like FiloUI use
    # __eq__ and __ne__ to determine if they are the same
    # object.
    e1 = E1('foo', 'bar')
    assert e1 == e1
    assert not (e1 != e1)
    e1_ = E1('foo', 'bar')
    assert e1 == e1_
    assert not (e1 != e1_)
    e2 = E2('foo', 'bar')
    assert e

# Generated at 2022-06-24 02:46:27.752275
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    ex = IllegalUseOfScopeReplacer('the_name', 'the_message', 'the_extra')
    expected = 'the_name: the_message: the_extra'
    got = str(ex)
    assert expected == got, '%s != %s' % (expected, got)



# Generated at 2022-06-24 02:46:29.160608
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Verify that an ImportProcessor can be constructed"""
    impr = ImportProcessor()



# Generated at 2022-06-24 02:46:35.661860
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """IllegalUseOfScopeReplacer.__init__ should set attributes."""
    name = 'name'
    msg = 'message'
    extra = 'extra'
    e = IllegalUseOfScopeReplacer(name, msg, extra)
    if name != e.name:
        raise AssertionError("name not set")
    if msg != e.msg:
        raise AssertionError("msg not set")
    if extra != e.extra[2:]:
        raise AssertionError("extra not set")


# Generated at 2022-06-24 02:46:43.931482
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should represent the exception and its arguments."""
    import pickle
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    repr(e) # repr should not raise an exception.
    # repr should produce a str that eval can produce an exception from.
    e2 = eval(repr(e))
    # The exception should be equal to its representation.
    assert e == e2
    # The exception representation should be pickleable.
    pickle.loads(pickle.dumps(e2))



# Generated at 2022-06-24 02:46:53.443188
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that we can detect wasted indirection."""
    import bzrlib.lazy_import
    import bzrlib.trace
    bzrlib.lazy_import.disallow_proxying()
    # No exception raised if the module is correctly loaded.
    bzrlib.trace.note(Note='x')
    if bzrlib.lazy_import.ScopeReplacer._should_proxy:
        raise AssertionError('_should_proxy should be False by now')
    # Accessing members of a lazy_import object will fail.
    from bzrlib.tests.lazy_import_fixture import some_function
    try:
        some_function()
    except bzrlib.lazy_import.IllegalUseOfScopeReplacer:
        pass
    else:
        raise Assertion

# Generated at 2022-06-24 02:47:02.403901
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    check_unicode_escape(repr(e1), r'IllegalUseOfScopeReplacer\(')


# This class is used by lazy_import to provide a function-like object that
# can represent an import for a module which hasn't been imported yet.  At
# first, it just raises an IllegalUseOfScopeReplacer exception, but once the
# real object has been imported, this will be replaced with the actual object
# being imported.  This should only be used in limited situations, e.g. at
# module top-level or inside a class definition.  It should not, for example,
# be used in the body of a method.

# Generated at 2022-06-24 02:47:13.730771
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], member=None, children={})
    ImportReplacer(scope, 'foo', ['foo'], member='bar', children={})
    ImportReplacer(scope, 'foo', ['foo'], member='bar', children={
        'baz':(['foo', 'bar'], None, {})})
    ImportReplacer(scope, 'foo', ['foo'], member='bar', children={
        'baz':(['foo', 'bar'], 'baz', {})})
    ImportReplacer(scope, 'foo', ['foo'], member='bar', children={
        'baz':(['foo', 'bar'], None, {
            'bazzle': (['foo', 'bar', 'baz'], None, {})})})

# Generated at 2022-06-24 02:47:24.581737
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import types
    import sys
    import bzrlib.lazy_import

    def check_get_module_func(use_bzrlib):
        if use_bzrlib:
            get_module_func = bzrlib.lazy_import.get_module
        else:
            get_module_func = bzrlib.lazy_import.ScopeReplacer._resolve

        my_scope = {}
        modname = 'm1'
        mod = __import__(modname)
        my_scope[modname] = mod
        my_scope['sys'] = sys

        # True because we have the module in the scope before we call the
        # get_module func.
        out = get_module_func(modname, my_scope)
        assert out is mod

        # False because we don't

# Generated at 2022-06-24 02:47:32.088043
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class Foo(object):
        pass
    class Bar(object):
        pass
    import_replacer = ImportReplacer(Foo.__dict__, 'foo', ['foo'], children={
        'bar':(['foo', 'bar'], None, {}),
        'baz':(['foo', 'baz'], None, {'qux':(['foo', 'baz', 'qux'], None, {})})
        })
    assert isinstance(import_replacer._import_replacer_children, dict)
    assert import_replacer._import_replacer_children['bar'][0] == ['foo', 'bar']
    assert import_replacer._import_replacer_children['bar'][1] is None
    assert import_replacer._import_replacer_children['bar'][2] == {}
   

# Generated at 2022-06-24 02:47:39.637965
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str, not a unicode object.

    TODO: This isn't a good test.
    """
    t = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r = repr(t)
    assert isinstance(r, unicode)
    r = str(t)
    assert isinstance(r, str)
    r = unicode(t)
    assert isinstance(r, unicode)


# _create_scope_replacer is not implemented yet.

# Generated at 2022-06-24 02:47:46.257262
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should call _format and return a unicode object."""
    import bzrlib.tests
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    bzrlib.tests.TestCaseWithMemoryTransport.assertEqualDiff(
        unicode(e),
        u'IllegalUseOfScopeReplacer(foo)')
    u = unicode(e)
    bzrlib.tests.TestCaseWithMemoryTransport.assertIsInstance(u, unicode)



# Generated at 2022-06-24 02:47:49.408619
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        raise IllegalUseOfScopeReplacer('foo', 'a')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'foo'



# Generated at 2022-06-24 02:47:55.682745
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib

    # before
    x = bzrlib
    # after
    disallow_proxying()
    x = bzrlib
    # still after
    y = bzrlib
    try:
        y = x
    except IllegalUseOfScopeReplacer as e:
        pass
    else:
        raise AssertionError('Succeeded to use a modifier variable')



# Generated at 2022-06-24 02:48:05.131711
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor"""
    # The key is the text to be imported,
    # the value is a tuple where the first element is the
    # expected imports and the second element is the expected
    # import map

# Generated at 2022-06-24 02:48:16.878856
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import imp
    import sys
    import bzrlib
    if sys.modules.has_key('ModuleUnitTestScopeReplacer'):
        del sys.modules['ModuleUnitTestScopeReplacer']
    scope = locals()
    scope['replacement'] = 'replacement value'
    module = imp.new_module('ModuleUnitTestScopeReplacer')
    module.__dict__['replacement'] = 'module value'
    module.__dict__['accessed'] = False
    def factory(self, scope, name):
        return module
    obj = ScopeReplacer(scope, factory, 'obj')
    if obj.__getattribute__('replacement') != 'module value':
        return 1
    if obj.__getattribute__('accessed') != False:
        return 2

# Generated at 2022-06-24 02:48:22.102851
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return an unicode object"""
    msg = 'this is an error message'
    e = IllegalUseOfScopeReplacer('name', msg)
    u = unicode(e)
    # The unicode object should contain the message
    assert msg in u
    # Only a unicode object should be returned
    assert isinstance(u, unicode)



# Generated at 2022-06-24 02:48:32.354387
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.lazy_import import ImportReplacer, _mod_import_hook
    import sys
    import bzrlib
    old_import_hook = sys.meta_path[:]
    sys.meta_path[:] = _mod_import_hook

# Generated at 2022-06-24 02:48:40.599820
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), '''
from bzrlib.lazy_import import disallow_proxying
''')
    disallow_proxying()
    # Importing any lazy module should fail as proxying is disabled.
    def import_version_info():
        import bzrlib.version_info
    e = TestCase.assertRaises(IllegalUseOfScopeReplacer, import_version_info)
    TestCase.assertContainsRe(e._format(), 'already replaced')



# Generated at 2022-06-24 02:48:48.740357
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor"""
    ip = ImportProcessor()
    input_string = """import foo, foo.bar, foo.bar.baz as bing,
    from foo import bar, baz as bing"""
    expected_imports = {
        'foo': ([u'foo'], None, {u'bar': ([u'foo', u'bar'], None, {u'baz': ([u'foo', u'bar', u'baz'], u'bing', {})})}),
        'bar': ([u'foo'], u'bar', {}),
        'bing': ([u'foo'], u'bing', {}),
        }
    ip.lazy_import({}, input_string)
    assert ip.imports == expected_imports


# Generated at 2022-06-24 02:48:52.533997
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # XXX: __getattribute__ is very hard to test, because
    # builtin.object.__getattribute__() is used in at least three places.
    pass

# Generated at 2022-06-24 02:49:01.340778
# Unit test for function lazy_import
def test_lazy_import():
    """Test importing a module and submodule (bzrlib.foo)"""
    lazy_import(globals(), '''
    import bzrlib
    import bzrlib.foo
    import bzrlib.foo.bar
    ''')
    # None of these should have been imported yet
    assert 'bzrlib' not in sys.modules
    assert 'bzrlib.foo' not in sys.modules
    assert 'bzrlib.foo.bar' not in sys.modules

    # This will trigger the import
    assert bzrlib.__name__ == 'bzrlib'
    # The module it replaces should be in sys.modules
    assert bzrlib.__name__ in sys.modules
    assert bzrlib is sys.modules[bzrlib.__name__]
    #

# Generated at 2022-06-24 02:49:12.724986
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import works as expected"""
    # First check for basic import
    globals = {}
    lazy_import(globals, 'import bzrlib')
    # Now bzrlib is in the dict.
    # Check that the value is a ScopeReplacer
    isinstance(globals['bzrlib'], ImportReplacer)
    # Now try using it
    globals['bzrlib'].version_info
    # Now that we've used it, it should become a real object.
    isinstance(globals['bzrlib'], ScopeReplacer)
    isinstance(globals['bzrlib'].version_info, tuple)

    # Now check for basic import
    globals = {}
    lazy_import(globals, 'from bzrlib import branch')
   

# Generated at 2022-06-24 02:49:24.676215
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def test():
        import bzrlib.trace
        scope = {}
        scope['bzrlib.trace'] = ScopeReplacer(scope, _mod_factory, 'bzrlib.trace')
        scope['bzrlib.trace'].is_quiet

    def _mod_factory(self, scope, name):
        # This is a hack to avoid circular imports
        return __import__(name, scope)
    try:
        ScopeReplacer._should_proxy = False
        e = test_bzr_catch_error_from_unittest(test)
        expected = ("Object already replaced, did you assign it to another"
                    " variable?")
        if not e.msg.endswith(expected):
            e.msg = e.msg + ' ' + expected
    finally:
        ScopeReplacer._

# Generated at 2022-06-24 02:49:36.149470
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    proc = ImportProcessor()
    proc.lazy_import(globals(), 'import foo, bar')
    proc.lazy_import(globals(), 'from bzrlib import foo')
    proc.lazy_import(globals(), 'from bzrlib import foo as bing')
    proc.lazy_import(globals(), 'from bzrlib.foo import bar')
    proc.lazy_import(globals(), 'import foo.bar, foo.bar.baz')

    # Check items are in imports map
    assert 'foo' in proc.imports
    assert 'bar' in proc.imports

    # Check children items were imported into map
    v = proc.imports['foo']
    assert v[0] == ['foo']
    assert v[1] is None

# Generated at 2022-06-24 02:49:47.822280
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ return value"""
    # ... should return a string of the form 'class(param1, param2, ...)'.
    from bzrlib.tests import TestCase
    class DummyException(Exception):
        pass
    class TestIllegalUseOfScopeReplacer(TestCase):
        """Unit test for method __repr__ of class IllegalUseOfScopeReplacer"""
        def test_default(self):
            try:
                raise IllegalUseOfScopeReplacer("TestIllegalUseOfScopeReplacer.test_default", 'foo')
            except IllegalUseOfScopeReplacer as e:
                self.assertEqual("""IllegalUseOfScopeReplacer("TestIllegalUseOfScopeReplacer.test_default", "foo")""", repr(e))
    return TestIllegalUseOfScopeReplacer("test_default")
#

# Generated at 2022-06-24 02:49:56.449677
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib.branch

    class FakeScopeReplacer(ScopeReplacer):
        _real_obj = bzrlib.branch.Branch()

    # Now we create the scopereplacer object
    scope = {}
    factory = lambda s,scope,name:FakeScopeReplacer(s,scope,name)

    replacer = ScopeReplacer(scope, factory, 'bzrlib')

    # Now we call it
    args = (1, 2, )
    kwargs = {'kw1':1, 'kw2':2}
    replacer(*args, **kwargs)

    expected_obj = bzrlib.branch.Branch

    # And the result should be the same as the real object
    actual_obj = scope['bzrlib'].__class__
    actual_obj

# Generated at 2022-06-24 02:50:09.008618
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Tests for the ImportProcessor (import text processor)"""

    # Test sample import text
    sample_text = """import bzrlib
from bzrlib.foo import bar, baz
import bzrlib.foo.bar as bing
from bzrlib.foo.bar import (John, Paul, George, Ringo)"""

    # This tests a lot of the content, but not the order.

# Generated at 2022-06-24 02:50:17.531516
# Unit test for function disallow_proxying
def test_disallow_proxying():
    global_scope = {}
    lazy_import(global_scope, '''
    import bzrlib
    ''')
    bzrlib = global_scope['bzrlib']
    bzrlib.version_info
    disallow_proxying()

# Generated at 2022-06-24 02:50:29.359453
# Unit test for function lazy_import
def test_lazy_import():
    """Unit test function lazy_import"""
    # reset things to default
    disallow_proxying()

    class LazyImportReplacer(ImportReplacer):
        """Replacer object which tracks lazy_import calls."""
        __slots__ = '_imp_count'

        def __init__(self, *args, **kwargs):
            # Clear out any existing calls to _import
            self._imp_count = 0
            super(LazyImportReplacer, self).__init__(*args, **kwargs)

        def _import(self, *args, **kwargs):
            self._imp_count += 1
            return super(LazyImportReplacer, self)._import(*args, **kwargs)

    test_scope = {}

    # test building an import request for 'import foo'

# Generated at 2022-06-24 02:50:40.307080
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class Dummy(object):
        pass

    class Dummy2(object):
        # a class to check we can set an attribute
        # that is not the object instance
        def __init__(self, *args, **kwargs):
            self.attr = 'attr'

    dummy = Dummy()

    scope = {'dummy': dummy}

    def factory(self, scope, name):
        return dummy

    name = 'dummy'

    sr = ScopeReplacer(scope, factory, name)

    def test_set_instance_attr():
        """You can set an attribute on the instance"""
        sr.attr = 'attr'
        assert dummy.attr == 'attr'

    def test_set_class_attr():
        """You can set a class attribute to an instance"""
        sr.class_attr = Dummy()
       

# Generated at 2022-06-24 02:50:47.005461
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'message')
    assert e.name == 'foo'
    assert e.msg == 'message'
    assert e.extra == ''
    assert str(e) == 'ScopeReplacer object \'foo\' was used incorrectly:' \
        ' message'

    e = IllegalUseOfScopeReplacer('foo', 'message', extra=2)
    assert e.name == 'foo'
    assert e.msg == 'message'
    assert e.extra == ': 2'
    assert str(e) == 'ScopeReplacer object \'foo\' was used incorrectly:' \
        ' message: 2'



# Generated at 2022-06-24 02:50:50.669568
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    exc = IllegalUseOfScopeReplacer('foo', 'test', extra='1')
    assert str(exc) == ("ScopeReplacer object 'foo' was used incorrectly:"
                        " test: 1")



# Generated at 2022-06-24 02:50:56.203406
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    # TODO: rbc 20060113 Write a unit test for method __unicode__
    # of class IllegalUseOfScopeReplacer
    raise NotImplementedError(
        "Test code for method __unicode__ of class IllegalUseOfScopeReplacer"
        " not yet written")

# Generated at 2022-06-24 02:50:58.521641
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    c = IllegalUseOfScopeReplacer('name', 'msg')
    c.extra = 'extra'
    c._fmt = 'fmt'



# Generated at 2022-06-24 02:51:02.017978
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # FIXME: write unit test
    # FIXME: write unit test
    # FIXME: write unit test


# Generated at 2022-06-24 02:51:06.911159
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Note that this test can only be run if the scope of scope_replacer_t
    # is global. Need to find a way to set it to a temporary scope.
    import bzrlib.scope_replacer_t
    assert isinstance(ScopeReplacer, bzrlib.scope_replacer_t.ScopeReplacer)
    assert ScopeReplacer(BaseException, lambda x: x, 'ScopeReplacer') is BaseException


# Generated at 2022-06-24 02:51:19.547533
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that you can't use a ScopeReplacer after it is resolved."""
    globals()['foo'] = ScopeReplacer(globals(), lambda s, sc, n: 'foo', 'foo')
    disallow_proxying()
    # assigning to foo is fine, as it is not resolved yet
    foo = 'bar'
    # but using the original value of foo as a proxy should raise an error
    raises(IllegalUseOfScopeReplacer, lambda: foo)
    # now we get it resolved so we can test what happens
    x = globals()['foo']
    # assigning to it is fine, as it is resolved
    foo = 'bar'
    # but using the original value of foo as a proxy should raise an error
    raises(IllegalUseOfScopeReplacer, lambda: foo)



# Generated at 2022-06-24 02:51:27.072223
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """
    Testing the method __setattr__ of class ScopeReplacer.
    """
    class a(object):
        def __init__(self):
            self.attr = 0
        def __str__(self):
            return "a"
    import sys
    factory = lambda x, y, z: a()
    scope = sys.modules
    replacer = ScopeReplacer(scope, factory, "testing_ScopeReplacer")

    replacer.attr = 42
    return replacer

# Generated at 2022-06-24 02:51:33.366637
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Testing IllegalUseOfScopeReplacer.__unicode__()"""
    #__pychecker__ = 'maxreturns=10'
    c = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    expected = (u"ScopeReplacer object 'name' was used incorrectly: "
                u'msg: extra')
    result = unicode(c)
    assert expected == result, (expected, result)
    class TestException(Exception):
        def __unicode__(self):
            return u'test'
    c = IllegalUseOfScopeReplacer('name', TestException('test'), 'extra')
    expected = (u"ScopeReplacer object 'name' was used incorrectly: "
                u"test: extra")
    result = unicode(c)
    assert expected == result, (expected, result)

# Generated at 2022-06-24 02:51:36.860894
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import doctest
    from bzrlib import lazy_import
    return doctest.DocTestSuite(lazy_import, optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-24 02:51:45.763242
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method __eq__ of class IllegalUseOfScopeReplacer"""
    import bzrlib.tests.test_lazy_import as _mod_test_lazy_import
    from bzrlib import _dummy_exception
    _dummy_exception.install_hooks()

# Generated at 2022-06-24 02:51:56.824937
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class Dummy(object):
        """Dummy for use in testing ImportReplacer"""
        def __init__(self, real_module, real_module_path,
                     real_module_python_path, real_member,
                     children):
            self.real_module = real_module
            self.real_module_path = real_module_path
            self.real_module_python_path = real_module_python_path
            self.real_member = real_member
            self.children = children

    class DummyImportReplacer(ImportReplacer):
        """Dummy subclass of ImportReplacer to help with test"""

        def _import(self, scope, name):
            children = object.__getattribute__(self, '_import_replacer_children')
            member = object.__getattribute__(self, '_member')

# Generated at 2022-06-24 02:51:58.489890
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""


# Generated at 2022-06-24 02:52:07.436455
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__(self, attr, value) <==> x.__setattr__(i, y) <==> x[i]=y
    import bzrlib.lazy_import
    import bzrlib.errors
    # Create a scope with the object to be replaced
    bzrlib.lazy_import.test_scope = {'test_var': bzrlib.errors.BzrError}
    # Create a special scope replacer for it
    replacer = bzrlib.lazy_import.ScopeReplacer(bzrlib.lazy_import.test_scope,
                    bzrlib.lazy_import.__import, 'test_var')
    # Turn off proxying
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    # Check

# Generated at 2022-06-24 02:52:13.016068
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    my_class = IllegalUseOfScopeReplacer('unused', 'my message', 'extra')
    assert my_class.name == 'unused'
    assert my_class.msg == 'my message'
    assert my_class.extra == ': extra'
    my_class = IllegalUseOfScopeReplacer('unused', 'my message', None)
    assert my_class.extra == ''
    assert str(my_class) == 'my message:extra'



# Generated at 2022-06-24 02:52:24.087355
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests import TestCase
    class test_IllegalUseOfScopeReplacer___eq__1(TestCase):
        def test__get_format_string(self):
            self.assertEqual(
                'This is a test: {0}',
                IllegalUseOfScopeReplacer(
                    'a', 'This is a test', extra='{0}')._get_format_string())

        def test__get_format_string_no_fmt(self):
            self.assertIs(None,
                IllegalUseOfScopeReplacer(
                    'a', 'This is a test', extra='{0}')._get_format_string())


# Generated at 2022-06-24 02:52:36.501664
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    i = ImportProcessor()
    i.lazy_import({}, text='''
        import bzrlib
        from bzrlib import workingtree
        from bzrlib import (
            errors,
            urlutils,
            )
    ''')
    assert 'bzrlib' in i.imports
    assert 'errors' not in i.imports
    assert 'urlutils' not in i.imports
    assert 'workingtree' in i.imports
    assert i.imports['bzrlib'][2] == {}
    assert i.imports['bzrlib'][0] == ['bzrlib']
    assert i.imports['workingtree'][0] == ['bzrlib']
    assert i.imports['workingtree'][2] == {}
    assert 'errors'

# Generated at 2022-06-24 02:52:48.100186
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    "Test the constructor for class IllegalUseOfScopeReplacer."

    import sys
    import bzrlib.tests.blackbox

    if sys.exc_info() != (None, None, None):
        # The constructor for IllegalUseOfScopeReplacer calls sys.exc_info,
        # which is supposed to return (None, None, None) when there is no
        # active exception.  If it does not, then "convenience" functions like
        # assertRaises will not work properly.  This is a one-time test that
        # will only be run if tests are run at the top level of the package,
        # and only once.  Note that it will not be triggered if tests are run
        # with 'python -m bzrlib.tests'.
        exc_catcher = bzrlib.tests.blackbox.ExceptionCatcher()

# Generated at 2022-06-24 02:52:53.481424
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of ImportReplacer"""
    def test_constructor(children, member):
        """Try to create an instance of ImportReplacer with
        the given children/member conditions.
        """
        try:
            ImportReplacer(scope={}, name='foo', module_path=['foo'],
                           children=children, member=member)
        except ValueError:
            # A ValueError is expected when children and member
            # are both supplied.
            if children and member:
                return True
            else:
                return False

    assert test_constructor({}, None)
    assert test_constructor({'bar': ('bar', None, {})}, None)
    assert test_constructor({}, 'bar')
    assert not test_constructor({'bar': ('bar', None, {})}, 'baz')

# Unit

# Generated at 2022-06-24 02:53:01.376482
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.bzrdir import BzrDir
    from bzrlib.lazy_import import lazy_import, disallow_proxying

    # Non-proxying mode is allowed for internal tests to verify that
    # no proxies are created, but it should not be used outside of
    # tests.
    disallow_proxying()

    # Get our fake scope
    scope = {}
    lazy_import(scope, '''
    from bzrlib import (
        urlutils,
        errors,
        )
    import bzrlib.bzrdir
    ''')

    # We should have some objects that are ImportReplacer objects
    assert isinstance(scope['urlutils'], ImportReplacer)
    assert isinstance(scope['bzrdir'], ImportReplacer)
    # And some

# Generated at 2022-06-24 02:53:11.649849
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib
    # First, call the function we want to test
    disallow_proxying()
    # Then, import lazily the module we want to access
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        )
    ''')
    # Then, try to get something from it
    try:
        errors
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Disallow_proxying() failed to raise an exception')
    # Now, re-allow proxies
    ScopeReplacer._should_proxy = True

