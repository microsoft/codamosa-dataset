

# Generated at 2022-06-24 02:43:12.530976
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer

    This test is to check the correct exception message is returned
    when incorrect usage is made of a ScopeReplacer object.
    """
    class Foo(object):
        pass
    foo = Foo()
    err = IllegalUseOfScopeReplacer('bar', 'foo goes to %(foobar)s', extra=foo)
    msg = unicode(err)
    expected = 'ScopeReplacer object \'bar\' was used incorrectly: foo goes to %(foobar)s: %r' % (foo,)
    assert msg == expected



# Generated at 2022-06-24 02:43:15.383108
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Test method __repr__ of IllegalUseOfScopeReplacer"""
    inst = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(inst) == \
"""Cannot use ScopeReplacer object 'name' incorrectly: msg: extra"""


# Generated at 2022-06-24 02:43:24.721988
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying works as expected."""

    # We will overwrite the dictionary in the module being imported, so
    # use a copy to keep the original one clean.
    import bzrlib.tests
    import bzrlib.tests.__init__

    __init___copy = bzrlib.tests.__init__.__dict__.copy()

    test_module_name = 'bzrlib.tests.__init__'

    # The module has not yet been imported, so this should fail

# Generated at 2022-06-24 02:43:32.022804
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    # The target dictionary for the lazy imports
    test_module_scope = {}
    # Define the lazy imports
    lazy_import(test_module_scope, '''
    from bzrlib import (
        osutils,
        )
    ''')
    # This will cause the real module to be loaded into the global namespace
    test_module_scope["osutils"]._resolve()
    test_module_scope["osutils"].chdir(".")
    # After this call the real module will have been loaded into the target
    # dictionary.
    test_module_scope["osutils"].rmtree(".")
    # Now the module has been loaded, and we can access it members directly.
    test_module_scope["osutils"].chdir(".")


# Generated at 2022-06-24 02:43:34.583790
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    raise NotImplementedError(
        'Test not implemented.')

    # TODO: Update test_ScopeReplacer___call__ to use new-style method
    # signatures.
    # raise NotImplemented



# Generated at 2022-06-24 02:43:38.680603
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test for constructor of class ImportProcessor

    The constructor of ImportProcessor is designed to convert text that users
    input into lazy import requests.

    This test will check how it works when there is no text.
    """
    ip = ImportProcessor()
    ip.imports = {}
    ip._lazy_import_class = ImportReplacer

    assert isinstance(ip, ImportProcessor), "ip is not a ImportProcessor."



# Generated at 2022-06-24 02:43:50.589286
# Unit test for function lazy_import
def test_lazy_import():
    proc = ImportProcessor()
    proc.lazy_import(globals(), '''
        from bzrlib import foo as bar
        import bzrlib.branch
        import bzrlib.transport
        ''')
    # Check that we imported the right things
    assert(proc.imports == {
        'bar': (['bzrlib'], 'foo', {}),
        'bzrlib': (['bzrlib'], None, {'branch': (['bzrlib'], 'branch', {}),
                                       'transport': (['bzrlib'], 'transport', {})}),
        })
    # Check that the right things are in globals()
    import bzrlib
    assert 'bar' in globals()
    assert bzrlib.foo is bar

# Generated at 2022-06-24 02:44:01.272554
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """ScopeReplacer.__setattr__

    Assigns a new value to the specified attribute.  If the object has
    already been replaced, raises because this is in fact illegal.
    """
    from bzrlib.tests.lazy_import_helper import MockScope, MockObj
    def factory(self, scope, name):
        return MockObj()
    # Some objects we will use for testing
    module = MockObj()
    module.__name__ = 'bzrlib.test_module'
    module.test_module = module
    # Set up a scope
    scope = MockScope()
    scope['name'] = 'bzrlib.test_module'
    # And finally the replacer
    replace = ScopeReplacer(scope, factory, 'module')
    # Mutate a property of the replacer
    replace.test

# Generated at 2022-06-24 02:44:08.454885
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_str = '''
    import bzrlib
    import bzrlib.foo

    import bzrlib.foo.bar as foo
    import bzrlib.foo.bar.baz as baz

    import bzrlib.foo, bzrlib.bar.baz

    import ( bzrlib.foo, bzrlib.bar.baz
             bzrlib.hello.world, bzrlib.goodbye.world )
    '''

    from_str = '''
    from bzrlib import foo
    from bzrlib import foo as bar

    from bzrlib import ( foo, bar, baz
                         hello, world, goodbye, world )
    '''

    # Mixing import and from

# Generated at 2022-06-24 02:44:16.373376
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ method of class IllegalUseOfScopeReplacer"""
    e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e1 == e2
    assert not (e1 != e2)
    # test differences
    e3 = IllegalUseOfScopeReplacer('othername', 'msg', 'extra')
    assert not (e1 == e3)
    assert e1 != e3
    assert e1 != None
    assert None != e1



# Generated at 2022-06-24 02:44:21.931334
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test method __setattr__ of class ScopeReplacer"""
    __unittest = True
    import doctest
    OptionFlags = doctest.NORMALIZE_WHITESPACE|doctest.ELLIPSIS
    doctest.testmod(optionflags=OptionFlags)


# Generated at 2022-06-24 02:44:32.086626
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.lazy_import import lazy_import
    children = {
        'foo':(['bzrlib', 'foo'], None, {}),
        'bar':(['bzrlib', 'bar'], None, {}),
        }
    scope = {}
    lazy_import(scope, 'from bzrlib import foo, bar')
    assert len(scope) == 1
    foo, = scope.values()
    assert isinstance(foo, ImportReplacer)
    assert foo._import_replacer_children == children
    assert foo._member is None
    assert foo._module_path == ['bzrlib']

    scope = {}
    # test that the children replacers are made at the right time (after
    # the parent has been resolved)
    # Also, test that it is safe to call lazy_import

# Generated at 2022-06-24 02:44:39.543185
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    e1 = IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra')
    assert e1 == e2


# Tests for IllegalUseOfScopeReplacer
#
# Note: To test the formatting, we have to use a pre-formatted string, and
# an explicit format string.  Testing the formatting itself is hard, because
# we can't be sure of the locale being used.

# Generated at 2022-06-24 02:44:46.940778
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    disallow_proxying()
    try:
        errors.BzrError
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Module should not be used as a proxy')
    try:
        osutils.pathjoin
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Module should not be used as a proxy')
    try:
        branch.BzrBranch
    except IllegalUseOfScopeReplacer:
        pass

# Generated at 2022-06-24 02:44:56.191186
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    # We fake the scope with a dict.
    scope = locals()
    # We create a factory that will return 'bzrlib'
    def factory(self, scope, name):
        return bzrlib
    # We create a ScopeReplacer with the fake scope, factory and name
    sr = ScopeReplacer(scope, factory, 'foo')
    # We test that the method bzrlib.version.get_version_string will be called
    # with the arguments: foo, scope and name
    bzrlib.version.get_version_string = lambda x, y, z: 'bar'
    assert sr('foo', 'scope', 'name') == 'bar'
    # We remove the fake attribute from bzrlib.version
   

# Generated at 2022-06-24 02:44:59.667016
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Ensures that ImportProcessor can be constructed with and without
       arguments.
    """
    ImportProcessor()
    ImportProcessor(ImportReplacer)

_import = __import__



# Generated at 2022-06-24 02:45:08.136108
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Unit test for constructor of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e.name == 'name'
    assert e.msg == 'msg'
    assert e.extra == ': extra'
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert e.name == 'name'
    assert e.msg == 'msg'
    assert e.extra == ''
    str(e)
    unicode(e)
    repr(e)


# Generated at 2022-06-24 02:45:15.589394
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test calling a ScopeReplacer
    def get_bar():
        return "bar"
    def factory(self, scope, name):
        return get_bar
    scope = {}
    # ScopeReplacer is called here
    replacer = ScopeReplacer(scope, factory, name="foo")
    # foo is an object with a method '__call__'.
    eq_(scope["foo"](""), 'bar')
    # And the method '__call__' returns the same object
    eq_(scope["foo"](""), 'bar')
    eq_(replacer(""), "bar")



# Generated at 2022-06-24 02:45:22.132846
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test IllegalUseOfScopeReplacer constructor"""
    exc = IllegalUseOfScopeReplacer('name', 'msg')
    assert exc.name == 'name'
    assert exc.msg == 'msg'
    assert exc.extra == ''
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert exc.name == 'name'
    assert exc.msg == 'msg'
    assert exc.extra == ': extra'



# Generated at 2022-06-24 02:45:29.018695
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    # Test attribute access to a resolved object
    global unittest_scope
    unittest_scope = {}
    def make_real_object(self, scope, name):
        global unittest_scope
        unittest_scope = scope
        return 'ok'
    scope = {}
    scope_replacer = ScopeReplacer(scope, make_real_object, 'foo')
    object.__setattr__(scope_replacer, '_should_proxy', True)
    scope['foo'].__class__
    scope['foo'].__name__
    scope['foo'].__doc__



# Generated at 2022-06-24 02:45:38.122949
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer("name1", "msg1", extra="extra1")
    assert e.name == "name1"
    assert e.msg == "msg1"
    assert e.extra == ": extra1"
    assert str(e) == 'ScopeReplacer object \'name1\' was used incorrectly: msg1: extra1'
    assert repr(e) == "IllegalUseOfScopeReplacer('name1', 'msg1', ': extra1')"
    assert e == IllegalUseOfScopeReplacer("name1", "msg1", extra="extra1")
    assert e != IllegalUseOfScopeReplacer("name1", "msg2", extra="extra1")
    assert e != IllegalUseOfScopeReplacer("name1", "msg1", extra="extra2")
    assert e != 1



# Generated at 2022-06-24 02:45:46.290985
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    # see http://lists.canonical.org/pipermail/bazaar/2005-October/005052.html
    e = IllegalUseOfScopeReplacer("foobar", "abc" * 1000)
    assert e.name == "foobar"
    assert isinstance(e.msg, str)
    assert len(e.msg) == 3000
    e.__dict__["_preformatted_string"] = "arf"
    assert unicode(e) == "arf"
    e.__dict__["_preformatted_string"] = None
    assert unicode(e).startswith("IllegalUseOfScopeReplacer")



# Generated at 2022-06-24 02:45:54.578761
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    replicate_test(ScopeReplacer, 'ScopeReplacer', '__call__')

    # imports
    def ScopeReplacer_call_factory(self, scope, name):
        import bzrlib.tests
        return bzrlib.tests

    globs = {}
    lazy_import(globs, '''
        from bzrlib.lazy_import import (
            ScopeReplacer,
            )
        ''', 'bzrlib.tests')
    globs['ScopeReplacer'].__call__ = ScopeReplacer_call_factory

    globs['ScopeReplacer'](globs, globs['ScopeReplacer'], 'bzrlib.tests')
    try:
        bzrlib.tests.TestCase()
    except AttributeError as e:
        raise TestNotApplicable(str(e))

# Generated at 2022-06-24 02:46:06.293265
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str.

    It should also always return an encoding of the unicode string that
    __unicode__ returns.
    """
    import sys
    if sys.getdefaultencoding() != 'utf-8':
        raise TestSkipped('__str__ of IllegalUseOfScopeReplacer is only valid '
                          'when the default encoding is utf8.')
    obj = IllegalUseOfScopeReplacer(u'peter', u'name')
    s = str(obj)
    assert isinstance(s, str), '__str__ should return a str.'
    u = unicode(obj)
    assert isinstance(s, str), '__unicode__ should return a unicode string.'

# Generated at 2022-06-24 02:46:10.728159
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    # Create a couple of instances to compare
    instance = IllegalUseOfScopeReplacer('fred', 'frobbed')
    other_instance = IllegalUseOfScopeReplacer('fred', 'frobbed')

    # Test that the two instances are equal
    assert (instance == other_instance)
test_IllegalUseOfScopeReplacer___eq__.unittest = ['.classes']



# Generated at 2022-06-24 02:46:19.294740
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    def check(expected, s):
        if isinstance(expected, unicode):
            expected = expected.encode('utf8')
        if s != expected:
            print (u'should have been "%s" but was "%s"'
                   % (unicode(expected, 'utf8'), unicode(s, 'utf8')))
    s = IllegalUseOfScopeReplacer('name', 'msg')
    check("name was used incorrectly: msg", s)
    check("name was used incorrectly: msg", str(s))
    check("name was used incorrectly: msg", unicode(s))
    check("name was used incorrectly: msg",
          unicode(IllegalUseOfScopeReplacer, 'name', 'msg'))



# Generated at 2022-06-24 02:46:27.785043
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a legal python string that can be eval'ed to
    recreate the object.

    If the object has a __repr__ method, then that method is used.
    """
    e = IllegalUseOfScopeReplacer('x', 'y', 'z')
    s = repr(e)
    t = eval(s)
    assert isinstance(t, IllegalUseOfScopeReplacer)
    assert t == e

# Generated at 2022-06-24 02:46:30.424532
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    imports = ImportProcessor()
    assert isinstance(imports._lazy_import_class, type)
    del imports
    imports = ImportProcessor(lazy_import_class=1)
    assert imports._lazy_import_class is 1
    del imports


# Generated at 2022-06-24 02:46:36.273789
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ returns unicode"""
    obj = IllegalUseOfScopeReplacer('name', 'msg')
    result = obj.__unicode__()
    # Result must be of class 'unicode'
    assert isinstance(result, unicode), repr(result)
    # Assert that the result is correct
    assert result == u'IllegalUseOfScopeReplacer(name)', repr(result)


# Generated at 2022-06-24 02:46:48.148370
# Unit test for function lazy_import
def test_lazy_import():
    """Test that the lazy_import helper works correctly"""
    class _TestImportReplacer(ImportReplacer):
        
        def __init__(self, scope, name, module_path, member=None, children={}):
            ImportReplacer.__init__(self, scope, name, module_path,
                                    member=member, children=children)
            self._trace = []
            self._name = name

        def _import(self, scope, name):
            self._trace.append(name)
            return ImportReplacer._import(self, scope, name)
    name = 'example'
    # Create a set of variables to import into
    ent = {
        'list':list,
        'dict':dict}
    # Now ask it to populate itself with lazy imports

# Generated at 2022-06-24 02:47:00.200260
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class FakeModule(object):
        pass
    scope = {}
    import_replacer = ImportReplacer(scope, 'bzrlib', ['bzrlib'])
    assert scope == {'bzrlib':import_replacer}, scope
    assert import_replacer._scope == scope
    assert import_replacer._import_replacer_children == {}, \
        import_replacer._import_replacer_children
    assert import_replacer._member is None
    assert import_replacer._module_path == ['bzrlib']
    import_replacer._factory(scope, 'bzrlib')
    assert scope == {'bzrlib':FakeModule()}, scope
    # Can get 'bzrlib' from the scope, even though we imported it into the
    # scope.

# Generated at 2022-06-24 02:47:11.150040
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class DummyClass(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __call__(self, *args, **kwargs):
            self.args += args
            self.kwargs.update(kwargs)
            return self.__class__

    scope = {}
    factory = DummyClass

    # __call__ returns the real instance which is an instance of DummyClass.
    scope_replacer = ScopeReplacer(scope, factory, 'DummyClass')
    self.assertIsInstance(scope_replacer(), DummyClass)
    # The real instance has the same arguments which were passed to
    # ScopeReplacer.
    self.assertEqual([], scope_replacer.args)

# Generated at 2022-06-24 02:47:19.605095
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # __getattribute__ -> self._resolve
    # self._resolve -> getattr
    # getattr -> __getattribute__
    # self._resolve -> getattr
    s = ScopeReplacer(
        {},
        factory=lambda x, y, name: x,
        name='scope_replacer')
    try:
        s.__getattribute__('foo')
    except IllegalUseOfScopeReplacer as e:
        assert str(e) == """
ScopeReplacer object 'scope_replacer' was used incorrectly:
Object tried to replace itself, check it's not using its own scope.
"""
    else:
        raise AssertionError("ScopeReplacer.__getattribute__ did not raise")
ScopeReplacer.test_ScopeReplacer___getattribute__ = (
    test_ScopeReplacer___getattribute__)
del test

# Generated at 2022-06-24 02:47:30.565033
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This test method was automatically generated by testtools. Please do not
    modify directly.
    """
    from unittest import TestCase
    class TestIllegalUseOfScopeReplacer___str__(TestCase):
        def test_IllegalUseOfScopeReplacer___str__(self):
            """This test was generated programmatically by testtools.
            Please do not modify directly, use the supervisor methods
            on TestCase instead.
            """
            import bzrlib.lazy_import
            self.failUnlessRaises(NotImplementedError,
                    getattr, bzrlib.lazy_import.IllegalUseOfScopeReplacer,
                                                            '_get_format_string')



# Generated at 2022-06-24 02:47:36.210204
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of the class ImportProcessor"""
    import_processor = ImportProcessor()
    import bzrlib.trace
    assert import_processor._lazy_import_class == ImportReplacer
    # The naming convention is import_processor._lazy_import_class, but we don't
    # yet have pychecker support for that



# Generated at 2022-06-24 02:47:45.783273
# Unit test for function disallow_proxying
def test_disallow_proxying():
    # Test that using lazy module as proxy fails after this call
    disallow_proxying()
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        )
    import bzrlib
    ''')
    def use_module(name):
        try:
            return name in globals()
        except IllegalUseOfScopeReplacer:
            return False
    assert use_module('errors')
    try:
        use_module('bzrlib')
        raise AssertionError('Must raise IllegalUseOfScopeReplacer')
    except IllegalUseOfScopeReplacer:
        pass
    assert 'errors' not in globals()
    assert 'bzrlib' not in globals()



# Generated at 2022-06-24 02:47:56.314242
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test IllegalUseOfScopeReplacer.

    Must provide a __unicode__() method.
    """
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    # Python 2.6.1 throws SyntaxError if it is not provided.
    str(e1)
    cmp(unicode(e1), "bar")
    e2 = IllegalUseOfScopeReplacer('a', 'b', 'c')
    cmp(unicode(e2), "b: c")
    e3 = IllegalUseOfScopeReplacer('a', u'b', 'c')
    # Python 2.6.1 throws TypeError
    cmp(unicode(e2), u"b: c")



# Generated at 2022-06-24 02:48:05.513682
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    disallow_proxying()

# Generated at 2022-06-24 02:48:17.244856
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_i18n import _get_tr_str
    class TestIllegalUseOfScopeReplacer(TestCase):
        def mk(self, name, msg, extra=None):
            return IllegalUseOfScopeReplacer(name, msg, extra)
        def test__get_format_string(self):
            e = self.mk('foo', 'bar')
            self.assertEqual('ScopeReplacer object %(name)r was used incorrectly: '
                             '%(msg)s%(extra)s',
                             e._get_format_string())


# Generated at 2022-06-24 02:48:22.102807
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    s = "This is an example message"
    e = IllegalUseOfScopeReplacer("bzrlib", "%s", (s,))
    assert repr(e) == 'IllegalUseOfScopeReplacer(%r)' % (str(e),)


# This is the 'magic' object that will be replaced with the real objects
# when they are used

# Generated at 2022-06-24 02:48:32.357613
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import bzrlib.trace
    scope = bzrlib.trace.ScopeReplacer._scope
    bzrlib.lazy_import.lazy_import(scope, 'from bzrlib.branch import Branch')
    import bzrlib.branch
    bzrlib.lazy_import.lazy_import(scope, 'from bzrlib import transport')
    import bzrlib.transport
    from bzrlib.trace import mutter
    mutter('bzrlib.branch: %s', bzrlib.branch) # also set by lazy_import
    # Continue to work even though the object has been replaced.
    bzrlib.trace.ScopeReplacer._should_proxy = False
    # Only allow one operation, then

# Generated at 2022-06-24 02:48:38.945973
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer

    The object should be strable, and at least give enough information
    to be useful.
    """
    s = IllegalUseOfScopeReplacer('name', 'meh')
    assert str(s).startswith('IllegalUseOfScopeReplacer('), str(s)



# Generated at 2022-06-24 02:48:47.130470
# Unit test for function lazy_import
def test_lazy_import():
    """Test function lazy_import"""
    from bzrlib.tests import TestCaseWithTransport
    tmp_dir = TestCaseWithTransport.get_test_permutations()[0][1]
    tmp_dir.create_dir('foo')
    tmp_dir.create_dir('foo/bar')
    tmp_dir.get_child('foo/bar').create_file('baz.py')
    t = tmp_dir.get_child('foo/bar/baz.py').get_text()
    t += """\
from bzrlib.foo.bar.baz import bing
"""
    tmp_dir.get_child('foo/bar/baz.py').set_text(t)
    t = tmp_dir.get_child('foo').get_text()

# Generated at 2022-06-24 02:48:48.620962
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    s = IllegalUseOfScopeReplacer('name', 'msg')
    unicode(s)


# Generated at 2022-06-24 02:48:59.197283
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    def check_irm(irm, member, children):
        assert irm._member == member
        assert irm._import_replacer_children == children
        assert isinstance(irm, ImportReplacer)
        if children:
            for name, (path, member, grandchildren) in children.iteritems():
                assert irm._import_replacer_children[name]._name == name
    # Test direct module import
    module_dict = {}
    ImportReplacer(module_dict, name='foo', module_path=['foo'],
                   member=None, children={})
    check_irm(module_dict['foo'], None, {})
    # Test module import with child import
    module_dict = {}

# Generated at 2022-06-24 02:49:10.665802
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    """Test __setattr__ of ScopeReplacer."""
    class DummyTest(TestCase):
        class DummyScopeReplacer(ScopeReplacer):
            def __init__(self):
                pass
        def setUp(self):
            self.subject = DummyTest.DummyScopeReplacer()
        def test_calls_ScopeReplacer__setattr__(self):
            # Having ScopeReplacer as a base class, we expect that
            # __setattr__ of the base class will be called.
            def _mock_real__setattr__(self, attr, value):
                self.called = True
            original_real__setattr__ = self.subject.__setattr__
            self.subject.__setattr__ = _mock_real__setattr__
           

# Generated at 2022-06-24 02:49:15.266116
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """ScopeReplacer constructor should not allow assignments to members"""
    import sys
    def factory(self, scope, name):
        pass
    e = None

# Generated at 2022-06-24 02:49:19.860594
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return an evaluable string"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r = repr(e)
    assert eval(r) == e


# Generated at 2022-06-24 02:49:26.878209
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib import lazy_import
    import __builtin__
    old_imp = __builtin__.__import__
    __builtin__.__import__ = bzrlib.tests.monkey_patch(__builtin__.__import__)

# Generated at 2022-06-24 02:49:28.685616
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Tests for IllegalUseOfScopeReplacer.__eq__"""
    raise NotImplementedError(__name__ + '.test_IllegalUseOfScopeReplacer___eq__')



# Generated at 2022-06-24 02:49:30.981020
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    ScopeReplacer(scope, None, 'ScopeReplacer')
    scope['ScopeReplacer']._resolve()


# Generated at 2022-06-24 02:49:43.952384
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Check that IllegalUseOfScopeReplacer is unicode clean."""
    # We use a unicode string here on purpose to check that we are
    # encoding properly, that is, that we are not simply passing the
    # unicode value up to the next class.
    msg = u'Something Happened'
    err = IllegalUseOfScopeReplacer('foo', msg)
    # All we can do is call the unicode() function and check that we
    # get back a string as expected. Not much else we can do really,
    # except try to decode the result using the default encoding,
    # which should give is a unicode string.
    u = unicode(err)
    err_u = unicode(u, 'utf-8')
    u2 = err._format()
    err_u = unicode(u2, 'utf-8')

# Generated at 2022-06-24 02:49:55.103063
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests import TestCase
    # Some of this is not very useful, but it is needed to test the
    # constructor.
    class Foo(TestCase):
        def setUp(self):
            super(Foo, self).setUp()
            self.scope = {}
        def _test_import(self, name, module_path, member, children):
            ImportReplacer(self.scope, name, module_path, member, children)
    foo = Foo(methodName='__init__')
    foo.setUp()
    foo._test_import('foo', ['foo'], None, {})
    foo._test_import('foo', ['foo'], 'bar', {})

# Generated at 2022-06-24 02:50:07.746451
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """An unit test for ImportProcessor."""
    scope = {}

# Generated at 2022-06-24 02:50:17.596636
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test cases for ScopeReplacer"""
    # Stress test for copy-on-write
    class A(object):
        __slots__ = ('a', )
    class B(object):
        __slots__ = ('b', )
    class C(object):
        __slots__ = ('c', )

    def _factory(sr, scope, name):
        if name == 'x':
            return A()
        if name == 'y':
            return B()
        if name == 'z':
            return C()
        # Unreachable but if it does somehow occur it will cause an exception
        return object()

    x = ScopeReplacer(globals(), _factory, 'x')
    # x.a is not yet defined because the factory hasn't been called yet

# Generated at 2022-06-24 02:50:29.357940
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test method ScopeReplacer.__getattribute__
    
    This tests the behaviour of __getattribute__ of ScopeReplacer,
    including handling of methods and attributes.
    """
    from bzrlib.branch import Branch
    branch = Branch.initialize('.')
    # Test attribute access.
    result = branch.__getattribute__('revno')
    expected = 0
    assert result == expected, "%r != %r" % (result, expected)
    from os.path import join
    result = branch.__getattribute__('controlled_files')
    expected = set([join('.', 'format'), join('.', 'branch-nick'),
            join('.', 'branch-format'), join('.', 'last-revision')])
    assert result == expected, "%r != %r" % (result, expected)


# Generated at 2022-06-24 02:50:31.486926
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    def factory(self, scope, name):
        return scope[name]
    o = ScopeReplacer(scope, factory, name='o')
    scope['o'] = object()
    o._resolve()
    return o



# Generated at 2022-06-24 02:50:39.360268
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """ImportProcessor.lazy_import(scope, text)"""
    import __future__
    import cStringIO
    import re

    proc = ImportProcessor()
    try:
        from testtools import PlaceHolder
        PlaceHolder # pyflakes
    except ImportError:
        from testtools.tests.placeholders import PlaceHolder
    scope = {'PlaceHolder': PlaceHolder}
    text = """\
    import __future__
    from cStringIO import StringIO
    from testtools import PlaceHolder as place
    from testtools.tests.placeholders import PlaceHolder as place2
    """
    proc.lazy_import(scope, text)
    proc1 = ImportProcessor(lazy_import_class=PlaceHolder)
    proc1.lazy_import(scope, text)

# Generated at 2022-06-24 02:50:47.598516
# Unit test for function lazy_import
def test_lazy_import():
    """Test the actual implementation of lazy_import"""
    import testtools
    from bzrlib.lazy_import import ImportReplacer, ScopeReplacer

    g = {}
    lazy_import(g, '''
    from bzrlib import (foo, bar, baz)
    import bzrlib.branch
    import bzrlib.transport
    ''')
    for key in ('foo', 'bar', 'baz', 'branch', 'transport'):
        testtools.TestCase.assertIsInstance(
                g[key], ImportReplacer,
                '%s != ImportReplacer' % g[key])
        testtools.TestCase.assertFalse(hasattr(g[key], '__bases__'))
    b = g['branch']

# Generated at 2022-06-24 02:50:59.065706
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import os
    def my_os_path_getattr(obj, attr):
        return os.path.__getattribute__(attr)
    scope = { }
    scope_replacer = ScopeReplacer(scope, my_os_path_getattr, 'os')
    assert scope['os'] == scope_replacer
    #print scope['os'].__getattribute__('isdir')
    #assert scope['os'].isdir == os.path.isdir
    #assert scope['os'].__getattribute__('isdir') == os.path.__getattribute__('isdir')
    #assert scope['os'].__getattribute__('__getattribute__') == os.path.__getattribute__
    #assert scope['os'].__getattribute__('isdir') == scope_replacer.__getattribute__('isd

# Generated at 2022-06-24 02:51:09.766730
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import re
    import weakref
    class Connection(object):
        closed = False
        def __init__(self, db):
            self.db = weakref.ref(db)
        def close(self):
            if self.closed:
                return
            self.closed = True
            self.db().connections.remove(self)
    class Db(object):
        def __init__(self):
            self.connections = set()
        def connect(self):
            c = Connection(self)
            self.connections.add(c)
            return c
    db = Db()
    from bzrlib.errors import BzrError

# Generated at 2022-06-24 02:51:22.538832
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import bzrlib
    import bzrlib.commands
    import bzrlib.version
    from bzrlib import errors
    from bzrlib.version import _format_version

    # Test basic import
    # TODO: jam 20060913 This test is very incomplete.
    imp = ImportProcessor()
    imp.lazy_import(locals(), """
        import bzrlib
        import bzrlib.commands""")

    assert bzrlib.__class__ is ImportReplacer
    assert bzrlib.commands.__class__ is ImportReplacer
    assert errors.__class__ is ImportReplacer

    # Test from import
    imp = ImportProcessor()
    imp.lazy_import(locals(), """
        from bzrlib import version""")

    assert version.__

# Generated at 2022-06-24 02:51:28.833061
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    inst = IllegalUseOfScopeReplacer("_name", "msg", "extra")
    inst.__dict__['_preformatted_string'] = 'preformatted'
    got = inst.__unicode__()
    expected = 'preformatted'
    assert expected == got, '%r != %r' % (expected, got)

    inst = IllegalUseOfScopeReplacer("_name", "msg", "extra")
    inst._fmt = 'message: %(msg)s'
    got = inst.__unicode__()
    expected = 'message: msg'
    assert expected == got, '%r != %r' % (expected, got)



# Generated at 2022-06-24 02:51:37.478431
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Test the _resolve() method of the proxy object
    import bzrlib
    # Note that this will import the module, but the test should pass
    # whether its done lazily or not.
    assert bzrlib._lazy_load_path is None
    obj = ScopeReplacer({}, lambda x, y, z: bzrlib, 'bzrlib')
    assert obj == bzrlib
    assert obj._resolve() == bzrlib
    assert obj._resolve() == bzrlib
    # test __getattribute__ of the object
    # object.__getattribute__(obj, '_resolve')()
    global _should_proxy
    old_should_proxy = _should_proxy
    _should_proxy = False

# Generated at 2022-06-24 02:51:39.898288
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()

# Unit tests for method _canonicalize_import_text of class ImportProcessor

# Generated at 2022-06-24 02:51:51.954214
# Unit test for function lazy_import
def test_lazy_import():
    """Test ImportProcessor.lazy_import"""
    # We don't need _real_ modules, so just make mocks
    class MockModule(object):
        def __init__(self, path):
            _mocks_by_path[path] = self
        def __repr__(self):
            return '<mock %s>' % self.__class__.__name__

    class MockBranchClass(MockModule):
        def __init__(self):
            MockModule.__init__(self, 'bzrlib.branch.Branch')
            self.Branch = self

    class MockBzrLib(MockModule):
        def __init__(self):
            MockModule.__init__(self, 'bzrlib')

    global _mocks_by_path
    _mocks

# Generated at 2022-06-24 02:51:55.310682
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    lazy_import(sys.modules[__name__], '''
    import bzrlib
    ''')
    disallow_proxying()
    globals()['bzrlib'].osutils



# Generated at 2022-06-24 02:52:02.093082
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_text = """
    from foo import bar, baz
    from foo.bar import bing as boom
    import foo, foo.bar as fb
    """
    import_map = {'bar': (['foo'], 'bar', {}),
                  'boom': (['foo', 'bar'], 'bing', {}),
                  'fb': (['foo'], 'bar', {}),
                  'foo': (['foo'], None,
                          {'bar': (['foo', 'bar'], None,
                                   {'bing': (['foo', 'bar', 'bing'], None, {})})})}
    import_processor = ImportProcessor()
    import_processor._build_map(import_text)

# Generated at 2022-06-24 02:52:09.599263
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import bzrlib.tests.blackbox
    import bzrlib.tests
    # No exception
    ImportReplacer(scope=bzrlib.tests.blackbox.__dict__,
                   name='tests',
                   module_path=['bzrlib', 'tests'])
    ImportReplacer(scope=bzrlib.tests.__dict__,
                   name='blackbox',
                   module_path=['bzrlib', 'tests', 'blackbox'])



# Generated at 2022-06-24 02:52:15.382437
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    ImportReplacer(scope, name='foo', module_path=['foo'],
                   member=None, children={'bar':(['foo', 'bar'], None, {})})
    try:
        ImportReplacer(scope, name='foo', module_path=['foo'],
                       member='bar', children={'bar':(['foo', 'bar'], None, {})})
        raise AssertionError('member and children should not be provided')
    except ValueError:
        pass



# Generated at 2022-06-24 02:52:23.532878
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that ImportProcessor returns the object requested"""

    # Test the default return value
    ip = ImportProcessor()
    assert isinstance(ip, ImportProcessor), \
        'Instance of ImportProcessor is not returned'
    assert ip.imports == {}, \
        'Instance of ImportProcessor does not have imports'
    assert isinstance(ip._lazy_import_class, ImportReplacer), \
        'Instance of ImportProcessor does not have correct lazy_import_class'

    # Test the custom lazy import class
    class TestImport(object):
        pass
    ip = ImportProcessor(TestImport)
    assert isinstance(ip._lazy_import_class, TestImport), \
        'Instance of ImportProcessor does not have correct lazy_import_class'


# Generated at 2022-06-24 02:52:35.660727
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""
    scope = {}
    lazy_import(scope, '''
    import bzrlib.branch
    import bzrlib.transport
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    from bzrlib.foo import (
        bar,
        baz,
        )
    from bzrlib.foo.bar import (
        baz,
        )
    ''')
    # Check that the bzrlib.branch is a LazyImport
    scope['bzrlib'].branch
    # Check that foo, bar, and baz is really a LazyImport
    scope['foo']
    scope['bar']
    scope['baz']
    # Check that foo.bar is a LazyImport


# Generated at 2022-06-24 02:52:46.820819
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test that the IllegalUseOfScopeReplacer object initializes correctly"""
    e = IllegalUseOfScopeReplacer('a','b','c')
    # Sanity check the class
    assert str(e) == 'Unprintable exception IllegalUseOfScopeReplacer: ' \
        'dict={\'extra\': \': c\', \'name\': \'a\', \'msg\': \'b\'},' \
        ' fmt=\'ScopeReplacer object %%(name)r was used incorrectly: ' \
        '%%(msg)s%%(extra)s\', error=None'
    # Check constructor
    assert e.name == 'a'
    assert e.msg == 'b'
    assert e.extra == ': c'



# Generated at 2022-06-24 02:52:55.233624
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that calls to disallow_proxying() are effective.

    We don't use real unit testing here, just a quick test that
    sets a global variable.
    """
    global disallow_proxying_result
    disallow_proxying_result = 'no effect'
    disallow_proxying()
    disallow_proxying()
    disallow_proxying()
    disallow_proxying_result = ('at this point, we do not allow'
                                ' ScopeReplacer to be used as a proxy')



# Generated at 2022-06-24 02:53:06.627999
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class A(IllegalUseOfScopeReplacer):
        pass
    a = A('foo', 'msg', 'extra')
    b = A('bar', 'msg2', 'extra')
    c = A('foo', 'msg', 'extra')
    d = A('foo', 'msg', 'extra2')
    e = A('foo', 'msg2')
    assert a is not c
    assert a == c
    assert a != b
    assert a != d
    assert a != e
    # Check that overriding __eq__ works
    class B(IllegalUseOfScopeReplacer):
        def __eq__(self, other):
            return True
    b = B('foo', 'msg', 'extra')
    c = B('bar', 'msg2', 'extra')
    assert b == c

