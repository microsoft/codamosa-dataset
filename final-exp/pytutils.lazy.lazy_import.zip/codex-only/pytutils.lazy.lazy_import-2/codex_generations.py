

# Generated at 2022-06-24 02:43:18.373328
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor"""
    import_processor = ImportProcessor()
    # Test case 1
    imports_list = """
    import foo.bar
    """
    import_processor.imports = {}
    import_processor._build_map(imports_list)
    assert import_processor.imports == {'foo' : (['foo'], None, {'bar' : (['foo', 'bar'], None, {})})}
    # Test case 2
    imports_list = """
    from foo import bar
    """
    import_processor.imports = {}
    import_processor._build_map(imports_list)
    assert import_processor.imports == {'bar' : (['foo'], 'bar', {})}

    # Test case 3

# Generated at 2022-06-24 02:43:20.767675
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ method of IllegalUseOfScopeReplacer works with identical objects

    returns true when objects are the same.
    """
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    return e1 == e2
assert test_IllegalUseOfScopeReplacer___eq__()

# Generated at 2022-06-24 02:43:30.089439
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Smoketest constructor

    # Actions:
    # - Should 'import foo'
    # - Should 'import foo.bar'
    # - Should 'from foo import baz'
    # - After 'import foo.bar' is accessed, should 'import foo.bar.baz'
    # - Before 'import foo.bar' is accessed, should not access
    #   'foo.bar.baz'
    # - Importing 'foo' should not access 'foo.bar'
    # - Importing 'foo' should not access 'foo.baz'
    # - Importing 'foo.bar' should not access 'foo.bar.baz'
    module_dict = {}

# Generated at 2022-06-24 02:43:39.754273
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def test_factory(self, scope, name):
        return scope[name] + 1
    scope = {'name': 1}
    replacer = ScopeReplacer(scope, test_factory, 'name')
    assert replacer._resolve() == 2
    replacer2 = replacer._resolve()
    assert replacer2 == 2
    replacer2 += 10
    assert replacer2 == 12
    assert replacer._resolve() == 12
    replacer3 = replacer + 1
    assert replacer3 == 13
    # test assignment of new members
    replacer.attr = "value"
    assert replacer.attr == "value"
    # test assignment of new members after replacement
    replacer2 = replacer._resolve()
    assert replacer2 == 12
    replacer2.attr = "value"

# Generated at 2022-06-24 02:43:51.846295
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() should return a string that can be
    passed to eval() to reconstruct the object.
    """
    obj = IllegalUseOfScopeReplacer(name='name', msg='msg', extra='extra')
    repr_str = repr(obj)
    assert repr_str == 'IllegalUseOfScopeReplacer(name=\'name\', msg=\'msg\', ' \
        'extra=\'extra\')'
    eval_str = 'from bzrlib.lazy_import import IllegalUseOfScopeReplacer; ' \
        'IllegalUseOfScopeReplacer(name=\'name\', msg=\'msg\', ' \
        'extra=\'extra\')'
    assert eval(repr_str) == eval(eval_str)

test_IllegalUseOfScopeReplacer

# Generated at 2022-06-24 02:43:56.206945
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import sys
    import bzrlib.import_processor

    # e.g. from bzrlib import foo, bar
    bzrlib_importer = bzrlib.import_processor.ImportProcessor()
    bzrlib_importer.lazy_import(sys.modules,
"""from bzrlib import osutils, tests
import bzrlib.lockdir
from bzrlib.lazy_import import lazy_import
from bzrlib.tests import TestCase
from bzrlib.tests import TestUtil

from foo import bar, baz
from foo.bar import baz, bing
from baz import bing
from baz import bing
""")

    assert 'osutils' in sys.modules
    assert 'tests' in sys.modules

# Generated at 2022-06-24 02:44:06.106142
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib.tests.test_import_processors import (
        TestImportProcessor,
        )
    from bzrlib.tests.test_import_processors import FakeImport

    def _mock_import(self, scope, name):
        return self._list_to_scope(scope, self.module_path,
                with_self=True)

    obj = TestImportProcessor(import_class=FakeImport)
    FakeImport._import = _mock_import

# Generated at 2022-06-24 02:44:13.223571
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object.

    The __unicode__ method of Exception returns a unicode object.
    """
    e = IllegalUseOfScopeReplacer('fake', 'The message')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-24 02:44:21.703501
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Make sure making a target object will fail when proxying is disabled.

    To avoid the need to set up a full-blown environment to run the lazy
    import code, this test only verifies that the error is correctly
    detected, without correctly setting up the object (that would be
    better tested in the other tests).
    """
    disallow_proxying()
    import pickle
    replaced = type('replaced', (object, ), {})
    def factory(*args):
        return replaced
    globals = {}
    proxy = ScopeReplacer(globals, factory, 'pickle')

# Generated at 2022-06-24 02:44:33.378655
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    r = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    q = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = IllegalUseOfScopeReplacer('name', 'msg', 'spam')
    t = IllegalUseOfScopeReplacer('name', 'foo', 'extra')
    u = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    w = None
    assert r == q
    assert r != s
    assert r != t
    assert r != u
    assert r != w


# Since this is so much used by bzrlib we assume that this is always used
# at the module level, so we can use sys._getframe for faster resolution
# (i.e. we assume that the call is coming from a module level). This is
# verified by a test.
#

# Generated at 2022-06-24 02:44:43.104603
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCaseWithTransport
    class MyClass(TestCaseWithTransport):
        def test_ScopeReplacer___setattr__(self):
            # This test is deliberately split into multiple sections
            # so that the first part can safely be run by the test
            # command and the second part by selftest.
            lazy_import(globals(), '''
            from bzrlib.lazy_import import (
                lazy_import,
                )
            ''')
            # When selftest runs, it enables ScopeReplacer._should_proxy=False.
            # This is to check that developers are not abusing the lazy
            # import mechanism. So we only want to run the first part of this
            # test from the test command.

# Generated at 2022-06-24 02:44:55.688863
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class X(object):
        pass
    class Y(X):
        pass
    class Z(X):
        pass
    x1 = X()
    x2 = X()
    y1 = Y()
    z1 = Z()
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    e3 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e4 = IllegalUseOfScopeReplacer('qux', 'bar')
    e5 = IllegalUseOfScopeReplacer('foo', 'baz')
    assert e1 == e2
    assert e1 != e3
    assert e1 != e4
    assert e1 != e5
    assert e1 != x1
    assert x1 != e1

# Generated at 2022-06-24 02:45:02.140171
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer."""
    from unittest import TestCase
    from StringIO import StringIO

    class Test(TestCase):

        def test(self):
            e = IllegalUseOfScopeReplacer('name', 'msg', ('extra',))
            s = str(e)
            self.assertEqualDiff(
                "ScopeReplacer object 'name' was used incorrectly:"
                " msg: ('extra',)", s)

    Test().test()



# Generated at 2022-06-24 02:45:11.916657
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    eq = IllegalUseOfScopeReplacer.__eq__
    assert eq(IllegalUseOfScopeReplacer('one', 'two'),
              IllegalUseOfScopeReplacer('one', 'two'))
    assert not eq(IllegalUseOfScopeReplacer('one', 'two'),
              IllegalUseOfScopeReplacer('one', 'two', 'extra'))
    assert not eq(IllegalUseOfScopeReplacer('one', 'one'),
              IllegalUseOfScopeReplacer('one', 'two'))
    assert NotImplemented == eq(IllegalUseOfScopeReplacer('one', 'two'), None)
    assert NotImplemented == eq(None, IllegalUseOfScopeReplacer('one', 'two'))



# Generated at 2022-06-24 02:45:16.674646
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ of IllegalUseOfScopeReplacer"""
    import doctest
    doctest.DontDocFile('lazy_import.txt')
    o1 = IllegalUseOfScopeReplacer('name', 'msg')
    o1.baz = 'baz'
    o2 = IllegalUseOfScopeReplacer('name', 'msg')
    o2.baz = 'baz'
    assert o1 == o2



# Generated at 2022-06-24 02:45:19.863720
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Check that __repr__ of IllegalUseOfScopeReplacer works"""
    e = IllegalUseOfScopeReplacer('scope', 'error')
    repr(e)

# Generated at 2022-06-24 02:45:28.695506
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying

    This unit test is split out of test_lazy_import, as that can't
    run until this function has been defined.
    """
    foo = 1
    lazy_import(locals(), '''
from bzrlib.lazy_import import disallow_proxying
import bzrlib.lazy_import
import bzrlib.debug
''')
    disallow_proxying()
    try:
        bar = foo + 1
    except Exception as e:
        assert isinstance(e, IllegalUseOfScopeReplacer)
        # Check it has the right error message:
        assert 'assign it to another variable?' in e.__unicode__()
        assert 'assign it to another variable?' in str(e)



# Generated at 2022-06-24 02:45:32.852413
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global import_error
    global ImportError
    if import_error:
        raise ImportError

    global import_failure
    import_failure += 1
    global total_import_failure
    total_import_failure += 1
    import bzrlib.tests
    if import_failure < 2:
        raise ImportError
    global import_success
    import_success = True
    return ('bzrlib.tests', 'TEST_SUITE', None)

# Generated at 2022-06-24 02:45:43.206711
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy import.
    
    This is a bit tricky to test, since lazy import replaces globals,
    which is not always a good idea.
    """
    # Just a happy path test for now.
    class MyReplacer(ImportReplacer):
        pass

# Generated at 2022-06-24 02:45:48.160275
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib import errors
    x = errors
    disallow_proxying()
    lazy_import(globals(), '''
    from bzrlib import errors
    ''')

# Generated at 2022-06-24 02:45:49.635941
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    s = IllegalUseOfScopeReplacer('name', 'err msg', 123)
    s.__repr__()



# Generated at 2022-06-24 02:45:58.343605
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            import types
            # a function used for testing purposes
            def function():
                pass
            # the test object
            obj = ScopeReplacer(locals(), lambda self, s, n: function, 'function')
            # the test
            result = obj()
            # checking results
        self.assertIsInstance(result,types.FunctionType)
        return result



# Generated at 2022-06-24 02:46:07.035975
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ of bzrlib.lazy_import.IllegalUseOfScopeReplacer"""
    # This code was automatically generated by the docstring test
    # generator. See http://docstring.wiki.branches.bzr.dev/
    # in the 'docstringtestgenerator' branch.
    eq = bzrlib.lazy_import.IllegalUseOfScopeReplacer.__eq__
    def new_obj(**kwargs):
        # Create a new object for testing.
        obj = bzrlib.lazy_import.IllegalUseOfScopeReplacer(
            "name", "msg")
        for attr in kwargs:
            setattr(obj, attr, kwargs[attr])
        return obj
    # Test 1

# Generated at 2022-06-24 02:46:11.220563
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ returns a unicode string"""
    e = IllegalUseOfScopeReplacer('foobar', 'something wrong')
    u = unicode(e)
    _assert_isinstance(u, unicode)



# Generated at 2022-06-24 02:46:13.886948
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    error = IllegalUseOfScopeReplacer("ModuleToLoad", "Call made before load")
    assert str(error) == "Call made before load"



# Generated at 2022-06-24 02:46:19.829641
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Lazy objects must be replaced immediately when proxying is disallowed"""
    scope = {}
    factory = lambda obj, scope, name: None
    import bzrlib
    lazy_import(scope, '''
    import bzrlib
    ''', locals())
    disallow_proxying()
    import bzrlib

# Generated at 2022-06-24 02:46:25.359365
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """ScopeReplacer stores all its data in slots, so it doesn't need to be
    created with keyword arguments.
    """
    from bzrlib.tests import TestCase
    ScopeReplacer(object, object, 'test')


# Generated at 2022-06-24 02:46:27.757639
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__() should return str(self)"""
    e = IllegalUseOfScopeReplacer('foobar', 'message')
    str(e) == e.__repr__() # no raise

# Generated at 2022-06-24 02:46:38.851350
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    # Effectively, this is a unit test for lazy_import

    import __builtin__
    import tempfile
    def factory(obj, scope, name):
        import os
        object.__setattr__(obj, '_real_obj', os)
        return obj

    # This should put 'os' into the scope
    with tempfile.TemporaryFile() as t:
        redirect_stdout = ScopeReplacer(__builtin__.__dict__, factory, 'os')
        # And grab it
        os = __builtin__.__dict__['os']
        assert isinstance(os, ScopeReplacer)
        assert os._factory is factory
        assert os is redirect_stdout



# Generated at 2022-06-24 02:46:47.080694
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # TODO: Nicer exceptions from ScopeReplacer when raising
    from bzrlib import (
        lazy_import,
        )

    def factory(self, scope, name):
        return "value"
    scope = {}
    lazy_import.ScopeReplacer(scope, factory, 'name')
    # XXX: Failed test: "value" != "other_value"
    eq(scope['name'], "other_value")

# Generated at 2022-06-24 02:46:59.595205
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the constructor of ScopeReplacer.

    These tests are somewhat ugly because we test for a exception type
    and a certain string.

    Because we want the test to operate on a vanilla object, we
    generate a local ScopeReplacer.
    """
    import sys
    from bzrlib.trace import mutter
    from bzrlib.tests import TestCase

    # Empty factory, should use first argument
    def empty_factory(self):
        return self
    # Exception factory, should use first argument
    def exception_factory(self):
        raise AssertionError('should not be used')
    # Normal factory, should use first argument
    def factory(self, scope, name):
        mutter('scope=%r, name=%r', scope, name)
        self.scope = scope
        self.name = name
       

# Generated at 2022-06-24 02:47:10.775464
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.trace import mutter

    #__setattr__ is not called when assigning __slots__ variables
    #so we do not test it.
    def test_setattr(self, attr, value):
        if attr == '_scope':
            mutter('ScopeReplacer._scope = %r', value)
        elif attr == '_factory':
            mutter('ScopeReplacer._factory = %r', value)
        elif attr == '_name':
            mutter('ScopeReplacer._name = %r', value)
        elif attr == '_real_obj':
            mutter('ScopeReplacer._real_obj = %r', value)
        else:
            obj = object.__getattribute__(self, '_resolve')()

# Generated at 2022-06-24 02:47:16.617638
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ should fill in the specified scope with this object."""
    scope = {}
    ScopeReplacer(scope, lambda x, y, z: None, 'a')
    if 'a' not in scope or scope['a'] is not None:
        raise AssertionError("ScopeReplacer(scope, lambda x, y, z: None, 'a') "
            "did not fill in scope as expected, should be None but was:"
            " %r" % (scope,))


# Generated at 2022-06-24 02:47:25.029329
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """
    Tests for correctness and for raising specific exceptions for
    illegal usage.
    """
    scope = {}
    name = 'foo'
    module_path = ['bzrlib', 'foo']
    member = 'bar'
    children = {'baz':(['bzrlib', 'foo', 'baz'], None, {})}

    # Test member and children
    e = None
    try:
        ImportReplacer(scope, name, module_path, member, children)
    except ValueError as e:
        pass
    assert e is not None

    # Test member and children
    e = None
    try:
        ImportReplacer(scope, name, module_path, member, {})
    except ValueError as e:
        pass
    assert e is None

    # Test member and children
    e = None


# Generated at 2022-06-24 02:47:26.482824
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test constructing an ImportProcessor object"""
    importer = ImportProcessor()
    # TODO: jam 20060912 Add more testing here.


# Generated at 2022-06-24 02:47:33.631739
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer should work properly"""
    exception = IllegalUseOfScopeReplacer('name', 'msg')

    result = str(exception)

    # XXX: I don't think it will be possible to test IllegalUseOfScopeReplacer
    # properly, because it uses _format() method which is quite tricky and will
    # be called directly only in error conditions (to provide some meaningful
    # message).
    if result is None: raise AssertionError
    # There is no way to check other properties of the result (like type of
    # the result), because they are dependent on current _format()
    # implementation.

# Generated at 2022-06-24 02:47:45.106009
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Method __setattr__ of class ScopeReplacer

    This tests that any attempt to set an attribute on this object
    before the object has been created results in a useful error.
    """
    from bzrlib.tests import TestSkipped
    from bzrlib.tests.blackbox import ExternalBase
    from subprocess import Popen, PIPE
    import time
    try:
        import fcntl
    except (ImportError):
        raise TestSkipped("Uses fcntl")
    try:
        import thread
    except (ImportError):
        raise TestSkipped("Uses threads")
    try:
        import threading
    except (ImportError):
        raise TestSkipped("Uses threads")


# Generated at 2022-06-24 02:47:50.878430
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        pass

    class Bar(object):
        pass

    foo = Foo()
    foo.my_attribute = Bar()

    my_attribute = ScopeReplacer(foo.__dict__, lambda self, scope, name: scope[name], 'my_attribute')

    assert_same_content(foo.my_attribute, my_attribute)
    assert_same_content(foo.my_attribute, my_attribute)



# Generated at 2022-06-24 02:47:55.211744
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    def factory(self, scope, name):
        return 5

    name = 'name'
    obj = ScopeReplacer(scope, factory, name)
    assert obj == 5
    assert scope[name] == 5


# Generated at 2022-06-24 02:48:04.803537
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test for ImportProcessor

    See http://bugs.python.org/issue8144 for additional tests in the standard
    library.
    """
    # The reason we're not using doctests or a unit test framework is because
    # they'd go through the lazy imports and cause them to actually get
    # imported, which is not what we want in this test.
    text = '''import foo, foo.bar.baz, foo.baz, foo.bar.baz.bing as bong
from foo import bar, baz, bing
from bar import bar, baz, bing
from bar import bar as local_bar
import (baz as local_baz, bar as local_bar2)'''
    processor = ImportProcessor()
    processor.lazy_import({}, text)

# Generated at 2022-06-24 02:48:16.795286
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer should work"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert 'foo' in unicode(e)
    assert 'bar' in unicode(e)
    e = IllegalUseOfScopeReplacer('foo', u'b\xe4r')
    assert 'foo' in unicode(e)
    assert u'b\xe4r' in unicode(e)
    e = IllegalUseOfScopeReplacer(u'f\xf6o', u'b\xe4r')
    assert u'f\xf6o' in unicode(e)
    assert u'b\xe4r' in unicode(e)
    # IllegalUseOfScopeReplacer must be printable whatever the encoding

# Generated at 2022-06-24 02:48:20.134346
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    class Test(IllegalUseOfScopeReplacer):
        _fmt = "%(name)s%(extra)s"
    assert str(Test('name', 'msg', 'extra')) == "nameextra"


# Generated at 2022-06-24 02:48:25.687657
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # this unit test is rather simple and mainly test that the
    # constructor works in an obvious manner
    assert (IllegalUseOfScopeReplacer('a', 'b', 'c').__dict__ ==
            {'name': 'a', 'msg': 'b', 'extra': ': c'})
    assert (IllegalUseOfScopeReplacer('a', 'b').__dict__ ==
            {'name': 'a', 'msg': 'b', 'extra': ''})



# Generated at 2022-06-24 02:48:27.689456
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = object()

    def factory(self, scope, name):
        return obj

    sr = ScopeReplacer(locals(), factory, 'obj')
    assert sr() is obj
    return



# Generated at 2022-06-24 02:48:31.319745
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return str"""
    s = IllegalUseOfScopeReplacer('ex1', 'msg1').__str__()
    from bzrlib import ui
    ui.ui_factory.make_output_stream(None, None).write(s)



# Generated at 2022-06-24 02:48:37.285300
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from cStringIO import StringIO
    stdout = sys.stdout
    try:
        sys.stdout = StringIO()
        # call the method
        self.replacer.__call__()
        # put your specific assertions here
    finally:
        sys.stdout = stdout


# Generated at 2022-06-24 02:48:45.110105
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    def child_test(test):
        def test_wrapper(self):
            self._initialize()
            self.children_entries = {
                'foo': (['bzrlib', 'foo'], None, {}),
                'bar': (['bzrlib', 'foo', 'bar'], None, {}),
                'baz': (['bzrlib', 'foo', 'baz'], 'blah', {}),
            }
            test(self)
        return test_wrapper
    class TestImportReplacer(ImportReplacer):
        def __init__(self, scope, name, module_path, member=None, children=None):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children
            self._

# Generated at 2022-06-24 02:48:52.444111
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import os
    import sys
    scope = locals()
    lazy_import(scope, "import os")
    os.path.abspath('.')
    lazy_import(scope, "import os")
    os.path.abspath('.')
    disallow_proxying()
    try:
        os.path.abspath('.')
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("Expected IllegalUseOfScopeReplacer error")
    # double check that the object was the same object
    assert scope['os'] is os
    # Test that out of scope usage also fails
    scope = {}
    lazy_import(scope, "import os")

# Generated at 2022-06-24 02:49:00.992823
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import bzrlib # must be legal import
    import bzrlib.foo
    from bzrlib.foo import bar
    from bzrlib.foo import bar as baz
    from bzrlib import foo
    import t_bzrlib # must be legal import
    from t_bzrlib import foo
    from t_bzrlib.foo import bar
    import bzrlib.foo, t_bzrlib.foo
    import bzrlib.foo as t_bzrlib_foo

    d = {}


# Generated at 2022-06-24 02:49:04.520578
# Unit test for function lazy_import
def test_lazy_import():
    from . import lazy_import_tests
    if lazy_import_tests.is_enabled():
        from .lazy_import_tests import test_lazy_import
        test_lazy_import()


# Generated at 2022-06-24 02:49:14.219179
# Unit test for function lazy_import
def test_lazy_import():
    """Test our lazy_import function"""

    scope = {}
    lazy_import(scope, '''
    from bzrlib import (foo,
                        bar,
                        baz,
                        )
    from bzrlib.branch import Branch
    from bzrlib.transport import get_transport
    ''')
    for name in ('foo', 'bar', 'baz', 'Branch', 'get_transport'):
        claimed = scope[name]
        expected = ScopeReplacer
        if not isinstance(claimed, expected):
            raise AssertionError(
                'Expected %r to be of type %r' % (claimed, expected))

    # Check that they all have the same scope
    scope0 = scope['foo'].scope

# Generated at 2022-06-24 02:49:25.805579
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class TestClass(object):
        def test_attr(self):
            return "value"

    def factory(self, scope, name):
        return TestClass()

    # Test with enabled proxying.
    ScopeReplacer._should_proxy = True
    test_scope = {}
    test_obj = ScopeReplacer(test_scope, factory, 'test_name')
    result = test_obj._resolve()
    assert isinstance(result, TestClass)
    # Attribute is fetched from the resolved object.
    assert test_obj.test_attr() == 'value'
    # The next time a resolved object is fetched from cache.
    assert test_obj._resolve() is result
    # Attribute is fetched from the resolved object.
    assert test_obj.test_attr() == 'value'

    # Test with disabled prox

# Generated at 2022-06-24 02:49:36.681841
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib
    bzrlib._testing_loose_scope_replacer_proxy = True

# Generated at 2022-06-24 02:49:48.325183
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    a1 = IllegalUseOfScopeReplacer(
            'baz', 'bar',
            extra=IllegalUseOfScopeReplacer('foo', 'baz'))
    a2 = IllegalUseOfScopeReplacer(
            'baz', 'bar',
            extra=IllegalUseOfScopeReplacer('foo', 'baz'))
    assert(a1 == a2)
    assert(not(a1 != a2))

    a3 = IllegalUseOfScopeReplacer('baz', 'bar')
    assert(a1 != a3)
    assert(not(a1 == a3))

    a4 = IllegalUseOfScopeReplacer('baz', 'bar')
    a5 = IllegalUseOfScopeReplacer('baz', 'baz')
   

# Generated at 2022-06-24 02:49:52.223615
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    i = IllegalUseOfScopeReplacer('a', 'b', extra='c')
    assert i.name == 'a'
    assert i.msg == 'b'
    assert i.extra == ': c'
    try:
        raise i
    except IllegalUseOfScopeReplacer:
        pass



# Generated at 2022-06-24 02:50:01.112336
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() is a unicode."""
    class E(IllegalUseOfScopeReplacer):
        pass
    e = E('a', 'b')
    assert isinstance(unicode(e), unicode)
    e._preformatted_string = unicode('xxx')
    assert isinstance(unicode(e), unicode)


# TODO: Move all the code in this module to lazy_import.py and remove
#       this file.
from bzrlib.lazy_import import lazy_import  # noqa: E402

# Generated at 2022-06-24 02:50:11.474396
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Method __eq__ of class IllegalUseOfScopeReplacer

    This method should compare dicts of two classes. It should return
    False if classes differ. And it should return NotImplemented if
    classes are equal, but not compared one.

    >>> from bzrlib.tests import TestCase
    >>> from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    >>> class MyClass(IllegalUseOfScopeReplacer):
    ...     pass

    >>> base = TestCase()
    >>> base.assertEqual(NotImplemented, IllegalUseOfScopeReplacer.__eq__(MyClass(), MyClass()))
    >>> base.assertFalse(IllegalUseOfScopeReplacer.__eq__(MyClass(), Exception()))
    """
    pass

import traceback



# Generated at 2022-06-24 02:50:22.775324
# Unit test for method lazy_import of class ImportProcessor

# Generated at 2022-06-24 02:50:26.287102
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ should create a valid repr
    string.

    Test 'IllegalUseOfScopeReplacer' because it overrides __repr__
    """
    ex = IllegalUseOfScopeReplacer('test_name', 'test_msg', 'test_extra')
    try:
        raise ex
    except IllegalUseOfScopeReplacer:
        # We've caught the exception, now we can test the repr
        pass
    # __repr__ must return a str, not a unicode object.
    assert isinstance(ex.__repr__(), str)



# Generated at 2022-06-24 02:50:30.574346
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly: " \
        "msg: extra"


# Generated at 2022-06-24 02:50:38.834859
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a string"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # The exception class is only used for __unicode__, so it doesn't really
    # matter if this is really a UnicodeEncodeError.
    UnicodeEncodeError('fishy', unicode('message'), 'ascii', 123, 789, 'ugh')
    e._preformatted_string = u'fishy'
    assert isinstance(unicode(e), unicode)
    e._preformatted_string = u'fishy'.encode('utf8')
    assert isinstance(unicode(e), unicode)
    e._preformatted_string = u'fishy'.encode('latin1')
    assert isinstance(unicode(e), unicode)
    e._preformatted

# Generated at 2022-06-24 02:50:45.821550
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ on IllegalUseOfScopeReplacer objects"""
    e1 = IllegalUseOfScopeReplacer('test', 'message', 'extra')
    e2 = IllegalUseOfScopeReplacer('test', 'message', 'extra')
    e3 = IllegalUseOfScopeReplacer('test', 'message', 'extra2')
    e4 = IllegalUseOfScopeReplacer('test2', 'message', 'extra')
    e5 = IllegalUseOfScopeReplacer('test', 'message2', 'extra')
    e6 = IllegalUseOfScopeReplacer('test', 'message', 'extra')
    e6.extra = 'extra2'
    e7 = IllegalUseOfScopeReplacer('test', 'message', 'extra')
    e7.msg = 'msg2'
    e8 = IllegalUseOfScopeReplacer('test', 'message', 'extra')

# Generated at 2022-06-24 02:50:57.269092
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_text = """
    # This is a test
    import foo, bar # another comment
    import foo.bar # comment
    import foo.bar.baz as bing
    import foo.bar.baz, bing.bong, # as is this
        bing.bong.baz as bingbongbaz # and this
    # and this
    from frob import widget,
     widget2, widget3
    """
    processor = ImportProcessor()
    processor._build_map(import_text)


# Generated at 2022-06-24 02:51:06.209324
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """This tests the constructor to ensure that it loads all the modules
    we want.
    """
    pp = ImportProcessor()

# Generated at 2022-06-24 02:51:18.762330
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the lazy_import method of class ImportProcessor.

    This is a rather complex class, and so the unit test for it
    has been kept in an external function, so that all the testing does
    not clutter up this module.
    """
    import sys

    class FakeScope(object):
        """This is a fake scope object.
        """

        def __init__(self):
            self.imports = []
            self.name_map = {}

        def __setitem__(self, key, value):
            self.name_map[key] = value
            self.imports.append((key, value))

    class FakeLazyImportClass(object):
        """This is a fake lazy import class.

        It is a basic shell of the ImportReplacer class.
        """


# Generated at 2022-06-24 02:51:29.261250
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # http://bazaar-vcs.org/bzr/bzr.dev/lazy_import.py@1260#L46
    # req: ???
    # from bzrlib.lazy_import import ScopeReplacer
    class MockScopeReplacer(ScopeReplacer):
        def __init__(self, v1, v2, v3):
            super(MockScopeReplacer, self).__init__(v1, v2, v3)
            self.__dict__ = {}
        def _resolve(self):
            return 'my_resolve'
    o = MockScopeReplacer('my_scope', 'my_factory', 'my_name')
    o = o._resolve()
    o = o.__getattribute__('_resolve')
    o = o()

# Generated at 2022-06-24 02:51:37.693392
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import sys
    ####
    class ScopeReplacer_1(object):
        """A lazy object that will replace itself in the appropriate scope.

        This object sits, ready to create the real object the first time it is
        needed.
        """

        __slots__ = ('_scope', '_factory', '_name', '_real_obj')

        # If you to do x = y, setting this to False will disallow access to
        # members from the second variable (i.e. x). This should normally
        # be enabled for reasons of thread safety and documentation, but
        # will be disabled during the selftest command to check for abuse.
        _should_proxy = True


# Generated at 2022-06-24 02:51:48.615840
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import mock
    import pdb
    from bzrlib.lazy_import import (
        ScopeReplacer,
        )
    ScopeReplacer._should_proxy = True
    obj10 = ScopeReplacer({}, None, 'name')
    obj10.mock_calls = []
    def _factory_call0(arg2, arg3, arg4):
        obj10.mock_calls.append(('_factory', (arg2, arg3, arg4)))
        return obj10
    obj10._resolve_factory = _factory_call0
    obj10._factory = mock.Mock(side_effect=_factory_call0)

# Generated at 2022-06-24 02:51:58.672060
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from mock import Mock

    class MockObj(object):
        def __getattr__(self, attr):
            return attr

    o = MockObj()
    l = ScopeReplacer(object(), lambda foo, bar, baz: o, 'name')
    assert l.foo == 'foo'
    assert l._resolve() == o

    # calling it should still work.
    assert o.bar == 'bar'

    l.bar = 'newbar'
    assert o.bar == 'newbar'

    new_obj = MockObj()
    l = ScopeReplacer(object(), lambda foo, bar, baz: new_obj, 'name')
    assert l._resolve() is new_obj

    # normally it is an error to call the original object:
    l.bar = 'newbar'
    assert new_obj.bar

# Generated at 2022-06-24 02:52:03.450246
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # This is here because I'm lazy and so it doesn't make a whole new file
    # for one line of test code.
    try:
        raise IllegalUseOfScopeReplacer('foo', 'message')
    except IllegalUseOfScopeReplacer as e:
        assert str(e) == 'foo: message', str(e)

test_IllegalUseOfScopeReplacer()



# Generated at 2022-06-24 02:52:13.493860
# Unit test for function lazy_import
def test_lazy_import():
    import inspect
    import bzrlib
    from bzrlib import tests

    test_mod = inspect.getmodule(tests.TestCase)
    scope = test_mod.__dict__
    # Now create a bunch of lazy replacements:
    #   * bzrlib.foo is replaced with LazyImport()
    #   * bzrlib.foo.bar is replaced with LazyImport()
    #   * bzrlib.foo.bar.baz is replaced with LazyImport()
    #   * baz is replaced with LazyImport()
    #   * bzrlib.bar is replaced with LazyImport()
    #   * bzrlib.transport.get_transport is replaced with LazyImport()

# Generated at 2022-06-24 02:52:22.475405
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the class ScopeReplacer"""

    class ClassToReplace(object):
        """A class to be replaced by ScopeReplacer.

        There is no special in this class, it could be
        replaced by any other class.
        """
        def __init__(self):
            pass

    def factory(replacer, scope, name):
        return ClassToReplace()

    # simulate a global scope
    scope = {}
    # create the ScopeReplacer object in a global scope
    replacer = ScopeReplacer(scope, factory, 'replacer_class')

    # check the replacer is in the scope
    # and it is a ScopeReplacer object
    assert 'replacer_class' in scope
    assert isinstance(scope['replacer_class'], ScopeReplacer)

    # test that we can call the object
    obj = replacer

# Generated at 2022-06-24 02:52:28.001689
# Unit test for function disallow_proxying
def test_disallow_proxying():
    # We need to use a real scope to assert that proxies can be disabled
    scope = {}
    lazy_import(scope, "from bzrlib import config")
    x = scope['config']
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-24 02:52:39.861894
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from StringIO import StringIO
    from bzrlib.tests import TestUtil

    class DummyModule(object):

        def __init__(self):
            self.v = 0

        def increment(self):
            self.v += 1

    def _create_module(self, scope, name):
        return DummyModule()

    t = TestCase()
    t.overrideAttr(TestUtil, '_mod_dir', t.get_vfs_only_url('mod'))

    # Initialize a dummy module
    test_module = TestUtil.build_tree_contents([('mod/__init__.py', '')])
    test_module.lock_write()
    test_

# Generated at 2022-06-24 02:52:46.230508
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ converts to string"""
    input = IllegalUseOfScopeReplacer("xyz", "foo is bar")
    exp = "IllegalUseOfScopeReplacer('xyz', 'foo is bar')"
    out = repr(input)
    # print "input=%s" % (input,)
    # print "exp=%s" % (exp,)
    # print "out=%s" % (out,)
    assert exp == out



# Generated at 2022-06-24 02:52:50.702485
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__: test for equality"""
    x = IllegalUseOfScopeReplacer('pyrex', 'doesn\'t work', ('until Python', '2.4'))
    y = IllegalUseOfScopeReplacer('pyrex', 'doesn\'t work', ('until Python', '2.4'))
    assert x == y
    # __eq__ is symmetrical so we also test for this.
    assert y == x
    z = IllegalUseOfScopeReplacer('pyrex', 'doesn\'t work', ('until Python', '2.3'))
    assert not (x == z)
    assert not (z == x)
    # Test the that the isinstance check in __eq__ works.
    assert not (x == 'hi')



# Generated at 2022-06-24 02:52:55.037387
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Ensure that ScopeReplacer is usable as a decorator and a callable."""
    import sys
    import bzrlib

    @ScopeReplacer
    def lazy_something(ignore, scope, name):
        sys.modules[name].something = "A real object"

    # Test that it can be used as a decorator.
    lazy_something
    bzrlib.something
    # Accessing the object creates it.
    bzrlib.something == 'A real object'

    # Test it can be used as a callable
    ScopeReplacer(sys.modules, lambda ignore, scope, name: None, 'nothing')
    sys.modules.nothing
    # Accessing the object creates it.
    sys.modules.nothing is None



# Generated at 2022-06-24 02:53:06.364504
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test ImportProcessor"""
    from pprint import pprint
    from StringIO import StringIO
    import sys
    import tempfile
    import traceback

    temp_module_name = tempfile.mktemp('.py')

    # Simple import
    test_data = ['''import foo''']
    processor = ImportProcessor()
    processor.lazy_import({}, '\n'.join(test_data))
    pprint(processor.imports)
    if processor.imports != {'foo': (['foo'], None, {})}:
        raise AssertionError()

    # Multiple imports on a single line
    test_data = ['''import foo, bar''']
    processor = ImportProcessor()
    processor.lazy_import({}, '\n'.join(test_data))

# Generated at 2022-06-24 02:53:15.396093
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.lazy_import import lazy_import, ImportProcessor

    class FakeGlobals(object):
        module_set = set()

        def __setitem__(self, key, value):
            self.module_set.add(key)
            self.key = value

    fake_scope = FakeGlobals()
    lazy_import(fake_scope, 'import bzrlib.foo, bzrlib.bar')
    fake_scope.module_set.remove('__builtins__')
    test_set = set(['bzrlib', 'bzrlib.bar', 'bzrlib.foo'])