

# Generated at 2022-06-24 02:43:14.020465
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return ascii"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    try:
        raise IllegalUseOfScopeReplacer('something', 'A msg')
    except Exception as e:
        s = str(e)
        u = unicode(e)
        assert isinstance(s, str), type(s)
        assert isinstance(u, unicode), type(u)
        # We don't have to check that s and u are identical.
        # 'str' uses utf8 by default, but we don't care about the encoding.
        # If the default ever changes, the assert here will fail, and we'll
        # know that the test needs to be adapted.
    else:
        assert False, "Should have raised"



# Generated at 2022-06-24 02:43:24.649762
# Unit test for function lazy_import
def test_lazy_import():
    """Test the function lazy_import"""
    def get_module(scope, name):
        module = scope[name]
        return module
    def test_import_for_name(scope, name, python_path):
        module = get_module(scope, name)
        assert module.__name__ == python_path, (
            '%s had __name__ %s, not %s'
            % (name, module.__name__, python_path))
    def test_children(scope, children):
        for name, python_path in children.items():
            test_import_for_name(scope, name, python_path)
    def test_scope(scope, root_module, children=None):
        if children is None:
            children = {}

# Generated at 2022-06-24 02:43:28.420707
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase

    class TestExternal(ExternalBase):
        def test_call_noargs(self):
            self.run_bzr(['lazy_import', 'call_noargs'])

    TestExternal().run_tests()


# Generated at 2022-06-24 02:43:40.327908
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Testing lazy import"""
    import imp # to test ImportProcessor.lazy_import
    import bzrlib
    import bzrlib.builtins
    import bzrlib.builtins.cmd_checkout as cmd_checkout
    import bzrlib.commands as commands
    import bzrlib.option as option
    import bzrlib.option_registry as option_registry
    import bzrlib.trace
    import bzrlib.ui
    import bzrlib.ui.text as text_ui

    # We need to make a new class, to make it easier to test object creation.
    class TestImportReplacer(ImportReplacer):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            Import

# Generated at 2022-06-24 02:43:49.271625
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'msg')
    assert isinstance(e, Exception)
    assert e.name == 'foo'
    assert e.msg == 'msg'
    assert e.extra == ''
    assert repr(e).endswith('msg')
    assert str(e) == 'msg'
    e = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    assert str(e) == 'msg: extra'
    assert 'extra' in repr(e)



# Generated at 2022-06-24 02:44:00.783040
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib import (
        lazy_import,
        )
    t = IllegalUseOfScopeReplacer('obj', 'foo', 'bar')
    assert str(t) == unicode(t)
    assert 'obj' in str(t)
    assert 'foo' in str(t)
    assert 'bar' in str(t)
    # The message can be overridden
    class MyIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        _fmt = "my override: %(msg)s"
    t = MyIllegalUseOfScopeReplacer('obj', 'foo', 'bar')
    assert str(t) == unicode(t)
    assert 'obj' in str(t)
    assert 'foo' in str(t)
    assert 'bar' in str(t)

# Generated at 2022-06-24 02:44:03.081610
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of ImportProcessor.

    Test that it takes the right argument.
    """
    processor = ImportProcessor(ImportReplacer)
    assert ImportReplacer == processor._lazy_import_class



# Generated at 2022-06-24 02:44:05.785625
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer(5, 'hello', ('extra',))
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-24 02:44:17.372384
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """
    Unit test for __unicode__ of class IllegalUseOfScopeReplacer.
    """
    import os
    import sys

    base_class = (OSError, IllegalUseOfScopeReplacer)

    class MyException(base_class):
        _fmt = 'My exception %(name)r'

        def __init__(self, name):
            super(MyException, self).__init__()
            self.name = name
            if os.name == 'nt':
                # We have to assign a WindowsError code to self.winerror.
                # The format is irrelevant, we just need to assign a valid code
                # for the __unicode__ test to work.
                self.winerror = 100


# Generated at 2022-06-24 02:44:23.512352
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a python expression that can be used to
    recreate the exception instance.

        >>> exc = IllegalUseOfScopeReplacer('foo', 'bar')
        >>> str(exc)
        'bar'
        >>> repr(exc)
        "IllegalUseOfScopeReplacer('foo', 'bar')"
        >>> eval(repr(exc))
        IllegalUseOfScopeReplacer('foo', 'bar')
    """


# Generated at 2022-06-24 02:44:32.148834
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__"""
    # __unicode__() uses the __dict__ attribute of the class and the
    # `_fmt` class attribute for substitution.
    #
    # The format attribute is a unicode string in the __init__()
    # constructor and when the class is created.
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class A(IllegalUseOfScopeReplacer):
        _fmt = u"Foo: %(msg)s"
    foo = A(u"name", u"value", u"extra")
    # The ascii() of the exception should contain the substituted
    # string.
    expected = u'IllegalUseOfScopeReplacer(Foo: value)'
    observed = ascii(foo)
    expected_coding = 'ascii'


# Generated at 2022-06-24 02:44:36.905792
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return the name of the class and all public attributes of
    the object.
    """
    e = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    assert repr(e) == "IllegalUseOfScopeReplacer('foo', 'msg', 'extra')"



# Generated at 2022-06-24 02:44:43.949805
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Regression test for IllegalUseOfScopeReplacer.

    Specifically for its method __unicode__
    """
    from bzrlib.lazy_import import scope_replace
    scope = scope_replace({"foo": "bar"})
    scope._name = 'scope'
    e = IllegalUseOfScopeReplacer("replacer", msg="this is a message", extra=scope)
    # Test that the message is not double escaped
    assert unicode(e), "should be printable: %r" % (unicode(e),)



# Generated at 2022-06-24 02:44:49.927391
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.lazy_import import ScopeReplacer
    def test(expected_result, **kwargs):
        """Run a test for the given kwargs"""
        r = ScopeReplacer(**kwargs)
        try:
            r.__getattr__('something')
        except Exception as e:
            s = str(e)
        else:
            raise AssertionError('Exception expected.')
        if expected_result != s:
            raise AssertionError('expected: %r instead of %r'
                                 % (expected_result, s))
    # Set the current locale to C and then restore it.
    import locale
    old_locale = locale.setlocale(locale.LC_ALL)

# Generated at 2022-06-24 02:44:54.039570
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit tests for constructors and use of class ScopeReplacer"""
    # These tests presume that it is safe to have a 'bzrlib' entry in the
    # namespace (which is almost always the case).


# Generated at 2022-06-24 02:44:59.947859
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ doesn't raise when called."""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    str(e)


# Generated at 2022-06-24 02:45:09.437097
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    scope = {}

    def test_import_text(text, expected_map=None):
        """Helper function to do a simple import test"""
        i = ImportProcessor()
        i.lazy_import(scope, text)
        if expected_map is not None:
            # Check that the internal map is correct
            assert i.imports == expected_map
        # Check the imports in scope are correct
        for k,v in scope.iteritems():
            assert isinstance(v, ScopeReplacer), \
                '%s is not a scope replacer' % (k,)
        # Check that the scope can be resolved
        scope_copy = scope.copy()
        for k,v in scope.iteritems():
            v._resolve()
        # Compare the scope after resolving
        assert scope == scope_copy, '%r != %r'

# Generated at 2022-06-24 02:45:16.812799
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Create a ScopeReplacer instance and check that it
    can be used to resolve a real object."""
    scope = {}

# Generated at 2022-06-24 02:45:27.074657
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test for ImportProcessor class.

    A healthy test would verify that if any object is imported,
    at some point a test for that object would have been run. At present we
    just check that the code is valid, and that no objects are 'remembered'
    from one test to the next.
    """
    scope = {}
    unittest.TestCase().assertEqual({}, scope)

    # Import a module
    proc = ImportProcessor()
    proc.lazy_import(scope, 'import foo')
    unittest.TestCase().assertNotEqual({}, scope)
    foo = scope['foo']
    unittest.TestCase().assertTrue(isinstance(foo, ImportReplacer))
    unittest.TestCase().assertFalse(foo._import_replacer_children)
    scope.clear()

    #

# Generated at 2022-06-24 02:45:31.130575
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def f(self, scope, name):
        return None
    scope = {}
    name = 'x'
    s = ScopeReplacer(scope, f, name)
    assert s.__call__() is None
    assert s() is None



# Generated at 2022-06-24 02:45:40.677188
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():

    class TestImportReplacer(ImportReplacer):
        """A test variation on ImportReplacer which records everything it
        imports.
        """

        __slots__ = ('imported',)

        def __init__(self, *args, **kwargs):
            self.imported = []
            ImportReplacer.__init__(self, *args, **kwargs)

        def _import(self, *args, **kwargs):
            self.imported.append((self.name, self.module_path[-1]))
            return ImportReplacer._import(self, *args, **kwargs)

    class TestReplacer(Replacer):
        """A test variation on Replacer which records everything it imports.
        """

        __slots__ = ('imported',)


# Generated at 2022-06-24 02:45:49.402662
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import lazy_import
    def test_function(a,b,c=None,d=None):
        return (a,b,c,d)
    global_scope = globals() # overridable for testing purposes
    lazy_import.lazy_import(global_scope, '''
    test_ScopeReplacer___getattribute___import = test_function
    ''')
    import_obj = global_scope['test_ScopeReplacer___getattribute___import']
    assert import_obj(1,2,3,4) == (1,2,3,4), import_obj.__dict__
    assert import_obj(1,2) == (1,2,None,None), import_obj
    assert isinstance(import_obj, lazy_import.ScopeReplacer)
    import_obj.invalid_

# Generated at 2022-06-24 02:46:00.782383
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    def factory(self, scope, name):
        raise Exception('Should never reach here!')

    def check(self, scope, name):
        return len(scope)

    self = ScopeReplacer(scope, check, 'self')

# Generated at 2022-06-24 02:46:09.022470
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object.

    This test is particularly important because it tests the
    default implementation of __unicode__.
    The default implementation relies on __str__() that
    should always return a 'str' object.
    """
    obj = IllegalUseOfScopeReplacer('test','test')
    u = unicode(obj)
    assert isinstance(u, unicode), \
        "%r should be a unicode object" % u
    assert len(u) >= 0, \
        "%r should have a length > 0" % u


# Generated at 2022-06-24 02:46:11.006912
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    try:
        ImportProcessor()
    except TypeError:
        raise TestNotApplicable('Constructor of class ImportProcessor needs arguments')


# Generated at 2022-06-24 02:46:19.755635
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import sys
    import traceback
    e = IllegalUseOfScopeReplacer('some_name', 'Constructing')
    # Just check that they don't raise an exception
    e.__unicode__()
    e.__str__()
    e.__repr__()

# Generated at 2022-06-24 02:46:30.695851
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying()"""
    # Here we test whether we get an IllegalUseOfScopeReplacer when we try
    # to use a lazy import after disallow_proxying().

# Generated at 2022-06-24 02:46:40.844502
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from _py_scope_replacer import _py_scope_replacer

    def _scope_replacer_factory(scope, name):
        return _py_scope_replacer

    __scope__ = globals()
    for x in range(5):
        __scope__['_scope_replacer_%d' % (x,)] = ScopeReplacer(
            __scope__, _scope_replacer_factory, '_scope_replacer_%d' % (x,),
            )


# Generated at 2022-06-24 02:46:47.228345
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import bzrlib.process_import as real_module
    from bzrlib.process_import import ImportReplacer
    from bzrlib.process_import import ImportProcessor
    from bzrlib.process_import import ScopeReplacer

    class FakeScopeReplacer(ScopeReplacer):

        def __init__(self, scope, name, module_path, member=None, children={}):
            object.__setattr__(self, 'scope', scope)
            object.__setattr__(self, 'name', name)
            object.__setattr__(self, 'module_path', module_path)
            object.__setattr__(self, 'member', member)
            object.__setattr__(self, 'children', children)

    fake_replacer = FakeScopeReplacer


# Generated at 2022-06-24 02:46:53.896035
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should be sane"""
    class SubException(IllegalUseOfScopeReplacer):
        pass
    x = IllegalUseOfScopeReplacer('foo', 'msg')
    y = SubException('foo', 'msg')
    assert x != y
    y = SubException('foo', 'othermsg')
    assert x != y



# Generated at 2022-06-24 02:47:03.527033
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    # This lazy import should work because it happens before
    # disallow_proxying is called
    lazy_import(globals(), 'bzrlib.osutils')
    disallow_proxying()
    # This lazy import should raise IllegalUseOfScopeReplacer, because
    # after disallow_proxying returns, lazy imports do not work anymore.
    try:
        lazy_import(globals(), 'bzrlib.osutils')
    except bzrlib.lazy_import.IllegalUseOfScopeReplacer:
        # caught the expected exception
        pass
    else:
        raise AssertionError('Did not get expected IllegalUseOfScopeReplacer')
    # This import should not raise, because lazy_import does

# Generated at 2022-06-24 02:47:14.602467
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    import doctest
    doctest.run_docstring_examples(
        IllegalUseOfScopeReplacer.__eq__, globals(),
        optionflags=doctest.ELLIPSIS)

    # Examples for subclassing
    class MyError(IllegalUseOfScopeReplacer):
        _fmt = "This is a %(name)s error, msg: %(msg)s"

    class MyError2(IllegalUseOfScopeReplacer):
        _fmt = "This is another %(name)s error, msg: %(msg)s"

    first = MyError(name="first", msg="bad bad error", extra="oops")
    second = MyError2(name="first", msg="bad bad error", extra="oops")
    third = MyError(name="first", msg="bad bad error", extra="oops")


# Generated at 2022-06-24 02:47:23.694151
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that the constructor of ImportReplacer works as expected."""
    scope = {'foo': 'bar'}
    ImportReplacer(scope, name='foo', module_path=['foo'], member=None,
                   children={})
    ImportReplacer(scope, name='foo', module_path=['foo'], member='bar',
                   children={})
    try:
        ImportReplacer(scope, name='foo', module_path=['foo'], member='bar',
                       children={'bar':(['foo', 'bar'], None, {})})
    except ValueError:
        pass
    else:
        raise ValueError('expected constructor to fail')



# Generated at 2022-06-24 02:47:28.455349
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should behave correctly

    - it must never return None
    - it should never raise an exception
    """
    import re
    import time
    import warnings

    # Disable the 'unicode' deprecation warning in Python 2.6
    # because this test is specifically testing Unicode.
    # If we also want to raise an exception on the use of
    # str() / unicode() in the future, add a warning category
    # for that.
    warnings.simplefilter('ignore', category=DeprecationWarning)

    class C(IllegalUseOfScopeReplacer):
        pass

    # First, let's check that the default methods behave sanely

    # this should not return None
    # this should not raise an exception
    u = unicode(C('foo', 'bar'))
    # we can at least check that the string matches

# Generated at 2022-06-24 02:47:34.608872
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__() should return an ascii string."""
    e = IllegalUseOfScopeReplacer('foo', 'this is a test', extra='this too')
    repr_ascii = repr(e)
    import sys
    if sys.version_info[0] >= 3:
        _expected = "IllegalUseOfScopeReplacer('foo', 'this is a test', extra='this too')"
    else:
        _expected = "IllegalUseOfScopeReplacer(u'foo', u'this is a test', extra='this too')"
    assert repr_ascii == _expected

# Generated at 2022-06-24 02:47:42.700754
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    v0 = ScopeReplacer(globals(), lambda self, scope, name: bzrlib, 'bzrlib')
    v1 = bzrlib
    bzrlib = object()
    try:
        v2 = v0.__getattribute__('this_is_not_an_attribute')
        v3 = v0.LockableFiles
    except:
        bzrlib = v1
        raise
    if (v0 is v1) or (v1 is v2) or (v2 is not None) or (v1.LockableFiles is v3):
        raise AssertionError
    bzrlib = v1


# Generated at 2022-06-24 02:47:50.708395
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import as _mod_lazy_import
    class MockScopeReplacer(_mod_lazy_import.ScopeReplacer):
        "A mock ScopeReplacer object."
        __slots__ = ('_resolve', '_real_obj', '_name')
        def __init__(self, *_1, **kwargs):
            super(MockScopeReplacer, self).__init__(*_1, **kwargs)
            object.__setattr__(self, '_resolve', lambda: object.__getattribute__(self, '_real_obj'))
        def checking_raise(self, name, msg, extra=None):
            raise _mod_lazy_import.IllegalUseOfScopeReplacer(name, msg, extra)

# Generated at 2022-06-24 02:47:57.629847
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    o1 = IllegalUseOfScopeReplacer(1, 2, 3)
    o2 = IllegalUseOfScopeReplacer(1, 2, 3)
    o3 = IllegalUseOfScopeReplacer(3, 4, 5)
    assert o1 == o2
    assert o1 != o3
test_IllegalUseOfScopeReplacer___eq__.unittest = ['test_exception_equality']



# Generated at 2022-06-24 02:48:05.941258
# Unit test for function lazy_import
def test_lazy_import():
    # This function also serves as a test for lazy_import
    from bzrlib.tests import TestSkipped

# Generated at 2022-06-24 02:48:17.677188
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor and _import method of ImportReplacer"""
    globs = {}
    ImportReplacer(globs, name='foo',
        module_path=['bzrlib', 'foo'], member=None, children={})
    globs['foo']
    assert globs['foo']._import_replacer_children == {}
    assert globs['foo']._member is None
    assert globs['foo']._module_path == ['bzrlib', 'foo']

    globs = {}
    replacements = {'bar':(['bzrlib', 'foo', 'bar'], None, {})}
    ImportReplacer(globs, name='foo',
        module_path=['bzrlib', 'foo'], member=None,
        children=replacements)
    assert globs['foo']._

# Generated at 2022-06-24 02:48:20.309790
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str"""
    s = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(str(s), str)



# Generated at 2022-06-24 02:48:31.738591
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # ScopeReplacer.__setattr__() -> None
    # Override __setattr__ to prevent changing the value of attributes
    # defined in __slots__.
    # Only class variables can be changed.
    obj = ScopeReplacer(None, None, None)
    try:
        obj.__setattr__('_name', 'foo')
    except AttributeError as e:
        # AttributeError: Attribute '_name' is read only, use __setattr__
        # provided by this class.
        assert str(e) == "Attribute '_name' is read only, use __setattr__ " \
            "provided by this class."


# Generated at 2022-06-24 02:48:42.705220
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of class ImportReplacer."""


# Generated at 2022-06-24 02:48:47.357421
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}

    # Test scope replacer with no factory set.
    scope['foo'] = ScopeReplacer(scope, None, 'foo')
    scope['foo']._resolve()

    # Test scope replacer with no factory set and resolve called twice
    scope['bar'] = ScopeReplacer(scope, None, 'bar')
    scope['bar']._resolve()
    scope['bar']._resolve()


# Generated at 2022-06-24 02:48:55.736217
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class AType(object):
        pass
    t = AType()
    t.foo = 10
    assert t.foo == 10
    t.foo = 20
    assert t.foo == 20
    t.bar = 30
    assert t.bar == 30
    try:
        # Try to set a non-existing attribute.
        t.non_existing = 40
        # Should never come here.
        raise AssertionError('t.non_existing = 40 should have raised an'
            ' exception.')
    except Exception:
        pass


# Generated at 2022-06-24 02:48:59.760552
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor"""
    from breezy.tests import TestCase

    class TestIP(TestCase):
        """Unit test for constructor of class ImportProcessor"""

        def test_constructor(self):
            ip = ImportProcessor()
            self.assertIsInstance(ip, ImportProcessor)

    TestIP().run_tests()


# Generated at 2022-06-24 02:49:03.370647
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying"""
    from bzrlib.lazy_import import lazy_import
    import bzrlib
    scope = locals()
    lazy_import(scope, 'import foo', 'foo')
    disallow_proxying()
    try:
        scope['foo'].__class__
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('expecting IllegalUseOfScopeReplacer exception')



# Generated at 2022-06-24 02:49:13.593250
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestUtil
    from bzrlib.lazy_import import lazy_import
    # Method used to set up environment for test cases
    def setUp(self):
        super(TestCase, self).setUp()
        TestUtil.make_bzrdir('.')
        TestUtil.build_tree(['a', 'b/'])
        TestUtil.run_bzr(['add', 'a', 'b'])
        TestUtil.run_bzr(['commit', '-m', 'foobar'])
        TestUtil.run_bzr_subprocess(['branch', 'b', '../b2'])

# Generated at 2022-06-24 02:49:25.273975
# Unit test for method lazy_import of class ImportProcessor

# Generated at 2022-06-24 02:49:31.558431
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Ensure ImportReplacer constructor works as expected"""
    # This is a bit of a strange test, because it touches private
    # variables of ImportReplacer, but since ImportReplacer is a
    # fixture, it doesn't make sense to expose these as public
    # variables.

    # set up some test data
    children = {'bar':(['foo', 'bar'], None, {})}
    member = 'baz'
    module_path = ['foo', 'bar']
    name = 'foo'
    scope = {}

    r = ImportReplacer(scope=scope, name=name, module_path=module_path,
                       member=member)
    # Make sure the object was placed in the scope
    eq(scope[name], r)
    # And make sure the private variables have been set correctly

# Generated at 2022-06-24 02:49:44.589327
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import imports into scope.

    This tests that the global scope is updated with the imported
    object.
    """
    # No module bzrlib, should raise an ImportError
    try:
        bzrlib
    except:
        pass
    else:
        raise AssertionError('bzrlib module already exists')
    try:
        lazy_import(globals(), 'import bzrlib')
    except ImportError:
        # This is expected, because there is no bzrlib module.
        pass
    else:
        raise AssertionError('lazy_import did not fail when it should')

    # Now import a module that we can find:
    import bzrlib.tests.blackbox

    # and try again

# Generated at 2022-06-24 02:49:53.586651
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test constructor of class ScopeReplacer."""
    import sys
    from bzrlib import lockdir

    scope = sys.modules.copy()
    scope['sys'] = sys
    scope['bzrlib'] = lockdir
    factory = lambda replacer, scope, name: name

    try:
        s = ScopeReplacer(scope, factory, 'hello')
    except AssertionError:
        pass
    else:
        raise AssertionError('valid scope should not be refused')

    s = ScopeReplacer(scope, factory, 'lockdir')
    assert scope['lockdir'] is s
    assert s._resolve() is s._name



# Generated at 2022-06-24 02:50:05.954548
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-24 02:50:09.630997
# Unit test for function disallow_proxying
def test_disallow_proxying():
    # Just make sure that the function doesn't raise
    disallow_proxying()



# Generated at 2022-06-24 02:50:19.203693
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit tests for lazy_import.disallow_proxying."""

    def lazy_import(scope, str):
        ScopeReplacer(scope, lambda self, scope, x: self, 'bzrlib')
        object.__setattr__(scope['bzrlib'], 'errors',
                           ScopeReplacer(scope,
                                         lambda self, scope, x: self, 'errors'))
        object.__setattr__(scope['bzrlib'].errors, 'BzrError',
                           ScopeReplacer(scope['bzrlib'].errors.__dict__,
                                         lambda self, scope, x: self,
                                         'BzrError'))
    disallow_proxying()

# Generated at 2022-06-24 02:50:24.655497
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__(other)

    Should return True iff other is a IllegalUseOfScopeReplacer with the same
    attributes.
    """
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "%(name)s: %(msg)s"
    e1 = MyException("bzr", "silly", "extra")
    e1.name = "bzr"
    e1.msg = "silly"
    e1.extra = "extra"
    e2 = MyException("bzr", "silly", "extra")
    e2.name = "bzr"
    e2.msg = "silly"
    e2.extra = "extra"
    assert e1 == e2

# Generated at 2022-06-24 02:50:35.369371
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Regression test for https://bugs.launchpad.net/bzr/+bug/364407
    # and for https://bugs.launchpad.net/bzr/+bug/735980

    # This test does not test much, but it should not raise anything when
    # executed. I don't know how to do better with the current design.

    from bzrlib.tests.lazy_import_helper import SimpleObject
    import sys
    import time

    # the following is written to the global scope
    lazy_import(globals(), '''
    from bzrlib.lazy_import import ScopeReplacer, IllegalUseOfScopeReplacer, SimpleObject
    ''')

    # Create a scope replacer that creates a SimpleObject

# Generated at 2022-06-24 02:50:37.097939
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('Foobar', 'nothing')
    assert unicode(e) == u'nothing'
    e = e.__class__('Foobar', 'nothing', 'extra')
    assert unicode(e) == u'nothing: extra'

# Generated at 2022-06-24 02:50:42.719023
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    processor = ImportProcessor()
    text = """
# import a module
import bzrlib

# this is a longer style import
import bzrlib.foo.bar

# import a module and alias it
import bzrlib.foo.bar.baz as bing

# import a module and a member
import bzrlib.foo.bar.baz.DictConfig as DConfig
        """
    processor.lazy_import(globals(), text)
    # check that the scope has new entries
    assert 'bzrlib' in globals()
    assert 'bing' in globals()
    assert 'DConfig' in globals()
    # check that 'bing' is a refernece to 'bzrlib.foo.bar.baz'
    assert 'bzrlib' in globals()


# Generated at 2022-06-24 02:50:50.049251
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class TestScopeReplacer(ScopeReplacer):

        def __init__(self, scope, name):
            ScopeReplacer.__init__(self, scope, self._create, name)

        def _create(self, scope, name):
            return scope[name] + 42

    my_scope = {'x': 42}
    TestScopeReplacer(my_scope, 'y')
    return my_scope['y'] == 84



# Generated at 2022-06-24 02:50:56.100565
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """__str__ must return a str, not unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(e.name, unicode)
    assert isinstance(e.msg, unicode)
    assert isinstance(e.extra, unicode)
    e_repr = repr(e)
    assert isinstance(e_repr, str)



# Generated at 2022-06-24 02:51:05.470137
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """ImportProcessor.lazy_import must:
        - Create a new ImportProcessor object with proper values
        - Convert lazy_import_class=None to ImportReplacer
        - Create a proper lazy_import object
        - Split multiline import text into single lines
        """
    # Test 1
    # Simple case: import x,y,z => x, y, z
    import_process = ImportProcessor()
    scope = {}
    import_process.lazy_import(scope, 'import x,y,z')
    assert scope['x'].__class__ == ImportReplacer
    assert scope['y'].__class__ == ImportReplacer
    assert scope['z'].__class__ == ImportReplacer
    # Test 2
    # Test incorrect import text
    import_process = ImportProcessor()
    scope = {}
    raised

# Generated at 2022-06-24 02:51:17.735245
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Testing method IllegalUseOfScopeReplacer.__eq__

    This is an example of a very contrived unit test.  The goal of this
    test is to make sure that IllegalUseOfScopeReplacer implements __eq__
    correctly.  Without this test, one could easily make a mistake in the
    implementation of __eq__ and pass all tests without knowing about it.
    """
    # First, a test for a class that does not have __eq__ inherited from
    # object.
    class Foo:
        pass

    e1 = Foo()
    e1.foo = 1
    e2 = Foo()
    e2.foo = 1
    if e1 == e2:
        raise AssertionError('Foo instances should not compare equal')
    if e2 == e1:
        raise AssertionError('Foo instance should not compare equal')

# Generated at 2022-06-24 02:51:27.274287
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer("name", "msg", "extra")
    e2 = IllegalUseOfScopeReplacer("name", "msg", "extra")
    e3 = IllegalUseOfScopeReplacer("name", "msg")
    e4 = IllegalUseOfScopeReplacer("name", "msg2", "extra")
    e5 = IllegalUseOfScopeReplacer("name2", "msg", "extra")
    e6 = IllegalUseOfScopeReplacer("name2", "msg2", "extra")
    assert e1 == e2
    assert e1 != e3
    assert e1 != e4
    assert e1 != e5
    assert e1 != e6



# Generated at 2022-06-24 02:51:36.626148
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import lazy_import
    from bzrlib.tests.per_lazy_import import TestCaseWithLazyImport
    import os
    import sys
    import tempfile
    test_module = tempfile.mktemp(dir='.', prefix='test_module', suffix='.py')
    test_lazy_module = tempfile.mktemp(dir='.', prefix='test_lazy_module', suffix='.py')
    self = TestCaseWithLazyImport()

# Generated at 2022-06-24 02:51:47.286628
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ must return True if exception is equal,
    False otherwise and NotImplemented on different exception classes."""
    # Equals
    e1 = IllegalUseOfScopeReplacer("name", "msg", "extra")
    e2 = IllegalUseOfScopeReplacer("name", "msg", "extra")
    assert e1 == e2
    # Not equals - different class
    class DifferentException(Exception):
        pass
    e3 = DifferentException("name", "msg", "extra")
    assert e1 != e3
    assert e3 != e1
    e2 = IllegalUseOfScopeReplacer("different_name", "msg", "extra")
    assert e1 != e2
    assert e2 != e1

# Generated at 2022-06-24 02:51:55.138921
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test that the method __setattr__ of class ScopeReplacer the basic
    # operations of setting an attribute and that raising an exception
    # works
    class A:
        pass
    a = A()
    replacer = ScopeReplacer({}, lambda *x: a, 'a')
    replacer.x = 1
    # test that the value is set on the object
    assert a.x == 1
    # test that exceptions are raised
    raises(AttributeError, setattr, replacer, 'bla', None)


# Generated at 2022-06-24 02:52:04.862453
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_text_lines = """
        # This line is a comment and should be ignored
        import bzrlib.foo
        import bzrlib.bar as bar, bzrlib.baz
        from bzrlib import bing
        from bzrlib import bing as bing2
        from bzrlib import blah, blar, blaw, \
                           blee, bloo, blip, blar #, blip
        from bzrlib.boo import bar
        from bzrlib.boo import bar, baz as baz2 #, bing
    """.strip().split('\n')

    m = []

    import_text = '\n'.join(import_text_lines)
    ip = ImportProcessor()
    ip.lazy_import({}, import_text)


# Generated at 2022-06-24 02:52:11.821124
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import __builtin__
    assert not hasattr(__builtin__, '__setattr__')
    class C(ScopeReplacer):
        __slots__ = ()
        def _resolve(self):
            return self
    c = C({}, lambda self, scope, name: self, 'c')
    c.x = 42
    assert not hasattr(__builtin__, '__setattr__')
    assert c.x == 42
    test_ScopeReplacer___setattr__()

    def test_ScopeReplacer___setattr__():
        import __builtin__
        assert not hasattr(__builtin__, '__setattr__')
        class C(ScopeReplacer):
            __slots__ = ()
            def _resolve(self):
                return self

# Generated at 2022-06-24 02:52:22.990845
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # imports which were not correct raise an error
    def _test_bad_string(input_string):
        import_processor = ImportProcessor()
        e = self.assertRaises(errors.InvalidImportLine,
            import_processor.lazy_import, globals(), input_string)
        # We are trying to check that the error message is printed
        self.assertContainsRe(str(e), 'Invalid Import Line')
    # Testing invalid strings
    _test_bad_string('')
    _test_bad_string('from bzrlib import')
    _test_bad_string('import bzrlib,')
    _test_bad_string('from bzrlib import bzrlib as alias')
    _test_bad_string('import bzrlib import bzrlib as alias')
    _test_bad

# Generated at 2022-06-24 02:52:30.342215
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # Test code
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(), text = """
        import foo, bar
        from baz import bing, bong
    """)

# Generated at 2022-06-24 02:52:41.103432
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """__init__ should set attributes"""
    err = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    eq = err.__eq__
    # eq is a method bound to err.
    # this is important because most subclasses do not provide __eq__
    # and we don't want to break the default implementation.
    eq(err) # should not raise

    # check the attributes
    # in python 2.6, if you say eq('foo', 'bar'), and __eq__ returns
    # NotImplemented, python doesn't actually call 'ne' (which is the
    # default implementation of __ne__). But in earlier versions it does
    # call 'ne' instead. So for python 2.5, we test the .__eq__ attribute
    # directly, and for 2.6, we test the .__dict__ attribute directly.

# Generated at 2022-06-24 02:52:43.893912
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # See http://bugs.python.org/issue4776
    from bzrlib import lazy_import
    lazy_import(locals(), '''
    from bzrlib import osutils
    ''')
    if osutils.canonical_path('/') != '/':
        raise AssertionError('/ must be /')


# Generated at 2022-06-24 02:52:48.250303
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should print the message."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    msg = 'ScopeReplacer object %r was used incorrectly:' \
        ' %s: extra' % (e.name, e.msg)
    assert_equal(str(e), msg)



# Generated at 2022-06-24 02:52:50.343788
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test constructor of class ImportProcessor."""
    lazy_import_class = ImportReplacer
    ip = ImportProcessor(lazy_import_class)
    assert ip._lazy_import_class is ImportReplacer



# Generated at 2022-06-24 02:52:58.624903
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor"""
    def test_helper(processor, lazy_import_class):
        eq(processor._lazy_import_class, lazy_import_class)
        eq(processor.imports, {})
    # Test the default constructor
    processor = ImportProcessor()
    test_helper(processor, ImportReplacer)
    # Test constructor with customized lazy import class
    class TestImportReplacer(ImportReplacer):
        pass
    processor = ImportProcessor(lazy_import_class=TestImportReplacer)
    test_helper(processor, TestImportReplacer)

# Unit tests for method _canonicalize_import_text

# Generated at 2022-06-24 02:53:11.493052
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib
    bzrlib.trace.enable_default_logging()
    t = '''
    import bzrlib

    # import bzrlib, os
    # import os, bzrlib
    import bzrlib, os, sys

    from bzrlib import osutils
    from bzrlib.tests import (
        test_perf, test_offlineimap)

    from bzrlib.trace import mutter
    from bzrlib.trace import (
        mutter, note)

    import bzrlib,
        os

    from bzrlib import (
        osutils,
        respository,
    )
    import (
        bzrlib,
        os,
    )
    '''
    replacer = ImportProcessor()
    replacer