

# Generated at 2022-06-24 02:43:11.918982
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test the constructor of IllegalUseOfScopeReplacer

    The constructor is not a real exception, is a class factory.
    """

    exc = IllegalUseOfScopeReplacer('foo', 'bar')
    assert exc.name == 'foo'
    assert exc.msg == 'bar'
    assert exc.extra == ''
    assert isinstance(str(exc), str)
    assert isinstance(unicode(exc), unicode)
    assert repr(exc) == "IllegalUseOfScopeReplacer('foo', 'bar')"



# Generated at 2022-06-24 02:43:15.665903
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    factory = lambda self, scope, name: scope[name]
    ScopeReplacer(scope, factory, 'foo')
    scope['foo'] = 'bar'
    # ScopeReplacer._resolve() should now return the value of scope['foo'],
    # which is 'bar'
    assert scope['foo']._resolve() == 'bar'



# Generated at 2022-06-24 02:43:26.628056
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that lazy imports detect indirect accesses to them."""
    globals()['called'] = None
    def f():
        import sys
        globals()['called'] = sys
        return sys

    lazy_import(globals(), 'from bzrlib.lazy_import import ScopeReplacer')
    ScopeReplacer._should_proxy = True
    ScopeReplacer(globals(), f, 'sys')
    assert sys is not None
    sys.modules
    assert called is None
    disallow_proxying()
    try:
        sys.modules
    except IllegalUseOfScopeReplacer as e:
        assert 'sys' in str(e)
    else:
        raise AssertionError(
            'IllegalUseOfScopeReplacer not raised when trying to access'
            ' sys.modules')



# Generated at 2022-06-24 02:43:29.096752
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def f(self, scope, name):
        raise AssertionError('f')
    scope = {}
    r = ScopeReplacer(scope, f, 'r')
    r()


# Generated at 2022-06-24 02:43:32.200887
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib
    # TODO: how are we going to test this?
    # Its not clear how the object is to be called on the first run to
    # generate a real object.
    pass



# Generated at 2022-06-24 02:43:39.558114
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the ImportProcessor class, which is used to lazy import packages.

    These tests should ideally be moved into a separate file, but they have to
    be here for now because of the way that the lazy_import() function works.
    """
    # Some helper functions
    def assert_map(expected, actual):
        """Check that two maps are equal, by comparing each key, value pair.

        :param expected: The expected map.
        :param actual: The actual map.
        """
        if expected != actual:
            raise Exception("expected: %r != actual: %r" % (expected, actual))


# Generated at 2022-06-24 02:43:44.307260
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import test_lazy_import
    import sys
    import types

    def factory(replacer, scope, name):
        return test_lazy_import
    scope = sys.modules
    name = 'bzrlib.tests.test_lazy_import'
    replacer = ScopeReplacer(scope, factory, name)
    obj = replacer._resolve()
    assert isinstance(obj, types.ModuleType)
    assert obj is test_lazy_import


# Generated at 2022-06-24 02:43:53.160671
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    import_processor._build_map('''
        import foo, (bar, baz)
        from foo import bar, baz
        from foo.bar import bing as blab
        ''')
    r = import_processor.imports
    assert 'foo' in r
    assert 'bar' in r
    assert 'baz' in r
    assert 'bing' in r
    r['foo'] == (['foo'], None, {'bar':(['foo', 'bar'], None,
                               {'bing':(['foo', 'bar', 'bing'], 'bing', {})}),
                                'baz':(['foo', 'baz'], 'baz', {})})
    r['bing'] == (['foo', 'bar', 'bing'], 'bing', {})

# Generated at 2022-06-24 02:43:57.060126
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    for self in [Exception(), Exception(None), Exception('hi'), Exception(1)]:
        check__unicode__equality(self)

# Generated at 2022-06-24 02:44:01.562713
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """The __str__() method of the IllegalUseOfScopeReplacer class must
    return a str object.
    """
    msg = "lazy import message"
    name = 'lazy_import'
    e = IllegalUseOfScopeReplacer(name, msg)
    assert isinstance(e.__str__(), str), \
        "__str__() must return a str object."



# Generated at 2022-06-24 02:44:08.627725
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    import sys
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    u = unicode(e)
    if sys.version_info[0] == 2:
        from bzrlib import _i18n_pyutils
        assert isinstance(s, str)
        assert isinstance(u, unicode)
        if _i18n_pyutils.is_unicode_safe_default_encoding():
            # We can't check for equality below if the encoding isn't one we
            # can convert to unicode.
            assert s == u
    else:
        from bzrlib import _i18n_pyutils
        assert isinstance(s, bytes)
        assert isinstance(u, str)

# Generated at 2022-06-24 02:44:17.730921
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), '''
    from bzrlib.lazy_import import disallow_proxying
    ''')
    import sys
    import bzrlib
    sys.modules['bzrlib'] = ScopeReplacer(globals(), lambda s, sc, n: sys.modules[n], 'bzrlib')
    disallow_proxying()
    try:
        # This test is not thread-safe, it might fail spuriosly in a
        # multithreaded environment.
        bzrlib.tests.test_lazy_import
        # If we get here, the test failed.
        raise AssertionError('Lazy import module bzrlib still proxying.')
    except IllegalUseOfScopeReplacer:
        pass



# Generated at 2022-06-24 02:44:21.726118
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() with a preformatted string"""
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'extra')
    assert repr(e) == "IllegalUseOfScopeReplacer('foo', 'bar', 'extra')"



# Generated at 2022-06-24 02:44:27.794604
# Unit test for function lazy_import
def test_lazy_import():
    globals_dict = {}
    text = 'from bzrlib import (\nfoo,\nbar,\nbaz,\n)'
    lazy_import(globals_dict, text)
    # We should have the import_replacers
    for name in 'foo', 'bar', 'baz':
        imp = globals_dict[name]
        assert isinstance(imp, ImportReplacer)
        assert imp in scope_replacers
test_lazy_import.__test__ = False



# Generated at 2022-06-24 02:44:36.956546
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.lazy_import import ImportReplacer
    from bzrlib.lazy_import import ImportProcessor
    from bzrlib.lazy_import import lazy_import

    def verify_imports(scope):
        for name in ('foo', 'bar', 'baz', 'bzrlib'):
            if name not in scope or not isinstance(scope[name], ImportReplacer):
                raise AssertionError('%r is not imported properly' % (name,))
        for name in ('bzrlib.transport', 'bzrlib.branch'):
            try:
                getattr(scope['bzrlib'], name)
            except AttributeError:
                raise AssertionError('%r is not imported properly' % (name,))

    scope = {}
    proc = Import

# Generated at 2022-06-24 02:44:45.509935
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that ImportReplacer object is generated correctly."""
    scope = {}
    name = 'test_module'
    module_path = ['bzrlib', 'tests']
    children = {'submodule_name': (['bzrlib', 'tests', 'submodule'],
                                   None,
                                   {})}

    ImportReplacer(scope, name, module_path, children=children)
    assert scope[name]._import_replacer_children == children
    assert scope[name]._member is None
    assert scope[name]._name == name
    assert scope[name]._scope is scope
    assert scope[name]._module_path == module_path

    # This can be removed after we move all objects to always be imported
    # via ImportReplacer
    scope = {}
    name = 'test_module'
   

# Generated at 2022-06-24 02:44:54.829696
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class Foo(object):
        pass

    scope = dict()

    def make_Foo(self, scope, name):
        return Foo()

    # Should create a proxy of type ScopeReplacer
    a = ScopeReplacer(scope, make_Foo, 'a')
    assert type(a) is ScopeReplacer

    # Should access the real Foo object when referenced
    assert isinstance(a, Foo)
    assert type(a) is Foo

    # Should replace itself with the real Foo object in scope
    assert scope['a'] is a
    assert scope['a'] is not a
    assert scope['a'] is not a
    assert scope['a'] is scope['a']



# Generated at 2022-06-24 02:45:04.987818
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    from bzrlib import config
    import random
    import sys

    random.seed(1)
    sys.modules['testmodule'] = config
    i = ImportProcessor()

    # Common pattern for unit tests
    if not hasattr(i, 'imports'):
        raise ImportError('ImportProcessor does not have the imports attribute')

    # Unit test for method lazy_import of class ImportProcessor
    def test_lazy_import_1():
        i.lazy_import(globals(),
"""import random
from testmodule import config
import os""")

        import random as _real_random
        from testmodule import config
        import os as _real_os
        import testmodule as _real_testmodule
        config = config


# Generated at 2022-06-24 02:45:15.523989
# Unit test for function lazy_import
def test_lazy_import():
    """Unit test for lazy_import, using ImportProcessor."""
    text = '''
    from bzrlib import (
       foo,
       bar,
       baz
       )
    import bzrlib.branch
    import bzrlib.transport
    '''
    # Create a map to match what will be created by import processor

# Generated at 2022-06-24 02:45:25.763730
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # XXX: this test should eventually become a doctest.
    # This class is not intended to be used outside of ScopeReplacer, but many
    # error routines do not expect the subclass to define __str__ and it is
    # useful to have a consistent text representation.
    e1 = IllegalUseOfScopeReplacer('my object',
        'The object can only be used in a scope.')
    e2 = IllegalUseOfScopeReplacer('my object',
        'The object can only be used in a scope.')
    assert str(e1) == str(e2)
    assert e1 == e2

# Generated at 2022-06-24 02:45:29.239830
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    ## call the method with all possible argument combinations.
    def funk(self, scope, name):
        return "obj"
    name = 'foo'
    scope = {name: None}
    r = ScopeReplacer(scope, funk, name)
    assert r() == "obj"



# Generated at 2022-06-24 02:45:38.535761
# Unit test for function lazy_import
def test_lazy_import():
    """Test that the function lazy_import works as expected."""
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import

    # Make sure that the __dict__ has no mention of bzrlib.tests.* objects
    for key in bzrlib.tests.__dict__.keys():
        if key.startswith('test_'):
            raise AssertionError('%r already in bzrlib.tests' % (key,))
    scope = bzrlib.tests.__dict__

    # Now do the lazy import
    lazy_import(scope,
        '''from bzrlib.tests import test_lazy_import''')

    # Now make sure that bzrlib.tests.test_lazy_import exists
    test_lazy_import = bzr

# Generated at 2022-06-24 02:45:45.024645
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase

    def _factory():
        # This will be replaced with a real object ready for use
        return None

    class _TestCase(TestCase):

        def test_setattr_before_resolved(self):
            # setattr should work even before ScopeReplacer has been resolved
            # to a real object.
            my_replacer = ScopeReplacer(None, _factory, None)
            my_replacer.a = 'a'

    _TestCase().run()

# Generated at 2022-06-24 02:45:52.475587
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys

    class TestScopeReplacer(TestCase):

        def test__setattr__should_not_allow_replacement_of_attributes(self):
            scope = {}
            def _factory(_name):
                return _name
            def _test(name, attr):
                scope[name] = ScopeReplacer(scope, _factory, name)
                setattr(scope[name], attr, 'bar')
                self.assertEquals('bar', getattr(scope[name], attr))
            _test('foo', 'foo')
            _test('bar', 'baz')
            _test('baz', '__dict__')

    from bzrlib.tests import TestUtil

# Generated at 2022-06-24 02:45:56.700480
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test the function disallow_proxying."""
    # First, let's check that the selection of the global variable
    # works well.
    assert ScopeReplacer._should_proxy
    disallow_proxying()
    assert not ScopeReplacer._should_proxy
    ScopeReplacer._should_proxy = True
    # Now let's test that the variable is properly set to False.
    from bzrlib import lazy_import
    def foo():
        return 'foo'
    def bar():
        return 'bar'
    # None of the lazy_import objects are created yet.
    lazy_import._test_a = None
    lazy_import._test_b = None
    # First, we have to disallow proxies or the test will be much too simple.
    disallow_proxying()
    # Now, we create the proxies,

# Generated at 2022-06-24 02:46:02.660405
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Method __repr__ returns the code to construct this exception object

    The constructor must be able to construct the object from the string
    returned by __repr__.
    """
    exc = IllegalUseOfScopeReplacer('exc', 'hello there', 'how are you')
    obj = eval(repr(exc))
    assert_equal(str(exc), str(obj))
    assert_equal(exc, obj)



# Generated at 2022-06-24 02:46:13.577089
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests._mock_module as _mock_module
    bzrlib._mock_module = _mock_module

# Generated at 2022-06-24 02:46:17.770650
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Method __eq__ of class IllegalUseOfScopeReplacer"""
    e1 = IllegalUseOfScopeReplacer(1, 2)
    e2 = IllegalUseOfScopeReplacer(1, 2, extra=None)
    e3 = IllegalUseOfScopeReplacer(1, 2, extra=3)
    assert e1 == e2
    assert not e1 == e3



# Generated at 2022-06-24 02:46:19.650863
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra msg')
    repr(obj)



# Generated at 2022-06-24 02:46:31.008748
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()

    This tests that __str__() will raise an error when no format string
    is available, and that __str__() will not raise an error if the format
    string does not match the arguments.
    """
    # Test for an IllegalUseOfScopeReplacer that does not contain a
    # format string
    class Foo(IllegalUseOfScopeReplacer):
        pass

    ex = Foo('test', 'foo')
    # Test that the object is re-created when we try to get the message
    e = raises(Exception, str, ex)
    # The exception should have a message that mentions that we could not
    # get the format message

# Generated at 2022-06-24 02:46:42.219269
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # All data paths are legal.
    replacer = ImportReplacer(object(), name='foo', module_path=['foo'],
                member=None, children={})
    replacer = ImportReplacer(object(), name='foo', module_path=['foo'],
                member='bar', children={})

    # Invalid data paths
    try:
        ImportReplacer(object(), name='foo', module_path=['foo'], member='bar',
                       children={'baz':(None, None, None)})
    except:
        pass
    else:
        raise AssertionError("Invalid data paths should raise error")

    try:
        ImportReplacer(object(), name='foo', module_path=['foo'],
                       member=None, children={'baz':(None, None, None)})
    except:
        pass

# Generated at 2022-06-24 02:46:52.516283
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ for ScopeReplacer.

    The general test strategy for ScopeReplacer is to:
    * create a scope holder
    * create a ScopeReplacer and inject it into the scope holder
    * assert that the scope holder and the fixed scope have a ScopeReplacer
    * invoke the ScopeReplacer to get the actual object
    * assert that the scope holder has a real object
    * assert that the fixed scope has both a real object and an
      unchanged ScopeReplacer

    The following tests have their own special assertions.
    """
    def _assert_scope_unchanged(scope, name, attr):
        """Assert that an object in scope is the same as an equivalent
        object in FIXED_SCOPE.
        """
        scope_obj = getattr(scope, name)
        fixed_obj = getattr(FIXED_SCOPE, name)

# Generated at 2022-06-24 02:47:02.751089
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.script import (
        must_be_writable,
        test_suite,
        )

    class TestScopeReplacer(TestCase):

        def test___call__(self):
            orig_should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-24 02:47:13.880363
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy_import."""

    class TestMapper(object):
        """Lazily map an object."""

        def __init__(self, scope, name, obj):
            """Map <name> in <scope> to <obj>."""
            self.scope = scope
            self.name = name
            self.obj = obj
            self.resolved = False

        def _resolve(self):
            """Resolve this mapping."""
            if self.resolved:
                return self.obj
            self.resolved = True
            self.scope[self.name] = self.obj
            return self.obj

        def __getattribute__(self, attr):
            obj = object.__getattribute__(self, '_resolve')()
            return getattr(obj, attr)


# Generated at 2022-06-24 02:47:24.582274
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():

    def called_factory(self, scope, name):
        return locals()

    class ClassScope(object):
        pass
    scope = ClassScope()
    factory = called_factory
    name = 'name'
    replacer = ScopeReplacer(scope, factory, name)

    obj = replacer.__getattribute__('_resolve')()
    expected = replacer
    got = obj['self']
    if expected != got:
        raise AssertionError("expected %r != %r" % (expected, got))
    expected = {'self': replacer, 'scope': scope, 'name': 'name'}
    got = obj
    if expected != got:
        raise AssertionError("expected %r != %r" % (expected, got))

    # __getattribute__() is not thread safe
    replacer = Scope

# Generated at 2022-06-24 02:47:32.096511
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    class TestReplacer(ImportReplacer):

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            ImportReplacer.__init__(self, *args, **kwargs)

    import_text = """
        import foo, bar, baz
        import foo.bing, bing.bar
    """
    expected_imports = {
        'foo': ([], None, {
            'bing': ([], None, {})},
        ),
        'bar': ([], None, {}),
        'baz': ([], None, {}),
        'bing': ([], None, {'bar': ([], None, {})}),
        }

    text_processor = ImportProcessor(lazy_import_class=TestReplacer)
    text_processor.l

# Generated at 2022-06-24 02:47:43.313877
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestException(Exception):
        def __init__(self, *args):
            super(TestException, self).__init__(*args)
    class TestCase(TestCase):
        """Simple tests to exercise the custom str methods of
        IllegalUseOfScopeReplacer.
        """
        def test__str__(self):
            def f(): raise TestException('Invalid name')
            self.assertRaises(TestException, f)
            e = TestException('Invalid name')
            self.assertTrue(isinstance(str(e), str))
            self.assertTrue(isinstance(unicode(e), unicode))
            self.assertRaises(TestException, f)

# Generated at 2022-06-24 02:47:51.022462
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test cases for method IllegalUseOfScopeReplacer.__eq__"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    class MyIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        pass

    class MyIllegalUseOfScopeReplacerSubclass(
        MyIllegalUseOfScopeReplacer):
        pass

    error1 = MyIllegalUseOfScopeReplacer("name", "msg")
    error1_copy = MyIllegalUseOfScopeReplacer("name", "msg")
    error2 = MyIllegalUseOfScopeReplacer("name", "msg2")
    error3 = MyIllegalUseOfScopeReplacer("name2", "msg")

# Generated at 2022-06-24 02:48:01.638545
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the ImportProcessor class.

    This is a unit test for the class ImportProcessor.
    """
    import traceback
    try:
        # Test the constructor of class ImportProcessor.
        import_processor = ImportProcessor()
    except:
        # If an exception is thrown, print an error message, the traceback
        # of the exception, and exit with status code 1.
        print('ERROR: An exception was thrown when calling the constructor of '
            'class ImportProcessor in module import_lazy.')
        traceback.print_exc(file=sys.stdout)
        sys.exit(1)
    print('Everything is ok.')
    # Exit with status code 0.
    sys.exit(0)


# Generated at 2022-06-24 02:48:12.994820
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    class SubException(IllegalUseOfScopeReplacer):
        """Subclass for testing purposes"""

    # Test basic functionality
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    e3 = IllegalUseOfScopeReplacer('name', 'msgt')
    e4 = IllegalUseOfScopeReplacer('namet', 'msg')
    e5 = SubException('name', 'msg')

    assert e1.__eq__(e1)
    assert e1.__eq__(e2)
    assert not e1.__eq__(e3)
    assert not e1.__eq__(e4)
    assert not e1.__eq__(e5)


# Generated at 2022-06-24 02:48:23.755412
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test a bunch of import statements to make sure they get converted properly.

    This is a little odd, because we don't have a setup method. I
    don't think we need one, because we're not relying on anything in
    the fixture.
    """
    # This is all a little weak, because we only test one module at a
    # time. Ideally, we'd want to test a bunch of imports, as well as
    # complex interactions between the modules.
    # For example, we don't test that 'from foo.bar.baz import quux,
    # grault' works when 'foo.bar.baz' is already imported.
    scope = {}
    processor = ImportProcessor()
    processor.lazy_import(scope, 'import bzrlib')
    assert scope['bzrlib'] is None

# Generated at 2022-06-24 02:48:32.822345
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """test for method IllegalUseOfScopeReplacer.__eq__"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class ConcreteException(IllegalUseOfScopeReplacer):
        pass
    e1 = ConcreteException('foo', 'hello world')
    e2 = ConcreteException('foo', 'hello world')
    e3 = ConcreteException('foo', 'hello cruel world')
    e4 = ConcreteException('foo', 'hello world', 'unexpected')
    e5 = ConcreteException('foo', 'hello world', 'unexpected')
    e6 = ConcreteException('bar', 'hello world')
    # Exact matches are equal
    assert e1 == e2, repr((e1, e2))
    # Different parameters are not equal

# Generated at 2022-06-24 02:48:43.973673
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test for function disallow_proxying"""
    namespace = {}
    func = __builtins__['__import__']
    def interpose(*args, **kwargs):
        r = func(*args, **kwargs)
        if args[0] == 'time':
            assert r is namespace['time']
        return r

# Generated at 2022-06-24 02:48:51.622905
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    scope = {}
    for line in ('from foo import bar',
                 'from bar import foo, baz',
                 'from baz import foo as bar, baz as foo',
                 'import foo',
                 'import foo, foo.bar, foo.unga',
                 'import foo as bar, foo.bar as bing',
                 'import(foo)',
                 'import(foo, foo.bar, bing.baz)'):
        proc = ImportProcessor()
        proc.lazy_import(scope, line)
        proc._convert_imports(scope)
        assert (isinstance(scope['foo'], ImportReplacer) or
            isinstance(scope['bar'], ImportReplacer) or
            isinstance(scope['baz'], ImportReplacer))


# Generated at 2022-06-24 02:48:59.158999
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), """
    import bzrlib
    """)
    disallow_proxying()
    # Accessing the lazily imported module should raise an exception,
    # because it was called after disallow_proxying.
    e = None

# Generated at 2022-06-24 02:49:10.625681
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that ScopeReplacer cannot be used directly.

    It should only be used via the lazy_import function.
    """
    import bzrlib.lazy_import as lazy_import
    def _factory_raises(self, scope, name):
        raise AssertionError('Should not be called')

    class _Scope(object):
        pass

    Scope = None
    # Make sure lazy_import wraps in try/except.
    try:
        ScopeReplacer(Scope, _factory_raises, 'foo')
    except TypeError:
        pass
    else:
        raise AssertionError('Direct use of ScopeReplacer allowed')
    # Check that the generated code from lazy_import is correct
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-24 02:49:18.029833
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import types

    class Foo(object):
        pass

    foo = Foo()
    mod = types.ModuleType('_scope_replacer_selftest')

    def factory(replacer, scope, name):
        return replacer

    ScopeReplacer(scope=vars(mod), factory=factory, name='foo')
    assert mod.foo is not foo
    assert mod.foo == foo
    assert mod.foo._resolve() is foo
    assert mod.foo._resolve() is foo
    assert mod.foo == foo



# Generated at 2022-06-24 02:49:19.694977
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    processor = ImportProcessor()
    return processor


# Generated at 2022-06-24 02:49:24.094272
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    global a
    b = ScopeReplacer({}, lambda s, scope, name: scope[name] + 'bar', 'a')
    a = 'foobar'
    my_assertRaises(IllegalUseOfScopeReplacer, b._resolve)
    assert b == 'foobarbar'

# Generated at 2022-06-24 02:49:27.533782
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__: compare scope replacer and self"""
    import copy
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert e == e
    f = copy.copy(e)
    assert e == f
    f.name = 'foobar'
    assert e != f



# Generated at 2022-06-24 02:49:29.574118
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    bzrlib.tests.Util.test_function_attributes(ScopeReplacer.__call__)



# Generated at 2022-06-24 02:49:34.821448
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ of class IllegalUseOfScopeReplacer must return a str.
    """
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    if not isinstance(str(exc), str):
        raise AssertionError("IllegalUseOfScopeReplacer.__str__ did not return str")

# Generated at 2022-06-24 02:49:47.053767
# Unit test for function lazy_import
def test_lazy_import():
    import sys

    # This is a very simple test, but right now the code is simple, so it
    # should suffice.

    # We need to ensure the imports don't already exist
    if 'bzrlib' in sys.modules:
        raise TestSkipped('bzrlib already imported')
    if 'bzrlib.transport' in sys.modules:
        raise TestSkipped('bzrlib.transport already imported')

    lazy_import(globals(), '''
        import bzrlib
        import bzrlib.transport
    ''')
    # We shouldn't have the modules yet
    if 'bzrlib' in sys.modules:
        raise TestSkipped('bzrlib already imported')
    if 'bzrlib.transport' in sys.modules:
        raise TestSkipped

# Generated at 2022-06-24 02:49:51.576726
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should behave well for IllegalUseOfScopeReplacer"""
    # Make sure that we can use str() on IllegalUseOfScopeReplacer
    # and that it returns a str object, not a unicode one.
    exception = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str(exception)



# Generated at 2022-06-24 02:49:53.444238
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    assert ip._lazy_import_class == ImportReplacer

    ip = ImportProcessor(ImportReplacer)
    assert ip._lazy_import_class == ImportReplacer



# Generated at 2022-06-24 02:50:05.814167
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class ImportReplacerStub(ImportReplacer):
        # Stub class so we can call _import and not actually import anything
        def _import(self, scope, name):
            return 'imported module'
    def check(name, module_path, member, children):
        scope = {}
        ImportReplacerStub(scope, name=name, module_path=module_path,
                           member=member, children=children)
        return scope
    scope = check('foo', ['foo'], None, {})
    assert scope['foo'] == 'imported module'
    scope = check('foo', ['foo', 'bar'], None, {})
    assert scope['foo'] == 'imported module'

# Generated at 2022-06-24 02:50:11.140439
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor."""
    import_processor = ImportProcessor()
    assert import_processor.imports == {}
    assert import_processor._lazy_import_class == ImportReplacer


# Generated at 2022-06-24 02:50:22.521301
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying."""
    import bzrlib
    lazy_import(locals(), """
    from bzrlib import errors, osutils
    errors.lazy_import(locals(), '''
    from bzrlib.tests import TestCase
    ''', locals_erase=True)
    """)
    # lambda functions are used to avoid getting any local variables that
    # would be resolved by the interpreter before the lazy_import calls
    # above.
    b = errors.BzrError
    b()
    o = osutils.sha_string
    o()
    disallow_proxying()
    b()
    o()
    import testtools
    TestCase().runTest()
    TestCase().runTest()
    TestCase().runTest()



# Generated at 2022-06-24 02:50:29.358168
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    import bzrlib.knit
    ''')
    globs = globals()
    doc = doctest.DocTestParser().get_doctest(globs, globs, '__call__',
                                              ScopeReplacer, 0)
    runner = doctest.DocTestRunner()
    runner.run(doc)


# Generated at 2022-06-24 02:50:32.918716
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor"""
    import_processor = ImportProcessor()
    # Test of the constructor
    assert import_processor.__class__.__name__ is 'ImportProcessor'


# Generated at 2022-06-24 02:50:40.050846
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    import bzrlib.branch
    class _Dummy:
        def __init__(self, a=1, b=2):
            self.a = a
            self.b = b
    s = ScopeReplacer({},
                      lambda x, y, z: _Dummy(a=1, b=1),
                      's')
    s = s(a=2, b=3)
    # end test_ScopeReplacer___call__
    assert (s.a, s.b) == (2, 3)


# Generated at 2022-06-24 02:50:48.904279
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import (
        default_scope,
        )
    from contextlib import contextmanager
    from StringIO import StringIO
    from bzrlib.lazy_import import (
        _get_failing_module,
        _make_failing_module_name,
        )
    no_module_name = _make_failing_module_name(__name__, __name__)
    no_module_module = _get_failing_module(__name__)
    @contextmanager
    def get_module_context(module_name, module_object):
        """Return a context manager to restore the module_name, module_object.

        This is a convenience context manager that restores the module_name
        and module_object while inside the context, and then removes them
        afterwards.
        """

# Generated at 2022-06-24 02:50:57.475936
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test getattribute in case _real_obj is a class"""
    class OtherClass:
        def __init__(self):
            self.test_attr = 'test'
    def factory(self, scope, name):
        return OtherClass()
    scope = {'testname':None}
    replacer = ScopeReplacer(scope, factory, 'testname')
    assert scope['testname'] == replacer
    assert scope['testname'].test_attr == 'test'
    assert scope['testname'] == scope['testname']
    assert scope['testname'] == scope['testname'].__class__



# Generated at 2022-06-24 02:51:04.596552
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    exc = IllegalUseOfScopeReplacer('a', 'b')
    assert str(exc)
    assert repr(exc)
    assert unicode(exc)
    assert exc.name == 'a'
    assert exc.msg == 'b'

    # check that the u'' prefix on the message works
    exc = IllegalUseOfScopeReplacer('a', u'c')
    assert str(exc)
    assert repr(exc)
    assert unicode(exc)
    assert exc.msg == u'c'
    assert 'Unicode' in str(exc) # the unicode prefix is visible in the ascii



# Generated at 2022-06-24 02:51:10.422826
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('bob', 'cat is gone')
    assert str(e) == 'IllegalUseOfScopeReplacer: "%(name)r was used incorrectly: %(msg)s%(extra)s": name=bob, msg=cat is gone, extra=: '
    assert repr(e) == 'IllegalUseOfScopeReplacer("bob", "cat is gone")'


# Generated at 2022-06-24 02:51:21.894117
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class A(object): pass
    a = A()
    scope = {}
    scope['a'] = a
    scope['b'] = a
    sr = ScopeReplacer(scope, _create_return_arg, 'c')
    assert sr._resolve() is sr
    assert sr.__getattribute__('_resolve') is A.__getattribute__
    assert sr.foo == 'foo'
    assert sr.bar(1, baz='baz') == ('bar', (1,), {'baz': 'baz'})
    assert sr.__getattribute__ is A.__getattribute__
    assert scope['a'] is a
    assert scope['b'] is a
    assert scope['c'] is sr


# Generated at 2022-06-24 02:51:26.638882
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    import doctest
    from bzrlib.tests import (Symbol,
                              test_sprint,
                              test_printing,
                              test_i18n) # get full i18n setup
    # So that we can test the equivalence of exceptions with different
    # format strings.
    test_i18n._set_exception_str_func()
    return doctest.DocTestSuite([test_sprint, test_printing])



# Generated at 2022-06-24 02:51:32.728779
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    def stub_factory(self, scope, name):
        return bzrlib
    f = ScopeReplacer(globals(), stub_factory, '_bzrlib')
    def _do_test():
        assert _bzrlib.__name__ == 'bzrlib'
    _do_test()



# Generated at 2022-06-24 02:51:40.631925
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import bzrlib.lazy_import
    scope = {}
    bzrlib.lazy_import.ImportReplacer(scope, name='foo',
        module_path=('foo',), member=None, children={})
    # Member and children cannot both be specified
    try:
        bzrlib.lazy_import.ImportReplacer(scope, name='foo',
            module_path=('foo',), member='bar', children={})
    except ValueError:
        pass
    else:
        raise AssertionError('Member and children can be specified together')

 

# Generated at 2022-06-24 02:51:52.474569
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import weakref

    class TestObj(object):
        __slots__ = ()
        def __setattr__(self, attr, val):
            object.__setattr__(self, attr, val)

    scope = {}
    test_obj = TestObj()
    replacer = ScopeReplacer(scope, lambda unused, unused2, unused3: test_obj,
        'test_obj')
    replacer.x = 1
    replacer.y = 2
    replacer.z = 3
    assert_equal(1, test_obj.x)
    assert_equal(2, test_obj.y)
    assert_equal(3, test_obj.z)
    replacer.x = 4
    replacer.y = 5
    replacer.z = 6

# Generated at 2022-06-24 02:52:00.573156
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the import processor object"""
    class ImportMap(object):

        __slots__ = ['modules', 'errors']

        def __init__(self):
            self.modules = {}
            self.errors = []

        def __setitem__(self, member, module):
            self.modules[member] = module
            return self

        def __getitem__(self, item):
            return self.modules[item]

        def set_error(self, error, details):
            self.errors.append((error, details))

    import_map = ImportMap()

    processor = ImportProcessor(lazy_import_class=import_map.__setitem__)

# Generated at 2022-06-24 02:52:12.232985
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should round-trip

    >>> x = IllegalUseOfScopeReplacer('foo', 'bar')
    >>> print(unicode(x).encode('utf8'))
    IllegalUseOfScopeReplacer object 'foo' was used incorrectly: bar
    >>> u = unicode(x)
    >>> print(type(u))
    <type 'unicode'>
    >>> y = eval(repr(x))
    >>> y == x
    True
    >>> print(type(y))
    <class 'bzrlib.lazy_import.IllegalUseOfScopeReplacer'>
    >>> b"%s" % x == b"%s" % x
    True
    >>> u"%s" % x == u"%s" % x
    True
    """


# Generated at 2022-06-24 02:52:16.208034
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib import (
        errors,
        osutils, # is a module
        )
    try:
        from bzrlib import (
            errors,
            osutils, # is a module
            )
    except TypeError as e:
        # Should get an error
        pass
    else:
        raise AssertionError('Factory did not raise error as expected.')



# Generated at 2022-06-24 02:52:21.234310
# Unit test for constructor of class ImportProcessor

# Generated at 2022-06-24 02:52:28.356705
# Unit test for function disallow_proxying
def test_disallow_proxying():
    scope = {}
    lazy_import(scope, 'from bzrlib.tests import TestCase')
    lazy_import(scope, 'import pdb') # not lazy, but will pass through unaffected
    from bzrlib.tests import TestCase
    import pdb
    disallow_proxying()
    e = TestCase.TestCase
    f = pdb.Pdb
    scope['TestCase']()
    scope['pdb']()
    # Check for identity after importing again to see if it's lazy.
    lazy_import(scope, 'from bzrlib.tests import TestCase')
    from bzrlib.tests import TestCase
    TestCase.TestCase is e
    scope['TestCase']()
    scope['pdb']()

# Generated at 2022-06-24 02:52:40.160902
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Check that ScopeReplacer is working as expected."""
    from bzrlib.tests import TestCase
    class MyTest(TestCase):
        def test_scope_replacer(self):
            # Check the constructor doesn't do anything
            scope = {}
            replacer = ScopeReplacer(scope, None, 'x')
            self.assertEqual(scope, {'x':replacer})

        def test_ScopeReplacer_resolve_once(self):
            # Check that _resolve only replaces itself once and then stops
            scope = {}
            def factory(self, scope, name):
                return name
            replacer = ScopeReplacer(scope, factory, 'x')
            self.assertEqual(replacer._resolve(), 'x')
            self.assertEqual(scope, {'x':'x'})
            self

# Generated at 2022-06-24 02:52:43.630226
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__"""
    err = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    repr(err)


# Generated at 2022-06-24 02:52:48.580576
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class ScopeReplacer_for_test(ScopeReplacer):
        __setattr__ = ScopeReplacer.__setattr__
    self = ScopeReplacer_for_test(scope={}, factory=factory, name='')
    def factory(self, scope, name): return object()
    self.instance_attribute = object()
    # if the function call raises an exception, it means the function call wasn't valid
test_ScopeReplacer___setattr__()



# Generated at 2022-06-24 02:52:58.520219
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    class Foo(IllegalUseOfScopeReplacer):
        _fmt = 'foo %(a)s'
    e = Foo('bar', 'baz', extra='quux')
    exceptions_differ = getattr(e, 'exceptions_differ', None)
    if exceptions_differ is not None:
        exceptions_differ(Foo('bar', 'baz', extra='quux'), 'foo baz: quux')
        exceptions_differ(Foo('bar', 'baz'), 'foo baz')
    else:
        assert str(e) == 'foo baz: quux'
        assert unicode(e) == unicode('foo baz: quux')

# Generated at 2022-06-24 02:53:10.515491
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Method "__eq__" of class "IllegalUseOfScopeReplacer" is tested."""
    from bzrlib.tests import TestCase
    # Definition of local subclasses for test.
    class Test3(TestCase):
        def test_eq_IllegalUseOfScopeReplacer(self):
            e1 = IllegalUseOfScopeReplacer('a', 'b')
            e2 = IllegalUseOfScopeReplacer('a', 'b')
            self.assertEqual(e1, e2)
            self.assertEqual(e2, e1)
            e1 = IllegalUseOfScopeReplacer('a', 'b', 'c')
            self.assertNotEqual(e1, e2)
            e2 = IllegalUseOfScopeReplacer('a', 'b', 'c')