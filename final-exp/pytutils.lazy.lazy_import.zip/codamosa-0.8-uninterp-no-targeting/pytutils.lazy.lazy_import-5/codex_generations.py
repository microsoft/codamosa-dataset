

# Generated at 2022-06-21 21:47:23.149865
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""
    scope = {}
    lazy_import(scope, '''
        from bzrlib import (
            foo,
            bar,
            baz,
            )
        import bzrlib.branch
        import bzrlib.transport
    ''')
    return scope



# Generated at 2022-06-21 21:47:27.883005
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import bzrlib.tests.stub_lazy_import as stub_module, \
        bzrlib.tests.stub_lazy_import2 as stub_module2

    class StubImportReplacer(ImportReplacer):
        __module__ = 'bzrlib.tests.test_lazy_import'

        def __init__(self, scope, name, module_path, member, children):
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children

    processor = ImportProcessor(StubImportReplacer)


# Generated at 2022-06-21 21:47:39.704719
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib.lazy_import
    import bzrlib.osutils
    try:
        bzrlib.lazy_import.disallow_proxying()
        bzrlib.lazy_import.lazy_reload(bzrlib.osutils)
        x = bzrlib.osutils
        # Proxy should be illegal at this point.
        try:
            bzrlib.osutils.pathjoin("foo", "bar")
        except bzrlib.lazy_import.IllegalUseOfScopeReplacer:
            pass
        else:
            raise AssertionError("pathjoin should have caused an exception")
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True



# Generated at 2022-06-21 21:47:51.636020
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    name = 'name'
    factory = lambda _, scope, name: scope[name]
    obj = ScopeReplacer(scope, factory, name)
    scope[name] = 1
    # obj is a ScopeReplacer, and the factory is not called
    eq = object.__getattribute__(obj, '__eq__')
    assert_false(eq(1))
    # obj will be replaced by 1 on use
    def f(o):
        return o
    eq = object.__getattribute__(obj, '__eq__')
    assert_true(eq(1))
    f(obj)
    assert_true(f(obj) is 1)
    assert_true(f(obj) is scope[name])
    assert_true(obj is scope[name])
    assert_true(eq(1))


# Generated at 2022-06-21 21:48:00.169822
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Method __getattribute__ of class ScopeReplacer"""
    # test constructor and getattr
    class Foo(object):
        def bar(self):
            return 'foo'
    globals = {}
    lazy_import(globals, '''
    from bzrlib import lazy_import
    import bzrlib.lazy_import
    ''')
    bzrlib.lazy_import.ScopeReplacer.__getattribute__ = \
        bzrlib.lazy_import.ScopeReplacer._resolve
    bzrlib.lazy_import.ScopeReplacer(globals, Foo, 'foo')
    use_case = foo.bar
    expected = 'foo'
    result = use_case()
    assert expected == result, (expected, result)



# Generated at 2022-06-21 21:48:08.527668
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a string representation of the exception"""
    # Smoke test for the repr protocol.
    from bzrlib.tests import TestCase
    TestCase.assertEndsWith(IllegalUseOfScopeReplacer(
        u'something',
        u'bar',
        None), "('something', 'bar', None)")
    TestCase.assertEndsWith(IllegalUseOfScopeReplacer(
        u'something',
        u'bar',
        'extra'), "('something', 'bar', 'extra')")



# Generated at 2022-06-21 21:48:17.515926
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of ScopeReplacer"""
    # Calling __setattr__ of ScopeReplacer with erroneous arguments types
    # raises TypeError.
    obj = ScopeReplacer({}, lambda self, scope, name: None, 'foo')
    args = [None]
    kwargs = random_kwargs()
    e = raises(TypeError, obj.__setattr__, *args, **kwargs)
    assert str(e.exception) == "__setattr__() takes exactly 3 arguments (2 given)"

# Generated at 2022-06-21 21:48:20.583393
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    assert e.name == 'name'
    assert e.msg == 'message'
    assert e.extra == ': extra'


# Generated at 2022-06-21 21:48:26.106153
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    # Check correct assignment
    d = {}
    def factory(replacer, scope, name):
        return 'foo'
    obj = ScopeReplacer(d, factory, 'name')
    obj._resolve()
    # Check that factory is called correctly, and that obj is correctly
    # assigned to the scope, and returned.
    assert d['name'] == 'foo'



# Generated at 2022-06-21 21:48:37.670240
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Ensure that the disallow_proxying function works as expected.
    """
    lazy_import(globals(), '''
    import bzrlib.lazy_import
    ''')

# Generated at 2022-06-21 21:48:56.448798
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import gc
    import sys
    s = {'a':1}
    b = ScopeReplacer(s, lambda self, s, name: 2, 'a')
    f = ScopeReplacer(s, lambda self, s, name: 3, 'f')
    del b
    del f
    gc.collect()
    for r in gc.get_referrers(s):
        if type(r) is dict and r is s:
            break
    else:
        raise AssertionError("Can not find dict with ScopeReplacer")
    for r in gc.get_referrers(s['a']):
        if type(r) is dict and r is s:
            break
    else:
        raise AssertionError("Can not find dict with ScopeReplacer")



# Generated at 2022-06-21 21:48:59.237451
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    iuossr = IllegalUseOfScopeReplacer(name='foo',
                                       msg='bar',
                                       extra='baz')
    from bzrlib import errors
    errors.TextReferenceFormatError('qux', baz=iuossr)



# Generated at 2022-06-21 21:49:07.482523
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This tests that IllegalUseOfScopeReplacer().__unicode__() works."""
    universal_newlines = True
    if universal_newlines:
        import sys
        if sys.platform == 'win32':
            # Make sure we're not using Windows universal newlines
            universal_newlines = False
    if universal_newlines:
        # This test uses "one line per field" and then checks for the
        # correct number of lines in the output.
        # If we're not using Windows universal newlines, then this test
        # will fail because it will be expecting one line per field,
        # and will be getting two lines per field (probably).
        fn = __file__
        file = fn.encode('utf-8')

# Generated at 2022-06-21 21:49:14.990587
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    scope = {'__name__': 'scope_name'}
    text = ("import foo.bar\n"
            "import foo.bar as bar.baz\n"
            "import foo.bar.baz as bing, (foo, bar)\n"
            "from bzrlib.foo import bar, bing\n")
    processor = ImportProcessor()
    # Check that the constructor succeeds by not raising any errors
    processor.lazy_import(scope, text)


# Generated at 2022-06-21 21:49:28.124911
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    try:
        raise IllegalUseOfScopeReplacer('bzr', 'mumble')
    except IllegalUseOfScopeReplacer as e:
        e = e
    s = str(e)
    u = unicode(e)
    r = repr(e)
    assert e.name == 'bzr'
    assert e.msg == 'mumble'
    assert 'IllegalUseOfScopeReplacer' in s
    assert 'IllegalUseOfScopeReplacer' in u
    assert 'IllegalUseOfScopeReplacer' in r
    assert 'bzr' in s
    assert 'bzr' in u
    assert 'bzr' in r
    assert 'mumble' in s
    assert 'mumble' in u
    assert 'mumble' in r
    assert type(s) is str

# Generated at 2022-06-21 21:49:41.062217
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    # We use bzrlib.tests because it is a module that exists, but is not
    # present in python's import path
    scope = {}
    name = 'bzrlib'
    module_path = [name, 'tests']
    children = {'tests':(module_path, None, {})}
    ImportReplacer(scope=scope, name=name, module_path=['bzrlib'],
                   children=children)
    # Check that importing bzrlib from this scope gives the same result
    # as importing bzrlib from sys.modules
    assert scope[name] is sys.modules[name]
    # Check that importing 'bzrlib.tests' from this scope gives the same
    # result as importing bzrlib.tests from sys.modules
    assert scope[name].tests is sys

# Generated at 2022-06-21 21:49:53.095884
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    class TestException(IllegalUseOfScopeReplacer):
        _fmt = "For your information: %(name)s, %(msg)s, %(extra)s"

# Generated at 2022-06-21 21:50:04.402130
# Unit test for function lazy_import
def test_lazy_import():
    """Unit tests for lazy_import

    :return: None
    """
    # TODO: jam 20060912 This unit test is probably insufficient.
    if __debug__:
        import bzrlib.dirstate
        from bzrlib.tests import TestCase

        class TestLazyImport(TestCase):
            """Test that lazy_import does the right thing"""

            def test_lazy_import(self):
                """Test that lazy_import does the right thing"""
                global lazy_import

                # Screw up the globals, so we can test multiple runs
                # of lazy_import
                del globals()['bzrlib']
                del globals()['bzrlib.dirstate']

                class FakeReplacer(object):
                    def __init__(self, *args):
                        self.args = args

               

# Generated at 2022-06-21 21:50:16.353644
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import ScopeReplacer
    if ScopeReplacer._should_proxy:
        try:
            ScopeReplacer._should_proxy = False
            original_setattr = setattr
            def replacing_setattr(obj, name, value):
                if name == '_name':
                    return
                return original_setattr(obj, name, value)
            setattr = replacing_setattr

            # The following should fail with IllegalUseOfScopeReplacer.
            # Don't forget to re-enable _should_proxy!
            self.assertRaises(lazy_import.IllegalUseOfScopeReplacer, lazy_import._imported_module, None, None, None)

        finally:
            Scope

# Generated at 2022-06-21 21:50:29.262352
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib
    ''')
    disallow_proxying()

# Generated at 2022-06-21 21:50:39.222728
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the architecture of ScopeReplacer objects."""
    import sys

    class Foo(object):
        pass

    scope = {}
    ScopeReplacer(scope, Foo, 'foo')
    scope['foo']



# Generated at 2022-06-21 21:50:50.721716
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__

    The method should return a string.
    """
    from StringIO import StringIO
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestSkipped
    import sys

    try:
        t = IllegalUseOfScopeReplacer('a', 'b', 'c')
    except AttributeError:
        raise TestSkipped("Error in the test IllegalUseOfScopeReplacer."
                "__repr__.  The object IllegalUseOfScopeReplacer seems to be"
                " broken.")
    class MyStream:
        def __init__(self):
            self.content = []
        def write(self, data):
            self.content.append(data)

    real_stdout = sys.stdout
    mystream = MyStream()
   

# Generated at 2022-06-21 21:50:54.565174
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    x = IllegalUseOfScopeReplacer('module', 'message')
    s = unicode(x)
    assert not isinstance(s, str)
    assert isinstance(s, unicode)

# Generated at 2022-06-21 21:51:05.078158
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """ImportProcessor.lazy_import: imports lazy modules"""
    import sys

    t = ImportProcessor()
    t.lazy_import(globals(), """
import os
from os import (
    fchmod,
    )
import foo         # on a separate line
import foo.bar.baz as bing
from foo import (
    goo as _goo,
    )
""")
    sys.modules.pop('foo', None)
    sys.modules.pop('foo.bar.baz', None)
    sys.modules.pop('foo.goo', None)
    try:
        t.foo
        raise AssertionError("module 'foo' not imported")
    except AttributeError:
        pass

# Generated at 2022-06-21 21:51:12.605364
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), "bzrlib")
    disallow_proxying()

# Generated at 2022-06-21 21:51:17.156178
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('e1', 'msg1')
    assert repr(e) == "IllegalUseOfScopeReplacer('e1', 'msg1')"



# Generated at 2022-06-21 21:51:28.310750
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import (
        lazy_import,
        )
    from bzrlib.lazy_import import (
        IllegalUseOfScopeReplacer,
        ScopeReplacer,
        )

    def get_name(lazy_obj):
        if isinstance(lazy_obj, ScopeReplacer):
            return lazy_obj._name
        else:
            return l

    class TestClass:
        def __init__(self, lazy_obj):
            self.lazy_obj = lazy_obj

        def test(self):
            name = get_name(self.lazy_obj)
            return self.lazy_obj.test()

        def proxy_test(self):
            return self.test()

    def check(should_proxy):
        ScopeReplacer._should_proxy = should_proxy
        globals

# Generated at 2022-06-21 21:51:39.504500
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test creating a ScopeReplacer"""
    # a factory that always returns foo.
    foo = object()
    def factory(self, scope, name):
        return foo

    # a reference that can be passed to ScopeReplacer
    replacer = [None]
    # create a ScopeReplacer
    def create_scope_replacer():
        replacer[0] = ScopeReplacer(locals(), factory, 'replacer')
    create_scope_replacer()
    # self is colliding with python's self
    self = replacer[0]
    # ScopeReplacer should be itself
    eq(self, replacer[0])
    # ... until it gets replaced
    eq(self._resolve(), foo)
    # then it should be replaced
    eq(self, foo)
    # and we should be able to use it

# Generated at 2022-06-21 21:51:52.099220
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    class DummyImportReplacer(object):
        """A dummy ImportReplacer for testing only"""

        __slots__ = ['replacements']

        def __init__(self, scope, name, module_path, member=None, children={}):
            self.replacements = [module_path, member, children]

    def do_test(text, expected):
        processor = ImportProcessor(DummyImportReplacer)
        processor.lazy_import({}, text)
        assert len(processor.imports) == 1
        assert processor.imports.keys()[0] == 'foo'
        assert processor.imports['foo'].replacements == expected
    do_test('import foo', ([u'foo'], None, {}))
    do_test('import foo.bar', ([u'foo', u'bar'], None, {}))

# Generated at 2022-06-21 21:51:54.763813
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import imp
    import os
    import sys
    f = open('test.py', 'w')

# Generated at 2022-06-21 21:52:12.814396
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class MyException(IllegalUseOfScopeReplacer):
        pass

    e = MyException('foo', 'message text')
    e2 = MyException('foo', 'other text')
    e3 = MyException('bar', 'message text')
    e4 = MyException('foo', 'message text', 'extra')
    e5 = MyException('foo', 'message text')
    e6 = MyException('foo', 'message text', 'extra')

    import bzrlib.tests
    bzrlib.tests.TestCase.assertIsInstance(e, IllegalUseOfScopeReplacer)
    bzrlib.tests.TestCase.assertFalse(e == 'foo')
    bzrlib.tests.TestCase.assertFalse(e == 3)
    bzrlib.tests.TestCase.assertFalse(e == e2)


# Generated at 2022-06-21 21:52:23.124708
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from unittest import TestCase
    from bzrlib.tests.test_lazy_import import test_module
    test_module.SampleClass1 = SampleClass1
    test_module.SampleClass2 = SampleClass2
    test_module.SampleClass3 = SampleClass3
    test_module.SampleClass3.static_method = staticmethod(SampleClass3.static_method)
    class test_instance(TestCase):
        def test_call(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.tests import test_lazy_import
            def factory(self, scope, name):
                return test_lazy_import.SampleClass1()
            scope = {}
            self.assertTrue(ScopeReplacer(scope, factory, 'SampleClass1') is not None)
           

# Generated at 2022-06-21 21:52:34.491719
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    from cStringIO import StringIO
    out = StringIO()
    ip = ImportProcessor()
    ip.lazy_import(globals(), """
        import bzrlib, bzrlib.foo.bar, bzrlib.foo.bar.baz as bing
        from bzrlib import bzrlib
        from bzrlib import (foo, bar)
    """)
    out.writelines(repr(globals()['bzrlib']))
    out.writelines(repr(globals()['bing']))
    out.writelines(repr(globals()['bzrlib']))
    out.writelines(repr(globals()['bar']))
    out.writelines(repr(globals()['foo']))

# Generated at 2022-06-21 21:52:39.445507
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    import bzrlib.trace
    ''')
    # If this next line raises, bzrlib.trace has not been imported
    # lazily. A plain import statement is needed.
    bzrlib.trace.note('foo')
    # Now we can disallow proxying
    disallow_proxying()
    try:
        bzrlib.trace.note('bar')
        raise AssertionError("IllegalUseOfScopeReplacer was not raised")
    except IllegalUseOfScopeReplacer:
        pass

# unit test for class ScopeReplacer

# Generated at 2022-06-21 21:52:45.636263
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Method lazy_import work correctly in class ImportProcessor"""
    text = "from foo import bar\nfrom baz import foo"
    import_processor = ImportProcessor()
    import_processor.lazy_import({}, text)
    test.TestCase.assertEqual(import_processor.imports['bar'],
                              [['foo'], 'bar', {}])
    test.TestCase.assertEqual(import_processor.imports['foo'],
                              [['baz'], 'foo', {}])


# Generated at 2022-06-21 21:52:57.284229
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ -> `IllegalUseOfScopeReplacer(s)`

    __repr__ returns a string representation of the object s.
    """
    import bzrlib.trace
    scope = {}
    bzrlib.trace._unittest_prepare()

# Generated at 2022-06-21 21:53:09.676566
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests import TestCase
    test_scope = {}
    test_name = 'foo'
    test_module_path = ['bzrlib', 'foo']
    test_member = None
    test_children = {}
    test_instance = ImportReplacer(test_scope, test_name,
        test_module_path, test_member, test_children)
    self.assertEqual(test_instance._import_replacer_children, test_children)
    self.assertEqual(test_instance._member, test_member)
    self.assertEqual(test_instance._module_path, test_module_path)
    self.assertEqual(test_instance._scope, test_scope)
    self.assertEqual(test_instance._name, test_name)

# Generated at 2022-06-21 21:53:15.008827
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    a = IllegalUseOfScopeReplacer("a", "b", "c")
    res = unicode(a)
    if isinstance(res, str):
        print("test_IllegalUseOfScopeReplacer___unicode__ failed: "
            "expected unicode, got str")

# Generated at 2022-06-21 21:53:26.488033
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test constructor behaviour for ScopeReplacer"""
    class TestClass(ScopeReplacer):
        pass
    scope = locals()
    name = 'test_instance'
    scope[name] = None
    def factory(self, scope, name):
        scope[name] = object()
        return scope[name]
    test_instance = TestClass(scope, factory, name)
    assert test_instance is scope[name]
    assert test_instance is not None
    assert test_instance() is scope[name]
    assert test_instance(1) is scope[name]
    assert test_instance(1, 2) is scope[name]
    assert test_instance(1, 2, 3) is scope[name]
    assert test_instance.attr is scope[name]
    assert test_instance.attr2 == scope[name]
    del scope

# Generated at 2022-06-21 21:53:30.484151
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a valid python string representation of the object.

    This method is used for debugging purposes.
    """
    __tracebackhide__ = True
    e1 = IllegalUseOfScopeReplacer("name", "message")
    result = repr(e1)
    expected = "IllegalUseOfScopeReplacer(name, message, '')"
    assert result == expected



# Generated at 2022-06-21 21:53:46.485712
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """test_ImportProcessor_lazy_import

    Here is a test that checks if 'foo' module was not imported because we
    requested a lazy import.

    Put it in a module named 'lazy_imports', with 'foo' module in it's
    subdirectory.

    Remember, the module is imported on the first access, so we have to
    actually access it to make sure it's imported.
    """
    # Create an ImportProcessor, and tell it to lazy import the module
    # 'foo.bar' which is located in the same directory as this file
    ip = ImportProcessor()
    ip.lazy_import(globals(), 'import foo.bar')
    # Accessing 'foo' should cause an exeption

# Generated at 2022-06-21 21:53:49.671215
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Ensure that ScopeReplacer constructs correctly."""
    def _factory(self, scope, name):
        return None
    scope = {}
    foo = ScopeReplacer(scope, _factory, 'foo')
    assert scope['foo'] == foo


# Generated at 2022-06-21 21:54:01.579124
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    class TestableScopeReplacer(ScopeReplacer):
        # _should_proxy is False to make sure we can proxy across an
        # assignment to another variable.
        _should_proxy = False
    class TestObj(object):
        def __init__(self):
            self.foo = 'foo value'
    scope = {}
    replacer = TestableScopeReplacer(
        scope, factory=lambda self, scope, name: TestObj(), name='obj')
    # The first time the ScopeReplacer is used to set an attribute, it
    # should have created a 'real' object and replaced itself in scope.
    replacer.foo = 'bar'
    self.assertEqual('bar', scope['obj'].foo)
    # Now we proxy across an assignment
    new_replacer = repl

# Generated at 2022-06-21 21:54:03.033357
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__(self, attr)"""

# Generated at 2022-06-21 21:54:11.825722
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""
    text = '''
    # import all the things
    from bzrlib import (
        foo,
        bar,
        baz
        )
    import bzrlib.branch
    import bzrlib.transport
    '''

    scope = {}
    lazy_import(scope, text)
    # bzrlib isn't loaded yet
    self.assertRaises(ImportError, scope['bzrlib'])
    # bzrlib.branch is loaded
    from bzrlib import branch
    self.assertIsInstance(scope['bzrlib.branch'], type(branch))
    # bzrlib.foo is not loaded
    self.assertRaises(ImportError, scope['bzrlib.foo'])


# TODO:

# Generated at 2022-06-21 21:54:18.356328
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    x = IllegalUseOfScopeReplacer('foo', 'msg')
    # Test constructor arguments were assigned correctly
    assert x.name == 'foo'
    assert x.msg == 'msg'
    assert x.extra == ''
    # Test that str, unicode and repr work
    assert isinstance(str(x), str)
    assert isinstance(unicode(x), unicode)
    assert isinstance(repr(x), str)


# Generated at 2022-06-21 21:54:28.301716
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import sys
    def DummyFactory(sr, scope, name):
        raise AssertionError("DummyFactory should not be called")

    def DummyFactory2(sr, scope, name):
        return sr

    try:
        sr = ScopeReplacer(sys.modules, DummyFactory, 'bzrlib')
    except AssertionError:
        pass
    else:
        raise AssertionError("DummyFactory should not be called")


# Generated at 2022-06-21 21:54:36.616624
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() -> unicode"""
    # Generate a Illegal use of ScopeReplacer exception

# Generated at 2022-06-21 21:54:45.269830
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib import lazy_import
    import sys
    import sys

    def make_foo(self, scope, name):
        class Foo(object):
            foo = 1

        return Foo

    scope = dict(sys.modules)
    lazy_import.ScopeReplacer(scope, make_foo, 'Foo')
    # If the getattr is working right, the ScopeReplacer instance 'Foo'
    # should be replaced with an object that has the 'foo' attribute.
    TestCase().assertEqual(1, scope['Foo'].foo)



# Generated at 2022-06-21 21:54:53.248570
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    args = (42,)
    kwargs = {'fums':43}
    stooges = ['larry', 'moe', 'curly']
    s = ScopeReplacer(stooges, lambda o,s,n: o, 'curly')
    s.__setattr__('stooge', 'curly')
    s.__setattr__('age', 42)
    s.__setattr__('hair', 'black')
    s.__setattr__('friend', 'moe')
    s.__setattr__('args', args)
    s.__setattr__('kwargs', kwargs)
    assert s.stooge == 'curly'
    assert s.age == 42
    assert s.hair == 'black'
    assert s.friend == 'moe'
    assert s.args

# Generated at 2022-06-21 21:55:15.447001
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    global module_path_foo, module_path_foo_bar

    def assertImport(scope, import_text, name, expected_module_path,
                     expected_select_member=None, expected_children={}):
        ip = ImportProcessor()
        ip.lazy_import(scope, import_text)
        scope_info = scope[name]
        module_path = scope_info._module_path
        select_member = scope_info._member
        children = scope_info._import_replacer_children
        if not isinstance(scope_info, ImportReplacer):
            raise AssertionError('not an ImportReplacer: %r' % scope_info)

# Generated at 2022-06-21 21:55:20.142313
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    for args in [('a', 'b'), ('c', 'd', 'e')]:
        err = IllegalUseOfScopeReplacer(*args)
        assert ''.join(repr(err).split()[1:]) == '%s(*%s)' % (
            err.__class__.__name__, str(args))


# Generated at 2022-06-21 21:55:31.733765
# Unit test for function lazy_import
def test_lazy_import():
    text = '''
    from bzrlib import (
        foo,
        bar,
        baz
        )
    import bzrlib.branch
    from bzrlib.transport import get_transport
    from bzrlib.transport import get_transport as get_transport_fn
    import bzrlib.transport as bzrlib_transport
    '''
    d = {}
    lazy_import(d, text)

    # Now verify that the imports were set up correctly
    # First lets see what we can see

# Generated at 2022-06-21 21:55:39.674509
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # This method's implementation is in this file because
    # of avoid-circular-import-problem.
    # Check that IllegalUseOfScopeReplacer (see above) defines a working
    # __unicode__.
    # We assume that the exception is raised in the _get_format_string method.
    def raise_in_format_string():
        import sys
        # Althout 'msg' is non-unicode, it is passed as a unicode string in
        # the constructor.
        # This does not break things because 'msg' is passed directly to
        # _format() as a unicode string.
        msg = 'non unicode msg'
        exc = IllegalUseOfScopeReplacer('f', msg, 'bill')

# Generated at 2022-06-21 21:55:51.635546
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class MyImportReplacer(ImportReplacer):
        def __init__(self, scope, name, module_path, member=None,
                     children={}):
            ImportReplacer.__init__(self, scope, name, module_path,
                                    member=member, children=children)
            self.attributes = []

        def _import(self, module_name):
            self.attributes = dir(module_name)
            return module_name

    scope = {}
    MyImportReplacer(scope, 'bzrlib', ['bzrlib'],
                            children={'foo': (['bzrlib', 'foo'], None,
                                              {'bar':(['bzrlib', 'foo', 'bar'],
                                                      None, {})})
                                      })

# Generated at 2022-06-21 21:55:56.623250
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import bzrlib.lazy_import
    r = bzrlib.lazy_import.IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(r)
    if not isinstance(u, unicode):
        raise AssertionError("unicode returned %r" % u)


# Generated at 2022-06-21 21:56:03.564212
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor."""
    from mock import Mock
    my_class = Mock()
    my_processor = ImportProcessor(my_class)
    try:
        my_processor.lazy_import({}, 'import foo')
    except: # e.g. Exception
        assert False, 'lazy_import() failed.'
    # my_class.assert_called_with({}, name='foo', module_path=['foo'],
    #                         member=None, children={})
    # TODO: jam 20060912 We cannot test this, until we can mock
    #       ImportReplacer to be able to check its parameters.
    #       See bug #85896
    #assert my_class.call_count == 1



# Generated at 2022-06-21 21:56:10.123241
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import copy
    # prepare arguments
    self = None
    attr = None
    value = None
    # execution
    e = None
    try:
        ScopeReplacer.__setattr__(self, attr, value)
    except Exception as _e:
        e = _e
    # verification
    assert str(e) == "Object already replaced, did you assign it to another variable?"





# Generated at 2022-06-21 21:56:21.034799
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the ImportProcessor class"""
    p = ImportProcessor()
    p.imports = {}
    # Test some regular import lines
    p._build_map('import foo')
    p._build_map('import bar, baz')
    p._build_map('import foo.bar, foo.baz')
    # Test some 'import foo as bar' lines
    p._build_map('import foo as bar')
    p._build_map('import foo.bar as baz')
    p._build_map('import bar as baz, baz as bing')
    p._build_map('import foo.bar as baz, foo.baz as bing')
    # Test some 'from foo import bar' lines
    p._build_map('from foo import bar')

# Generated at 2022-06-21 21:56:29.398576
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class SampleScopeReplacer(ScopeReplacer):
        __slots__ = ()

    class SampleClass(object):
        __slots__ = ()

        def __call__(self, x, y=None):
            return (self, x, y)

    scope = {'SampleClass': SampleClass}
    sr = SampleScopeReplacer(scope, lambda s, scope, name: scope[name], 'SampleClass')
    (sr_result, x_result, y_result) = sr(2, y=4)
    assert (sr_result, x_result, y_result) == (sr, 2, 4), (sr_result, x_result, y_result)


# Generated at 2022-06-21 21:56:49.867591
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    global_scope = {}
    class DummyClass:
        def dummy_method(self, arg1):
            return arg1
    dummy_class = DummyClass()
    lazy_import(global_scope, 'dummy_class')
    assert global_scope['dummy_class'] is dummy_class


# Generated at 2022-06-21 21:57:00.025994
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    lm = bzrlib.lazy_import.ImportProcessor()
    #import foo 
    lm.lazy_import(globals(), "import foo")
    #from foo import bar
    lm.lazy_import(globals(), "from foo import bar")
    #import foo.bar.baz as bing
    lm.lazy_import(globals(), "import foo.bar.baz as bing")
    #from foo import bar, baz
    try:
        lm.lazy_import(globals(), "from foo import bar, baz")
    except errors.ImportNameCollision:
        pass
    #from foo import bar as baz, baz
    lm.lazy_import(globals(), "from foo import bar as baz")
    #from foo