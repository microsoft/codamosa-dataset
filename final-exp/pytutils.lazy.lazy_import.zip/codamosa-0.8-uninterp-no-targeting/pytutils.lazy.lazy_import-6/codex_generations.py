

# Generated at 2022-06-21 21:47:24.342047
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Testing method __getattribute__ of class ScopeReplacer"""
    import sys
    import weakref
    import gc

    def scope_replacer_factory(self, scope, name):
        return scope
    scope = weakref.WeakKeyDictionary()
    scope['ScopeReplacer'] = ScopeReplacer
    scope['scope_replacer_factory'] = scope_replacer_factory
    scope['sys'] = sys
    scope['gc'] = gc
    scope['gc.collect'] = gc.collect
    scope['gc.enable'] = gc.enable
    scope['gc.disable'] = gc.disable
    scope['gc.isenabled'] = gc.isenabled
    scope['gc.set_debug'] = gc.set_debug
    scope['gc.get_debug'] = gc.get_debug


# Generated at 2022-06-21 21:47:37.059127
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import StringIO
    from bzrlib import lazy_import

    def factory(self, scope, name):
        raise AssertionError('factory should not be called!')

    def run_setattr_test(obj, name, attr, value, expected_exception=None):
        """Set an attribute on ``obj``, expecting an exception"""
        # Ensure the expected exception is actually raised
        if expected_exception:
            exc = expected_exception
        else:
            exc = None
        try:
            setattr(obj, attr, value)
        except exc:
            pass

# Generated at 2022-06-21 21:47:45.852703
# Unit test for function lazy_import
def test_lazy_import():
    """Unit tests for the 'lazy_import' function"""
    scope = {}
    lazy_import(scope, 'import bzrlib.foo')
    scope['bzrlib'].__class__.__name__ == 'ImportReplacer'

    scope = {}
    lazy_import(scope, 'from bzrlib import foo')
    scope['foo'].__class__.__name__ == 'ImportReplacer'

    scope = {}
    lazy_import(scope, 'from bzrlib import (foo, bar, baz)')
    scope['foo'].__class__.__name__ == 'ImportReplacer'
    scope['bar'].__class__.__name__ == 'ImportReplacer'
    scope['baz'].__class__.__name__ == 'ImportReplacer'



# Generated at 2022-06-21 21:47:48.860650
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ of exception IllegalUseOfScopeReplacer"""
    name = "find_on_path"
    msg = "value was replaced by a module"
    ex = IllegalUseOfScopeReplacer(name, msg, extra="extra info")
    assert(str(ex) == "ScopeReplacer object 'find_on_path' "
           "was used incorrectly: value was replaced by a module: extra info")



# Generated at 2022-06-21 21:47:56.709449
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    disallow_proxying()
    # Use the variables in a way that will exercise their lazy loading,
    # so that we can test that disallow_proxying() has an effect.
    b = branch.Branch.open('')
    e = errors.BzrError()
    import bzrlib
    class MyError(bzrlib.errors.BzrError):
        """Dummy class."""
        pass
# end test_disallow_proxying



# Generated at 2022-06-21 21:48:00.822945
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg')"

# Generated at 2022-06-21 21:48:12.588876
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib.trace
    bzrlib.trace.mutter_callsite = bzrlib.trace.mutter

    def test_bad_setattr():
        scope = {}
        lazy_import(scope, '''
            import bzrlib.trace
        ''')

# Generated at 2022-06-21 21:48:24.994399
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Unit test for method __getattribute__ of class ScopeReplacer."""
    # Unit test for method __getattribute__ of class ScopeReplacer
    # If you to do x = y, setting this to False will disallow access to
    # members from the second variable (i.e. x). This should normally
    # be enabled for reasons of thread safety and documentation, but
    # will be disabled during the selftest command to check for abuse.
    # _should_proxy = True
    class ScopeReplacer(ScopeReplacer):
        """A lazy object that will replace itself in the appropriate scope.

        This object sits, ready to create the real object the first time it is
        needed.
        """
        def __init__(self, scope, factory, name):
            object.__setattr__(self, "_scope", scope)
            object.__set

# Generated at 2022-06-21 21:48:36.712062
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test function disallow_proxying."""
    from bzrlib.lazy_import import lazy_import
    from bzrlib import osutils
    # Use a specific name to ensure that the same name is in both scopes.
    lazy_import(globals(), 'from bzrlib import (osutils)')
    lazy_import(globals(), 'import bzrlib')
    # Check osutils is used as a proxy
    disallow_proxying()
    # Check osutils is used as a proxy
    osutils.pathjoin('a', 'b')
    # Check bzrlib is used as a proxy
    bzrlib.osutils.pathjoin('a', 'b')
    # Importing osutils again should cause an exception

# Generated at 2022-06-21 21:48:46.623121
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def func():
        raise AssertionError("Incorrect call. args=%r kwargs=%r" % (
            (1,2), {'a':3, 'b':4}))
    def generator():
        yield 0
    def result():
        return 5

    # This is a bit clumsy, but it's the only way to tell if __call__ was
    # called on a ScopeReplacer
    mod = {}
    sr = ScopeReplacer(mod, func, 'foo')
    try:
        # In some cases, __call__ is only called to see if it exists.
        # Check that we don't have any false positives.
        mod['foo']()
    except AssertionError:
        raise tests.TestSkipped("expose a problem in python's inspect")
    # The real test

# Generated at 2022-06-21 21:49:06.565560
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the base class, ImportProcessor"""
    processor = ImportProcessor()
    lines = ('import foo, bar, baz as bling',
             'from  me_and_you import you ')
    processor.lazy_import(globals(), '\n'.join(lines))
    # Now the lines should have been imported into a set of lazy
    # import objects
    for line in lines:
        if not line.startswith('import '):
            if not line.startswith('from '):
                raise ValueError(line)
            from_module = line[len('from '):]
            from_module = from_module.split(' import ')[0]
            from_module_path = from_module.split('.')
            # Make sure the module has been imported

# Generated at 2022-06-21 21:49:13.261710
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class Foo(IllegalUseOfScopeReplacer):
        _fmt = "foo"
    a = Foo("bar", "foo")
    b = Foo("bar", "foo")
    c = Foo("baz", "foo")
    assert a == b
    assert not (a != b)
    assert a != c
    assert not (a == c)



# Generated at 2022-06-21 21:49:17.294638
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    e3 = IllegalUseOfScopeReplacer('foo1', 'bar')
    assert e1 == e2
    assert e2 != e3



# Generated at 2022-06-21 21:49:28.672292
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Unit tests for ImportReplacer constructor"""

    module_path = ['bzrlib', 'foo', 'bar']
    for member in [None, 'boring', 'really']:
        for children in [{}, {'foo':(['bzrlib', 'foo'], None, {})}]:
            replacer = ImportReplacer(scope={}, name='lavender',
                                      module_path=module_path,
                                      member=member, children=children)
            assert(replacer._import_replacer_children == children)
            assert(replacer._member == member)
            assert(replacer._module_path == module_path)


# Generated at 2022-06-21 21:49:35.185175
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Make sure __unicode__ raises no exception.

    Make sure __unicode__ does not create circular references.
    """
    # Make sure unicode(IllegalUseOfScopeReplacer('a', 'b')) does not raise
    # an exception
    unicode(IllegalUseOfScopeReplacer('a', 'b'))



# Generated at 2022-06-21 21:49:37.171698
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer(u'x', u'y')
    isinstance(e.__unicode__(), unicode)

# Generated at 2022-06-21 21:49:38.311301
# Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-21 21:49:45.304366
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that ImportReplacer works as expected"""
    # Modules that we will pretend we have already imported
    class MockModule1(object):
        pass

    class MockModule2(object):
        pass

    # A mock module which has a member already imported.
    class MockModule3(object):
        bar = MockModule2
    # A mock module which has children
    class MockModule4(object):
        bar = MockModule1

    # A mock module which has children and is also part of a larger import.
    class MockModule5(ImportReplacer):
        baz = MockModule1
    # An even more complex example.
    class MockModule6(ImportReplacer):
        class MockModule7(object):
            bar = MockModule1
    # A mock module
    class MockModule8(object):
        pass

    # Test situation where

# Generated at 2022-06-21 21:49:56.672571
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    caller = ScopeReplacer
    object.__setattr__(caller, '_resolve', lambda self:eval('lambda x, y: x * y'))
    caller._resolve.im_func.func_globals['__builtins__'] = __builtins__
    caller._resolve.im_func.func_globals['__name__'] = 'eval'
    caller._resolve.im_func.func_globals['__doc__'] = None
    caller._resolve.im_func.func_globals['__package__'] = None
    object.__setattr__(caller, '_real_obj', None)

# Generated at 2022-06-21 21:49:59.589110
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Test method IllegalUseOfScopeReplacer.__repr__"""
    instance = IllegalUseOfScopeReplacer(
        name='b', msg='c', extra=None)
    expected = "IllegalUseOfScopeReplacer('b', 'c')"
    assert repr(instance) == expected, \
        "Expected %s, got %s" % (expected, repr(instance))

# Generated at 2022-06-21 21:50:13.093350
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    p=ImportProcessor()
    assert p.imports == {}

    p=ImportProcessor(ImportReplacer)
    assert p.imports == {}
    assert p._lazy_import_class == ImportReplacer



# Generated at 2022-06-21 21:50:20.103272
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Ensure the constructor for ScopeReplacer works correctly."""
    # This test is designed to run before the selftest
    # command sets _should_proxy to False.
    # ScopeReplacer.__init__() sets the variable
    # to the StateReplacer object, so we check that
    # it is not a ScopeReplacer object (i.e. has not
    # been replaced yet).
    some_scope = {}
    def obj_factory(self, scope, name):
        return self
    name = None
    obj = ScopeReplacer(some_scope, obj_factory, name)
    # Will raise exception if obj is a ScopeReplacer
    # object.
    obj(False)



# Generated at 2022-06-21 21:50:26.176490
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    def factory(self, scope, name):
        return 42
    scope = {}
    replacer = ScopeReplacer(scope, factory, 'foo')
    assert not scope.keys()
    # Check that we can trigger the factory to run
    assert replacer._resolve() is 42
    assert scope.keys() == ['foo']
    assert scope['foo'] is 42


# Generated at 2022-06-21 21:50:28.820117
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import doctest
    doctest.run_docstring_examples(IllegalUseOfScopeReplacer, globals())


# Generated at 2022-06-21 21:50:31.231601
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that ImportProcessor's constructor works."""
    import_processor = ImportProcessor()
    assert isinstance(import_processor, ImportProcessor)



# Generated at 2022-06-21 21:50:35.328035
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    error = IllegalUseOfScopeReplacer(
        "name", "msg", extra="extra")
    assert repr(error) == ("IllegalUseOfScopeReplacer('ScopeReplacer object "
        "name was used incorrectly: msg: extra',)")

# Generated at 2022-06-21 21:50:48.447847
# Unit test for function lazy_import
def test_lazy_import():
    def get_foo(scope):
        return scope['foo']
    class Foo(object):
        pass
    foo_object = Foo()
    scope = {}
    assert not scope
    lazy_import(scope, 'import foo')
    scope['foo'] = foo_object
    assert get_foo(scope) is foo_object
    lazy_import(scope, 'from foo import bar')
    scope['foo'].bar = foo_object
    assert scope['bar'] is foo_object
    lazy_import(scope, 'from foo import baz as quux')
    scope['foo'].baz = foo_object
    assert scope['quux'] is foo_object
    lazy_import(scope, '''
    from foo import (
        bar,
        baz as quux,
        )
    ''')

# Generated at 2022-06-21 21:50:59.821563
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib.tests import TestCase
    class Test(TestCase):

        def test_constructor(self):
            # Test the construction of IllegalUseOfScopeReplacer
            # objects
            e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
            self.assertEqual(
                unicode(e),
                u"ScopeReplacer object 'name' was used incorrectly:"
                u" msg: extra")
            self.assertEqual(
                str(e),
                "ScopeReplacer object 'name' was used incorrectly:"
                " msg: extra")
            self.assertEqual(
                repr(e),
                "IllegalUseOfScopeReplacer("
                "'ScopeReplacer object \'name\' was used incorrectly:"
                " msg: extra')")
    return Test



# Generated at 2022-06-21 21:51:05.886518
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase

    class TestDisallowProxying(TestCase):

        def test_disallow_proxying(self):
            class TestException(Exception):
                pass

            def factory(self, scope, name):
                scope[name] = 42
                return 42

            scope = {'test': ScopeReplacer(scope, factory, 'test')}

            disallow_proxying()
            self.assertRaises(IllegalUseOfScopeReplacer, scope['test']._resolve)
            self.expectFailure('Raise IllegalUseOfScopeReplacer if proxy'
                               'is used after initialisation',
                               self.assertEqual, scope['test'], 42)

    # FIXME: Maybe we can do it without having to import this module?

# Generated at 2022-06-21 21:51:18.032041
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_text = """ \
    import foo # As comment
    # another comment
    # another comment
    import foo, bar.baz, # As comment
    quux # As comment

    # another comment
    import foo # As comment

    # another comment
    from foo import bar # As comment

    # another comment
    from foo import bar as baz, quux # As comment
    """
    import_text_canonicalized = """ \
    import foo
    import foo
    import bar.baz
    import quux

    import foo

    from foo import bar

    from foo import bar
    from foo import quux"""
    processor = ImportProcessor()
    assert import_text_canonicalized == '\n'.join(processor._canonicalize_import_text(import_text))


# Generated at 2022-06-21 21:51:33.603239
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test importing something"""
    import sys
    import bzrlib.lazy_import
    scope = {}
    ImportReplacer(scope, 'foo', ['bzrlib', 'lazy_import'])
    try:
        scope['foo'].ImportReplacer
    except KeyError:
        raise AssertionError(
            "ImportReplacer not found in scope"
            " after lazy_import.ImportReplacer was used")



# Generated at 2022-06-21 21:51:42.469350
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    #  This test passes, but cannot be run because ScopeReplacer does not play
    #  well with the testbed.
    #  Instead, run this test as part of the lazy_import_test.py module.
    return
    class Foo(ScopeReplacer):
        def __init__(self):
            self.bar = 42

    import sys
    sys.modules['blibber'] = Foo()
    from blibber import bar
    from bzrlib.tests import warn
    warn('bar')

# Generated at 2022-06-21 21:51:47.147009
# Unit test for function lazy_import
def test_lazy_import():
    """Test for function lazy_import"""
    # Work out a module which should be importable.
    import bzrlib
    import os
    lazy_module = os.path.dirname(os.path.dirname(bzrlib.__file__))
    # Ensure it is not in sys.path
    if lazy_module in sys.path:
        raise AssertionError('%r is already in sys.path' % (lazy_module,))
    # Create a new module with a name that will be importable.
    new_module_name = os.path.basename(lazy_module)
    # Create a new module with a name that will be importable.
    new_module = types.ModuleType(new_module_name, new_module_name)
    new_module.__file__ = os.path.join

# Generated at 2022-06-21 21:51:54.803016
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    module_name = __name__
    if not module_name.startswith('bzrlib.'):
        # This test would be meaningless if not testing a bzrlib module.
        # Luckily, it's easy to spot.
        raise AssertionError(
            '%s.test_disallow_proxying would be meaningless' % __name__)

    # We need to verify that imported modules are lazily imported
    # but we can't do that directly because of the risk of cyclic
    # imports so we use a test module in a different package
    # to avoid that risk.

# Generated at 2022-06-21 21:52:06.322103
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor"""
    scope = {}

    # create ImportProcessor object
    import_processor = ImportProcessor()

    # test the function lazy_import() with canonical import
    # statement
    import_processor.lazy_import(scope, """
        import token, tokenize
        """)

    # convert the string to a list
    list_1 = [
        'token',
        'tokenize',
    ]

    # convert the string to a list
    list_2 = [
        'token',
        'tokenize',
    ]

    # compare the both lists
    eq(list_1, list_2)

    # test the function lazy_import() with non canonical import
    # statement
    import_processor.lazy_import(scope, """
        import token, tokenize,
        """)

# Generated at 2022-06-21 21:52:13.897890
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class CustomException(Exception):
        pass

    class ScopeReplacerTest(object):
        def __init__(self, scope, factory, name):
            if factory is not self._factory:
                raise CustomException('invalid factory received')
            if name != 'test_obj':
                raise CustomException('invalid name received')
            if scope is not locals():
                raise CustomException('invalid scope received')
            scope[name] = self
            scope[name].test_var = 1
        def _factory(self, scope, name):
            return self
        def __getattribute__(self, attr):
            if attr == 'test_var':
                raise CustomException('Accessing test_var is forbidden')
            return object.__getattribute__(self, attr)


# Generated at 2022-06-21 21:52:23.512073
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import os
    import sys

    class TestScopeReplacer__call__(TestCase):
        def test_simple_call(self):
            import os
            import sys
            scope = {}
            def factory(bogus, scope, name):
                return os.getcwd()
            lazy_os = ScopeReplacer(scope, factory, 'os')
            dirname = lazy_os()
            expected_call = os.getcwd()
            self.assertEqual(dirname, expected_call)

    test_suite = TestSuite()
    test_loader = TestLoader()
    tests = test_loader.loadTestsFromTestCase(TestScopeReplacer__call__)
    test_suite.addTests(tests)
    return test_suite


# Unit

# Generated at 2022-06-21 21:52:33.874041
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ of IllegalUseOfScopeReplacer"""
    # Raw data
    name = 'simple'
    msg = 'test message'
    extra = 'test extra message'
    # Check exception creation
    exc = IllegalUseOfScopeReplacer(name, msg, extra)
    # Check optionals
    exc = IllegalUseOfScopeReplacer(name, msg)
    # Check exception comparison
    exc1 = IllegalUseOfScopeReplacer(name, msg)
    exc2 = IllegalUseOfScopeReplacer(name, msg)
    eq_(exc1, exc2)
    eq_(exc, exc2)
    ne_(exc1, exc)
    ne_(exc, msg)
    eq_(exc, exc)
    # Check if exception can be pickled
    eq_(exc, pickle.loads(pickle.dumps(exc)))




# Generated at 2022-06-21 21:52:45.782461
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # This function tests method __call__ of class ScopeReplacer
    #
    # Ensure that __call__ works on a normal object
    class myint(int):
        called = 0
        def __call__(self, v):
            myint.called += 1
            return v + self
    i = myint(5)
    assert i(1) == 6
    assert myint.called == 1
    # Ensure that __call__ works on a ScopeReplacer
    scope = {}
    factory = lambda sr,scope,name: myint(5)
    sr = ScopeReplacer(scope, factory, 'i')
    assert sr(1) == 6
    assert myint.called == 2
    # Ensure that __call__ works on a ScopeReplacer that has been resolved
    sr = ScopeReplacer(scope, factory, 'i')
    r

# Generated at 2022-06-21 21:52:57.409228
# Unit test for function lazy_import
def test_lazy_import():
    try:
        from breezy.tests.import_map import (
            lazy_import_class,
            imported_module,
            imported_module_module,
            imported_module_module_a,
            imported_module_module_b,
            )
    except ImportError:
        raise TestSkipped('This test needs a breezy.tests.import_map')

    global imported_module_module_a
    global imported_module_module_b

    # A hack to force the module to be imported
    imported_module_module_a
    imported_module_module_b
    scope = globals()
    scope['imported_module'].__module__ = 'real_imported_module'
    scope['imported_module_module'].__module__ = 'real_imported_module_module'

# Generated at 2022-06-21 21:53:10.944882
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    class Foo(IllegalUseOfScopeReplacer):
        _fmt = "Foo"
    assert (str(Foo(5, 'a')) ==
            "Foo object 5 was used incorrectly: a")
    assert (str(Foo('hello', 'b', extra='c')) ==
            "Foo object 'hello' was used incorrectly: b: c")


# Generated at 2022-06-21 21:53:22.465708
# Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-21 21:53:25.849648
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer."""
    # Test method is really tested by test_get_lazy_import_scope_not_dict
    # but here to make pylint quiet we override the classmethod.
    class TestException(IllegalUseOfScopeReplacer):
        pass
    assert TestException('msg', 'fmt') == TestException('msg', 'fmt')
    return



# Generated at 2022-06-21 21:53:33.005457
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(ScopeReplacer):
        # Since ScopeReplacer is a new-style class, we need a new-style subclass
        # for the super tests to work correctly
        pass

    def _helper(self, scope, name):
        scope.name = 'my name'
        return scope.name

    class TestableTestCase(TestCase):

        class _TestableTestCase(object):
            # Mocking a namespace
            name = None
            def _init_(self):
                self.name = None

        def test_proxy_case(self):
            # Checking that we can proxy something
            scope = self._TestableTestCase()
            sr = TestScopeReplacer(scope, _helper, 'name')
            self.assertNotEqual(sr, scope.name)

# Generated at 2022-06-21 21:53:44.120822
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method '__str__' of class 'IllegalUseOfScopeReplacer'"""
    import os
    import cStringIO

    def run_test(self, expect_lines, expect_encoding):
        """Run a single test"""
        # create a StringIO object to capture stdout and stderr
        stream = cStringIO.StringIO()
        sys_stdout = sys.stdout

# Generated at 2022-06-21 21:53:49.586813
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib.errors
    from bzrlib.lazy_import import lazy_import

    disallow_proxying()
    lazy_import(globals(), '''
    from bzrlib import errors
    ''')
    try:
        errors.BzrError()
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Access to global "errors" should not be allowed')



# Generated at 2022-06-21 21:54:01.525314
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Unit test for method lazy_import of class ImportProcessor"""
    processor = ImportProcessor()
    import_str = """
        import foo.bar, foo.baz as bing
        from foo import bar, baz as buzz
        from foo.bar import bing
        """
    expected_imports = {
        'foo': (['foo'], None,
            {'bar': (['foo', 'bar'], None, {}),
             'baz': (['foo', 'baz'], 'bing', {})}),
        'bar': (['foo'], 'bar', {}),
        'baz': (['foo'], 'buzz', {}),
        'bing': (['foo', 'bar'], 'bing', {})
        }

# Generated at 2022-06-21 21:54:07.400927
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a string containing the exception type and
    a unicode string.
    """
    import re
    import bzrlib
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    assert isinstance(repr(IllegalUseOfScopeReplacer(None, None)), str)
    assert re.match(r"^<bzrlib.lazy_import.IllegalUseOfScopeReplacer object at 0x[0-9a-fA-F]+>$",
                    repr(IllegalUseOfScopeReplacer(u"\u0644\u0627", u"\u0644\u0627")))


# Generated at 2022-06-21 21:54:14.021487
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        def bar(self):
            return 'foo'
    # Test that getting an attribute does not cause a C stack overflow
    globals = {}
    def foo_factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(globals, foo_factory, 'foo')
    assert_equal(replacer.bar(), 'foo')



# Generated at 2022-06-21 21:54:18.560136
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    assert str(e) == 'IllegalUseOfScopeReplacer object \'foo\' was used incorrectly: msg: extra'
    assert repr(e) == "IllegalUseOfScopeReplacer('foo', 'msg', 'extra')"



# Generated at 2022-06-21 21:54:29.366778
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
  import functools
  import sys
  class _MockModule(object):
    def __init__(self, *args, **kwargs):
      self.__callbacks = []
      for cb in args:
        cb()
      for cb in kwargs.values():
        cb()
      return None
    def __getattr__(self, attr):
      return functools.partial(self.__callbacks.append, attr)
    def __call__(self, *args, **kwargs):
      for cb in args:
        cb()
      for cb in kwargs.values():
        cb()
    def test(self):
      return self
  def _test_factory(self, scope, name):
    if name == 'bzrlib':
      return _M

# Generated at 2022-06-21 21:54:41.286474
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the methods of the class ScopeReplacer.

    Note: This unit test does not use the standard unittest framework,
    but is executed using run_tests.
    """
    import testtools

    class MyClass_ScopeReplacer(object):
        def __init__(self):
            self.value = 1
        def __getattribute__(self, attr):
            if attr == 'value':
                return object.__getattribute__(self, attr)
            else:
                obj = object.__getattribute__(self, '_resolve')()
                return getattr(obj, attr)
        def __call__(self, *args, **kwargs):
            obj = object.__getattribute__(self, '_resolve')()
            return obj(*args, **kwargs)


# Generated at 2022-06-21 21:54:50.453930
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that all the permutations for constructing an ImportReplacer are
    handled correctly"""
    def assert_raises(error_type, func, *args):
        try:
            func(*args)
        except error_type:
            pass
        else:
            raise AssertionError("Expected %r, got none" %
                (error_type,))

    scope = {}

    # 'member' and 'children' cannot both be supplied
    assert_raises(ValueError, ImportReplacer, scope, 'foo', 'foo', 'bar',
                  {'baz':(['foo', 'baz'], None, {})})

    # Test a simple module import.
    ImportReplacer(scope, 'foo', 'foo')
    assert scope['foo']._import_replacer_children == {}

# Generated at 2022-06-21 21:54:58.068492
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer class directly"""
    from bzrlib.tests import TestCase

    class TestImportReplacer(TestCase):
        def test_import_replacer(self):
            # Test that we have all the needed __slots__
            # '_import_replacer_children' is tested separately
            self.assertEquals(ImportReplacer.__slots__,
                ('_scope', '_factory', '_name', '_real_obj',
                 '_import_replacer_children', '_member', '_module_path'))

            global test_import_replacer_scope
            test_import_replacer_scope = {}
            ImportReplacer(test_import_replacer_scope, 'a', 'a')

# Generated at 2022-06-21 21:55:04.035612
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test that IllegalUseOfScopeReplacer is equal to itself"""
    def check_equal(**kwargs):
        """Check that two exceptions are equal"""
        from bzrlib.lazy_import import IllegalUseOfScopeReplacer
        a = IllegalUseOfScopeReplacer('name1', 'msg1', extra='extra1')
        b = IllegalUseOfScopeReplacer('name1', 'msg1', extra='extra1')
        for k,v in kwargs.items():
            setattr(a, k, v)
            setattr(b, k, v)
        if a != b:
            raise AssertionError('%r != %r' % (a, b))
        if a is not b:
            raise AssertionError('a is not b', a, b)

    # Check that the default attributes are equal


# Generated at 2022-06-21 21:55:09.991134
# Unit test for function lazy_import
def test_lazy_import():

    scope = {}
    text = '''from bzrlib import (
                foo,
                bar,
                baz,
                )
            import bzrlib.branch
            import bzrlib.transport
            from bzrlib.transport import (
                connect_ssh,
                )
            from bzrlib.errors import (
                FooBarBaz,
                )'''
    lazy_import(scope, text)

    # Now scope should contain entries for
    # bzrlib, foo, bar, baz, branch, transport, connect_ssh
    # They should all have the right module path
    # They should all be ImportReplacer objects
    # Branch and Transport should be proxies
    # FooBarBaz (and the other errors) should be bogus
    # The children of the bzrlib object should be

# Generated at 2022-06-21 21:55:15.066888
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    err = IllegalUseOfScopeReplacer(
        'name', msg='error message', extra='for the extra data')
    err2 = eval(repr(err))
    assert err == err2
    assert repr(err) == repr(err2)
    assert str(err) == str(err2)



# Generated at 2022-06-21 21:55:17.288612
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    ScopeReplacer(scope, lambda s, scope, name: scope, "name")
    assert scope["name"] is scope



# Generated at 2022-06-21 21:55:25.209569
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    # __str__ should return a str object.
    try:
        raise IllegalUseOfScopeReplacer('name', 'message')
    except IllegalUseOfScopeReplacer as e:
        s = str(e)
        u = unicode(e)
        assert isinstance(s, str)
        assert isinstance(u, unicode)


# Generated at 2022-06-21 21:55:29.138665
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() works.
    """
    from bzrlib import lazy_import
    s = unicode(lazy_import.IllegalUseOfScopeReplacer('foo', 'bar'))
    assert s.__class__ is unicode


# Generated at 2022-06-21 21:55:43.161923
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor"""
    importer = ImportProcessor()
    test_map = importer.imports
    if not isinstance(test_map, dict):
        raise AssertionError
    if test_map:
        raise AssertionError
    test_text = "import foo, bar\n"
    importer.lazy_import({}, test_text)
    test_map = importer.imports
    if not (test_map == {'foo':([], None, {}), 'bar':([], None, {})}):
        raise AssertionError


# Generated at 2022-06-21 21:55:46.119764
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    s = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert repr(s) == 'IllegalUseOfScopeReplacer(name msg extra)'

# Generated at 2022-06-21 21:55:47.982047
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.lazy_import_test import TestLazyImport
    from bzrlib.tests.test_lazy_import import TestScopeReplacer___setattr__ as test_suite
    run_test_suite(test_suite, TestLazyImport)


# Generated at 2022-06-21 21:55:59.162667
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Use a dict for 'scope' so we can verify the results
    scope = {}
    # 'from foo import bar'
    ImportReplacer(scope, name='bar', member='bar',
                   module_path=['foo'])
    # 'from foo import bar as baz'
    ImportReplacer(scope, name='baz', member='bar',
                   module_path=['foo'])
    # 'from foo import bar as baz, zot'
    ImportReplacer(scope, name='baz', member='bar',
                   module_path=['foo'])
    ImportReplacer(scope, name='zot', module_path=['foo'],
                   children={'zot':(['foo', 'zot'], None, {})})
    # 'import foo.bar'

# Generated at 2022-06-21 21:56:11.170353
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    text = '''
        import foo
        import foo.bar as bing
        import foo.bar.baz, foo.bing.baz
        from foo.bar import bar as barry
        from foo.bar.baz import (baz,
                                 bing)
        '''
    mp = ImportProcessor()
    mp.lazy_import(globals(), text)

    # Now lets make sure the results are correct.
    for name in ['foo', 'bing', 'bar', 'barry']:
        globals()[name]
    for name in ['foo.bar.baz', 'foo.bing.baz', 'foo.bar.baz.baz',
                 'foo.bar.baz.bing']:
        getattr(foo, name)



# Generated at 2022-06-21 21:56:21.835811
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() works OK

    This test is designed to ensure that IllegalUseOfScopeReplacer.__repr__()
    works OK.

    It does this by creating a IllegalUseOfScopeReplacer object and calling
    its __repr__ method.
    """
    # Create a IllegalUseOfScopeReplacer object
    obj = IllegalUseOfScopeReplacer(u'name', u'msg')

    # Call __repr__()
    r = repr(obj)

    # Check that the result is OK
    if r != "IllegalUseOfScopeReplacer(u'name', u'msg')":
        raise AssertionError('IllegalUseOfScopeReplacer.__repr__() fails:\n'
                             '\trepr(): %s\n'
                             % (r))
#

# Generated at 2022-06-21 21:56:27.138659
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Tests for the ImportProcessor constructors"""
    importer = ImportProcessor()
    err = None
    try:
        importer = ImportProcessor('string')
    except:
        err = sys.exc_info()[1]
    assert err is not None
    assert isinstance(err, TypeError)


# Unit test to see if all children of ImportProcessor are working
# together

# Generated at 2022-06-21 21:56:39.109711
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__"""
    from bzrlib.i18n import gettext
    from bzrlib.lazy_import import lazy_import
    # Test when string is encoded unicode.
    try:
        lazy_import(globals(), '''37\xe9''')
    except IllegalUseOfScopeReplacer as e:
        # The string is encoded using the default encoding.
        # Check it can be decoded using utf-8.
        s = str(e)
        assert isinstance(s, str)
        assert s.decode('utf8').encode('utf8') == s
        # Check it can be decoded using iso8859-1 and is unicode.
        u = unicode(e)
        assert isinstance(u, unicode)
        assert u.en

# Generated at 2022-06-21 21:56:49.621006
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()"""
    # without extra argument
    e = IllegalUseOfScopeReplacer('myname', 'mymessage')
    r = repr(e)
    # check that repr is evaluable as expected
    e2 = eval(r)
    assert e2 == e
    assert isinstance(e2, IllegalUseOfScopeReplacer)
    # with extra argument
    e = IllegalUseOfScopeReplacer('myname', 'mymessage', 'myextra')
    r = repr(e)
    # check that repr is evaluable as expected
    e2 = eval(r)
    assert e2 == e
    assert isinstance(e2, IllegalUseOfScopeReplacer)


# Generated at 2022-06-21 21:56:59.486699
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Objects are imported as expected"""
    from bzrlib import (
        osutils,
        ui,
        )
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), """
    from bzrlib.lazy_import import ImportReplacer
    from bzrlib.ui.text import TextUIFactory
    """)
    # One for each type of module import that we support
    members = {
        'import foo.bar.baz':(['foo', 'bar', 'baz'], None, {}),
        'from foo import bar':(['foo'], 'bar', {}),
        }
    for import_spec, expected in members.iteritems():
        module_name = import_spec.split()[1]
        dict = {}
        ImportReplacer