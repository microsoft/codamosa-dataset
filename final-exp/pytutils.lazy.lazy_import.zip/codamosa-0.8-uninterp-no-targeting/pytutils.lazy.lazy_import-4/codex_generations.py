

# Generated at 2022-06-21 21:47:20.724747
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ of class IllegalUseOfScopeReplacer."""
    e = IllegalUseOfScopeReplacer('a', 'b', 'c')
    u = unicode(e)
    s = str(e)
    # This is a very small test, but it's better than nothing.
    from bzrlib.i18n import gettext
    assert gettext(u) == gettext(s)



# Generated at 2022-06-21 21:47:23.986546
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    subject = IllegalUseOfScopeReplacer('test1', 'test2', 'test3')
    assert repr(subject) == "IllegalUseOfScopeReplacer('test1', 'test2', 'test3')"



# Generated at 2022-06-21 21:47:31.175585
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Tests for the constructor of ImportReplacer"""
    # ImportReplacer(scope, name, module_path, member=None, children={})
    f = ImportReplacer
    # Import foo.bar
    f(scope={}, name='foo', module_path=['foo'], member=None, children={})
    # Import foo.bar.baz
    f(scope={}, name='foo', module_path=['foo'], member=None,
      children={'bar':(['foo', 'bar'], None, {})})
    # Import foo
    f(scope={}, name='foo', module_path=['foo'], member=None, children={})
    # Import foo.bar

# Generated at 2022-06-21 21:47:33.872762
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)



# Generated at 2022-06-21 21:47:35.563300
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    assert import_processor.imports == {}, \
        "ImportProcessor.imports should be empty"
    return import_processor


# Generated at 2022-06-21 21:47:45.044907
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import sys
    import bzrlib
    if (sys.exc_info()[0] is not None
        or sys.exc_info()[1] is not None
        or sys.exc_info()[2] is not None):
        raise AssertionError("sys.exc_info() was not (None, None, None)")

# Generated at 2022-06-21 21:47:56.247786
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib.tests import TestCase
    from bzrlib import errors # needed for get_exception_format_string
    class TestClass(TestCase):
        def test_constructor(self):
            # We need to test the constructor has the right api and it raises
            # an error with the right type and format.
            o = IllegalUseOfScopeReplacer("i", "msg")
            self.assertRaises(IllegalUseOfScopeReplacer, getattr, o, "noexist")
            self.assertIsInstance(o, IllegalUseOfScopeReplacer)
            self.assertEqual([], list(o.__dict__.keys()))
            self.assertIsInstance(str(o), str)
            self.assertIs(unicode(o), str(o))

# Generated at 2022-06-21 21:48:05.142234
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method IllegalUseOfScopeReplacer.__unicode__"""
    from bzrlib.tests.test_i18n import get_test_translator
    obj = IllegalUseOfScopeReplacer("name", "msg")
    assert str(obj) == \
        "ScopeReplacer object 'name' was used incorrectly: msg"
    # set up fake translations:
    try:
        _t = get_test_translator()
        obj._fmt = "ScopeReplacer %(name)r: %(msg)s"
        str(obj)
    finally:
        _t.finish()



# Generated at 2022-06-21 21:48:15.979561
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    d = {}
    try:
        ImportReplacer(d, 'foo', ['foo'], member='bar', children={})
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError")
    try:
        ImportReplacer(d, 'foo', ['foo'], member=None, children={'bar':(['foo'],
            None, {})})
    except ValueError:
        pass
    else:
        raise AssertionError("Should have raised ValueError")
    d = {}
    ImportReplacer(d, 'foo', ['foo'], children={'bar':(['foo', 'bar'],
        None, {})})
    assert 'foo' in d
    foo = d['foo']
    assert 'bar' in foo.__dict__
    foo.bar
   

# Generated at 2022-06-21 21:48:21.089019
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from unittest import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib import (
        osutils,
        )


# Generated at 2022-06-21 21:48:29.404034
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    processor = ImportProcessor()


# Generated at 2022-06-21 21:48:35.844267
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    x = IllegalUseOfScopeReplacer('name', 'foo')
    y = IllegalUseOfScopeReplacer('name', 'foo')
    z = IllegalUseOfScopeReplacer('name', 'bar')
    w = IllegalUseOfScopeReplacer('NAME', 'foo')
    assert(x == y)
    assert(x != z)
    assert(x != w)
# End unit test for method __eq__ of class IllegalUseOfScopeReplacer



# Generated at 2022-06-21 21:48:38.999335
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import unittest

    class TestImportProcessor(unittest.TestCase):

        def test_constructor(self):
            processor = ImportProcessor()
            self.assertTrue(hasattr(processor, 'imports'))
            self.assertTrue(hasattr(processor, '_lazy_import_class'))

    unittest.main()



# Generated at 2022-06-21 21:48:42.903101
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Ensure that class ImportProcessor can be instantiated."""
    ip = ImportProcessor()
    # This is really just to make sure that the __init__ function 
    # doesn't raise an exception, which is what this test currently
    # checks.


# Generated at 2022-06-21 21:48:47.484061
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str, not unicode."""
    s = IllegalUseOfScopeReplacer(u'foo', 'Illegal use of %(name)s.')
    assert isinstance(str(s), str)



# Generated at 2022-06-21 21:48:52.762818
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method IllegalUseOfScopeReplacer.__unicode__"""
    # Constructing object IllegalUseOfScopeReplacer
    def _test():
        IllegalUseOfScopeReplacer('decode', 'input is not valid utf8')
    # Calling method IllegalUseOfScopeReplacer.__unicode__ on object
    # IllegalUseOfScopeReplacer and testing returned value
    _test().__unicode__()
    return # leave frame



# Generated at 2022-06-21 21:48:54.971426
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    global ImportProcessor
    i = ImportProcessor()



# Generated at 2022-06-21 21:48:58.094022
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = ScopeReplacer(None, None, None)
    class foo:
        def bar(): pass
    obj._real_obj = foo
    obj.bar()



# Generated at 2022-06-21 21:49:02.329089
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__() of IllegalUseOfScopeReplacer should return a valid python
    expression"""
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra')
    s = eval(repr(e))
    assert e.__dict__ == s.__dict__



# Generated at 2022-06-21 21:49:15.507142
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    # we can't use lazy_import here because it would be a recursive use
    # of ScopeReplacer. We need to construct a ScopeReplacer manually.
    class LazyScope(ScopeReplacer): pass
    class LazyModule(object):
        __name__ = 'bzrlib.lazy_import'
    import sys
    sys_modules = sys.modules.copy()
    lazy_import = LazyScope(sys.modules, factory=lambda self, scope, name: LazyModule(), name='bzrlib.lazy_import')
    # then use this ScopeReplacer to do the real import
    lazy_import(globals(), '''
from bzrlib.lazy_import import (
    ScopeReplacer,
    )
''')

# Generated at 2022-06-21 21:49:34.243016
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer("myname", "mymsg" , "my details")
    s = str(e)
    assert s[:4] == 'myn:'


# Generated at 2022-06-21 21:49:43.814689
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():

    class Foo(object):
        _called = False
        def bar(self):
            pass

    # Do not use one of the reserved keywords
    scope = {'class':None}
    def factory(replacer, scope, name):
        # Check that scope is the scope dictionary, and not a global
        scope['class'] = Foo
        return Foo()

    scope['self'] = ScopeReplacer(scope, factory, 'self')
    # Validate that foo.bar exists, and that _called is False.
    assert scope['self'].bar.__name__ == 'bar'
    assert scope['self']._called == False
    # Validate that Foo has been placed in scope, and that it has been called.
    assert isinstance(scope['class'], type)
    assert scope['class']._called == True
test_ScopeReplacer

# Generated at 2022-06-21 21:49:52.010871
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    import bzrlib.lazy_import
    obj = bzrlib.lazy_import.IllegalUseOfScopeReplacer(
        'name',
        'message',
        'extra')
    result = str(obj)
    expected = "ScopeReplacer object 'name' was used incorrectly:" + \
        " message: extra"
    assert result == expected, "%r != %r" % (result, expected)



# Generated at 2022-06-21 21:49:59.589485
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import new
    globals = new.module('fake_module')
    scope = globals.__dict__
    scope.update({'test_1': 1})
    # Get a reference to a global that does not exist
    scope_replacer = ScopeReplacer(scope, object, 'test_2')
    # Get a reference to a global that does exist
    scope_replacer = ScopeReplacer(scope, object, 'test_1')
    # Get a reference to a global that does exist but is a ScopeReplacer
    scope_replacer = ScopeReplacer(scope, object, 'test_2')
    # Check that a ScopeReplacer is returned
    scope_replacer = scope['test_2']
    assert type(scope_replacer) == ScopeReplacer
    # Check that the ScopeReplacer can replace itself with something else
    scope_

# Generated at 2022-06-21 21:50:06.824917
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy import in the general case"""
    scope = {}
    lazy_import(scope, '''
from bzrlib import (
    import_dependencies,
    _test_import_dependencies,
    )''')

    lazy_import(scope, '''
from bzrlib.lazy_import import (
    disallow_proxying,
    ScopeReplacer,
    ImportReplacer,
    ImportProcessor,
    lazy_import,
    )
from bzrlib.lazy_import import (
    ScopeReplacer,
    )''')

    scope['_test_import_dependencies'](scope)

# Generated at 2022-06-21 21:50:12.807593
# Unit test for function lazy_import
def test_lazy_import():
    scope = {}
    lazy_import(scope, '''
    import os
    import os.path
    import os.path as p
    from os.path import join as j
    ''')

    def _check_import(scope, name, module_path, member=None, children={}):
        """Check that the given import is prepared in scope"""
        if not isinstance(scope[name], ImportReplacer):
            raise AssertionError('Expected import %s to be a ImportReplacer'
                                 ' object, found %s' %
                                 (name, scope[name]))

# Generated at 2022-06-21 21:50:18.001497
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer"""
    t = IllegalUseOfScopeReplacer('name', 'msg')
    assert t.__repr__() == "IllegalUseOfScopeReplacer(name)"
    t = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    assert t.__repr__() == "IllegalUseOfScopeReplacer(name)"


# Generated at 2022-06-21 21:50:30.243890
# Unit test for function lazy_import
def test_lazy_import():
    def assert_all_proxy(namespace, *names):
        """assert that the given names all are proxy objects"""
        for name in names:
            if name not in namespace:
                raise AssertionError('%s not in namespace' % name)
            if not (isinstance(namespace[name], ScopeReplacer) or
                namespace[name] is None):
                raise AssertionError('%s should be a proxy, but is not' % name)

    def assert_all_real(namespace, *names):
        """assert that the given names all are real objects"""
        for name in names:
            if name not in namespace:
                raise AssertionError('%s not in namespace' % name)

# Generated at 2022-06-21 21:50:39.855708
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer(42, 'something', [1, 2])
    assert e.name == 42
    assert e.msg == 'something'
    assert e.extra == ': [1, 2]'
    assert str(e) == "ScopeReplacer object 42 was used incorrectly: something: [1, 2]"
    assert repr(e) == "IllegalUseOfScopeReplacer(ScopeReplacer object 42 was used incorrectly: something: [1, 2])"
    assert e == IllegalUseOfScopeReplacer(42, 'something', [1, 2])
    assert not e == IllegalUseOfScopeReplacer(42, 'something', [1, 2, 3])
    assert not e == IllegalUseOfScopeReplacer(42, 'something2', [1, 2, 3])

# Generated at 2022-06-21 21:50:49.879376
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ImportReplacer(
        scope={}, name='foo', module_path=['foo'],
        member=None, children={'bar':(['foo', 'bar'], None, {})})
    try:
        bzrlib.lazy_import.ImportReplacer(
            scope={}, name='foo', module_path=['foo'],
            member='bar', children={'baz':(['foo', 'baz'], None, {})})
    except ValueError:
        pass
    else:
        raise AssertionError('should have raised ValueError')



# Generated at 2022-06-21 21:51:00.669837
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    args = ['a', 'b', 'c']
    kwargs = dict(d='d', e='e')
    exc = IllegalUseOfScopeReplacer(*args, **kwargs)
    assert exc.name == 'a'
    assert exc.msg == 'b'
    assert exc.extra == ': c'
    assert exc.e == 'e'
    assert exc.d == 'd'



# Generated at 2022-06-21 21:51:11.563527
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import gc
    import weakref
    class Foo(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
    def factory(self, scope, name):
        return Foo('x', 'y')
    scope = {}
    name = 'MyName'
    obj = ScopeReplacer(scope, factory, name)
    assert obj is not None
    assert scope[name] is obj
    real_obj = obj._resolve()
    assert(isinstance(real_obj, Foo))
    assert(scope[name] is not obj)
    assert(scope[name] is real_obj)
    assert(scope[name].x == 'x')
    assert(scope[name].y == 'y')
    assert(obj is not real_obj)

# Generated at 2022-06-21 21:51:18.513157
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """If the original object is callable, this will be supported.

    This is needed for functions that are used as factories.

    >>> scope = {}
    >>> factory = lambda obj, scope, name: obj
    >>> scope_replacer = ScopeReplacer(scope, factory, 'name')
    >>> scope_replacer()
    >>> scope['name']
    <bzrlib.lazy_import.ScopeReplacer object at ...>
    """



# Generated at 2022-06-21 21:51:28.544881
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test import replacement for a variety of different uses"""
    # __file__ is not available, so we can't import the module
    md = {}
    import_replacer = ImportReplacer(md, name='foo', module_path=['foo'],
        children={'bar':(['foo', 'bar'], None, {})})
    # We should now have an 'foo' attribute which is an ImportReplacer, with
    # a 'bar' attribute which is also an ImportReplacer.
    assert isinstance(md['foo'], ImportReplacer)
    assert isinstance(md['foo']._import_replacer_children['bar'],
        ImportReplacer)
    # Now we should be able to ask for the real objects
    # TODO: Get this test to actually simulate importing a module, so we can
    #       see that the objects

# Generated at 2022-06-21 21:51:39.603950
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Tests of the import processing code."""

    # Raw test data, a list of (input, expected_output) tuples

# Generated at 2022-06-21 21:51:51.427018
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # (scope, name, module_path, member, children)
    import_tuple = (
        ({}, 'foo', ['foo'], None, {}),
        ({}, 'foo', ['foo'], 'bar', {}),
        ({}, 'foo', ['foo'], None,
            {'bar':(['foo', 'bar'], None, {})}),
        ({}, 'foo', ['foo'], 'baz',
            {'bar':(['foo', 'bar'], None, {})}),
        )
    for scope, name, module_path, member, children in import_tuple:
        ImportReplacer(scope, name, module_path, member, children)
    # a failure will raise an exception.



# Generated at 2022-06-21 21:52:00.699295
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    try:
        from . import lazy_import
        from . import osutils
    except ImportError:
        from bzrlib.tests import TestNotApplicable
        raise TestNotApplicable
    l = lazy_import.ScopeReplacer({}, lazy_import._import_factory, 'osutils')
    l.RandomNumberGenerator()._rand = lambda : 4
    s = osutils.sha_string('frob')
    return s == '0e3f4d06fabf4cae2b7f8cbfa3ea3f904e69bb2e'



# Generated at 2022-06-21 21:52:12.784276
# Unit test for function lazy_import
def test_lazy_import():
    """Ensure lazy_import() works as expected"""
    # This is a regression test - before this was fixed, this import would
    # fail.
    scope = {'__name__': '__main__'}

# Generated at 2022-06-21 21:52:18.612554
# Unit test for function disallow_proxying
def test_disallow_proxying():
    def check(expected):
        import bzrlib.lazy_import as _mod_lazy_import
        orig = '%s' % (_mod_lazy_import.ScopeReplacer._should_proxy,)
        try:
            _mod_lazy_import.disallow_proxying()
            new = '%s' % (_mod_lazy_import.ScopeReplacer._should_proxy,)
        finally:
            _mod_lazy_import.ScopeReplacer._should_proxy = expected
        return orig, new

    # this is not a real unit test, but a runnable regression test
    orig, new = check(True)
    assert orig == 'True'
    assert new == 'False'
    orig, new = check(False)
    assert orig == 'False'
    assert new == 'False'



# Generated at 2022-06-21 21:52:22.248152
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ should return the string form"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    r = repr(e)
    assert r == "IllegalUseOfScopeReplacer('msg')"



# Generated at 2022-06-21 21:52:29.691639
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ must be correct"""
    e = IllegalUseOfScopeReplacer(
        "foo", "bar")
    assert repr(e) == "IllegalUseOfScopeReplacer('bar')"



# Generated at 2022-06-21 21:52:36.845028
# Unit test for function disallow_proxying
def test_disallow_proxying():
    global x
    x = object()
    lazy_import(globals(), 'x')
    disallow_proxying()
    # Replaced x with a proxy
    try:
        x
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("Should be unable to use x")

# Generated at 2022-06-21 21:52:44.651113
# Unit test for function disallow_proxying
def test_disallow_proxying():
    locals = {}
    exec("import math") in locals
    # math.ceil is not replaced with a proxy.
    ceil = locals['math'].ceil
    # This function is not lazy so it is safe to call it.
    ceil(3.0)
    disallow_proxying()
    lazy_import(locals, "import math")
    exc = locals['math'].ceil(3.0)
    # math.ceil is now replaced with a proxy, so calling it raises an
    # exception.
    assert isinstance(exc, IllegalUseOfScopeReplacer)



# Generated at 2022-06-21 21:52:45.656844
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    global getattr

# Generated at 2022-06-21 21:52:57.326324
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    class Lazy(ScopeReplacer):
        def __new__(cls, scope, factory, name):
            return ScopeReplacer.__new__(cls, scope, factory, name)

    class Cls(object):
        def __call__(self):
            return 42

    scope = {}
    Lazy(scope, lambda self, scope, name: scope[name], 'Cls')

    scope['Cls'].__call__() # raises IllegalUseOfScopeReplacer

    scope['Cls'] = Cls()

    scope['Cls'].__call__() # works now

    scope['other'] = Cls()
    ScopeReplacer._should_proxy = False
    try:
        scope['other'].__call__() # raises IllegalUseOfScopeReplacer
    finally:
        ScopeReplacer._should_proxy = True



# Generated at 2022-06-21 21:53:05.885227
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ must compare the attributes."""
    class MyException(Exception):
        pass
    e1 = MyException(1, 2, 3)
    e2 = MyException(1, 2, 3)
    e3 = MyException(1, 2)
    e4 = IOError(1, 2, 3)
    assert e1 != e2 # These can be equal, but not the same
    assert e1 != e3
    assert e2 != e3
    assert e1 != e4




# Generated at 2022-06-21 21:53:17.085516
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class C(object):
        def __init__(self):
            self.X = None
        def getX(self):
            return self.X
        def setX(self, value):
            self.X = value
    scope = {}
    def factory(self, scope, name):
        return C()
    sr = ScopeReplacer(scope, factory, 'sr')
    expected_type = type(C())
    actual_type = type(sr)
    assert actual_type == expected_type, (actual_type, expected_type)
    expected_x = None
    actual_x = sr.getX()
    assert actual_x == expected_x, (actual_x, expected_x)
    sr.setX(123)
    expected_x = 123
    actual_x = scope['sr'].getX()
   

# Generated at 2022-06-21 21:53:28.253498
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # Create an import processor
    import_processor = ImportProcessor()

    # Empty text should generate an empty import map
    import_processor.lazy_import({}, '')
    assert import_processor.imports == {}, ("Empty text should generate an"
        " empty import map")

    # A single import should just create an entry in the import map
    import_processor.lazy_import({}, 'import foo')
    assert import_processor.imports == {'foo':(['foo'], None, {})}, (
        "Importing foo should create a foo entry in the import map")
    # Clear the import map for next test
    import_processor.imports.clear()

    # Multiple imports can be specified on one line, and should be treated
    # appropriately

# Generated at 2022-06-21 21:53:40.214337
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Method __eq__ of class IllegalUseOfScopeReplacer

    The method is tested by running a bunch of permutations of 4 exceptions
    with different values.
    """
    permutations = [('foo', 'bar', 'baz'), (1, 2, 3)]
    for exc_name1, msg1, extra1 in permutations:
        for exc_name2, msg2, extra2 in permutations:
            for exc_name3, msg3, extra3 in permutations:
                for exc_name4, msg4, extra4 in permutations:
                    assert IllegalUseOfScopeReplacer(exc_name1, msg1, extra1) \
                        == IllegalUseOfScopeReplacer(exc_name1, msg1, extra1)

# Generated at 2022-06-21 21:53:49.630174
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy_import works as expected on normal code"""
    # This isn't a very thorough test, but it is the best I can think
    # of right now.
    # TODO: jam 2007-01-02 Rethink this test. It is pretty useless at this
    #       point.
    import os.path
    scope = {'__name__':'__main__'}
    lazy_import(scope, '''
    import bzrlib
    ''')
    scope['bzrlib']
    scope['bzrlib.osutils']
    scope['bzrlib.osutils'].path
    scope['bzrlib'].osutils
    scope['bzrlib'].osutils.path
    scope['bzrlib'].osutils.path == os.path


# Generated at 2022-06-21 21:54:06.520091
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test processing of text describing imports"""

    class TestReplacer(object):
        """The replacer for tests

        The import string is compared against an expected string.

        :ivar expected: the expected import string
        :ivar tested: Whether the import has been tested or not.
        """

        def __init__(self, scope, name, module_path, member=None,
                     children=None):
            self.expected = "%s.%s" % ('.'.join(module_path), member)
            self.tested = False

        def __eq__(self, other):
            return other == self.expected


# Generated at 2022-06-21 21:54:18.666053
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import os
    import shutil
    import tempfile
    from bzrlib.tests import TestUtil

    class TestableImportProcessor(ImportProcessor):
        """This is a subclass of ImportProcessor that knows how to generate
        a module.
        """

        def _create_module(self, scope, text):
            """Create a module with given scope and source text"""
            f = tempfile.NamedTemporaryFile(delete=False)
            try:
                f.write(text)
                f.close()
                p = load_python_module(self._get_module_name(), f.name)
                scope[p.__name__] = p
                return p
            finally:
                if os.path.exists(f.name):
                    os.unlink(f.name)


# Generated at 2022-06-21 21:54:29.351741
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the ImportProcessor class"""
    ip = ImportProcessor()
    ip.lazy_import(globals(), 'import foo')
    ip.lazy_import(globals(), 'import foo.bar')
    try:
        ip.lazy_import(globals(), 'import foo')
    except errors.ImportNameCollision:
        pass
    else:
        raise AssertionError('already imported foo should have been caught')
    ip.lazy_import(globals(), """
        import foo.bar.baz as bing
        import foo.bar.baz.bing as bingy
        """)

# Generated at 2022-06-21 21:54:41.286623
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import

    def factory(self, scope, name):
        """Factory that creates a new object"""
        return ''

    scope = locals()
    lazy_import.lazy_import(scope, '''
    abc = bzrlib.lazy_import.ScopeReplacer(scope, factory, 'abc')
    ''')
    scope['abc'] = 'xyz'
    # Some more code using scope['abc'] that should not be optimised out by
    # coverage.py
    assert isinstance(scope['abc'], str)
    # The following line should raise an exception.
    try:
        scope['abc'] = 'abc'
    except lazy_import.IllegalUseOfScopeReplacer as e:
        assert isinstance(e, lazy_import.IllegalUseOfScopeReplacer)


# Generated at 2022-06-21 21:54:48.815483
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """unit test for IllegalUseOfScopeReplacer.__unicode__"""
    from bzrlib.tests import TestCase
    # Cannot use TestCase.assertEqualU() because it would call
    # __unicode__ on the IllegalUseOfScopeReplacer object
    class Test(TestCase):
        def test(self):
            err = IllegalUseOfScopeReplacer(
                'foo',
                "cannot use",
                extra='bar')
            self.assertEqual(unicode(err),
                             "ScopeReplacer object 'foo' was used incorrectly:"
                             " cannot use: bar")
    Test('test').run()



# Generated at 2022-06-21 21:54:55.203260
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from unittest import TestCase

    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    class MyClass(object):

        def __init__(self, name, value):
            self.name = name
            self.value = value

        def read(self):
            return self.value

        def write(self, value):
            self.value = value

        def call(self, *args, **kwargs):
            return self.value

    class MyTestCase(TestCase):

        def test_getattribute(self):
            scope = {}
            lazy_obj = ScopeReplacer(scope, lambda self, scope, name: 'real_obj',
                'lazy_obj')
            obj = MyClass('name', 'value')

# Generated at 2022-06-21 21:55:07.476621
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method ScopeReplacer.__setattr__ of class ScopeReplacer

    To run all tests:
        $ ./bzrlib/_lazy_import.py
    To run this test:
        $ ./bzrlib/_lazy_import.py ScopeReplacer.__setattr__
    """
    import os
    import tempfile
    import traceback
    import unittest
    from bzrlib.lazy_import import lazy_import, _LazyImportError
    from bzrlib._lazy_import import (
        ScopeReplacer,
        )
    from bzrlib.tests import (
        TestCase,
        TestCaseWithMemoryTransport,
        )


# Generated at 2022-06-21 21:55:15.228352
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    def factory(scope_replacer, scope, name):
        return 'Hello, World!'

    # if __call__ is not implemented, calling instance will raise an exception
    from bzrlib.tests import TestCase
    import sys

    class DummyTestCase(TestCase):

        def test_foo(self):
            scope = {}
            name = 'my_string'
            my_string = ScopeReplacer(scope, factory, name)
            self.assertEqual(my_string(), 'Hello, World!')

    out = StringIO()
    runner = TestUtil.TestRunner(stream=out)
    result = runner.run(DummyTestCase('test_foo'))
    self.assertEqual(0, result.wasSuccessful())



# Generated at 2022-06-21 21:55:25.138414
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    import os.path

    # it should be able to import a module in the path, with given a single
    # module_path
    local_scope = {}
    cls = ImportReplacer.__getattribute__(ImportReplacer, '__class__')
    replacer = ImportReplacer(local_scope,
                              name='sys',
                              module_path=['sys'],
                              member=None)
    assert local_scope['sys'].__class__ is replacer.__class__
    assert local_scope['sys']._module_path is not None
    assert local_scope['sys'].__dict__['sys'] is sys
    assert local_scope['sys'].__dict__['path'] is os.path

    # it should be able to import a module in the path, with given module
    # path

# Generated at 2022-06-21 21:55:35.893593
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib.lazy_import as lazy_import
    real_import = __builtins__.__import__
    __builtins__.__import__ = lambda *args, **kwargs: None
    
    def test_lazy_module_as_module():
        # Test that the module successfully appears as a module.
        glob = {}
        lazy_import.lazy_import(glob, 'import bzrlib')
        module = glob['bzrlib']
        assert not hasattr(module, 'urlutils')
        import bzrlib.urlutils
        assert hasattr(module, 'urlutils')

    def test_lazy_module_as_variable():
        # Test that the module successfully appears as a variable.
        glob = {}

# Generated at 2022-06-21 21:55:54.412630
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), 'from bzrlib.tests import TestCase')
    TestCase.disallow_proxying()



# Generated at 2022-06-21 21:56:02.830392
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import sys
    def my_factory(replacer, scope, name):
        return 42
    def my_factory_2(replacer, scope, name):
        return 43

    # Create a ScopeReplacer
    bzrlib.lazy_import.ScopeReplacer(sys.modules['bzrlib.lazy_import'],
                                     my_factory, 'answer')
    # Assing to a real object
    answer = sys.modules['bzrlib.lazy_import'].answer
    # Check that the __setattr__ method of the real object is called
    # instead of the __setattr__ of the ScopeReplacer
    answer.value = answer()
    assert answer.value == 42
    # Try to change the factory and create a new ScopeReplacer
   

# Generated at 2022-06-21 21:56:14.495045
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This test passes if IllegalUseOfScopeReplacer.__unicode__() works"""
    def check_for_unicode(ex):
        """Returns true if exception ex returns a unicode string"""
        try:
            u = ex.__unicode__()
        except:
            return False
        if not isinstance(u, unicode):
            return False
        return True

    # Make sure that ex.__unicode__() works.
    # For example, in 2.3.5, it used to fail with a TypeError.
    ex = IllegalUseOfScopeReplacer('ex', 'ex')
    if not check_for_unicode(ex):
        raise AssertionError("IllegalUseOfScopeReplacer.__unicode__()"
                             " is broken")



# Generated at 2022-06-21 21:56:16.364589
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of class ScopeReplacer"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:56:24.394545
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    import_replacer = ImportReplacer(scope=globals(), name='foo',
                                     module_path=['foo'], member=None,
                                     children={})
    assert import_replacer._module_path == ['foo']
    assert import_replacer._member is None
    assert import_replacer._import_replacer_children == {}

    import_replacer = ImportReplacer(scope=globals(), name='foo',
                                     module_path=['foo'], member='bar',
                                     children={})
    assert import_replacer._module_path == ['foo']
    assert import_replacer._member == 'bar'
    assert import_replacer._import_replacer_children == {}


# Generated at 2022-06-21 21:56:34.406468
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test creation of a ScopeReplacer object.

    Ensures that it is created as a lazy import, i.e. that
    it provides a placeholder, instead of the real thing.
    """
    global foo
    dummy = object

    def factory(self, scope, name):
        return dummy

    ScopeReplacer(locals(), factory, 'foo')
    assert(isinstance(foo, ScopeReplacer))
    assert(foo() is dummy)
    assert(foo is dummy)


# Generated at 2022-06-21 21:56:38.926455
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    import doctest
    doctest.Equality(IllegalUseOfScopeReplacer('a', 'b'),
                     IllegalUseOfScopeReplacer('a', 'b'))
    doctest.Equality(IllegalUseOfScopeReplacer('a', 'b', 'c'),
                     IllegalUseOfScopeReplacer('a', 'b', 'c'))



# Generated at 2022-06-21 21:56:44.029672
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    bzrlib.tests.per_interpreter_def('test_ScopeReplacer___call__', [])
    # TODO: Test that __call__ calls the constructor of the replaced object
    # with the same args and kwargs.
    pass


# Generated at 2022-06-21 21:56:55.542861
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class Foo (IllegalUseOfScopeReplacer):
        pass
    def _FailUnlessEquals(a, b):
        if a != b:
            raise AssertionError('%r != %r' % (a, b))
    _FailUnlessEquals(Foo(u'unicode', u'unicode', 1),
                      Foo(u'unicode', u'unicode', 1))
    _FailUnlessEquals(Foo('ascii', 'ascii', 1),
                      Foo('ascii', 'ascii', 1))
    _FailUnlessEquals(Foo('ascii', 'ascii', 1),
                      Foo('ascii', 'ascii', 1))