

# Generated at 2022-06-21 21:47:37.811175
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that imported modules can be used as proxies.

    This unit test also serves as documentation as to how to use
    disallow_proxying().
    """
    def _prepare_my_module():
        """This function will be executed to generate the module"""
        class MyModule(object):
            def my_method(self):
                return True
        return MyModule()

    exec("""
    from bzrlib.lazy_import import (
        lazy_import,
        disallow_proxying,
        )
    disallow_proxying()
    lazy_import(globals(), '''
    import bzrlib.lazy_import_tests.my_module
    ''')
    """) # in order to get 'a real' module we have to use exec here.


# Generated at 2022-06-21 21:47:50.852739
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    late = []
    def should_not_run():
        late.append(1)

    scope = {}
    text = '''
            from bzrlib import errors
            import os
            from bzrlib import (bzrdir,
                                workingtree)
            from bzrlib.workingtree import (
                WorkingTree,
                )
            import bzrlib.se
            from bzrlib.urlutils import (
                split_segment_parameters,
                )
            '''
    importer = ImportProcessor(lazy_import_class=LazyImport)
    importer.lazy_import(scope, text)

    scope['errors'].should_be_late
    scope['os'].should_be_late
    scope['bzrdir'].should_be_late
    scope

# Generated at 2022-06-21 21:48:01.082439
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib import lazy_import
    lazy_import.lazy_import(locals(), 'bzrlib.errors')
    e = errors.IllegalUseOfScopeReplacer('a', 'b')
    assert str(e) == "ScopeReplacer object 'a' was used incorrectly: b"
    e = errors.IllegalUseOfScopeReplacer('a', 'b', 1)
    assert str(e) == "ScopeReplacer object 'a' was used incorrectly: b: 1"
    e = errors.IllegalUseOfScopeReplacer('a', 'b', extra='1')
    assert str(e) == "ScopeReplacer object 'a' was used incorrectly: b: 1"



# Generated at 2022-06-21 21:48:05.835892
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib import tests
    t = tests.TestCase('__init__')
    class Dummy(IllegalUseOfScopeReplacer):
        _fmt = 'dummy %(msg)s'
    t.assertEqual('dummy testy', str(Dummy('foo', 'testy')))



# Generated at 2022-06-21 21:48:16.561186
# Unit test for function lazy_import
def test_lazy_import():
    scope = {}

# Generated at 2022-06-21 21:48:21.807619
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.tests import TestCase
    import bzrlib
    class TestLazyImport(TestCase):
        def setUp(self):
            self.scope = {}

        def test_import(self):
            lazy_import(self.scope, '''
            import bzrlib
            import bzrlib.foo
            import bzrlib.branch''')

            # This is a magic name which will be replaced by a real reference
            # to the module on first use.
            self.assertTrue('bzrlib' in self.scope)
            self.assertTrue('foo' in self.scope)
            self.assertTrue('branch' in self.scope)


# Generated at 2022-06-21 21:48:26.467956
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor of class ImportReplacer.

    Test the constructor of class ImportReplacer, including that
    it throws the appropriate errors.
    """

    # Create an instance of the ImportReplacer using all valid parameters
    scope = {}
    replacer = ImportReplacer(scope=scope, name='foo',
                              module_path=['foo', 'bar'],
                              member=None,
                              children={'fred':(['foo', 'bar', 'baz'], None, {})})

    # Check that the appropriate attributes have been set correctly
    assert replacer._import_replacer_children == {'fred': (['foo', 'bar', 'baz'], None, {})}
    assert replacer._member is None
    assert replacer._module_path == ['foo', 'bar']
    assert replacer._name == 'foo'

# Generated at 2022-06-21 21:48:28.857089
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test method ScopeReplacer.__setattr__ of class ScopeReplacer"""
    # Insert your code here
    raise NotImplementedError()

# Generated at 2022-06-21 21:48:33.280787
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # In this first test, we have a simple case of 'import foo.bar'. We have
    # 2 modules, foo and bar. foo has a child called bar.
    # We expect to have a Children entry of name:bar, and member:None.
    # Other tests are similar in nature, as we only modify the inputs and
    # outputs.
    scope = {}
    name = 'foo'
    module_path = ['foo']
    member = None
    children = {'bar':(['foo', 'bar'], None, {})}
    import_replacer = ImportReplacer(scope, name, module_path, member, children)
    assert import_replacer._import_replacer_children == children
    assert import_replacer._member == member
    assert import_replacer._module_path == module_path
    assert import_replacer._

# Generated at 2022-06-21 21:48:42.924863
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Method __getattribute__ of class ScopeReplacer"""
    class TestClass:
        def __init__(self, value):
            self.value = value
        def get_value(self):
            return self.value
        def set_value(self, value):
            self.value = value
    def test_factory(self, scope, name):
        return TestClass(name)

    scope = {}
    lazy_obj = ScopeReplacer(scope, test_factory, 'testValue')

    assert lazy_obj.get_value() == "testValue"
    assert lazy_obj.value == "testValue"
    class TestClass2:
        def __init__(self, value):
            self.value = value
    lazy_obj.set_value(TestClass2("newValue"))
    assert lazy_obj.get_value

# Generated at 2022-06-21 21:48:54.100697
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('dummy_name', 'dummy_message', 'dummy_extra')
    wanted = r"IllegalUseOfScopeReplacer('dummy_name', 'dummy_message', 'dummy_extra')"
    s = repr(e)
    if s != wanted:
        raise AssertionError('%s != %s' % (s, wanted))

# Generated at 2022-06-21 21:49:02.107232
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """This test checks that a ScopeReplacer object can be called as a
    regular function.
    """
    def foo(f):
        return f()
    def factory(self, scope, name):
        return lambda : True
    s = ScopeReplacer({}, factory, 'bar')
    assert foo(s)

    # Now test that the replacing has occurred.
    assert 'bar' not in s._scope
    assert s._scope['bar'], "bar did not get replaced"
test_ScopeReplacer___call__.expected_failure = True



# Generated at 2022-06-21 21:49:15.506023
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from cStringIO import StringIO
    
    import bzrlib

# Generated at 2022-06-21 21:49:28.247450
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.blackbox import ExternalBase

    # To ensure that an object that is already replaced will not be
    # reused, we set _should_proxy to false, which will raise an
    # IllegalUseOfScopeReplacer if an attr is set on a replaced object.
    # Note that this relies on setattr calling __getattribute__, which
    # it does in 2.5.
    ScopeReplacer._should_proxy = False
    class TestScopeReplacer(ExternalBase):

        def test_replaced_obj_cannot_be_setattr(self):
            def _factory(self, scope, name):
                obj = object()
                return obj

            scope = locals()
            name = 'obj'

# Generated at 2022-06-21 21:49:29.243691
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass

# Generated at 2022-06-21 21:49:41.626088
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """A unit test for IllegalUseOfScopeReplacer.__unicode__

    This test is implemented as a function so that it can be run under
    Python 2.3.  See comments in the body of test_IllegalUseOfScopeReplacer
    for details.
    """
    class FooScopeReplacer(IllegalUseOfScopeReplacer):
        pass

    class BarScopeReplacer(IllegalUseOfScopeReplacer):

        _fmt = '%(foo)s'

    assert str(FooScopeReplacer('foo', 'bar', extra='baz')) == \
        'Unprintable exception FooScopeReplacer: dict={\'extra\': \'\', \'msg\': \'bar\', \'name\': \'foo\'}, fmt=None, error=None'

# Generated at 2022-06-21 21:49:53.688173
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for constructor of class ScopeReplacer"""
    class MyClass:
        def __init__(self):
            self.value = 0

        def __getattribute__(self, attr):
            if attr != 'value' and attr != '__class__':
                raise Exception('This code should not be reached')
            return object.__getattribute__(self, attr)

        def __setattr__(self, attr, value):
            if attr != 'value' and attr != '__class__':
                raise Exception('This code should not be reached')
            object.__setattr__(self, attr, value)

    attr = 'value'
    my_obj = MyClass()
    my_var = 0
    my_var_name = 'my_var'

    scope = {}
    scope_

# Generated at 2022-06-21 21:49:57.798592
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    obj_repr = repr(obj)
    expected_repr = "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    assert obj_repr == expected_repr, obj_repr



# Generated at 2022-06-21 21:50:02.104538
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return str"""
    err = IllegalUseOfScopeReplacer("name", "message", "extra")
    s = str(err)
    assert isinstance(s, str)


# Generated at 2022-06-21 21:50:15.442998
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    s = {'foo':1}
    p = ImportProcessor()
    p.lazy_import(s, """
        import foo
        import foo.bar as bing
        import foo.bar.baz
        import foo.bar.baz as bong
        # This is a comment
        from foo import bar, baz as bop
        """)
    assert s == {}
    assert s['foo']._import_replacer_children == {
            'bar':(['foo', 'bar'], None,
                {'baz':(['foo', 'bar', 'baz'], None, {})})
            }
    assert s['bing']._import_replacer_children == {}
    assert s['foo.bar.baz']._import_replacer_children == {}

# Generated at 2022-06-21 21:50:35.286584
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # A test for the ImportProcessor class
    proc = ImportProcessor()

    # Test for normal imports
    proc.lazy_import(globals(), 'import bzrlib.transport')
    proc.lazy_import(globals(), 'import bzrlib.transport\n'
                                'import bzrlib.errors')
    proc.lazy_import(globals(), 'import bzrlib.transport,\nbzrlib.errors')
    proc.lazy_import(globals(), 'import bzrlib.transport, \n'
                                'bzrlib.errors')
    proc.lazy_import(globals(), 'import bzrlib.transport,bzrlib.errors')

# Generated at 2022-06-21 21:50:41.010616
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    import bzrlib
    scope = sys.modules
    name = 'bzrlib'
    module_path = ['bzrlib']
    member = None
    children = {}
    I = ImportReplacer(scope, name, module_path, member, children)
    bzrlib_I = scope['bzrlib']
    assert I is bzrlib_I
    bzrlib_real = __import__('bzrlib', scope, scope, [], level=0)
    assert bzrlib_I is bzrlib_real
    pass



# Generated at 2022-06-21 21:50:49.706335
# Unit test for function lazy_import
def test_lazy_import():
    global_dict = {}
    lazy_import(global_dict, '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    ''')
    for name in global_dict:
        import_replacer = global_dict[name]
        if isinstance(import_replacer, ImportReplacer):
            raise AssertionError("lazy_import produced an ImportReplacer "
                                 "for %s, should have been a ScopeReplacer"
                                 % (name,))



# Generated at 2022-06-21 21:50:59.561451
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import unicodedata
    # Check that the method __unicode__ of class IllegalUseOfScopeReplacer
    # successfully replaces the message fields with their values
    exception1 = IllegalUseOfScopeReplacer('example', 'error message')
    u = unicode(exception1)
    assert isinstance(u, unicode)
    # Check that it's the correct message
    assert u == 'ScopeReplacer object \'example\' was used incorrectly: error message'
    # Check that it's not marked as untranslated
    assert unicodedata.category(u[0]) != 'Cn'
    # Check that it gives the same result for __str__
    assert str(exception1) == u.encode('utf8')



# Generated at 2022-06-21 21:51:04.920793
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test the method __setattr__ of class ScopeReplacer
    class DemoClass(object):
        def get_id(self):
            return self._id
        def set_id(self, value):
            self._id = value

        id = property(get_id, set_id)

    replacer = ScopeReplacer(locals(), 'DemoClass', 'DemoClass')
    inst = DemoClass()
    assert replacer.id is None

    replacer.id = 1
    assert inst._id == 1
    assert replacer.id == 1

    inst.id = 2
    assert inst._id == 2
    assert replacer.id == 2

# Generated at 2022-06-21 21:51:13.267877
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test for method lazy_import of class ImportProcessor."""
    # Trivial case
    ip = ImportProcessor()
    ip.lazy_import({}, '')
    try:
        ip.lazy_import({}, 'import foo')
        raise AssertionError('ImportProcessor.lazy_import() should raise '
            'InvalidImportLine in case of invalid import line.')
    except errors.InvalidImportLine:
        pass
    try:
        ip.lazy_import({}, 'import foo,')
        raise AssertionError('ImportProcessor.lazy_import() should raise '
            'InvalidImportLine in case of invalid import line.')
    except errors.InvalidImportLine:
        pass

# Generated at 2022-06-21 21:51:26.735669
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test ScopeReplacer constructor

    This test is not part of the test suite as it's the task of this
    module to detect all errors that it can.
    """
    # No exception should occur
    scope = {}
    factory = lambda obj, scope, name: scope
    name = 'Test'
    # Work around selftest's proxy detection:
    saved_proxy_state = ScopeReplacer._should_proxy
    try:
        ScopeReplacer._should_proxy = True
        ScopeReplacer(scope, factory, name)
    finally:
        ScopeReplacer._should_proxy = saved_proxy_state
    # Now test the Exception cases:
    # scope is not a dict
    scope = None
    error = None

# Generated at 2022-06-21 21:51:38.751569
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.i18n import gettext
    gettext('foo')
    # We need to do this to create the _translations dict.
    # TODO: Jam 20060809 find a better way to fake the gettext infrastructure
    from bzrlib.i18n import _translations
    if not _translations:
        import bzrlib.i18n
        _translations = getattr(bzrlib.i18n, '_translations')
    _translations['foo'] = 'bar'
    e = IllegalUseOfScopeReplacer('assign_lazy_to_globals', 'scope missing')
    assert e._get_format_string() == 'scope missing'
    assert str(e) == 'scope missing'

# Generated at 2022-06-21 21:51:46.900036
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ should set the __slots__ data, and place self in the given scope"""
    # We don't want to actually import anything, so we define a fake module here
    class FakeModule(object):
        pass
    fake_module = FakeModule()
    fake_module.fake_var = None
    factory = lambda replacer, scope, name: 1
    foo = ScopeReplacer(fake_module.__dict__, factory, 'fake_var')
    assert foo._scope is fake_module.__dict__
    assert foo._factory is factory
    assert foo._name == 'fake_var'
    assert foo._real_obj is None
    assert fake_module.fake_var is foo
test_ScopeReplacer.requires = []



# Generated at 2022-06-21 21:51:54.726580
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() works correctly

    If _format returns a unicode object directly, it should be returned.
    If _format returns a str object, it should be decoded using the
    system default encoding.
    If _format returns any other object, it should be cast to unicode
    using unicode(...)
    """
    class BadSR(IllegalUseOfScopeReplacer):
        def _format(self):
            return u'does not like to be used'
    class BadSR2(IllegalUseOfScopeReplacer):
        def _format(self):
            return 'does not like to be used'
    class BadSR3(IllegalUseOfScopeReplacer):
        def _format(self):
            return None

# Generated at 2022-06-21 21:52:11.288691
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should work on IllegalUseOfScopeReplacer instances."""
    c1 = IllegalUseOfScopeReplacer('name1', 'msg1')
    c2 = IllegalUseOfScopeReplacer('name2', 'msg2')
    c3 = IllegalUseOfScopeReplacer('name1', 'msg1')
    assert c1 != c2
    assert c1 != c3
    assert c2 != c3
    assert c1 == IllegalUseOfScopeReplacer('name1', 'msg1')
    assert c2 == IllegalUseOfScopeReplacer('name2', 'msg2')


# Generated at 2022-06-21 21:52:17.724720
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(None, None, None)
    obj.a = 1
    obj.b = 1
    obj.c = 1
    obj.d = 1
    obj.e = 1
    obj.f = 1
    obj.g = 1
    obj.h = 1
    obj.i = 1
    obj.j = 1
    obj.k = 1
    obj.l = 1
    obj.m = 1
    obj.n = 1
    obj.o = 1
    obj.p = 1
    obj.q = 1
    obj.r = 1
    obj.s = 1
    obj.t = 1
    obj.u = 1
    obj.v = 1
    obj.w = 1
    obj.x = 1
    obj.y = 1
    obj.z = 1

# Generated at 2022-06-21 21:52:24.722653
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    except IllegalUseOfScopeReplacer as e:
        assert isinstance(str(e), str)
        assert isinstance(unicode(e), unicode)
        assert isinstance(repr(e), str)
        assert 'IllegalUseOfScopeReplacer' in repr(e)
        assert 'foo' in str(e)
        assert 'bar' in str(e)
        assert 'baz' in str(e)



# Generated at 2022-06-21 21:52:30.164908
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """The scope replacer should format nicely"""
    # TODO: Jam 20070205 Test that it works in other languages.
    e = IllegalUseOfScopeReplacer('a', 'msg', 'extra')
    assert e.__str__() == 'msgextra'



# Generated at 2022-06-21 21:52:35.390732
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = e.__unicode__()
    assert isinstance(u, unicode), type(u)



# Generated at 2022-06-21 21:52:47.308145
# Unit test for function lazy_import
def test_lazy_import():
    lazy_import(globals(), '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    ''')
    def _check_lazy_import(name):
        import bzrlib
        # bzrlib is already imported
        assert name not in bzrlib.__dict__
        assert name in globals()
        # Double check that we are getting real, not proxy information
        if name == 'bzrlib':
            assert name is globals()[name]
        else:
            assert name == globals()[name].__name__

    _check_lazy_import('foo')
    _check_lazy_import('bar')
    _check_lazy_

# Generated at 2022-06-21 21:52:57.283673
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib._lazy_import_test_data import (
        IllegalUseOfScopeReplacer,
        )
    e1 = IllegalUseOfScopeReplacer('bar', 'cannot invoke me')
    e2 = IllegalUseOfScopeReplacer('bar', 'cannot invoke me')
    e3 = IllegalUseOfScopeReplacer('bar', 'cannot invoke me', 'foo')
    e4 = IllegalUseOfScopeReplacer('bar', 'cannot invoke me', 'foo')
    e5 = IllegalUseOfScopeReplacer('bar', 'bad', 'foo')
    assert e1 == e2
    assert e3 == e4
    assert e1 != e3
    assert e3 != e5



# Generated at 2022-06-21 21:53:08.792885
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """
    Method __setattr__ of class ScopeReplacer does not allow changing
    of attributes on already-resolved objects.
    """
    class MyClass(object):
        attr = 'baz'
    scope = {}
    replacer = ScopeReplacer(scope, lambda scope, name, cls=MyClass: cls(),
            'replacer')
    replacer.attr = 'foo'
    assert scope['replacer'].attr == 'foo'
    replacer.attr = 'bar'
    assert scope['replacer'].attr == 'bar'
    # disable changing of attributes
    ScopeReplacer._should_proxy = False
    replacer.attr = 'hop'
    assert scope['replacer'].attr == 'bar'



# Generated at 2022-06-21 21:53:18.306395
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    scope = {}
    def factory(scoper, scope, name):
        return scoper
    lazy_import(scope, 'x = factory', factory=factory)
    assert scope['x'] != scope['x']
    assert scope['x']._should_proxy
    disallow_proxying()
    try:
        x = scope['x']
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('upfront replacement was allowed')
    x._should_proxy = True
    assert x == x
    assert scope['x']._should_proxy



# Generated at 2022-06-21 21:53:28.917768
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """The method lazy_import of class ImportProcessor"""
    import sys
    import re
    import bzrlib
    ip = ImportProcessor(lazy_import_class = ImportReplacer)

# Generated at 2022-06-21 21:53:41.134154
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class MyIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        _fmt = ''
    x = MyIllegalUseOfScopeReplacer('n', 'm')
    y = MyIllegalUseOfScopeReplacer('n', 'm')
    z = MyIllegalUseOfScopeReplacer('n2', 'm')
    w = MyIllegalUseOfScopeReplacer('n', 'm2')
    xx = x
    assert x == y
    assert x != z
    assert x != w
    assert x == xx



# Generated at 2022-06-21 21:53:49.380805
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestableScopeReplacer(ScopeReplacer):
        def __init__(self):
            ScopeReplacer.__init__(self, None, None, None)
    obj = TestableScopeReplacer()
    def fn(arg1):
        return 'okay-%s' % arg1
    fn.__name__ = 'fn'
    obj.__call__ = fn
    assert obj(1234) == 'okay-1234'
# End unit test for method __call__ of class ScopeReplacer


# Generated at 2022-06-21 21:53:58.194980
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of the ScopeReplacer object.

    It is legal to set any attribute on a ScopeReplacer object:

    >>> from bzrlib.lazy_import import ScopeReplacer
    >>> from bzrlib.lazy_import import _MutableDict
    >>> s = ScopeReplacer(_MutableDict(), None, 'name')
    >>> s.name = 'value'
    <bzrlib.lazy_import.ScopeReplacer object at ...>
    >>> s.foo = 'bar'
    <bzrlib.lazy_import.ScopeReplacer object at ...>

    """


# Generated at 2022-06-21 21:54:01.628370
# Unit test for function lazy_import
def test_lazy_import(): 
    from bzrlib.tests.lazy_import_tests import test_lazy_import
    return test_lazy_import()



# Generated at 2022-06-21 21:54:11.071524
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import traceback

    # Indirecting through object.__getattribute__ so that children
    # overriding _import are followed (especially our instrumented version)
    def _should_proxy(self, scope, name):
        try:
            object.__getattribute__(self, '_import')(scope, name)
        except IllegalUseOfScopeReplacer:
            pass

    def _resolve(self):
        return object.__getattribute__(self, '_resolve_override')()

    def __getattribute__(self, attr):
        obj = object.__getattribute__(self, '_resolve')()
        return getattr(obj, attr)

    def __setattr__(self, attr, value):
        obj = object.__getattribute__(self, '_resolve')()
       

# Generated at 2022-06-21 21:54:18.223104
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method IllegalUseOfScopeReplacer.__unicode__"""
    # part 1
    # expected_element is a unicode object.
    expected_element = u'Illegal use of ScopeReplacer, did you use' \
        u' `from _mod_ import *' \
        u"' in your code? If so, please fix it. (exception raised in" \
        u" mod_name.attribute_name)"
    object1 = IllegalUseOfScopeReplacer(u'mod_name.attribute_name',
        u'Illegal use of ScopeReplacer, did you use `from _mod_ import *' \
        u"' in your code? If so, please fix it.", None)
    # __unicode__ method returns a unicode object.
    u1 = object1.__unicode__()

# Generated at 2022-06-21 21:54:28.934572
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Method lazy_import"""
    # This test could be expanded.
    imports = """\
        import foo, bar as bing, baz.bing as fred, \
                baz.bing as fred, baz.foo.bar as foob
        from foo import bar, baz"""
    processor = ImportProcessor()
    processor.lazy_import({}, imports)

    assert set(processor.imports.keys()) == set(
            ['foo', 'bar', 'bing', 'baz', 'fred', 'foob'])
    assert processor.imports['foo'] == (['foo'], None, {})
    assert processor.imports['bar'] == (['foo'], 'bar', {})
    assert processor.imports['bing'] == (['bar'], None, {})

# Generated at 2022-06-21 21:54:36.406436
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ must produce a string which if
    evaluated will recreate an instance with the same value"""
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    obj2 = eval(repr(obj))
    assert obj == obj2, "__repr__ produced: %r, but it wasn't equivalent" % (
        obj2,)
test_IllegalUseOfScopeReplacer___repr__.unittest = ['.errors']



# Generated at 2022-06-21 21:54:39.292785
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This method should return a string."""
    s = IllegalUseOfScopeReplacer('foo', 'bar')
    str(s)

# Generated at 2022-06-21 21:54:43.476183
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def func(obj):
        return obj.some_attr
    class SomeClass(object):
        some_attr = 'foo'
    obj = ScopeReplacer({}, lambda o,s,n: SomeClass(), 'SomeClass')
    assert func(obj) == 'foo'



# Generated at 2022-06-21 21:54:56.908838
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer.

    We test with the default format string, and with a custom format string
    given as a property of the exception class.

    Also, we test that None is ok as parameter 'msg'.
    """
    ex1 = IllegalUseOfScopeReplacer('name1', None, 'extra1')
    assert str(ex1) == \
'ScopeReplacer object \'name1\' was used incorrectly: None: extra1'
    ex2 = IllegalUseOfScopeReplacer('name2', 'message2', 'extra2')
    assert str(ex2) == \
'ScopeReplacer object \'name2\' was used incorrectly: message2: extra2'
    ex1._fmt = 'Format for %(name)s: %(msg)s%(extra)s'

# Generated at 2022-06-21 21:55:04.751271
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test construction of ScopeReplacer objects."""
    # Step 1: create a scope
    d = {}

    # Step 2: create a factory
    def factory(self, scope, name):
        scope[name] = 'a real object'
        return scope[name]

    # Step 3: create an instance of ScopeReplacer
    replacer = ScopeReplacer(d, factory, 'foo')
    # Check that it is in the scope
    assert d['foo'] is replacer



# Generated at 2022-06-21 21:55:10.469421
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ of ScopeReplacer doesn't raise an exception"""
    scope = {}
    def foo(obj, scope, name):
        ScopeReplacer._should_proxy = False
        return obj
    ScopeReplacer(scope, foo, 'bar')
    raise test_must_fail(IllegalUseOfScopeReplacer, "__init__ of class "
                         "ScopeReplacer doesn't raise an exception")


# Generated at 2022-06-21 21:55:21.596461
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """ScopeReplacer objects should complain if they are used as proxies."""
    disallow_proxying()

# Generated at 2022-06-21 21:55:27.950037
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    try:
        ip.lazy_import(globals(), 'import (os, sys as system)')
    except errors.InvalidImportLine:
        pass
    else:
        raise AssertionError('Died on unmatched parenthesis')
    ip.lazy_import(globals(), 'import os, sys as system')

# Test that ImportProcessor does the right thing for from foo import bar

# Generated at 2022-06-21 21:55:37.721967
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__

    Class IllegalUseOfScopeReplacer has a __repr__ method which gives the
    exception it's name and a printable str() of the instance. This test makes
    sure that the printable string representation is of the format
    'IllegalUseOfScopeReplacer("descriptive message")'. When using
    __repr__ to re-raise exceptions, the message to the user is the printable
    version, so this test is to make sure the message is intelligible.
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    exc = IllegalUseOfScopeReplacer("name of object",
                                    "descriptive message",
                                    "extra")
    expected = "IllegalUseOfScopeReplacer('IllegalUseOfScopeReplacer object " \
              

# Generated at 2022-06-21 21:55:50.073967
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import (
        testtools,
        )

    # Test that __getattribute__ forces the resolution of the scope replacer.
    scope = {}
    scope['key'] = None
    class TestObj(object):
        def __init__(self):
            self.done = False

        def foo(self):
            self.done = True
            return "foo"

        def bar(self):
            return "bar"

    def mock_factory(sr, scope, name):
        scope['key'] = scope[name]
        return TestObj()

    scope['foo'] = ScopeReplacer(scope, mock_factory, 'foo')
    scope['foo'].bar()
    scope['foo'].foo()

# Generated at 2022-06-21 21:56:00.259477
# Unit test for function lazy_import
def test_lazy_import():
    class DummyModule(object):
        def __init__(self, name):
            self.name = name

    class BrokenModule(object):
        def __init__(self, name):
            self.name = name

        def __getattribute__(self, attr):
            raise AttributeError('No %r in %s' % (attr, self.name))

    class LazyImportClass(ScopeReplacer):
        def _import(self, scope, name):
            try:
                return scope[name]
            except KeyError:
                return DummyModule(name)

    # This is a boring test because it uses the ImportProcessor directly.
    # However, it suffices for now and is repeatable.
    # The real test is the lazy_import function itself.


# Generated at 2022-06-21 21:56:11.963001
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Assert IllegalUseOfScopeReplacer.__unicode__() works"""
    # ok
    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar', 'extra')
    except IllegalUseOfScopeReplacer as e:
        if e.name != 'foo':
            raise AssertionError('e.name == %r != foo' % (e.name,))
        if e.msg != 'bar':
            raise AssertionError('e.msg == %r != bar' % (e.msg,))
        if e.extra != ': extra':
            raise AssertionError('e.extra == %r != \'\': extra' % (e.extra,))

# Generated at 2022-06-21 21:56:17.254511
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    class Foo(object):
        pass
    foo = Foo()
    error = IllegalUseOfScopeReplacer('name', 'msg', foo)
    expected = ("ScopeReplacer object 'name' was used incorrectly:"
                " msg: " + repr(foo))
    assert str(error) == expected



# Generated at 2022-06-21 21:56:36.240652
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer___call__(TestCase):
        def test__ScopeReplacer___call__(self):
            import bzrlib.tests.blackbox.test_lazy_import as t
            import bzrlib.tests.blackbox.test_lazy_import as u
            self.assertIsNot(t, u)

    import bzrlib.tests.blackbox.test_lazy_import as module
    module.test_suite = TestScopeReplacer___call__
# end Unit test for method __call__ of class ScopeReplacer



# Generated at 2022-06-21 21:56:44.731468
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.lazy_import import ImportReplacer

    def check_import(name, module_path, member=None, children={}):
        """Assert that ImportReplacer initializes ok."""
        ImportReplacer({}, 'foo', module_path=module_path,
                       member=member, children=children)

    check_import('foo', ['foo'])
    check_import('foo', ['foo'], children={'bar':(['foo', 'bar'], None, {})})
    check_import('bar', ['foo'], member='bar')

    # Can't have both member and children

# Generated at 2022-06-21 21:56:56.224093
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {'bar': 'unexpected'}
    name = 'foo'
    module_path = ['foo']
    human_path = '.'.join(module_path)
    try:
        ImportReplacer(scope=scope, name=name,
                       module_path=module_path,
                       member='bar')
    except ValueError as e:
        assert str(e) == ("Cannot supply both a member and children")
    else:
        raise AssertionError("Member and children constructor parameters should"
            " not be allowed")

    importreplacer = ImportReplacer(scope=scope, name=name,
                                    module_path=module_path)
    # Import the module manually
    orig_foo = __import__(human_path, scope, scope, [], level=0)

    # Ensure that they both have the same