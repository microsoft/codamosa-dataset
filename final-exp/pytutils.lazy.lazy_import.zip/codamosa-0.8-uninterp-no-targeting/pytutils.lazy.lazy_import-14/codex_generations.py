

# Generated at 2022-06-21 21:47:15.448561
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    import doctest
    from bzrlib import lazy_import
    from bzrlib.tests import TestCase
    TestCase.run_doctest(lazy_import, "test_IllegalUseOfScopeReplacer___eq__")


# Generated at 2022-06-21 21:47:25.820234
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Unit test for constructor of class ImportReplacer"""
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'])
    if scope['foo'] != 'foo':
        raise AssertionError('Basic import failed')

    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], member='bar')
    if scope['foo'] != 'foobar':
        raise AssertionError('Basic import member failed')

    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], member='bar', children={})
    if scope['foo'] != 'foobar':
        raise AssertionError('Basic import member failed')

    if object.__getattribute__(scope['foo'], '_import_replacer_children'):
        raise AssertionError('children dict not cleared')


# Generated at 2022-06-21 21:47:37.108536
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # We instantiate the lazy import exception with a 'name' parameter
    # that is a regular Unicode string and not a subclass of
    # basestring.
    exception = IllegalUseOfScopeReplacer(u"branch", u"a message")
    # The __repr__'ed version of the exception should be able to be
    # eval'd into the same exception object.
    assert eval(repr(exception)) == exception
test_IllegalUseOfScopeReplacer___repr__.__doc__ = \
    IllegalUseOfScopeReplacer.__repr__.__doc__

# Generated at 2022-06-21 21:47:50.796977
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_errors import TestCaseWithTransport
    class ExpectedException(TestCaseWithTransport.TestCase):
        def test_exception(self):
            raise IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    try:
        e = ExpectedException()
        e.test_exception()
    except IllegalUseOfScopeReplacer as err:
        e = err
    self.assertEqual(e, IllegalUseOfScopeReplacer('name', 'msg', 'extra'))
    self.assertEqual(
        e, IllegalUseOfScopeReplacer(u'name', 'msg', 'extra'))
    self.assertEqual(
        e, IllegalUseOfScopeReplacer('name', u'msg', 'extra'))
   

# Generated at 2022-06-21 21:48:01.442871
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # Test the constructor when called with a unicode string.
    err = IllegalUseOfScopeReplacer(u'foo', u'bar', u'extra')
    assert err.name == u'foo', \
        'name should be unicode: got %r' % err.name
    assert err.msg == u'bar', \
        'msg should be unicode: got %r' % err.msg
    assert err.extra == u': extra', \
        'extra should be unicode: got %r' % err.extra
    assert str(err) == "ScopeReplacer object u'foo' was used incorrectly:" \
        " bar: extra", \
        '__str__ returned %r' % str(err)

# Generated at 2022-06-21 21:48:08.197312
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Only tests that the constructor doesn't crash
    for args in [
            ({}, 'foo', ['foo'], None, {}),
            ({}, 'foo', ['foo'], 'bar', {}),
            ({}, 'foo', ['foo', 'bar'], None, {}),
            ({}, 'foo', ['baz', 'bar'], None, {}),
            ]:
        ImportReplacer(*args)



# Generated at 2022-06-21 21:48:16.185144
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class MyException(IllegalUseOfScopeReplacer):
        pass
    e1 = MyException('msg')
    e2 = MyException('msg')
    e3 = IllegalUseOfScopeReplacer('msg', 'msg')
    e4 = MyException('msg2')
    e5 = MyException('msg', 'extra')
    e6 = MyException('msg', 'extra')
    assert e1 == e2
    assert e1 != e3
    assert e1 != e4
    assert e1 != e5
    assert e5 == e6
test_IllegalUseOfScopeReplacer___eq__.todo = "Str format not implemented"



# Generated at 2022-06-21 21:48:26.693123
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Testing method IllegalUseOfScopeReplacer.__unicode__"""
    import sys
    # This test should be expanded to test all the different ways of
    # formatting the exception
    from bzrlib.i18n import gettext
    gettext(unicode("Hello")) # Can't translate a unicode string
    # First test the default
    default_exception = IllegalUseOfScopeReplacer("IllegalUseOfScopeReplacer",
                                                  "test")
    assert 'test' in unicode(default_exception)
    # Now test a formatted string
    class SubException(IllegalUseOfScopeReplacer):
        _fmt = "test _fmt %(msg)s"
    fmt_exception = SubException("SubException", "test",
                                 extra=default_exception)
    assert 'test _fmt test'

# Generated at 2022-06-21 21:48:29.060283
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test '__setattr__' of class ScopeReplacer"""
    # TODO: write unit test
    pass


# Generated at 2022-06-21 21:48:37.167171
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    global test_ScopeReplacer
    def test_fail(expr, msg):
        try:
            expr
        except Exception as e:
            assert e.msg == msg
        else:
            raise AssertionError('Expected exception')
    def factory(replacer, scope, name):
        return replacer
    scope = {}
    test_fail(lambda: ScopeReplacer(scope, factory, 'name'),
            'Object tried to replace itself, check it\'s not using its own'
            ' scope.')
del test_ScopeReplacer



# Generated at 2022-06-21 21:48:56.449565
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class TestException(Exception):
        pass
    class TestObject(object):
        def __call__(self, *args, **kwargs):
            return "called object"
        def method(self):
            return "replaced object"

    # Check that ScopeReplacer is behaving as expected when constructed
    # with valid parameters.
    scope = {}
    name = 'testobj'
    replacer = ScopeReplacer(scope, lambda self, scope, name: TestObject(), name)
    assert scope['testobj'] is replacer

    # Check that ScopeReplacer calls the factory function to generate the
    # replacement object, that it does not call the factory function more than
    # once, and that the name and scope are passed correctly.
    scope = {}
    name = 'testobj'
    call_count = [0]

# Generated at 2022-06-21 21:49:03.324117
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test import processing"""
    i = ImportProcessor()
    i.lazy_import(globals(),
"""# comments are ok

# should ignore blanks

import foo, bar

from baz import quux, corge as grault

# A trailing , is ok
import quux,
""")

    expected = {'bar': (['bar'], None, {}),
                'foo': (['foo'], None, {}),
                'grault': (['baz'], 'corge', {}),
                'quux': (['baz'], 'quux', {}),
                }
    assert expected == i.imports

# Generated at 2022-06-21 21:49:12.210208
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy_import()."""
    from bzrlib.tests import TestSkipped
    try:
        import bzrlib.tests.test_lazy_import
    except ImportError:
        raise TestSkipped("bzrlib.tests.test_lazy_import cannot be imported")


__all__ = ['ScopeReplacer', 'ImportReplacer', 'lazy_import',
           'ImportProcessor']

# Generated at 2022-06-21 21:49:16.536123
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    e = IllegalUseOfScopeReplacer('name', 'message')
    # __repr__ must return a str.
    assert isinstance(e.__repr__(), str)
    s = repr(e)
    assert s == "IllegalUseOfScopeReplacer('name', 'message')"


# Generated at 2022-06-21 21:49:28.217072
# Unit test for function disallow_proxying
def test_disallow_proxying():
    def check_illegal(scope):
        raise IllegalUseOfScopeReplacer('scope', msg="Error was raised"
            " when attempting to use a proxy object as a variable.")
    from bzrlib.trace import mutter
    # We need to unset _should_proxy for this test to work
    saved_proxy = ScopeReplacer._should_proxy
    try:
        ScopeReplacer._should_proxy = False
        scope = {}
        lazy_import(scope, """
        scope = {}
        scope['obj'] = scope
        import bzrlib.lazy_import
        bzrlib.lazy_import.disallow_proxying()
        """)
        check_illegal(scope['obj'])
    finally:
        ScopeReplacer._should_proxy = saved_proxy



# Generated at 2022-06-21 21:49:37.325714
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import sys
    import bzrlib
    import bzrlib.trace
    # Just test that it doesn't throw an exception
    ImportReplacer(sys.modules, name='bzrlib', module_path=['bzrlib'],
                   children={'trace':(['bzrlib', 'trace'], None, {})})
    bzrlib.trace
    # Make sure that it really imported
    assert(sys.modules['bzrlib.trace'] is bzrlib.trace)



# Generated at 2022-06-21 21:49:41.626968
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test the constructor of class IllegalUseOfScopeReplacer.

    This unit test is here to prevent regresions in the initialisation of
    IllegalUseOfScopeReplacer.
    Currently it tests only the exact signature of the constructor.
    """
    IllegalUseOfScopeReplacer('name', 'msg', 'extra')



# Generated at 2022-06-21 21:49:49.138076
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer class."""
    def test_illegal_import():
        """Makes sure that it is illegal to specify a member and children"""
        replacer = ImportReplacer({}, 'foo', 'foo', 'bar', {})
        def assert_legal(replacer):
            return replacer
        from bzrlib.tests import TestCase
        TestCase.assertRaises(ValueError, assert_legal, replacer)

    test_illegal_import()



# Generated at 2022-06-21 21:50:01.269180
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    import doctest
    error_msg = 'IllegalUseOfScopeReplacer.__eq__ is broken'
    eg =  IllegalUseOfScopeReplacer('a','b','c')
    assert eg == IllegalUseOfScopeReplacer('a','b','c'), error_msg
    assert not (eg == IllegalUseOfScopeReplacer('a','b','cx')), error_msg
    assert not (eg == IllegalUseOfScopeReplacer('ax','b','c')), error_msg
    assert not (eg == IllegalUseOfScopeReplacer('ax','bx','c')), error_msg
    assert not (eg == 'a'), error_msg


__all__ = ['ScopeReplacer', 'lazy_import', 'lazy_format',
           'first_in_list_with_attr',
           'LazyObjects']


# Generated at 2022-06-21 21:50:05.293258
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Check IllegalUseOfScopeReplacer.__str__ against IllegalArgumentException.__str__"""
    x = IllegalUseOfScopeReplacer('obj', 'msg', 'extra')
    y = IllegalArgumentException('obj', 'msg', 'extra')
    assert x.__str__() == y.__str__()


# Generated at 2022-06-21 21:50:16.154208
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    try:
        import bzrlib
    except ImportError:
        pass # We're not actually expecting to import bzrlib, this is just
             # a scope we can use.
    else:
        raise AssertionError('Expected "import bzrlib" to fail')

    my_scope = {}
    # Note: This is *not* the same as 'from bzrlib import errors' - this
    # actually creates a lazy import object that will replace itself with
    # the bzrlib module.

# Generated at 2022-06-21 21:50:28.874154
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    def check_equal(a, b):
        return a == b and b == a
    def check_not_equal(a, b):
        return a != b and b != a

    assert check_equal(IllegalUseOfScopeReplacer('name', 'msg'),
                       IllegalUseOfScopeReplacer('name', 'msg'))
    assert check_not_equal(IllegalUseOfScopeReplacer('name', 'msg'),
                           IllegalUseOfScopeReplacer('other', 'msg'))
    assert check_not_equal(IllegalUseOfScopeReplacer('name', 'msg'),
                           IllegalUseOfScopeReplacer('name', 'other'))
    # Check that the extra argument to the constructor is ignored

# Generated at 2022-06-21 21:50:31.443982
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class A(IllegalUseOfScopeReplacer):
        pass
    a1 = A(1, 2, 3)
    a2 = A(1, 2, 3)
    assert a1 == a2



# Generated at 2022-06-21 21:50:36.933736
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """See that the ImportProcessor class works as advertised.

    We should be able to do:
        bzrlib.foo.bar
        bzrlib.foo.bar.baz
        bzrlib.foo.bar as bar

    We should be able to do:
        import bzrlib.foo.bar
        import bzrlib.foo.bar.baz as baz
        from bzrlib import foo.bar, foo.baz.bar

    We should not be able to:
        from bzrlib import foo.bar as bar
    """
    from bzrlib.tests import TestCase
    test_case_instance = TestCase()
    test_case_instance.module_path = 'bzrlib'

    test_case_instance.activator_instance = ImportProcessor()
    test_

# Generated at 2022-06-21 21:50:49.793207
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-21 21:50:54.980480
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__: should return unicode

    It should return a unicode object, even if the format string is a
    str object.
    """
    exc = IllegalUseOfScopeReplacer(u'foo', 'msg', u'extra')
    u = unicode(exc)



# Generated at 2022-06-21 21:51:02.036515
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import _mod_lazy_import
    scope = {}
    cnt = []
    def f(_self, scope, name):
        assert _self is scope[name]
        assert scope is scope[name]._scope
        assert name == scope[name]._name
        assert _self is scope[name]._resolve()
        cnt.append(5)
        return 4
    _mod_lazy_import.ScopeReplacer(scope, f, 'name')
    assert len(cnt) == 0
    assert scope['name']() == 4
    assert len(cnt) == 1



# Generated at 2022-06-21 21:51:05.031003
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the ImportProcessor constructor

    For now, this just tests the constructor.
    """
    ip = ImportProcessor()


# Generated at 2022-06-21 21:51:10.546120
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Testing that IllegalUseOfScopeReplacer.__unicode__ returns a unicode object"""
    o = IllegalUseOfScopeReplacer(1, 2)
    s = o.__unicode__()
    expected = u'Unprintable exception IllegalUseOfScopeReplacer: dict={1: 1, 2: 2}, fmt=None, error=None'
    if s != expected:
        raise AssertionError('expected %(expected)r, got %(s)r' % locals())



# Generated at 2022-06-21 21:51:22.238945
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib.tests import test_lazy_import
    scope = {
        '__name__':'__main__',
        '__doc__':None,
        '__package__':None,
        '__file__':'bzrlib/tests/lazy_import.py'
        }

# Generated at 2022-06-21 21:51:38.526953
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    # __eq__ should compare content, not id
    IllegalUseOfScopeReplacer('name', 'msg') == IllegalUseOfScopeReplacer('name', 'msg')
    IllegalUseOfScopeReplacer('name', 'msg') != IllegalUseOfScopeReplacer('name2', 'msg')



# Generated at 2022-06-21 21:51:42.948240
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    try:
        raise IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'name'
        assert e.msg == 'msg'
        assert e.extra == ': extra'


# Generated at 2022-06-21 21:51:48.900730
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class A:
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
    x = A()
    y = {}
    z = ScopeReplacer(y, lambda x, y, z: x, 'a')
    y['a'] = x
    return z(*(1, 2), **{'foo':'bar'}) == ((1, 2), {'foo':'bar'})
test_ScopeReplacer___call__()


# Generated at 2022-06-21 21:51:54.706030
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
    """
    from bzrlib.tests import TestUtil
    e = IllegalUseOfScopeReplacer('name', 'message')
    u = unicode(e)


# Generated at 2022-06-21 21:52:06.221504
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    '''Test method __getattribute__ on class ScopeReplacer.'''

    class FakeScope(object):

        def __init__(self, name):
            self.name = name

        def __getitem__(self, name):
            raise AssertionError(
                'should not load %r from scope %r' % (name, self.name))

    class A(object):
        pass

    fake_scope = FakeScope('fake_scope')
    obj = A()
    obj.test_attribute = 'test_value'
    obj_replacer = ScopeReplacer(fake_scope, lambda _obj, _scope, _name: obj,
                                 'test_attribute')
    # Ensure getattribute works.
    eq = test_suite.TestCase.assertEquals

# Generated at 2022-06-21 21:52:13.829209
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    import sys
    module_name = 'bzrlib.lazy_import'
    other_name = 'other_module'
    # TODO: Simplify test to not use this form.
    lazy_import(sys.modules[__name__].__dict__,
        '''
        from bzrlib import (
            errors,
            osutils,
            branch,
            transport,
            )
        ''')
    lazy_import.lazy_import(sys.modules[module_name].__dict__,
        '''
        import %s
        ''' % (other_name,))

# Generated at 2022-06-21 21:52:22.615457
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a string representation of the error"""
    from bzrlib.tests import TestCase
    from bzrlib.tests.features import UnicodeFeature
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    if UnicodeFeature.available():
        t = TestCase('__str__')
        e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
        t.assertEqual('ScopeReplacer object \'name\' was used incorrectly:'
                      ' msg: extra', str(e))
        t.assertEqual(
            u'ScopeReplacer object \'name\' was used incorrectly:'
            u' msg: extra', unicode(e))


# Generated at 2022-06-21 21:52:31.479911
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """ScopeReplacer exceptions should be able to be converted to unicode."""
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='some more')
    u = unicode(e)
    # The error should be human readable.
    # The message should be in it.
    # The name should be in it.
    # The extra should be in it.
    assert 'msg' in u
    assert 'name' in u
    assert 'some more' in u

# Generated at 2022-06-21 21:52:42.466397
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    The simplest form.
    """
    msg = 'Foo, Bar'
    e = IllegalUseOfScopeReplacer('module', msg)
    u = unicode(e)
    assert u == 'module: Foo, Bar'
    assert not isinstance(u, str)
    assert isinstance(u, unicode)

    # A more complicated form
    e = IllegalUseOfScopeReplacer('module', msg, extra='baz')
    u = unicode(e)
    assert u == 'module: Foo, Bar: baz'
    assert not isinstance(u, str)
    assert isinstance(u, unicode)



# Generated at 2022-06-21 21:52:54.533977
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import (
        TestCase,
        )
    # Test that __call__ works.

    class _FakeObj(object):

        def __call__(self, *args, **kwargs):
            return (args, kwargs)

    def _fakeobj_factory(replacer, scope, name):
        return _FakeObj()

    scope = {}
    scope_replacer = ScopeReplacer(scope, _fakeobj_factory, 'obj')
    args = (1, 2, 3)
    kwargs = {'a': 1, 'b': 2, 'c': 3}
    self.assertEqual((args, kwargs), scope_replacer(*args, **kwargs))



# Generated at 2022-06-21 21:53:03.624356
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """test_ImportProcessor_lazy_import"""
    raise NotImplementedError(
        "Test for method ImportProcessor.lazy_import not implemented")

# Generated at 2022-06-21 21:53:08.022260
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert_equal(e.name, 'name')
    assert_equal(e.msg, 'msg')
    assert_equal(e.extra, ': extra')


# Generated at 2022-06-21 21:53:19.419360
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from StringIO import StringIO
    from bzrlib import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib
    ''')
    buf = StringIO()
    buf.write("%s\n" % (errors,))
    buf.write("%s\n" % (osutils,))
    buf.write("%s\n" % (branch,))
    buf.write("%s\n" % (bzrlib,))
    s = buf.getvalue()
    del buf
    # Do not assign before this
    lazy_import.disallow_proxying()
    buf = StringIO()

# Generated at 2022-06-21 21:53:29.536620
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCaseInTempDir
    class Testable(object):
        def __init__(self):
            self.args = []
            self.kwargs = {}
        def __call__(self, *args, **kwargs):
            self.args.append(args)
            self.kwargs.update(kwargs)
            return self
    class Test(TestCaseInTempDir):
        def setUp(self):
            super(Test, self).setUp()
            self.scope = {}
            self.testable = Testable()
        def test_called(self):
            def factory(repl, scope, name):
                return self.testable
            repl = ScopeReplacer(self.scope, factory, 'test')
            repl(1, a=True)

# Generated at 2022-06-21 21:53:41.238672
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('myname', 'mymsg', extra='myextra')
    # Check equality
    e2 = IllegalUseOfScopeReplacer('myname', 'mymsg', extra='myextra')
    assert e == e2
    # Check inequality
    e3 = IllegalUseOfScopeReplacer('othername', 'mymsg', extra='myextra')
    assert e != e3
    e4 = IllegalUseOfScopeReplacer('myname', 'othermsg', extra='myextra')
    assert e != e4
    e5 = IllegalUseOfScopeReplacer('myname', 'mymsg', extra='otherextra')
    assert e != e5
    # Check repr
    assert repr(e) == "IllegalUseOfScopeReplacer('myname', 'mymsg', extra='myextra')"
    # Check str


# Generated at 2022-06-21 21:53:52.763691
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.test_lazy_import import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.branch import Branch

    # Create a lazy object and call it.
    scope = dict()
    lazy_import(scope, 'from bzrlib.branch import Branch')
    scope['Branch']()

    # Try to call a module (possible with older lazy_import methods)
    scope = dict()
    lazy_import(scope, 'import os')
    self.assertRaises(AttributeError, scope['os'])

    # Try to call a class.
    scope = dict()
    lazy_import(scope, 'from bzrlib.branch import Branch')
    scope['Branch']()

    # Try to call a function.

# Generated at 2022-06-21 21:54:00.641388
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy import function"""
    # Do some stubbing to make the lazy importer happy
    saved_import = __builtin__.__import__
    class Dummy(object):
        def __init__(self, name):
            self.name = name
        def __setattr__(self, name, value):
            if name not in self.__dict__:
                raise AssertionError(
                    '%s accessed %s on %s' % (self.name, name, value))
            self.__dict__[name] = value
    def import_stub(name, *args, **kwargs):
        return Dummy(name)
    def import_failure_stub(*args, **kwargs):
        raise SyntaxError('syntax error during import')
    __builtin__.__import__ = import_fail

# Generated at 2022-06-21 21:54:06.565149
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that ImportProcessor only produces valid import strings.

    This is a direct unit test of the class, so it will not live in a
    test/__init__.py, but instead __init__.py::

        if __name__ == '__main__':
            test_suite()
    """
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-21 21:54:13.702230
# Unit test for constructor of class ScopeReplacer

# Generated at 2022-06-21 21:54:23.777957
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests import TestCase

    class Ex(Exception):
        def __init__(self, v1, v2):
            self.v1 = v1
            self.v2 = v2
        def __eq__(self, other):
            return (self.__class__ == other.__class__
                    and self.__dict__ == other.__dict__)

    ex1 = Ex(1, [2])
    ex2 = Ex(1, [2])
    ex3 = Ex(1, [3])
    ex4 = Ex(1, 'foo')

    class TestIllegalUseOfScopeReplacer(TestCase):

        def test___eq__(self):
            self.assertEqual(ex1, ex2)
            self.assertNotEqual(ex1, ex3)

# Generated at 2022-06-21 21:54:39.134175
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should be sane."""
    # Even though the exception is using self._fmt, we don't really care
    # about the format string here, we just care that we get back a 'str'
    # exception.
    e = IllegalUseOfScopeReplacer("foo", "bar")
    r = repr(e)
    assert isinstance(r, str)

# Generated at 2022-06-21 21:54:45.490144
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str)
    assert 'foo' in s
    assert 'bar' in s
    e = IllegalUseOfScopeReplacer('foo', u'bar')
    s = str(e)
    assert isinstance(s, str)
    assert 'foo' in s
    assert 'bar' in s

# Generated at 2022-06-21 21:54:53.304376
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """ScopeReplacer.__call__(...)

    Basically a copy of the unit test for the ScopeReplacer class,
    just running all the test functions as methods on the object.
    """


    from bzrlib import lazy_import
    from bzrlib.tests import TestCase


    def create(self, scope, name):
        class TestCase(object):
            def run(self, result):
                self.count = getattr(self, 'count', 0) + 1
                self.count2 = getattr(self, 'count2', 0) + 2

        return TestCase()


    class TestScopeReplacer(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            self.scope = {}

# Generated at 2022-06-21 21:55:01.087703
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should be able to be eval'd back to the same object"""
    class Foo(IllegalUseOfScopeReplacer):
        def __init__(self, name, msg, extra=None):
            IllegalUseOfScopeReplacer.__init__(self, name, msg, extra)
    f = Foo('fred', 'flintstone')
    r = repr(f)
    f1 = eval(r)
    assert isinstance(f1, Foo)
    assert f == f1


# Generated at 2022-06-21 21:55:06.050546
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = IllegalUseOfScopeReplacer('asdf', 'asdf', 'a').__unicode__()
    assert isinstance(u, unicode)
    u = IllegalUseOfScopeReplacer('asdf', 'asdf', 'a').__str__()
    assert isinstance(u, str)


# Generated at 2022-06-21 21:55:13.405234
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() works correctly"""
    # Exceptions are hard to test.  This tests something close enough.
    import sys
    try:
        raise IllegalUseOfScopeReplacer('name', 'msg')
    except Exception as e:
        s = str(e)
    s_expected = ("ScopeReplacer object 'name' was used incorrectly:"
                  " msg")
    if s != s_expected:
        print ('expected: %s' % s_expected)
        print ('received: %s' % s)
        raise AssertionError('test failed')



# Generated at 2022-06-21 21:55:23.537953
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    g = {}
    ImportReplacer(g, 'foo', ['foo'])
    ImportReplacer(g, 'foo.bar', ['foo'], children={'baz':(['foo'], 'baz', {})})
    ImportReplacer(g, 'foo.bar', ['foo'], member='bar')
    from bzrlib.tests.test_missing_import import TestImportReplacer
    TestImportReplacer().test_constructor_ImportReplacer()

# _import_replacers is used to cache all the import replacers that
# have been created for a given scope. This is needed to work around
# the fact that lazy import does not create Replacer objects for
# every import, but rather creates an ImportReplacer that will then
# create the Replacer objects as needed. This can break if a
# ImportReplacer creates a Replacer object

# Generated at 2022-06-21 21:55:34.644277
# Unit test for function disallow_proxying
def test_disallow_proxying():
    # Check that an already replaced object causes IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    import bzrlib.lazy_import
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-21 21:55:40.434819
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class MyClass(object):
        def __init__(self):
            self.test = 'test'
    scope = {}
    scope_replacer = ScopeReplacer(
        scope, lambda _, __, ___: MyClass(), 'test-module')
    scope_replacer.test = 'test2'
    scope_replacer.test_module
    scope['test-module'].test == 'test2'

# Generated at 2022-06-21 21:55:52.404114
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import sys

    class Test_ScopeReplacer___call__(TestCase):
        def setUp(self):
            def factory(self, scope, name):
                return lambda x:x
            self.real_obj = ScopeReplacer(sys.modules, factory, "foo")
        def test_simple(self):
            self.assertEqual(self.real_obj("1"), "1")
        def test_simple_with_args(self):
            self.assertEqual(self.real_obj("1", 1), "1")
        def test_simple_with_kwargs(self):
            self.assertEqual(self.real_obj("1", kw=1), "1")

# Generated at 2022-06-21 21:56:09.594103
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.per_interpreter
    class FakeClass(object):
        def mymethod(self):
            return "foo"
    fc = FakeClass()
    actual = ScopeReplacer(bzrlib.tests.per_interpreter.__dict__,
                           lambda *args: fc, 'fc')()
    bzrlib.tests.per_interpreter.fc = fc
    expected = bzrlib.tests.per_interpreter.fc()
    # Note: we expect "foo" here, not the fc object, because the ScopeReplacer
    # is a callable that returns the resolved object, which is in this case
    # an instance of FakeClass.
    assert actual == expected



# Generated at 2022-06-21 21:56:20.588229
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import correctly replaces imports"""
    # Make a new scope to run in
    class TestScope(object):
        def __init__(self):
            self.imported_modules = {}
        def __getitem__(self, item):
            return self.imported_modules[item]
    scope = TestScope()
    # Now populate it with some imports
    lazy_import(scope, '''
        import bzrlib.foo, bzrlib.bar, bzrlib.baz
        ''')

    # ok, now check that foo, bar and baz all have the same class
    # we can't test equality, because they are all unique instances
    # of the same class
    class_of_first_member = type(scope['bzrlib.foo'])

# Generated at 2022-06-21 21:56:25.338126
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This test that method __str__ of class IllegalUseOfScopeReplacer
    works correctly and consistently
    """
    a = IllegalUseOfScopeReplacer('scope_name', 'message')
    assert str(a) == "ScopeReplacer object u'scope_name' was used incorrectly: message"



# Generated at 2022-06-21 21:56:30.167967
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('a', 'b')
    assert e.name == 'a'
    assert e.msg == 'b'
    assert e.extra == ''



# Generated at 2022-06-21 21:56:40.745325
# Unit test for function lazy_import
def test_lazy_import():
    """This tests lazy_import directly."""
    a = {'foo':42}
    # Basic import
    lazy_import(a, '''
        from bzrlib import (
            foo,
            bar,
            baz as bing,
            )
        ''')
    assert isinstance(a['foo'], ScopeReplacer)
    assert isinstance(a['bar'], ScopeReplacer)
    assert isinstance(a['bing'], ScopeReplacer)
    # Make sure that the import worked
    from bzrlib import commands
    a['foo']._replace(commands)
    assert a['foo'].stack_on_broken_pipe is commands.stack_on_broken_pipe
    assert a['bar'].stack_on_broken_pipe is commands.stack_on_broken_pipe

# Generated at 2022-06-21 21:56:47.500346
# Unit test for function lazy_import
def test_lazy_import():
    scope = {}
    lazy_import(scope, '''
        import bzrlib.branch
        import bzrlib.transport
        from bzrlib import (
            foo,
            bar,
            baz,
            )
        ''')
    # Our scope should now have 4 things in it.
    # Note: the builtins are always there.
    assert len(scope) == 6, "not all of the imports got added"
    assert '__builtins__' in scope

    # Now we loop over the scope, and each one should be a ScopeReplacer
    # which will load the module on first use
    for name in scope:
        scope_obj = scope[name]
        # ScopeReplacer is an old style class, so can't use
        # isinstance.
        assert 'ScopeReplacer' in scope_

# Generated at 2022-06-21 21:56:51.328137
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import unittest
    # Make sure we can get the real attribute when it's there
    class Foo:
        x = 1

    class TestCase(unittest.TestCase):
        def test(self):
            # Make sure the class is created and we can call a method
            self.assertEqual(1, ScopeReplacer({}, lambda s, s, n: Foo, 'Foo').x)

    TestCase('test').run()