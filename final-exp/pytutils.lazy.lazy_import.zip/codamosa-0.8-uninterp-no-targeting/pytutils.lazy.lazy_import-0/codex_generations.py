

# Generated at 2022-06-21 21:47:18.895583
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.per_lazy_import
    return bzrlib.tests.per_lazy_import.test_ScopeReplacer___setattr__()

# Generated at 2022-06-21 21:47:21.629791
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() works."""
    exc = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    unicode(exc)


# Generated at 2022-06-21 21:47:27.137247
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test construction of ScopeReplacer

    Note that this doesn't work as a unit test, as the module isn't actually
    imported into the relevant scope at this point.  So, this is just for
    manual testing of the lazy import feature.
    """
    import bzrlib.tests.test_lazy_import
    assert bzrlib.tests.test_lazy_import.__name__ == 'test_lazy_import'



# Generated at 2022-06-21 21:47:31.965522
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Simple test, more involved tests done in the test suite.
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    unicode(e)
    unicode(e)



# Generated at 2022-06-21 21:47:33.691590
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    i = ImportProcessor()
    assert isinstance(i._lazy_import_class, type)
    assert i._lazy_import_class is not None
    assert i._lazy_import_class is not ImportReplacer
    assert i.imports is not None
    assert i.imports == {}


# Generated at 2022-06-21 21:47:43.666808
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for IllegalUseOfScopeReplacer.__eq__

    returns NotImplemented when not equal,
    returns True when equal.
    """
    # test NotImplemented
    exception1 = IllegalUseOfScopeReplacer('name1', 'message1')
    exception2 = IllegalUseOfScopeReplacer('name2', 'message2')
    # test_equals returns NotImplemented
    test_equals = exception1.__eq__(exception2)
    # test NotImplemented
    if test_equals is not NotImplemented:
        raise AssertionError('test_equals must be NotImplemented when not equal')
    # test returns True
    exception1 = IllegalUseOfScopeReplacer('name1', 'message1')

# Generated at 2022-06-21 21:47:55.285998
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class SubException(IllegalUseOfScopeReplacer):
        pass
    ex1 = SubException('name1', 'msg1', 'extra1')
    ex2 = SubException('name1', 'msg1', 'extra1')
    ex3 = SubException('name1', 'msg1', 'extra3')
    ex4 = SubException('name4', 'msg1', 'extra1')
    ex5 = SubException('name1', 'msg5', 'extra1')
    ex6 = SubException('name6', 'msg6', 'extra6')
    ex7 = IllegalUseOfScopeReplacer('name7', 'msg7')
    # the __eq__ method should be inherited
    # by SubException
    assert ex1 == ex2
    assert ex1 != ex3
    assert ex1 != ex4
    assert ex1 != ex5


# Generated at 2022-06-21 21:48:07.071072
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    processor = ImportProcessor()
    expected = {
        'foo':(['foo'], None, {'bar':(['foo', 'bar'], None, {}),
                               'baz':(['foo', 'baz'], None, {}),
                               'bing':(['foo', 'bing'], None, {})}),
        'bar':(['bar'], None, {'baz':(['bar', 'baz'], None, {})}),
        'bing':(['bing'], None, {'baz':(['bing', 'baz'], None, {})}),
        'baz':(['baz'], None, {})
        }
    processor._build_map(
        'import foo, (bar, bing, foo.bar, baz), foo.baz, foo.bing')
    #

# Generated at 2022-06-21 21:48:13.560302
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test IllegalUseOfScopeReplacer(name, msg, extra=None)"""
    err = IllegalUseOfScopeReplacer('name', 'msg')
    assert err.name == 'name'
    assert err.msg == 'msg'
    assert err.extra == ''
    err = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert err.name == 'name'
    assert err.msg == 'msg'
    assert err.extra == ': extra'



# Generated at 2022-06-21 21:48:20.195538
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # A simple import of a single module
    text = """
    import foo
    """
    ip = ImportProcessor()
    ip.lazy_import(globals(), text)
    assert ip.imports == {'foo': (['foo'], None, {})}

    # A simple import of a single module with a different name
    text = """
    import foo as bar
    """
    ip = ImportProcessor()
    ip.lazy_import(globals(), text)
    assert ip.imports == {'bar': (['foo'], None, {})}

    # A simple from import of a single module with a different name
    text = """
    from foo import bar as quux
    """
    ip = ImportProcessor()
    ip.lazy_import(globals(), text)
    assert ip.imports

# Generated at 2022-06-21 21:48:40.329702
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    cls = IllegalUseOfScopeReplacer
    a = cls("name", "msg", "extra")
    assert a == a # sanity
    assert not a != a # sanity
    b = cls("name", "msg", "extra")
    assert a == b
    assert not a != b
    b.name = "name2"
    assert a != b


# TODO(jelmer): Remove this once we've migrated completely to
#    from bzrlib.lazy_import import lazy_import
from bzrlib.trace import mutter as _mutter



# Generated at 2022-06-21 21:48:51.477696
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    global __bzrlib_test__
    __bzrlib_test__ = sys.modules['__bzrlib_test__']
    global __bzrlib__
    __bzrlib__ = sys.modules['__bzrlib__']
    global __bzrlib_branch__
    __bzrlib_branch__ = sys.modules['__bzrlib_branch__']
    global __bzrlib_builtins__
    __bzrlib_builtins__ = sys.modules['__bzrlib_builtins__']
    global __bzrlib_builtins_object__
    __bzrlib_builtins_object__ = sys.modules['__bzrlib_builtins_object__']
    global __bzrlib_errors__


# Generated at 2022-06-21 21:48:55.584748
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == ("ScopeReplacer object 'name' was used incorrectly:"
            " msg: extra")



# Generated at 2022-06-21 21:49:04.175121
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    # test __str__
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    u = unicode('ScopeReplacer object %(name)r was used incorrectly:'
                ' %(msg)s')
    s_expected = u % dict(e.__dict__)
    assert(s == s_expected)


try:
    any
except NameError:
    def any(iterable):
        for element in iterable:
            if element:
                return True
        return False


# Generated at 2022-06-21 21:49:12.390923
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    Unit test for bzrlib.lazy_import.IllegalUseOfScopeReplacer.__unicode__()
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('xxx', 'a msg')
    assert isinstance(e.__unicode__(), unicode)

# Generated at 2022-06-21 21:49:23.368729
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    ip.lazy_import(None, '''
import bzrlib as bzr # This is a comment
import bzrlib.foo

from bzrlib import bar

# This is a multi line import
import (bzrlib.quux,
bzrlib.foo.bar)

# This is a multi line import, that starts on the next line
from bzrlib import (foo,
bar,
baz)
''')
    # Now check that we have the correct results.
    if len(ip.imports) != 3:
        raise AssertionError('Wrong number of entries, got %r'
            % (ip.imports,))

    if ip.imports['bzr'][0] != ['bzrlib']:
        raise Assert

# Generated at 2022-06-21 21:49:29.325744
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ for IllegalUseOfScopeReplacer"""

    class DummyIllegalUseOfScopeReplacer(object):
        pass

    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    e3 = IllegalUseOfScopeReplacer('foo', 'baz')
    e4 = IllegalUseOfScopeReplacer('baz', 'bar')
    e5 = DummyIllegalUseOfScopeReplacer()
    e6 = DummyIllegalUseOfScopeReplacer()

    # test equality
    assert_true(e1 == e1)
    assert_true(e1 == e2)
    assert_false(e1 == e3)
    assert_false(e1 == e4)
    assert_false(e1 == e5)

# Generated at 2022-06-21 21:49:38.101142
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Method __repr__ of class IllegalUseOfScopeReplacer."""
    import doctest
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    globs = locals()
    if doctest.testmod(globs=globs)[0] != 0:
        raise TestNotPassed(__name__)
test_IllegalUseOfScopeReplacer___repr__.unittest = ['IllegalUseOfScopeReplacer']
del test_IllegalUseOfScopeReplacer___repr__



# Generated at 2022-06-21 21:49:43.923191
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class Foo(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
    scope = {}
    factory = lambda self, scope, name: Foo()
    replacer = ScopeReplacer(scope, factory, 'x')
    scope['x'] is replacer
    scope['x']('a', 'b', c='d') == (('a','b'), {'c':'d'})



# Generated at 2022-06-21 21:49:50.900366
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that the ImportProcessor is working as advertised."""
    ip = ImportProcessor()
    ip._build_map('import foo as bar, foo.bar as baldilocks')
    ip._convert_imports({})
    assert ip.imports == {'bar': (['foo'], None, {}),
                          'baldilocks': (['foo', 'bar'], None, {})}



# Generated at 2022-06-21 21:50:06.278327
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    scope = {}
    text = """
    import foo
    import foo.bar, foo.bar.baz as bing
    from foo import bar, baz
    """
    ip = ImportProcessor()
    ip.lazy_import(scope, text)

    children = ip.imports['foo'][2]

    # import foo
    # foo should refer to a ScopeReplacer
    assert isinstance(scope['foo'], ScopeReplacer)

    # import foo.bar
    assert isinstance(children['bar'][0], ScopeReplacer)

    # import foo.bar.baz as bing
    assert bing is scope['bing']

    # from foo import bar, baz
    assert isinstance(scope['bar'], ScopeReplacer)
    assert isinstance(scope['baz'], ScopeReplacer)


# Unit

# Generated at 2022-06-21 21:50:17.690094
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    m = {}
    # Simple import
    n = ImportReplacer(scope=m, name='foo', module_path=['foo'],
                       member=None, children={})
    # Importing a member
    n = ImportReplacer(scope=m, name='bar', module_path=['foo'],
                       member='bar', children={})
    # Importing a member, with a non-trivial name
    n = ImportReplacer(scope=m, name='baz.bar', module_path=['foo'],
                       member='bar', children={})
    # Import with children
    n = ImportReplacer(scope=m, name='baz', module_path=['foo'],
                       member=None, children={'bar':(['baz', 'bar'], None, {})})
    # Import with children and importing children

# Generated at 2022-06-21 21:50:30.200419
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    class MyImportReplacer(ImportReplacer):
        def __init__(self, scope, name, module_path, member=None, children={}):
            self.imports = {}
            for child_name, (child_path, child_member, grandchildren) in children.iteritems():
                self.imports[child_name] = (child_path, child_member, grandchildren)
            self.name = name
            self.member = member
            self.module_path = module_path
            self.scope = scope
            self._reset_to_None()

        def _reset_to_None(self):
            object.__setattr__(self, '_real_obj', None)

    my_import_replacer_class = MyImportReplacer
    import_processor = ImportProcessor(my_import_replacer_class)


# Generated at 2022-06-21 21:50:39.529121
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Ensure IllegalUseOfScopeReplacer subclasses Exception without changing
    its behaviour.
    """
    # The following is copied from bzrlib.tests.test_errors.test_exception

# Generated at 2022-06-21 21:50:42.492739
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    '''test for method __getattribute__ of class ScopeReplacer'''
    # Insert your code here
    return



# Generated at 2022-06-21 21:50:52.587098
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class A(ImportReplacer):
        pass

    class B(ImportReplacer):
        pass

    for cls in (A, B):
        # Force the children to get instantiated as the appropriate class
        scope = {}
        cls(scope, 'foo', ['foo'])
        cls(scope, 'foo', ['foo', 'bar'], member='baz')
        cls(scope, 'foo', ['foo'], children={
            'bar':(['foo', 'bar'], None, {}),
            'baz':(['foo', 'baz'], 'qux', {}),
            })

# Generated at 2022-06-21 21:50:58.345621
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import (
        lazy_import,
        )
    scope = {'a':1}
    def factory(obj, scope, name):
        return scope[name]
    lazy_object = ScopeReplacer(scope, factory, 'a')
    assert lazy_object(1) == 1
    # check the "real" object is still functional
    assert lazy_object(2) == 2


# Generated at 2022-06-21 21:51:00.409368
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # __str__ must return a str
    x = IllegalUseOfScopeReplacer(name=42, msg=u'abc')
    str(x)

# Generated at 2022-06-21 21:51:05.448544
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """This method is just an alias for _resolve.
    """
    factory = lambda self, scope, name: 'ok'
    sr = ScopeReplacer({}, factory, 'name')
    sr.__call__()



# Generated at 2022-06-21 21:51:13.577241
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    lazy_import(sys.modules[__name__], '''
    from bzrlib import (
        urlutils,
        )
    ''')
    disallow_proxying()
    # Assigning to another variable breaks the scope replacer
    try:
        urlutils2 = urlutils
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Using a scope replacer after proxying is'
                             ' disabled should raise an exception')
    # As does using it directly
    try:
        urlutils.join
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Using a scope replacer after proxying is'
                             ' disabled should raise an exception')
    # But assigning to itself should be fine
    urlutils = url

# Generated at 2022-06-21 21:51:30.288382
# Unit test for function lazy_import
def test_lazy_import():
    """Ensure that LazyImport works as we expect"""
    # TODO: jam 20060911 Create a better unit test that uses a better
    #       test framework and unit test object.
    text = '''
    from bzrlib import foo, bar
    import bzrlib.baz
    '''
    scope = {}
    lazy_import(scope, text)
    from bzrlib import foo as real_foo, bar as real_bar
    from bzrlib.baz import baz as real_baz
    # Ensure that we only replaced the modules, and not the members.
    # This is because we don't see accesses to the members
    assert scope['foo'] is not real_foo
    assert scope['bar'] is not real_bar
    assert scope['baz'] is not real_baz
    # Now

# Generated at 2022-06-21 21:51:35.817451
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test if constructor of class ImportProcessor works.

    The test is done by calling constructor in the test, and ensures that
    there is no exception raised.
    """
    try:
        ImportProcessor() 
    except:
        raise TestNotApplicable(
            'Failed to call constructor of class ImportProcessor.')



# Generated at 2022-06-21 21:51:45.686432
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import traceback
    def test_exception(exc, msg):
        """Assert that calling exc() raises an exception with message msg."""
        try:
            exc()
        except Exception as e:
            tb = traceback.format_exc()
        else:
            tb = ''
            assert False, "%s() should have raised an exception\n" % (exc,)
        assert str(e) == msg, (
            "%s() should have raised an exception with message %s, but it "
            "raised %s with traceback:\n%s" % (exc, repr(msg), e, tb))
    def test_function(f):
        """Assert that using f causes an exception to be raised."""

# Generated at 2022-06-21 21:51:48.397762
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return unicode in unicode/ascii."""
    u = IllegalUseOfScopeReplacer('spam', 'eggs').__unicode__()
    # This should not raise UnicodeDecodeError
    str(u)



# Generated at 2022-06-21 21:51:53.743538
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import SymlinkFeature
    from bzrlib.tests import TestNotApplicable

    def sym_link_factory(self, scope, name):
        return SymlinkFeature()

    tmp = {}
    try:
        lazy_import(tmp, 'from bzrlib.tests import SymlinkFeature',
            globals(), sym_link_factory=sym_link_factory)
    except TestNotApplicable:
        pass
    else:
        self.assertTrue(tmp['SymlinkFeature']())



# Generated at 2022-06-21 21:52:01.069252
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should be evalable."""
    name = 'name'
    msg = 'msg'
    extra = 'extra'
    e = IllegalUseOfScopeReplacer(name, msg, extra)
    expected = "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    actual = repr(e)
    assert expected == actual, 'expected %r; got %r' % (expected, actual)

# Generated at 2022-06-21 21:52:07.172146
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    instance = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    from bzrlib.tests import TestCase
    TestCase.assertEqualDiff('ScopeReplacer object \'name\' was used incorrectly: msg: extra',
                             unicode(instance))



# Generated at 2022-06-21 21:52:14.793601
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # We are not importing the module bzrlib.lazy_import, but we need to
    # ensure that an ImportReplacer is inserted into sys.modules, so that
    # when an import is requested, it will be resolved properly.
    import sys
    module = sys.modules['bzrlib.lazy_import']
    if module is None or not isinstance(module, ImportReplacer):
        module = ImportReplacer(sys.modules, 'bzrlib.lazy_import',
                                ['bzrlib', 'lazy_import'])
        sys.modules['bzrlib.lazy_import'] = module

    # Construct a fake module object to insert into globals.
    # We need one that has the '__dict__' attribute and a '__file__' attribute.
    # This is the only way we can

# Generated at 2022-06-21 21:52:23.816529
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Tests for ImportProcessor.lazy_import

    This tests the import processor, which is used to convert import
    statements into lazy import objects.

    The lazy import objects are used to defer the actual loading of modules
    until the last possible moment.  This is an optimization because many
    modules are only referenced by docstrings, and never actually used.
    """

    class MyImportReplacer(object):
        """A class that is used as a factory for ImportReplacer objects."""

        def __init__(self):
            self.calls = []

        def __call__(self, scope, name, module_path, member=None, children={}):
            self.calls.append((scope, name, module_path, member, children))

    replacer = MyImportReplacer()
    processor = ImportProcessor(replacer)

# Generated at 2022-06-21 21:52:33.915934
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer._format() should return a str

    This test is here because IllegalUseOfScopeReplacer.__str__() relies on
    that method.
    """
    from bzrlib.tests import TestRecursiveStr
    class MyException(Exception):
        _preformatted_string = "a str"
    e = IllegalUseOfScopeReplacer("name", "msg")
    s = e._format()
    TestRecursiveStr.static_check(s, "str")
    e._preformatted_string = "a unicode"
    s = e._format()
    TestRecursiveStr.static_check(s, "str")
    e._preformatted_string = u"a unicode"
    s = e._format()
    TestRecursiveStr.static_check(s, "str")


# Generated at 2022-06-21 21:52:47.322536
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys

    class TestScopeReplacer(TestCase):

        def _test_ScopeReplacer_alias(self, module_name, obj_name):
            # Test that the alias works immediately after assignment.
            mod = sys.modules[module_name]
            expected = getattr(mod, obj_name)
            self.assertIs(expected, vars(scope)[obj_name])
            # Test that setting is correct on the scope holder
            setattr(scope[obj_name], 'dummy', True)
            self.assertTrue(getattr(expected, 'dummy'))

        def test_ScopeReplacer_alias(self):
            self.overrideEnv('PYTHONPATH', '')

# Generated at 2022-06-21 21:52:58.141503
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import_lines = '''
from foo import bar, baz
from foo.bar import bing, bong
from bzrlib.tests import per_interpreter, TestCase
from bzrlib.tests.per_interpreter import TestCaseWithInterpreter
from bzrlib.tests.features import (TestFeature, TestFeature1,
    TestFeature2)
import foo, foo.bar, foo.bar.baz as bing, bzrlib.tests.script
from bzrlib.tests import (test_testtrace,
    test_script)
    '''
    proc = ImportProcessor()
    proc.lazy_import(sys.modules, import_lines)


# Generated at 2022-06-21 21:53:04.414678
# Unit test for function disallow_proxying
def test_disallow_proxying():
    scope = {}
    lazy_import(scope, "from bzrlib import lazy_import")
    disallow_proxying()
    try:
        scope['lazy_import'] = 42
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise Exception("Should not assign to lazy import")



# Generated at 2022-06-21 21:53:15.672934
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import types
    import_processor = ImportProcessor()
    scope = {}
    import_processor.lazy_import(scope,
        'import foo\n'
        'import foo.bar\n'
        'import foo.bar.baz\n'
        'import foo.bar.baz as bing\n'
        'import foo, foo.bar, foo.bar.baz\n'
        'import foo, foo.bar, foo.bar.baz as bing\n'
        'from foo import bar, baz\n'
        'from foo import bar, baz as bing\n')

    assert 'foo' in scope
    foo_object = scope['foo']
    assert isinstance(foo_object, types.ModuleType)

    assert 'bar' in scope
    bar_object = scope['bar']

# Generated at 2022-06-21 21:53:21.735748
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Tests method __unicode__ of class IllegalUseOfScopeReplacer"""
    # This can't be done in bzrlib.tests.__init__ because
    # IllegalUseOfScopeReplacer depends on lazy loading and import.
    import bzrlib.tests.per_interrepository
    bzrlib.tests.per_interrepository.test_suite()



# Generated at 2022-06-21 21:53:30.812742
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Raising the exception should work with unicode or str args."""
    # Calls __unicode__
    try:
        raise IllegalUseOfScopeReplacer(u'illegalº©¸™£', u'msgº©¸™£')
    except IllegalUseOfScopeReplacer as e:
        assert isinstance(str(e), str)
        assert isinstance(unicode(e), unicode)
    # Calls __str__
    try:
        raise IllegalUseOfScopeReplacer('illegal', 'msg')
    except IllegalUseOfScopeReplacer as e:
        assert isinstance(str(e), str)
        assert isinstance(unicode(e), unicode)
    # No __unicode__ or __str__
    class BadlyDefinedException(Exception):
        pass

# Generated at 2022-06-21 21:53:42.550431
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    scope = {}
    processor = ImportProcessor()
    processor.lazy_import(scope, text='import foo')
    processor.lazy_import(scope, text='import bar.baz as bing\n')
    processor.lazy_import(scope, text='import bar.baz as bing')
    processor.lazy_import(scope, text='import foo from bar.baz')
    processor.lazy_import(scope, text='from foo import bar\n')
    with pytest.raises(errors.ImportNameCollision):
        processor.lazy_import(scope, text='import foo, foo')
    with pytest.raises(errors.ImportNameCollision):
        processor.lazy_import(scope, text='import foo, bar.foo')

# Generated at 2022-06-21 21:53:51.050736
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    import bzrlib.tests
    # This test was written because IllegalUseOfScopeReplacer.__str__() was
    # calling unicode() on a Unicode object, and unicode() requires an
    # encoding.  We don't have a way to specify an encoding in the output of
    # this test, so this test will only work when the default encoding of the
    # system it is running on can decode all of the strings in this test.
    # That's a bit much to ask, so this test will be disabled for now, and
    # we'll just have to hope that this doesn't come back to bite us in the
    # future.
    #
    # Using the default encoding for unicode() is the wrong thing to do,
    # the __str__() method should just return the unic

# Generated at 2022-06-21 21:53:59.437843
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ returns a unicode object in all circumstances"""
    # This test depends on the fact that the exception class uses
    # unicode() when converting variables. If this changes then we will
    # need to add more tests to check that the conversion works as expected.
    e = IllegalUseOfScopeReplacer('x', u'Some string')
    assert isinstance(e.__unicode__(), unicode)
    # setting _fmt causes the message to be generated by _format which
    # uses gettext to convert the message. However, we do not want it gettexted
    # in the test. So we set e._preformatted_string instead.
    e._fmt = u'%(msg)s'
    e._preformatted_string = u'Some string'
    assert isinstance(e.__unicode__(), unicode)

# Generated at 2022-06-21 21:54:05.692873
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs) -> object

    :seealso: ScopeReplacer.__call__
    """
    from bzrlib import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        osutils,
    )
    ''')
    # TODO: add real tests
    assert osutils


# Generated at 2022-06-21 21:54:20.695743
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Unit test for method lazy_import of class ImportProcessor"""

    import imp
    import os
    import sys

    target_module = 'import_processor_test'
    module_path = target_module + '.py'


# Generated at 2022-06-21 21:54:31.202861
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit tests for the ScopeReplacer class"""

    from bzrlib.tests.blackbox import ExternalBase

    class TestScopeReplacer(ExternalBase):

        def test_simple_scope_replacer(self):
            """Test a simple scope replacer works as expected."""
            class A(object):
                pass

            class B(object):

                def __init__(self, obj):
                    self.obj = obj

            def _factory(x, y, z):
                if z == 'a':
                    return A()
                return B(x)

            # Make a new scope
            scope = {}
            # Make sure autodoc works
            # autodoc will try to get the members of the object
            # causing the ScopeReplacer to resolve, so here we need to disable
            # proxying to prevent the object from being resolved.

# Generated at 2022-06-21 21:54:43.476315
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for constructor of class ScopeReplacer"""
    from bzrlib.tests.blackbox import ExternalBase

    class TestImport(ExternalBase):
        """Test for the lazy_import function."""

        def test_lazy_import(self):
            """Test for the lazy_import function."""
            tree = self.make_branch_and_tree('tree')
            self.build_tree_contents([('tree/a', 'original\na\n')])
            tree.add(['a'])
            tree.commit('added a')
            self.build_tree_contents([('tree/a', 'modified\na\n')])
            tree.add_parent_tree_id('a')
            import bzrlib.diff

# Generated at 2022-06-21 21:54:51.179505
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """You should be able to compare IllegalUseOfScopeReplacer instances for
    equality, in particular to check for the same error message.
    """
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    e3 = IllegalUseOfScopeReplacer('foo', 'quux')
    e4 = IllegalUseOfScopeReplacer('foo', 'bar', 'extra stuff')
    assert e1 == e2
    assert e1 != e3
    assert e3 != e4
    assert e1 != e4



# Generated at 2022-06-21 21:54:59.828921
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    try:
        raise IllegalUseOfScopeReplacer('sr1', 'msg1')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'sr1', e.name
        assert e.msg == 'msg1', e.msg
        assert e.extra == '', e.extra
    try:
        raise IllegalUseOfScopeReplacer('sr2', 'msg2', 'extra2')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'sr2', e.name
        assert e.msg == 'msg2', e.msg
        assert e.extra == ': extra2', e.extra


# Generated at 2022-06-21 21:55:08.659147
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import sys
    bzrlib = sys.modules.get('bzrlib', None)
    try:
        if bzrlib is None:
            sys.modules['bzrlib'] = None
        # Unit test for constructor of class IllegalUseOfScopeReplacer
        ex = IllegalUseOfScopeReplacer('a', 'b', 'extra')
        assert ex.name == 'a'
        assert ex.msg == 'b'
        assert ex.extra == ': extra'
    finally:
        if bzrlib is None:
            del sys.modules['bzrlib']


# Generated at 2022-06-21 21:55:10.832403
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer."""
    pass # TODO: implement your test here




# Generated at 2022-06-21 21:55:17.242581
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == 'Unprintable exception IllegalUseOfScopeReplacer: ' \
        'dict={\'name\': \'name\', \'msg\': \'msg\', \'extra\': \'\'}, ' \
        'fmt=None, error=None'



# Generated at 2022-06-21 21:55:30.494442
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.lazy_import import lazy_import
    class TestImport(TestCaseWithTransport):
        def test_lazy_import(self):
            globals.foo_loaded = False
            scope = globals()
            scope['__name__'] = 'bzrlib.tests.lazy_import_imports.test_foo'
            scope['someglobal'] = 'fooglobal'
            text = '''
            from bzrlib import (
                errors,
                osutils,
                )
            '''
            lazy_import(scope, text)
            # We should have an entry for all of these
            self.assertTrue('osutils' in scope)
            self.assertTrue('errors' in scope)
            # and they should be Import

# Generated at 2022-06-21 21:55:33.610880
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying prevents module proxy use.

    See comment in disallow_proxying.
    """
    global foo
    lazy_import(globals(), """
    import test_lazy_import""")
    try:
        disallow_proxying()
    except:
        return False
    else:
        return True



# Generated at 2022-06-21 21:55:44.915215
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer."""
    assert not IllegalUseOfScopeReplacer("1", "23") == "123"
    assert IllegalUseOfScopeReplacer("1", "23") == IllegalUseOfScopeReplacer("1", "23")
test_IllegalUseOfScopeReplacer___eq__.unittest = ['.errors']


# Generated at 2022-06-21 21:55:56.670491
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test ImportReplacer's constructor.

    This test is only for the constructor, it does not test that the
    object actually replaces itself correctly.
    """
    # check it can import the module
    scope = {}
    replacer = ImportReplacer(scope, 'foo', ['foo'])
    # check it can import a member
    scope = {}
    replacer = ImportReplacer(scope, 'foo', ['foo'], member='bar')
    # check it can import a child
    scope = {}
    replacer = ImportReplacer(scope, 'foo', ['foo'],
            children={'bar': (['foo', 'bar'], None, {})})
    # check it can import a member with children
    scope = {}

# Generated at 2022-06-21 21:56:01.578359
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import unittest
    scope = {}
    real_obj = [42]
    def factory(proxy, scope, name):
        return real_obj
    lazy_obj = ScopeReplacer(scope, factory, 'lazy_obj')
    res = lazy_obj(5, 6)
    unittest.TestCase().assertEqual(
        res, real_obj, "Object was not properly replaced and called")


# Generated at 2022-06-21 21:56:07.312229
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ => str"""
    e = IllegalUseOfScopeReplacer('name', 'message', 'extra message')
    s = e.__str__()
    assert isinstance(s, str)
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-21 21:56:18.741377
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    __tracebackhide__ = True
    # Testing the 'import foo, foo.bar' style of import
    proc = ImportProcessor()
    proc.lazy_import({}, 'import foo')
    proc.lazy_import({}, 'import foo')
    # Importing the same thing twice is ok, but don't expect them both to
    # return the same object
    foo1 = proc.imports['foo'][0]({}, 'foo')
    foo2 = proc.imports['foo'][0]({}, 'foo')
    if foo1 is foo2:
        raise errors.TestNotApplicable('Expected separate instances')
    # This should raise an exception
    # Importing the same thing twice is ok, but don't expect them both to
    # return the same object

# Generated at 2022-06-21 21:56:23.493631
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ must satisfy x==y <=> x is y"""
    # this is a very minimal test
    x = IllegalUseOfScopeReplacer('name', 'msg')
    y = x
    assert x == y
    y = IllegalUseOfScopeReplacer('name', 'msg')
    assert x == y
    y = IllegalUseOfScopeReplacer('name', 'msg2')
    assert not (x == y)



# Generated at 2022-06-21 21:56:31.681410
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    ip.lazy_import(globals(), 'import foo')
    assert foo.__name__ == 'foo'
    ip.lazy_import(globals(), 'from foo import bar')
    assert bar.__name__ == 'bar'
    assert ('bar', bar) not in foo.__dict__.items()
    del bar

    # We don't currently handle the 'from foo import bar, baz' case
    # properly
    try:
        ip.lazy_import(globals(), 'from foo import bar, baz')
    except errors.ImportNameCollision:
        pass
    else:
        raise AssertionError('from foo import bar, baz should fail')
    assert 'bar' not in globals()
    assert 'baz' not in globals()

# Generated at 2022-06-21 21:56:41.506521
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib.tests

    replacer = ImportReplacer(scope={}, name="bzrlib",
        module_path=["bzrlib"], member=None, children={
            'tests':(["bzrlib", "tests"], None, {
                'test_ImportProcessor':(["bzrlib", "tests", "test_ImportProcessor"], None, {})})})

    scope = {}   # scope is empty, so we need to populate it
    replacer._import(scope, "bzrlib")
    tests = scope["bzrlib"].tests

    # this will trigger the lazy import chain
    from bzrlib.tests import test_ImportProcessor
    assert test_ImportProcessor is tests.test_ImportProcessor



# Generated at 2022-06-21 21:56:48.478553
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e1 = IllegalUseOfScopeReplacer("Raymond", "forgot an argument", "foo")
    assert str(e1) == ("ScopeReplacer object 'Raymond' was used "
                       "incorrectly: forgot an argument: foo")
    e2 = IllegalUseOfScopeReplacer("Raymond", "forgot an argument", "foo")
    assert e1 == e2
test_IllegalUseOfScopeReplacer()



# Generated at 2022-06-21 21:56:51.149067
# Unit test for function lazy_import
def test_lazy_import():
    scope = {}
    lazy_import(scope, 'from bzrlib import foo')
    assert isinstance(scope['foo'], ImportReplacer)
    # If we access the attribute, it will get replaced
    scope['foo'].errors
    assert isinstance(scope['foo'], module)

