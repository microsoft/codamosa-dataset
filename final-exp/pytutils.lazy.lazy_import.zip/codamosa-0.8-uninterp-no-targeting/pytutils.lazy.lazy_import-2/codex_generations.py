

# Generated at 2022-06-21 21:47:18.303639
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ checks for correct arguments"""
    from bzrlib.missing import MissingModule
    from bzrlib.plugins import plugin_object
    import bzrlib
    def factory(self, scope, name):
        assert(self._scope is scope)
        assert(self._name == name)
        assert(self._factory is factory)
        assert(self._real_obj is None)
        return 42
    scope = locals()
    name = 'answer'
    assert(scope is locals())
    assert(name == 'answer')
    # No exception should be raised
    scope[name] = ScopeReplacer(scope, factory, name)



# Generated at 2022-06-21 21:47:22.869687
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor"""
    from bzrlib import bzrdir, errors
    from bzrlib.import_processor import ImportProcessor

    scope = {'bzrdir': bzrdir,
             'errors': errors,
             'ImportProcessor': ImportProcessor}
    import_processor = ImportProcessor()

    try:
        import_processor._convert_import_str('import foo')
    except errors.InvalidImportLine:
        pass
    try:
        import_processor._convert_from_str('foo.bar as baz')
    except errors.InvalidImportLine:
        pass

# Generated at 2022-06-21 21:47:26.908968
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-21 21:47:39.540928
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from quack.quack import Quackable, Quacker
    q = Quacker()
    q.foo = Quackable()
    q2 = ScopeReplacer({}, lambda q,s,n: q, 'q2')
    q.foo = q2
    try:
        q.foo.bar
    except Exception as e:
        r = e
    else:
        raise AssertionError('IllegalUseOfScopeReplacer not raised')
    if not isinstance(r, IllegalUseOfScopeReplacer):
        raise AssertionError('Expected IllegalUseOfScopeReplacer,'
            ' got %r' % r)
    if r.name != 'q2':
        raise AssertionError('Expected q2, got %r' % r.name)

# Generated at 2022-06-21 21:47:49.212883
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import unittest
    test_scope = {'a': 'value'}
    def factory(self, scope, name):
        return scope[name]
    a_replacer = ScopeReplacer(test_scope, factory, 'a')
    assert a_replacer.__getattribute__('a') == test_scope['a']
    b_replacer = ScopeReplacer(test_scope, factory, 'b')
    assert b_replacer._resolve() is None
    assert b_replacer.__getattribute__('b') is None
    assert a_replacer._resolve() == 'value'



# Generated at 2022-06-21 21:47:54.192668
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns unicode string"""
    e = IllegalUseOfScopeReplacer(u'\N{Latin Capital Letter G With Cedilla}',
                                  u'\N{Latin Capital Letter G With Cedilla}')
    s = unicode(e)
    assert isinstance(s, unicode)
    assert s == u'Unprintable exception IllegalUseOfScopeReplacer: '\
                u'dict={\'msg\': u\'\\u011c\', \'name\': u\'\\u011c\', ' \
                u'\'extra\': u\'\'}, fmt=None, error=None'

# Generated at 2022-06-21 21:48:05.246946
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    import threading
    from bzrlib.lazy_import import ScopeReplacer
    ''')

    def thread(module):
        try:
            module.sum(1, 2)
        except IllegalUseOfScopeReplacer:
            pass
        else:
            raise AssertionError('proxying allowed')

    globals()['thread'] = thread
    lazy_import(globals(), '''
    import operator
    ''')
    t1 = threading.Thread(target=thread, args=(operator,))
    t2 = threading.Thread(target=ScopeReplacer.disallow_proxying)
    t1.start()
    t2.start()
    t1.join()


# Generated at 2022-06-21 21:48:12.487171
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import sys
    import doctest
    # We should be able to pass a unicode instance as the message
    # and we should be able to pass a unicode instance as the name
    test = doctest.DocTestSuite(sys.modules[__name__], optionflags=doctest.ELLIPSIS)
    from bzrlib.tests import TestCaseInTempDir
    result = TestCaseInTempDir().run_suite(test)
    return result.wasSuccessful()



# Generated at 2022-06-21 21:48:18.083528
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """disallow_proxying() can be called as part of unit tests"""
    # Ensure _should_proxy is enabled first
    ScopeReplacer._should_proxy = True
    disallow_proxying()



# Generated at 2022-06-21 21:48:30.751410
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import tempfile
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 21:48:48.130467
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.tests import TestCase
    from bzrlib.errors import NoSuchFile, NoSuchRevision, AlreadyBranchError, \
        DependencyNotPresent

    class TestLazyImport(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            self.imports = {}
            self.instrumented = False

        def _import(self, scope, name):
            if self.imports[name][0] == 'ERROR':
                raise NoSuchFile(name)
            elif self.imports[name][0] == 'ERROR2':
                raise NoSuchRevision(name)
            return self.imports[name][0]

        def instrument(self):
            self.instrumented = True

# Generated at 2022-06-21 21:48:50.982065
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ for IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer(name='my_lazy_import', msg='error message')
    repr(e) # Doesn't raise



# Generated at 2022-06-21 21:48:55.966067
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Tests __unicode__ method of class IllegalUseOfScopeReplacer by
    verifying that the resulting string is unicode."""
    err = IllegalUseOfScopeReplacer('name', 'Some message.')
    assert(isinstance(unicode(err), unicode))

# Generated at 2022-06-21 21:49:06.049169
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Equivalence of IllegalUseOfScopeReplacer objects is based on class and
    dict."""
    from bzrlib._do_tests import TestCase
    class TestEquivalence(TestCase):
        def test_instance_equivalence(self):
            exception = IllegalUseOfScopeReplacer('foo', 'bar')
            copy = IllegalUseOfScopeReplacer('foo', 'bar')
            self.assertEquals(exception, copy)
            self.assertEquals(copy, exception)
        def test_different_instances_unequal(self):
            exception = IllegalUseOfScopeReplacer('foo', 'bar')
            diff_name = IllegalUseOfScopeReplacer('foon', 'bar')
            diff_msg = IllegalUseOfScopeReplacer('foo', 'barn')
            diff_class = Exception('foo')
           

# Generated at 2022-06-21 21:49:16.623696
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit tests for the IllegalUseOfScopeReplacer.__eq__ method.

    This is a separate function to allow importing the module.
    """
    # Check that two error objects with the same contents are equal.
    e1 = IllegalUseOfScopeReplacer('foo', 'bar')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar')
    assert e1 == e2
    # Check that two objects with different contents are not equal.
    e3 = IllegalUseOfScopeReplacer('foo', 'bar2')
    assert not (e1 == e3)
    e4 = IllegalUseOfScopeReplacer('foo2', 'bar')
    assert not (e1 == e4)
    # Check that an error object does not compare equal to a non-error object.
    assert not (e1 == 1)


# Generated at 2022-06-21 21:49:28.466899
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns unicode object."""
    import bzrlib.lazy_import as lazy_import
    scope = {}
    dummy = lazy_import.ScopeReplacer(scope, "dummy", "from bzrlib.foo import".split())
    # Create an exception with a unicode string.
    e = lazy_import.IllegalUseOfScopeReplacer('dummy', u'Hello, world', '')
    dummy.raise_unusable_error(e)
    u = unicode(e)
    # It should return a unicode object.
    try:
        assert(isinstance(u, unicode))
    except AssertionError:
        raise AssertionError("%r is not unicode object." % repr(u))


# Generated at 2022-06-21 21:49:39.604471
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    # create a new empty module
    ns = types.ModuleType('lazy-import-test')
    ns.__dict__.update(sys.modules[test_ImportProcessor_lazy_import.__module__].__dict__)
    sys.modules['lazy-import-test'] = ns

    processor = ImportProcessor()
    processor.lazy_import(ns.__dict__, text="import foo.bar\nfrom foo import bar")

    # We should have a single entry: foo
    foo = ns.foo
    if foo.bar is not ns.bar:
        raise AssertionError('bar was imported directly')


# Generated at 2022-06-21 21:49:51.162434
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import os
    import sys

    p = ImportProcessor()
    globs = {}
    p.lazy_import(globs, '''
import sys
import os
from bzrlib import (
    osutils,
    trace,
)
from bzrlib.tests import
    test_cmdline,
    )
import bzrlib.commands''')

    def assertModuleIsReplacer(mod):
        return isinstance(mod, ScopeReplacer) and \
               mod._real_obj is None and \
               mod._factory is ImportReplacer._import and \
               mod._import_replacer_children != {}
    # The top level modules should be replaced
    assert not assertModuleIsReplacer(globs['sys']),  \
        "sys wasn't replaced, was %r" % globs['sys']


# Generated at 2022-06-21 21:50:03.058969
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests import TestCase

    class TestImportReplacer(TestCase):

        def test_ctor(self):
            """Test the constructor of ImportReplacer"""
            a_global = {}
            ImportReplacer(a_global, 'foo', ['foo'])
            self.assertTrue(callable(a_global['foo']))

            a_global = {}
            ImportReplacer(a_global, 'foo', ['foo'],
                children={'bar':(['foo', 'bar'], None, {})})
            # Make sure 'foo' is the object returned from scope
            self.assertEqual(a_global['foo'], foo)
            # Make sure 'foo' has the correct children
            self.assertTrue(callable(foo.bar))


    # Create a module with a child named 'bar'


# Generated at 2022-06-21 21:50:09.829068
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """_format should return unicode strings to __unicode__"""
    x = IllegalUseOfScopeReplacer('x', 'my message')
    x.__dict__['_preformatted_string'] = 'hello'
    assert isinstance(x.__unicode__(), unicode)
    assert x.__class__.__unicode__ is x.__unicode__



# Generated at 2022-06-21 21:50:30.199475
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test method lazy_import of class ImportProcessor"""
    import bzrlib.tests
    logger = logging.getLogger('bzrlib.tests')
    logger.warn('Import test of ImportProcessor.lazy_import')
    logger.info('Test should run, but not display anything to stdout')
    from bzrlib import (
        annotate,
        workingtree,
        )
    from bzrlib.bundle import (
        serializer,
        serializer_v4,
        )
    from bzrlib.config import (
        bzrdir,
        location,
        option,
        )
    from bzrlib.conflicts import (
        conflicts,
        text_conflicts,
        )

# Generated at 2022-06-21 21:50:39.857203
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    ip = ImportProcessor()
    ip.lazy_import(globals(), """\
    import bzrlib
    import bzrlib.branch
    import bzrlib.bundle as foo
    import bzrlib.errors
    import bzrlib.errors.BzrError
    import bzrlib.mutabletree
    import bzrlib.remote
    from bzrlib import transport
    from bzrlib.mutabletree import MutableTree
    from bzrlib.transport import Transport
    from bzrlib.transport import ssh as foo
    from bzrlib.transport import ssh
    """)

    # We don't care about the actual order of the keys, so convert
    # to a set for comparison
    actual_keys = set(globals().keys())

# Generated at 2022-06-21 21:50:51.199949
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    input_text = '\n'.join(['import foo',
                            'import foo.bar',
                            'from foo import baz',
                            'from foo import bar, baz, flam',
                            'import foo.bar.bing as bong, foo.bar.baz'])

# Generated at 2022-06-21 21:51:01.659959
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode string, and if it doesn't, then
    it should coerce whatever it returns into one.
    """
    import sys
    # these tests assume utf-8 encoding
    if sys.getdefaultencoding() != 'utf-8':
        raise TestSkipped('default encoding is not utf-8')
    obj = IllegalUseOfScopeReplacer('name', 'message')
    unicode_obj = unicode(obj)
    assert isinstance(unicode_obj, unicode)
    utf8_str = unicode_obj.encode('utf-8')
    # make sure it does the same thing when it is passed a unicode string
    unicode_obj2 = unicode(IllegalUseOfScopeReplacer(unicode('name'),
                                                     unicode('message')))

# Generated at 2022-06-21 21:51:11.253560
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    # __setattr__() raises a IllegalUseOfScopeReplacer because
    # ScopeReplacer._should_proxy is False
    import bzrlib
    ScopeReplacer._should_proxy = False
    try:
        bzrlib.lockdir.LockDir = bzrlib.lockdir
    except IllegalUseOfScopeReplacer as e:
        if str(e) == 'ScopeReplacer object \'LockDir\' was used incorrectly: ' \
'Object already replaced, did you assign it to another variable?':
            pass
        else:
            raise AssertionError()
    else:
        raise AssertionError()
    ScopeReplacer._should_proxy = True
# Unit te

# Generated at 2022-06-21 21:51:21.648401
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ must return a repr that gives a valid python expression for the
    instance.
    """
    i = IllegalUseOfScopeReplacer('foo', 'message', 'extra')
    result = repr(i)
    # This is a rather fiddly test.  It checks that the result can be
    # eval'd and that the resulting object has the same __dict__ as i.
    # This is abusive, but then __repr__ is explicitly specified to
    # give a str that can be eval'd to get an equal object.
    i2 = eval(result)
    assert i2.__dict__ == i.__dict__, "%r != %r" % (i2.__dict__, i.__dict__)



# Generated at 2022-06-21 21:51:29.422300
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    import sys
    import time
    import threading
    # We need a context manager for this test, but we can't actually use
    # contextlib.contextmanager until after lazy_import has worked its
    # magic, so we create a context manager manually.
    def contextmanager(func):
        def helper(*args, **kwds):
            return manager(func, args, kwds)
        return helper

    class manager(object):
        def __init__(self, func, args, kwds):
            self.func = func
            self.args = args
            self.kwds = kwds

        def __enter__(self):
            return self.func(*self.args, **self.kwds)


# Generated at 2022-06-21 21:51:34.772313
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() => str"""
    e = IllegalUseOfScopeReplacer("name", "msg")
    s = str(e)
    assert isinstance(s, str)
    assert "msg" in s


# Generated at 2022-06-21 21:51:45.311088
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    # Catch the call to __init__ to avoid relying on an implementation detail
    # of Exception.__eq__.
    # The implementation details is that there is a tuple of arguments to
    # __init__.
    # Just use a simple test case to ensure that the first argument
    # and the other arguments are considered by __eq__.
    def check(a, b):
        if a != b:
            raise AssertionError('%r != %r' % (a, b))
    try:
        BaseException.__init__
    except AttributeError:
        # Python 2.4 and before
        check(IllegalUseOfScopeReplacer('name', 'msg'),
              IllegalUseOfScopeReplacer('name', 'msg'))

# Generated at 2022-06-21 21:51:51.381653
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Check that disallow_proxying works.

    This function is a selftest, so please remember to add tests for the
    things you add.
    """
    disallow_proxying()
    import sys
    scope = sys.modules
    class LazyTest(object):
        pass
    def factory_test(self, scope, name):
        return LazyTest()
    lazy_test = ScopeReplacer(scope, factory_test, 'lazy_test')
    # Test that __getattribute__ fails with a meaningful error message
    # when ScopeReplacer._should_proxy is unset.
    import sys
    lazy_test = scope['lazy_test']
    lazy_test

# Generated at 2022-06-21 21:52:05.628986
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    disallow_proxying()
    lazy_import(globals(), '''
    import bzrlib.errors''')
    def get_bzrlib_errors(scope):
        return scope['bzrlib'].errors

# Generated at 2022-06-21 21:52:14.317610
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ returns a string representing the
    exception.

    This must be parsable to re-create the exception, and it must be
    human readable.
    """
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'extra')
    s = repr(e)
    e2 = eval(s)
    eq = e == e2
    # This is important because the __eq__ method considers the
    # pre-formatted string to be equal to the format string.
    if s == e._fmt:
        raise AssertionError(
            "repr(%r) == %r, but __eq__(%r) == %r.  IllegalUseOfScopeReplacer"
            " should not be considered equal to its format string."
            % (e, s, e, eq))

# Generated at 2022-06-21 21:52:19.598412
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should be implemented for IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    repr(e)
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    repr(e)



# Generated at 2022-06-21 21:52:30.940759
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase

    class TestScopeReplacer(TestCase):

        def test___setattr__(self):
            from bzrlib import lazy_import
            import bzrlib
            def maker(self, scope, name):
                return bzrlib
            ScopeReplacer(globals(), maker, 'bzrlib')
            bzrlib.lazy_import = lazy_import
            import bzrlib.ui
            self.assert_(bzrlib.ui is bzrlib.ui)

    TestScopeReplacer().test___setattr__()



# Generated at 2022-06-21 21:52:34.320672
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # TODO jam 20051224 Write tests
    pass # Not implemented


# factory function to create and return a ScopeReplacer object.

# Generated at 2022-06-21 21:52:46.282663
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    import bzrlib.tests
    test_m = sys.modules[__name__]
    lazy_import(test_m, """
    from bzrlib import lazy_import
    """)
    # Make sure that the proxies are enabled.
    disallow_proxying()
    # Try to import something that was already imported.
    lazy_import(test_m, """
    from bzrlib import (
        errors,
        osutils,
        selftest,
        )
    """, force=True)
    # Importing something that was already imported is illegal.
    bzrlib.tests.TestCase().assertRaises(
        IllegalUseOfScopeReplacer,
        lazy_import, test_m, """
        from bzrlib import osutils
        """, force=True)


# Generated at 2022-06-21 21:52:57.639954
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert e._format() == 'bar: baz'
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert e._format() == 'bar'
    e = IllegalUseOfScopeReplacer('foo', 'bar', extra=None)
    assert e._format() == 'bar'
    # This one is a bit puzzling. We pass in 'extra=None' but it doesn't
    # seem to matter here. This is because when extra=None, the e.extra is
    # set to '' (nothing) and not ': None'
    # This is because the line in the __init__() is:
    #     if extra:
    # which will not be true when extra is None.

# Generated at 2022-06-21 21:52:58.276640
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    pass

# Generated at 2022-06-21 21:53:05.730175
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__(self):

    Tests that the __str__ method produces a string.
    """
    name = 'foo'
    msg = 'bar'
    extra = 'baz'
    value = IllegalUseOfScopeReplacer(name, msg, extra)
    result = str(value)
    expected = "ScopeReplacer object 'foo' was used incorrectly: bar: baz"
    assert expected == result

# Generated at 2022-06-21 21:53:10.280545
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()"""
    from bzrlib._lazy_import import IllegalUseOfScopeReplacer
    x = IllegalUseOfScopeReplacer('a', 'b', 'c')
    y = eval(repr(x))

# Generated at 2022-06-21 21:53:24.276828
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ of class IllegalUseOfScopeReplacer

    This method is tested implicitly by
    test_IllegalUseOfScopeReplacer___str__ and
    test_IllegalUseOfScopeReplacer___repr__.
    """
    pass

# Generated at 2022-06-21 21:53:29.810549
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should be always implementable"""
    import doctest
    # this test is designed to raise any exception that __unicode__ will
    class r(IllegalUseOfScopeReplacer):
        pass
    # The traceback is different if unittest.py is used as __main__ or imported
    #  In the second case, the traceback is inside the unittest module.
    doctest.run_docstring_examples(r.__unicode__, globals())



# Generated at 2022-06-21 21:53:37.278988
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should return NotImplemented when called with the wrong class

    When the other argument is not an IllegalUseOfScopeReplacer instance,
    then __eq__ must return NotImplemented.  This is a requirement of the
    special method contract.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert e.__eq__(e) == True
    assert e.__eq__(object()) == NotImplemented



# Generated at 2022-06-21 21:53:45.562293
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_obj = ScopeReplacer(None, None, None)
    test_obj._resolve = lambda: lambda *args, **kwargs: (args, kwargs)
    assert ((), {}) == test_obj()
    assert ((1,), {}) == test_obj(1)
    assert ((), {'x': 3}) == test_obj(x=3)
    assert ((1,), {'x': 3}) == test_obj(1, x=3)
    assert ((1, 2), {'x': 3}) == test_obj(1, 2, x=3)



# Generated at 2022-06-21 21:53:57.231742
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method __eq__ of class IllegalUseOfScopeReplacer."""
    a = IllegalUseOfScopeReplacer('name', 'msg')
    b = IllegalUseOfScopeReplacer('name', 'msg')
    assert a == b
    assert not (a != b)

    a = IllegalUseOfScopeReplacer('name', 'msg', 'more')
    b = IllegalUseOfScopeReplacer('name', 'msg', 'more')
    assert a == b
    assert not (a != b)

    a = IllegalUseOfScopeReplacer('name', 'msg')
    b = IllegalUseOfScopeReplacer('name2', 'msg')
    assert a != b
    assert not (a == b)

    a = IllegalUseOfScopeReplacer('name', 'msg')
    assert a != object()
    assert not (a == object())




# Generated at 2022-06-21 21:54:08.421435
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    import_module = ScopeReplacer
    def check(namespace, modulename):
        # This method is defined here to support cross-testing from
        # lazy_import.py, because bzrlib.tests.__init__ has a lazy_import
        # of TestCase, so check_lazy_import cannot use the TestCase class
        # before it has been loaded.
        return check_lazy_import(namespace, modulename,
            is_lazy=not import_module._should_proxy)
    check(sys.modules, 'lazy_import')
    disallow_proxying()
    check(globals(), 'lazy_import')
    check({'LazyImportCaller' : LazyImportCaller}, 'lazy_import')


# Generated at 2022-06-21 21:54:15.829012
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Simple test for IllegalUseOfScopeReplacer"""

    err = IllegalUseOfScopeReplacer('c', 'I am not used')
    assert str(err) == ("IllegalUseOfScopeReplacer('c', 'I am not used'"
                        ", extra='')")
    assert unicode(err) == ("IllegalUseOfScopeReplacer('c', 'I am not used'"
                            ", extra=u'')")



# Generated at 2022-06-21 21:54:24.942685
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Unit tests for ImportReplacer"""
    scope = {}
    import_replacer = ImportReplacer(scope, 'foo', ['foo'])
    try:
        scope['foo']
    except KeyError:
        pass
    else:
        raise AssertionError('must not set scope[foo] yet')
    foo_cls = scope['foo'].__class__
    if not issubclass(foo_cls, ImportReplacer):
        raise AssertionError('must set scope[foo] to ImportReplacer class')

    # If a member is provided, its __init__ must not make children
    import_replacer = ImportReplacer(scope, 'bar', ['foo'], member='bar')
    bar_cls = scope['bar'].__class__

# Generated at 2022-06-21 21:54:33.165131
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Test method ScopeReplacer.__getattribute__ of class ScopeReplacer

    # Implementation details:  This test is implemented by testing that
    # attempting to access a member (which exists in the class, but not
    # in the object) throws an exception.
    class A(object):
        pass
    class B(object):
        def __init__(self, x):
            pass
        def __eq__(self, other):
            return True
    s = ScopeReplacer({}, lambda x, y, z: B(x), 'x')
    # Test that unexisting members of the object raises an exception
    # Test __getattribute__ (1 of 2)
    raises(AttributeError, s.__getattribute__, 'bogus')
    # Test that unexisting members of the class raises an exception
    # Test __getattribute__ (1 of

# Generated at 2022-06-21 21:54:41.986393
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer instances should be printable"""
    e = IllegalUseOfScopeReplacer("name", "msg", extra="extra")
    if not str(e).endswith("extra"):
        raise AssertionError(str(e))
    e = IllegalUseOfScopeReplacer("name", "msg")
    if e.__str__() != repr(e):
        raise AssertionError("__str__ != repr")
    if str(e) != repr(e):
        raise AssertionError("__str__ != repr")



# Generated at 2022-06-21 21:54:57.709157
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    class FooError(IllegalUseOfScopeReplacer):
        _fmt = 'A foo error occurred: %(msg)s'

    e = FooError('foo', 'bar')
    assert str(e) == 'A foo error occurred: bar'
    # Now set a 'preformatted' string and make sure
    # it's used instead
    e._preformatted_string = 'foo'
    assert str(e) == 'foo'



# Generated at 2022-06-21 21:55:04.497950
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from bzrlib.tests.per_errors import TestCase
    class TestIllegalUseOfScopeReplacer(TestCase):

        def test_IllegalUseOfScopeReplacer(self):
            e = IllegalUseOfScopeReplacer('name', 'msg')
            repr(e)

    TestIllegalUseOfScopeReplacer('test_IllegalUseOfScopeReplacer').run()



# Generated at 2022-06-21 21:55:07.488249
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import doctest
    doctest.testmod(
        name='bzrlib.lazy_import.IllegalUseOfScopeReplacer',
        )



# Generated at 2022-06-21 21:55:10.223425
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # XXX the real test should access an attribute of an object
    # created by a factory
    factory = object
    name = 'name'
    obj = ScopeReplacer({}, factory, name)
    result = obj.__getattribute__(name)
    # verify the outcome
    assert result is name



# Generated at 2022-06-21 21:55:21.597806
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import __future__
    import re
    ip = ImportProcessor()
    ip.lazy_import(globals(), """
        import __future__
        from re import (
            compile,
            )
        from cStringIO import StringIO
        import bzrlib
        import bzrlib.branch as branch
        import bzrlib.errors

        import os.path
        import os.path as pth
        from os.path import join
        from os.path import (
            join,
            split,
            )
        import time, time
    """)
    assert __future__ is __future__.__dict__['__future__']
    assert re is re.__dict__['re']
    assert compile is re.__dict__['compile']

# Generated at 2022-06-21 21:55:24.395056
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    lazy_import.inject_into_namespace(locals(), 'os')
    import os
    return os.environ == {}



# Generated at 2022-06-21 21:55:26.804632
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test constructor of class ImportProcessor"""
    a = ImportProcessor()
    b = ImportProcessor(ImportReplacer)


# Generated at 2022-06-21 21:55:30.975010
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('foo', 'Cannot do blah blah blah')
    s = str(e)
    assert ('Cannot do blah blah blah (foo)' in s) is True
    assert ('Unprintable exception' not in s) is True

# Generated at 2022-06-21 21:55:38.207217
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Dummy(object):
        __slots__ = ('__value',)

        def __init__(self):
            self.__value = 3

        def dummy_method(self):
            return 42

    def factory(lazy_object, scope, name):
        if name == 'foo':
            return Dummy()
        else:
            return Dummy

    locals = {}
    ScopeReplacer(locals, factory, 'foo')
    ScopeReplacer(locals, factory, 'bar')
    assert locals['foo'].dummy_method() == 42
    assert locals['bar'].dummy_method() == 42



# Generated at 2022-06-21 21:55:50.797135
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class C(object):
        def __init__(self):
            self.a = 5
    c = ScopeReplacer(dict(), lambda s, sc, name: C(), 'c')
    assert c.a == 5
    c.a = 6
    # Unit test for method __getattribute__ of class ScopeReplacer
    def test_ScopeReplacer___getattribute__():
        class C(object):
            def __init__(self):
                self.a = 5
        c = ScopeReplacer(dict(), lambda s, sc, name: C(), 'c')
        assert c.a == 5
        # Test that we can't access members from a proxy object
        from bzrlib.tests.test_scope_replacer import (
            ScopeReplacer,
            IllegalUseOfScopeReplacer,
            )
        assert c.a == 5

# Generated at 2022-06-21 21:56:11.963616
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import time

    # test of original code
    def factory_func_1(self, scope, name):
        val = object.__new__(int)
        object.__setattr__(val, 'real', 23)
        return val

    # code in branch - will cause IllegalUseOfScopeReplacer exception
    def factory_func_2(self, scope, name):
        return self

    # code in branch - raises exception in __getattribute__
    def factory_func_3(self, scope, name):
        import sys
        import time

        class FooBar(object):
            def __init__(self, sys, time):
                self.sys = sys
                self.time = time
                self.items = {'one':1, 'two':2}


# Generated at 2022-06-21 21:56:19.213854
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    replacer = ScopeReplacer(scope, lambda self, scope, name: scope, "key")
    scope2 = {}
    try:
        replacer2 = ScopeReplacer(scope2, lambda self, scope, name: scope, "key")
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError for two replacers for same"
            " key, but got %r" % replacer2)



# Generated at 2022-06-21 21:56:29.054060
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import sys
    scope = {}
    class C(object):
        def __init__(self, scope, name):
            scope[name] = self
            scope[name + '_other'] = self
    def factoryA(self, scope, name):
        return C(scope, name)
    def factoryB(self, scope, name):
        return scope['other']
    def factoryC(self, scope, name):
        return self
    # Check that it resolves on getattr
    ScopeReplacer(scope, factoryA, 'a')
    assert scope['a']._resolve() is scope['a_other']
    # Callable objects
    ScopeReplacer(scope, factoryA, 'b')
    scope['b'](1)
    # Check that it generates the object correctly

# Generated at 2022-06-21 21:56:31.054997
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    r = ScopeReplacer(None, None, None)
    assert r._resolve() == None


# Generated at 2022-06-21 21:56:41.349126
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    def _check(name, msg, extra=None):
        e = IllegalUseOfScopeReplacer(name, msg, extra)
        # Make a list of the various permutations of args to build the expected
        # result string.
        permutations = [(name, None, ''),
                        (None, msg, ''),
                        (None, None, ''),
                        (name, msg, ''),
                        (name, None, extra),
                        (None, msg, extra),
                        (None, None, extra),
                        (name, msg, extra),
                        ]
        for name, msg, extra in permutations:
            if name is None:
                name = ''
            if msg is None:
                msg = ''
            if extra is None:
                extra = ''
            # Now

# Generated at 2022-06-21 21:56:46.282271
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e1 = IllegalUseOfScopeReplacer('name', 'word')
    e2 = IllegalUseOfScopeReplacer('name', 'word')
    e3 = IllegalUseOfScopeReplacer('name', 'other')
    assert(e1 == e2)
    assert(e1 != e3)



# Generated at 2022-06-21 21:56:57.509409
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object with correct content"""
    dummy_scope_replacer = DummyScopeReplacer()
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # Default format is set and works
    e.name = 'name1'
    e.msg = 'msg1'
    e._fmt = "%(name)s-%(msg)s"
    u = unicode(e)
    assert isinstance(u, unicode), "__unicode__ must return unicode object"
    assert u == u"name1-msg1"
    # Format is dynamically set and works
    e.name = 'name2'
    e.msg = 'msg2'
    e._fmt = "%(name)s+%(msg)s"
    u = unicode(e)