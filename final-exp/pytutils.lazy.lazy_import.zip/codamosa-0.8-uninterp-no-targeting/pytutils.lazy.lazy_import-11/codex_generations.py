

# Generated at 2022-06-21 21:47:16.696954
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer"""

    assert str(IllegalUseOfScopeReplacer('foo', 'bar')) == \
        'IllegalUseOfScopeReplacer(foo)'



# Generated at 2022-06-21 21:47:26.742361
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScope(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
        def __getitem__(self, key):
            return self.value
        def __setitem__(self, key, value):
            self.value = value
    class FakeObject(object):
        def __init__(self):
            self.att = None
        def method(self):
            pass
    scope = TestScope('test_ScopeReplacer___getattribute__', None)
    def proxy_factory(instance, scope, name):
        return FakeObject()
    scope.value = ScopeReplacer(scope, proxy_factory, 'value')

# Generated at 2022-06-21 21:47:39.373262
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ must be implemented as returning just "%s(%s)" % (self.__class__.__name__,
    str(self))."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    assert str(e) == 'name: msg: extra'
    # Test with a unicode message
    e = IllegalUseOfScopeReplacer(u'name', u'\u03b1\u03b2\u03b3', 'extra')
    assert repr(e) == "IllegalUseOfScopeReplacer(u'name', u'\u03b1\u03b2\u03b3', 'extra')"

# Generated at 2022-06-21 21:47:51.236845
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should handle all cases

    This test is designed to exercise all possible cases for the
    __unicode__ method.
    """
    from bzrlib import errors

    # format this exception like the others do
    e = errors.IllegalUseOfScopeReplacer(name='foo',
                                         msg='baz',
                                         extra='bar')
    e_unicode = unicode(e)
    expected = u"foo was used incorrectly: baz: bar"
    assert e_unicode == expected, "%r != %r" % (e_unicode, expected)

    # check that we get the right behaviour with a plain str
    e = errors.IllegalUseOfScopeReplacer(name='foo',
                                         msg='baz',
                                         extra='bar')
    e.__

# Generated at 2022-06-21 21:47:56.852861
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    # Test for a single-character unicode message.
    e = IllegalUseOfScopeReplacer('foo', u'\u2600')
    expected = u'foo'
    actual = e.__unicode__()
    # not using u"..." because that's not unicode in Python 2.5,
    # and I want this to run on Debian stable without warnings.
    if(expected != actual):
        raise Exception(
            "__unicode__ returned %r, expected %r" % (actual, expected))
    # Test for a string message.
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    expected = u'foo'
    actual = e.__unicode__()

# Generated at 2022-06-21 21:48:09.145710
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    s = ScopeReplacer(globals(),lambda self, scope, name: None, 'None')
    def f(x):
        s.f()
    import traceback
    try:
        f(1)
    except IllegalUseOfScopeReplacer as e:
        assert(str(e) == 'IllegalUseOfScopeReplacer: None was used incorrectly: Object already replaced, did you assign it to another variable?: ')
        assert(e.name == 'None')
        assert(e.msg == 'Object already replaced, did you assign it to another variable?')
        assert(e.extra == '')

# Generated at 2022-06-21 21:48:18.001806
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should convert format string and args to unicode, and return unicode"""
    class E(IllegalUseOfScopeReplacer):
        _fmt = '%(msg)s'
    e1 = E('a', 'b')
    e2 = E('a', 'b')
    e3 = E('a', u'b')
    e4 = E('a', 'b', extra='c')
    assert e1 == e2 # __eq__, __dict__
    assert e1 != e3 # __dict__
    assert e1 != e4 # __dict__
    assert e3 == e3 # __eq__, __dict__
    assert not (e1 != e2) # __eq__, __dict__
    assert not (e1 == e3) # __eq__, __dict__

# Generated at 2022-06-21 21:48:27.915335
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.matchers import ContainsNoVfsCalls

    class PrintableObject(object):
        """A trivial object for testing that the printable
        output of an object is proxied correctly.
        """
        def __str__(self):
            return "testString"

    class TestObject(object):
        """Object used to do actual testing."""

        def __init__(self):
            self.foo = "bar"

        def __deepcopy__(self, memo):
            # This is here to trigger the test in test_deepcopy described below.
            # You won't normally need to do this.
            return self


# Generated at 2022-06-21 21:48:28.740153
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""


# Generated at 2022-06-21 21:48:33.672255
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    # Test for subclasses overriding _real_obj, __getattribute__, _resolve
    import bzrlib
    obj = bzrlib.lazy_import.ScopeReplacer(
        globals(), lambda x, y, z: x, 'obj')
    class MyScopeReplacer(ScopeReplacer):
        __slots__ = ()
        def _resolve(self):
            return object.__getattribute__(self, '_real_obj')
    obj._real_obj = 1
    # __getattribute__ should not be redirected as _resolve returns as soon
    # as possible with _real_obj
    assert(id(obj.__getattribute__) == id(ScopeReplacer.__getattribute__))
    # Check that an exception was raised if _real

# Generated at 2022-06-21 21:48:47.753082
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    scope = {}
    scope['func'] = [1]
    func = ScopeReplacer(scope, lambda *args: scope['func'], 'func')
    assert scope['func'] is func
    scope['func'].append(2)
    assert func() == [1, 2]
    assert scope['func'] is func
    assert func(3) == [1, 2, 3]
    assert scope['func'] is not func



# Generated at 2022-06-21 21:48:51.353761
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer(1,2)
    e2 = IllegalUseOfScopeReplacer(3,4)
    e3 = IllegalUseOfScopeReplacer(1,2)
    assert e1 != e2
    assert e1 == e3



# Generated at 2022-06-21 21:49:03.544958
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""
    import bzrlib.tests
    scope = {'bzrlib': bzrlib}
    lazy_import(scope, '''
        import bzrlib.tests
        from bzrlib.tests import TestCase
        ''')
    # This should not have replaced the existing bzrlib module with a
    # new one.
    assert scope['bzrlib'] is bzrlib
    # These should not have been loaded yet
    assert not hasattr(scope['bzrlib'], 'TestCase')
    assert not hasattr(scope['bzrlib'], 'tests')
    # Now we touch them, and they should be loaded
    scope['bzrlib.TestCase']

# Generated at 2022-06-21 21:49:16.018187
# Unit test for function lazy_import
def test_lazy_import():
    """The function 'lazy_import' has a fairly simple unit test"""
    scope = {}
    text = '''
        from bzrlib import (
            branch as b,
            errors as e,
            )
        from bzrlib.tests import (
            blackbox as bb,
            )
        from bzrlib.tests.blackbox import (
            foo as f,
            bar as b,
            )
        import bzrlib.branch
        import bzrlib.transport
        '''
    lazy_import(scope, text)
    scope['bzrlib']._resolve()
    scope['bzrlib'].branch._resolve()
    scope['bzrlib'].transport._resolve()
    scope['branch']._resolve()

# Generated at 2022-06-21 21:49:20.572686
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str(obj)
    unicode(obj)
    repr(obj)



# Generated at 2022-06-21 21:49:27.712320
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class Dummy(object):
        def foo(self): return 'foo'
    def factory(self, scope, name):
        return Dummy()
    scope = {'x': 'yz'}
    lazy_obj = ScopeReplacer(scope, factory, 'x')
    assert lazy_obj.__call__() == 'foo'
    assert scope['x'].__call__() == 'foo'
    assert lazy_obj() == 'foo'
    assert scope['x']() == 'foo'



# Generated at 2022-06-21 21:49:36.127227
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(), 'import bzrlib')
    from bzrlib import branch
    import bzrlib.branch
    branch_class = branch.Branch
    branch_class2 = bzrlib.branch.Branch
    if branch_class is not branch_class2:
        raise TestNotApplicable('ImportProcessor constructor not working')



# Generated at 2022-06-21 21:49:44.479927
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.per_repository
    import bzrlib.tests.test_transport

    scope = {}
    lazy = ImportProcessor()
    lazy.lazy_import(scope, """
    import bzrlib.tests.
    from bzrlib import tests
    """)
    bzrlib_tests = scope['bzrlib']._real_obj.tests
    assert bzrlib_tests is scope['bzrlib']._real_obj.tests
    assert bzrlib.tests is scope['bzrlib']._real_obj.tests
    assert bzrlib.tests is scope['bzrlib']._real_obj.tests._real_obj

# Generated at 2022-06-21 21:49:49.029530
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    scope = {}
    def test_factory(self, scope, name):
        return object()
    scope_replacer = ScopeReplacer(scope, test_factory, 'test_name')
    scope_replacer.test_attribute


# Generated at 2022-06-21 21:49:53.833277
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Applying .__str__() to an IllegalUseOfScopeReplacer

    should return a str object.
    """
    e = IllegalUseOfScopeReplacer('name', 'message', extra=None)
    str_value = str(e)
    assert type(str_value) is str


# Generated at 2022-06-21 21:50:03.089036
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import scope_replacer_for
    from bzrlib import (
        tests,
        )
    tests.unit.test_lazy_import.TestScopeReplacer._test_ScopeReplacer___call__(
        scope_replacer_for)



# Generated at 2022-06-21 21:50:15.550524
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.branch import Branch

    globals()['lazy_module'] = None
    disallow_proxying()
    lazy_import(globals(), '''from bzrlib import lazy_module''')
    assert Branch.__module__ == 'bzrlib.branch', Branch.__module__
    assert lazy_module.Branch.__module__ == 'bzrlib.branch', (
        lazy_module.Branch.__module__)

    # Any indirect reference to an object must raise IllegalUseOfScopeReplacer
    # This is because we are testing for them and want to be warned if they
    # happen.
    import re
    import time
    import bzrlib
    import bzrlib.branch
   

# Generated at 2022-06-21 21:50:28.151367
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    from bzrlib.tests import TestNotApplicable
    class DummyScopeReplacer(ScopeReplacer):
        pass
    # Class variables will not be proxied because ScopeReplacer._should_proxy
    # is False, so all calls will raise an IllegalUseOfScopeReplacer exception.
    try:
        obj = DummyScopeReplacer(dict(), lambda *args: None, 'obj')
        raise Exception("ScopeReplacer.__init__ should have raised an "
            "exception due to ScopeReplacer._should_proxy being False.")
    except IllegalUseOfScopeReplacer as e:
        expected_msg = "Object already replaced, did you assign it to another variable?"

# Generated at 2022-06-21 21:50:34.901429
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()

# Generated at 2022-06-21 21:50:47.958759
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import new
    import sys

    class TestImportReplacer(object):

        def __init__(self, scope, name, module_path, member=None):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member

        def _import(self):
            return (self.scope, self.name, self.module_path, self.member)

    class TestScope(object):

        def __setitem__(self, key, value):
            if getattr(self, key, None) is not None:
                raise AssertionError("key %r already exists" % (key,))
            self.__dict__[key] = value
            return

    processor = ImportProcessor(TestImportReplacer)
    scope = TestScope()

    processor.lazy_

# Generated at 2022-06-21 21:50:59.561476
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import __builtin__
    
    # Create a real module with a name that is likely to not exist
    module_name = 'test_ImportProcessor_lazy_import_module_%s' % id(sys.modules)
    module_dict = {}
    module = __builtin__.__dict__[module_name] = type(module_name, (object,),
                                                     module_dict)
    
    def check_import(name, should_exist):
        if should_exist:
            should_equal = module_name
        else:
            should_equal = name

# Generated at 2022-06-21 21:51:10.461261
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying"""
    import sys
    import bzrlib.lazy_import

    # Enable proxy mode and make sure it works
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    bzrlib.lazy_import.lazy_import(
        sys.modules[__name__].__dict__, '''
        from bzrlib.tests import TestCase
        ''')
    assert isinstance(test_disallow_proxying, TestCase)
    # Disable the proxy mode
    bzrlib.lazy_import.disallow_proxying()
    # The next access should raise an exception due to
    # "dereference after undereference"

# Generated at 2022-06-21 21:51:22.021427
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('obj', 'something bad')
    assert str(e) == 'Unprintable exception IllegalUseOfScopeReplacer:' \
        ' dict={\'msg\': \'something bad\', \'name\': \'obj\', \'extra\': \'\'}' \
        ', error=None'
    # Check a more complex exception
    e = IllegalUseOfScopeReplacer('obj', 'something bad',
                                  'another error')
    assert str(e) == 'Unprintable exception IllegalUseOfScopeReplacer:' \
        ' dict={\'msg\': \'something bad\', \'name\': \'obj\', \'extra\': \'\':' \
        ' another error}' \
        ', error=None'
    # Now with a pre

# Generated at 2022-06-21 21:51:31.896940
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    err = IllegalUseOfScopeReplacer('a', 'b', 'c')
    err2 = IllegalUseOfScopeReplacer('a', 'b', 'c')
    err3 = IllegalUseOfScopeReplacer('b', 'b', 'c')
    err4 = IllegalUseOfScopeReplacer('a', 'b')
    assert err == err2
    assert not err == err3
    assert err != err3
    assert not err == err4
    assert err != err4

# aliases for some of the module names we use in lazy_import_modules.
# This avoids the need to handle a few special cases in lazy_import_modules
# when run from the bzrlib.tests test suite.  See the comment in
# bzrlib.tests.TestUtil.assertEqual for more details.
import bzrlib.tests.test

# Generated at 2022-06-21 21:51:39.110150
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Ensure IllegalUseOfScopeReplacer.__unicode__ correctly
    # returns a unicode object.
    e = IllegalUseOfScopeReplacer(
        name='name',
        msg='msg',
        extra='extra')
    u = e.__unicode__()
    u.__repr__()


# Generated at 2022-06-21 21:51:48.865419
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Tests for ScopeReplacer objects."""
    from bzrlib.tests import TestCase, TestCaseWithMemoryTransport
    class TestScopeReplacer(TestCaseWithMemoryTransport):

        def test_ScopeReplacer(self):
            """Test that ScopeReplacer objects are functioning correctly."""
            # Build a testing environment with the following variables
            # assigned in this order:
            # 1. An object with an attribute.
            # 2. A ScopeReplacer object that is a lazy loaded version of
            #    object (1).
            # 3. Another object with an attribute that is the same as the
            #    object in object (1).
            # 4. An object (empty)
            #
            # The object that is placed in the scope should be obj1.
            # Access to the object should pass through to obj2, but
            # att

# Generated at 2022-06-21 21:52:02.468129
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Assert that two IllegalUseOfScopeReplacer instances
    of the same class compare equal iff they have the same
    attributes.

    This is based on the test in bzrlib.trace.test_trace._test_mutating
    which checks that Trace.__eq__ works.
    """
    import operator
    IllegalUseOfScopeReplacer._fmt = u"foo"
    a = IllegalUseOfScopeReplacer("a", "a", "a")
    aa = IllegalUseOfScopeReplacer("a", "a", "a")
    ab = IllegalUseOfScopeReplacer("a", "b", "a")
    abc = IllegalUseOfScopeReplacer("a", "b", "c")
    b = IllegalUseOfScopeReplacer("b", "a", "a")


# Generated at 2022-06-21 21:52:11.947582
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # This tests ScopeReplacer.__call__(), which is only used when the
    # lazy-loaded object was a class, and is being instantiated. This
    # is not normally used for bzrlib, but we'd still like to have this tested.
    def class_factory(replacer, scope, name):
        return object.__new__(replacer)
    d = {}
    ScopeReplacer(d, class_factory, 'MyClass')
    inst = d['MyClass']()
    assert inst.__class__.__name__ == 'ScopeReplacer'
    return inst



# Generated at 2022-06-21 21:52:18.123627
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test the method __setattr__ of class ScopeReplacer"""
    from bzrlib.tests.blackbox import ExternalBase

    # This test is derived from a test case written by John Arbash Meinel
    # <john@arbash-meinel.com>

    # An object that has a writable __doc__
    class Foo(object):
        """Foo"""

    class DocTestExternal(ExternalBase):
        """Test the method __setattr__ of class ScopeReplacer"""

        def test_foo(self):
            # Make sure we can actually set a docstring on Foo
            Foo.__doc__ = 'something'
            # And make sure that it is actually set, to catch bugs in the
            # interpreter (such as http://bugs.python.org/issue4935)

# Generated at 2022-06-21 21:52:27.784886
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()

    The method __repr__ should return a string representation of the
    object that can be used to reconstruct it.
    """
    class Foo(IllegalUseOfScopeReplacer):
        pass
    error = Foo('foo', 'bar', 'baz')
    expected_repr = ('Foo(<IllegalUseOfScopeReplacer object at 0x%x: ScopeReplacer'
                     ' object \'foo\' was used incorrectly: bar: baz>)'
                     % id(error))
    repr_result = repr(error)
    assert repr_result == expected_repr
# End test for method __repr__ of class IllegalUseOfScopeReplacer



# Generated at 2022-06-21 21:52:36.112641
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ must work"""
    class MyException(IllegalUseOfScopeReplacer):
        pass
    e1 = MyException('foo', 'msg')
    e2 = MyException('foo', 'msg')
    if e1 != e2:
        raise AssertionError('equal exceptions are not equal')
    e3 = MyException('foo', 'msg2')
    if e1 == e3:
        raise AssertionError('inequal exceptions are equal')
    class _MyException(Exception):
        pass
    e4 = _MyException()
    if e1 == e4:
        raise AssertionError('exceptions of different classes are equal')
test_IllegalUseOfScopeReplacer___eq__()



# Generated at 2022-06-21 21:52:48.572931
# Unit test for function lazy_import
def test_lazy_import():
    """Test the lazy_import function"""
    from bzrlib.tests.blackbox import ExternalBase

    class TestLazyImport(ExternalBase):
        """Test lazy_import"""

        def test_lazy_import_works(self):
            """Test that lazy imports actually work"""
            # This is simply a smoke test, we don't really want to test
            # that internals work
            # Load up a bunch of things
            lazy_import(globals(), '''
            from bzrlib import (
                branch,
                errors,
                merge_directive,
                osutils,
                tests,
                transport,
                )
            import bzrlib
            ''')
            self.run_bzr('help') # This will load a bunch of modules

    # Note: We just run the tests in process, as the

# Generated at 2022-06-21 21:52:58.549951
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Test for method __call__ of class ScopeReplacer"""
    import bzrlib.tests

    def _foo():
        return 'foo'
    # Set up the scope and the factory which creates the real object
    scope = {}
    factory = lambda self, scope, name: _foo
    # Create the replacer
    e = ScopeReplacer(scope, factory, '_foo')
    # Check that it is in the scope
    bzrlib.tests.TestCase.assertEqual(
        {'_foo': e},
        scope)
    # Do something which should invoke the replacer
    bzrlib.tests.TestCase.assertEqual(
        'foo',
        e())
    # Check that it has now been replaced with the real object

# Generated at 2022-06-21 21:53:11.127807
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str.

    __str__ must be the same as unicode(self).encode('utf8')
    """
    import sys
    # This is the easy part.  Most things will work well.
    err = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(err.__str__(), str)
    assert str(err) == 'foo was used incorrectly: bar'
    # This is the 'hard' part.  We need to return a str of utf8 bytes.
    err = IllegalUseOfScopeReplacer(u'f\xe9e', u'b\xe9r')
    assert isinstance(err.__str__(), str)
    assert str(err) == 'f\xc3\xa9e was used incorrectly: b\xc3\xa9r'
    assert unic

# Generated at 2022-06-21 21:53:15.160636
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()"""
    rep = repr(IllegalUseOfScopeReplacer("foo", "bar", "baz"))
    assert rep == "IllegalUseOfScopeReplacer('foo', 'bar', 'baz')"



# Generated at 2022-06-21 21:53:26.673448
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from doctest import OutputChecker
    from bzrlib import tests

    tests.doctest_for_exception(IllegalUseOfScopeReplacer,
        """\
>>> import sys
>>> try:
...     lazy_import(sys.modules, 'no_such_module')
... except IllegalUseOfScopeReplacer, e:
...     print e.name
...     print e.msg
...
lazy_import_no_such_module
no_such_module
""")



# Generated at 2022-06-21 21:53:33.916917
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class MyImportReplacer(ImportReplacer):
        def __init__(self, scope, name, module_path, member=None, children={}):
            ImportReplacer.__init__(self, scope, name, module_path,
                                    member=member, children=children)
    scope = {}
    MyImportReplacer(scope=scope, module_path=['bzrlib'], name='foo')



# Generated at 2022-06-21 21:53:44.196904
# Unit test for function disallow_proxying
def test_disallow_proxying():
    class MyScopeReplacer(ScopeReplacer):
        """A scope replacer that remembers the arguments of its ctor"""
        def __init__(self, *args, **kwargs):
            super(MyScopeReplacer, self).__init__(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs
    class MyObject(object):
        """A simple object that remembers the methods that are called"""
        def __init__(self, *args, **kwargs):
            self.called = []
        def foo(self, *args, **kwargs):
            self.called.append(('foo', args, kwargs))
            return args[0]

    scope = {}
    import sys

# Generated at 2022-06-21 21:53:52.966358
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import shutil
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer

# Generated at 2022-06-21 21:54:04.493117
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__

    of class IllegalUseOfScopeReplacer
    """
    # test with a preformatted message
    x = IllegalUseOfScopeReplacer('name', 'msg', extra=None)
    x._preformatted_string = 'hello world'
    assert x.__unicode__() == 'hello world'
    assert isinstance(x.__unicode__(), unicode)
    # test with a format string, using the arguments of the original exception
    s = u'hello \u1234'
    assert isinstance(s, unicode)
    y = IllegalUseOfScopeReplacer(s, 'msg', extra=s)
    y._fmt = u'*** %(name)s *** %(msg)s *** %(extra)s ***'

# Generated at 2022-06-21 21:54:11.897707
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Unit test for IllegalUseOfScopeReplacer class."""
    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'foo', e
        assert e.msg == 'bar'
        assert e.extra == ''
        assert str(e) == "ScopeReplacer object 'foo' was used incorrectly: bar"
        assert repr(e).endswith("'bar')")
    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    except IllegalUseOfScopeReplacer as e:
        assert str(e) == "ScopeReplacer object 'foo' was used incorrectly: bar: baz"



# Generated at 2022-06-21 21:54:15.739739
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Tests for ImportProcessor class.
    """
    import_processor = ImportProcessor()
    if import_processor._lazy_import_class != ImportReplacer:
        raise AssertionError('Default lazy import class is wrong')

    class TestImportReplacer(ImportReplacer):
        pass

    import_processor = ImportProcessor(TestImportReplacer)
    if import_processor._lazy_import_class != TestImportReplacer:
        raise AssertionError('Wrong lazy import class')


# Generated at 2022-06-21 21:54:24.884246
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the ImportProcessor class"""
    ip = ImportProcessor()
    ip.lazy_import(globals(), """import foo.bar
    from foo.bar import baz, bing as bong, (bada, bing)
    import foo.bar as blam""")

    for name in ['foo', 'bar', 'baz', 'bong', 'bada', 'blam']:
        assert name not in globals()

    # Now verify that the map contains the correct information
    assert ip.imports['foo'] == ([u'foo'], None, {u'bar':
        ([u'foo', u'bar'], None, {})})
    assert ip.imports['bar'] == ([u'foo', u'bar'], None, {})

# Generated at 2022-06-21 21:54:27.944060
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert e.name == 'a'
    assert e.msg == 'b'
    assert e.extra == ': c'

# Generated at 2022-06-21 21:54:34.349661
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import lazy_import
    import new

    module = new.module('foo')
    module.x = 42
    scope = {'foo':lazy_import.ScopeReplacer(
        locals(), lambda self, scope, name:scope[name], 'foo')}
    obj = scope['foo']
    assert obj.x == 42
    assert scope['foo'].x == 42
    assert locals()['foo'].x == 42

    # Now disable proxying and ensure the exception is raised
    old_should_proxy = lazy_import.ScopeReplacer._should_proxy
    lazy_import.ScopeReplacer._should_proxy = False
    scope['foo'] = scope['foo'].x

# Generated at 2022-06-21 21:54:43.702485
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def factory(self, scope, name):
        def my_fun(*args):
            return args
        return my_fun

    scope = {}
    foo = ScopeReplacer(scope, factory, 'foo')
    assert (('bar',), {}) == foo('bar')
    assert scope['foo'] == foo



# Generated at 2022-06-21 21:54:52.209010
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    ip.lazy_import(globals(), "from foo import bar, baz, bing")
    ip.lazy_import(globals(), "import foo.bar.bing, foo.bar.baz, foo")
    ip.lazy_import(globals(), "import foo, foo.bar as bing, baz")
    ip.lazy_import(globals(), "import foo, (bar, baz)")
    ip.lazy_import(globals(), "import (foo)\n")
    ip.lazy_import(globals(), "import (foo)\n import (bar)")
    ip.lazy_import(globals(), "import (foo as bar)\n import (baz)")

# Generated at 2022-06-21 21:54:58.590948
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should proxy to the underlying object

    >>> class A(object):
    ...     def __init__(self):
    ...         self.foo = 1
    ...         self.bar = 2
    ...     def hello(self):
    ...         pass
    ...     def goodbye(self):
    ...         pass
    ...
    >>> scope = {}
    >>> def factory(self, scope, name):
    ...     # Create an instance to replace self
    ...     return A()
    >>> name = 'obj'
    >>> sr = ScopeReplacer(scope, factory, name)
    >>> sr.hello()
    >>> obj = scope[name]
    >>> obj.bar = 42
    >>> sr.bar
    42
    """



# Generated at 2022-06-21 21:55:01.908512
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import doctest
    from bzrlib import lazy_import
    doctest.run_docstring_examples(lazy_import.ScopeReplacer.__getattribute__,
                                   globals())


# Generated at 2022-06-21 21:55:12.117474
# Unit test for function disallow_proxying
def test_disallow_proxying():

    import sys

    # This is the module we'll use to check proxying.
    # If disallow_proxying() works, it should have been replaced by
    # a ScopeReplacer object, and this reference to it should be
    # frozen.
    module = sys.modules['bzrlib.lazy_import']

    # Make sure we're using the lazy_import module
    assert isinstance(module, ScopeReplacer)

    # Then disallow proxying and check it hasn't changed
    disallow_proxying()
    assert isinstance(module, ScopeReplacer)

    # Import another module, check is unaffected
    import bzrlib.test_suite

    assert isinstance(bzrlib.test_suite, ScopeReplacer)



# Generated at 2022-06-21 21:55:22.726288
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def run(scope, factory, name, args, kwargs, retval):
        called_args = []
        called_kwargs = {}
        called_retval = "r"
        obj = object()
        def factory(self, scope, name):
            called_args.append((scope, name))
            return obj
        def __call__(self, *args, **kwargs):
            called_args.append(args)
            called_kwargs.update(kwargs)
            return called_retval
        setattr(obj, '__call__', __call__)
        s = ScopeReplacer(scope, factory, name)
        try:
            ret = s(*args, **kwargs)
        finally:
            del scope[name]
        assert ret == retval
        assert called_args[0][0] == scope

# Generated at 2022-06-21 21:55:32.080511
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib
    scope = {}
    lazy_import(scope, '''
        from bzrlib import (
            branch,
            errors,
            )
        import bzrlib.tests
        ''')
    assert scope['errors'] is errors
    assert scope['branch'] is branch
    assert scope['tests'] is tests
    # It should have removed itself from the name list
    assert 'lazy_import' not in scope
    assert 'bzrlib' not in scope
    assert 'bzrlib.tests' not in scope
    assert 'bzrlib.errors' not in scope
    # now really import something
    scope['branch'].Branch
    for key in scope.keys():
        value = scope[key]
        if isinstance(value, ScopeReplacer):
            value._resolve

# Generated at 2022-06-21 21:55:36.857105
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # Note: Pickling and unpickling is tested in
    # test_scope_pickling
    sr = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(sr)
    u = unicode(sr)
    repr(sr)
    assert type(s) == str
    assert type(u) == unicode
    assert sr == IllegalUseOfScopeReplacer('name', 'msg')



# Generated at 2022-06-21 21:55:41.997859
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ of class IllegalUseOfScopeReplacer should return a str"""
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(obj)
    assert type(s) is str, "__str__() should return a str, not %r" % type(s)

# Generated at 2022-06-21 21:55:54.270243
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ImportReplacer

    class TestLazyImport(TestCase):

        def test_lazy_import_single(self):
            scope = {}
            lazy_import(scope, 'import time')
            time = scope['time']
            self.assertIsInstance(time, ImportReplacer)
            self.assertIs(time._resolve(), time)

        def test_lazy_import_double(self):
            scope = {}
            lazy_import(scope, 'import time\nimport os')
            self.assertIsInstance(scope['time'], ImportReplacer)
            self.assertIsInstance(scope['os'], ImportReplacer)

        def test_lazy_import_from(self):
            scope = {}

# Generated at 2022-06-21 21:56:02.001679
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ should work as expected."""
    inst = IllegalUseOfScopeReplacer('name', 'msg')
    repr(inst)



# Generated at 2022-06-21 21:56:14.131036
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib.transport
    import bzrlib.branch

    def check_lazy(name):
        # Make sure that a module was not imported, but an ImportReplacer
        # started.
        return isinstance(globals()[name], ImportReplacer)

    scope = globals()
    scope['bzrlib'] = 1
    scope['bzrlib.transport'] = 2
    scope['bzrlib.branch'] = 3

    proc = ImportProcessor()

# Generated at 2022-06-21 21:56:23.310231
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ does not raise UnicodeEncodeError when printing

    This is sometimes used for tracebacks for errors we want users to report
    so we want it to be as robust as possible.
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # Assume this will be in sys.excepthook soon
    import traceback
    try:
        e = IllegalUseOfScopeReplacer('foo', 'bar')
        raise e
    except Exception:
        type, value, tb = sys.exc_info()
        lines = traceback.format_exception(type, value, tb)
        # the traceback should not raise a UnicodeEncodeError in python 2.5
        ''.join(lines)
# END test_IllegalUseOfScopeReplacer___str__



# Generated at 2022-06-21 21:56:30.908772
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    x = IllegalUseOfScopeReplacer('name', 'hi', 'there')
    y = IllegalUseOfScopeReplacer('name', 'hi', 'there')
    z = IllegalUseOfScopeReplacer('name', 'hi')
    assert x == y
    assert x != z
    assert y != z
    assert x == x
    assert y == y
    assert z == z
    from bzrlib import symbol_versioning
    assert symbol_versioning.deprecated_passed(x)
    assert symbol_versioning.deprecated_passed(y)
    assert symbol_versioning.deprecated_passed(z)



# Generated at 2022-06-21 21:56:37.406251
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return unicode with utf8 encoding"""
    # __unicode__ should return unicode with utf8 encoding
    e = IllegalUseOfScopeReplacer('foo', u'bar', u'b\xE2z')
    assert isinstance(unicode(e), unicode)
    assert unicode(e).encode('utf8') == 'foo was used incorrectly: bar: b\xc3\xa2z'

# Generated at 2022-06-21 21:56:48.325002
# Unit test for function lazy_import
def test_lazy_import():
    import sys
    import bzrlib

    mod1 = sys.modules.pop('bzrlib', None)
    if mod1 is not None:
        del sys.modules['bzrlib']

    mod2 = sys.modules.pop('bzrlib.foo', None)
    if mod2 is not None:
        del sys.modules['bzrlib.foo']

    # Make sure the module isn't loaded
    try:
        bzrlib.foo
    except AttributeError:
        pass
    else:
        raise AssertionError('lazy_import should not have imported foo')

    def cleanup():
        if mod1 is not None:
            sys.modules['bzrlib'] = mod1
        if mod2 is not None:
            sys.modules['bzrlib.foo'] = mod2