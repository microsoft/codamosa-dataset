

# Generated at 2022-06-21 21:47:25.809257
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    def check_imported_module(text, num_imports):
        # Create a ScopeReplacer, that will override imported modules.
        scope = {}
        import_processor = ImportProcessor()
        import_processor.lazy_import(scope, text)
        # Check for the number of imports
        real_num_imports = len(scope)
        if real_num_imports != num_imports:
            raise AssertionError("%d modules imported. Expected %d"
                                 % (real_num_imports, num_imports))
        # Make sure that the module has been imported
        for module in scope.itervalues():
            # Use object.__getattribute__ to avoid ImportReplacer.__getattribute__
            if None is object.__getattribute__(module, "_resolve")():
                raise Ass

# Generated at 2022-06-21 21:47:32.164777
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test constructor of class IllegalUseOfScopeReplacer.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    s = str(e)


# List of global variables that should be replaced by ScopeReplacer.
# This list is used by the lazy_import function.
# It is important that the following names are not added to this list:
# '_', '__builtins__', '__doc__', '__file__', '__name__', '__path__', '__version__'.

# Generated at 2022-06-21 21:47:42.729987
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """The str() of IllegalUseOfScopeReplacer should be given a value."""
    e = IllegalUseOfScopeReplacer('spam', 'eggs')
    s = str(e)
    # Depending on the location of the bzrlib path, this may be different:
    # '/home/robertc/src/bzrlib/bzrlib/lazy_import.py'
    # '/u1/robertc/src/bzrlib/bzrlib/lazy_import.py'
    # '/usr/local/python/lib/python2.4/site-packages/bzrlib/lazy_import.py'

# Generated at 2022-06-21 21:47:51.634033
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    d = {}
    v = ImportReplacer(d, 'foo', ['foo', 'bar'], None, {})
    assert isinstance(v, ImportReplacer)
    assert repr(v) == 'ImportReplacer(None, member=None, name=foo, ' \
        'module_path=[\'foo\', \'bar\'], scope={}'
    assert v._module_path == ['foo', 'bar']
    assert v._member is None
    assert v._name == 'foo'
    assert v._import_replacer_children == {}
    assert v._scope == d



# Generated at 2022-06-21 21:47:57.130837
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib
    import bzrlib.parser

    disallow_proxying()

    x = bzrlib

    # It is ok to import 'bzrlib.parser', but not to assign it to 'y'
    # because 'bzrlib' is a proxy.
    try:
        y = bzrlib.parser
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'bzrlib'
    else:
        raise AssertionError("bzrlib should have been a proxy, but it's not")

    from bzrlib.branch import Branch
    b1 = Branch()

    # It is ok to import 'bzrlib.branch.Branch', but not to assign it to 'b2'.
    # Because 'bzrlib.branch'

# Generated at 2022-06-21 21:48:09.350896
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    class Mock(object):
        def __init__(self):
            self.called = 0
        def __getattribute__(self, name):
            self.called += 1
            return object.__getattribute__(self, name)
    obj = Mock()
    bzrlib.lazy_import.ScopeReplacer(sys.modules, lambda x, y, z: obj, '__name__')
    # Proxy the obj through a local variable, so that accesses are caught and
    # the 'proxy_obj' can be replaced.
    proxy_obj = sys.modules['__name__']
    # Try accessing the attribute __name__
    e = sys.exc_info()[1]

# Generated at 2022-06-21 21:48:18.117849
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test that we cannot set an attribute on a ScopeReplacer with
    # _should_proxy=False.
    import sys
    import tempfile
    tmp = tempfile.mkdtemp()
    sys.path.insert(0, tmp)

    saved_should_proxy = ScopeReplacer._should_proxy
    ScopeReplacer._should_proxy = False


# Generated at 2022-06-21 21:48:30.793647
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import sys
    try:
        if sys.exc_clear() is None:
            raise AssertionError()
    except AttributeError:
        # exc_clear not available in all pythons, e.g. python 2.4
        pass
    # Check that equals raises NotImplementedError
    is_actually_illegal_use = IllegalUseOfScopeReplacer("foo", "blah", "blah")
    try:
        if is_actually_illegal_use == "a":
            raise AssertionError("IllegalUseOfScopeReplacer should not"
                                 " compare equal to a string.")
    except NotImplementedError:
        pass
    import bzrlib.tests
    bzrlib.tests.run_doctest(__name__, __file__)



# Generated at 2022-06-21 21:48:41.395412
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor"""
    # Simple test of the constructor with normal arguments
    ip = ImportProcessor()
    ip.lazy_import(globals(), 'import foo')
    assert(globals()['foo'] is not None)
    assert(globals()['foo']._import_replacer_children == {})
    assert(globals()['foo']._member is None)
    assert(globals()['foo']._name == 'foo')
    assert(globals()['foo']._scope is globals())
    assert(globals()['foo']._factory.func_name == '_import')
    assert(globals()['foo']._module_path == ['foo'])
    # Test of extra arguments to the constructor
    lazy_import_class

# Generated at 2022-06-21 21:48:52.253024
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer."""
    from unittest import TestCase
    import bzrlib.lazy_import as _mod_lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class Test_ScopeReplacer(TestCase):
        def test_Source_called_before_import(self):
            # Calling __call__ on a ScopeReplacer should resolve the
            # replacement object and call its __call__ method.
            import bzrlib.tests
            bzrlib.tests.called = False
            def test_callable():
                return 1
            def test_callable_factory(scope_replacer, scope, name):
                return test_callable
            def test_init_factory(scope_replacer, scope, name):
                return b

# Generated at 2022-06-21 21:49:06.187234
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Tests for ImportReplacer"""
    # Test simple import
    scope = {}
    ImportReplacer(scope=scope, name='foo', module_path=['foo'], member=None)
    # Test import with member
    scope = {}
    ImportReplacer(scope=scope, name='bar', module_path=['foo'], member='bar')
    # Test import with child
    scope = {}
    ImportReplacer(scope=scope, name='foo', module_path=['foo'], member=None,
                   children={'bar':(['foo', 'bar'], None, {})})


# Generated at 2022-06-21 21:49:16.697147
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests.test_lazy_import import TestUninstrumentedImports
    import sys
    scope = {}
    children = {'Foo': (['bzrlib', 'tests', 'test_lazy_import', 'TestUninstrumentedImports'], 'Foo', {})}
    ImportReplacer(scope=scope, name='TestUninstrumentedImports',
                   module_path=['bzrlib', 'tests', 'test_lazy_import', 'TestUninstrumentedImports'],
                   children=children)
    scope['TestUninstrumentedImports']
    scope['TestUninstrumentedImports'].Foo
    assert isinstance(scope['TestUninstrumentedImports'], TestUninstrumentedImports)

# Generated at 2022-06-21 21:49:28.493231
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    class MyObject(object):
        def __init__(self, param1, param2, param3):
            self._param1 = param1
            self._param2 = param2
            self._param3 = param3
        def _resolve(self):
            return self
        def __call__(self, param1, param2, param3, **kwargs):
            return param1 + param2 + param3

    my_obj = MyObject('x', 'y', 'z')
    assert my_obj('a', 'b', 'c', arg4='w') == 'abc'
    sr = ScopeReplacer(my_obj, None, None)
    assert sr is not my_obj
    assert sr._resolve() is my_obj

# Generated at 2022-06-21 21:49:38.740933
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying() disables proxying."""
    lazy_import(globals(), '''
        from bzrlib import (
            osutils,
            urlutils,
            )
        ''')
    # Proxying should be enabled
    assert osutils._should_proxy
    assert urlutils._should_proxy
    disallow_proxying()
    # Proxying should be disabled
    assert not osutils._should_proxy
    assert not urlutils._should_proxy
test_disallow_proxying.unittest_skip = 'Function not designed for use by unit tests'



# Generated at 2022-06-21 21:49:50.947012
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for function disallow_proxying"""
    import bzrlib
    scope = {}
    lazy_import(scope, "from bzrlib import lazy_import")
    assert scope["lazy_import"] is bzrlib.lazy_import
    assert ScopeReplacer._should_proxy
    disallow_proxying()
    assert not ScopeReplacer._should_proxy
    # Importing a new module should be allowed to create a proxy
    scope = {}
    lazy_import(scope, "from bzrlib import builder_dirstate")
    assert scope["builder_dirstate"] is not bzrlib.builder_dirstate
    # Using a already replaced module should fail
    scope = {}
    lazy_import(scope, "from bzrlib import errors")
    assert scope["errors"] is b

# Generated at 2022-06-21 21:49:54.357053
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import bzrlib.lazy_import
    exc = bzrlib.lazy_import.IllegalUseOfScopeReplacer(
        'name', 'msg', 'extra')
    unicode(exc)



# Generated at 2022-06-21 21:50:05.294216
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    test_case = TestCase()
    import sys

    # Create a lazy import that would work normally
    d = { 'x': "some value" }
    lazy_import(d, '''from bzrlib import errors''')
    test_case.assertEqual("some value", d['x'])
    test_case.assertIsInstance(d['errors'], ScopeReplacer)
    e = d['errors']
    # Inject a dummy 'errors' module in sys.modules, as if it had been imported
    # from the actual module
    sys.modules['bzrlib.errors'] = object()
    disallow_proxying()
    test_case.assertRaises(IllegalUseOfScopeReplacer, getattr, e, 'errors')
    # Now make sure that

# Generated at 2022-06-21 21:50:17.033979
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """test_ImportProcessor_lazy_import()
    Test that, when using ImportProcessor, assigning __import__ to
    something else after installing the lazy import doesn't break
    the lazy import.
    """
    import_processor = ImportProcessor()
    import_processor.lazy_import(globals(),
        """import bzrlib.foo, bzrlib.bar.baz
        from bzrlib.foo import bar, baz as gadget
        from bzrlib import frob, default_transport""")

    import sys
    __import__ = sys.__import__
    from bzrlib.foo import bar
    from bzrlib import frob, default_transport
    bzrlib.bar.baz
    bzrlib.foo
    bzrlib.foo.bar


# Generated at 2022-06-21 21:50:30.018720
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib import log
    import threading
    import time

# Generated at 2022-06-21 21:50:39.699572
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # Test code for 'ImportProcessor'
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestCaseWithTransport

    # the mock_import method is the base class of both.
    class TestImportReplacer(ImportReplacer):
        def _import(self, scope, name):
            if isinstance(self, TestCase):
                # The instrumented version wants to be imported as
                # 'import bzrlib.tests.test_lazy_import.Instrumented
                # ImportReplacer. a non instrumented version wants to be
                # imported as 'import bzrlib.tests.test_lazy_import.TestImportReplacer'
                name = 'bzrlib.tests.test_lazy_import' + '.' + \
                    self.__class__.__name__
           

# Generated at 2022-06-21 21:50:51.085712
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ doesn't raise.

    This test is just a defensive test to ensure the IllegalUseOfScopeReplacer
    __repr__ method doesn't raise.  It doesn't actually test that the
    output is correct.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    repr(e)
test_IllegalUseOfScopeReplacer___repr__()



# Generated at 2022-06-21 21:51:01.583578
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Check that __getattribute__ works as expected

    In particular we test that illegal uses of the lazy object will
    raise an exception.
    """

    def factory(self, scope, name):
        return 42

    global_obj = {}
    lazy_obj = ScopeReplacer(global_obj, factory, 'name1')
    class MyObject(object):

        def __init__(self):
            self.foo = 1

    # Check that proxy works correctly
    assert lazy_obj.foo == 1

    # Check that proxy is not allowed after object is resolved
    obj = lazy_obj._resolve()
    obj.bar = 2

# Generated at 2022-06-21 21:51:06.816261
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    class Test(IllegalUseOfScopeReplacer):
        def __init__(self, a, b):
            super(Test, self).__init__(a, "a was %r" % (a,),
                                       "b was %r" % (b,))
    Test(1, 2)



# Generated at 2022-06-21 21:51:12.808754
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that it is impossible to use lazy_import'ed modules as proxies.
    """
    from bzrlib.tests import TestUtil
    t = TestUtil.TestCase("test_disallow_proxying")
    lazy_import(globals(), "from bzrlib.tests import TestCase")
    t.assertRaises(IllegalUseOfScopeReplacer, TestCase, "test_test_test")
# return the test case, to be added to a test suite somewhere
test_disallow_proxying = [test_disallow_proxying]



# Generated at 2022-06-21 21:51:26.640520
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib.lsprof
    import sys
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_blackbox
    import bzrlib.tests.blackbox.test_blackbox.TestCaseWithTransport
    import bzrlib.tests.blackbox.test_blackbox.TestCaseWithTransport.testSomething

    scope = {}
    import_text = '''
        import sys
        import bzrlib.lsprof as lsprof
        from bzrlib.tests import blackbox
        from bzrlib.tests.blackbox import (test_blackbox,
            TestCaseWithTransport)
        import bzrlib.tests.blackbox.test_blackbox.TestCaseWithTransport
    '''
    processor = ImportProcessor()

# Generated at 2022-06-21 21:51:37.484919
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    def func1(self, scope, name):
        return self
    def func2(self, scope, name):
        return self

    replacer = ScopeReplacer({}, func1, 'x')
    replacer2 = ScopeReplacer({}, func2, 'y')

    replacer.x = 0
    replacer.y = 1

    replacer2.x = 2
    replacer2.y = 3

    # Verify scope is set to object returned from func1
    assert sys.modules['__main__'].x is replacer
    # Verify scope is set to object returned from func2
    assert sys.modules['__main__'].y is replacer2


# Generated at 2022-06-21 21:51:50.130117
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    import bzrlib
    lazy_import(globals(), '''
        from bzrlib.tests import TestCase
    ''')


# Generated at 2022-06-21 21:52:02.569955
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import can load the lazy_import module"""
    def test_me():
        """This function should be able to import the lazy_import module"""
        import lazy_import
        return lazy_import

    test_scope = {}
    lazy_import(test_scope, '''
    from bzrlib import (
        lazy_import,
        )
    ''')

    result = test_me()
    if result is not lazy_import:
        raise AssertionError('result should be the module, but is %r'
                             % (result,))

    # Assert that lazy_import did not actually import anything
    if 'lazy_import' in test_scope:
        raise AssertionError('lazy_import should not have resolved')
test_lazy_import.todo = 'Not yet implemented'



# Generated at 2022-06-21 21:52:09.079145
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str, not a unicode object"""
    # Create an instance of the exception class
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'qux')
    # Check that the result of __str__() is a str object
    assert isinstance(str(e), str)



# Generated at 2022-06-21 21:52:19.025682
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Calling the constructor should set the name, msg and extra.

    The repr() should print out the message.
    """
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = '%(msg)s'

    e = MyException('a', 'b')
    assert e.__dict__ == {'name': 'a', 'msg': 'b', 'extra': ''}
    assert repr(e) == "MyException('b')"


# Generated at 2022-06-21 21:52:33.932070
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ returns True iff the attributes are equal"""
    a = IllegalUseOfScopeReplacer('a', 'b', 'c')
    b1 = IllegalUseOfScopeReplacer('a', 'b', 'c')
    b2 = IllegalUseOfScopeReplacer('a', 'b', 'd')
    b3 = IllegalUseOfScopeReplacer('a', 'c', 'c')
    b4 = IllegalUseOfScopeReplacer('b', 'b', 'c')
    c = IllegalUseOfScopeReplacer('a', 'b')
    d = Exception('a')
    assert a == b1 and a != b2 and a != b3 and a != b4 and a != c and a != d



# Generated at 2022-06-21 21:52:46.002740
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'])
    assert scope['foo']._member is None
    assert scope['foo']._module_path == ['foo']
    assert scope['foo']._import_replacer_children == {}

    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], member='bar')
    assert scope['foo']._member == 'bar'
    assert scope['foo']._module_path == ['foo']
    assert scope['foo']._import_replacer_children == {}

    scope = {}
    ImportReplacer(scope, 'foo', ['foo'],
                   children={'bar':(['foo', 'bar'], None, {})})
    assert scope['foo']._member is None
    assert scope['foo']._module_path

# Generated at 2022-06-21 21:52:57.524452
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import traceback
    from bzrlib import errors, osutils, branch, lazy_import
    from bzrlib.branch import Branch

    # test_ScopeReplacer___getattribute__() was generated using the following
    # code:
    #
    #     # First, generate a function that will create the lazy import.  It
    #     # uses a 'with' statement and closures to capture the correct local
    #     # 'scope' and 'factory' variables:
    #
    #     def make_factory(name, module_name, class_name):
    #         def factory(self, scope, name):
    #             module = __import__(module_name, scope, scope, [class_name])
    #             cls = getattr(module, class_name)
    #             instance = cls

# Generated at 2022-06-21 21:53:09.930005
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test for constructor of class ScopeReplacer"""
    # Constructor should work
    global abc
    replacer = ScopeReplacer(globals(), lambda self, scope, name: 1, 'abc')
    # replacer should be in the scope
    if abc is not replacer:
        raise AssertionError("replacer is not in the scope")
    # replacer should not have a real object
    if replacer._real_obj is not None:
        raise AssertionError("replacer should not have a real object")
    # resolving the replacer should return an object
    if replacer._resolve() != 1:
        raise AssertionError("resolving the replacer should return an object")
    # replacer should have a real object

# Generated at 2022-06-21 21:53:21.507879
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method IllegalUseOfScopeReplacer.__eq__"""
    # Test for when 'other' is of a different class
    s = IllegalUseOfScopeReplacer('name', 'msg')
    class OtherException(Exception):
        def __init__(self, msg):
            self.msg = msg
    o = OtherException('msg')
    assert (s.__eq__(o) is NotImplemented)
    assert (o.__eq__(s) is NotImplemented)
    # Test for when 'other' is of the same class
    o = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert (s.__eq__(o) is False)
    o = IllegalUseOfScopeReplacer('name', 'msg')
    assert (s.__eq__(o) is True)




# Generated at 2022-06-21 21:53:25.796379
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test constructor of class ScopeReplacer."""
    def factory(self, scope, name):
        return 1

    scope = dict()
    name = 'name'
    scope_replacer = ScopeReplacer(scope, factory, name)

    assert scope_replacer._factory == factory
    assert scope_replacer._scope == scope
    assert scope_replacer._name == name
    assert scope_replacer._real_obj is None
    assert scope_replacer.__slots__ == ('_scope', '_factory', '_name', '_real_obj')
    assert scope_replacer._should_proxy is True



# Generated at 2022-06-21 21:53:32.586758
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should return whether attributes are equal

    This should include self._preformatted_string.
    """
    # test for when: self._preformatted_string is not None.
    a = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    a._preformatted_string = 'something'
    b = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    b._preformatted_string = 'something'
    assert a == b

    # test for when self._preformatted_string is None
    a = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    b = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert a == b


# Generated at 2022-06-21 21:53:37.786285
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test what happens when we print a IllegalUseOfScopeReplacer object.
    """
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert (str(exc) ==
        "<class 'bzrlib.lazy_import.IllegalUseOfScopeReplacer'>"
        "(name='name', msg='msg', extra='extra')")



# Generated at 2022-06-21 21:53:43.975224
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # should be able to take a normal string and convert it.
    # well, a very simple normal string
    ip = ImportProcessor()
    ip.lazy_import(globals(), '''
    import os.path
    from os import path
    ''')

# Generated at 2022-06-21 21:53:52.818106
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # This is called in test_import_lazy to ensure the test_import_lazy
    # tests all branches in ImportProcessor.lazy_import.
    # This function is not exported, because it is only a helper
    # function for the test_import_lazy test.
    # The tests here are a subset of what's tested in test_import_lazy.
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_import_lazy import TestImportLazy
    # We want to test all code paths in ImportProcessor, so we need to
    # instrumentalize the imports so that we can tell which imports actually
    # happened.

# Generated at 2022-06-21 21:54:10.157677
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    text = '''
            # Comment
            from foo import bar as baz, bing
            import foo
            import foo.bar

            import foo.bar.baz as bing
            from foo.bar import bar
            from foo.bar import bar, bing
            from foo import bar as bing, foo as foo2
            from foo import (bar as bing,
                             foo as foo2,
                             baz)
            '''
    ip = ImportProcessor()
    ip.lazy_import({}, text)



# Generated at 2022-06-21 21:54:16.328017
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns a unicode object"""
    def _make_obj():
        return IllegalUseOfScopeReplacer(name='a', msg='b', extra='c')
    str_type = _make_obj().__unicode__().__class__
    assert str_type is unicode



# Generated at 2022-06-21 21:54:27.995843
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import __builtin__
    scope = {}
    # Can't have a child entry when member is specified.
    try:
        ImportReplacer(scope, 'foo', ['foo'], member='foo', children={})
        raise AssertionError('should not be able to supply a member and'
                             ' children')
    except ValueError:
        pass
    # member entry is created as an attribute of the module
    ImportReplacer(scope, 'foo', ['foo'], member='foo', children=None)
    foo = scope['foo']
    __builtin__.__dict__['__foo__'] = foo

    # children entries are created as attributes on the module,
    # and are themselves ImportReplacer objects

# Generated at 2022-06-21 21:54:39.921775
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib import (
        osutils,
        )
    
    class TestScope(object):
        pass
    s = TestScope()
    t = ImportProcessor()
    t.lazy_import(s, "from  bzrlib import osutils")
    t.lazy_import(s, " import osutils")
    t.lazy_import(s, "import osutils as foo, osutils as bar")
    t.lazy_import(s, "import bzrlib.foo, bzrlib.bar")
    t.lazy_import(s, """\
      from bzrlib import osutils
      import osutils
      """)
    t.lazy_import(s, "import osutils, foo.bar as baz, (foo.bar, bad.bad)")




# Generated at 2022-06-21 21:54:47.260841
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    d = {'foo':None}
    bzrlib.lazy_import.ScopeReplacer(d, lambda o,s,n: o, 'foo')
    try:
        d['foo'].foo = 'bar'
        raise AssertionError("__setattr__ should have thrown an exception")
    except bzrlib.lazy_import.IllegalUseOfScopeReplacer:
        # Should raise
        pass


# Generated at 2022-06-21 21:54:51.179422
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer"""
    obj = IllegalUseOfScopeReplacer("name", "msg", "extra")
    repr(obj)

# Generated at 2022-06-21 21:55:01.863247
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Create a ScopeReplacer and perform some tests.

    This is a unit test for the ScopeReplacer class.
    """
    import sys
    import gc
    from bzrlib import lazy_import
    lazy_import(locals(), '''
    import bzrlib
    ''')
    # Use sys.path to do the name testing.
    sys.path = sys.path[:]
    lazy_object = bzrlib.ScopeReplacer(sys.path, lambda r, s, name: s[name],
                                       "lazy_object")
    # Test that the object is behaving as expected.
    lazy_object.append("foo")
    assert lazy_object[-1] == "foo"

    # Remove the reference to the object and make sure we can still get at it
    del lazy_object
    lazy_

# Generated at 2022-06-21 21:55:12.671414
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import as _mod_lazy_import
    class FakeScopeReplacer(_mod_lazy_import.ScopeReplacer):
        """An object like ScopeReplacer that has a simple way to introspect
        calls to __setattr__, __getattribute__ and __call__.
        """
        seen = None
        def __getattribute__(self, attr):
            self.seen = ('__getattribute__', attr)
            return super(FakeScopeReplacer, self).__getattribute__(attr)
        def __setattr__(self, attr, value):
            self.seen = ('__setattr__', attr, value)
            return super(FakeScopeReplacer, self).__setattr__(attr, value)

# Generated at 2022-06-21 21:55:22.818187
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test the method ImportProcessor.lazy_import"""
    import bzrlib
    import bzrlib.errors
    import bzrlib.trace
    scope = {'ImportProcessor': ImportProcessor}

# Generated at 2022-06-21 21:55:31.336805
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # we need to be able to generate a random string to represent
    # a possible name, which is why we import random here
    from random import randint
    from bzrlib.lazy_import import scope_replacer
    scope = {}
    # we generate the name by making it the callable name, concatenated
    # with a random number from 0 to 1000.
    name = ('%s_%i' % ('function_name', randint(0, 1000)))
    scope_replacer(scope, lambda obj, scope1, name1: name1, name)
    assert scope[name]() == name

# Generated at 2022-06-21 21:55:52.792174
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """ScopeReplacer doesn't have a lot, but we should test it anyway.

    It is important to ensure that ScopeReplacer does not accidentally
    resolve itself, as a common case is to replace an object at the same time as
    it is generated. (ie, a lambda, or some other function that does the import
    and returns itself).
    """
    scope = {}
    def factory(sr, scope, name):
        scope['factory.pre_resolve'] = sr()
        return sr

# Generated at 2022-06-21 21:56:02.069974
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    x = ScopeReplacer(sys.modules, lambda s,m,n: sys.modules[n], 'x')
    x.a = 1
    del x
    try:
        disallow_proxying()
    except AttributeError as e:
        # We are running from an old interpreter where ScopeReplacer doesn't
        # have _should_proxy
        if e.args[0] != '_should_proxy':
            raise
    else:
        x = ScopeReplacer(sys.modules, lambda s,m,n: sys.modules[n], 'x')
        try:
            x.a = 1
        except IllegalUseOfScopeReplacer as e:
            if (e.name != 'x' or
                e.msg != "Object already replaced, did you assign it to another variable?"):
                raise
       

# Generated at 2022-06-21 21:56:06.592798
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ must return a str"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    r = repr(e)
    assert isinstance(r, str)


# Generated at 2022-06-21 21:56:17.983211
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__ of ScopeReplacer"""
    from bzrlib.lazy_import import lazy_import
    import bzrlib
    lazy_import(locals(), '''
    from bzrlib import bzrdir
    ''')
    p = bzrdir.__path__
    # No errors are thrown by the use of the following
    p = bzrdir.__path__
    p = bzrdir.__path__
    p = bzrdir.__path__
    p = bzrdir.__path__
    p = bzrdir.__path__
    p = bzrdir.__path__
    p = bzrdir.__path__
    p = bzrdir.__path__
    p = bzrdir.__path__

# Generated at 2022-06-21 21:56:24.457375
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__"""
    class A(IllegalUseOfScopeReplacer):
        pass
    class B(IllegalUseOfScopeReplacer):
        pass
    a1 = A(1, 2, 3)
    a2 = A(1, 2, 3)
    a3 = A(2, 3, 4)
    a4 = A(1, 2, 4)
    a5 = A(1, 3, 3)
    b1 = B(1, 2, 3)
    assert a1 == a2
    assert a2 == a1
    assert a1 != a3
    assert a1 != a4
    assert a1 != a5
    assert a1 != b1



# Generated at 2022-06-21 21:56:34.408108
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.per_lazy_import
    test_obj = bzrlib.tests.per_lazy_import.LazyImportModule()
    import bzrlib.tests
    m = ScopeReplacer(bzrlib.tests.__dict__,
                      bzrlib.tests.per_lazy_import.lazy_module_factory,
                      'module_placeholder')
    bzrlib.tests.module_placeholder()


# Generated at 2022-06-21 21:56:37.878777
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor

    This test is just to demonstrate that we can create an instance of the
    ImportProcessor class
    """
    import_processor = ImportProcessor()
    return import_processor



# Generated at 2022-06-21 21:56:45.697391
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.tests

    def create_test_object(self, scope, name):
        """Create the real object of this class So that ScopeReplacer is
        able to be tested.

        :param self: The instance of ScopeReplacer
        :param scope: The scope that ScopeReplacer lives in
        :param name: The name of the ScopeReplacer in the scope

        The real object will be created.
        """
        class Test(object):

            def __init__(self):
                self.name = name
                self.scope = scope
                self.self = self

            def get_attribute_of_self(self):
                return self.name

            def get_attribute_of_scope(self):
                return self.scope

        return Test()

    #__getattribute__ is called when accessing attributes of the


# Generated at 2022-06-21 21:56:51.227577
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    c = IllegalUseOfScopeReplacer
    x = c('foo', 'bad')
    y = c('bar', 'bad')
    z = c('foo', 'bad')
    assert x == z, "expected x == z"
    assert x != y, "expected x != y"
test_IllegalUseOfScopeReplacer___eq__()

