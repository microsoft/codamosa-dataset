

# Generated at 2022-06-21 21:47:27.417137
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib.tests
    bzrlib.tests.support.run_test_test = lambda *args: args
    t = bzrlib.tests.TestCase('run_test_test')
    scope = scope_import_module(t)
    text = '''
    import bzrlib.tests.run_test_test
    from bzrlib.tests import run_test_test as run_unit
    import (bzrlib.tests,
            bzrlib.tests.run_test_test as run_function)
    '''
    processor = ImportProcessor()
    processor.lazy_import(scope, text)

    assert scope['run_unit'].__name__ == 'run_test_test'
    assert scope['run_function'].__name__ == 'run_test_test'

# Generated at 2022-06-21 21:47:33.467238
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should produce an informative string."""
    e = IllegalUseOfScopeReplacer('spam', 'msg', 'more')
    assert repr(e) == "IllegalUseOfScopeReplacer('spam', 'msg', 'more')"



# Generated at 2022-06-21 21:47:43.544224
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the ImportReplacer constructor.

    The constructor is used when dynamic imports are done. As this
    mechanism is used for test isolation, these tests should be
    located in a non-isolated test module.
    """
    from bzrlib import lazy_import
    scope = {} # module scope is empty
    import_replacer = lazy_import.ImportReplacer(scope,
        name='foo', module_path=['bzrlib', 'foo'])
    import_replacer = lazy_import.ImportReplacer(scope,
        name='foo', module_path=['bzrlib', 'foo'],
        children={'bar': (['bzrlib', 'foo', 'bar'], None, {})})

# Generated at 2022-06-21 21:47:55.248229
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """ImportProcessor.lazy_import converts text into a map of imports.

    It converts the text into a map of imports. It then converts the map
    into a set of import objects. Each import object will then import
    itself when requested.
    """
    prototype = ImportProcessor()
    # TODO: jam 20060912 We should be validating that we got the right
    #       imports, but for now we are just concerned that it doesn't
    #       raise an exception, and the debugger says it got all the
    #       imports correct, so it is close enough

# Generated at 2022-06-21 21:48:00.516354
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__(self) should return 'str', not 'unicode'"""

# Generated at 2022-06-21 21:48:04.673541
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import types
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class _SampleClass(object):
        _x = "sample attribute"
        def get_x(self):
            return self._x
    def factory(self, scope, name):
        return _SampleClass()
    def test_attr(self, scope, name):
        lazy = scope[name]
        self.assertEqual(_SampleClass._x, lazy.get_x())
        self.assertEqual(_SampleClass._x, lazy._x)
        self.assertIs(type(lazy), _SampleClass)
    def test_call(self, scope, name):
        lazy = scope[name]
        lazy.get_x()

# Generated at 2022-06-21 21:48:15.568143
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import unittest

    class TestCase(unittest.TestCase):
        """TestCase for class ScopeReplacer."""

        def setUp(self):
            from bzrlib.lazy_import import lazy_import
            global x
            global y
            global z
            x = ScopeReplacer({}, lambda a, b, c: a, 'x')

        def test__set_same_ScopeReplacer_twice(self):
            y = ScopeReplacer({}, lambda a, b, c: a, 'y')
            ScopeReplacer._should_proxy = False

            try:
                y.x = y
            except IllegalUseOfScopeReplacer:
                pass
            else:
                self.fail('Should have raised exception.')

        def test__set_ScopeReplacer_then_use(self):
            y = Scope

# Generated at 2022-06-21 21:48:22.344590
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a bytestring."""
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # In Python3, the str() of an exception should return a bytestring.
    result = str(exc)
    assert isinstance(result, str), \
        "str(exc) should return a bytestring, got %r" % (result,)


# Generated at 2022-06-21 21:48:33.632924
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestDisallowProxying(TestCase):
        # The goal of this test is to demonstrate that disallow_proxying
        # works and that it causes runtime exceptions when used
        # incorrectly.
        # Note: the call to disallow_proxying must come outside of this class.

        def test_disallow(self):
            self.assertTrue(ScopeReplacer._should_proxy)
            disallow_proxying()
            self.assertFalse(ScopeReplacer._should_proxy)
            self.assertRaises(IllegalUseOfScopeReplacer, setattr,
                              bzrlib, 'lazy_import', 'foo')


# Generated at 2022-06-21 21:48:43.152532
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # try not to modify global namespace
    g = {}
    global_scope = g
    exec('import sys', global_scope)
    global_scope['foo'] = 1
    ip = ImportProcessor()
    ip.lazy_import(global_scope, 'import foo\n')
    __tracebackhide__ = True
    if 'foo' not in global_scope:
        raise TestNotApplicable('global scope does not contain foo')
    if type(global_scope['foo']) is not ImportReplacer:
        raise TestNotApplicable('foo is not a ImportReplacer object')
    # check that 'foo' hasn't been imported yet
    global_scope['foo'] = 'does not import foo'
    if 'foo' in sys.modules:
        raise TestNotApplicable('foo has already been imported')
    # now access the Import

# Generated at 2022-06-21 21:48:59.573848
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys

    # this test is slightly delicate because the class variable of
    # ImportReplacer _should_proxy is checked in the _resolve method.
    # _resolve is in turn called by __getattribute__, which is called
    # by all the accessor methods in python.
    # So this test is an attempt to ensure that we can access all the
    # methods of the imported libraries and get their
    # correct value.

    from bzrlib.tests import TestCaseWithTransport

    class TestImportProcessor(TestCaseWithTransport):

        def test_I_import(self):
            """Ensure that we can handle a single import"""
            ip = ImportProcessor()
            ip.lazy_import({}, 'import bzrlib')
            self.assertRaises(ImportError, ip.import_name)
            bz

# Generated at 2022-06-21 21:49:07.611874
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
  """This tests the method 'lazy_import' of class ImportProcessor."""
  import_processor = ImportProcessor()

  scope = {}
  import_processor.lazy_import(scope, 'import foo')

  if 'foo' not in scope:
    raise test_fail('ImportProcessor.lazy_import: test 1 - failing.')

  if not isinstance(scope['foo'], ImportReplacer):
    raise test_fail('ImportProcessor.lazy_import: test 2 - failing.')

  # at this point we have presented one import line to the ImportProcessor.
  # since the ImportProcessor is working properly so far, we can use the
  # ImportProcessor to present multiple lines of imports to the ImportProcessor
  # and see how it handles more imports.

# Generated at 2022-06-21 21:49:17.077637
# Unit test for function lazy_import
def test_lazy_import():
    # Check that unreachable symbols don't exist
    class FakeModule(object):
        __slots__ = ['called', '__dict__']
        def __init__(self):
            self.called = False
        def __getattr__(self, attr):
            self.called = True
            raise AttributeError()

    fake1 = FakeModule()
    fake2 = FakeModule()
    globals()['_lazy_import_test_bzrlib'] = fake1
    lazy_import(globals(), '''
        from _lazy_import_test_bzrlib import _lazy_import_test_bar
        ''')
    globals()['_lazy_import_test_bzrlib'] = fake2

    # Now the import should be in place, but not yet called

# Generated at 2022-06-21 21:49:27.058559
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    lazy_import(locals(), '''
    from bzrlib.lazy_import import lazy_import
    ''')

    class TestScopeReplacer(TestCase):

        def test_disallow_proxying(self):
            scope = {}
            lazy_import(scope, 'from bzrlib.tests import TestCase')
            # The object is not yet replaced, so we can assign to it
            scope['TestCase'] = None
            # The object is replaced, so we cannot assign to it anymore
            self.assertRaises(IllegalUseOfScopeReplacer,
                              disallow_proxying)
            # We can still access the members of the object
            scope['TestCase'].__name__


# Generated at 2022-06-21 21:49:40.314107
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_processor = ImportProcessor()

    import_processor.lazy_import({}, "import foo.bar")
    assert import_processor.imports == {'foo':
        (['foo'], None, {'bar': (['foo', 'bar'], None, {})})}

    import_processor.imports = {}
    import_processor.lazy_import({}, "import foo.bar as bing")
    assert import_processor.imports == {'bing': (['foo', 'bar'], None, {})}

    import_processor.imports = {}
    import_processor.lazy_import({}, "from foo import bar")
    assert import_processor.imports == {'bar': (['foo'], 'bar', {})}

    import_processor.imports = {}

# Generated at 2022-06-21 21:49:51.958679
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Build a fake package, then import from it."""
    from bzrlib import tests
    fake_dir = tests.subdir_test_module('fake_module')
    fake_package = fake_dir.module_name
    fake_submodule = fake_package + '.submodule'

    class FakeModule(object):
        attr1 = 'attr1'
        class submodule(object):
            attr2 = 'attr2'

    sys.modules[fake_package] = FakeModule
    sys.modules[fake_submodule] = FakeModule.submodule

    # The following lines are what most lazy imports will look like
    # Most of this is normally done by the function 'lazy_import'
    # (see below)
    from importlib import import_module
    def _import(scope, name):
        return import_module

# Generated at 2022-06-21 21:50:03.701900
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib.tests import TestCase
    from bzrlib import symbol_versioning

    class FakeScope(object):
        def __init__(self):
            self.old_modules = {}
            self.new_modules = {}

        def __setitem__(self, key, value):
            self.old_modules[key] = value

        def __getitem__(self, key):
            # this is needed to allow self.old_modules[key] to be replaced
            return None

    class TestImportProcessor(TestCase):

        def make_fake_scope(self):
            return FakeScope()


# Generated at 2022-06-21 21:50:07.586727
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    e = IllegalUseOfScopeReplacer('foo', 'bar', sys)
    str(e)
    unicode(e)
    e._get_format_string()



# Generated at 2022-06-21 21:50:11.577656
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {'name': 'value'}
    def factory(self, scope, name):
        return scope[name]
    replacer = ScopeReplacer(scope, factory, 'name')



# Generated at 2022-06-21 21:50:18.064721
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # TODO: perhaps find a better way to do the tests...
    import sys

    def factory(self, scope, name):
        return [name, scope, self]

    obj = ScopeReplacer(sys._getframe(1).f_globals, factory, 'obj')

    # Verify that __getattribute__ works
    assert obj[0] == 'obj', obj

    # Verify that __call__ works
    assert obj() == ['obj', sys._getframe(1).f_globals, obj], obj



# Generated at 2022-06-21 21:50:38.592267
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor"""
    importprocessor = ImportProcessor()
    importprocessor.lazy_import({}, """\
        import bzrlib, bzrlib.foo, bzrlib.bar.baz as bing
        from bzrlib.perf import perf_counter
        """)
    # TODO: jam 20060912 We should assert that the imports are turned into
    #       the right lazy objects.


# Generated at 2022-06-21 21:50:43.565201
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying() works"""
    class myclass(ScopeReplacer):
        pass
    disallow_proxying()
    import sys
    def factory(placeholder, scope, name):
        return placeholder
    myobj = myclass(sys.modules, factory, 'myclass')
    try:
        temp = myobj
    except IllegalUseOfScopeReplacer:
        e = sys.exc_info()[1]
        assert e.msg == "Object already replaced, did you assign it to another variable?"
    else:
        assert False, "Expected exception IllegalUseOfScopeReplacer"



# Generated at 2022-06-21 21:50:52.385195
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that we can disable proxying for unit tests.

    This is important to avoid accidental proxy objects being passed
    around.
    """
    sample_mod = {}
    lazy_import(sample_mod, '''
    from bzrlib import (
        osutils,
        )
    ''')

    disallow_proxying()
    try:
        osutils.dirname('foo')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'osutils'
        assert e.msg == 'Object already replaced, did you assign it to' \
                        ' another variable?'
    else:
        raise AssertionError('Expected IllegalUseOfScopeReplacer exception')



# Generated at 2022-06-21 21:51:02.128459
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestLazyImport__call__(TestCase):
        """Tests for the ScopeReplacer method __call__"""
        # Using plain 'lambda' here leaves the callable unbound and this
        # results in 'TypeError: unbound method must be called with
        # instance as first argument'.
        def test_ScopeReplacer___call__(self):
            factory = lambda self_obj, scope, name: lambda *args, **kwargs: (
                (self_obj, scope, name, args, kwargs))
            import sys
            scope = sys._getframe(1).f_globals
            name = 'test_callable'
            obj = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-21 21:51:06.189131
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for constructor of class ScopeReplacer."""
    scope = {}

    def factory(self, scope, name):
        object.__setattr__(self, '_scope', scope)
        object.__setattr__(self, '_name', name)
        return self

    name = 'x'
    x = ScopeReplacer(scope, factory, name)
    try:
        assert x._scope == scope
        assert x._name == name
    except AttributeError:
        # This means that the scope was not replaced.
        raise AssertionError('ScopeReplacer did not replace scope.')


# Generated at 2022-06-21 21:51:17.571480
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__"""
    scope = {}
    def factory(self, scope, name):
        return self
    def helper():
        return ScopeReplacer(scope, factory, 'name')
    # name should appear in the given scope
    name = helper()
    if 'name' not in scope:
        raise AssertionError('name should be in scope')
    # factory should be called the first time it is used
    try:
        name == name
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Usage of name should cause an exception')
    # name should be replaced in its scope
    if name != scope['name']:
        raise AssertionError('name should be in scope')



# Generated at 2022-06-21 21:51:19.194934
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor."""
    processor = ImportProcessor()



# Generated at 2022-06-21 21:51:26.569329
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    # This would be safe, but we want to catch usage of the lazy import
    # so we disable the proxy here.
    disallow_proxying()
    try:
        osutils
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('An exception should have been raised when '
            'using a lazy imported object after it has been resolved.')



# Generated at 2022-06-21 21:51:34.603987
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ needs to be tested"""
    class TestException(Exception):
        _fmt = "TestException in %(where)s"
    class TestSubException(TestException):
        _fmt = "Sub %(where)s"
    e = TestException(where="A")
    assert str(e) == 'TestException in A'



# Generated at 2022-06-21 21:51:40.922928
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    test_exception = ILLEGAL_USE_OF_SCOPE_REPLACER
    ex = test_exception('hello', 'world')
    assert ex.name == 'hello'
    assert ex.msg == 'world'
    assert ex.extra == ''


ILLEGAL_USE_OF_SCOPE_REPLACER = IllegalUseOfScopeReplacer



# Generated at 2022-06-21 21:51:56.542100
# Unit test for method lazy_import of class ImportProcessor

# Generated at 2022-06-21 21:52:06.946978
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.lazy_import import ImportReplacer

    # Test with a single import
    scope = {}
    name = 'foo'
    module_path = ['foo']
    replacer = ImportReplacer(scope, name, module_path)
    assert scope[name] is replacer

    # Test with a module with children
    scope = {}
    name = 'foo'
    module_path = ['foo']
    member = None
    children = {'bar':()}
    replacer = ImportReplacer(scope, name, module_path, member=member,
        children=children)
    assert scope[name] is replacer

    # Test with a member import
    scope = {}
    name = 'bar'
    module_path = ['foo']
    member = 'bar'
    children = {'bar':()}

# Generated at 2022-06-21 21:52:14.547765
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class SomeScope(object):
        def __init__(self):
            self.attrs = {}

        def __setitem__(self, key, val):
            self.attrs[key] = val

        def __getitem__(self, key):
            return self.attrs[key]

    scope = SomeScope()

    # test that it raises if the factory tries to replace itself
    def factory1(sr, scope, name):
        raise Exception('Factory1 failed to install object')

    try:
        ScopeReplacer(scope, factory1, 'illegal')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'illegal'
        assert str(e).startswith('Object tried to replace itself, check it\'s')
    else:
        raise AssertionError('Expected exception not raised')

    #

# Generated at 2022-06-21 21:52:20.660634
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    exc = IllegalUseOfScopeReplacer('a', 'b')
    expected = "%s(a, b, '')" % exc.__class__.__name__
    eq_ = lambda: '%r != %r' % (exc.__repr__(), expected)
    from nose.tools import assert_equal
    assert_equal(exc.__repr__(), expected, eq_())



# Generated at 2022-06-21 21:52:28.415446
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return the formatted message."""
    msg = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    u = msg.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'foo\' was used incorrectly: bar: baz'



# Generated at 2022-06-21 21:52:34.693175
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Ensure that the ScopeReplacer object behaves correctly"""

    def factory(scope_replacer, scope, name):
        return "hello, world"

    # Create a scope replacer and ensure that it can only be called once
    scope = {}
    scope_replacer = ScopeReplacer(scope, factory, "test")
    assert scope["test"] == scope_replacer
    assert scope_replacer() == "hello, world"
    assert scope["test"] == "hello, world"

    assert scope_replacer() == "hello, world"
    assert scope["test"] == "hello, world"


# Generated at 2022-06-21 21:52:46.359386
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ should return True if two objects have identical fields.

    And it should return NotImplemented if they are not the same
    class.
    """
    instance = IllegalUseOfScopeReplacer('name', 'message')
    instance2 = IllegalUseOfScopeReplacer('name', 'message')
    assert instance == instance2
    assert instance == instance

    instance3 = IllegalUseOfScopeReplacer('OTHERname', 'message')
    assert instance != instance3
    assert instance != instance3

    class Subclass(IllegalUseOfScopeReplacer):
        pass
    subinstance = Subclass('name', 'message')
    assert instance != subinstance



# Generated at 2022-06-21 21:52:51.344414
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    import sys
    result = lazy_import(sys.modules, '''
    import bzrlib.trace
    import bzrlib.revision
    ''')
    result.run_tests()



# Generated at 2022-06-21 21:53:02.890513
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # Even though it is not used, this must be specified.
    scope = {}
    for val in ('foo', 'bar', 'baz', 'x'):
        scope[val] = val
    bzrlib = ImportReplacer(scope=scope, name='bzrlib',
                            module_path=['bzrlib'], member=None,
                            children={'osutils':(['bzrlib', 'osutils'], None,
                                    {'foo':(['bzrlib', 'osutils', 'foo'], None,
                                    {})})})
    # Should have set baz in scope to a ScopeReplacer object, and left the
    # other objects in the scope unchanged
    assert scope['bar'] == 'bar'
    assert scope['baz'] == 'baz'

# Generated at 2022-06-21 21:53:06.620306
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the ScopeReplacer constructor"""

    class MyObject(object):
        pass
    scope = {}
    ScopeReplacer(scope, lambda s, sc, n: MyObject(), 'myobj')
    obj = scope['myobj']
    assert isinstance(obj, ScopeReplacer)
    assert scope['myobj']._scope is scope
    assert scope['myobj']._name == 'myobj'

# Generated at 2022-06-21 21:53:20.904103
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    class MyException(Exception):
        def __str__(self):
            return u'string\u2603'
    e = IllegalUseOfScopeReplacer('test', 'illegal use', MyException())
    assert isinstance(e.__str__(), str)



# Generated at 2022-06-21 21:53:22.619155
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """__init__ should create temporary object in the specified scope."""
    scope = {}
    factory = lambda self, scope, name: True
    name = 'foo'

    s = ScopeReplacer(scope, factory, name)
    assert scope[name] is s
    assert s._scope is scope



# Generated at 2022-06-21 21:53:31.286791
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import types

    # test that real objects work
    l = []
    sr = ScopeReplacer({}, lambda o, s, n: l, 'l')
    l.append(3)
    if sr._resolve() != l:
        raise AssertionError()
    if sr[0] != 3:
        raise AssertionError()
    if sr.__class__ is not list:
        raise AssertionError()
    if getattr(sr, "append")(4) is not None:
        raise AssertionError()
    if sr[1] != 4:
        raise AssertionError()
    def bar(*args, **kwargs):
        return (args, kwargs)

# Generated at 2022-06-21 21:53:35.644682
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    a = IllegalUseOfScopeReplacer('a', 'b', 'c')
    b = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert a == b
test_IllegalUseOfScopeReplacer___eq__()



# Generated at 2022-06-21 21:53:40.717806
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test constructor of IllegalUseOfScopeReplacer."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    try:
        raise e
    except IllegalUseOfScopeReplacer as e:
        s = str(e)

# Generated at 2022-06-21 21:53:44.552296
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    l = IllegalUseOfScopeReplacer("my object", "reason")
    assert "reason" in str(l)
    assert "my object" in str(l)
    assert "reason" in unicode(l)
    assert "my object" in unicode(l)


# Generated at 2022-06-21 21:53:55.737589
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import bzrlib.transport

    from bzrlib.lazy_import import lazy_import, disallow_proxying
    disallow_proxying()
    lazy_import(globals(), 'from bzrlib import transport')
    try:
        transport.get_transport_from_url("http://fake")
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("transport was used as a proxy after"
                             " disallow_proxying was called.") # pragma: no cover
    # transport was not lazy so it should be imported before disallow_proxying
    # was called.
    bzrlib.transport.get_transport_from_url("http://fake")



# Generated at 2022-06-21 21:54:07.507412
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib.lsprof
    import bzrlib.trace
    from bzrlib.trace import mutter, error, note, warning, mutter_callsite, \
        mutter_tail
    import sys
    import bzrlib.missing

# Generated at 2022-06-21 21:54:19.294363
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        """For testing the ImportReplacer constructor"""

        def test_one(self):
            # Test the most basic case
            module = {}
            ImportReplacer(scope=module, name='foo', module_path=['foo'])
            self.assertEqual(1, len(module))
            foo = module['foo']
            self.assertIsInstance(foo, ImportReplacer)
            self.assertEqual('foo', foo._name)

        def test_children(self):
            # Test a simple case with children
            module = {}
            ImportReplacer(scope=module, name='foo', module_path=['foo'],
                           children={'bar':(['foo', 'bar'], None, {})})

# Generated at 2022-06-21 21:54:26.218671
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-21 21:54:46.652522
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class ImportReplacerFake(ImportReplacer):
        _imports = []

        def _import(self, scope, name):
            self._imports.append((scope, name))

    scope = {}
    ImportReplacerFake(scope=scope, name='foo', module_path='foo',
                       member=None, children={})
    # foo module was imported
    assert ImportReplacerFake._imports == [(scope, 'foo')]

    ImportReplacerFake._imports = []
    ImportReplacerFake(scope=scope, name='foo', module_path='foo',
                       member=None, children={'bar':(['foo', 'bar'], None, {})})
    # foo module was imported
    assert ImportReplacerFake._imports == [(scope, 'foo')], \
        ImportReplacerFake._imports
    # foo.

# Generated at 2022-06-21 21:54:49.259688
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class Foo(ScopeReplacer):
        """Test that the ScopeReplacer constructor works properly."""

    scope = {}
    foo = Foo(scope, lambda s,scop,n: "dummy", "foo")


# Generated at 2022-06-21 21:54:54.941263
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """See 'test_lazy_import.py' for a more complete test."""
    scope = {}
    import_replacer = ImportReplacer(scope, 'foo', ['foo'])
    assert scope['foo']._import_replacer_children == {}
    assert scope['foo']._member is None
    assert scope['foo']._module_path == ['foo']
    assert scope['foo']._name == 'foo'
    assert scope['foo']._scope is scope



# Generated at 2022-06-21 21:55:07.328367
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() should return the expected value:
    'IllegalUseOfScopeReplacer(name, msg, extra)'
    """

# Generated at 2022-06-21 21:55:11.361248
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying() raises an IllegalUseOfScopeReplacer
    exception"""
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''import bzrlib.transform''')
    disallow_proxying()
    try:
        transform
        raise AssertionError("Should have raised")
    except IllegalUseOfScopeReplacer:
        pass



# Generated at 2022-06-21 21:55:21.680268
# Unit test for function lazy_import
def test_lazy_import():
    """Unit test for function lazy_import"""
    scope = {}

    lazy_import(scope, '''
    import foo
    import foo.bar
    import foo.bar.baz
    ''')
    assert len(scope) == 1, scope
    assert 'foo' in scope, scope
    assert isinstance(scope['foo'], ScopeReplacer)

    scope['foo'] = 23
    assert scope['foo'] == 23

    scope = {}
    lazy_import(scope, '''
    from foo import bing
    ''')
    assert len(scope) == 1, scope
    assert 'bing' in scope, scope
    assert isinstance(scope['bing'], ScopeReplacer)



# Generated at 2022-06-21 21:55:28.448155
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # IllegalUseOfScopeReplacer is a subclass of Exception.
    from bzrlib import (
        errors,
        )
    # It has a parameterised constructor.
    e1 = errors.IllegalUseOfScopeReplacer('bar', 'foo')
    e2 = errors.IllegalUseOfScopeReplacer('foo', 'bar')
    # It has an __eq__ method.
    assert e1 == e1
    assert not e1 == e2


# Generated at 2022-06-21 21:55:38.023724
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import StringIO
    import sys
    import threading
    import traceback
    import warnings

    from bzrlib.tests.blackbox import ExternalBase

    class TestScopeReplacer(ExternalBase):

        def test_threading(self):
            # Test that exception is raised when ScopeReplacer object
            # is used from another thread.
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.tests import (
                TestCase,
                TestSkipped,
                )

            class Dummy(object):
                def __init__(self):
                    self.a = 1

                def b(self):
                    return 2
            dummy = Dummy()
            scope = {'dummy':None}
            sr = ScopeReplacer(scope, lambda obj,scope,name: dummy, 'dummy')

           

# Generated at 2022-06-21 21:55:49.130540
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import as m_lazy_import; reload(m_lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    scope = {'name': None}
    def f(self, scope, name):
        scope[name] = 'value'
        return scope[name]
    o = ScopeReplacer(scope, f, 'name')
    o.a = 1
    if (not (o.a == 1)): raise AssertionError()
    if (not (scope['name'] == 'value')): raise AssertionError()
    if (not ('_real_obj' in dir(o))): raise AssertionError()

# Generated at 2022-06-21 21:55:59.618045
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    import sys
    import traceback
    import unittest

    class ToBeReplaced(object):
        def __init__(self):
            self.boink = 'I was called'

        def __call__(self, *args, **kwargs):
            return (self.boink, args, kwargs)

    class Test(unittest.TestCase):
        def test_call(self):
            replacer = ScopeReplacer(sys.modules, ToBeReplaced, 'ToBeReplaced')
            self.assertEqual(replacer.boink, 'I was called')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              lambda: replacer.boink) # already filled in

# Generated at 2022-06-21 21:56:19.664098
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer."""
    # This test is needed because __unicode__ is implemented in a way
    # that depends on variables in the scope where it is used.
    # This test fails if we do not implement __unicode__ in a way that
    # guarantees it can be used outside the scope where it is defined.
    # See the method __unicode__ for details.
    import sys
    if 'bzrlib.tests' in sys.modules:
        from bzrlib.tests import TestCase
    else:
        from unittest import TestCase
    from bzrlib.trace import mutter
    mutter('Testing IllegalUseOfScopeReplacer.__unicode__')
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'extra')

# Generated at 2022-06-21 21:56:24.029402
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # This is needed by tests so test can check for IllegalUseOfScopeReplacer
    # being raised. Otherwise, when called, the real object will be resolved,
    # and so the test will never see the exception.
    return object.__getattribute__(self, attr)



# Generated at 2022-06-21 21:56:37.790139
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that disallow_proxying() raises an exception in __getattribute__."""
    import sys
    g = {}
    # We set _should_proxy to True to trick the ScopeReplacer object into
    # letting us proxy some attributes, otherwise it will make the object
    # not work.

# Generated at 2022-06-21 21:56:45.641505
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test equality.

    'e' and 'f' are unequal because 'e' has a non-default 'extra' attribute.
    """
    class DummyException(Exception):
        _fmt = "dummy"
    class Subclass(DummyException):
        pass
    e = IllegalUseOfScopeReplacer('name1', 'msg1', 'extra1')
    f = IllegalUseOfScopeReplacer('name1', 'msg1')
    g = IllegalUseOfScopeReplacer('name1', 'msg2') # different message
    h = IllegalUseOfScopeReplacer('name3', 'msg1') # different name
    assert e != f
    assert e == e
    assert e != g
    assert e != h
    # Ensure that equality comparisons work for subclasses too.
    assert e == Subclass(e)



# Generated at 2022-06-21 21:56:56.798736
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    # The method __eq__ should return True if and only if the difference
    # between the two objects are the empty dict.
    e0 = IllegalUseOfScopeReplacer('e0', 'msg', 'extra')
    e1 = IllegalUseOfScopeReplacer('e1', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer('e2', 'msg', 'extra')
    e3 = IllegalUseOfScopeReplacer('e3', 'msg', 'extra')
    assert e0 == e1
    assert e0 != e2, '%r != %r' % (e0, e2)
    assert e0 != e3, '%r != %r' % (e0, e3)
    d = dict(e0.__dict__)
    e0.__dict__['a'] = 'b'