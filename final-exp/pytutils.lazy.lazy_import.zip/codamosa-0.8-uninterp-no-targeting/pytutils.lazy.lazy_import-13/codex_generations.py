

# Generated at 2022-06-21 21:47:25.736593
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """ImportReplacer should parse import statements."""
    def local_import(name, module_path, children):
        """Test helper to construct an ImportReplacer"""
        # could use bzrlib.lazy_import._local_import, but that's a private
        # function, and we don't want to expose it here.
        # this function doesn't need to be instrumented.
        return ImportReplacer(scope=globals(), name=name,
                              module_path=module_path, children=children)

    local_import('bzrlib', ['bzrlib'], {})
    assert bzrlib._import_replacer_children == {}
    local_import('bzrlib', ['bzrlib', 'progress'], {})
    assert bzrlib._import_replacer_children == {}
   

# Generated at 2022-06-21 21:47:30.794643
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_text = """
    from bzrlib import foo, bar
    from bzrlib import foo as bar, bar as baz
    from bzrlib import foo, bar, baz
    import bzrlib.foo
    import bzrlib.foo.bar
    import bzrlib.foo.bar as baz
    """
    ip = ImportProcessor()
    ip.lazy_import(globals(), import_text)
    import bzrlib
    assert 'bzrlib' in globals()
    assert 'foo' in bzrlib.__dict__
    assert 'foo' in bzrlib.__dict__
    assert 'foo' in bzrlib.__dict__
    assert 'bar' in bzrlib.__dict__
    assert 'baz' not in b

# Generated at 2022-06-21 21:47:35.356351
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test method __setattr__ of class ScopeReplacer

    This test is temporary disabled.
    """
    #
    #test_ScopeReplacer___setattr__() isn't relevant until __proxied__ is
    #implemented.
    #
    return



# Generated at 2022-06-21 21:47:40.269778
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Repr should show class and object in simple cases

    This test is especially to show the failure mode.

    >>> class Test(Exception):
    ...     pass
    >>> err = Test('test')
    >>> repr(err)
    Traceback (most recent call last):
    ...
    AttributeError: 'NoneType' object has no attribute '__name__'
    """



# Generated at 2022-06-21 21:47:52.251519
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import sys
    import types

    if 'lazy_import_test' in sys.modules:
        del sys.modules['lazy_import_test']
    try:
        del sys.modules['__builtin__.lazy_import_test']
    except KeyError:
        pass

    local_dict = {}
    global_dict = {}

# Generated at 2022-06-21 21:48:00.266299
# Unit test for function disallow_proxying
def test_disallow_proxying():
    def check_lazy(m, v):
        m.disallow_proxying()
        # We can't use a lambda here because it needs to be pickleable
        def factory(*args, **kwargs):
            raise Exception("Should not be called")
        m.ScopeReplacer(v, factory, 'x')
        # Make sure the test passes even if x is already set
        del v['x']
        v['x'] = 42
        # Now x should be set to 42, not a ScopeReplacer
        assert v['x'] == 42
        # Accessing the attribute should result in an exception
        m.lazy_import(v, '''x''')
        try:
            # v['x'] is already replaced by 42
            v['x']
        except m.IllegalUseOfScopeReplacer as e:
            assert e

# Generated at 2022-06-21 21:48:07.343233
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    # Test the constructor.  In particular, the exception message.
    scope = {}
    try:
        ScopeReplacer(scope, lambda x, y, z: x, 'x')
    except IllegalUseOfScopeReplacer as e:
        assert(str(e) == "ScopeReplacer object 'x' was used incorrectly:"
                          " Object tried to replace itself, check it's not"
                          " using its own scope.")


# Generated at 2022-06-21 21:48:16.494911
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    global __doctest_imports__ # pylint: disable=W0601
    from bzrlib.lazy_import import ScopeReplacer
    mod_name = 'bzrlib.tests.test_lazy_import'
    __doctest_imports__ = {mod_name: l_imports}
    # Check the attributes of the instance of ScopeReplacer can be modified.
    l_imports.x = 1
    assert l_imports.x == 1
    # Check the attributes of the instance of ScopeReplacer can be modified.
    l_imports.y.z = 'foo'
    assert l_imports.y.z == 'foo'
# test_ScopeReplacer___setattr__()

# Generated at 2022-06-21 21:48:26.087965
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """The method __eq__ of class IllegalUseOfScopeReplacer should return
    True for two class instances which have equal attributes.

    """
    class C(object):
        def __eq__(self, other):
            return True

    c1 = C()
    c2 = C()
    e1 = IllegalUseOfScopeReplacer('name', 'msg', c1)
    e2 = IllegalUseOfScopeReplacer('name', 'msg', c2)
    assert e1 == e2

_alpha_order = ('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
                '0123456789_')



# Generated at 2022-06-21 21:48:35.157325
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Ensure that the ScopeReplacer object can be created."""
    class DummyScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            super(DummyScopeReplacer, self).__init__(scope, factory, name)

    d = {}
    DummyScopeReplacer(d, lambda x, y, z: x, 'x')
    DummyScopeReplacer(d, lambda x, y, z: y, 'y')
    DummyScopeReplacer(d, lambda x, y, z: z, 'z')
    assert d['x'] is d['y'] is d['z'] is d



# Generated at 2022-06-21 21:48:52.936465
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    import bzrlib
    lazy_import(vars(bzrlib), 'os')
    os = bzrlib.os
    disallow_proxying()

# Generated at 2022-06-21 21:49:02.196859
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib.tests import modules
    ip = ImportProcessor(ImportReplacer)
    test_scope = modules.construct_test_tree()
    ip.lazy_import(test_scope, 'import bzrlib')
    ip.lazy_import(test_scope, 'from bzrlib import revisiontree')
    ip.lazy_import(test_scope, 'import bzrlib.revisiontree')
    ip.lazy_import(test_scope, 'import bzrlib.revisiontree as revtree')
    ip.lazy_import(test_scope, 'import bzrlib.revisiontree as revtree')
    ip.lazy_import(test_scope, 'from bzrlib import revisiontree as revtree')
    # Also test for duplicate imports within a line which should be converted


# Generated at 2022-06-21 21:49:15.506035
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class TestableScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            # Hack to support testing, do not do this elsewhere
            object.__setattr__(self, '_real_obj', None)
            # Hack to support testing, do not do this elsewhere
            object.__setattr__(self, '_should_proxy', True)
            super(TestableScopeReplacer, self).__init__(scope, factory, name)

    class TestableScopeReplacer2(ScopeReplacer):
        def __init__(self, scope, factory, name):
            # Hack to support testing, do not do this elsewhere
            object.__setattr__(self, '_real_obj', None)
            # Hack to support testing, do not do this elsewhere

# Generated at 2022-06-21 21:49:28.246065
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    def do_test(first, second, expected):
        """Do test values with __eq__"""
        if expected:
            assert first == second
            assert second == first
            assert not (first != second)
            assert not (second != first)
        else:
            assert first != second
            assert second != first
            assert not (first == second)
            assert not (second == first)
    do_test(
        IllegalUseOfScopeReplacer('a', 'x', 'y'),
        IllegalUseOfScopeReplacer('a', 'x', 'y'),
        True)
    do_test(
        IllegalUseOfScopeReplacer('a', 'x', 'y'),
        IllegalUseOfScopeReplacer('b', 'x', 'y'),
        False)

# Generated at 2022-06-21 21:49:36.879039
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    obj = ScopeReplacer(
        scope = {},
        factory = callable,
        name = 'x')
    def _call_func():
        pass
    # Verify that we see the real object
    obj.__getattribute__ = _call_func
    if obj.__getattribute__ is not _call_func:
        raise AssertionError('obj.__getattribute__ should have value %s, got %s' % (_call_func, obj.__getattribute__))

# Generated at 2022-06-21 21:49:44.007183
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib import lazy_import
    import bzrlib.lazy_import
    _scope = {}
    _factory = lambda s, sc, n: None
    _name = 'name'
    l = lazy_import.ScopeReplacer(_scope, _factory, _name)
    # _resolve is called, obj is None so the factory is called and the object
    # is created and set to '_real_obj' slot; the object is then returned.

# Generated at 2022-06-21 21:49:53.736016
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should produce 8 bit strings

    This is a regression test for bug #93861.
    """
    import bzrlib.errors
    bzrlib.errors.IllegalUseOfScopeReplacer.__unicode__ = (
        lambda x: u'foo')
    e = bzrlib.errors.IllegalUseOfScopeReplacer('bar', 'baz')
    s = e.__str__()
    if isinstance(s, unicode):
        raise AssertionError('IllegalUseOfScopeReplacer.__str__ must produce '
                             'an 8-bit string')



# Generated at 2022-06-21 21:50:04.880203
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # pylint: disable=W0212
    from bzrlib.tests.lazy_import import make_to_string_broker
    from bzrlib.tests.lazy_import import make_to_string_factory
    # pylint: enable=W0212
    # Create a ScopeReplacer, and replace the real object.
    replace_name = 'replace_me'
    replace_scope = locals()
    replace_factory = make_to_string_factory('REPLACED')
    replace_obj = ScopeReplacer(replace_scope, replace_factory, replace_name)

# Generated at 2022-06-21 21:50:15.549541
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__() should return a string with all parameters of the error"""
    from bzrlib import lazy_import
    e = lazy_import.IllegalUseOfScopeReplacer(
        "foo", "bar", "baz")
    repr_val = repr(e)
    repr_val.index("foo")
    repr_val.index("bar")
    repr_val.index("baz")
    # Test if something is added to the error.
    e = lazy_import.IllegalUseOfScopeReplacer(
        "foo", "bar")
    repr_val = repr(e)
    repr_val.index("foo")
    repr_val.index("bar")



# Generated at 2022-06-21 21:50:19.809765
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """The method __repr__ of class IllegalUseOfScopeReplacer should
    return a string."""
    r = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(repr(r), str)

# Generated at 2022-06-21 21:50:30.267230
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Tests for ImportReplacer"""
    # Wrong types
    # None member, not None children
    try:
        ImportReplacer(scope={}, name='foo', module_path=['foo'],
            member=None, children={'bar':(['foo', 'bar'], None, {})})
    except ValueError:
        pass
    else:
        assert False


# Ideally the __name__ should be a list like in the constructor, but we
# don't have support for that yet.

# Generated at 2022-06-21 21:50:36.268696
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer(
        "foo",
        "Bar")
    assert e.name == "foo"
    assert e.msg == "Bar"
    assert e.extra == ""

# Generated at 2022-06-21 21:50:43.239321
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    ip.lazy_import(scope=None, text="""\
    from bzrlib import workingtree, osutils, ui
    from bzrlib.branch import Branch
    import bzrlib.errors
    from bzrlib import (
        revision as _mod_revision,
        config as _mod_config)
    """)

# Generated at 2022-06-21 21:50:53.476528
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that ScopeReplacer.disallow_proxying works."""
    import bzrlib
    import bzrlib.dirstate

# Generated at 2022-06-21 21:51:02.850284
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ for IllegalUseOfScopeReplacer"""

    class E(IllegalUseOfScopeReplacer):
        _fmt = '%(name)s %(msg)s'

    e = E('lazy_import', 'error1')
    assert e._format() == u'lazy_import error1'

    e = E('lazy_import', 'error1', extra='error2')
    assert e._format() == u'lazy_import error1: error2'

    # This 'IllegalUseOfScopeReplacer' has an error in the format string
    # And as such, we should see the error message, not the format error
    class E(IllegalUseOfScopeReplacer):
        _fmt = '%(name)s %(msg)s%(error)s'


# Generated at 2022-06-21 21:51:05.728989
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    e = IllegalUseOfScopeReplacer('name', 'message')
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'message')"



# Generated at 2022-06-21 21:51:09.519373
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """
    IllegalUseOfScopeReplacer.__repr__()
    """
    obj = IllegalUseOfScopeReplacer('obj_name', 'message')
    repr = obj.__repr__()
    assert repr == ("IllegalUseOfScopeReplacer("
                    "'obj_name', 'message')"), repr



# Generated at 2022-06-21 21:51:12.194138
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_obj = ScopeReplacer(None, None, 'test')
    test_obj.attr = 'value'
    # Asserts.
    assert test_obj.attr == 'value', test_obj.attr

# Generated at 2022-06-21 21:51:25.076898
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Assert IllegalUseOfScopeReplacer.__eq__(other)

    Equality is checked by comparing the exceptions attributes in __dict__.
    """
    # since __eq__ is implemented without calling super, we override it
    # here again to test the right behavior
    class Super(object):
        def _get_format_string(self):
            return 'test'
        def __eq__(self, other):
            return NotImplemented
    class A(IllegalUseOfScopeReplacer, Super):
        pass
    my_dict = dict(name='name', msg='msg', extra='extra')
    a = A(**my_dict)
    b = a
    assert a == b, "Equality operator should return True if compared to self"
    b = A(**my_dict)

# Generated at 2022-06-21 21:51:37.921296
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    __tracebackhide__ = True
    class TestClass:
        def __init__(self):
            pass
    test_scope = {'foo': TestClass()}

    imp = ImportProcessor()
    str = 'from bzrlib.foo import bar'

    __ = imp._convert_from_str
    __tracebackhide__ = True
    assert_raises(ValueError, __, imp, 'import hello')
    assert_raises(ValueError, __, imp, 'from hello import')
    assert_raises(ValueError, __, imp, 'from hello import *')
    assert_raises(ValueError, __, imp, 'from hello import bar,*')
    assert_raises(ValueError, __, imp, 'from hello import bar as ifoobar,*')

# Generated at 2022-06-21 21:51:48.865908
# Unit test for function lazy_import
def test_lazy_import():
    _ConcreteParent = object()

    class TestLazyImportRecorder(object):
        """A test object which counts how many times it has been accessed"""
        __slots__ = ['_access_count']

        def __init__(self):
            self._access_count = 0

        def __getattribute__(self, attr):
            obj = object.__getattribute__(self, '_access_count')
            self._access_count += 1
            return obj

    class TestLazyImportReplacer(ScopeReplacer):
        """Instrumented version of ScopeReplacer for testing"""

        def _resolve(self):
            self.access_count += 1
            return super(TestLazyImportReplacer, self)._resolve()


# Generated at 2022-06-21 21:51:51.406394
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    pass


# Generated at 2022-06-21 21:52:03.444524
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib.tests import TestCase
    class TestIllegalUseOfScopeReplacer(TestCase):

        def test__format_not_overridden(self):
            exc = IllegalUseOfScopeReplacer('name', 'msg')
            self.assertEqualDiff(
                'Unprintable exception IllegalUseOfScopeReplacer: dict={'
                '\'name\': \'name\', \'extra\': \'\', \'msg\': \'msg\'}, '
                'fmt=\'%(name)r was used incorrectly: %(msg)s%(extra)s\', '
                'error=None',
                exc._format())

        def test_format_overridden(self):
            exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')

# Generated at 2022-06-21 21:52:13.509074
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of class IllegalUseOfScopeReplacer"""
    # Testing method IllegalUseOfScopeReplacer.__str__
    # with variant 1, argument 'extra' = "msg\n:\n"
    # and argument 'msg' = "msg"
    # and argument 'name' = "name"

    # Call the function
    r = IllegalUseOfScopeReplacer("name", "msg", "msg\n:\n")
    # Check the result
    expected = "ScopeReplacer object 'name' was used incorrectly: msg: msg\\n:\\n"
    got = str(r)
    if (expected != got):
        raise ValueError('__str__ returned:\n%s\nexpected:\n%s' % (got, expected))
    # Check the result



# Generated at 2022-06-21 21:52:23.276603
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # test_ScopeReplacer___getattribute__()
    # This is an autogenerated by testtools.deferredruntest.
    from bzrlib.tests.lazy_import_scenarios import LazyModule
    from bzrlib.tests.lazy_import_scenarios import LazyModule2
    from bzrlib.tests.lazy_import_scenarios import LazyModule3
    from bzrlib.tests.lazy_import_scenarios import LazyObject
    from bzrlib.tests.lazy_import_scenarios import LazyObject2
    from bzrlib.tests.lazy_import_scenarios import LazyObject3
    from bzrlib.tests.lazy_import_scenarios import LazyObject4

# Generated at 2022-06-21 21:52:34.549737
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, disallow_proxying, ScopeReplacer
    import __builtin__
    class DummyModule(object):
        __name__ = 'dummy'
        def __init__(self, name):
            assert name != '__builtin__'
            self.name = 'dummy.%s' % (name,)
            __builtin__.__dict__[name] = self
        def __repr__(self):
            return self.name
    def import_module(module_name):
        return DummyModule(module_name)
    def fake_import(*names):
        for name in names:
            import_module(name)
    b = __builtin__
    b.__import__ = fake_import

# Generated at 2022-06-21 21:52:37.218759
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__

    checks return values of class IllegalUseOfScopeReplacer.
    """
    e = IllegalUseOfScopeReplacer('scope', 'x')
    assert_equal(e.__str__(), "The scope replacer 'scope' was used incorrectly: x")



# Generated at 2022-06-21 21:52:46.932467
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """The __unicode__ method must return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    # __unicode__ should return a correctly encoded unicode object.
    e = IllegalUseOfScopeReplacer('f\xE9', 'b\xe0r')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'IllegalUseOfScopeReplacer(fé, bàr)'
    # Test that the format string can be language specific
    e._fmt = 'Illegal use of %(name)r: %(msg)s'
    e._preformatted_string = 'foo'
    u = e.__unicode__()


# Generated at 2022-06-21 21:52:57.980193
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import_processor = ImportProcessor()
    scope = {}
    import_processor.lazy_import(scope, 'from foo import bar, baz')
    import_processor.lazy_import(scope, 'import foo')
    import_processor.lazy_import(scope, 'import foo.bar, bing, foo.bar.baz as bing')
    test_dict = {'foo': (['foo'], None, {'bar':
        (['foo', 'bar'], None, {'baz': (['foo', 'bar', 'baz'], None, {})})}),
        'bar': (['foo'], 'bar', {}), 'baz': (['foo'], 'baz', {}),
        'bing': (['foo', 'bar', 'baz'], None, {})}

# Generated at 2022-06-21 21:53:10.638911
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import re
    import sys
    lazy_module_name = 'lazy_module'
    module_name = 'module_name'
    class_name = 'ClassName'
    object_name = 'object_name'
    class_member = 'class_member'
    object_member = 'object_member'

    def test_line(line, module_name=module_name, class_name=class_name,
                  object_name=object_name, class_member=class_member,
                  object_member=object_member):
        scope = {}
        import_processor = ImportProcessor()
        import_processor.lazy_import(scope, line)
        module = scope[lazy_module_name]
        class_ = getattr(module, class_name)
        return getattr(class_, class_member), get

# Generated at 2022-06-21 21:53:36.006035
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    import os
    os.rmdir(tmp_dir)
    scope = {}
    import bzrlib.branch
    def factory(sr, scope, name):
        return os # factory is called with (self, scope, name)
    ScopeReplacer(scope, factory, 'os')
    assert scope['os'] is not os # os is not in the scope yet
    assert scope['os'].walk is os.walk # os.walk is in the scope now

# Generated at 2022-06-21 21:53:46.191011
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import doctest
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestSkipped

    class MyObject(object):
        pass
    exist_obj = MyObject()
    exist_obj.my_method = lambda *args, **kwargs: ('my_method', args, kwargs)
    exist_obj.my_attr = 'my_attr'
    orig_getattr = getattr

# Generated at 2022-06-21 21:53:50.207417
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert(str(e) == "ScopeReplacer object 'name' was used incorrectly: msg: extra")
    assert(repr(e) == "IllegalUseOfScopeReplacer('ScopeReplacer object %r was used incorrectly: %r: %r')" % ('name', 'msg', 'extra'))

# Generated at 2022-06-21 21:54:02.152770
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """This is a simple test for __eq__

    It is here to fix a bug in launchpadlib:
     - https://bugs.launchpad.net/launchpadlib/+bug/481395
       AttributeError: 'IllegalUseOfScopeReplacer' object has no attribute '_fmt'

    The problem is that IllegalUseOfScopeReplacer.__eq__() assumes that the
    _fmt attribute exists, while it does not in launchpadlib.
    The only requierement for IllegalUseOfScopeReplacer.__eq__() is that the
    class defines a _fmt attribute.
    """
    class T(IllegalUseOfScopeReplacer):
        pass
    instance = T("name", "msg", "extra")
    if instance != instance:
        raise AssertionError("instance != instance")

# Generated at 2022-06-21 21:54:11.325953
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # This validates the check in exception.py that unicode messages are
    # returned, even if the format string is ascii.
    # The exception class is not public, so the tests need to be here.
    from bzrlib import _dummy_exceptions
    _dummy_exceptions.install()

# Generated at 2022-06-21 21:54:13.085677
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import_module = ImportProcessor()


# Generated at 2022-06-21 21:54:23.444836
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib.foo
    import bzrlib.branch
    import bzrlib.bar

    class Globals:
        pass

    globals = Globals()
    lazy_imports = {}
    lazy_import(globals, '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    ''')
    def fail_import(name, obj):
        if name not in lazy_imports:
            raise AssertionError('Unexpected import of %s as %s' %
                                 (name, type(obj)))
        del lazy_imports[name]


# Generated at 2022-06-21 21:54:29.182139
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ must return unicode object"""
    # This method is only for testing of method __unicode__.
    class UnicodeException(Exception):
        def __str__(self):
            return u'\N{SNOWMAN}'
    e = UnicodeException()
    r = IllegalUseOfScopeReplacer('name', 'message')
    assert isinstance(unicode(r), unicode)
    # In Python 2.6, Exception has __unicode__ too, but in Python 2.4 and
    # Python 2.5 it does not and that is why we have to test this.
    assert isinstance(unicode(e), unicode)
    assert isinstance(unicode(r), unicode)
    assert isinstance(unicode(IllegalUseOfScopeReplacer('name', e)), unicode)
    # check that illegal characters

# Generated at 2022-06-21 21:54:41.233369
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if used on real object"""
    def _factory(self, scope, name):
        return self

    scope = locals()
    name = '_dummy'
    del _dummy
    lazy_obj = ScopeReplacer(scope, _factory, name)
    try:
        lazy_obj.foo = 'bar'
    except IllegalUseOfScopeReplacer as e:
        if e.name != '_dummy':
            raise TestNotApplicable('name should be _dummy')
        if e.msg != "Object tried to replace itself, check it's not using its" \
                " own scope.":
            raise TestNotApplicable('msg should be correct')
    else:
        raise TestNotApplicable('expected IllegalUseOfScopeReplacer')


# Generated at 2022-06-21 21:54:44.595026
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import unittest
    import sys
    import bzrlib.tests
    result = bzrlib.lazy_import._test_ScopeReplacer___call__()
    return result

# Generated at 2022-06-21 21:55:30.494000
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from cStringIO import StringIO
    from unittest import TestCase, TestLoader, TextTestRunner
    from . import TestUtil
    from .TestUtil import test_log

    import sys
    import traceback

    __traceback_info__ = None

    class ScopeReplacerTests(TestCase):
        def clear_scope(self):
            self.scope = {}

        def setUp(self):
            self.clear_scope()
            self.old_should_proxy = ScopeReplacer._should_proxy

        def tearDown(self):
            ScopeReplacer._should_proxy = self.old_should_proxy

        def test_get_resolves(self):
            self.scope['foo'] = 'foo'
            sr = ScopeReplacer(self.scope, lambda r,s,n:s[n], 'foo')


# Generated at 2022-06-21 21:55:35.268785
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """ImportProcessor.lazy_import"""
    scope = {}
    ip = ImportProcessor()
    ip.lazy_import(scope, """# Comment
    # Comment
    import foo
    """)
    assert scope == {'foo':ImportReplacer(scope, 'foo', ['foo'], None, {})}



# Generated at 2022-06-21 21:55:46.530281
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object.

    Moreover it should never fail and should avoid infinite recursion.
    """
    import locale
    import sys
    save_locale = locale.setlocale(locale.LC_ALL)

# Generated at 2022-06-21 21:55:53.173287
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCaseInTempDir
    from bzrlib.tests.test__lazy_import import DummyClassToCall
    t = TestCaseInTempDir()
    t.assertEqual(DummyClassToCall('some args').args,
                  ['some args'])
    t.assertEqual(DummyClassToCall(1, 2).args,
                  [1, 2])



# Generated at 2022-06-21 21:56:02.315416
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor
    """

    class FakeClass(object):
        def __init__(self, scope, name, module_path, member=None, children={}):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children

    scope = {}
    import_text = """
        import foo.bar, bzrlib.diff.diff_file, bzrlib.diff
        from bzrlib.plugins import gpg
        from bzrlib.plugins import foo as bar, foo as baz
    """
    processor = ImportProcessor(FakeClass)
    processor.lazy_import(scope, import_text)

# Generated at 2022-06-21 21:56:07.568250
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    assert repr(e) == "IllegalUseOfScopeReplacer('foo', 'msg', 'extra')"
    assert str(e) \
        == "ScopeReplacer object 'foo' was used incorrectly: msg: extra"



# Generated at 2022-06-21 21:56:13.139342
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for constructor of class ScopeReplacer."""

    def factory(self, scope, name):
        real_obj = int(name)
        return real_obj

    # Test __init__
    scope = {}
    name = "1"
    test_obj = ScopeReplacer(scope, factory, name)
    assert isinstance(test_obj, ScopeReplacer)



# Generated at 2022-06-21 21:56:21.502369
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    r = repr(e)
    # Check that the name of the class is in the repr.
    # This will catch renaming of the class.
    assert r.startswith('IllegalUseOfScopeReplacer('), r
    # Check that all the arguments are present in the repr, in the same order
    # as the arguments to the constructor.
    # This will catch adding or removing arguments, or changing their order.
    assert "<'name'>" in r, r
    assert "<'msg'>" in r, r



# Generated at 2022-06-21 21:56:27.054955
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__(self) returns a string in the format specified in the class definition.
    """
    exc = IllegalUseOfScopeReplacer('name', 'message', extra='extra')
    s = str(exc)
    # look for the known components
    assert 'ScopeReplacer' in s
    assert 'name' in s
    assert 'message' in s
    assert 'extra' in s



# Generated at 2022-06-21 21:56:39.063005
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    class TestIllegalUseOfScopeReplacer(IllegalUseOfScopeReplacer):
        # we need a concrete class for object equality tests
        pass
    def make_err(*args, **kwargs):
        er = TestIllegalUseOfScopeReplacer(*args, **kwargs)
        return er

    er = make_err('foo', 'bar')
    as_str = str(er)
    assert 'foo' in as_str
    assert 'bar' in as_str
    assert repr(er).startswith('TestIllegalUseOfScopeReplacer')
    # {a} does not get replaced by 'car' because the _fmt string
    # does not include it. This is intentional, because it is causing the
    # InvalidPlaceholder exception, so that we can test that this