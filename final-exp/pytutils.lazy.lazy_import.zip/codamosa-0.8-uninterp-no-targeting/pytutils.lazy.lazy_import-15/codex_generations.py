

# Generated at 2022-06-21 21:47:17.865310
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('the_name', 'the_message', 'the_extra')
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError('__unicode__() should return a unicode object')

# Generated at 2022-06-21 21:47:25.694835
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    a = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert a.name == 'a'
    assert a.msg == 'b'
    assert a.extra == ': c'
    assert a.__unicode__() == b'a was used incorrectly: b: c'
    assert a.__str__() == 'a was used incorrectly: b: c'
    assert a.__repr__() == "IllegalUseOfScopeReplacer('a', 'b', 'c')"
    b = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert a == b



# Generated at 2022-06-21 21:47:38.262234
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from . import (
        tests,
        )
    from .tests import (
        features,
        )
    if not features.lazy_import_modules.available():
        return
    import bzrlib
    old_bzrlib = bzrlib
    tests.TestCase.overrideAttr(bzrlib.lazy_import, 'ScopeReplacer',
                                ScopeReplacer)

# Generated at 2022-06-21 21:47:49.554957
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.test_lazy_import import TestLazyImport

    class SubTestLazyImportScopeReplacer(TestLazyImport):
        def test___init__(self):
            scope = {}
            global_mod = 'bzrlib.tests.test_lazy_import'
            factory_func = lambda self, scope, name:\
                __import__(global_mod)
            name = global_mod
            sr = ScopeReplacer(scope, factory_func, name)
            self.assertEqual('', '')

    sr_test = SubTestLazyImportScopeReplacer('test___init__')
    test_result = sr_test.test_suite()



# Generated at 2022-06-21 21:47:51.269846
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    exc = IllegalUseOfScopeReplacer('foobar', 'foobar %s', 'foo')
    u = exc.__unicode__()
    pass



# Generated at 2022-06-21 21:47:56.893662
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Make sure disallow_proxying works"""
    import sys
    import bzrlib.osutils
    # Make sure ScopeReplacer was the class used.
    assert sys.modules['bzrlib'].osutils._real_obj.__class__ == ScopeReplacer
    # Now disable proxying
    disallow_proxying()
    # And check
    try:
        bzrlib.osutils._real_obj.exe
    except IllegalUseOfScopeReplacer:
        # as expected
        pass
    else:
        raise AssertionError("Expected IllegalUseOfScopeReplacer "
                             "but no exception was raised")
    # test proxy assignment
    try:
        bzrlib.osutils = "foo"
    except IllegalUseOfScopeReplacer:
        # as expected
        pass

# Generated at 2022-06-21 21:48:05.939109
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class MyClass(object):
        pass

    d = {}

    def factory(obj, scope, name):
        if obj is not scope[name]:
            raise AssertionError("%r is not %r" % (obj, scope[name]))
        if name != 'obj':
            raise AssertionError("name should be 'obj', but is %r" % name)
        if obj is not scope['obj']:
            raise AssertionError("%r is not %r" % (obj, scope['obj']))
        return MyClass()

    obj = ScopeReplacer(d, factory, 'obj')



# Generated at 2022-06-21 21:48:12.028387
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer class

    The method __str__() returns a str object and
    if it fails to decode the unicode of this exception
    it should return a str object.
    """
    err = IllegalUseOfScopeReplacer(name='lazy_import',
                                    msg='LazyImport object was used '
                                        'incorrectly:',
                                    extra=None)
    str(err)
    err = IllegalUseOfScopeReplacer(name='lazy_import',
                                    msg='LazyImport object was used '
                                        'incorrectly:',
                                    extra=3.14)
    str(err)

# Generated at 2022-06-21 21:48:20.825879
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() -> unicode"""
    e = IllegalUseOfScopeReplacer('mysrc', 'msg', 'extra')
    assert isinstance(e, Exception)
    assert isinstance(e, IllegalUseOfScopeReplacer)
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    assert isinstance(repr(e), str)
    assert not isinstance(repr(e), unicode)

# Generated at 2022-06-21 21:48:25.449186
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ must return a string object."""
    e = IllegalUseOfScopeReplacer('f', 'g', None)
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode) # should decode using default encoding


# Generated at 2022-06-21 21:48:58.200734
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    import bzrlib.branch
    ''')
    def test():
        return 'test'
    bzrlib.branch._test_method = test
    bzrlib.branch.__setattr__('_test_method', test)
    return bzrlib.branch._test_method()

# Generated at 2022-06-21 21:49:07.083023
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import gc
    scope = {}

    def factory(self, scope, name):
        return scope[name] + 1

    ScopeReplacer(scope, factory, 'counter')
    scope['counter'] = 0
    assert scope['counter'] == 0
    scope['counter'] += 1
    assert scope['counter'] == 2
    scope['counter'] = 3
    assert scope['counter'] == 4
    scope['counter'] += 1
    assert scope['counter'] == 5

    # We should be able to create a ScopeReplacer object and only
    # import the module it refers to when it is actually needed.
    # This test is to make sure that gc won't complain while
    # the object is being used.
    ScopeReplacer(scope, factory, 'gc_test')
    gc.collect()
    scope['gc_test'] = 0


# Generated at 2022-06-21 21:49:16.932248
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    class foo:
        bar = {}
    def _factory1(self, scope, name):
        return self
    def _factory2(self, scope, name):
        return self.bar
    def _factory3(self, scope, name):
        return foo()
    def _factory4(self, scope, name):
        return self._baz
    def _factory5(self, scope, name):
        return 1
    def _factory6(self, scope, name):
        return scope
    def _factory7(self, scope, name):
        return 0/0

    try:
        ScopeReplacer(scope, _factory1, 'x')
    except IllegalUseOfScopeReplacer as e:
        pass

# Generated at 2022-06-21 21:49:27.035517
# Unit test for function lazy_import
def test_lazy_import():
    """Test the function 'lazy_import'."""
    c = ImportProcessor()
    c.lazy_import({}, """
        from bzrlib import foo, bar
        from bzrlib.foo import baz as quux
    """)
    # Globals isn't used for anything yet
    import bzrlib
    foo_d = bzrlib.foo.__dict__
    bar_d = bzrlib.bar.__dict__
    # On the first use of bzrlib.foo.baz, it's replaced with a real
    # object.
    c.lazy_import(foo_d, 'from bzrlib.foo import baz')
    lazy_foo_baz = foo_d['baz']
    # Replace it with a real object
    # TODO: RBC 200

# Generated at 2022-06-21 21:49:40.212517
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Tests for method lazy_import of class ImportProcessor"""
    # Prepare some variables
    from systemtools.basics import BinaryFile
    from bzrlib.trace import mutter
    import traceback
    import unittest
    import weakref
    
    # Prepare some values
    text = """\
import codecs
import os
import sys
import posixpath
import stat
from os.path import isdir, islink, join
from stat import ST_DEV, ST_INO, ST_MTIME, ST_MODE
"""
    d = {}
    e = {}
    f = {}
    g = {}
    h = {}
    # Prepare some functions and classes
    def test(scope, text, result):
        # Prepare some variables
        import_processor = ImportProcessor()

# Generated at 2022-06-21 21:49:42.293668
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('a', 'b', 'c')
    assert str(e) == str('b: c')


# Generated at 2022-06-21 21:49:47.853525
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """
    Check the equality comparison of exceptions of different classes is not
    implemented. This is a unittest.TestCase method.
    """
    err1 = IllegalUseOfScopeReplacer('name', 'msg')
    err2 = Exception()
    try:
        err1 == err2
    except NotImplemented:
        pass



# Generated at 2022-06-21 21:50:00.238608
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    v = {}
    lazy_import(v, 'from bzrlib import osutils')
    # Just to be sure
    assert type(v['osutils']) is ScopeReplacer
    try:
        # Try to access something.
        v['osutils'].pathjoin
        # Try to overwrite the content with another scope_replacer
        # (must raise)
        #v['osutils'] = ScopeReplacer
    except IllegalUseOfScopeReplacer:
        # Expected: access not allowed
        pass
    else:
        # Unexpected: access allowed !
        raise AssertionError
    # Just to be sure
    assert type(v['osutils']) is ScopeReplacer
    # Try to access something.
    v['osutils'].pathjoin
   

# Generated at 2022-06-21 21:50:08.426667
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests import features
    if features.UnicodeFilenameFeature.available():
        name = u'\N{GREEK SMALL LETTER ALPHA}\N{GREEK SMALL LETTER BETA}'
        msg = u'\N{GREEK SMALL LETTER GAMMA}\N{GREEK SMALL LETTER DELTA}'
        extra = u'\N{GREEK SMALL LETTER EPSILON}\N{GREEK SMALL LETTER ZETA}'
    else:
        name = 'logname'
        msg = 'mymsg'
        extra = 'myextra'
    exc = IllegalUseOfScopeReplacer(name, msg, extra)

# Generated at 2022-06-21 21:50:18.650724
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    def my_callable_factory():
        """A fake callable factory"""
    class MyClass(object):
        """A fake class"""
    # test default values
    sr = ScopeReplacer(None, my_callable_factory, None)
    assert sr._scope is None
    assert sr._factory is my_callable_factory
    assert sr._name is None
    assert sr._real_obj is None
    # test using a string in name and an instance of an object
    sr = ScopeReplacer(MyClass, my_callable_factory, 'name_id')
    assert sr._scope == MyClass
    assert sr._factory is my_callable_factory
    assert sr._name == 'name_id'
    assert sr._real_obj is None



# Generated at 2022-06-21 21:50:36.925119
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """This tests lazy import processing"""
    o = ImportProcessor()
    text = '''
        import foo
        import foo.bar
        import foo.bar.baz as bautzy
        from foo import bar
    '''
    o.lazy_import({}, text)
    import_map = o.imports
    foo_info = import_map['foo']
    assert foo_info[0] == ['foo']
    assert foo_info[1] is None
    bar_parent = foo_info[2]
    bar_info = bar_parent['bar']
    assert bar_info[0] == ['foo', 'bar']
    assert bar_info[1] is None
    baz_parent = bar_info[2]
    baz_info = baz_parent['baz']
    assert baz_info

# Generated at 2022-06-21 21:50:49.749991
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test the __str__ method of IllegalUseOfScopeReplacer

    This method is used when str() is called on an IllegalUseOfScopeReplacer
    object.
    """
    se = IllegalUseOfScopeReplacer("name", "msg", extra=None)
    assert str(se).startswith("IllegalUseOfScopeReplacer('name', 'msg', ':\\n")
    # Check that it's correctly encoded as ascii
    assert type(str(se)) == str
    # The 'extra' attribute can be an exception object
    ex = Exception("my exception")
    se2 = IllegalUseOfScopeReplacer("n2", "m2", ex)
    assert str(se2).startswith("IllegalUseOfScopeReplacer('n2', 'm2', ':\\n")
    # Check that it's correctly encoded as

# Generated at 2022-06-21 21:51:00.665890
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    __slots__ = ['imports', '_lazy_import_class']

    def __init__(self, lazy_import_class=None):
        self.imports = {}
        if lazy_import_class is None:
            self._lazy_import_class = ImportReplacer
        else:
            self._lazy_import_class = lazy_import_class

    def _convert_import_str(self, import_str):
        if not import_str.startswith('import '):
            raise ValueError('bad import string %r' % (import_str,))
        import_str = import_str[len('import '):]

        for path in import_str.split(','):
            path = path.strip()
            if not path:
                continue

# Generated at 2022-06-21 21:51:11.600627
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    # Tests for method lazy_import of class ImportProcessor
    from bzrlib.tests import TestCase
    from bzrlib import lazy_import

    class TestImportProcessor(TestCase):

        def test_basic_lazy_import(self):
            # Basic test, test that we can import the bzrlib package
            ip = ImportProcessor()
            ip.lazy_import(globals(), 'import bzrlib')
            self.assert_(isinstance(bzrlib, lazy_import.ImportReplacer))
            # Check that we can use it as a module
            bzrlib.trace.note(42)

        def test_import_tricky_imports(self):
            ip = ImportProcessor()
            ip.lazy_import(globals(), 'import bzrlib')
            self

# Generated at 2022-06-21 21:51:15.819845
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Smoke test for exception class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    u = unicode(e)



# Generated at 2022-06-21 21:51:23.243714
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.lazy_import import lazy_import
    g = {}
    lazy_import(g, '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    ''')
    for name in ['foo', 'bar', 'baz', 'branch', 'transport']:
        assert isinstance(g[name], ImportReplacer)


# Generated at 2022-06-21 21:51:31.371294
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Ensure IllegalUseOfScopeReplacer produces the expected
    output when passed to str()"""
    import bzrlib.lazy_import
    try:
        x = bzrlib.lazy_import.ScopeReplacer('foo')
        x.__getattr__('bar')
    except bzrlib.lazy_import.IllegalUseOfScopeReplacer as e:
        assert str(e) == 'IllegalUseOfScopeReplacer(ScopeReplacer object \'foo\' was used incorrectly: Cannot obtain attributes from the scope replacer: bar)'
    else:
        raise AssertionError('Should have raised IllegalUseOfScopeReplacer')



# Generated at 2022-06-21 21:51:38.818725
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e.name == 'name'
    assert e.msg == 'msg'
    assert e.extra == ': extra'
    repr(e)
    str(e)
    unicode(e)


# Generated at 2022-06-21 21:51:51.500823
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test for constructor of class ImportProcessor"""
    def check_processed_text(text, expected_result):
        import_info = ImportProcessor()
        import_info.lazy_import(scope={}, text=text)
        result = import_info.imports
        if expected_result != result:
            raise AssertionError('%r != %r\n%s' % (expected_result, result, text))

    # Regular import
    check_processed_text('import foo.bar.baz',
        {'foo': (['foo'], None,
                {'bar': (['foo', 'bar'], None,
                        {'baz': (['foo', 'bar', 'baz'], None, {})})})})

    # Import with rename

# Generated at 2022-06-21 21:51:53.625042
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # XXX: __getattribute__ is not supposed to be called directly by the user
    return

# Generated at 2022-06-21 21:52:11.910418
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should return a unicode string"""
    e = IllegalUseOfScopeReplacer('a', 'b')
    e._preformatted_string = 'c'
    assert isinstance(e.__unicode__(), unicode)
    e.__dict__['_preformatted_string'] = unicode('c')
    assert isinstance(e.__unicode__(), unicode)
    e._preformatted_string = '\xc2'
    assert isinstance(e.__unicode__(), unicode)
    e._preformatted_string = 'c\xc2'
    assert isinstance(e.__unicode__(), unicode)
    e._preformatted_string = '\xc2c'
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-21 21:52:13.318043
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    from bzrlib import lazy_import
    lazy_import.ImportProcessor()


# Generated at 2022-06-21 21:52:22.979121
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    class DummyException(Exception):
        pass
    from bzrlib.tests import TestCase
    import sys
    class TestIllegalUseOfScopeReplacer(TestCase):
        def test_subclass_equality(self):
            e1 = DummyException('msg', 'extra')
            e2 = DummyException('msg', 'extra')
            self.assertEqual(e1, e2)
        def test_subclass_inequality_same_class(self):
            e1 = DummyException('msg', 'extra')
            e2 = DummyException('msg', 'extra1')
            self.assertNotEqual(e1, e2)
        def test_subclass_inequality_different_class(self):
            e1 = D

# Generated at 2022-06-21 21:52:34.438675
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that ImportReplacer correctly sets up its parameters.

    This test does not test the actual import, just that the data structures
    are set up correctly to allow the import.
    """
    # This should work
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], None, {})
    ImportReplacer(scope, 'foo', ['foo'], 'bar', {})
    ImportReplacer(scope, 'foo', ['foo'], None,
                   {'bar':(['foo', 'bar'], None, {})})
    # This should fail
    try:
        ImportReplacer(scope, 'foo', ['foo'], 'bar',
                       {'bar':(['foo', 'bar'], None, {})})
    except ValueError:
        # Good, it should have raised a ValueError
        pass
   

# Generated at 2022-06-21 21:52:46.282900
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib import lazy_import as _mod_lazy_import
    from bzrlib.lazy_import import ScopeReplacer, ImportProcessor
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import disallow_proxying

    # We need to reset the cache in case tests have already run and
    # loaded this module
    ScopeReplacer._scope_replacer_obj_cache = {}

    # First, we need to make sure each of the helper functions work
    def check_lazy_import(text, expected):
        globals = {}
        lazy_import(globals, text)
        assert set(globals.keys()) == set(expected), \
            ("Expected %r got %r" % (expected, globals.keys()))

   

# Generated at 2022-06-21 21:52:51.705493
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__"""

    # test_IllegalUseOfScopeReplacer___repr__
    assert repr(IllegalUseOfScopeReplacer('name', 'msg', 'extra')) == \
        'IllegalUseOfScopeReplacer(name, msg, extra)'



# Generated at 2022-06-21 21:53:01.577421
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attribute of object"""
    from bzrlib.tests.lazy_import_helper import LazyImportHelper
    lazy_import_obj = ScopeReplacer({}, LazyImportHelper, '')
    __tracebackhide__ = True
    try:
        lazy_import_obj.__setattr__('_real_obj', 42)
        e = None
    except IllegalUseOfScopeReplacer as e: # expected failure
        pass
    __tracebackhide__ = False
    assert e is None
    assert lazy_import_obj._real_obj == 42


# Generated at 2022-06-21 21:53:09.256340
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Method '__repr__' must return a string that when evaluated returns an
    object equal to the original object.

    For example, we can do:

    >>> from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    >>> IllegalUseOfScopeReplacer('a', 'b') == eval(repr(IllegalUseOfScopeReplacer('a', 'b')))
    True
    """
# End of unit tests for method __repr__ of class IllegalUseOfScopeReplacer


# Generated at 2022-06-21 21:53:17.847249
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__(self, other) -> bool"""
    e1 = IllegalUseOfScopeReplacer('name', 'msg')
    e2 = IllegalUseOfScopeReplacer('name', 'msg')
    assert e1 == e2
    assert e2 == e1
    e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e1 == e2
    assert e2 == e1
    e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer('name', 'msg2', 'extra')
    assert e1 != e2
    assert e2 != e1
    e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e

# Generated at 2022-06-21 21:53:28.549318
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-21 21:53:49.233730
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Unit test for lazy_import.disallow_proxying"""
    from bzrlib.lazy_import import lazy_import
    global __should_proxy__
    __should_proxy__ = ScopeReplacer._should_proxy
    ScopeReplacer._should_proxy = True
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    import bzrlib
    # Inform about potential race conditions, but don't fail as this test
    # is not thread safe.
    import warnings

# Generated at 2022-06-21 21:54:01.157021
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib.errors as errors
    import bzrlib.tests.blackbox.test_blackbox as test_blackbox
    import bzrlib.transport as transport
    import bzrlib.ui as ui
    ip = ImportProcessor()

    # Test the error case of a text that starts with something other than
    # 'from ' or 'import '
    try:
        ip.lazy_import(test_blackbox.__dict__, 'foo bar')
    except errors.InvalidImportLine:
        pass
    else:
        raise AssertionError('InvalidImportLine not raised')

    # Test a basic import
    ip = ImportProcessor()
    ip.lazy_import(test_blackbox.__dict__, 'import bzrlib')

# Generated at 2022-06-21 21:54:10.796864
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from . import tests
    import bzrlib.tests
    bzrlib.tests.per_interpreter.setUp(__file__)
    bzrlib.tests.features.load_features()

# Generated at 2022-06-21 21:54:15.211406
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    import bzrlib.tests
    bzrlib.tests.TestCase(
        'test_IllegalUseOfScopeReplacer___repr__').test_IllegalUseOfScopeReplacer___repr__()


# Generated at 2022-06-21 21:54:19.206290
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    e = IllegalUseOfScopeReplacer(
        'foo', 'bar',
        extra='baz')
    r = repr(e)
    require.equal(
        "IllegalUseOfScopeReplacer('foo', 'bar', 'baz')",
        r)



# Generated at 2022-06-21 21:54:23.227793
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a str"""
    import bzrlib.lazy_import
    e = bzrlib.lazy_import.IllegalUseOfScopeReplacer('name', 'msg')
    repr(e)


# Generated at 2022-06-21 21:54:32.198245
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    ip = ImportProcessor()
    class mydict(dict):
        def __init__(self):
            dict.__init__(self)
            self.count = 0
        def __setitem__(self, key, value):
            if key in self:
                raise KeyError('%r already in dict' % (key,))
            self.count += 1
            dict[self, key] = value
    scope = mydict()
    ip.lazy_import(scope, 'import foo, foo.bar as bing, foo.bar.baz.boo')
    ImportReplacer(scope, 'foo', ['foo'])
    ImportReplacer(scope, 'bing', ['foo', 'bar'])

# Generated at 2022-06-21 21:54:44.294532
# Unit test for function lazy_import
def test_lazy_import():
    """Test lazy_import function.

    It should work in a variety of cases, and do the right thing in each.
    """
    # We're doing these tests in a doctest, because that way we can
    # just show off their use.
    import os

    # First, we'll show what happens without lazy_import
    # This requires patching sys.path, importlib.invalidate_caches
    # and sys.modules
    # These should all exist
    import bzrlib
    import bzrlib.foo
    import bzrlib.foo.bar
    import bzrlib.foo.bar.baz
    import bzrlib.branch
    import bzrlib.transport
    import bzrlib.version_info
    import bzrlib.version_info as vi
    # These should

# Generated at 2022-06-21 21:54:52.579989
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Test method '__call__' of class ScopeReplacer."""
    # method '__call__' is only called if obj is a function
    # or a class.

    # tests for classes
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests.per_lazy_import import TestForLazyImport
    class TestClass():
        def __init__(self):
            self.call_count = 0
        def __call__(self):
            self.call_count += 1
            return self.call_count
    test_class_obj = TestClass()
    sr = ScopeReplacer(locals(), lambda *args: test_class_obj, 'test_class_obj')
    # test that the __call__ method of sr works
    assert test_class_obj() == 1
   

# Generated at 2022-06-21 21:54:54.078616
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    i = ImportProcessor()
    return i



# Generated at 2022-06-21 21:55:31.733177
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import __builtin__
    import bzrlib
    old_implementation = bzrlib.scope_replacer.ScopeReplacer.__call__
    bzrlib.scope_replacer.ScopeReplacer.__call__ = \
        lambda self, *args, **kwargs: old_implementation(self, *args, **kwargs)
    import bzrlib.scope_replacer
    bzrlib.scope_replacer.ScopeReplacer.__call__ = old_implementation


# Generated at 2022-06-21 21:55:39.697477
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Method __call__ of class ScopeReplacer can be called with right-number
    of args and kwargs."""
    import inspect

    def factory(self, scope, name):
        return 1e3

    def test(scope, name):
        # Tries to fake the effect of using 'lazy_import' to put a
        # ScopeReplacer into global scope in a test.
        ScopeReplacer(scope, factory, name)

    # Create new scope, which is probably a bit overkill, but should work.
    scope = {}
    test(scope, 'test_name')
    scope['test_name'].__call__()
    scope['test_name'].__call__(1)
    scope['test_name'].__call__(1, 2)

# Generated at 2022-06-21 21:55:51.698070
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__ should return True if the other object is of the same class, and has the same attributes (values in __dict__).

    >>> class MyException(Exception): pass
    >>> class MyBadException(MyException): pass
    >>> e = MyException('this is a test message')
    >>> e == e
    True
    >>> e2 = MyException('this is a test message')
    >>> e == e2
    True
    >>> e2 = MyException('this is a test message2')
    >>> e == e2
    False
    >>> e2 = MyBadException('this is a test message')
    >>> e == e2
    False
    >>> e2 = MyBadException('this is a test message2')
    >>> e == e2
    False
    """


# Generated at 2022-06-21 21:55:57.091979
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()

    This tests the method '__str__' of the class IllegalUseOfScopeReplacer.
    """
    # Test simple case.
    try:
        raise IllegalUseOfScopeReplacer('foo', 'bar')
    except IllegalUseOfScopeReplacer as e:
        str(e) # Should not raise an exception.


# Generated at 2022-06-21 21:55:58.771246
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Check functionality of class ImportProcessor"""
    proc = ImportProcessor()
    assert proc



# Generated at 2022-06-21 21:56:11.118883
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """test_IllegalUseOfScopeReplacer___eq__

    Test for method __eq__ of class IllegalUseOfScopeReplacer
    """
    e1 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e3 = IllegalUseOfScopeReplacer('foo', 'bar')
    e4 = IllegalUseOfScopeReplacer('foo', 'bar', 'qux')
    e5 = IllegalUseOfScopeReplacer('FOO', 'bar', 'baz')
    e6 = IllegalUseOfScopeReplacer('foo', 'BAR', 'baz')
    e7 = IllegalUseOfScopeReplacer('foo', 'bar', 'BAZ')

# Generated at 2022-06-21 21:56:21.801275
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Method __setattr__ of class ScopeReplacer.

    This test checks the behaviour of the __setattr__ method of the
    ScopeReplacer class.

    In particular it tests to see if an exception is raised when
    replacement of a proxy object has been disabled.
    """
    def factory(self, scope, name):
        return ''
    scope = {}
    name = 'foo'
    proxy = ScopeReplacer(scope, factory, name)
    assert scope[name] is proxy
    assert proxy._real_obj is None
    proxy.bar = 1
    assert scope[name].bar == 1
    assert proxy._real_obj.bar == 1
    scope[name].baz = 2
    assert scope[name].baz == 2
    assert proxy._real_obj.baz == 2
    assert proxy.baz == 2
    Scope

# Generated at 2022-06-21 21:56:30.786069
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    __tracebackhide__ = True
    # Test that we proxy __setattr__ to the real object

    # Arrange
    # Create a ScopeReplacer that resolves to the class.
    import bzrlib.lazy_import
    class MyClass(object):
        def __setattr__(self, attr, value):
            object.__setattr__(self, attr, value)
    class_ = MyClass()
    class_sr = bzrlib.lazy_import.ScopeReplacer({}, lambda c, s, n: class_, 'x')
    import bzrlib.trace
    # Act
    bzrlib.trace.mutex_debug = 1
    class_.attr = 0
    # Assert

# Generated at 2022-06-21 21:56:38.431850
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    x = {}
    test_name = 'test_scope_replacer'
    try:
        # You must specify a factory so the object can be replaced.
        ScopeReplacer(x, 1, test_name)
    except TypeError:
        pass
    else:
        raise AssertionError("ScopeReplacer should require a factory")
    def factory(replacer, scope, name):
        return True
    # Create a ScopeReplacer, but don't use it
    ScopeReplacer(x, factory, test_name)
    return True



# Generated at 2022-06-21 21:56:49.723554
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test for __call__ method of class ScopeReplacer
    # Test: Calling a lazy object that will replace itself in the
    # appropriate scope.
    # This object sits, ready to create the real object the first
    # time it is needed.
    # 1. Create a temporary object in the specified scope.
    #    Once used, a real object will be placed in the scope.
    # 2. Return the real object for which this is a placeholder
    # 3. Calling a lazy object
    # 4. Calling a lazy object
    # 5. Calling a lazy object
    # 6. Calling a lazy object

    class ExampleClass1:
        def __init__(self, *args, **kwargs):
            pass
        def __call__(self, *args, **kwargs):
            return 'Exampl1'
