

# Generated at 2022-06-21 21:47:26.471593
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    global y
    ScopeReplacer._should_proxy = False
    def factory(self, scope, name):
        """
        >>> factory(None, None, None)
        Traceback (most recent call last):
        ...
        IllegalUseOfScopeReplacer: (u'None', u"Object tried to replace itself, check it's not using its own scope.")
        """
        return self
    y = ScopeReplacer({}, factory, 'y')



# Generated at 2022-06-21 21:47:34.140229
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit test for ScopeReplacer"""
    a = {}
    get = lambda self, scope, name: self
    ScopeReplacer(a, get, 'x')
    assert a['x'].__class__.__name__ == 'ScopeReplacer'

ScopeReplacer._should_proxy = False
try:
    test_ScopeReplacer()
finally:
    ScopeReplacer._should_proxy = True



# Generated at 2022-06-21 21:47:39.200358
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    ip.lazy_import(None, 'import foo.bar, (foo.bar.baz as bing'
                    ', foo.bar.baz as bing2), baz')
    ip.lazy_import(None, 'import foo.bar, (foo.bar.baz as bing'
                    ', foo.bar.baz as bing2), baz')
    ip.lazy_import(None, 'import foo.bar, (foo.bar.baz as bing'
                    ', foo.bar.baz as bing2)')
    ip.lazy_import(None, 'import foo.bar, (foo.bar.baz as bing as)')

# Generated at 2022-06-21 21:47:51.070560
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import tempfile
    from bzrlib.lazy_import import lazy_import
    from bzrlib.ui import ui_factory
    from bzrlib.tests.per_lazy_import import TestCaseWithMemoryTransport

    lazy_import(globals(), '''
    from bzrlib import transport
    ''')

    class TestScopeReplacer__setattr__(TestCaseWithMemoryTransport):

        def setUp(self):
            TestCaseWithMemoryTransport.setUp(self)
            self.backup_should_proxy = ScopeReplacer._should_proxy
            self.overrideAttr(scope_replacer, '_should_proxy', False)

        def tearDown(self):
            ScopeReplacer._should_proxy = self.backup_should_proxy
            TestCaseWithMemoryTransport

# Generated at 2022-06-21 21:48:01.702493
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('globals', 'test')
    assert e.name == 'globals'
    assert e.msg == 'test'
    assert e.extra == ''
    e = IllegalUseOfScopeReplacer('globals', 'test', 'extra')
    assert e.name == 'globals'
    assert e.msg == 'test'
    assert e.extra == ': extra'
    assert str(e) == "ScopeReplacer object 'globals' was used incorrectly:"\
            " test: extra"
    assert unicode(e) == u"ScopeReplacer object 'globals' was used" \
            u" incorrectly: test: extra"

# Generated at 2022-06-21 21:48:13.411019
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests.test_lazy_import import test_suite
    from bzrlib.tests.blackbox import ExternalBase
    from StringIO import StringIO
    from bzrlib.trace import mutter

    class TestExternal(ExternalBase):
        def test_suite(self):
            return test_suite()
    out = StringIO()
    old_mutter = mutter

# Generated at 2022-06-21 21:48:20.746207
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__()"""
    class A(IllegalUseOfScopeReplacer):
        _fmt = 'A'
    a = A(1, 2, 3)
    b = A(1, 2, 3)
    c = A(1, 2, 4)
    assert a == b
    assert a != c



# Generated at 2022-06-21 21:48:25.598274
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    text = ("import foo, foo.bar as bing")
    ip = ImportProcessor()
    ip.lazy_import({}, text)
    import sys
    # Make sure that the imports haven't happened yet
    assert 'foo' not in sys.modules
    assert 'bing' not in sys.modules['foo']
    # Now go through and access some variables
    obj = ip.imports['foo']()
    assert obj is sys.modules['foo']
    obj = ip.imports['bing']()
    assert obj is sys.modules['foo'].bar





# This allows other modules to lazily import themselves before
# they're needed. This is done by replacing globals() with an object that
# knows what to import, and how to import it.
#
# Currently it understands
# * 'import foo, foo.bar as bing

# Generated at 2022-06-21 21:48:30.664915
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    assert repr(IllegalUseOfScopeReplacer(name='a', msg='b')) == "IllegalUseOfScopeReplacer('a', 'b')"
    assert repr(IllegalUseOfScopeReplacer(name='a', msg='b', extra='c')) == "IllegalUseOfScopeReplacer('a', 'b', 'c')"

# Generated at 2022-06-21 21:48:35.127082
# Unit test for function lazy_import
def test_lazy_import():
    globs = {}
    text = """
    import bzrlib.foo
    from bzrlib import bar
    from bzrlib.foo import baz as bing
    """
    lazy_import(globs, text, lazy_import_class=ImportReplacer)
    # Should be modified in place
    assert len(globs) == 3
    assert set(globs) == set(['bzrlib', 'bar', 'bing'])
    assert isinstance(globs['bzrlib'], ImportReplacer)
    assert isinstance(globs['bar'], ImportReplacer)
    assert isinstance(globs['bing'], ImportReplacer)
    assert globs['bzrlib']._module_path == ['bzrlib']

# Generated at 2022-06-21 21:48:52.455873
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), """
    from bzrlib import (
        osutils,
        trace,
        urlutils,
        )
    import bzrlib
    """)
    try:
        disallow_proxying()
        # This should not be allowed
        osutils.pathjoin('foo')
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("Proxying should have been disabled")
    # This should be allowed
    bzrlib.trace.note('bar')



# Generated at 2022-06-21 21:49:04.306487
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    class ExpectedUse(Exception):
        """An exception for testing ScopeReplacer"""

    def raise_exception(*args, **kwargs):
        raise ExpectedUse("Should've been caught")

    scope = {}
    replacer = ScopeReplacer(scope, raise_exception, "exception")
    # If a dummy object is returned to replace itself in scope,
    # raise an error.
    try:
        scope['exception']
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("ScopeReplacer failed to raise "
                             "IllegalUseOfScopeReplacer")
    # And raise an expected exception if called
    try:
        scope['exception']()
    except ExpectedUse:
        pass

# Generated at 2022-06-21 21:49:16.127861
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class ChildImportReplacer(ImportReplacer):

        def _import(self, scope, name):
            return self.__class__
    # Basic function
    from bzrlib.tests import TestCase
    class TestImportReplacer(TestCase):
        """Tests for ImportReplacer"""

        def test_basic(self):
            name = 'foo'
            module_path = ['foo']
            children = {'bar':(['foo', 'bar'], 'baz', {})}
            scope = {}
            self.assertRaises(ValueError, ImportReplacer,
                              scope, name, module_path, children=children)
            self.assertRaises(ValueError, ImportReplacer,
                              scope, name, module_path, member='baz',
                              children=children)

# Generated at 2022-06-21 21:49:28.360327
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    r"""unit test for method __unicode__ of class IllegalUseOfScopeReplacer

    Strategy: create an IllegalUseOfScopeReplacer, and then we test if
    __unicode__() returns a unicode object, and if that object is equal to
    'foo, bar'
    """
    # note: q is an object of the class IllegalUseOfScopeReplacer
    q = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    result = q.__unicode__()
    if not isinstance(result, unicode):
        raise AssertionError(
            "%s is not a unicode object" % (result,))
    expected_result = 'foo, bar'
    if result != expected_result:
        raise AssertionError(
            "expected %s, got %s" (expected_result, result))




# Generated at 2022-06-21 21:49:41.150193
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that ImportReplacer works"""
    import bzrlib
    # This is intentionally using the dict directly, rather than vars()
    # because vars() uses __getattribute__.
    globals_dict = globals()

    ImportReplacer(globals_dict, 'bzrlib', ['bzrlib'], member=None, children={})
    ImportReplacer(globals_dict, 'bzrlib', ['bzrlib', 'tests'], member=None,
        children={'test_ImportReplacer':(['bzrlib', 'tests',
            'test_lazy_import'], 'test_ImportReplacer', {})})

    # Allow the module to be imported, and test that the children are present
    # The children are present if they've been replaced by actual modules
    # This tests that

# Generated at 2022-06-21 21:49:53.212146
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """This tests the _build_map and _convert_imports methods of ImportProcessor"""
    import_str = """"import foo.bar as bar
                     import bzrlib.foo as foo
                     import bzrlib.foo
                     import bzrlib.foo.bar.baz
                     import bzrlib.foo.bar.baz as a
                     import bzrlib.foo.bar.baz as a, bzrlib.foo.bar.baz as b
                     from bzrlib.foo import bar
                     from bzrlib.foo import bar as bing
                     from bzrlib.foo import (bar, baz, bing)
                     from bzrlib.foo import (bar as bar, baz as baz,
                                             bing as bing)
                     """

# Generated at 2022-06-21 21:50:03.145322
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    u = unicode(e)
    # We return a unicode object by default.
    assert isinstance(u, unicode)


# Import the TracebackException class to avoid the import
# dependency upon 'traceback' within the later LazyImport class.
# This is done manually to allow the LazyImport class itself to
# be imported from 'traceback' (and thus used by the test suite)
# without causing a recursion.
from bzrlib import (
    errors,
    traceback,
    )



# Generated at 2022-06-21 21:50:10.410465
# Unit test for function lazy_import
def test_lazy_import():
    import sys
    sys.modules['foo'] = 1
    lazy_import(globals(), """
    import foo
    import nope.nope
    import nope
    from nope import nope
    """)
    get_foo = globals()['foo']
    get_nope = globals()['nope']
    get_nope_nope = globals()['nope'].__dict__['nope']
    # The foo in our module should be replaced with 1
    assert get_foo is 1
    # The 'nope' module should not yet be imported, and should be a
    # ImportReplacer object. We cannot just check the type though,
    # because those are not imported yet either, however, all
    # ImportReplacer objects have a member dict, so we can check
    # that.

# Generated at 2022-06-21 21:50:19.519755
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """Unit test for method __repr__ of class IllegalUseOfScopeReplacer."""

    import StringIO
    import sys

    # The error message to be handled by the test.
    msg = \
        "ScopeReplacer object 'foo' was used incorrectly: Used too early."

    # Miscellaneous setup for the test.
    if hasattr(sys, 'exc_clear'):
        # sys.exc_clear() only exists starting Python 2.5.
        sys.exc_clear()
    import bzrlib.dirty_imports
    del sys.modules['bzrlib.dirty_imports']
    reload(bzrlib.dirty_imports)
    from bzrlib.dirty_imports import IllegalUseOfScopeReplacer

    # Save the sys.stderr functions to restore them at the end of the test.
    st

# Generated at 2022-06-21 21:50:27.684574
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method __unicode__ of IllegalUseOfScopeReplacer."""
    msg = "foo"
    extra = "bar"
    name = "fooname"
    f = IllegalUseOfScopeReplacer(name, msg, extra)
    # Check the exception's string representation contain the necessary
    # fields.
    ustr = str(f)
    assert ustr.find(msg) != -1
    assert ustr.find(name) != -1
    assert ustr.find(extra) != -1



# Generated at 2022-06-21 21:50:38.118518
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return a string"""
    class Dummy(IllegalUseOfScopeReplacer):
        _fmt = "%(name)s has a %(fault)s"

    dummy = Dummy('name', 'message', 'fault')
    s = str(dummy)
    assert s == 'name has a fault'
    assert isinstance(s, str)
    assert isinstance(s, str)



# Generated at 2022-06-21 21:50:50.484103
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    test_children = {
        'foo':(['bzrlib', 'foo'], None,
               {'bar':(['bzrlib', 'foo', 'bar'], None, {})}),
        }
    ImportReplacer(scope=scope, name='bzrlib', module_path=['bzrlib'],
                   children=test_children)
    # Check that the children objects were created.
    assert type(scope['bzrlib']) is ImportReplacer, scope['bzrlib']
    # Check that the children have the correct values set.
    foo_replacer = scope['bzrlib']._import_replacer_children['foo'][0]
    assert foo_replacer._name == 'foo'

# Generated at 2022-06-21 21:51:01.157833
# Unit test for method lazy_import of class ImportProcessor

# Generated at 2022-06-21 21:51:11.785426
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer."""
    old_locale = {'LC_ALL':None, 'LANGUAGE':None}
    new_locale = {'LC_ALL':'fi_FI.UTF-8'}
    for var, value in old_locale.iteritems():
        try:
            old_locale[var] = os.environ[var]
            os.environ[var] = value
        except KeyError:
            del old_locale[var]

# Generated at 2022-06-21 21:51:16.893871
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that ImportProcessor constructs as expected."""
    i = ImportProcessor()
    assert i._lazy_import_class == ImportReplacer
    i = ImportProcessor(ImportReplacer)
    assert i._lazy_import_class == ImportReplacer



# Generated at 2022-06-21 21:51:27.543239
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """__init__ should work as expected"""
    foo_bar_baz = ['foo', 'bar', 'baz']
    foo_bar = ['foo', 'bar']
    foo = ['foo']
    children = {
        'bar': (foo_bar, None, {
            'baz': (foo_bar_baz, None, {}),
            }),
        }
    ImportReplacer(scope={}, name='foo', module_path=foo, children=children)
    ImportReplacer(scope={}, name='bar', module_path=foo_bar, member='bar')
    ImportReplacer(scope={}, name='baz', module_path=foo_bar_baz, member='baz')



# Generated at 2022-06-21 21:51:36.095318
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from bzrlib import lazy_import
    # This validates the repr of IllegalUseOfScopeReplacer for
    # python 2.4
    foo = lazy_import.ScopeReplacer('foo', 'bar')
    try:
        raise foo
    except foo.__class__ as exc:
        pass
    else:
        raise AssertionError('No IllegalUseOfScopeReplacer raised')
    print('exception: %r' % (exc,))


# Generated at 2022-06-21 21:51:41.274547
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.tests import TestSkipped
    try:
        disallow_proxying()
        p = ScopeReplacer(locals(), lambda n,s,v: n, 'n')
        n = p
        raise TestSkipped('disallow_proxying did not raise')
    except IllegalUseOfScopeReplacer:
        pass



# Generated at 2022-06-21 21:51:52.967702
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the constructor for the ImportReplacer class.

    The ImportReplacer class is designed for unit tests.
    """
    # Create a scope for the import replacer objects to import into
    scope = {}

    # Import 'foo.bar' as 'foo'
    def check_foo_bar_baz():
        """Check the the foo replacer generated foo.bar & foo.bar.baz"""
        foo = scope['foo']
        bar = scope['foo.bar']
        baz = scope['foo.bar.baz']
        assert foo.bar is bar
        assert foo.bar.baz is baz


# Generated at 2022-06-21 21:52:01.222523
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__()

    The __repr__ method should be used to generate a string
    which can be passed to the eval() function to create a new
    object that is identical to the one represented by the
    original string.
    """
    o = IllegalUseOfScopeReplacer('path', 'msg', ('extra', 'extra2'))
    r = repr(o)
    oo = eval(r)
    assert o == oo
    assert isinstance(oo, IllegalUseOfScopeReplacer)



# Generated at 2022-06-21 21:52:18.798176
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    inst = IllegalUseOfScopeReplacer('name', 'msg')
    assert 'name' in unicode(inst)
    assert 'msg' in unicode(inst)


# Emulate the old _ScopeReplacer which was used to implement lazy_import.
# It's not worth having a whole other class for this.
_ScopeReplacer = _LazyImportWrapper



# Generated at 2022-06-21 21:52:29.151541
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    bzrlib = ScopeReplacer(locals(), lambda self, scope, name: object(), 'bzrlib')
    bzrlib.__class__.__call__ = lambda self: 42
    class Test(TestCase):
        def test_call(self):
            self.assertEqual(42, bzrlib())
    Test("test_call").run()

    # __call__ must be able to be called on a child of the replaced object
    class Child(object):
        pass
    bzrlib.child = Child()
    bzrlib.child.__class__.__call__ = lambda self: 43
    class Test(TestCase):
        def test_call_child(self):
            self.assertEqual(43, bzrlib.child())


# Generated at 2022-06-21 21:52:33.872610
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    m = ImportReplacer(scope, 'foo', ['foo'], children={'bar':
        (['foo', 'bar'], None,
            {'baz':(['foo', 'bar', 'baz'], None, {})})})
    m.bar
    scope['foo'].bar.baz
    from foo.bar import baz
    scope['baz'] = baz


# Generated at 2022-06-21 21:52:38.997826
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests import TestCase

    class T(TestCase):
        def test_eq(self):
            one = IllegalUseOfScopeReplacer('a', 'b')
            two = IllegalUseOfScopeReplacer('a', 'b')
            self.assertEqual(one, two)

    T('test_eq').test_eq()



# Generated at 2022-06-21 21:52:43.526410
# Unit test for function lazy_import
def test_lazy_import():
    def _test_lazy_import(text, reference_children):
        _locals = {}
        lazy_import(_locals, text)
        _check_map(_locals, reference_children)

    def _check_map(locals_map, reference_children):
        ref = {}
        for (name, (module_path, member, children)) in reference_children.iteritems():
            module_path = [module_path]
            ref[module_path[0]] = (module_path, member, children)
        if locals_map != ref:
            raise AssertionError('%r != %r' % (locals_map, ref))

    # Simple import
    _test_lazy_import("""
    import foo
    """, {'foo': (['foo'], None, {})})
    # Multiple import

# Generated at 2022-06-21 21:52:50.646193
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """The constructor of ScopeReplacer"""
    scope = {}
    factory = lambda self, scope, name: None

    replacer = ScopeReplacer(scope, factory, 'foo')
    from bzrlib import lazy_import, selftest
    selftest.TestCase.assertIsInstance(replacer, ScopeReplacer,
                                       'constructor of ScopeReplacer')



# Generated at 2022-06-21 21:53:02.763275
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests import TestCase

    # Helper function to check the attributes of an ImportReplacer
    def check_replacer(replacer, scope, name, member=None, children={}):
        # Check the attributes of the ImportReplacer
        self.assertEqual(replacer._scope, scope)
        self.assertEqual(replacer._name, name)
        self.assertEqual(replacer._module_path, [name])
        self.assertEqual(replacer._import_replacer_children, children)
        self.assertEqual(replacer._member, member)

    class TestImportReplacer(TestCase):

        def test_constructor_simple(self):
            scope = {'os':'dummy'}
            name = 'os'
            module_path = ['os']

# Generated at 2022-06-21 21:53:06.354586
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    from bzrlib import _lazy_import
    class DummyClass(object):
        pass
    d = DummyClass()
    name = 'foo'
    d.__dict__[name] = None
    # Note: the use of ScopeReplacer here is to exercise it, not because it is
    # *needed* here.
    r = ScopeReplacer(d.__dict__, _lazy_import.ScopeReplacer, name)



# Generated at 2022-06-21 21:53:17.596980
# Unit test for function lazy_import
def test_lazy_import():
    """Test that lazy_import does what we want it to do.

    Essentially, we want to make sure that when we import a module,
    a proxy object is created that is replaced with the real object
    on first use.
    """
    from bzrlib.lazy_import import lazy_import
    import bzrlib

    def module_is_proxied(name):
        """Check that a module is a proxy.

        It does this by checking that it is an instance of ImportReplacer,
        and has a self._module_path attribute.
        """
        return (isinstance(bzrlib, ImportReplacer)
                and getattr(bzrlib, '_module_path', None) is not None)

    # We have just loaded bzrlib. Now, check that it is a proxy

# Generated at 2022-06-21 21:53:28.508850
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__(*) -> str

    Return a string representation of an object.
    """
    # Any exceptions not keyed by class, or raised by a function you call must
    # be caught like this. For example here we catch any exceptions which might
    # be raised by your method or the methods it calls.

# Generated at 2022-06-21 21:53:39.992029
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__()

    ScopeReplacer should transparently set attributes of the underlying
    object, once it has been created.
    """
    import time
    def make_time():
        return time
    global_scope = {}
    replacer = ScopeReplacer(global_scope, make_time, 'time')
    assert not replacer._real_obj
    assert replacer.altzone == -10800
    assert global_scope['time'].altzone == -10800
    # Ensure real object has been created
    assert replacer._real_obj is global_scope['time']

# Generated at 2022-06-21 21:53:49.470327
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    ImportReplacer(scope, name='foo', module_path=['foo'])
    ImportReplacer(scope, name='bar', module_path=['foo', 'bar'])
    ImportReplacer(scope, name='baz', module_path=['foo', 'baz'],
        member='bar')
    assert scope['foo'] is scope['foo']
    assert scope['bar'] is scope['bar']
    assert scope['baz'] is scope['baz']
    assert scope['foo'] is not scope['bar']
    assert scope['foo'] is not scope['baz']
    assert scope['bar'] is not scope['baz']
    try:
        ImportReplacer(scope, name='foo', module_path=['foo'], member='bar',
            children={})
    except ValueError:
        pass

# Generated at 2022-06-21 21:53:59.434264
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the constructor of class ScopeReplacer."""
    global _test_init_scope_replacer
    def _test_init_scope_replacer():
        _test_init_scope_replacer.is_called = True
    _test_init_scope_replacer.is_called = False
    replacer = ScopeReplacer(globals(),
                             lambda self, scope, name: _test_init_scope_replacer(),
                             '_test_init_scope_replacer')
    assert(_test_init_scope_replacer.is_called == False)
    assert(_test_init_scope_replacer is _test_init_scope_replacer)



# Generated at 2022-06-21 21:54:09.807031
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Func(object):
        def __init__(self, arg):
            self.arg = arg

    class Foo(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    def factory(obj, scope, name):
        return Foo(1, 2)

    def factory2(obj, scope, name):
        return Func(name)

    def factory_self(obj, scope, name):
        return obj

    # Test that a ScopeReplacer's attribute is returned and the factory is
    # not called.
    obj = ScopeReplacer(locals(), factory, 'u')
    try:
        getattr(obj, '_scope')
        assert False, "Expected exception"
    except AttributeError:
        pass # expected

    # Test that when an

# Generated at 2022-06-21 21:54:15.998920
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor and methods of ImportProcessor"""
    import_processor = ImportProcessor()
    # Test the constructor
    assert import_processor.imports == {}
    import_processor = ImportProcessor(lazy_import_class=ImportReplacer)
    assert import_processor._lazy_import_class is ImportReplacer



# Generated at 2022-06-21 21:54:24.996745
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """'__unicode__(self)' returns a unicode object created from
    the instance's __str__ method."""
    # Test with a unicode string.
    e = IllegalUseOfScopeReplacer(u'name', u'illegal use', u'illegal use details')
    u = e.__unicode__()
    assert isinstance(u, unicode), "u should be a unicode object"
    assert u == e.__str__(), "u should be created from __str__"

    # Test with a string.
    e = IllegalUseOfScopeReplacer('name', 'illegal use', 'illegal use details')
    u = e.__unicode__()
    assert isinstance(u, unicode), "u should be a unicode object"
    assert u == e.__str__(), "u should be created from __str__"



# Generated at 2022-06-21 21:54:32.791956
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    global ScopeReplacer
    from bzrlib.tests.blackbox import ExternalBase

    class TestableScopeReplacer(ScopeReplacer):
        """A special ScopeReplacer for testing."""

    class TestLazyImport(ExternalBase):

        def test_getattr_returns_wrapped_object(self):
            t = TestableScopeReplacer({}, lambda self, scope, name: 42, 'tester')
            self.assertIsInstance(t, int)
            self.assertEqual(t, 42)

    def test_suite():
        from unittest import TestSuite
        result = TestSuite()
        result.addTest(TestLazyImport('test_getattr_returns_wrapped_object'))
        return result



# Generated at 2022-06-21 21:54:44.551876
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test for function disallow_proxying"""
    lazy_import(globals(), """
    from bzrlib import osutils
    """)
    osutils
    disallow_proxying()
    try:
        osutils.pathjoin()
        raise AssertionError("Did not get exception with proxying disabled")
    except IllegalUseOfScopeReplacer as e:
        # Check the exception for the proxy name and message.
        if e.name != 'osutils':
            raise AssertionError("Got an exception, but with the wrong name"
                " set: %r" % e.name)

# Generated at 2022-06-21 21:54:48.615522
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    lazy_import.lazy_import(globals(), '''
    from bzrlib import lockdir
    import bzrlib.lockdir
    ''')
    bzrlib.lockdir.LockDir('.')
    bzrlib.lockdir('.')



# Generated at 2022-06-21 21:54:56.966095
# Unit test for function lazy_import
def test_lazy_import():
    """Unit test for lazy_import."""
    from bzrlib import osutils
    from bzrlib import errors as bzr_errors
    text = '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    '''
    globs = {}
    lazy_import(globs, text)

    # Check that they are ScopeReplace objects
    for name, obj in globs.iteritems():
        if (name == 'foo') or (name == 'bar') or (name == 'baz'):
            assert isinstance(obj, ScopeReplacer), name
        elif name == 'branch' or name == 'transport':
            assert isinstance(obj, ScopeReplacer), name

# Generated at 2022-06-21 21:55:14.347780
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that ImportReplacer behaves as expected."""
    def assert_issubclass(cls, parent):
        assert issubclass(cls, parent), \
            "%s not a subclass of %s" % (cls.__name__, parent.__name__)

    # The class only used for testing
    class TestImportReplacer(ImportReplacer):
        pass

    # Importing the global module
    scope = {}
    TestImportReplacer(scope, name='os', module_path=['os'])
    assert_issubclass(scope['os'].__class__, ScopeReplacer)
    assert scope['os']._name == 'os'
    assert scope['os']._module_path == ['os']
    assert scope['os']._member is None

    # Importing a particular symbol
    scope = {}

# Generated at 2022-06-21 21:55:24.243422
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import sys
    import os
    from tempfile import mkdtemp
    from shutil import rmtree
    from stat import S_IEXEC
    from pipes import quote
    from subprocess import check_call
    from bzrlib.tests.test_importing import TestImportHook

    # TODO: This writing of a python executable is a hack
    #       which should be replaced by a more general
    #       method of running fresh python processes
    # TODO: jam 20061201 This is meant to be a temporary hack
    #       to pollute sys.path and make sure that we can make
    #       a new python process.
    #       We want to reuse the existing framework for doing
    #       environment isolation but for now this will do.
    # TODO: RBC 20080102 The above todos gave a suggested replacement which
    #

# Generated at 2022-06-21 21:55:26.217398
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that ImportProcessor constructs as expected"""
    ip = ImportProcessor()
    return ip



# Generated at 2022-06-21 21:55:29.105319
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__"""
    o = IllegalUseOfScopeReplacer('v', 'm', 'e')
    r = repr(o)
    assert str(o) == r



# Generated at 2022-06-21 21:55:38.387704
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class MyClass(object):
        def __call__(self, x, y, z=1):
            return x, y, z
        def __new__(cls, x, y, z=1):
            o = object.__new__(cls)
            o.x, o.y, o.z = x, y, z
            return o
    g = {'lala':MyClass}
    lala = ScopeReplacer(g, MyClass, 'lala')
    x, y, z = lala(10, 20)
    assert((x, y, z) == (10, 20, 1))
    x, y, z = lala.x, lala.y, lala.z
    assert((x, y, z) == (10, 20, 1))



# Generated at 2022-06-21 21:55:42.255471
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-21 21:55:54.459112
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase
    class TestableScopeReplacer(ExternalBase):
        """Class TestableScopeReplacer allows to test __call__ method of
        ScopeReplacer class via ExternalBase class.
        """
        def get_test_params(self):
            scope = {}
            def factory(self, scope, name):
                return lambda: 'test'
            name = '__lazy'
            def test(self):
                return self.run_bzr(['lazy_import.py', 'test_ScopeReplacer___call__',
                    '%s' % scope, '%s' % factory, '%s' % name])
        # test_ScopeReplacer___call__()

# Generated at 2022-06-21 21:56:02.855386
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib.tests, subprocess
    scope = {}
    text = '''
    from bzrlib import (
        errors,
        tests)
    import subprocess
    '''

    lazy_import(scope, text)
    obj = scope['subprocess']
    assert isinstance(obj, ImportReplacer)
    assert obj._module_path == ['subprocess']
    assert obj._member is None
    children = {'Popen': ['subprocess', 'Popen'],
                'PIPE': ['subprocess', 'PIPE']}
    assert obj._import_replacer_children == children

    obj = scope['errors']
    assert isinstance(obj, ImportReplacer)
    assert obj._module_path == ['bzrlib', 'errors']
    assert obj._member is None
    children = {}

# Generated at 2022-06-21 21:56:12.144030
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Test method IllegalUseOfScopeReplacer.__eq__"""
    e1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e2 = IllegalUseOfScopeReplacer('name2', 'msg2', 'extra2')
    assert e1 != e2
    e2.name = 'name'
    assert e1 != e2
    e2.msg = 'msg'
    assert e1 != e2
    e2.extra = 'extra'
    assert e1 == e2
# End of test for method IllegalUseOfScopeReplacer.__eq__

# End of class IllegalUseOfScopeReplacer



# Generated at 2022-06-21 21:56:22.569428
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib
    module = bzrlib

    def check_module_version(module):
        # Make sure the module imported correctly
        if not hasattr(module, '__version__'):
            raise AssertionError('%s does not have __version__' % (module,))

        version = module.__version__
        if version != '2.2':
            raise AssertionError('__version__ is %r, not 2.2' % (version,))

    def check_lazy_module_version(module):
        # Make sure the module imported correctly
        if not hasattr(module, '__version__'):
            raise AssertionError('%s does not have __version__' % (module,))

        version = module.__version__
        if version != '2.2':
            raise Assert

# Generated at 2022-06-21 21:56:32.499317
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    from bzrlib.tests import TestCase

    class TestImportProcessor(TestCase):

        def test_init(self):
            imp = ImportProcessor()


test_ImportProcessor.todo = 'test_init does nothing useful'



# Generated at 2022-06-21 21:56:34.666617
# Unit test for function disallow_proxying
def test_disallow_proxying():
    def f():
        # code to be tested
        disallow_proxying()
    f()


# Generated at 2022-06-21 21:56:39.512999
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Unit tests for lazy_import()"""
    scope = {'a': 1}
    scope_replacer = ScopeReplacer(scope, lambda self, scope, name: scope[name] * 10, 'a')
    assert scope['a'] == scope_replacer
    assert scope_replacer.a == 10
    assert scope['a'] == 10


# Generated at 2022-06-21 21:56:46.623307
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    import bzrlib
    scope = bzrlib.__dict__
    cls = ImportReplacer

    children = {}
    cls(scope, 'foo', ['foo'], children=children)
    cls(scope, 'foo', ['foo', 'bar'], children=children)

    # Now check that the children have been created correctly
    # The children would have put themselves into bzrlib.__dict__
    foo = scope['foo']
    bar = scope['foo'].bar
    children = foo._import_replacer_children
    assert children == {'bar': (['foo', 'bar'], None, {})}
    children = bar._import_replacer_children
    assert children == {}

    # Check that the factory is doing the right thing.
    # This will cause the import to happen, and verify that it calls the