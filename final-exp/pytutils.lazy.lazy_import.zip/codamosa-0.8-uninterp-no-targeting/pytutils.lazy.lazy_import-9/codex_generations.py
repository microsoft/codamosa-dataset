

# Generated at 2022-06-21 21:47:21.551576
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test that ScopeReplacer copies the attributes (read only)"""
    class Foo:
        pass
    def factory(obj, scope, name):
        return Foo()
    scope = {}
    name = 'foo'
    scopeReplacer = ScopeReplacer(scope, factory, name)
    scope2 = scopeReplacer._scope
    factory2 = scopeReplacer._factory
    name2 = scopeReplacer._name
    scope[name2] = 999
    assert scope2[name2] == 999
    assert factory2 != factory
    assert name2 == name



# Generated at 2022-06-21 21:47:29.941970
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()

    __repr__ must show the class name, and the message if there is one. It
    must return a str.
    """
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    r = repr(e)
    try:
        unicode_r = unicode(r)
    except UnicodeDecodeError:
        # 'r' is not a unicode object
        pass
    else:
        raise AssertionError(
            "repr(IllegalUseOfScopeReplacer) returned a unicode object")
    if 'foo' not in r or 'bar' not in r:
        raise AssertionError(
            "repr(IllegalUseOfScopeReplacer) does not show message")

# Generated at 2022-06-21 21:47:35.145831
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import gc
    import bzrlib.lazy_import

    count = [0]
    def import_counted(name):
        count[0] = count[0]+1
        return __import__(name)

    class LazyImportTest:
        from bzrlib.lazy_import import lazy_import
        lazy_import(locals(), 'os')
        lazy_import(locals(), 'sys')
    bzrlib.lazy_import._import = import_counted
    l = LazyImportTest()
    assert count[0] == 0
    l.os
    assert count[0] == 1
    l.os
    assert count[0] == 1
    l.sys
    assert count[0] == 2
    # test that the lazy import can be used as proxy.

# Generated at 2022-06-21 21:47:44.436985
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import multiply_tests
    from bzrlib.tests.blackbox import ExternalBase

    # Method __getattribute__ of class - tested from the outside
    class TestCase(ExternalBase):
        def __init__(self, *args, **kwargs):
            super(TestCase, self).__init__(*args, **kwargs)
            self.lazy_module_name = 'bzrlib._lazy_import_test'

        def test_scope_replacer(self):
            """Test that the ScopeReplacer class works as expected"""
            # This is only tested in the 'blackbox' tree because of the extra
            # imports involved.
            self.requireFeature(lambda x: x.startswith('python '))

            lazy_module = self.lazy_module_name
            test_module_

# Generated at 2022-06-21 21:47:52.303672
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    s = ScopeReplacer("test.py", "foo")
    try:
        s.replace("blah", 123)
    except IllegalUseOfScopeReplacer as e:
        import pprint
        assert pprint.pformat(e) == 'Unprintable exception IllegalUseOfScopeReplacer: dict=\n{ \'extra\': \'\',\n  \'msg\': u"\'blah\' is not a valid name",\n  \'name\': \'foo\'}, fmt=None, error=None'



# Generated at 2022-06-21 21:48:00.268122
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test __setattr__ with a proxy object

    # Sample class to be proxied
    class foo(object):
        attr = 1
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    # No replacement for arg1 key
    def factory(self, scope, name):
        return foo(scope['arg1'], 'new_value')

    # Original arg2 value
    original_arg2 = 'old_value'

    # Scope to proxy in
    scope = {'arg1': 1, 'arg2': original_arg2}

    # Create ScopeReplacer for proxy
    proxy = ScopeReplacer(scope, factory, 'proxy')

    # Check initial value of arg2
    assert('old_value' == scope['arg2'])

    #

# Generated at 2022-06-21 21:48:07.397515
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    from bzrlib import lazy_import
    scope = {}
    text = '''from bzrlib import (foo as bar,
    )
    import foo.bar as baz,
    bing'''
    proc = ImportProcessor(lazy_import.ImportReplacer)
    proc.lazy_import(scope, text)
    assert 'bar' in scope
    assert proc.imports['bar'][1] == None

# Generated at 2022-06-21 21:48:16.275001
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    def check_empty(e):
        check(e, "", "")
    def check_extra(e):
        check(e, "extra", extra="extra")
    def check(e, obj, extra):
        exc = IllegalUseOfScopeReplacer('name', 'msg', obj)
        assert exc.name == 'name'
        assert exc.msg == 'msg'
        assert exc.extra == extra
    check_empty(None)
    check_empty(1)
    check_empty(object())
    check_extra(5)
    check_extra(object())
    check_empty("")
    check_empty("abc")
    check_empty(u"")
    check_empty(u"abc")



# Generated at 2022-06-21 21:48:24.424332
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_simple(self):
            class _X(object):
                pass
            class _Proxy(ScopeReplacer):
                __slots__ = ()
                def __init__(self):
                    ScopeReplacer.__init__(self, dict(), self._factory, 'x')
                def _factory(self, scope, name):
                    return _X()
            x = _Proxy()
            x.y = 42
            self.assertEquals(42, x.y)
    Test().test_simple()


# Generated at 2022-06-21 21:48:35.694688
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    # test canonicalize_import_text
    ip = ImportProcessor()
    assert ip._canonicalize_import_text("") == []
    assert ip._canonicalize_import_text("#") == []
    assert ip._canonicalize_import_text("a") == ['a']
    assert ip._canonicalize_import_text("a, b") == ['a, b']
    assert ip._canonicalize_import_text("#a\nb") == ['b']
    assert ip._canonicalize_import_text("#a\nimport b") == ['import b']
    assert (ip._canonicalize_import_text("#a\nimport b, c") ==
            ['import b, c'])

# Generated at 2022-06-21 21:48:46.880381
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer('test', 'message %(test)s',
                                  ('test', 'extra'))
    e.test = 'test value'
    assert str(e) == "ScopeReplacer object 'test' was used incorrectly:" \
        " message test value: ('test', 'extra')"



# Generated at 2022-06-21 21:48:52.936053
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase
    class Dummy(object):
        called = False
        def __call__(self, *args, **kwargs):
            self.called = True
    dummy = Dummy()
    dummy.__call__ = ScopeReplacer(dummy.__dict__, lambda self, scope, name: self, "__call__")
    dummy()
    self.assertTrue(dummy.called)

# Generated at 2022-06-21 21:48:56.409708
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """__init__ creates an empty self.imports dict."""
    t = ImportProcessor()
    assert isinstance(t.imports, dict)


# Generated at 2022-06-21 21:49:04.813154
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys, random
    scope = sys._getframe(1).f_locals
    factory = lambda *a, **kw: None
    name = str(random.random())
    d = {'_scope': scope, '_factory': factory, '_name': name, '_real_obj': None}
    lzo = ScopeReplacer(scope, factory, name)
    assert lzo._scope == scope
    assert lzo._factory == factory
    assert lzo._name == name
    assert lzo._real_obj is None
    scope[name] = lzo
    assert scope == d


# Generated at 2022-06-21 21:49:14.953984
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    children = {'bar':(['foo', 'bar'], None, {}),
                'baz':(['foo', 'baz'], 'CustomBazMember', {}),
                }
    ImportReplacer(scope=scope, name='foo', module_path=['foo'],
                   children=children)
    c = scope['foo'].__class__
    assert c._import_replacer_children == children
    assert c._member is None
    assert c._module_path == ['foo']
    assert c._name == 'foo'
    assert c._scope == scope
    assert c._factory is c._import



# Generated at 2022-06-21 21:49:25.668617
# Unit test for function lazy_import
def test_lazy_import():
    scope = {}
    lazy_import(scope, '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    from bzrlib import (
        urlutils
        )
    ''')

    module = imp.new_module('bzrlib')
    for i in [foo, bar, baz, branch, urlutils]:
        # Make sure they are all ScopeReplacer objects
        assert isinstance(i, ScopeReplacer)

    # Now we have to replace some objects.
    scope['foo'] = 'rewritten'
    scope['bar'] = 'rewritten'
    scope['baz'] = 'rewritten'
    scope['bzrlib'] = module
    scope['urlutils'] = 'rewritten'

    # At

# Generated at 2022-06-21 21:49:29.188716
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    o = ScopeReplacer(None, None, None)
    o.__setattr__('_factory', 4)


# Generated at 2022-06-21 21:49:41.583498
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Traceback exceptions are properly formatted.

    Test to verify bug #49889 is fixed.
    """
    import sys
    import types
    try:
        raise IllegalUseOfScopeReplacer('name', 'msg')
    except IllegalUseOfScopeReplacer as e:
        formatted = unicode(e)
        assert isinstance(formatted, unicode) # check to see it's unicode
        if sys.exc_info()[1] is not e:
            # if the exception object is not the same as the one
            # held in exc_info(), then we cannot get the traceback
            return
        if hasattr(sys, 'last_type'):
            # Python 2.3 and earlier
            tb = sys.exc_info()[2]

# Generated at 2022-06-21 21:49:53.638156
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.tests import TestCaseWithTransport

    class TestSetAttr(TestCaseWithTransport, ExternalBase):

        def test_setattr(self):
            from bzrlib.lazy_import import lazy_import, ScopeReplacer
            from bzrlib import errors
            class Abc(object):
                def __init__(self):
                    self._foo = 'test'
            fake_scope = {}
            def factory(replacer, scope, name):
                return Abc()
            replacer = ScopeReplacer(fake_scope, factory, 'abc')
            self.assertEqual('test', replacer._foo)
            replacer._foo = 'bar'
            self.assertEqual('bar', replacer._foo)


# Generated at 2022-06-21 21:50:04.855038
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """This test the method ImportProcessor.lazy_import"""
    # build a projet containing some python modules
    project = test_utils.TestProject()
    project_path = project.project_path
    project.build()

    scope = {}
    # Inject a fake module in the scope
    scope['foo'] = 'bar'

    # Test a simple import
    ip = ImportProcessor()
    import_text = 'import foo'
    ip.lazy_import(scope, import_text)
    # Check that the import was correctly replaced
    assert 'foo' in scope and not isinstance(scope['foo'], basestring)
    # Check that the replacement object return the expected value
    assert scope['foo'] == 'bar'

    # Test a multi line import
    ip = ImportProcessor()

# Generated at 2022-06-21 21:50:19.793846
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    from bzrlib import lazy_import

    # Simple object that knows its own name as an attribute
    class Obj(object):
        def __init__(self, name):
            self.name = name

    # Produce a dummy class for each test
    class FakeEnv(object):
        def __init__(self):
            self.__class__.__slots__ = []
            self.__class__.__dict__.clear()
            self.__class__.__dict__.update(FakeEnv.__dict__)
        def factory(self, replacer, dummy_scope, name):
            return Obj(name)
        def factory_prexisting(self, replacer, dummy_scope, name):
            return Obj('X')

    # build a ScopeReplacer, and create a real Obj

# Generated at 2022-06-21 21:50:26.652995
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    msg = 'There is an error'
    e = IllegalUseOfScopeReplacer('foo', msg)
    assert isinstance(e, Exception)
    assert str(e) == 'There is an error'
    assert repr(e) == "IllegalUseOfScopeReplacer('foo', 'There is an error')"
    assert e.name == 'foo'
    assert e.msg == msg



# Generated at 2022-06-21 21:50:36.040567
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Tests method __eq__ from class IllegalUseOfScopeReplacer.

    This method is called directly in the unit test because it is a private
    method of its class.
    """
    class foo(IllegalUseOfScopeReplacer):
        _fmt = "This is my format"
    first_exception = foo("name", "msg", "extra")
    second_exception = foo("name", "msg", "extra")
    third_exception = foo("name", "msg", "other extra")
    assert first_exception == second_exception
    assert not first_exception == third_exception
    assert not first_exception == "other"



# Generated at 2022-06-21 21:50:45.051985
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import nose.tools
    import bzrlib.tests
    from bzrlib.lazy_import import ScopeReplacer
    def test_call(self, scope, name):
        scope[name] = 'real'
        return 'real'
    scope = {}
    name = 'foo'
    o = ScopeReplacer(scope, test_call, name)
    nose.tools.assert_equals('real', o.x)
    nose.tools.assert_equals('real', o())




# Generated at 2022-06-21 21:50:51.894087
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ for IllegalUseOfScopeReplacer"""
    e1 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e2 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e3 = IllegalUseOfScopeReplacer('bar', 'baz', 'foo')
    assert e1 == e2
    assert e1 != e3
    assert e1 != 'IllegalUseOfScopeReplacer(foo, bar, baz)'
    assert e1 != Exception('foo')



# Generated at 2022-06-21 21:50:56.533408
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class _Mock(ScopeReplacer):
        def __call__(self, *args, **kwargs):
            return args, kwargs
    try:
        ScopeReplacer._should_proxy = False
        _Mock.__call__()
    finally:
        ScopeReplacer._should_proxy = True



# Generated at 2022-06-21 21:51:06.141105
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Create a scopereplacer object and get an attribute using it
    # TODO: perhaps redo so we can use our own scope
    import gc
    scope = globals()
    scope['name'] = scopereplacer = ScopeReplacer(scope, lambda self, scope, name: "hi", name='name')
    scopereplacer.__getattribute__('upper')('hello') == 'HELLO'
    # The scopereplacer should now be gone, so trying this again should raise
    # an error
    gc.collect()
    raises(IllegalUseOfScopeReplacer, scopereplacer.__getattribute__, 'upper')('hello')


from bzrlib._weakrefutils import WeakKeyDictionary



# Generated at 2022-06-21 21:51:13.993744
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    ip = ImportProcessor()
    ip.lazy_import(globals(),
        """
        import foo, foo.bar, (foo.bar2, foo.bar3 as bar4), foo as bar
        from bar import foo, bar as baz
        """)
    assert(ip.imports['foo'] == ([u'foo'], None,
        {u'bar': ([u'foo', u'bar'], None, {}),
         u'bar2': ([u'foo', u'bar2'], None, {}),
         u'bar3': ([u'foo', u'bar3'], None, {})}))
    assert(ip.imports['bar'] == ([u'bar'], u'foo', {}))
    assert(ip.imports['baz'] == ([u'bar'], u'bar', {}))

# Generated at 2022-06-21 21:51:24.451569
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__() returns an evaluable string."""
    # This checks that __repr__() returns a string that allows to reconstruct
    # the instance (using eval())
    # => __repr__() should be of form ClassName(arg1, arg2, ...)
    # This is important for pickling and ipython
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    r = repr(e)
    eval(r) # should not throw an error


# Generated at 2022-06-21 21:51:37.482565
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__() should match dicts"""
    a = IllegalUseOfScopeReplacer(name='a', msg='msg', extra='extra')
    b = IllegalUseOfScopeReplacer(name='a', msg='msg', extra='extra')
    c = IllegalUseOfScopeReplacer(name='a', msg='msg', extra='extra2')
    d = IllegalUseOfScopeReplacer(name='a', msg='msg2', extra='extra')
    e = IllegalUseOfScopeReplacer(name='a2', msg='msg', extra='extra')
    assert a == b
    assert a != c
    assert a != d
    assert a != e
    assert b == a
    assert c != a
    assert d != a
    assert e != a
    assert not (a != b)
    assert not (a == c)

# Generated at 2022-06-21 21:51:48.234672
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """The IllegalUseOfScopeReplacer.__unicode__ method works as expected"""
    x = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(unicode(x), unicode)
    assert isinstance(str(x), str)
    assert isinstance(repr(x), str)

# Generated at 2022-06-21 21:51:55.071226
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Tests for the ScopeReplacer.

    This tests the basic functions of the ScopeReplacer"""
    import sys
    # define a factory function which replaces self with 42
    def factory(self, scope, name):
        return 42

    def call_as_func():
        """Callable Function"""
        pass

    # clear the module, and create the object
    sys.modules['__main__'] = None
    obj = ScopeReplacer(globals(), factory, 'obj')
    sys.modules['__main__'] = None
    obj2 = ScopeReplacer(globals(), factory, 'obj2')
    # check that the object appears in the scope correctly

# Generated at 2022-06-21 21:52:06.480954
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    scope = {}
    name = 'foo'
    scope[name] = None


# Generated at 2022-06-21 21:52:09.558311
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object."""
    s = IllegalUseOfScopeReplacer('foo', 'bar')
    result = str(s)
    # __str__() should always return a 'str' object
    # never a 'unicode' object.
    return isinstance(result, str)

# Generated at 2022-06-21 21:52:13.722373
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test the IllegalUseOfScopeReplacer exception"""
    class MyException(IllegalUseOfScopeReplacer):
        _fmt = "A test exception for %(things)s"
    exc = MyException('spam', 'eggs', extra='nonsense')
    assert str(exc) == "A test exception for spam"
    assert repr(exc) == "MyException('A test exception for spam')"



# Generated at 2022-06-21 21:52:23.308156
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Ensure that function disallow_proxying() works as expected."""
    def _check_setattr(self, key, value):
        setattr(self, key, value)
    def _check_setitem(self, key, value):
        self[key] = value
    _fmt = "Lazy object %r can be used as a proxy for %r."
    for klass, method in [(dict, _check_setitem),
                          (object, _check_setattr)]:
        value = "foo"
        # Create a lazily imported object
        lazy_obj = lazy_import(klass(), "value")
        # Verify that it is usable as a proxy before the self-test starts
        method(lazy_obj, "key", value)
        # Disable proxying and check whether lazy object still works
        disallow

# Generated at 2022-06-21 21:52:33.594544
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # check member
    global foo
    ImportReplacer(globals(), name='foo', module_path=['foo_module'],
        member='FooMember')
    try:
        ImportReplacer(globals(), name='foo', module_path=['foo_module'],
            member='FooMember', children={})
    except ValueError:
        pass
    else:
        raise AssertionError('Should have raised ValueError')

    # Check children
    global foo
    ImportReplacer(globals(), name='foo', module_path=['foo_module'],
        children={'Baz': (['foo_module', 'baz_module'], None, {})})

# Generated at 2022-06-21 21:52:45.330450
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test ImportProcessor.lazy_import()"""
    import sys
    import bzrlib
    import bzrlib.version
    global_var = 'foo'

    fake_scope = {'global_var':global_var}
    # We expect no new keys to be created
    assert set(fake_scope) == set(('global_var',))

    processor = ImportProcessor()
    processor.lazy_import(fake_scope, """
        import global_var, bzrlib.version as version, bzrlib.foo,
        (bzrlib.bar.baz, bzrlib.blah, sys.argv)
    """)

    # We expect 4 new keys to be created

# Generated at 2022-06-21 21:52:57.153767
# Unit test for function disallow_proxying
def test_disallow_proxying():
    """Test that old proxies are disallowed once disallow_proxying is called.

    This test also verifies that the __call__ method of ScopeReplacer
    is handled properly.
    """
    ScopeReplacer._should_proxy = True
    # Replace something in the current scope
    lazy_import(globals(), """
    import sys
    """)
    try:
        # This will pass because it's the first time
        sys()
    except TypeError:
        pass
    # Now replace again
    disallow_proxying()
    try:
        lazy_import(globals(), """
        import sys
        """)
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('IllegalUseOfScopeReplacer not raised')
    # Future uses of the object should be fine
   

# Generated at 2022-06-21 21:53:09.413278
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    def _eq(one, other, value):
        if not (one == other) == value:
            raise AssertionError(
                '%r != %r, expected %r' % (one, other, value))
    def _ne(one, other):
        return _eq(one, other, False)
    def _eq2(one, other, value):
        _eq(one, other, value)
        _eq(other, one, value)
    one = IllegalUseOfScopeReplacer('me', 'message', 'extra')
    two = IllegalUseOfScopeReplacer('me', 'message', 'extra')
    _eq2(one, two, True)

    two = IllegalUseOfScopeReplacer('you', 'message', 'extra')
    _ne(one, two)

# Generated at 2022-06-21 21:53:28.591253
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer(
        "foo",
        "bar",
        extra="extra")
    e._preformatted_string = None
    u = unicode(e)
    assert_not_contains_whitespace(u)
    e._preformatted_string = u"dirty preformatted"
    assert_not_contains_whitespace(unicode(e))
    e._preformatted_string = u"\u1234 dirty preformatted"
    assert_not_contains_whitespace(unicode(e))



# Generated at 2022-06-21 21:53:32.686261
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import sys

    processor = ImportProcessor()
    def test(text, results):
        processor.lazy_import(sys.modules, text)
        assert dict(processor.imports) == results, processor.imports

    test("import foo", {'foo': (['foo'], None, {})})
    test("import foo, bar", {'foo': (['foo'], None, {}),
                             'bar': (['bar'], None, {})})
    test("import foo.bar", {'foo': (['foo'], None,
                                    {'bar': (['foo', 'bar'], None, {})})})
    test("import foo as bar", {'bar': (['foo'], None, {})})

# Generated at 2022-06-21 21:53:43.123810
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that ImportProcessor works as expected."""
    import bzrlib.symbol_versioning as symbol_versioning
    import_processor = ImportProcessor()
    text = """
    import foo, bar.baz, test_baz

    from bzrlib import transports, urlutils
    from bzrlib.plugins import something
    """

    class MockScope(object):
        def __init__(self):
            self._seen = []

        def __setattr__(self, attr, value):
            self._seen.append((attr, value))

    def test_import(name, module_path, member=None, children={}):
        return ImportReplacer(scope, name=name, module_path=module_path,
                              member=member, children=children)

    import_processor.lazy_import

# Generated at 2022-06-21 21:53:47.408852
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test construction of ScopeReplacer objects.

    See also tests in test_lazy_import.py.
    """
    import sys
    new_locals = {}
    ScopeReplacer(new_locals, lambda obj, scope, name: object(), 'foo')
    assert new_locals['foo'] is not None



# Generated at 2022-06-21 21:53:49.232869
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__ of ScopeReplacer is tested by
    # 'test_lazy_import_self_reference'
    pass # nothing to do

# Generated at 2022-06-21 21:53:53.348572
# Unit test for function lazy_import
def test_lazy_import():
    module = 'bzrlib.tests.lazy_import_tests'
    scope = {}
    lazy_import(scope, '''
    from %s import (
        import_a,
        import_b,
        )
    import %s.import_c
    ''' % (module, module))

    if 'import_a' in scope or 'import_b' in scope or 'import_c' in scope:
        raise AssertionError('imports were declared in scope.')

    scope['import_a']()
    scope['import_b']()
    scope['import_c']()

    # Now we check that the real modules have been imported correctly

# Generated at 2022-06-21 21:53:57.230667
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    exc = IllegalUseOfScopeReplacer('foo', 'msg')
    assert(str(exc) == 'foo: msg')
    assert(unicode(exc) == u'foo: msg')



# Generated at 2022-06-21 21:54:03.441147
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """_IllegalUseOfScopeReplacer objects can be turned into a string"""
    msg = "foo"
    name = "bar"
    s = unicode(IllegalUseOfScopeReplacer(name, msg))
    assert name in s, "Exception should contain name: %r" % name
    assert msg in s, "Exception should contain message: %r" % msg



# Generated at 2022-06-21 21:54:10.637254
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    global __dict__
    def f1(): return 'x'
    class c1(object): pass
    c1.__len__ = f1
    def f2(replacer, scope, name): return replacer
    obj = ScopeReplacer(__dict__, f2, 'obj')
    try:
        assert obj._scope is __dict__
        assert obj._factory is f2
        assert obj._name == 'obj'
        obj._resolve()
    except IllegalUseOfScopeReplacer:
        pass
    else:
        assert False, "Should have detected illegal assignment to self"



# Generated at 2022-06-21 21:54:21.184427
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object

    This is tested by instantiating the exception with a Unicode
    message, and verifying that the message is still a Unicode object
    at the end.

    """
    msg = u'\u03c3\u03b5\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ae ' \
        u'\u03b5\u03cd\u03bc\u03b5\u03bd\u03b7 \u00a9'
    e = IllegalUseOfScopeReplacer('bzrlib', msg)
    d = e.__unicode__()
    assert isinstance(d, unicode)
    assert d == msg



# Generated at 2022-06-21 21:54:51.665351
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # TODO _jam 20060202 Should really have a unit-test here, but
    # haven't figured out how to test it yet. About to break the API,
    # so I'll leave it for another day.
    pass

# Generated at 2022-06-21 21:54:58.680126
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():

    # Test without a member name
    scope = {}
    i = ImportReplacer(scope, 'foo', ['foo'])
    del i
    import foo
    assert 'foo' in scope
    assert scope['foo'] is foo

    # Test with a member name
    scope = {}
    i = ImportReplacer(scope, 'bar', ['foo'], 'bar')
    del i
    from foo import bar
    assert 'bar' in scope
    assert scope['bar'] is bar

    # Test loading a child
    scope = {}
    i = ImportReplacer(scope, 'foo', ['foo'], children={'bar':(['foo', 'bar'], None, {})})
    del i
    import foo
    assert 'foo' in scope
    assert scope['foo'] is foo
    from foo import bar

    # Test loading a grand

# Generated at 2022-06-21 21:55:04.354032
# Unit test for constructor of class IllegalUseOfScopeReplacer

# Generated at 2022-06-21 21:55:13.980688
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    # Define some test methods for ScopeReplacer
    def factory(self, scope, name):
        return 'testing'

    def test_getattr():
        # test __getattr__
        obj = ScopeReplacer({}, factory, 'name')
        obj = obj._resolve()
        assert 'testing' == obj
        # We need to restore the original value again to pass the test
        obj._scope['name'] = obj

    def test_setattr():
        # test __setattr__
        d = {}
        obj = ScopeReplacer(d, factory, 'name')
        obj = obj._resolve()
        assert 'testing' == obj
        obj2 = obj
        obj2 = 'foo'
        assert 'foo' == obj2
        assert 'foo' == obj
        assert 'foo' == d['name']
        # We

# Generated at 2022-06-21 21:55:19.704677
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Make sure the constructor of class ImportProcessor works as expected.
    """
    processor = ImportProcessor()
    out = processor._canonicalize_import_text(
        ' from foo import bar, baz,\n'+\
        ' from baz import foo, bar\n'+\
        'import bar')
    out.sort()
    assert out == ['import bar', 'from baz import foo', 'from foo import bar']



# Generated at 2022-06-21 21:55:31.387194
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer
    """
    import __builtin__
    old_getattribute = __builtin__.getattribute
    old_setattr = __builtin__.setattr
    def setattr(self, name, value):
        global orig_object_setattr
        orig_object_setattr = value
    def getattribute(self, name):
        if name == '_scope':
            return '_scope'
        if name == '_factory':
            return '_factory'
        if name == '_name':
            return '_name'
        if name == '_real_obj':
            return None
        if name == '_resolve':
            return '_resolve'
        return old_getattribute(self, name)

# Generated at 2022-06-21 21:55:35.617685
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Method test() of class ScopeReplacer
    """
    def factory(self, scope, name):
        import bzrlib.errors as errors
        return errors
    scope = {}
    replacer = ScopeReplacer(scope, factory, 'errors')
    assert (replacer._scope is scope)
    assert (replacer._factory is factory)
    assert (replacer._name == 'errors')



# Generated at 2022-06-21 21:55:47.135151
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    import sys
    locals_ = {}

# Generated at 2022-06-21 21:55:49.642680
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # TODO

    # TODO: more tests
    # TODO: more tests



# Generated at 2022-06-21 21:55:57.513792
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """make sure __str__() produces a string"""
    import bzrlib.tests
    # It is important that this exception is used correctly.
    bzrlib.tests.TestCaseWithTransport.tearDown = \
        original_test_case_tear_down
    test_case = bzrlib.tests.TestCaseWithTransport()
    def wronge():
        raise IllegalUseOfScopeReplacer(
            'test', 'a test exception, should not be seen.')
    test_case.assertRaises(Exception, wronge)

# Generated at 2022-06-21 21:56:37.701635
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ => ASCII string

    This test ensures that IllegalUseOfScopeReplacer.__repr__
    returns an ASCII string.
    """
    from bzrlib import lazy_import
    # FIXME: This test does not ensure that the error message is
    # correctly translated.
    cls = lazy_import.IllegalUseOfScopeReplacer
    e1 = cls(name=u'e1', msg=u'\u0153')
    # repr(e1) should not raise an UnicodeEncodeError
    repr(e1)
    # repr(e1) should return a str object
    assert isinstance(repr(e1), str)

# Generated at 2022-06-21 21:56:48.813811
# Unit test for constructor of class ScopeReplacer