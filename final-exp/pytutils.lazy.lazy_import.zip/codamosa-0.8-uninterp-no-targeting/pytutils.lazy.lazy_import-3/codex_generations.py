

# Generated at 2022-06-21 21:47:11.651999
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import doctest
    doctest.testmod(verbose=None)

# Generated at 2022-06-21 21:47:21.070569
# Unit test for function lazy_import
def test_lazy_import():
    import bzrlib.tests
    scope = {}
    lazy_import(scope, '''
import bzrlib.tests
from bzrlib.tests import TestCase
''')
    test_case = scope['TestCase']
    # grab the reference to TestCase so we don't accidentally
    # delete it
    test_case = TestCase
    # let's make sure this works recursively
    scope = {}
    scope['lazy_import'] = lazy_import

# Generated at 2022-06-21 21:47:26.349119
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    def factory(self, scope, name):
        return 42

    scope = {'answer': ScopeReplacer(scope, factory, 'answer')}
    obj = scope['answer']
    assert obj._scope is scope
    assert obj._factory is factory
    assert obj._name == 'answer'
    assert obj._real_obj is None
    assert type(scope['answer']) is ScopeReplacer



# Generated at 2022-06-21 21:47:38.963525
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """This test tests if IllegalUseOfScopeReplacer.__str__() returns
    the expected string.
    """
    import StringIO
    saved_stderr = None
    try:
        saved_stderr = sys.stderr
        f = StringIO.StringIO()
        sys.stderr = f
        e = IllegalUseOfScopeReplacer('foo', 'bar')
        s = str(e)
    finally:
        sys.stderr = saved_stderr
    # We expect the following message
    expected = "IllegalUseOfScopeReplacer object 'foo' was used incorrectly:"\
               " bar\n"

# Generated at 2022-06-21 21:47:51.013867
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test for ImportProcessor.lazy_import."""
    # Trivial
    proc = ImportProcessor()
    proc.lazy_import(globals(), 'import foo')
    proc.lazy_import(globals(), 'from foo import bar')
    proc.lazy_import(globals(), 'import foo.bar')

    # Single line
    proc = ImportProcessor()
    proc.lazy_import(globals(), 'import foo, bar')
    proc.lazy_import(globals(), 'import foo as bar, baz')
    proc.lazy_import(globals(), 'from foo import bar, baz')
    proc.lazy_import(globals(), 'from foo import bar as bing, baz')

# Generated at 2022-06-21 21:47:56.692632
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib import tests
    import sys
    def raises_IllegalUseOfScopeReplacer():
        raise IllegalUseOfScopeReplacer('name', 'msg')

    # test for IllegalUseOfScopeReplacer and IllegalUseOfScopeReplacer
    # same message
    e1 = raises_IllegalUseOfScopeReplacer()
    e2 = raises_IllegalUseOfScopeReplacer()
    tests.TestCase.assertEqual(e1, e2)

    # test for IllegalUseOfScopeReplacer and IllegalUseOfScopeReplacer
    # different message
    e3 = raises_IllegalUseOfScopeReplacer()
    e3.msg = 'msg1'
    tests.TestCase.assertNotEqual(e1, e3)

    # test for IllegalUseOfScopeReplacer and Exception
    tests.TestCase.assertNot

# Generated at 2022-06-21 21:48:04.137976
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    test_scope = {}
    test_imports = {'foo': ImportReplacer,
                    'bar': ImportReplacer,
                    'baz': ImportReplacer}
    test_imports['foo'](test_scope, 'foo', ['foo'])
    test_imports['bar'](test_scope, 'foo', ['foo', 'bar'])
    test_imports['baz'](test_scope, 'baz', ['foo', 'bar', 'baz'])



# Generated at 2022-06-21 21:48:11.292846
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    from bzrlib.tests import TestCase
    class TestCaseIllegalUseOfScopeReplacer(TestCase):

        def test_IllegalUseOfScopeReplacer(self):
            e = IllegalUseOfScopeReplacer("foo", "bar")
            self.assertEqual("Scope replacer object 'foo' was used incorrectly: "
                "bar", str(e))

    TestCaseIllegalUseOfScopeReplacer().test_IllegalUseOfScopeReplacer()



# Generated at 2022-06-21 21:48:18.700363
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), 'test_bzrlib._lazy_import_test_module')
    disallow_proxying()
    # This should raise an exception, as the module should have already been
    # imported and should not be used as a proxy anymore
    try:
        test_bzrlib._lazy_import_test_module.replace_me
    except AttributeError:
        # This is fine, since we're not passing in the correct scope to make
        # that attribute available
        pass
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Should not be able to access '
                             '_lazy_import_test_module as a proxy')



# Generated at 2022-06-21 21:48:31.083835
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    from bzrlib.tests import TestCaseInTempDir

    class TestImportReplacer(ImportReplacer):

        def __init__(self, *args, **kwargs):
            self.calls = []
            ImportReplacer.__init__(self, *args, **kwargs)

        def _import(self, *args):
            self.calls.append(args)
            return ImportReplacer._import(self, *args)

    class TestImportProcessor(TestCaseInTempDir):

        def _test_lazy_import(self, text):
            import sys
            orig_dict = sys.modules.copy()
            replacer = TestImportReplacer(globals(), name='foo',
                module_path=['foo'], member=None, children={})

# Generated at 2022-06-21 21:48:42.420808
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__()"""
    # __repr__ returns the value of __str__
    msg = 'message'
    name = 'name'
    e = IllegalUseOfScopeReplacer(name, msg)
    r = repr(e)
    assert r == "%s('%s')" % (e.__class__.__name__, msg)



# Generated at 2022-06-21 21:48:49.896818
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    from StringIO import StringIO
    from cStringIO import StringIO as cStringIO
    import sys
    import time
    import traceback

    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r = repr(e)
    print >> sys.stderr, r


# TODO: This needs to be moved to a more appropriate place in
# bzrlib.trace, and then the rest of the lazy_import functionality can
# move to a better place.

# Generated at 2022-06-21 21:48:59.066348
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests import TestCase

    class TestImportReplacer(TestCase):
        def test_member_and_children(self):
            """Only one of member and children may be supplied."""
            module = {'foo':1}
            self.assertRaises(ValueError, ImportReplacer,
                scope=module, name='foo', module_path=['foo'],
                member='bar', children={})

    TestImportReplacer().test_member_and_children()



# Generated at 2022-06-21 21:49:07.243532
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    from bzrlib.tests import TestCaseWithTransport
    class TestImportReplacer(TestCaseWithTransport):

        def assertContains(self, container, key, msg=None):
            self.assertTrue(key in container, msg)

        def test_import_replacer_constructor(self):
            class FooReplacer(ImportReplacer):
                """Explicitly subclass ImportReplacer and provide constructor
                just to allow testing of the ImportReplacer constructor.
                """
                def __init__(self2, scope, name, module_path, member=None,
                             children={}):
                    ImportReplacer.__init__(self2, scope=scope, name=name,
                                            module_path=module_path,
                                            member=member, children=children)

            global_scope = {}
            FooReplacer

# Generated at 2022-06-21 21:49:14.412525
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test the ScopeReplacer object.

    The tests in this file for the ScopeReplacer object should be
    self-contained, thus any other tests for methods under the
    ScopeReplacer object are not required for this test.
    """
    import sys
    import unittest

    class TestScopeReplacer(unittest.TestCase):

        def setUp(self):
            # We explicitly create a new dictionary for the class so that
            # when the ScopeReplacer object runs its function, it will
            # not remove the old item from the globals() dictionary.
            #
            # This is really a bug in the ScopeReplacer code, where it
            # should be using the name to look up the item in the
            # dictionary instead of deleting it, but for the moment
            # this is how it is implemented.
            self.m_dict = {}


# Generated at 2022-06-21 21:49:27.818418
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Check the equality of IllegalUseOfScopeReplacer instances

    What it tests:
        Equality of IllegalUseOfScopeReplacer instances with same content.
    What it tests implicitly:
        __eq__ method for IllegalUseOfScopeReplacer
        __ne__ method for IllegalUseOfScopeReplacer
    """
    d = dict(
        name = 'name',
        msg = 'msg',
        extra = 'extra',
        )
    assert d
    e1 = IllegalUseOfScopeReplacer(**d)
    e2 = IllegalUseOfScopeReplacer(**d)
    assert e1 == e2

    for k, v in d.iteritems():
        d.pop(k)
        e2 = IllegalUseOfScopeReplacer(**d)
        # check that the comparison is not based on id

# Generated at 2022-06-21 21:49:29.014865
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass

# Generated at 2022-06-21 21:49:41.454731
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import types
    # Prepare mocks
    MockType = type('MockType', (), {
        '__name__': 'MockType',
        '__bases__': (types.ObjectType,),
        '__getattribute__': lambda x, y: object.__getattribute__(x, y)
    })
    MockObject = MockType()
    MockObject.__getattribute__ = lambda x, y: object.__getattribute__(x, y)
    MockObject.__setattr__ = lambda x, y, z: object.__setattr__(x, y, z)
    MockObject._resolve = lambda x: object.__getattribute__(x, '_real_obj')
    MockObject._resolve.__name__ = '_resolve'
    MockObject._name = '_name'


# Generated at 2022-06-21 21:49:53.538171
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """A test for some code that really really needs to be tested."""
    import sys
    import StringIO
    old_err = sys.stderr

# Generated at 2022-06-21 21:49:57.615258
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer("x", "y")
    assert str(e) == "x: y"
    e = IllegalUseOfScopeReplacer("x", "y", "z")
    assert str(e) == "x: y: z"



# Generated at 2022-06-21 21:50:18.336680
# Unit test for function disallow_proxying
def test_disallow_proxying():
    def simple_import(self, scope, name):
        import bzrlib
        return bzrlib

    global_scope = globals()
    lazy_import(global_scope, 'import bzrlib', simple_import)
    proxy = global_scope['bzrlib']
    disallow_proxying()

# Generated at 2022-06-21 21:50:27.893694
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}

    # import foo
    i = ImportReplacer(scope=scope, name='foo', module_path=['foo'],
        member=None, children={})
    # Make sure it does the right thing
    assert scope['foo'] is i
    assert scope is i._scope
    assert scope['foo']._scope is scope
    assert scope['foo']._member is None
    assert scope['foo']._module_path is i._module_path
    assert scope['foo']._module_path == ['foo']
    assert scope['foo']._import_replacer_children == {}


# Generated at 2022-06-21 21:50:30.927681
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    # Check that format strings work
    err = IllegalUseOfScopeReplacer('name', 'msg')
    str(err)
    # Check that extra parameters are available
    err = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str(err)



# Generated at 2022-06-21 21:50:38.303214
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__ should always go to the real object and not the
    replacement.
    """
    # Create a scope_replacer, and set the real object to a simple class.
    scope_replacer = ScopeReplacer(globals(), lambda x, scope, name: scope[name], 'MyClass')
    scope_replacer._real_obj = type('MyClass', (), {'a': 1})

    # Access the attribute of the real object, this will only get to
    # the real object and not the scope-replacer.
    assert scope_replacer.a == 1



# Generated at 2022-06-21 21:50:45.289760
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    from bzrlib import branch
    from bzrlib import errors as _mod_errors
    from bzrlib import urlutils
    from bzrlib import urlutils as _mod_urlutils
    from bzrlib.trace import mutter, mutter as _mod_mutter
    from bzrlib.trace import note, note as _mod_note
    from bzrlib.trace import show_error
    # Unit testing is weird
    global branch
    global _mod_errors
    global urlutils
    global _mod_urlutils
    global mutter, _mod_mutter
    global note, _mod_note
    global show_error

    # This is a free-form string that should be easy to put at the top
    # of any file

# Generated at 2022-06-21 21:50:58.246544
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from bzrlib.tests.per_errors import TestCase
    import operator
    from copy import copy
    from bzrlib.trace import mutter
    TestCase.add_error(copy)
    TestCase.add_error(operator.eq)
    TestCase.add_error(IllegalUseOfScopeReplacer._get_format_string)
    TestCase.add_error(IllegalUseOfScopeReplacer.__unicode__)
    TestCase.add_error(IllegalUseOfScopeReplacer.__str__)
    TestCase.add_error(IllegalUseOfScopeReplacer.__repr__)
    TestCase.add_error(mutter)

    # Test some basic equivalence.
    a = IllegalUseOfScopeReplacer('foo', 'a', 1)

# Generated at 2022-06-21 21:51:09.106194
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    processor = ImportProcessor()
    processor.lazy_import(globals(), """\
        import foo.bar, baz, blah blah
        from foo import blah as bloo, blah
        import (foo, baz)
        """)
    if sorted(processor.imports.keys()) != ['baz', 'blah', 'foo']:
        raise AssertionError('%r != %r' % (sorted(processor.imports.keys()),
                                           sorted(['baz', 'blah', 'foo'])))
    foo_value = processor.imports['foo']
    if foo_value[0] != ['foo']:
        raise AssertionError('%r != %r' % (foo_value[0], ['foo']))
    if foo_value[1] is not None:
        raise Assert

# Generated at 2022-06-21 21:51:13.383323
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__(other) should return True iff other is of the same class and
    has the same attributes."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    other = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e == other
    other = IllegalUseOfScopeReplacer('name', 'msg')
    assert e != other
    assert not e == 1



# Generated at 2022-06-21 21:51:19.992507
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # __unicode__ must return a unicode object.
    e = IllegalUseOfScopeReplacer('my_object', 'This is a msg', extra='detail')
    u = e.__unicode__()
    assert isinstance(u, unicode), repr(u)



# Generated at 2022-06-21 21:51:30.561719
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return a str object"""
    import warnings
    warnings.simplefilter('error', UnicodeWarning)
    try:
        # The unicode function will be called by __str__(),
        # if the __str__() returns a unicode object.
        # The following will raise a UnicodeWarning if _format returns a
        # unicode object.
        IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    except UnicodeWarning:
        raise AssertionError("IllegalUseOfScopeReplacer.__str__ doesn't return a str object")
    finally:
        warnings.simplefilter('default', UnicodeWarning)



# Generated at 2022-06-21 21:51:52.219905
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ of IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase
    class TestIllegalUseOfScopeReplacer(TestCase):
        def test___eq__(self):
            a = IllegalUseOfScopeReplacer('a', 'b')
            b = IllegalUseOfScopeReplacer('a', 'b')
            c = IllegalUseOfScopeReplacer('a', 'c')
            d = IllegalUseOfScopeReplacer('d', 'c')
            self.assertEqual(a, b)
            self.assertNotEqual(a, c)
            self.assertNotEqual(a, d)

    return TestIllegalUseOfScopeReplacer('test___eq__')



# Generated at 2022-06-21 21:51:57.886601
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should always return a str object,
    never a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(str(e), str)
    assert not isinstance(unicode(e), str)



# Generated at 2022-06-21 21:52:00.804868
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    import pickle
    p = IllegalUseOfScopeReplacer('foo', 'msg', 'extra')
    p = pickle.loads(pickle.dumps(p))




# Generated at 2022-06-21 21:52:09.677529
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    e1 = IllegalUseOfScopeReplacer('a', 'b')
    e2 = IllegalUseOfScopeReplacer('a', 'b')
    e3 = IllegalUseOfScopeReplacer('b', 'b')
    e4 = IllegalUseOfScopeReplacer('a', 'c')
    assert e1 == e2
    assert not e1 == e3
    assert not e1 == e4
    assert e1 != e3
    assert e1 != e4



# Generated at 2022-06-21 21:52:15.505220
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test construction of a ScopeReplacer object."""
    # These tests check that the construction of ScopeReplacer objects
    # doesn't create problems with the python bytecode loader. This
    # problem has been fixed in python 2.4.4, but not in previous
    # versions.
    # See https://bugs.launchpad.net/bzr/+bug/75045
    def factory(self, scope, name):
        raise ValueError
    a = {}
    b = {}
    import sys
    module = sys.modules[__name__]
    # Construct a ScopeReplacer
    try:
        ScopeReplacer(a, factory, 'a')
    except ValueError:
        pass
    # Construct a ScopeReplacer in a different scope

# Generated at 2022-06-21 21:52:25.023895
# Unit test for function lazy_import
def test_lazy_import():
    def test_import(root, name, expected):
        try:
            del root[name]
        except KeyError:
            pass
        lazy_import(root, 'import %s' % name)
        import_obj = root[name]
        assert isinstance(import_obj, ScopeReplacer)
        obj = import_obj._resolve()
        assert obj is root[name]
        assert isinstance(obj, lazy_import_class)
        assert list(obj._import_replacer_children.keys()) == expected

    def check_import(root, name, expected):
        """Check that a module was imported and it was the expected version."""

        # The child members is a map of child_name -> child_path
        expected_children = {}

# Generated at 2022-06-21 21:52:33.487265
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    import bzrlib
    lazy_import(globals(), """
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    """)
    disallow_proxying()
    try:
        errors.BzrError()
    except IllegalUseOfScopeReplacer as e:
        assert "Object already replaced, did you assign it to another variable?"\
                in str(e), str(e)
    else:
        assert False, "Unexpected success"
    # The next import should still work
    from bzrlib import branch



# Generated at 2022-06-21 21:52:43.237317
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class Subclass(IllegalUseOfScopeReplacer):
        pass
    obj1 = IllegalUseOfScopeReplacer('foo', 'bar')
    obj2 = IllegalUseOfScopeReplacer('foo', 'bar')
    obj3 = IllegalUseOfScopeReplacer('foo', 'baz')
    assert obj1 == obj2
    assert obj1 != obj3
    assert obj1 != 'foo'
    assert obj1 != id(obj1)
    assert obj1 != Subclass('foo', 'bar')
    assert obj1 != Subclass('foo', 'bar')
    assert obj1 != Subclass('foo', 'baz')
    assert obj1 != Subclass('foo', 'baz')


# Generated at 2022-06-21 21:52:55.915076
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    scope = {}
    import_replacer = ImportReplacer(scope=scope, name='foo',
        module_path=['foo'], member=None, children={})
    # Check that it gets the __import__ call
    # TODO: jam 20070612 Rework this to not use eval at all.
    import_replacer._import(scope, 'foo')
    eval('import foo')
    assert foo is scope['foo']

    scope = {}
    import_replacer = ImportReplacer(scope=scope, name='foo',
        module_path=['foo'], member=None, children={'bar':(['foo', 'bar'], None, {})})
    # Check that it gets the __import__ call
    # TODO: jam 20070612 Rework this to not use eval at all.

# Generated at 2022-06-21 21:53:08.743471
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    def assert_illegal_use_of_scope(method_name, assertion_func, *args):
        """Call the given method with the args and assert that an exception is raised.

        :param method_name: The name of the method to call.
        :param assertion_func: A callable that will be passed the raised exception as
            its only argument. This can be used to expand the test on the exception.
        :param args: The arguments to pass to the method.
        """
        replacer = ScopeReplacer({}, lambda x,y,z: x, "name")

# Generated at 2022-06-21 21:53:31.956802
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {'name': None}
    def factory(self, scope, name):
        return True
    replacer = ScopeReplacer(scope, factory, 'name')
    repl = replacer._resolve()
    assert isinstance(repl, bool)
    assert repl is True
    name = replacer._name
    assert name == 'name'
    assert scope['name'] is repl
    replacer._should_proxy = False
    replacer.foo = 'bar'
    assert scope['name'].foo == 'bar'

# Generated at 2022-06-21 21:53:39.054378
# Unit test for function disallow_proxying
def test_disallow_proxying():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    disallow_proxying()

# Generated at 2022-06-21 21:53:45.516908
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """ScopeReplacer should be able to be made in pure Python,
    and its constructor should make a placeholder object."""
    scope = {}
    def factory(self, scope, name):
        scope[name] = 42
        return scope[name]
    replacer = ScopeReplacer(scope, factory, 'test')
    # Object should appear in scope
    assert 'test' in scope
    assert scope['test'] is replacer
    assert replacer.test_resolve() == 42


# Generated at 2022-06-21 21:53:57.181655
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase

    class TestObj(object):
        called = False
        def __getattribute__(self, attr):
            TestObj.called = True
            return object.__getattribute__(self, attr)

    class TestScopeReplacer(TestCase):
        def test_scope_replacement(self):
            scope = {}
            global_scope = globals()
            test_obj = TestObj()
            def factory(dummy_self, dummy_scope, dummy_name):
                return test_obj
            obj = ScopeReplacer(scope, factory, 'testobj')
            self.assertEqual(None, obj._real_obj)
            self.assertFalse(TestObj.called)
            self.assertEqual(test_obj, obj._resolve())

# Generated at 2022-06-21 21:54:04.530532
# Unit test for function lazy_import
def test_lazy_import():
    def check(scope, text):
        lazy_import(scope, text)
        for name in scope:
            assert isinstance(scope[name], ScopeReplacer)

    check(globals(), """
        from bzrlib import (
            foo,
            bar,
            baz,
            )
        import bzrlib.branch
        import bzrlib.transport
        """)

    check(globals(), """
        from bzrlib import foo, bar, baz
        import bzrlib.branch
        import bzrlib.transport
        """)

# Generated at 2022-06-21 21:54:09.078027
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ => str"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r = repr(e)
    expected = "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    assert r == expected #, (r, expected)


# Generated at 2022-06-21 21:54:18.664783
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ should return a string that can be evaluated to recreate the
    exception"""
    # This is really a generic test for user defined exceptions..
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    r = repr(e)
    t = eval(r)
    assert isinstance(t, IllegalUseOfScopeReplacer)
    assert t == e
    # Make sure __repr__ actually returns a valid repr.
    import pickle
    # "e" is a new-style class, so it's safe to pickle it
    pickle.loads(pickle.dumps(e))



# Generated at 2022-06-21 21:54:25.866462
# Unit test for function disallow_proxying
def test_disallow_proxying():
    lazy_import(globals(), 'os')
    disallow_proxying()
    import os
    try:
        os.path
    except IllegalUseOfScopeReplacer as e:
        if e.name != 'os' or e.msg != "Object already replaced, did you assign" \
                " it to another variable?":
            raise AssertionError("Unexpected scope replacer error: %s" % e)
    else:
        raise AssertionError("Scope replacer did not raise")



# Generated at 2022-06-21 21:54:28.849752
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """IllegalUseOfScopeReplacer.__repr__ should quote its message"""
    import doctest
    doctest.testmod()
test_IllegalUseOfScopeReplacer___repr__()



# Generated at 2022-06-21 21:54:40.789143
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class TestScopeReplacer(object):
        """A dummy replacement object"""
        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
            self.dummy = 'dummy'
        def __call__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
    def makeObj(sr, s, n):
        del s[n]
        return TestScopeReplacer('arg1', 'arg2', kwarg1='kwval1', kwarg2='kwval2')
    obj = ScopeReplacer({}, makeObj, 'test')
    obj('arg3', 'arg4', kwarg1='newkwval1', kwarg2='newkwval2')

# Generated at 2022-06-21 21:55:11.506130
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Basic unit tests for lazy_import.ScopeReplacer"""
    import sys
    # Check replaces itself ok
    module = sys.modules.setdefault('bzrlib.lazy_test_module',
        sys.modules['bzrlib.lazy_import'])
    test_val = []
    def test_factory(self, scope, name):
        test_val.append((self, scope, name))
        return self
    ScopeReplacer(module.__dict__, test_factory, 'module_test')
    # test_val[0][0] is the self, so should be ScopeReplacer instance
    assert(test_val[0][0] is module.__dict__['module_test'])
    # test_val[0][1] is the scope, so should be module.__dict__

# Generated at 2022-06-21 21:55:22.693642
# Unit test for function lazy_import
def test_lazy_import():
    from bzrlib.tests import TestNotApplicable
    from bzrlib import (
        lazy_import,
        )
    try:
        import bzrlib.tests
    except ImportError:
        raise TestNotApplicable("bzrlib is not importable")
    glob = {}
    lazy_import(glob, '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.not_used
    import bzrlib.transport
    ''')
    try:
        glob['bar']
    except KeyError:
        raise TestNotApplicable("'bar' was not in globals()")

# Generated at 2022-06-21 21:55:33.936763
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test that ImportProcessor can build a map from text
    """

    processor = ImportProcessor()
    text = """
    import foo.bar as baz
    import foo.foo, foo, foo.bar
    from foo import bar, baz
    from foo.bar import bing
    """
    processor.lazy_import(globals(), text)
    assert len(processor.imports) == 4

# Generated at 2022-06-21 21:55:45.626943
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test that we can instantiate an ImportReplacer object.
    
    This is mostly to ensure the language cases we want to handle are
    actually handled.
    """
    from bzrlib import tests
    import bzrlib.tests as bzrlib_tests

    class Test(tests.TestCase):
        def check_replacer(self, replacer, name, module_path, member, children):
            self.assertIsInstance(replacer, ImportReplacer)
            self.assertEqual(replacer._name, name)
            self.assertEqual(replacer._module_path, module_path)
            self.assertEqual(replacer._member, member)
            self.assertEqual(replacer._import_replacer_children, children)


# Generated at 2022-06-21 21:55:57.330414
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import bzrlib
    ImportProcessor().lazy_import(globals(), """
from bzrlib import lock as lockmod
from bzrlib import (
    lock as lockmod2,
    ui
)
import bzrlib.lock as lockmod3
import bzrlib.lock as lockmod4, bzrlib.ui as ui2
""")
    assert lockmod is lockmod2
    assert lockmod is lockmod3
    assert lockmod is lockmod4
    assert ui is ui2
    # TODO: jam 20060912 This is a bit of a hack to deconfuse nose
    #       We want to make sure that the 'bzrlib.lock' object isn't
    #       bound to 'bzrlib' during the test, but we don't want
    #       to

# Generated at 2022-06-21 21:56:10.123287
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    def check_I_R(name, module_path, member, children):
        scope = {}
        ImportReplacer(scope=scope, name=name, module_path=module_path,
                       member=member, children=children)
        return scope
    scope = check_I_R('foo', ['foo'], None, {})
    assert isinstance(scope['foo'], ImportReplacer)
    scope = check_I_R('foo', ['foo'], None, {'bar':(['foo', 'bar'], None, {})})
    assert isinstance(scope['foo'], ImportReplacer)
    assert isinstance(scope['foo']._import_replacer_children['bar'][0],
                      ImportReplacer)
    scope = check_I_R('bar', ['foo'], 'bar', {})

# Generated at 2022-06-21 21:56:20.994885
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    e = IllegalUseOfScopeReplacer("name", "msg")
    assert e.name == "name"
    assert e.msg == "msg"
    assert e.extra == ''
    s = str(e)

# Generated at 2022-06-21 21:56:26.189595
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer.

    This test makes sure that __str__ method returns a str object,
    not a unicode object.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    got = str(e)
    assert isinstance(got, str)



# Generated at 2022-06-21 21:56:38.657163
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """IllegalUseOfScopeReplacer.__eq__: Two IllegalUseOfScopeReplacer have the
    same __dict__ and the same class, they are equal.

    Two IllegalUseOfScopeReplacer have the same __dict__ and the same class,
    they are equal.
    """
    from bzrlib import lazy_import
    # First with a lazy_import
    one = lazy_import.IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    two = lazy_import.IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert one is not two # __eq__ is not identity
    assert two is not one # __eq__ is not identity
    assert one == two
    assert two == one
    # And again, with a lazy_import.IllegalUseOfScopeReplacer
    # (in

# Generated at 2022-06-21 21:56:46.163419
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    """Test the import replacer objects work correctly.

    - The constructor validates its parameters.
    - The scope is correctly propagated.
    - The import is correctly performed.
    - The children are correctly propagated.
    """
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], children={'bar':(['foo', 'bar'], None,
                                                           {})})
    try:
        ImportReplacer(scope, 'foo', ['foo'], children={'bar':(['foo', 'bar'],
                                                               'baz', {})})
    except ValueError:
        pass
    else:
        raise AssertionError('member and children are mutually exclusive.')

    ImportReplacer(scope, 'foo', ['foo'], member='baz')

