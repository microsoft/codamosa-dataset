

# Generated at 2022-06-21 21:47:18.506984
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should always return a native string"""
    import sys
    class FailingStr(str):
        def __str__(self):
            raise ValueError("can't __str__")
    if sys.version_info[0] == 2:
        # In Python 2.x, calling str() on an instance of a subclass of str
        # causes the __str__() method of that subclass to be called.
        # So if __str__() fails, str() fails too.
        s = FailingStr('Foo')
        e = raises(ValueError, str, s)
        e.msg = "can't __str__"

# Generated at 2022-06-21 21:47:23.071186
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Unit test for constructor of class ImportProcessor.
    """
    processor = ImportProcessor()
    processor.lazy_import(globals(),
"""import foo
from foo import bar
import foo.baz
from foo import bar as bing
import foo.baz.bing as bong
""")
    assert 'foo' in globals()
    assert 'bar' in globals()
    assert 'baz' in globals()
    assert 'bing' in globals()
    assert 'bong' in globals()
    assert isinstance(foo, ImportReplacer)
    assert isinstance(bar, ImportReplacer)
    assert isinstance(baz, ImportReplacer)
    assert isinstance(bing, ImportReplacer)
    assert isinstance(bong, ImportReplacer)

# Generated at 2022-06-21 21:47:30.593749
# Unit test for function disallow_proxying
def test_disallow_proxying():
    class Foo(object):
        pass
    def factory(self, scope, name):
        return Foo()

    scope = {}
    lazy_import(scope, 'test1', factory)
    disallow_proxying()
    lazy_import(scope, 'test2', factory)
    test1 = scope['test1']
    test2 = scope['test2']
    try:
        test1.bar
    except Exception:
        raise AssertionError("test1 should work")

# Generated at 2022-06-21 21:47:41.974759
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    class OtherImportReplacer(ImportReplacer):
        pass

    # Test 1 - import foo
    scope1 = {}
    scope_globals = scope1
    name = 'foo'
    module_path = [name]
    member = None
    children = {}
    ImportReplacer(scope_globals, name, module_path, member, children)

    # Test 2 - import foo.bar
    scope2 = {}
    scope_globals = scope2
    name = 'foo'
    module_path = [name, 'bar']
    member = None
    children = {}
    ImportReplacer(scope_globals, name, module_path, member, children)

    # Test 3 - from foo import bar
    scope3 = {}
    scope_globals = scope3
    name = 'bar'
    module

# Generated at 2022-06-21 21:47:46.754875
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    _scope = {}
    def _factory(self, scope, name):
        return 'foo'
    _name = 'bar'
    _obj = ScopeReplacer(_scope, _factory, _name)


import pdb  # Breakpoint debugger


# Generated at 2022-06-21 21:47:49.728890
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Just check construction and display of exception works"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str(e)


# Generated at 2022-06-21 21:48:00.465188
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Test checking of whether the _factory sets the object correctly"""
    class C (object):
        pass
    class D (object):
        pass
    foo = {}
    factory_set_self = ScopeReplacer(foo, lambda self, scope, name: self, 'foo')
    factory_set_C = ScopeReplacer(foo, lambda self, scope, name: C(), 'foo')
    self.assertIsInstance(factory_set_self, ScopeReplacer)
    self.assertRaises(IllegalUseOfScopeReplacer, getattr, factory_set_self,
                      '_resolve')
    self.assertIsInstance(factory_set_C, ScopeReplacer)
    real_obj = factory_set_C._resolve()
    self.assertIsInstance(real_obj, C)

# Generated at 2022-06-21 21:48:12.243764
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import sys
    m = ImportProcessor()
    m.lazy_import(sys.modules, """
        import foo
        import foo.bar
        import foo.bar.baz
        import foo.bar.baz, foo.bar.baz.bing
        from foo.bar import baz
        from foo.bar import baz as bing
        from foo.bar import baz, bing as bong
        import abc, def
        """)

    # Check that it's safe to re-run multiple times

# Generated at 2022-06-21 21:48:20.786205
# Unit test for function disallow_proxying
def test_disallow_proxying():
    scope = {}
    lazy_import(scope, '''
            from bzrlib import osutils
            ''')
    disallow_proxying()

# Generated at 2022-06-21 21:48:25.598615
# Unit test for function lazy_import
def test_lazy_import():
    # This basic test is more of a smoke test, because it is really
    # hard to test lazy import mechanisms.
    imports = {}
    def _fake_import(scope, name, module_path, member=None, children={}):
        if member is None:
            scope[name] = 'mod:%s' % name
        else:
            scope[name] = 'mem:%s.%s' % (module_path, member)
        imports[name] = (module_path, member, children)

    lazy_import(imports, '''
    from bzrlib import (
        foo,
        bar,
        baz,
        )
    import bzrlib.branch
    import bzrlib.transport
    ''', lazy_import_class=_fake_import)


# Generated at 2022-06-21 21:48:33.172905
# Unit test for function lazy_import
def test_lazy_import():
    """Tests for the lazy_import function."""
    _test_lazy_import_1()
    _test_lazy_import_2()
    _test_lazy_import_3()
    _test_lazy_import_4()
    _test_lazy_import_5()
    _test_lazy_import_6()



# Generated at 2022-06-21 21:48:35.592456
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    def f():
        pass
    sr = ScopeReplacer({}, f, "f")
    sr(1)


# Generated at 2022-06-21 21:48:44.114618
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    class Derived1(IllegalUseOfScopeReplacer):
        _fmt = "Derived1 exception"
    class Derived2(IllegalUseOfScopeReplacer):
        _fmt = "Derived2 exception"
    class Derived3(Derived1):
        _fmt = "Derived3 exception"
    class Derived4(Derived1):
        _fmt = "Derived4 exception"
    class Derived5(IllegalUseOfScopeReplacer):
        _fmt = "Derived5 exception"
    class Derived6(IllegalUseOfScopeReplacer):
        _fmt = "Derived6 exception"
    class Derived7(Derived5):
        _fmt = "Derived7 exception"
    class Derived8(Derived6):
        _fmt = "Derived8 exception"

# Generated at 2022-06-21 21:48:54.404511
# Unit test for function lazy_import
def test_lazy_import():
    import sys
    # First, test the lazy_import function on a simple case
    glob_dict = {}
    lazy_import(glob_dict, '''import bzrlib.foo, bzrlib.bar''')
    assert 'bzrlib' not in glob_dict
    assert 'bzrlib' not in sys.modules

    assert 'bzrlib' not in glob_dict
    assert 'bzrlib' not in sys.modules

    # Note that this is the only way to get access to the 'foo' object.
    # If you try to access glob_dict['foo'], you will get an exception.
    foo_mod = glob_dict['bzrlib'].foo
    assert 'bzrlib' in glob_dict
    assert 'bzrlib' in sys.modules

# Generated at 2022-06-21 21:48:57.570871
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert repr(exc) == "IllegalUseOfScopeReplacer('name: msg: extra')"

# Generated at 2022-06-21 21:49:06.669473
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import bzrlib.tests
    bzrlib.tests.TestCase.assertIsInstance(
        IllegalUseOfScopeReplacer, Exception)
    bzrlib.tests.TestCase.assertIsNotNone(
        IllegalUseOfScopeReplacer(None, None))
    bzrlib.tests.TestCase.assertIsNotNone(
        IllegalUseOfScopeReplacer("name", "msg"))
    bzrlib.tests.TestCase.assertIsNotNone(
        IllegalUseOfScopeReplacer("name", "msg", "extra"))

    e = IllegalUseOfScopeReplacer("name", "msg", "extra")
    bzrlib.tests.TestCase.assertEqual("name", e.name)

# Generated at 2022-06-21 21:49:11.505500
# Unit test for method __repr__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___repr__():
    """__repr__ must be able to run even if the object is not fully
    initialized."""
    e = IllegalUseOfScopeReplacer('a', 'b')
    repr(e)



# Generated at 2022-06-21 21:49:20.501787
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.lazy_import
    globals = dict(map(lambda symbol: (symbol,bzrlib.lazy_import.ScopeReplacer(scope=locals(), factory=lambda self, scope, name: object(), name=symbol)), ('bzrlib',)))
    assert 'bzrlib' in globals, repr(globals)
    assert isinstance(globals['bzrlib'], bzrlib.lazy_import.ScopeReplacer), repr(globals['bzrlib'])
    assert globals['bzrlib'] is not None, repr(globals['bzrlib'])



# Generated at 2022-06-21 21:49:27.364913
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.log as _bzrlib_log
    _bzrlib_log._log_handler = _bzrlib_log.LogHandler(None, None, None)
    scope = {}
    name = 'name'
    def factory(self, scope, name):
        return 'real_obj'
    replacer = ScopeReplacer(scope, factory, name)
    replacer._setattr(replacer, '_scope', 'scope')


# Generated at 2022-06-21 21:49:40.526548
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys, threading
    def get_test_scope():
        import sys
        return sys.modules[__name__].__dict__
    scope = get_test_scope()

    def make_replacer(scope, factory, name):
        return ScopeReplacer(scope, factory, name)

    # This module is supposed to be thread-safe, but occasionally tests
    # have been known to fail, so we run them many times. This should make
    # them fail more reliably if they have any threading issues.
    for i in xrange(5):
        # Test that it can be used as an attribute/dictionary proxy
        replacer = make_replacer(scope, lambda self, scope, name: {}, 'foo')
        scope['foo']['bar'] = 42
        if scope['foo']['bar'] != 42:
            raise

# Generated at 2022-06-21 21:49:51.209576
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # put more accurate test here
    from bzrlib.tests.per_lazy_import import TestCaseWithMemoryTransport
    test_case = TestCaseWithMemoryTransport()
    test_case.run_test___setattr__()


# Generated at 2022-06-21 21:49:57.404738
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    # Test basic construction and attribute lookup
    scope = {}

    class test_class(object):
        pass

    def factory(replacer, scope, name):
        return test_class()
    replacer = ScopeReplacer(scope, factory, 'test_var')
    scope_value = scope['test_var']
    try:
        scope_value.attribute
    except AttributeError:
        pass
    else:
        raise AssertionError("ScopeReplacer didn't resolve attributes")
    scope_value.attribute = 1
    if scope['test_var'].attribute != 1:
        raise AssertionError("ScopeReplacer didn't update attributes")


# Generated at 2022-06-21 21:50:07.423880
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    class import_recorder(object):
        def __init__(self, scope, name, module_path, member, children):
            self.scope = scope
            self.name = name
            self.module_path = module_path
            self.member = member
            self.children = children
        def __setattr__(self, attr, value):
            raise Exception()
        def __getattribute__(self, attr):
            raise Exception()

    class import_recorder_factory(object):
        def __init__(self):
            self.attrs = {}
        def __call__(self, scope, name, module_path, member, children):
            r = import_recorder(scope, name, module_path, member, children)
            self.attrs[name] = r
            return r

# Generated at 2022-06-21 21:50:18.336474
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """Tests for a ScopeReplacer object."""
    # Issues we're trying to detect:
    # - using as a proxy twice
    # - calling self._resolve
    # - trying to replace yourself in the scope
    def _create_obj(self, scope, name):
        return 42
    scope = {}
    class TestClass(object):
        pass
    test_obj = TestClass()
    test_obj.test_scope = {}
    test_obj.test_scope['test_name'] = test_obj
    test_obj.test_name = test_obj
    # Test that we can't replace ourselves with a lazy proxy

# Generated at 2022-06-21 21:50:25.382051
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test the constructor of class ImportProcessor.

    This function may throw an exception, if the constructor fails.
    """
    import breezy
    ImportProcessor(breezy.tests.test_lazy_import.ImportReplacer)


try:
    from breezy import _mod_lazy_import
    ImportReplacer._import = _mod_lazy_import.lazy_import_replacer_import
except ImportError:
    pass



# Generated at 2022-06-21 21:50:35.664689
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    # Should call the real object's __call__
    def make_object(ignored, scope, name):
        class TestScopeReplacer(object):
            def __call__(self, *args, **kwargs):
                return list(args) + sorted(kwargs.items())
        return TestScopeReplacer()
    scope = {}
    lazy_object = ScopeReplacer(scope, make_object, 'some_name')
    bzrlib.tests.TestCase.assertEqual(
        [(1, 2), (3, 4), (5, 6)],
        lazy_object(1, 2, three=3, four=4, five=5, six=6))

# Generated at 2022-06-21 21:50:48.760562
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    import bzrlib.ui as ui
    import bzrlib.option as option

    # Convert a python import statement into a lazy import map
    # import foo => {'foo':(['foo'], None, {})}
    
    # from foo import bar => {'bar':(['foo'], 'bar', {})}
    processor = ImportProcessor()
    processor.lazy_import(globals(),
        """
        import bzrlib.ui
        import bzrlib.option
        # import ignored
        import bzrlib.ui as ui
        import bzrlib.option as option
        # import ignored
        from bzrlib.ui import _mod_ui
        from bzrlib.option import Option
        # from ignored
        """)
    # We need to also make sure we don't

# Generated at 2022-06-21 21:50:53.714649
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ method is broken.

    This test is only intended to exercise the __str__ method so it gets
    coverage.
    """
    e = IllegalUseOfScopeReplacer('fooname', 'foomsg')
    str(e)


# Generated at 2022-06-21 21:51:02.781718
# Unit test for function lazy_import
def test_lazy_import():
    class TestScope(object):
        pass
    scope = TestScope()
    scope.activated = False
    scope.replacement = None
    def _replacement(*args, **kwargs):
        scope.activated = True
        scope.replacement = ScopeReplacer(*args, **kwargs)
    lazy_import(scope, '''
    from bzrlib.foo import bar, baz
    import bzrlib.qux
    ''',
    lazy_import_class=_replacement)
    scope.__dict__

# Generated at 2022-06-21 21:51:12.065791
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    """Test IllegalUseOfScopeReplacer constructor for coverage.

    This tests if the constructor args are correctly assigned to the
    right attributes, and if the format methods are correctly implemented.
    """
    import sys
    if not hasattr(sys, 'exc_clear'):
        # Python 3.x, so not relevant.
        return
    e = IllegalUseOfScopeReplacer('foo', '10/20')
    sys.exc_clear()
    if str(e) != "ScopeReplacer object 'foo' was used incorrectly: 10/20":
        raise AssertionError("Test failed on %s" % e)
    e = IllegalUseOfScopeReplacer('bar', 'foo', 'Number must be positive')

# Generated at 2022-06-21 21:51:28.197442
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This test method was generated by testtools.

    testtools is Copyright (c) 2009 Canonical Ltd, and licensed under the
    MIT license.  Its source is available on https://launchpad.net/testtools.

    The unit tests generated by testtools are licensed under the GPLv3 or
    later.  A copy of this license is available at
    http://www.gnu.org/licenses/gpl-3.0 or later.
    """
    from testtools.testcase import ExpectedException
    from testtools.testcase import TestCase
    __tracebackhide__ = True # Hide traceback for py.test
    class IllegalUseOfScopeReplacerTest(TestCase):
        """Test the IllegalUseOfScopeReplacer class."""


# Generated at 2022-06-21 21:51:38.319790
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    """Test ImportProcessor constructor.
    
    It should always succeed and set only the expected attributes.
    """
    ip1 = test_support.import_process_env('ImportProcessor')
    ip2 = test_support.import_process_env('ImportProcessor',
                                          lazy_import_class=ImportReplacer)
    assert isinstance(ip1._lazy_import_class, type)
    assert not ip1.imports
    assert ip1._lazy_import_class is ImportReplacer
    assert ip2._lazy_import_class is ImportReplacer
    assert not ip1.imports

# Unit tests for the _build_map method of class ImportProcessor

# Generated at 2022-06-21 21:51:47.254082
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.test_lazy_import import CallableReplacer
    import unittest
    class __extend_str(object):
        def __init__(self, base):
            self.base = base
        def __call__(self, *args, **kwargs):
            return self.base + (args[0],)
    class TestCase_test_ScopeReplacer___call__(unittest.TestCase):
        def test_0(self):
            # testing that we can create a ScopeReplacer object that is a callable
            x = ScopeReplacer({}, CallableReplacer, 'x')
            y = x('bar')
            self.assertEqual(('x', 'bar'), y)
        def test_1(self):
            # testing that we can replace the callable
            x = Scope

# Generated at 2022-06-21 21:51:51.354384
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    try:
        raise IllegalUseOfScopeReplacer('obj', 'msg', extra=2)
    except IllegalUseOfScopeReplacer as e:
        pass
    assert str(e) == "ScopeReplacer object 'obj' was used incorrectly: msg: 2"



# Generated at 2022-06-21 21:52:03.444835
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test lazy_import method of ImportProcessor."""
    import_processor = ImportProcessor()
    globals()['ip'] = import_processor
    def process_import_str(import_str):
        """Process one import string."""
        import_processor.lazy_import(globals(), import_str)
    process_import_str('import foo')
    assert 'foo' not in globals()
    foo = object.__getattribute__(globals()['foo'], '_resolve')()
    from bzrlib.trace import mutter
    mutter(globals()['foo'])
    import_processor.lazy_import(globals(), 'import foo.bar')
    assert 'foo' not in globals()
    assert 'bar' not in globals()
    foo = object.__get

# Generated at 2022-06-21 21:52:13.709363
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Method __call__ of class ScopeReplacer"""
    def get_args_kwargs_str(args, kwargs):
        """Return a string representation of args and kwargs
        """
        arg_str = ', '.join(repr(arg) for arg in args)
        kw_str = ', '.join('%s=%r' % (k, v) for (k, v) in kwargs.iteritems())
        if arg_str and kw_str:
            arg_str += ', '
        arg_str += kw_str
        return arg_str

    class FakeScope(dict):
        """Fake scope"""

    class FakeObject(object):
        """Fake object that will replace the ScopeReplacer"""

        def __init__(self, *args, **kwargs):
            """Do nothing"""
            pass

# Generated at 2022-06-21 21:52:23.308832
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-21 21:52:34.549794
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from io import BytesIO
    from bzrlib.tests import TestCase

    class TestScopeReplacer(TestCase):

        def test_set_attibute_to_default(self):
            # Setting an attribute to its default value should succeed
            # even if that attribute is in __slots__.
            class Test(object):
                __slots__ = ('foo',)
                def __init__(self):
                    self.foo = 'bar'

            s = ScopeReplacer(dict(), Test, 'name')
            # Test the case of replacing an attribute with the same value
            s.foo = 'bar'
            TestCase.assertEqual(self, 'bar', s.foo)

            # Test the case of replacing an attribute with None
            s.foo = None

# Generated at 2022-06-21 21:52:37.933170
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__ should return a unicode object"""

    e = IllegalUseOfScopeReplacer("my_name", "my_msg")
    assert isinstance(e, Exception)
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'IllegalUseOfScopeReplacer object my_name was used incorrectly:' \
                ' my_msg'


# Generated at 2022-06-21 21:52:47.263633
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    
    class ImportReplacer(object):
        __slots__ = ['imports']
        def __init__(self, scope, name, module_path, member=None, children={}):
            
            self.imports = {}
            self.imports = {'name':name, 'module_path':module_path,
                            'member':member, 'children':children}
    
    
    
    scope = None
    text = 'import foo, foo.bar, foo.bar.baz as bing'
    imp_proc = ImportProcessor(import_replacer_class = ImportReplacer)
    imp_proc.lazy_import(scope, text)
    
    
    
    
    assert imp_proc.imports['foo'][1] == None

# Generated at 2022-06-21 21:52:57.911891
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import (
        ScopeReplacer,
        )
    # no arguments, raises TypeError
    try:
        ScopeReplacer.__getattribute__()
    except TypeError:
        pass
    else:
        raise AssertionError
    # one argument, raises TypeError
    try:
        ScopeReplacer.__getattribute__(None)
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 21:53:10.538246
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):
        def test__resolve__called_from___call__(self):
            # As a simple test, we allocate a new object in the global
            # namespace, and if called, resolve to that object.
            global resolved
            resolved = False
            global called_from
            called_from = None
            def factory(self, scope, name):
                global resolved
                global called_from
                resolved = True
                called_from = '__call__'
                class Dummy(object):
                    def __call__(self):
                        return 'called'

# Generated at 2022-06-21 21:53:22.045186
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    class Foo(IllegalUseOfScopeReplacer):
        _fmt = ("ScopeReplacer object %(name)r was used incorrectly:"
            " %(msg)s%(extra)s")
    e1 = Foo('a name', 'some message', 'some extra text')
    e2 = Foo('a name', 'some message', 'some extra text')
    e3 = Foo('another name', 'some message', 'some extra text')
    e4 = Foo('a name', 'some other message', 'some extra text')
    e5 = Foo('a name', 'some message', 'some other extra text')
    e6 = UnicodeError()
    assert e1 == e2
    assert e1 != e3
    assert e1 != e4
    assert e1 != e5
    assert e1 != e6
    assert str(e1)

# Generated at 2022-06-21 21:53:27.127271
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should always return a unicode object"""
    s = IllegalUseOfScopeReplacer('name', 'message')
    result = unicode(s)
    if not isinstance(result, unicode):
        raise AssertionError(
            "IllegalUseOfScopeReplacer.__unicode__ did not return a unicode"
            " object")


# Generated at 2022-06-21 21:53:39.052154
# Unit test for function disallow_proxying
def test_disallow_proxying():
    # This is nasty and fragile, but the best we can do without
    # the necessary API or monkey patching.
    assert ScopeReplacer._should_proxy
    from bzrlib.lazy_import import lazy_import
    from bzrlib.trace import mutter
    disallow_proxying()
    # Can't import mutter, so we just check it doesn't crash and hope
    # the selftest caller will notice the error.
    lazy_import(globals(), """
    import bzrlib.trace
    """)
    try:
        mutter('hello')
    except Exception as e:
        assert isinstance(e, IllegalUseOfScopeReplacer)
    else:
        assert False, "Disallow proxying didn't prevent using mutter"



# Generated at 2022-06-21 21:53:42.499486
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    variables = {}
    name = 'my_name'
    replacer = ScopeReplacer(variables, lambda sr, sc, n: 'good', name)
    assert replacer._scope is variables
    assert replacer._name == name



# Generated at 2022-06-21 21:53:46.821048
# Unit test for constructor of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer():
    error = IllegalUseOfScopeReplacer(name='foo', msg='bar')
    # make sure the error looks reasonable
    str(error)
    unicode(error)
    repr(error)
    # make sure the error is unique
    error2 = IllegalUseOfScopeReplacer(name='foo', msg='bar')
    error == error2



# Generated at 2022-06-21 21:53:57.665122
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Example of the ImportProcessor used in __init__.py"""
    # This class is pretty easy to unit test, as it implements a simple grammar
    processor = ImportProcessor()
    def verify_module(module, expected_member, expected_children):
        """Verify that a particular module entry is present"""
        module_def = processor.imports[module]
        if expected_member is not None:
            assert module_def[1] == expected_member
        for child, child_def in expected_children.items():
            assert child in module_def[2]
            assert module_def[2][child][1] == child_def[0]
            assert set(module_def[2][child][2].keys()) == set(child_def[1])


# Generated at 2022-06-21 21:54:09.078089
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ must escape %s as %%s.

    This might be a bit obscure, but it is important to have a consistent
    escaping approach.
    """
    x = IllegalUseOfScopeReplacer('foo', '%s', 42)
    u = unicode(x)
    if u != "IllegalUseOfScopeReplacer object 'foo' was used incorrectly:" \
            " 42":
        raise AssertionError(u)
    s = str(x)
    if s != "IllegalUseOfScopeReplacer object 'foo' was used incorrectly:" \
            " 42":
        raise AssertionError(s)
    # Test with a preformatted string
    x = IllegalUseOfScopeReplacer('foo', '%%s %s %s %s', (1, 2, 3))
    u

# Generated at 2022-06-21 21:54:20.736629
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    import re
    import sys
    import time
    import bzrlib
    import bzrlib.branch as branch
    import bzrlib.commands as commands
    import bzrlib.diff
    import bzrlib.dirstate
    import bzrlib.errors as errors
    import bzrlib.help_topics as help_topics
    import bzrlib.inventory
    import bzrlib.log as log
    import bzrlib.merge_directive
    import bzrlib.revision as revision
    import bzrlib.smart
    import bzrlib.status
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.external
    import bzrlib.tests.branch_implementations
    import b

# Generated at 2022-06-21 21:54:33.314774
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """Test for class ImportProcessor method lazy_import
    
        This test verifies the functionality of the method
    lazy_import of the ImportProcessor class.
        The test verifies three separate sets of import
    statements, and checks that the variables are added
    to the local scope as is expected.
        The test also verifies that exceptions are raised
    where they are expected.
    """
    import bzrlib
    import sys
    # test a simple import statement
    def test_simple_import():
        ip = ImportProcessor()
        ip.lazy_import(locals(), 'import bzrlib')
        assert bzrlib is bzrlib
        assert 'bzrlib' in locals()
        assert 'sys' not in locals()
    # test an import with an 'as' clause

# Generated at 2022-06-21 21:54:44.804139
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test_IllegalUseOfScopeReplacer___str__ - method __str__ of class IllegalUseOfScopeReplacer"""
    class MyClass(IllegalUseOfScopeReplacer):
        _fmt = '%(foo)s'

    class Derived(MyClass):
        pass

    obj = MyClass("name", "bar")
    assert obj._format() == "bar"
    assert str(obj) == "bar"
    assert repr(obj) == "MyClass('bar')"

    try:
        obj = Derived("name", "bar")
    except NameError:
        pass
    else:
        assert False, "Derived class should have raised NameError"


# Generated at 2022-06-21 21:54:52.456869
# Unit test for constructor of class ScopeReplacer
def test_ScopeReplacer():
    """This is a test implementation of the ScopeReplacer class.

    It should be used for unit testing the class,
    and not for real code.
    """
    class A(object):
        def f(self):
            return 'A.f()'

    a = A()
    def lazy_factory(scope_replacer, scope, name):
        return a

    scope = {}
    scope_replacer = ScopeReplacer(scope, lazy_factory, 'a')
    assert scope_replacer._name == 'a'
    assert scope_replacer._scope == scope
    assert scope_replacer._real_obj is None
    assert scope_replacer._factory is lazy_factory
    assert scope['a'] is scope_replacer



# Generated at 2022-06-21 21:54:59.728651
# Unit test for function disallow_proxying
def test_disallow_proxying():
    try:
        disallow_proxying()
        def f():
            return Proxy('something')
        lazy_import(globals(), 'from bzrlib.lazy_import import disallow_proxying')
        try:
            f()
            raise AssertionError('RuntimeError not raised')
        except RuntimeError as e:
            pass
    finally:
        ScopeReplacer._should_proxy = True



# Generated at 2022-06-21 21:55:10.875791
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import random
    import sys
    import threading
    # Attempt to enforce load of _ScopeReplacer__getattribute__.
    a = ScopeReplacer(None, None, None); a = None
    expect = 'abcdefghijklmnopqrstuvwxyz0123456789'
    # Enable proxy mode for selftest.
    ScopeReplacer._should_proxy = True
    # Set up structures for testing expected behaviour
    def test_factory(self, scope, name):
        # Check that we are called with the appropriate arguments
        if (scope is not sys.modules and
                self is not test_ScopeReplacer and
                name is not 'ScopeReplacer'):
            raise IllegalUseOfScopeReplacer(name, msg="Bad arguments to factory")
        return 32

# Generated at 2022-06-21 21:55:22.076532
# Unit test for function disallow_proxying
def test_disallow_proxying():
    import sys
    import bzrlib.lazy_import
    lazy_import = bzrlib.lazy_import.lazy_import

    # The 'inspect' module must be imported lazily to make it possible
    # to use this unit test to check its import.
    lazy_import(sys.modules[__name__], """
    import inspect
    """)
    import inspect
    try:
        disallow_proxying()
    except TypeError:
        # The scope replacer didn't exist yet and can't call
        # disallow_proxying. This is expected behavior and doesn't mean
        # the function is broken.
        pass

# Generated at 2022-06-21 21:55:33.009195
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class C(object):
        pass
    spl = C()
    spl.a = 1
    spl.b = 2
    global x
    x = ScopeReplacer(None, None, None)
    x._should_proxy = True
    x._real_obj = spl
    # Test with enabled proxy
    assert x.a == 1
    # Test with disabled proxy
    x._should_proxy = False
    try:
        x.a
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'x'
        assert e.msg == 'Object already replaced, did you assign it to ' \
            'another variable?'
        assert e.extra == ''
    else:
        assert False, "Should have raised IllegalUseOfScopeReplacer"
# test ends


# Generated at 2022-06-21 21:55:44.017513
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from . import lazy_import
    lazy_import(globals(), '''
from bzrlib import (
    errors,
    osutils,
    branch,
    )
import bzrlib.branch
''')
    try:
        # This should work, because not yet lazy-loaded.
        assert branch.Branch.open('.')
    except ImportError:
        raise TestSkipped('This test needs the "bzr branch" command available.')
    # Now for the test:
    class Foo(object):
        def __call__(self, *args, **kwargs):
            raise AssertionError("__call__ shouldn't be called")
    lazy_import(globals(), 'bzrlib.lazy_import.test_ScopeReplacer___call__.Foo')
    # Check that a call

# Generated at 2022-06-21 21:55:55.869506
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test the __str__ method of class IllegalUseOfScopeReplacer, which is a somewhat
    special case, because it needs to override the default format string.
    """
    # This test is completely impossible to write in a portable manner. The
    # Default encoding is different on different systems, and the only command
    # we have is unicode().
    from bzrlib.osutils import get_user_encoding
    import locale
    _save_loc = locale.getlocale()

# Generated at 2022-06-21 21:56:03.562660
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """__eq__ for IllegalUseOfScopeReplacer"""
    import doctest
    class Dummy(object):
        pass
    d = Dummy()
    d.__eq__ = lambda *args: None
    def check_IllegalUseOfScopeReplacer___eq__():
        """Test __eq__ for IllegalUseOfScopeReplacer"""
        # N.B.: doctest.EqualityFailure is not a subclass of Exception, so
        #       we can't just use that
        class MyEqualityFailure(Exception):
            pass
        # override doctest's equality checker to raise MyEqualityFailure
        # instead of AssertionError
        doctest.checker.compare = \
            lambda o, e: o != e and MyEqualityFailure(o, e)
        def make_exception():
            e1 = IllegalUseOfScopeRepl

# Generated at 2022-06-21 21:56:19.306979
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    """This tests ImportProcessor.lazy_import"""
    class TestImportReplacer(ImportReplacer):
        def __init__(self, scope, name, module_path, member=None, children={}):
            self.args = (scope, name, module_path, member, children)
            self.imported = False
            ImportReplacer.__init__(self, scope, name, module_path, member,
                                    children)
        def _import(self, scope, name):
            self.imported = True
            return ImportReplacer._import(self, scope, name)

    scope = {}
    processor = ImportProcessor(TestImportReplacer)

# Generated at 2022-06-21 21:56:25.485538
# Unit test for constructor of class ImportReplacer
def test_ImportReplacer():
    # This can be run from bzrlib.tests.test_bzrdir.
    #
    # It is run here because 'import bzrlib.tests.test_bzrdir' would trigger
    # problems with the instrumented tests - if you tried to import that
    # module, it would be loaded twice.

    # Some simple imports
    scope = {}
    ImportReplacer(scope, 'foo', ['foo'])
    assert scope['foo'] == ImportReplacer

    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], member='bar')
    assert scope['foo'] == ImportReplacer

    scope = {}
    ImportReplacer(scope, 'foo', ['foo'], member='bar', children={})
    assert scope['foo'] == ImportReplacer

    # And some complex imports
    scope = {}

# Generated at 2022-06-21 21:56:33.190525
# Unit test for constructor of class ImportProcessor
def test_ImportProcessor():
    p = ImportProcessor()
    p.lazy_import(dict(), text='\nimport bzrlib\n')
    out = p.imports
    expected = {'bzrlib': (['bzrlib'], None, {})}
    assert out == expected, 'imports map wrong, %s != %s' % (out, expected)


# Generated at 2022-06-21 21:56:42.580328
# Unit test for function disallow_proxying
def test_disallow_proxying():
    ScopeReplacer._should_proxy = True
    def test_function_to_be_replaced(self, scope, name):
        return None

    class TestClass(object):
        pass

    scope = {'lazy_obj': ScopeReplacer({}, test_function_to_be_replaced,
                                       'lazy_obj')}
    disallow_proxying()
    for key in ('__class__', '__getattribute__', '__setattr__',
                '__call__', '__dir__'):
        try:
            getattr(scope['lazy_obj'], key)
        except IllegalUseOfScopeReplacer:
            pass
        else:
            raise AssertionError(key)

# Test class ScopeReplacer:
# test that the class behaves as advertised

# Generated at 2022-06-21 21:56:54.203690
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    scope = bzrlib.__dict__.copy()
    scope['bzrlib'] = bzrlib
    orig = bzrlib.Repository
    del bzrlib.Repository