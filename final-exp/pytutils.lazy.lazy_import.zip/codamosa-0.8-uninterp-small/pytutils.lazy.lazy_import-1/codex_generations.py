

# Generated at 2022-06-26 02:15:52.549401
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('a string', 'a string', 'a string')
    var_0.__str__()


# Generated at 2022-06-26 02:15:53.775990
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    return None


# Generated at 2022-06-26 02:16:01.949664
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys as module_0

    check_function_name(ScopeReplacer.__setattr__, '__setattr__')
    check_function_name(ScopeReplacer, 'ScopeReplacer')

    scope_4 = {'var_0':var_0}
    var_0 = ScopeReplacer(scope_4, lambda x,y,z:y[z], 'var_0')

    def test_case_1():
        var_0 = disallow_proxying()
    test_case_1()

    var_0.__setattr__('foo', 'bar')


# Generated at 2022-06-26 02:16:07.466992
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # The callable is implemented by the '_resolve' method which will be called
    # automatically.
    a = ScopeReplacer({}, lambda r, s, n: r, 'a')
    assert a() is a


# Generated at 2022-06-26 02:16:12.976648
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.blackbox
    import bzrlib.lazy_import
    gc = {}
    factory = lambda s, scope, name: bzrlib.tests.blackbox.TestCase
    obj = bzrlib.lazy_import.ScopeReplacer(gc, factory, 'obj')
    result = obj(0)



# Generated at 2022-06-26 02:16:18.795072
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestUtil
    import sys
    import testresources
    global_testresources = testresources.IsolatedResourceManager()
    def test_factory_0(self, scope, name):
        test_case_0()
        self_real_obj = object.__getattribute__(self, '_real_obj')
        self_factory = object.__getattribute__(self, '_factory')
        self_scope = object.__getattribute__(self, '_scope')
        global_scope = 'global'
        self_name = object.__getattribute__(self, '_name')
        return self_real_obj
    from bzrlib.tests import TestUtil
    import sys
    import testresources
    global_testresources = testresources.IsolatedResourceManager()
    my

# Generated at 2022-06-26 02:16:32.326803
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import scope_replacer
    from bzrlib.lazy_import import scope
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import LazyObject
    from bzrlib.lazy_import import LazyClass
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import LazyModule
    from bzrlib.lazy_import import ImportNotFound
    from bzrlib.lazy_import import illegal_use_of_scope_replacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import disallow_proxying

    # module scope_replacer
    var_0 = Scope

# Generated at 2022-06-26 02:16:39.781337
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Test normal use of IllegalUseOfScopeReplacer by supplying arguments
    # to the constructor.
    assert unicode(IllegalUseOfScopeReplacer('name', 'msg', 'extra')) == \
        u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'


# Generated at 2022-06-26 02:16:43.483942
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    global var_0
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    var_0 = IllegalUseOfScopeReplacer(
            'name',
            'msg',
            'extra')
    var_1 = str(var_0)


# Generated at 2022-06-26 02:16:52.524532
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from StringIO import StringIO
    from sys import stdout
    from io import StringIO as UnicodeIO
    exception = IllegalUseOfScopeReplacer('bar','foo',extra='baz')
    try:
        raise exception
    except:
        f = StringIO()
        import pdb
        pdb.post_mortem(f)
        value = f.getvalue()
    return


# Generated at 2022-06-26 02:17:08.162326
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib import lazy_import
    from cStringIO import StringIO
    from bzrlib.bzrdir import BzrDir

    class TestCase(TestCase):

        def test_ScopeReplacer___call__(self):
            # Test that ScopeReplacer will proxy a call to the real object.
            #
            # This test is required to ensure that ScopeReplacer() will be
            # called as a function.
            #
            # setUp()
            globals_ = {}
            name = 'BzrDir'
            # ScopeReplacer()
            lazy_import.lazy_import(globals_, """
from bzrlib import (
    globals,
    osutils,
    )
import bzrlib
""")
            # test

# Generated at 2022-06-26 02:17:13.395001
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    instance = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(instance.__unicode__(), unicode)


# Generated at 2022-06-26 02:17:15.969142
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer("name_0", "name_1")
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:17:17.394142
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-26 02:17:26.042590
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from testtools import TestCase
    from testtools.matchers import Contains
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer(u'name', u'msg', u'extra')
    s = e.__unicode__()
    TestCase().assertThat(s, Contains(u'"name"'))
    TestCase().assertThat(s, Contains(u'"msg"'))
    TestCase().assertThat(s, Contains(u'"extra"'))


# Generated at 2022-06-26 02:17:34.398291
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # It is useful to be able to construct an IllegalUseOfScopeReplacer
    # instance and then call __str__ on it. This ensures that the
    # exception message is created in the right way, regardless of
    # whether str is called first or unicode is called first.
    e = IllegalUseOfScopeReplacer("foo", "bar")
    str(e)
    unicode(e)


# Generated at 2022-06-26 02:17:47.844043
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import unittest
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    def test_callable_0(args, kwargs):
        if len(args) != 2:
            raise TypeError('Wrong number of positional arguments')
        if len(kwargs) != 2:
            raise TypeError('Wrong number of keyword arguments')
        if args[0] != 'a':
            raise TypeError('Wrong arguments')
        if args[1] != 'b':
            raise TypeError('Wrong arguments')
        if kwargs['c'] != 'c':
            raise TypeError('Wrong arguments')
        if kwargs['d'] != 'd':
            raise TypeError('Wrong arguments')
        return args, kwargs
   

# Generated at 2022-06-26 02:17:59.655385
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCaseInTempDir

    class TestCase(TestCaseInTempDir):

        def test_ScopeReplacer___setattr__(self):
            from bzrlib import lazy_import

            # create a scope
            scope = {}
            factory = lazy_import.lazy_import
            name = 'a'
            subject = lazy_import.ScopeReplacer(scope, factory, name)
            lazy_import.allow_proxying()

            subject.__setattr__('_should_proxy', False)
            self.assertRaises(lazy_import.IllegalUseOfScopeReplacer, subject.__getattribute__, '_should_proxy')

    test_case_0.tearDown = TestCase.tearDown



# Generated at 2022-06-26 02:18:03.293718
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    instance = ScopeReplacer(None, None, None)
    if hasattr(instance, '_ScopeReplacer__setattr__'):
        attr = '_ScopeReplacer__setattr__'
    else:
        attr = '__setattr__'
    method = getattr(instance, attr)
    method('_name', 'foo')
    assert_equal('foo', instance._name)
    method('_name', 'bar')
    assert_equal('bar', instance._name)


# Generated at 2022-06-26 02:18:12.223899
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from doctest import DocTestCase
    import bzrlib
    import bzrlib.tests
    docstr_0 = "A lazy object that will replace itself in the appropriate scope.\n\n    This object sits, ready to create the real object the first time it is\n    needed.\n    "
    docstr_1 = "Create a temporary object in the specified scope.\n        Once used, a real object will be placed in the scope.\n\n        :param scope: The scope the object should appear in\n        :param factory: A callable that will create the real object.\n            It will be passed (self, scope, name)\n        :param name: The variable name in the given scope.\n        "

# Generated at 2022-06-26 02:18:28.572859
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import test_case_0
    assert test_case_0.__module__ == __name__
    def func(self, *args, **kwargs):
        return args, kwargs
    assert type(func) is type(ScopeReplacer)
    assert isinstance(func, ScopeReplacer)
    globals()['var_0'] = ScopeReplacer(globals(), func, 'var_0')
    test_case_0()


# Generated at 2022-06-26 02:18:32.191783
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer("a", "b", "c")
    assert str(e) == 'IllegalUseOfScopeReplacer object \'a\' was used ' \
        'incorrectly: b: c'


# Generated at 2022-06-26 02:18:36.371351
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer("a", "b")
    print('Unit test for method __str__ of class IllegalUseOfScopeReplacer')
    print(e)


# Generated at 2022-06-26 02:18:38.844893
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = disallow_proxying()
    var_1 = IllegalUseOfScopeReplacer('b', 'c', var_0)
    var_1.__unicode__()


# Generated at 2022-06-26 02:18:42.501621
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer, disallow_proxying, allow_proxying
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class _TestCase(TestCase):
        def test_0(self):
            test_case_0()

    test_case_0 = _TestCase('test_0')
    test_case_0.run()



# Generated at 2022-06-26 02:18:50.499664
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import test.test_lazy_import
    f = test.test_lazy_import.ScopeReplacer
    obj_0 = f
    def g0(this, scope, name):
        a = this
    def f0(this):
        a = this
        b = obj_0._factory
        c = obj_0._name
        d = obj_0._real_obj
        e = obj_0._resolve
        g0(this)
    f0(obj_0)


# Generated at 2022-06-26 02:18:58.566927
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests.TestUI import TestUI
    from bzrlib.trace import mutter
    from unittest import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # Test the module-level method
    mutter("foo")
    # Test overriding the default message.
    name = 'foo'
    msg = 'bar'
    extra = 'spam'
    err = IllegalUseOfScopeReplacer(name, msg, extra)
    # Test the module-level method
    err.mutter()


# Generated at 2022-06-26 02:19:06.256572
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCaseWithMemoryTransport
    from bzrlib.tests.test_lazy_import import fake_module
    from bzrlib.lazy_import import (
        lazy_import,
        _lazy_import,
        _replace_scope_with_value,
        disallow_proxying,
        )
    from bzrlib.trace import mutter
    import sys

    def _call_ScopeReplacer___setattr__(attr, value):
        return ScopeReplacer.__setattr__(self, attr, value)

    # Replace ScopeReplacer._should_proxy as a workaround for the
    # fact that it is not possible to call setattr on the class
    # directly.
    # The test case is extracted from bug #505252.

# Generated at 2022-06-26 02:19:18.433005
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import disallow_proxying
    from bzrlib.lazy_import import lazy_import
    from testtools import ExpectedException
    global loc_0, loc_1, loc_2, var_0, var_1, var_2
    scope = { }
    scope['x'] = 0
    with ExpectedException(IllegalUseOfScopeReplacer,
            "ScopeReplacer object 'x' was used incorrectly: "
            "Object already replaced, did you assign it to another variable?"):
        lazy_import(scope, '''
        x = "1"
        ''')
    disallow_proxying()

# Generated at 2022-06-26 02:19:25.061797
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unicode of IllegalUseOfScopeReplacer is its message"""

    err = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    err_unicode = unicode(err)
    if isinstance(err_unicode, str):
        # Try decoding the str using the default encoding.
        err_unicode = unicode(err_unicode)
    if err_unicode != u'ScopeReplacer object \'name\' was used incorrectly: msg: extra':
        raise AssertionError('Unicode of IllegalUseOfScopeReplacer is not its message')


# Generated at 2022-06-26 02:19:32.143291
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    assert var_0.__str__() == var_0.msg


# Generated at 2022-06-26 02:19:43.506215
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import os
    import traceback
    from bzrlib import lazy_import

    def test_case_1():
        import sys
        var_0 = (1)
        var_1 = var_0.__neg__()
        sys.stderr.write("\n%s %s %s %s\n" % (var_1, var_0, test_case_1, var_0.__neg__))
        return (var_1 is None)

    def test_case_2():
        import sys
        var_0 = 5
        var_1 = var_0.__abs__()
        sys.stderr.write("\n%s %s %s %s\n" % (var_1, var_0, test_case_2, var_0.__abs__))

# Generated at 2022-06-26 02:19:52.650001
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Units tests for __setattr__.

    This is a little tricky because __setattr__ doesn't actually raise
    the error.
    """
    from bzrlib.lazy_import import lazy_import, disallow_proxying
    from bzrlib import errors
    globals()['errors'] = errors
    vars = {}
    lazy_import(vars, 'from bzrlib import (errors, osutils,)')
    var_1 = vars['errors']
    var_2 = errors
    try:
        var_1.__setattr__('stupid_variable', 0)
    except TypeError:
        return
    try:
        var_2.__setattr__('stupid_variable', 0)
    except TypeError:
        return
    var_0 = disallow_proxying()

# Generated at 2022-06-26 02:19:56.338173
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # from bzrlib import lazy_import
    # var_0 = lazy_import.ScopeReplacer(None, None, None)
    # var_0.__setattr__('name', 'value')
    raise NotImplementedError


# Generated at 2022-06-26 02:19:58.050237
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = disallow_proxying()


# Generated at 2022-06-26 02:20:06.086694
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer()
    var_1 = var_0._resolve()
    try:
        var_2 = var_0()
    except Exception as var_3:
        var_2 = None
    var_4 = var_0.__call__()
    var_5 = var_0.__getattribute__('__call__')()
    try:
        var_6 = var_0.__getattribute__('_resolve')()()
    except Exception as var_7:
        var_6 = None


# Generated at 2022-06-26 02:20:09.746055
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__()
    """
    var_0 = Exception()
    var_1 = IllegalUseOfScopeReplacer('lazy_import', 'failed to import', var_0)
    var_2 = var_1.__str__()



# Generated at 2022-06-26 02:20:16.013499
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    global var_0
    var_0 = test_case_0()
    # Set obj.passed_thru_self in main scope
    var_0.passed_thru_self = "passed_thru_self"
    # obj.passed_thru_self should still be set
    assert var_0.passed_thru_self == "passed_thru_self"

if __name__ == '__main__':
    test_ScopeReplacer___setattr__()

# Generated at 2022-06-26 02:20:19.679005
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import unittest
    class TestScopeReplacer(unittest.TestCase):
        def test_0(self):
            return

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestScopeReplacer))
    result = unittest.TestResult()
    suite.run(result)
    return result


# Generated at 2022-06-26 02:20:31.164711
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('var_0', 'Dummy')
    # <bound method IllegalUseOfScopeReplacer._format of
    # IllegalUseOfScopeReplacer('var_0', 'Dummy', '')>
    # str(e)
    # 'IllegalUseOfScopeReplacer(var_0, Dummy)'
    # repr(e)
    # "IllegalUseOfScopeReplacer('var_0', 'Dummy', '')"
    # e._format()
    # 'Illegal use of scope replacer: Dummy'
    # getattr(e, '_fmt', None)
    # 'Illegal use of scope replacer: %(msg)s%(extra)s'
    pass # tested in bzrlib.tests.blackbox.test_lazy_import.TestLazyImport.test_

# Generated at 2022-06-26 02:20:43.925068
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    c = IllegalUseOfScopeReplacer("var_0", "var_1", extra="var_2")
    r = repr(c)
    e = "IllegalUseOfScopeReplacer('var_0', 'var_1', 'var_2')"
    assert(r == e)
    s = str(c)
    e = "var_0: var_1: var_2"
    assert(s == e)


# Generated at 2022-06-26 02:20:46.250149
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-26 02:20:49.650263
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    var_1 = var_0.__unicode__()
    assert(var_1 == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra')
    pass



# Generated at 2022-06-26 02:21:00.543087
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from StringIO import StringIO
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    import sys
    import unittest

    class TestableScopeReplacer(ScopeReplacer):
        """A ScopeReplacer that is testable.
        It is created by specifying the attributes to set.
        """
        def __init__(self,
            _name='_name',
            _real_obj='_real_obj',
            _scope='_scope',
            _factory='_factory',
            attr='attr',
            value='value',
            ):
            ScopeReplacer.__init__(self, _scope, _factory, _name)
            object.__setattr__(self, '_name', _name)

# Generated at 2022-06-26 02:21:05.959261
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCaseInTempDir
    import os.path
    import sys
    import _importer
    test_case_0()
    test_obj = ScopeReplacer(globals(), _importer.import_, 'test_obj')
    test_obj.test_bar(test_obj)
    return None # mark as passed


# Generated at 2022-06-26 02:21:10.933240
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer({}, None, None)
    var_1 = IllegalUseOfScopeReplacer(None, None)
    try:
        var_0.__setattr__('foo', 'bar')
    except IllegalUseOfScopeReplacer as var_2:
        var_1 = var_2
    var_3 = 'Object already replaced'
    var_4 = var_1._get_format_string()
    assert var_4 == var_3

# Generated at 2022-06-26 02:21:18.808624
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    global var_0
    var_0 = ScopeReplacer(locals(), lambda x: None, 'var_0')
    # From line 22, col 1.
    write('''\n''')
    # From line 23, col 1.
    write('''var_0 = object()\n''')
    # From line 24, col 1.
    write('''assert var_0 is not None''')


# Generated at 2022-06-26 02:21:30.923327
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__ScopeReplacer___call__ : 
    Tests that an exception is thrown when a ScopeReplacer instance is
    called and has already been resolved.
    
    """
    var_0 = ScopeReplacer
    var_1 = IllegalUseOfScopeReplacer
    var_2 = var_0.__init__(var_0, '_scope', '_factory', '_name', '_real_obj')
    var_3 = var_0._resolve(var_0)
    try:
        var_4 = var_0(var_0, *[])
    except var_1 as var_5:
        var_6 = var_5
    except Exception as var_7:
        var_8 = var_7
    else:
        var_8 = None

# Generated at 2022-06-26 02:21:33.686506
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()

# vim: set filetype=python ts=4 sw=4 et si

# Generated at 2022-06-26 02:21:36.752354
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(), (lambda obj, scope, name: obj), '__builtins__')
    var_0._should_proxy = False
    getattr(var_0, 'get')()


# Generated at 2022-06-26 02:22:05.023937
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    dummy_self = ScopeReplacer(globals(), None, 'dummy_self')
    dummy_attr = '__call__'
    dummy_args = (None,)
    dummy_kwargs = {}
    with testtools.ExpectedException(IllegalUseOfScopeReplacer, ""):
        dummy_self.__call__(dummy_attr, dummy_args, dummy_kwargs)


# Generated at 2022-06-26 02:22:11.272280
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_1 = IllegalUseOfScopeReplacer(name = 'name', msg = 'msg', extra = 'extra')
    var_2 = var_1._format()
    var_3 = unicode(var_2)
    var_4 = var_1.__unicode__()
    var_5 = pyunit.unit.compare(var_4, var_3, "Test #0 for method __unicode__ of class IllegalUseOfScopeReplacer")
    if (var_5 != 0):
        pyunit.unit.erase_last_test_exception()
        raise pyunit.unit.TestException("Test #0 for method __unicode__ of class IllegalUseOfScopeReplacer failed: " + str(var_5))

# Generated at 2022-06-26 02:22:13.251518
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
  scope = {}
  var_0 = ScopeReplacer(scope,factory, 'name')
  var_0()
  pass


# Generated at 2022-06-26 02:22:17.531149
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from io import BytesIO
    out = BytesIO()
    s = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    print(s, file=out)


# Generated at 2022-06-26 02:22:23.010613
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_1 = var_0._format()
    var_2 = 'Unprintable exception IllegalUseOfScopeReplacer: dict=%(dict)r, fmt=%(fmt)r, error=%(error)r'
    var_3 = var_1 == var_2


# Generated at 2022-06-26 02:22:27.612860
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(var_0, var_0)
    var_0 = var_0.__str__()


# Generated at 2022-06-26 02:22:33.031364
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # If you to do x = y, setting this to False will disallow access to
    # members from the second variable (i.e. x). This should normally
    # be enabled for reasons of thread safety and documentation, but
    # will be disabled during the selftest command to check for abuse.
    ScopeReplacer._should_proxy = False



# Generated at 2022-06-26 02:22:38.915508
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Make sure that str() works
    class SomeError(RuntimeError):
        _fmt = ("Failed to %(action)s. %(msg)s")
        def __init__(self, arg0):
            pass
    obj = SomeError(var_0)
    str(obj)
    # Make sure that unicode() works
    unicode(obj)


# Generated at 2022-06-26 02:22:39.449883
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:22:41.358244
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = IllegalUseOfScopeReplacer(
        u"name",
        u"msg",
        )
    # _fmt is a unicode string
    case_0._fmt = u"fmt"
    test_case_0()


# Generated at 2022-06-26 02:23:13.197524
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # this will raise an exception if it fails.
    test_case_0()


# Generated at 2022-06-26 02:23:16.647805
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__(self: bzrlib.lazy_import.IllegalUseOfScopeReplacer) -> str"""
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_1 = var_0.__str__()
    return var_1


# Generated at 2022-06-26 02:23:25.069739
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    assertEqual(var_0, None)
    var_0 = allow_proxying()
    globals()["var_1"] = lazy_import_factory(None, "bzrlib.lazy_import.test_case_0", "var_1")
    var_1()
    test_case_0()
    assertEqual(var_0, "var_0")
    assertEqual(var_1, "var_1")


# Generated at 2022-06-26 02:23:26.053795
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass # tested elsewhere


# Generated at 2022-06-26 02:23:28.188506
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('a', 'b')
    str(e)


# Generated at 2022-06-26 02:23:33.793448
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__() should raise IllegalUseOfScopeReplacer if proxying is
    # disabled and the replacement has already happened.
    obj = ScopeReplacer(None, None, 'name')
    try:
        obj.__setattr__('x', True)
    except IllegalUseOfScopeReplacer:
        exc = lldb.SBError
    else:
        exc = None

    if exc is None:
        raise ReadEofError("got True, expected IllegalUseOfScopeReplacer")


# Generated at 2022-06-26 02:23:42.964654
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global var_0
    try:
        var_0
    except NameError:
        var_0 = None
    if var_0 is None:
        from bzrlib.tests import resources
        resources.load_tests()
        from bzrlib.tests.blackbox import test_selftest
        var_0 = test_selftest.SelftestBlackboxTestCase(test_case_0, [], 'test case 0')
    return var_0


# Generated at 2022-06-26 02:23:46.677198
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    test_case_0()
    test_case_0()


_imports_by_module = {}
_imports_by_module_lock = bzrlib.lockdir.LockDir()



# Generated at 2022-06-26 02:23:51.439387
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestSkipped
    case_0_obj = ScopeReplacer(globals(),
                               lambda self, scope, name: scope[name],
                               name='test_case_0')
    var_0 = disallow_proxying()



# Generated at 2022-06-26 02:23:55.585936
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import (
        IllegalUseOfScopeReplacer,
        )
    obj_0 = IllegalUseOfScopeReplacer('','')
    var_0 = unicode(obj_0)
    assert isinstance(var_0, unicode)


# Generated at 2022-06-26 02:24:24.089135
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import (ScopeReplacer, IllegalUseOfScopeReplacer)

    class TestableScopeReplacer(ScopeReplacer):
        """Derived class with wrapper for _real_obj"""
        def __init__(self):
            super(TestableScopeReplacer, self).__init__(
                scope={}, factory=lambda x, y, z: x, name='var_0')
        def get_real_obj(self):
            return self._real_obj

    # Make sure class has initial state
    test_case_0()

    def factory(tmp, scope, name):
        return "a string"

    # test case with initial state 'var_0' not in scope
    x = {}
    tmp = TestableScopeReplacer()

# Generated at 2022-06-26 02:24:27.687098
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    # Confirm that the repr() is something reasonable
    str(var_0)


# Generated at 2022-06-26 02:24:36.048312
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as e:
        assert isinstance(e.name, str)
        assert isinstance(e.msg, str)
        assert isinstance(e.extra, str)
        assert str(e) == 'ScopeReplacer object \'var_0\' was used incorrectly: This variable cannot yet be used like this: integer'
        return
test_IllegalUseOfScopeReplacer___unicode__.func_annotations = {'return': (str,)}


# Generated at 2022-06-26 02:24:37.057519
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(1, 2)
    assert isinstance(var_0, Exception)


# Generated at 2022-06-26 02:24:40.318044
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer("name_0", "msg_1", "extra_2")
    var_3 = str(var_0)
    return var_3



# Generated at 2022-06-26 02:24:44.310569
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    __tracebackhide__ = True
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    try:
        var_0.__unicode__()
        var_1 = True
    except Exception:
        var_1 = False
    return var_1


# Generated at 2022-06-26 02:24:46.113358
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer(None, None)
    value = e.__unicode__()
    assert isinstance(value, unicode)


# Generated at 2022-06-26 02:24:47.294322
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()



# Generated at 2022-06-26 02:24:49.744171
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for  IllegalUseOfScopeReplacer.__unicode__
    """
    # Insert your code here.
    raise AssertionError("No implemented")


# Generated at 2022-06-26 02:24:54.363090
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exception = IllegalUseOfScopeReplacer("name", "message", "extra")
    exception._preformatted_string = 'Unicode string'
    result = str(exception)
    if result != "Unicode string":
        raise AssertionError("expected \"Unicode string\", got %r" % result)
