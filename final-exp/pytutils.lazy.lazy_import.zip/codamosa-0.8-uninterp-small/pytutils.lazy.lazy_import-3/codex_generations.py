

# Generated at 2022-06-26 02:16:03.920236
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """It must return a unicode object."""
    # The exception constructor takes two arguments: a name, and a message.
    # Unicode is allowed.
    e = IllegalUseOfScopeReplacer(u'foo', u'bar')
    assert isinstance(e.name, unicode)
    assert isinstance(e.msg, unicode)
    # The extra argument is optional.
    u = unicode(e)
    assert isinstance(u, unicode)
    # The exception constructor must not accept a bytestring.
    e = IllegalUseOfScopeReplacer(u'foo', 'bar')
    assert isinstance(e.name, unicode)
    assert isinstance(e.msg, unicode)


# Generated at 2022-06-26 02:16:11.624607
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    l = IllegalUseOfScopeReplacer("name", "msg")
    l._fmt = ''
    l.__dict__['_preformatted_string'] = 'bar'
    assert 'name' in str(l)
    assert 'msg' in str(l)
    assert 'bar' in str(l)
    assert 'IllegalUseOfScopeReplacer' in str(l)


# Generated at 2022-06-26 02:16:17.943260
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    ScopeReplacer._should_proxy = True

    a_name = "a_name"
    a_name_graph = ScopeReplacer(globals(), lambda self,scope,name: \
        None if name == a_name else IllegalUseOfScopeReplacer(
            name, msg="Expected '%s'." % name), a_name)
    assert a_name_graph._scope == globals()

# Generated at 2022-06-26 02:16:21.414041
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    func_code = '''
    def fn():
        pass
    '''
    import_processor = ImportProcessor()
    import_processor.process_source_lines(func_code, globals())
    import_processor.do_import('fn')
    import_processor.do_import('invalid_import')



# Generated at 2022-06-26 02:16:33.350196
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer

    def f():
        pass

    # __call__ calls _resolve
    # _resolve returns the real object for which this is a placeholder
    # It updates _scope,_factory,_name,_real_obj
    # Here _name is passed as name, _factory is passed as factory
    # and _scope is passed as scope

    # Here in _resolve, _real_obj is None hence real_obj is None
    # obj is calculated in _resolve and returned
    # In _resolve if obj is self it raises an exception
    # Here obj is not self
    # The last if stmt is not executed as real_obj is None
    # Hence the remaining statements are executed
    # obj is set to _real_obj and the scope is updated
    # obj is

# Generated at 2022-06-26 02:16:42.379016
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(locals(), ImportProcessor, 'import_processor_0')
    # Test for bzrlib.lazy_import.test_case_0 passed
    # Test for bzrlib.lazy_import.test_case_0 passed
    # Test for bzrlib.lazy_import.test_case_0 passed


# Generated at 2022-06-26 02:16:49.856733
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    s = str_lazy_import
    try:
        import_processor_1 = ImportProcessor()
    except IllegalUseOfScopeReplacer as e:
        e_str = str(e)
        assert(e_str == s)
    except Exception as e:
        assert(False)


# Generated at 2022-06-26 02:16:51.176415
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case_0()


# Generated at 2022-06-26 02:16:54.371948
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import doctest

    from bzrlib.lazy_import import ImportProcessor
    e = ImportProcessor.IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    doctest.testmod(e)



# Generated at 2022-06-26 02:17:04.530490
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from __fake__ import (
        ScopeReplacer,
        IllegalUseOfScopeReplacer,
        )
    import_processor_1 = ImportProcessor()
    import_processor_2 = ImportProcessor()
    import_processor_3 = ImportProcessor()
    import_processor_4 = ImportProcessor()
    import_processor_5 = ImportProcessor()
    import_processor_6 = ImportProcessor()
    import_processor_7 = ImportProcessor()
    import_processor_8 = ImportProcessor()
    import_processor_9 = ImportProcessor()
    import_processor_10 = ImportProcessor()
    import_processor_11 = ImportProcessor()
    import_processor_12 = ImportProcessor()
    import_processor_13 = ImportProcessor()
    import_processor_14 = ImportProcessor()
    import_processor_

# Generated at 2022-06-26 02:17:16.877505
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    import_processor_0.extend_globals(globals())
    import_processor_0.__getattribute__("import_processor_0")
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()



# Generated at 2022-06-26 02:17:24.673649
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_3 = ImportProcessor()
    scope_replacer_2 = ScopeReplacer(globals(), import_processor_3.get_factory("bzrlib"), "bzrlib")

    # Call method scope_replacer_2.__setattr__("fnord", "foo_5")
    scope_replacer_2.__setattr__("fnord", "foo_5")


# Generated at 2022-06-26 02:17:27.739499
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    pass # TODO: implement your test here


# Generated at 2022-06-26 02:17:29.325988
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:17:36.891816
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer(
        'ScopeReplacer', 'ScopeReplacer used incorrectly')
    e_unicode = (u'ScopeReplacer object ScopeReplacer was used incorrectly: '
                 u'ScopeReplacer used incorrectly')
    if e.__unicode__() != e_unicode:
        raise AssertionError('{0!r} should be {1!r}'.format(e.__unicode__(), e_unicode))
test_IllegalUseOfScopeReplacer___unicode__()


# Generated at 2022-06-26 02:17:47.612045
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # IllegalUseOfScopeReplacer.__unicode__(): unicode
    # It's very hard to test something like unicode(). The first 'if' branch
    # could return None, but that would cause an infinite loop. So assume
    # that it returns a valid unicode object.
    e = IllegalUseOfScopeReplacer(None, None)
    u = e.__unicode__()
    u = u + u
    if u is not None:
        # It's a unicode object, but we don't know whether it's valid.
        # We can at least see if it is convertible to a unicode object.
        u += u + u


# Generated at 2022-06-26 02:17:57.737683
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    ex_IllegalUseOfScopeReplacer_0 = IllegalUseOfScopeReplacer(u'import_processor_0', u'can only be used in a with statement')
    try:
        raise ex_IllegalUseOfScopeReplacer_0
    except:
        ex_IllegalUseOfScopeReplacer_1 = sys.exc_info()[1]
        sys.stdout.write(str(ex_IllegalUseOfScopeReplacer_1))
    finally:
        pass


# Generated at 2022-06-26 02:18:10.405157
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import __builtin__

# Generated at 2022-06-26 02:18:15.682349
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    from StringIO import StringIO
    stream = StringIO()
    import_processor_0.print_exception(stream=stream)
    assert stream.getvalue() == 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:18:22.426959
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    assert import_processor_0.modulename == '__main__'

# Generated at 2022-06-26 02:18:38.467019
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import_processor_0 = ImportProcessor()
    import_processor_0.import_module(
        'lazy_import', 'bzrlib.lazy_import')
    import_processor_0.apply_imports(sys.modules[__name__])
    try:
        test_case_0()
    except TypeError:
        # Unhandled exception
        raise


# Generated at 2022-06-26 02:18:40.773171
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(0, 0, 0)
    assert_raises(IllegalUseOfScopeReplacer, scope_replacer_0)


# Generated at 2022-06-26 02:18:49.845144
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    The exception's '_fmt' attribute is used to format the exception using
    the '%' operator, passing the instance dictionary as the parameters.
    """
    # Test a basic exception
    e = IllegalUseOfScopeReplacer(
        'name', 'msg', extra='extra')
    # gettext strings must be passed through gettext() to be translated
    expected_str = r"name: msg: extra"
    assert unicode(e) == expected_str



# Generated at 2022-06-26 02:18:52.408268
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_1 = ImportProcessor()
    import_processor_1.test__setattr__()


# Generated at 2022-06-26 02:18:57.040546
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    x = IllegalUseOfScopeReplacer(None, None)
    x.name = "abc"
    x.msg = "def"
    x.extra = None
    assert x.__unicode__() == u"ScopeReplacer object 'abc' was used incorrectly: def"


# Generated at 2022-06-26 02:19:03.844496
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() is 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'"""
    # Calling object constructor
    obj_0 = IllegalUseOfScopeReplacer('name_0', 'msg_0', 'extra_1')
    # Call method __str__
    result_0 = obj_0.__str__()
    # Verify the result
    assert result_0 == 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:19:13.233838
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_1 = ImportProcessor()
    import_processor_1._name = "module_importer_for_import_processor_1"
    test_IllegalUseOfScopeReplacer___unicode___error = IllegalUseOfScopeReplacer(
        name="module_importer_for_import_processor_1", 
        msg="was used outside of its intended context", 
        extra=None)
    test_IllegalUseOfScopeReplacer__unicode_ = test_IllegalUseOfScopeReplacer___unicode___error.__unicode__()

# Generated at 2022-06-26 02:19:23.247402
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import symbol_versioning

    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import (
        test_case_0,
        scope_replacer_0,
        scope_replacer_1,
        scope_replacer_2,
        scope_replacer_3,
        scope_replacer_4,
        scope_replacer_5,
        )

    # from bzrlib.lazy_import import ScopeReplacer
    # from bzrlib.tests.test_lazy_import import (
    #     test_case_0,
    #     scope_replacer_0,
    #     scope_replacer_1,
    #     scope_replacer_2,
    #     scope_replacer_3,
    #

# Generated at 2022-06-26 02:19:26.974769
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    import unittest

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(
            TestIllegalUseOfScopeReplacer___unicode__))
    runner = unittest.TextTestRunner()
    result = runner.run(suite)
    sys.exit(not result.wasSuccessful())



# Generated at 2022-06-26 02:19:33.826618
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import_processor_0 = ImportProcessor()
    spec_0 = import_processor_0.import_statement_to_spec('import sys')
    module_0 = _real_import(spec_0)
    self_0 = ScopeReplacer(module_0, ScopeReplacer._replacer, 'test')
    test_0 = self_0
    test_0.arg = 'test'
    self = test_0
    self.arg = 'test'


# Generated at 2022-06-26 02:20:19.329163
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib import lazy_import
    exc = lazy_import.IllegalUseOfScopeReplacer(name="", msg="")



# Generated at 2022-06-26 02:20:28.776021
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(),
                                     import_processor_0.__call__,
                                     "import_processor_2")
    import_processor_1 = ImportProcessor()
    scope_replacer_1 = ScopeReplacer(globals(),
                                     import_processor_1.__call__,
                                     "import_processor_3")
    scope_replacer_0._resolve()
    scope_replacer_0._resolve()
    scope_replacer_1._resolve()
    scope_replacer_1._resolve()


# Generated at 2022-06-26 02:20:32.545539
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert(str(e) == "ScopeReplacer object 'name' was used incorrectly:"
           " msg: extra")


# Generated at 2022-06-26 02:20:36.363743
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str(e)
    repr(e)
    e._preformatted_string = u'foo'
    str(e)
    repr(e)


# Generated at 2022-06-26 02:20:45.551757
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object.

    It should always return a 'str' object, even for subclasses that
    return a 'unicode' object from _format().
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    obj = IllegalUseOfScopeReplacer(None, None)
    obj._preformatted_string = 'x'
    assert isinstance(str(obj), str)
    obj._preformatted_string = 'x'
    assert isinstance(str(obj), str)
    obj._preformatted_string = u'x'
    assert isinstance(str(obj), str)
    obj._preformatted_string = object()
    assert isinstance(str(obj), str)
    # get the errno's messages
    import errno
    obj._preformatted

# Generated at 2022-06-26 02:20:46.359307
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()


# Generated at 2022-06-26 02:20:50.140517
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # This test is done in the module test_lazy_import because
    # only the lazy_import function can create the class
    # IllegalUseOfScopeReplacer.
    from bzrlib.tests.test_lazy_import import test_case_0
    test_case_0()



# Generated at 2022-06-26 02:21:01.182684
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    if bzrlib.tests.per_module_doctest:
        test_case = test_case_0()
        import_processor = import_processor_0()
        bzrlib.tests.per_module_doctest.append('bzrlib.lazy_import')
    else:
        # If we're not doing per-module doctests, we're running a naked test
        # suite. Run this test here.
        test_case = test_case_0()
        import_processor = import_processor_0()

# Generated at 2022-06-26 02:21:10.647371
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import ImportProcessor
    import bzrlib.errors as errors
    def factory_0(self, scope, name):
        import bzrlib.errors as errors_0
        return errors_0
    def factory_1(self, scope, name):
        import bzrlib.errors as errors_1
        return errors_1
    ScopeReplacer(locals(), factory_0, 'errors')
    ScopeReplacer(locals(), factory_1, 'errors')
    errors = ScopeReplacer(locals(), factory_0, 'errors_0')
    errors = ScopeReplacer(locals(), factory_1, 'errors_1')
    errors = ScopeReplacer(locals(), factory_0, 'errors')
    errors

# Generated at 2022-06-26 02:21:19.357537
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return unicode object.
    """
    x = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(x)
    x = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(x)
    x = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(x)
    x = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(x)


# Generated at 2022-06-26 02:23:20.695453
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    test_case_0()
    # Calling function test_case_0
    # Calling function test_IllegalUseOfScopeReplacer___str__
    # Calling function import_processor_0
    # Calling function ImportProcessor
    global IllegalUseOfScopeReplacer
    IllegalUseOfScopeReplacer = 1
    # Calling function IllegalUseOfScopeReplacer
    if 1:
        raise IllegalUseOfScopeReplacer("IllegalUseOfScopeReplacer",
            "IllegalUseOfScopeReplacer")
        # Throwing exception raise IllegalUseOfScopeReplacer("IllegalUseOfScopeReplacer",
        #    "IllegalUseOfScopeReplacer")
    # Caught exception IllegalUseOfScopeReplacer("IllegalUseOfScopeReplacer",
    #    "IllegalUseOfScopeReplacer")

# Generated at 2022-06-26 02:23:31.419542
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_1 = ImportProcessor()

    import_processor_1.__class__.__unicode__ = IllegalUseOfScopeReplacer.__unicode__
    name_1 = 'x'
    msg_1 = 'y'
    extra_1 = 'z'
    result_1 = None

# Generated at 2022-06-26 02:23:33.216887
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    obj = ScopeReplacer(import_processor_0, import_processor_0, 't')
    obj.__setattr__('s', 2)



# Generated at 2022-06-26 02:23:43.145761
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(), import_processor_0,
                                     'scope_replacer_0')
    # Access method __call__ of class ScopeReplacer
    try:
        scope_replacer_0()
    except IllegalUseOfScopeReplacer as e:
        assert e.msg == "Object already replaced, did you assign it to another variable?"
        assert e.extra == ""
    else:
        raise AssertionError



# Generated at 2022-06-26 02:23:45.118996
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import doctest
    return doctest.DocTestSuite(
        optionflags=doctest.ELLIPSIS,
        )



# Generated at 2022-06-26 02:23:53.064207
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    a = 1
    import bzrlib.tests
    b = 2
    import bzrlib.tests
    ScopeReplacer.test_case_0()
    def test_case_1():
        bzrlib.tests = 1
    def test_case_2(a=1+1):
        a = bzrlib.tests
    def test_case_3():
        a = bzrlib.tests.__dict__


# Generated at 2022-06-26 02:24:02.247273
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0._scope, import_processor_0._factory, "ImportProcessor")
    scope_replacer_1 = ScopeReplacer(0, import_processor_0._factory, "ImportProcessor")
    scope_replacer_1._factory = scope_replacer_0._resolve
    scope_replacer_1._should_proxy = False
    scope_replacer_2 = ScopeReplacer(0, import_processor_0._factory, "ImportProcessor")
    scope_replacer_2._factory = scope_replacer_0._resolve
    scope_replacer_2._should_proxy = False

# Generated at 2022-06-26 02:24:11.286422
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    bzrlib = ScopeReplacer(
        globals(),
        ImportProcessor,
        'bzrlib',
        )
    osutils = ScopeReplacer(
        globals(),
        ImportProcessor,
        'osutils',
        )
    # Call __getattribute__(x)
    ScopeReplacer.__getattribute__(bzrlib, 'osutils')
    ScopeReplacer.__getattribute__(osutils, 'bzrlib')


# Generated at 2022-06-26 02:24:16.409193
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return 'str' object, not 'unicode' object."""
    # Get an instance, and check that the __str__() method returns a 'str'
    # object.
    inst = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str1 = str(inst)
    type1 = type(str1)
    # Now check that it returns a byte string for a byte string format string.
    inst._fmt = '%(msg)s'
    str2 = str(inst)
    type2 = type(str2)
    assert type1 == type2, \
           "returned types do not match: %s != %s" % (type1, type2)
    assert type1 is str, \
           "returned type is not 'str': %s" % (type1,)


# Generated at 2022-06-26 02:24:23.527615
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Test when a str message is provided
    exception = IllegalUseOfScopeReplacer("exception_name", "message")
    str_exception = str(exception)
    assert str_exception == "IllegalUseOfScopeReplacer('exception_name', 'message', '')"

    # Test when a unicode message is provided
    exception = IllegalUseOfScopeReplacer("exception_name", u"message")
    str_exception = str(exception)
    assert str_exception == "IllegalUseOfScopeReplacer('exception_name', u'message', '')"

