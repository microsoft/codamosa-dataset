

# Generated at 2022-06-26 02:16:17.190820
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import doctest
    if doctest.master is None:
        # Note: There is a bug in Python 2.5 (fixed in 2.6) where doctest fails
        # to clean up the DocTestMaster created by the first call to
        # testmod(), which leads to an error about DocTestParser being
        # garbage collected.
        doctest.master = doctest._FakeDocTestMaster()
    import bzrlib.tests
    from bzrlib.tests import test_lazy_import
    suite = doctest.DocFileSuite('../../../doc/developers/lazy_importing.txt',
                                 optionflags=doctest.ELLIPSIS,
                                 package=test_lazy_import,
                                 setUp=test_case_0)

# Generated at 2022-06-26 02:16:21.615002
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    exception = IllegalUseOfScopeReplacer('exception_name', 'explanation')
    try:
        raise exception
    except IllegalUseOfScopeReplacer as e:
        str_e = str(e)
    assert("exception_name" in str_e)


# Generated at 2022-06-26 02:16:33.379068
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import doctest
    # Let's create a temporary ImportProcessor object
    import_processor_0 = ImportProcessor()
    # Let's create a temporary IllegalUseOfScopeReplacer object
    illegal_use_of_scope_replacer_0 = IllegalUseOfScopeReplacer(
        'name',
        'msg',
        )
    import_processor_0.illegal_use_of_scope_replacer_0 = illegal_use_of_scope_replacer_0

# Generated at 2022-06-26 02:16:45.347366
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    import_processor_0 = ImportProcessor()
    for length_1 in range(0, 1):
        for length_2 in range(0, 1):
            for length_3 in range(0, 1):
                for length_4 in range(0, 1):
                    for length_5 in range(0, 1):
                        error_message_0 = ((('' if (0 < 1) else 'a') + 'b') +
                                           'c')
                        if error_message_0 != ((('' if (0 < 1) else 'a') +
                                                'b') + 'c'):
                            raise AssertionError

# Generated at 2022-06-26 02:16:54.809053
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def factory(self, scope, name):
        return self
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0.local_scope, factory, 'x')
    pass
    try:
        scope_replacer_0.__setattr__('t', scope_replacer_0)
        # Do something with scope_replacer_0.t
        pass
    except IllegalUseOfScopeReplacer as e:
        # expected exception
        pass
    except Exception as e:
        # unexpected exception
        raise


# Generated at 2022-06-26 02:16:57.431474
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    s = IllegalUseOfScopeReplacer(
        u'module',
        u'The name of the variable has already been assigned to',
        u'current value = "invalid.Dummy"')
    try:
        t = str(s)
    except Exception as e:
        raise AssertionError(e)
    except:
        raise AssertionError



# Generated at 2022-06-26 02:17:00.895111
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    import_processor_0.__setattr__('_factory', 'globals')


# Generated at 2022-06-26 02:17:07.662449
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests.lazy_import_processor import ImportProcessor

    import_processor_0 = ImportProcessor()
    import_processor_0.__setattr__('real_name', 'import_processor_0')
    importer = import_processor_0.importer
    import_processor_0.__setattr__('importer', 'import_processor_0')
    scope_replacer_0 = ScopeReplacer({}, None, 'import_processor_0')
    scope_replacer_0.__setattr__('_name', 'import_processor_0')
    scope_replacer_0.__setattr__('_scope', {})
    scope_replacer_0.__setattr__('_factory', None)
    scope_replacer

# Generated at 2022-06-26 02:17:17.112789
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    import_processor_0.declare('test_ScopeReplacer___call__',
        'test_ScopeReplacer___call__')
    test_ScopeReplacer___call___scope = {}
    def test_ScopeReplacer___call___factory(self, scope, name):
        return 'test_ScopeReplacer___call__'
    test_ScopeReplacer___call___name = 'test_ScopeReplacer___call__'
    test_ScopeReplacer___call___0 = ScopeReplacer(
        test_ScopeReplacer___call___scope,
        test_ScopeReplacer___call___factory,
        test_ScopeReplacer___call___name)
    assert test_ScopeReplacer___call___0() == 'test_ScopeReplacer___call__'

#

# Generated at 2022-06-26 02:17:30.040787
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import unittest

    import_processor_0 = ImportProcessor()

    class Test(unittest.TestCase):
        def test(self):
            import_processor_0.process_imports(globals(), '''
            from bzrlib.lazy_import import ScopeReplacer
            def foo(x):
                return x + '!'
            ''')
            import_processor_0.process_imports(globals(), '''
            from bzrlib.lazy_import import ScopeReplacer
            def bar(x):
                return x + '?'
            ''')

# Generated at 2022-06-26 02:17:45.271066
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import builtins
    if not hasattr(builtins, "unicode"):
        return
    s = b"a string"
    u = unicode(s, 'ISO-8859-1')
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e._preformatted_string = u
    assert str(e) == s


import types


# Generated at 2022-06-26 02:17:52.424221
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0, import_processor_0, "name")
    scope_replacer_0.__setattr__("attr", "value")


# Generated at 2022-06-26 02:18:01.259332
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import testtools
    import bzrlib.tests
    import bzrlib.lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    # We create a dict object 'object_dict' to store the value of the current
    # object attributes.
    object_dict = {}
    # We create a test object of class ScopeReplacer, call it 'obj_for_test'.
    obj_for_test = ScopeReplacer(object_dict, test_case_0,
                                 "import_processor_0")
    # We reset the attribute '_should_proxy' of class ScopeReplacer.
    ScopeReplacer._should_proxy = True
    # We create a test object of class ImportProcessor, call it
    # 'import_processor_1'.
    import_processor_1 = bzrlib.l

# Generated at 2022-06-26 02:18:07.101276
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.osutils
    _old_bzrlib_osutils = bzrlib.osutils
    try:
        test_case_0()
    finally:
        bzrlib.osutils = _old_bzrlib_osutils


# Generated at 2022-06-26 02:18:08.349256
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    doctest.testmod()


# Generated at 2022-06-26 02:18:13.527542
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    import_processor_0 = ImportProcessor()

# Generated at 2022-06-26 02:18:26.113513
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import unittest

    class TestableScopeReplacer(ScopeReplacer):
        __slots__ = ('_scope', '_factory', '_name', '_real_obj')
        def __init__(self, scope, factory, name):
            super(TestableScopeReplacer, self).__init__(scope=scope,
                factory=factory, name=name)

    class MyTest(unittest.TestCase):
        def test_ScopeReplacer__setattr(self):
            def factory(self, scope, name):
                tmp_obj = object()
                return tmp_obj

            scope = dict()
            tmp_obj = TestableScopeReplacer(scope=scope, factory=factory,
                name='tmp_obj')
            tmp_obj.attr = 'value'

# Generated at 2022-06-26 02:18:33.496754
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    obj = IllegalUseOfScopeReplacer(u'name', u'msg', u'extra')
    s = obj.__str__()
    assert isinstance(s, str)
    try:
        s.decode('ascii')
    except (UnicodeEncodeError, UnicodeDecodeError):
        assert False, "%r can't be converted to ascii" % (s,)
    except AttributeError:
        # s is not unicode
        pass


# Generated at 2022-06-26 02:18:37.178700
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    x = ScopeReplacer("test_scope_0", "test_factory_0", "test_name_0")
    x.__setattr__("test_attr_1", "test_value_1")
    return None


# Generated at 2022-06-26 02:18:40.617348
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer

    _factory = lambda: None
    _scope = {}
    name = "name"
    obj = ScopeReplacer(_scope, _factory, name)
    obj.__setattr__("a", 1)
    obj.__setattr__("a", 2)



# Generated at 2022-06-26 02:18:51.014727
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    e = IllegalUseOfScopeReplacer('name', 'msg')
    import_processor_0.IllegalUseOfScopeReplacer___unicode__(e)


# Generated at 2022-06-26 02:18:56.001823
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a 'str' instance"""
    case = IllegalUseOfScopeReplacer('name', 'message')
    s = case.__str__()
    assert isinstance(s, str)

# TODO: Unit test for method _format of class IllegalUseOfScopeReplacer

# Generated at 2022-06-26 02:19:03.954379
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()

    import_processor_0._raise_exception = True

    try:
        import_processor_0._set_attr('hello', '', 'bzrlib.*')
    except IllegalUseOfScopeReplacer as e:
        e_msg = (
                "ScopeReplacer object 'hello' was used incorrectly:"
                " Object already replaced, did you assign it to another "
                "variable?")
        assert e._format() == e_msg, \
            'assertion failed: %s != %s' % (e._format(), e_msg)
    else:
        raise AssertionError('No exception raised')



# Generated at 2022-06-26 02:19:06.469717
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    x = ScopeReplacer(globals(), lambda me, scope, name: [], "x")

    # test_case_0 is the expected case.
    test_case_0()


# Generated at 2022-06-26 02:19:14.907123
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib
    import bzrlib.lazy_import
    _test_scope = {'bzrlib': bzrlib}
    import_processor_0 = ImportProcessor()
    ScopeReplacer_0 = ScopeReplacer(_test_scope,
        import_processor_0.replace, 'bzrlib')
    try:
        ScopeReplacer_0.__getattribute__('lazy_import')
        raise AssertionError
    except AttributeError:
        pass


# Generated at 2022-06-26 02:19:24.270887
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    import_processor_0._read_file('ScopeReplacer___setattr__.py')
    globals_0 = {}
    locals_0 = {}

# Generated at 2022-06-26 02:19:29.620145
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    if sys.version_info[:2] < (2, 6):
        from unittest import TestCase
    else:
        from unittest2 import TestCase
    from bzrlib.lazy_import import (
        IllegalUseOfScopeReplacer,
        )
    class Test(TestCase):

        def test__1(self):
            e = IllegalUseOfScopeReplacer('test', 'a message')
            self.assertEqual('test', e.name)
            self.assertEqual('a message', e.msg)
            self.assertEqual('', e.extra)
            self.assertEqual("IllegalUseOfScopeReplacer(test)", repr(e))
            self.assertEqual("IllegalUseOfScopeReplacer(test)",
                e.__str__())
            # In Python

# Generated at 2022-06-26 02:19:35.091128
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    # Operation with illegal value raises TypeError
    # Check TypeError is raised when the first argument is of the wrong type
    # Assert TypeError raised
    with testtools.ExpectedException(IllegalUseOfScopeReplacer,
            "did you assign it to another variable?"):
        test_case_0()


# Generated at 2022-06-26 02:19:40.661045
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    my_e = IllegalUseOfScopeReplacer('ImportProcessor', 'hello')
    expected_result = u'hello'
    result = my_e.__unicode__()
    assert result == expected_result, (result, expected_result)


# Generated at 2022-06-26 02:19:43.007485
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(e.__unicode__(), unicode)


# Generated at 2022-06-26 02:19:52.052481
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Run test
    test_case_0()



# Generated at 2022-06-26 02:19:55.270878
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_obj = ScopeReplacer(None, None, None)
    attr = "attr"
    value = "value"
    try:
        test_obj.__setattr__(attr, value)
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("'__setattr__' does not work as expected")


# Generated at 2022-06-26 02:20:02.581537
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Create an instance of ScopeReplacer
    obj = ScopeReplacer('scope_0', lambda self, scope, name: self, 'name_0')
    obj._resolve = lambda: None
    obj._real_obj = None
    # Call method __setattr__ of ScopeReplacer
    ScopeReplacer._should_proxy = True
    obj.__setattr__('attr_0', 'value_0')
    # No exceptions should be raised


# Generated at 2022-06-26 02:20:09.658730
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    import_processor_0.imports = {'one':import_processor_0._ImportInfo(False, False, None)}
    import_processor_0.imports['one'].real_obj = str
    import_processor_0.create_scope({'one':import_processor_0._ImportInfo(True, False, None)})
    import_processor_0.scope['one']._resolve()
    import_processor_0.scope.get('one')._resolve()


# Generated at 2022-06-26 02:20:16.308821
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Copy the attribute set by __init__ for ScopeReplacer
    obj = ScopeReplacer(globals(), lambda x, y, z: y[z], 'import_processor_0')
    assert type(obj) == ScopeReplacer
    obj.attr_0 = 42
    # Check that the attribute has been set by __setattr__ and not by __init__
    assert obj.__dict__.get('attr_0', None) == 42
    # Check that the attribute has been set correctly
    assert obj.attr_0 == 42


# Generated at 2022-06-26 02:20:19.706825
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    for x in [u'hello', u'€', u'A', u'\xe4\xe4\xe4\xe4', u'\uD800\uDC00']:
        raise IllegalUseOfScopeReplacer(x, u'Invalid use of ScopeReplacer')


# Generated at 2022-06-26 02:20:25.239441
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    scope = {}
    scope['test'] = scope
    ScopeReplacer_0 = ScopeReplacer(scope, import_processor_0.__call__, 'test')
    ScopeReplacer_0(scope, import_processor_0.__call__, 'test')


# Generated at 2022-06-26 02:20:33.259196
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(), lazy_module, 'osutils')
    try:
        scope_replacer_0.__call__()
        raise AssertionError
    except TypeError:
        pass
    try:
        scope_replacer_0.__call__(None)
        raise AssertionError
    except TypeError:
        pass
    try:
        scope_replacer_0.__call__(None, None)
        raise AssertionError
    except TypeError:
        pass


# Generated at 2022-06-26 02:20:43.407336
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import testtools
    import testtools.matchers as matchers

    from bzrlib.trace import mutter

    # set mutter to be verbose so that the test failure will be seen.
    mutter.set_verbosity_level(4)
    # create a scope replacer and store it in the developer's scope.
    sr = ScopeReplacer(locals(), lambda self, scope, name: None, 'sr')
    sr._should_proxy = False
    # Test that we can NOT set an attribute to the scope replacer.
    exception_raised = False
    try:
        sr.foo = 'bar'
    except IllegalUseOfScopeReplacer as e:
        exception_raised = True
        testtools.TestCase().assertThat(e.msg,
                                        matchers.StartsWith('Object already'))


# Generated at 2022-06-26 02:20:49.343361
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import bzrlib.tests
    from bzrlib.tests import TestCase
    try:
        import_processor_0 = ImportProcessor()
    except IllegalUseOfScopeReplacer as e:
        bzrlib.tests.TestCase.assertEqual(IllegalUseOfScopeReplacer, type(e))
        bzrlib.tests.TestCase.assertEqual(
            'ScopeReplacer object \'the name\' was used incorrectly: '
            'the message: the extra',
            str(e))
    else:
        TestCase.fail('IllegalUseOfScopeReplacer must be raised')


# Generated at 2022-06-26 02:21:04.415291
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()
    name = "lazy_import"
    msg = "The import processor has already been used"
    extra = "foo"
    temp = IllegalUseOfScopeReplacer(name, msg, extra)
    result = str(temp)
    assert result is not None
    # Now check for coverage
    temp = IllegalUseOfScopeReplacer(name, msg)
    result = str(temp)
    assert result is not None


# Generated at 2022-06-26 02:21:06.936994
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import os
    import __builtin__

    test_case_0()


# Generated at 2022-06-26 02:21:09.375639
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__str__ should return a string object"""
    x = IllegalUseOfScopeReplacer(123, 'oops')
    assert isinstance(x.__unicode__(), unicode)


# Generated at 2022-06-26 02:21:10.702917
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.test_case_0()


# Generated at 2022-06-26 02:21:17.749185
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import doctest
    import bzrlib.lazy_import
    return doctest.DocTestSuite(bzrlib.lazy_import)

# TODO: All the traces from test_case_0 are not necessary, only
# call_site.  But there is no way to get rid of them.
# TODO: test_0 will only work with python 2.7

# Generated at 2022-06-26 02:21:24.226401
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # test set attr of a ScopeReplacer.
    import_processor_0 = ImportProcessor()
    global_scope_0 = globals()
    scope_replacer_0 = ScopeReplacer(global_scope_0, import_processor_0.import_func, 'scope_replacer_0')
    scope_replacer_0.__setattr__('_resolve', scope_replacer_0._resolve) #pass


# Generated at 2022-06-26 02:21:32.150304
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    import_processor_0 = ImportProcessor()
    s = "lala"
    t = "blah"
    e = IllegalUseOfScopeReplacer(s, t)
    import doctest
    doctest.testmod(name='bzrlib.lazy_import', verbose=False)
    # TODO: do we want to assert anything here?


# Generated at 2022-06-26 02:21:39.438225
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.errors as errors
    from bzrlib.tests import TestCase
    import_processor_4 = ImportProcessor()
    class TestCase_0(TestCase):
        def _test(self, obj):
            self.assertEqual('TestCase_0', obj.__class__.__name__)
        def test___getattribute__(self):
            from bzrlib.lazy_import import ScopeReplacer
            self._test(ScopeReplacer)
    test_case_0 = TestCase_0()
    test_case_0.test___getattribute__()


# Generated at 2022-06-26 02:21:40.778176
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    doctest.testmod(verbose=1)



# XXX: this belongs in breezy, not bzrlib.

# Generated at 2022-06-26 02:21:50.095353
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib
    import_processor_0 = ImportProcessor()
    import sys
    expected_result_0 = None
    old_displayhook_0 = sys.displayhook
    sys.displayhook = lambda s: expected_result_0
    sys.displayhook = old_displayhook_0
    try:
        import_processor_0._process_import_statement((
            ('bzrlib', 'errors', None, None),
        ))
        f = bzrlib.errors
        f()
        # If the exception is not thrown the test fails
        assert False
    except Exception as e:
        assert "test_for_regression" in str(e)
    finally:
        import_processor_0._process_import_statement((
            ('bzrlib', 'errors', None, None),
        ))




# Generated at 2022-06-26 02:22:01.072691
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(scope=None, factory=None, name=None)
    try:
        obj._resolve()
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:22:06.009276
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(attr, value) always raises IllegalUseOfScopeReplacer"""
    f = ScopeReplacer
    s = f(None, None, None)
    e = None
    try:
        s.__setattr__('e', 'e')
    except Exception as e:
        pass
    assert isinstance(e, IllegalUseOfScopeReplacer)


# Generated at 2022-06-26 02:22:12.711375
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    fake_scope_0 = dict()
    def calltest_0(test_arg_0): test_arg_0.test_attr_0 = 0
    scope_replacer_0 = ScopeReplacer(fake_scope_0, calltest_0, 'test_var_0')
    scope_replacer_0()
    try:
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-26 02:22:18.898597
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope = {}
    name = 'name'
    import_processor_0.lazy_import(scope, 'name = ImportProcessor()')
    import_processor_1 = scope[name]
    attr = '_resolve'
    value = 'value'
    import_processor_1._resolve = 'value'


# Generated at 2022-06-26 02:22:20.333848
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()


# Generated at 2022-06-26 02:22:26.018711
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    import doctest
    doctest.Ellipsis = 'FAILURE IN __str__'

    print_test = doctest.DocTestParser().get_doctest(
        IllegalUseOfScopeReplacer.__str__,
        globals(),
        'IllegalUseOfScopeReplacer.__str__',
        None, None)
    runner = doctest.DocTestRunner()
    runner.run(print_test, clear_globs=False)



# Generated at 2022-06-26 02:22:31.339890
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    scope, name, factory = {}, 'xyz', lambda self, scope, name: scope
    obj = ScopeReplacer(scope, factory, name)
    scope[name] = 'xyz'
    obj._resolve()
    scope[name]()


# Generated at 2022-06-26 02:22:42.090695
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # This test is not valid - in this case, 'bzrlib' is already in scope,
    # so a ScopeReplacer will not be created.
    # If a __getattribute__ test is needed, it should look something like:
    #    from bzrlib import (
    #        errors,
    #        osutils,
    #        )
    #    from bzrlib.errors import BzrError
    #    import bzrlib
    #    scope = locals()
    #    lazy_import(scope, 'from bzrlib import selftest')
    #    try:
    #        selftest
    #    except IllegalUseOfScopeReplacer:
    #        pass
    #    else:
    #        raise AssertionError("expected IllegalUseOfScopeReplacer")

    pass




# Generated at 2022-06-26 02:22:54.103765
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    global import_processor_1
    import_processor_1 = ImportProcessor()
    global BadImportProxy
    class BadImportProxy(object):
        __module__ = 'bzrlib.tests.lazy_import_test'
        _factory = staticmethod(static_func)
        _name = 'import_processor_0'
        _real_obj = None
        _scope = globals()
        _should_proxy = None
        def _resolve(self):
            return import_processor_1
        def __init__(self, scope, factory, name):
            pass
        def __call__(self, *args, **kwargs):
            pass
        def __getattribute__(self, attr):
            return 1

# Generated at 2022-06-26 02:22:58.224143
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    exc = IllegalUseOfScopeReplacer(1, 2, 3)
    s = str(exc)
    assert isinstance(s, str), "str(exc) is not a str but a %r" % (type(s),)
    assert s == 'Unprintable exception IllegalUseOfScopeReplacer: dict={1: 2, 3: None, "name": 1}, fmt=None, error=None'
    exc = IllegalUseOfScopeReplacer(1, 2, 'extra')
    s = str(exc)
    assert isinstance(s, str), "str(exc) is not a str but a %r" % (type(s),)

# Generated at 2022-06-26 02:23:15.099979
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    var_0 = lazy_import(globals(), '''
    import pkg_resources
    ''')

    def factory(self, scope, name):
        return pkg_resources
    var_1 = ScopeReplacer(globals(), factory, "pkg_resources")

    var_2 = pkg_resources
    try:
        var_1.version = None
    except IllegalUseOfScopeReplacer as e:
        var_3 = e


# Generated at 2022-06-26 02:23:16.449272
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import scope_replacer
    scope_replacer.test_case_0()



# Generated at 2022-06-26 02:23:19.173807
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    test_case_0()


# Generated at 2022-06-26 02:23:30.211427
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib import lazy_import
    # test for negative condition 1:
    # IllegalUseOfScopeReplacer object var_0 ref to illegal object
    var_0 = disallow_proxying()
    var_1 = (var_0,)
    var_2 = IllegalUseOfScopeReplacer('var_0', 'ref to illegal object', var_1)
    var_3 = 'Unprintable exception IllegalUseOfScopeReplacer: dict={\'extra\': \
(var_0,), \'name\': \'var_0\', \'msg\': \'ref to illegal object\'}, fmt=None, \
error=None'
    # test for condition 1:
    # IllegalUseOfScopeReplacer object var_0 ref to illegal object
    assert var_2.__str__() == var_3


# Generated at 2022-06-26 02:23:34.540626
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scalar_0 = 0
    scalar_1 = 7
    scalar_2 = 7
    scalar_3 = 7
    object_0 = ScopeReplacer(None, None, None)
    object_0.attr_0 = scalar_2
    object_0.attr_0 = scalar_0
    assert(scalar_1 == scalar_3)


# Generated at 2022-06-26 02:23:39.183378
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('foo', 'bar')
    # __str__() must return str or unicode
    var_1 = isinstance(var_0, basestring)
    assert (var_1 == False)


# Generated at 2022-06-26 02:23:51.669378
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():

    from bzrlib.lazy_import import (
        ScopeReplacer,
        IllegalUseOfScopeReplacer,
        )

    class MyReplacer(ScopeReplacer):

        __slots__ = ('_attr',)

        def __init__(self, scope, factory, name):
            ScopeReplacer.__init__(self, scope, factory, name)

        def _resolve(self):
            return self

        def __getattribute__(self, attr):
            return ScopeReplacer.__getattribute__(self, attr)

    scope = {}

    # ensure that IllegalUseOfScopeReplacer is raised when
    # ScopeReplacer._should_proxy is False
    _should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-26 02:23:53.162961
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    unicode(e)  # Should not fail.


# Generated at 2022-06-26 02:23:59.285583
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    case = IllegalUseOfScopeReplacer('name_0', 'msg_1', 'extra_2')
    u = case.__unicode__()
    expected = "ScopeReplacer object 'name_0' was used incorrectly: msg_1: extra_2"
    eq = (u == expected)
    if not eq:
        raise AssertionError("Expected:\n%s\nbut was:\n%s" % (expected, u))



# Generated at 2022-06-26 02:24:05.031505
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer

    # Call method __setattr__ of class ScopeReplacer
    # with arguments:
    #     attr='_should_proxy'
    #     value=False
    # to test:
    #     Setting _should_proxy to false prevents access to members
    #     of other variables.
    #     Assigning self to another variable is allowed though.

    # setup
    class X(ScopeReplacer):
        pass
    x = X({}, lambda self, scope, name: name, 'x')

    # test
    x._should_proxy = False
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError
    # check that self is still ok
    x.asdf = 1



# Generated at 2022-06-26 02:24:14.340376
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer()
    var_0.__str__()


# Generated at 2022-06-26 02:24:23.702534
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import imp
    import sys

    # Create a new ScopeReplacer object
    factory = imp.find_module("test_lazy_import")[2]["test_case_0"]
    name = "test"
    test_obj = ScopeReplacer({}, factory, name)

    # Call object with incorrect argument types, verify TypeError raised
    args = ()
    kwargs = {}
    try:
        test_obj.__call__(*args, **kwargs)
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError not raised")

    # Call object with correct argument types
    args = ()
    kwargs = {}
    test_obj.__call__(*args, **kwargs)



# Generated at 2022-06-26 02:24:36.521935
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class Test(TestCase):
        _should_proxy = False

        def setUp(self):
            super(Test, self).setUp()
            self.scope = {}
            self.sr = ScopeReplacer(self.scope,
                                    lambda sr, scope, name: object(),
                                    'var_0')

        def test_set_attribute(self):
            self.sr.var_1 = 1
            self.assertEqual(1, self.sr.var_1)

        def test_set_attribute__proxy(self):
            self.assertRaises(IllegalUseOfScopeReplacer,
                              test_case_0)

    Test('test_set_attribute').run()

# Generated at 2022-06-26 02:24:39.695798
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    def _factory(obj, scope, name):
        return None
    var_1 = bzrlib.lazy_import.ScopeReplacer(globals(), _factory, 'var_0')
    var_2 = var_1.__call__()
    assert var_2 is None, var_2


# Generated at 2022-06-26 02:24:44.391656
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # check __unicode__ returns a unicode object
    assert isinstance(e.__unicode__(), unicode)
    # check __unicode__ is the 'long' form of the exception, not the short form
    assert e.__unicode__().startswith('ScopeReplacer object \'name\'')


# Generated at 2022-06-26 02:24:46.096340
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__()"""
    # dummy code to quiet pyflakes
    var_0 = disallow_proxying()


# Generated at 2022-06-26 02:24:49.076759
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    got = str(e)
    assert [got] == [u'IllegalUseOfScopeReplacer object foo was used incorrectly: bar']


# Generated at 2022-06-26 02:24:52.926581
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # Assert that the result of __unicode__ is expected.
    assert e.__unicode__() == 'Lazy Import: name: msg', e.__unicode__()


# Generated at 2022-06-26 02:24:55.455558
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer(1, '\xef')
    assert_raises(UnicodeError, e.__unicode__)


# Generated at 2022-06-26 02:24:59.952364
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    x = bzrlib.lazy_import.ScopeReplacer({}, None, None)
    x.__setattr__(None, None)


# Generated at 2022-06-26 02:25:19.232451
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-26 02:25:21.201316
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__()"""
    case_0 = test_case_0()



# Generated at 2022-06-26 02:25:31.264013
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib.tests
    scope = {}  # scope of the test case
    object_factory = None  # object factory we're testing
    name = None  # name of the variable we're testing
    object_factory = lambda object_proxy, object_scope, object_name: object_proxy
    name = 'var_0'
    object_proxy = ScopeReplacer(scope, object_factory, name)
    # After the call to __init__, object_proxy should be in scope
    assert scope[name] is object_proxy
    # setattr should call _factory with the scope and name
    assert object_proxy._factory == object_factory
    assert object_proxy._scope == scope
    assert object_proxy._name == name
    # self._