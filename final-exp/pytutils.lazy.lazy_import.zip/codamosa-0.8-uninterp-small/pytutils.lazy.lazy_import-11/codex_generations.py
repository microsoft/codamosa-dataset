

# Generated at 2022-06-26 02:16:12.028390
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    import_processor_0.scope_replacer_0 = ScopeReplacer(globals(),
                                                        import_processor_0.make_import_processor_0,
                                                        'import_processor_0.import_processor_0')
    import_processor_0.scope_replacer_0()


# Generated at 2022-06-26 02:16:16.862363
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    ScopeReplacer_instance_0 = ScopeReplacer(globals(), import_processor_0, 'lazy_import')
    assert_equal(ScopeReplacer_instance_0.__call__(globals(), 'from bzrlib import ( errors, osutils, branch, ) import bzrlib.branch'), None)


# Generated at 2022-06-26 02:16:22.202475
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    # __str__ must return a str.
    # Test method __str__ of class IllegalUseOfScopeReplacer
    assert_raises(IllegalUseOfScopeReplacer,
                  lambda x: ImportProcessor.process_import_statements(
                      import_processor_0, x),
                  ["import_processor_0 = ImportProcessor()"],
                  "__str__ must return a str.",
                  )


# Generated at 2022-06-26 02:16:29.618398
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        ScopeReplacer._should_proxy = False
        import_processor_0 = ImportProcessor()
        a = ScopeReplacer(locals(), import_processor_0._import_and_replace, 'a')
        obj_0 = a.obj
    finally:
        ScopeReplacer._should_proxy = True
    pass


# Generated at 2022-06-26 02:16:39.508733
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0._scope, import_processor_0.import_, 'ScopeReplacer')
    scope_replacer_0.__setattr__('attr', 'value')
    scope_replacer_0.__setattr__('attr', 'value')
    scope_replacer_0.__setattr__('attr', 'value')


# Generated at 2022-06-26 02:16:43.048454
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    if sys.version_info[0] > 2:
        return
    import bzrlib.lazy_import
    bzrlib.lazy_import.IllegalUseOfScopeReplacer('foo', 'bar')


# Generated at 2022-06-26 02:16:55.938580
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # We want to test the case where _resolve() returns something different
    # than 'self'.

    # We need to emulate what is done in lazy_import to have a correct
    # initialization of ScopeReplacer objects.
    class TestCase:
        def __init__(self, test_obj):
            # we use a TestCase object to keep a reference of the object
            # that needs to be returned by the _resolve method.
            self.test_obj = test_obj

        def _resolve(self):
            return self.test_obj

    test_string = 'a string'
    # This is a test object that will be inserted in the ScopeReplacer
    # object by the _resolve() method.
    test_obj = TestCase(test_string)
    # The ScopeReplacer which is being tested.

# Generated at 2022-06-26 02:17:06.338652
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # set_x sets _should_proxy to False to track calls to x, then calls
    # _set_x to do the actual setting.
    def set_x(self, x, scope, name):
        ScopeReplacer._should_proxy = False
        self._set_x(x, scope, name)
    # ScopeReplacer._set_x is actually a method of self, not of ScopeReplacer,
    # and an instance of _set_x is created.
    ScopeReplacer._set_x = ScopeReplacer._set_x
    # ScopeReplacer._factory is set to set_x, which will be reset back to
    # ScopeReplacer._set_x in the end.
    ScopeReplacer._factory = set_x

    u = ScopeReplacer(globals(), ScopeReplacer._factory, 'u')
   

# Generated at 2022-06-26 02:17:08.895427
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()

# vim: set filetype=python ts=4 sw=4 et si

# Generated at 2022-06-26 02:17:17.453242
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    import_processor_0 = ImportProcessor()
    scope_path_1 = (u'bzrlib', u'lazy_import')
    scope_replacer_2 = ScopeReplacer(import_processor_0._scope, (lambda self, scope, name: scope[name]), scope_path_1)
    scope_path_3 = (u'bzrlib', u'lazy_import')
    scope_replacer_4 = scope_replacer_2._factory(scope_replacer_2, import_processor_0._scope, scope_path_3)
    scope_path_5 = (u'bzrlib', u'lazy_import')

# Generated at 2022-06-26 02:17:27.366720
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    c = IllegalUseOfScopeReplacer("name", "msg")
    result = c.__unicode__()
    assert(isinstance(result, unicode))


# Generated at 2022-06-26 02:17:38.559444
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from StringIO import StringIO
    from cStringIO import StringIO as cStringIO
    try:
        from StringIO import StringIO as _StringIO
    except ImportError:
        _StringIO = None
    try:
        from cStringIO import StringIO as _cStringIO
    except ImportError:
        _cStringIO = None

    def _test_StringIO(sio, __str__):
        sio = dict_with_copied_items(sio)
        sio['__str__'] = __str__
        return sio

    # Test with normal objects
    yield _test_StringIO, 'abcd', lambda: 'abcd'
    yield _test_StringIO, u'abcd', lambda: u'abcd'

    # Test with broken __str__
    yield _test_StringIO, None,

# Generated at 2022-06-26 02:17:45.528788
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    import_processor_0 = ImportProcessor()
    # Test normal operation
    try:
        raise IllegalUseOfScopeReplacer("name", "msg")
    except IllegalUseOfScopeReplacer as exc:
        assert unicode(exc) == "name was used incorrectly: msg"



# Generated at 2022-06-26 02:17:54.605523
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    e = IllegalUseOfScopeReplacer(
            'foo',
            'bar',
            'baz')
    s = str(e)
    st = ('ScopeReplacer object \'foo\' was used incorrectly: bar: baz')
    assert s == st, '%r != %r' % (s, st)



# Generated at 2022-06-26 02:18:07.812676
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    bzrlib.lazy_import.ScopeReplacer.__setattr__ = (
        lambda *args,**kwargs: object.__setattr__(*args,**kwargs))

# Generated at 2022-06-26 02:18:09.085174
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Nothing to do. It's a stub.
    pass


# Generated at 2022-06-26 02:18:22.174292
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from io import BytesIO
    from io import TextIOWrapper
    from io import UnsupportedOperation

    import bzrlib.lazy_import
    import bzrlib.lazy_import

    arg0 = bzrlib.lazy_import.ImportProcessor()
    arg1 = ''
    arg2 = bzrlib.lazy_import.ImportProcessor()
    arg3 = bzrlib.lazy_import._ImportState()
    arg4 = BytesIO(b'\x80\x81\x82')
    arg5 = BytesIO(b'\x80\x81\x82')
    arg6 = BytesIO(b'\x80\x81\x82')

    # __call__ of ScopeReplacer is not callable

# Generated at 2022-06-26 02:18:23.320495
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    pass # TODO write me


# Generated at 2022-06-26 02:18:34.705411
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import testtools
    e = IllegalUseOfScopeReplacer(name='name', msg='Illegal msg')
    assert (unicode(e) ==
            u'Unprintable exception IllegalUseOfScopeReplacer: '
            'dict={\'msg\': \'Illegal msg\', \'name\': \'name\', '
            '\'extra\': \'\'}, fmt=None, error=None')
    exc = testtools.ContentMismatchError(u'foo', u'bar')
    e = IllegalUseOfScopeReplacer(name='name', msg='Illegal msg', extra=exc)

# Generated at 2022-06-26 02:18:49.298189
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a string"""
    # Calling __str__ should return a str, not a unicode, so the default
    # encoding is used.
    import_processor_0 = ImportProcessor()
    try:
        raise import_processor_0.ScopeReplacer('import_processor_0',
                                               'test-message')
    except Exception as e:
        s = e.__str__()
        if not isinstance(s, str):
            raise AssertionError(
                's should be an str, not %r' % type(s))


# Generated at 2022-06-26 02:19:04.407996
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer()
    # Invalid operation on this object.
    if var_0._format.__doc__ == None:
        var_0 = var_0._format()
    # __unicode__() should always return a 'unicode' object
    # never a 'str' object.
    else:
        var_0 = var_0.__unicode__()
    return var_0


# Generated at 2022-06-26 02:19:05.994759
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # test first line of __unicode__
    # test second line of __unicode__
    return None



# Generated at 2022-06-26 02:19:07.631394
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    s = IllegalUseOfScopeReplacer('foo', 'bar')
    s.__str__()


# Generated at 2022-06-26 02:19:19.759418
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('a', 'b')
    var_1 = var_0._format()
    if (var_1 != 'Unprintable exception IllegalUseOfScopeReplacer: dict={\'name\': \'a\', \'msg\': \'b\', \'extra\': \'\'}, fmt=None, error=None'):
        raise AssertionError
    var_0 = IllegalUseOfScopeReplacer('a', 'b')
    var_1 = var_0._format()
    if (var_1 != 'Unprintable exception IllegalUseOfScopeReplacer: dict={\'name\': \'a\', \'msg\': \'b\', \'extra\': \'\'}, fmt=None, error=None'):
        raise AssertionError

# Generated at 2022-06-26 02:19:24.989568
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('var_0', 'msg')
    # Test for assumption about the formatting of subclass __init__
    assert e.name == 'var_0'
    assert e.msg == 'msg'
    assert str(e).startswith('IllegalUseOfScopeReplacer')
    assert str(e).endswith("'msg'}")


# Generated at 2022-06-26 02:19:29.424430
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__()"""
    global var_0
    if 'var_0' in globals() and var_0 is not None:
        pass # Jython bug in handling closures
    var_0 = None
    try:
        test_case_0()
    except AttributeError:
        pass
    return #__inline

import sys


# Generated at 2022-06-26 02:19:30.752573
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    pass


# Generated at 2022-06-26 02:19:34.730290
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    replacer = ScopeReplacer(dict(), lambda x,y,z: None, 'var_0')
    replacer([], {})
    replacer(1)
    replacer(1, 2)
    replacer(1, 2, 3)


# Generated at 2022-06-26 02:19:40.315670
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = lazy_import(globals(), 'bzrlib.help_topics', 'help_topics')

    cases = [
        test_case_0,
        ]
    for case in cases:
        try:
            case()
        except Exception:
            import traceback
            traceback.print_exc()


# Generated at 2022-06-26 02:19:44.555779
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method __unicode__ of class IllegalUseOfScopeReplacer"""
    # XXX: add some test cases for method IllegalUseOfScopeReplacer.__unicode__
    raise NotImplementedError(
        "Test cases for method IllegalUseOfScopeReplacer.__unicode__ are missing")


# Generated at 2022-06-26 02:19:56.143937
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test case 0: __call__
    var_0 = test_case_0()




# Generated at 2022-06-26 02:20:02.680445
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # Test for normal behaviour:
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly: msg: extra"
    # Test for special behaviour:
    e._preformatted_string = "Foo"
    assert str(e) == "Foo"


# Generated at 2022-06-26 02:20:04.844526
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    IllegalUseOfScopeReplacer(u'var_0', u'var_1', u'var_2')


# Generated at 2022-06-26 02:20:05.792409
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # TODO


# Generated at 2022-06-26 02:20:12.703519
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    code_obj_0 = compile('var_0.disallow_proxying()', '<string>', 'exec')
    test_env_0 = {'disallow_proxying': disallow_proxying, '__builtins__': __builtins__, '__file__': __file__, 'var_0': var_0, '__name__': __name__, '__doc__': __doc__}

# Generated at 2022-06-26 02:20:16.051726
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test cases for ScopeReplacer.

    test_cases = [
        # ScopeReplacer.__setattr__(self, attr, value)
    ]
    for test_case in test_cases:
        yield test_case_0, test_case


# Generated at 2022-06-26 02:20:17.714239
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test for ScopeReplacer.__setattr__"""
    # Test for:
    #  ScopeReplacer.__setattr__(self, attr, value)
    pass


# Generated at 2022-06-26 02:20:18.858088
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    assert test_case_0() is None



# Generated at 2022-06-26 02:20:21.162828
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    var_1 = unicode(var_0)


# Generated at 2022-06-26 02:20:32.386825
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__()

    ScopeReplacer tries to emulate the real object, so calling a function
    will just forward it to the real one.
    """
    def foo(self, scope, name):
        """the function to call"""
        return 42
    #
    # Create a replacement for 'foo_obj' in the global scope.
    #
    foo_obj = ScopeReplacer(
        globals(),
        foo,
        "foo_obj")
    #
    # Now call it, it should try to instantiate a real object and
    # call it.
    #
    result = foo_obj()
    #
    # Check that the real object was put into the global scope.
    #
    assert globals()["foo_obj"] != foo_obj
    assert result == 42


# Generated at 2022-06-26 02:20:43.404042
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = ScopeReplacer(_scope, _factory, _name)
    var_1 = var_0.__getattribute__(attr)


# Generated at 2022-06-26 02:20:45.890036
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    # Should be enough to make sure that we do not crash, or that we
    # return something other than a unicode object.
    var_1 = unicode(var_0)


# Generated at 2022-06-26 02:20:54.114331
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    factory = lambda self, scope, name: lambda: 1
    name = 'name'
    scope = {'name': None}
    aScopeReplacer = ScopeReplacer(scope, factory, name)
    # Call aScopeReplacer.__call__
    aScopeReplacer()
    if scope['name'] != None:
        raise AssertionError
    if not isinstance(aScopeReplacer, ScopeReplacer):
        raise AssertionError
    if aScopeReplacer._should_proxy:
        raise AssertionError
    var_0 = disallow_proxying()
    if aScopeReplacer._should_proxy:
        raise AssertionError


# Generated at 2022-06-26 02:20:55.842905
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(u'', u'')


# Generated at 2022-06-26 02:21:06.003019
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    __expected_exception = None
    __expected_result = None
    __test_name = 'test case 0'
    __test_description = '''test case 0'''
    __test_timeout = None
    try:
        var_0 = test_case_0()
    except Exception as e:
        __expected_exception = e
    __expected_result = None
    if __expected_exception is not None:
        if type(__expected_exception) == type(__expected_result):
            raise __expected_exception
        else:
            raise Exception("Expected exception type to be %s, but was %s"
                            % (type(__expected_result), type(__expected_result)))


# Generated at 2022-06-26 02:21:08.481537
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        var_0 = disallow_proxying()
        # test if exception was raised
        raise Exception("test failed")
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:21:14.485762
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    import sys

    class TestScopeReplacer(TestCase):

        def test_case_0(self):
            var_0 = ScopeReplacer(globals(), None, 'var_0')
            attr = '_real_obj'
            val = None
            try:
                var_0.__setattr__(attr, val)
            except TypeError:
                self.fail(self.UNEXPECTED_EXCEPTION)

        def test_case_1(self):
            var_0 = ScopeReplacer(globals(), None, 'var_1')
            attr = '_resolve'
            val = None


# Generated at 2022-06-26 02:21:19.270286
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__ of ScopeReplacer is working properly."""
    var_3 = ScopeReplacer(var_0, var_1, var_2)
    try:
        var_3._resolve.__wrapped__(var_3)
    except AttributeError:
        pass


# Generated at 2022-06-26 02:21:24.172578
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Test that if the object does have _fmt defined, it is used by
    # __unicode__ for formatting
    exc = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert exc.__unicode__() == u'IllegalUseOfScopeReplacer: foo'




# Generated at 2022-06-26 02:21:30.722656
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    global var_0
    var_0 = None
    expected_0 = "AttributeError: 'NoneType' object has no attribute 'a'"
    actual_0 = None
    try:
        var_0.a = 1
    except AttributeError as e:
        actual_0 = str(e)
    # assert var_0.a = 1
    assert expected_0 == actual_0


# Generated at 2022-06-26 02:21:42.687776
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    exception = IllegalUseOfScopeReplacer(
        'foo',
        'bar',
        )
    unicode(exception)
    # call __unicode__ explicitly
    exception.__unicode__()


# Generated at 2022-06-26 02:21:44.882868
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer()
    # __call__(self, *args, **kwargs)
    raise NotImplementedError



# Generated at 2022-06-26 02:21:46.518345
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case_0()
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-26 02:21:52.937316
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.trace import mutter
    var_0 = mutter('testing IllegalUseOfScopeReplacer.__str__')
    var_1 = IllegalUseOfScopeReplacer(u'mock_name', u'mock_msg')
    var_2 = str(var_1)
    assert var_2.startswith('IllegalUseOfScopeReplacer')
    assert var_2.endswith('(mock_msg)')


# Generated at 2022-06-26 02:21:56.479121
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Create instance of IllegalUseOfScopeReplacer to be tested
    var_0 = IllegalUseOfScopeReplacer(arg_0, arg_1, arg_2)
    # Call the method to be tested
    var_1 = var_0.__str__()



# Generated at 2022-06-26 02:22:01.012489
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer."""
    var_14 = IllegalUseOfScopeReplacer('name', 'msg')
    var_15 = str(var_14)
    assert var_15 == "IllegalUseOfScopeReplacer object 'name' was used incorrectly: msg"


# Generated at 2022-06-26 02:22:04.338050
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = IllegalUseOfScopeReplacer._IllegalUseOfScopeReplacer__unicode__(
        'var_0',
        'var_1',
        'var_2')


# Generated at 2022-06-26 02:22:06.236300
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    str(e)
    str(e)



# Generated at 2022-06-26 02:22:09.065900
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    s = 'test'
    u = u'foo'
    var_0 = IllegalUseOfScopeReplacer('name', s)
    var_1 = str(var_0)
    var_2 = var_1.decode('utf8')


# Generated at 2022-06-26 02:22:20.668490
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib.lazy_import
    dummy_factory = None
    dummy_name = 'name'

    # Method __call__ of the ScopeReplacer class returns the real object when
    # accessed from the same function.
    def mock_factory(object, scope, name):
        return object

    var_0 = ScopeReplacer(sys.modules, mock_factory, dummy_name)
    result = var_0.__call__()
    assert result is var_0

    # Method __call__ of the ScopeReplacer class raises an exception if it is
    # accessed from another function.
    var_0 = ScopeReplacer(sys.modules, mock_factory, dummy_name)
    error = None
    try:
        test_case_0()
    except Exception as exc:
        error = exc

# Generated at 2022-06-26 02:22:40.650117
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = test_case_0()
    assert var_0 is None



# Generated at 2022-06-26 02:22:43.395264
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    case_0 = test_case_0()
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    var_1 = var_0.__unicode__()
    assert var_1 == u''


# Generated at 2022-06-26 02:22:53.941788
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """This method is not allowed, either obj is already replaced, or
    __call__ would cause the object to be replaced.
    """
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as e:
        # IllegalUseOfScopeReplacer( name='_should_proxy', msg='Object
        # already replaced, did you assign it to another variable?')
        assert e.name == '_should_proxy'
        assert e.msg == 'Object already replaced, did you assign it to' + \
            ' another variable?'
        assert e.extra == ''
    else:
        raise AssertionError('Exception IllegalUseOfScopeReplacer not raised')


# Generated at 2022-06-26 02:22:56.363409
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = lazy_import(globals(), 'os')
    obj('posix')



# Generated at 2022-06-26 02:23:01.052436
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    cases = [
        (test_case_0, None),
    ]
    for case, expected in cases:
        obj = ScopeReplacer(None, None, None)
        actual = obj.__call__(*case[0], **case[1])



# Generated at 2022-06-26 02:23:04.220160
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer()
    var_1 = var_0.__str__()
    assert var_1 =='Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:23:09.756033
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(globals(), None, 'var_0')
    obj._should_proxy = False

# Generated at 2022-06-26 02:23:13.447377
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """
    Ensure __str__() can be called with no arguments.
    """
    IllegalUseOfScopeReplacer('test_name', 'test_msg', 'test_extra')


# Generated at 2022-06-26 02:23:25.480783
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of ScopeReplacer"""
    global var_0
    global ScopeReplacer
    obj = ScopeReplacer(__main__.__dict__, lambda x, y, z: x, 'var_0')
    try:
        try:
            obj.__setattr__('_should_proxy', False)
            ok = True
        except:
            ok = False
        if not ok:
            raise TestFailed('ScopeReplacer.__setattr__(_should_proxy)'
                             ' should not raise IllegalUseOfScopeReplacer')
    finally:
        del ScopeReplacer
    # Pass '_should_proxy' as the actual attribute name instead of the
    # 'fake' attribute name. That way the exception message won't refer
    # to the 'fake' attribute name.

# Generated at 2022-06-26 02:23:34.178786
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Make sure that the _should_proxy check works"""

# Generated at 2022-06-26 02:23:57.833786
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    try:
        # Generate exception 'IllegalUseOfScopeReplacer'
        test_case_0()
    except IllegalUseOfScopeReplacer:
        pass



# Generated at 2022-06-26 02:24:01.594211
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method __unicode__ of class IllegalUseOfScopeReplacer

    The goal of this test is to ensure that IllegalUseOfScopeReplacer
    __unicode__() method can actually be called. It is not a goal to test
    its correctness.
    """
    assert False # implemented in C code


# Generated at 2022-06-26 02:24:14.148160
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    import unittest

    # Exercise function disallow_proxying from module bzrlib.lazy_import
    disallow_proxying()

    # Exercise function allow_proxying from module bzrlib.lazy_import
    allow_proxying()

    # Exercise function lazy_import from module bzrlib.lazy_import
    lazy_import(globals(), '''
    import bzrlib.lazy_import
    ''')

    # Exercise function ScopeReplacer from module bzrlib.lazy_import

# Generated at 2022-06-26 02:24:18.415385
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = IllegalUseOfScopeReplacer("var_0", "var_1")
    expect_0 = "var_0"
    actual_0 = case_0.__str__()
    assert actual_0 == expect_0


# Generated at 2022-06-26 02:24:21.416465
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests.blackbox import ExternalBase
    var_0 = ExternalBase()
    var_0.assertEqual(u'Unprintable exception IllegalUseOfScopeReplacer: dict={"extra": "", "msg": "This is an error"}', IllegalUseOfScopeReplacer(var_0, u"This is an error").__unicode__())


# Generated at 2022-06-26 02:24:24.123249
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import os
    import bzrlib.tests
    bzrlib.tests.blackbox.test_default_transport.TestCaseWithLoopbackTransport()
    os.path.abspath('')


# Generated at 2022-06-26 02:24:32.250160
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    scope = {}
    name = "var_0"
    factory = lazy_import.LazyImport(name, 'bzrlib.lazy_import.test_case_0', None, True)
    inst_0 = ScopeReplacer(scope, factory, name)
    assert (inst_0._should_proxy is True)


# Generated at 2022-06-26 02:24:42.586859
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self: IllegalUseOfScopeReplacer) -> unicode"""
    var_0 = IllegalUseOfScopeReplacer('mock_name01', 'mock_msg02', None)
    var_0._preformatted_string = 'mock_preformatted_string04'
    var_1 = var_0._get_format_string()
    # __unicode__() should return a unicode string.
    var_2 = isinstance(var_1, unicode)
    var_3 = var_0.__unicode__()
    var_4 = isinstance(var_3, unicode)
    var_5 = var_3
    # __str__() should return a str object.
    var_6 = var_0.__str__()

# Generated at 2022-06-26 02:24:46.567159
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer must return a 'str' object.

    It should not return a 'unicode' object. 'IllegalUseOfScopeReplacer'
    objects expect to be able to format them using a '%s' operator.
    """
    # self.assertRaises((), IllegalUseOfScopeReplacer.__str__)
    assert(False)


# Generated at 2022-06-26 02:24:50.807217
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_1 = ScopeReplacer(None, None, None)
    try:
        try:
            var_1(None, None)
        except TypeError:
            var_2 = True
        else:
            var_2 = False
        assert var_2
    finally:
        var_0 = reallow_proxying()


# Generated at 2022-06-26 02:25:09.454113
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    disallow_proxying()

    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    global_0 = test_case_0.func_globals
    scope_replacer_0 = ScopeReplacer(global_0, None, "var_0")

# Generated at 2022-06-26 02:25:13.219371
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('var_0', 'var_1', 'var_2')
    var_1 = str(var_0)
    var_2 = isinstance(var_1, str)
    var_3 = var_1 == 'IllegalUseOfScopeReplacer object \'var_0\' was used incorrectly: var_1: var_2'
    expect(var_2 and var_3)


# Generated at 2022-06-26 02:25:16.450647
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test with illegal arguments
    # Call object.__getattribute__(self, attr)
    self = ScopeReplacer(scope, factory, name)
    object.__getattribute__(self, attr)


# Generated at 2022-06-26 02:25:20.892708
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global var_0
    global var_1
    global var_2
    var_2 = ScopeReplacer(var_0, lambda self, scope, name: var_1, var_2)
    var_1 = var_2 = var_3 = var_4 = None


# Generated at 2022-06-26 02:25:22.170927
# Unit test for method __call__ of class ScopeReplacer

# Generated at 2022-06-26 02:25:26.596017
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.tests.blackbox.test_case_0 as test_case_0
    var_0 = test_case_0.disallow_proxying
    assert isinstance(var_0, ScopeReplacer), "Type mismatch"



# Generated at 2022-06-26 02:25:27.526063
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    raise NotImplementedError


# Generated at 2022-06-26 02:25:34.368601
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(), test_case_0, 'test_case_0')
    try:
        var_0()
    except IllegalUseOfScopeReplacer as var_1:
        var_2 = ('test_case_0', 'Object already replaced, did you assign it'
            ' to another variable?', '')
        var_3 = var_1
    else:
        var_1 = tuple()
        raise AssertionError(('test-case-0', 'ScopeReplacer.__call__'))

    var_4 = (var_3.name, var_3.msg, var_3.extra)
    assert(var_4 == var_2)
