

# Generated at 2022-06-26 02:16:04.130728
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('scope', 'foo', 23)
    s = unicode(e)
    assert isinstance(s, unicode)
    assert type(s) is unicode


# Generated at 2022-06-26 02:16:07.867355
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = ScopeReplacer(globals(), lambda x, y, z: None, '__name__')
    obj.__call__()


# Generated at 2022-06-26 02:16:20.371943
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    # test that __setattr__ will set an attribute on the object rather than the
    # class.
    class AnotherObject(object):
        def __init__(self, value=1):
            object.__setattr__(self, 'value', value)
        def method(self, value):
            object.__setattr__(self, 'value', value)
        def __setattr__(self, attr, value):
            assert(attr == 'value')
            object.__setattr__(self, attr, value)
    obj = AnotherObject()
    test_case_0 = TestCase()
    test_case_0.assertEqual(1, obj.value)
    obj.method(5)
    test_case_0.assertEqual(5, obj.value)

# Generated at 2022-06-26 02:16:26.535552
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    scope = {}
    scope_replacer_inst = ScopeReplacer(scope, test_case_0, 'import_processor_0')
    scope_replacer_inst._resolve()
    scope_replacer_inst.object



# Generated at 2022-06-26 02:16:34.267131
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    python_builtin = __import__("__builtin__")
    scope_replacer_0 = python_builtin.object()
    scope_replacer_1 = scope_replacer_0
    scope_replacer_1.__setattr__("_should_proxy", False)
    scope_replacer_2 = ScopeReplacer({"bzrlib": python_builtin}, import_processor_0.import_module, "bzrlib")
    scope_replacer_3 = scope_replacer_2
    scope_replacer_4 = scope_replacer_3
    scope_replacer_4.foo = scope_replacer_2


# Generated at 2022-06-26 02:16:41.002084
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest, bzrlib.lazy_import
    doctest.run_docstring_examples(bzrlib.lazy_import.IllegalUseOfScopeReplacer.__str__,
                                   globals(),
                                   name='IllegalUseOfScopeReplacer.__str__')



# Generated at 2022-06-26 02:16:48.578133
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    # Test for 1st exception raised by method __setattr__
    # of class ScopeReplacer
    global __expects_t1
    try:
        __expects_t1 = True
        global t1
        t1 = ScopeReplacer({}, lambda a, b, c: None, None)
        t1.__setattr__("new_attr", "val")
    except NameError as e:
        assert e.args[0] == global_name_error_value, \
            'Unexpected exception was raised: ' + str(e)

    # Test for 2nd exception raised by method __setattr__
    # of class ScopeReplacer
    global __expects_t2

# Generated at 2022-06-26 02:16:54.181388
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    import_processor_0 = ImportProcessor()
    import_processor_0.first_use_of('j')
    exc = IllegalUseOfScopeReplacer('name', 'msg')
    r = str(exc)
    raise ExceptionThunk((r,))


# Generated at 2022-06-26 02:17:05.908980
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import (
        ModuleWithFunction,
        ModuleWithFunctionAndProperty,
        ModuleWithProperty,
        )
    from bzrlib.lazy_import import lazy_import, ScopeReplacer

    class TestModuleWithFunction(TestCase):

        def test_method___call__(self):
            import_processor_0 = lazy_import(ModuleWithFunction)
            t = ModuleWithFunction()
            self.assertIsInstance(t.foo, ScopeReplacer)
            self.assertEqual(0, t.foo())
            t.test_function()
            self.assertEqual(1, t.foo())


# Generated at 2022-06-26 02:17:16.642844
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_2 = ImportProcessor()
    import_processor_2.__enter__()

# Generated at 2022-06-26 02:17:27.598711
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-26 02:17:37.019396
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = _ScopeReplacer()
    scope_replacer_0.name = '<unprintable exception object>'
    scope_replacer_0.msg = '<unprintable exception object>'
    scope_replacer_0.extra = '<unprintable exception object>'
    str_0 = str(scope_replacer_0)
    scope_replacer_0.msg = 'msg'
    scope_replacer_0.extra = 'extra'
    str_1 = str(scope_replacer_0)



# Generated at 2022-06-26 02:17:39.914047
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        setattr(ScopeReplacer(), "name", "value")
    except:
        pass


# Generated at 2022-06-26 02:17:42.994448
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # if you see a failure here, you are calling a lazy_imported object
          # without a variable first.


# Generated at 2022-06-26 02:17:44.534457
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:17:49.293375
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    scope_replacer_1 = ScopeReplacer(globals(), 'symbol_3', 'import_processor_0', 'lazy_import_0')
    try:
        raise IllegalUseOfScopeReplacer('scope_replacer_1', 'Use before initialization')
    except IllegalUseOfScopeReplacer as e:
        assert str(e) == "ScopeReplacer object 'scope_replacer_1' was used incorrectly: Use before initialization"

import sys



# Generated at 2022-06-26 02:18:00.364544
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a 'str' object, not a 'unicode' object."""
    import_processor_0 = ImportProcessor()
    import sys
    try:
        import_processor_0.execute("from bzrlib import lp_a")
        assert False, "The ImportProcessor.execute must fail with ImportError"
    except ImportError as e:
        u = unicode(e)
        s = str(e)
        if sys.platform == 'win32':
            # On Windows, Python 2.6 sometimes returns a str and sometimes a unicode.
            # See http://bugs.python.org/issue4305 for details.
            assert isinstance(u, unicode)
            assert isinstance(s, str)
        else:
            assert type(u) != unicode

# Generated at 2022-06-26 02:18:05.205419
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor = ImportProcessor()

    # __call__
    # A lazy object that will replace itself in the appropriate scope.
    #
    # This object sits, ready to create the real object the first time it is
    # needed.
    #
    # :param scope: The scope the object should appear in
    # :param factory: A callable that will create the real object.
    #     It will be passed (self, scope, name)
    # :param name: The variable name in the given scope.
    #
    #

    # Call test_case_0()

    # __getattribute__
    # Return the real object for which this is a placeholder
    #
    #

    # __setattr__
    #
    #
    #





# Generated at 2022-06-26 02:18:15.818030
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    scope = {}
    scope['ScopeReplacer'] = lazy_import.ScopeReplacer
    scope['ScopeReplacer']._should_proxy = True
    from bzrlib.trace import mutter
    scope['mutter'] = mutter
    scope['get_transaction'] = None
    scope['get_transaction_manager'] = None
    # Test the case in which the instance attribute '_resolve' return the value
    # of the instance attribute '_real_obj' which is not None
    import_processor_0 = ModuleDecorator('bzrlib.trace')
    scope['get_transaction'] = get_transaction = import_processor_0(1)
    scope['get_transaction_manager'] = get_transaction_manager = import_processor_0(2)


# Generated at 2022-06-26 02:18:28.618096
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib
    import bzrlib.lazy_import as lazy_import
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import as test_lazy_import

    # Call test_ScopeReplacer___call__ without argument.
    lazy_import.test_ScopeReplacer___call__()

    # Call test_ScopeReplacer___call__ with argument 'woof'

# Generated at 2022-06-26 02:18:41.844366
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():                  #IGNORE:L111
    import sys
    if sys.version_info[0] == 0:
        return
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    assert str(e) == "name was used incorrectly: msg: extra"


# Generated at 2022-06-26 02:18:51.855578
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    _var_0 = disallow_proxying()
    _var_1 = ScopeReplacer({}, lambda: 42, 42)
    try:
        _var_1._resolve = lambda: _var_1
        _var_1._factory = lambda x: x
        _var_1._scope = _var_0
        _var_1._name = 42
        _var_1.__setattr__(42, 42)
    except IllegalUseOfScopeReplacer as _var_e:
        _var_2 = _var_e
    else:
        raise AssertionError("IllegalUseOfScopeReplacer not raised")


# Generated at 2022-06-26 02:18:53.579514
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Returns: The real object for which this is a placeholder
    pass


# Generated at 2022-06-26 02:18:57.690643
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    scope = {'MyCls': MyCls}
    name = 'MyCls'
    replacer = ScopeReplacer(scope, _make_class, name)
    # Call the unbound method with valid args
    self = TestCase()
    result_0 = replacer.__call__(self)
    # Call the unbound method with invalid args
    self = 4
    exception = "TypeError: unbound method __call__() must be called with "\
        "ScopeReplacer instance as first argument "\
        "(got int instance instead)"

# Generated at 2022-06-26 02:19:04.338401
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name',
        'msg', 'extra')
    var_1 = var_0.__str__()
    assert(
        var_1 ==
        'ScopeReplacer object \'name\' was used incorrectly: msg: extra'
    )

    var_0 = IllegalUseOfScopeReplacer('name',
        'msg', None)
    var_1 = var_0.__str__()
    assert(
        var_1 ==
        'ScopeReplacer object \'name\' was used incorrectly: msg'
    )


# Generated at 2022-06-26 02:19:06.959121
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exc = IllegalUseOfScopeReplacer(name='var_0', msg='message')
    expected = "var_0 was used incorrectly: message"
    actual = str(exc)
    assert expected == actual


# Generated at 2022-06-26 02:19:19.099047
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = test_case_0()
    var_1 = ScopeReplacer(var_0, None, None)
    var_2 = isinstance(var_1, ScopeReplacer)
    Assert(var_2)
    Assert(var_1.__getattribute__('_should_proxy'))
    var_1.__setattr__('_should_proxy', False)
    Assert(not var_1.__getattribute__('_should_proxy'))
    try:
        var_1.__setattr__('_should_proxy', True)
    except IllegalUseOfScopeReplacer as e:
        var_3 = e.__getattribute__('_name')
        Assert('var_1' == var_3)

# Generated at 2022-06-26 02:19:26.486996
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    cases = [
        (test_case_0, ),
    ]

# Generated at 2022-06-26 02:19:37.072710
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.symbol_versioning
    bzrlib.symbol_versioning.provide('bzrlib.lazy_import',
            latest_version=(1, 2, 3))
    bzrlib.symbol_versioning.require_minimum('bzrlib.lazy_import',
            (1, 2, 3))
    assert bzrlib.symbol_versioning.module_version('bzrlib.lazy_import') == (1, 2, 3)
    assert ScopeReplacer._should_proxy
    assert test_case_0.__code__.co_names[0] == 'disallow_proxying'
    assert bzrlib.lazy_import.ScopeReplacer._should_proxy

# Generated at 2022-06-26 02:19:44.933356
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    import StringIO
    stream = StringIO.StringIO()
    var_0 = IllegalUseOfScopeReplacer(name="var_0", msg="var_1")

# Generated at 2022-06-26 02:20:08.738739
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    testcase = '''
    # test_IllegalUseOfScopeReplacer___unicode__
    from bzrlib.lazy_import import (
        IllegalUseOfScopeReplacer,
        )
    from bzrlib.tests import (
        TestCase,
        )
    class TestCase_0(TestCase):
        def test_case_0(self):
            var_0 = IllegalUseOfScopeReplacer("name", "msg")
    '''
    import sys
    from StringIO import StringIO
    from bzrlib.tests import test_suite
    from bzrlib.tests import (
        KnownFailure,
        )
    from bzrlib.lazy_import import (
        LazyImporter,
        ScopeReplacer,
        )
    # Get rid of the stack frame that is this function

# Generated at 2022-06-26 02:20:14.429116
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    ScopeReplacer(
        global_scope,
        lambda self, scope, name: scope['bzrlib.commands.cmd_selftest'].test_case_0,
        'var_0'
    )
    # Output:
    # IllegalUseOfScopeReplacer('var_0',
    #                           'Object already replaced, did you assign it'
    #                           ' to another variable?')


# Generated at 2022-06-26 02:20:15.320449
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # tested via interactive __call__


# Generated at 2022-06-26 02:20:16.079134
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() -> unicode"""
    return test_case_0()

# Generated at 2022-06-26 02:20:19.274778
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    e = TestCase.assertRaises(IllegalUseOfScopeReplacer,
        test_case_0)
    TestCase.assertTrue(e.msg.startswith("Object already replaced, did"))


# Generated at 2022-06-26 02:20:28.733471
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('replacer', 'some message')

    tt = e.__str__()

    # ValueError: format requires a mapping
    # __str__() should return a string
    assert isinstance(tt, str)

    # ValueError: format requires a mapping
    assert tt.find(
        'replacer') >= 0, '%s not found in %s' % ('replacer', ascii(tt))

    # ValueError: format requires a mapping
    assert tt.find(
        'some message') >= 0, '%s not found in %s' % ('some message', ascii(tt))


# Generated at 2022-06-26 02:20:39.034973
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """This test must pass before the real value is set in the __setattr__
    method.
    """
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer, IllegalUseOfScopeReplacer

    class FakeScope(object):
        def __init__(self):
            self.dict = {}
        def __setitem__(self, name, obj):
            self.dict[name] = obj
        def __getitem__(self, name):
            return self.dict[name]

    def _factory(replacer, scope, name):
        return replacer

    def _proxy_setter(obj):
        obj.__setattr__ = getattr(obj, '_resolve').__get__(obj)


# Generated at 2022-06-26 02:20:47.250606
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import bzrlib.trace
    env = {'bzrlib': bzrlib, 'bzrlib_lazy_import':bzrlib.lazy_import,
           'bzrlib_trace':bzrlib.trace}
    var_0 = None
    try:
        var_0 = bzrlib.lazy_import.lazy_import(globals(), '''
        from bzrlib.trace import note
        ''')
    except:
        pass
    var_1 = None
    try:
        var_1 = bzrlib.lazy_import.lazy_import(env, '''
        from bzrlib.trace import note
        ''')
    except:
        pass
    assert var_

# Generated at 2022-06-26 02:20:48.576992
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Calls test_case_0()
    test_case_0()


# Generated at 2022-06-26 02:20:50.218604
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg')
    str(e)


# Generated at 2022-06-26 02:21:04.147041
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    assert not (var_0 is None)
    assert ('<bzrlib.lazy_import.ScopeReplacer object at' in '%r' % (var_0,))
    var_1 = var_0()
    assert not (var_1 is None)
    assert ('<bzrlib.lazy_import.ScopeReplacer object at' in '%r' % (var_1,))


# Generated at 2022-06-26 02:21:09.568255
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    #test cases
    obj = ScopeReplacer(ScopeReplacer._should_proxy, ScopeReplacer._fmt, ScopeReplacer._resolve, ScopeReplacer._scope, ScopeReplacer.__setattr__, ScopeReplacer._real_obj, ScopeReplacer.__call__, ScopeReplacer._name, ScopeReplacer._factory)
    #testind code
    assert False # TODO: implement your test here


# Generated at 2022-06-26 02:21:11.271803
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True



# Generated at 2022-06-26 02:21:16.938461
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from io import StringIO
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # call test method
    # test __str__'s docstring
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')


# Generated at 2022-06-26 02:21:25.784778
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        var_0 = lazy_import(globals(), 'bzrlib.lazy_import')
    except Exception:  # TODO pick exact exception
        raise AssertionError
    try:
        var_1 = IllegalUseOfScopeReplacer()
    except Exception:  # TODO pick exact exception
        raise AssertionError
    try:
        var_2 = var_1.__unicode__()
    except Exception:  # TODO pick exact exception
        raise AssertionError
    except Exception:  # TODO pick exact exception
        raise AssertionError


# Generated at 2022-06-26 02:21:29.677359
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import

    # Test case 0 - IllegalUseOfScopeReplacer
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:21:35.895195
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    var_0 = ScopeReplacer(globals(),None,'import foo')
    try:
        var_0.foo
        var_0.bar = 'x'
    except AttributeError:
        from bzrlib.lazy_import import IllegalUseOfScopeReplacer
        raise



# Generated at 2022-06-26 02:21:43.691327
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # This method tests the functionality of the __str__ method of the
    # IllegalUseOfScopeReplacer class.
    var_0 = IllegalUseOfScopeReplacer('var_0', 'var_1')
    var_0.__class__ = type
    var_0.__bases__ = ()
    var_0.__dict__ = {}
    var_0.__name__ = 'IllegalUseOfScopeReplacer'
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    if (var_0._get_format_string() != None):
        raise AssertionError
    if (str(var_0) != 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'):
        raise AssertionError

# Generated at 2022-06-26 02:21:49.530128
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ on IllegalUseOfScopeReplacer"""
    # Calling basic sanity check
    o = IllegalUseOfScopeReplacer("name_0", "msg_0")
    o._preformatted_string = ""
    o._fmt = ""

# Generated at 2022-06-26 02:21:59.793479
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class_under_test = ScopeReplacer

    # Test 1: Assigning to a module name
    #   Input:
    #      class_under_test.__setattr__()
    #          attr = 'bzrlib.builtins'
    #          value = 'Module "bzrlib/builtins.pyc"'
    attr = 'bzrlib.builtins'
    value = 'Module "bzrlib/builtins.pyc"'
    instance = class_under_test.__new__(class_under_test)
    instance.__init__(scope='dummy')
    #   Expected:
    #      class_under_test._real_obj = {'bzrlib.builtins': 'Module "bzrlib/builtins.pyc"'}

# Generated at 2022-06-26 02:22:18.167466
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Mock(object):
        attr = "dummy"

    mock = Mock()
    object.__setattr__(mock, '_name', "mock")

    object.__setattr__(mock, '_resolve', lambda: mock)
    assert mock.attr == "dummy"

# Generated at 2022-06-26 02:22:24.172860
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    exc = IllegalUseOfScopeReplacer("'name'", "This is a %(msg)s", "extra")
    u = exc.__unicode__()
    # The following assertions fail if this method does not return a
    # unicode object.  There is no way to test for values of the
    # returned string, since it depends on the current locale.
    assert isinstance(u, unicode)
    assert not isinstance(u, str)


# Generated at 2022-06-26 02:22:28.042167
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(None,None,None)
    try:
        var_0.__setattr__(None,None)
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:22:30.056263
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # tested in test_case_0


# Generated at 2022-06-26 02:22:34.710986
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_0.script_name = 'script_name'
    var_0._fmt = '_fmt'
    # Test normal execution path
    var_1 = str(var_0)
    assert var_1 == '_fmt'


# Generated at 2022-06-26 02:22:40.711278
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(scope=None, factory=None, name=None)
    assert hasattr(obj, '__setattr__'), "'ScopeReplacer' object has no __setattr__ method."
    try:
        obj.__setattr__(attr=None, value=None)
    except AttributeError:
        pass # XXX this test method needs a docstring


# Generated at 2022-06-26 02:22:41.627103
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    assert True


# Generated at 2022-06-26 02:22:53.982660
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib.lazy_import

    def factory(scope_replacer, scope, name):
        return None

    global name_0
    name_0 = 'name_0'
    global name_1
    name_1 = 'name_1'
    scope_replacer_0 = bzrlib.lazy_import.ScopeReplacer(globals(), factory,
                                                        name_0)
    scope_replacer_0.__setattr__(name_1, sys.modules)

# Generated at 2022-06-26 02:23:00.620711
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    expected_var_0 = None
    actual_var_0 = test_case_0()
    are_equal_var_0 = (expected_var_0 == actual_var_0)
    if not are_equal_var_0:
        raise AssertionError("%r == %r" % (expected_var_0, actual_var_0))


# Generated at 2022-06-26 02:23:02.536646
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # TODO: write a unit test for method __unicode__ of class IllegalUseOfScopeReplacer
    pass


# Generated at 2022-06-26 02:23:22.700866
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    instance = IllegalUseOfScopeReplacer("var_0", "test_msg")
    # __unicode__ method returns an unicode object
    test_result = isinstance(instance.__unicode__(), unicode)
    assert test_result == True, "'__unicode__' method does not return an unicode object."


# Generated at 2022-06-26 02:23:33.069131
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    ScopeReplacer._should_proxy = False
    l = dict()
    o = ScopeReplacer(l, lambda s, sc, n: None, 'N')
    o.a = 1
    assert_equal(dict(a=1), o.__dict__)
    assert_equal(dict(N=o, a=1), l)

    o = ScopeReplacer(l, lambda s, sc, n: s, 'N')
    o.a = 1
    assert_equal(dict(a=1), o.__dict__)
    assert_equal(dict(N=o, a=1), l)

    o = ScopeReplacer(l, lambda s, sc, n: None, 'N')
    o.a = 1
    assert_equal(dict(a=1), o.__dict__)

# Generated at 2022-06-26 02:23:36.698991
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import gc
    var_0 = ScopeReplacer({}, lambda x, scope, name: scope, 'var_0')
    var_0(123)
    assert var_0 == {'var_0': 123}, repr(var_0)
    assert test_ScopeReplacer___call__.__doc__ == 'Unit test for method __call__ of class ScopeReplacer', repr(test_ScopeReplacer___call__.__doc__)
    gc.collect()


# Generated at 2022-06-26 02:23:37.406657
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    IllegalUseOfScopeReplacer('fmt', 'extra')


# Generated at 2022-06-26 02:23:41.484724
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() -> unicode"""
    var_0 = IllegalUseOfScopeReplacer('var_3', 'var_4')
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:23:46.216210
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('foo', 'bar')
    assert var_0.__unicode__() == u'Unprintable exception IllegalUseOfScopeReplacer: dict={\'name\': \'foo\', \'msg\': \'bar\', \'extra\': \'\'}, fmt=None, error=None'



# Generated at 2022-06-26 02:23:47.513426
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = ScopeReplacer(1)
    var_0.__getattribute__('_resolve')()


# Generated at 2022-06-26 02:23:52.329899
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # test cases
    try:
        var_0 = IllegalUseOfScopeReplacer.__str__()
    except Exception as var_1:
        var_0 = var_1
    assert isinstance(var_0, NotImplementedError)


# Generated at 2022-06-26 02:23:54.922705
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    assertInstanceWithHash(IllegalUseOfScopeReplacer(None, None),
                           IllegalUseOfScopeReplacer, 'IllegalUseOfScopeReplacer')


# Generated at 2022-06-26 02:24:01.496924
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import __builtin__
    # Auto-generated by testmaker
    # On: 2016-11-14 14:47:40
    # If this test fails revise the generator and/or fix the fault.
    t = ScopeReplacer(__builtin__, ScopeReplacer, '__builtin__')
    test_case_0()
    t.__setattr__(ScopeReplacer(__builtin__, ScopeReplacer, '__builtin__'), ScopeReplacer(__builtin__, ScopeReplacer, '__builtin__'))



# Generated at 2022-06-26 02:24:35.057802
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    factory = lambda self, scope, name: object()
    var_0 = ScopeReplacer({}, factory, 'name')
    try:
        var_0.name = 2
    except:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-26 02:24:40.742544
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test the behavior of IllegalUseOfScopeReplacer.__unicode__()"""
    # Check that IllegalUseOfScopeReplacer.__unicode__() works without
    # throwing an exception.
    var_0 = IllegalUseOfScopeReplacer('foo', 'msg', 'extra information')
    var_1 = var_0.__unicode__()
    assert isinstance(var_1, unicode)


# Generated at 2022-06-26 02:24:44.552091
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(name='the_name', msg='the_msg',
                                      extra='the_extra')
    var_1 = var_0.__unicode__()
    assert(isinstance(var_1, unicode))
    return var_1


# Generated at 2022-06-26 02:24:45.323914
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case_0()


# Generated at 2022-06-26 02:24:49.742927
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def test_case_1():
        var_0 = ScopeReplacer()
        var_1 = None
        var_0.__setattr__('_real_obj', 'var_1')
        var_0.__setattr__('var_2', 'var_1')
    test_case_1()


# Generated at 2022-06-26 02:24:54.028220
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Make a vector of methods to test.
    methods = [
        IllegalUseOfScopeReplacer,
        ]
    for method in methods:
        # Call the method.
        try:
            method()
        except Exception as e:
            assert e.__unicode__() is not None


# Generated at 2022-06-26 02:25:01.139637
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from testtools.matchers import raises
    from bzrlib.lazy_import import ScopeReplacer
    scope = {}
    name = 'var_0'
    def factory():
        return 1
    scope_replacer = ScopeReplacer(scope, factory, name)
    assert_raises(IllegalUseOfScopeReplacer,
                  scope_replacer.__setattr__, 'var_1', 1)


# Generated at 2022-06-26 02:25:02.388832
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # TODO: implement test
    raise NotImplementedError


# Generated at 2022-06-26 02:25:13.224785
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    #
    # __str__ method
    #

    case_0_name = 'case_0'
    case_0_msg = 'case_0_msg'
    case_0_extra = 'case_0_extra'
    case_0 = IllegalUseOfScopeReplacer(case_0_name, case_0_msg, case_0_extra)

    case_0_str = 'ScopeReplacer object \'case_0\': case_0_msg: case_0_extra'
    case_0_repr = 'IllegalUseOfScopeReplacer(\'case_0\')'

    if case_0.__str__() != case_0_str or repr(case_0) != case_0_repr:
        raise AssertionError('__str__ method failed')


# Generated at 2022-06-26 02:25:19.276673
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import __builtin__
    if hasattr(__builtin__, 'unicode'):
        # built-in method __str__
        # called via instance
        var_0 = IllegalUseOfScopeReplacer.__str__(test_case_0.var_0)
    else:
        # built-in function __str__
        # called via instance
        var_0 = str(test_case_0.var_0)