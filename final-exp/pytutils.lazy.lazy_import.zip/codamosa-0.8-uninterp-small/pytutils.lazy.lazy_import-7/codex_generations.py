

# Generated at 2022-06-26 02:16:12.535083
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    illegal_use_of_scope_replacer_0 = IllegalUseOfScopeReplacer(None, None)
    scope_replacer_0 = ScopeReplacer({}, test_case_0, None)

# Generated at 2022-06-26 02:16:20.946604
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    str_0 = '}^ZE:Ik|m'
    scope_replacer_0 = ScopeReplacer(import_processor_0, object, str_0)
    scope_replacer_0._should_proxy = True
    scope_replacer_0._real_obj = object
    try:
        scope_replacer_0.__setattr__('a', 'a')
        raise AssertionError()
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:16:31.844201
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    str_0 = '-wPb<'

    ################################################################################
    ## Start of Scope: 'ORR$,hHp'
    ################################################################################

    ################################################################################
    ## Start of Scope: '+R,GJ}`'
    ################################################################################

    ################################################################################
    ## End of Scope: '+R,GJ}`'
    ################################################################################

    ################################################################################
    ## End of Scope: 'ORR$,hHp'
    ################################################################################



# Generated at 2022-06-26 02:16:44.775489
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import (ScopeReplacer, IllegalUseOfScopeReplacer)
    from bzrlib import (
        errors, osutils, branch)
    from bzrlib.branch import Branch
    import bzrlib

    # Test illegal use
    lazy_branch = ScopeReplacer(locals(), _obj_factory, 'Branch')
    try:
        lazy_branch.test = 'foo'
    except TypeError:
        pass
    else:
        raise AssertionError('Illegal access to ScopeReplacer'
                             ' method should raise TypeError')

    # Test illegal use with proxying disabled
    ScopeReplacer._should_proxy = False
    try:
        lazy_branch.test = 'foo'
    except TypeError:
        pass
    else:
        raise

# Generated at 2022-06-26 02:16:46.282878
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()


# Generated at 2022-06-26 02:16:56.048915
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_1 = ImportProcessor()
    str_1 = ')t;$#q0&%fZ|0?'
    local_scope_1 = {str_1: None}
    def factory_1(self_1, scope_1, name_1):
        local_scope_1[str_1] = self_1
        return self_1
    replacement_1 = ScopeReplacer(local_scope_1, factory_1, str_1)
    replacement_1.some_attr = 1
    if (local_scope_1[str_1].some_attr != 1):
        print('FAIL test_ScopeReplacer___setattr__')




# Generated at 2022-06-26 02:16:58.656320
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    try:
        str_0 = 'P>oKAz@|H())#$'
        test_case_0()
    except Exception:
        raise
    else:
        return 0


# Generated at 2022-06-26 02:17:09.250353
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global import_processor_0
    global str_0
    global test_case_0
    if test_case_0 == 0:
        test_case_0 = 1
    else:
        return
    import_processor_0 = ImportProcessor()
    str_0 = ')0}~kluwA^^U:qcO'

    def factory(self, scope, name):
        """ Test docstring """
        return self

    try:
        import_processor_0.lazy_import(locals(), str_0, factory)
    except IllegalUseOfScopeReplacer:
        pass
    except Exception:
        raise AssertionError



# Generated at 2022-06-26 02:17:13.844914
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from import_processor import ImportProcessor
    import_processor_0 = ImportProcessor()
    str_0 = ')0}~kluwA^^U:qcO'


# Generated at 2022-06-26 02:17:15.686243
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    str_0 = 'Gu&;MK'


# Generated at 2022-06-26 02:17:31.341238
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # test with a non-unicode message
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    repr(e)
    str(e)
    unicode(e)


# Generated at 2022-06-26 02:17:34.272208
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    doctest.testmod(verbose=True, report=True)



# Generated at 2022-06-26 02:17:47.795538
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('e_name', 'msg')
    # Test that we can format the exception.
    unicode(e)
    # Test that the formatted message contains the name and message.
    assert 'e_name' in unicode(e)
    assert 'msg' in unicode(e)
    # Test that __str__ gives the same message with the same encoding
    assert str(e) == unicode(e).encode('utf8')

# A class to temporarily replace objects in a module's namespace
# This can sometimes be used instead of 'from foo import bar'
#
# For example, to replace 'foo.bar' with our own version, you can use::
#
#   replacer = ScopeReplacer(foo, 'bar')
#   replacer.replace('a-string')
#   ...
#   repl

# Generated at 2022-06-26 02:17:59.859694
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import logging
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import_processor_1 = ImportProcessor()
    import_processor_1._call_lazy_import_callback = True
    import_processor_1._is_global = False
    import_processor_1._import_processor_2 = ImportProcessor()
    import_processor_1._has_import_processor_3 = False
    import_processor_1._collect_assignments_1 = True
    import_processor_1._contains_global_imports = True
    import_processor_1.imp_name_2 = 'imp_name_2'
    import_processor_1.imp_name_3 = 'imp_name_3'
    import_processor_1._is_

# Generated at 2022-06-26 02:18:04.524614
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Calls the method __call__ of ScopeReplacer with appropriate arguments.
    # The method should normally raise an error, if it works correctly.
    test_case_0()

test_ScopeReplacer___call__()


# Generated at 2022-06-26 02:18:06.295295
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test method ScopeReplacer.__setattr__"""
    # Insert your code here.


# Generated at 2022-06-26 02:18:08.459341
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('the name', 'the msg')
    u = unicode(e)
    assert u == "ScopeReplacer object 'the name' was used incorrectly: the msg"


# Generated at 2022-06-26 02:18:11.119100
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    r = IllegalUseOfScopeReplacer('name', 'message')
    assert str(r) == 'IllegalUseOfScopeReplacer(name): message'


# Generated at 2022-06-26 02:18:16.395834
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCaseInTempDir, KnownFailure
    import_processor_0 = ImportProcessor()
    # Known failure - this test cannot be run by itself.
    raise KnownFailure(
        'This test cannot be run by itself. It needs to be run as part of another test.'
    )


# Generated at 2022-06-26 02:18:23.320788
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import (
        ImportProcessor,
        ScopeReplacer,
        )
    import_processor = ImportProcessor()
    # This is an instance of class ImportProcessor
    import_processor.tokens = []
    ScopeReplacer.__call__(import_processor)


# Generated at 2022-06-26 02:18:40.851519
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()

    name_0 = u"foo \u4e0a\u4e0b"
    msg_0 = u"bar \u4e0a\u4e0b"
    extra_0 = u"baz \u4e0a\u4e0b"
    illegalUseOfScopeReplacer_0 = IllegalUseOfScopeReplacer(name_0, msg_0, extra_0)

    name_1 = u"foo \u4e0a\u4e0b"
    msg_1 = u"bar \u4e0a\u4e0b"
    extra_1 = u"baz \u4e0a\u4e0b"

# Generated at 2022-06-26 02:18:53.848330
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests import TestCase
    from bzrlib.error import get_error_from_msg

    # Here we check that the __str__() method of an error class works
    # properly.
    e = get_error_from_msg('test')
    t = TestCase('__str__')
    t.assertEqualDiff('test', str(e))
    t.assertEqualDiff('test', unicode(e))

    # Should format with the message and arguments
    e = get_error_from_msg('%s: %s', 'foo', 'bar')
    t.assertEqualDiff('foo: bar', str(e))
    t.assertEqualDiff('foo: bar', unicode(e))

    # Should return a str
    e = get_error_from_msg(u'foo')

# Generated at 2022-06-26 02:19:01.462358
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Built-in functions
    import __builtin__
    ScopeReplacer_0 = ScopeReplacer(__builtin__, ImportProcessor, '0')
    try:
        # test for bad scope name
        ScopeReplacer_0._resolve()
    except IllegalUseOfScopeReplacer as e:
        if str(e) == "ScopeReplacer object '0' was used incorrectly: Object tried to replace itself, check it's not using its own scope.":
            pass
        else:
            print('FAIL: got %s' % e)
    else:
        print('FAIL: expected exception here')



# Generated at 2022-06-26 02:19:05.421838
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    try:
        import_processor_0.illegal_use()
    except IllegalUseOfScopeReplacer as e:
        actual = str(e)
        f = "ScopeReplacer object 'imp' was used incorrectly: the key 'a' is not present in the ScopeReplacer%(extra)s"
        expect = f % {'extra': (': ('
            "KeyError('a',), None, <traceback object at 0x%x>)" % (id(e.extra),)),
            }
        assert expect == actual



# Generated at 2022-06-26 02:19:08.134859
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    f = IllegalUseOfScopeReplacer.__str__
    # The function must return a str.
    assert isinstance(f(IllegalUseOfScopeReplacer("foo", "bad thing")), str)


# Generated at 2022-06-26 02:19:20.529569
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    lazy_import.__patched_import__ = lazy_import.__patched_import__.replace('ScopeReplacer', 'test_ScopeReplacer___call__\n    from bzrlib.lazy_import import ScopeReplacer')
    if 'test_ScopeReplacer___call__' in globals():
        del globals()['test_ScopeReplacer___call__']
    globals()['test_ScopeReplacer___call__'] = None
    try:
        exec('test_case_0()')
        obj = globals()['import_processor_0']
        expected = 'test'
        got = obj(expected)
        if (got != expected): raise AssertionError

    finally:
        lazy_import.__patched_import__ = lazy_import.__patched_

# Generated at 2022-06-26 02:19:28.339168
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import ImportProcessor
    import_processor_0 = ImportProcessor()
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    object_17 = object()
    object_18 = object()
    object_19 = object()
    object_20 = object()
    object_

# Generated at 2022-06-26 02:19:29.257242
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:19:33.770683
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(), import_processor_0, "test_case_0")
    result = scope_replacer_0()
    #
    # FIXME: The actual test would be here
    #



# Generated at 2022-06-26 02:19:45.054948
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0, None, None)
    import_processor_1 = ImportProcessor({})
    scope_replacer_1 = ScopeReplacer(import_processor_1, None, None)
    scope_replacer_0._factory = lambda self, scope, name: scope_replacer_1
    scope_replacer_0._name = 'name'
    scope_replacer_0._scope = import_processor_1
    scope_replacer_0._resolve()
    scope_replacer_0._resolve = lambda: scope_replacer_1
    scope_replacer_0._real_obj = scope_replacer_1

# Generated at 2022-06-26 02:19:56.290157
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # unit tests for this functionality were written in test_case_0
    # test_case_0 is covered by test_IllegalUseOfScopeReplacer__format
    pass


# Generated at 2022-06-26 02:20:04.765927
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.per_interceptor import TestCaseWithIntercept
    test = TestCaseWithIntercept()
    ScopeReplacer._should_proxy = True

    def constructor(r, s, n):
        return object()
    test.assertRaises((IllegalUseOfScopeReplacer, AttributeError),
        ScopeReplacer, {}, constructor, 'foo')
    ScopeReplacer._should_proxy = False
    test.assertRaises(IllegalUseOfScopeReplacer,
        ScopeReplacer, {}, constructor, 'foo')


# Generated at 2022-06-26 02:20:07.647597
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(), import_processor_0, "test_case_0")
    scope_replacer_0()


# Generated at 2022-06-26 02:20:12.068976
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self)

    Exception.__str__ is supposed to return str, not unicode.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = unicode(e) # should not raise UnicodeDecodeError
    assert isinstance(s, unicode)



# Generated at 2022-06-26 02:20:19.818583
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import unittest
    global import_processor_0
    try:
        test_case_0()
    except:
        # We have no control over which exception is raised, so we catch
        # all of them.
        pass


# functions that are always called when an attribute is accessed
# through a proxy, even when the value is just returned

# Generated at 2022-06-26 02:20:26.073735
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib import (
        errors,
        osutils,
        branch,
        )

    def factory(self, scope, name):
        import bzrlib.branch
        return bzrlib.branch

    locals()['branch'] = ScopeReplacer(globals(), factory, 'branch')
    errors



# Generated at 2022-06-26 02:20:36.830220
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(), None, 'x')
    scope_replacer_0.__setattr__('attr_0', 'abc')
    scope_replacer_0.__setattr__('attr_1', 'abc')
    scope_replacer_0.__setattr__('attr_2', 'abc')
    scope_replacer_0.__setattr__('attr_3', 'abc')
    scope_replacer_0.__setattr__('attr_4', 'abc')
    scope_replacer_0.__setattr__('attr_5', 'abc')
    scope_replacer_0.__setattr__('attr_6', 'abc')

# Generated at 2022-06-26 02:20:45.901336
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0.scope_0,
        import_processor_0.factory_0, import_processor_0.name_0)
    scope = ScopeReplacer(import_processor_0.scope_0,
        import_processor_0.factory_0, import_processor_0.name_0)
    # Test the exception is raised with the correct arguments

# Generated at 2022-06-26 02:20:54.496455
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    scope = {}
    scope_replacer = scope['lazy_import'] = ScopeReplacer(
        scope, lambda *args: None, 'name')
    scope_replacer.__setattr__('attr', 1)
    scope_replacer.__setattr__('attr2', 2)
    # Verify that the object is actually replaced after a method call
    assert scope['lazy_import'] != scope_replacer
    scope_replacer.__setattr__('attr', 3)
    scope_replacer.__setattr__('attr2', 4)
    assert scope['lazy_import'] != scope_replacer


# Generated at 2022-06-26 02:21:05.604786
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()

    a = "aa_%(b)sd"
    b = "b"
    z = IllegalUseOfScopeReplacer("zz", a % locals())

# Generated at 2022-06-26 02:21:17.099628
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Call function 'test_case_0' with arguments:
    test_case_0()


# Generated at 2022-06-26 02:21:23.104862
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import test_case_0
    try:
        test_case_0()
        assert 0, 'IllegalUseOfScopeReplacer not raised'
    except IllegalUseOfScopeReplacer as exc_info:
        expected_msg = "Object already replaced, did you assign it to another"\
            " variable?"
        assert exc_info.msg == expected_msg


# Generated at 2022-06-26 02:21:26.917948
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer("name", "msg", "extra")
    var_1 = str(var_0)
    var_2 = unicode(var_0)


# Generated at 2022-06-26 02:21:34.990685
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test case for IllegalUseOfScopeReplacer.__str__ method

    IllegalUseOfScopeReplacer.__str__(self)

    This test generates a IllegalUseOfScopeReplacer object,
    calls its __str__ method, and checks that the string it returns
    contains information about the exception.
    """
    exc = IllegalUseOfScopeReplacer('foo', 'bar')
    # This is just a minimal test, to verify that it doesn't crash
    assert 'bar' in str(exc)


# Generated at 2022-06-26 02:21:43.150412
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(name = "abcd", msg = None, extra = None)
    var_0.name = None
    var_0.msg = "abcd"
    var_0.extra = None
    assert var_0.__str__() == "Unprintable exception IllegalUseOfScopeReplacer: dict={'extra': None, 'name': None, 'msg': 'abcd'}, fmt=None, error=None"
    var_0.name = "abcd"
    var_0.msg = None
    var_0.extra = None
    assert var_0.__str__() == "Unprintable exception IllegalUseOfScopeReplacer: dict={'extra': None, 'name': 'abcd', 'msg': None}, fmt=None, error=None"
    assert var_0.__str__

# Generated at 2022-06-26 02:21:53.290162
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    x = ScopeReplacer(None, None, None)
    # Check for IllegalUseOfScopeReplacer
    try:
        x._resolve()
        assert False
    except IllegalUseOfScopeReplacer:
        pass
    # Check for TypeError
    try:
        ScopeReplacer._should_proxy = False
        d = ScopeReplacer(None, None, None)
        d._factory = None
        d._name = 'd'
        d._scope = {}
        d._real_obj = None
        d._scope[d._name] = d
        d._resolve()
        d.foo = 1
        assert False
    except TypeError:
        pass
    # Check for IllegalUseOfScopeReplacer

# Generated at 2022-06-26 02:21:55.434829
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    assert var_0 == 'qt_message_id_undefined'


# Generated at 2022-06-26 02:21:58.827481
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    r = ScopeReplacer({}, lambda *args: None, 'r')
    r._should_proxy = False
    r._resolve = lambda: r
    r_real_obj = r
    r.var0 = 0
    assert r.var0 == 0


# Generated at 2022-06-26 02:22:01.795810
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer("var_1", "var_2", "var_3")
    var_0.__unicode__()


# Generated at 2022-06-26 02:22:06.829548
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import bzrlib.errors as errors
    var_1 = lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        )
    ''')
    try:
        var_2 = ScopeReplacer._should_proxy
        try:
            test_case_0()
            var_3 = True
        except:
            var_3 = False
            raise

    finally:
        ScopeReplacer._should_proxy = var_2

    return int(var_3)



# Generated at 2022-06-26 02:22:24.579390
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    import sys
    sys.modules['test_lazy_import'] = sys.modules['__main__']
    try:
        var_1 = lazy_import.lazy_import(locals(), '''
from bzrlib import (
    errors,
    osutils,
    branch,
    )
import bzrlib.branch
''')
    finally:
        del sys.modules['test_lazy_import']
    var_2 = True
    var_3 = True
    if (var_1 != var_2):
        raise AssertionError("%(__file__)r, line %(lineno)r: %(__name__)r != %(__name__)r" % vars())
    if (var_1 != var_3):
        raise

# Generated at 2022-06-26 02:22:30.677901
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import, _lazy_import
    import bzrlib.errors
    _lazy_import(globals(), 'bzrlib.errors')
    lazy_import(globals(), 'bzrlib.errors')
    pass # FIXME


# Generated at 2022-06-26 02:22:31.194625
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exception = IllegalUseOfScopeReplacer()



# Generated at 2022-06-26 02:22:33.195259
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(), import_lazy_module, 'test_case_0')
    var_0()
    var_1 = ScopeReplacer(globals(), import_lazy_module, 'test_case_0')
    try:
        var_1()
        raise AssertionError()
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:22:37.760619
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer()
    var_1 = ValueError()
    try:
        var_0.__setattr__('_name', var_1)
    except:
        var_2 = sys.exc_info()[1]
        raise var_2


# Generated at 2022-06-26 02:22:45.673433
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    # test 0
    var_0 = IllegalUseOfScopeReplacer('LazyObject',
        'The $name property was used on a lazy loading object')
    var_1 = var_0._format()
    var_2 = var_1._get_format_string()
    try:
        var_3 = var_1._get_format_string()
    except Exception as var_3:
        pass
    var_4 = var_2 % {'name': 'LazyObject'}
    var_5 = var_0._format()
    try:
        var_6 = var_0._format()
    except Exception as var_6:
        pass

# Generated at 2022-06-26 02:22:49.426847
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    try:
        # TODO: how to test
        pass
    except Exception as e:
        raise TestNotApplicable('Exception in test: %s' % str(e))



# Generated at 2022-06-26 02:23:01.457135
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import test_case_0
    from bzrlib.trace import mutter

    # If a ScopeReplacer is used as a bound method it may get a __self__
    # attribute
    mutter('test_ScopeReplacer__setattr__: '
           'test case #1 - instance of ScopeReplacer as bound method')
    import cStringIO
    f = cStringIO.StringIO()

# Generated at 2022-06-26 02:23:09.393661
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import tests.blackbox.test_lazy_import as m_test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import as m_bzrlib_test_lazy_import
    # set up test - create ScopeReplacer object sr
    sr = ScopeReplacer(scope=sys.modules, name='bzrlib.tests.blackbox.test_lazy_import', factory=m_test_lazy_import.__getattribute__('create'))
    # assign to bzrlib.tests.blackbox.test_lazy_import
    sys.modules['bzrlib.tests.blackbox.test_lazy_import'] = sr
    # set sr._real_obj to m_bzrlib_test_lazy_import
    sr._real_

# Generated at 2022-06-26 02:23:20.796192
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.blackbox import TestCaseWithTransport

    class TestableScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            ScopeReplacer.__init__(self, scope, factory, name)

    class TestCase_test_ScopeReplacer___setattr__(TestCaseWithTransport):
        def test_0(self):
            scope = {}
            name = 'x'
            value = 'foo'
            TestableScopeReplacer._should_proxy = False
            sr = TestableScopeReplacer(scope, lambda *args: None, name)
            # call the test method
            try:
                sr.__setattr__(name, value)
            except IllegalUseOfScopeReplacer as e:
                # the specific exception we expect to catch
                pass

# Generated at 2022-06-26 02:23:30.724971
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    o = IllegalUseOfScopeReplacer(None, None, None)
    r = o.__str__()
    # Check that r is a 'str' object
    if not (isinstance(r, str)):
        raise AssertionError
    # Check that r is a 'str' object
    if not (isinstance(r, str)):
        raise AssertionError


# Generated at 2022-06-26 02:23:35.368450
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = ScopeReplacer(None, None, None)
    # Assert can find attribute: _real_obj
    var_0._real_obj
    # Assert can find attribute: _resolve
    var_0._resolve
    try:
        # Assert can get attribute: _should_proxy
        var_0._should_proxy
    except IllegalUseOfScopeReplacer as var_1:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-26 02:23:39.885083
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self) -> unicode

    Return a unicode representation of this exception.
    """
    try:
        var_0 = test_case_0()
        return True
    except:
        return False

_proxy_replacers = {}


# Generated at 2022-06-26 02:23:42.838663
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    foo = IllegalUseOfScopeReplacer('bar')
    foobar = foo.__unicode__()


# Generated at 2022-06-26 02:23:45.641731
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    a = IllegalUseOfScopeReplacer('a', 'b')
    u = a.__unicode__()


# Generated at 2022-06-26 02:23:57.119705
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib
    var_0 = ScopeReplacer
    try:
        var_0 = ScopeReplacer(
            {
                'bzrlib': None,
                'bzrlib.version_info': None,
                'bzrlib.version_info.__version__': None,
            }, lambda x1, x2, x3: __import__('bzrlib', globals(), locals(), ['__version__'], -1), 'bzrlib.version_info')
    except:
        var_0 = None
    var_1 = var_0
    if ((var_1 is not None) and hasattr(var_1, '__call__')):
        var_1 = var_1()
    var_2 = var_1

# Generated at 2022-06-26 02:24:04.066281
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase
    fake_modules = [
        'bzrlib.tests.blackbox.test_selftest.test_case_0',
        ]
    # Test that the method __call__ of class ScopeReplacer returns the right
    # type of object for the following cases:
    #     - when the object has not been created yet,
    #     - when the object has already been created, and
    #     - when the object has again been replaced by something else,
    #       with selftest.
    test_case = ExternalBase('selftest', fake_modules=fake_modules)
    test_case.run_bzr('selftest')
    return test_case.finish()


# Generated at 2022-06-26 02:24:13.911351
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """This test verifies that IllegalUseOfScopeReplacer(
    IllegalUseOfScopeReplacer) works."""
    try:
        new_var = test_case_0()
        new_var = IllegalUseOfScopeReplacer(new_var, new_var, new_var)
    except Exception as e:
        new_var = None
        new_var = e
        if new_var.__class__ is IllegalUseOfScopeReplacer:
            new_var = unicode(new_var)
            return new_var
        else:
            raise


# Generated at 2022-06-26 02:24:20.542414
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Test calls to '__getattribute__' of a ScopeReplacer object,
    # that have no return value.

    # Call the __getattribute__ method of a ScopeReplacer object,
    # with a variable length argument list.
    # No exception should be raised.
    # Note: the scope of this object is a dictionary object.
    try:
        test_case_0()
    except Exception:
        # We should not have any exceptions
        raise AssertionError



# Generated at 2022-06-26 02:24:21.443100
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()


# Generated at 2022-06-26 02:24:38.768346
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Unit test for method __str__ of class IllegalUseOfScopeReplacer
    import cStringIO
    import sys
    import unittest

    my_globals = globals()
    my_globals.update(locals())

    my_globals['__name__'] = 'bzrlib.tests.test_lazy_import.test_IllegalUseOfScopeReplacer___str__'
    my_globals['__file__'] = __file__


# Generated at 2022-06-26 02:24:41.380538
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    in_0 = IllegalUseOfScopeReplacer('var_0', 'var_1')
    out_0 = str(in_0)
    assert out_0


# Generated at 2022-06-26 02:24:42.344292
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()



# Generated at 2022-06-26 02:24:47.203065
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    w = IllegalUseOfScopeReplacer('_0', '_1', '_2')
    e = w._get_format_string()
    test_case_0()
    expected_value_0 = '_1: _2'
    actual_value_0 = str(w)
    assert actual_value_0 == expected_value_0
    assert e is not None


# Generated at 2022-06-26 02:24:56.933267
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    global var_0

# Generated at 2022-06-26 02:25:05.527365
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from unittest import TestCase
    import __builtin__
    test_case_0()
    class __extend__(TestCase):
        def __str__(self):
            return (super(TestCase, self).__str__())
    case_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    try:
        self.assertEqual(case_0.__str__(), 'name')
    except AssertionError:
        self.fail('Non-standard __str__ implementation')
    finally:
        case_0 = None


# Generated at 2022-06-26 02:25:08.154194
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    replacer = ScopeReplacer(scope, lambda self, scope, name: None, 'name')
    replacer.__setattr__('_real_obj', 'object')
    return replacer._real_obj


# Generated at 2022-06-26 02:25:11.094377
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()

_default_scope = {}


# Generated at 2022-06-26 02:25:21.472392
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """ScopeReplacer - Calling a function reference"""
    import bzrlib
    var_0 = ScopeReplacer(locals(),
                          lambda self, s, n: s['var_0'],
                          'var_0')
    if ((var_0.__class__ is not ScopeReplacer) and
        (var_0.__class__ is not bzrlib.lazy_import.ScopeReplacer)):
        raise ValueError('var_0.__class__ != ScopeReplacer: %s' % (
            var_0.__class__,))
    if not isinstance(var_0, bzrlib.lazy_import.ScopeReplacer):
        raise ValueError('isinstance(var_0, ScopeReplacer) is not True: %s' % (
            type(var_0),))
    var_

# Generated at 2022-06-26 02:25:26.595951
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    this_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')

    # Call the method
    var_0 = this_0.__str__()
    # Asserts
    # Check var_0 type
    assert isinstance(var_0, str)



# Generated at 2022-06-26 02:25:40.283698
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as e:
        assert isinstance(e, IllegalUseOfScopeReplacer)
        assert isinstance(e, Exception)
        assert isinstance(e.__dict__, dict)
        assert isinstance(e.__unicode__(), unicode)
        assert e.__unicode__() == u'disallow_proxying() cannot return a proxy'
        assert isinstance(e.__str__(), str)
    else:
        assert False, "expected IllegalUseOfScopeReplacer"
