

# Generated at 2022-06-26 02:16:03.180961
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.script import ScriptRunner
    import sys
    class TestException(Exception):
        _fmt = "TestException(%(msg)r)"

        def __init__(self, msg):
            # Provide a way to return a different message later.
            # This is a bit of a hack, but it is useful for some testing.
            self.original_msg = msg
            super(TestException, self).__init__()

    def func_0_factory(self, scope, name):
        """Factory to generate function that raises an exception."""
        def func_0(x):
            raise TestException(x)
        return func_0

    def func_1():
        """Function that uses global variable that should not be set yet."""

# Generated at 2022-06-26 02:16:08.116572
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exc = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(exc) == "ScopeReplacer object 'name' was used incorrectly: msg: extra"


# Generated at 2022-06-26 02:16:18.244642
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer

    To run this method on its own, use::

        python bzrlib/lazy_import.py test_IllegalUseOfScopeReplacer___str__

    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly: msg"
    assert unicode(e) == u"ScopeReplacer object 'name' was used incorrectly: msg"
    e = IllegalUseOfScopeReplacer('unicode\u1234name', 'unicode\u1234msg',
        extra=u'\u1234unicode\u1234')

# Generated at 2022-06-26 02:16:22.543175
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    g = {}
    l = locals()
    lazy_import(l, '''
    from bzrlib.lazy_import import ScopeReplacer
    ''')
    sr = ScopeReplacer(scope=g, factory=lambda s, l, n: 'factory', name='name')
    try:
        sr.x = False
        assert False
    except IllegalUseOfScopeReplacer:
        pass
    else:
        assert False


# Generated at 2022-06-26 02:16:26.132716
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    pass # TODO: implement this!


# Generated at 2022-06-26 02:16:31.666862
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        test_case_0()
    except Exception as e:
        u = e.__unicode__()
        if type(u) is not unicode:
            raise AssertionError('test_IllegalUseOfScopeReplacer___unicode__'
                                 ' failed, returned %s, expected %s' %
                                 (type(u), unicode))


# Generated at 2022-06-26 02:16:36.076783
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(lambda var_1, var_2, var_3, var_4: object, object, object)


# Generated at 2022-06-26 02:16:37.278556
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(None, None, '')
    var_0()


# Generated at 2022-06-26 02:16:45.025687
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test passing args and kwargs.
    def dummy(self, *args, **kwargs):
        self.args = list(args)
        self.kwargs = dict(kwargs)
    scope = {}
    lazy_obj = ScopeReplacer(scope, dummy, 'obj')
    arglist = ['a', 'b', 'c']
    argdict = {'a': 'A', 'b': 'B', 'c': 'C'}
    lazy_obj(*arglist, **argdict)
    assert scope['obj'].args == arglist
    assert scope['obj'].kwargs == argdict



# Generated at 2022-06-26 02:16:47.198841
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exception = IllegalUseOfScopeReplacer(None, None)



# Generated at 2022-06-26 02:16:57.117910
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(None, None, None)
    var_0._should_proxy = False
    with var_0.assertRaises(IllegalUseOfScopeReplacer) as ex_0:
        test_case_0()
    with var_0.assertSubstring("Object already replaced") as ex_0:
        test_case_0()


# Generated at 2022-06-26 02:17:02.868511
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    obj = IllegalUseOfScopeReplacer()
    # Call the method
    # test __unicode__ directly
    result = IllegalUseOfScopeReplacer.__unicode__(obj)
    # __unicode__ should return a unicode object
    assert isinstance(result, unicode)



# Generated at 2022-06-26 02:17:09.668889
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    # call the method
    var_0 = IllegalUseOfScopeReplacer('name','msg','extra')
    var_1 = var_0.__unicode__()

    # check var_1
    if var_1 != 'ScopeReplacer object \'name\' was used incorrectly: msg: extra':
        raise AssertionError("%r != 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'"
                             "\n    var_1: %r"
                             % (var_1, 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'))


# Generated at 2022-06-26 02:17:17.630490
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import disallow_proxying, lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.lazy_import import make_module_for_test
    import sys

    mod = make_module_for_test('mod')
    mod.func = lambda a,b,c: (a,b,c)
    fig = make_module_for_test('fig')
    fig.BAR = 42
    sys.modules['fig'] = fig

    # Test the two 'on first use' modes of lazy_import:
    # delayed import using 'from' syntax
    lazy_import(locals(), 'from mod import func')
    TestCase().assertIsInstance(func, ScopeReplacer)

# Generated at 2022-06-26 02:17:18.381319
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:17:23.266662
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Method __str__ of class IllegalUseOfScopeReplacer"""
    test_case_0()


# Generated at 2022-06-26 02:17:36.310296
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from test_lazy_import import Test_lazy_import
    # Run test with and without disallowing proxying
    # In the latter case this will raise IllegalUseOfScopeReplacer
    def run_test():
        globals()["bar"] = lambda: var_0
        test_obj = Test_lazy_import()
        try:
            test_obj.test_last_used_module()
        finally:
            del globals()["bar"]
    try:
        run_test()
    except IllegalUseOfScopeReplacer:
        # kludge to avoid triggering the error during the test
        reenable_proxying()
        run_test()
        disallow_proxying()



# Generated at 2022-06-26 02:17:48.630464
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer()
    var_1 = ArgumentError()
    var_2 = test_ScopeReplacer___call__.im_func.func_code
    var_3 = var_2.co_varnames
    var_4 = var_3[0:1]
    var_5 = var_2.co_argcount
    var_6 = var_2.co_consts
    var_7 = var_6[0]
    var_8 = var_6[1]
    var_9 = var_6[2]
    var_10 = var_6[3]
    var_11 = var_6[4]
    var_12 = var_6[5]
    var_13 = var_6[6]
    var_14 = var_6[7]

# Generated at 2022-06-26 02:17:54.059442
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(), lambda self, scope, name: None, 'var_0')
    var_0_1 = var_0()
    assert var_0_1 is None


# Generated at 2022-06-26 02:17:56.834456
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer()
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:18:09.318225
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('foo', 'bar', extra='qux')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'foo\' was used incorrectly: bar: qux'


# Generated at 2022-06-26 02:18:13.908281
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    case_0 = IllegalUseOfScopeReplacer(u'name_0', u'msg_0')
    try:
        var_0 = unicode(case_0)
    except Exception as var_1:
        var_0 = False
    return var_0


# Generated at 2022-06-26 02:18:18.010687
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import osutils
    ScopeReplacer._should_proxy = True
    var_0 = ScopeReplacer(locals(), osutils._modules_to_load_factory, 'osutils')
    var_1 = var_0()
    assert var_1 is osutils


# Generated at 2022-06-26 02:18:29.751433
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    global_scope = globals()
    name_0 = 'var_0'
    factory_0 = lambda self, scope, name: self
    var_0 = ScopeReplacer(global_scope, factory_0, name_0)
    try:
        disallow_proxying()
        var_0.__setattr__('_should_proxy', False)
        try:
            test_case_0()
        except IllegalUseOfScopeReplacer:
            pass
        else:
            raise AssertionError('IllegalUseOfScopeReplacer not raised')
    finally:
        var_0.__setattr__('_should_proxy', True)


# Generated at 2022-06-26 02:18:37.856491
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    r"""ScopeReplacer.__call__():

    This test covers the case where the object replaces itself as a
    result of a call to __call__. This is a very common occurrence, in
    particular with module classes.
    """
    scope = {}

    def factory(self, scope, name):
        from bzrlib.tests import TestUtil
        return TestUtil.TestUtil

    var_0 = ScopeReplacer(scope, factory, 'var_0')
    var_0 = var_0()
    var_1 = var_0()
    return var_1


# Generated at 2022-06-26 02:18:43.370566
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import os
    import shutil
    import tempfile
    try:
        tempfile.tempdir = None
        tmpdir = tempfile.mkdtemp()
        saved_dir = os.getcwd()
        os.chdir(tmpdir)
        try:
            os.mkdir('a')
            os.chdir('a')
            var_0 = osutils.mkdir_convenience('a/b')
        finally:
            os.chdir(saved_dir)
            shutil.rmtree(tmpdir)
    finally:
        tempfile.tempdir = None


# Generated at 2022-06-26 02:18:55.564543
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    from bzrlib.tests import TestCase, TestCaseWithTransport
    from bzrlib.transport import get_transport_from_path
    def _factory(replacer, scope, name):
        # factory that returns a ready to use transport object
        return get_transport_from_path(u".")
    lazy_import.lazy_import(locals(), '''
    from bzrlib.transport import get_transport_from_path
    ''')
    t = get_transport_from_path.__call__(u".")
    # make sure the lazy object is working,
    # that it's a ScopeReplacer object and that it's "callable"
    self.assertIsInstance(get_transport_from_path, ScopeReplacer)

# Generated at 2022-06-26 02:19:04.719632
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from _UserList import UserList
    from UserDict import UserDict
    from UserString import UserString
    from types import DictProxyType, InstanceType, MethodType, ModuleType

    for var_0 in (False, True):
        var_1 = ScopeReplacer(globals(), lambda self, scope, name: object(), 'test_ScopeReplacer___setattr__')
        var_1._should_proxy = var_0
        test_case_0()

        test_case_2()
        try:
            test_case_3()
        except TypeError:
            pass

        test_case_5()
        try:
            test_case_6()
        except TypeError:
            pass

        test_case_8()
        try:
            test_case_9()
        except TypeError:
            pass

# Generated at 2022-06-26 02:19:08.083457
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        var_0 = disallow_proxying()
    except:
        var_1 = IllegalUseOfScopeReplacer(
            "var_0",
            "disallowed proxying",
            None,
        )
        pass


# Generated at 2022-06-26 02:19:11.404714
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # XXX Implement an appropriate test case
    raise AssertionError('Test not implemented.')


# Generated at 2022-06-26 02:19:23.675365
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    def do_test(var_0):
        assert var_0.__class__ is IllegalUseOfScopeReplacer
        expected = 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'
        assert var_0.__unicode__() == expected

    test_case_0()
    do_test(var_0)


# Generated at 2022-06-26 02:19:25.752280
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    raise NotImplementedError(
        "Test for method IllegalUseOfScopeReplacer.__str__ not implemented")


# Generated at 2022-06-26 02:19:31.247434
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda self, scope, name: 'foo',
                                   'bar')
    try:
        # Try and set an attribute - it should fail.
        scope_replacer.a = 1
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('Expected IllegalUseOfScopeReplacer')


# Generated at 2022-06-26 02:19:40.984067
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = IllegalUseOfScopeReplacer(name = 'var_0', msg = 'var_1', extra = 'var_2')
    var_0 = 'Unprintable exception IllegalUseOfScopeReplacer: dict={\'msg\': \'var_1\', \'extra\': \'var_2\', \'name\': \'var_0\'}, fmt=\'ScopeReplacer object %(name)r was used incorrectly: %(msg)s%(extra)s\', error=<type \'exceptions.KeyError\'>'
    var_1 = case_0._format() # __str__ of IllegalUseOfScopeReplacer, line 112
    assert var_0 == var_1


# Generated at 2022-06-26 02:19:43.727263
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.trace import mutter
    from bzrlib.tests import TestCase
    # test for method __call__
    test_case_0()


# Generated at 2022-06-26 02:19:52.839631
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCaseInTempDir
    from bzrlib.tests.test_lazy_import import test_case_0
    from bzrlib import lazy_import
    lazy_import.lazy_import(globals(), """
    from bzrlib import tests
    from bzrlib.lazy_import import disallow_proxying
    """)

    # first use is successful
    test_case_0()                                          # okay
    # second use gives IllegalUseOfScopeReplacer
    raises(IllegalUseOfScopeReplacer,
           test_case_0)                                    # okay


# Generated at 2022-06-26 02:20:04.334833
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    f_0 = lambda: 0
    v_0 = ScopeReplacer({}, f_0, 0)
    assert f_0() == v_0()

    def f_1(s_0, s_1, s_2):
        return s_0

    v_1 = ScopeReplacer({}, f_1, 1)
    assert v_1 == f_1(v_1, None, None)

    # Test if an exception is thrown when proxying is disabled.
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as e_0:
        assert e_0.msg == "Object already replaced, did you assign it to another variable?"
        assert e_0.name == '1'
    else:
        assert False



# Generated at 2022-06-26 02:20:06.366810
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('lazy_import', "illegal")
    string_0 = str(var_0)


# Generated at 2022-06-26 02:20:10.937548
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_1 = ScopeReplacer({}, lambda: 0, 'a')
    var_2 = var_1
    try:
        var_1.size = 10
    except Exception as var_3:
        pass
    else:
        raise AssertionError
    return var_2


# Generated at 2022-06-26 02:20:14.178008
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrtools.lazy_import import ScopeReplacer
    var_0 = ScopeReplacer(None, None, None)
    var_1 = object()
    var_0.__setattr__('x', var_1)


# Generated at 2022-06-26 02:20:25.884666
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('x', 'y')
    var_1 = var_0.__str__()

# Generated at 2022-06-26 02:20:28.776281
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    sut = ScopeReplacer(None, None, None)
    if not (sut.__call__() == NotImplemented):
        raise AssertionError


# Generated at 2022-06-26 02:20:31.079715
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    test_case_0()


# Generated at 2022-06-26 02:20:32.101727
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()


# Generated at 2022-06-26 02:20:36.239528
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(None, None)
    var_0.test_attr = 'test_val'
    var_0.test_attr_2 = 'test_val_2'
    var_0._preformatted_string = 'string'


# Generated at 2022-06-26 02:20:37.563301
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    o = ScopeReplacer(None, None, None)



# Generated at 2022-06-26 02:20:38.507703
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()


# Generated at 2022-06-26 02:20:42.591855
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # test_case_0
    var_0 = IllegalUseOfScopeReplacer('a%c', 'b%(d)s', 'e')
    test_case_0()
    #assert_equals(expected, var_0.__str__())
    var_0.__str__()


# Generated at 2022-06-26 02:20:50.257764
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    r"""ScopeReplacer.__setattr__()

    ScopeReplacer is a class that provides delayed initialization of some
    objects.  It is used to ensure that the objects are only loaded when
    they are actually used.  In general, it is used to delay import of
    modules.  Usage looks like:

        from bzrlib.lazy_import import lazy_import
        lazy_import(globals(), '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                ui,
                )
        ''')

    Then, 'errors' and 'osutils' will exist as lazy-loaded objects in the
    current scope, which will be replaced with a real object on first use.
    """
    from bzrlib.tests import TestSkipped


# Generated at 2022-06-26 02:20:52.255441
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = test_case_0()
    str(case_0)


# Generated at 2022-06-26 02:21:03.377189
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(locals(), lambda self, scope, name: globals())
    var_0.__setattr__('_name', 'foo')
    var_0.__setattr__('_scope', locals())
    var_0.__setattr__('_factory', lambda self, scope, name: 'foo')


# Generated at 2022-06-26 02:21:10.861938
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case = ScopeReplacer('ScopeReplacer', '__getattribute__', 'test_case')
    var_0 = object.__class__.__getattribute__(test_case, '__getattribute__')(test_case, '_resolve')()
    var_1 = object.__getattribute__(var_0, '_scope')
    expected = var_1
    actual = 'ScopeReplacer'
    if (expected != actual):
        raise AssertionError("""Test with arguments: ('ScopeReplacer', '__getattribute__', 'test_case') failed: expected "%s", got "%s" """ % (expected, actual,))


# Generated at 2022-06-26 02:21:19.901463
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    # Test with simple positional arguments
    var_0 = ScopeReplacer(None, None, None)

# Generated at 2022-06-26 02:21:33.082396
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    # This will create a dictionary at runtime.
    scope_1 = {}
    name_2 = 'var_0'
    # This will create a class at runtime.
    factory_3 = lambda this, scope, name: this
    obj_0 = bzrlib.lazy_import.ScopeReplacer(scope_1, factory_3, name_2)
    value_0 = test_case_0()
    # The call to __call__ will cause the object to resolve and become the
    # result of the 'lambda' call above.
    value_1 = obj_0(value_0)
    # The object should be replaced in the scope.
    value_2 = scope_1[name_2]
    value_3 = obj_0 == value_2
    assert value_3



# Generated at 2022-06-26 02:21:41.898486
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from testresources import TestResourceManager
    from bzrlib.tests.blackbox import ExternalBase
    # Test the general case.
    blackbox = ExternalBase()
    ctx = TestResourceManager()
    blackbox.addCleanup(ctx.cleanup)
    with ctx.manager() as _:
        # value to be set
        value = None
        # attr to be set
        attr = None
        # expected result
        expected = None
        # actual result
        result = None
        # Test the specific case in which _setattr__ is called.
        value = None
        attr = None
        expected = None
        result = None
        # Test the behaviour of the tested method.
        value = None
        attr = None
        expected = None
        result = None
    # Test the general case.
    black

# Generated at 2022-06-26 02:21:45.005935
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    var_0 = IllegalUseOfScopeReplacer()
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:21:52.557222
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Import the module under test
    from bzrlib.lazy_import import ScopeReplacer
    # Setup the state needed for testing getattr
    replacer = ScopeReplacer.__new__(ScopeReplacer)
    replacer.__init__({'foo': 'bar'}, lambda self, scope, name: scope[name], 'foo')
    # Test accessing a known member.
    assert replacer.__getattribute__(replacer, 'foo') == 'bar'
    assert replacer.__getattribute__(replacer, 'foo') == 'bar'


# Generated at 2022-06-26 02:22:02.677492
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # FIXME: this test is bogus, as it doesn't actually check anything.
    #  the 'real_obj' is never used, and the 'obj' created by 'factory'
    #  is just turned into a lambda (i.e. it has no content at all).
    #  I think this test is just bogus anyway, as it makes no sense to
    #  call a function defined like:
    #     def foo(self, scope, name):
    #  from the scope where it's defined.  As there's no argument
    #  for 'scope', this will just result in exceptions.
    #  The __call__ method is tested indirectly via the test_case_0
    #  function.
    scope = {}
    name = 'foo'

    def factory(self, scope, name):
        return lambda: None
    obj = Scope

# Generated at 2022-06-26 02:22:10.037396
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # An instantiation of IllegalUseOfScopeReplacer with None passed in the
    # first parameter was missing an explicit return None. This has been
    # added. The tests are not able to make the missing explicit return None
    # actually happen.
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    a = IllegalUseOfScopeReplacer("var_0", "var_1")
    expected = "ScopeReplacer object 'var_0' was used incorrectly: var_1"
    actual = str(a)
    assert actual == expected, "'%s' != '%s'" % (actual, expected)
    actual = a._format()
    assert actual == expected, "'%s' != '%s'" % (actual, expected)


# Generated at 2022-06-26 02:22:15.062496
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    factory = lambda self, scope, name: scope[name]
    scope = {'name': None}
    name = 'name'
    replacer = ScopeReplacer(scope, factory, name)
    scope[name] = 10
    # __call__ should return the value in scope
    expected = 10
    observed = replacer()
    return observed == expected


# Generated at 2022-06-26 02:22:23.905252
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(), lambda o,s,n:None, 'None')
    if var_0() is not None:
        raise AssertionError



# Generated at 2022-06-26 02:22:33.636296
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_1 = IllegalUseOfScopeReplacer(u'name', u'msg', u'extra')
    assert isinstance(var_1, IllegalUseOfScopeReplacer)
    assert isinstance(var_1, Exception)
    assert var_1.name == 'name'
    assert var_1.msg == 'msg'
    assert var_1.extra == ': extra'
    var_2 = var_1.__str__()
    assert isinstance(var_2, str)
    assert var_2 == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'


# Generated at 2022-06-26 02:22:34.604408
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:22:44.473479
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()
    var_7 = object()
    var_8 = object()
    var_9 = object()
    var_10 = object()
    var_11 = object()
    var_12 = object()
    var_13 = object()
    var_14 = object()
    var_15 = object()
    # Set var_0 to the appropriate value here
    # Set var_1 to the appropriate value here
    # Set var_2 to the appropriate value here
    # Set var_3 to the appropriate value here
    # Set var_4 to the appropriate value here
    # Set var_5 to the appropriate value here

# Generated at 2022-06-26 02:22:47.126332
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = str(IllegalUseOfScopeReplacer('self.name', 'self.msg'))



# Generated at 2022-06-26 02:22:51.962471
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ of class IllegalUseOfScopeReplacer

    """
    assert unicode(IllegalUseOfScopeReplacer(None, None)) == \
        'Unprintable exception IllegalUseOfScopeReplacer: dict={}, ' \
        'fmt=None, error=None'


# Generated at 2022-06-26 02:22:55.532757
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() -> string

    Return printable representation
    """
    #FIXME: Add test here.
    #self.fail("Test if the testcase is working.")


# Generated at 2022-06-26 02:22:59.719529
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    o = ScopeReplacer({}, lambda self, scope, name: None, 'var_0')
    scope = {'var_0': 1}
    name = 'var_0'
    test_case_0(scope, name)


# Generated at 2022-06-26 02:23:08.279840
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import unittest
    import pytest
    # Non-str return value
    e = IllegalUseOfScopeReplacer('var_0', 'Illegal call to __call__')
    pytest.fail("Non-str return value")
    # Non-unicode return value
    e = IllegalUseOfScopeReplacer('var_0', 'Illegal call to __call__')
    pytest.fail("Non-unicode return value")
    # Overriden method, with preformatted string
    e = IllegalUseOfScopeReplacer('var_0', 'Illegal call to __call__')
    pytest.fail("Overriden method, with preformatted string")
    # Overriden method, with failing format string
    e = IllegalUseOfScopeReplacer('var_0', 'Illegal call to __call__')
    pytest.fail

# Generated at 2022-06-26 02:23:10.533488
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = test_case_0()


# Generated at 2022-06-26 02:23:24.281901
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    lazy_import_globals = { '__name__' : '__main__' }
    bzrlib.lazy_import.test_case_0()



# Generated at 2022-06-26 02:23:26.544394
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', (1, 2, 3))
    u = e.__str__()


# Generated at 2022-06-26 02:23:27.575257
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_1 = ScopeReplacer.__setattr__()


# Generated at 2022-06-26 02:23:28.552660
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    r = ScopeReplacer()


# Generated at 2022-06-26 02:23:35.943165
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    mock_self = Mock(name='mock_self')
    mock_attr = Mock(name='mock_attr')
    mock_value = Mock(name='mock_value')
    _mock_call = Mock(name='_mock_call')
    args = (mock_attr, mock_value)
    _mock_call.return_value = None
    with patch('bzrlib.lazy_import.ScopeReplacer._resolve', _mock_call):
        _real_ScopeReplacer___setattr__(mock_self, *args, **None)
        _mock_call.assert_called_with(mock_self)
        setattr(_mock_call.return_value, mock_attr, mock_value)



# Generated at 2022-06-26 02:23:44.627898
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests.test_lazy_import import LazyImportTestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer(1, 2)
    # The string representation should have the class name, and have the
    # instance values in a dictionary.
    LazyImportTestCase.assertEqualDiff(
        "IllegalUseOfScopeReplacer({'extra': '', 'name': 1, 'msg': 2})",
        str(e))


# Generated at 2022-06-26 02:23:48.297880
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    with TrySingleImport('bzrlib.lazy_import'):
        # Called with keyword arguments
        ScopeReplacer._should_proxy = True
        try:
            _ = test_case_0()
        finally:
            ScopeReplacer._should_proxy = False
        # Called with arguments
        ScopeReplacer._should_proxy = True
        try:
            _ = test_case_0()
        finally:
            ScopeReplacer._should_proxy = False
# -



# Generated at 2022-06-26 02:23:56.246388
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__(self) -> str

    Return a string containing a more detailed message than the
    exception message.
    """
    try:
        # test the error case:
        raise IllegalUseOfScopeReplacer('var_0', "disallowed usage")
    except Exception as e:
        s = str(e)
    def check(expected):
        assert str(e) == expected, '%r != %r'%(str(e),expected)
    check("var_0 was used incorrectly: disallowed usage")


# Generated at 2022-06-26 02:23:57.736178
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    pass # test case for method __getattribute__ of class ScopeReplacer



# Generated at 2022-06-26 02:24:01.214703
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    global var_0
    def factory(self, scope, name):
        return real_obj_0
    r = ScopeReplacer(var_0, factory, 'var_0')
    # Valid method call
    r.__setattr__('foo', 'bar')


# Generated at 2022-06-26 02:24:12.794811
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    ScopeReplacer._should_proxy = False
    try:
        lazy_import(globals(), '''
from bzrlib.tests import test_case_0
''')
        test_case_0()
    finally:
        ScopeReplacer._should_proxy = True



# Generated at 2022-06-26 02:24:14.783210
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as e:
        s = str(e)
    else:
        assert False, "Failed to raise IllegalUseOfScopeReplacer"



# Generated at 2022-06-26 02:24:23.148072
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    r1 = ScopeReplacer(globals(), lambda self, scope, name: self, 'var_0')
    r1.__setattr__('_name', 'var_1')
    ScopeReplacer._should_proxy = True
    test_case_0()

# Generated at 2022-06-26 02:24:29.454730
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of ScopeReplacer must raise exception to prevent
    variable reassignment and to document that variable should not
    be assigned."""
    var_0 = ScopeReplacer({}, None, None)
    try:
        var_0.__setattr__('foo', None)
        raise AssertionError
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:24:32.149472
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""


# Generated at 2022-06-26 02:24:34.698538
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import (
        ScopeReplacer,
        lazy_import,
        )
    test_case_0()


# Generated at 2022-06-26 02:24:44.813303
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__
    Method on ScopeReplacer class for variables in modules that
    lazy_import assigns to.

    This test case tests that when a variable has been replaced in the
    module, it is not possible to set attributes on a variable that
    has been assigned to other variables.
    """

    import module_0
    assert module_0.var_0.__class__.__name__ == 'ScopeReplacer', \
        'incorrect class type %r' % module_0.var_0.__class__.__name__
    assert module_0.var_0._resolve().__class__.__name__ == 'LazyModule', \
        'incorrect class type %r' % module_0.var_0.__class__.__name__

# Generated at 2022-06-26 02:24:48.359210
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    name = 'name'
    msg = 'msg'
    extra = 'extra'
    var_0 = IllegalUseOfScopeReplacer(name, msg, extra)
    var_1 = str(var_0)

# Class TraceableIlllegalUseOfScopeReplacer

# Generated at 2022-06-26 02:24:59.865764
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests import TestCase

    class TestIllegalUseOfScopeReplacerBase(TestCase):

        def test_unicode_default(self):
            e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
            u = u'ScopeReplacer object name was used incorrectly: msg: extra'
            self.assertIsInstance(e.__unicode__(), unicode)
            self.assertEqual(e.__unicode__(), u)

    # test with a format string
    class TestIllegalUseOfScopeReplacer(TestIllegalUseOfScopeReplacerBase):

        def setUp(self):
            super(TestIllegalUseOfScopeReplacer, self).setUp()
            self._old_fmt = IllegalUseOfScopeReplacer._fmt

# Generated at 2022-06-26 02:25:05.301778
# Unit test for method __str__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-26 02:25:21.983784
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import per_interpreter

    @per_interpreter
    def test_ScopeReplacer___call___interpreter():
        import bzrlib
        var_0 = bzrlib.lazy_import
        var_0 = var_0.ScopeReplacer
        var_0 = var_0._should_proxy
        var_0 = None
        var_0 = bzrlib.lazy_import
        var_0 = var_0.ScopeReplacer
        var_0 = var_0._should_proxy
        var_0 = False
        var_0 = bzrlib.lazy_import
        var_0 = var_0.ScopeReplacer
        var_0 = var_0._should_proxy
        var_0 = True
        var_0 = None
        var

# Generated at 2022-06-26 02:25:28.736222
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Check that we get an AttributeError when we try to access an
    # attribute on a ScopeReplacer with _should_proxy set to false.
    disallow_proxying()
    try:
        var_0 = ScopeReplacer({}, lambda x,y,z: x, "var_0")
        var_0.alpha
        raise AssertionError("should have raised AttributeError")
    except AttributeError:
        pass
    allow_proxying()
