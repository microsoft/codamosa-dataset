

# Generated at 2022-06-26 02:16:03.909027
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Create instance
    var_0 = IllegalUseOfScopeReplacer('string1', 'string1')
    # Call to __str__
    var_1 = var_0.__str__()
    # assertIsInstance
    try:
        assertIsInstance(var_1, str)
    except AssertionError as e:
        raise AssertionError(str(e) + "\n  Actual type: " +
                             str(type(var_1)))
    # compare
    try:
        assert var_1 == 'IllegalUseOfScopeReplacer object \'string1\' was used incorrectly: string1'
    except AssertionError as e:
        raise AssertionError(str(e) +
                             "\n  Actual: " + str(var_1))


# Generated at 2022-06-26 02:16:08.259119
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__

    Returns unicode(self)
    """
    _test_IllegalUseOfScopeReplacer___unicode__()


# Generated at 2022-06-26 02:16:09.483665
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()


# Generated at 2022-06-26 02:16:18.652035
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__()

    Test method __setattr__ of class ScopeReplacer.
    """
    from bzrlib import lazy_import
    # Here we call the _setUp method.
    lazy_import._setUp()
    try:
        # Call the function.
        test_case_0()
    finally:
        # Finally, we call the _tearDown method.
        lazy_import._tearDown()



# Generated at 2022-06-26 02:16:20.784883
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    obj = IllegalUseOfScopeReplacer(name = None, msg = None)
    obj2 = IllegalUseOfScopeReplacer(name = None, msg = None)
    obj3 = IllegalUseOfScopeReplacer(name = None, msg = None)


# Generated at 2022-06-26 02:16:26.608700
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    value = "value"
    name = "name"
    msg = "msg"
    extra = "extra"
    obj = IllegalUseOfScopeReplacer(name, msg, extra)
    res = obj.__str__()



# Generated at 2022-06-26 02:16:29.371352
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:16:32.456974
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer("name", "message", "extra")
    expected = 'IllegalUseOfScopeReplacer("name", "message", "extra")'
    actual = str(e)
    assert actual == expected, \
        "Method __unicode__ of class IllegalUseOfScopeReplacer returned %s, expected %s" % (actual, expected)


# Generated at 2022-06-26 02:16:39.338924
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Constructor test
    var_1 = ScopeReplacer
    var_2 = {}
    var_3 = lambda:None
    var_4 = ''
    var_1 = ScopeReplacer(var_2, var_3, var_4)


# Generated at 2022-06-26 02:16:40.836078
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()



# Generated at 2022-06-26 02:16:55.421613
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import StringIO
    f = StringIO.StringIO()
    def stub_self():
        return NotImplemented
    IllegalUseOfScopeReplacer._fmt = '%(name)s'
    # __unicode__ should write str to f
    IllegalUseOfScopeReplacer.__unicode__(stub_self(), f)
    if f.getvalue() != "NotImplemented":
        raise AssertionError()
    f.close()


# Generated at 2022-06-26 02:16:56.924668
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    raise NotImplementedError



# Generated at 2022-06-26 02:17:03.203097
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Unit test for method __str__ of class IllegalUseOfScopeReplacer
    # Called on a proxy object raises an exception
    assert_raises_regex(
        IllegalUseOfScopeReplacer,
        'ScopeReplacer .*unavailable.*',
        test_case_0)


# Generated at 2022-06-26 02:17:07.735230
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # TestCase_0
    var_0 = disallow_proxying()
    try:
        var_1 = ScopeReplacer
        var_2 = test_case_0()
    except IllegalUseOfScopeReplacer:
        var_3 = True
    else:
        var_3 = False
    var_4 = var_3
    assert var_4


# Generated at 2022-06-26 02:17:10.370721
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # __str__ must return a str.
    another_var = str(disallow_proxying())


# Generated at 2022-06-26 02:17:13.128778
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'message')
    var_1 = str(var_0)


# Generated at 2022-06-26 02:17:25.236967
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import

    # Fix the scope
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    # Run the function being tested
    try:
        bzrlib.lazy_import.test_case_0()
    except bzrlib.lazy_import.IllegalUseOfScopeReplacer as e:
        # Check the type of the exception raised
        if e.name != 'var_0':
            raise AssertionError("expected: %s got: %s" % ('var_0', e.name))
        if e.msg != "Object already replaced, did you assign it to another variable?":
            raise AssertionError("expected: %s got: %s" % ("Object already replaced, did you assign it to another variable?", e.msg))

# Generated at 2022-06-26 02:17:26.282320
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    pass

# Generated at 2022-06-26 02:17:29.698057
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # This function tests the IllegalUseOfScopeReplacer.__unicode__() method.
    test_case_0()



# Generated at 2022-06-26 02:17:39.141907
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test for method __call__ of class ScopeReplacer
    # You should only call this method once.
    # Calling it twice will result in an IllegalUseOfScopeReplacer.
    # This can be used for objects that are intialized the first time
    # they are called.
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as e:
        assert e.extra == ''
        assert e.msg == 'Object already replaced, did you assign it' \
                        ' to another variable?'
        assert e.name == 'var_0'
    except Exception as e:
        raise AssertionError("Unexpected exception raised: %r" % (e,))
    else:
        raise AssertionError("IllegalUseOfScopeReplacer not raised")



# Generated at 2022-06-26 02:17:50.097004
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Implement your test here
    raise Exception("Test not implemented")


# Generated at 2022-06-26 02:17:55.373665
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'message')
    # Convert to unicode and back to string to check that
    # the utf8 encoding takes place.
    str(unicode(e))


# Generated at 2022-06-26 02:17:57.180432
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    u = IllegalUseOfScopeReplacer(1, "2", 3)

    test_case_0()



# Generated at 2022-06-26 02:18:04.462820
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    cases = [
        # Check that getting attributes works before the object is resolved.
        (test_case_0, 'var_0', 'var_0'),
    ]
    test_cases = build_test_cases(ScopeReplacer, '__getattribute__', cases)
    run_test_cases(test_cases)


# Generated at 2022-06-26 02:18:07.753712
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    name = "var_0"
    msg = "var_1"
    extra = "var_2"
    expected_value = "var_3"
    obj = IllegalUseOfScopeReplacer(name, msg, extra)
    if obj.__str__() != expected_value:
        raise AssertionError


# Generated at 2022-06-26 02:18:13.185902
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """test_ScopeReplacer___getattribute__

    See http://bazaar-vcs.org/bzrlib/selftest/test_lazy_import.txt
    """
    from bzrlib import tests
    v = tests.TestCaseWithMemoryTransport.test_case_0

# Generated at 2022-06-26 02:18:17.133454
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case = ScopeReplacer(__builtins__, __builtins__['object'], 'ScopeReplacer')
    try:
        disallow_proxying()
        test_case_0()
    finally:
        allow_proxying()


# Generated at 2022-06-26 02:18:29.959139
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.features import (Feature, 
        _standard_feature_set, 
        _FeatureTestCase, 
        )
    f = Feature("ScopeReplacer___call__")
    _standard_feature_set.add_feature(f)
    _standard_feature_set.require_feature(f)
    from bzrlib.lazy_import import (ScopeReplacer, 
        )
    from bzrlib import (tests, 
        )
    import __builtin__
    def func1():
        class __ScopeReplacer(ScopeReplacer):

            def __call__(self, *args, **kwargs):
                globals()["kwargs"] = kwargs
                globals()["args"] = args
                obj = object.__getattribute__(self, '_resolve')()

# Generated at 2022-06-26 02:18:34.292023
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    instance = IllegalUseOfScopeReplacer('name', 'msg')
    assert(instance.__unicode__() == u'name was used incorrectly: msg')


# Generated at 2022-06-26 02:18:39.966385
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = ScopeReplacer(scope=globals(), factory=None, name='var_0')
    var_1 = var_0.__getattribute__(attr=None)
    var_2 = var_0._resolve()
    var_3 = var_0.__getattribute__(attr=None)
    var_4 = ScopeReplacer._should_proxy
    var_0._should_proxy = None
    var_5 = var_0._resolve()
    raise TokenEndOfTestCase()


# Generated at 2022-06-26 02:18:52.996628
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    global var_0
    var_0 = ScopeReplacer(locals(), _factory, 'var_0')


# Generated at 2022-06-26 02:19:02.788538
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import StringIO
    out = StringIO.StringIO()
    # Call method __call__ of ScopeReplacer
    import bzrlib.tests.blackbox.test_selftest
    try:
        var_0 = test_case_0(bzrlib.tests.blackbox.test_selftest, out)
    except IllegalUseOfScopeReplacer as e:
        import bzrlib.tests.blackbox.test_selftest
        bzrlib.tests.blackbox.test_selftest.assertEqual('IllegalUseOfScopeReplacer("ModuleVariableNotFound",'
            ' "Object already replaced, did you assign it"\n                          " to another variable?")',
            repr(e))
    else:
        import bzrlib.tests.blackbox.test_selftest
        b

# Generated at 2022-06-26 02:19:06.743473
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        test_case_0()
    except Exception as exc_0:
        pass
    msg_0 = 'foo bar baz'
    var_0 = IllegalUseOfScopeReplacer('1', msg_0)
    var_1 = var_0.__unicode__()

test_IllegalUseOfScopeReplacer___unicode__()



# Generated at 2022-06-26 02:19:12.243042
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(dict(), test_case_0, 'var_0')

# Generated at 2022-06-26 02:19:22.470246
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer
    builtin_0 = _builtin__['object']
    str_0 = '_ScopeReplacer__setattr__'
    var_1 = hasattr(var_0, str_0)
    Assert(var_1)
    var_2 = getattr(var_0, str_0)
    var_3 = hasattr(var_2, 'im_func')
    Assert(var_3)
    var_4 = getattr(var_2, 'im_func')
    var_5 = hasattr(builtin_0, str_0)
    Assert(var_5)
    var_6 = getattr(builtin_0, str_0)
    var_7 = hasattr(var_6, 'im_func')
    Assert(var_7)


# Generated at 2022-06-26 02:19:24.305368
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer("name", "msg")
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:19:25.083282
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # Not implemented


# Generated at 2022-06-26 02:19:27.777109
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    expect_str = "IllegalUseOfScopeReplacer(name, msg)"
    actual_str = repr(var_0)
    actual_str = str(var_0)
    assert(expect_str == actual_str)



# Generated at 2022-06-26 02:19:29.174638
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # implemented in module lazy_import.py




# Generated at 2022-06-26 02:19:30.921927
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer()


# Generated at 2022-06-26 02:19:40.603366
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = disallow_proxying()


# Generated at 2022-06-26 02:19:45.879045
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    expected = '\u0fff' # 'U+0fff'
    var_0 = IllegalUseOfScopeReplacer(u'foo', u'bar')
    var_0._preformatted_string = u'\u0fff'
    var_1 = var_0.__unicode__()
    if (var_1 != expected):
        raise AssertionError(var_1)


# Generated at 2022-06-26 02:19:51.214801
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__ must raise an exception if proxying is disabled and
    # the object has already been resolved.
    global var_0
    var_0 = scope_replacer(0)
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError('https://bugs.launchpad.net/bzr/+bug/718563')



# Generated at 2022-06-26 02:19:54.327465
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    this_0 = ScopeReplacer.__new__(ScopeReplacer)
    xxx_todo_changeme(0, ScopeReplacer.__init__(this_0, {}, lambda: None, ''))
    var_1 = this_0.__call__('', '', '', '')



# Generated at 2022-06-26 02:20:00.252119
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    # set up
    global var_0
    try:
        var_0
    except NameError:
        var_0 = None
    if var_0 is None:
        test_case_0()
    # run test
    var_0()


# Generated at 2022-06-26 02:20:10.892317
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    var_0 = lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    var_1 = disallow_proxying()
    var_2 = errors
    var_3 = errors

    def test_case_0():
        var_4 = AttributeError
        var_5 = IllegalUseOfScopeReplacer
        var_6 = False
        try:
            var_2.NotImplemented = var_6
        except var_4:
            var_7 = False
        else:
            var_7 = True
        var_8 = (var_5._fmt == var_2._fmt)

# Generated at 2022-06-26 02:20:13.731715
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('arg_0', 'arg_1')
    var_1 = str(var_0)
    assert(isinstance(var_1, str))


# Generated at 2022-06-26 02:20:18.719225
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # from bzrlib.tests import test_scope_replacer
    # from bzrlib.lazy_import import ScopeReplacer
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda self, scope, name: object(), "var_0")
    scope_replacer.__setattr__("_should_proxy", True)
    def test_case_0():
        var_0 = disallow_proxying()
    test_case_0()


# Generated at 2022-06-26 02:20:20.502066
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case = IllegalUseOfScopeReplacer('lazy_import', 'some description')



# Generated at 2022-06-26 02:20:27.595148
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Tests that assigning a ScopeReplacer object to another variable
    # is disallowed if _should_proxy is False.
    scope = {'var_0': ScopeReplacer(scope=None,factory=None,name='var_0')}
    proxy = scope['var_0']
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as error_msg:
        return True
    return False


# Generated at 2022-06-26 02:20:43.182167
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    msg = 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'
    assert(str(e) == msg)


# Generated at 2022-06-26 02:20:44.553008
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    obj = ScopeReplacer()
    with ExpectedException(AttributeError):
        obj.attribute
# vim: set fileencoding=utf-8 :

# Generated at 2022-06-26 02:20:46.463327
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(
        dict(),
        lambda this, scope, name: None,
        'name'
        )
    # No exception


# Generated at 2022-06-26 02:20:56.341174
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """ScopeReplacer.__setattr__

    Called when a scope-replaced object is set as an object attribute.
    This method should ensure the object is resolved, and then set the
    attribute on the resolved object.
    """
    __tracebackhide__ = True
    # Would be better to use a mock object here, but the builtin Mock
    # class refuses to be set as a class attribute and getattr is not
    # useful for our purposes either.
    class mock_type(object):
        pass
    scope_replacer = ScopeReplacer({}, lambda self, scope, name: mock_type(),
        "scope_replacer")
    scope_replacer.foo = None
    # ensure the object was resolved
    assert isinstance(scope_replacer, mock_type)
    # ensure the attribute was set on the resolved object
    assert hasattr

# Generated at 2022-06-26 02:21:07.380451
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tweak import TweakManager

    def add_4(replacer, scope, name):
        return 4

    class TestResolve(TestCase):

        def setUp(self):
            TestCase.setUp(self)
            self.locals = {}
            self.replacer = ScopeReplacer(self.locals, add_4, 'add_4')

        def test_resolve(self):
            self.assertEqual(self.replacer(), 4)

    def test_suite():
        from unittest import TestSuite
        suite = TestSuite()
        import bzrlib.tests

# Generated at 2022-06-26 02:21:10.754426
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    example = IllegalUseOfScopeReplacer("examplar", "msg")
    expected = "msg"
    actual = example.__unicode__()
    assert actual == expected, "__unicode__() returned '%(actual)s' instead of '%(expected)s'" % vars()


# Generated at 2022-06-26 02:21:16.076873
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        var_0 = ScopeReplacer({}, None, 'foo')
        var_0 = var_1 = var_0 = disallow_proxying()
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:21:18.429275
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    bzrlib.tests.load_tests.load_tests(globals())


# Generated at 2022-06-26 02:21:28.545218
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    global __test_0_var_0, __test_0_var_1, __test_0_var_2, __test_0_var_3
    __test_0_var_0 = ScopeReplacer({}, lambda self, scope, name: self, 'var_0')
    __test_0_var_1 = ScopeReplacer({}, lambda self, scope, name: self, 'var_1')
    __test_0_var_2 = ScopeReplacer({}, lambda self, scope, name: self, 'var_2')
    __test_0_var_3 = ScopeReplacer({}, lambda self, scope, name: self, 'var_3')


# Generated at 2022-06-26 02:21:33.347556
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        var_0 = IllegalUseOfScopeReplacer(None, None)
    except Exception as e:
        var_0 = e
    assert isinstance(var_0, IllegalUseOfScopeReplacer)


# Generated at 2022-06-26 02:22:27.972573
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self) -> unicode"""
    var_2 = disallow_proxying()
    var_1 = var_2._format()
    var_4 = 1
    var_5 = 0
    var_6 = 'Unprintable exception IllegalUseOfScopeReplacer: dict=%r, fmt=%r, error=%r'
    var_7 = 'Unprintable exception IllegalUseOfScopeReplacer: dict=%r, fmt=%r, error=%r'
    var_8 = 'Unprintable exception IllegalUseOfScopeReplacer: dict=%r, fmt=%r, error=%r'

# Generated at 2022-06-26 02:22:30.614970
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name','msg','extra')
    return


# Generated at 2022-06-26 02:22:41.529067
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import

    def test_fac():
        return 'test-fac'
    scope = {}
    scope_replacer = lazy_import.ScopeReplacer(scope, test_fac, 'test')
    scope_replacer.__setattr__('test', 'test-value')
    calls = []
    class TestCase(lazy_import.TestCase):
        def test_0(self):
            self.assertEqual(scope['test'], 'test-value')
            calls.append(scope['test'])
        def test_1(self):
            self.assertEqual(scope['test'], 'test-value')
            calls.append(scope['test'])
    case = TestCase('test_0')
    case.run()

# Generated at 2022-06-26 02:22:53.992918
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    assertEqual = _mod_testing.TestCase.assertEqual
    assertRaises = _mod_testing.TestCase.assertRaises
    assertTrue = _mod_testing.TestCase.assertTrue
    evaluate_result = _mod_testing.TestCase.assertFalse
    evaluate_result = _mod_testing.TestCase.assertFalse
    evaluate_stderr = _mod_testing.TestCase.assertRaises
    exc_info = _mod_testing.TestCase.failUnlessRaises
    failUnlessEqual = _mod_testing.TestCase.failUnlessEqual
    failUnlessRaises = _mod_testing.TestCase.failUnlessRaises
    import_module = _mod_testing.TestCase.import_module
    lazy_import = _mod_testing.TestCase.lazy_import
    run_bzr = _

# Generated at 2022-06-26 02:22:57.952939
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # No exception raised.
    obj_0 = IllegalUseOfScopeReplacer('val_0', 'val_1', 'val_2')
    obj_0._preformatted_string = 'foo'
    val_0 = obj_0.__unicode__()
    # No exception raised.
    obj_0._preformatted_string = 'foo'
    val_1 = obj_0.__unicode__()
    # No exception raised.
    obj_0._preformatted_string = 'foo'
    val_2 = obj_0.__unicode__()
    # No exception raised.
    obj_0._preformatted_string = 'foo'
    val_3 = obj_0.__unicode__()


# Generated at 2022-06-26 02:23:02.836226
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(globals(), 0, 'var_0')
    def test_se():
        try:
            var_0.__setattr__('var_2', 0)
        except IllegalUseOfScopeReplacer:
            return 0
        else:
            return 1
    var_1 = test_se()
    return var_1


# Generated at 2022-06-26 02:23:04.576995
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    assert_raises(IllegalUseOfScopeReplacer, test_case_0)


# Generated at 2022-06-26 02:23:11.222279
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test __str__"""
    import bzrlib.tests.blackbox.test_copydir as _test_copydir
    check_0 = test_case_0()
    test_utils_0 = _test_copydir.to_workspace('./')
    var_1 = test_utils_0.build_tree_contents([('./',), ('./foo/',), ('./foo/a', '1\n')])
    check_1 = test_utils_0.build_tree(var_1)
    # Build a simple tree in a temporary directory
    var_2 = test_utils_0.get_transport('.')
    var_3 = var_2.relpath('foo')
    var_4 = var_2.relpath('./foo/a')
    # Copy

# Generated at 2022-06-26 02:23:12.346656
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import warnings
    warnings.warn('TODO, not yet implemented',
                  category=DeprecationWarning,
                  stacklevel=2)


# Generated at 2022-06-26 02:23:19.407840
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('foo', 'bar')
    var_1 = 'foo'
    var_2 = 'bar'
    var_3 = 'IllegalUseOfScopeReplacer("%(name)s", "%(msg)s", extra=%(extra)r)' % {'msg': var_2, 'extra': '', 'name': var_1}
    test_case_0(var_0, var_1, var_2, var_3)


# Generated at 2022-06-26 02:24:21.005620
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # The __str__ method of IllegalUseOfScopeReplacer should return the same
    # string as the __unicode__ method.
    f = IllegalUseOfScopeReplacer
    e1 = f('name_0', 'msg_0')
    # Check that the __str__ method returns a string.
    try:
        __str__ = str(e1)
    except Exception as e:
        raise AssertionError(e)

    # Check that the __unicode__ method returns a unicode string.
    try:
        __unicode__ = unicode(e1)
    except Exception as e:
        raise AssertionError(e)
    # Check that the strings returned by __str__ and __unicode__ are the same.
    assert __str__ == __unicode__


# Generated at 2022-06-26 02:24:24.846765
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(None, None, None)
    var_0.__setattr__('_real_obj', None)
    var_0.__setattr__('_name', None)
    var_0.__setattr__('_real_obj', None)
    var_0.__setattr__('_name', None)


# Generated at 2022-06-26 02:24:32.099048
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('foo', 'bar')
    var_0._fmt = '%(name)r %(msg)r'
    var_0._preformatted_string = ''
    # testing method __unicode__
    var_1 = var_0.__unicode__()
    return var_1


# Generated at 2022-06-26 02:24:35.651254
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ of class IllegalUseOfScopeReplacer"""
    # XXX: Not sure if I should just call the method and check that it
    # runs without crashing, or if I should test the return value
    pass


# Generated at 2022-06-26 02:24:40.318451
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.scope import GlobalScope
    global_scope = GlobalScope()
    global_scope['ScopeReplacer'] = ScopeReplacer
    global_scope['disallow_proxying'] = disallow_proxying
    test_case_0()

__all__ = [
    'ScopeReplacer',
    ]


# Generated at 2022-06-26 02:24:47.701993
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__ is the method called by default when doing instance.attr = val
    # http://docs.python.org/reference/datamodel.html#object.__setattr__
    var_1 = 17
    var_2 = var_1
    # Statement truncated
    """
    Check that we raise when trying to setattr var_1
    """
    var_3 = IllegalUseOfScopeReplacer('var_1', 'Object tried to replace'
        ' itself, check it\'s not using its own scope.')
    try:
        # test control block
        # put value in var_1
        return assertRaises(IllegalUseOfScopeReplacer, var_1.__setattr__,
            '_real_obj', var_2)
    except IllegalUseOfScopeReplacer:
        pass

# Unit test

# Generated at 2022-06-26 02:24:54.160331
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        # ScopeReplacer_isinstance__lzyobj_22329936
        inst_0 = ScopeReplacer(globals(), lambda self, scope, name: object(), 'var_0')
    except:
        inst_0 = None
    if inst_0:
        var_0 = inst_0
    if inst_0:
        inst_0.illegal_use = 1
    if inst_0:
        var_0 = inst_0
    var_0.illegal_use = 1


# Generated at 2022-06-26 02:25:02.294232
# Unit test for method __call__ of class ScopeReplacer

# Generated at 2022-06-26 02:25:04.082284
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Testing method __setattr__ of class ScopeReplacer"""
    raise NotImplementedError



# Generated at 2022-06-26 02:25:05.748194
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Method calls tested:
    # __setattr__
    test_case_0()
