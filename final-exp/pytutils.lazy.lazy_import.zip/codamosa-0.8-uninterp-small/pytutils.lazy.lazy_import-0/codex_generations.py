

# Generated at 2022-06-26 02:16:07.562944
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(u'foo', u'bar')
    # test return value type
    assert isinstance(var_0.__unicode__(), unicode), var_0.__unicode__()
    # test return value contents
    assert var_0.__unicode__() == 'bar', var_0.__unicode__()



# Generated at 2022-06-26 02:16:19.928108
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_1 = ScopeReplacer(globals(), lambda self, scope, name: None, 'var_1')
    assert var_1.__getattribute__('_real_obj') is None
    assert var_1.__getattribute__('_factory') is not None
    assert var_1.__getattribute__('_name') is not None
    assert var_1.__getattribute__('_scope') is not None
    var_1.__setattr__('_real_obj', 'foo')
    assert var_1.__getattribute__('_real_obj') == 'foo'
    assert var_1.__getattribute__('_factory') is not None
    assert var_1.__getattribute__('_name') is not None
    assert var_1.__getattribute__('_scope') is not None

#

# Generated at 2022-06-26 02:16:27.466327
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(u'illegal_0', u'msg_0')
    assert isinstance(var_0, IllegalUseOfScopeReplacer)
    var_1 = var_0.__str__()
    assert isinstance(var_1, str)


# Generated at 2022-06-26 02:16:29.542954
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = IllegalUseOfScopeReplacer(None, None)




# Generated at 2022-06-26 02:16:33.164595
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer({}, None, None)
    ScopeReplacer._should_proxy = False
    var_0._resolve = lambda: None
    try:
        var_0.a = None
        test_case_0()
        unexpected = True
    except IllegalUseOfScopeReplacer:
        unexpected = False
    if unexpected:
        raise AssertionError("unexpected")

# Unit test of method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-26 02:16:42.300305
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() -> unicode"""
    var_0 = IllegalUseOfScopeReplacer('var_0', 'var_1')
    var_1 = unicode(var_0)
    var_2 = IllegalUseOfScopeReplacer('var_2', 'var_3', 'var_4')
    var_3 = unicode(var_2)
    return var_1, var_3


# Generated at 2022-06-26 02:16:55.559099
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            try:
                var_0 = test_case_0()
            except:
                err = sys.exc_info()[1]
                self.assert_(isinstance(err, IllegalUseOfScopeReplacer), (
                             'illegal exception: %r' % (err,)))
                self.assertEqual([err.name, err.msg, err.extra], [
                 'var_0', 'disallow_proxying()', ''])
            else:
                self.fail("Did not get expected exception.")
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Test))
    unittest.TextTestRunner(verbosity=2).run(suite)


# Unit

# Generated at 2022-06-26 02:17:00.256894
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test IllegalUseOfScopeReplacer.__unicode__()"""
    # FIXME: add tests for IllegalUseOfScopeReplacer.__unicode__
    raise TestSkipped('Test not written')


# Generated at 2022-06-26 02:17:07.469653
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from cStringIO import StringIO
    out = StringIO()

    x = IllegalUseOfScopeReplacer(
        'a', 'b',
        )
    expected = "Unprintable exception IllegalUseOfScopeReplacer: " \
        "dict={'name': 'a', 'extra': '', 'msg': 'b'}, " \
        "fmt='ScopeReplacer object %(name)r was used incorrectly: " \
        "%(msg)s%(extra)s', error=None"

    s = str(x)
    out.write("%r\n" % (s,))
    s = unicode(x)
    out.write("%r\n" % (s,))
    s = repr(x)
    out.write("%r\n" % (s,))

    result = out.getvalue

# Generated at 2022-06-26 02:17:12.273237
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Calling ScopeReplacer.__setattr__ with "attr" of "var_0" and "value" of 
    #  "disallow_proxying()"
    test_case_0()

# Generated at 2022-06-26 02:17:39.030977
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.trace import mutter
    # Test with no values
    var_0 = IllegalUseOfScopeReplacer(None, None)
    test_result = 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'
    mutter(test_result)
    assert str(var_0) == test_result
    # Test with no fmt attribute
    var_0 = IllegalUseOfScopeReplacer(None, None)
    test_result = "Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error='UnicodeEncodeError: 'ascii' codec can't encode character u'\\xe9' in position 141: ordinal not in range(128)'"
    mutter(test_result)
    assert str(var_0) == test_result
    #

# Generated at 2022-06-26 02:17:42.134079
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Testing precondition:
    assert isinstance(test_case_0(), disallow_proxying)


# Generated at 2022-06-26 02:17:49.141463
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(None, None, None)
    assert not isinstance(obj, ScopeReplacer)
    assert isinstance(obj, object)
    assert isinstance(obj, NotImplemented)
    # Wrong number of arguments (1) passed to function test_case_0.
    # Raising type error with message "test_case_0() takes exactly 0 arguments (1 given)".
    # This needs to be fixed.
    # test_case_0(obj)
    # Exception: None
    # add your test here
    raise NotImplementedError("test not implemented yet")


# Generated at 2022-06-26 02:17:56.669739
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # test for method __str__ of class IllegalUseOfScopeReplacer
    var_0 = disallow_proxying()
    raise NotImplementedError()


# Generated at 2022-06-26 02:18:05.831298
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from testtools.content import text_content

    var_0 = IllegalUseOfScopeReplacer('name', 'msg')

    # Check default message:
    var_1 = str(var_0)

    # Check unicode message:
    var_2 = unicode(var_0)

    # Check str message:
    var_3 = str(var_0)

    # Check repr message:
    var_4 = repr(var_0)



# Generated at 2022-06-26 02:18:08.812917
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('var_1', 'var_2')
    var_1 = var_0.__unicode__() # implicit assert on var_1


# Generated at 2022-06-26 02:18:11.561821
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    assert_equal(str(IllegalUseOfScopeReplacer(str('var_0'),str('var_1'))), str('var_0'))


# Generated at 2022-06-26 02:18:13.526184
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer().__str__()


# Generated at 2022-06-26 02:18:26.153565
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    globals_0 = {}
    var_0 = globals_0
    var_1 = ScopeReplacer
    factory_0 = lambda self, scope, name: self
    var_2 = factory_0
    var_3 = 'var_1'
    var_1 = var_1(var_0, var_2, var_3)
    def setattr_0(obj, attr, value):
        obj.attr = value
    def setattr_1(obj, attr, value):
        obj._attr = value

# Generated at 2022-06-26 02:18:30.250702
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    test_case = ScopeReplacer.UnitTestCase()
    test_case.setUp()
    test_case_0()
    test_case.tearDown()
    return test_case


# Generated at 2022-06-26 02:18:49.504177
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    scope = locals()
    lazy_import(scope, '''
    from bzrlib.lazy_import import ScopeReplacer
    ''')
    lazy_obj_0 = ScopeReplacer(scope, test_case_0, 'var_0')
    lazy_obj_0()
    if not hasattr(scope['var_0'], '__call__'):
        raise AssertionError('callable attribute not found in scope')


# Generated at 2022-06-26 02:18:55.605896
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # make sure we can actually create an instance of this class
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    # make sure __str__ doesn't raise an exception
    e.__str__()
    # make sure the returned value is of the correct type
    val_1 = e.__str__()
    assert isinstance(val_1, str), val_1.__class__


# Generated at 2022-06-26 02:18:57.788454
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() -> unicode"""
    if False: # the test is redundant
        test_case_0()


# Generated at 2022-06-26 02:18:59.538027
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_1 = var_0
    var_2 = var_1
    var_3 = var_2
    var_4 = var_3.__unicode__()
    return var_4


# Generated at 2022-06-26 02:19:00.106839
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()



# Generated at 2022-06-26 02:19:02.203867
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(), lambda a1,a2,a3:a1, 'a')
    var_1 = var_0()
    var_2 = (var_1 == var_0)
    assert (var_2)
    return None


# Generated at 2022-06-26 02:19:09.651044
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_1 = var_0.__unicode__()
    var_2 = var_0.__str__()
    # var_3 = var_0.__repr__()
    if (isinstance(var_1, unicode)):
        # var_2 = var_1.encode('utf8')
        var_3 = unicode(var_1)
    elif not isinstance(var_1, unicode):
        # var_3 = unicode(var_1)
        var_2 = str(var_1)


# Generated at 2022-06-26 02:19:20.609564
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_1 = u'This is a test of the unicode implementation'
    var_2 = var_1.encode('utf8')
    var_3 = IllegalUseOfScopeReplacer(var_2, '', None)
    var_4 = var_3.__unicode__()
    # Assert type
    try:
        assert isinstance(var_4, unicode)
    except AssertionError as e:
        raise AssertionError(str(e) + ' : ' +
            "Expected: %s, Actual: %s"%(unicode, type(var_4)))
    if var_4 != var_1:
        raise AssertionError("Expected: %s, Actual: %s"%(var_1, var_4))


# Generated at 2022-06-26 02:19:23.286785
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Init the test suite
    import bzrlib.lazy_import
    # Init the test case
    assert not ScopeReplacer()._should_proxy
    test_case_0()


# Generated at 2022-06-26 02:19:28.725046
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__"""
    # Test that IllegalUseOfScopeReplacer.__str__ returns a str.
    try:
        var_0 = test_case_0()
    except IllegalUseOfScopeReplacer as e:
        var_1 = str(e)
    else:
        var_1 = None
    var_2 = isinstance(var_1, str)
    return var_2

# Test that IllegalUseOfScopeReplacer.__str__ returns a unicode string.

# Generated at 2022-06-26 02:19:40.368514
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """Test that __getattribute__ lets you access methods but not override them

    This tests getting 'var_0'
    """
    var_0 = ScopeReplacer(scope=globals(), factory=lambda a,b,c: a, name='var_0')
    assert var_0.var_0 is var_0


# Generated at 2022-06-26 02:19:47.580341
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # ScopeReplacer.__setattr__: sets a module level variable to a
    # ScopeReplacer, then assigns a value to an attribute of that
    # variable. If the second line throws an IllegalUseOfScopeReplacer
    # exception, the test succeeds.
    var_0 = disallow_proxying()
    try:
        var_0.__setattr__('child_0', 1)
    except IllegalUseOfScopeReplacer:
        return
    else:
        raise AssertionError("test_ScopeReplacer___setattr__ failed")


# Generated at 2022-06-26 02:19:55.317820
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from StringIO import StringIO
    from testtools.content_type import ContentType
    from testtools.tests.content_type import TestContentType
    from testtools.tests.compat import TestCase
    from bzrlib.lazy_import import _lazy_import_import
    from io import BytesIO
    from io import StringIO
    from testtools.content_type import (
        ContentType,
        UTF8_TEXT,
        )
    from testtools.tests.content_type import (
        TestContentType,
        )
    var_0 = isinstance(type_0, type)
    var_1 = isinstance(type_0, type)
    var_2 = isinstance(type_0, type)
    var_3 = isinstance(type_0, type)

# Generated at 2022-06-26 02:20:06.775131
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    obj = ScopeReplacer({}, lambda x,y,z: z, 'var_0')
    exception_caught = False
    # We can copy, but we can't set attrs

# Generated at 2022-06-26 02:20:09.271952
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    foo = ScopeReplacer( {}, __builtins__['int'], 'foo' )
    self._assertEqual(foo(), 0)


# Generated at 2022-06-26 02:20:10.261409
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()


# Generated at 2022-06-26 02:20:11.835671
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = ScopeReplacer.__getattribute__


# Generated at 2022-06-26 02:20:18.389567
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    print >> sys.stderr, 'Testing IllegalUseOfScopeReplacer.__unicode__'
    input = 'value'
    actual = IllegalUseOfScopeReplacer.__unicode__(input)
    expected = 'value'
    #print >> sys.stderr, 'Expected: %s' % (expected)
    #print >> sys.stderr, 'Actual:   %s' % (actual)
    assert actual == expected, '__unicode__() failed'
    print >> sys.stderr, '%s.__unicode__() ok' % (input)


# Generated at 2022-06-26 02:20:21.369246
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    var_0 = IllegalUseOfScopeReplacer("does not implement __str__")
    var_1 = str(var_0)


# Generated at 2022-06-26 02:20:25.618729
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = test_case_0()

# << Fold


# The option is here so that we can automatically replace the module
# when reimporting the bzrlib package.
#
# Note that reload() does not accept the namespace argument.

# Generated at 2022-06-26 02:20:51.929042
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__ of ScopeReplacer must return the real object for which this is a placeholder"""

    # tests for local variables

    # test where we are not proxying, this will raise an exception
    obj = _fake_ScopeReplacer(None, None, None)
    try:
        obj.__call__()
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("__call__ of ScopeReplacer must raise an exception as we are not allowing proxying")

    # test where we are not proxying and a real_obj exists
    obj = _fake_ScopeReplacer(None, None, None, real_obj=True)
    try:
        obj.__call__()
    except IllegalUseOfScopeReplacer:
        pass

# Generated at 2022-06-26 02:20:53.916155
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__()"""
    pass # no implemented function


# Generated at 2022-06-26 02:20:57.149422
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name_0', 'msg_0', 'extra_0')
    expected = 'name_0: msg_0: extra_0'
    assert str(var_0) == expected


# Generated at 2022-06-26 02:21:01.615060
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # IllegalUseOfScopeReplacer.__str__() -> str
    var_0 = IllegalUseOfScopeReplacer("name","msg",extra="extra")
    assert type(var_0.__str__()) is str


# Generated at 2022-06-26 02:21:06.001303
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('var_1', 'var_2')
    var_0.__dict__['_preformatted_string'] = 'var_0'
    test_result = 'var_0'
    assert var_0.__str__() == test_result


# Generated at 2022-06-26 02:21:10.718763
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import __builtin__
    sr = ScopeReplacer(__builtin__.__dict__,
        lambda self, scope, name: __builtin__.__dict__['str'],
        'str')
    sr.x = "The quick brown fox"
    var_0 = sr.x
    sr.__setattr__('x', 'jumped over the lazy dog')
    var_1 = sr.x


# Generated at 2022-06-26 02:21:23.546286
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import examples
    import sys
    import builtins
    # store previous module values
    tmp_globals = sys.modules['bzrlib.examples'].__dict__.copy()
    # put something in the module namespace
    sys.modules['bzrlib.examples'].__dict__['var_0'] = var_0 = None
    # put something in the builtin namespace
    builtins.var_1 = var_1 = None

# Generated at 2022-06-26 02:21:29.591047
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import disallow_proxying
    var_0 = disallow_proxying()
    var_1 = IllegalUseOfScopeReplacer(var_0, None)
    try:
        var_1.__str__()
    except Exception:
        import sys
        return sys.exc_info()[1]


# Generated at 2022-06-26 02:21:34.392524
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # '_real_obj' is not in __slots__, but we are allowed to set it
    # for some reason.
    x = ScopeReplacer({}, None, None)
    x._real_obj = 'foo'


# Generated at 2022-06-26 02:21:39.880272
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    r"""ScopeReplacer.__call__()

    ScopeReplacer.__call__(self, *args, **kwargs)
    -> obj(*args, **kwargs)
    """
    from testtools import TestCase
    class test_ScopeReplacer___call__(TestCase):
        def test_0(self):
            self.assertRaises(IllegalUseOfScopeReplacer,
                              test_case_0)
    test_case_0()



# Generated at 2022-06-26 02:21:55.434527
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()


# Generated at 2022-06-26 02:21:58.461900
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    obj = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert 'name' in str(obj)
    assert 'extra' in str(obj)
    assert 'msg' in str(obj)


# Generated at 2022-06-26 02:21:59.840822
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    pass # no exceptions

# Generated at 2022-06-26 02:22:02.258692
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    foo = IllegalUseOfScopeReplacer("name", "message", "extra_info")
    str(foo)


# Generated at 2022-06-26 02:22:07.178396
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # test for simple case where IllegalUseOfScopeReplacer.__str__ just
    # returns a constant string
    exception = IllegalUseOfScopeReplacer(1, 2)
    expected = 'IllegalUseOfScopeReplacer(1, 2)'
    actual = str(exception)
    assert(expected == actual)



# Generated at 2022-06-26 02:22:19.394005
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__()

    If proxy is allowed, returns the result of calling the
    ScopeReplacer object.
    """
    # Function to be wrapped by ScopeReplacer
    def txt(var_0, var_1, var_2, var_3=None, var_4=None, var_5=None):
        return (var_0, var_1, var_2, var_3, var_4, var_5)
    # Check return value from wrapping
    global_env = {
        'txt': txt,
        }
    local_env = {}
    lazy_import(global_env, local_env, 'txt')
    txt_0 = local_env['txt']

# Generated at 2022-06-26 02:22:26.582652
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import bzrlib.lazy_import
    x, y, z, w, v = object(), object(), object(), object(), object()
    obj = bzrlib.lazy_import.IllegalUseOfScopeReplacer(x, y, z, w=w, v=v)
    expected = "Unprintable exception IllegalUseOfScopeReplacer: dict={'name': %s, 'extra': '', 'msg': %s}, fmt=None, error=None" % (repr(x), repr(y))
    actual = obj.__unicode__()
    assert expected == actual, '%r != %r' % (expected, actual)


# Generated at 2022-06-26 02:22:28.133248
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    pass  #TODO write me


# Generated at 2022-06-26 02:22:33.504874
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'message')
    u = e.__unicode__() # no exception raised
    try:
        e.__unicode__()
    except Exception:
        pass
    else:
        raise AssertionError('IllegalUseOfScopeReplacer.__unicode__ should have raised an Exception')


# Generated at 2022-06-26 02:22:38.373695
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import disallow_proxying
    from bzrlib.lazy_import import _generate_module
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestCaseWithFactory
    t = TestCase()
    scope_0 = {}
    test_case_0.__globals__ = scope_0
    t.assertRaises(IllegalUseOfScopeReplacer, test_case_0)
    t.assertEqual(scope_0, {'var_0': None})
    test_case_0.__globals__ = {}
    t = TestCaseWithFactory()
    factory_0 = _generate_module

# Generated at 2022-06-26 02:23:00.884961
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    sr = ScopeReplacer(scope, lambda s,o,n: None, 'test_name')
    test_ScopeReplacer___setattr__.sr = sr
    for _ in range(5):
        ScopeReplacer._should_proxy = False
        try:
            sr.__setattr__('test_attr', 'test_value')
        except IllegalUseOfScopeReplacer as e:
            e._preformatted_string = (
                "test_name: Object already replaced, did you assign it"
                " to another variable?")
        else: raise AssertionError
        finally:
            ScopeReplacer._should_proxy = True
    scope['test_name'] = 'test_value'
    # Ensure the attribute is propagated to the current object
    assert sr.test_attr == 'test_value'



# Generated at 2022-06-26 02:23:03.172538
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__ - XXX to be implemented"""
    raise NotImplementedError(
        "test_ScopeReplacer___setattr__ not implemented")


# Generated at 2022-06-26 02:23:04.677204
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()


# Generated at 2022-06-26 02:23:09.156060
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    # __call__ cannot be tested, since ScopeReplacers are only used
    # via lazy_import, and in bzrlib we have no lazy_imports that
    # are callable. There are a few in bzrlib.plugins, but they
    # are not very convenient to test.
    # See https://bugs.launchpad.net/bzr/+bug/624654
    assert(False)


# Generated at 2022-06-26 02:23:19.469854
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Called with bad argument types
    try:
        var_0 = IllegalUseOfScopeReplacer('name', 'msg')
        var_0.__str__(None)
    except TypeError:
        pass
    else:
        raise AssertionError('non-TypeError exception raised')
    # Called with good argument types
    var_1 = IllegalUseOfScopeReplacer('name', 'msg')
    assert var_1.__str__() == 'IllegalUseOfScopeReplacer(name, msg)'

    var_2 = IllegalUseOfScopeReplacer('name', 'msg')
    assert var_2.__str__() == 'IllegalUseOfScopeReplacer(name, msg)'



# Generated at 2022-06-26 02:23:25.432289
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    # Set up some objects and call test_case_0
    var_1 = ScopeReplacer(sys.modules['bzrlib.lazy_import'],
        lambda self, scope, name: None, 'disallow_proxying')
    # Call function test_case_0
    test_case_0()


# Generated at 2022-06-26 02:23:30.963282
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Test that we can access a global variable which is lazy imported.
    test_case_0()
    # Test that we can access a member of a global variable which is lazy
    # imported
    test_case_0()
    # Test that we can access a member of a method of a global variable which
    # is lazy imported
    test_case_0()
    # Test that we can call a method of a global variable which is lazy
    # imported
    test_case_0()


# Generated at 2022-06-26 02:23:32.856276
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('1', '2')
    raise NotImplementedError(
        'Test not implemented for IllegalUseOfScopeReplacer.__unicode__')


# Generated at 2022-06-26 02:23:45.075507
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import disallow_proxying
    from bzrlib.lazy_import import lazy_import
    lazy_import(locals(), '''
    import os
    import bzrlib.tests
    ''')

    def factory_0(self, scope, name):
        import bzrlib.lazy_import
        return bzrlib.lazy_import.ScopeReplacer(
            scope,
            factory_0,
            name)
    obj_0 = ScopeReplacer({}, factory_0, 'obj_0')
    test_case_0()
    test_case_0()
    test_case_0()
    return True # passed


# Generated at 2022-06-26 02:23:47.017490
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')



# Generated at 2022-06-26 02:23:59.296688
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    err = IllegalUseOfScopeReplacer('foo', 'bar')
    str(err)


# Generated at 2022-06-26 02:24:04.836176
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    try:
        raise NotImplementedError()
    except NotImplementedError:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        for arg in [exc_type, exc_value, exc_traceback]:
            assert isinstance(arg, object)


# Generated at 2022-06-26 02:24:06.683758
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()



# Generated at 2022-06-26 02:24:12.453527
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() for `IllegalUseOfScopeReplacer`"""
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    expected = "ScopeReplacer object 'name' was used incorrectly: msg"
    s = str(var_0)
    assert s == expected, "%r != %r" % (s, expected)



# Generated at 2022-06-26 02:24:22.540356
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # The following call to ScopeReplacer.__init__ is the first
    # assignment to the scope.  That assignment needs to happen
    # before the call to disallow_proxying().
    scope_replacer = ScopeReplacer(globals(), lambda pos, scope, name: None,
                                   'globals')
    var_0 = disallow_proxying()
    try:
        scope_replacer.__setattr__('_var_0', 'Not assigned')
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'globals'
        assert 'Object already' in str(e)
        assert "did you assign it" in str(e)

# Generated at 2022-06-26 02:24:27.929932
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import test_case_0
    from bzrlib.lazy_import import _should_proxy


# Generated at 2022-06-26 02:24:37.278681
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import unittest
    from StringIO import StringIO

    class MyTest(unittest.TestCase):
        def test_0(self):
            var_0 = IllegalUseOfScopeReplacer('var_0', 'var_1')
            var_1 = None
            # BEGIN: IllegalUseOfScopeReplacer.__str__()
            var_2 = var_0.__str__()
            # END: IllegalUseOfScopeReplacer.__str__()
            self.assertEqual(var_2, 'var_0 was used incorrectly: var_1')

    unittest.main()


# Generated at 2022-06-26 02:24:42.250462
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    global ScopeReplacer
    from bzrlib.tests.lazy_import_test import ScopeReplacer
    # testing __call__(self, *args, **kwargs):
    blah = ScopeReplacer._should_proxy = True
    var_0 = ScopeReplacer()


# Generated at 2022-06-26 02:24:43.852448
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Template method: subclasses must override
    raise NotImplementedError()


# Generated at 2022-06-26 02:24:50.846354
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys

    def case_0():
        global isinstance_callable
        def factory_0(x0, x1, x2):
            return isinstance
        isinstance_callable = lambda x0, x1: ScopeReplacer(x0, x0, x1)
        var_0 = ScopeReplacer(globals(), factory_0, 'isinstance')
        var_1 = isinstance('', str)
        assert var_1 is True
        assert isinstance_callable is None
        assert isinstance is not None
        assert isinstance is sys.modules['__builtin__'].isinstance

    case_0()


# Generated at 2022-06-26 02:25:15.915675
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import warnings
    warnings.simplefilter('ignore', PendingDeprecationWarning)
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer, ScopeReplacer

    class TestScopeReplacer(unittest.TestCase):

        def test_ScopeReplacer_01(self):
            """__setattr__ handles IllegalUseOfScopeReplacer"""
            sr = ScopeReplacer(dict(), _do_resolve, '__name')
            sr._real_obj = object

            # should not raise
            self.assertRaises(IllegalUseOfScopeReplacer, sr.__setattr__, 'a', 3)

    # Return a test suite.
    return unittest.TestLoader().loadTestsFromTestCase

# Generated at 2022-06-26 02:25:22.128753
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Creating a new scope
    scope = {}
    # Creating a new ScopeReplacer
    obj = ScopeReplacer(scope,
                        factory=lambda self, scope, name: scope[name],
                        name='var_0')
    try:
        res = obj.__getattribute__('_name')
    except IllegalUseOfScopeReplacer:
        raise Exception("This test should not fail")
    else:
        return [res]



# Generated at 2022-06-26 02:25:26.555880
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_1 = IllegalUseOfScopeReplacer(str(var_0), 'msg', 'extra')
    var_2 = str(var_1)
    assert (var_2 == "ScopeReplacer object 'var_0' was used incorrectly: msg: \
extra")


# Generated at 2022-06-26 02:25:34.415183
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test that ScopeReplacer correctly replaces itself in a given scope
    # after use.
    from cStringIO import StringIO
    from bzrlib import ui
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests.test_lazy_import import tests_module
    # Create a dummy module that we can use as a factory
    factory_module = tests_module.ModuleWithFunctions()
    # Create a dummy scope
    dummy_scope = {}
    # Create a dummy ui.ui_factory
    ui_factory = ui.ui_factory
    dummy_ui_factory = factory_module.dummy_ui_factory
    ui.ui_factory = dummy_ui_factory
    # Try to import this module