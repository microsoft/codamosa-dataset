

# Generated at 2022-06-26 02:15:51.611666
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass


# Generated at 2022-06-26 02:16:02.674173
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    if (not hasattr(__builtin__, '__import__')):
        __builtin__.__import__ = None
    global __file__
    import bzrlib.lazy_import
    scope = {}
    factory = test_case_0
    name = 'var_0'
    obj = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        obj.__call__()
        raise AssertionError('Uncaught IllegalUseOfScopeReplacer: '
                             '"<lambda>"')
    except IllegalUseOfScopeReplacer as e:
        assert str(e) == '"<lambda>"'
    finally:
        bzrlib.lazy_import.Scope

# Generated at 2022-06-26 02:16:15.328607
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test for method __setattr__ of class ScopeReplacer
    # TODO: This should be converted to a test in
    # test_lazy_import.py. For now, we have to run it manually
    # because it touches the module global.
    global DISALLOW_PROXYING
    DISALLOW_PROXYING = False
    # Test that attr proxying is allowed if DISALLOW_PROXYING is False
    x = test_case_0()
    DISALLOW_PROXYING = True
    try:
       x = test_case_0()
    except IllegalUseOfScopeReplacer:
       pass
    else:
       raise AssertionError(
           "Expected IllegalUseOfScopeReplacer when proxying is disallowed")

# Class to allow testing of method __setattr__ of class ScopeReplacer

# Generated at 2022-06-26 02:16:23.662623
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    try:
        var_0.blah()
        raise AssertionError('AssertionError expected')
    except IllegalUseOfScopeReplacer as var_1:
        var_2 = var_1._format()
        var_3 = str(var_1)
        var_1.__class__.__name__
        var_1.__dict__
        var_1._fmt
        var_1._format()
        var_1.blah()
        try:
            var_1.blah()
            raise AssertionError('AssertionError expected')
        except IllegalUseOfScopeReplacer as var_4:
            var_4.__str__()
            var_4.__class__.__name__

# Generated at 2022-06-26 02:16:24.771798
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # proxy_scope = {'var_0': __setattr__}
    assert 0 # TODO: implement your test here


# Generated at 2022-06-26 02:16:34.287470
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    gb = globals()
    fb = 'bzrlib._lazy_import'
    factory = 'ScopeReplacer'
    name = 'var_0'
    # This executes
    # from bzrlib._lazy_import import ScopeReplacer as var_0
    ScopeReplacer(gb, fb, factory, name)
    # This executes:
    # var_0 = ScopeReplacer(gb, fb, factory, name)
    # var_0()
    # Which results in a call to the method _resolve in the class
    # ScopeReplacer, and an IllegalUseOfScopeReplacer exception raised.

# Generated at 2022-06-26 02:16:44.208601
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    old_should_proxy = ScopeReplacer._should_proxy
    ScopeReplacer._should_proxy = False
    try:
        try:
            globals()['var_0'] = lazy_import(globals(), '''
            from bzrlib import tests
            ''')
            test_case_0()
            raise AssertionError('IllegalUseOfScopeReplacer not raised')
        except IllegalUseOfScopeReplacer as e:
            assert_('replaced' in e.msg)
            assert_('assign' in e.msg)
    finally:
        ScopeReplacer._should_proxy = old_should_proxy


# Generated at 2022-06-26 02:16:52.536205
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(1, 2, 3)
    var_1 = var_0.__unicode__()
    assert(var_1 == u'Unprintable exception IllegalUseOfScopeReplacer: dict={\'msg\': 2, \'extra\': \'\', \'name\': 1}, fmt=None, error=None')
    return None


# Generated at 2022-06-26 02:17:01.875571
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    scope = {}

    # Calling object constructor
    obj_0 = ScopeReplacer(scope, lambda x, y, z: x, 'var_0')
    # Assigning to var
    var_0 = obj_0
    # Calling function disallow_proxying
    test_case_0()
    # Calling method _resolve of object obj_0
    var_1 = obj_0._resolve()



# Generated at 2022-06-26 02:17:07.184007
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test method __unicode__ of class IllegalUseOfScopeReplacer"""
    object_0 = IllegalUseOfScopeReplacer(name=None, msg=None, extra=None)
    # g.coverage.py diverges here
    #assertNotEquals(object_0.__class__.__name__, None)


# Generated at 2022-06-26 02:17:29.162719
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__()

    The standard call method, which should work exactly as it would on
    the real object.
    """
    pass # tested by test_case_0


# Generated at 2022-06-26 02:17:38.729892
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # test for method __call__ of class ScopeReplacer
    var_0 = ScopeReplacer(module_0, None, '__name__')

# Generated at 2022-06-26 02:17:49.368282
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.tests
    from bzrlib.lazy_import import lazy_import, disallow_proxying, ScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests.lazy_import import (
        TestCaseWithFactory,
        test_case_0,
        )
    from bzrlib.lazy_import import (
        ScopeReplacer,
        )

    # Set-up of the class
    lazy_import(locals(), '''
    from bzrlib import (
        tests,
        )
    ''')

    # Set-ups for the method
    ScopeReplacer._should_proxy = True
    obj = ScopeReplacer({}, None, '_name')
    attr = '_name'

# Generated at 2022-06-26 02:18:00.390197
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    # Test without unicode format string
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(e.__unicode__(), unicode)

    # Test with unicode format string
    e = IllegalUseOfScopeReplacer('name', 'msg')
    e._preformatted_string = 'unicode'
    assert isinstance(e.__unicode__(), unicode)

    # Test with str format string
    e = IllegalUseOfScopeReplacer('name', 'msg')
    e._preformatted_string = 'ascii'
    assert isinstance(e.__unicode__(), unicode)

    # Test with int format string
    e = IllegalUseOfScopeReplacer('name', 'msg')
    e._preform

# Generated at 2022-06-26 02:18:03.352759
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    name = '_should_proxy'
    old_value = ScopeReplacer._should_proxy
    try:
        ScopeReplacer._should_proxy = False
        try:
            var_0 = test_case_0()
        except Exception:
            pass
        assert old_value == ScopeReplacer._should_proxy
    finally:
        ScopeReplacer._should_proxy = old_value


# Generated at 2022-06-26 02:18:06.837330
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Simple example test
    f = IllegalUseOfScopeReplacer("name","msg")
    r = str(f)


# Generated at 2022-06-26 02:18:09.095874
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer

    foo_0 = ScopeReplacer.__call__(ScopeReplacer(), *(None,))


# Generated at 2022-06-26 02:18:10.295336
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # Nothing to test.


# Generated at 2022-06-26 02:18:18.559038
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Tests the output of IllegalUseOfScopeReplacer.__str__"""
    # TODO This method needs docstring!!!
    # TODO This test needs some serious renaming...

    error = IllegalUseOfScopeReplacer('name', 'msg')
    # Ascii
    expected = ("Illegal use of ScopeReplacer: ScopeReplacer object 'name' was "
            "used incorrectly: msg")
    eq = (str(error) == expected)

# Generated at 2022-06-26 02:18:22.717830
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    global var_0
    var_0 = IllegalUseOfScopeReplacer('name_0', 'msg_0', 'extra_0')



# Generated at 2022-06-26 02:18:31.166246
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case_0()


# Generated at 2022-06-26 02:18:40.413538
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests import TestCase
    import sys
    class TestIllegalUseOfScopeReplacer___unicode__(TestCase):
        def test_0(self):
            var_0 = IllegalUseOfScopeReplacer('name', 'msg')
            self.assertEqual(var_0.__unicode__(), "IllegalUseOfScopeReplacer"
                " object 'name' was used incorrectly: msg")
    # Setup test suite
    loader = TestLoader()
    suite = loader.loadTestsFromTestCase(TestIllegalUseOfScopeReplacer___unicode__)
    # Setup test runner
    if sys.version_info[0:2] < (2, 7):
        runner = TextTestRunner(verbosity=2)
    else:
        runner = TextTestRunner(verbosity=2, buffer=True)


# Generated at 2022-06-26 02:18:44.349093
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('var_1', 'var_2', 'var_3')
    var_0.__str__()


# Generated at 2022-06-26 02:18:45.397057
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()


# Generated at 2022-06-26 02:18:52.408713
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_1 = IllegalUseOfScopeReplacer((), 'msg', None)
    var_2 = IllegalUseOfScopeReplacer.__unicode__(var_1)
    assert_(var_2 in ("Unprintable exception IllegalUseOfScopeReplacer: dict=(), fmt=None, error=None", "Unprintable exception IllegalUseOfScopeReplacer: dict=(), fmt=None, error=Message: "))


# Generated at 2022-06-26 02:18:55.435418
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer({}, None, None)
    var_0._resolve()
    var_1 = {}
    var_2 = test_case_0()


# Generated at 2022-06-26 02:18:59.546649
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__(...) => string

    Test the method __str__ of class IllegalUseOfScopeReplacer using
    various inputs.
    """
    # Test 0: no parameters
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 02:19:04.024602
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    o_0 = IllegalUseOfScopeReplacer("var_0", "var_0")
    val_0 = o_0.__unicode__()
    if (val_0.__class__ is not unicode):
        raise AssertionError("val_0.__class__ is not unicode: '%(val_0.__class__)s'" % locals())


# Generated at 2022-06-26 02:19:09.844469
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """ test for method __setattr__ of class ScopeReplacer """

    # AssertionError: ScopeReplacer object 'var_0' was used incorrectly: 
    # Object already replaced, did you assign it to another variable?: 
    # scope=['var_0'], factory=<function test_case_0 at 0xb7143b04>, 
    # name='var_0'
    test_case_0()

# Generated at 2022-06-26 02:19:13.892091
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests.blackbox import ExternalBase

    test_case_0()

    res = ExternalBase()
    if res.test_result():
        return 0
    return 1


# Generated at 2022-06-26 02:19:37.563193
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.i18n import gettext
    from bzrlib.i18n import ugettext
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    var_1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert var_0.__str__() == 'name has not been initialized yet.'
    assert var_1.__str__() == 'name has not been initialized yet.'
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    var_1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert var_0.__str__() == 'name has not been initialized yet.'
    assert var_1.__

# Generated at 2022-06-26 02:19:46.483208
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys, StringIO
    if sys.version_info[0] >= 3:
        buffer = StringIO.StringIO()
    else:
        buffer = StringIO.StringIO()
    var_0 = StringIO.StringIO()
    var_0.write('IllegalUseOfScopeReplacer(None)')
    actual = buffer.getvalue()
    expected = var_0.getvalue()
    assert actual == expected, "Test for IllegalUseOfScopeReplacer.__unicode__() failed:\n" \
                               "actual   = %r\n" \
                               "expected = %r" % (actual, expected)



# Generated at 2022-06-26 02:19:47.906178
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Empty test to avoid failures with missing tests
    pass


# Generated at 2022-06-26 02:19:49.885036
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name_0', 'msg_1')
    var_1 = str(var_0)


# Generated at 2022-06-26 02:19:51.013194
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_1 = IllegalUseOfScopeReplacer('var_0', 'var_1')
    # AssertionError: assert 'var_0' == u''


# Generated at 2022-06-26 02:19:52.506285
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() -> string

    __str__(x) <==> str(x)
    """
    var_0 = disallow_proxying()


# Generated at 2022-06-26 02:19:56.619254
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    try:
        test_case_0()
    except (Exception) as e:
        assert isinstance(e, IllegalUseOfScopeReplacer)
        assert str(e) == "ScopeReplacer object 'var_0' was used incorrectly: you should not have constructed this directly: 0"
        assert repr(e) == "IllegalUseOfScopeReplacer(ScopeReplacer object 'var_0' was used incorrectly: you should not have constructed this directly: 0)"
    else:
        raise AssertionError("ScopeReplacer object 'var_0' was used incorrectly: you should not have constructed this directly: 0")


# Generated at 2022-06-26 02:20:01.367611
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # prepare arguments for test
    name = 'unknown'
    msg = 'unknown'
    var_0 = IllegalUseOfScopeReplacer(name, msg)

    # run test
    var_0.__unicode__()



# Generated at 2022-06-26 02:20:09.703135
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Get the class to instantiate
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer as cls
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer as UNICODE_CLASS
    var_0 = cls('__unicode__', '__unicode__')
    # Call the method
    try:
        result = UNICODE_CLASS.__unicode__(var_0)
    except Exception as e:
        if cls is not type(e):
            raise AssertionError("Expected class %r, got %r"
                                 % (cls, type(e)))



# Generated at 2022-06-26 02:20:18.660400
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import (
        disallow_proxying,
        IllegalUseOfScopeReplacer,
        ScopeReplacer,
        ) # _should_proxy

    class TestScopeReplacer(TestCase):

        def test_case_0(self):
            """Raise IllegalUseOfScopeReplacer when _should_proxy is disabled
            and the same variable is used twice"""
            ScopeReplacer._should_proxy = False
            try:
                test_case_0()
            except IllegalUseOfScopeReplacer as e:
                self.assertEquals('var_0', e.name)
                self.assertTrue(e.msg.startswith('Object already replaced'))
            finally:
                ScopeReplacer._should_proxy = True

    return TestScopeRepl

# Generated at 2022-06-26 02:20:54.243124
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(None, None)


# Generated at 2022-06-26 02:21:02.133880
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_1 = var_0.__str__()
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    var_2 = IllegalUseOfScopeReplacer()
    var_3 = var_2.__str__()


# Generated at 2022-06-26 02:21:07.420440
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exp_fmt = ("ScopeReplacer object %(name)r was used incorrectly:"
            " %(msg)s%(extra)s")
    e = IllegalUseOfScopeReplacer('name', 'msg')
    act_format = e._get_format_string()
    exp_format = exp_fmt
    assert isinstance(act_format, str)
    assert act_format == exp_format


# Generated at 2022-06-26 02:21:11.788734
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests

    class DummyScopeReplacer(object):
        def __init__(self, *args):
            pass

    var_0 = bzrlib.tests.ProtocolTestCase(methodName='test_case_0')
    var_1 = DummyScopeReplacer()
    var_0.assertRaises(IllegalUseOfScopeReplacer,
                       var_1.__call__)



# Generated at 2022-06-26 02:21:18.943067
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib

    factory_0 = disallow_proxying
    name_0 = 'var_0'
    scope_0 = {name_0: None}
    scope_replacer_0 = ScopeReplacer(scope_0, factory_0, name_0)
    scope_replacer_0.__setattr__(name_0, None) # raises IllegalUseOfScopeReplacer



# Generated at 2022-06-26 02:21:25.786245
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from . import lazy_import
    from .lazy_import import IllegalUseOfScopeReplacer
    var_0 = disallow_proxying()
    var_1 = lazy_import.disallow_proxying()
    var_2 = IllegalUseOfScopeReplacer(var_1, var_0)
    var_3 = str(var_2)
    var_4 = unicode(var_2)


# Generated at 2022-06-26 02:21:30.722816
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    ScopeReplacer._should_proxy = False
    try:
        var_0 = globals()()
        var_0['test_case_0'] = test_case_0
        var_0['test_case_0']()
    finally:
        ScopeReplacer._should_proxy = True


# Generated at 2022-06-26 02:21:33.966555
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = disallow_proxying()
    var_0.var_0('foo', 'bar', 'baz')


# Generated at 2022-06-26 02:21:42.482446
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Test __call__ on ScopeReplacer.

    The call should be proxied through to the real object.
    """
    globals_ = {
        'var_0': ScopeReplacer(globals(), test_case_0, 'var_0'),
    }

    def test_case_1():
        def test_case_2(obj, scope, name):
            return obj

        var_1 = ScopeReplacer(globals_, test_case_2, 'var_1')
        var_1()
        return var_1

    # Check that calling the fake object actually calls the real object
    def test_case_2(obj, scope, name):
        return 'real_value'

    var_1 = ScopeReplacer(globals_, test_case_2, 'var_1')
    var_1()

# Generated at 2022-06-26 02:21:44.894533
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # test for IllegalUseOfScopeReplacer.__str__ (pyrex)
    # currently skipped.
    pass


# Generated at 2022-06-26 02:23:50.172214
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    scope = {}
    scope["var_1"] = None
    scope["var_0"] = ScopeReplacer(scope,
        test_case_0, "var_1")
    scope["var_0"]._should_proxy = False
    scope["var_0"].var_1 = 1
    assert scope["var_0"]._real_obj == None
    assert scope["var_1"] == 1
    scope["var_0"].var_1 = 1
    assert scope["var_0"]._real_obj == 1
    assert scope["var_1"] == 1


# Generated at 2022-06-26 02:24:00.246393
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test for __str__."""
    # Test for a simple case
    msg = "This is a message!"
    e = IllegalUseOfScopeReplacer("foo", msg)
    assert e.__str__() == "IllegalUseOfScopeReplacer: foo: This is a message!"

    # Test for an unprintable value
    e = IllegalUseOfScopeReplacer("foo", msg, unprintable_value)
    assert str(e).startswith(
        "IllegalUseOfScopeReplacer: foo: This is a message!: unprintable_value")

    # Test for a missing value
    e = IllegalUseOfScopeReplacer("foo", msg, missing_value)
    assert str(e).endswith(": missing_value")



# Generated at 2022-06-26 02:24:05.648719
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_1 = disallow_proxying()

# Generated at 2022-06-26 02:24:12.090075
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.tests import TestCase
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 02:24:14.030079
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(name='blah', msg='blah', extra='blah')
    pass


# Generated at 2022-06-26 02:24:18.215410
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('lazy_impl', 'scope', 'msg')
    var_1 = str(var_0)
    assert var_1 == 'lazy_impl scope: msg'


# Generated at 2022-06-26 02:24:24.876167
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from cStringIO import StringIO
    try:
        tmp1 = StringIO()
        tmp1.name = 'tmp1'
        tmp2 = StringIO()
        tmp2.name = 'tmp2'
        tmp1.write('')
        tmp2.write('')
        var_1 = IllegalUseOfScopeReplacer(tmp1, tmp2)
    except:
        var_1 = None
    else:
        var_1 = StringIO()
        var_1.write('%s' % var_1)
        var_1 = var_1.getvalue()
    return (var_1)


# Generated at 2022-06-26 02:24:28.036181
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(None, None)
    var_1 = var_0._format()


# Generated at 2022-06-26 02:24:35.057106
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Tests that the unicode method of IllegalUseOfScopeReplacer is
    # implemented.
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    # We don't care *what* the string is, but it must be unicode.
    assert isinstance(u, unicode), 'Got %r, %r' % (u, type(u))


# Generated at 2022-06-26 02:24:39.538738
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # obj = ScopeReplacer(scope, factory, name)
    # test for no exception.
    var_0 = ScopeReplacer(scope, factory, name)
    # obj.test_case_0()
    var_0.test_case_0()
    # test for exception raise.
