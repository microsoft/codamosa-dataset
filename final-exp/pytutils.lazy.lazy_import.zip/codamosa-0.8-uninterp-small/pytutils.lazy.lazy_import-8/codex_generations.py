

# Generated at 2022-06-26 02:16:13.479519
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Note: the try/except blocks in this unit test are present because of
    # somewhat complex exception handling in all __setattr__ methods.
    from bzrlib.lazy_import import test_case_0, IllegalUseOfScopeReplacer

    # IllegalUseOfScopeReplacer is raised in a nested try except block
    # that is not visible to a debugger. So set up an exception hook
    # to give us a chance to inspect the exception.
    def exception_hook(ex_type, ex_value, ex_traceback):
        assert isinstance(ex_value, IllegalUseOfScopeReplacer)
        assert ex_value.name == 'x'
        assert ex_value.msg.startswith('Object already replaced,')
    import sys
    orig_excepthook = sys.excepthook
    sys.excep

# Generated at 2022-06-26 02:16:16.468801
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import StringIO
    fout = StringIO.StringIO()
    var_0 = IllegalUseOfScopeReplacer('abc', 'def', 'ghi')
    var_0.__str__()


# Generated at 2022-06-26 02:16:21.180186
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ == str(IllegalUseOfScopeReplacer)"""
    obj = IllegalUseOfScopeReplacer('obj', 'msg')
    assert str(obj) == 'Unprintable exception IllegalUseOfScopeReplacer: '\
        'dict={}, fmt=None, error=None'



# Generated at 2022-06-26 02:16:29.396518
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name', 'message')
    var_1 = var_0._format()
    var_2 = var_0.__unicode__()
    var_3 = var_0.__str__()
    var_4 = var_0.__repr__()
    var_5 = str(var_0)


# Generated at 2022-06-26 02:16:30.466551
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = disallow_proxying()


# Generated at 2022-06-26 02:16:42.867328
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of ScopeReplacer"""
    if (ScopeReplacer._should_proxy):
        raise AssertionError("ScopeReplacer._should_proxy not false")
    else:
        pass
    try:
        var_0 = ScopeReplacer("var_1", "var_2", "var_3")
        var_0.__setattr__("var_4", "var_5")
    except IllegalUseOfScopeReplacer:
        var_6 = False
    else:
        var_6 = True
    if (var_6):
        raise AssertionError("(var_6)")
    else:
        pass



# Generated at 2022-06-26 02:16:44.768753
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()


# Generated at 2022-06-26 02:16:50.087878
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    sr = ScopeReplacer(locals(), None, 'var_0')
    try:
        sr(0)
    except TypeError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-26 02:16:54.778412
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """
    WARNING: If method __str__ of class IllegalUseOfScopeReplacer does not
             define a return value, then the value of result is not
             defined.
             If the return value of this method is used, then make sure
             that the value is defined.
    """
    result = IllegalUseOfScopeReplacer._get_format_string()



# Generated at 2022-06-26 02:16:57.529188
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # XXX need a testcase that doesn't depend on gettext
    raise NotImplementedError


# Generated at 2022-06-26 02:17:18.383032
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    var_0 = IllegalUseOfScopeReplacer(None, None)
    var_0._fmt = '%(foo)s'
    var_0.__dict__['foo'] = 'bar'
    # Call method __str__ of var_0
    expected_1 = 'bar'
    var_1 = str(var_0)
    var_2 = expected_1 == var_1
    assert var_2


# Generated at 2022-06-26 02:17:23.267188
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():

    foo = ScopeReplacer('global', 'global', 'foo')
    foo = True


# Generated at 2022-06-26 02:17:28.943008
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('my_name', 'my_msg', 'my_extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-26 02:17:31.554280
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Create an instance of IllegalUseOfScopeReplacer
    test_case_0()


# Generated at 2022-06-26 02:17:37.534023
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    ScopeReplacer._should_proxy = True
    var_0 = ScopeReplacer.__call__
    var_0 = ScopeReplacer()
    var_0.__call__()
    var_0 = ScopeReplacer()
    var_0.__call__(3, a=4)
    var_0._should_proxy = False
    var_0 = ScopeReplacer()
    var_0.__call__()


# Generated at 2022-06-26 02:17:45.614745
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def _factory(obj, scope, name):
        return object()
    scope = {}
    obj = ScopeReplacer(scope, _factory, 'name')
    assert scope['name'] is obj, ('scope was %r' % (scope,))
    obj.x = 1
    assert scope['name'].x == 1, ('scope was %r' % (scope,))


# Generated at 2022-06-26 02:17:59.244755
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests.test_lazy_import import Example1
    e = IllegalUseOfScopeReplacer('test', 'This is a test.', 'test')
    # test_case_0()
    test_case_0()
    # If we are translating bzr, then check that this string is translated
    # correctly.
    if e._get_format_string() == u"ScopeReplacer object 'test' was used incorrectly: This is a test.test":
        e = IllegalUseOfScopeReplacer('test_name', 'test_msg', 'test_extra')
        assert str(e) == "ScopeReplacer object 'test_name' was used incorrectly: test_msg: test_extra"

# Generated at 2022-06-26 02:18:03.391607
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(name=None, msg=None)
    assert(var_0.__unicode__() is not NotImplemented)


# Generated at 2022-06-26 02:18:11.167090
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # test_case_0
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    try:
        raise var_0
    except IllegalUseOfScopeReplacer as e:
        str(e)
        unicode(e)
    # test_case_1
    var_1 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    try:
        raise var_1
    except IllegalUseOfScopeReplacer as e:
        str(e)
        unicode(e)
    # test_case_2
    var_2 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    try:
        raise var_2
    except IllegalUseOfScopeReplacer as e:
        str(e)
        unicode(e)
    # test_case_3

# Generated at 2022-06-26 02:18:23.493080
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # no object generated previously, so assign to scope and return.
    # There is still a small window here where races will not be detected,
    # but safest to avoid additional locking.
    scope = {}
    scope_replacer = ScopeReplacer(scope, lambda scope_replacer, scope, name:
        scope_replacer, 'var_0')
    scope_replacer.__setattr__('attr_0', 'attr value')
    assert scope == {'var_0': scope_replacer}
    assert scope_replacer._real_obj is None
    assert scope_replacer._name == 'var_0'
    assert scope_replacer._scope == scope
    assert scope_replacer.attr_0 == 'attr value'



# Generated at 2022-06-26 02:18:40.851364
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.i18n import gettext
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    # XXX: Unicode strings are not allowed in py3k.
    # Uncomment this to run this test for py2k only.
    if getattr(__builtins__, 'unicode', None) is None:
        return

    s = IllegalUseOfScopeReplacer('var_0', 'msg_0')
    n = None
    if n is s.extra:
        n = ''
    u = u'ScopeReplacer object \'var_0\' was used incorrectly: msg_0' + n
    if u != unicode(s):
        raise AssertionError(u)


# Generated at 2022-06-26 02:18:53.847200
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import mock
    from bzrlib.lazy_import import test_case_0
    # Setup Mock objects
    test_scope = {'__name__': 'bzrlib.tests.test_lazy_import'}
    test_factory = object()
    test_name = 'var_0'
    with mock.patch('bzrlib.lazy_import.ScopeReplacer._should_proxy') as mock_should_proxy, mock.patch('bzrlib.lazy_import.ScopeReplacer._resolve') as mock_resolve:
        # Set up test fixture
        mock_should_proxy.__get__ = mock.Mock(return_value=False)
        mock_resolve.return_value = 'real_obj'

# Generated at 2022-06-26 02:19:01.850909
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = IllegalUseOfScopeReplacer("name", "msg", "extra")
    case_1 = IllegalUseOfScopeReplacer("name2", "msg2", "extra2")
    case_2 = IllegalUseOfScopeReplacer("name2a", "msg2a", "extra2a")
    assert case_0.__str__() != case_0.__str__()
    assert case_0.__str__() != case_1.__str__()
    assert case_1.__str__() != case_0.__str__()
    assert case_1.__str__() != case_2.__str__()




# Generated at 2022-06-26 02:19:05.363001
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    o = ScopeReplacer
    o._should_proxy = False
    # Test if the object can be called normally.
    call_1 = o._resolve()
    # Test if an exception is thrown on an incorrect call.
    try:
        call_2 = o._resolve(1)
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:19:16.303305
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib.lazy_import
    # called function calls function '_resolve'
    try:
        var_0 = bzrlib.lazy_import.lazy_import({'bzrlib': None}, 
            'import bzrlib.lazy_import')
    except Exception as var_1:
        var_0 = None
    if ((hasattr(var_0, '_resolve') and callable(var_0._resolve)) and 
        ((var_1 is not None) and isinstance(var_1, ScopeReplacer))):
        var_0()
    else:
        raise AssertionError


# Generated at 2022-06-26 02:19:17.603936
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()
    return

# Generated at 2022-06-26 02:19:18.553861
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()


# Generated at 2022-06-26 02:19:19.840943
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import unittest

    test_case_0()


# Generated at 2022-06-26 02:19:24.115568
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return a str"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    ex = IllegalUseOfScopeReplacer("ex", "message")
    TestCase().assertIsInstance(str(ex), str)



# Generated at 2022-06-26 02:19:26.454066
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    x = IllegalUseOfScopeReplacer(1, 2)
    expected = "IllegalUseOfScopeReplacer(1, 2)"
    actual = str(x)
    assert actual == expected


# Generated at 2022-06-26 02:19:35.971866
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_1 = _IllegalUseOfScopeReplacer___str__()


# Generated at 2022-06-26 02:19:41.995824
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(scope={}, factory=test_case_0, name='var_0')
    var_0()
    check_0 = (False, True)
    var_1 = check_0[ScopeReplacer._should_proxy]
    assert var_1 == True, ("actual value is %r" % var_1)


# Generated at 2022-06-26 02:19:43.188431
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    pass # TODO


# Generated at 2022-06-26 02:19:50.301057
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():

    # Check that assignments to a member of a lazy object propagate through to
    # the real object.
    def make_real(obj, scope, name):
        return object()

    scope = {'var_0': None}
    lazy_import(scope, 'var_0', make_real)
    var_0 = scope['var_0']
    var_1 = 'value_1'
    var_0.var_1 = var_1
    expected_1 = var_1
    actual_1 = var_0.var_1
    assert_equal(actual_1, expected_1)



# Generated at 2022-06-26 02:19:56.552588
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test if a previous instance of it is returned if not all params are
    set.

    TODO: fix
    """
    import tempfile
    original = tempfile.gettempdir()
    new = tempfile.gettempdir()
    try:
        import subprocess
        s = tempfile.gettempdir()
        tempfile.gettempdir = lambda: s + '/xxx'
        old_subprocess = subprocess.Popen
        subprocess.Popen = 123
        try:
            test_case_0()
            assert False
        except Exception as e:
            assert e.args[0] == "Object already replaced, did you assign"\
                " it to another variable?"
    finally:
        tempfile.gettempdir = original
        subprocess.Popen = old_subprocess


# Generated at 2022-06-26 02:19:57.847942
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    pass


# Generated at 2022-06-26 02:20:01.218102
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('name_0', 'msg_0')
    var_1 = var_0._format()


# Generated at 2022-06-26 02:20:03.072062
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case = IllegalUseOfScopeReplacer(u'', u'', None)


# Generated at 2022-06-26 02:20:06.280333
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(name='var_0', msg='var_1',
                                      extra='var_2')
    var_0.test_IllegalUseOfScopeReplacer___str__()



# Generated at 2022-06-26 02:20:09.140486
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib import lazy_import
    from cStringIO import StringIO
    from unittest import TestCase
    test_case_0()


# Generated at 2022-06-26 02:20:24.470854
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import re
    import sys
    if sys.version_info[0] == 3:
        e = IllegalUseOfScopeReplacer("name", "msg", None)
    else:
        e = IllegalUseOfScopeReplacer("name", u"msg", None)
        m = re.match('Unprintable exception IllegalUseOfScopeReplacer: '
            'dict={.+}$', str(e))
        assert m, 'Expected error, got %r' % str(e)


# Generated at 2022-06-26 02:20:27.870045
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer({}, lambda x,y,z: 0, 0)
    try:
        obj.__setattr__("w",0)
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:20:35.458134
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer

# Generated at 2022-06-26 02:20:38.423327
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('A', 'B', 'C')
    assert 'A' in str(e)
    assert 'B' in str(e)
    assert 'C' in str(e)



# Generated at 2022-06-26 02:20:41.465768
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    instance = IllegalUseOfScopeReplacer('(name)', 'Test')
    expected = u'Test'
    actual = instance.__unicode__()
    assert expected == actual


# Generated at 2022-06-26 02:20:45.621066
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    f = IllegalUseOfScopeReplacer(u'unicode_arg', u'unicode_msg')
    expected = u'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'
    got = f.__unicode__()
    assert got == expected, '%r == %r' % (got, expected)


# Generated at 2022-06-26 02:20:48.535102
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Only tests the ascii part of the __str__ method
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == ("ScopeReplacer object 'name' was used incorrectly:"
                      " msg")



# Generated at 2022-06-26 02:20:59.317977
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import disallow_proxying
    from bzrlib.lazy_import import allow_proxying

    global basic_test_import_lazy

    class test_ScopeReplacer___setattr__(TestCase):
        def test_0(self):
            # This test is a bit tricky to understand, the idea is
            # to make sure that we don't incorrectly cache the scope_0.
            # If we did, then eval('var_0.name') would fail,
            # but as long as we don't then all is well.
            scope_0 = {}
            # Method body line a bit ugly because we can't use globals()
            # directly until lazy_import is

# Generated at 2022-06-26 02:21:09.183098
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    _tests = {
        # test with a preformatted message
        0 :
        {'in' :
         { 'name' : 'var_0',
         'msg' : 'msg_0',
         'extra' : 'extra_0',
         '_preformatted_string' : 'msg_0 extra_0',
         },
         'out' : u'msg_0 extra_0'
         },
        }
    _errors = [
        ]
    _failures = [
        ]
    for _i in range(len(_tests)):
        _test = _tests[_i]
        _in = _test['in']
        _out = _test['out']
        var_0 = IllegalUseOfScopeReplacer(_in['name'], _in['msg'], _in['extra'])
        setattr

# Generated at 2022-06-26 02:21:10.615299
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    var_1 = var_0.__unicode__()


# Generated at 2022-06-26 02:21:39.716702
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from StringIO import StringIO
    from unittest import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    _stdout = sys.stdout
    sys.stdout = StringIO()

    # Test Unicode handling in IllegalUseOfScopeReplacer.__unicode__
    class FakeGettext(object):
        def ugettext(self,s):
            return unicode(s)
    class FakeGettextModule(object):
        gettext = FakeGettext()

    # Test standard usage
    class TestCase(TestCase):
        def test_case_0(self):
            var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')

    # Test without a '_fmt' attribute

# Generated at 2022-06-26 02:21:48.360404
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer

    # Caller must pass a string, which is the name of a class or function
    # defined in this module.
    def get_class_for_name(name):
        return globals()[name]

    scope = {}
    scope_replacer_class = get_class_for_name("ScopeReplacer")
    scope_replacer = scope_replacer_class(
        scope,  # scope
        get_class_for_name,  # factory
        "ScopeReplacer"  # name
        )
    scope_replacer._should_proxy = False
    scope_replacer.x = 42
    scope["ScopeReplacer"] = scope_replacer

    # The object can be called as a function.
    scope_replacer2 = scope_replacer
    scope_

# Generated at 2022-06-26 02:21:49.440838
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:21:53.516641
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # See http://www.voidspace.org.uk/python/mock/examples.html#checking-multiple-calls-with-one-mock
    # for examples
    var_0 = ScopeReplacer()
    var_0.__call__()



# Generated at 2022-06-26 02:21:55.324765
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_10 = ScopeReplacer(scope = None,factory = None,name = None)


# Generated at 2022-06-26 02:22:05.440510
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(globals(), generate_real_obj_from_factory, "var_0")
    try:
        var_0 = ScopeReplacer(globals(), generate_real_obj_from_factory, "var_0")
        var_0.test = 0
        var_2 = var_0.test
        var_3 = 1
        var_4 = (var_2 == var_3)
    except:
        var_4 = False

    var_5 = False
    var_6 = (not var_4)

# Generated at 2022-06-26 02:22:10.772257
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = test_case_0()
    # method __str__
    case_0.assertItemsEqual(case_0.__str__().split(), ['Unprintable', 'exception', 'IllegalUseOfScopeReplacer:', 'dict={},', 'fmt=None,', 'error=None'])
    return case_0


# Generated at 2022-06-26 02:22:14.707443
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Call methods so that we can be sure they exist
    scope_replacer = ScopeReplacer.__new__(ScopeReplacer)
    scope_replacer.__init__()
    scope_replacer.__setattr__('test_attr_0', None)


# Generated at 2022-06-26 02:22:19.494265
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = allow_proxying()
    var_1 = ScopeReplacer(globals(), lambda self, scope, name: scope[name], 'var_0')
    globals()['var_1']
    test_case_0()


# Generated at 2022-06-26 02:22:24.806243
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__"""
    eq_(
        "ScopeReplacer object 'foo' was used incorrectly: "
        "its module was not fully loaded: "
        "insufficient data to determine.",
        IllegalUseOfScopeReplacer(
            'foo',
            "its module was not fully loaded",
            extra="insufficient data to determine.").__str__()
        )


# Generated at 2022-06-26 02:22:40.844012
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Test that __unicode__ returns a unicode object.
    # self.assertIsInstance(self, unicode) doesn't always work because
    # of __nonzero__.
    #
    # Use of var_0 is undefined.
    var_0 = IllegalUseOfScopeReplacer('self', 'msg')
    # Test that __unicode__ returns a unicode object.
    # self.assertIsInstance(self, unicode) doesn't always work because
    # of __nonzero__.
    return var_0.__unicode__()


# Generated at 2022-06-26 02:22:42.685738
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    str_0 = IllegalUseOfScopeReplacer("domain", "message", "extra")
    str_1 = str_0.__str__()


# Generated at 2022-06-26 02:22:45.733931
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    x = IllegalUseOfScopeReplacer('a', 'b', 'c')
    x.__str__()


# Generated at 2022-06-26 02:22:49.936596
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    exp = 'name: msg: extra'
    res = str(e)
    assert exp == res


# Generated at 2022-06-26 02:22:52.494962
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')



# Generated at 2022-06-26 02:23:03.693355
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    from bzrlib.lazy_import import BadModuleName
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer

    a = IllegalUseOfScopeReplacer('name', 'msg')
    a.value = 'value'
    a.something = 'something'
    str(a)
    # <TestCase test method __str__ of class IllegalUseOfScopeReplacer>
    b = IllegalUseOfScopeReplacer('foo', 'bar', 'extra info')
    str(b)
    # 'ScopeReplacer object \'foo\' was used incorrectly: bar: extra info'
    c = IllegalUseOfScopeReplacer('foo', 'bar', 'extra info')
    c.__dict__ == b

# Generated at 2022-06-26 02:23:04.614097
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()


# Generated at 2022-06-26 02:23:15.256649
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from StringIO import StringIO
    from StringIO import StringIO
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    s = IllegalUseOfScopeReplacer('var_0', 'var_1', 'var_2')
    var_3 = StringIO()
    s.print_unicode(file=var_3)
    var_4 = var_3.getvalue()
    var_4 = u'IllegalUseOfScopeReplacer: var_0\nvar_1: var_2\n'
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    s = IllegalUseOfScopeReplacer('var_0', 'var_1')
    var_5 = StringIO()
    s.print_unicode(file=var_5)
    var_6 = var_5

# Generated at 2022-06-26 02:23:16.229203
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()



# Generated at 2022-06-26 02:23:28.275742
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # __getattribute__ must delegate to the real object if it exists.
    def _create_obj_with_getattribute(replacer, scope, name):
        class _ObjWithGetattribute(object):
            def __getattribute__(self, attr):
                return "this is the result"
        return _ObjWithGetattribute()

    obj = ScopeReplacer(locals(), _create_obj_with_getattribute, 'obj')

# Generated at 2022-06-26 02:24:09.650195
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class module(object):
        pass
    class_0 = IllegalUseOfScopeReplacer(var_0, var_0)

# Generated at 2022-06-26 02:24:20.170883
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from unittest import TestCase
    class test_case_1(TestCase):
        def runTest(self):
            from bzrlib import lazy_import
            import bzrlib.lazy_import
            self.assertEqual(bzrlib.lazy_import.lazy_import,
                             lazy_import)
    test_case_1().runTest()

    def test_case_2():
        import bzrlib.lazy_import
        self.assertIs(bzrlib.lazy_import, bzrlib.lazy_import)

    # The following is a list of tuples of the form
    # (ename, expected_value, value).
    #
    # ename: The exception name, i.e. 'ScopeReplacer'
    # expected_value: The exception message to

# Generated at 2022-06-26 02:24:25.393699
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    replacement_scope = {'lazy_import':lazy_import, 'test_case_0':test_case_0}
    lazy_import.lazy_import(replacement_scope,
        '''
        from bzrlib.lazy_import import ScopeReplacer
        ''')
    replacement_scope['test_case_0']()
    var_0 = replacement_scope['ScopeReplacer']
    replacement_scope['test_case_0']()
    return


# Generated at 2022-06-26 02:24:38.338638
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    from bzrlib.lazy_import import ScopeReplacer

    # no scope
    obj_0 = ScopeReplacer(
        None,
        lambda x, scope, name: None,
        'real_obj')
    try:
        try:
            # Attempt to invoke method __setattr__ of object obj_0
            obj_0.__setattr__('_real_obj',
                              'real_obj')
            pass
        except IllegalUseOfScopeReplacer:
            pass
    finally:
        # Restore object 'obj_0'
        obj_0._scope['real_obj'] = 'real_obj'

    # with scope
    obj_1 = ScopeReplacer(
        sys.modules,
        lambda x, scope, name: None,
        'real_obj')

# Generated at 2022-06-26 02:24:45.999203
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    sys.modules[test_lazy_import.__module__] = test_lazy_import
    global var_0
    var_0 = ScopeReplacer(globals(), test_case_0)
    var_0
    try:
        var_1 = var_0
    except Exception as var_2:
        print('Caught exception: ' + repr(var_2))
    else:
        print('Uncaught exception')
    try:
        var_1
    except Exception as var_3:
        print('Caught exception: ' + repr(var_3))
    else:
        print('Uncaught exception')
    return 0

# Generated at 2022-06-26 02:24:47.483664
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # FIXME: currently this is not callable.
    pass


# Generated at 2022-06-26 02:24:51.718827
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer(
        'e',
        'Message 1',
        extra='Message 2',
        )
    s = str(e)
    assert 'IllegalUseOfScopeReplacer' in s
    assert 'Message 1' in s
    assert 'Message 2' in s
    assert 'e' in s


# Generated at 2022-06-26 02:24:53.716779
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__()

    Try to decode the str using the default encoding.
    """


# Generated at 2022-06-26 02:24:56.892738
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():

    def check_with_disabled_proxying(f):
        var_0 = disallow_proxying()
        return f()
    var_1 = check_with_disabled_proxying(test_case_0)



# Generated at 2022-06-26 02:25:01.098875
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    this_module = lazy_import.lazy_import
    test_case_0()
