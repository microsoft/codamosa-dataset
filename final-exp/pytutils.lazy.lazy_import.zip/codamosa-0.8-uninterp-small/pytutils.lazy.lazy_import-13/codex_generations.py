

# Generated at 2022-06-26 02:16:04.174683
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import my_function

    scope = {}
    var_0 = ScopeReplacer(scope, my_function, 'var_0')

    # Verify that call works for lazy imported objects.
    var_0(1)

    # Replace 'var_0' with its real object, check that call still works.
    scope['var_0'] = scope['var_0']._resolve()
    scope['var_0'](2)

    # Disable proxying, so any attempt to call will fail
    # and cause an exception to be raised.
    test_case_0()

    # Now call 'var_0' again and the following statement
    # should fail with the appropriate exception.

# Generated at 2022-06-26 02:16:07.238890
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Var 0 (type ScopeReplacer)
    test_case_0()



# Generated at 2022-06-26 02:16:11.541437
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test for IllegalUseOfScopeReplacer.__str__()"""
    var_1 = IllegalUseOfScopeReplacer('var_0', 'var_1', 'var_2')
    var_2 = var_1.__str__()


# Generated at 2022-06-26 02:16:14.502822
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exc = IllegalUseOfScopeReplacer('foo', 'bar')
    expected = "ScopeReplacer object 'foo' was used incorrectly: bar"
    actual = str(exc)
    assert actual == expected


# Generated at 2022-06-26 02:16:15.701157
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = disallow_proxying()



# Generated at 2022-06-26 02:16:23.767155
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test cases for method __str__ of class IllegalUseOfScopeReplacer
    """

    test_0 = IllegalUseOfScopeReplacer('var_0', 'var_1', 'var_2')
    test_0.__str__()
    test_1 = IllegalUseOfScopeReplacer('var_3', 'var_4', 'var_5')
    test_1.__str__()
    test_2 = IllegalUseOfScopeReplacer('var_6', 'var_7', 'var_8')
    test_2.__str__()
    test_3 = IllegalUseOfScopeReplacer('var_9', 'var_10', 'var_11')
    # Cause: TypeError
    # See 'test_case_3'

# Generated at 2022-06-26 02:16:33.998146
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = disallow_proxying()
    var_1 = ScopeReplacer
    var_2 = ScopeReplacer.__setattr__
    var_3 = ScopeReplacer.ScopeReplacer
    var_4 = var_3.__setattr__,
    var_5 = ScopeReplacer.__init__
    var_6 = var_3.__init__,
    var_7 = '_name'
    var_8 = ScopeReplacer._name
    var_9 = var_3._name,
    var_10 = var_3._name
    var_11 = '_should_proxy'
    var_12 = ScopeReplacer._should_proxy
    var_13 = var_3._should_proxy,
    var_14 = var_3._should_proxy
    var_15 = '_real_obj'


# Generated at 2022-06-26 02:16:40.100670
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Test for method __setattr__ of class ScopeReplacer"""

    # Can set attributes in normal use
    name = 'name'
    scope = {name: None}
    factory = lambda x,sc,n: sc[n]
    obj = ScopeReplacer(scope, factory, name)
    obj.foo = 'bar'
    assert obj.foo == 'bar'
    assert scope[name].foo == 'bar'

    # Can set attributes when proxying is disabled
    try:
        obj.foo = 'baz'
    except IllegalUseOfScopeReplacer:
        test_case_0()



# Generated at 2022-06-26 02:16:46.154922
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    from UserString import MutableString
    var_0 = IllegalUseOfScopeReplacer(None, None)
    var_1 = IllegalUseOfScopeReplacer(None, None)
    assert var_0 == var_0
    try:
        var_2 = IllegalUseOfScopeReplacer(None, None)
        assert var_0 != var_2
    except TypeError:
        var_2 = MutableString(None)
    try:
        var_3 = IllegalUseOfScopeReplacer(None, None)
        assert var_0 != var_3
    except TypeError:
        var_3 = MutableString(None)
    return


# Generated at 2022-06-26 02:16:57.481116
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class test_ScopeReplacer___call__(TestCase):
        '''Unit test for method __call__ of class ScopeReplacer'''

        def test_case_0(self):
            '''Test for ScopeReplacer.__call__.

            Test a simple call using the default factory.
            '''
            class SomeObject(object):
                def __init__(self):
                    self.some_value = 42

            def special_factory(scope_replacer, scope, name):
                return SomeObject()

            scope = { }
            var_0 = ScopeReplacer(scope, special_factory, 'some_var')
            var_0()

# Generated at 2022-06-26 02:17:39.762185
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import re
    import sys

    name = '__setattr__ on %r' % ScopeReplacer
    factory = _create_factory(ScopeReplacer)
    scope = {}
    scope.update(globals())
    scope.update(locals())

    scope_replacer = factory(scope, name)

    test_setattr = 'test_setattr'
    scope_replacer.test_setattr = 'value of test_setattr'

    msg = 'ScopeReplacer.__setattr__ with attr=%r and value=%r.' \
        % (test_setattr, scope_replacer.test_setattr)
    name0 = 'test_setattr on %r' % scope_replacer
    test_result = scope_replacer.test_setattr == 'value of test_setattr'
    verify

# Generated at 2022-06-26 02:17:45.912662
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    var_0 = bzrlib.tests.blackbox.test_lazy_import.test_case_0()


# Generated at 2022-06-26 02:17:49.177164
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    inst_ = ScopeReplacer(globals(), lambda o,s,n:None, 'inst_')



# Generated at 2022-06-26 02:18:00.364937
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """When the value of 'fmt' is not set, IllegalUseOfScopeReplacer.__str__
    should return a string representation of self.
    """
    import random
    import string

    def random_string():
        # Creates a random string of ASCII characters of length
        # random.choice(range(10))
        return ''.join(random.choice(string.ascii_letters)
            for i in range(random.choice(range(10))))
    c = random.choice
    for i in range(10):
        name = random_string()
        msg = random_string()
        extra = random_string()
        exception = IllegalUseOfScopeReplacer(name, msg, extra)
        s = str(exception)
        assert s.startswith("IllegalUseOfScopeReplacer("), s
        assert s

# Generated at 2022-06-26 02:18:01.909998
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib import lazy_import
    var_0 = lazy_import.ScopeReplacer()
    var_0.__call__()


# Generated at 2022-06-26 02:18:06.681156
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    expected = None
    var_0 = IllegalUseOfScopeReplacer('foo', "bar", "baz")
    actual = var_0.__unicode__()
    assert expected == actual


# Generated at 2022-06-26 02:18:11.684601
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import

    # A case where ScopeReplacer._should_proxy == True
    global glob_0, var_0
    glob_0 = {}
    glob_0['var_0'] = None
    lazy_import(glob_0, 'from bzrlib.tests.per_lazy_import import test_case_0')
    var_0 = glob_0['var_0']
    # This should not raise an error
    var_0.attribute_0 = None


# Generated at 2022-06-26 02:18:23.110949
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Create an instance of ScopeReplacer
    var_1 = disallow_proxying()
    var_2 = 'ScopeReplacer'
    var_3 = ScopeReplacer.__init__
    var_4 = ScopeReplacer
    var_5 = var_3(var_4, var_1, var_2)
    # Assign '_factory'
    var_6 = '_factory'
    var_7 = ScopeReplacer.__setattr__
    var_8 = ScopeReplacer
    var_9 = '_name'
    var_10 = var_7(var_8, var_9, var_6)
    return var_10


# Generated at 2022-06-26 02:18:25.440548
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    space = {}
    lazy_import(space, 'bzrlib.lazy_import')
    test_case_0()


# Generated at 2022-06-26 02:18:31.727458
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    _factory = lambda s, sc, n: object()
    _scope = {}
    _name = "foo"
    s = ScopeReplacer(_scope, _factory, _name)

# Generated at 2022-06-26 02:18:49.545869
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_1 = ScopeReplacer(None, None, None)
    try:
        var_1.__setattr__("1", "2")
    except IllegalUseOfScopeReplacer as err:
        var_4 = str(err)
        var_3 = True
    else:
        var_3 = False

    var_0 = var_3
    return var_0


# Generated at 2022-06-26 02:19:00.380726
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # This test fails on platforms where the encoding is not utf-8.
    try:
        var_1 = unicode('hello world')
    except UnicodeError:
        return
    var_0 = IllegalUseOfScopeReplacer(None, var_1)
    var_2 = unicode(var_0)
    assert var_2 == u'hello world'
    var_3 = IllegalUseOfScopeReplacer('name', var_1)
    var_4 = unicode(var_3)
    assert var_4 == u'name: hello world'
    var_5 = IllegalUseOfScopeReplacer('name', var_1, 'extra')
    var_6 = unicode(var_5)
    assert var_6 == u'name: hello world: extra'


from bzrlib.lazy_import import allow_pro

# Generated at 2022-06-26 02:19:07.037654
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.trace import mutter
    import sys
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    # Test that the function returns the correct value by default
    global_scope = globals()
    bzrlib_lazy_import_lazy_import = global_scope.get('bzrlib.lazy_import.lazy_import')
    ScopeReplacer_test_var_0 = global_scope.get('test_var_0')

# Generated at 2022-06-26 02:19:14.380775
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """test_ScopeReplacer___call__

    Unit test for method __call__ of class ScopeReplacer
    """
    import tempfile
    import bzrlib.controldir
    wt = bzrlib.workingtree.WorkingTree.open(tempfile.gettempdir(),
        transport=None)
    var_0 = wt.is_versioned('foo')


# Generated at 2022-06-26 02:19:16.127968
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    obj = IllegalUseOfScopeReplacer(var_0, )
    assert str(obj) == ''


# Generated at 2022-06-26 02:19:19.983355
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import (
        ScopeReplacer,
        lazy_import,
        )
    # construction
    var_0 = ScopeReplacer(None, None, None)
    # __getattribute__

# Generated at 2022-06-26 02:19:26.980489
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.lazy_import_test_case import (
        LazyImportTestCase,
        )
    from bzrlib.lazy_import import (
        lazy_import,
        )

    class LocalException(Exception):
        pass

    class TestScopeReplacer(LazyImportTestCase):
        def test_setattr(self):
            self.assertNotIn('var_0', self.globals)
            self.lazy_import(self.globals, """
            var_0 = disallow_proxying()
            """)
            self.assertIn('var_0', self.globals)
            self.globals['var_0'] = 2

# Generated at 2022-06-26 02:19:30.446094
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(),
                          ScopeReplacer._resolve,
                          'var_0')
    var_1 = var_0()
    var_1 = var_0()


# Generated at 2022-06-26 02:19:33.161810
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer('var_0', 'var_1')
    var_1 = var_0.__unicode__()
    pass


# Generated at 2022-06-26 02:19:35.096481
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = test_case_0()
    assert case_0.__str__() == ""


# Generated at 2022-06-26 02:19:53.090022
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    global var_0
    var_0 = IllegalUseOfScopeReplacer()
    var_0.a = 1
    var_0.b = 2
    var_0.c = 3
    var_0._fmt = "Attribute %(a)r and %(b)r and %(c)r."
    try:
        var_0.__unicode__()
    except Exception as var_1:
        var_2 = var_1
    var_3 = var_0.__repr__()
    try:
        var_0.__unicode__()
    except Exception as var_4:
        var_5 = var_4


# Generated at 2022-06-26 02:20:01.418645
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import sys
    name = "bogus"
    msg = "mcs was used incorrectly"
    extra = None

# Generated at 2022-06-26 02:20:09.702367
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.branch
    import bzrlib.errors
    var_0 = ScopeReplacer('bzrlib.branch', '_factory', '_name')
    var_1 = bzrlib.branch.__getattribute__(var_0, '_resolve')()
    var_1 = getattr(var_1, '_resolve')
    var_2 = var_1()
    var_1 = getattr(var_2, '_resolve')
    var_2 = var_1()
    var_2 = hasattr(var_2, '_orig_open_with_history')


# Generated at 2022-06-26 02:20:18.660306
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class test_IllegalUseOfScopeReplacer___str__(TestCase):
        """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
        def setUp(self):
            super(test_IllegalUseOfScopeReplacer___str__, self).setUp()
            pass
        def test_0(self):
            var_0 = IllegalUseOfScopeReplacer('', '')
            var_0.name = 'foo'
            var_0.msg = 'bar'
            var_0.extra = 'baz'
            str(var_0)
            str(var_0)

# Generated at 2022-06-26 02:20:24.470638
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    global var_0
    from bzrlib.lazy_import import test_case_0
    scope_rep_obj_0 = ScopeReplacer(
        globals(),
        test_case_0,
        'var_0')
    scope_rep_obj_0()


# Generated at 2022-06-26 02:20:26.864339
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer('a', 'b', 'c')
    var_0.__setattr__('d', 'e')


# Generated at 2022-06-26 02:20:36.363499
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    var_3 = lazy_import(globals(), 'bzrlib.lazy_import')
    # Call method __call__ of class ScopeReplacer
    # var_1 = var_0('test_case_0', var_0.test_case_0, 'var_0')
    # Call function disallow_proxying of module lazy_import
    # var_2 = var_3.disallow_proxying()
    # Call method __call__ of class ScopeReplacer
    # var_1('', '', '')
    import bzrlib.lazy_import
    bzrlib.lazy_import.disallow_proxying()



# Generated at 2022-06-26 02:20:40.201163
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__"""
    exc = IllegalUseOfScopeReplacer("A", "B")
    assert str(exc) == "Unprintable exception IllegalUseOfScopeReplacer: dict={'name': 'A', 'extra': '', 'msg': 'B'}, fmt=None, error=None"


# Generated at 2022-06-26 02:20:41.800344
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_1 = IllegalUseOfScopeReplacer()


# Generated at 2022-06-26 02:20:42.715737
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass


# Generated at 2022-06-26 02:21:04.975835
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer()
    var_0.Unprintable_exception_IllegalUseOfScopeReplacer_dict__r_fmt__r_error__r = u"Unprintable exception IllegalUseOfScopeReplacer: dict={'extra': '', 'name': 'NoNameGiven', 'msg': 'NoMessageGiven'}, fmt='%(__class__)s throws an exception.  dict=(%(__dict__)s)', error=None"
    var_1 = var_0._format()
    assert var_1 == "Unprintable exception IllegalUseOfScopeReplacer: dict={'extra': '', 'name': 'NoNameGiven', 'msg': 'NoMessageGiven'}, fmt='%(__class__)s throws an exception.  dict=(%(__dict__)s)', error=None", var_1

# Generated at 2022-06-26 02:21:09.939397
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()

# Generated at 2022-06-26 02:21:11.812784
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer(
        "var_0",
        "msg_0",
        )
    s = unicode(e)


# Generated at 2022-06-26 02:21:19.357406
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import tempfile
    filename = tempfile.mktemp()
    try:
        f = file(filename, "wb")
        try:
            f.write("\x00\x00\x00\x00")
            f.seek(0, 0)
            f.write("\x01\x00\x00\x00")
        finally:
            f.close()
    finally:
        pass


# Generated at 2022-06-26 02:21:26.270770
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self) -> unicode

    In Python 2.6+, __unicode__ is an alias for __str__, so this should
    work in the same way.
    """

    err = IllegalUseOfScopeReplacer('lalala', 'message')
    result = err.__unicode__()
    assert isinstance(result, unicode), \
        "__unicode__ did not return an unicode object"


# Generated at 2022-06-26 02:21:28.389143
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Try to make a simple case work"""
    var_1 = IllegalUseOfScopeReplacer(None, None)


# Generated at 2022-06-26 02:21:32.292163
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    x = IllegalUseOfScopeReplacer("abc", "def")
    assert x.__str__() is not None
    assert x.__repr__() is not None


# Generated at 2022-06-26 02:21:33.085361
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    pass



# Generated at 2022-06-26 02:21:36.247022
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(globals(), lambda f, s, n: None, 'var_0')
    obj.__setattr__('attr_0', 1)
    assert obj.attr_0 == 1


# Generated at 2022-06-26 02:21:41.505327
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib import _lazy_import
    import unittest
    test_case_instance = unittest.TestCase()
    global_var_0 = IllegalUseOfScopeReplacer(1, 2, 3)
    test_case_instance.assertEqual(
        global_var_0.__unicode__(),
        # expected value (unicode string)
        u"IllegalUseOfScopeReplacer object 1 was used incorrectly: 2: 3")


# Generated at 2022-06-26 02:21:58.423789
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    global var_0
    var_0 = IllegalUseOfScopeReplacer("branch", "branch is not a module", "failed to load module 'bzrlib.branch': No module named branch")
    if (repr(var_0) != "IllegalUseOfScopeReplacer('branch', 'branch is not a module', 'failed to load module %r: No module named branch')"):
        raise AssertionError

if (__name__ == '__main__'):
    test_case_0()

# Generated at 2022-06-26 02:22:08.290968
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    def _test():
        from bzrlib.lazy_import import ScopeReplacer
        mock = Mock()
        mock._name = 'foobar'
        mock._factory = lambda x, y, z: x
        mock._scope = {}
        mock._real_obj = None
        new_obj = object()
        mock.__setattr__('new_attr', new_obj)
        return mock._real_obj['new_attr']


# Generated at 2022-06-26 02:22:17.354887
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer, test_case_0, disallow_proxying
    # once proxying is disabled _should_proxy will be set to False
    scope = {'disallow_proxying': lambda: ScopeReplacer._should_proxy}
    test_case_0(scope)
    var_0 = scope['var_0']
    expected = False
    got = var_0
    if (expected != got):
        raise AssertionError("got %r, expected %r" % (got, expected))


# Generated at 2022-06-26 02:22:24.435297
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import bzrlib.lazy_import as Mlazy_import
    factory_0 = lambda self_0, scope_0, name_0: str(name_0)
    name_0 = 'module'
    var_0 = Mlazy_import.ScopeReplacer(locals(), factory_0, name_0)
    if (not (var_0() == 'module')):
        raise AssertionError
    if (not ('module' in locals())):
        raise AssertionError


# Generated at 2022-06-26 02:22:30.056344
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import bzrlib

    object_0 = IllegalUseOfScopeReplacer('name_0', 'msg_0')
    string_0 = _format(object_0)
    str_0 = str(object_0)
    # Do the assertion
    assert str_0 == string_0


# Generated at 2022-06-26 02:22:41.208370
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib._pychecker_skips import skip_pychecker
    from bzrlib.tests import TestCase
    from bzrlib.tests.features import UnicodeFilenameFeature
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import os
    filename_u = u'\u03a3.txt'
    filename_u_encoded = filename_u.encode('utf8')
    filename_bytes = str(filename_u)
    #for space in ['', ' ']:
    #    for newline in ['', '\n']:
    #        for suffix in ['', ' \n', '\n ']:
    #            for prefix in ['', ' ', '\n']:
    #                for prefix2 in ['', ' ', '\n']:
    #                    for suffix

# Generated at 2022-06-26 02:22:43.059925
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    case_0 = test_case_0()


# Generated at 2022-06-26 02:22:45.432802
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self: bzrlib.lazy_import.IllegalUseOfScopeReplacer) -> unicode"""
    pass


# Generated at 2022-06-26 02:22:48.459347
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test_IllegalUseOfScopeReplacer___str__()"""
    local_test_case_0()


# Generated at 2022-06-26 02:22:58.400531
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import sys
    import os
    import time
    import re
    import bzrlib.lazy_import
    var_0 = disallow_proxying()
    try:
        var_0 = IllegalUseOfScopeReplacer('var_0', 'var_0', 'var_0')
        # The test-specific part of this test-case starts here
        var_1 = None
        # The test-specific part of this test-case ends here
    except Exception as var_2:
        var_1 = var_2
    if (var_1 is not None):
        raise var_1
    return None


# Generated at 2022-06-26 02:24:12.256855
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exc = IllegalUseOfScopeReplacer('var_0', 'msg', 'extra')
    # The __str__ method should return a unicode string.
    str(exc)
    # The __str__ method should return a unicode string.



# Generated at 2022-06-26 02:24:17.593211
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test for case where instance was not called.
    # 
    # Test for case where the resolver does not return an object.
    # 
    # Test for case where a duplicate object is installed in the scope.
    # 
    # Test for case where method __call__ of class 
    # ScopeReplacer is called.
    # 
    # Test that the callable returns the correct object.
    # 
    # Test that the callable returns the correct result.

    def _factory(s, scope, name):
        if name == 'var_0':
            return 42
        elif name == 'var_1':
            return lambda: 42
        elif name == 'var_2':
            return lambda x:x
        return object()
    name = 'var_3'
    scope = locals()
    global ScopeRepl

# Generated at 2022-06-26 02:24:18.771263
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        var_0 = disallow_proxying()
    except Exception as var_1:
        pass



# Generated at 2022-06-26 02:24:22.577686
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    err = IllegalUseOfScopeReplacer("var_0", "msg_0", "extra_0")
    got = str(err)
    msg = "got '%s', expected 'ScopeReplacer object var_0 was used incorrectly: msg_0: extra_0'"
    assert got == "ScopeReplacer object var_0 was used incorrectly: msg_0: extra_0", msg % got


# Generated at 2022-06-26 02:24:24.287599
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    self = IllegalUseOfScopeReplacer('self', 'self',)
    # self.__unicode__()
    # verify expectation


# Generated at 2022-06-26 02:24:31.513675
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from StringIO import StringIO
    out = StringIO()
    err = StringIO()
    def redirect_stdout(out_, err_):
        print >> out_, "Hello world"
        print >> err_, "This is an error"
    redirect_stdout(out, err)
    # end test body



# Generated at 2022-06-26 02:24:39.625288
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # This method is a little difficult to test.
    # What we really want to test is that an attribute returned from
    # __getattribute__ is itself a ScopeReplacer, so that this method gets
    # called again.
    vars = {}
    lazy_import(vars, '''
    from bzrlib.lazy_import import test_case_0
    ''')

# Generated at 2022-06-26 02:24:41.862914
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """
    >>> i = IllegalUseOfScopeReplacer('1', '2', '3')
    >>> str(i)
    """


# Generated at 2022-06-26 02:24:44.551975
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__ - check __setattr__ with a new attribute"""
    pass # TODO implement test for __setattr__(ScopeReplacer, 'attr', value)



# Generated at 2022-06-26 02:24:47.274326
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    with_0 = test_case_0()
    out_0 = IllegalUseOfScopeReplacer(u'disallow_proxying', u'', '')
    assert(isinstance(out_0, IllegalUseOfScopeReplacer))
    eq_0 = (out_0.__unicode__() is not None)
    assert eq_0
