

# Generated at 2022-06-26 02:16:14.382247
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.test_lazy_import import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestImportAndInit(TestCase):
        def test_import_and_initialize(self):
            scope = {}
            # This example is useful for testing because fake.Foo has
            # an __init__ method that takes an argument.
            ScopeReplacer(scope,
                lambda self, scope, name: __import__('bzrlib.fake').Foo(5),
                'Foo')
            self.assertEqual(5, scope['Foo'].value)
            self.assertEqual(scope['Foo'].value, scope['Foo'].value)
    TestImportAndInit().test_import_and_initialize()
    return TestImportAndInit


# Generated at 2022-06-26 02:16:17.059042
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-26 02:16:24.083029
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox as tests_blackbox # module autoimport
    # Local variable __builtin__.__setattr__ has a value,
    # which is a builtin function or method.
    __builtin__.__setattr__ = __builtin__.__setattr__
    # Local variable import_processor_0 has a value,
    # which is an instance of class ImportProcessor.
    import_processor_0 = tests_blackbox.ImportProcessor()
    # Local variable passed_attr_attr has a value,
    # which is an instance of class ScopeReplacer.
    passed_attr_attr = import_processor_0
    # Local variable passed_attr_value_0 has a value,
    # which is an instance of class ScopeReplacer.
    passed_attr_value_0 = import_processor_0

# Generated at 2022-06-26 02:16:34.091209
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib
    import bzrlib.tests
    import bzrlib.errors
    import bzrlib.tests.blackbox
    mock_bzr = bzrlib.tests.mock_bzr
    import bzrlib.tests.mock_bzr
    import bzrlib.trace
    import bzrlib.tests.script
    from bzrlib.tests import TestCase, TestSkipped
    from bzrlib.trace import mutter
    import bzrlib.osutils
    import bzrlib.transport
    import bzrlib.bzrdir
    import bzrlib.tests.test_memorytree
    import_processor_1 = ImportProcessor()
    # Init of class ImportProcessor
    obj = bzr

# Generated at 2022-06-26 02:16:39.240524
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # __unicode__() returns a unicode object
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = unicode(e)
    expected = u"ScopeReplacer object 'name' was used incorrectly: msg"
    if s != expected:
        raise AssertionError('%r != %r' % (s, expected))



# Generated at 2022-06-26 02:16:41.856601
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from testtools.matchers import Raises
    from testtools import TestCase
    class test_case_0(TestCase):
        def test_0(self):
            import_processor_0 = ImportProcessor()
            test_case_0.assertThat(import_processor_0.__setattr__("r",
                import_processor_0), Raises(IllegalUseOfScopeReplacer))



# Generated at 2022-06-26 02:16:43.963117
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    x = ScopeReplacer(None, None, None)
    x()



# Generated at 2022-06-26 02:16:56.198475
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # test the call with args
    try:
        raise IllegalUseOfScopeReplacer('name1', 'msg', 'extra')
    except IllegalUseOfScopeReplacer as e:
        assert e.__unicode__() == u"ScopeReplacer object 'name1' was used incorrectly: msg: extra"
    # test the call without args
    try:
        raise IllegalUseOfScopeReplacer('name1', 'msg')
    except IllegalUseOfScopeReplacer as e:
        assert e.__unicode__() == u"ScopeReplacer object 'name1' was used incorrectly: msg"
    # test the call with a preformatted message

# Generated at 2022-06-26 02:16:58.961888
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import bzrlib.tests
    bzrlib.tests.run_doctest('bzrlib.lazy_import')

test_case_0()

test_IllegalUseOfScopeReplacer___unicode__()


# Generated at 2022-06-26 02:17:05.400874
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert e.__unicode__() == u'bar'


# Generated at 2022-06-26 02:17:22.653714
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    try:
        __instance = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    except:
        import traceback
        exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
        traceback.print_exception(exceptionType, exceptionValue, exceptionTraceback,
                                  limit=10, file=sys.stdout)

    assert __instance.__unicode__() is not None



# Generated at 2022-06-26 02:17:24.711988
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    test_case_0()

# Unit tests for methods of class ScopeReplacer

# Generated at 2022-06-26 02:17:27.136718
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # tested by test_case_0


# Generated at 2022-06-26 02:17:35.895553
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import StringIO
    s = StringIO.StringIO()
    try:
        e = IllegalUseOfScopeReplacer("name", "msg", "extra")
    except:
        import sys
        s.write('test_IllegalUseOfScopeReplacer___unicode__():  Exception raised')
        traceback.print_exc(file=s)
    else:
        s.write('test_IllegalUseOfScopeReplacer___unicode__():  No Exception')

# Generated at 2022-06-26 02:17:46.704945
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__(self):

    Return a unicode representation of the exception.
    """
    import_processor_0 = ImportProcessor()
    name_0 = "import_processor_1"
    msg_0 = '<Not Yet Implemented>'
    extra_0 = None
    illegal_use_of_scope_replacer_0 = IllegalUseOfScopeReplacer(name_0,
                                                                msg_0,
                                                                extra_0)
    unicode_0 = unicode(illegal_use_of_scope_replacer_0)


# Generated at 2022-06-26 02:17:58.741886
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import import_processor_0

    # call ScopeReplacer.__call__ w/ trivial args
    x = import_processor_0.ScopeReplacer( {}, lambda _1,_2,_3: None, 'x' )
    import_processor_0.ScopeReplacer.__call__( x,  (),  {} )
    # call ScopeReplacer.__call__ w/ complex args
    # test return value
    x = import_processor_0.ScopeReplacer( {}, lambda _1,_2,_3: None, 'x' )
    import_processor_0.ScopeReplacer.__call__( x,  (),  {} )
    pass


# Generated at 2022-06-26 02:18:10.726750
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys

    #Basic test
    try:
        raise IllegalUseOfScopeReplacer(u'lazy_import', u'wrong use of lazy_import', u'an extra argument')
    except IllegalUseOfScopeReplacer:
        exception = sys.exc_info()[1]
    u1 = u"IllegalUseOfScopeReplacer object %(name)r was used incorrectly:"\
        " %(msg)s%(extra)s: an extra argument"
    u2 = unicode(exception)
    assert u1 == u2, u"%r != %r" % (u1, u2)

    #Test if __unicode__ returns 'unicode' object
    u3 = u2 + u'z'
    assert not isinstance(u3, str), u"%s is a str" % (u3,)


# Generated at 2022-06-26 02:18:12.269709
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-26 02:18:14.577319
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    import_processor_0


# Generated at 2022-06-26 02:18:16.772506
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    msg = 'abc'
    e = IllegalUseOfScopeReplacer('foo', msg)
    assert unicode(e) == msg


# Generated at 2022-06-26 02:18:37.659042
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # We must use the default encoding
    import locale
    locale.setlocale(locale.LC_ALL, '')
    # generate the exception message to be tested
    excp = IllegalUseOfScopeReplacer('name',
        msg='msg', extra='extra')
    # get the message using unicode()
    u = unicode(excp)
    # check if the message contains 'name', 'msg', and 'extra'
    if not u.find('name') >= 0 or\
        not u.find('msg') >= 0 or\
        not u.find('extra') >= 0:
        raise TestFailed('[test_IllegalUseOfScopeReplacer___unicode__]'\
            ' Test Failed, expected result not achieved!')


# Generated at 2022-06-26 02:18:42.340713
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.test_lazy_import as _test_lazy_import
    _test_lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-26 02:18:44.647231
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str(e)


# Generated at 2022-06-26 02:18:48.969519
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Invalid argument
    try:
        ScopeReplacer('test', 'test', 'test').__setattr__(None, 'test')
    except:
        pass
    else:
        assert False, "Could not detect invalid argument"


# Generated at 2022-06-26 02:18:53.450919
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor = ImportProcessor()
    import_processor.scope = {}
    import_processor.name = 'foo'
    import_processor.msg = 'bar'
    import_processor.extra = None
    import_processor.__unicode__()



# Generated at 2022-06-26 02:18:56.469098
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    exc = IllegalUseOfScopeReplacer(name='name', msg='msg')
    assert str(exc) == 'name'
    assert unicode(exc) == u'name'


# Generated at 2022-06-26 02:18:57.787918
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    test_case_0()



# Generated at 2022-06-26 02:19:03.547353
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    import_processor_0 = ImportProcessor()
    scope = {}
    def factory(self, scope, name): return None
    name = 'name'
    scope_replacer_0 = ScopeReplacer(scope, factory, name)
    attr = 'attr'
    value = 'value'
    assert scope_replacer_0.__setattr__(attr, value) is None


# Generated at 2022-06-26 02:19:07.587104
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Method __call__ of class ScopeReplacer, line 92
    test_case_0() # Unit test for method __call__ of class ScopeReplacer
    test_case_0() # Unit test for method __call__ of class ScopeReplacer
    test_case_0() # Unit test for method __call__ of class ScopeReplacer


# Generated at 2022-06-26 02:19:18.304589
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    e = IllegalUseOfScopeReplacer('name_0', 'msg_1', 'extra_2')
    try:
        raise e
    except:
        s = str(e)
        assert s == 'Unprintable exception IllegalUseOfScopeReplacer:' \
            ' dict={\'msg\': \'msg_1\', \'name\': \'name_0\', \'extra\': ' \
            '\'extra_2\'}, fmt=\'%(name)r was used incorrectly: %(msg)s%(extra)s\',' \
            ' error=\'unsupported format character %(\' at index 0'


# Generated at 2022-06-26 02:19:35.536337
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(), import_processor_0.process, "test_ScopeReplacer___setattr__")
    scope_replacer_1 = ScopeReplacer(globals(), import_processor_0.process, "test_ScopeReplacer___setattr__")
    scope_replacer_1.does_not_exist = "abcd"
    scope_replacer_0.does_not_exist = "abcd"


# Generated at 2022-06-26 02:19:46.527939
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import doctest
    suite = doctest.DocFileSuite("../ScopeReplacer.txt")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        return 0
    return 1

if __name__ == '__main__':
    import sys
    sys.path.insert(0, '..')
    # Disable doctest verbose mode
    import doctest
    doctest.set_unittest_reportflags(doctest.REPORT_NDIFF |
                                     doctest.REPORT_ONLY_FIRST_FAILURE)
    # Run unit tests
    res = test_ScopeReplacer___call__()
    if not res:
        # TODO(jelmer): Replace with a proper unit test suite
        test_case_0()


# Generated at 2022-06-26 02:19:54.802549
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib._pyio import StringIO
    from bzrlib.tests import TestCase
    from io import BytesIO

    real_stdout = TestCase.real_stdout
    TestCase.real_stdout = BytesIO()

# Generated at 2022-06-26 02:20:06.324977
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-26 02:20:10.892366
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # This creates a new ScopeReplacer instance for each test.
    import_processor_0 = ImportProcessor()
    # This gets the latest ScopeReplacer instance from the import processor.
    import_processor_0.get_module_scope_replacer(1)
    test_case_0()


# Generated at 2022-06-26 02:20:15.172425
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    expected_value = "name was used incorrectly: msg: extra"
    actual_value = str(e)
    assert actual_value == expected_value, '%r != %r' % (
        actual_value, expected_value)


# Generated at 2022-06-26 02:20:17.289318
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    scope = {}
    name = 'test'
    def factory(replacer, scope, name):
        return 'value'
    replacer = ScopeReplacer(scope, factory, name)
    replacer.__getattribute__
    replacer()


# Generated at 2022-06-26 02:20:24.675231
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode."""
    for s in [
        "abc",
        u"abc",
        "abc".decode('utf-8'),
        "abc\xe9",
        "abc\xe9".decode('utf-8'),
        u"abc\xe9",
    ]:
        exc = IllegalUseOfScopeReplacer(s, "msg")
        u = unicode(exc)
        assert isinstance(u, unicode)


# Generated at 2022-06-26 02:20:35.415894
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test of IllegalUseOfScopeReplacer.__unicode__"""
    # testing the following cases:
    #
    # _fmt = None
    # _fmt = ''
    # _fmt = '%(name)r'
    # _fmt = '%(name)s'
    # _fmt = '%(missing)s'
    # _fmt = '%(extra)s'
    # _fmt = '%(msg)s%(extra)s'
    #
    # extra = None
    # extra = object()
    #


# Generated at 2022-06-26 02:20:44.943911
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    import re
    import bzrlib
    import bzrlib.lazy_import

    ScopeReplacer._should_proxy = True

    # 1.
    bzrlib_1 = ''
    re_1 = ''
    bzrlib_lazy_import_1 = ''

# Generated at 2022-06-26 02:21:18.062817
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test case for method IllegalUseOfScopeReplacer.__str__
    """
    import_processor = ImportProcessor()
    result = import_processor._error('foo', 'Error message', 'extra')



# Generated at 2022-06-26 02:21:29.808881
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    import_processor_0.__setattr__('name', 'bzr')
    import_processor_0.__setattr__('scope', {})

# Generated at 2022-06-26 02:21:35.663136
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Method __call__ of class ScopeReplacer
    # Called from:
    #     def test_case_0 at line 41 of lazy_import.py
    import_processor_0 = None
    # AssertionError: __call__ expected the following arguments:
    # *args = (...,)
    # **kwargs = {...}
    pass


# Generated at 2022-06-26 02:21:43.564608
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()

# Generated at 2022-06-26 02:21:50.093678
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__ of ScopeReplacer must set 'method_called' to True."""
    import_processor_0 = ImportProcessor()
    # __call__ is normally called by lazy_import, so set
    # _should_proxy to False to make sure we did not used the
    # underlying object directly.
    ScopeReplacer._should_proxy = False
    import_processor_0._method_called = False
    # call __call__ of ScopeReplacer
    import_processor_0()
    return import_processor_0._method_called


# Generated at 2022-06-26 02:21:50.977769
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case_0()


# Generated at 2022-06-26 02:22:01.625969
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import test_case_0

    # Test simple assignment
    test_case_0()
    import bzrlib.lazy_import
    sr = bzrlib.lazy_import.ScopeReplacer._scope['import_processor_0']
    sr.__setattr__('foo', 'bar')
    if sr.foo != 'bar':
        raise AssertionError()

    # Test simple assignment of special attributes
    sr.__setattr__('__name__', 'somenewname')
    if sr.__name__ != 'somenewname':
        raise AssertionError()

    # Test that the object can't be used to replace itself
   

# Generated at 2022-06-26 02:22:07.969269
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__"""
    m = ImportProcessor()
    def check(name, msg):
        import traceback
        try:
            raise IllegalUseOfScopeReplacer(name, msg)
        except IllegalUseOfScopeReplacer as e:
            s = unicode(e)
            if not isinstance(s, unicode):
                from bzrlib.trace import mutter
                mutter('test_IllegalUseOfScopeReplacer___unicode__ returns %r',
                       s)


# Generated at 2022-06-26 02:22:10.933351
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method IllegalUseOfScopeReplacer.__str__"""
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:22:14.223917
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer({}, lambda: object, '')
    obj2 = object()
    obj.__setattr__('_resolve', obj2)
    assert(obj._resolve is obj2)


# Generated at 2022-06-26 02:22:57.734311
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    import_processor_0._scope = {}
    import_processor_0._factory = lambda x, y, z: x
    import_processor_0._name = '_name'
    import_processor_0._real_obj = None
    obj = import_processor_0.__getattribute__('__class__')
    assert obj is ScopeReplacer, 'incorrect __class__ attribute value'
    obj = import_processor_0.__getattribute__('__slots__')
    assert obj == ['_scope', '_factory', '_name', '_real_obj'], 'incorrect __slots__ attribute value'
    obj = import_processor_0.__getattribute__('__doc__')
    assert obj is not None, 'incorrect __doc__ attribute value'
    obj

# Generated at 2022-06-26 02:22:59.534532
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()



# Generated at 2022-06-26 02:23:04.261480
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    scope = import_processor_0._globals
    factory = ImportProcessor.create
    name = 'import_processor_0'
    scope_replacer_0 = ScopeReplacer(scope, factory, name)
    scope_replacer_0('import_processor_0', 'import_processor_0')


# Generated at 2022-06-26 02:23:09.998209
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__()

    IllegalUseOfScopeReplacer
     - returns a unicode object even if _format() returns a non-string object.
    """
    import_processor_0 = ImportProcessor()
    import_processor_0.name = 'import_processor_0'
    import_processor_0.msg = 'msg'
    import_processor_0.extra = 'extra'
    import_processor_0.assertRaise(
        'import_processor_0',
        'msg',
        'extra',
        "ScopeReplacer object 'import_processor_0' was used incorrectly:"
        " msg: extra")


# Generated at 2022-06-26 02:23:14.694149
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing method __str__ for IllegalUseOfScopeReplacer."""
    test_case_0()
    "__str__ should return a string."
    # This assertion is guaranteed to fail, but it is here in case it is
    # needed later.
    assert(False)


# Generated at 2022-06-26 02:23:26.054603
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests import TestCase

    class TestCaseWithScopeReplacer(TestCase):
        """Base class for ImportProcessor tests"""

        def get_scope_replacer(self, name, message, extra=None):
            """Create a scope replacer for testing.

            This will have its name set to the given name and its message
            to the given message.
            """
            return ScopeReplacer(name, message, extra)

    scope_replacer = TestCaseWithScopeReplacer('get_scope_replacer').get_scope_replacer('name', 'message')
    TestCaseWithScopeReplacer('test_IllegalUseOfScopeReplacer___str__').assertEqual('ScopeReplacer(name, message)', str(scope_replacer))


# Generated at 2022-06-26 02:23:34.605850
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Assign to test_case_1
    test_case_1 = test_case_0()
    test_case_1._should_proxy = False

    # Assign to obj_1
    obj_1 = ScopeReplacer(None, None, None)

    # Assign to test_case_2
    test_case_2 = test_case_0()
    test_case_2._should_proxy = True

    # Assign to obj_2
    obj_2 = ScopeReplacer(None, None, None)
    obj_2._real_obj = None

    # Assign to test_case_2
    test_case_2 = test_case_0()

    # Assign to name_1
    name_1 = '_name'

    # Assign to name_2
    name_2 = '_name'

# Generated at 2022-06-26 02:23:46.872449
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    m = "foo message"
    e = IllegalUseOfScopeReplacer("error1", m, "extra")
    u = unicode(e)
    eu = unicode(IllegalUseOfScopeReplacer("error1", m, "extra"))
    assert u == eu
    eu = unicode(IllegalUseOfScopeReplacer("error2", m, "extra"))
    assert u != eu, "Changed illegalName should change message."
    eu = unicode(IllegalUseOfScopeReplacer("error2", m, "extra2"))
    assert u != eu, "Changed extra should change message."
    eu = unicode(IllegalUseOfScopeReplacer("error2", m, None))
    assert u != eu, "Added None extra should change message."


# Generated at 2022-06-26 02:23:57.892852
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    ei1 = IllegalUseOfScopeReplacer(u'name-0', u'msg-1', u'extra-2')
    ei2 = IllegalUseOfScopeReplacer(u'name-a', u'msg-b', u'extra-c')
    ei3 = IllegalUseOfScopeReplacer(u'name-d', u'msg-e')

# Generated at 2022-06-26 02:23:59.539855
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import doctest
    doctest.testmod() 
