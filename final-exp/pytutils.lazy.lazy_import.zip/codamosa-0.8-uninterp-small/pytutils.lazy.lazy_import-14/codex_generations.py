

# Generated at 2022-06-26 02:15:51.398100
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    case_0()


# Generated at 2022-06-26 02:16:02.591596
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import StringIO
    import sys
    from StringIO import StringIO
    from cStringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    from StringIO import StringIO
    var_0 = IllegalUseOfScopeReplacer('var_0', 'str_0')
    var_1 = var_0._format()
    var_2 = str(var_1)

# Generated at 2022-06-26 02:16:05.405752
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer:
        pass


# Generated at 2022-06-26 02:16:07.562816
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib.lazy_import import test_case_0
    ''')
    test_case_0()


# Generated at 2022-06-26 02:16:09.700217
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    IllegalUseOfScopeReplacer(1, 2).__eq__(3)


# Generated at 2022-06-26 02:16:16.617971
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    processor_0 = ImportProcessor()
    str_0 = 'from bzrlib import (\n    errors,\n)  # noqa \nimport bzrlib'
    processor_0.lazy_import(globals(), str_0)
    assert processor_0.imports['bzrlib'] == (['bzrlib'], None, {})
    assert processor_0.imports['errors'] == (['bzrlib', 'errors'], None, {})
    return True


# Generated at 2022-06-26 02:16:22.596379
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Create an instance of the class
    # set the attribute '_should_proxy' to false
    # test if the exception IllegalUseOfScopeReplacer(name, msg="Object already replaced, did you assign it to another variable?") is raised
    var_0 = disallow_proxying()
    str_0 = '\\euYb?b#{5h/,y\x0c'
    int_0 = -1327
    var_1 = str_0
    var_2 = var_0
    return


# Generated at 2022-06-26 02:16:29.432075
# Unit test for method lazy_import of class ImportProcessor
def test_ImportProcessor_lazy_import():
    var_0 = ImportProcessor()
    var_1 = disallow_proxying()
    str_1 = 'B\n5|#\x00r\\\\x\x00\nq\x08l\x1aDA\x1e\x1f\\'
    str_2 = '2GW}\x0f\x16\x01\x1d\x0f\\l\x1d\x0b\x13\x1f\x1e\x0b\x1a'
    str_3 = '\x0c\x0f\x1e\x1f\x0b9\x1f\x0c\x04\x1bJ'

# Generated at 2022-06-26 02:16:30.497220
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_IllegalUseOfScopeReplacer___unicode___0()


# Generated at 2022-06-26 02:16:37.011921
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_0 = ScopeReplacer(ScopeReplacer, None, 'var_0')
    str_0 = '\\euYb?b#{5h/,y\x0c'
    int_0 = var_0.var_0


# Generated at 2022-06-26 02:16:57.117612
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    expected = 'foo'

    # Call test_case_0
    returned_0 = test_case_0()
    try:
        returned_0.expect_exception(IllegalUseOfScopeReplacer)
    except Exception as e:
        returned_0 = e
    if (returned_0 is not None and isinstance(returned_0, IllegalUseOfScopeReplacer)
        and not returned_0.__eq__(IllegalUseOfScopeReplacer('var_0', 'Object already replaced, did you assign it'
                                                                     ' to another variable?', None))):
        passed_1 = False
    else:
        passed_1 = True
    # 
    if (passed_1):
        passed_0 = True
    else:
        passed_0 = False
    assert passed_0


# Generated at 2022-06-26 02:17:02.856414
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test_IllegalUseOfScopeReplacer___str__() -> None

    Tests the __str__ method of IllegalUseOfScopeReplacer.
    """
    # TODO: When the test suite is better, a real test can be written.
    test_case_0()


# Generated at 2022-06-26 02:17:07.344184
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() -> unicode

    Return a unicode representation of the exception.

    This is typically the same as __str__() but may involve using
    non-ascii characters if appropriate for the locale.
    """

    # Call with dummy arguments:
    test_case_0()
    return None




# Generated at 2022-06-26 02:17:16.641848
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # TODO: This method is testing the special case where no format string
    # is provided. Normally a format string is provided, and this test
    # should be modified to test that case.
    ex = IllegalUseOfScopeReplacer("NAME", "MSG", "EXTRA")
    # The %r format is tricky because Unicode objects are printed
    # differently in Python 2 and Python 3.
    expected_fallback = ("Unprintable exception "
                         "IllegalUseOfScopeReplacer: dict={'name': "
                         "'NAME', 'extra': 'EXTRA', 'msg': "
                         "'MSG'}, fmt=None, error=None")
    assert str(ex) == expected_fallback
    assert unicode(ex) == unicode(expected_fallback)


# Generated at 2022-06-26 02:17:20.102794
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.selftest
    bzrlib.selftest.run_selftest(bzrlib.selftest.__file__)


# Generated at 2022-06-26 02:17:22.949078
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Add unit test for method __setattr__ of class ScopeReplacer"""
    import bzrlib.lazy_import
    test_case_0()


# Generated at 2022-06-26 02:17:31.129561
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    instance_0 = IllegalUseOfScopeReplacer('illegal use of scope replacer',
                                           'could not replace')
    instance_0._fmt = '%(_fmt)s'
    instance_0.__init__('illegal use of scope replacer', 'could not replace')
    __str__ = instance_0.__str__


# Generated at 2022-06-26 02:17:35.441488
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import lazy_import
    e = IllegalUseOfScopeReplacer(test_case_0, 'IllegalUseOfScopeReplacer', 'test_case_0')
    e.__unicode__()


# Generated at 2022-06-26 02:17:41.400434
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # __unicode__ returns a unicode object.
    # __unicode__ is expected to raise an UnprintableException exception for
    # this test.
    if 1:
        raise UnprintableException
    pass


# Generated at 2022-06-26 02:17:50.076142
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import unittest

    class test_IllegalUseOfScopeReplacer___unicode__(unittest.TestCase):
        def test_0(self):
            test_case_0()

    single_test_cases = [
        # (expected_result, args),
    ]
    test_cases = [
        # (expected_result, args),
        (test_case_0, []),
    ]

    if tests_to_run is None:
        # Run all tests in this file
        tests = unittest.TestSuite(map(test_IllegalUseOfScopeReplacer___unicode__,
                                       ["test_%s" % i for i,_ in test_cases]))
    else:
        tests = unittest.TestSuite()

# Generated at 2022-06-26 02:18:04.357704
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    replacer = ScopeReplacer(
        None, lambda self, scope: {'_name': 'unit_test_replacer'}, None)

    # Call the method
    result = replacer()

    # Test the results
    if result is not None:
        raise Exception("Unexpected result: " + str(result))


# Generated at 2022-06-26 02:18:06.728495
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import sys
    import tests.test_lazy_import
    var_0 = tests.test_lazy_import.Universe(None, None)
    var_0.test_case_0()


# Generated at 2022-06-26 02:18:13.185759
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() -> string.  Return this exception's message."""
    var_0 = IllegalUseOfScopeReplacer(0,0)
    var_0.__dict__['_preformatted_string'] = 0
    try:
        var_0._get_format_string()
        var_0.__dict__['_preformatted_string'] = 0
        var_0.__dict__['name'] = 0
        var_0.__dict__['msg'] = 0
        try:
            var_1 = var_0._format()
        except:
            var_1 = 0
        finally:
            try:
                assert var_1 == 0
            except:
                var_1 = 0
    except:
        var_1 = 0
    finally:
        var_2 = var_1

# Generated at 2022-06-26 02:18:19.381082
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import test_case_0
    from bzrlib.lazy_import import ScopeReplacer

# Generated at 2022-06-26 02:18:24.437836
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('var_0',
                                      'var_1',
                                      'var_2')
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:18:35.626810
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    from bzrlib.tests.lazy_import_bench import disallow_proxying
    from bzrlib.tests.lazy_import_bench import test_case_0
    from bzrlib.tests.lazy_import_bench import lazy_import
    from bzrlib.tests.lazy_import_bench import IllegalUseOfScopeReplacer
    assert hasattr(bzrlib.tests, 'lazy_import_bench')

    test_case_0()
    try:
        disallow_proxying()
    except IllegalUseOfScopeReplacer as x:
        # Expected exception
        assert isinstance(x, IllegalUseOfScopeReplacer)
        return
    raise AssertionError("Illegal use of ScopeReplacer not detected")


# Generated at 2022-06-26 02:18:39.110990
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Testing method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer(u'CODECOMPLETION', u'CODECOMPLETION')
    e._preformatted_string = u'CODECOMPLETION'
    str(e)


# Generated at 2022-06-26 02:18:41.528741
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(0, 0)
    test_result_var_0 = var_0.__str__()
    assert test_result_var_0 == "<bzrlib.lazy_import.IllegalUseOfScopeReplacer object>"


# Generated at 2022-06-26 02:18:47.503806
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    vars = {}
    var_0 = disallow_proxying()
    var_1 = ScopeReplacer(vars, vars.get("some_factory_0"), "some_name_0")
    with var_0:
        var_1(var_0)


# Generated at 2022-06-26 02:18:49.752179
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_1 = ScopeReplacer._should_proxy = True
    var_2 = ScopeReplacer._should_proxy = False


# Generated at 2022-06-26 02:19:03.171456
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from testresources import ResourcedTestCase

    class _ScopeReplacerTest(ResourcedTestCase):
        resources = [('test_case_0', test_case_0)]
        def test__getattribute__(self):
            self.assertEqual(ScopeReplacer._should_proxy, True)
    return _ScopeReplacerTest



# Generated at 2022-06-26 02:19:06.354896
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0_0 = 'proxy'

    def test_case_0():
        errors = 'proxy'

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-26 02:19:12.724335
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCaseWithMemoryTransport
    var_0 = ScopeReplacer(globals(), lambda self, scope, name: None, 'None')
    var_1 = TestCaseWithMemoryTransport()
    var_2 = var_1.test_ScopeReplacer___call__(var_0)


# Generated at 2022-06-26 02:19:17.158391
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__ of ScopeReplacer() => AttributeError"""
    a = ScopeReplacer(None, None, None)
    try:
        a.__getattribute__
    except AttributeError:
        pass
    else:
        fail("__getattribute__ of ScopeReplacer() failed")


# Generated at 2022-06-26 02:19:22.943049
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.blackbox

    def _factory(self, scope, name):
        return 0
    global_vars = dict()
    var_0 = ScopeReplacer(global_vars, _factory, 'var')
    var_1 = var_0()
    bzrlib.tests.blackbox.tests.append(
        ('test_case_0', test_case_0))

test_ScopeReplacer___call__()

# Generated at 2022-06-26 02:19:30.924056
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Make a scope
    scope = {}

    # Make a new ScopeReplacer object, representing variable 'var_0' in
    # scope 'scope'
    var_0 = ScopeReplacer(scope, lambda self, scope, name: None, 'var_0')

    # Set attr named 'attr_1' on object 'var_0' to value 'var_1'
    var_1 = "var_1"
    var_0.attr_1 = var_1

    # Assert that scope does not contain replacement object
    if scope.has_key("var_0"):
        raise AssertionError("expected scope to contain var_0 == var_1")


import signal


# Generated at 2022-06-26 02:19:34.163355
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__()

    This is a test for the correct implementation of the method __unicode__
    for the class IllegalUseOfScopeReplacer
    """
    test_case_0()


# Generated at 2022-06-26 02:19:38.306532
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    expected_result = "foo"
    class_instance = IllegalUseOfScopeReplacer("foo", "bar")
    result = class_instance.__unicode__()
    if result != expected_result:
        raise ValueError("Expected result %s, but got %s" % (expected_result, result))



# Generated at 2022-06-26 02:19:43.236481
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import pdb; pdb.set_trace()
    global __test_case_0
    var_0 = ScopeReplacer(__test_case_0, '_resolve', 'var_0')
    var_1 = var_0()


# Generated at 2022-06-26 02:19:50.367354
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals())
    with var_0 as var_1:
        try:
            raise RuntimeError
        except:
            import sys
            import traceback
            exc_info = sys.exc_info()
            traceback.print_tb(exc_info[2], file=var_1)
    var_0.close()
    var_0 = ScopeReplacer(globals(), test_case_0)
    var_0()
    var_0 = ScopeReplacer(globals(), test_case_0)
    var_0()


# Generated at 2022-06-26 02:20:14.676018
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # This test checks if an object is returned when using a ScopeReplacer
    # instance.
    def test_function():
        pass
    scope = {}
    ScopeReplacer(scope, lambda _,__,___:test_function, name='test_function')
    attr = 'test_function'
    scope_replacer = scope['test_function']
    obj = scope_replacer.__getattribute__(attr)
    assert obj == test_function, '__getattribute__ should return the' \
        ' originally assigned object'


# Generated at 2022-06-26 02:20:15.624507
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    str(e)


# Generated at 2022-06-26 02:20:21.358890
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(None, None, 'bzrlib')
    with var_0.builtin_get('__builtin__').patch_module('bzrlib'):
        var_1 = ScopeReplacer(None, None, 'bzrlib')
        var_2 = var_1._resolve()
        var_3 = var_2.__class__
        var_4 = var_3.__module__
        var_5 = var_4 != 'bzrlib'
        var_6 = IllegalUseOfScopeReplacer(None, None, 'module %r != %r' %
                (var_4, 'bzrlib'))
        var_7 = var_1()

# Generated at 2022-06-26 02:20:32.267180
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__

    This tests the ability to call and get attributes of a ScopeReplacer
    object.

    """
    # Call the __init__ method
    global var_0
    var_0 = lazy_import(globals(), '''
        test_case_0
        ''')

    # Call __setattr__ on a ScopeReplacer object
    var_0._setattr_(attr, value)

    # Make sure the real object is generated
    var_0._resolve()

    # Get an attribute or method.

    # Finally, verify that the real object was replaced.
    # self.assertEqual(expected, var_0)

# Generated at 2022-06-26 02:20:42.474656
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import disallow_proxying
    from bzrlib.lazy_import import lazy_import

    # Test creating a function with lazy_import
    GLOBALS = {'__name__': 'module_lazy_import'}
    lazy_import(GLOBALS, '''
            def foo():
                return 42
            ''')
    x = GLOBALS['foo']()
    assert(x == 42)

    # Test create a class with lazy_import
    GLOBALS = {'__name__': 'module_lazy_import'}

# Generated at 2022-06-26 02:20:50.098871
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase

    class _TestCase(TestCase):

        def test_getattribute(self):
            obj = ScopeReplacer({}, lambda s,d,n: {'a': 'b'}, 'obj')
            self.assertEqual('b', obj.a)

        def test_getattribute_failure(self):
            obj = ScopeReplacer({}, lambda s,d,n: {'a': 'b'}, 'obj')
            self.assertEqual('b', obj.a)
            ex = self.assertRaises(IllegalUseOfScopeReplacer,
                                   test_case_0)

# Generated at 2022-06-26 02:21:01.125424
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    from bzrlib.lazy_import import ScopeReplacer

    # Test with empty string as the variable name and empty dictionary
    # as the variable scope.
    variable_name = ''
    variable_scope = {}
    variable_factory = lambda s, scope, name: scope
    variable = ScopeReplacer(variable_scope, variable_factory, variable_name)

    # Test with empty string as the variable name and empty dictionary
    # as the variable scope.
    variable_name = ''
    variable_scope = {}
    variable_factory = lambda s, scope, name: scope
    variable = ScopeReplacer(variable_scope, variable_factory, variable_name)

    # Test with empty string as the variable name and empty dictionary
    # as the variable scope.
    variable_name = ''
    variable_scope = {}
    variable_

# Generated at 2022-06-26 02:21:03.619436
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test IllegalUseOfScopeReplacer.__unicode__()"""
    pass # test is run in test_case_0


# Generated at 2022-06-26 02:21:09.492438
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer:
        def __init__(self):
            ScopeReplacer(self, self, '_real')
    test_scope_replacer_0 = TestScopeReplacer()
    test_scope_replacer_0._real = 'Bob'
    # AssertionError: AssertionError: Object already replaced, did you assign it to another variable?

# Generated at 2022-06-26 02:21:11.668610
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(1, 2)
    assert var_0.__str__() == 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'



# Generated at 2022-06-26 02:21:35.171366
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_1 = disallow_proxying()
    try:
        var_1()
    except IllegalUseOfScopeReplacer as var_2:
        var_2.name = ''
        var_2.msg = ''
        var_2.extra = ''
        var_3 = var_2._get_format_string()
        var_4 = var_2._format()
        if var_3 is not None:
            assert var_3 == unicode("ScopeReplacer object %(name)r was used incorrectly:"
                                    " %(msg)s%(extra)s"), 'assertion failed'
        assert isinstance(var_2, Exception), 'assertion failed'
        assert var_4 == unicode("ScopeReplacer object u'' was used incorrectly:"
                                " u''"), 'assertion failed'

# Generated at 2022-06-26 02:21:41.790071
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer('var_0', 'was used incorrectly')
    assert str(e) == u"ScopeReplacer object 'var_0' was used incorrectly"

globals()['test_case_0'] = test_case_0
globals()['test_IllegalUseOfScopeReplacer___str__'] = test_IllegalUseOfScopeReplacer___str__


try:
    from bzrlib.plugin import load_plugins
except ImportError:
    def load_plugins():
        raise ImportError(
            "This function requires bzrlib >= 2.5.0 to work.")



# Generated at 2022-06-26 02:21:48.178867
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
        var_0 = IllegalUseOfScopeReplacer('name_0', 'msg_0')
        var_0._fmt = '_fmt_0'
        # Test raising an exception:
        var_0._get_format_string = raise_exception
        # Test a failing format string:
        var_0._fmt = '_fmt_1'
        # Test a failing message:
        var_0.msg = object()
        # Test a failing name:
        var_0.name = object()



# Generated at 2022-06-26 02:21:56.479195
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import sys
    orig_stderr = sys.stderr
    orig_stdout = sys.stdout
    fh = open("/home/nox/Temp/bzr-2.6.0/bzrlib/tests/data/lazy_import_test_IllegalUseOfScopeReplacer___str__.txt", 'w')
    try:
        test_case_0()
    finally:
        sys.stderr.close()
        sys.stderr = orig_stderr
        sys.stdout.close()
        sys.stdout = orig_stdout
    return fh.close()


# Generated at 2022-06-26 02:21:57.412100
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    pass # tested in another module



# Generated at 2022-06-26 02:21:59.793715
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    var_0 = IllegalUseOfScopeReplacer(None, None)


# Generated at 2022-06-26 02:22:02.214884
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_1 = ScopeReplacer(globals(), lambda self, scope, name: None, 'var_1')
    var_1()


# Generated at 2022-06-26 02:22:05.468844
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    name = 'var_0'
    factory = lambda self, scope, name: scope[name]
    var_0 = ScopeReplacer(scope, factory, name)
    var_0.test_case_0()


# Generated at 2022-06-26 02:22:16.141501
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    t = ScopeReplacer({"key": 2}, factory, "key")
    try:
        t.__setattr__("key", "value")
    except Exception as e:
        assert isinstance(e, IllegalUseOfScopeReplacer)
        assert e.name == "key"
        assert e.msg == "Object already replaced, did you assign it to another variable?"
        assert e.extra is None
    else:
        assert False, "This exception should have been raised"
    try:
        t.__setattr__("this_does_not_exist", "value")
    except Exception as e:
        assert isinstance(e, IllegalUseOfScopeReplacer)
        assert e.name == "key"
        assert e.msg == "Object already replaced, attempting to set unknown attribute"

# Generated at 2022-06-26 02:22:17.871473
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test the IllegalUseOfScopeReplacer.__str__ method (case 0)"""
    var_0 = IllegalUseOfScopeReplacer('name_0', 'msg_1', 'extra_2')
    var_0.__str__()



# Generated at 2022-06-26 02:22:41.038527
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() -> str

    Return a string representation of the object.  For most objects, this
    looks like a valid Python expression that could be used to recreate an
    object with the same value (given an appropriate environment).

    If no args are given, this method simply calls __str__() or __repr__()
    of the object.
    """
    # auto-generated by tools/generate_tests.py
    import doctest
    from bzrlib import lazy_import
    from bzrlib.tests import TestUtil

    failure_count, test_count = doctest.testmod(lazy_import)
    TestUtil.check_doctest_coverage(lazy_import, lazy_import)
    doc_count, test_count = TestUtil.count_doctests(lazy_import)
   

# Generated at 2022-06-26 02:22:44.974274
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    exception = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    u = exception.__unicode__() # calling __unicode__ may not throw
    assert isinstance(u, unicode)


# Generated at 2022-06-26 02:22:57.612893
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib._lazy_import import _ScopeReplacerProxy
    from bzrlib.lazy_import import (ScopeReplacer, disallow_proxying,
                                    _set_should_proxy)
    ScopeReplacer._should_proxy = False
    x = ScopeReplacer({}, lambda self, scope, name: 1, 'x')

# Generated at 2022-06-26 02:22:59.157943
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()


# Generated at 2022-06-26 02:23:01.984037
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    c = ScopeReplacer({}, lambda self, scope, name: None, 'foo')
    # A test case to check that the method '__setattr__' of class
    # 'ScopeReplacer' raises the exception 'IllegalUseOfScopeReplacer'
    # when 'ScopeReplacer._should_proxy' is False.
    test_case_0()



# Generated at 2022-06-26 02:23:03.730464
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()
    test_IllegalUseOfScopeReplacer___str___0()


# Generated at 2022-06-26 02:23:10.772069
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.missing
    import bzrlib.progress
    real_ScopeReplacer = bzrlib.lazy_import.ScopeReplacer
    real_NotImplementedError = bzrlib.missing.NotImplementedError
    real_ProgressRecorder = bzrlib.progress._ProgressRecorder
    class DummyProgressRecorder(object):
        def __init__(self, *args, **kwargs):
            pass
        def start(self):
            pass
    class DummyNotImplementedError(Exception):
        pass
    class DummyScopeReplacer(real_ScopeReplacer):
        __slots__ = ('_scope', '_factory', '_name', '_real_obj')
        def _resolve(self):
            super

# Generated at 2022-06-26 02:23:12.151832
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    var_0 = IllegalUseOfScopeReplacer('', '')
    with var_0:
        str(var_0)


# Generated at 2022-06-26 02:23:13.355116
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    ScopeReplacer._should_proxy = True
    c = ScopeReplacer({}, get_factory(0), 'var_0')
    c.foo = 1


# Generated at 2022-06-26 02:23:20.893792
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    scope['__setattr__'] = None
    factory = lambda s, scope, name: scope[name]
    name = '__setattr__'
    obj = ScopeReplacer(scope, factory, name)
    value = lambda: None
    obj.__setattr__('var_0', value)
    if scope.get('__setattr__') is not None:
        return 1
    value = scope.get('var_0')
    if not (value is None):
        return 1
    return 0


# Generated at 2022-06-26 02:23:33.182508
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name0', 'msg0', extra='extra0')
    var_1 = str(var_0)
    var_2 = unicode(var_0)
    var_3 = repr(var_0)


# Generated at 2022-06-26 02:23:38.557107
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # set up state
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')

    # exercise code
    result_0 = str(var_0)

    # check results
    assert isinstance(result_0, str)


# Generated at 2022-06-26 02:23:45.119953
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    global var_0
    var_0 = None
    # Run test
    global var_0
    try:
        var_0.__setattr__()
    # Check fail
    except IllegalUseOfScopeReplacer as e:
        TestCase.assertIsInstance(e, IllegalUseOfScopeReplacer)


# Generated at 2022-06-26 02:23:54.331037
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_0 = IllegalUseOfScopeReplacer(u'\u202a4', u'\u202a4')
    # Check for expected exception
    try:
        var_0.__unicode__()
        raise AssertionError("Failed Assertion:  Expected Exception")
    except IllegalUseOfScopeReplacer as e:
        pass
    # Check for expected exception
    try:
        var_0.__unicode__()
        raise AssertionError("Failed Assertion:  Expected Exception")
    except IllegalUseOfScopeReplacer as e:
        pass


# Generated at 2022-06-26 02:23:56.808318
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer(u'name_0', u'msg_0')
    var_1 = var_0.__str__()


# Generated at 2022-06-26 02:24:00.324278
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    a_ScopeReplacer = ScopeReplacer( scope, factory, name)
    args =  ()
    kwargs =  {}
    result = a_ScopeReplacer.__call__( *args, **kwargs)



# Generated at 2022-06-26 02:24:13.045306
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    var_1 = ScopeReplacer({'lazy_import':var_0, 'bzrlib':var_0},
        {'bzrlib':var_0, 'lazy_import':var_0}, 'lazy_import')
    var_2 = ScopeReplacer({'lazy_import':var_0, 'bzrlib':var_0},
        {'bzrlib':var_0, 'lazy_import':var_0}, 'bzrlib')
    var_3 = var_2
    var_4 = var_3
    var_5 = var_4
    var_6 = var_5
    var_7 = var_6
    var_8 = var_7
    var_9 = var_8

# Generated at 2022-06-26 02:24:15.778914
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() -> string

    __unicode__() should return a unicode object.
    """
    # Test case 0
    var_0 = IllegalUseOfScopeReplacer('name', 'msg')
    var_1 = unicode(var_0)
    var_2 = isinstance(var_1, unicode)
    assert var_2 == True


# Generated at 2022-06-26 02:24:19.626700
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    ScopeReplacer._should_proxy = False

    # Test illegal use of ScopeReplacer sets an exception
    import sys
    import bzrlib
    try:
        var_0 = lazy_import(globals(), 'bzrlib.osutils')
        var_1 = var_0.pathjoin('foo', 'bar')
        test_case_0()
    except IllegalUseOfScopeReplacer as e:
        # Exception should be raised
        pass
    else: # Will not be called if the except throws an exception
        raise Exception('Expected exception did not occur')
    enable_proxying()



# Generated at 2022-06-26 02:24:21.298099
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    "ScopeReplacer.__setattr__"
    var_0 = test_case_0()


# Generated at 2022-06-26 02:24:34.699102
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    expected = 'Unprintable exception IllegalUseOfScopeReplacer:' \
        ' dict={}, fmt=%(fmt)s, error=None'
    # This may raise an exception, in which case the test will fail
    test_case_0()


# Generated at 2022-06-26 02:24:44.120708
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib._pychecker_skips import allow_method_overriding
    allow_method_overriding(scope_replacer, "__str__")
    """Unit test for Method IllegalUseOfScopeReplacer.__str__."""
    import StringIO
    import sys
    stderr = StringIO.StringIO()
    sys.stderr = stderr
    try:
        var_0 = IllegalUseOfScopeReplacer('var_1', 'var_2', 'var_3')
        sys.stderr = sys.__stderr__
        var_4 = var_0.__str__()
        return var_4
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-26 02:24:53.490145
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    var_0 = ScopeReplacer(sys.modules, lambda self, scope, name: None,
                          'bzrlib.tests.lazy_import_scope_replacer')
    test_case_0()

    class test_ScopeReplacer___setattr__(TestCase):
        def test_0(self):
            local_var_0 = ScopeReplacer(sys.modules, lambda self, scope, name: None,
                                        'bzrlib.tests.lazy_import_scope_replacer')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              local_var_0.__setitem__, 'a', None)

# Generated at 2022-06-26 02:25:01.799103
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    expected_value = u'Unprintable exception IllegalUseOfScopeReplacer' \
                     u': dict=dict(_preformatted_string=None, ' \
                     u'extra="", msg="", name="var_0"), ' \
                     u'fmt="ScopeReplacer object %(name)r was used ' \
                     u'incorrectly: %(msg)s%(extra)s", ' \
                     u'error="Message only available in unicode"'
    assert expected_value == var_0.__unicode__()


# Generated at 2022-06-26 02:25:05.671455
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    initial_string = IllegalUseOfScopeReplacer('name', 'msg')._format()
    test_string = IllegalUseOfScopeReplacer('name', 'msg').__unicode__()
    try:
        assert initial_string == test_string
    except AssertionError:
        return False
    return True


# Generated at 2022-06-26 02:25:07.084634
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer(globals(), aimport, 'ScopeReplacer')


# Generated at 2022-06-26 02:25:18.659066
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import (
        ScopeReplacer,
        )

    class TestableScopeReplacer(ScopeReplacer):

        def _resolve(self):
            return self

    try:
        obj = TestableScopeReplacer(
            {}, # _scope
            lambda self, scope, name: self, # _factory
            'name', # _name
            )
    except TypeError as e:
        if str(e) != "__init__() takes exactly 4 arguments (3 given)":
            raise TestCase.failureException("TypeError not raised or"
                " raised at wrong time")
    else:
        raise TestCase.failureException("TypeError not raised or"
            " raised at wrong time")
    obj1 = TestableScopeReplacer

# Generated at 2022-06-26 02:25:23.804593
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    unit_test = IllegalUseOfScopeReplacer('n', 'm')
    assert isinstance(unit_test, Exception)
    assert isinstance(unit_test, IllegalUseOfScopeReplacer)
    assert str(unit_test) == "IllegalUseOfScopeReplacer('n', 'm')"

try:
    import cPickle as pickle
except ImportError:
    import pickle


# Generated at 2022-06-26 02:25:28.025258
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """test_IllegalUseOfScopeReplacer___unicode__() -> None

    Test that unicode(IllegalUseOfScopeReplacer()) is sane.
    """
    # check en_US.UTF-8.
    test_case_0()


# Generated at 2022-06-26 02:25:34.985506
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    try:
        var_0 = disallow_proxying()
    except Exception as var_1:
        var_0 = var_1
    var_2 = type(var_0)
    var_3 = unicode('Unprintable exception IllegalUseOfScopeReplacer: '
                    'dict=%r, fmt=%r, error=%r' % (var_0.__dict__, getattr(
                    var_0, '_fmt', None), var_0))
    var_4 = isinstance(var_0, IllegalUseOfScopeReplacer)
    var_5 = unicode(var_0)
    var_6 = isinstance(var_0, var_2)
    var_7 = unicode(var_0)
    var_8 = isinstance(var_0, IllegalUseOfScopeReplacer)
