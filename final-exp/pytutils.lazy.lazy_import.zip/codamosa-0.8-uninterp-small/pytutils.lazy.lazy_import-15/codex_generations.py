

# Generated at 2022-06-26 02:16:07.314555
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    x = IllegalUseOfScopeReplacer('lazy_import', 'did not return',
                                  'from bzrlib.lazy_import import lazy_import')
    str(x)


# Generated at 2022-06-26 02:16:09.680481
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer(name='foo', msg='bar')
    expected_str = 'IllegalUseOfScopeReplacer(foo: bar)'
    assert str(e) == expected_str


# Generated at 2022-06-26 02:16:16.546270
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    # Normally we would just test for equality, but we don't want to
    # depend on the exact formatting here. So we test for containment
    # instead.
    assert 'name' in unicode(e)
    assert 'msg' in unicode(e)
    assert 'extra' in unicode(e)


# Generated at 2022-06-26 02:16:19.545550
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    assertEquals(str(import_processor_0), 'name')


# Generated at 2022-06-26 02:16:25.818870
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ must return a str.
    """
    exception = IllegalUseOfScopeReplacer('name', 'msg')
    str_exception = str(exception)
    isinstance(str_exception, str)




# Generated at 2022-06-26 02:16:30.630476
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    illegal_use_of_scope_replacer_0 = IllegalUseOfScopeReplacer(
        'illegal_use_of_scope_replacer_0', 'illegal_use_of_scope_replacer_1')



# Generated at 2022-06-26 02:16:44.346537
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case_0()
    try:
        e = None
        # Call the __getattribute__ method of the class ScopeReplacer using the
        # default keyword arguments.
        __call__0 = ScopeReplacer.__getattribute__()
        # Assert that the __call__0 is equal to None.
        assert __call__0 is None
    except Exception as __e:
        # In case of exception, assign it to e and proceed to call the
        # __getattribute__ method of the class IllegalUseOfScopeReplacer using
        # the default keyword arguments.
        e = __e
        __call__0 = IllegalUseOfScopeReplacer.__getattribute__()
        # Assert that the __call__0 is equal to None.
        assert __call__0 is None
    # Check the type of the e, which should be a subclass of

# Generated at 2022-06-26 02:16:56.321675
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import bzrlib.trace
    import bzrlib.osutils
    from bzrlib.tests import (
        TestCase,
        )
    from bzrlib.lazy_import import (
        ScopeReplacer,
        ImportProcessor,
        )
    import bzrlib.branch
    import bzrlib.errors
    import bzrlib.osutils
    import bzrlib.trace
    # This method is tested by the interpreter, but we need to perform a
    # test that doesn't raise an exception.

# Generated at 2022-06-26 02:17:03.525367
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Create instance of class
    obj = ScopeReplacer('a', 'b', 'c')
    # set attr 'd' to something
    object.__setattr__(obj, 'd', 'a')
    # check if attr 'd' is set to right value
    assert object.__getattribute__(obj, 'd') == 'a'


# Generated at 2022-06-26 02:17:04.802412
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    pass


# Generated at 2022-06-26 02:17:31.730975
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    from bzrlib.lazy_import import ScopeReplacer



# Generated at 2022-06-26 02:17:34.121934
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()


# Generated at 2022-06-26 02:17:47.171185
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    The __unicode__ method of IllegalUseOfScopeReplacer should try to return
    the error message as a unicode string.  For that, it needs to know how the
    string is encoded.

    In this test case, the encoding is hard-coded to 'utf8'.
    """
    # Setup
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    error = IllegalUseOfScopeReplacer(
        'scope_replacer_object',
        'Illegal attribute access')
    expected_result = 'Illegal attribute access'

    # Exercise
    observed_result = unicode(error)

    # Verify
    assert expected_result == observed_result


# Generated at 2022-06-26 02:17:49.034965
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()


# Generated at 2022-06-26 02:17:53.296107
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():

    exc1 = IllegalUseOfScopeReplacer('foo', 'bar')
    assert str(exc1) == 'foo', 'should be foo'


# Generated at 2022-06-26 02:17:57.701465
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    inst = IllegalUseOfScopeReplacer('name', 'msg')
    u = inst.__unicode__()
    assert isinstance(u, unicode), repr(u)
    assert u == u'IllegalUseOfScopeReplacer object name was used incorrectly: msg'


# Generated at 2022-06-26 02:18:02.514653
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer

    try:
        test_case_0()
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-26 02:18:11.378864
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        raise IllegalUseOfScopeReplacer('pony', 'wuggly')
    except IllegalUseOfScopeReplacer as e:
        assert e._get_format_string() == u"ScopeReplacer object %(name)r " \
            "was used incorrectly: %(msg)s%(extra)s"
        assert unicode(e) == u"ScopeReplacer object 'pony' was used " \
            "incorrectly: wuggly"
        assert str(e) == "ScopeReplacer object 'pony' was used incorrectly: " \
            "wuggly"
        assert repr(e) == "IllegalUseOfScopeReplacer('pony', 'wuggly')"



# Generated at 2022-06-26 02:18:13.310458
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()


# Generated at 2022-06-26 02:18:23.062177
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    ScopeReplacer_0 = ScopeReplacer(globals(), test_case_0, 'import_processor_0')

# Generated at 2022-06-26 02:18:41.128822
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    if (not (import_processor_0.scopereplacer_0_obj is None)):
        return 0
    import_processor_0.scopereplacer_0_obj = ScopeReplacer(
        import_processor_0.scope_0,
        import_processor_0.factory_1,
        'import_processor_0.scopereplacer_0',
    )
    r0 = import_processor_0.scopereplacer_0_obj.factory_1
    return r0


# Generated at 2022-06-26 02:18:53.947763
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import sys
    import codecs
    if sys.getdefaultencoding() == 'ascii':
        # test will fail for ascii encodings
        return
    def test_IllegalUseOfScopeReplacer___unicode__0():
        exc = IllegalUseOfScopeReplacer(u'unicode', u'unicode')
        unicode(exc)
    codecs.register_error('strict',
        lambda exc: (u'STUB', exc.start + 1))
    try:
        sys.getdefaultencoding = lambda: 'ascii'
        test_IllegalUseOfScopeReplacer___unicode__0()
    finally:
        sys.getdefaultencoding = sys.getdefaultencoding.__func__
    codecs.register_error('strict', None)


# Generated at 2022-06-26 02:18:54.885318
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()


# Generated at 2022-06-26 02:18:59.323880
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope = {}
    factory_0 = lambda self, scope, name: scope.get(name)
    name = object()
    scopereplacer_0 = ScopeReplacer(scope, factory_0, name)
    scopereplacer_0.__setattr__(name, object())


# Generated at 2022-06-26 02:19:04.881830
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import unittest
    test_case_0()
    import testtools
    import testtools.matchers
    class Test(testtools.TestCase):
        def test_things(self):
            import_processor_0 = ImportProcessor()
            import_processor_0.__call__()
            self.assertThat(import_processor_0, testtools.matchers.IsInstance(ImportProcessor))
    return unittest.TestSuite([
        unittest.makeSuite(Test),
        ])



# Generated at 2022-06-26 02:19:06.152997
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()


# Generated at 2022-06-26 02:19:18.304886
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    import_processor_0
    try: raise ImportProcessor.IllegalUseOfScopeReplacer(2, 3, 4)
    except ImportProcessor.IllegalUseOfScopeReplacer as argument_0:
        assert argument_0.__str__() == "ScopeReplacer object 2 was used incorrectly: 3"
    try: raise ImportProcessor.IllegalUseOfScopeReplacer(2, 3, 4)
    except ImportProcessor.IllegalUseOfScopeReplacer as argument_0:
        assert argument_0.__str__() == "ScopeReplacer object 2 was used incorrectly: 3"

# Generated at 2022-06-26 02:19:26.891714
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import unittest
    import testtools

    try:
        import bzrlib.tests.test_lazy_import
        import bzrlib.lazy_import
    except Exception:
        # XXX: Since this is a selftest, if it's not part of bzrlib,
        # then we'll silently skip it.
        return

    class TestCase(unittest.TestCase):

        def test__setattr__(self):
            import_processor = bzrlib.tests.test_lazy_import.ImportProcessor()
            self.assertIs(None, import_processor.mock_import)
            self.assertIs(None, import_processor.mock_scope_replacer)
            module_name = 'bzrlib.tests.test_lazy_import'
           

# Generated at 2022-06-26 02:19:32.232283
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    def factory_2(scope_replacer_3, scope_4, name_5):
        return scope_replacer_3
    scope_replacer_1 = ScopeReplacer(globals(), factory_2, 'obj2')
    scope_replacer_1_0 = scope_replacer_1()
    pass


# Generated at 2022-06-26 02:19:43.616582
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    import sys
    def dummy(): pass
    def dummy1(): pass
    def dummy2(): pass
    def dummy3(scope, name): pass
    def dummy4(scope, name): pass
    def dummy5(scope, name): return dummy2
    def dummy6(scope, name): return dummy3
    obj = ScopeReplacer(sys._getframe(1).f_globals, dummy, 'dummy1')
    obj.__setattr__('c', 'c')
    obj.__setattr__('b', 'b')
    assert obj.b == 'b', obj.b
    obj.__setattr__('b', 'a')
    assert obj.b == 'a', obj.b

# Generated at 2022-06-26 02:19:52.530126
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    import_processor_0.test_case_ScopeReplacer___call__()


# Generated at 2022-06-26 02:19:55.020813
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()
    IllegalUseOfScopeReplacer("#1", "#2", "#3")


# Generated at 2022-06-26 02:20:00.496625
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    scope = {}
    factory = lambda loader, scope, name: object()
    name = 'class'
    x = ScopeReplacer(scope, factory, name)
    assert scope[name] is x
    setattr(x, 'key', 'value')
    assert scope[name].key == 'value'


# Generated at 2022-06-26 02:20:08.223488
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    # Assert that the test is set up correctly
    assert test_case_0()
    assert import_processor_0 is not None
    assert isinstance(import_processor_0, ImportProcessor)

    # Call method __call__ of ScopeReplacer on object import_processor_0
    import_processor_0.__call__(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')

test_ScopeReplacer___call__()

# Generated at 2022-06-26 02:20:09.658255
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-26 02:20:18.629581
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib
    import_processor_0 = ImportProcessor()
    import_processor_0._fmt = "fmt"
    import_processor_0._real_obj = None
    import_processor_0._scope = sys.modules
    import_processor_0._name = "bzrlib"
    import_processor_0._factory = (lambda this, scope, name: scope[name])
    saved_should_proxy = ScopeReplacer._should_proxy

# Generated at 2022-06-26 02:20:23.998681
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import ScopeReplacer, test_case_0
    # Test with an instance of class ScopeReplacer
    test_instance_0 = ScopeReplacer
    test_instance_0 = ScopeReplacer(import_processor_0, test_case_0, None)
    test_instance_0()


# Generated at 2022-06-26 02:20:34.751266
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0, 'var_0')
    class_0 = IllegalUseOfScopeReplacer('var_0', 'string_0')
    class_0._preformatted_string = 'Unprintable exception IllegalUseOfScopeReplacer'
    class_0._fmt = "ScopeReplacer object %(name)r was used incorrectly: %(msg)s%(extra)s"
    str_0 = scope_replacer_0._str(class_0)
    assert str_0 == 'ScopeReplacer object var_0 was used incorrectly: string_0'
    class_0._preformatted_string = 'string_0'
    str_0 = scope_replacer_0._str(class_0)
    assert str_0

# Generated at 2022-06-26 02:20:40.240019
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    unit_test_0 = test_case_0()
    my_obj = ScopeReplacer(globals(), lambda self, scope, name: None, "my_obj")
    my_obj.a = 1
    my_obj.b = 2
    if my_obj.a != 1:
        raise ValueError("my_obj.a")
    if my_obj.b != 2:
        raise ValueError("my_obj.b")


# Generated at 2022-06-26 02:20:47.882711
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(), lambda self, scope, name: self, 'scope_replacer_1')
    scope_replacer_2 = str(type(scope_replacer_0))
    exception_0 = None
    try:
        scope_replacer_0.a = 'a'
    except Exception as exception_0:
        pass
    assert(isinstance(exception_0, IllegalUseOfScopeReplacer))
    assert(exception_0._name == 'scope_replacer_1')
    assert(exception_0._msg == 'Object already replaced, did you assign it to another variable?')
    assert(scope_replacer_0._real_obj == 'a')
    import_processor_0 = ImportProcessor()
    scope_

# Generated at 2022-06-26 02:21:06.416109
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import unittest
    from bzrlib.tests.test_lazy_import import TestCase

    class TestIllegalUseOfScopeReplacer___str__(TestCase):
        '''__str__'''
        def _test_result_0(self, str_0):
            self.assertIsInstance(str_0, str)
            self.assertEqual('', str_0)
            self.assertIsInstance(str_0, str)
        def test_0(self):
            self._test_result_0('')
    try:
        import unittest2 as unittest
    except ImportError:
        pass
    unittest.main(defaultTest='TestIllegalUseOfScopeReplacer___str__')


# Generated at 2022-06-26 02:21:07.600184
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    t0 = ScopeReplacer()
    t0(t0)


# Generated at 2022-06-26 02:21:08.752641
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    obj = ScopeReplacer(object(), object(), object())
    obj()


# Generated at 2022-06-26 02:21:11.344445
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    try:
        import_processor_0.test_case_0()
    except:
        import sys

# Generated at 2022-06-26 02:21:18.610687
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    a = IllegalUseOfScopeReplacer('a', '', None)
    assert isinstance(a, Exception)
    try:
        a._preformatted_string = 'spam'
        assert a.__unicode__() == 'spam'
    finally:
        del a._preformatted_string


# Generated at 2022-06-26 02:21:30.592948
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('my_name', 'my_msg')
    s = unicode(e)
    e2 = IllegalUseOfScopeReplacer('my_name', 'my_msg')
    s2 = unicode(e2)
    assert s == s2, (s, s2)

    e = IllegalUseOfScopeReplacer('my_name', u'my_msg')
    s = unicode(e)
    e2 = IllegalUseOfScopeReplacer('my_name', u'my_msg')
    s2 = unicode(e2)
    assert s == s2, (s, s2)

    # Check that a preformatted version is detected
    e = IllegalUseOfScopeReplacer('my_name', 'my_msg')

# Generated at 2022-06-26 02:21:39.256551
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """test_IllegalUseOfScopeReplacer___str__ - class IllegalUseOfScopeReplacer

    This tests the __str__ method of class IllegalUseOfScopeReplacer"""
    # Invoke method __str__ of class IllegalUseOfScopeReplacer
    method = getattr(
        IllegalUseOfScopeReplacer,
        '__str__',
        None)
    # Create input arguments
    method_args = []
    method_args.append(None)
    method_kwargs = {
    }

# Generated at 2022-06-26 02:21:41.224791
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()
    test_case_0 = ScopeReplacer(import_processor_0, test_case_0, 'test_case_0')
    test_case_0()


# Generated at 2022-06-26 02:21:45.603584
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():

    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(globals(),
                                     import_processor_0.create,
                                     'import_processor_0')

    try:
        import_processor_0()
    except Exception as exc:
        print(exc)


# Generated at 2022-06-26 02:21:48.786416
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test for IllegalUseOfScopeReplacer.__unicode__()."""
    import_processor_0 = ImportProcessor()
    for arg in import_processor_0._get_args():
        yield test_case_0,


# Generated at 2022-06-26 02:22:11.253470
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import __builtin__

# Generated at 2022-06-26 02:22:12.199310
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    test_case_0()


# Generated at 2022-06-26 02:22:14.511996
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    sc = ScopeReplacer({}, lambda self, scope, name: 42, '_name')
    assert sc._name == 42


# Generated at 2022-06-26 02:22:19.245469
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer('test', 'test failed')
    j = unicode(e)
    assert(isinstance(j, unicode))
    assert(j == u'ScopeReplacer object \'test\' was used incorrectly: test failed')


# Generated at 2022-06-26 02:22:24.435221
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ScopeReplacer(import_processor_0.globals, import_processor_0.import_, 'bzrlib')
    scope_replacer_0.tests = 'value'

# Unit test the method __setattr__ of the class ImportProcessor

# Generated at 2022-06-26 02:22:32.706589
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import support
    import doctest
    doctest.DONT_ACCEPT_BLANKLINE = True
    doctest.ELLIPSIS_MARKER = '-ellipsis-'
    doctest.NORMALIZE_WHITESPACE = True
    globs = globals()
    globs.update(locals())
    return doctest.DocTestSuite(globs=globs, optionflags=doctest.NORMALIZE_WHITESPACE|doctest.ELLIPSIS)



# Generated at 2022-06-26 02:22:38.054158
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_0 = ImportProcessor()
    try:
        raise import_processor_0.IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    except Exception as e:
        if not (repr(e) == 'IllegalUseOfScopeReplacer(name, msg, extra)'):
            raise AssertionError


# Generated at 2022-06-26 02:22:45.825829
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """func IllegalUseOfScopeReplacer.__unicode__
    (self) -> unicode"""
    from bzrlib.lazy_import import ScopeReplacer
    import_processor_0 = ImportProcessor()
    object_0 = ScopeReplacer(import_processor_0, 'mod', 'name')
    try:
        object_0.replaced
        raise AssertionError('indirect-access')
    except IllegalUseOfScopeReplacer as e:
        # check that the exception message is formatted correctly
        try:
            e._get_format_string()
        except Exception:
            pass

# Generated at 2022-06-26 02:22:48.760926
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    import_processor_1 = ImportProcessor()
    import_processor_1.__str__()


# Generated at 2022-06-26 02:22:50.105616
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    import_processor_0 = ImportProcessor()


# Generated at 2022-06-26 02:23:23.038441
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    e = IllegalUseOfScopeReplacer(name='foo', msg='bar', extra=None)
    u = e._format()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'foo\' was used incorrectly: bar'


# Generated at 2022-06-26 02:23:26.012181
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    e = IllegalUseOfScopeReplacer("name", "msg", "extra")
    str(e)



# Generated at 2022-06-26 02:23:29.222672
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    try:
        test_case_0()
    except IllegalUseOfScopeReplacer as e:
        # Test that repr(e) is a valid way of instantiating the exception
        test = eval('%s' % repr(e))
        # Test that the exception can be formatted
        u = str(e)
        # Test that the exception can be printed

# Generated at 2022-06-26 02:23:31.821936
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = IllegalUseOfScopeReplacer('foo', 'bar').__unicode__()
    return u


# Generated at 2022-06-26 02:23:35.636243
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()
    test_case_1()
    try:
        e = IllegalUseOfScopeReplacer(name=u'foo', msg=u'bar')
    except:
        e = None
    if e is None:
        return 0
    return 1


# Generated at 2022-06-26 02:23:36.583366
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import_processor_0 = ImportProcessor()


# Generated at 2022-06-26 02:23:48.642179
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    from bzrlib.tests import TestNotApplicable
    import __builtin__
    def _factory(replacer, scope, name):
        scope["a"] = 'foo'
        return scope["a"]
    scope = globals()
    name = "a"
    obj = ScopeReplacer(scope, _factory, name)
    # call internal function _resolve on the obj
    obj._resolve()
    # assignment to the original name "a" should be replaced by the
    # resolved object
    scope[name] = "bar"
    # The actual name "a" should be assigned to the scope as
    # determined by _factory, not the origianl name "a"
    if scope[name] != "foo":
        raise

# Generated at 2022-06-26 02:23:51.983321
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    r = ScopeReplacer({}, lambda s, n: n, '')
    r.a = 1
    assert r.a == 1


# Generated at 2022-06-26 02:23:52.936195
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()


# Generated at 2022-06-26 02:23:55.586404
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    import_processor = ImportProcessor()
    IllegalUseOfScopeReplacer('name', 'msg')


# Generated at 2022-06-26 02:25:18.098706
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Method __unicode__ of class IllegalUseOfScopeReplacer"""
    name = 'import_processor_0'
    msg = 'object was not initialized'
    extra = 'inside function test_IllegalUseOfScopeReplacer___unicode__'
    ex = IllegalUseOfScopeReplacer(name, msg, extra)
    txt = unicode(ex)
    # Check that the exception was properly formatted
    assert 'not initialized' in txt
    assert 'test_IllegalUseOfScopeReplacer' in txt



# Generated at 2022-06-26 02:25:25.409174
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import_processor_0 = ImportProcessor()
    scope_replacer_0 = ImportProcessor.create_lazy('bzrlib.lazy_import.Proxy',
                                                   'bzrlib',
                                                   import_processor_0,
                                                   'lambda *args: NotImplemented')
    try:
        assert import_processor_0.bzrlib.NotImplemented == NotImplemented

    # caught exception
    except ImportError as exc:
        raise AssertionError('Raised ImportError unexpectedly')


# Generated at 2022-06-26 02:25:31.650031
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests
    import bzrlib
    import_processor_0 = ImportProcessor(bzrlib.tests.test_lazy_import)
    import_processor_1 = ImportProcessor(bzrlib.tests)
    import_processor_2 = ImportProcessor(bzrlib)
    test_case_0(import_processor_0, import_processor_1, import_processor_2)
