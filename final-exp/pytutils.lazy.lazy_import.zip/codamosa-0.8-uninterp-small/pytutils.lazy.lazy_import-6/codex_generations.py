

# Generated at 2022-06-26 02:16:15.050554
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_IllegalUseOfScopeReplacer___unicode___0 = IllegalUseOfScopeReplacer(bool_0, bool_0)
    test_IllegalUseOfScopeReplacer___unicode___0_u = test_IllegalUseOfScopeReplacer___unicode___0._format()
    try:
        test_IllegalUseOfScopeReplacer___unicode___0_u_u = unicode(test_IllegalUseOfScopeReplacer___unicode___0_u)
    except UnicodeDecodeError as test_IllegalUseOfScopeReplacer___unicode___0_u_u_e:
        test_IllegalUseOfScopeReplacer___unicode___0_u_u_e_u = unicode(test_IllegalUseOfScopeReplacer___unicode___0_u_u_e)


# Generated at 2022-06-26 02:16:16.546226
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()


# Generated at 2022-06-26 02:16:18.589401
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    test_case_0()


# Generated at 2022-06-26 02:16:23.839890
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    bool_0 = False
    bool_1 = True
    str_0 = str()
    str_1 = str()
    # Line: 26
    illegal_use_of_scope_replacer_0 = IllegalUseOfScopeReplacer(bool_0, bool_0)
    # Line: 27
    def function_0(param_0, param_1, param_2):
        """function_0 doc string"""
        # Line: 28
        try:
            # Line: 29
            if (param_0 or param_1):
                # Line: 30
                param_2[str_0] = bool_0
            else:
                # Line: 31
                param_2[str_1] = bool_1
        except:
            # Line: 33
            param_2[str_0] = bool_0
    
       

# Generated at 2022-06-26 02:16:29.096086
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    bool_0 = False
    scope_replacer_0 = ScopeReplacer(bool_0, bool_0, bool_0)
    scope_replacer_0.__setattr__(bool_0, bool_0)


# Generated at 2022-06-26 02:16:33.035067
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import test_case_0

    try:
        test_case_0()
    except Exception as exc:
        exc_str = str(exc)
        assert isinstance(exc_str, str)
        assert exc_str == 'Unprintable exception IllegalUseOfScopeReplacer: dict={}, fmt=None, error=None'


# Generated at 2022-06-26 02:16:45.281316
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    sys.modules['bzrlib.tests.test_lazy_import'] = sys.modules['bzrlib.tests.test_lazy_import']
    class TestClass(object):
        def __init__(self):
            self.bool_0 = False
        def __getattribute__(self, attr):
            if attr == '__setattr__':
                ScopeReplacer._should_proxy = False
                tmp_0 = object.__getattribute__(self, attr)
                tmp_0('bool_0', True)
                return tmp_0
            return object.__getattribute__(self, attr)
    test_class_0 = TestClass()

# Generated at 2022-06-26 02:16:47.368516
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    test_case_0()
    try:
        test_case_0()
        assert False
    except IllegalUseOfScopeReplacer as e:
        assert True


# Generated at 2022-06-26 02:16:55.456491
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    bool_0 = False
    illegal_use_of_scope_replacer_0 = IllegalUseOfScopeReplacer(bool_0, bool_0)
    unicode_0 = unicode()
    try:
        unicode_0 = illegal_use_of_scope_replacer_0.__unicode__()
    except Exception as exception_0:
        raise exception_0
    else:
        try:
            assert bool_0 is False
        except AssertionError as exception_0:
            raise exception_0


# Generated at 2022-06-26 02:17:01.296688
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # IllegalUseOfScopeReplacer.__init__
    illegal_use_of_scope_replacer_0 = IllegalUseOfScopeReplacer(test_case_0, test_case_0)
    scope_replacer_0 = ScopeReplacer(test_case_0, test_case_0, test_case_0)
    try:
        # Should raise IllegalUseOfScopeReplacer
        scope_replacer_0.__setattr__(test_case_0, test_case_0)
        passed = True
    except IllegalUseOfScopeReplacer:
        passed = False

# Generated at 2022-06-26 02:17:25.071632
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # Call function 'IllegalUseOfScopeReplacer' of module 'test_lazy_import'
    # test_case_0()

    test_result = False


# Generated at 2022-06-26 02:17:29.820422
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    msg = 'test case 0 failed'
    try:
        test_case_0()
    except Exception as err:
        if not isinstance(err, IllegalUseOfScopeReplacer):
            raise AssertionError(msg)

# Generated at 2022-06-26 02:17:32.469340
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    str_0 = 'bzrlib.tests.test_lazy_import'


# Generated at 2022-06-26 02:17:37.226696
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    name = 'bzrlib.tests.test_lazy_import'
    extra = 'bzrlib.tests.test_lazy_import'
    msg = 'bzrlib.tests.test_lazy_import'
    obj = IllegalUseOfScopeReplacer(name, msg, extra)
    assert str_0 == repr(obj)


# Generated at 2022-06-26 02:17:42.921076
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test that __str__(IllegalUseOfScopeReplacer) does not throw an exception"""
    str_0 = 'bzrlib.tests.test_lazy_import'
    IllegalUseOfScopeReplacer()


# Generated at 2022-06-26 02:17:45.358579
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    blah = IllegalUseOfScopeReplacer(blah, blah)
    blah.__unicode__()


# Generated at 2022-06-26 02:17:51.845673
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_case_0()
    # TODO: implement test case
    raise NotImplementedError('%s.%s' % (__name__,
                                         'test_IllegalUseOfScopeReplacer___unicode__'))


# Generated at 2022-06-26 02:17:59.377041
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    from bzrlib.tests.per_interpreter import TestCaseWithInterpreter
    import sys
    import bzrlib.tests
    str_0 = 'bzrlib.tests.test_lazy_import'
    str_1 = '\n    foo,\n    '
    str_2 = '\nfrom bzrlib import (\n    foo,\n    )'
    str_3 = 'from bzrlib import (\n    foo,\n)'
    str_4 = 'bzrlib is not a module name'
    str_5 = 'bzrlib is not a package'
    str_6 = 'bzrlib is not a module name'
    str_7 = 'bzrlib is not a package'

# Generated at 2022-06-26 02:18:03.548105
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    str_0 = "'Hello'"
    str_1 = 'bzrlib.tests.test_complex_lazy_import'
    test_case_0()



# Generated at 2022-06-26 02:18:11.298451
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    _a = lazy_import(globals(), locals(), ['ScopeReplacer'], 1)
    def _f(self, scope, name):
        return 55

    def _g(self, scope, name):
        return 77

    f = ScopeReplacer({}, _f, "f")
    f()
    #Check f is replaced
    if f != 55:
        raise ValueError('f is not 55')

    # Check that f is replaced with a new value
    f = ScopeReplacer({}, _g, "f")
    f()
    if f != 77:
        raise ValueError('f is not 77')


# Generated at 2022-06-26 02:18:22.425975
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.test_lazy_import
    return


# Generated at 2022-06-26 02:18:29.056628
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()
    import bzrlib.tests.test_lazy_import
    scope = {}
    name = 'real_obj'
    value = bzrlib.tests.test_lazy_import
    factory = (lambda self, scope, name:
        bzrlib.tests.test_lazy_import.ScopeReplacer(scope, factory, name))
    value.ScopeReplacer(scope, factory, name).__setattr__(name,value)


# Generated at 2022-06-26 02:18:39.149376
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    str_0 = 'bzrlib.tests.test_lazy_import'
    _factory_0 = test_case_0
    local_scope_0 = locals()
    _name_0 = 'test_case_0'
    # Constructing an object of the base type ScopeReplacer
    _obj_0 = ScopeReplacer(local_scope_0, _factory_0, _name_0)
    try:
        _obj_0.__setattr__('_name', '_name')
    except AttributeError:
        pass
    # Constructing an object of the base type ScopeReplacer
    _obj_1 = ScopeReplacer(local_scope_0, _factory_0, _name_0)

# Generated at 2022-06-26 02:18:45.106473
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""

    # From the class definition:
        #   The string returned by __unicode__ must be a unicode string
        #   not a regular string.
    # This is not a test of the implementation. The implementation is
    # simply to cast the result of __str__ to unicde. This is tested
    # in test_IllegalUseOfScopeReplacer___str__ instead.
    try:
        e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
        result = e.__unicode__()
    except AssertionError as e:
        if (not isinstance(e, AssertionError) or
            'unicode' not in e.args[0]):
            # Wrong exception type/content
            raise

# Generated at 2022-06-26 02:18:49.844262
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """Unit test for method __call__ of class ScopeReplacer"""
# Constructor test(s)

# Method test(s)

# vim: set fileencoding=utf-8 filetype=python shiftwidth=4 tabstop=4 softtabstop=4 expandtab :

# Generated at 2022-06-26 02:18:52.789036
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test for method __setattr__ of class ScopeReplacer"""
    # TODO: implement your test here
    raise SkipTest


# Generated at 2022-06-26 02:19:02.632633
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    str_1 = test_case_0()
    py_1 = lazy_import(globals(), str_1)
    py_2 = ScopeReplacer(py_1)
    py_3 = py_1['src_branch']
    py_4 = '%s(%s)' % ('IllegalUseOfScopeReplacer', 'bzrlib.tests.test_lazy_import.src_branch')
    py_5 = py_2.replace(py_3, py_1['dst_branch'])
    py_6 = py_2.replace(py_3, py_1['dst_branch'])
    py_7 = IllegalUseOfScopeReplacer(py_3, 'Already replaced')
    assert py_4 == py_7.__unicode__()
	

# Generated at 2022-06-26 02:19:03.273231
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    raise NotImplementedError


# Generated at 2022-06-26 02:19:04.831426
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    u = 'bzrlib.tests.test_lazy_import'


# Generated at 2022-06-26 02:19:16.491976
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    test_case_0()
    # A ScopeReplacer may not be used to assign to another member, only the
    # generated objects may be used for this.
    from bzrlib.lazy_import import ScopeReplacer, lazy_import
    scope = {}
    def create_thing(s, scope, name):
        scope[name] = 'mything'
        return scope[name]
    ScopeReplacer(scope, create_thing, 'mything')
    lazy_import(scope, '''
    from bzrlib.config import C
    ''')
    # The generated object is ok.
    mything = scope['mything']
    mything.foo = 'foo'
    # The scope replacer is not ok.
    scope_replacer = scope['mything']

# Generated at 2022-06-26 02:19:25.414671
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    var_0 = ScopeReplacer
    var_2 = len
    var_3 = var_0(var_1, var_0, var_2)
    return var_3


# Generated at 2022-06-26 02:19:27.777368
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    try:
        raise IllegalUseOfScopeReplacer("var_0", "var_1", "var_2")
    except IllegalUseOfScopeReplacer as e:
        pass
    # Some expression to make pychecker happy
    assert "var_3"


# Generated at 2022-06-26 02:19:29.938345
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    #TODO: Test for method __str__ of class IllegalUseOfScopeReplacer
    raise NotImplementedError



# Generated at 2022-06-26 02:19:41.454274
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Method __init__ of class ScopeReplacer creates ScopeReplacer
    # objects.
    var_0 = ScopeReplacer
    scope = {'key_0': 'value_0'}
    name_0 = 'name_0'
    factory = lambda self, scope: scope
    obj_0 = var_0(scope, factory, name_0)
    first_attr = '_real_obj'
    first_value = 'value_1'
    # Method __setattr__ can be called with a string as first
    # argument (the name of the attribute to set) and a second
    # argument that is an object.
    obj_0.__setattr__(first_attr, first_value)
    real_obj = obj_0._real_obj
    real_obj_member = real_obj._real_obj
    # The

# Generated at 2022-06-26 02:19:47.497698
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    ut_0 = IllegalUseOfScopeReplacer(
        u'u_var_0',
        u'u_var_1',
        )
    assert len(ut_0._format()) > 0
    assert ut_0._get_format_string()
    assert ut_0.__str__().decode('UTF-8') == ut_0.__unicode__()
    assert unicode(ut_0) == ut_0.__unicode__()



# Generated at 2022-06-26 02:19:51.937242
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    var_0 = ScopeReplacer(globals(), lambda self,scope,name:scope[name], 'var_0')
    test_case_0()
    check_object(var_0, "var_0", IllegalUseOfScopeReplacer)
    # call:
    var_0 = var_0()
    # call:
    var_0.test_case_0()


# Generated at 2022-06-26 02:19:53.910893
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    # Test normal behavior
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    var_0.__str__() # expected no exception


# Generated at 2022-06-26 02:19:59.930684
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.script import TestCaseInTempDir

    test_case = TestCaseInTempDir()
    import sys
    test_case_0 = ScopeReplacer(sys.modules['__main__'],
                                ScopeReplacer_factory,
                                'var_0')
    test_case_0()


# Generated at 2022-06-26 02:20:09.228948
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    current_scope = {'var_0':0}
    test_obj_0 = ScopeReplacer(current_scope,
                               method_0,
                               'var_0')
    try:
        test_obj_0.__setattr__('attribute_0', 0)
        test_obj_0._should_proxy = False
        test_obj_0.__setattr__('attribute_1', 0)
        test_obj_0._should_proxy = True
        if test_obj_0._real_obj is None:
            raise AssertionError
    except KeyboardInterrupt:
        raise
    except ValueError:
        raise
    except:
        raise AssertionError


# Generated at 2022-06-26 02:20:18.080395
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    # Note that the message for IllegalUseOfScopeReplacer contains a % character
    # so attempts to format this will fail; this is to demonstrate that
    # IllegalUseOfScopeReplacer handles the error safely.
    e = IllegalUseOfScopeReplacer("name", "msg", extra=5)
    try:
        f = e.__format__("")
    except TypeError:
        pass # expected result
    # Note that the contents of e are not checked directly, as on Python 2.6,
    # some extra repr(e) information is present, so this will fail. Instead,
    # just check that the message is a valid unicode object
    assert type(e.__unicode__()) == unicode



# Generated at 2022-06-26 02:20:37.816165
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    obj = ScopeReplacer(None, None, None)
    # AssertionError: len(args) must be 2
    # __setattr__() takes exactly 2 arguments (1 given)
    obj.__setattr__('attr')

    # AssertionError: args[1] must be None or not equal
    obj.__setattr__('attr', 'value')
    obj.__setattr__('attr', 'value')

    # AttributeError: _real_obj not set
    with open('file.txt', 'a') as f:
        obj.__setattr__('attr', 'value', f)



# Generated at 2022-06-26 02:20:41.594358
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    try:
        var_0 = IllegalUseOfScopeReplacer("foo", "bar")
    except:
        var_0 = sys.exc_info()[1]
    var_0.__str__()
    var_0.__str__()

# Generated at 2022-06-26 02:20:42.515573
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_0 = IllegalUseOfScopeReplacer('name', 'msg', 'extra')



# Generated at 2022-06-26 02:20:48.752999
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # Test getter with initial object.
    ci = CountingImporter()

# Generated at 2022-06-26 02:20:52.516724
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Tests IllegalUseOfScopeReplacer.__str__()"""
    unit_test.assertEqual(
        repr(IllegalUseOfScopeReplacer('yes', 'no')),
        'IllegalUseOfScopeReplacer(yes: no)')


# Generated at 2022-06-26 02:21:03.753475
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import disallow_proxying
    import sys
    import traceback

    # Verify that a correct argument does not trigger an exception
    try:
        test_case_0()
    except Exception as e:
        raise AssertionError('Raised unexpected exception in test_case_0:\n%s' %(traceback.format_exc()))

    # Verify that a bad argument raises an appropriate exception
    try:
        test_case_1()
    except IllegalUseOfScopeReplacer as e:
        if str(e) != 'ScopeReplacer object \'var_1\' was used incorrectly: Object already replaced, did you assign it to another variable?':
            raise AssertionError('Raised unexpected exception in test_case_1:\n%s' %(traceback.format_exc()))

# Generated at 2022-06-26 02:21:07.717055
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    obj = bzrlib.lazy_import.ScopeReplacer(None, None, None)
    obj._should_proxy = True
    attr = 'name'
    value = 'value'
    obj.__setattr__(attr, value)


# Generated at 2022-06-26 02:21:10.754823
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    assert_equal(test_case_0().__str__(), 'Unprintable exception IllegalUseOfScopeReplacer: dict={\'name\': disallow_proxying, \'extra\': \'\', \'msg\': \'1\'}, fmt=None, error=None')


# Generated at 2022-06-26 02:21:15.651057
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.config import (
        BzrConfig,
        GlobalConfig,
        )
    from bzrlib.config import (
        TransportConfig,
        StandardTransportConfig,
        )
    from bzrlib.config import (
        ConfigObj,
        )
    from bzrlib import (
        errors,
        urlutils,
        ui,
        transport,
        trace,
        )
    import bzrlib.trace
    import bzrlib.ui
    scope = locals()

# Generated at 2022-06-26 02:21:18.063500
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    obj = ScopeReplacer(None, None, 'name_0')
    var_0 = obj._resolve()


# Generated at 2022-06-26 02:21:45.734115
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    expected = "ScopeReplacer object 'var_0' was used incorrectly: "
    assert(IllegalUseOfScopeReplacer('var_0', "ScopeReplacer object 'var_0' was used incorrectly: ") ==
           IllegalUseOfScopeReplacer('var_0', "ScopeReplacer object 'var_0' was used incorrectly: "))
    assert(IllegalUseOfScopeReplacer('var_0', "ScopeReplacer object 'var_0' was used incorrectly: ") !=
           IllegalUseOfScopeReplacer('var_0', "ScopeReplacer object 'var_0' was used incorrectly: ", 'msg'))

# Generated at 2022-06-26 02:21:48.180312
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Unit test for method __unicode__ of class IllegalUseOfScopeReplacer"""

# Generated at 2022-06-26 02:21:58.223806
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    scope = {}
    scopeReplacer0 = ScopeReplacer(scope,
                                   (lambda param_0, param_1, param_2:
                                    None),
                                   'var_0')
    # The next line causes an exception which is caught in the following
    # try-except statement. If the exception is not caught there, the
    # test is considered to have failed.
    try:
        scopeReplacer0._should_proxy = False
        scopeReplacer0.var_1 = 'var_1'
    except TypeError:
        return 0
    # If the next line is reached, the test has failed.
    raise AssertionError(
        "Exception not raised when calling method __setattr__ of class"
        " ScopeReplacer")



# Generated at 2022-06-26 02:22:05.864816
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """test_ScopeReplacer___setattr__ - test setting of attributes"""
    # test__setattr__ is a static method
    # test_arg_unexpected is a static method
    # test_arg_unexpected is a static method
    # test_arg_unexpected is a static method
    # test_arg_unexpected is a static method
    # test_arg_unexpected is a static method
    # test_arg_unexpected is a static method
    # test_arg_unexpected is a static method
    # test__setattr__ is a static method


# Generated at 2022-06-26 02:22:09.634000
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Calling __getattribute__ of ScopeReplacer
    # __getattribute__ is implemented manually, so no need to test it.
    var_0 = ScopeReplacer
    var_0 = var_0


# Generated at 2022-06-26 02:22:21.183292
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # We're testing IllegalUseOfScopeReplacer.__unicode__, not
    # IllegalUseOfScopeReplacer.__str__.
    testcase_0 = IllegalUseOfScopeReplacer('str', 'str') # __init__
    # unicode: testcase_0 is expected to be an instance of class
    # IllegalUseOfScopeReplacer.
    testcase_0.__class__
    # testcase_0 is expected to be an instance of class IllegalUseOfScopeReplacer.
    unicode_0 = unicode(testcase_0)
    # unicode: unicode_0 is expected to be an instance of class unicode.
    unicode_0.__class__
    # unicode_0's value is expected to be 'IllegalUseOfScopeReplacer(u'IllegalUseOfScopeReplacer(u'IllegalUseOf

# Generated at 2022-06-26 02:22:28.014814
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.lazy_import import lazy_class, disallow_proxying

    # test for the function:
    # def __call__(self, *args, **kwargs):
    # case 0:
    # test for the case of __call__

    class test(ExternalBase):
        def test_call(self):
            test_case_0()
            return 1
    class_name = 'test'
    test_case = getattr(test, 'test_call')
    var_0 = lazy_class(class_name)
    var_0 = lazy_class(class_name)
    var_0 = test_case()
    var_0 = disallow_proxying()

    return 1



# Generated at 2022-06-26 02:22:30.664807
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    r = IllegalUseOfScopeReplacer('name', 'msg', 'extra')



# Generated at 2022-06-26 02:22:35.139356
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    name = 'var_0'
    attr = 'attr_0'
    value = 'value_0'
    scope = {name: ScopeReplacer(scope = {}, factory = None, name = name)}
    scope[name][attr] = value
    var_0 = scope[name][attr]
    assert var_0 == value


# Generated at 2022-06-26 02:22:41.137152
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__ is called on an instance of the class
    # we want to test an assignment to a class variable
    ScopeReplacer._should_proxy = True

# Generated at 2022-06-26 02:23:55.012874
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Tests calling method __getattribute__ on object of class ScopeReplacer
    # Ensures correct response to correct argument types
    # Ensures correct response to incorrect argument types
    # Test correct arguments

    # Test incorrect arguments

    pass # no test needed


# Generated at 2022-06-26 02:24:02.404651
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """Test that __unicode__ returns a unicode object, and not a str object

    In Python 2.6, __unicode__ was renamed to __str__, so this test has been
    updated to use __str__, but it will still test that it returns a unicode
    object, not a str object.
    """
    try:
        test_case_0()
    except Exception as e:
        u = e.__str__()
        from bzrlib.tests import TestSkipped
        if isinstance(u, str):
            raise TestSkipped("TODO: Fix IllegalUseOfScopeReplacer.__unicode__")

ScopeReplacer = _ScopeReplacer



# Generated at 2022-06-26 02:24:07.752666
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    test_object = IllegalUseOfScopeReplacer()
    # __unicode__ must return an unicode object
    if (not isinstance(test_object.__unicode__(), unicode)):
        return False
    return True


# Generated at 2022-06-26 02:24:13.092836
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import (ScopeReplacer,
        disallow_proxying as _disallow_proxying)
    _disallow_proxying()
    import bzrlib.lazy_import
    x = bzrlib.lazy_import.ScopeReplacer._should_proxy
    return x


# Generated at 2022-06-26 02:24:14.634051
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    o = ScopeReplacer(var_0, var_0, var_0)
    o()


# Generated at 2022-06-26 02:24:19.178646
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    var_1 = u"Unprintable exception IllegalUseOfScopeReplacer"
    var_2 = IllegalUseOfScopeReplacer(None, None)
    var_3 = var_2.__unicode__()
    assert var_3 == var_1


# Generated at 2022-06-26 02:24:20.841219
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """ScopeReplacer.__call__() -> <whatever the underlying object is>"""
    test_case_0()


# Generated at 2022-06-26 02:24:23.377523
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    # This is just a very trivial test of the method.  It should be expanded.
    assert isinstance(IllegalUseOfScopeReplacer('name', 'message').__unicode__(), unicode)


# Generated at 2022-06-26 02:24:33.065744
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests.per_lazy_import import TestCaseWithMemoryTransport

    class TestCase(TestCaseWithMemoryTransport):

        def test___setattr__(self):
            def f(s, scope, name): pass
            var_0 = lazy_import.ScopeReplacer(
                {}, f, 'fake_variable')
            var_0.__setattr__('fake_attribute', 'value')
            return

    test_case_0()


# Generated at 2022-06-26 02:24:34.739977
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    var_1 = IllegalUseOfScopeReplacer(n='S', msg='M', extra='E')
