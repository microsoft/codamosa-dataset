

# Generated at 2022-06-25 02:02:00.263380
# Unit test for function main
def test_main():
    var_1 = {'_ansible_parsed': True, '_ansible_diff': None, '_ansible_no_log': False, '_ansible_check_mode': False, '_ansible_debug': False, '_ansible_verbose_always': True, '_ansible_verbosity': 0, '_ansible_socket': None, '_ansible_item_result': True, '_ansible_item_label': None, '_ansible_item_skip_fields': [], '_ansible_item_label_args': None}
    var_3 = [-1, '127.0.0.1', 22]

# Generated at 2022-06-25 02:02:05.927764
# Unit test for function main
def test_main():
    try:
        main()
    except:
        raise AssertionError('An error occurred during testing')

test_case_0()

# Generated at 2022-06-25 02:02:10.857841
# Unit test for function check_command
def test_check_command():
    commandline = "/usr/bin/make_database.sh db_user db_name creates=/path/to/database"
    module = AnsibleModule(argument_spec={})
    ret = check_command(module, commandline)
    assert ret == None


# Generated at 2022-06-25 02:02:11.697339
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    # main()
    test_main()

# Generated at 2022-06-25 02:02:12.555761
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:02:17.053167
# Unit test for function main
def test_main():
    import tempfile
    fd, filename = tempfile.mkstemp()
    # Remove file
    os.close(fd)
    if os.path.exists(filename):
        os.remove(filename)
    with open(filename, "w") as f:
        f.write("\n")
    test_case_0()
    # Remove file
    if os.path.exists(filename):
        os.remove(filename)


# Generated at 2022-06-25 02:02:18.288964
# Unit test for function check_command
def test_check_command():
    commandline = 'commandline'
    module = os.path
    # check_command(module, commandline)


# Generated at 2022-06-25 02:02:24.058830
# Unit test for function main
def test_main():
    # Replace below with your actual code
    try:
        main()
    except Exception as e:
        print('Error:', e)
        return 0
    return 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:02:29.184970
# Unit test for function main
def test_main():

    # Create the function object for function main
    function1 = A1()

    # Set parameters for function main
    function1.str_0 = u'var_11'
    function1.bool_0 = True
    function1.str_1 = u'var_18'
    function1.str_2 = u'var_10'
    function1.str_3 = u'var_20'
    function1.str_4 = u'var_3'
    function1.str_5 = u'var_9'
    function1.str_6 = u'var_8'

# Generated at 2022-06-25 02:02:35.783544
# Unit test for function main
def test_main():
    mock_module = type('MockModule', (), {'exit_json': lambda self, **kwargs: None, 'fail_json': lambda self, **kwargs: None})
    mock_module_instance = mock_module()
    real_datetime = datetime.datetime
    real_glob = glob.glob
    real_os = os
    real_shlex = shlex
    real_text = to_text

    tmp_glob = type('Glob', (), {'glob': lambda self, *args: None})
    tmp_text = type('Text', (), {'to_text': lambda self, *args: None})

    datetime.datetime = type('DateTime', (), {'now': lambda self: None, 'datetime': type('DateTime', (), {'now': lambda self: None})})

# Generated at 2022-06-25 02:02:52.921617
# Unit test for function main
def test_main():
    arg_0 = {'_raw_params': '', '_uses_shell': '', 'argv': '', 'chdir': '', 'executable': '', 'creates': '', 'removes': '', 'warn': '', 'stdin': '', 'stdin_add_newline': '', 'strip_empty_ends': ''}
    main(arg_0)

if __name__ == '__main__':
    test_case_0()
    test_main()
else:
    main()

# Generated at 2022-06-25 02:02:54.403784
# Unit test for function check_command
def test_check_command():
    test_case_0()


# Generated at 2022-06-25 02:02:56.125436
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:02:56.982046
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:02:58.241508
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:03:01.263706
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Error while testing function main')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:03:10.801604
# Unit test for function check_command
def test_check_command():
    # AnsibleModule object
    module = AnsibleModule(
        argument_spec = dict(
            free_form=dict(type='str'),
            cmd=dict(type='str'),
            argv=dict(type='list', elements='str'),
            creates=dict(type='str'),
            removes=dict(type='str'),
            chdir=dict(type='str'),
            warn=dict(type='bool'),
            stdin=dict(type='str'),
            stdin_add_newline=dict(type='bool'),
            strip_empty_ends=dict(type='bool')
        ),
        supports_check_mode=True,
    )

    # AnsibleModule object

# Generated at 2022-06-25 02:03:17.987978
# Unit test for function main

# Generated at 2022-06-25 02:03:27.532247
# Unit test for function main
def test_main():
    var_1 = {'_ansible_check_mode': False, '_ansible_no_log': False, '_ansible_debug': False, '_ansible_diff': False, '_ansible_verbosity': 0, '_ansible_version': u'2.7.0', '_ansible_module_name': u'ansible.builtin.command', '_ansible_module_sourcedir': '/root/ansible/ansible/modules/commands', '_ansible_syslog_facility': u'LOG_USER', '_ansible_module_name': u'ansible.builtin.command', '_ansible_socket': None, '_ansible_module_sourcedir': '/root/ansible/ansible/modules/commands'}

# Generated at 2022-06-25 02:03:28.354292
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:03:50.304096
# Unit test for function main
def test_main():
    # mock_args
    mock_args = dict({})
    main.return_value = None
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 02:03:54.683248
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:03:59.373489
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:04:00.752180
# Unit test for function main
def test_main():
    var_0 = main()
    result = 's'

    assert result == var_0
    

# Generated at 2022-06-25 02:04:08.735008
# Unit test for function main
def test_main():
    var_1 = ["alias"]
    var_2 = {"changed": False, "stdout": "", "stderr": "", "rc": None, "cmd": None, "start": None, "end": None, "delta": None, "msg": ""}
    var_3 = "alias"
    var_4 = False
    var_5 = None
    var_6 = main(var_1, var_2, var_3, var_4, var_5)


# Generated at 2022-06-25 02:04:11.573142
# Unit test for function check_command
def test_check_command():
  module = AnsibleModule(argument_spec={})
  commandline = 'crystal-1.0.2-1.x86_64.rpm'
  # Check default behavior
  if not os.path.exists(commandline):
    test_case_0()
    check_command(module, commandline)


# Generated at 2022-06-25 02:04:15.912667
# Unit test for function check_command
def test_check_command():
    AnsibleModule = AnsibleModul(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run()

main()

# Generated at 2022-06-25 02:04:18.068241
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print >>sys.stderr, "Reneging on promise to not exit"
            sys.exit(1)


# Generated at 2022-06-25 02:04:28.988919
# Unit test for function main

# Generated at 2022-06-25 02:04:32.470948
# Unit test for function main
def test_main():
    args = [
     __file__,
     '--help',
    ]
    ret = 0
    with open('testcase.txt', 'w') as fp:
        ret = do_test(args, fp)
        ret |= do_test(args, fp)
    if ret == 0:
        print('test passed')
    else:
        print('test failed')


# Generated at 2022-06-25 02:05:14.401334
# Unit test for function check_command

# Generated at 2022-06-25 02:05:15.209467
# Unit test for function check_command
def test_check_command():
    main(None, None)


# Generated at 2022-06-25 02:05:21.308427
# Unit test for function main
def test_main():
    var_0 = {'warn': False, 'creates': None, 'removes': None, '_raw_params': '', '_uses_shell': False, 'chdir': None, 'stdin_add_newline': True, 'strip_empty_ends': True, 'argv': [], 'executable': None}
    main(var_0)


# Generated at 2022-06-25 02:05:23.356662
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    # Test module
    commandline = ["ansible-doc", "packaging"]
    check_command(module, commandline)



# Generated at 2022-06-25 02:05:25.919993
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == 0


# Generated at 2022-06-25 02:05:26.786496
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:33.176957
# Unit test for function main
def test_main():
    # check if variable is actually a function
    assert callable(main)
    try:
        test_case_0()
    except Exception as e:
        assert 0
    else:
        assert 1


# Generated at 2022-06-25 02:05:42.914569
# Unit test for function main
def test_main():
    import ansible.module_utils.command as command

    # AnsibleModule class
    args = {}
    args["_raw_params"] = "net"
    args["_uses_shell"] = False
    args["chdir"] = ""

    # AnsibleModule.__init__()
    module = AnsibleModule(argument_spec=args)
    # AnsibleModule.run_command()
    (rc, out, err) = command.run_command('/usr/sbin/nginx -t', use_unsafe_shell=False, encoding=None)
    assert rc == 0
    assert out == ''
    assert err == ''
    module.exit_json(changed=False, msg='foo')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:49.998904
# Unit test for function main
def test_main():
    # mock module
    class AnsibleModule:
        def __init__(self):
            pass
        def fail_json(self, **kwargs):
            pass
        def warn(self, **kwargs):
            pass
        def check_mode(self):
            return False
        def run_command(self, args, executable, use_unsafe_shell, data, binary_data):
            return 0, '', ''

    mod = AnsibleModule()
    mod.fail_json = MagicMock(side_effect=lambda *args, **kwargs: test_case_0())
    args = 'cat > /etc/motd'
    argv = None
    shell = False
    chdir = None
    executable = None
    creates = None
    removes = None
    warn = False
    stdin = None
    stdin_

# Generated at 2022-06-25 02:05:51.039857
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:07:18.827377
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 02:07:20.134568
# Unit test for function check_command
def test_check_command():
    test_case_0()

if __name__ == '__main__':
    test_check_command()

# Generated at 2022-06-25 02:07:20.655948
# Unit test for function main
def test_main():
    assert test_case_0() == 1

# Generated at 2022-06-25 02:07:21.646534
# Unit test for function main
def test_main():
    if not main():
        print("Failed to run main() function.")


# Generated at 2022-06-25 02:07:23.645334
# Unit test for function check_command
def test_check_command():
    var_0 = AnsibleModule()

    var_1 = ['/usr/bin/echo', 'hello']

    test_case_0()


# Generated at 2022-06-25 02:07:25.148560
# Unit test for function main
def test_main():
    var_0 = main()
    return var_0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:07:32.085307
# Unit test for function main
def test_main():
    var_0 = glob.glob('')
    var_1 = AnsibleModule(argument_spec=dict(_raw_params=dict(), _uses_shell=dict(type='bool', default=False), argv=dict(type='list', elements='str'), chdir=dict(type='path'), executable=dict(), creates=dict(type='path'), removes=dict(type='path'), warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'), stdin=dict(required=False), stdin_add_newline=dict(type='bool', default=True), strip_empty_ends=dict(type='bool', default=True)), supports_check_mode=True)
    var_2 = 'no command given'

# Generated at 2022-06-25 02:07:36.862798
# Unit test for function main
def test_main():
    try:
        test_case_0()

    # Define test suite
    except NameError as err:
        import sys
        print("NameError: " + err.args[0])
        import traceback
        print(traceback.format_exc()) # Print exception

    except:
        print("Unknown error: " + str(sys.exc_info()[0]))
        import traceback
        print(traceback.format_exc()) # Print exception

    else:
        print("No errors")

if __name__ == "__main__":
    main()
    test_main()

# Generated at 2022-06-25 02:07:37.604511
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:07:39.493959
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Error while executing main")
        raise

# main function entry point call
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:11:07.244101
# Unit test for function main

# Generated at 2022-06-25 02:11:08.310534
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:11:09.294477
# Unit test for function main
def test_main():
    var_1 = main()

if __name__ == '__main__':
    main()
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:11:09.927426
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:11:10.857547
# Unit test for function check_command
def test_check_command():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 02:11:11.542144
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 02:11:13.316569
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:11:18.344115
# Unit test for function check_command
def test_check_command():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except Exception:
        pass

    module = AnsibleModule([])
    module.params = []
    module.warn = lambda x: ''

    assert check_command(module, '')
    assert check_command(module, [''])
    assert check_command(module, [0])
    assert check_command(module, ['a', 'b'])

# tests for test_case_0

# Generated at 2022-06-25 02:11:19.567992
# Unit test for function main
def test_main():
    test_case_0()

test_main()

# Generated at 2022-06-25 02:11:27.598531
# Unit test for function main
def test_main():
    class Object(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    var_0 = Object(run_command=lambda var_0, executable, use_unsafe_shell, encoding, data, binary_data: (0, "stdout", "stderr"))
    var_1 = Object(params={'_uses_shell': False, 'warn': False, 'chdir': None, 'executable': None, '_raw_params': "echo", 'creates': None, 'stdin': None, 'removes': None, 'argv': []}, check_mode=False, fail_json=lambda var_0: Exception(), exit_json=lambda var_0: Exception(), warn=lambda var_0: Exception())
    var_1.module = var_0
    var_1