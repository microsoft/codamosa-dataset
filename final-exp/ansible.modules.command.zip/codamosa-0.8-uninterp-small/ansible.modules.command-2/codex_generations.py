

# Generated at 2022-06-25 02:02:01.445747
# Unit test for function main

# Generated at 2022-06-25 02:02:02.040577
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:02:10.062922
# Unit test for function main
def test_main():
    module_args = { "_raw_params": "xxx-xxx-xxx", "_uses_shell": False, "argv": [ "xxx" ], "warn": False, "chdir": "/tmp/ansible_command_payload_UNcaPn/roles/terraform/tasks", "executable": "xxx-xxx-xxx", "creates": "xxx-xxx-xxx", "removes": "xxx-xxx-xxx", "stdin": "xxx-xxx-xxx", "stdin_add_newline": False, "strip_empty_ends": True }
    with pytest.raises(SystemExit):
        main(module_args)


# Generated at 2022-06-25 02:02:18.063618
# Unit test for function main
def test_main():
    shell = False
    chdir = None
    executable = None
    args = None
    argv = None
    creates = None
    removes = None
    warn = False
    stdin = None
    stdin_add_newline = True
    strip = True
    return_value_0,return_value_1,return_value_2,rc,return_value_4,return_value_5,return_value_6,return_value_7,return_value_8,return_value_9 = main(shell,chdir,executable,args,argv,creates,removes,warn,stdin,stdin_add_newline,strip)
    assert True == return_value_0
    assert '' == return_value_1
    assert '' == return_value_2
    assert 256 == rc

# Generated at 2022-06-25 02:02:23.694454
# Unit test for function main
def test_main():
    import test.unit_tests as unit_tests
    unit_tests._test_module_generic(main)

if __name__ == '__main__':
    # test_case_0()
    test_main()

# Generated at 2022-06-25 02:02:25.233736
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    test_main()
    var_0 = main()

# Generated at 2022-06-25 02:02:25.865205
# Unit test for function main
def test_main():
    assert var_0 == None


# Generated at 2022-06-25 02:02:28.395963
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({'command':'echo hello'})
    check_command(module, 'ls')


# Generated at 2022-06-25 02:02:32.769527
# Unit test for function main
def test_main():
    # Stub for function main
    command_line = 'ping www.baidu.com'
    argv = shlex.split(command_line)
    main(argv)

if __name__ == "__main__":
    test_case_0()
    #test_main()

# Generated at 2022-06-25 02:02:33.866803
# Unit test for function main
def test_main():
    assert value == True

test_case_0()
test_main()

# Generated at 2022-06-25 02:02:46.560147
# Unit test for function main
def test_main():
    var_0 = str()
    var_0 = "foo"
    var_0 = []
    var_0 = {'bar': 'baz'}

    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:02:48.466739
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('test_case_0 FAILED!')
    else:
        print('test_case_0 PASSED!')

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:02:59.444194
# Unit test for function main
def test_main():
    # Get the test cases for the function
    test_cases = [
        # (expected, input0, input1)
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), ""),
        ((), (), "")
    ]

# Generated at 2022-06-25 02:03:08.793918
# Unit test for function main
def test_main():
    os.chdir("/tmp")

    argv = list()
    argv.append("/usr/local/bin/ansible-playbook")
    argv.append("/home/ansible/ansible_test/test-util/test-command/test_main.yml")
    argv.append("--extra-vars")
    argv.append(" == jbw")
    argv.append("--limit")
    argv.append("192.168.222.10")
    argv.append("--inventory-file")
    argv.append("/etc/ansible/hosts")
    argv.append("--connection")
    argv.append("local")
    argv.append("--module-name")
    argv.append("ansible.builtin.command")
    argv.append

# Generated at 2022-06-25 02:03:09.812253
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == True

# Generated at 2022-06-25 02:03:11.367014
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 != None


# Generated at 2022-06-25 02:03:18.521829
# Unit test for function main
def test_main():
    argument_spec = dict(
        _raw_params=dict(),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        # The default for this really comes from the action plugin
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )

# Generated at 2022-06-25 02:03:27.421530
# Unit test for function check_command
def test_check_command():
    # Check mode is not supported
    with pytest.raises(AnsibleExitJson) as exc:
        check_command(AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    ), ['ls'])
    assert exc.value.args[0]['rc'] == 0

    # check_command() does not have a return statement.
    # If check_command() does not have a return statement, the function can be simplified to a function declaration.
    assert check_command(AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    ), ['ls']) == None

if __name__ == '__main__':
    test_case_0()
    test_check_command()

# Generated at 2022-06-25 02:03:31.976779
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print >>sys.stderr, "Ran 1 tests in 0.000s"
            print >>sys.stderr, "FAILED (errors=1)"
            raise


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:03:37.869044
# Unit test for function main

# Generated at 2022-06-25 02:04:03.082305
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            print('GOOD: main() exit with 0')
        else:
            print(inst)
            print('FAIL: main() exit with non-zero')
    except BaseException as inst:
        print(inst)
        print('FAIL: main() threw BaseException')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:04:04.459584
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:04:08.020095
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Test Exception:  Unit test for function main")

# Run unit test
test_main()

# Generated at 2022-06-25 02:04:08.768668
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:04:10.047177
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:04:14.072114
# Unit test for function main
def test_main():
    var_0 = main()
    assert 'args' in var_0
    assert 'stdout' in var_0
    assert 'stderr' in var_0
    assert 'rc' in var_0
    assert 'cmd' in var_0
    assert 'start' in var_0
    assert 'end' in var_0
    assert 'delta' in var_0
    assert 'msg' in var_0

# Generated at 2022-06-25 02:04:14.562068
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:04:16.913605
# Unit test for function main
def test_main():
  var_1 = {}
  test_case_0()


# Generated at 2022-06-25 02:04:22.935233
# Unit test for function main
def test_main():
    args = ['-s']
    args.extend(['arg1', 'arg2'])
    script = 'command'
    

# Generated at 2022-06-25 02:04:24.612594
# Unit test for function check_command
def test_check_command():
    pass
    check_command()


# Generated at 2022-06-25 02:05:08.167750
# Unit test for function main
def test_main():
    # ensure that the correct type of object is returned
    assert isinstance(main(), object)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:10.037329
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:11.331401
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_0()


# Generated at 2022-06-25 02:05:15.900675
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        if (isinstance(e, AttributeError) or isinstance(e, TypeError)):
            return False
        else:
            return True

test_main()

# Generated at 2022-06-25 02:05:17.173164
# Unit test for function check_command
def test_check_command():
    assert(test_case_0)


# Generated at 2022-06-25 02:05:21.911530
# Unit test for function main
def test_main():
    class MockArgs(object):
        def __init__(self,
                     _raw_params=None,
                     _uses_shell=None,
                     argv=None,
                     chdir=None,
                     executable=None,
                     creates=None,
                     removes=None,
                     warn=None,
                     stdin=None,
                     stdin_add_newline=None,
                     strip_empty_ends=None):
            self._raw_params = _raw_params
            self._uses_shell = _uses_shell
            self.argv = argv
            self.chdir = chdir
            self.executable = executable
            self.creates = creates
            self.removes = removes
            self.warn = warn
            self.stdin = stdin
            self.stdin_add_newline = stdin_add

# Generated at 2022-06-25 02:05:23.305909
# Unit test for function check_command
def test_check_command():
    obj = AnsibleModule(
        argument_spec={},
    )
    main(AnsibleModuleArgs=obj, check_command=True)



# Generated at 2022-06-25 02:05:25.328720
# Unit test for function main
def test_main():
    #target = sys.modules[__name__]
    #f = target.main(target.module)
    #print(f)
    #assert f == 'Hello, world'
    pass


# Generated at 2022-06-25 02:05:31.169845
# Unit test for function main
def test_main():
    with mock.patch.object(builtins, 'open', mock.mock_open(read_data='b"b"')):
        with mock.patch('os.path.exists', return_value=True):
            var_0 = main()
            assert var_0 == None

# Generated at 2022-06-25 02:05:37.970725
# Unit test for function main
def test_main():
    # LOGIC: test_main

    status = 0

    # Create an instance of the AnsibleModule class
    argument_spec = dict()
    argument_spec['_raw_params'] = dict()
    argument_spec['_uses_shell'] = dict()
    argument_spec['argv'] = dict()
    argument_spec['chdir'] = dict()
    argument_spec['executable'] = dict()
    argument_spec['creates'] = dict()
    argument_spec['removes'] = dict()
    argument_spec['warn'] = dict()
    argument_spec['stdin'] = dict()
    argument_spec['stdin_add_newline'] = dict()
    argument_spec['strip_empty_ends'] = dict()
    argument_spec['supports_check_mode'] = dict()

    module = AnsibleModule

# Generated at 2022-06-25 02:07:23.708548
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)
    print("Success")


# Generated at 2022-06-25 02:07:24.465207
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:07:25.196821
# Unit test for function check_command
def test_check_command():
    pass

# Generated at 2022-06-25 02:07:32.115586
# Unit test for function check_command
def test_check_command():
    check_command(AnsibleModule, "command")
    check_command(AnsibleModule, ["command", "command"])
    check_command(AnsibleModule, ["yum"])
    check_command(AnsibleModule, ["rm"])
    check_command(AnsibleModule, ["wget"])
    check_command(AnsibleModule, ["svn"])
    check_command(AnsibleModule, ["service"])
    check_command(AnsibleModule, ["mount"])
    check_command(AnsibleModule, ["rpm"])
    check_command(AnsibleModule, ["yum"])
    check_command(AnsibleModule, ["apt-get"])
    check_command(AnsibleModule, ["tar"])

# Generated at 2022-06-25 02:07:32.844537
# Unit test for function main
def test_main():
    assert main() == 'main() return something'

# Generated at 2022-06-25 02:07:38.652284
# Unit test for function main
def test_main():
    params = dict()
    params['_raw_params'] = "echo hello"
    params['_uses_shell'] = False
    params['argv'] = None
    params['chdir'] = None
    params['executable'] = None
    params['creates'] = None
    params['removes'] = None
    params['_ansible_check_mode'] = False
    params['stdin'] = None
    params['stdin_add_newline'] = True
    params['strip_empty_ends'] = True
    test_main_0 = main(params=params)
    print(test_main_0)



if __name__ == '__main__':
    test_case_0()
    #test_main()

# Generated at 2022-06-25 02:07:40.087407
# Unit test for function main
def test_main():
    data = get_test_data()
    var_0 = main()
    assert not var_0.check_err()


# Generated at 2022-06-25 02:07:41.989153
# Unit test for function main
def test_main():
    # Test
    try:
        test_case_0()
    except Exception as err:
        AssertionError(err)

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:07:47.289708
# Unit test for function main

# Generated at 2022-06-25 02:07:49.315796
# Unit test for function main
def test_main():
    try:
        result = main()
    except Exception as e:
        assert False, e
    else:
        assert result == 0

if __name__ == '__main__':
    unittest.main()