

# Generated at 2022-06-25 02:01:54.524936
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-25 02:01:57.753726
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'Test'


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:02:05.940261
# Unit test for function check_command
def test_check_command():
    var_9 = 'echo 0'
    module = AnsibleModule(argument_spec = dict())
    check_command(module,var_9)

    #var_10 = 'touch /etc/foobar'
    #module = AnsibleModule(argument_spec = dict())
    #check_command(module,var_10)

    var_11 = 'chmod 777 /etc/foobar'
    module = AnsibleModule(argument_spec = dict())
    check_command(module,var_11)

    var_12 = 'chown root:root /etc/foobar'
    module = AnsibleModule(argument_spec = dict())
    check_command(module,var_12)

    var_13 = 'ln -s /foo/bar /etc/foobar'
    module = AnsibleModule(argument_spec = dict())


# Generated at 2022-06-25 02:02:09.517507
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = list([u'/bin/command'])

    assert check_command(module, commandline) is None


# Generated at 2022-06-25 02:02:11.277362
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:02:12.465085
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:02:13.940340
# Unit test for function main
def test_main():
    assert main() == 'success'

# Unit test to check the execution time of the function main

# Generated at 2022-06-25 02:02:22.285939
# Unit test for function main
def test_main():
    dict_0 = dict()
    dict_0['changed'] = False
    dict_0['stdout'] = ''
    dict_0['stderr'] = ''
    dict_0['rc'] = None
    dict_0['cmd'] = None
    dict_0['msg'] = ''
    dict_0['start'] = None
    dict_0['delta'] = None
    dict_0['_raw_params'] = ''
    dict_0['argv'] = None
    dict_0['chdir'] = None
    dict_0['_uses_shell'] = False
    dict_0['creates'] = None
    dict_0['removes'] = None
    dict_0['warn'] = False
    dict_0['stdin'] = None
    dict_0['stdin_add_newline'] = True


# Generated at 2022-06-25 02:02:24.460073
# Unit test for function check_command
def test_check_command():
    try:
        test_case_0()
    except:
        print("Test case failed")
    else:
        print(" ---> Success <--- ")

main()

# Generated at 2022-06-25 02:02:25.703119
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False

if __name__ == '__main__':
    # Run main function
    main()

# Generated at 2022-06-25 02:02:42.441195
# Unit test for function main
def test_main():
    var_0 = {'_ansible_item_result': False, '_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_verbosity': 2, '_ansible_ignore_errors': False, '_ansible_diff': False}
    var_1 = {'insertbefore': '# END ansible-managed', 'regexp': '^# END ansible-managed', 'line': '# END ansible-managed', 'state': 'present', 'path': '/tmp/file'}
    var_0['_raw_params'] = "echo '# END ansible-managed' >> /tmp/file"
    var_0['_uses_shell'] = False
    var_0['executable'] = None
    var_0['creates'] = None

# Generated at 2022-06-25 02:02:46.564699
# Unit test for function check_command
def test_check_command():
    AnsibleModule.warn = lambda *args, **kwargs: None
    try:
        check_command(AnsibleModule, 'ls -la /opt/')
    except SystemExit:
        raise SystemExit(1)
    except Exception as e:
        raise AssertionError('Unexpected Exception raised: {}'.format(str(e)))
    try:
        check_command(AnsibleModule, ['ls', '-la', '/opt/'])
    except SystemExit:
        raise SystemExit(1)
    except Exception as e:
        raise AssertionError('Unexpected Exception raised: {}'.format(str(e)))


# Generated at 2022-06-25 02:02:47.994379
# Unit test for function check_command
def test_check_command():
    # Setup stack
    var_1 = AnsibleModule()
    var_2 = [u'/bin/echo', 'hello']

    # Call function
    check_command(var_1, var_2)


# Generated at 2022-06-25 02:02:50.442126
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-25 02:02:57.904633
# Unit test for function main
def test_main():
    #Call:
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    ansi_out = subprocess.Popen(['ansible-playbook', '-i', './hosts', './test_command.yml', '--connection=local'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout,stderr = ansi_out.communicate()
    rc = ansi_out.returncode
    assert rc == 0

setattr(main, '__doc__', to_native(main.__doc__, encoding='utf-8'))
setattr(check_command, '__doc__', to_native(check_command.__doc__, encoding='utf-8'))

# Generated at 2022-06-25 02:02:59.978112
# Unit test for function main
def test_main():
    print('test_main')
    var_0 = main()


# Generated at 2022-06-25 02:03:10.415973
# Unit test for function main
def test_main():
    # Mock object for module
    class module:
        def __init__(self):
            self.argument_spec = dict()
            self.check_mode = False
            self.params = dict()
            self.result = dict()

    module_0 = module()
    # Mock object for class AnsibleModule
    class AnsibleModule:
        def __init__(self, spec, supports_check_mode=False):
            pass
    # Mock object for check_command
    def check_command(module_param_0, commandline):
        # Mock object for module.warn
        def warn(msg):
            pass
        module_param_0.warn = warn
    # Mock object for module.run_command

# Generated at 2022-06-25 02:03:13.965365
# Unit test for function main
def test_main():
    assert var_0 == None

if __name__ == "__main__":
    test_main()
    var_0 = main()

# Generated at 2022-06-25 02:03:14.769519
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-25 02:03:17.196500
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:03:38.806106
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:03:40.441631
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = "/bin/ls"

    # Call the function
    check_command(module, commandline)


# Generated at 2022-06-25 02:03:43.867316
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-25 02:03:46.442795
# Unit test for function main
def test_main():
    try:
        assert type(test_case_0()) == int
    except:
        raise Exception("Unit test for function main failed.")

# Main Program
if __name__ == "__main__":
    # Call the test_main function
    test_main()

# Generated at 2022-06-25 02:03:47.899718
# Unit test for function main
def test_main():
    print("Testing function main")

if __name__ == '__main__':

    test_main()

# Generated at 2022-06-25 02:03:54.441031
# Unit test for function check_command

# Generated at 2022-06-25 02:04:04.673755
# Unit test for function main
def test_main():
    var_attr_0 = main()
    assert var_attr_0.strip_empty_ends is True
    var_attr_1 = main()
    assert var_attr_1.stdin_add_newline is True
    var_attr_2 = main()
    assert var_attr_2.warn is False
    var_attr_3 = main()
    assert var_attr_3.creates == 'path'
    var_attr_4 = main()
    assert var_attr_4.removes == 'path'
    var_attr_5 = main()
    assert var_attr_5.executable == 'None'
    var_attr_6 = main()
    assert var_attr_6.chdir == 'path'
    var_attr_7 = main()

# Generated at 2022-06-25 02:04:08.840683
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception:
        import traceback
        error = traceback.format_exc()
        print(error)
        assert False

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:04:12.422615
# Unit test for function main
def test_main():
    if var_0.get('rc') != 0:
        var_1 = var_0['msg']
    else:
        var_1 = var_0['stdout']
    assert var_1 == 'hello'

# Test case for function main

# Generated at 2022-06-25 02:04:15.243158
# Unit test for function check_command
def test_check_command():
    try:
        test_case_0()
    except Exception as e:
        print('Exception from test_check_command: ' + str(e) + '\n')
    return

# Test Case Definition

# Case 1
# Test Case Description
# This is a sample test case description


# Generated at 2022-06-25 02:04:57.734538
# Unit test for function main
def test_main():
    args = {
        "_raw_params": "",
        "_uses_shell": False,
        "argv": [],
        "chdir": "/Users/kiui/code/ansible",
        "creates": "",
        "executable": "",
        "removes": "",
        "strip_empty_ends": True,
        "stdin": "",
        "stdin_add_newline": True,
        "warn": False
    }
    module = AnsibleModule(argument_spec=args, supports_check_mode=True)
    main()

# Generated at 2022-06-25 02:05:00.427303
# Unit test for function check_command
def test_check_command():
    try:
        command = 'test_value'
        check_command(command)
    except:
        print("Exception when calling function check_command!")
        raise


# Generated at 2022-06-25 02:05:01.502300
# Unit test for function main
def test_main():

    if __name__ == '__main__':
        test_main()

# Generated at 2022-06-25 02:05:05.917526
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str'),
        ),
        supports_check_mode=True
    )

    if module.params['command'] is None:
        raise Exception('command must be specified')

    check_command(module, module.params['command'])


# Generated at 2022-06-25 02:05:07.210910
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        pass

# Template for function main
main()

# Generated at 2022-06-25 02:05:13.533649
# Unit test for function check_command
def test_check_command():
    with mock.patch('os.path.basename') as mock_path_basename:
        with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
            var_1 = mock.Mock()
            var_1.warn = mock.Mock()
            var_2 = 'ls'
            mock_AnsibleModule.return_value = var_1
            mock_path_basename.return_value = var_2

            # Call method
            check_command(var_1, var_2)

            # Asserts
            mock_path_basename.assert_called_once_with('ls')

# Generated at 2022-06-25 02:05:15.057301
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Execution test failed")
        raise

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:16.729593
# Unit test for function main
def test_main():
    test_case_0()
    
    
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:20.438846
# Unit test for function main
def test_main():
    var_1 = main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:05:30.792125
# Unit test for function main
def test_main():
    # Mock args and kwargs
    mock_module = [
        {
            '_raw_params': [
                'ls'
            ],
            '_uses_shell': [
                False
            ],
            'argv': [
                [
                    'ls'
                ]
            ],
            'chdir': [
                'None'
            ],
            'executable': [
                'None'
            ],
            'creates': [
                'None'
            ],
            'removes': [
                'None'
            ],
            'warn': [
                False
            ],
            'stdin': [
                'None'
            ],
            'stdin_add_newline': [
                True
            ],
            'strip_empty_ends': [
                True
            ]
        }
    ]



# Generated at 2022-06-25 02:08:19.762139
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print >>sys.stderr, "Ran %s, but it did not exit gracefully as expected. It returned %d" % (inc_path, inst.args[0])
            sys.exit(1)

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:08:20.498985
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:08:26.356065
# Unit test for function main
def test_main():
    # Command: cat file1 file2 | sed -e 's/foo/bar/g' | grep baz
    args = [
        'cat',
        '/tmp/file1',
        '/tmp/file2',
        '|',
        'sed',
        '-e',
        's/foo/bar/g',
        '|',
        'grep',
        'baz'
    ]

    # Args: finds the msg key
    assert 'msg' not in main()

    # Args: finds the first value to 'cmd' key
    assert 'cat' == var_0['cmd'][0]

    # Args: finds the last value to 'cmd' key
    assert 'baz' == var_0['cmd'][8]


# Generated at 2022-06-25 02:08:27.311164
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:08:31.165052
# Unit test for function main
def test_main():
    with open('test/test_command.log', 'w+') as f:
        for name, f_test in inspect.getmembers(sys.modules[__name__], inspect.isfunction):
            if name.startswith('test_'):
                print >>f, 'Running test: %s()' % name
                f_test()
                print >>f, '\n'

if __name__ == '__main__':
    if len(sys.argv) > 1:
        test_main()
    else:
        main()

# Generated at 2022-06-25 02:08:33.548714
# Unit test for function main
def test_main():
    # mock_module = MagicMock()
    # mock_ansible.run_command.return_value = (0, '', '')
    var_0 = main()
    assert var_0 is None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 02:08:38.862084
# Unit test for function main
def test_main():
  # Note: The following test case is under development.
  test_main_args = dict()
  try:
    test_main_return = main(**test_main_args)
  except IOError as e:
    print('IOError: %s' % e)
  else:
    print('test_main_return = %s\n' % (test_main_return))

# Runs the unit tests for the module.