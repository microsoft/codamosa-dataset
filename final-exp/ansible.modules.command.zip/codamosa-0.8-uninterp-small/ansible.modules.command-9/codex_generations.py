

# Generated at 2022-06-25 02:01:54.807540
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:02:00.296372
# Unit test for function main

# Generated at 2022-06-25 02:02:01.804104
# Unit test for function main
def test_main():
    print("Executing function main...")
    test_case_0()

# Main function

# Generated at 2022-06-25 02:02:12.079390
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(_raw_params=dict(), _uses_shell=dict(type='bool', default=False), argv=dict(type='list', elements='str'), chdir=dict(type='path'), executable=dict(), creates=dict(type='path'), removes=dict(type='path'), warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'), stdin=dict(required=False), stdin_add_newline=dict(type='bool', default=True), strip_empty_ends=dict(type='bool', default=True),))

    # this is some magic to replace the module with our stub
    import sys
    import os

    # testing

# Generated at 2022-06-25 02:02:19.175700
# Unit test for function main
def test_main():
    var_0 = AnsibleModule()
    var_1 = {'_raw_params': '', '_uses_shell': False, 'argv': '', 'chdir': '', 'executable': '', 'creates': '', 'removes': '', 'warn': False, 'stdin': '', 'stdin_add_newline': True, 'strip_empty_ends': True}
    var_2 = 'no command given'
    var_3 = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': var_2}
    var_4 = var_3['rc']
    var_5 = 'msg'
    var_6 = var_3['msg']
    var_

# Generated at 2022-06-25 02:02:31.557291
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/usr/bin/make_database.sh db_user db_name',
        _uses_shell=True,
        argv=['/usr/bin/make_database.sh', 'db_user', 'db_name'],
        chdir='somedir/',
        executable=None,
        creates='/path/to/database',
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        check=False,
        diff=False,
    )

# Generated at 2022-06-25 02:02:39.437855
# Unit test for function main

# Generated at 2022-06-25 02:02:41.271392
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:02:52.421795
# Unit test for function check_command
def test_check_command():
    print("Start test_check_command")
    var_args = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}
    var_cmd = 'echo'
    var_module = AnsibleModule()
    var_cmdline = "/usr/bin/{} hello".format(var_cmd) 
    var_result = check_command(var_module, var_cmdline) 
    # Test case 0
    assert var_result == None, 'Unit Test Error: test_check_command\n'


# Generated at 2022-06-25 02:02:53.017939
# Unit test for function check_command
def test_check_command():
    main()

# Generated at 2022-06-25 02:03:16.558884
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Failed to run unit test for command')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:03:20.233403
# Unit test for function main
def test_main():

    class MyModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.args = args
            self.kwargs = kwargs

    mock_module = MyModule()

    command = 'ls /usr/bin/ansible'
    test_case_0(mock_module, command)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:03:23.086915
# Unit test for function check_command
def test_check_command():
    # Test arguments and expected return values
    # Test.assert_equals(ansible_command_module.check_command(), None)
    pass


# Generated at 2022-06-25 02:03:24.372084
# Unit test for function main
def test_main():
    var_0 = main()
    assert not var_0, var_0

# Generated at 2022-06-25 02:03:25.643341
# Unit test for function main
def test_main():
    assert True

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:03:33.750331
# Unit test for function main
def test_main():
    cmd = ['/bin/true']
    args = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group', 'ln': 'state=link', 'mkdir': 'state=directory', 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch' }

# Generated at 2022-06-25 02:03:36.201351
# Unit test for function check_command
def test_check_command():
    if not test_case_0():
        test_case_0()


# Generated at 2022-06-25 02:03:37.415808
# Unit test for function main
def test_main():
    res, out, err = assert_raises(SystemExit, main, [])

# Generated at 2022-06-25 02:03:44.840178
# Unit test for function main
def test_main():
    mock_params = {'_raw_params': 'args',
                   '_uses_shell': 'shell',
                   'argv': 'argv',
                   'chdir': 'chdir',
                   'executable': 'executable',
                   'creates': 'creates',
                   'removes': 'removes',
                   'warn': 'warn',
                   'stdin': 'stdin',
                   'stdin_add_newline': 'stdin_add_newline',
                   'strip_empty_ends': 'strip_empty_ends'}
    mock_args = {'check_mode': 'check_mode'}

# Generated at 2022-06-25 02:03:45.628994
# Unit test for function main
def test_main():
    # Checking expected results from unit test
    pass


# Generated at 2022-06-25 02:04:12.541958
# Unit test for function check_command

# Generated at 2022-06-25 02:04:15.722536
# Unit test for function main
def test_main():

    var_0 = main()
    assert var_0


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:04:20.345331
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict()
    )
    commandline = 'command_out_stderr'
    # check the new method
    if isinstance(commandline, list):
        command = commandline[0]
    else:
        command = commandline.split()[0]
    command = os.path.basename(command)

    # Testing for exceptions raised
    # Check for module.fail_json exception
    try:
        check_command(module, commandline)
    except Exception as e:
        print('exception thrown')
        print(e)
    finally:
        module.exit_json(changed=False, msg="Test done")


# Generated at 2022-06-25 02:04:21.973259
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:04:24.713503
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:04:25.960106
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:04:26.548920
# Unit test for function check_command
def test_check_command():
    var_0 = main()


# Generated at 2022-06-25 02:04:29.837859
# Unit test for function check_command
def test_check_command():
    # Test argument types and counts
    try:
        test_case_0()
    except TypeError as e:
        print("Error in check_command()")
        print("\tTypeError:", e)
    except AssertionError as ae:
        print("Error in check_command()")
        print("\tAssertionError:", ae)


# Generated at 2022-06-25 02:04:31.483948
# Unit test for function check_command
def test_check_command():
    try:
        assert check_command({}, {'cmd': 'ls -l'}) == None
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 02:04:32.471211
# Unit test for function check_command
def test_check_command():
    test_case_0()

# Main function for unit test

# Generated at 2022-06-25 02:04:50.631456
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule()
    commandline = "program"

    # Call function
    check_command(module, commandline)

    module.exit_json()


# Generated at 2022-06-25 02:04:53.756662
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:04:55.837802
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict()
    )
    commandline = 'my command'
    var_0 = check_command(module, commandline)
    print(var_0)


# Generated at 2022-06-25 02:04:59.936739
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=[], supports_check_mode=False)
    commandline = ''
    check_command(module, commandline)


# Generated at 2022-06-25 02:05:08.168350
# Unit test for function main
def test_main():
    var_1 = 'cat /etc/motd' # Command to run
    var_2 = '/etc/motd' # File to check for after running the command
    var_3 = '/etc/motd' # File to check for before running the command
    var_4 = '/etc/motd' # File to check for before running the command
    var_5 = 'False' #warn
    var_6 = 'False' #warn
    var_7 = 'False' #warn
    var_8 = 'False' #warn
    var_9 = 'False' #warn
    var_10 = 'False' #warn
    var_11 = 'False' #warn
    var_12 = 'False' #warn
    var_13 = 'False' #warn
    var_14 = 'False' #warn
    var_15 = 'False'

# Generated at 2022-06-25 02:05:14.281063
# Unit test for function check_command

# Generated at 2022-06-25 02:05:20.439844
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(
        cmd=dict(type='str'),
        creates=dict(type='str'),
        removes=dict(type='str')
    ))
    check_command(module, dict({"cmd": "/usr/bin/make_database.sh db_user db_name", "creates": "/path/to/database"}))



# Generated at 2022-06-25 02:05:30.754125
# Unit test for function main

# Generated at 2022-06-25 02:05:33.796059
# Unit test for function check_command
def test_check_command():
    check_command(var_0, var_1)

if __name__ == "__main__":
    test_case_0()
    test_check_command()

# Generated at 2022-06-25 02:05:43.627382
# Unit test for function main
def test_main():
    mock_options = {}
    main(mock_options)
    mock_options['_raw_params'] = ''
    main(mock_options)
    mock_options['_raw_params'] = ''
    mock_options['argv'] = ''
    main(mock_options)
    mock_options['_raw_params'] = ''
    mock_options['argv'] = ''
    mock_options['chdir'] = ''
    main(mock_options)
    mock_options['_raw_params'] = ''
    mock_options['argv'] = ''
    mock_options['chdir'] = ''
    mock_options['executable'] = ''
    main(mock_options)
    mock_options['_raw_params'] = ''
    mock_options['argv'] = ''

# Generated at 2022-06-25 02:06:26.275738
# Unit test for function check_command
def test_check_command():
    # test 1
    var_1 = main()
    

# Generated at 2022-06-25 02:06:26.764321
# Unit test for function main
def test_main():
    var = main()

# Generated at 2022-06-25 02:06:28.186887
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Fail")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:06:37.660139
# Unit test for function main
def test_main():
    with mock.patch('ansible.module_utils.basic.AnsibleModule',
                    autospec=True) as mock_module:
        mock_module.return_value.params = {
            '_raw_params': '',
            '_uses_shell': False,
            'chdir': '',
            'creates': '',
            'executable': '',
            'removes': '',
            'stdin_add_newline': True,
            'warn': False,
        }
        mock_module.return_value.check_mode = False
        mock_module.return_value.run_command.return_value = (0, '', '')
        mock_module.return_value.exit_json.return_value = None

# Generated at 2022-06-25 02:06:42.014625
# Unit test for function main
def test_main():
    print("Testing function main")

    #var_1 = main()

if __name__ == '__main__':
    import sys
    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch
    main()

    #main_no_return()


#test_main()

# Generated at 2022-06-25 02:06:44.277990
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('Error while calling function main.')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:06:50.392327
# Unit test for function check_command
def test_check_command():
    import json

# Generated at 2022-06-25 02:06:53.464352
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            pass
        else:
            print('test_main >>> Failed to exit cleanly')
            raise


# Generated at 2022-06-25 02:06:55.778506
# Unit test for function main
def test_main():
    # Testing no_log
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:07:02.499478
# Unit test for function main

# Generated at 2022-06-25 02:08:35.801150
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        # The only exit code allowed in unit tests is 0
        assert e.code == 0


# Generated at 2022-06-25 02:08:37.909141
# Unit test for function main
def test_main():
    # Setup
    var_0 = None

    # Test
    test_case_0()

    # Teardown
    pass

# Generated at 2022-06-25 02:08:41.383124
# Unit test for function main
def test_main():
    var_0 = main()
    # Assertion
    #print(var_0)

if __name__ == "__main__":
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:08:46.238073
# Unit test for function check_command
def test_check_command():
    var_0 = main()
    commandline = ["test_0","test_1","test_2"]
    check_command(var_0,commandline)
    commandline = ["test_0","test_1","test_2"]
    check_command(var_0,commandline)
    commandline = ["test_0","test_1","test_2"]
    check_command(var_0,commandline)
    commandline = ["test_0","test_1","test_2"]
    check_command(var_0,commandline)


# Generated at 2022-06-25 02:08:53.531287
# Unit test for function main
def test_main():
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    shutil.rmtree('demo/', ignore_errors=True)
    shutil.copytree('demo_main/', 'demo/')
    shutil.copy('demo_main/value_file.yaml', 'demo/')
    shutil.copy('demo_main/dict_file.yaml', 'demo/')

    with open('demo/ansible_test.yml') as f:
        content = f.read()
        assert 'ansible.builtin.command' in content
    os.chdir('demo/')
    var_0 = os.system('ansible-playbook -i hosts.yml ansible_test.yml')
    assert var_0 == 0

# Generated at 2022-06-25 02:08:54.733391
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    print("Running unit test for function main...")
    test_main()

# Generated at 2022-06-25 02:08:56.839398
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('test_case_0() failed.')

# Global unit test
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:08:59.448391
# Unit test for function main
def test_main():
    main(argv=[], exit=False)

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:09:00.590916
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:09:02.429990
# Unit test for function check_command
def test_check_command():
    # Create a module object
    module = AnsibleModule(argument_spec={})
    # Call the method with a command line to check
    check_command(module, "/bin/sysctl")
