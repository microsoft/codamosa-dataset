

# Generated at 2022-06-25 02:01:54.857827
# Unit test for function main
def test_main():
    var_0 = main()
    # print(var_0.rc)
    # print(var_0.cmd)
    # print(var_0.stdout)
    # print(var_0.stderr)
    # print(var_0.stdout_lines)
    # print(var_0.stderr_lines)
    # print(var_0.delta)
    # print(var_0.start)
    # print(var_0.end)
    # print(var_0.changed)
    # print(var_0.msg)
    # print(var_0.warnings)


if __name__ == '__main__':
    test_case_0()
    # test_main()

# Generated at 2022-06-25 02:01:57.751366
# Unit test for function main
def test_main():
    test_case_0()
    
    
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:02:03.008423
# Unit test for function check_command
def test_check_command():
    global module
    var_1 = AnsibleModule(argument_spec=dict())
    check_command(var_1, "touch foo")
    if var_1.check_mode:
        var_1.exit_json(changed=True)
    if not os.path.exists("foo"):
        file("foo", "w").write("")
    var_1.exit_json(changed=False)
    try:
        os.unlink("foo")
    except:
        pass


# Generated at 2022-06-25 02:02:04.379835
# Unit test for function check_command
def test_check_command():
    print("Unit test for function check_command")
    test_case_0()


# Generated at 2022-06-25 02:02:05.107430
# Unit test for function main
def test_main():
    test_case_0()

main()

# Generated at 2022-06-25 02:02:06.849434
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:02:16.170439
# Unit test for function main
def test_main():
    args = ['command', '_raw_params', '_uses_shell', 'argv', 'chdir', 
            'executable', 'creates', 'removes', 'warn', 'stdin', 
            'stdin_add_newline', 'strip_empty_ends']
    vars = [None, None, False, None, None, None, None, None, False, None, 
            True, True]
    return main(args, vars)

if __name__ == '__main__':
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    #test_case_0()
    test_main()

# Generated at 2022-06-25 02:02:22.041379
# Unit test for function check_command
def test_check_command():
    var_0 = 'cmd'
    var_1 = 'rm /etc/hosts'
    try:
        check_command(var_0, var_1)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 02:02:32.067302
# Unit test for function main

# Generated at 2022-06-25 02:02:34.561999
# Unit test for function check_command
def test_check_command():
    assert main()

# Import test modules from module_utils
from ansible_collections.ansible.community.tests.unit.compat.mock import patch

test_mock = patch('ansible_collections.ansible.community.plugins.modules.command.AnsibleModule')
import unittest


# Generated at 2022-06-25 02:02:46.165563
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-25 02:02:47.687144
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:02:48.278059
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:02:51.654350
# Unit test for function check_command
def test_check_command():
    print("Running unit test for function check_command")
    var_0 = AnsibleModule("ansible.builtin.command", "echo hello")
    test_case_0()

# Generated at 2022-06-25 02:02:52.495253
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:02:55.091394
# Unit test for function main
def test_main():
    test_case_0()

# Execute this file when executed
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:03:02.796720
# Unit test for function check_command
def test_check_command():
    print("tests for command check_command")

    var_0 = check_command()
    var_1 = check_command()
    var_2 = check_command()
    var_3 = check_command()
    var_4 = check_command()

    # TODO: Test statements
    assert var_0 not in [None, 0]
    assert var_1 not in [None, 0]
    assert var_2 not in [None, 0]
    assert var_3 not in [None, 0]
    assert var_4 not in [None, 0]


# Generated at 2022-06-25 02:03:13.352600
# Unit test for function main
def test_main():
    var_0 = "argv"
    var_1 = "creates"
    var_2 = "removes"
    var_3 = "executable"
    var_4 = "stdin"
    var_5 = "stdin_add_newline"
    var_6 = "strip_empty_ends"
    var_7 = "chdir"
    var_8 = "warn"
    var_9 = "shell"
    var_10 = "args"
    var_11 = "Hello World!"
    # args = {
    #     '_raw_params': None,
    #     '_uses_shell': False,
    #     'argv': [
    #         'echo',
    #         var_11
    #     ],
    #     'chdir': None,
    #     'creates

# Generated at 2022-06-25 02:03:23.436298
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(argument_spec=dict(_raw_params=dict(),_uses_shell=dict(type='bool',default=False),argv=dict(type='list',elements='str'),chdir=dict(type='path'),executable=dict(),creates=dict(type='path'),removes=dict(type='path'),warn=dict(type='bool',default=False,removed_in_version='2.14',removed_from_collection='ansible.builtin'),stdin=dict(required=False),stdin_add_newline=dict(type='bool',default=True),strip_empty_ends=dict(type='bool',default=True),),supports_check_mode=True,)

# Generated at 2022-06-25 02:03:24.038405
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:03:33.109460
# Unit test for function check_command
def test_check_command():
    command = '/usr/bin/make_database.sh db_user db_name'
    check_command(command)


# Generated at 2022-06-25 02:03:42.296224
# Unit test for function main
def test_main():
    var_1 = dict(argv=[],chdir='',creates='')
    var_1['_raw_params'] = 'fasdasf'
    var_1['_uses_shell'] = 'True'
    var_1['executable'] = 'test_resource'
    var_1['removes'] = 'test_resource'
    var_1['stdin'] = 'test_resource'
    var_1['stdin_add_newline'] = 'True'
    var_1['strip_empty_ends'] = 'True'
    var_1['warn'] = 'True'
    main(var_1)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:03:43.618397
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 02:03:48.495997
# Unit test for function main
def test_main():
    args = {
        "_raw_params": 0,
        "_uses_shell": 0,
        "argv": "ansible.builtin.str",
        "chdir": "ansible.builtin.str",
        "creates": "ansible.builtin.str",
        "executable": "ansible.builtin.str",
        "removes": "ansible.builtin.str",
        "stdin": "ansible.builtin.str",
        "stdin_add_newline": "ansible.builtin.bool",
        "strip_empty_ends": "ansible.builtin.bool",
        "warn": "ansible.builtin.bool"
    }
    main()
    main(ansible_args=args)
    main(ansible_check_mode=True)

# Generated at 2022-06-25 02:03:49.533247
# Unit test for function main
def test_main():
    pass

# Utility to generate accurate test case and template

# Generated at 2022-06-25 02:03:53.131494
# Unit test for function main
def test_main():
    try:
        # We should call main() when we invoke the function directly.
        test_case_0()
        print("\n***********************\n")
    except Exception as exception:
        print("\n***********************\n")

# Call main()
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:04:03.655566
# Unit test for function main

# Generated at 2022-06-25 02:04:04.423704
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:04:12.964312
# Unit test for function main
def test_main():
    var_2 = None
    var_3 = str(";")
    var_4 = "ITslem&0V8Yv[Ldj7VN"
    var_5 = "Ic%^=ZCxMi3q/F$]8?v"
    var_6 = str("l")
    var_7 = "r$Gz^5O5o4%N[hN8*-L"
    var_8 = ";dkJW/Q"
    var_9 = "Tlh6m#1ID|#:3X+-Ld"
    var_10 = str("1")
    var_11 = "aGk8IpGlLOJ7R"
    var_12 = str("e")
    var_13 = "v+-Ld;dkJW/Q"

# Generated at 2022-06-25 02:04:18.379554
# Unit test for function main
def test_main():
    # See Docstring for main
    try:
        test_case_0()
        test_case_10()
        test_case_20()
        test_case_30()
        test_case_40()
    except Exception as ex:
        print("Exception in main program")
        raise(ex)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:04:39.838641
# Unit test for function main
def test_main():
    temp_var_0 = main()
    expected_output_0 = "Command would have run if not in check mode"
    assert temp_var_0['msg'] == expected_output_0


# Generated at 2022-06-25 02:04:41.595473
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:04:48.381981
# Unit test for function main
def test_main():
    # Test 0
    main_args = {'creates': '/tmp/foo', 'removes': '/tmp/foo'}
    main_result = {}
    main_result['changed'] = True
    main_result['rc'] = 0
    main_result['msg'] = 'non-zero return code'
    main_result['stdout'] = ''
    main_result['stderr'] = ''
    main_result['cmd'] = None
    main_result['start'] = None
    main_result['end'] = None
    main_result['delta'] = None
    assert var_0 == main_result
# Reference Output:
# {
#     "changed": true,
#     "rc": 0,
#     "msg": "non-zero return code",
#     "stdout": "",
#     "stder

# Generated at 2022-06-25 02:04:49.661846
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 02:04:55.853193
# Unit test for function main

# Generated at 2022-06-25 02:04:58.349402
# Unit test for function main
def test_main():
    pass

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:05:01.465682
# Unit test for function check_command
def test_check_command():
    print('Testing function check_command')
    try:
        test_case_0()
    except:
        print('Testing function check_command failed')
    else:
        print('Testing function check_command passed')


# Generated at 2022-06-25 02:05:05.554427
# Unit test for function main
def test_main():
    test_cases = [
                  0
                ]

    for case in test_cases:
        test_case = {
            'case': case
        }
        test_case_0()
        return True

    return False

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:06.881051
# Unit test for function main
def test_main():
	test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:05:08.202442
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:05:52.079839
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str', required=True),
        )
    )
    commandline = 'this is a fake command'
    result = check_command(module, commandline)
    assert result is not None



# Generated at 2022-06-25 02:05:57.288495
# Unit test for function check_command
def test_check_command():

    var_0 = {}
    var_0 = {}
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False
    var_0['ansible.builtin.command'] = False

# Generated at 2022-06-25 02:06:00.634344
# Unit test for function main
def test_main():
	print("Testing function main")
	try:
		test_case_0()
		print("Method test_case_0 PASSED")
	except:
		print("Method test_case_0 FAILED")

if __name__ == '__main__':
	test_main()

# Generated at 2022-06-25 02:06:02.778424
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(argument_spec={})
    test_commandline = 'test'
    check_command(test_module, test_commandline)


# Generated at 2022-06-25 02:06:10.578602
# Unit test for function main
def test_main():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 02:06:16.331290
# Unit test for function main
def test_main():
    dict_0 = {'register': 'mymotd'}
    dict_1 = {'register': 'mymotd'}
    dict_2 = {'register': 'mymotd'}
    dict_3 = {'register': 'mymotd'}
    dict_4 = {'register': 'mymotd'}
    dict_5 = {'register': 'mymotd'}
    dict_6 = {'register': 'mymotd'}
    dict_7 = {'register': 'mymotd'}
    dict_8 = {'register': 'mymotd'}
    dict_9 = {'register': 'mymotd'}
    dict_10 = {'register': 'mymotd'}
    dict_11 = {'register': 'mymotd'}

# Generated at 2022-06-25 02:06:17.692634
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-25 02:06:25.899112
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 is None


# Generated at 2022-06-25 02:06:27.933343
# Unit test for function main
def test_main():
    assert 1 == 1


# Generated at 2022-06-25 02:06:30.960124
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Test the function.
test_case_0()

# Module to execute.
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:08:17.884526
# Unit test for function main
def test_main():
    my_dict = {"chdir": "chdir", "creates": "creates", "removes": "removes", "stdin": "stdin", "stdin_add_newline": "stdin_add_newline", "strip_empty_ends": "strip_empty_ends"}

# Generated at 2022-06-25 02:08:21.001081
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as inst:
        if inst.args[0] is True:
            pass
        else:
            print('FAIL: Expected True, got %s' % (inst.args[0],))
            raise

    print('PASS')

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:08:23.161675
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except AssertionError as e:
        raise(AssertionError(str(e) + "\n" + "Failed on function: " + inspect.stack()[0][3]))



# Generated at 2022-06-25 02:08:23.914628
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:08:28.718252
# Unit test for function main
def test_main():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_0 = 'test'
    var_1 = 'test'
    var_2 = 'test'
    var_3 = 'test'
    var_4 = 'test'
    var_5 = 'test'
    var_6 = 'test'
    var_7 = 'test'
    var_8 = 'test'
    var_9 = 'test'
    var_10 = 'test'
    var_11 = 'test'

# Generated at 2022-06-25 02:08:29.472619
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:08:35.396491
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    root_dir = os.path.dirname(os.path.abspath(__file__))
    ansible_dir = os.path.join(root_dir, "ansible")
    if os.path.exists(ansible_dir):
        os.environ["ANSIBLE_LIBRARY"] = os.path.join(root_dir, "ansible/modules")
    library_dir = os.path.join(root_dir, "library")
    if os.path.exists(library_dir):
        os.environ["ANSIBLE_LIBRARY"] = os.path.join(root_dir, "library")
    main()

#

# Generated at 2022-06-25 02:08:36.362450
# Unit test for function check_command
def test_check_command():
    assert 1==1, "check_command is not implemented"



# Generated at 2022-06-25 02:08:45.107003
# Unit test for function main
def test_main():
    class MockModule(object):

        def __init__(self, params, fail=False):
            self.params = params
            self.fail = fail

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            if self.fail:
                raise Exception('failed')

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def run_command(self, *args, **kwargs):
            return self.params['rc'], self.params['stdout'], self.params['stderr']


    params = dict(
        cmd='echo hello world',
    )

    module = MockModule(params)
    main()
    assert module.exit_args['changed'] is True

# Generated at 2022-06-25 02:08:52.444503
# Unit test for function main
def test_main():
    path = "/home/miguel/papi"
    var_items = {'_raw_params': 'sudo apt-get install --assume-yes ansible-lint', '_uses_shell': False, 'chdir': '', 'executable': None, 'argv': '', 'creates': '', 'removes': ''}
    var_items['chdir'] = path
    var_items['_raw_params'] = 'ansible-lint .'
    var_items['argv'] = 'ansible-lint .'
    var_items['_uses_shell'] = True
    var_items['_raw_params'] = 'sudo apt-get install --assume-yes ansible-lint'
    var_items['creates'] = path + "/ansible.cfg"