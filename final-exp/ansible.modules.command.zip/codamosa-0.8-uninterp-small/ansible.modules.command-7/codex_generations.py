

# Generated at 2022-06-25 02:01:59.114058
# Unit test for function main
def test_main():
    args0 = {}
    var0 = main(**args0)
    assert var0 == 'main(): void'

test_case_0()
test_main()