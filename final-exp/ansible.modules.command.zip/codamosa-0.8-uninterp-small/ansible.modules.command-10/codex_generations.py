

# Generated at 2022-06-25 02:02:01.264920
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.warn = lambda x: print(x)

    commandline = 'cat /etc/motd'
    module = TestModule()

    check_command(module, commandline)
    check_command(module, commandline.split())



# Generated at 2022-06-25 02:02:03.533799
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        pass
    except Exception as e:
        traceback.print_exc()
        print(e)
        assert False


# Generated at 2022-06-25 02:02:04.336342
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:02:12.409772
# Unit test for function check_command
def test_check_command():
    var_1 = AnsibleModule(argument_spec=dict())
    var_2 = 'cat /etc/motd'
    var_1.params = {
        'free_form': var_2,
    }
    var_1.check_mode = True
    var_1.no_log = True
    check_command(module=var_1, commandline=var_2)


# Generated at 2022-06-25 02:02:17.889893
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print("Error! Test case failed.")
        print(e)
        assert False

# Program entry point
if __name__ == "__main__":
    # call function main
    test_main()

# unit test end

# Generated at 2022-06-25 02:02:22.670770
# Unit test for function main
def test_main():
    assert 0 == main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:02:24.820720
# Unit test for function main
def test_main():
    output = StringIO()
    sys.stdout = output

    main()
    sys.stdout = sys.__stdout__

    assert True

# Generated at 2022-06-25 02:02:34.029191
# Unit test for function main
def test_main():
    with mock.patch('ansible.modules.commands.command.AnsibleModule') as mock_module:
        mock_module.return_value = 'mock_module'
        with mock.patch('ansible.modules.commands.command.check_command') as mock_check_command:
            mock_check_command.return_value = 'mock_check_command'
            with mock.patch('ansible.modules.commands.command.shlex.split') as mock_shlex_split:
                mock_shlex_split.return_value = 'mock_shlex_split'
                with mock.patch('ansible.modules.commands.command.os') as mock_os:
                    mock_os.path.exists.return_value = 'mock_os.path'

# Generated at 2022-06-25 02:02:34.843558
# Unit test for function main
def test_main():
    assert main() == None # Returned by module.exit_json()


# Generated at 2022-06-25 02:02:40.461988
# Unit test for function main
def test_main():
    cmd = ['echo', 'hello'];
    shell = 0;
    chdir = '';
    executable = None;
    args = None;
    argv = None;
    creates = None;
    removes = None;


# Generated at 2022-06-25 02:03:02.246146
# Unit test for function main

# Generated at 2022-06-25 02:03:09.692444
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import unittest

    class ansible_builtin_command_case_insensitive_test(unittest.TestCase):
        def setUp(self):
            self.held, sys.stdout = sys.stdout, StringIO.StringIO()

        def test_case_0(self):
            test_case_0()
            result = sys.stdout.getvalue()
            sys.stdout.close()
            self.assertEqual(result, "")

        def tearDown(self):
            sys.stdout = self.held


    unittest.main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:03:20.427458
# Unit test for function main
def test_main():
    print("Unit test for function main")

    def func1(argv):
        argv[0] = argv[0] + argv[1]

    def func2(argv):
        argv[0] = argv[0] + argv[1]

    def func3(argv):
        argv[0] = argv[0] + argv[1]

    event1 = {'returncode': 0, 'output': 'Hello'}
    event2 = {'returncode': 0, 'output': 'Hello'}
    event3 = {'returncode': 0, 'output': 'Hello'}

    m1 = create.create_autospec(AnsibleModule)

# Generated at 2022-06-25 02:03:25.175056
# Unit test for function main
def test_main():
    assert True

try:
    # Unit test for function check_command
    def test_check_command():
        assert True
except:
    pass

if __name__ == '__main__':
    import time
    test_case_0()
    test_main()
    test_check_command()
    main()

# Generated at 2022-06-25 02:03:27.687746
# Unit test for function check_command
def test_check_command():
    import mock
    mock_module = mock.Mock()
    mock_commandline = mock.Mock()
    test_case_0(mock_module, mock_commandline)


# Generated at 2022-06-25 02:03:35.045882
# Unit test for function main
def test_main():

    # Mock module class
    class ansible_module_command_mock:
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.check_mode = True
        def fail_json(self, *args, **kwargs):
            return dict(failed=True, *args, **kwargs)
        def exit_json(self, *args, **kwargs):
            return dict(*args, **kwargs)
        def warn(self, *args, **kwargs):
            return dict(*args, **kwargs)
        def run_command(self, *args, **kwargs):
            return dict(*args, **kwargs)

    # Create mock object

# Generated at 2022-06-25 02:03:36.628908
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:03:40.046812
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        # If the unit test fails, an exception will be raised.
        print("Unittest for function main has failed.")

# Generated at 2022-06-25 02:03:46.009018
# Unit test for function main
def test_main():
    var_0 = main(args=["ansible-test","--debug", "--module-path", "/home/leo/Documents/ansible_modules", "--inventory", "/home/leo/Documents/ansible_hosts", "/home/leo/Documents/testing.yml"])
    return var_0

# Generated at 2022-06-25 02:03:56.008644
# Unit test for function check_command
def test_check_command():
    # Create the 'mock' module object
    module = AnsibleModule(
        argument_spec = dict(
            a_bool=dict(type='bool', required=False, default=False),
            a_dict=dict(type='dict', required=False, default='_value_'),
            a_int=dict(type='int', required=False, default=_DEFAULT_A_INT),
            a_list=dict(type='list', required=False, default='_value_'),
            a_str=dict(type='str', required=False, default='_value_'),
            action=dict(type='str', required=False, default='_value_')
        )
    )

    # Set the module args with the values from the fixture
    module.params = fixture_args

    # Set the 'ansible_check_mode'

# Generated at 2022-06-25 02:04:16.602324
# Unit test for function main
def test_main():
    assert (main() is not None)


# Generated at 2022-06-25 02:04:22.725710
# Unit test for function main

# Generated at 2022-06-25 02:04:24.774915
# Unit test for function check_command
def test_check_command():
    commandline = ""
    main()
    main()
    main()
    main()


# Generated at 2022-06-25 02:04:29.851125
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(argument_spec=dict(_raw_params=dict(), _uses_shell=dict(type='bool', default=False), argv=dict(type='list', elements='str'), chdir=dict(type='path'), executable=dict(), creates=dict(type='path'), removes=dict(type='path'), warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'), stdin=dict(required=False), stdin_add_newline=dict(type='bool', default=True), strip_empty_ends=dict(type='bool', default=True)), supports_check_mode=True)

    var_1 = var_0.params['_raw_params']
    var_2 = var_0.params['_uses_shell']
   

# Generated at 2022-06-25 02:04:33.133747
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == 0

################################################################################
# TESTING
################################################################################
# Pylint is complaining about not being able to test private methods for some reason
# pylint: disable=protected-access

from ansible.compat.tests import unittest
from ansible.compat.tests.mock import patch
from ansible.module_utils import basic


# Generated at 2022-06-25 02:04:33.757090
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:04:43.741795
# Unit test for function check_command
def test_check_command():
    temp_AnsibleModule = AnsibleModule
    temp_os_path_basename = os.path.basename
    temp_module_warn = AnsibleModule.warn
    temp_isinstance = isinstance

    # Define the parameters that would normally be passed to the AnsibleModule
    module_args = dict(
        commandline=[True, "true"]
    )

    # AnsibleModule utilises argparse and thus the argument specification has to be a Namespace
    module_args_namespace = argparse.Namespace(**module_args)

    # Define the return value of os.path.basename
    temp_os_path_basename = "true"
    os.path.basename = lambda x: temp_os_path_basename

    # Define the return value of isinstance
    temp_isinstance = False
   

# Generated at 2022-06-25 02:04:44.851742
# Unit test for function main
def test_main():
    pass

# End of main function

# Unit Testing code

# Generated at 2022-06-25 02:04:46.663082
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        pass

test_main()

# Generated at 2022-06-25 02:04:49.103814
# Unit test for function check_command
def test_check_command():
    try:
        module = AnsibleModule(argument_spec={})
        commandline = 'foo'
        result = check_command(module, commandline)

    except Exception as e:
        raise Exception(e)

    assert result == None

#
#print(test_case_0())

# Generated at 2022-06-25 02:05:30.794484
# Unit test for function main
def test_main():
    try:
        test_case_0()
        print("Passed ")
    except:
        print("Test Failed")
    # Implement your Tests Here

# Main 
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:05:37.734406
# Unit test for function main
def test_main():
    var_1 = ("cat", "foo")
    var_2 = "/tmp"
    var_3 = ("/usr/bin/env", "HOME=/tmp", "USER=ansible", "LC_MESSAGES=C", "PWD=/tmp", "LANG=en_US.UTF-8", "sss=213")
    var_4 = ("ls", "-lah")
    var_5 = 0
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None

# Generated at 2022-06-25 02:05:40.818569
# Unit test for function check_command
def test_check_command():
    commandline = "A string"
    module = "A string"
    assert(check_command(module, commandline)) == 1

raw_command = None


# Generated at 2022-06-25 02:05:45.140364
# Unit test for function main
def test_main():
    try:
        os.remove("test/unit/output/test_main.txt")
    except OSError:
        pass
    with open("test/unit/output/test_main.txt", "a") as myfile:
        myfile.write("Running test_main\n")
    var_0 = main()
    assert(var_0 == None)


# Generated at 2022-06-25 02:05:47.037139
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('[FAILED] Exception caught during testing of function main.')
        raise


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:05:56.393000
# Unit test for function main
def test_main():
    mock_params = {}
    mock_params.update({ 'sanitize': False, 'argv': ['/usr/bin/make_database.sh', 'db_user', 'db_name'], '_raw_params': '/usr/bin/make_database.sh db_user db_name', 'warn': True, 'creates': '/path/to/database', 'shell': False, 'chdir': 'somedir/', '_uses_shell': False, 'removes': '', 'executable': None, 'args': None})

# Generated at 2022-06-25 02:06:02.134152
# Unit test for function check_command
def test_check_command():
    # Set up mock module and commandline
    # Arguments used in check_command call
    module = AnsibleModule(
        argument_spec = dict(
            foo = dict(type='int'),
            bar = dict(type='int')
        ),
        supports_check_mode=True
    )
    commandline = "foo"
    # Set up return values
    # Call function to be tested
    check_command(module, commandline)
    # Assert return value
    # Assert side effects


# Generated at 2022-06-25 02:06:03.107071
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:06:04.773402
# Unit test for function main
def test_main():
    # print main()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:06:08.231345
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False

if __name__ == '__main__':
    try:
        test_main()
    except SystemExit as e:
        pass
    except:
        print('Unhandled Exception:')
        raise

# Generated at 2022-06-25 02:07:44.030072
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("[FAIL] test_case_0")

# Main program
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:07:46.824216
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in test case 0: %s" % (str(e)))


# Generated at 2022-06-25 02:07:47.430996
# Unit test for function check_command
def test_check_command():
    var_0 = main()



# Generated at 2022-06-25 02:07:48.148282
# Unit test for function main
def test_main():
    var_0 = main()
    

# Generated at 2022-06-25 02:07:49.395099
# Unit test for function main
def test_main():
    print("Testing function main...")
    test_case_0()
    print("Success!")


# Generated at 2022-06-25 02:07:50.972768
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 02:07:51.965773
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:07:53.298362
# Unit test for function main
def test_main():
    var_0 = main()
    return var_0

if __name__ == '__main__':
   main()

# Generated at 2022-06-25 02:08:01.358408
# Unit test for function main
def test_main():
    results = main()
    # result_0 = results[0]


#############################################################################
# DO NOT EDIT THIS FILE.
#
# Generated by yaml2pytest.py
# https://gist.github.com/robertputt/6526872
#############################################################################

import sys

import pytest
import pytest_html

from ansible import modules

# TODO: Update this with the expected module parameters.
expected_module_params = (
    '_raw_params',
    '_uses_shell',
    'argv',
    'chdir',
    'creates',
    'executable',
    'removes',
    'stdin',
    'stdin_add_newline',
    'strip_empty_ends',
    'warn',
)

# TODO:

# Generated at 2022-06-25 02:08:04.119748
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == "__main__":
    try:
        test_main()
    except TypeError as te:
        print(te)