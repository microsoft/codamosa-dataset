

# Generated at 2022-06-25 02:01:59.230475
# Unit test for function main
def test_main():
    try:
        var_1 = main()
    except SystemExit as e:
        assert e.code == 0, 'Incorrect exit code, got %d' % e.code
    else:
        if var_1 is not None:
            raise AssertionError('main() should return None, got ' + repr(var_1))



# Generated at 2022-06-25 02:02:07.893905
# Unit test for function main
def test_main():
    class MainTestCase(unittest.TestCase):
        @mock.patch("ansible.builtin.piping")
        @mock.patch("ansible.builtin.sys")
        @mock.patch("ansible.builtin.shlex")
        @mock.patch("ansible.builtin.datetime")
        def test_main(self, mock_datetime, mock_shlex, mock_sys, mock_piping):
            str_0 = 'Unable to change directory before execution: '
            str_1 = 'Consider using the '
            str_2 = ' module rather than running '
            str_3 = 'abcd'
            str_4 = 'Consider using the '
            str_5 = ' module with '
            str_6 = 'abcdabcd'

# Generated at 2022-06-25 02:02:11.133884
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print ("Fail")
        assert False

#Test case run
test_main()

# Generated at 2022-06-25 02:02:18.479381
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
            argument_spec = dict(
                command = {'required': True},
                creates = {'type': 'path'},
                removes = {'type': 'path'},
                chdir = {'type': 'path'},
                raw = {'type': 'bool', 'default': False},
                executable = {},
                directory_mode = {'type': 'raw'},
                warn = {'type': 'bool', 'default': False},
                stdin = {'type': 'str'},
                stdin_add_newline = {'type': 'bool', 'default': False},
                strip_empty_ends = {'type': 'bool', 'default': True},
            ),
            supports_check_mode = True
        )
    command = module.params['command']
    # Test raises

# Generated at 2022-06-25 02:02:24.419522
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("An exception occurred during the test cases.")
        import traceback
        traceback.print_exc()
        assert False

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:02:29.000143
# Unit test for function check_command
def test_check_command():
    class module:
        warn = print

    commandline = ["echo hello"]
    expected_result = None
    actual_result = check_command(module, commandline)

    assert actual_result == expected_result


# Generated at 2022-06-25 02:02:30.232712
# Unit test for function check_command
def test_check_command():
    test_case_0()
    print("\nTest if display the warning message in the command line")

# Run all the test cases

# Generated at 2022-06-25 02:02:31.482645
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 02:02:32.614841
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:02:38.433535
# Unit test for function check_command
def test_check_command():
    command = "command"
    module = AnsibleModule(
        argument_spec = dict(),
    )
    ansible_0 = AnsibleModule(
        argument_spec = dict(
            commandline=dict(type='str', required=False)
        ),
        supports_check_mode=False
    )
    result = check_command(module, commandline=command)
    print("Function check_command worked!")


# Generated at 2022-06-25 02:02:48.188935
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:02:51.266760
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    # Set up mock
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-25 02:02:54.030462
# Unit test for function main
def test_main():
    with mock.patch('builtins.print') as mock_print:
        # Call tested function
        test_case_0()
        # Check print calls
        assert mock_print.call_count == 0


# Generated at 2022-06-25 02:03:04.007498
# Unit test for function main
def test_main():
    var_1 = "outcome"
    var_2 = "outcome[\"changed\"]"
    var_3 = "outcome[\"msg\"]"
    var_4 = "outcome[\"rc\"]"
    var_5 = "outcome[\"stderr\"]"
    var_6 = "outcome[\"stderr_lines\"]"
    var_7 = "outcome[\"stdout\"]"
    var_8 = "outcome[\"stdout_lines\"]"
    var_9 = "outcome[\"warnings\"]"
    var_10 = "'command'"
    var_11 = "''"
    var_12 = "'ansible-doc'"
    var_13 = "''"
    var_14 = "'ansible-doc'"
    var_15 = "'ansible-doc'"
    var_

# Generated at 2022-06-25 02:03:08.830774
# Unit test for function check_command
def test_check_command():
    # Create Mock Module
    mock_module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode = True
    )

    # Set up mock
    check_command(mock_module, '/bin/echo hello')
    # Test passes
    try:
        mock_module.warn.assert_called()
    except Exception:
        raise Exception('Failed to assert that mock was called')


# Generated at 2022-06-25 02:03:10.719780
# Unit test for function check_command
def test_check_command():

    test_module = AnsibleModule({}, {})
    test_commandline = "hello world"
    check_command(test_module, test_commandline)


# Generated at 2022-06-25 02:03:11.676178
# Unit test for function main
def test_main():
    assert func_0

# Run tests
main()
test_main()

# Generated at 2022-06-25 02:03:14.031481
# Unit test for function main
def test_main():
    with mock.patch.object(builtins, 'print') as mock_print:
        assert main() == mock_print.assert_called_with()


# Generated at 2022-06-25 02:03:17.073744
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = 'test string'
    result = check_command(module, commandline)
    assert result is None


# Generated at 2022-06-25 02:03:26.488871
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(argument_spec=dict(_raw_params=dict(), _uses_shell=dict(default=False, type='bool'), argv=dict(type='list', elements='str'), chdir=dict(type='path'), executable=dict(), creates=dict(type='path'), removes=dict(type='path'), warn=dict(default=False, removed_in_version='2.14', type='bool', removed_from_collection='ansible.builtin'), stdin=dict(required=False), stdin_add_newline=dict(default=True, type='bool'), strip_empty_ends=dict(default=True, type='bool')), supports_check_mode=True)
    var_2 = var_1.params['_uses_shell']
    var_3 = var_1.params['chdir']
    var

# Generated at 2022-06-25 02:03:45.318411
# Unit test for function main
def test_main():
    dict_0 = {'strip_empty_ends': False}
    # This might be used for testing
    print(main(dict_0))
    # This might be used for testing
    print(main(dict_0))

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:03:51.375480
# Unit test for function main
def test_main():
    try:
        assert True
    except AssertionError as e:
        print("AssertionError raised in module test_main.")
    except Exception as e:
        print("Exception raised in module test_main: " + str(e))

# Execute test_main()
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:03:52.155042
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 02:04:02.838079
# Unit test for function main
def test_main():
    temp_var_0 = {}

    # Create mock module object
    temp_var_0['basic'] = [{'side_effect': [module_return_0]}]

    # Create mock module object
    temp_var_0['_raw_params'] = [{'side_effect': [module_return_0]}]

    # Create mock module object
    temp_var_0['_uses_shell'] = [{'side_effect': [module_return_0]}]

    # Create mock module object
    temp_var_0['argv'] = [{'side_effect': [module_return_0]}]

    # Create mock module object
    temp_var_0['chdir'] = [{'side_effect': [module_return_0]}]

    # Create mock module object
    temp_var_0['executable']

# Generated at 2022-06-25 02:04:07.449302
# Unit test for function check_command
def test_check_command():
    try:
        assert callable(check_command)
        test_case_0(check_command)
    except AssertionError as e:
        		# Unit test for function check_command
        print('check_command unit test failed.')
        print('AssertionError: ', e)
        



# Generated at 2022-06-25 02:04:14.080999
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        test_case_0()

# class AnsibleModule(object):
#     arguments_spec = {'_raw_params': {'type': 'str'},
#                       '_uses_shell': {'default': False, 'type': 'bool'},
#                       'argv': {'elements': 'str', 'type': 'list'},
#                       'chdir': {'type': 'path'},
#                       'creates': {'type': 'path'},
#                       'executable': {'default': None, 'type': 'path'},
#                       'removes': {'type': 'path'},
#                       'stdin': {'default': None, 'type': 'str'},
#                       'strip_empty_ends': {'default': True, 'type':

# Generated at 2022-06-25 02:04:17.793892
# Unit test for function main
def test_main():
    print(test_case_0)
    try:
        test_case_0()
    except:
        print("Error while testing the function main")
        raise

# Call the main function
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:04:20.145708
# Unit test for function check_command
def test_check_command():
    try:
        main()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 02:04:30.161697
# Unit test for function check_command
def test_check_command():
    class ModuleStub:
        def __init__(self, warn_args=None):
            self.warn_args = warn_args
            self.warn_called = False
            self.debug_called = False
            self.info_called = False
            self.error_called = False

        def warn(self, msg, *args, **kwargs):
            assert self.warn_args == (msg, args, kwargs)
            self.warn_called = True

        def debug(self, msg, *args, **kwargs):
            pass

        def info(self, msg, *args, **kwargs):
            pass

        def error(self, msg, *args, **kwargs):
            pass

    # Test commands that should call the warnings
    commandline = 'curl http://test.com'
    module = ModuleStub

# Generated at 2022-06-25 02:04:35.734896
# Unit test for function main
def test_main():
    # Create the mock
    mock_cmd_module_instance = MockedCmdModule()

    # Set the function reference we want to call
    # Mock it in a dynamic way so the whole test class is not needed
    mock_cmd_module_instance.run_command = main

    # Create a new instance of 'MockedCmdModule' to call the action plugin
    action_module_instance = MockedCmdModule()

    # Set our mock back on the action plugin
    action_module_instance.module = mock_cmd_module_instance

    # Create the task
    task = Task()

    # Create the task args

# Generated at 2022-06-25 02:05:14.367362
# Unit test for function main
def test_main():
    var_1 = {"_raw_params": "echo hello", "warn": False}
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:05:15.171404
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:05:16.541089
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:05:18.003333
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0



# Generated at 2022-06-25 02:05:21.533323
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
    )
    commandline = "command-line"

    check_command(module, commandline)


# Generated at 2022-06-25 02:05:22.551956
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:05:29.488577
# Unit test for function check_command
def test_check_command():
    global out_2

    # Create mock module
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': 'no'}})

    # Create mock commandline
    commandline = 'command'

    # Create expected output
    out_0 = None

    # Create mock module
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': 'no'}})

    # Create mock commandline
    commandline = 'command'

    # Create expected output
    out_1 = None

    # Create mock module
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': 'no'}})

    # Create mock commandline
    commandline = 'command'

    # Create expected output
    out_2 = None

   

# Generated at 2022-06-25 02:05:32.507125
# Unit test for function check_command
def test_check_command():
    commandline_0 = "/sbin/service"
    module_0 = AnsibleModule(argument_spec=dict())
    # Testing for exception jinja2.exceptions.UndefinedError in
    # task_execution.validate_task_keys
    # test case 0
    with pytest.raises(NotImplementedError):
        check_command(module_0, commandline_0)



# Generated at 2022-06-25 02:05:33.353882
# Unit test for function main
def test_main():
    var_0 = main()
    assert (var_0 == 'True')

# Generated at 2022-06-25 02:05:35.177734
# Unit test for function main
def test_main():
    pass
	
if __name__ == '__main__':
	test_main()

# Generated at 2022-06-25 02:07:11.577315
# Unit test for function main
def test_main():

    # Input params sample for function main
    args = []
    kwargs = {"creates": "/path/to/database"}

    main(args,kwargs)


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:07:13.856093
# Unit test for function check_command
def test_check_command():
    module = AnsibleModuleStub()
    commandline = 'echo hello'
    check_command(module, commandline)


# Generated at 2022-06-25 02:07:14.596866
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:07:23.104617
# Unit test for function check_command
def test_check_command():
    class ModuleStub(object):
        def __init__(self):
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    command = ['/usr/bin/make_database.sh', 'db_user', 'db_name']
    check_command(ModuleStub(), command)
    assert 'Consider using the file module with state=directory rather than running \'mkdir\'.  ' \
           'If you need to use \'mkdir\' because the file module is insufficient you can add \'warn: false\' to this ' \
           'command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get rid of this message.' \
           in ModuleStub.warnings, ModuleStub.warnings


# Generated at 2022-06-25 02:07:24.655716
# Unit test for function main
def test_main():
    var_1 = None
    var_0 = main(var_1)
    assert var_0 == False


# Generated at 2022-06-25 02:07:25.552093
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:07:26.783079
# Unit test for function main
def test_main():
    # main()
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:07:33.753639
# Unit test for function check_command

# Generated at 2022-06-25 02:07:36.267530
# Unit test for function check_command
def test_check_command():
    # Check for valid command.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=[])
    var_0 = check_command(module, "ls")
    # Assert response.
    assert(var_0 == None)
    # Check for invalid command.
    var_1 = check_command(module, "foo")
    # Assert response.
    assert(var_1 == None)


# Generated at 2022-06-25 02:07:36.986820
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:11:17.418556
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print('test_case_0() failed')

test_main()

# Generated at 2022-06-25 02:11:20.890500
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print(traceback.format_exc())
        assert False
    assert True

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:11:28.314171
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict( type='bool', default = False ),
            argv=dict( type='list', elements="str"),
            chdir=dict( type='path'),
            executable=dict(),
            creates=dict( type='path'),
            removes=dict( type='path'),
            warn=dict( type='bool', default = True, removed_from_collection ='ansible.builtin'),
            stdin=dict( required = False),
            stdin_add_newline=dict( type='bool', default = True),
            strip_empty_ends=dict( type='bool', default = True),
        ),
        supports_check_mode=True,
    )
    func_0 = True

# Generated at 2022-06-25 02:11:30.980832
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print >>sys.stderr, "Exit non-zero"
            sys.exit(1)

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:11:32.901056
# Unit test for function check_command
def test_check_command():
    arg_0 = 'foo'
    arg_1 = 'bar'
    try:
        check_command(arg_0, arg_1)
    except:
        pass


# Generated at 2022-06-25 02:11:33.851328
# Unit test for function check_command
def test_check_command():
    commandline = 'echo hello'
    test_case_0()


# Generated at 2022-06-25 02:11:36.608156
# Unit test for function main
def test_main():
    # Produce a system error message.
    try:
        assert False
    except AssertionError as e:
        err_msg = str(e)
        print(f'AssertionError: {err_msg}')

if __name__ == '__main__':
    test_main()