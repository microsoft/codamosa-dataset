

# Generated at 2022-06-11 06:39:14.520125
# Unit test for function main
def test_main():
    import json
    import os

    mod = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib',
                       'ansible', 'modules', 'commands', 'command.py')

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    args_json = '{"changed": false, "stdout": "", "stderr": "", "rc": 256, "cmd": null, "start": null, "end": null, "delta": null, "msg": "no command given"}'

    stdout = b'foo'


# Generated at 2022-06-11 06:39:18.865627
# Unit test for function main
def test_main():
    result = {}
    my_dict = {}
    main()
    assert 'changed' in result
    assert 'msg' in result
    assert 'rc' in result
    assert 'cmd' in result
    assert 'stdout' in result
    assert 'stderr' in result

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:30.714682
# Unit test for function main

# Generated at 2022-06-11 06:39:35.549523
# Unit test for function main
def test_main():

    # AnsibleModule can not be used in this case as it makes system calls which are not allowed in unit tests
    # Using MagicMock instead of AnsibleModule to mimic the required function and return values
    # for the purpose of unit testing.
    class MockAnsibleModule:

        def __init__(self, argument_spec=None, supports_check_mode=None):
            self.params = {}
            self.check_mode = False

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def exit_json(self, **kwargs):
            return kwargs

        def run_command(self, args, executable=None, use_unsafe_shell=None, encoding=None, data=None):
            return 0, "", ""


# Generated at 2022-06-11 06:39:43.816484
# Unit test for function main
def test_main():
    argument_spec = {
        '_raw_params': '',
        '_uses_shell': True,
        'argv': [],
        'chdir': '',
        'executable': '',
        'creates': '',
        'removes': '',
        'warn': True,
        'stdin': '',
        'stdin_add_newline': True,
        'strip_empty_ends': True,
        'check_mode': False
    }
    module = type('Module', (object,), {'argument_spec': argument_spec, 'params': {}})
    module.fail_json = lambda **kwargs: kwargs
    module.exit_json = lambda **kwargs: kwargs

# Generated at 2022-06-11 06:39:55.926390
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l /tmp',
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    r = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )

# Generated at 2022-06-11 06:39:58.931182
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as context:
        main()
    assert 'msg' in context.value.args[0]

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:40:10.961314
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    check_command(module, "rm /tmp/foo")
    check_command(module, "rm -rf /tmp/foo")
    check_command(module, "rm /tmp/foo")

    check_command(module, ["chown", "me:us", "/tmp/foo"])
    check_command(module, ["chmod", "600", "/tmp/foo"])
    check_command(module, ["chgrp", "us", "/tmp/foo"])

    check_command(module, ["svn", "checkout", "svn://svn.zope.org/repos/main/ZConfig/trunk/"])
    check_command(module, ["service", "svn", "start"])

# Generated at 2022-06-11 06:40:22.466215
# Unit test for function main

# Generated at 2022-06-11 06:40:34.642199
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes

    # Test for check_command warning for command: curl.
    result = {
        "changed": False,
        "stdout": "",
        "stderr": "",
        "rc": None,
        "cmd": None,
        "start": None,
        "end": None,
        "delta": None,
        "msg": ""
    }
    args = {
        "_raw_params": "curl -u user:passwd https://127.0.0.1/mydir/file.txt",
        "_uses_shell": False,
        "chdir": None,
        "executable": None,
        "creates": None,
        "removes": None,
        "warn": True
    }

# Generated at 2022-06-11 06:40:45.367317
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert check_command(module, ['/usr/bin/touch']) == None


# Generated at 2022-06-11 06:40:47.455671
# Unit test for function check_command
def test_check_command():
    command = "yum install -y httpd"
    module = AnsibleModule(command=command, check_mode=True)
    check_command(module, command)



# Generated at 2022-06-11 06:40:48.248361
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 06:40:51.009720
# Unit test for function main
def test_main():
    test_module = AnsibleModule({'_raw_params': 'ls'}, check_invalid_arguments=False)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:00.229880
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': True}})

    for command in ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch',
                    'curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
                    'tar', 'unzip', 'sed', 'dnf', 'zypper',
                    'sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        check_command(module, "%s foo" % command)



# Generated at 2022-06-11 06:41:10.577935
# Unit test for function main
def test_main():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs
    class AnsibleModule(object):
        exit_json = print
        fail_json = print
        run_command = print
        check_mode = False
        def __init__(self, **kwargs):
            self.params = Options(**kwargs)
        def fail_json(self, **kwargs):
            assert False
    class Datetime(object):
        def __enter__(self):
            return self
        def __exit__(self, a, b, c):
            pass
    class Exception(object):
        pass
    class Shlex(object):
        @staticmethod
        def split(args):
            return args.split()
    class IOError(Exception):
        pass

# Generated at 2022-06-11 06:41:11.528706
# Unit test for function main
def test_main():
    result = main()

# Generated at 2022-06-11 06:41:21.778765
# Unit test for function main
def test_main():
    module_args = dict(
        _raw_params='ls -l',
        _uses_shell=False
    )
    import json
    res = dict(
        changed=True,
        cmd=['ls', '-l'],
        delta='0:00:00.001529',
        end='2017-09-29 22:03:48.084657',
        msg='',
        rc=0,
        start='2017-09-29 22:03:48.083128',
        stderr='',
        stdout='Clustering node rabbit@slave1 with rabbit@master …'
    )
    m = AnsibleModule(argument_spec=module_args)
    main()
    assert json.loads(m.json()) == res

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:30.789238
# Unit test for function main
def test_main():
    # Mock moduleA
    moduleA = Mock()
    moduleA.fail_json.side_effect = exitA
    moduleA.run_command.return_value = (0, 'stdout', 'stderr')
    moduleA.check_mode = False

    # Mock argv
    argv = ['/bin/true']

    # Execute the main function
    with pytest.raises(exitA):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:39.232074
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = ["chown"]
    check_command(module, commandline)
    commandline = ["chmod"]
    check_command(module, commandline)
    commandline = ["chgrp"]
    check_command(module, commandline)
    commandline = ["ln"]
    check_command(module, commandline)
    commandline = ["mkdir"]
    check_command(module, commandline)
    commandline = ["rmdir"]
    check_command(module, commandline)
    commandline = ["rm"]
    check_command(module, commandline)
    commandline = ["touch"]
    check_command(module, commandline)
    commandline = ["curl"]
    check_command(module, commandline)

# Generated at 2022-06-11 06:42:06.308711
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})

    module.warn = MagicMock(name='warn')
    check_command(module, b"touch /tmp/foo")
    assert module.warn.called is True
    args, kwargs = module.warn.call_args
    assert args == ("Consider using the file module with state=touch rather than running 'touch'.  "
                    "If you need to use 'touch' because the file module is insufficient you can add "
                    "'warn: false' to this command task or set 'command_warnings=False' in the "
                    "defaults section of ansible.cfg to get rid of this message.",)
    assert kwargs == {}

    # Check that warnings are not raised when disabled.

# Generated at 2022-06-11 06:42:17.916809
# Unit test for function main
def test_main():
    args = {}
    # Create the module wrapper
    module = AnsibleModule( argument_spec=dict(_raw_params=dict(),_uses_shell=dict(type='bool', default=False),argv=dict(type='list', elements='str'),chdir=dict(type='path'),executable=dict(),creates=dict(type='path'),removes=dict(type='path'),warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),stdin=dict(required=False),stdin_add_newline=dict(type='bool', default=True),strip_empty_ends=dict(type='bool', default=True), ), supports_check_mode=True, )
    # Set the arguments
    args['_uses_shell'] = False

# Generated at 2022-06-11 06:42:28.826206
# Unit test for function check_command
def test_check_command():
    # Construct a mock module object
    module = type('', (object,), {
        'warn': lambda self, msg: print(msg)
    })()
    # Call the function with a command known to produce
    # a warning, confirm that the warning is printed
    from io import StringIO
    from contextlib import contextmanager
    original_stdout = sys.stdout
    @contextmanager
    def stdoutIO(stdout=os.devnull):
        new_target = StringIO()
        old_target, sys.stdout = sys.stdout, new_target
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_target
    with stdoutIO() as s:
        check_command(module, "echo")
    output = s.getvalue().strip()

# Generated at 2022-06-11 06:42:33.946263
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec=dict(command=dict(type='str', default='echo hello'),
                                         test_func=dict(type='str', default='check_command')))
    if m.params['test_func'] == 'check_command':
        check_command(m, m.params['command'])


# Generated at 2022-06-11 06:42:45.460532
# Unit test for function main
def test_main():
    argv = ['command.py', 'arg1=hello', 'arg2=world']
    argv_expected = ['command.py', 'arg1=hello', 'arg2=world']
    with mock.patch.object(sys, 'argv', argv):
        with mock.patch.object(sys, 'exit') as m_exit:
            with mock.patch.object(sys, 'stdout', new=mock.MagicMock) as m_stdout:
                with mock.patch.object(ansible.module_utils.basic.AnsibleModule, 'run_command') as m_run_command:
                    m_run_command.return_value = (0, '', '')
                    main()

    # Assertions

# Generated at 2022-06-11 06:42:57.267190
# Unit test for function main
def test_main():
    # Invoke the command with a bad parameter
    args = """{
        "_raw_params": "bad arg",
        "_uses_shell": false,
        "chdir": "string",
        "executable": "string",
        "creates": "string",
        "removes": "string",
        "warn": false,
        "stdin": "string",
        "stdin_add_newline": true,
        "strip_empty_ends": true
    }"""
    if six.PY3:
        # Convert to text since run_command uses text
        args = args.encode('utf8')
    rc, out, err = module.run_command(args)
    assert rc == 0
    assert out is not None
    assert err is None

    # Invoke the command with a good parameter

# Generated at 2022-06-11 06:43:06.966945
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='uptime',
        _uses_shell=True,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        strip_empty_ends=True
    )

# Generated at 2022-06-11 06:43:17.195052
# Unit test for function main

# Generated at 2022-06-11 06:43:26.219366
# Unit test for function main
def test_main():
    # Mock os module
    os_module = Mock()
    os_module.path.basename.return_value = 'some cmd'
    os_module.path.join.return_value = 'some/path'
    os_module.path.exists.return_value = True
    os_module.path.isdir.return_value = True
    os_module.getcwd.return_value = 'some/dir'
    os_module.chdir.side_effect = lambda x: x
    os_module.path.abspath.return_value = 'some/abs/path'
    os_module.path.normpath.return_value = 'some/norm/path'
    os_module.path.normcase.return_value = 'some/norm/path'

# Generated at 2022-06-11 06:43:31.406793
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule(
        argument_spec = dict(
            command = dict(aliases=['name']),
            creates = dict(type='path'),
        )
    )
    mod._ansible_warn = True
    check_command(mod, ['echo', 'hello'])
    mod._ansible_warn = False
    check_command(mod, ['echo', 'hello'])



# Generated at 2022-06-11 06:44:24.393626
# Unit test for function check_command
def test_check_command():
    commandline = "test"
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-11 06:44:35.374458
# Unit test for function main

# Generated at 2022-06-11 06:44:46.977208
# Unit test for function main
def test_main():
    # create some temporary files for test purposes
    (temp_fd, temp_name) = tempfile.mkstemp()
    os.close(temp_fd)
    temp_fd2 = tempfile.NamedTemporaryFile()

    # create a temporary command file
    get_command_filename = tempfile.mkstemp(suffix='.command')
    os.close(get_command_filename[0])
    get_command_filename = get_command_filename[1]
    file_handle = open(get_command_filename, 'w')
    file_handle.write("echo 'Hello, world!'\n")
    file_handle.close()

    # create a temporary script file
    get_script_filename = tempfile.NamedTemporaryFile(suffix='.py', delete=False)
    get_script_filename = get

# Generated at 2022-06-11 06:44:49.992011
# Unit test for function main
def test_main():
    with pytest.raises(FailJsonException) as excinfo:
        main()

    assert excinfo.value.kwargs['msg'] == 'no command given'


# Generated at 2022-06-11 06:44:51.396230
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:44:58.473762
# Unit test for function check_command
def test_check_command():
    module = MockModule()
    check_command(module, "echo")
    assert module.warnings == []

    module = MockModule()
    check_command(module, "sed")
    assert len(module.warnings) == 1
    assert "use the replace, lineinfile or template module" in module.warnings[0]

    module = MockModule()
    check_command(module, "chown")
    assert len(module.warnings) == 1
    assert "use the file module with owner" in module.warnings[0]

    module = MockModule()
    check_command(module, "curl")
    assert len(module.warnings) == 1
    assert "use the get_url or uri module" in module.warnings[0]



# Generated at 2022-06-11 06:45:08.712057
# Unit test for function main

# Generated at 2022-06-11 06:45:10.370503
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:45:14.570236
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "sed")
    check_command(module, "svn")
    check_command(module, "yum")
    check_command(module, ["/bin/sed", "-n", "1p "])



# Generated at 2022-06-11 06:45:22.732271
# Unit test for function main
def test_main():
    args = dict(
    _raw_params='ls',
    _uses_shell=False,
    argv='ls'
    )
    r = dict(
    cmd='ls',
    delta=None,
    end=None,
    changed=False,
    rc=None,
    msg='',
    start=None,
    stdout='',
    stderr=''
    )
    res_args = main(args, False)
    assert res_args == r, "expected: %s, got: %s" % (r, res_args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:46:32.433236
# Unit test for function main

# Generated at 2022-06-11 06:46:40.377290
# Unit test for function main
def test_main():
    args = dict(
        creates="/test/test",
        argv=["echo", "hello"]
    )
    command_data = dict(
        changed=False,
        msg='',
        rc=0,
        stdout='',
        stderr='',
        stdout_lines=[],
        stderr_lines=[],
        cmd=[]
    )
    res_command_data = dict(
        changed=False,
        msg='non-zero return code',
        rc=0,
        stdout='',
        stderr='',
        stdout_lines=[],
        stderr_lines=[],
        cmd=[]
    )

# Generated at 2022-06-11 06:46:46.917281
# Unit test for function main
def test_main():
    # This is a basic test, only checking one path
    args = dict(
        _raw_params = 'false',
        _uses_shell = True,
        argv = 'false',
        chdir = None,
        executable = None,
        creates = None,
        removes = None,
        warn = True,
        stdin = None,
        stdin_add_newline = True,
        strip_empty_ends = True,
    )
    r = main()
    assert r['rc'] == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:46:54.523572
# Unit test for function main

# Generated at 2022-06-11 06:46:59.861184
# Unit test for function main
def test_main():
  import tempfile
  import os
  import shutil
  import json


# Generated at 2022-06-11 06:47:06.454261
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warns = []
        def fail_json(self, **args):
            pass
        def exit_json(self, **args):
            pass
        def warn(self, msg):
            self.warns.append(msg)

    m = FakeModule()
    check_command(m, 'curl http://localhost')
    assert len(m.warns) == 2
    assert isinstance(m.warns[0], str)
    assert 'curl' in m.warns[0]



# Generated at 2022-06-11 06:47:14.700602
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule(argument_spec={})
    check_command(mod, 'chown nonroot:nonroot /home/nonroot')
    check_command(mod, 'chmod 0600 /home/nonroot/my.cnf')
    check_command(mod, 'chgrp nonroot /home/nonroot')
    check_command(mod, 'ln -s target link')
    check_command(mod, 'mkdir -p /tmp/test')
    check_command(mod, 'rmdir /tmp/test')
    check_command(mod, 'rm -f /tmp/test/*')
    check_command(mod, 'touch /tmp/test')

    check_command(mod, 'curl https://google.com/myurl')

# Generated at 2022-06-11 06:47:16.817630
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    doc = basic.AnsibleModule.__doc__
    assert doc


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:47:18.061592
# Unit test for function main
def test_main():
    result = main()
    assert result is None


# Generated at 2022-06-11 06:47:25.903317
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    def ansible_main(args):
        # NOTE: args is in to_native format
        args = { k:v for k,v in args.items() }