

# Generated at 2022-06-11 06:39:10.250281
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'_ansible_check_mode': {'type': 'bool', 'required': False},
                                          '_ansible_no_log': {'type': 'bool', 'required': False},
                                          'check_command_warnings': {'type': 'bool', 'required': False}})
    check_command(module, 'find')



# Generated at 2022-06-11 06:39:20.477006
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import exit_json, fail_json
    # Create a dummy module for unit testing,
    # this module does nothing and just records all the arguments.
    test = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    command = ['mkdir', '-p', '/tmp/test']
    check_command(test, commandline=command)
    # Check that the proper warning was issued.
    assert len(test.warnings) == 1
    result = test.warnings[0]

# Generated at 2022-06-11 06:39:30.579568
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    # Passing comma separated list of commands to the function
    check_command(module, ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir',
                           'rm', 'touch', 'curl', 'wget', 'svn', 'service',
                           'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip',
                           'sed', 'dnf', 'zypper', 'sudo', 'su', 'pbrun',
                           'pfexec', 'runas', 'pmrun', 'machinectl'])



# Generated at 2022-06-11 06:39:38.279735
# Unit test for function main
def test_main():
    args = {
        '_raw_params': 'uname -a',
        '_uses_shell': False,
        'argv': ['uname', '-a'],
        'chdir': '/path/to/chdir',
        'executable': None,
        'creates': '/path/to/creates',
        'removes': '/path/to/removes',
        'warn': False,
        'stdin': 'uname -a',
        'stdin_add_newline': True,
        'strip_empty_ends': True,
    }
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    r = main.__wrapped__(module=module, **args)
   

# Generated at 2022-06-11 06:39:49.716790
# Unit test for function main

# Generated at 2022-06-11 06:39:59.124568
# Unit test for function main
def test_main():
    import tempfile
    import os

# Generated at 2022-06-11 06:40:09.773345
# Unit test for function main
def test_main():
    test = {}
    test['params'] = {}
    test['params']['_raw_params'] = None
    test['params']['_uses_shell'] = False
    test['params']['argv'] = None
    test['params']['chdir'] = None
    test['params']['creates'] = None
    test['params']['executable'] = None
    test['params']['removes'] = None
    test['params']['warn'] = False
    test['params']['stdin'] = None
    test['params']['stdin_add_newline'] = True
    test['params']['strip_empty_ends'] = True
    main(test)

# Generated at 2022-06-11 06:40:12.148943
# Unit test for function main
def test_main():
    r = main()
    assert r is not None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:40:23.129566
# Unit test for function main
def test_main():
    # provided by the module
    result = dict(
        changed=True,
        msg='non-zero return code',
        rc=1,
        stdout='',
        stderr='',
        cmd='echo hello',
    )
    # populate the args structure
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=None,
        chdir='.',
        executable='',
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    # call the function
    main(args)
    # verify that we got what we expected
    assert result == args



# Generated at 2022-06-11 06:40:35.342895
# Unit test for function check_command
def test_check_command():
    obj = type("obj", (object,), {})
    obj.warn = lambda x: True
    def test(cmd, res):
        obj.warn = lambda x: False
        check_command(obj, cmd)
        assert obj.warn == res
    test('/usr/bin/chown', True)
    test('/usr/bin/chgrp', True)
    test('/usr/bin/chmod', True)
    test('/usr/bin/ln', True)
    test('/usr/bin/mkdir', True)
    test('/usr/bin/rmdir', True)
    test('/usr/bin/rm', True)
    test('/usr/bin/touch', True)
    test('/usr/bin/curl', True)
    test('/usr/bin/wget', True)

# Generated at 2022-06-11 06:40:54.944363
# Unit test for function main
def test_main():
    args = dict(
        argv=[
            '/bin/echo', 'Hello world!'
        ],
        _uses_shell=False,
        executable=None,
        _raw_params=None,
        chdir=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True
    )

# Generated at 2022-06-11 06:41:05.119841
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'check_command_warnings': {'type': 'bool', 'default': True}})

    # Test for argument warning
    commandline = 'cp somefile someotherfile'
    check_command(module, commandline)

    # Test for command warning
    commandline = 'apt-get install somepackage'
    check_command(module, commandline)

    # Test for become warning
    commandline = 'sudo -u someuser command'
    check_command(module, commandline)

    module.exit_json()


# ===========================================
# Main control flow

try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()



# Generated at 2022-06-11 06:41:06.460660
# Unit test for function main
def test_main():
  main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:14.693313
# Unit test for function main
def test_main():
    test_module_name = 'ansible.builtin.command'

# Generated at 2022-06-11 06:41:18.024520
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    check_command(module, "wget -O some_file some_url")
# end of function test_check_command


# Generated at 2022-06-11 06:41:30.697550
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ["curl"])
    check_command(module, ["/usr/bin/curl"])
    check_command(module, ["curl", "foo"])
    check_command(module, ["curl", "foo", "bar"])
    check_command(module, ["/usr/bin/curl", "foo"])
    check_command(module, ["/usr/bin/curl", "foo", "bar"])
    check_command(module, ["/usr/bin/curl", "foo", "bar", "baz"])
    check_command(module, ["sed"])
    check_command(module, ["/usr/bin/sed"])
    check_command(module, ["sed", "foo"])
    check_

# Generated at 2022-06-11 06:41:34.655701
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(module, '/usr/bin/apt-get update')
    assert not module.fail_json.called, "check_command should not cause AnsibleModule.fail_json to be called"



# Generated at 2022-06-11 06:41:45.090234
# Unit test for function main

# Generated at 2022-06-11 06:41:56.294164
# Unit test for function main
def test_main():
    test_command = ['asdffdsa']
    from ansible.modules.command.command import main
    import json
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    # test fails with non-zero command
    def run_command_fail(args, executable=None, use_unsafe_shell=False, data=None, binary_data=True):
        return 1, "STDIN: %s\nSTDOUT: %s\nSTDERR: %s\n" % (data, args, executable), ""

    # test succeeds with non-zero command

# Generated at 2022-06-11 06:41:57.669763
# Unit test for function check_command
def test_check_command():
  assert check_command('command') == 'command'


# Generated at 2022-06-11 06:42:22.016501
# Unit test for function main
def test_main():
    from ansible.modules.system.command import main
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='list', elements='str'),
            creates=dict(type='path'),
            removes=dict(type='path'),
        ),
        supports_check_mode=True,
    )
    main(module)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:42:33.731511
# Unit test for function main
def test_main():

    # Setup argument_spec
    argument_spec = dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            # The default for this really comes from the action plugin
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        )

    assert True == True

# Generated at 2022-06-11 06:42:43.161123
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.iosxr.iosxr import run_commands, iosxr_argument_spec
    from ansible.module_utils.parsing.convert_bool import boolean

    assert basic
    assert Connection
    assert load_provider
    assert run_commands
    assert iosxr_argument_spec
    assert boolean

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:42:55.022072
# Unit test for function main
def test_main():

    #import unittest
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from ansible.module_utils.common.collections import is_iterable
    import os
    import glob

    # makes sure check_command doesn't break
    check_command_args = 'ls'
    check_command_modules = ['ansible.builtin.file']
    check_command_response = 'Consider using the ansible.builtin.file module'
    m = AnsibleModule(argument_spec={})
    def mockwarn(msg):
        assert msg.startswith(check_command_response)

    with patch.object(m, 'warn', mockwarn):
        check_command(m, check_command_args)

    #
    # Test warn messages for command module
   

# Generated at 2022-06-11 06:43:05.221904
# Unit test for function main
def test_main():
    ostr = "Successful test"

# Generated at 2022-06-11 06:43:14.176594
# Unit test for function main
def test_main():
    args = dict(_raw_params='ls', chdir='/fake/path')
    r = dict(changed=False, stdout='', stderr='', rc=None, start=None, end=None, delta=None, cmd=None, msg='')
    p = dict(argument_spec=dict(
        _raw_params=dict(),
        chdir=dict(type='path'),
    ),
    check_mode = True,
    )
    p['_ansible_check_mode'] = True
    p['_raw_params'] = 'ls'
    p['chdir'] = '/fake/path'

    module = AnsibleModule(**p)
    module.run_command = lambda args, **kwargs: (0, 'abcdefg\n', '')
    main()



# Generated at 2022-06-11 06:43:23.765066
# Unit test for function main
def test_main():
    import json
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    def test_result(module, args, expected_result, is_shell_false=True,
                    executable=None, chdir=None, creates=None, removes=None, warn=False, stdin=None,
                    stdin_add_newline=True, strip=True, expected_stdout=None, expected_stderr=None):

        with pytest.raises(SystemExit) as exc:
            main()
            assert exc.value_code == 0

        assert args == module.params.get('_raw_params')
        assert executable == module.params.get('executable')

# Generated at 2022-06-11 06:43:33.534092
# Unit test for function main
def test_main():
    r = {'changed': False, 'msg': '', 'skip_reason': '', 'skipped': True,
         'stdout': '', 'stdout_lines': [], 'stderr': '', 'stderr_lines': []}

    # import module snippets
    from ansible.modules.command.command import main
    from ansible.module_utils import basic


# Generated at 2022-06-11 06:43:43.279954
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    import json

    parameters = dict(
        chdir='.',
        executable='/bin/echo',
        creates='/bin/echo',
        argv=['/bin/echo', 'hello'],
        strip_empty_ends=False)


# Generated at 2022-06-11 06:43:53.529045
# Unit test for function main
def test_main():
  cur_dir = os.path.dirname(os.path.realpath(__file__))
  os.chdir(cur_dir)
  data = {"_raw_params": "ls -l", "argv": [], "chdir": None, "executable": None, "creates": None, "removes": None, "warn": False, "stdin": None, "strip_empty_ends": True}
  with open('command.json', 'w') as f:
    json.dump(data, f)
  with open('command.json') as f:
    mod = CommandModule(argument_spec={},check_invalid_arguments=False, supports_check_mode=True, bypass_checks=True)
    output = mod.main()

# Generated at 2022-06-11 06:44:36.404117
# Unit test for function check_command
def test_check_command():
    import pytest

    class MockModule(object):
        def __init__(self):
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    module = MockModule()

    check_command(module, 'echo hello')
    assert not module.warnings

    check_command(module, '/bin/echo hello')
    assert not module.warnings



# Generated at 2022-06-11 06:44:38.839917
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    args = {}
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:44:50.332909
# Unit test for function main
def test_main():

    # Results of module execution.
    results = {
        'changed': False,
        'stdout': '',
        'stderr': '',
        'rc': None,
        'cmd': None,
        'start': None,
        'end': None,
        'delta': None,
        'msg': ''
    }

    # Replace the module, recipe results, and fixed input arguments with mocks.

# Generated at 2022-06-11 06:44:58.095529
# Unit test for function main
def test_main():
    raw_params_1 = "ansible --version"
    chdir_1 = "test"
    executable_1 = "bin/ansible"
    creates_1 = "/tmp/test"
    removes_1 = "/tmp/test"
    warn_1 = True
    #stdin_1 = "yes"
    #stdin_add_newline_1 = True
    strip_empty_ends_1 = True
    argv_1 = [raw_params_1]
    # test case 0
    command = raw_params_1
    chdir = chdir_1
    executable = executable_1
    creates = creates_1
    removes = removes_1
    warn = warn_1
    #stdin = stdin_1
    #stdin_add_newline = stdin_add_newline_1
    strip

# Generated at 2022-06-11 06:45:02.971976
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0
    assert pytest_wrapped_e.value.message is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:45:04.620934
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:45:14.877912
# Unit test for function main
def test_main():
    mod = AnsibleModule(argument_spec={'argv': {'type': 'list', 'elements': 'str'}})
    setattr(mod, '_ansible_verbosity', 1)
    setattr(mod, '_ansible_debug', True)
    mod.run_command = lambda cmd, executable=None, use_unsafe_shell=False, encoding='utf-8', data=None, binary_data=False: (0, '', '')
    mod.check_mode = False
    mod.params['argv'] = ['/usr/bin/make_database.sh', 'My db user', 'My db name']
    main()
    assert mod.exit_json.called
    assert mod.fail_json.called == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:45:15.988605
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-11 06:45:25.908073
# Unit test for function main
def test_main():
    import sys
    if sys.version_info[:2] == (2, 6):
        # start of python26 support
        import re
        import subprocess
        import json
        # Python 2.6 subprocess.check_output returns stderr
        def check_output(*popenargs, **kwargs):
            if 'stdout' in kwargs:
                raise ValueError('stdout argument not allowed, it will be overridden.')
            process = subprocess.Popen(stdout=subprocess.PIPE, *popenargs, **kwargs)
            output, unused_err = process.communicate()
            retcode = process.poll()
            if retcode:
                cmd = kwargs.get("args")
                if cmd is None:
                    cmd = popenargs[0]
                raise subprocess.Called

# Generated at 2022-06-11 06:45:26.758060
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:46:42.404817
# Unit test for function main
def test_main():
    r_elem = 'no command given'
    if r_elem in r['msg']:
        pass

    # the command module is the one ansible module that does not take key=value args
    # hence don't copy this one if you are looking to build others!
    # NOTE: ensure splitter.py is kept in sync for exceptions

# Generated at 2022-06-11 06:46:51.467035
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable
    import ansible.module_utils.command as command
    import datetime
    import glob
    import os


# Generated at 2022-06-11 06:46:59.996807
# Unit test for function main
def test_main():
    with patch.object(sys, 'argv', ['command']):
        module = importlib.import_module('ansible.builtin.command')
        def mock_datetime():
            return datetime.datetime(2017, 9, 29, 22, 3, 48, 83128)
        def mock_run_command(args, executable=None, use_unsafe_shell=None, data=None, binary_data=False):
            return (0, 'Clustering node rabbit@slave1 with rabbit@master …', '')
        with patch.object(module, 'run_command', side_effect=mock_run_command):
            with patch.object(datetime.datetime, 'now', side_effect=mock_datetime):
                with patch.object(sys, 'exit') as mock_exit:
                    module.main()


# Generated at 2022-06-11 06:47:08.795975
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile, os
    from ansible.modules.command import main
    some_stdin = '''
- hosts: localhost
  tasks:
    - name: test command
      ansible.builtin.command: /bin/echo hello world
'''
    with tempfile.NamedTemporaryFile() as f:
        f.write(to_bytes(some_stdin))
        f.flush()

# Generated at 2022-06-11 06:47:17.092091
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': True, 'no_log': True}})
    warnings = []
    setattr(module, 'warn', warnings.append)

    check_command(module, '/bin/chown nobody /etc/foo')
    assert len(warnings) == 1
    assert 'file' in warnings[0]
    assert 'chown' in warnings[0]

    check_command(module, ['/usr/local/bin/wget', 'http://www.example.com/path/to/file'])
    assert len(warnings) == 2
    assert 'get_url or uri' in warnings[1]
    assert 'wget' in warnings[1]

    check_command(module, '/bin/rpm -q package')

# Generated at 2022-06-11 06:47:25.168493
# Unit test for function main

# Generated at 2022-06-11 06:47:29.050435
# Unit test for function main
def test_main():
    # make args look like ansible's args
    import sys
    import json
    sys.argv = ["ansible-command", '{"creates":  "doc", "args": "foo"}']
    a = AnsibleModule(**{})
    b = main()
    #assert b == (dict(rc=256, msg='only command or argv can be given, not both'), 256)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:47:36.718568
# Unit test for function main
def test_main():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    base_dir = os.path.dirname(test_dir)
    lib_dir = os.path.join(base_dir, 'lib')
    ansible_module_utils_path = os.path.join(lib_dir, 'ansible', 'module_utils')
    module_name = 'ansible.builtin.command'
    path_args = [ ansible_module_utils_path ]
    if ansible_module_utils_path not in sys.path:
        sys.path.insert(0, ansible_module_utils_path)


# Generated at 2022-06-11 06:47:44.889242
# Unit test for function check_command
def test_check_command():
    os.environ['ANSIBLE_MODULE_ARGS'] = "{'command':'yum', 'warnings': True}"
    for cmd in ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        os.environ['ANSIBLE_MODULE_ARGS'] = "{'command':'%s', 'warnings': True}" % cmd
        module = AnsibleModule(argument_spec=dict())
        check_command(module, cmd)
        assert module.warnings[0].startswith('Consider using become')
    os.environ['ANSIBLE_MODULE_ARGS'] = "{'command':'ln', 'warnings': True}"
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'ln')
   

# Generated at 2022-06-11 06:47:47.291764
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule

    inputs = {}
    module = AnsibleModule(argument_spec=inputs)

    check_command(module, 'curl http://localhost/')

