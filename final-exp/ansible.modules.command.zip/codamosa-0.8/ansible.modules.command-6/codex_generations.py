

# Generated at 2022-06-11 06:39:09.572865
# Unit test for function main
def test_main():
    r = {}
    args = []
    r['cmd'] = args

    # actual executes command (or not ...)
    r['rc'], r['stdout'], r['stderr'] = run_command(args)

    if r['rc'] != 0:
        r['msg'] = 'non-zero return code'
        module.fail_json(**r)

    module.exit_json(**r)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:14.157764
# Unit test for function main
def test_main():
    for attr in ('_uses_shell', '_raw_params', 'argv', 'chdir', 'executable', 'warn', 'stdin', 'stdin_newline', 'strip_empty_ends'):
        assert hasattr(main, attr)

# Generated at 2022-06-11 06:39:15.775292
# Unit test for function main
def test_main():
    assert 1 == 1

if __name__ == "__main__":
    main()

# Generated at 2022-06-11 06:39:20.258774
# Unit test for function main
def test_main():
    args = {
        '_raw_params': 'ls -la /tmp',
        '_uses_shell': False,
        'chdir': '/',
        'creates': '/tmp',
        'removes': None,
        'warn': False,
    }
    main(args)

if __name__ == '__main__':
    main(sys.argv[1:])

# Generated at 2022-06-11 06:39:27.625918
# Unit test for function check_command
def test_check_command():
    # Incomplete unit test for function check_command
    # Does not check what happens when command is a list or module is a list,
    # and does not implement the 'warn' module
    module = AnsibleModule(argument_spec={})
    module.warn = None
    check_command(module, 'curl')
    assert module.warn == None
    check_command(module, 'touch')
    assert module.warn == None



# Generated at 2022-06-11 06:39:36.740756
# Unit test for function main

# Generated at 2022-06-11 06:39:45.917005
# Unit test for function main
def test_main():
    test_args = {
        '_raw_params': "cat /etc/motd",
        '_uses_shell': True,
        'chdir': None,
        'creates': None,
        'executable': None,
        'removes': None,
        'warn': False,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True
    }


# Generated at 2022-06-11 06:39:49.983299
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    module.check_mode = True
    result = main()
    assert result.copy() == {"changed": False, "failed": False, "rc": None, "stdout": "", "stderr": "", "cmd": "", "start": None, "end": None, "delta": None, "msg": "Command would have run if not in check mode", "skipped": True}

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:53.328892
# Unit test for function main
def test_main():
    # Execute the main function, we are not testing for exit_json and fail_json here
    # Also main function is not part of the module, it cannot be tested like the others.
    main()


# Generated at 2022-06-11 06:40:01.129828
# Unit test for function main
def test_main():

    # test module arguments
    _raw_params = 'command with space'
    _uses_shell = False
    argv = ['command', 'with', 'space']
    chdir = 'path/to/dir'
    executable = 'exec/path'
    creates = 'path/to/file'
    removes = 'path/to/file'
    warn = False
    stdin = 'stdin content'
    stdin_add_newline = True
    strip_empty_ends = True

    # prepare the arguments that would be sent to the AnsibleModule

# Generated at 2022-06-11 06:40:21.837426
# Unit test for function main
def test_main():
    test_args = ['blue', 'green']

# Generated at 2022-06-11 06:40:33.914617
# Unit test for function main

# Generated at 2022-06-11 06:40:43.980207
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, ModuleDeprecationWarning
    from ansible.modules.command.command import main as command_main
    from ansible.module_utils import common as ansible_module_utils
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import MagicMock, Mock, patch

    ansible_module_utils.get_exception = MagicMock(return_value=Exception)
    ansible_module_utils.module_deprecation_warning = MagicMock(side_effect=ModuleDeprecationWarning)
    args = {'_raw_params': '', '_uses_shell': False, 'argv': {}, 'chdir': '', 'executable': '', 'creates': '', 'removes': ''}

    m = MagicM

# Generated at 2022-06-11 06:40:51.268027
# Unit test for function main
def test_main():
    args = {"_raw_params": "ps -ef | grep netmiko", "creates": "testfile", "executable": None, "removes": None,
            "warn": False, "stdin": None, "stdin_add_newline": True, "strip_empty_ends": True, "_uses_shell": False,
            "chdir": None, "argv": None}
    r = {"msg": "", "rc": 256, "start": "2017-09-29 22:03:48.083128", "end": "2017-09-29 22:03:48.084657",
         "delta": "0:00:00.001529", "changed": False, "stdout": "", "stderr": "", "cmd": None}

    module = AnsibleModule(argument_spec=dict())



# Generated at 2022-06-11 06:41:02.063308
# Unit test for function main
def test_main():
    module_args = dict(
            _raw_params = 'true',
            executable = None,
            creates = None,
            removes = None,
            warn = False,
            stdin = '',
            stdin_add_newline = True,
            strip_empty_ends = True,
    )

# Generated at 2022-06-11 06:41:11.876130
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.module_common import AnsibleModule
    mock_module = AnsibleModule()
    check_command(mock_module, commandline="echo hello")
    check_command(mock_module, commandline=["echo", "hello"])
    check_command(mock_module, commandline="sudo echo hello")
    check_command(mock_module, commandline="su echo hello")
    check_command(mock_module, commandline="mv file newfile")
    check_command(mock_module, commandline="chmod newmode file")
    check_command(mock_module, commandline="chgrp newgroup file")
    check_command(mock_module, commandline="ln -s oldfile newfile")

# Generated at 2022-06-11 06:41:22.949260
# Unit test for function main
def test_main():
    commandline = 'echo hello'

# Generated at 2022-06-11 06:41:27.618087
# Unit test for function main
def test_main():
    # Mock module parameters
    args = ['/usr/bin/ls', '-1']  # argv
    argv = ['/usr/bin/ls', '-1']  # argv
    chdir = ''
    executable = None
    creates = ''
    removes = ''
    warn = False
    stdin = ''
    stdin_add_newline = True
    strip = True

# Generated at 2022-06-11 06:41:32.547573
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    commandline = "command"
    check_command(module, commandline)
    assert module.deprecations == []
    commandline = ["sh", "-c", "foo"]
    check_command(module, commandline)
    assert module.deprecations == []
    commandline = ["echo", "foo"]
    check_command(module, commandline)
    assert commandline in [deprecation.msg for deprecation in module.deprecations]
    module.deprecations = []

    commandline = "curl -O www.git.com"
    check_command(module, commandline)
    assert commandline in [deprecation.msg for deprecation in module.deprecations]



# Generated at 2022-06-11 06:41:40.378883
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def __init__(self):
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    # Use strings
    mod = FakeModule()
    check_command(mod, 'curl http://www.example.com/')
    assert "Consider using the get_url or uri module rather than running 'curl'.  " in mod.warnings[-1]
    assert "get_url or uri" in mod.warnings[-1]
    assert "If you need to use 'curl'" in mod.warnings[-1]

    # Use lists
    mod = FakeModule()
    check_command(mod, ['rpm', '-i', 'package.rpm'])

# Generated at 2022-06-11 06:42:01.587082
# Unit test for function check_command
def test_check_command():
    ''' ansible.builtin.command.check_command() returns None '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

    _warnings = []

#    class FakeModule(AnsibleModule):
#        def warn(self, msg):
#            _warnings.append(msg)
#
#    ansible.builtin.command.check_command(FakeModule(dict()), 'echo "hello"')
#    assert _warnings == []

    class FakeModule(AnsibleModule):
        def warn(self, msg):
            _warnings.append(msg)


    ansible.builtin.command.check_command(FakeModule(dict()), 'touch myfile')

# Generated at 2022-06-11 06:42:13.727597
# Unit test for function main
def test_main():
    args = 'ls --color=never'
    module = mock.Mock()
    module.params = {'_raw_params': args, 'warn': False}
    module.check_mode = False
    module.run_command.return_value = (0, "stdout", "stderr")
   
    with mock.patch.object(datetime, 'datetime') as patch_datetime:
        now = patch_datetime.now()
        main()
        assert module.run_command.called
        run_command_args, run_command_kwargs = module.run_command.call_args

        assert run_command_args == ((args,),)

# Generated at 2022-06-11 06:42:17.163834
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as exc:
        main()
    print('Info: %s' % exc.value.args[0])

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:42:28.163498
# Unit test for function main
def test_main():
    class AnsibleModuleMock(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, **kwargs):
            raise Exception("AnsibleModule.fail_json was called")
        def run_command(self, **kwargs):
            return 0, "", ""
    class ExceptionInRunCommand(Exception):
        pass
    def run_command_exception(self, **kwargs):
        raise ExceptionInRunCommand("Exception when running command")
    def run_command_mocked(self, **kwargs):
        self.run_command_called = True
        self.run_command_args = kwargs
        return 0, "test", ""

# Generated at 2022-06-11 06:42:39.798279
# Unit test for function main

# Generated at 2022-06-11 06:42:51.264307
# Unit test for function main
def test_main():
    args = ['command', 'test', 'arg1', 'arg2']
    raw_params = [args[1]]
    raw_params.extend(args[2:])
    raw_params = ' '.join(raw_params)
    if os.getenv('ANSIBLE_CHECK_MODE'):
        check_mode = 'True'
    else:
        check_mode = 'False'


# Generated at 2022-06-11 06:43:02.452000
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    # Test generic warning
    fm = FakeModule()
    check_command(fm, 'foo')
    assert len(fm.warnings) == 1

    # Test separation of warning argument and warning message
    fm = FakeModule()
    check_command(fm, 'foo bar')
    assert len(fm.warnings) == 1
    assert 'foo' in fm.warnings[0]
    assert 'bar' in fm.warnings[0]

    # Test file module usage
    fm = FakeModule()
    check_command(fm, 'chown')
    assert len(fm.warnings) == 1
    assert 'file'

# Generated at 2022-06-11 06:43:08.935584
# Unit test for function main
def test_main():
    # Create a dummy module.
    dummy_module = AnsibleModule(argument_spec={})
    dummy_module.params = {'creates': '/Users/danieljgrogan/PycharmProjects/ansible_command_module/test_file'}
    dummy_module.check_mode = False

    # This should return False since the file does not exist.
    assert main(dummy_module) == False

    dummy_module.check_mode = True
    # This should return True since the file does not exist.
    assert main(dummy_module) == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:43:19.137425
# Unit test for function main
def test_main():  # noqa
    action_args = {'_raw_params': 'migrate',
                   '_uses_shell': False,
                   'chdir': None,
                   'executable': None,
                   'creates': None,
                   'removes': None,
                   'warn': False,
                   'stdin': None,
                   'stdin_add_newline': True,
                   'strip_empty_ends': True}
    class MyModule(object):
        def __init__(self, action_args):
            self.action_args = action_args
            self.exit_json_called = False
            self.exit_json_called_with = {}
            self.fail_json_called = False
            self.fail_json_called_with = {}

        def exit_json(self, called_with):
            self.exit

# Generated at 2022-06-11 06:43:20.697993
# Unit test for function main
def test_main():
    os.system('ansible-playbook -i inventory.ini playbook.yml')
#
#

# Generated at 2022-06-11 06:43:35.186282
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-11 06:43:37.952366
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as cm:
        main()
    pytest.raises(AnsibleModule)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:43:48.134180
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common_errno
    from ansible.module_utils import connection
    from ansible.module_utils import six
    from ansible.module_utils import system
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.selinux import get_context_args
    from ansible.module_utils.selinux import get_selinux_enforce_mode
    from ansible.module_utils.selinux import get_selinux_context
    from ansible.module_utils.selinux import selinux_initial_setup
    from ansible.module_utils.selinux import get_selinux_

# Generated at 2022-06-11 06:43:56.785299
# Unit test for function main

# Generated at 2022-06-11 06:44:07.198155
# Unit test for function main

# Generated at 2022-06-11 06:44:17.000150
# Unit test for function main

# Generated at 2022-06-11 06:44:26.200157
# Unit test for function main

# Generated at 2022-06-11 06:44:37.597300
# Unit test for function main
def test_main():
    args = ['sleep','1']
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
        ),
        supports_check_mode=True,
    )
    shell = module.params['_uses_shell']
    chdir = module.params['chdir']
    executable = module.params['executable']
    args = module.params['_raw_params']
    argv = module.params['argv']

# Generated at 2022-06-11 06:44:49.055463
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.constants as C
    C.COMMAND_WARNINGS = True
    m = AnsibleModule(argument_spec={})
    check_command(m, './doesnotexist')
    check_command(m, 'curl')
    check_command(m, 'wget')
    check_command(m, 'tar')
    check_command(m, 'unzip')
    check_command(m, 'svn')
    check_command(m, 'service')
    check_command(m, 'mount')
    check_command(m, 'rpm')
    check_command(m, 'yum')
    check_command(m, 'apt-get')
    check_command(m, 'sed')

# Generated at 2022-06-11 06:44:52.182523
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.warn = lambda x: x
    command = 'pbrun make'

    # make sure pbrun doesn't trigger "command not found" return code
    module.run_command = lambda x: (0, '', '')
    check_command(module, command)

    # make sure pbrun warning occurs
    module.run_command = lambda x: (0, '', '')
    result = check_command(module, command)
    assert "_ansible_suppress_command_warnings" in result



# Generated at 2022-06-11 06:45:37.136638
# Unit test for function main
def test_main():
    # Setup mock args and unittest
    args = {
        'chdir': '/',
        'creates': '/path/to/file',
        'executable': '/bin/bash',
        'removes': '/path/to/file',
        '_uses_shell': False,
        'warn': False,
        '_raw_params': 'echo foo',
        'stdin': 'bar',
        'strip_empty_ends': True,
        'stdin_add_newline': True,
        'check_mode': False,
    }
    module = AnsibleModule(args=args)

    # Run main
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:45:40.771441
# Unit test for function main
def test_main():
    params = {}
    args = {}
    r = {}
    params['_raw_params'] = 'Hello'
    params['executable'] = 'C:/Program Files/Git/bin/bash.exe'
    params['creates'] = 'C:/Users/Josh/Desktop/hello.txt'
    main(params)

main()

# Generated at 2022-06-11 06:45:49.575910
# Unit test for function main
def test_main():
    test_file = 'test_file'

    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}

    args = 'echo hello'
    executable = None
    chdir = None
    creates = None
    removes = None
    warn = True
    stdin = None
    stdin_add_newline = True
    strip = True

    # We promissed these in 'always' ( _lines get autoaded on action plugin)
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}

    #

# Generated at 2022-06-11 06:45:58.434788
# Unit test for function main

# Generated at 2022-06-11 06:46:01.941771
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'echo Hello World')
    check_command(module, '/usr/bin/echo Hello World')
    check_command(module, ['echo', 'Hello', 'World'])



# Generated at 2022-06-11 06:46:11.082796
# Unit test for function main
def test_main():
    import json
    import sys
    # Python 3 renamed json.dumps to json.dumps
    if sys.version_info[0] < 3:
        to_text = unicode
    else:
        to_text = str
    # This is a partial copy of the real module_utils/basic.py, with the important parts for testing here
    class AnsibleModule(object):
        class ModuleFailException(Exception):
            pass
        def __init__(self, argument_spec, supports_check_mode):
            self.params = {}
            for k, v in argument_spec.items():
                self.params[k] = None
            self.check_mode = False
        def run_command(self, cmd, **kwargs):
            return 0, to_text(self.params['_raw_params']).split(), ""
       

# Generated at 2022-06-11 06:46:12.988318
# Unit test for function main
def test_main():
    print("Test")
    assert main() is None

if __name__ == '__main__':
    #test_main()
    main()

# Generated at 2022-06-11 06:46:15.169700
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    check_command(module, 'command')

# ===========================================
# Main control flow


# Generated at 2022-06-11 06:46:24.653010
# Unit test for function main

# Generated at 2022-06-11 06:46:33.892877
# Unit test for function main
def test_main():
    """Unit test for function main"""

# Generated at 2022-06-11 06:48:22.242651
# Unit test for function main
def test_main():
    test_data = dict(
        _raw_params='/bin/date'
    )
    obj = AnsibleModule(argument_spec=test_data)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:48:31.769510
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable
    args = ['/usr/bin/make_database.sh db_user db_name']

# Generated at 2022-06-11 06:48:39.333485
# Unit test for function main
def test_main():

    args = {'_raw_params':"ansible-playbook -i /tmp/inventory -l localhost -vvvv /tmp/playbook.yml", '_uses_shell':True, 'chdir':'/tmp', 'executable':None, 'creates':None, 'removes':None, 'warn':True, 'stdin':None, 'stdin_add_newline':True, 'strip_empty_ends':True}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, **args)

    main()

    # Command Should Fail and return a non-zero exit status
    assert module.exit_json.called


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:48:46.977715
# Unit test for function main

# Generated at 2022-06-11 06:48:53.326166
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="echo hello",
        _uses_shell=False
    )
    check = dict(
        changed=True,
        cmd=['echo', 'hello'],
        delta='0:00:00.002343',
        end='2019-05-22 12:02:52.375638',
        msg='',
        rc=0,
        start='2019-05-22 12:02:52.373295',
        stderr='',
        stdout='hello'
    )