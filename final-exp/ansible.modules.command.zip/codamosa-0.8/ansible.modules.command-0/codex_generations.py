

# Generated at 2022-06-11 06:39:14.989564
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule(argument_spec={})
    check_command(mod, 'ansible-lint /path/to/playbook.yaml')
    check_command(mod, ['yum', 'install', 'git'])
    assert len(mod.warnings) == 2



# Generated at 2022-06-11 06:39:15.742799
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-11 06:39:26.994075
# Unit test for function main
def test_main():

    def test_basic(monkeypatch):
        # basic test

        def mock_init(self):  # pylint: disable=no-self-argument
            return True

        def mock_run_command(self, cmd, **kwargs):  # pylint: disable=unused-argument
            return 0, 'stdout', 'stderr'

        def mock_exit_json(self, **kwargs):  # pylint: disable=unused-argument
            return True

        def mock_fail_json(self, **kwargs):  # pylint: disable=unused-argument
            return True

        # pylint: disable=too-many-arguments

# Generated at 2022-06-11 06:39:36.267859
# Unit test for function main
def test_main():
    # get all the args that would be passed to ansibleModule
    import StringIO
    args = json.load(open('./command_args.json'))
    args['check_mode'] = False
    args['_ansible_diff'] = True
    f = StringIO.StringIO()
    with redirect_stdout(f):
        with pytest.raises(SystemExit) as pytest_wrapped_e:
            main(args)
    # the exception is always a SystemExit with the return code in the .code attribute

# Generated at 2022-06-11 06:39:38.153212
# Unit test for function main
def test_main():
    assert main() is None


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:42.193150
# Unit test for function main
def test_main():
    try:
        from ansible.modules.system.command import main
    except:
        module.fail_json(msg="Error importing main")
    else:
        main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:54.572000
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/chown')
    check_command(module, '/usr/bin/chmod')

    check_command(module, ['/usr/bin/chown', 'test', 'owner'])
    check_command(module, ['/usr/bin/chmod', 'test', 'mode'])
    check_command(module, ['/usr/bin/chgrp', 'test', 'group'])
    check_command(module, ['/usr/bin/ln', 'test', 'state=link'])
    check_command(module, ['/usr/bin/mkdir', 'test', 'state=directory'])
    check_command(module, ['/usr/bin/rmdir', 'test', 'state=absent'])
    check

# Generated at 2022-06-11 06:40:05.857288
# Unit test for function main
def test_main():
    test_env = os.environ.copy()

# Generated at 2022-06-11 06:40:18.624509
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import sys
    import json

    # Get the module arguments from the AnsibleModule object

# Generated at 2022-06-11 06:40:28.079734
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    for cmd in [
        'chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch',
        'curl', 'wget', 'svn', 'service',
        'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip', 'sed',
        'dnf', 'zypper',
        'sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl'
    ]:
        check_command(module, cmd)
    assert module.msg == []



# Generated at 2022-06-11 06:40:49.321009
# Unit test for function main
def test_main():
    import sys
    #from ansible.module_utils import basic
    #m = basic.AnsibleModule(
    #    argument_spec=dict(
    #        _raw_params=dict(),
    #        _uses_shell=dict(type='bool', default=False),
    #        argv=dict(type='list', elements='str'),
    #        chdir=dict(type='path'),
    #        executable=dict(),
    #        creates=dict(type='path'),
    #        removes=dict(type='path'),
    #        # The default for this really comes from the action plugin
    #        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
    #        stdin=dict(required=False),
    #       

# Generated at 2022-06-11 06:40:59.581382
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec = dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:41:10.090705
# Unit test for function main

# Generated at 2022-06-11 06:41:16.865214
# Unit test for function main
def test_main():
    from ansible.module_utils import basic


# Generated at 2022-06-11 06:41:29.533285
# Unit test for function main
def test_main():
    args = "{'_raw_params': ''}"
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 256
    args = "{'_raw_params': '', 'argv': ['test']}"
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 256
    args = "{'_raw_params': '', 'argv': 'test'}"
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped

# Generated at 2022-06-11 06:41:38.383336
# Unit test for function main

# Generated at 2022-06-11 06:41:49.068793
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', default='date'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(type='str'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            # The default for this really comes from the action plugin
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
   

# Generated at 2022-06-11 06:41:59.719000
# Unit test for function main
def test_main():

    # import module snippets
    # basic setup of module object
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )



# Generated at 2022-06-11 06:42:03.246173
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = mock.Mock()
    command = 'test_command'

    check_command(module, command)

    assert module.warn.call_count == 13



# Generated at 2022-06-11 06:42:15.419815
# Unit test for function main
def test_main():
    args = {
        '_raw_params': "/usr/bin/make_database.sh db_user db_name",
        'chdir': 'somedir/',
        'creates': '/path/to/database',
        'removes': None,
        'argv': ["/usr/bin/make_database.sh", "db_user", "db_name"],
        'warn': False,
        'executable': None,
        '_uses_shell': False,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True
    }

# Generated at 2022-06-11 06:42:46.392501
# Unit test for function main
def test_main():
    module = AnsibleModule({}, {'_raw_params': None, 'chdir': None, 'executable': None,
                                'creates': None, 'removes': None, 'warn': False,
                                'stdin': None, 'stdin_add_newline': True,
                                'strip_empty_ends': True, '_uses_shell': False,
                                'argv': None})
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    shoulda = "Would"
    module.exit_json(**r)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:42:58.003461
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # mock run_command
    def run_command(args, **kwargs):
        rc = 0
        stdout = 'skipped, since /foo exists'
        stderr = ''
        if args[0] == 'fail_command':
            rc = 1
            stdout = ''
            stderr = 'a failure'
        elif args[0] == 'echo' and args[1] == 'foo':
            if kwargs.get('encoding', None) == 'utf-8':
                stdout = 'foo\n'
            else:
                stdout = u'foo\n'
        return rc, stdout, stderr

    # mock check_command
    def check_command(module, commandline):
        return

    # mock exit_

# Generated at 2022-06-11 06:43:00.479600
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:43:04.034512
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import tempfile

    d, f = tempfile.mkstemp(dir='/tmp')
    os.write(d,b'')
    os.close(d)
    t = AnsibleExitJson({'rc': 0, 'msg': ''}) 
    try:
        sys.argv = ['command.py', f]
        main()

    finally:
        os.remove(f)

# Generated at 2022-06-11 06:43:12.795395
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    # Do not use assertRaises since we need the Exception message
    failed = False
    try:
        check_command(module, "rm")
    except SystemExit as e:
        failed = True
        assert "Consider using the file module with state=absent rather than running 'rm'." in to_native(e), to_native(e)
    assert failed, 'Did not raise SystemExit for rm'
    failed = False
    try:
        check_command(module, "touch")
    except SystemExit as e:
        failed = True
        assert "Consider using the file module with state=touch rather than running 'touch'." in to_native(e), to_native(e)
    assert failed, 'Did not raise SystemExit for touch'
    failed = False

# Generated at 2022-06-11 06:43:22.612165
# Unit test for function main
def test_main():
    # Stub for function main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils.six import PY3
    module = AnsibleModule({
        '_raw_params': '',
        '_uses_shell': False,
        'argv': '',
        'chdir': '',
        'executable': '',
        'creates': '',
        'removes': '',
        'warn': False,
        'stdin': '',
        'stdin_add_newline': True,
        'strip_empty_ends': True,
    })

# Generated at 2022-06-11 06:43:32.173397
# Unit test for function check_command
def test_check_command():
    bad_commands = ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch',
                    'curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
                    'tar', 'unzip', 'sed', 'sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun']
    alternatives = {'mkdir': 'state=directory', 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}
    for command in bad_commands:
        class FakeModule(object):
            def __init__(self, command):
                self.params = {"cmd": command, "warn": True}

# Generated at 2022-06-11 06:43:41.960383
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

# Generated at 2022-06-11 06:43:51.982393
# Unit test for function main

# Generated at 2022-06-11 06:43:53.571874
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:44:46.111726
# Unit test for function main

# Generated at 2022-06-11 06:44:55.932557
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def run_command_mock(cmd, executable=None, use_unsafe_shell=False, encoding='utf-8', data=None, binary_data=True):
        if cmd == ['echo', 'hello']:
            return 0, 'world', ''
        elif cmd == ['echo', 'hello', 'world']:
            return 0, '', ''
        elif cmd == ['echo', 'hello world']:
            return 0, '', ''
        else:
            return 1, '', ''


# Generated at 2022-06-11 06:44:57.295983
# Unit test for function check_command
def test_check_command():
    from ansible.modules.utilities.logic import chec

# Generated at 2022-06-11 06:45:00.971288
# Unit test for function main
def test_main():
    r = main()
    assert r['rc'] == 0
    assert r['msg'] == ''
    #
    # @TODO add more unit tests
    #
    #
# import module snippets
from ansible.module_utils.basic import *
main()

# Generated at 2022-06-11 06:45:11.590094
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    test_env = {u'ANSIBLE_MODULE_ARGS': {
        u'_raw_params': u'none',
        u'argv': None,
        u'_uses_shell': False,
        u'chdir': None,
        u'creates': None,
        u'removes': None,
        u'executable': None,
        u'warn': False,
        u'stdin': None,
        u'stdin_add_newline': True,
        u'strip_empty_ends': True
        }
    }

# Generated at 2022-06-11 06:45:19.594506
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(module, ['touch', '/tmp/testfile'])
    check_command(module, ['rm', '/tmp/testfile'])
    check_command(module, ['svn', 'co', 'repo', '/tmp/testdir'])
    check_command(module, ['curl', '/tmp/testdir'])
    check_command(module, ['chown', 'tom', '/tmp/testdir'])
    check_command(module, ['chgrp', 'tom', '/tmp/testdir'])
    check_command(module, ['chmod', '0777', '/tmp/testdir'])
    check_command(module, ['yum', 'install', 'epel-release'])

# Generated at 2022-06-11 06:45:24.360031
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.plugins.module_utils import basic
    command = "/bin/id -u"
    args = {
        "_raw_params": command
        }
    c = basic.AnsibleModule(
        argument_spec = {},
        supports_check_mode=True)
    main(c)


# Generated at 2022-06-11 06:45:31.364956
# Unit test for function main
def test_main():
    data = dict(
        executable='/bin/sh',
        args="/sbin/losetup /dev/loop0",
        chdir='/tmp',
        executable='/usr/bin/python',
        stdin="Hello, World!",
        stdin_add_newline=False
    )
    args = dict(
        **data
    )
    mock_module = Mock(AnsibleModule)
    mock_module.check_mode = False
    with patch.object(mock_module, "run_command") as mock_run_command:
        mock_run_command.return_value = (0, "out", "err")
        r = main()
        assert r == (0, "out", "err")

# Generated at 2022-06-11 06:45:41.369545
# Unit test for function main
def test_main():
    my_argv = ['ansible', '-m', 'command', '-a', 'command_to_run', '-c', 'local', 'testhost']
    args = dict(ANSIBLE_MODULE_ARGS={'command': 'command_to_run'})
    set_module_args(args)
    with pytest.raises(AnsibleExitJson) as ex:
        main()

    result = ex.value.args[0]
    assert result['changed'] == True
    assert result['start'] is not None
    assert result['end'] is not None
    assert result['delta'] is not None
    assert result['stdout'] is not None
    assert result['stderr'] is None
    assert result['rc'] == 0
    assert result['cmd'] == ['command_to_run']


# Generated at 2022-06-11 06:45:50.317413
# Unit test for function main

# Generated at 2022-06-11 06:47:38.787695
# Unit test for function main
def test_main():
    # Remove if the function and/or its arguments change
    args = dict()
    args['_raw_params'] = '''/usr/bin/make_database.sh db_user db_name'''
    args['_uses_shell'] = False
    args['argv'] = ['echo', 'hello']
    args['chdir'] = '/tmp'
    args['executable'] = None
    args['creates'] = '/tmp'
    args['removes'] = '/tmp'
    args['warn'] = False
    args['stdin'] = ''
    args['stdin_add_newline'] = True
    args['strip_empty_ends'] = True
    main(args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:47:47.014648
# Unit test for function main
def test_main():
    package = __import__("ansible.builtin.command", fromlist=["Command"])
    stdout = [b"Failed to load fips mode when checking for FIPS support"]
    stderr = [b"Failed to load FIPS compliance module: No module named 'fipscheck'"]
    rc = 1
    setattr(package, "builtin_module_results",
            {"rc": rc, "stdout_b": [stdout], "stderr_b": [stderr]})
    module = {"module": package}

# Generated at 2022-06-11 06:47:56.900938
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """

# Generated at 2022-06-11 06:48:06.014411
# Unit test for function main
def test_main():
    """
    Test method main()
    """
    input_mock_str = 'I am some text'
    output_mock_str = 'I am some text'
    input_mock = mock(return_value=input_mock_str)
    output_mock = mock(return_value=output_mock_str)
    with patch('ansible.modules.packaging.os.path.isdir', input_mock):
        args = {'argv': "['/bin/ls', '-la']", '_raw_params': '', 'chdir': '/home'}
        with patch.object(builtins, 'open') as mock_open:
            main(args)
            input_mock.assert_called_once_with(input_mock_str)
            assert mock_open.called
            output

# Generated at 2022-06-11 06:48:12.164223
# Unit test for function main
def test_main():
    # Dict for command module parameters
    cmd_module_params = dict(
        _raw_params="",
        _uses_shell=False,
        argv=['cat', '/etc/motd'],
        chdir="",
        executable=None,
        creates="",
        removes="",
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

    # Check if main function works as expected
    try:
        main()
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            raise


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:48:16.631266
# Unit test for function main
def test_main():
    args = dict(
        argv=['ls', '-l'],
    )
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params.update(args)
    r = main()
    assert(r['cmd'] == ['ls', '-l'])


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:48:18.116266
# Unit test for function main
def test_main():
    assert main() is None


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:48:25.380376
# Unit test for function main
def test_main():
    # Test case 1: modules_main_1
    print('*** Test Case 1: modules_main_1 ***')
    print('Test 1: Test case when no args or command is given')

# Generated at 2022-06-11 06:48:32.880827
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warn = False
            self.warn_msg = "add warning msg"
        def warn(self,msg):
            self.warn_msg = msg
            self.warn = True

    test_mod = FakeModule()
    check_command(test_mod, ['apt-get', 'install', 'apache2'])
    assert test_mod.warn == True
    assert 'Consider using the apt module rather than running apt-get.  If you need to use apt-get because the apt module is insufficient you can add \'warn: false\' to this command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get rid of this message.' == test_mod.warn_msg
    test_mod.warn = False

# Generated at 2022-06-11 06:48:41.557417
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_iterable

    # the command module is the one ansible module that does not take key=value args
    # hence don't copy this one if you are looking to build others!
    # NOTE: ensure splitter.py is kept in sync for exceptions