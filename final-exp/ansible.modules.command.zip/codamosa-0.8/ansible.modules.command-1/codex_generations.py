

# Generated at 2022-06-11 06:39:13.657098
# Unit test for function main
def test_main():
    # Test with _raw_params as an empty string
    module_returned = {}
    module_mock = AnsibleModule({'_raw_params': '', '_uses_shell': False})
    module_mock.exit_json = lambda x: module_returned.update(x)
    main()
    assert module_returned['rc'] == 256
    assert module_returned['msg'] == 'no command given'

    # Test with argv as an empty list
    module_returned = {}
    module_mock = AnsibleModule({'argv': [], '_uses_shell': False})
    module_mock.exit_json = lambda x: module_returned.update(x)
    main()
    assert module_returned['rc'] == 256

# Generated at 2022-06-11 06:39:23.948342
# Unit test for function main

# Generated at 2022-06-11 06:39:25.266564
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:35.762694
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import type_is_iterable
    from ansible.module_utils.common.collections import type_is_sequence
    from ansible.module_utils.basic import AnsibleModule

    argv = ['cd', '-l', '-a']
    argv_unicode = [to_text(item, encoding='utf-8') for item in argv]


# Generated at 2022-06-11 06:39:45.670927
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.warnings = []
            for k, v in kwargs.items():
                self.__dict__[k] = v
        def warn(self, warning):
            self.warnings.append(warning)
    module = FakeModule(
        command_warnings=True,
    )
    check_command(module, 'chown root /tmp/foo')
    assert len(module.warnings) == 1
    check_command(module, 'wget http://www.example.com')
    assert len(module.warnings) == 2
    check_command(module, 'tar -jxf /var/tmp/foo.tar.bz2')
    assert len(module.warnings) == 3

# Generated at 2022-06-11 06:39:52.114395
# Unit test for function check_command
def test_check_command():
    import sys
    import io
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    stdout = StringIO()
    stderr = StringIO()
    sys.stdout = stdout
    sys.stderr = stderr

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(type='list', elements='str', default=['echo', 'hello'])
        )
    )

    check_command(module, 'touch /tmp/test_file')
    check_command(module, 'mount')
    check_command(module, ['svn', 'update'])
    check_command(module, ['foo', 'bar'])

    assert 'Consider using the module' in stdout.getvalue()

    # Note: test

# Generated at 2022-06-11 06:40:00.507834
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command') as mock_run_command:
        # This items should be returned from the run_command mock
        mock_run_command.return_value = (0, 'Stdout', 'Stderr')

# Generated at 2022-06-11 06:40:13.334083
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def warn(self, msg):
            raise Exception(msg)

    class TestModule2(object):
        def warn(self, msg):
            pass

    command = 'ls'
    module = TestModule()
    try:
        check_command(module, command)
    except Exception as e:
        assert "Consider using the file module with state=directory rather than running '%s'." % (command,) in to_text(e)
    command = 'chown user file'
    try:
        check_command(module, command)
    except Exception as e:
        assert "Consider using the file module with owner=user rather than running '%s'." % (command,) in to_text(e)
    command = 'chmod 777 file'

# Generated at 2022-06-11 06:40:23.680587
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    import json
    import sys
    import os

# Generated at 2022-06-11 06:40:28.773762
# Unit test for function main
def test_main():
    argv = ['']
    argv[0] = "ansible.builtin.command"
    argv.append("/usr/bin/make_database.sh db_user db_name creates=/path/to/database")
    assert(main(argv) == 0)

# Generated at 2022-06-11 06:40:54.742463
# Unit test for function main
def test_main():
    __salt__ = {
        'cmd.has_exec': MagicMock(return_value=True),
        'cmd.run_all': MagicMock(return_value={'retcode': 0, 'stdout': '', 'stderr': ''})
    }
    __grains__ = {
        'kernel': 'Linux'
    }
    __opts__ = {
        'test': False,
    }
    with patch.dict(modules.ansible_command.__opts__, __opts__), \
            patch.dict(modules.ansible_command.__salt__, __salt__), \
            patch.dict(modules.ansible_command.__grains__, __grains__):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:05.677067
# Unit test for function main
def test_main():
    """
    Autogenerated doctest for function main
    """
    args = dict(warning=dict(),_raw_params=dict(default=None,choices=None,no_log=False,type='str'))
    data = dict(_ansible_module_create_mode='command', _ansible_no_log=False, _ansible_module_name='command',
                ansible_shell_type='sh', _ansible_verbosity=4)
    module = AnsibleModule(argument_spec=args, supports_check_mode=True, bypass_checks=False)
    # We do not currently test the recursive generators
    def test_gen(a):
        yield a
    module.run_command = (lambda x, **kwargs: (0, '', ''))

# Generated at 2022-06-11 06:41:06.997971
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:15.040020
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text


# Generated at 2022-06-11 06:41:19.007122
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    #Test with command not in become
    check_command(module, 'rm file')
    # Test with command in become
    check_command(module, 'sudo apt')

# Backwards compat
from ansible.module_utils.basic import get_exception



# Generated at 2022-06-11 06:41:31.672534
# Unit test for function main
def test_main():

    import sys
    sys.path.append("../")
    import test.driver_utils as driver_utils
    import os

    args = driver_utils.hack_args(module_name='command', group='command',
                                  action='run', cmd= "/bin/true")
    module_args = dict(
        _raw_params=args.cmd,
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        removes=None,
        warn=True)
    new_module = AnsibleModule(module_args)
    old_module = sys.modules["ansible.builtin.raw"]
    sys.modules["ansible.builtin.raw"] = new_module
    old_cwd = os.getcwd()
    os.chdir("/tmp")


# Generated at 2022-06-11 06:41:39.832646
# Unit test for function main
def test_main():
    import sys
    import json

    # save the original sys.argv
    prev_sys_argv = list(sys.argv)

    # prepare new sys.argv
    sys.argv = ['']

    # try to execute the module function
    with open('/tmp/ansible_command_result.json', 'r') as result_fd:
        module_results = json.load(result_fd)
        rc = module_results.get('rc', None)
        failed = module_results.get('failed', None)
        changed = module_results.get('changed', None)
        msg = module_results.get('msg', None)
        module = AnsibleModule(argument_spec = dict())
        result = main()

    # compare the results:
    assert result.get('rc') == rc

# Generated at 2022-06-11 06:41:50.597491
# Unit test for function main

# Generated at 2022-06-11 06:42:00.767319
# Unit test for function main
def test_main():
    import pytest
    import subprocess
    import uuid
    command = ['python', '-c', 'print("command")']
    chdir = '/tmp' 
    executable = '/usr/bin/python' 
    argv = ['python', '-c', 'print("argv")']
    creates = '/tmp/unit-test-file-' + str(uuid.uuid4())
    removes = '/tmp/unit-test-file-' + str(uuid.uuid4())
    warn = True
    stdin = '/tmp/unit-test-file-' + str(uuid.uuid4())
    stdin_add_newline = True
    strip = True

# Generated at 2022-06-11 06:42:09.290514
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    args = dict()
    module = AnsibleModule(argument_spec=args)
    msg = "Consider using the file module with chown rather than running 'chown'.  " \
          "If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    module.warn = lambda x : None
    check_command(module, 'chown user:group path/file')
 


# Generated at 2022-06-11 06:42:29.992814
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    args = ['ls']
    module.params['_raw_params'] = args
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:42:41.666081
# Unit test for function main
def test_main():

    import sys
    import os
    import time

    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def test_run_command(args, executable=None, use_unsafe_shell=False, encoding=None, data='', binary_data=False):
        return 0, '', '',

    class TestAnsibleModule(AnsibleModule):
        def exit_json(self, **kwargs):
            raise AnsibleExitJson(kwargs)

        def fail_json(self, **kwargs):
            raise AnsibleFailJson(kwargs)

    def mock_check_command(module, commandline, warn=False):
        pass

    m

# Generated at 2022-06-11 06:42:44.388352
# Unit test for function main
def test_main():
    with pytest.raises(FailJsonException) as exc:
        main()
    print('Info: %s' % exc.value.args[0]['msg'])

# Generated at 2022-06-11 06:42:56.183910
# Unit test for function check_command
def test_check_command():
    class TestModule:
        def __init__(self, *args, **kwargs):
            self.warnings = []
            pass

        def warn(self, warning):
            self.warnings.append(warning)

    module = TestModule()
    check_command(module, ['chmod'])
    assert module.warnings == ["Consider using the file module with mode rather than running 'chmod'.  "
           "If you need to use 'chmod' because the file module is insufficient you can add "
           "'warn: false' to this command task or set 'command_warnings=False' in "
           "the defaults section of ansible.cfg to get rid of this message."]
    module.warnings = []
    check_command(module, ['chown'])

# Generated at 2022-06-11 06:43:06.174810
# Unit test for function main

# Generated at 2022-06-11 06:43:09.051835
# Unit test for function check_command
def test_check_command():
    pass
# Note: The argspec is described in the source code directly since we use
# the AnsibleModule argument spec to create arguments.  The warning
# suppressions are imported in ActionModule
# pylint: disable=arguments-differ, missing-docstring, no-self-use, redefined-builtin



# Generated at 2022-06-11 06:43:19.218667
# Unit test for function main
def test_main():
    # If a command is successfully run, rc is 0 and changed status is True.
    # If the command fails to execute, rc is not 0 and changed status is False.
    # If we do not get an output from the command execution, return an error.

    # Empty args and argv
    args = ''
    argv = ''
    command = '/usr/bin/ls'
    rc = 1
    changed = False
    stdout = None
    stderr = None
    # When there is no command given, return rc 256 and error.
    returned_rc, returned_stdout, returned_stderr = module.run_command(args, executable=command)
    assert returned_rc == rc
    assert returned_stdout == stdout
    assert returned_stderr == stderr

    # File exists

# Generated at 2022-06-11 06:43:28.319631
# Unit test for function main
def test_main():
    check_output_module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:43:29.918588
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:43:40.011424
# Unit test for function main
def test_main():
  args = {'_raw_params': 'ls', '_uses_shell': False}
  r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
  with open('test_data/out', 'r') as ansible_output:
    with open('test_data/expected_data', 'r') as expected_data:
      from ansible.module_utils import basic
      from ansible.module_utils._text import to_bytes, to_text
      m = basic.AnsibleModule(argument_spec={}, supports_check_mode=False)
      r['cmd'] = args['_raw_params']

# Generated at 2022-06-11 06:44:24.213846
# Unit test for function main
def test_main():
    testArgs = {
        "chdir": "/home/sample",
        "executable": None,
        "creates": "/home/sample/testfile",
        "removes": None,
        "warn": False,
        "_raw_params": "ls",
        "_uses_shell": False,
        "stdin": None,
        "stdin_add_newline": True,
        "strip_empty_ends": True,
        "argv": None,
    }

# Generated at 2022-06-11 06:44:30.198757
# Unit test for function main
def test_main():
    os.environ['ANSIBLE_MODULE_ARGS'] = json.dumps({'chdir': 'somedir/', '_raw_params': '/usr/bin/make_database.sh db_user db_name', '_uses_shell': True, 'args': {'creates': '/path/to/database'}})
    args = os.environ['ANSIBLE_MODULE_ARGS']
    result = main()
    assert True

# Generated at 2022-06-11 06:44:41.874826
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 06:44:52.907539
# Unit test for function main
def test_main():
    args = dict(
            argv=['/usr/bin/make_database.sh', 'db_user', 'db_name', 'creates=/path/to/database'],
            chdir='somedir/',
            stdin='This is the input',
            warn=True
            )


# Generated at 2022-06-11 06:45:02.397179
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        chdir='/root/',
        executable='/bin/sh',
        creates='~/test_file.txt',
        removes='~/test_file.txt',
        warn=True,
        stdin='This is a test'
    )

# Generated at 2022-06-11 06:45:12.888106
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    shell = module

# Generated at 2022-06-11 06:45:19.089206
# Unit test for function main
def test_main():
    module = mock.Mock()
    module.run_command = mock.Mock()
    module.run_command.return_value = 0, "hello", ""
    args = {'creates': '', 'removes': ''}
    module.params = args
    module.exit_json = mock.Mock()
    module.exit_json.return_value = "hello"
    module.exit_json.return_value = ""
    module.fail_json = mock.Mock()
    module.fail_json.return_value = ""

    result = main()
    assert result == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:45:27.451355
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        "_raw_params": "cat /etc/passwd",
        "chdir": "./ansible/test/units/modules/utilities/command",
        "_uses_shell": "False",
        "creates": "/etc/passwd.yml",
        "removes": "/etc/passwd.yml",
        "warn": "False",
        "stdin": "",
        "stdin_add_newline": "True",
        "strip_empty_ends": "True",
        "argv": "",
    }, check_invalid_arguments=False)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:45:34.536303
# Unit test for function check_command
def test_check_command():
    fake_module = type('AnsibleModule', (), {'warn': lambda self, warn: print(warn)})
    check_command(fake_module, "/usr/bin/chown root /etc/passwd")
    check_command(fake_module, "chmod 600 /etc/sudoers")
    check_command(fake_module, "/bin/chgrp wheel /etc/sometest")
    check_command(fake_module, "/bin/ln /usr/bin/python /usr/bin/python2")
    check_command(fake_module, "/bin/mkdir /usr/local/test")
    check_command(fake_module, "/bin/rmdir /usr/local/test")
    check_command(fake_module, "/bin/rm -f /usr/local/test")

# Generated at 2022-06-11 06:45:38.705238
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_args = ['-v']
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:47:13.617903
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils import basic

    import json
    import shlex

    module_args = {}
    module_args.update(
        dict(
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        )
    )
    # we promissed these in 'always' ( _lines get autoaded on action plugin

# Generated at 2022-06-11 06:47:21.694892
# Unit test for function main

# Generated at 2022-06-11 06:47:25.994901
# Unit test for function check_command
def test_check_command():
    module = None
    commandline_list = ['/usr/bin/yum', 'install', '-y', 'foo']
    commandline_str = '/usr/bin/yum install -y foo'
    try:
        check_command(module, commandline_list)
        check_command(module, commandline_str)
    except:
        print('check_command function test error with list and string arguments')



# Generated at 2022-06-11 06:47:33.302676
# Unit test for function main
def test_main():
    test_module_parameters = dict(
        _raw_params="ls -al",
        executable="/bin/bash",
        chdir="/",
        creates=None,
        removes=None,
        warn=True
    )


# Generated at 2022-06-11 06:47:37.747726
# Unit test for function main
def test_main():
    module_args = dict(
        argv=["/usr/sbin/gluster", "--version"],
        executable="/usr/sbin/gluster"
    )
    because = dict(
        module_args=module_args
    )
    # Silent output is broken
    #with pytest.raises(SystemExit) as excinfo:
    #    with silenced(open, os.open):
    #        main()
    main()


# Generated at 2022-06-11 06:47:45.893078
# Unit test for function main

# Generated at 2022-06-11 06:47:55.111284
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False, type='str'),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 06:48:05.051001
# Unit test for function main
def test_main():
    argv = [to_bytes('ansible-playbook'), to_bytes('playbook.yml'), to_bytes('-b')]
    stdout = b'Hello World\n'
    stderr = b''
    rc = 0

# Generated at 2022-06-11 06:48:10.547914
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=None,
        strip_empty_ends=None,
        _uses_shell=False,
        argv=None
    )
    module_mock = AnsibleModule(argument_spec=dict())
    module_mock.params = args
    module_mock.run_command = run_command_mock
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:48:14.960132
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.warnings import AnsibleModuleWarning
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.deprecate('test', 'test', '2.13')
    try:
        check_command(module, 'chmod 777 /var/tmp/something')
    except AnsibleModuleWarning:
        pass

