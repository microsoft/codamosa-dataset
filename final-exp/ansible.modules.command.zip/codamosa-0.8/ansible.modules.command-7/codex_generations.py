

# Generated at 2022-06-11 06:39:12.208313
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    class TestModule(object):
        def __init__(self, module, commandline):
            self.commandline = commandline
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)

    def test(commandline, expected):
        tm = TestModule(module, commandline)
        check_command(tm, tm.commandline)
        assert tm.warnings == expected, (commandline, expected, tm.warnings)

    test('cat /etc/motd', [])

# Generated at 2022-06-11 06:39:15.954789
# Unit test for function check_command
def test_check_command():
    # TODO: write unit test for check_command
    from ansible.modules.commands.command import check_command
    try:
        check_command('', '')
    except NameError as e:
        raise Exception('Test exception: %s' % e)


# Generated at 2022-06-11 06:39:27.225954
# Unit test for function main
def test_main():
    # Test with exec
    args = {
        '_raw_params': 'echo hello world',
        'executable': '/bin/bash',
        'chdir': './',
        'creates': './test_dir',
        'removes': './test_dir',
        'warn': 'yes',
        'stdin': 'hello',
        'stdin_add_newline': 'yes',
        'strip_empty_ends': 'yes'
    }
    module = AnsibleModule(argument_spec={})
    module.params = args
    main()
    # Test without exec

# Generated at 2022-06-11 06:39:36.426026
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    magic_symbol = '${MAGIC_SYMBOL}'
    args = "%s/bin/python --version" % magic_symbol
    if not module.check_mode:
        r['start'] = datetime.datetime.now()
        r['rc'], r['stdout'], r['stderr'] = module.run_command(args, use_unsafe_shell=True, encoding=None, data=None)
        r['end'] = datetime.datetime.now

# Generated at 2022-06-11 06:39:38.784199
# Unit test for function main
def test_main():
    print("Testing function main")
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:40.560038
# Unit test for function check_command
def test_check_command():
    module = ""
    command = "echo hello"
    assert check_command(module, command) is None



# Generated at 2022-06-11 06:39:43.815407
# Unit test for function main
def test_main():
    a = AnsibleModule()
    r = []
    r['rc'] = 0
    print("main")
    print(r)
    return r


# Generated at 2022-06-11 06:39:55.915179
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = ['ln', '-s', 'A', 'B']
    check_command(module, commandline)
    assert module.warnings[0].startswith("Consider using the file module with state=link rather than running")
    assert module.warnings[1].startswith("Consider using 'become', 'become_method', and 'become_user' rather than running")

    commandline = ['touch', 'foo.txt']
    check_command(module, commandline)
    assert module.warnings[2].startswith("Consider using the file module with state=touch rather than running")

    commandline = ['mkdir', 'foo.txt']
    check_command(module, commandline)

# Generated at 2022-06-11 06:40:07.156838
# Unit test for function main
def test_main():
    os.chdir(os.path.dirname(os.path.realpath(__file__)))

# Generated at 2022-06-11 06:40:19.774525
# Unit test for function main
def test_main():
    import mock
    # We can't use unit test for this. We need to mock the module_utils/basic.py to
    # exit from the module, so this is an integration test.
    #module = AnsibleModule(argument_spec={})
    # We use a patched AnsibleModule.
    class PatchedAnsibleModule(object):
        class ExitJsonException(Exception):
            pass

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            self.params = kwargs.get('argument_spec', {})

        def fail_json(self, **kwargs):
            raise PatchedAnsibleModule.ExitJsonException(kwargs)

        def exit_json(self, **kwargs):
            raise PatchedAnsibleModule.Exit

# Generated at 2022-06-11 06:40:40.720328
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self, **kwargs):
            pass

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            pass

        def warn(self, msg):
            pass

    # pylint: disable=no-self-use, unused-argument
    class FakeAnsibleModule(FakeModule):
        def __init__(self, **kwargs):
            params = kwargs.pop('params', {})
            super(FakeAnsibleModule, self).__init__(**kwargs)
            self.params = params
            self.cp = CommandRunner(self)

    class CommandRunner(FakeModule):
        def __init__(self, module):
            super(CommandRunner, self).__init__(module=module)

# Generated at 2022-06-11 06:40:46.589803
# Unit test for function main
def test_main():
    args = ['/bin/echo', 'success']
    r = {'changed': True, 'stdout': 'success', 'stderr': '', 'rc': 0, 'cmd': args, 'start': '2017-09-29 22:03:48.083128', 'end': '2017-09-29 22:03:48.084657', 'delta': '0:00:00.001529'}
    result = main()
    assert result == r


# Generated at 2022-06-11 06:40:55.954386
# Unit test for function main
def test_main():
    # Remove if the plugin class above has examples to prepopulate the result dict
    result = dict(
        msg='',
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
    )

    # the command module is the one ansible module that does not take key=value args
    # hence don't copy this one if you are looking to build others!
    # NOTE: ensure splitter.py is kept in sync for exceptions

# Generated at 2022-06-11 06:41:06.825627
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import copy

    # Make test unit for function 'main'
    def _main(self):
        argv = ['/bin/true']
        self.run_command.return_value = (0, b'out', b'err')
        with self.assertRaises(basic.AnsibleExitJson) as result:
            main()
        result = result.exception.args[0]
        self.assertEqual(result['cmd'], argv)
        self.assertEqual(result['rc'], 0)
        self.assertEqual(result['stdout'], 'out')
        self.assertEqual(result['stderr'], 'err')

    # Make test unit for function '_check_command

# Generated at 2022-06-11 06:41:08.137338
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:15.746920
# Unit test for function main
def test_main():

    results = {}
    # Update to match string returned from module (this will be removed once module is ported to Python 3)
    stdout_valid = "Clustering node rabbit@slave1 with rabbit@master …\n\nClustered 1 nodes in 0.02 seconds."

    return_value = {'rc':1, 'stdout': 'hello world', 'stdout_lines': ['hello world']}

    # Get the module parameters passed from the Ansible command
    module_args = dict()

    results.update(return_value)

# Generated at 2022-06-11 06:41:17.073333
# Unit test for function main
def test_main():
    # Command module: main function
    pass


# Generated at 2022-06-11 06:41:29.785102
# Unit test for function main
def test_main():
    # This is the list of varibles that would be passed to the main function
    module_args = {'executable':None,'_raw_params': 'ls -la','_uses_shell': True}
    argv = 'ls -la'
    args = shlex.split(argv)
    # This is to be used for unittest only
    setattr(module, 'params', module_args)
    module.run_command = lambda x, **kargs: (0, '', '')
    # This creates an instance of the AnsibleModule object
    module_instance = AnsibleModule(module_args)
    # Assign the module's exit_json and fail_json methods to local vars
    exit_json = module_instance.exit_json
    fail_json = module_instance.fail_json
    # Update module's params with

# Generated at 2022-06-11 06:41:38.552343
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    import json
    import os
    import shutil
    import tempfile
    import time
    import pytest
    import os
    import shutil
    import tempfile
    import time
    import pytest
    # idempotence test

# Generated at 2022-06-11 06:41:49.211418
# Unit test for function main

# Generated at 2022-06-11 06:42:19.195265
# Unit test for function main
def test_main():
    args = {}
    args['_raw_params'] = 'foo bar'
    args['_uses_shell'] = True
    args['chdir'] = '/tmp'
    args['creates'] = '/tmp/abc'
    args['removes'] = '/tmp/def'
    args['warn'] = False
    args['stdin'] = ''
    args['stdin_add_newline'] = False
    args['strip_empty_ends'] = False
    main(module=AnsibleModule(argument_spec=args))


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:42:30.362708
# Unit test for function main
def test_main():
    test_dict = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo hello'],
        chdir='',
        executable=None,
        creates='',
        removes='',
        warn=True,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg=''
    )


# Generated at 2022-06-11 06:42:34.148549
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as exec_info:
        main()
    assert exec_info.value.args[0]['rc'] == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:42:45.677038
# Unit test for function main

# Generated at 2022-06-11 06:42:57.423609
# Unit test for function check_command
def test_check_command():
    module = MockModule()
    check_command(module, '/usr/bin/curl')
    check_command(mock_module, ['/usr/bin/wget', '-q'])
    check_command(mock_module, '/usr/bin/svn')
    check_command(mock_module, '/sbin/service')
    check_command(mock_module, '/bin/mount')
    check_command(mock_module, '/usr/bin/rpm')
    check_command(mock_module, '/usr/bin/yum')
    check_command(mock_module, '/usr/bin/apt-get')
    check_command(mock_module, '/bin/tar')
    check_command(mock_module, '/usr/bin/unzip')

# Generated at 2022-06-11 06:43:07.116280
# Unit test for function main
def test_main():

    # mock -m module_utils.basic.AnsibleModule
    class MockAnsibleModule:
        def __init__(self):
            self.params = {
                '_raw_params': '',
                '_uses_shell': False,
                'argv': [],
                'chdir': '',
                'executable': '',
                'creates': '',
                'removes': '',
                'warn': False,
                'stdin': None,
                'stdin_add_newline': True,
                'strip_empty_ends': True,
                'support_check_mode': True
            }
        def exit_json(self, **kwargs):
            print(kwargs)
        def fail_json(self, **kwargs):
            print(kwargs)

# Generated at 2022-06-11 06:43:10.749438
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(supports_check_mode=True, argument_spec={})
    check_command(module, "/usr/bin/yum install foo")
    assert 'Consider using the yum module rather than running \'yum\'.' in ''.join(module.warnings)



# Generated at 2022-06-11 06:43:14.585153
# Unit test for function main
def test_main():
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:43:24.011219
# Unit test for function check_command
def test_check_command():
    import tempfile

    class WarnHandler(object):
        def __init__(self):
            self.warnings = []
        def __call__(self, msg):
            self.warnings.append(msg)

    warnings = WarnHandler()

    test_module = AnsibleModule({}, supports_check_mode=True, warnings=warnings)


# Generated at 2022-06-11 06:43:33.817536
# Unit test for function check_command
def test_check_command():
    # no error is raised
    check_command(AnsibleModule, ['/bin/command', 'arg1', 'arg2'])

    class MockModule(object):
        def __init__(self):
            self.warning = []

        def warn(self, warning):
            self.warning.append(warning)

    module = MockModule()

    # First tests are for string commands
    check_command(module, '/bin/ln arg1 arg2')
    assert len(module.warning) == 1, 'ln should warn'
    check_command(module, '/bin/mkdir arg1')
    assert len(module.warning) == 2, 'mkdir should warn'
    check_command(module, '/bin/rmdir arg1')
    assert len(module.warning) == 3, 'rmdir should warn'
    check_

# Generated at 2022-06-11 06:44:25.292909
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/usr/bin/make_database.sh db_user db_name',
        chdir='somedir/',
        creates='/path/to/database',
    )
    check_args(args)

    args = dict(
        cmd='/usr/bin/make_database.sh db_user db_name',
        chdir='somedir/',
        creates='/path/to/database',
    )
    check_args(args)

    args = dict(
        _raw_params='/usr/bin/make_database.sh db_user db_name',
        chdir='somedir/',
        creates='/path/to/database',
        _uses_shell=True,
    )
    check_args(args)


# Generated at 2022-06-11 06:44:36.568047
# Unit test for function main
def test_main():
    res = {}

# Generated at 2022-06-11 06:44:48.054171
# Unit test for function main
def test_main():

    # Unit test for function main
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            # The default for this really comes from the action plugin
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:44:52.059072
# Unit test for function main
def test_main():
    r = dict(changed = False, failed = False, msg = 'non-zero return code', stdout = "", stderr = "", rc = 0, cmd = '')
    assert(main() == r)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:44:54.893298
# Unit test for function check_command
def test_check_command():
    cmd = 'curl'
    argv = ['curl', 'www.example.com']
    commandline = 'curl'
    assert check_command(cmd, argv)
    assert check_command(cmd, commandline)

# Given a string command line, return a list of strings of the tokens

# Generated at 2022-06-11 06:45:04.780408
# Unit test for function check_command
def test_check_command():
    class ModuleTest(AnsibleModule):
        pass
    module = ModuleTest(
        argument_spec=dict(),
    )
    check_command(module, '/usr/bin/apt-get -y install python')
    assert module.warnings == ["Consider using the apt module rather than running 'apt-get'.  If you need to use 'apt-get' because the apt module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]

# This function checks for an existing file in two ways.
# First, it checks if the given path exists and is a file.
# Second, if the given path is a symbolic link, it checks
# the target of the symbolic link.

# Generated at 2022-06-11 06:45:14.995426
# Unit test for function main
def test_main():
    # Test module arguments
    args = dict(
        _raw_params='module',
        _uses_shell=True,
        argv=['module', 'parameters'],
        chdir=os.path.abspath(os.path.join(os.path.dirname(__file__), '..')),
        executable=None,
        creates='',
        removes='',
        warn=True,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

    # Module execution

# Generated at 2022-06-11 06:45:25.100619
# Unit test for function main

# Generated at 2022-06-11 06:45:31.924695
# Unit test for function main
def test_main():
    import sys
    import inspect
    import argparse
    import json
    import collections

# Generated at 2022-06-11 06:45:41.491862
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': {'type': 'str'}})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-11 06:46:49.224173
# Unit test for function check_command
def test_check_command():
    assert check_command("command", "echo") == "echo"
    assert check_command("command", "chown") == "chown"
    assert check_command("command", "chmod") == "chmod"
    assert check_command("command", "chgrp") == "chgrp"
    assert check_command("command", "ln") == "ln"
    assert check_command("command", "mkdir") == "mkdir"
    assert check_command("command", "rmdir") == "rmdir"
    assert check_command("command", "rm") == "rm"
    assert check_command("command", "touch") == "touch"
    assert check_command("command", "curl") == "curl"
    assert check_command("command", "wget") == "wget"
    assert check_command

# Generated at 2022-06-11 06:46:56.090606
# Unit test for function main

# Generated at 2022-06-11 06:47:05.412433
# Unit test for function main
def test_main():
    # any tests you wish to run on ansible.builtin.command can be added in here
    # make sure you are testing the full path to the function
    cmd = "/usr/bin/ansible-lint"

# Generated at 2022-06-11 06:47:07.343973
# Unit test for function main
def test_main():
    print("Beginning tests")

    # Perform tests
    # assert main() == "Success"

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:47:15.752729
# Unit test for function main
def test_main():
    # test main function for missing/invalid/default params
    mock_args = dict(
    )
    mock_main = MagicMock(side_effect=main)
    mock_module = MagicMock()
    mock_args = dict(
        _raw_params='',
        _uses_shell=False,
        argv=[],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    with patch('ansible.module_utils.basic.AnsibleModule', return_value=mock_module):
        mock_module.params = mock_args
        main()
        main()
        main()
        main()

# Generated at 2022-06-11 06:47:23.670360
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 06:47:30.996667
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/foo')
    assert module.warnings == []

    check_command(module, '/usr/bin/chown')
    assert module.warnings == ['Consider using the file module with owner rather than running '
                               "'chown'.  If you need to use 'chown' because the file module is "
                               'insufficient you can add \'warn: false\' to this command task or '
                               'set \'command_warnings=False\' in the defaults section of ansible.cfg '
                               "to get rid of this message."]

    check_command(module, '/usr/bin/svn')

# Generated at 2022-06-11 06:47:38.420963
# Unit test for function main
def test_main():
    # Test case 1
    args = {"_raw_params":"'echo hello'","_uses_shell":False,"creates":None,"argv":None,"removes":None,"chdir":None,"stdin_add_newline":True,"executable":None,"strip_empty_ends":True,"stdin":None,"warn":False}
    main()

    # Test case 2
    args = {"_raw_params":"'echo hello'","_uses_shell":False,"creates":None,"argv":None,"removes":None,"chdir":None,"stdin_add_newline":True,"executable":None,"strip_empty_ends":True,"stdin":None,"warn":False}
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:47:46.552030
# Unit test for function main
def test_main():
    from ansible.modules.commands.command import main
    import sys
    import os
    import json
    import subprocess

    fd, path = tempfile.mkstemp()
    os.close(fd)

    with open(path, 'w+') as f:
        f.write("test")

# Generated at 2022-06-11 06:47:56.211203
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable
