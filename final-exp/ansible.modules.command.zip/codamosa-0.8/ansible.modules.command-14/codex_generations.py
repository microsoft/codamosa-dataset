

# Generated at 2022-06-11 06:39:13.658864
# Unit test for function main
def test_main():
    import sys, StringIO
    from ansible.utils.color import ansi_wrap
    from ansible.modules.command import main as cmd
    from ansible.module_utils.basic import AnsibleModule

    out = StringIO.StringIO()
    old = sys.stdout
    sys.stdout = out

    r = {'changed': False, 'rc': None, 'stderr': '', 'stdout': ''}

    # tests
    if sys.version_info < (2, 7):
        # python 2.6
        assert '{0}' == ansi_wrap("{0}")
    else:
        # python 2.7
        assert '\x1b[1;32m{0}\x1b[0m' == ansi_wrap("{0}")


# Generated at 2022-06-11 06:39:20.914415
# Unit test for function main
def test_main():
    # run tests without _raw_params
    params = {}
    params["creates"] = 'path/to/file'
    params["executable"] = 'shell'
    params["chdir"] = 'path/to/dir'
    params["removes"] = 'path/to/file'
    params["warn"] = False
    params["_raw_params"] = None
    params["argv"] = 'foo/bar/file'
    params["_uses_shell"] = False
    module = AnsibleModule(argument_spec=dict())
    result = main()
    assert result["changed"] == False

# Generated at 2022-06-11 06:39:32.364000
# Unit test for function main
def test_main():
    args = dict(
        #_raw_params='netstat -antup',
        _raw_params='ls -lrt',
        #_raw_params='hostname',
        _uses_shell = False,
        argv=['ls', '-lrt'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp',
        removes='/tmp',
        # The default for this really comes from the action plugin
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

    main()

    main(dict(_raw_params="netstat -antup", _uses_shell = False))

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:37.352423
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='cat /etc/motd',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        stdin=None,
        warn=True,
        strip_empty_ends=True
    )

# Generated at 2022-06-11 06:39:46.342728
# Unit test for function main
def test_main():
    module = DummyModule()
    args = {
        "_raw_params": "",
        "_uses_shell": False,
        "argv": [
        ],
        "chdir": None,
        "creates": None,
        "executable": None,
        "removes": None,
        "stdin": None,
        "stdin_add_newline": True,
        "strip_empty_ends": True,
        "warn": False
    }
    r = {
        "changed": None,
        "cmd": None,
        "delta": None,
        "end": None,
        "msg": None,
        "rc": None,
        "start": None,
        "stderr": None,
        "stdout": None
    }
    setattr(module, "params", args)

# Generated at 2022-06-11 06:39:57.312493
# Unit test for function main

# Generated at 2022-06-11 06:39:59.019574
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'sudo ls -l')



# Generated at 2022-06-11 06:40:11.078152
# Unit test for function main
def test_main():
    myDict = {}
    myDict['_raw_params'] = ""
    myDict['_uses_shell'] = 'false'
    myDict['argv'] = "cat /etc/motd"
    myDict['chdir'] = "/etc"
    myDict['executable'] = "cat /etc"
    myDict['creates'] = "/etc"
    myDict['removes'] = "/etc/motd"
    myDict['warn'] = "false"
    myDict['stdin'] = False
    myDict['stdin_add_newline'] = "True"
    myDict['strip_empty_ends'] = "True"

    main(dict(myDict))

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:40:14.689277
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson) as exec_info:
        main()
    assert 'no command given' in str(exec_info)

# Generated at 2022-06-11 06:40:16.056006
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    assert check_command(m, 'apt-get install')
    assert check_command(m, 'mkdir')


# Generated at 2022-06-11 06:40:42.854122
# Unit test for function main
def test_main():
    # Instantiation of module class
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'))
        )
    # set the parsed params as an attribute of the module
    module.params = {'_raw_params': 'ls /tmp', '_uses_shell': False, 'argv': None, 'chdir': None}
    # Attempting call of function main with defined args
    try:
        main()
    except SystemExit:
        pass
    # The above exception was the direct cause of the following exception:
    # AnsibleFailJson: {
    #     "changed": true,
    #     "cmd

# Generated at 2022-06-11 06:40:50.713852
# Unit test for function main

# Generated at 2022-06-11 06:41:01.226451
# Unit test for function main
def test_main():
    import subprocess
    import platform
    import sys

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_supports_check_mode = True
            self.check_mode = False

        def fail_json(self, **kwargs):
            raise AssertionError(str(kwargs))

        def exit_json(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        @staticmethod
        def run_command(args, **kwargs):
            if (sys.platform.startswith('win') and 'tasklist' in args) or 'ps' in args:
                return -1, b'', b''

# Generated at 2022-06-11 06:41:11.363022
# Unit test for function main

# Generated at 2022-06-11 06:41:21.603753
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict(
            commandline = dict(type='list', elements='str', required=True),
            warn = dict(type='bool', default=True),
        )
    )
    module.warn = lambda msg: msg


# Generated at 2022-06-11 06:41:34.080154
# Unit test for function check_command
def test_check_command():
    # mimicing ansible module
    class Ansible_Module(object):
        def __init__(self):
            self.params = {}
            self.warn = None

    my_module = Ansible_Module()
    my_module.params['command_warnings'] = True
    check_command(my_module, 'test')
    assert my_module.warn == 'Consider using the file module with state=directory rather than running \'test\'.  ' \
                             'If you need to use \'test\' because the file module is insufficient you can add \'warn: false\' to ' \
                             'this command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get rid of this message.'
    my_module.warn = None
    check_command(my_module, 'test')

# Generated at 2022-06-11 06:41:41.223020
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 06:41:52.704884
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert check_command(module, 'chown') == "Consider using the file module with owner rather than running 'chown'."
    assert check_command(module, ['chmod']) == "Consider using the file module with mode rather than running 'chmod'."
    assert check_command(module, ['curl']) == "Consider using the get_url or uri module rather than running 'curl'."
    assert check_command(module, ['wget']) == "Consider using the get_url or uri module rather than running 'wget'."
    assert check_command(module, ['svn']) == "Consider using the subversion module rather than running 'svn'."
    assert check_command(module, ['service']) == "Consider using the service module rather than running 'service'."

# Generated at 2022-06-11 06:42:01.531396
# Unit test for function check_command
def test_check_command():
    import doctest
    import ansible.modules.system.command
    results = doctest.testmod(ansible.modules.system.command, optionflags=doctest.NORMALIZE_WHITESPACE)
    if results[0] != 0:
        exit(1)


# <<INCLUDE_ANSIBLE_MODULE_COMMON>>

# Generated at 2022-06-11 06:42:13.678805
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo "this is a test"',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
    )

    mock_module = MagicMock()
    mock_module.params = args
    mock_module.check_mode = False
    mock_module.run_command.return_value = (0, b"", "")

    main(mock_module)

# Generated at 2022-06-11 06:42:41.714263
# Unit test for function main

# Generated at 2022-06-11 06:42:48.574516
# Unit test for function main
def test_main():
    r = dict()
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
        ),
        supports_check_mode=True, )
    r['cmd'] = "echo 'hello'"
    r['rc'] = 0
    r['stdout'] = "hello"
    r['stderr'] = ""
    assert main() == r

main()

# Generated at 2022-06-11 06:42:59.914621
# Unit test for function check_command
def test_check_command():
    test_dict = dict(
        system_warning='',
        no_log='False',
        warn='True',
        check_mode='False',
        diff_mode='True',
        path='/usr/bin:/bin',
        default_chdir='',
        force_handlers='False',
        localhost='ansible-test',
        remote_addr='127.0.0.1',
        )
    test_mod = type('AnsibleModule', (), test_dict)
    test_mod.params = dict(
        creates=None,
        removes=None,
        chdir=None,
        executable=None,
        stdin=None,
        strip_empty_ends=None,
        )
    test_mod.fail_json = lambda **kwargs: {}

# Generated at 2022-06-11 06:43:03.038821
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({}, {}, [], [], [])
    check_command(module, '/usr/bin/chown')
    check_command(module, ['rpm'])



# Generated at 2022-06-11 06:43:11.346056
# Unit test for function main

# Generated at 2022-06-11 06:43:13.472598
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:43:22.877338
# Unit test for function main
def test_main():
    args = {"chdir": "somedir/", "_uses_shell": True, "creates": "/path/to/database", "executable": "", "_raw_params": "/usr/bin/make_database.sh db_user db_name", "removes": ""}
    result = main()
    assert result['changed'] == True
    assert result['cmd'] == args._raw_params
    assert result['rc'] == 0
    assert result['end'] == None
    assert result['start'] == None 
    assert result['delta'] == None 
    assert result['stderr'] == "" 
    assert result['stdout'] == "" 
    assert result['msg'] == 'non-zero return code'
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 06:43:27.392834
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    data = dict(
        _raw_params='/bin/echo "It works"',
        executable='/bin/bash'
    )
    mod = AnsibleModule(argument_spec=dict())
    mod.params = data
    results = main()
    assert (results['rc'] == 0)


# Generated at 2022-06-11 06:43:36.469888
# Unit test for function main
def test_main():
    request = {}
    request['_raw_params'] = 'abc'
    request['chdir'] = '/tmp/'
    module = AnsibleModule(argument_spec=dict())
    response = module.params
    response['_raw_params'] = 'abc'
    response['chdir'] = '/tmp/'
    response['_uses_shell'] = None
    response['argv'] = None
    response['executable'] = None
    response['creates'] = None
    response['removes'] = None
    response['warn'] = False
    response['stdin'] = None
    response['stdin_add_newline'] = True
    response['strip_empty_ends'] = True
    assert request == response

# Generated at 2022-06-11 06:43:40.144447
# Unit test for function main
def test_main():
    args = """/usr/bin/make_database.sh db_user db_name creates=/path/to/database"""
    argv = None
    module = """"""
    main(module, args, argv)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:44:24.981923
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable


# Generated at 2022-06-11 06:44:36.182480
# Unit test for function main
def test_main():
    '''
    Ansible module to run arbitrary commands on a remote node
    '''

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', default=''),
            _uses_shell=dict(type='bool', default=True),
            chdir=dict(type='str', default=''),
            creates=dict(type='str', default=''),
            executable=dict(type='str', default=None),
            removes=dict(type='str', default=''),
            warn=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    import os

# Generated at 2022-06-11 06:44:43.168174
# Unit test for function main
def test_main():
    args = dict(
        creates=[],
        removes=[],
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        _raw_params='',
        _uses_shell=False,
        argv=[],
        chdir=None,
        executable=None,
    )

    main(args)

if __name__ == "__main__":
    main()

# Generated at 2022-06-11 06:44:44.736645
# Unit test for function check_command
def test_check_command():
    check_command(os.path.basename(command))



# Generated at 2022-06-11 06:44:54.986128
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    # Test for command module
    module_args = dict(
        _raw_params='ls',
        _uses_shell=False,
        argv=[],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        supports_check_mode=True)
    module_args_str = "ls"
    module_name = 'ansible.builtin.command'
    non_zero_return_code = 1
    non_empty_strout = 'Ansible Module: Command'
    non_empty_stderr = 'stderr'

# Generated at 2022-06-11 06:45:05.296184
# Unit test for function check_command
def test_check_command():
    '''
    Test function check_command
    :return:
    '''
    module = AnsibleModule(argument_spec=dict(
        command_warnings=dict(type='bool', default=True),
        command=dict(type='str', default='echo test'),
    ))

    # Test with command dict
    md = module_defaults(module)
    command = {
        'command': "echo test",
        'warnings': True
    }
    check_command(module, command)

    # Test with command string
    md = module_defaults(module)
    command = "echo test"
    check_command(module, command)

    # Test with hidden command
    md = module_defaults(module)
    command = "/usr/bin/sudo echo test"
    check_command(module, command)

   

# Generated at 2022-06-11 06:45:15.409580
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="ls /tmp",
        _uses_shell=False,
        argv=[],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-11 06:45:21.989090
# Unit test for function main
def test_main():
    command = ["echo", "hello"]
    executable = None
    args = "echo hello"
    argv = ["echo", "hello"]
    creates = None
    removes = None
    warn = True
    stdin = "Text to send"
    stdin_add_newline = True

# Generated at 2022-06-11 06:45:30.313355
# Unit test for function main
def test_main():
    my_module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default='echo hello'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(default=['echo', 'hello']),
            chdir=dict(),
            executable=dict(),
            creates=dict(),
            removes=dict(),
            warn=dict(type='bool', default=False),
            stdin=dict(),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    result = main()
    assert result['changed'] == True
    assert result['rc'] == 0
    assert result['start'] is not None


# Generated at 2022-06-11 06:45:41.020140
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 06:47:22.206609
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="date",
        executable="/bin/sh",
        creates=None,
        removes=None,
        warn=True,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True
    )
    module = AnsibleModule(**args)
    try:
        result = main()
    except Exception as err:
        print("FAILURE:", err)
        # raise
        result = False
    if module.check_mode:
        print("SKIPPED: not running in check mode")
        # raise Exception("SKIPPED: not running in check mode")
        result = None
    assert result


# Generated at 2022-06-11 06:47:29.627037
# Unit test for function main

# Generated at 2022-06-11 06:47:37.510141
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='str'),
            executable=dict(type='str'),
            creates=dict(type='str'),
            removes=dict(type='str'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
    )
    args = module.params

# Generated at 2022-06-11 06:47:45.634688
# Unit test for function main
def test_main():
    # Check load module from ansible
    def load_from_file():
        from ansible.module_utils.basic import AnsibleModule

        return AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

    # Types of different arguments
    args = {}
    # We want to check for changed = False
    args['changed'] = False
    # Return Code
    args['rc'] = 0
    # Command
    args['cmd'] = ['ls']
    # Stdin
    args['stdin'] = 'Filtering by Product Name: RHEV-H\n'
    # Stderr
    args['stderr'] = 'non-zero return code'
    # Start time
    args['start'] = '2017-09-29 22:03:48.083128'
    # End time
   

# Generated at 2022-06-11 06:47:54.816786
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os
    import sys
    import json
    import subprocess
    my_env = os.environ.copy()

# Generated at 2022-06-11 06:48:04.833569
# Unit test for function main

# Generated at 2022-06-11 06:48:11.892258
# Unit test for function main
def test_main():
    import tempfile
    import os
    import datetime

    # TODO: rewrite using tempfile.{Named,Temporary}Directory?
    prefix = 'tmpcmd_'
    suffix = '.txt'
    dirpath = tempfile.mkdtemp()
    testfile = tempfile.NamedTemporaryFile(prefix=prefix, suffix=suffix, text=True, dir=dirpath)
    testfile.write('some line\n')
    testfile.flush()
    testfile.seek(0)
    # TODO: rewrite using contextlib.{closing,suppress}?

# Generated at 2022-06-11 06:48:21.316399
# Unit test for function main
def test_main():
    import subprocess
    import sys
    import shutil
    import tempfile
    import json

    class AnsibleModuleMock(object):
        def __init__(self):
            self.check_mode = False
            self.params = {'_raw_params': 'echo hello world',
                           '_uses_shell': False,
                           'chdir': None,
                           'executable': None,
                           'creates': None,
                           'removes': None,
                           'warn': False,
                           'stdin': None,
                           'stdin_add_newline': False,
                           'strip_empty_ends': False}
            self.args = []
            self.fail_json = lambda: sys.exit(1)
            self.exit_json = lambda x: sys.exit(0)

# Generated at 2022-06-11 06:48:26.947793
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Test argument replacements
    check_command(module, 'chown root /foo/bar')
    check_command(module, ['chmod', 'u+w'])
    check_command(module, ['chgrp', 'root', '/foo/bar'])
    check_command(module, 'ln -s foo bar')
    check_command(module, ['mkdir', '-p', '/tmp/foo'])
    check_command(module, 'rmdir /tmp/foo')
    check_command(module, 'rm /tmp/foo')
    check_command(module, 'touch /tmp/foo')

    # Test Ansible module replacements

# Generated at 2022-06-11 06:48:34.205623
# Unit test for function main
def test_main():
    import files
    import re
    import time
    import os
    import sys
    import traceback
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # Assure we get the same results
    time.time = lambda : 1501073211.63
    os.urandom = lambda x : '\xd2O\xce\x9b\x9b\x18\xdd\xf3\xfa\xe6\x8b\x13\xe9\xab\x9b\xb6\xb7\x98\x1d\xd8\xed\xce\xbc\xdb9\x9bm\x02l\xea'
    re.compile('', re.UNICODE)