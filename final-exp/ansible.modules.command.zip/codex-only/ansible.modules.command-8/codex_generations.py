

# Generated at 2022-06-23 03:06:08.695937
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': True}})
    check_command(module, ['echo', 'hello'])



# Generated at 2022-06-23 03:06:12.470909
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable
    module = AnsibleModule(argument_spec={})
    assert check_command(module, ['sed']) == None



# Generated at 2022-06-23 03:06:17.795150
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def warn(self, msg):
            raise Exception(msg)

    def _run():
        check_command(TestModule(), ['chown'])
        check_command(TestModule(), ['wget'])
        check_command(TestModule(), ['svn'])
        check_command(TestModule(), ['mount'])
        check_command(TestModule(), ['rpm'])
        check_command(TestModule(), ['yum'])
        check_command(TestModule(), ['apt-get'])
        check_command(TestModule(), ['tar'])
        check_command(TestModule(), ['unzip'])
        check

# Generated at 2022-06-23 03:06:26.168139
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        _raw_params=dict(required=True),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    ))
    check_command(module, 'echo hello world')

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:37.102713
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict(),
    )


# Generated at 2022-06-23 03:06:41.622324
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'check_mode': {'type': 'bool'}})
    commandline = 'curl'
    check_command(module, commandline)
    out = module.warn.call_args[0]
    assert 'curl' in out[0]


# Generated at 2022-06-23 03:06:52.822654
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning

    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-23 03:07:03.001145
# Unit test for function main
def test_main():
    import unittest
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils._text import to_text

    class TestMain(unittest.TestCase):
        def test_splits_args(self):
            """Test splits args into list of strings"""
            module = AnsibleModule(
                argument_spec=dict(
                    _raw_params=dict(),
                    _uses_shell=dict(type='bool', default=False),
                    chdir=dict(type='path'),
                    executable=dict(),
                    creates=dict(type='path'),
                    removes=dict(type='path'),
                    warn=dict(type='bool', default=False),
                ),
                supports_check_mode=True
            )
            args = 'ls -l'
            argv = main()

# Generated at 2022-06-23 03:07:08.716480
# Unit test for function main
def test_main():

    import json
    import unittest
    import os
    import random
    import shutil
    import tempfile
    import time

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves.queue import Queue
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Make sure we don't have issues parsing gdbinit files when installed
    # via fpm on mips
    try:
        import gdb
    except ImportError:
        pass

    if not PY3:
        builtin_open = '__builtin__.open'
    else:
        builtin

# Generated at 2022-06-23 03:07:13.185322
# Unit test for function check_command
def test_check_command():
    command = 'sudo'
    commandline = ['/bin/su', '-', 'foo']
    module = AnsibleModule(
        argument_spec = dict(
            command = dict(type='str', required=True),
        ),
        supports_check_mode=True,
    )
    check_command(module, commandline)
    return True



# Generated at 2022-06-23 03:07:21.793244
# Unit test for function check_command
def test_check_command():
    """The function test_check_command() is strictly used to test the check_command() function.
    Do NOT use it as a place to run actual tests.
    """
    module = AnsibleModule({})
    test_command1 = ['touch']
    test_command2 = ['echo', 'blah']
    test_command3 = ['dnf', 'install', '-y', 'nginx']
    check_command(module, test_command1)
    check_command(module, test_command2)
    check_command(module, test_command3)



# Generated at 2022-06-23 03:07:35.819827
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(
        argument_spec = dict(),
    )
    check_command(mod, 'chown')
    assert mod.warnings == ['Consider using the file module with owner rather than running \'chown\'.  If you need to '
                            'use \'chown\' because the file module is insufficient you can add \'warn: false\' to this '
                            'command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to '
                            'get rid of this message.']
    mod = AnsibleModule(
        argument_spec = dict(),
    )
    check_command(mod, 'apt-get')

# Generated at 2022-06-23 03:07:46.524893
# Unit test for function main
def test_main():
    import json

    def mock_module(**kwargs):
        args = kwargs.get('argument_spec', None)
        return AnsibleModule(argument_spec=args)

    module = mock_module()
    args = {'_raw_params':'useradd -m -p "test" --comment comment --groups group --shell "/bin/sh" --uid 1005 testuser', '_uses_shell':True, 'chdir':'/usr/bin/'}
    module.params = args
    main()
    args = {'_raw_params':'/usr/bin/useradd -m -p "test" --comment comment --groups group --shell "/bin/sh" --uid 1005 testuser', '_uses_shell':True, 'chdir':'/usr/bin/', 'strip_empty_ends':False}
    module.params

# Generated at 2022-06-23 03:07:50.936450
# Unit test for function check_command
def test_check_command():
    am = AnsibleModule({})
    check_command(am, ['ln'])
    check_command(am, '/usr/bin/ln')
    check_command(am, 'ln -s')
    check_command(am, 'foo.sh')
    check_command(am, '/usr/bin/foo.sh')
    check_command(am, 'foo')
    check_command(am, '/usr/bin/foo')



# Generated at 2022-06-23 03:07:54.024991
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/bin/false',
    )
    result = main()
    assert result['changed'] == True
    assert result['rc'] != 0
    assert result['msg'] == 'non-zero return code'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:02.731039
# Unit test for function check_command
def test_check_command():
    module_mock = AnsibleModule(argument_spec={})
    module_mock.warn = lambda *args, **kwargs: None
    # command not in arguments, commands, become
    check_command(module_mock, 'ls')
    # command in arguments
    check_command(module_mock, 'chown')
    # command in commands
    check_command(module_mock, 'curl')
    # command in become
    check_command(module_mock, 'sudo')



# Generated at 2022-06-23 03:08:11.864346
# Unit test for function main
def test_main():
    args = 'ls -l'
    import sys
    sys.modules['__main__'].__file__ = '/Users/mariakarpenko/Documents/ansible_task_4/ansible/library/command.py'
    r = main()
    if r[0] != 0:
        print('Error %d, %s' %(r[0], r[1]))
    print(r[2])

if __name__ == '__main__':
    main()
    #test_main()

# Generated at 2022-06-23 03:08:25.303387
# Unit test for function main
def test_main():
    from ansible.module_utils import basic


# Generated at 2022-06-23 03:08:37.352702
# Unit test for function main

# Generated at 2022-06-23 03:08:40.909196
# Unit test for function main
def test_main():
    empty_module = AnsibleModule({}, bypass_checks=True)
    empty_module.params = {}
    if main():
        raise AssertionError()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:47.050210
# Unit test for function check_command
def test_check_command():
    sample_command = "ls -l /usr/bin/python*"
    # if module is DummyModule, the warn method does nothing
    module = DummyModule()
    # assume check_command returns nothing
    if check_command(module, sample_command) is None:
        assert True
    else:
        assert False


# Generated at 2022-06-23 03:08:48.454126
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:00.482448
# Unit test for function main
def test_main():
    # Invalid parameter
    args = dict(argv=['/bin/ls', '-d'])
    p = AnsibleModule(argument_spec=args)
    r = dict()
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 256
    
    # No paramters
    args = dict(argv=[])
    p = AnsibleModule(argument_spec=args)
    r = dict()
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 256
    
    #

# Generated at 2022-06-23 03:09:09.738195
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str', required=True),
        ),
    )
    module._warnings = []
    check_command(module, 'echo hello')
    assert module._warnings == []

    module._warnings = []
    check_command(module, 'chown myfile.txt')

# Generated at 2022-06-23 03:09:23.477676
# Unit test for function main
def test_main():
    with mock.patch.object(AnsibleModule, 'run_command') as umock:
        umock.return_value = (0, 'stdout', 'stderr')
        with mock.patch.object(os, 'chdir') as cmock:
            module = mock.MagicMock()
            module.check_mode = False
            module.params = {'_raw_params': 'foo', 'chdir':'/tmp', 'warn': False, 'strip_empty_ends': False, 'executable': None, 'creates': None, 'removes': None, 'argv': None, 'stdin': None, 'stdin_add_newline': True, '_uses_shell': False}
            cmock.return_value = None
            result = main()
            print(result)
            assert not result['changed'] == True

# Generated at 2022-06-23 03:09:36.840740
# Unit test for function check_command
def test_check_command():
    """Tests for the function check_command."""
    from ansible.module_utils.basic import AnsibleModule
    from collections import namedtuple
    FakeModule = namedtuple('FakeModule', ['warn'])
    m = FakeModule(warn=lambda x: None)
    check_command(m, ['/bin/sh', '-c', 'ls'])
    check_command(m, ['/bin/sh', '-c', 'yum install httpd'])
    check_command(m, ['/bin/sh', '-c', 'dnf install httpd'])
    check_command(m, ['/bin/sh', '-c', 'zypper install httpd'])
    check_command(m, ['/bin/sh', '-c', 'service foo start'])

# Generated at 2022-06-23 03:09:49.926252
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    command = 'ansible-doc command'
    check_command(module, command)
    assert module.warnings[0].startswith('Consider using the command module')
    assert module.warnings[0].endswith('ansible-doc command\'')

    del module.warnings[0]
    check_command(module, ['wget'])
    assert module.warnings[0].startswith("Consider using the get_url or uri module")

    check_command(module, ['touch'])
    assert module.warnings[1].startswith("Consider using the file module with state=touch rather than running")
    assert module.warnings[1].endswith("touch\''.")

    check_command(module, ['svn'])
    assert module.warn

# Generated at 2022-06-23 03:09:51.861622
# Unit test for function main
def test_main():
    res = main()
    assert res[0] == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:59.738135
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.compat.tests.mock import patch, MagicMock
    from contextlib import contextmanager

    mod = basic.AnsibleModule(
        argument_spec=dict(echo=dict(type='str', default='default')),
        supports_check_mode=True
    )

    # command
    with patch('ansible.module_utils.basic.AnsibleModule') as module_mock:
        module_mock = mod
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:08.905319
# Unit test for function main

# Generated at 2022-06-23 03:10:17.519171
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule(argument_spec={})
    try:
        check_command(mod,['/bin/echo','echo','echo','echo'])
        assert 1 == 0
    except SystemExit as e:
        assert e.code == 0
    try:
        check_command(mod,['/bin/cat'])
        assert 1 == 0
    except SystemExit as e:
        assert e.code == 0
    try:
        check_command(mod,['/bin/chmod','777'])
        assert 1 == 0
    except SystemExit as e:
        assert e.code == 0
    try:
        check_command(mod,['chmod','777'])
        assert 1 == 0
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-23 03:10:28.481508
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import common_koji
    from ansible.module_utils import common_cert
    from ansible.module_utils import common_selinux
    from ansible.module_utils import common_dbus
    from ansible.module_utils import common_systemd
    from ansible.module_utils import common_ansible
    from ansible.module_utils import common_config
    from ansible.module_utils import common_systemd_import
    from ansible.module_utils import common_crypto
    from ansible.module_utils import common_logging

# Generated at 2022-06-23 03:10:38.351386
# Unit test for function main
def test_main():
    test_dict = dict(
        argv=[],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
        supports_check_mode=True,
        _raw_params='',
        _uses_shell=False
    )

# Generated at 2022-06-23 03:10:48.624816
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="/bin/false",
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        check_mode=False
    )
    r = dict(
        changed=True,
        stdout='',
        stderr='',
        rc=1,
        msg='non-zero return code'
    )
    module = AnsibleModule(argument_spec=args)
    assert main() == module.fail_json(**r)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:00.419234
# Unit test for function main

# Generated at 2022-06-23 03:11:04.293381
# Unit test for function main
def test_main():
    print("Test main")
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:14.514723
# Unit test for function check_command
def test_check_command():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    module.warn = warning_capture.append

    warnings = []

    with warnings_capture_context(warnings):
        check_command(module, ['chmod'])

    assert warnings == [
        "Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message.",
    ]

    warnings = []


# Generated at 2022-06-23 03:11:15.339358
# Unit test for function check_command
def test_check_command():
    assert check_command is not None, "check_command function not defined"



# Generated at 2022-06-23 03:11:29.893392
# Unit test for function main

# Generated at 2022-06-23 03:11:30.937253
# Unit test for function check_command
def test_check_command():
    check_command(module="test_module", commandline="mkdir /test")



# Generated at 2022-06-23 03:11:39.435923
# Unit test for function check_command
def test_check_command():
    assert check_command(None, ['touch']) == 'touch'
    assert check_command(None, '/bin/chmod') == 'chmod'
    assert check_command(None, 'chmod') == 'chmod'
    assert check_command(None, ['/bin/bash', '-c', 'chmod']) == 'chmod'
    assert check_command(None, ['/bin/bash', '-c', 'echo']) == 'echo'
    assert check_command(None, ['/bin/bash', '-c', 'pip install ansible']) == 'pip'
    assert check_command(None, ['/bin/bash', '-c', 'sudo su - user']) == 'su'



# Generated at 2022-06-23 03:11:49.486089
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='command to run',
        _uses_shell=True,
        argv=['command to run'],
        chdir='/',
        executable='/bin/bash',
        creates='/tmp/testfile',
        removes='/testfile',
        warn='',
        stdin='cmd',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:59.389992
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:12:10.305784
# Unit test for function main
def test_main():
    module_args = {}
    module_args.update({'chdir': '/tmp'})
    module_args.update({'executable': '/bin/bash'})
    module_args.update({'args': 'ls'})
    module_args.update({'warn': True})
    module_args.update({'stdin': 'ping –c1 google.com'})
    module_args.update({'stdin_add_newline': True})
    module_args.update({'strip_empty_ends': True})

# Generated at 2022-06-23 03:12:13.673696
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson) as exec_info:
        main()


# Generated at 2022-06-23 03:12:16.001936
# Unit test for function main
def test_main():
    unit_test_main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:17.934332
# Unit test for function check_command
def test_check_command():
    assert(check_command('/usr/local/bin/my-command -a'))



# Generated at 2022-06-23 03:12:19.742383
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:22.709401
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
    )
    result = execute_module(module_args=args)
    assert result['stdout'] == 'hello'

# Generated at 2022-06-23 03:12:35.676243
# Unit test for function main

# Generated at 2022-06-23 03:12:44.311107
# Unit test for function main
def test_main():
    test_args = dict(
        _raw_params="echo hello",
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/test',
        executable='/bin/sh',
        creates='/test/file',
        removes='/test/file',
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    r = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )
    m = AnsibleModule(test_args)
    main(m)


# Generated at 2022-06-23 03:12:51.469626
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    basic._ANSIBLE_ARGS = to_bytes('')

# Generated at 2022-06-23 03:12:59.434500
# Unit test for function main
def test_main():
    test_args = { 'argv':['./test/ansible/modules/shell/command/test_command.sh', 'test'], 'check_mode': True, 'strip_empty_ends': True}
    result = main()
    assert result == True

if __name__ == '__main__':
    main()
    #test_main()

# Generated at 2022-06-23 03:13:10.458203
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    a = AnsibleModule(argument_spec=dict())
    commands = {'curl': ('get_url', 'uri'), 'wget': ('get_url', 'uri'),
                'svn': ('subversion',), 'service': ('service',),
                'mount': ('mount',), 'rpm': ('yum', 'dnf', 'zypper'), 'yum': ('yum',), 'apt-get': ('apt',),
                'tar': ('unarchive',), 'unzip': ('unarchive',), 'sed': ('replace', 'lineinfile', 'template'),
                'dnf': ('dnf',), 'zypper': ('zypper',)}

# Generated at 2022-06-23 03:13:22.415326
# Unit test for function check_command
def test_check_command():
    # fake args to make the module think it's running from cli
    from ansible.module_utils.basic import AnsibleModule
    a = AnsibleModule({'warn': True,'_ansible_remote_tmp': '/'}, is_argument=False)
    check_command(a,"echo")
    check_command(a, "touch")
    check_command(a, "wget")
    check_command(a,"sudo")
    check_command(a, "su")
    check_command(a, "service")
    check_command(a, "pbrun")
    check_command(a,"pfexec")
    check_command(a, "runas")
    check_command(a, "pmrun")
    check_command(a,"machinectl")
    check_command(a,"mount")


# Generated at 2022-06-23 03:13:27.522232
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs
            self.warn = None

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, **kwargs):
            pass

        def set_warn(self, text):
            self.warn = text


# Generated at 2022-06-23 03:13:37.164280
# Unit test for function check_command
def test_check_command():

    module = AnsibleModule(argument_spec=dict())
    assert check_command(module, 'curl')
    assert check_command(module, 'wget')
    assert check_command(module, 'svn')
    assert check_command(module, 'service')
    assert check_command(module, 'mount')
    assert check_command(module, 'rpm')
    assert check_command(module, 'yum')
    assert check_command(module, 'apt-get')
    assert check_command(module, 'tar')
    assert check_command(module, 'chown')
    assert check_command(module, 'chmod')
    assert check_command(module, 'chgrp')
    assert check_command(module, 'ln')
    assert check_command(module, 'unzip')

# Generated at 2022-06-23 03:13:37.822469
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-23 03:13:39.960672
# Unit test for function main
def test_main():
    something = 'something'

    assert something != None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:50.049974
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.params = {'warn': 'yes'}
        def warn(self, msg):
            self.msgs = msg
    test_module = TestModule()
    check_command(test_module, ['apt-get'])
    assert test_module.msgs == "Consider using the apt module rather than running 'apt-get'.  If you need to use 'apt-get' because the apt module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
# Test of function check_command
test_check_command()


# Generated at 2022-06-23 03:13:54.690203
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )
    check_command(module, to_bytes('echo hello'))



# Generated at 2022-06-23 03:14:02.252166
# Unit test for function main
def test_main():
    arg_spec = dict(
        _raw_params=dict(default=None, type='str'),
        _uses_shell=dict(default='', type='bool'),
        argv=dict(default=None, type='list'),
        chdir=dict(default=None, type='path'),
        executable=dict(default=None, type=''),
        creates=dict(default=None, type='path'),
        removes=dict(default=None, type='path'),
        warn=dict(default=False, type='bool'),
        stdin=dict(default=None, required=False),
        stdin_add_newline=dict(default=True, type='bool'),
        strip_empty_ends=dict(default=True, type='bool')
    )
    supports_check_mode = True

# Generated at 2022-06-23 03:14:10.508951
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    check_command(module, '/usr/bin/foo')
    check_command(module, '/bin/chown')
    check_command(module, ['chmod'])
    check_command(module, ['rpm'])
    check_command(module, ['apt-get'])
    check_command(module, [os.path.join(os.path.sep, 'usr', 'bin', 'rpm')])


# ===========================================
# main


# Generated at 2022-06-23 03:14:12.825215
# Unit test for function main
def test_main():
    print("testing function main")
    res = main()
    print("function main returned: ", res)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:14:24.314094
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="ansible-doc -t module yum",
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        _ansible_check_mode=False,
        _ansible_diff=False,
        _ansible_verbosity=0,
    )
    mock_module = MagicMock()

# Generated at 2022-06-23 03:14:36.445837
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/chown')
    check_command(module, ['/usr/bin/chown'])
    check_command(module, '/usr/bin/chmod')
    check_command(module, '/usr/bin/chgrp')
    check_command(module, '/usr/bin/ln')
    check_command(module, '/usr/bin/mkdir')
    check_command(module, '/usr/bin/rmdir')
    check_command(module, '/usr/bin/rm')
    check_command(module, '/usr/local/bin/touch')
    check_command(module, '/usr/bin/curl')
    check_command(module, '/usr/bin/wget')

# Generated at 2022-06-23 03:14:46.840376
# Unit test for function check_command
def test_check_command():
    class Arguments():
        def __init__(self):
            self.warn = True
            self.chdir = None
            self.stdin = None
            self.creates = None
            self.removes = None

    class Module():
        def __init__(self):
            self.params = Arguments()
            self.check_mode = False
            self.run_command = lambda *args, **kwargs: ('', '', 0)

        def warn(self, msg):
            raise AssertionError("warn called: " + msg)

    module = Module()

# Generated at 2022-06-23 03:14:51.618722
# Unit test for function check_command
def test_check_command():
    cmd = ["/usr/bin/python", "-c", "import json; print json.dumps({'a': 'b'})"]
    module = AnsibleModule(argument_spec={})
    check_command(module, cmd)
    #FIXME: can't read state of module.warn



# Generated at 2022-06-23 03:15:02.944622
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    class Args(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

# Generated at 2022-06-23 03:15:12.484099
# Unit test for function check_command

# Generated at 2022-06-23 03:15:21.637787
# Unit test for function check_command
def test_check_command():
    mock_module = type('', (), {})
    mock_module.warn = lambda x: None
    # test warning generated if command not in list of warnings to suppress
    commands = ['touch', 'rm', 'rmdir', 'chmod', 'chown', 'chgrp',
                'ln', 'mkdir', 'curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
                'tar', 'unzip', 'sed', 'dnf', 'zypper']
    for command in commands:
        check_command(mock_module, command)



# Generated at 2022-06-23 03:15:32.415786
# Unit test for function main
def test_main():
    a = dict(stdin=None, executable=None, argv=None, chdir=None, creates=None, removes=None, warn=None)
    b = dict(_raw_params='', _uses_shell=False)
    args = dict(a, **b)
    argv = dict(a, _raw_params='')
    args_shell = dict(a, _raw_params='', _uses_shell=True)
    no_command = dict(a, _raw_params='', _uses_shell=True, executable='/bin/sh')
    command = dict(no_command, _raw_params='command -v echo')
    args_command = dict(no_command, _raw_params='echo')
    # test invalid output since no command was executed

# Generated at 2022-06-23 03:15:39.886868
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:15:49.423487
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    cmd = ['cat', '/etc/motd']
    check_command(module, cmd)
    cmd = 'cat /etc/motd'
    check_command(module, cmd)
    cmd = 'sudo runme'
    check_command(module, cmd)
    cmd = ['chmod', '0644', '/path/to/file']
    check_command(module, cmd)
    cmd = 'chmod 0644 /path/to/file'
    check_command(module, cmd)
    cmd = 'wget http://example.com/file'
    check_command(module, cmd)
    cmd = ['wget', 'http://example.com/file']
    check_command(module, cmd)

# Generated at 2022-06-23 03:15:55.004719
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

    module = AnsibleModule({}, supports_check_mode=True)
    cmd = ["/usr/bin/make_database.sh", "db_user", "db_name"]
    check_command(module, cmd)



# Generated at 2022-06-23 03:15:58.821831
# Unit test for function main
def test_main():
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    result = main()
    assert result == r



# Generated at 2022-06-23 03:16:10.833516
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.check_command(['touch'])
    assert module.warnings[0] == 'Consider using the file module with state=touch rather than running \'touch\'.  If you need to use \'touch\' because the file module is insufficient you can add \'warn: false\' to this command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get rid of this message.'
    module.check_command(['service'])
    assert module.warnings[1] == "Consider using the service module rather than running 'service'.  If you need to use 'service' because the service module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    module.check_