

# Generated at 2022-06-23 03:06:05.033710
# Unit test for function main
def test_main():
    # Unit tests are needed to be written!
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:17.288797
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="ping -c 1 google.com",
        executable=None,
        chdir="#",
        creates="/tmp/file",
        warns=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True
    )

# Generated at 2022-06-23 03:06:27.957328
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'warn': dict(default='yes', type='bool'),
                                          'arguments': dict(default=[], type='list'),
                                          'command': dict(type='str')})
    check_command(module, 'touch test')
    check_command(module, 'mkdir test')
    check_command(module, 'rm test')
    check_command(module, 'rmdir test')
    check_command(module, 'ln test')
    check_command(module, 'chmod test')
    check_command(module, 'chgrp test')
    check_command(module, 'chown test')
    check_command(module, 'rpm test')
    check_command(module, 'yum test')
    check_command(module, 'apt-get test')
   

# Generated at 2022-06-23 03:06:32.039856
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, "/bin/sh")
    check_command(module, "sh")
    check_command(module, "/bin/sh /path/to/script.sh")
    result = {'warnings': ["Consider using the service module rather than running 'sh'.",
                           "Consider using the service module rather than running 'sh'.",
                           "Consider using the service module rather than running 'sh'."]}
    module.exit_json(**result)



# Generated at 2022-06-23 03:06:41.112192
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 03:06:52.445231
# Unit test for function check_command

# Generated at 2022-06-23 03:07:01.955295
# Unit test for function main

# Generated at 2022-06-23 03:07:07.477071
# Unit test for function main
def test_main():
    args = ['echo', 'hello']

# Generated at 2022-06-23 03:07:18.204843
# Unit test for function check_command
def test_check_command():
    command = "ansible-test double --debug"
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-23 03:07:27.454213
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.warn_msg = list()

        def warn(self, msg):
            self.warn_msg.append(msg)

    test_commands = {'curl': 'get_url or uri', 'wget': 'get_url or uri',
                     'svn': 'subversion', 'service': 'service',
                     'mount': 'mount', 'rpm': 'yum, dnf or zypper', 'yum': 'yum', 'apt-get': 'apt',
                     'tar': 'unarchive', 'unzip': 'unarchive', 'sed': 'replace, lineinfile or template',
                     'dnf': 'dnf', 'zypper': 'zypper'}
    test_command = 'sed'


# Generated at 2022-06-23 03:07:39.074957
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        "_raw_params": "test command",
        "_uses_shell": False,
        "argv": [],
        "chdir": "",
        "executable": None,
        "creates": None,
        "removes": None,
        "warn": False,
        "stdin": None,
        "stdin_add_newline": True,
        "strip_empty_ends": True,
    }, no_log=True)
    test_module.run_command = MagicMock(return_value=(0, "test_stdout", "test_stderr"))
    test_module.exit_json = MagicMock()
    test_module.fail_json = MagicMock()

    test_main = None

# Generated at 2022-06-23 03:07:47.377615
# Unit test for function check_command
def test_check_command():
    check_command = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    check_command.check_mode = False
    check_command.check_command(check_command, "ansible.builtin.command")
    check_command.check_command(check_command, "ansible.builtin.command test")
    check_command.check_command(check_command, "ansible.builtin.command test test2")

    # Check that errors are raised and warnings are given
    check_command.check_mode = True
    check_command.check_command(check_command, "ansible.builtin.command")
    check_command.check_command(check_command, "sudo")
    check_command.check_command(check_command, "rm")

# Generated at 2022-06-23 03:07:56.583175
# Unit test for function main
def test_main():
    import json
    import sys
    import pytest

    # normal run

# Generated at 2022-06-23 03:08:03.888615
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='netstat -rn',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=None,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(**args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:13.273775
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    args_dict = dict(
        argv=[
            'echo', '"hello"'
        ]
    )
    with pytest.raises(SystemExit):
        module = AnsibleModule(argument_spec=dict())
        main()
        main()
        main()
        main()


# Generated at 2022-06-23 03:08:26.555976
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'warnings':dict(type='bool', default=True)})

# Generated at 2022-06-23 03:08:33.046754
# Unit test for function check_command
def test_check_command():
    module = create_mock_module()
    check_command(module, ['/path/to//command'])
    sleep(0.1)
    assert module.warn_called_with(
        "Consider using the file module with owner rather than running 'command'.  If you need to use 'command' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    )



# Generated at 2022-06-23 03:08:36.315625
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'grep this file')
    assert len(module.warnings) == 1
    check_command(module, ['grep', 'this file'])
    assert len(module.warnings) == 2


# Generated at 2022-06-23 03:08:47.732204
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    shell = module

# Generated at 2022-06-23 03:08:58.688688
# Unit test for function check_command
def test_check_command():

    module = AnsibleModule(
        argument_spec=dict(
            free_form=dict(type='str'),
            warn=dict(type='bool', default=True)
        ),
        supports_check_mode=True
    )
    local_args = dict(
        # cmd is a parameter, not a keyword argument
        cmd='/usr/bin/make_database.sh db_user db_name'
    )
    module.params['warn'] = False
    check_command(module, local_args['cmd'])
    assert module.warnings[0]['msg'].startswith('Consider using the service module rather than running \'service\'.  ')



# Generated at 2022-06-23 03:09:02.146117
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    check_command(module, "/usr/bin/make_database.sh db_user db_name creates=/path/to/database")



# Generated at 2022-06-23 03:09:10.659146
# Unit test for function check_command
def test_check_command():
    '''Unit test function check_command'''
    test_mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Create the mock objects
    class warn_class(object):
        ''' Fake class to set up calls to warn_class.warn '''
        def __init__(self, message):
            self.msg = message

        def warn(self, message):
            assert message == self.msg, 'warn called with unexpected message'


# Generated at 2022-06-23 03:09:20.139953
# Unit test for function main
def test_main():
    # command_run unit test goes here
    args = {}
    args['_raw_params'] = u'/bin/false'
    args['_uses_shell'] = False
    args['chdir'] = None
    args['executable'] = None
    args['creates'] = None
    args['removes'] = None
    args['strip_empty_ends'] = True
    # If fails on None object
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:23.654483
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    c = Command(m, {'cmd': u'/bin/echo foo'})
    c.check_command()
    #cmd = shlex.split(u'/bin/echo foo')
    #check_command(m, cmd)



# Generated at 2022-06-23 03:09:29.950105
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    cmds = ['chmod 666 foo', 'dnf -y install foo', 'sudo apt-get install foo', 'rpm -ivh foo.rpm']
    for cmd in cmds:
        check_command(module, cmd)



# Generated at 2022-06-23 03:09:40.262741
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:09:51.723993
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.warnings = []
            super(TestModule, self).__init__(*args, **kwargs)

        def warn(self, msg):
            self.warnings.append(msg)

    # Test with a commandline argument
    module = TestModule({}, {'command': '/usr/bin/mkdir testdir'})
    check_command(module, module.params['command'])
    assert len(module.warnings) == 1

# Generated at 2022-06-23 03:10:04.574903
# Unit test for function main

# Generated at 2022-06-23 03:10:14.389756
# Unit test for function main

# Generated at 2022-06-23 03:10:24.295383
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    args = ['chown foo bar']
    check_command(module, args)
    args = ['chmod 755 foo']
    check_command(module, args)
    args = ['chgrp foo bar']
    check_command(module, args)
    args = ['ln -s foo bar']
    check_command(module, args)
    args = ['mkdir foo bar']
    check_command(module, args)
    args = ['rmdir foo bar']
    check_command(module, args)
    args = ['cp foo bar']
    check_command(module, args)
    args = ['rm foo bar']
    check_command(module, args)
    args = ['touch foo bar']


# Generated at 2022-06-23 03:10:29.063966
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    module.warn = lambda msg: None
    module.params['warn'] = True
    check_command(module, 'ls')
    check_command(module, 'rm')
    check_command(module, 'yum')



# Generated at 2022-06-23 03:10:37.445060
# Unit test for function check_command
def test_check_command():
    args = {'warn': True}
    module = AnsibleModule(argument_spec = dict())
    check_command(module, ['/bin/chmod', '644', '/tmp/file'])
    check_command(module, ['/bin/chgrp', 'root', '/tmp/file'])
    check_command(module, ['/bin/chown', 'joe', '/tmp/file'])
    check_command(module, ['/usr/bin/ln', 'foo', '/tmp/bar'])
    check_command(module, ['/bin/mkdir', '/tmp/joe'])
    check_command(module, ['/bin/rm', 'foo'])
    check_command(module, ['/bin/rm', 'foo'])

# Generated at 2022-06-23 03:10:50.617111
# Unit test for function main

# Generated at 2022-06-23 03:10:53.598046
# Unit test for function check_command
def test_check_command():
    assert check_command("fake_module", "echo hello")
    assert check_command("fake_module", ["echo", "hello"])



# Generated at 2022-06-23 03:11:04.221969
# Unit test for function check_command
def test_check_command():
    import mock
    import tempfile
    from ansible.module_utils._text import to_bytes

    # Create a mock module
    module = mock.MagicMock()
    module.params = {}

    # Create tempfile
    _, tmp_path = tempfile.mkstemp()
    tmp_path = to_bytes(tmp_path, errors='surrogate_or_strict')
    tmp_dir, tmp_name = os.path.split(tmp_path)

    # Do a touch to create the file
    os.chdir(tmp_dir)
    touch_cmd = "touch %s" % tmp_name
    os.system(touch_cmd)

    # Test the command with and without parameters
    test_cmd = "rm"
    test_cmd_with_params = "rm -f"

# Generated at 2022-06-23 03:11:10.813598
# Unit test for function check_command
def test_check_command():
    command = 'ansible.builtin.command'
    commandline = '/usr/bin/make_database.sh db_user db_name creates=/path/to/database'
    module = AnsibleModule(command, commandline)
    check_command(module, commandline)
    commandline = ['ansible.builtin.command', '/usr/bin/make_database.sh db_user db_name creates=/path/to/database']
    check_command(module, commandline)

# Generated at 2022-06-23 03:11:22.343602
# Unit test for function check_command
def test_check_command():
    import sys
    import collections
    import types
    import operator
    import warnings
    import tempfile

    class FakeAnsibleModule():
        def __init__(self):
            self.params = collections.defaultdict(lambda: None)
            self.params.update(command="")
            self.deprecations = collections.OrderedDict()
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

# Generated at 2022-06-23 03:11:32.981320
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    import ansible.module_utils.common.warnings as warnings
    import ansible.module_utils.ansible_builtin_command_warnings as warning_handler

    module = AnsibleModule(argument_spec={})

    warnings.warn = warning_handler.warn
    warnings.once_per_command = {}

    check_command(module, 'echo')
    assert len(warnings.once_per_command) == 0

    check_command(module, 'ln')
    assert len(warnings.once_per_command) == 1



# Generated at 2022-06-23 03:11:43.093825
# Unit test for function main
def test_main():
    os.environ['ANSIBLE_MODULE_ARGS'] = '_raw_params=hello, chdir=.., creates=world, check_mode=True, _uses_shell=False'
    os.environ['ANSIBLE_MODULE_ARGS'] += ', warn=True'
    global module

# Generated at 2022-06-23 03:11:54.471661
# Unit test for function check_command
def test_check_command():
    import tempfile

    module = AnsibleModule(argument_spec={
        'warn': {'type': 'bool', 'default': True},
    })
    module.check_mode = False
    module.no_log = True

    # temporary file for module.debug usage in check_command()
    handle, tmpfile = tempfile.mkstemp()
    os.close(handle)

    # no warnings
    check_command(module, "touch /tmp/file")
    with open(tmpfile, 'rb') as debug:
        assert debug.read() == b''

    # warn about /bin/chown
    check_command(module, "/bin/chown root:root /tmp/file")

# Generated at 2022-06-23 03:12:01.754873
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': {'type': 'str', 'aliases': ['cmd']},
                                          '_uses_shell': {'type': 'bool'}})

    # check_command actually has no return value, so just call it to make sure it doesn't error out
    check_command(module, '/bin/false')

# ===========================================
# Main control flow


# Generated at 2022-06-23 03:12:07.539353
# Unit test for function main
def test_main():
    class Args(object):
        def __init__(self):
            self._raw_params = None
            self._uses_shell = False
            self.argv = None
            self.chdir = None
            self.executable = None
            self.creates = None
            self.removes = None
            self.warn = False
            self.stdin = None
            self.stdin_add_newline = True
            self.strip_empty_ends = True

    arg_data_default = Args()
    arg_data_default._raw_params = 'ls -la'
    arg_data_default._uses_shell = True
    arg_data_default.chdir = '/tmp'
    arg_data_default.creates = 'test.txt'

# Generated at 2022-06-23 03:12:18.369056
# Unit test for function check_command
def test_check_command():
    # Should not warn with no parameters
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'does_not_matter')
    assert not module.fail_json.called
    assert not module.warn.called

    # Should not warn with parameters that don't modify the command
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'does_not_matter')
    assert not module.fail_json.called
    assert not module.warn.called
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'does_not_matter')
    assert not module.fail_json.called
    assert not module.warn.called

    # Should warn with chown
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 03:12:21.320356
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str', required=True)
        )
    )
    check_command(m, "touch hello")

# Generated at 2022-06-23 03:12:34.811209
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager()
    config_manager.update('command_warnings', 'False')

    mod = basic.AnsibleModule(
        argument_spec={},
    )
    check_command(mod, 'touch file')
    check_command(mod, 'echo hello')
    assert mod.warnings == []
    mod.warnings = []

    mod = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    check_command(mod, 'touch file')
    check_command(mod, 'echo hello')
    assert mod.warnings == []
    mod.warnings = []


# Generated at 2022-06-23 03:12:43.678721
# Unit test for function main
def test_main():
    test_module_args = dict(
        _raw_params = dict(type='str', required=True),
        _uses_shell = dict(type='bool', required=False),
        argv = dict(type='list', required=True),
        chdir = dict(type='path', required=True),
        executable = dict(type='str', required=True),
        creates = dict(type='path', required=True),
        removes = dict(type='path', required=True),
        # The default for this really comes from the action plugin
        warn = dict(type='bool', required=False),
        stdin = dict(required=False),
        stdin_add_newline = dict(type='bool', required=False),
        strip_empty_ends = dict(type='bool', required=False),
    )

    module = Ans

# Generated at 2022-06-23 03:12:45.171478
# Unit test for function main
def test_main():
    r = main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:52.306341
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.collections import ImmutableDict
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    assert module.warnings == ["Consider using the file module with chown rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]
    module.reset_warnings()
    check_command(module, 'chmod')

# Generated at 2022-06-23 03:13:06.757450
# Unit test for function main
def test_main():
    # These are just some arbitrary module names, and are not relevant
    # to the test really. Just don't want to pass None.
    module = AnsibleModule(
        argument_spec=dict(
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # Import the

# Generated at 2022-06-23 03:13:19.444088
# Unit test for function check_command
def test_check_command():
    args = {}
    module = AnsibleModule(argument_spec={}, supports_check_mode=False, **args)
    check_command(module, ["/usr/bin/make_database.sh", "db_user", "db_name"])
    check_command(module, ["echo", "hello"])
    check_command(module, ["service", "foo", "start"])
    check_command(module, ["touch", "bar"])
    check_command(module, ["curl", "http://somehost/somepath/file.ext"])
    check_command(module, ["yum", "install", "somepackage"])
    check_command(module, ["zypper", "install", "somepackage"])

# Generated at 2022-06-23 03:13:24.870317
# Unit test for function main
def test_main():
    args = {}
    args['_raw_params'] = "dir"
    args['_uses_shell'] = True
    args['creates'] = None

# Generated at 2022-06-23 03:13:28.704120
# Unit test for function check_command
def test_check_command():
    args = {}
    args['warn'] = True
    args['command'] = 'wget http://foo.bar/path'
    mod = AnsibleModule(argument_spec={})
    check_command(mod, args['command'])



# Generated at 2022-06-23 03:13:40.747429
# Unit test for function main
def test_main():


    #args = {'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': False, '_raw_params': '/bin/true', 'argv': None, '_uses_shell': False}
    args = {'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': False, '_raw_params': '/bin/true', 'argv': None, '_uses_shell': False}
    #raw = {'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': False, '_raw_params': '/bin/true', 'argv': None, '_uses_shell': False}
    raw = {}

# Generated at 2022-06-23 03:13:48.657837
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'chdir': {}, 'executable': {'type': 'path'}, 'creates': {'type': 'path'}, 'removes': {'type': 'path'}, 'warn': {'type': 'bool'}, 'chdir': {'type': 'path'}})
    import ansible.modules.commands.command as command
    result = command.check_command(module,["/path/to/date"])
    if result is not None:
        raise AssertionError("check_command should be None")



# Generated at 2022-06-23 03:13:57.734259
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_bytes
    from ansible.module_utils.common.collections import is_iterable

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    check_command(module, 'mv /some/where/somefile /some/other/place')
    check_command(module, 'cp /some/where/somefile /some/other/place')
    check_command(module, 'chown root /etc/somefile')
    check_command(module, 'chmod 0600 /etc/somefile')
    check_command(module, 'chgrp root /etc/somefile')

# Generated at 2022-06-23 03:14:08.209413
# Unit test for function check_command
def test_check_command():
    test_command = [os.path.join(os.path.dirname(__file__), 'data/command_check.py')]
    cmd = ["./data/command_check.py", "touch", "foo", "bar", "state=touch"]
    rc, out, err = module.run_command(cmd)
    assert out == "valid command: ['./data/command_check.py', 'touch', 'foo', 'bar', 'state=touch']\n"

    cmd = ["./data/command_check.py", "touch", "foo", "bar", "state=touch", "-vvvv", "-b"]
    rc, out, err = module.run_command(cmd)

# Generated at 2022-06-23 03:14:16.153272
# Unit test for function main
def test_main():
    result = {}
    result['rc'] = 0
    result['stdout'] = 'Clustering node rabbit@slave1 with rabbit@master …'
    result['stderr'] = 'ls cannot access foo: No such file or directory'
    result['cmd'] = ['echo', 'hello']
    result['msg'] = ''
    result['start'] = '2017-09-29 22:03:48.083128'
    result['end'] = '2017-09-29 22:03:48.084657'
    result['delta'] = '0:00:00.001529'
    result['changed'] = True
    assert main() == result

# FIXME: this really should be a function, not a class

# Generated at 2022-06-23 03:14:28.835853
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    import ansible.utils.display
    args = {
        'creates': '/tmp/testmain',
        'chdir': '/tmp/testchdir',
        '_raw_params': 'echo 1',
        '_uses_shell': False,
        'stdin': to_bytes('test'),
        'strip_empty_ends': True,
    }
    r = {
        'rc': 0,
        'stdout': '',
        'stderr': '',
        'cmd': 'echo 1',
        'start': None,
        'end': None,
        'delta': None,
        'msg': u'',
        'changed': True,
        'warnings': [],
    }


# Generated at 2022-06-23 03:14:37.735945
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    check_command(module, ['echo'])
    check_command(module, ['curl'])
    check_command(module, ['touch', 'something'])
    check_command(module, ['mkdir', 'something'])
    check_command(module, ['ln', 'something', 'something'])
    check_command(module, ['rm', 'something'])
    check_command(module, ['rpm', 'something'])
    check_command(module, ['yum', 'something'])
    check_command(module, ['apt-get', 'something'])
    check_command(module, ['tar', 'something'])
    check_command(module, ['sed', 'something'])

# Generated at 2022-06-23 03:14:41.797709
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({'warn': True})
    check_command(module, 'echo test')
    check_command(module, 'chmod test')


# Generated at 2022-06-23 03:14:54.283875
# Unit test for function main
def test_main():

    import os
    import tempfile
    import shutil
    import json
    import sys
    import subprocess
    import re
    import errno
    import stat
    import time

    # This is a subfunction to test a command, and return the output, stdout, and exit code
    def _exec(cmd, pwd):
        proc = subprocess.Popen(cmd, cwd=pwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        out, err = proc.communicate()
        return (out, err, proc.returncode)

    # This is a subfunction that tests a command against the expected output and return code, and exits at the end

# Generated at 2022-06-23 03:15:06.085695
# Unit test for function main

# Generated at 2022-06-23 03:15:15.004493
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common_test_utils
    import ansible.module_utils.basic

# Generated at 2022-06-23 03:15:26.205370
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.basic import _load_params

    args = _load_params()

    # command module does not take key=val args, so we have to replace
    args = [a for a in args if not a.startswith("_")]

    # Build up required args
    required_args = dict()
    required_args['_raw_params'] = args

    # Build up argument spec
    argument_spec = dict()
    argument_spec['_raw_params'] = dict(type='list',
                                        required=True,
                                        no_log=True)

    # Instantiate module

# Generated at 2022-06-23 03:15:27.995232
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:36.918882
# Unit test for function check_command
def test_check_command():
    global module
    for command in ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch', 'curl', 'wget', 'svn',
                    'service', 'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip', 'sed', 'dnf', 'zypper', 'sudo', 'su',
                    'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        check_command(module, command)
    check_command(module, ['chown'])
    check_command(module, ['chmod'])
    check_command(module, ['chgrp'])
    check_command(module, ['ln'])
    check_command(module, ['mkdir'])


# Generated at 2022-06-23 03:15:39.049219
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict()
    )
    check_command(module, 'command')

# Return file information

# Generated at 2022-06-23 03:15:45.911197
# Unit test for function check_command
def test_check_command():
    commandline = 'ls /foo/bar'
    module = AnsibleModule(commandline=commandline, check_mode=True, supports_check_mode=True)
    check_command(module, commandline)
    assert [module.warn_args] == ['Consider using the file module rather than running '
                                  "'ls'.  If you need to use 'ls' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]



# Generated at 2022-06-23 03:15:57.435756
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chmod 755 /blah/blah')
    assert module.warnings == [
        "Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."], module.warnings
    check_command(module, 'chown sylvain /blah/blah')

# Generated at 2022-06-23 03:16:09.508345
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    assert module.warn.called is False
    check_command(module, 'foo')
    assert module.warn.called is False
    check_command(module, ['chown', 'bar'])
    assert 'file' in module.warn.call_args_list[0][0][0]
    assert 'owner' in module.warn.call_args_list[0][0][0]
    assert 'foo' not in module.warn.call_args_list[0][0][0]
    assert 'file' not in module.warn.call_args_list[1][0][0]
    assert 'bar' not in module.warn.call_args_list[1][0][0]