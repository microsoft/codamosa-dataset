

# Generated at 2022-06-23 03:06:10.662711
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        {'executable': {'type': 'path'},
         '_raw_params': {'type': 'str'}}
    )
    mod.run_command = lambda args, **kw: (0, '', '')
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:23.124782
# Unit test for function main
def test_main():
  class Module:
    argument_spec = None
    check_mode = False

    def __init__(self, params):
      self.params = params
      self.run_command = lambda *argv, **kwargs: (0, u"STDOUT", u"STDERR")

    def fail_json(self, params):
      raise Exception(params)

    def exit_json(self, params):
      assert params is not None
      return params


# Generated at 2022-06-23 03:06:26.607410
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            cmd=dict(type='str', required=False),
            argv=dict(type='list', elements='str'),
        ),
    )

    check_command(module, commandline=['ls', '-a'])
    check_command(module, commandline=['/usr/bin/ls', '-a'])
    check_command(module, commandline='ls -a')
    check_command(module, commandline='/usr/bin/ls -a')



# Generated at 2022-06-23 03:06:37.179391
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable
    module = AnsibleModule(supports_check_mode=True)
    assert module.check_mode == True
    assert module.ansible_version == "2.5.5"
    assert module.ansible_facts == {}
    assert module.params['_uses_shell'] == False
    assert module.params['chdir'] == None
    assert module.params['executable'] == None
    assert module.params['creates'] == None
    assert module.params['removes'] == None
    assert module.params['warn'] == False
    assert module.params['stdin'] == None
    assert module.params['stdin_add_newline'] == True

# Generated at 2022-06-23 03:06:42.941505
# Unit test for function check_command
def test_check_command():
    warn_msg = "Consider using the file module with chmod rather than running 'chmod'.  If you need to use 'chmod' "
    warn_msg += "because the file module is insufficient you can add 'warn: false' to this command task or set "
    warn_msg += "'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    class TestWarn(object):
        def __init__(self, arg):
            self.arg = arg
        def __call__(self, s):
            assert s == self.arg
    test_cmd = ['chmod', '777', '/tmp/ok']
    test_module = type('', (object,), {'warn': TestWarn(warn_msg)})
    check_command(test_module, test_cmd)



# Generated at 2022-06-23 03:06:49.017851
# Unit test for function check_command
def test_check_command():
    commandline = "echo hello"
    module = AnsibleModule(
        argument_spec=dict(
            chdir=dict(type='path'),
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            executable=dict(type='path'),
            _args=dict(type='list'),
            _antsibull_warnings=dict(type='list', default=[]),
            warn=dict(type='bool', default=True),
            creates=dict(),
        ),
        supports_check_mode=True,
    )
    check_command(module, commandline)


# Generated at 2022-06-23 03:07:01.668331
# Unit test for function check_command
def test_check_command():
    """
    Test check_command
    """
    m_mock = MagicMock()
    check_command(m_mock, 'yum install -y tree')
    m_mock.warn.assert_called_once_with("Consider using the yum module rather than running 'yum'.")
    m_mock.reset_mock()

    check_command(m_mock, 'chmod 777 /tmp/foo')
    m_mock.warn.assert_called_once_with("Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message.")
    m_mock.reset_m

# Generated at 2022-06-23 03:07:04.432829
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        args = dict(
            executable='echo',
            args=['echo', 'hello'],
        )
        main(**args)

if __name__ == '__main__':
    main()