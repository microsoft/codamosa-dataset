

# Generated at 2022-06-23 03:06:06.888361
# Unit test for function check_command
def test_check_command():
  assert True



# Generated at 2022-06-23 03:06:17.860486
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    for cmd in ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        check_command(module, cmd)
    for cmd in ['chown', 'chmod', 'chgrp']:
        check_command(module, [cmd])
    for cmd in ['ln', 'mkdir', 'rmdir', 'rm', 'touch']:
        check_command(module, [cmd])
    for cmd in ['curl', 'wget']:
        check_command(module, [cmd])
    for cmd in ['svn']:
        check_command(module, [cmd])
    for cmd in ['service']:
        check_command(module, [cmd])

# Generated at 2022-06-23 03:06:28.410961
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            commandline=dict(type='raw'),
            warn=dict(type='bool', default=True),
        ),
        check_invalid_arguments=False,
    )
    check_command(module, '/bin/mkdir')
    check_command(module, ['cat', '/etc/motd'])
    assert module.warnings[0] == "Consider using the file module with state=directory rather than running '/bin/mkdir'.  If you need to use '/bin/mkdir' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

# Generated at 2022-06-23 03:06:37.588902
# Unit test for function check_command
def test_check_command():
    module, commandline = Mock(), 'foo'
    try:
        check_command(module, commandline)
    except SystemExit:
        pass
    assert not module.fail_json.called
    assert module.warn.call_count == 0

    module.warn.reset_mock()
    commandline = ['curl', 'http://www.example.com']
    check_command(module, commandline)
    assert module.warn.call_count == 1
    assert module.warn.call_args[0][0].startswith("Consider using the get_url or uri module")
    assert module.warn.call_args[0][0].endswith("to get rid of this message.")

    module.warn.reset_mock()
    commandline = ['touch', '/foo.txt']

# Generated at 2022-06-23 03:06:44.436622
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({}, check_mode=True)
    check_command(module, 'ln -s target link')
    assert "running 'ln'" in module.warnings[0]
    check_command(module, 'mount -o loop /tmp/foo /mnt')
    assert 'mount' in module.warnings[1]
    check_command(module, 'rpm -ivh foo')
    assert 'running' in module.warnings[2]



# Generated at 2022-06-23 03:06:55.119977
# Unit test for function main
def test_main():
    args = dict(
        _raw_params = '''/usr/bin/make_database.sh ''',
        _uses_shell = False,
        argv = ['sh'],
        chdir = '/tmp',
        executable = '',
        creates = '/path/to/database',
        removes = '',
        warn ='',
        stdin = '',
        stdin_add_newline = True,
        strip_empty_ends = True
    )


# Generated at 2022-06-23 03:07:04.530336
# Unit test for function main
def test_main():
    from ansible.module_utils import basic


# Generated at 2022-06-23 03:07:15.558746
# Unit test for function check_command
def test_check_command():
    # basic list command
    cmd = ['echo', 'hello']
    m = AnsibleModule(argument_spec={})
    m._ansible_check_mode = False
    check_command(m, cmd)
    # basic string command
    cmd = 'echo hello'
    m = AnsibleModule(argument_spec={})
    m._ansible_check_mode = False
    check_command(m, cmd)
    # warn disabled
    cmd = 'echo hello'
    m = AnsibleModule(argument_spec={'warn': False})
    m._ansible_check_mode = False
    check_command(m, cmd)
    # redirected echo
    cmd = 'echo hello 1>/dev/null'
    m = AnsibleModule(argument_spec={})
    m._ansible_check_mode = False
    check_

# Generated at 2022-06-23 03:07:26.229516
# Unit test for function main
def test_main():
    ansible_builtin_command_path = "ansible.builtin.command"
    if ansible_builtin_command_path in sys.modules:
        del sys.modules[ansible_builtin_command_path]
    import ansible.modules.system.command as command
    sys.modules["ansible.builtin.command"] = command

    class AnsibleModuleMock(object):
        def __init__(self, argument_spec=None, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

        def fail_json(self, rc=None, msg=None, **kwargs):
            raise Exception("fail_json called")

        def exit_json(self, rc=None, msg=None, **kwargs):
            exit

# Generated at 2022-06-23 03:07:38.417786
# Unit test for function check_command
def test_check_command():
    # dummy module object
    class DummyModule:
        def __init__(self, s):
            self.warnings = []
        def warn(self, s):
            self.warnings.append(s)
    module = DummyModule('')
    check_command(module, 'apt-get install foo')

# Generated at 2022-06-23 03:07:47.926823
# Unit test for function main

# Generated at 2022-06-23 03:07:56.622294
# Unit test for function main
def test_main():
    # Building fake module
    class MyModule(object):
        def __init__(self):
            self.params = {
                            "argv": None,
                            "chdir": None,
                            "creates": None,
                            "removes": None,
                            "shell": True,
                            "stdin": None,
                            "_raw_params": "echo hello",
                            "stdin_add_newline": None,
                            "strip_empty_ends": None,
                            "warn": None,
                            "executable": None,
                        }

        def run_command(self, args, executable=None, use_unsafe_shell=False, data=None, binary_data=False):
            return 0, "ok", ""


# Generated at 2022-06-23 03:08:06.661148
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

# Generated at 2022-06-23 03:08:21.413205
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils._text import to_native, to_bytes, to_text


# Generated at 2022-06-23 03:08:34.697142
# Unit test for function check_command
def test_check_command():
    # Create a fake module
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])
        def warn(self, *args):
            print(args)

    for cmd in ('sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl'):
        with pytest.raises(Exception):
            mod = TestModule(command=cmd)
            check_command(mod, cmd)


# Generated at 2022-06-23 03:08:43.810607
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'ln -s')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')

# Generated at 2022-06-23 03:08:57.269202
# Unit test for function check_command
def test_check_command():
    class module(object):
        def __init__(self, warn=None, debug=None):
            self.warn = warn
            self.debug = debug

    # Test functional cases
    m = module(warn=True)
    check_command(m, ['test', '1', '2'])
    check_command(m, ['test'])
    check_command(m, ['test', '1', '2'])
    check_command(m, ['test', '1', '2'])
    check_command(m, ['test', '1', '2'])
    check_command(m, ['test', '1', '2'])
    check_command(m, ['test', '1', '2'])

    # Test edge cases
    m = module(warn=False)

# Generated at 2022-06-23 03:09:07.248475
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self, check_mode=False):
            self.check_mode = check_mode

    fake_module = FakeModule()
    check_command(fake_module, 'chown')
    check_command(fake_module, 'svn')
    check_command(fake_module, 'sudo')
    check_command(fake_module, ['ls', '-la'])
    check_command(fake_module, 'ls')
    check_command(fake_module, 'chmod')
    check_command(fake_module, 'touch')
    check_command(fake_module, 'ln')
    check_command(fake_module, 'rmdir')
    check_command(fake_module, 'rm')



# Generated at 2022-06-23 03:09:18.002115
# Unit test for function main
def test_main():
    arguments = {'_raw_params': 'whoami', '_uses_shell': True, 'argv': [], 'chdir': '', 'executable': None, 'creates': '', 'removes': '', 'warn': False, 'stdin': '', 'stdin_add_newline': True, 'strip_empty_ends': True}

# Generated at 2022-06-23 03:09:21.524226
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ["asdfasdf", "echo", "hello"])
    check_command(module, ["asdfasdf", "echo", "hello"])



# Generated at 2022-06-23 03:09:29.582020
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.warnings import AnsibleWarning

    module = AnsibleModule(argument_spec={})
    module.warn = lambda *args, **kwargs: None

    def assert_warned(command, **kwargs):
        check_command(module, command.split())
        assert module.warn.call_count == 1
        assert module.warn.call_args_list[0][0][0].startswith('Consider using the ')
        assert 'file' in module.warn.call_args_list[0][0][0]

        if kwargs.get('module'):
            assert kwargs.get('module') in module.warn.call_args_list[0][0][0]

        if kwargs.get('subcommand'):
            assert kwargs.get('subcommand')

# Generated at 2022-06-23 03:09:40.032586
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule(argument_spec={})
    check_command(mod, "echo")
    check_command(mod, ["echo", "hello"])
    check_command(mod, "chown me file")
    check_command(mod, ["chown", "me", "file"])
    check_command(mod, "chmod u+x file")
    check_command(mod, ["chmod", "u+x", "file"])
    check_command(mod, "chgrp admin file")
    check_command(mod, ["chgrp", "admin", "file"])
    check_command(mod, "ln -s /path/to/target /path/to/link")
    check_command(mod, ["ln", "-s", "/path/to/target", "/path/to/link"])
   

# Generated at 2022-06-23 03:09:51.548484
# Unit test for function main

# Generated at 2022-06-23 03:10:04.238473
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(argument_spec={})
    check_command(test_module, ['chmod', '0755', '/path/to/file'])
    assert not test_module.fail_json.called
    output = test_module._output.pop()
    assert output == "Consider using the file module with mode rather than running 'chmod'.  " \
                     "If you need to use 'chmod' because the file module is insufficient you can add 'warn: false'" \
                     " to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg" \
                     " to get rid of this message."
    check_command(test_module, ['tar', 'xzf', 'archive.tar.gz'])
    assert not test_module.fail_json.called
    output = test_module

# Generated at 2022-06-23 03:10:13.801948
# Unit test for function main
def test_main():
    args = {
        "_raw_params": "echo hello",
        "chdir": "somedir/",
        "executable": "",
        "creates": "/path/to/database",
        "removes": "",
        "warn": False,
        "stdin": "",
        "stdin_add_newline": True,
        "strip_empty_ends": True,
    }
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    main(args, r)


# Generated at 2022-06-23 03:10:17.182447
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'sudo ls')
    check_command(module, ['rm', '/tmp/foo'])
    check_command(module, ['echo', 'foo'])



# Generated at 2022-06-23 03:10:21.323062
# Unit test for function main
def test_main():
    args = {}
    args['creates'] = '/tmp/file.txt'
    args['removes'] = '/tmp/file.txt'
    main(args)

# import unit tests
from ansible.module_utils import basic
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:32.034979
# Unit test for function check_command
def test_check_command():
    import sys
    import ansible.modules.extras.io.command as command
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.compat.tests import unittest

    m = sys.modules[command.__module__]
    m.AnsibleModule = basic.AnsibleModule
    m.to_native = to_native
    m.is_iterable = is_iterable

    fake_module_args = dict(
        command='foo bar',
        warn=False,
    )
    fake_module = basic.AnsibleModule(**fake_module_args)
    m.warn = fake_module.warn

# Generated at 2022-06-23 03:10:40.860189
# Unit test for function main
def test_main():
    tmp_paths = ['/tmp/ansible.builtin.command.run_command.rc', '/tmp/ansible.builtin.command.run_command.stdout']
    tmp_paths.append('/tmp/ansible.builtin.command.run_command.stderr')

    for path in tmp_paths:
        if os.path.exists(path):
            os.remove(path)
        assert not os.path.exists(path)

    command_rc = """#!/bin/bash
echo $? > /tmp/ansible.builtin.command.run_command.rc
"""
    with open('/tmp/ansible.builtin.command.run_command.rc.py', 'w') as f:
        f.write(command_rc)


# Generated at 2022-06-23 03:10:43.974136
# Unit test for function check_command
def test_check_command():
    command = 'echo hello'
    module = AnsibleModule(command=command, warn=True)

    check_command(module, 'echo')
    check_command(module, ['echo'])
    check_command(module, ['echo', 'hello'])



# Generated at 2022-06-23 03:10:56.671443
# Unit test for function check_command
def test_check_command():
    class FakeCommandWarnModule(object):
        def __init__(self):
            self._warn_msg = None
        def warn(self, msg):
            self._warn_msg = msg
    def get_warn_msg(command):
        module = FakeCommandWarnModule()
        check_command(module, command)
        return module._warn_msg

    # test argument warnings
    assert get_warn_msg('/bin/chown') == "Consider using the file module with owner rather than running '/bin/chown'.  If you need to use '/bin/chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

# Generated at 2022-06-23 03:11:05.788034
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default='ls'),
            _uses_shell=dict(default='False', type='bool'),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    main()

# Generated at 2022-06-23 03:11:15.289841
# Unit test for function check_command
def test_check_command():
    import ansible.constants
    ansible.constants.HOST_KEY_CHECKING = False
    module = AnsibleModule(argument_spec={})
    assert not check_command(module, 'sed foo')
    assert not check_command(module, ['sed', 'foo'])
    assert not check_command(module, 'svn checkout /foo')
    assert not check_command(module, 'wget http://foo')
    assert not check_command(module, ['foo'])
    assert not check_command(module, '/foo')
    assert not check_command(module, 'python foo')
    assert not check_command(module, 'chmod 0644 foo')
    assert not check_command(module, 'chown foo:foo foo')
    assert not check_command(module, 'chgrp foo foo')

# Generated at 2022-06-23 03:11:29.851974
# Unit test for function main
def test_main():
    def ansible_run_command_mock(args, executable, use_unsafe_shell, data, binary_data):
        return (0, 'stdout', 'stderr')

    def os_chdir_mock(path):
        return

    # Mock
    import __builtin__ as builtins
    builtins.open = open

    # Replace
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule.run_command = ansible_run_command_mock
    os.chdir = os_chdir_mock

    # Test
    command_stderr = 'env: ansible-command: No such file or directory\n'
    parent_group_id = os.getegid()

# Generated at 2022-06-23 03:11:39.350877
# Unit test for function main
def test_main():
    global args
    global module
    global chdir
    global executable
    global argv
    global creates
    global removes
    global warn
    global stdin
    global stdin_add_newline
    global strip
    global r
    global shell
    global shoulda

# Generated at 2022-06-23 03:11:52.349758
# Unit test for function main

# Generated at 2022-06-23 03:12:01.558935
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = Mock()
    # Check arguments
    check_command(module, '/bin/chown user /tmp')
    assert module.warn.call_count == 1
    module.warn.reset_mock()
    check_command(module, ['/bin/chmod', '755', '/tmp'])
    assert module.warn.call_count == 1
    module.warn.reset_mock()
    check_command(module, '/bin/chgrp group /tmp')
    assert module.warn.call_count == 1
    module.warn.reset_mock()
    check_command(module, '/bin/ln -s /usr/local/bin/python /bin/python')
    assert module.warn.call_count == 1
    module.warn.reset_m

# Generated at 2022-06-23 03:12:06.929157
# Unit test for function check_command
def test_check_command():

    # Setup mock module
    testmodule = AnsibleModule(
        argument_spec = dict(
            commandline = dict(type='list', required=True),
            warnings = dict(type='bool', default=True),
            diff_mode = dict(type='bool', default=False),
            creates = dict(type='path'),
            removes = dict(type='path'),
        )
    )

    check_command(testmodule, ['ls', 'foo'])

    # Test if warning message is generated.
    if testmodule.params['warnings']:
        assert 'module' in testmodule.warnings[0]['msg']
    else:
        assert len(testmodule.warnings) == 0



# Generated at 2022-06-23 03:12:11.568435
# Unit test for function main
def test_main():
    import mock

    import ansible.module_utils.basic
    ansible.module_utils.basic.RETRYABLE_EXCEPTIONS.append(RuntimeError)

    module = mock.MagicMock()
    module.check_mode = False
    module.exit_json.side_effect = SystemExit

    # test main called with argv
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:18.743707
# Unit test for function main
def test_main():
    params = {'_raw_params': 'mkdir /tmp/test', 'chdir': '/tmp', 'creates': 'foo.cfg',
              'removes': 'bar.cfg', 'warn': True, '_uses_shell': False}
    r = main(params)

    assert True == r['changed']


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:27.219603
# Unit test for function main
def test_main():
    # command_raw not used global variable
    # args not used global variable
    # AnsibleModule() not used global variable
    # module not used global variable
    # to_native() not used global variable
    # to_bytes() not used global variable
    # to_text() not used global variable
    # is_iterable() not used global variable
    # os.path.basename() not used global variable
    # os.chdir() not used global variable
    # shlex.split() not used global variable
    # datetime.datetime.now() not used global variable
    # datetime.datetime not used global variable
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:37.787552
# Unit test for function main
def test_main():
    test_args = {
        "_raw_params": "echo hello, ",
        "chdir": "/home/contint/test/ansible",
        "creates": "sample.txt",
        "executable": "/bin/bash",
        "removes": "sample.txt",
        "warn": True,
        "_uses_shell": True,
        "argv": [
            "echo",
            "hello,"
        ],
        "stdin": "yes",
        "stdin_add_newline": True,
        "strip_empty_ends": True
    }


# Generated at 2022-06-23 03:12:45.728766
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    # test for valid arguments
    assert module.params['_uses_shell']

# Generated at 2022-06-23 03:12:50.447756
# Unit test for function check_command
def test_check_command():
    module = type('MockModule', (object,), {
        'warn' : lambda *args: None,
        'changed' : False
    })
    check_command(module, 'curl http://www.google.com/')
    assert module.changed == False
    assert getattr(module, 'warn', False)
    check_command(module, 'ansible-test-command')
    assert module.changed == False
    assert not getattr(module, 'warn', False)


# Generated at 2022-06-23 03:12:59.228950
# Unit test for function main
def test_main():
  sample_output = {
    "start": "2017-12-07 16:38:46.405835",
    "delta": "0:00:00.040849",
    "stderr": "",
    "end": "2017-12-07 16:38:46.446684",
    "cmd": ["pwd"],
    "stdout": "/",
    "msg": "",
    "rc": 0,
    "changed": False
  }


# Generated at 2022-06-23 03:13:08.836417
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "_ansible_no_log": False,
        "argv": ["date", "+%Y-%m-%d", "--date", "yesterday"],
        "chdir": None,
        "creates": None,
        "executable": None,
        "removes": None,
        "stdin": None,
        "stdin_add_newline": True,
        "strip_empty_ends": True,
        "warn": False,
        "_raw_params": "",
        "_uses_shell": False})

    results = main()
    assert results["rc"] == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:16.066022
# Unit test for function check_command
def test_check_command():
    """Check check_command function with defined checks"""

    # Args and Command
    module = MockModule()
    check_command(module, 'chown foo:foo /tmp/')
    assert module.warnings[0] == "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

    # Args and Command
    module = MockModule()
    check_command(module, ['chgrp', 'bar', '/tmp/'])

# Generated at 2022-06-23 03:13:18.726114
# Unit test for function main
def test_main():
    args = dict(
        creates='test.txt'
    )
    set_module_args(args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:23.105542
# Unit test for function main
def test_main():
    try:
        with open('tests/command_ansible.json') as fd:
            module_args = json.load(fd)
        p = Mock(**module_args)
        main()
    except SystemExit:
        pass


# Generated at 2022-06-23 03:13:24.525214
# Unit test for function check_command
def test_check_command():
    assert check_command



# Generated at 2022-06-23 03:13:36.999326
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.warn_count = 0
            self.warn_msg = ''
            self.warn = self.warn_ansible_module

        def warn_ansible_module(self, msg):
            self.warn_count += 1
            self.warn_msg += msg

    testmodule = TestModule()
    # Test with a single command
    check_command(testmodule, '/usr/bin/make_database.sh db_user db_name creates=/path/to/database')
    assert testmodule.warn_count == 0
    check_command(testmodule, '/bin/touch')
    assert testmodule.warn_count == 1

    # Test with a list of commands
    testmodule.warn_count = 0

# Generated at 2022-06-23 03:13:44.566593
# Unit test for function main
def test_main():
    # FIXME: Make this a proper unit test
    args = dict(
        _raw_params='echo hello',
        chdir='/',
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True)
    with AnsibleModule(argument_spec=args) as module:
        r = main(module)
        assert r['rc'] == 0
        assert to_text(r['stdout']).rstrip() == 'hello'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:56.513483
# Unit test for function main
def test_main():
    module_args = dict(
    )
    module = AnsibleModule(module_args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:58.071866
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:14:03.809718
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/bin/ls')
    assert not module.fail_json.called
    check_command(module, 'ls')
    assert not module.fail_json.called
    check_command(module, ['ls'])
    assert not module.fail_json.called


# ===========================================
# Main control flow


# Generated at 2022-06-23 03:14:14.001979
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    # test command substitution
    module.warn = lambda x: check_command.substitutions.update({'warned': x})
    check_command.substitutions.clear()
    check_command(module, '/bin/ls')
    assert check_command.substitutions['warned'] == "Consider using the file module with state=directory rather than running 'ls'.  If you need to use 'ls' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check_command.substitutions.clear()
    check_command(module, '/usr/bin/ln')

# Generated at 2022-06-23 03:14:26.319105
# Unit test for function main

# Generated at 2022-06-23 03:14:32.457383
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module.warn = lambda msg: None
    module.check_command(to_bytes('/bin/ls', errors='surrogate_or_strict'), [to_bytes('ls')])



# Generated at 2022-06-23 03:14:42.532986
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    #mock_stdin_handle = StringIO(u'o\n')
    #mock_stdin_handle.isatty = lambda: False
    #mock_stdin_handle.readline = lambda: u'o\n'
    #mock_stdin_handle.read = lambda: u'o\n'
    mock_stdin_handle = u'o\n'
    mock_stdin_handle.fileno = lambda: 0

# Generated at 2022-06-23 03:14:46.621218
# Unit test for function check_command
def test_check_command():

    module = AnsibleModule(argument_spec=dict())
    check_command(module, ['rsync'])
    assert module.warnings == []
    check_command(module, ['sudo'])
    assert module.warnings != []



# Generated at 2022-06-23 03:14:58.789598
# Unit test for function check_command
def test_check_command():
    # Create a mock for module
    module = type('module', (object,), {'warn': lambda msg: msg})
    # Test with 'yum' command
    check_command(module, '/usr/bin/yum')
    # Test with 'ls' command
    check_command(module, '/usr/bin/ls')
    # Test with 'dev/null' command
    check_command(module, '/usr/bin/dev/null')
    # Test with sudo command
    check_command(module, 'sudo')
    # Test with a list of test commands
    check_command(module, ['/usr/bin/yum', 'echo', 'hello'])
    # Test unicode handling
    check_command(module, u'\u304a\u306f\u3088\u3046')


# Generated at 2022-06-23 03:15:00.554080
# Unit test for function check_command
def test_check_command():
    commandline=['ln']
    module=AnsibleModule
    assert check_command(module,commandline)==None


# Generated at 2022-06-23 03:15:03.079829
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    check_command(mod, "pbrun test")




# Generated at 2022-06-23 03:15:12.577155
# Unit test for function main
def test_main():
    # Test function main with all args
    args = dict(
        _raw_params=dict(),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        # The default for this really comes from the action plugin
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )
    module = Ansible

# Generated at 2022-06-23 03:15:13.461265
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-23 03:15:14.605273
# Unit test for function check_command
def test_check_command():
    assert 0 == check_command()


# Generated at 2022-06-23 03:15:25.841609
# Unit test for function check_command
def test_check_command():
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-23 03:15:27.615412
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:29.295966
# Unit test for function main
def test_main():
	print("Inside test_main")
	assert True
	#assert False


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:15:41.934076
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    assert module.warnings == ['Consider using the file module with owner rather than running \'chown\'.  '
            'If you need to use \'chown\' because the file module is insufficient you can add \'warn: false\' '
            'to this command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get '
            'rid of this message.']
    check_command(module, 'mount')

# Generated at 2022-06-23 03:15:52.767067
# Unit test for function main
def test_main():
    test_args = {
        '_raw_params': 'cat /etc/motd',
        'creates': '/etc/motd',
        'chdir': '', 
        'executable': '',
        'removes': '',
        'strip_empty_ends': '',
        'warn': ''
    }

# Generated at 2022-06-23 03:15:54.633066
# Unit test for function check_command
def test_check_command():
    assert check_command(type('module', (object,), {}), '/bin/rm')



# Generated at 2022-06-23 03:15:58.844764
# Unit test for function main
def test_main():
    result = main()
    assert result == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:16:00.163564
# Unit test for function check_command
def test_check_command():
    assert check_command("/bin/ls /tmp") == None


# Generated at 2022-06-23 03:16:11.806389
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            # The default for this really comes from the action plugin
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin')
        ),
        supports_check_mode=True,
    )
    shell = module.params['_uses_shell']
    chdir = module.params['chdir']
    executable = module.params['executable']
    args = module