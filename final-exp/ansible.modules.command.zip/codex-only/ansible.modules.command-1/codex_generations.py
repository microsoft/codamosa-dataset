

# Generated at 2022-06-23 03:06:14.691879
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(
            command=dict(type='str', required=False),
        )
    )
    check_command(module, commandline=["/bin/mv", "/etc/sudoers", "/tmp"])
    check_command(module, commandline=["/bin/chmod", "a+r", "/etc/sudoers"])
    check_command(module, commandline=["/bin/chown", "root", "/etc/sudoers"])
    check_command(module, commandline=["/bin/chgrp", "root", "/etc/sudoers"])
    check_command(module, commandline=["/bin/ln", "/bin/bash", "/bin/sh"])

# Generated at 2022-06-23 03:06:18.746233
# Unit test for function main
def test_main():

    arguments = {'_raw_params': 'cd /home/cyruslab/Workspace/', '_uses_shell': True, 'chdir': '/home/cyruslab/Workspace/', 'creates': '/home/cyruslab/Desktop/test.txt', 'removes': None, 'stdin': None, 'stdin_add_newline': True, 'strip_empty_ends': True, 'warn': False}


# Generated at 2022-06-23 03:06:22.397333
# Unit test for function main
def test_main():
  argv = [1,2,3]
  argv = shlex.split(argv)
  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:32.591491
# Unit test for function main
def test_main():
    a = AnsibleModule({
        "executable": "",
        "removes": "",
        "argv": "",
        "creates": "",
        "chdir": "",
        "_raw_params": "",
        "_uses_shell": "",
        "strip_empty_ends": True,
        "warn": False,
        "stdin": ""
    })
    a.run_command = lambda command : (0, "Test", "")
    try:
        main()
    except Exception as error:
        print("error!!!")
        print(error)


# Generated at 2022-06-23 03:06:35.053624
# Unit test for function main
def test_main():
    # TODO: work out how we test this
    #       It's not something that can be tested only using unit tests.
    pass

# import module snippets
from ansible.module_utils.basic import *
main()

# Generated at 2022-06-23 03:06:39.638444
# Unit test for function main

# Generated at 2022-06-23 03:06:50.381422
# Unit test for function check_command
def test_check_command():
    # set up mock module
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/make_database.sh db_user db_name')
    # test warning messages
    assert module.warn.call_count == 4
    assert module.warn.call_args[0][0] == "Consider using the {mod} module rather than running '{cmd}'.  If you need to use '{cmd}' because the {mod} module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    assert 'Make_database.sh' in module.warn.call_args[0][0]
    assert 'get_url' in module.warn.call_args[0][0]

# Generated at 2022-06-23 03:07:01.806194
# Unit test for function main
def test_main():
    module = MagicMock()
    module.run_command.return_value = True
    module.check_mode = False
    module.exit_json.return_value = True
    chdir = '/bin'
    executable = None
    args = 'echo hello'
    module.params = {'_raw_params': args, '_uses_shell': False,
                     'argv': None, 'chdir': chdir, 'executable': executable, 'creates': True,
                     'removes': True, 'warn': False, 'r': {
                     },
                     }
    main()

# Generated at 2022-06-23 03:07:03.123825
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(command_warnings=True)
    commandline = '/bin/foo'
    check_command(module, commandline)
    assert True



# Generated at 2022-06-23 03:07:12.573539
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    #Check for non-existent file
    check_command(module, "echo /etc/motd")
    check_command(module, ["echo", "/etc/motd"])
    #Check for files that do exist
    check_command(module, "echo /etc/passwd")
    check_command(module, ["echo", "/etc/passwd"])
    #Check random string
    check_command(module, "ls /usr/local")
    check_command(module, ["ls", "/usr/local"])

# import module snippets
from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 03:07:24.027178
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "cp test /tmp/foo")
    check_command(module, "mkdir /tmp/foo")
    check_command(module, "rm -rf /tmp/foo")
    check_command(module, "chmod 0777 /tmp/foo")
    check_command(module, "chown root /tmp/foo")
    check_command(module, "chgrp root /tmp/foo")
    check_command(module, "/usr/bin/curl https://www.ansible.com/")
    check_command(module, "/usr/bin/wget https://www.ansible.com/")
    check_command(module, "/usr/bin/apt-get install apache2")

# Generated at 2022-06-23 03:07:33.810528
# Unit test for function main
def test_main():
    main()

# noinspection PyUnresolvedReferences
from ansible.module_utils.basic import AnsibleModule
# noinspection PyUnresolvedReferences
from ansible.module_utils._text import to_native
# noinspection PyUnresolvedReferences
from ansible.module_utils.common.collections import is_iterable
from ansible.module_utils.connection import Connection

from ansible_collections.ansible.builtin.plugins.module_utils.argspec.command import command_spec
from ansible_collections.ansible.builtin.plugins.module_utils.argspec.command import command_argument_spec



# Generated at 2022-06-23 03:07:45.104988
# Unit test for function main
def test_main():
    args = dict(
        _raw_params = "ls -ltr",
        _uses_shell = False,
        argv = ['/bin/ls', '-ltr'],
        chdir = "/tmp",
        executable = "/bin/ls",
        creates = "/tmp/test_file",
        removes = "/tmp/test_file",
        warn = False,
        stdin = None,
        stdin_add_newline = True,
        strip_empty_ends = True,
    )

# Generated at 2022-06-23 03:07:52.695637
# Unit test for function check_command
def test_check_command():
    # We need to test the function without actually calling module.warn since
    # the function will fail if we actually call warn.  So we hack in a
    # call to a throwaway object here that we'll just test to make sure it's
    # called
    #
    # The best way to do this would be to use mock and have the method return
    # a mock object.  But that requires that the function be decorated with
    # @mock.patch which we can't do since the function is already defined in
    # this file.
    #
    # So instead, we define a class that throws an exception if warn is called
    # and then instantiate it and pass it in to check_command.  This way, if
    # warn is called, we get an exception.
    class MockModule:
        def __init__(self, testcase):
            self

# Generated at 2022-06-23 03:08:05.423568
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.command import Command
    from ansible.errors import AnsibleError
    from ansible.utils.color import stringc


# Generated at 2022-06-23 03:08:14.239681
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    check_command(module, "ansible-doc")
    check_command(module, ["ansible-doc", "--version"])
    check_command(module, "wget foo")
    check_command(module, ["wget", "foo"])
    check_command(module, "apt-get install lsb-release")
    check_command(module, ["apt-get", "install", "lsb-release"])
    check_command(module, "chown foo:bar /baz")
    check_command(module, ["chown", "foo:bar", "/baz"])
    check_command(module, "tar xjf foo.tar.bz2")
    check_command(module, ["tar", "xjf", "foo.tar.bz2"])


# Generated at 2022-06-23 03:08:20.730077
# Unit test for function main

# Generated at 2022-06-23 03:08:30.078107
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    commands = ['echo hi', 'curl localhost', 'echo "rm -rf /" | sudo', 'chmod +x foo', 'tar xf site.tgz', 'service foo start']
    for cmdline in commands:
        try:
            check_command(module, cmdline)
        except Exception as e:
            module.fail_json(msg="unexpected exception when running check_command(%s): %s" % (to_native(cmdline), to_native(e)))



# Generated at 2022-06-23 03:08:40.465941
# Unit test for function check_command
def test_check_command():

    class TestModule(object):
        def __init__(self):
            self.warn = []

        def warn(self, warning):
            self.warn.append(warning.replace('\n', ' '))

    test_module = TestModule()
    check_command(test_module, "froam")
    assert len(test_module.warn) == 0

    test_module = TestModule()
    check_command(test_module, "touch")
    assert len(test_module.warn) == 1
    assert "file" in test_module.warn[0]
    assert "state=touch" in test_module.warn[0]
    assert "ansible.cfg" in test_module.warn[0]
    assert "warn" in test_module.warn[0]

    test_module = TestModule()
    check

# Generated at 2022-06-23 03:08:53.863295
# Unit test for function main

# Generated at 2022-06-23 03:09:00.684685
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ["/usr/bin/echo", "hello"])

    # No warning if the command is in the list of available commands
    module = AnsibleModule(argument_spec={}, available_variables=dict(command='echo'))
    check_command(module, ["echo", "hello"])



# Generated at 2022-06-23 03:09:14.048173
# Unit test for function main

# Generated at 2022-06-23 03:09:24.737704
# Unit test for function main
def test_main():
    args={}
    args['_raw_params'] = ''
    args['_uses_shell'] = False
    args['argv'] = []
    args['chdir'] = None
    args['executable'] = None
    args['creates'] = None
    args['removes'] = None
    args['warn'] = False
    args['stdin'] = None
    args['stdin_add_newline'] = True
    args['strip_empty_ends'] = True
    main(args)

if __name__ == '__main__':
    import sys
    import imp
    import os
    import pkgutil
    from ansible.module_utils.basic import *
    from ansible.module_utils.common.collections import is_iterable


# Generated at 2022-06-23 03:09:37.644600
# Unit test for function check_command
def test_check_command():
    try:
        import ansible.modules.system.command as cmd
        from ansible.utils.home_location import return_legacy_mode_root_path
        import ansible.utils.vars as ansible_vars
        import ansible.constants as constants
    except ImportError:
        print('SKIPPED: ansible.modules.system.command is unavailable')
        return


# Generated at 2022-06-23 03:09:42.186719
# Unit test for function main
def test_main():
    a = dict()
    b = dict()
    a['rc']=0
    b['rc']=0
    assert main(a) == main(b)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:51.029953
# Unit test for function main
def test_main():
    argv=None
    #Test 0
    module = AnsibleModule()
    # Test 1

# Generated at 2022-06-23 03:10:03.500938
# Unit test for function main
def test_main():
    r = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )

    # test with none, non-iterable and non-string iterable
    args = None
    assert _flatten(args) == []

    args = 1
    assert _flatten(args) == []

    args = [1, 2, 3]
    assert _flatten(args) == []

    # test with iterable of non-string and strings
    args = [1, 2, 3, '1', '2', '3']
    assert _flatten(args) == ['1', '2', '3']

    # test with iterable of non-string and strings and

# Generated at 2022-06-23 03:10:13.670642
# Unit test for function main
def test_main():
    # run module (in check-mode) to get output parameters
    set_module_args(dict(
        args='/bin/df -k',
        executable='/bin/bash',
        warn=True,
        chdir='/tmp'
    ))
    out = my_module.main()
    assert out['rc'] == 0
    assert out['start'] is not None
    assert out['end'] is not None
    assert out['delta'] is not None
    assert out['chdir'] == '/tmp'

# Generated at 2022-06-23 03:10:15.496402
# Unit test for function check_command
def test_check_command():
    check_command(None, 'mkdir')
    check_command(None, 'test')



# Generated at 2022-06-23 03:10:25.272890
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule

    def fake_module_warn(self, arg):
        return arg

    module = AnsibleModule({})
    module.warn = fake_module_warn
    command = 'chown'
    expected_result = "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check_command(module, command)
    assert module.warnings[0] == expected_result



# Generated at 2022-06-23 03:10:33.686429
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict()
    )
    check_command(module, ['chown raleigh'])
    check_command(module, ['chmod -p 755'])
    check_command(module, ['chgrp wheel'])
    check_command(module, ['ln /tmp/foo /tmp/bar'])
    check_command(module, ['mkdir /tmp/bar'])
    check_command(module, ['rmdir /tmp/bar'])
    check_command(module, ['rm /tmp/bar'])
    check_command(module, ['touch /tmp/bar'])
    check_command(module, ['curl https://no_such.invalid'])
    check_command(module, ['wget https://no_such.invalid'])
    check_command

# Generated at 2022-06-23 03:10:43.089908
# Unit test for function check_command
def test_check_command():
    """Test command argument check"""

    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'machinectl')

# Generated at 2022-06-23 03:10:45.872547
# Unit test for function check_command
def test_check_command():
    #NOTE: Implement a unit test for this function.  This is challenging since there are module warnings in the function and we can't get the warnings out of the context to verify them.
    assert False



# Generated at 2022-06-23 03:10:51.515125
# Unit test for function check_command
def test_check_command():
    commandline = 'test -f /test_file'
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
        )
    )
    module.check_command(module, commandline)
    assert not module.warn.called


# Generated at 2022-06-23 03:10:58.856685
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule, get_exception
    import sys

    if sys.version_info[:2] == (2, 6):
        module = AnsibleModule(argument_spec=dict(command=dict(type='str')))
    else:
        class MockAnsibleModule:
            def __init__(self, argument_spec):
                self.argument_spec = argument_spec
                self.params = {}
                self.fail_json = self.warn = self.deprecate = lambda d, msg: msg
            def fail_json(self, *args, **kwargs):
                raise Exception(kwargs['msg'])

        module = MockAnsibleModule(argument_spec=dict(command=dict(type='str')))
        setattr(module, 'check_mode', True)



# Generated at 2022-06-23 03:10:59.496395
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-23 03:11:13.348712
# Unit test for function main

# Generated at 2022-06-23 03:11:23.265546
# Unit test for function check_command
def test_check_command():
    """Command module - check_command - alias, warning"""
    module = AnsibleModule(argument_spec={})
    check_command(module, 'sudo ls')
    assert module.warnings == ['Consider using \'become\', \'become_method\', and \'become_user\' '
                               'rather than running sudo']



# Generated at 2022-06-23 03:11:36.313916
# Unit test for function check_command
def test_check_command():
  dummy_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
  # Ensure warnings are generated for commands that are known to be modules
  check_command(dummy_module, ['/bin/cp', 'file', 'dest'])
  assert 'file' in dummy_module.warnings[0]
  del dummy_module.warnings[:]
  check_command(dummy_module, ['/usr/bin/chmod', '700', 'file'])
  assert 'file' in dummy_module.warnings[0]
  del dummy_module.warnings[:]
  check_command(dummy_module, ['/usr/bin/svn', 'checkout'])
  assert 'subversion' in dummy_module.warnings[0]
  del dummy_module.warnings[:]
  # Ensure

# Generated at 2022-06-23 03:11:37.959571
# Unit test for function check_command
def test_check_command():
    check_command()


# Generated at 2022-06-23 03:11:45.916415
# Unit test for function main
def test_main():
    args = {}
    args.update({"_raw_params": None})
    args.update({"_uses_shell": False})
    args.update({"argv": None})
    args.update({"chdir": None})
    args.update({"executable": None})
    args.update({"creates": None})
    args.update({"removes": None})
    args.update({"warn": False})
    args.update({"stdin": None})
    args.update({"stdin_add_newline": True})
    args.update({"strip_empty_ends": True})
    main(args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:57.088026
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.common.collections

# Generated at 2022-06-23 03:11:58.293860
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:04.372618
# Unit test for function check_command
def test_check_command():
    """ This is not a real test yet.  Just a method to call the function
    to see what it does.  Will probably need to mock some other functions
    to make it work properly.
    """

    # Create the module object
    module = AnsibleModule({'warn': True}, supports_check_mode=True)
    check_command(module, ['echo', 'hello'])



# Generated at 2022-06-23 03:12:13.202186
# Unit test for function check_command
def test_check_command():
    module = type('', (), {})()
    module.warn = lambda message: None
    if hasattr(check_command, 'warnings'):
        check_command.warnings = []
    else:
        check_command.warnings = []
    commandline = ['chown', 'test_user', 'test_file']
    check_command(module, commandline)
    assert len(check_command.warnings) == 1
    assert check_command.warnings[0] == \
        "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

# Generated at 2022-06-23 03:12:23.680955
# Unit test for function check_command
def test_check_command():
    os.environ['ANSIBLE_STRIP_UNPRINTABLE'] = 'False'
    m = AnsibleModule(argument_spec={'command': {'type': 'str'}, '_ansible_check_mode': {'type': 'bool'}}, check_invalid_arguments=False)
    m.params['_ansible_check_mode'] = True
    m.params['command'] = '/usr/bin/check_command.sh'
    check_command(m, m.params['command'])

    # file module
    m.params['command'] = 'chown'
    check_command(m, m.params['command'])

    # apt module
    m.params['command'] = 'apt-get'
    check_command(m, m.params['command'])

    # rpm module

# Generated at 2022-06-23 03:12:25.070185
# Unit test for function main
def test_main():
    assert True == True


if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-23 03:12:36.362889
# Unit test for function check_command
def test_check_command():
    mock_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert check_command(mock_module, '/bin/chown') is None
    assert check_command(mock_module, '/bin/chmod') is None
    assert check_command(mock_module, '/bin/chgrp') is None
    assert check_command(mock_module, '/bin/ln') is None
    assert check_command(mock_module, '/bin/mkdir') is None
    assert check_command(mock_module, '/bin/rmdir') is None
    assert check_command(mock_module, '/bin/rm') is None
    assert check_command(mock_module, '/bin/touch') is None

# Generated at 2022-06-23 03:12:46.749549
# Unit test for function check_command
def test_check_command():
    import imp, sys
    m = imp.new_module('test')
    m.warn = lambda *args, **kwargs: sys.stdout.write(repr(args) + repr(kwargs) + '\n')
    m.fail_json = lambda *args, **kwargs: sys.stdout.write(repr(args) + repr(kwargs) + '\n')
    m.exit_json = lambda *args, **kwargs: sys.stdout.write(repr(args) + repr(kwargs) + '\n')

    check_command(m, '/usr/bin/make_database.sh db_user db_name creates=/path/to/database')
    check_command(m, '/usr/bin/curl http://www.ansible.com/')

# Generated at 2022-06-23 03:12:58.340812
# Unit test for function check_command
def test_check_command():
    meta = {"warnings": []}
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=False, no_log=True)
    test_module.params["check_mode"] = False
    test_module.params["warn"] = True
    check_command(test_module, 'chown')
    warnings = meta["warnings"]
    assert warnings == [
        "Consider using the file module with chown rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    ], warnings

# Generated at 2022-06-23 03:13:03.731123
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.warn = lambda x: None
    for i in ['service', 'mount', 'rm', 'rpm', 'touch', 'sed', 'sudo']:
        check_command(module, [i])



# Generated at 2022-06-23 03:13:13.418799
# Unit test for function check_command
def test_check_command():
    args = dict(warn='yes', executable=dict(type='str'))
    check_command_class = type('AnsibleModule', (object,), dict(
        params=lambda self: args,
        warn=lambda self, msg: module.fail_json(msg='Warn found: %s' % msg),
    ))
    # Create a mock module
    module = check_command_class()
    commandline = ['chown', 'owner']
    check_command(module, commandline)
    commandline = ['chmod', 'mode']
    check_command(module, commandline)
    commandline = ['chgrp', 'group']
    check_command(module, commandline)
    commandline = ['ln', 'state=link']
    check_command(module, commandline)

# Generated at 2022-06-23 03:13:22.925425
# Unit test for function check_command
def test_check_command():
    test_dict = {'command': '/bin/curl foo bar', 'warn': True}
    module_test = AnsibleModule({'command': '/bin/curl foo bar', 'warn': True},
                                check_invalid_arguments=False)
    check_command(module_test, test_dict['command'])
    assert module_test.warnings[0] == "Consider using the get_url or uri module rather than running " \
        "'curl'.  If you need to use 'curl' because the get_url or uri module is insufficient you can " \
        "add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section " \
        "of ansible.cfg to get rid of this message."

# Generated at 2022-06-23 03:13:35.761889
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

# Generated at 2022-06-23 03:13:45.599382
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(check_mode=dict(type='bool', default=False)))
    check_command(module, 'curl http://example.com')
    check_command(module, 'yum install foo')
    check_command(module, 'wget http://example.com')
    check_command(module, 'svn co http://example.com')
    check_command(module, 'service httpd start')
    check_command(module, 'mount /dev/foo /bar')
    check_command(module, 'rpm -ivh foo')
    check_command(module, 'tar xf foo.tar')
    check_command(module, 'unzip foo.zip')
    check_command(module, 'sed s/foo/bar/g file')

# Generated at 2022-06-23 03:13:55.260264
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(
        argument_spec={'warn': {'type': 'bool', 'default': True}},
        supports_check_mode=True
    )
    check_command(m, 'sudo /bin/foo')
    assert m._warnings == [
        "Consider using 'become', 'become_method', and 'become_user' rather than running sudo"
    ], m._warnings
    m = AnsibleModule(
        argument_spec={'warn': {'type': 'bool', 'default': True}},
        supports_check_mode=True
    )
    check_command(m, 'chmod')

# Generated at 2022-06-23 03:14:06.028543
# Unit test for function main
def test_main():
    mybase = os.path.abspath(__file__)
    mybase = os.path.dirname(mybase)
    playbooks_dir = os.path.join(mybase, "../../test/integration/targets/playbooks")
    temp_dir = os.path.join(playbooks_dir, "../temp")
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)
    file_path = os.path.join(temp_dir, "foo.txt")
    cmd = "echo hello"
    result = main()
    assert result is None
    if os.path.exists(file_path):
        os.remove(file_path)


# Generated at 2022-06-23 03:14:15.706342
# Unit test for function main

# Generated at 2022-06-23 03:14:26.210530
# Unit test for function check_command
def test_check_command():
    module = MockModule()
    command = ['touch', '/path/to/somewhere']
    check_command(module, command)
    assert module.warnings == [
        "Consider using the file module with state=touch rather than running 'touch'.  If you need to use 'touch' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    ]

    command = ['echo', 'hello']
    module = MockModule()
    check_command(module, command)
    assert module.warnings == []



# Generated at 2022-06-23 03:14:36.145371
# Unit test for function main
def test_main():
    #assert True
    # Testcase 1
    # Output of command is 0
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None,
         'delta': None, 'msg': ''}
    r['rc'] = 0

    # Testcase 2
    # Output of command is not 0
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None,
         'delta': None, 'msg': ''}
    r['rc'] = 1

    # Testcase 3
    # rc is greater than 255

# Generated at 2022-06-23 03:14:45.772626
# Unit test for function check_command

# Generated at 2022-06-23 03:14:55.923500
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.modules.utilities.logic import check_command
    from ansible.parsing.yaml.objects import AnsibleUnicode

    module = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str', required=True),
            cmd=dict(type='str'),
        ),
    )
    commandline = AnsibleUnicode('ln')
    check_command(module, commandline)
    commandline = AnsibleUnicode('chmod')
    check_command(module, commandline)


# Generated at 2022-06-23 03:15:06.279520
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        class FakeResult:
            def __init__(self):
                self.warnings = []
            def _log(self, msg, level):
                self.warnings.append(msg)

        def __init__(self):
            self.result = FakeResult()

        def warn(self, msg):
            self.result._log(msg, 'warn')

    for cmd in [
        'ansible-command',
        ['ansible-command'],
        'ansible-command arg',
        ['ansible-command', 'arg'],
    ]:
        yield check_command, FakeModule(), cmd
        assert FakeModule.result.warnings == []


# Generated at 2022-06-23 03:15:15.146723
# Unit test for function check_command
def test_check_command():
    test_commands = ['curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip', 'sed', 'dnf', 'zypper']
    test_arguments = ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch']
    test_become = ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']
    class Result(object):
        def __init__(self):
            self.warnings = []
    class Module(object):
        def __init__(self):
            self.params = {'warn': True}
        def warn(self, msg):
            self.warnings.append

# Generated at 2022-06-23 03:15:26.296668
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.common.warnings as warnings

    # Create module to run checks on
    module = AnsibleModule(argument_spec={})

    # Check for basic warning command
    check_command(module, 'cat')
    assert not len(warnings._WARNINGS)

    # Check for basic warning command (list)
    check_command(module, ['cat'])
    assert not len(warnings._WARNINGS)

    # Check for a warning command
    check_command(module, 'chmod')
    assert len(warnings._WARNINGS)

    # Check for a warning command (list)
    check_command(module, ['chmod'])
    assert len(warnings._WARNINGS)

    # Check for a warning command with sudo
    check_command

# Generated at 2022-06-23 03:15:29.791541
# Unit test for function main
def test_main():
    # NOTE: need test for:
    #   assert args
    #   check_command call
    #   check_mode
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:41.523985
# Unit test for function main
def test_main():
    params = { "_raw_params": "echo hello", "_uses_shell": True, "argv": [ "echo", "hello" ], "chdir": "/etc", "creates": "/etc", "executable": "/bin/zsh", "removes": "/usr/bin", "warn": False, "stdin": None, "stdin_add_newline": True, "strip_empty_ends": True }
    params = { "_raw_params": "uname -a", "_uses_shell": False, "argv": None, "chdir": None, "creates": None, "executable": None, "removes": None, "warn": True, "stdin": None, "stdin_add_newline": True, "strip_empty_ends": True }
    main()

# Generated at 2022-06-23 03:15:45.273815
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    testmodule = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(testmodule, "/bin/echo")


# ===========================================
# Command module support methods.
#


# Generated at 2022-06-23 03:15:53.687500
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_bytes, to_text
    from ansible.module_utils.common.collections import is_iterable
    import os
    import shlex
    import glob


# Generated at 2022-06-23 03:16:00.864306
# Unit test for function main
def test_main():
    args = dict(_raw_params='ls -la') if PY2 else dict(_raw_params=['ls', '-la'])
    with pytest.raises(AnsibleExitJson) as exc:
        main()
    result = exc.value.args[0]
    assert result['rc'] == 0
    assert result['stdout'] != ''
    assert result['stderr'] == ''
    assert result['msg'] == ''
    assert result['changed'] == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:16:05.659567
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = ["touch", "junk"]
    check_command(module, commandline)
    commandline = "tar xfz foo.tgz"
    check_command(module, commandline)

# ===========================================
# Main control flow
