

# Generated at 2022-06-23 03:06:12.002827
# Unit test for function main
def test_main():
    test_args = [
        ['arg1', 'arg2']
    ]

    import sys
    import json

# Generated at 2022-06-23 03:06:24.246653
# Unit test for function main
def test_main():
    def run_command(args, **kwargs):
        return 0, "some output", ""
    args = "running_command"
    check_mode = False
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    module = AnsibleModule(
        argument_spec = dict()
    )
    setattr(module, 'run_command', run_command)
    setattr(module, 'check_mode', check_mode)
    setattr(module, 'params', {'_raw_params': args})

    try:
        main()
    except SystemExit as ex:
        if ex.args[0] == 0:
            # "success"
            pass
        else:
            raise

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:35.292090
# Unit test for function main

# Generated at 2022-06-23 03:06:41.301809
# Unit test for function check_command
def test_check_command():
    args = dict(command='echo "hello"')
    m = AnsibleModule(argument_spec={'command': dict(type='str', required=True)}, supports_check_mode=True)
    # command = 'echo "hello"'
    # m = AnsibleModule(argument_spec={'command': dict(type='str', required=True)})
    check_command(m, args['command'])



# Generated at 2022-06-23 03:06:47.688760
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    module.warn = lambda msg: None
    check_command(module, ['touch'])
    check_command(module, 'touch')
    check_command(module, ['chmod'])
    check_command(module, 'chmod')
    check_command(module, ['ls'])
    check_command(module, 'ls')


# Generated at 2022-06-23 03:06:55.963355
# Unit test for function check_command
def test_check_command():
    # Test default command
    cmd = '/bin/ls'
    module = AnsibleModule({'command': cmd}, check_invalid_arguments=False)
    check_command(module, cmd)
    assert module.warn.call_count == 1
    module.warn.assert_called_with("Consider using the file module with state=directory rather than running '/bin/ls'.  If you need to use '/bin/ls' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message.")

    # Test command not in list
    module.reset_mock()
    cmd = '/bin/mv'
    check_command(module, cmd)
    assert module.warn.call_count == 0

    # Test command in list

# Generated at 2022-06-23 03:07:04.821039
# Unit test for function main

# Generated at 2022-06-23 03:07:10.084287
# Unit test for function main
def test_main():
    module = AnsibleModule()
    module.exit_json = lambda *args, **kwargs: exit_args.update(kwargs) or exit_args
    main()

# Generated at 2022-06-23 03:07:14.716655
# Unit test for function main
def test_main():
    m = AnsibleModule(argument_spec={'_raw_params': {'type': 'str'}, 'chdir': {'type': 'str'}, 'executable': {'type': 'str'}, 'creates': {'type': 'str'}, 'removes': {'type': 'str'}, 'warn': {'default': False, 'type': 'bool'}, 'stdin': {'required': False, 'type': 'str'}, 'stdin_add_newline': {'default': True, 'type': 'bool'}, 'strip_empty_ends': {'default': True, 'type': 'bool'}})

# Generated at 2022-06-23 03:07:17.442767
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': {'type': 'list'}})
    check_command(module, ['curl', 'http://localhost'])



# Generated at 2022-06-23 03:07:33.759668
# Unit test for function check_command
def test_check_command():
    command = 'sudo apt-get -y install nginx'
    module = AnsibleModule(command=command)

    check_command(module, command)

    command = 'tar xvf foo.tar'
    module = AnsibleModule(command=command)

    check_command(module, command)

    command = 'chmod 600 /etc/sudoers'
    module = AnsibleModule(command=command)

    check_command(module, command)

    command = 'su - pbrun'
    module = AnsibleModule(command=command)

    check_command(module, command)

    command = 'service foo start'
    module = AnsibleModule(command=command)

    check_command(module, command)

    command = 'rpm -ivh foo.rpm'
    module = AnsibleModule(command=command)

    check

# Generated at 2022-06-23 03:07:45.062607
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils._text import to_native, to_bytes


# Generated at 2022-06-23 03:07:46.247016
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:07:48.297479
# Unit test for function check_command
def test_check_command():
    # TODO: Write tests for this function - does not appear to be called anywhere
    pass

# https://github.com/ansible/ansible/issues/15491

# Generated at 2022-06-23 03:07:53.982684
# Unit test for function check_command
def test_check_command():
    result = dict(warnings=[], changed=False)
    warning = dict(msg=None)
    result['warnings'].append(warning)
    module = MockModule(result)
    commandline = "chown foo bar"
    check_command(module, commandline)
    assert module._result == dict(warnings=[dict(msg="Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."), dict(msg=None)], changed=False)
    module = MockModule(result)
    commandline = "chmod foo bar"
    check_command(module, commandline)
    assert module._result

# Generated at 2022-06-23 03:07:57.558719
# Unit test for function check_command
def test_check_command():
  module = AnsibleModule({})
  assert check_command(module, 'touch foo') == None
  assert check_command(module, 'mkdir foo') == None
  assert check_command(module, 'curl bar') == None


# Generated at 2022-06-23 03:08:08.158427
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='command',
        chdir='~/',
        executable='execute',
        creates='create',
        removes='remove',
        warn=True,
        stdin='stdin',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = get_module(args)

    assert main() == module.exit_json(changed=True,
        cmd='command',
        delta='0:00:00',
        end='2018-02-10 22:58:39',
        msg='',
        rc=0,
        start='2018-02-10 22:58:39',
        stderr='',
        stdout=''
    )


# Generated at 2022-06-23 03:08:15.028682
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ['touch','file'])
    check_command(module, ['rm','-rf','/'])
    check_command(module, ['sudo','touch','file'])
    check_command(module, ['mkdir','dir'])


# Generated at 2022-06-23 03:08:17.259003
# Unit test for function main
def test_main():
    '''
    Unit test for function main from module ansible.module_utils.basic
    '''
    pass

# can't test for exit code of module, so instead we just trap the standard import and redirect to our stub
if __name__ == '__main__':
    test_main()
    print("You need to run this module with python -m unittest test_command, also see the README.md for details")

# Generated at 2022-06-23 03:08:20.225981
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    # Unit test for function with real input
    test_main()

# Generated at 2022-06-23 03:08:28.353545
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, command):
            self.params = {'command': command}

        def warn(self, msg):
            self.warning = msg

    module = TestModule('touch /tmp/test')
    check_command(module, module.params['command'])
    assert module.warning == "Consider using the file module with state=touch rather than running 'touch'."
    module = TestModule('yum list')
    check_command(module, module.params['command'])
    assert module.warning == "Consider using the yum module rather than running 'yum'."



# Generated at 2022-06-23 03:08:33.382972
# Unit test for function main
def test_main():
    # Remove if the function is defined in the file
    del main


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:34.460997
# Unit test for function main
def test_main():
    print("test")


# Generated at 2022-06-23 03:08:44.971712
# Unit test for function main
def test_main():
    args = dict( _raw_params='echo hello', _uses_shell=False, argv=['echo', 'hello'],
                 chdir='/tmp', executable=None, creates='/random',
                 removes='/random', stdin=None, stdin_add_newline=True,
                 strip_empty_ends=True)

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    # mock module object
    setattr(basic, 'AnsibleModule', MockAnsibleModule)


    # mock args and execute

# Generated at 2022-06-23 03:08:52.536066
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec={},
        is_base_platform=False,
    )
    check_command(module, '/bin/ls')
    check_command(module, ['/bin/ls'])
    check_command(module, 'curl http://www.ansible.com')
    check_command(module, 'chmod +x foo.bar')
    check_command(module, '/usr/bin/chmod +x foo.bar')
    check_command(module, '/bin/mount /dev/foo /mnt/bar')
    check_command(module, 'machinectl shell foo.bar /bin/ls')
    # Quietly does nothing
    check_command(module, 'ansible-foo-bar')



# Generated at 2022-06-23 03:09:02.801160
# Unit test for function main
def test_main():
    info = {"test_parameter":"test_value","_raw_params": "test_value"}
    with patch.object(AnsibleModule, "__init__") as am:
        with patch.object(AnsibleModule, "run_command") as rc:
            rc.return_value = (0,"test_stdout","test_stderr")
            am.return_value = None
            with patch.object(AnsibleModule, "exit_json") as ej:
                ej.return_value = None
                main()

# Generated at 2022-06-23 03:09:15.046487
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={'command': {'required': True},
                                     'warn': {'type': 'bool', 'default': False},
                                     'executable': {'required': False},
                                     'chdir': {'required': False},
                                     'creates': {'required': False},
                                     'removes': {'required': False},
                                     'stdin': {'required': False},
                                     'stdin_add_newline': {'type': 'bool', 'default': True},
                                     })

    # test warnings
    m.warn = mock_module_warn
    m.warn.messages = []
    check_command(m, 'curl')

# Generated at 2022-06-23 03:09:25.227788
# Unit test for function main

# Generated at 2022-06-23 03:09:38.129928
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            args=dict(type='list', required=True),
        ),
        supports_check_mode=True
    )
    module.fail_json = lambda *args: None
    module.warn = lambda msg: msg

# Generated at 2022-06-23 03:09:40.017536
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:41.125056
# Unit test for function check_command
def test_check_command():
    assert check_command == check_command



# Generated at 2022-06-23 03:09:52.366887
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    module.warn = lambda x: x
    # Check that known modules get flagged in command string
    check_command(module, '/bin/chmod 644 foo')
    check_command(module, ['tar', 'xf', '/tmp/foo.tar'])

    # Check that known modules get flagged in command array
    check_command(module, ['/bin/chmod', '644', 'foo'])
    check_command(module, ['/bin/rm', '/tmp/foo'])
    check_command(module, ['/bin/rpm', '-Uvh', '/tmp/foo.rpm'])

    # Check that known become get flagged in command string
    check_command(module, 'sudo /bin/chmod 644 foo')

# Generated at 2022-06-23 03:09:57.465153
# Unit test for function main
def test_main():
    args = ['ansible-playbook', '--syntax-check', 'test-command.yml']
    args = ['-s'] + args # source activate
    args = ['-c', 'local'] + args
    cmd = " ".join(args)
    os.system(cmd)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:10:09.745443
# Unit test for function check_command
def test_check_command():
    # check_result is the returned list of ansible warnings to be matched against expected warnings
    # This test does not check for the addition of (or absence of) ansible warnings
    check_result = []
    class TestModule(object):
        def __init__(self, check_result):
            self.check_result = check_result
        def warn(self, msg):
            self.check_result.append(msg)
    test_module = TestModule(check_result)
    # This tests for a command that has a corresponding Ansible module with one argument
    check_command(test_module, 'chown')
    # This tests for a command that has a corresponding Ansible module with several arguments
    check_command(test_module, 'ln')
    # This tests for a command that has more than one possible corresponding Ansible module

# Generated at 2022-06-23 03:10:18.124661
# Unit test for function main

# Generated at 2022-06-23 03:10:29.064745
# Unit test for function main

# Generated at 2022-06-23 03:10:32.387680
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule(argument_spec={'check_cmd': {'type': 'str', 'required': False}})
    test_command = 'testcmd'
    result = check_command(mod, test_command)
    mod.exit_json(result=result)



# Generated at 2022-06-23 03:10:37.847043
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "cat /etc/resolv.conf")
    check_command(module, "sed -i s/foo/bar/g /etc/hosts")
    check_command(module, ["chmod", "777", "/opt/xyz"])


# Generated at 2022-06-23 03:10:45.522703
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def __init__(self):
            self._ansible_no_log = False
        def warn(self, msg):
            assert 'command_warnings' in msg
    commandline = ['command']
    test_check_command.check_command(commandline)



# Generated at 2022-06-23 03:10:51.514496
# Unit test for function main
def test_main():
    test_args = ['ansible-test', 'command', '--trace']
    with pytest.raises(SystemExit):
        main()

    with pytest.raises(SystemExit):
        main(args=test_args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:02.886320
# Unit test for function check_command
def test_check_command():
    # First test, valid warning
    module = AnsibleModule(argument_spec={})
    mock_module = MagicMock()
    mock_module.warn.return_value = None
    with patch.object(AnsibleModule, '__init__', return_value=None):
        with patch.dict(AnsibleModule.argument_spec, {}):
            AnsiModule = AnsibleModule(argument_spec={})
            AnsiModule.params = {'warn': True}
            AnsiModule._warnings = []
            AnsiModule.run_command = MagicMock(name='run_command', return_value=('test line', 'test line', 0, None))
            result = check_command(AnsiModule, ['test', 'command'])

# Generated at 2022-06-23 03:11:11.021645
# Unit test for function main
def test_main():
    # Imports required by unit tests and namespace
    import time
    import sys
    import shlex
    import subprocess
    import json
    import os

    # Create a local function to use in unit tests as a module

# Generated at 2022-06-23 03:11:22.387098
# Unit test for function check_command
def test_check_command():
    class TestModule:
        def warn(self, msg):
            raise AssertionError("Should not call warn")
    t = TestModule()

    assert check_command(t, 'curl') is None
    assert check_command(t, 'wget') is None
    assert check_command(t, 'tar') is None
    assert check_command(t, 'mount') is None
    assert check_command(t, 'rpm') is None
    assert check_command(t, 'yum') is None
    assert check_command(t, 'svn') is None
    assert check_command(t, 'sed') is None
    assert check_command(t, 'apt-get') is None
    assert check_command(t, 'unzip') is None
    assert check_command(t, 'chmod') is None

# Generated at 2022-06-23 03:11:35.189402
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    assert module
    check_command(module, 'touch /tmp/testfile')
    check_command(module, 'echo test')
    check_command(module, 'sudo touch /tmp/testfile')
    check_command(module, 'svn co http://myrepo/svn/somedir/')
    check_command(module, 'service iptables restart')
    check_command(module, 'mount /dev/sda1 /mountpoint/')
    check_command(module, 'rpm -qa')
    check_command(module, 'yum install -y somepackage')
    check_command(module, 'apt-get update')
    check_command(module, 'tar xzf /path/to/file.tar.gz')
   

# Generated at 2022-06-23 03:11:45.948015
# Unit test for function check_command
def test_check_command():

    def test_module(name, params):
        """Function to make test module"""
        warnings = []
        def warn(msg):
            warnings.append(msg)
        module = type('AnsibleModule', (object,), {'params': params, 'warn': warn})
        return module, warnings

    params = {'warn': True}
    module, warnings = test_module('command', params)
    check_command(module, 'curl')
    assert 'curl' in warnings[0]
    check_command(module, 'wget')
    assert 'wget' in warnings[1]
    check_command(module, 'svn')
    assert 'svn' in warnings[2]
    check_command(module, 'service')
    assert 'service' in warnings[3]

# Generated at 2022-06-23 03:11:56.915521
# Unit test for function main
def test_main():
    #Test the return code path
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    r['rc'] = 256
    r['msg'] = "no command given"
    module.warn = lambda x: x
    module.fail_json.side_effect = Exception('fail_json called')
    module.run_command.side_effect = OSError('run_command called')
    module.exit_json.side_effect = Exception('exit_json called')
    with pytest.raises(Exception) as excinfo:
        main()
    assert excinfo.value.args[0] == 'fail_json called'
    module.fail_json.side_

# Generated at 2022-06-23 03:12:08.490925
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='command',
        _uses_shell=True,
        argv=['commands'],
        chdir='chdir',
        executable='executable',
        creates='creates',
        removes='removes',
        warn=False,
        stdin='stdin',
        stdin_add_newline=True,
        strip_empty_ends=True
    )
    module = AnsibleModule(**args)
    module.exit_json = lambda r: False
    module.fail_json = lambda **kargs: False
    module.run_command = lambda args, **_: (0, '', '')
    module.warn = lambda m: False
    module.check_mode = False

    module.params = args

    result = main()

# Generated at 2022-06-23 03:12:22.070467
# Unit test for function main
def test_main():
    args = {
        "chdir": ".",
        "creates": "test_main.txt",
        "executable": None,
        "removes": "test_main.txt",
        "warn": False,
        "_raw_params": "touch test_main.txt",
        "stdin": "my_input",
        "stdin_add_newline": True,
        "strip_empty_ends": True,
        "argv": "touch test_main.txt",
        "_ansible_check_mode": False,
        "_ansible_debug": False,
        "_ansible_diff": False,
        "_ansible_verbosity": 0,
        "_uses_shell": True
    }
    # call function main with module args
    retval = main()

# Generated at 2022-06-23 03:12:25.222578
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:34.537627
# Unit test for function check_command
def test_check_command():
    """Validate check_command function"""
    from ansible.module_utils.common.collections import Mapping
    module = Mapping()
    module.warn = lambda msg: msg
    # valid input, check output
    rtn = check_command(module, 'chmod')
    assert rtn == "Consider using the file module with mode rather than running 'chmod'.  " \
                  "If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to " \
                  "this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."



# Generated at 2022-06-23 03:12:46.617537
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = lambda a: a
    command = 'echo hello'
    check_command(module, command)
    assert module.warnings[0] == "Consider using 'become', 'become_method', and 'become_user' rather than running echo"
    command = ['echo hello']
    check_command(module, command)
    assert module.warnings[1] == "Consider using 'become', 'become_method', and 'become_user' rather than running echo"
    command = 'curl http://domain.com'
    check_command(module, command)

# Generated at 2022-06-23 03:12:53.594415
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="echo hello",
        _uses_shell=False,
        argv=False,
        chdir=False,
        executable=False,
        creates=False,
        removes=False,
        warn=True,
        stdin=False,
        stdin_add_newline=True,
        strip_empty_ends=True,
        supports_check_mode=True,
    )
    obj = AnsibleModule(**args)
    commands.getoutput("rm -rf /tmp/test_main")
    check_command(obj, "echo hello")
test_main()

# Generated at 2022-06-23 03:13:06.968781
# Unit test for function main
def test_main():
    objects = {}
    def main_mock_module(** kwargs):
        module = AnsibleModule(**kwargs)
        objects['module'] = module
        return module

    # TODO: Add testing for AnsibleModule with argument_spec = dict(
    # _raw_params = dict(),
    # _uses_shell = dict(type = 'bool', default = False),
    # argv = dict(type = 'list', elements = 'str'),
    # chdir = dict(type = 'path'),
    # executable = dict(),
    # creates = dict(type = 'path'),
    # removes = dict(type = 'path'),
    # warn = dict(type = 'bool', default = False, removed_in_version = '2.14', removed_from_collection = 'ansible.builtin'),
    # stdin =

# Generated at 2022-06-23 03:13:12.837725
# Unit test for function main
def test_main():
    args = 'echo hello'
    executable = None
    use_unsafe_shell = False
    no_log = False
    encoding = None
    stdin = None
    binary_data = None
    data = 'test'
    chdir = 'test'
    os.chdir(chdir)
    
    # Returns tuple of return code, stdout, and stderr
    r = module.run_command(args, executable, use_unsafe_shell, no_log, encoding,
                           stdin, binary_data, data)
    

# Generated at 2022-06-23 03:13:22.646974
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    result = check_command(m, 'echo hello world')
    assert m.warn.call_args_list == []
    result = check_command(m, 'curl http://example.com')

# Generated at 2022-06-23 03:13:27.834484
# Unit test for function check_command
def test_check_command():
    module_mock = MockAnsibleModule()
    check_command(module_mock, 'command')
    assert module_mock.warn.call_count == 5

# Generated at 2022-06-23 03:13:39.061591
# Unit test for function check_command
def test_check_command():
    class ModuleArgs():
        def __init__(self, commandline, no_log, warn=False):
            self.args = commandline
            self.no_log = no_log
            self.warn = warn
    class Warnings():
        def __init__(self):
            self.append = self.append2

        def append2(self, msg):
            self.msg = msg

    mycommand = ModuleArgs(commandline=['/sbin/add-user', 'ghost', 'fish'], no_log=False, warn=True)
    mywarnings = Warnings()
    mywarnings.msg = ''
    mycommand.warn = mywarnings.append
    check_command(mycommand, mycommand.args)

# Generated at 2022-06-23 03:13:50.548769
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-23 03:13:52.401106
# Unit test for function main
def test_main():
    assert main() == 'changed'


# Generated at 2022-06-23 03:13:53.852696
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:14:04.630221
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import MutableMapping

    MOCK_BASIC_PARSED_ARGS = MutableMapping()

# Generated at 2022-06-23 03:14:08.374912
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
      foo=dict(required=False, aliases=['bar'], type='str', default=None)
    )
  )
  main()
  
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:14:17.032521
# Unit test for function main

# Generated at 2022-06-23 03:14:29.251343
# Unit test for function main
def test_main():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch, MagicMock

    class TestCommand(unittest.TestCase):

        def setUp(self):
            self.mock_module = MagicMock()
            self.mock_module.run_command.return_value = (0, 'fake_out', 'fake_error')
            self.mock_module.check_mode = False

# Generated at 2022-06-23 03:14:40.511724
# Unit test for function main

# Generated at 2022-06-23 03:14:52.973588
# Unit test for function main
def test_main():
    test_args = {"_raw_params": "ls /home/user/", "_uses_shell": False, "argv": ["ls", "home", "user"], "chdir": "home/user", "executable": "/bin/bash",
                 "creates": "home/user", "removes": "home/user", "warn": True, "stdin": "stdin",
                 "stdin_add_newline": True, "strip_empty_ends": True}

# Generated at 2022-06-23 03:14:55.490217
# Unit test for function main
def test_main():
    # Test with default values
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:02.956363
# Unit test for function main
def test_main():
    args = {
        "_raw_params": "Hello World!",
        "_uses_shell": False,
        "argv": [
            "Hello",
            "World!"
        ],
        "chdir": "/tmp/chdir_test",
        "creates": "/tmp/creates_test",
        "executable": "Hello World!",
        "removes": "/tmp/removes_test",
        "warn": False,
        "stdin": "Hello World!",
        "stdin_add_newline": True,
        "strip_empty_ends": True
    }

# Generated at 2022-06-23 03:15:04.680345
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:13.327805
# Unit test for function check_command
def test_check_command():
    class DummyModule(object):
        def __init__(self):
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)

    module = DummyModule()
    check_command(module, 'chown')
    assert module.warnings[0] == "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    module.warnings = []
    check_command(module, ['/bin/chown'])

# Generated at 2022-06-23 03:15:24.700288
# Unit test for function main
def test_main():
    data = dict(
        _raw_params="echo hello",
        chdir="/tmp",
        executable="/usr/bin/echo",
        creates="/tmp/testfile",
        removes="/tmp/testfile2",
        warn="True",
        stdin="True",
        stdin_add_newline="True",
        strip_empty_ends="True"
    )


# Generated at 2022-06-23 03:15:34.794057
# Unit test for function main
def test_main():
    args = dict(
        executable="/usr/bin/ansible",
        creates="bar",
        removes="foo",
        args="whoami",
        warn=True,
    )
    result = dict(
        changed=False,
        cmd=['whoami'],
        end=None,
        failed=False,
        invocations={
            'module_args': ['whoami'],
            'module_complex_args': {},
            'module_name': 'raw'
        },
        rc=0,
        start=None,
        stderr='',
        stdout=''
    )

# Generated at 2022-06-23 03:15:40.753816
# Unit test for function check_command
def test_check_command():
    # command: touch /tmp/foo
    assert check_command(commandline='touch /tmp/foo') == 'touch'
    # command: touch /tmp/foo
    assert check_command(commandline=['touch', '/tmp/foo']) == 'touch'
#/ Unit test for function check_command



# Generated at 2022-06-23 03:15:45.317084
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            free_form=dict(),
            args=dict(type='dict', no_log=True),
            executable=dict()
        ),
        supports_check_mode=True,
    )
    check_command(module, ['touch', 'foo'])



# Generated at 2022-06-23 03:15:49.451504
# Unit test for function check_command
def test_check_command():
    module = DummyModule()
    commandline = ['touch', '/foo/bar']
    check_command(module, commandline)
    assert "Consider using the file module with state=touch rather than running 'touch'." in module.warnings_to_return


# Generated at 2022-06-23 03:15:57.410665
# Unit test for function check_command
def test_check_command():
    # Strings
    # First command
    test_command1 = 'sudo  -S -p ''  bash -c " echo BECOME-SUCCESS-aefvzyrjatxinagkavlxztnnbvnkfzrh ; LANG=C LC_ALL=C LC_MESSAGES=C /usr/bin/python /home/ralph/.ansible/tmp/ansible-tmp-1502129752.84-142953415720438/command1; rm -rf \"/home/ralph/.ansible/tmp/ansible-tmp-1502129752.84-142953415720438/\" > /dev/null 2>&1" && sleep 0'

# Generated at 2022-06-23 03:15:59.490566
# Unit test for function main
def test_main():

    # Call main()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:16:11.139566
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.check_command(module, 'ls')
    module.check_command(module, 'wget')
    module.check_command(module, 'echo')
    module.check_command(module, ['/usr/bin/wget', 'www.google.com'])
    module.check_command(module, 'sudo ls')
    module.check_command(module, 'pbrun ls')
    module.check_command(module, 'machinectl')
    module.check_command(module, 'mv')
    module.check_command(module, 'chmod')
    module.check_command(module, 'chown')
    module.check_command(module, 'chgrp')