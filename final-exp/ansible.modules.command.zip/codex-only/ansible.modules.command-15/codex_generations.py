

# Generated at 2022-06-23 03:06:17.289590
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, ['chown', 'foo'])
    check_command(module, ['chmod', 'foo'])
    check_command(module, ['chgrp', 'foo'])
    check_command(module, ['ln', 'foo'])
    check_command(module, ['mkdir', 'foo'])
    check_command(module, ['rmdir', 'foo'])
    check_command(module, ['rm', 'foo'])
    check_command(module, ['touch', 'foo'])
    check_command(module, ['curl', 'foo'])
    check_command(module, ['wget', 'foo'])
    check_command(module, ['svn', 'foo'])

# Generated at 2022-06-23 03:06:17.976495
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-23 03:06:19.476622
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-23 03:06:28.959121
# Unit test for function check_command
def test_check_command():
    import sys
    import warnings
    from ansible.module_utils.six.moves import StringIO

    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            pass

        def warn(self, warning):
            return warning

    # if version < 2.12, fail_json is not in builtins
    try:
        from ansible.module_utils.basic import AnsibleModule
        test_ansible_module = AnsibleModule(argument_spec={})
        has_fail_json = True
    except (ImportError, AttributeError):
        test_ansible_module = TestAnsibleModule(argument_spec={})
        has_fail_json = False

    # check_command() doesn't

# Generated at 2022-06-23 03:06:30.345424
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:33.107519
# Unit test for function check_command
def test_check_command():
    command = "test_command"
    class TestModule:
        def warn(self, m):
            print(m)
    tm = TestModule()
    check_command(tm, command)




# Generated at 2022-06-23 03:06:40.432161
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    command_line = ['/bin/chown', '/tmp/somefile']
    check_command(module, command_line)
    command_line = '/bin/wget http://someurl'
    check_command(module, command_line)
    command_line = ['sudo', 'echo', 'some_text']
    check_command(module, command_line)


# Generated at 2022-06-23 03:06:48.363593
# Unit test for function main
def test_main():

    # Module has command not using shell
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', default='command'),
            _uses_shell=dict(type='bool', default=False),
            chdir=dict(type='str', default='/tmp'),
            executable=dict(type='str', default=''),
            creates=dict(type='str', default=''),
            removes=dict(type='str', default=''),
            warn=dict(type='bool', default=False)
        ),
        supports_check_mode=True)
    main()

    # Module has command using shell

# Generated at 2022-06-23 03:06:51.696338
# Unit test for function check_command
def test_check_command():
    data = {}
    data['command'] = '/usr/bin/make_database.sh db_user db_name'
    module = AnsibleModule(argument_spec={
        'command':{},
    })
    check_command(module, data['command'])



# Generated at 2022-06-23 03:07:02.161638
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:07:05.606073
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def __init__(self, *args, **kwargs):
            self.warnings = []
            self.params = args[0]

        def warn(self, warning):
            self.warnings.append(warning)
    fake_module = FakeModule({})
    check_command(fake_module, 'echo')
    assert len(fake_module.warnings) == 1
    assert isinstance(fake_module.warnings[0], basestring)



# Generated at 2022-06-23 03:07:16.851171
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "curl")
    check_command(module, "wget")
    check_command(module, "svn")
    check_command(module, "service")
    check_command(module, "mount")
    check_command(module, "rpm")
    check_command(module, "yum")
    check_command(module, "apt-get")
    check_command(module, "tar")
    check_command(module, "unzip")
    check_command(module, "sed")
    check_command(module, "dnf")
    check_command(module, "zypper")
    check_command(module, "sudo")
    check_command(module, "su")
    check_command(module, "pbrun")

# Generated at 2022-06-23 03:07:24.274067
# Unit test for function check_command
def test_check_command():
    check_command(None, 'echo')
    check_command(None, 'echo foo')
    check_command(None, ['echo', 'foo'])
    check_command(None, ['wget', 'http://example.org/foo.txt'])
    check_command(None, ['sed', '-i', 's/foo/bar/g'])
    check_command(None, ['rpm', '-q', 'ansible'])
    check_command(None, ['yum', 'install', 'ansible'])
    check_command(None, ['curl', 'http://example.org/foo.txt'])



# Generated at 2022-06-23 03:07:35.555808
# Unit test for function main
def test_main():
    arg_spec = dict(
        _raw_params=dict(),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        # The default for this really comes from the action plugin
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )

# Generated at 2022-06-23 03:07:45.231521
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 03:07:54.527702
# Unit test for function check_command
def test_check_command():
    args = dict(
        warn = True,
        become = True,
        become_method = 'sudo',
        become_user = 'root'
    )
    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )


# Generated at 2022-06-23 03:08:00.454173
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:10.709158
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    check_command(module, "echo")
    assert module.warn.call_count == 0, "unexpected warnings: %s" % module.warn.call_args_list

    check_command(module, "chown")
    assert module.warn.call_count == 1, "unexpected warnings: %s" % module.warn.call_args_list

    check_command(module, "chmod")
    assert module.warn.call_count == 2, "unexpected warnings: %s" % module.warn.call_args_list

    check_command(module, "chgrp")
    assert module.warn.call_count == 3, "unexpected warnings: %s" % module.warn.call_args_list

# Generated at 2022-06-23 03:08:15.672655
# Unit test for function main
def test_main():
    args = {}
    if __name__ == '__main__':
        import sys
        if len(sys.argv) > 1:
            args.update(json.loads(sys.argv[1]))
    main(**args)