

# Generated at 2022-06-23 03:06:14.717248
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)

    # module_utils.basic.AnsibleModule already handles this, so it's not
    # normally reached, but we're testing a function without setting up
    # the args, so we can't just use the normal path.
    for command in ['chown', 'chmod', 'chgrp',
                    'ln', 'mkdir', 'rmdir', 'rm', 'touch']:
        commandline = [command, 'foo']
        m = FakeModule()
        check_command(m, commandline)
        assert(len(m.warnings) == 1)

# Generated at 2022-06-23 03:06:19.488984
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(argument_spec={})

    setattr(mod, 'check_mode', False)
    setattr(mod, 'warn', None)
    check_command(mod, 'curl')
    assert mod.warn.call_count == 1
    check_command(mod, 'wget')
    assert mod.warn.call_count == 2
    check_command(mod, 'svn')
    assert mod.warn.call_count == 3
    check_command(mod, 'service')
    assert mod.warn.call_count == 4
    check_command(mod, 'mount')
    assert mod.warn.call_count == 5
    check_command(mod, 'rpm')
    assert mod.warn.call_count == 6
    check_command

# Generated at 2022-06-23 03:06:31.679789
# Unit test for function main
def test_main():
    # Test the idempotence, that is, can we run the function twice
    # and have the same results.
    command = ['echo', 'hello']
    module = AnsibleModule(
        argument_spec = {
            '_raw_params': command,
        },
        supports_check_mode = True,
    )
    r1 = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None,
         'start': None, 'end': None, 'delta': None, 'msg': ''}
    r1 = main()
    assert r1 == r2

    command = ['echo', 'hello']

# Generated at 2022-06-23 03:06:34.785648
# Unit test for function main
def test_main():
    r = main()
    if r['rc'] == 0:
        assert r == True
    else:
        assert r == False
test_main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:39.705304
# Unit test for function main
def test_main():
    # Test input
    arguments = {'_raw_params': {}, '_uses_shell': {}, 'argv': {}, 'chdir': {}, 'executable': {}, 'creates': {}, 'removes': {}, 'warn': {}, 'stdin': {}, 'stdin_add_newline': {}, 'strip_empty_ends': {}}

    # Check code
    main(arguments)


# Generated at 2022-06-23 03:06:50.421174
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, ['ls', '-ltr', '/tmp'])
    check_command(module, 'ls -ltr /tmp')
    check_command(module, 'chmod -R 600 /tmp/foo')
    check_command(module, 'chown root:root /tmp/foo')
    check_command(module, 'chgrp root /tmp/foo')
    check_command(module, 'ls -ltr /tmp')
    check_command(module, 'ln -s /tmp/foo /tmp/bar')
    check_command(module, 'mkdir /tmp/bar')
    check_command(module, 'rmdir /tmp/bar')
    check_command(module, 'rm -f /tmp/bar.txt')
    check_command

# Generated at 2022-06-23 03:06:58.049873
# Unit test for function check_command
def test_check_command():
    module = DummyAnsibleModule()
    commandline = ["touch", "filename"]
    check_command(module, commandline)
    assert module.warnings == [
        "Consider using the file module with state=touch rather than running 'touch'.  "
        "If you need to use 'touch' because the file module is insufficient you can add 'warn: false' to this command task or "
        "set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]


# ===========================================
# AnsibleModule boilerplate
#


# Generated at 2022-06-23 03:06:59.751956
# Unit test for function main
def test_main():
    # This module is really an alias and is covered by raw, script, and shell
    pass


main()

# Generated at 2022-06-23 03:07:07.865759
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default=''),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(default=None),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:07:19.715066
# Unit test for function main

# Generated at 2022-06-23 03:07:22.045873
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.params = {'command': ''}
    check_command(module, '')
    assert module.warnings == []


# Generated at 2022-06-23 03:07:31.042502
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils._text import to_native, to_bytes, to_text


# Generated at 2022-06-23 03:07:34.061734
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(command=dict(required=True)))
    check_command(module, 'sudo ls')
    check_command(module, ['sudo', 'ls'])



# Generated at 2022-06-23 03:07:45.296942
# Unit test for function main

# Generated at 2022-06-23 03:07:52.310299
# Unit test for function check_command
def test_check_command():
    myargs = {'command_warnings': False, 'no_log': False}
    mymod = AnsibleModule(
        argument_spec=dict(
            free_form=dict(required=True, aliases=['command']),
            creates=dict(aliases=['creates']),
            removes=dict(aliases=['removes'], type='list'),
            warn=dict(type='bool', default=False),
            chdir=dict(type='path', aliases=['chdir']),
        ),
        supports_check_mode=True,
        no_log=myargs['no_log'],
        add_file_common_args=True,
    )
    check_command(module=mymod, commandline='touch /root/foobar')

# Generated at 2022-06-23 03:08:04.394035
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LocalAnsibleModule

    def validate_message(msg):
        return msg == DEFAULT_MESSAGE

    DEFAULT_MESSAGE = 'Hello World'
    _module = LocalAnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    check_command(_module, '/usr/bin/chmod')
    check_command(_module, '/bin/chmod')
    check_command(_module, '/usr/bin/rm')
    check_command(_module, '/usr/bin/apt-get')
    check_command(_module, '/usr/bin/svn')
    check_command(_module, '/usr/bin/curl')

# Generated at 2022-06-23 03:08:04.966310
# Unit test for function check_command
def test_check_command():
    assert check_command("echo") == None



# Generated at 2022-06-23 03:08:13.896196
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({'warn': True})

    # Trigger warning for arguments:
    for command in ('chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch'):
        check_command(module, [command, 'owner', 'path'])

    # Trigger warning for modules:
    for command in ('curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get', 'tar',
                    'unzip', 'sed', 'dnf', 'zypper'):
        check_command(module, [command])

    # Trigger warning for become methods:
    for command in ('sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl'):
        check

# Generated at 2022-06-23 03:08:27.066354
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    check_command(m, '/usr/bin/chmod')
    check_command(m, ['chmod'])
    check_command(m, '/bin/chmod')
    check_command(m, '/bin/sed')
    check_command(m, ['/bin/sed'])
    check_command(m, 'chmod /path')
    check_command(m, 'chmod')
    check_command(m, 'chmod 777 /path')
    check_command(m, '/bin/curl http://www.example.com/')
    check_command(m, 'curl')
    check_command(m, '/usr/bin/yum -y install wget')

# Generated at 2022-06-23 03:08:38.044906
# Unit test for function check_command
def test_check_command():
    check_command(list(['yum']))
    check_command('yum')
    check_command(list(['apt-get']))
    check_command('apt-get')
    check_command(list(['svn']))
    check_command('svn')
    check_command(list(['chown']))
    check_command('chown')
    check_command(list(['chmod']))
    check_command('chmod')
    check_command(list(['chown']))
    check_command('chown')
    check_command(list(['chgrp']))
    check_command('chgrp')
    check_command(list(['touch']))
    check_command('touch')
    check_command(list(['mkdir']))
    check_command('mkdir')

# Generated at 2022-06-23 03:08:39.570735
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:08:52.616896
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.warns = []
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            pass

        def warn(self, msg):
            self.warns.append(msg)


# Generated at 2022-06-23 03:08:57.896082
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': dict(type='str')})
    check_command(commandline="rm -R /")


# Generated at 2022-06-23 03:09:02.104896
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec=dict())
    module, commandline = m, "commandline"
    check_command(module, commandline)
    assert module.warnings[0] == "Consider using the apt module rather than running 'commandline'."


# Generated at 2022-06-23 03:09:10.631258
# Unit test for function main

# Generated at 2022-06-23 03:09:23.613201
# Unit test for function main
def test_main():

    def myrun_command(self, cmd, executable=None, use_unsafe_shell=False, data='', binary_data=True):
        return (0, 'standard_out', 'standard_err')

    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            creates=dict(type='path'),
            removes=dict(type='path'),
        )
    )

    # inject my own run_command, to avoid fork
    module.run_command = myrun_command

    # set args
    module.params['_raw_params'] = 'ls'
    module.params['creates'] = '/tmp/createme'
    module.params['removes'] = '/tmp/removeme'

    # set check

# Generated at 2022-06-23 03:09:36.628303
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello'
    )
    result = {
        'changed': True,
        'cmd': ['echo', 'hello'],
        'delta': '0:00:00.001690',
        'end': '2017-09-29 22:03:48.084657',
        'rc': 0,
        'start': '2017-09-29 22:03:48.083128',
        'stderr': '',
        'stderr_lines': [],
        'stdout': 'hello',
        'stdout_lines': ['hello'],
    }
    main_result = main()
    assert isinstance(main_result, dict)
    assert result == main_result


# Generated at 2022-06-23 03:09:47.329460
# Unit test for function main

# Generated at 2022-06-23 03:09:59.128215
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    args = ['/bin/echo', 'hello']
    check_command(module, args)
    args = '/bin/echo hello'
    check_command(module, args)
    args = 'echo hello'
    check_command(module, args)
    args = 'wget https://example.com/foo.txt'
    check_command(module, args)
    args = 'svn co https://example.com/svn/foo'
    check_command(module, args)
    args = 'chown nobody /tmp/test.txt'
    check_command(module, args)
    args = '/bin/sed -i \'s/foo/bar/g\''
    check_command(module, args)


# Generated at 2022-06-23 03:10:10.126859
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/tmp/ls',
        creates='file.txt',
        removes='file.txt',
        warn=False,
        stdin='input',
        stdin_add_newline=True,
        strip_empty_ends=True,
        _uses_shell=False,
    )
    with mock.patch('ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule'):
        ansible.builtin.plugins.modules.command.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:19.774509
# Unit test for function check_command
def test_check_command():
    import ansible.module_utils

    class FakeModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            arguments = {'module_name': 'fake'}
            super(FakeModule, self).__init__(**arguments)

        def warn(self, msg):
            assert msg.startswith("Consider using the file module with chmod rather than running 'chmod'")

    module = FakeModule()
    check_command(module, 'chmod')
    check_command(module, '/bin/chmod')
    check_command(module, ['/bin/chmod'])



# Generated at 2022-06-23 03:10:22.223838
# Unit test for function main
def test_main():
    import json
    import os
    import tempfile

    tempDir = tempfile.gettempdir()
    tempFileName = os.path.join(tempDir, 'tempFileName')

    with open(tempFileName, 'w') as tempFile:
        tempFile.write('test_main')

test_main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:32.857401
# Unit test for function main
def test_main():
    args_dict = 	{
  "_raw_params": "echo hello",
  "_uses_shell": False,
  "argv": None,
  "chdir": None,
  "creates": None,
  "executable": None,
  "removes": None,
  "stdin": None,
  "stdin_add_newline": True,
  "strip_empty_ends": True,
  "warn": False
}
    main(args_dict)

# Generated at 2022-06-23 03:10:34.756846
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:43.984400
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

    class FakeModule:
        def __init__(self):
            self.warns = []

        def warn(self, msg):
            self.warns.append(msg)


# Generated at 2022-06-23 03:10:56.736425
# Unit test for function check_command
def test_check_command():
    module = MagicMock()
    check_command(module, ['chown'])
    check_command(module, ['chown', 'root', 'test'])
    check_command(module, ['chmod', '755', 'test'])
    check_command(module, ['chgrp', 'test', 'test'])
    check_command(module, ['ln', 'test', 'test'])
    check_command(module, ['mkdir', 'test'])
    check_command(module, ['rmdir', 'test'])
    check_command(module, ['rm', 'test'])
    check_command(module, ['touch', 'test'])
    check_command(module, ['curl', 'test'])
    check_command(module, ['wget', 'test'])

# Generated at 2022-06-23 03:11:06.489720
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import patch

    m = MagicMock(return_value=(0, "Success", ""))
    with patch.dict(command.__dict__, {'run_command': m}):
        with patch.object(os, 'chdir') as mock_chdir:
            run_command_result = {'rc': 0, 'stdout': "Success", 'stderr': ""}
            command.main()
            assert mock_chdir()
            assert run_command_result == {'rc': 0, 'stdout': "Success", 'stderr': ""}


if __name__ == '__main__':
    main

# Generated at 2022-06-23 03:11:12.094353
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    command = 'ls -al'
    check_command(module, command)
    command = ['ls', '-al']
    check_command(module, command)
    command = 'touch /tmp/test'
    check_command(module, command)



# Generated at 2022-06-23 03:11:23.240621
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    check_command(module, 'rm /tmp/test_file')
    check_command(module, 'sudo rm /tmp/test_file')
    check_command(module, 'wget http://example.com/')
    check_command(module, 'curl http://example.com/')
    check_command(module, 'service ntpd restart')
    check_command(module, 'rpm -ivh http://download1.rpmfusion.org/free/fedora/releases/20/Everything/i386/os/pulseaudio-module-bluetooth-2.1-1.fc20.i686.rpm')
    check_command(module, 'yum install pulseaudio-module-bluetooth')

# Generated at 2022-06-23 03:11:32.896077
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create a fake module

# Generated at 2022-06-23 03:11:36.209048
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    # Check if the module is present
    check_command(module, "git")
    assert "git" in module._warnings[0]



# Generated at 2022-06-23 03:11:44.863605
# Unit test for function main
def test_main():
    # These are all the various conditionals that can fail or succeed
    # Dependent on the conditionals, the following are changed:
    # msg, skipped, stdout
    # run_command is mocked out
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import _ANSIBLE_ARGS
    from ansible.module_utils.common.collections import is_iterable


# Generated at 2022-06-23 03:11:52.193825
# Unit test for function main
def test_main():
    #import sys;sys.argv=['', 'Test.testName']
    #import unittest
    #unittest.main()
    #args = {'executable': u'/bin/sh', 'removes': u'/tmp/asdf', '_uses_shell': False, 'creates': u'/tmp/yumlock.13285', 'chdir': None}
    #res = main(args)
    #print res
    pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:12:01.451036
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
    )

    result = main()
    assert result.has_key('msg') == True
    assert result.has_key('rc') == True
    assert result.has_key('start') == True
    assert result.has_key('stderr') == True
    assert result.has_key('stdout') == True
    assert result.has_key('end') == True
    assert result.has_key('delta') == True
    assert result['rc'] == 0
    assert result['msg'] == ''

    args = dict(
        _raw_params=None,
        argv=[
            'ls',
            '-l'
        ],
    )

    result = main()
    assert result.has_key('msg') == True

# Generated at 2022-06-23 03:12:02.621323
# Unit test for function main
def test_main():
    module = AnsibleModule()
    module.parse_params(dict(args='ls'))
    assert main() == True


# Generated at 2022-06-23 03:12:07.560634
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import json
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

    # Make sure ansible-test doesn't try to interpret this as a real test case
    test_args = {
        'no_log': True,
        '_ansible_debug': True,
        'python_version': 2
    }

    # We'll hijack the builtin __salt__ dunder to mock out any functions that
    # might be called in these test cases.

# Generated at 2022-06-23 03:12:21.506169
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 03:12:34.853148
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    warnings = []
    module = AnsibleModule(fake_params=dict(warn=True, command='/bin/bash'),
                           check_invalid_arguments=False,
                           argument_spec=dict(warn=dict(type='bool', default=False)))
    def fake_warn(message):
        warnings.append(message)
    module.warn = fake_warn
    check_command(module, 'wget')
    check_command(module, 'touch')
    check_command(module, 'svn')
    check_command(module, 'ln')
    check_command(module, 'service')
    check_command(module, 'sudo')
    check_command(module, ['/bin/bash', '-c', 'wget'])
    assert warnings

# Generated at 2022-06-23 03:12:44.956178
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from io import StringIO
    from ansible.compat.six import StringIO

    mock_run_command = basic.AnsibleModule.run_command
    def run_command(self, cmd, executable=None, use_unsafe_shell=False, encoding=None, binary_data=False, data=None):
        return 0, "stdout", "stderr"

    def fail_json(self, **kwargs):
        raise AssertionError('fail_json called: %s' % kwargs)


# Generated at 2022-06-23 03:12:54.358176
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3, b
    from ansible.module_utils.six.moves import shlex_quote as quote
    from ansible.module_utils.pycompat24 import get_exception
    # run module using internal code
    setattr(AnsibleModule, 'run_command', run_command)
    setattr(AnsibleModule, '_load_params', _load_params)
    setattr(basic, 'ANSIBLE_MODULE_ARGS', ANSIBLE_MODULE_ARGS)
    # test with exception
    args = quote(test_command)
    old_stdin = sys.stdin

# Generated at 2022-06-23 03:13:00.350908
# Unit test for function main

# Generated at 2022-06-23 03:13:11.161779
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import common_koji

    class FakeAnsibleModule:
        def __init__(self):
            self.deprecations = []

        def warn(self, msg):
            self.deprecations.append(msg)

    class FakeArgs:
        def __init__(self, args):
            self.args = args

    module = FakeAnsibleModule()
    check_command(module, FakeArgs(['/bin/ls']))
    assert module.deprecations == []
    check_command(module, FakeArgs(['tar', 'cvf', 'file.tar', 'file/', 'folder/']))

# Generated at 2022-06-23 03:13:17.233546
# Unit test for function main
def test_main():
    args = dict(
        creates="/tmp/ansible_command_exists",
        _raw_params="echo hello"
    )
    module = AnsibleModule(argument_spec=args)
    result = main()
    assert result['stdout'] == 'hello'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:19.809550
# Unit test for function main
def test_main():
    assert to_text(True) == "True"


# Generated at 2022-06-23 03:13:31.931295
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='cat /etc/motd',
        argv='cat /etc/motd',
        chdir='somedir/',
        executable='',
        creates='/path/to/database',
        removes='/path/to/database',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-23 03:13:33.886515
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "command")
    check_command(module, [ "command" ])



# Generated at 2022-06-23 03:13:44.242000
# Unit test for function main
def test_main():
    import os
    import datetime
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_bytes, to_text
    from ansible.module_utils.common.collections import is_iterable
    import ansible.builtin.command

# Generated at 2022-06-23 03:13:54.158825
# Unit test for function check_command
def test_check_command():
    class test_module_name(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.check_mode = False
            self.no_log = False
            self.run_command = lambda x, y, z: None
            AnsibleModule.__init__(self, *args, **kwargs)
        def warn(self, msg):
            self.warnings.append(msg)
    m = test_module_name(
        argument_spec={'command': {'type': 'list', 'required': False, 'default': '/bin/true'}},
        supports_check_mode=True
    )
    check_command(m, '/bin/chown')
    check_command(m, '/bin/chgrp')
    check_command(m, '/bin/ln')
   

# Generated at 2022-06-23 03:14:02.023562
# Unit test for function main
def test_main():
    args = dict(
        _raw_params = '/usr/bin/id',
        _uses_shell = True,
        argv = "/usr/bin/id",
        chdir = None,
        executable = None,
        creates = None,
        removes = None,
        warn = True,
        stdin = None,
        stdin_add_newline = True,
        strip_empty_ends = True,
    )
    r = main(**args)
    assert r['rc'] == 0


if __name__ == '__main__':
    main()