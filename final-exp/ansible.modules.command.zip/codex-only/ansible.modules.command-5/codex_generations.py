

# Generated at 2022-06-23 03:06:13.398152
# Unit test for function main
def test_main():
    args = {'_raw_params': 'ls -lah',
            'chdir': '/home/ec2-user',
            '_uses_shell': False,
            'creates': '',
            'removes': '',
            'warn': False,
            'stdin': '',
            'stdin_add_newline': True,
            'strip_empty_ends': True
            }
    module = AnsibleModule(argument_spec=args)
    global main  # for testing
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:17.839552
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:26.369485
# Unit test for function main
def test_main():
    test_params = dict(
        {
          "argv": ["service", "rabbitmq-server", "status"],
          "chdir": "/app/",
          "creates": "/var/lock/subsys/rabbitmq-server",
          "removes": None,
          "strip_empty_ends": True,
          "warn": False
        }
        )
    test_module = AnsibleModule(argument_spec=test_params)
    main()
    test_module.exit_json(success=True)
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 03:06:31.021747
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'touch a b')
    check_command(module, 'sudo touch a b')
    check_command(module, 'rm a b')
    check_command(module, 'curl a b')
    check_command(module, 'apt-get a b')



# Generated at 2022-06-23 03:06:33.188804
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule({})
    test_command = 'yum'
    check_command(test_module, test_command)
# Unit test



# Generated at 2022-06-23 03:06:41.095139
# Unit test for function main

# Generated at 2022-06-23 03:06:45.733794
# Unit test for function check_command
def test_check_command():
  # Run the unit test
  import __builtin__
  m = __builtin__.__dict__['ANSIBLE_MODULE_INSTANCE'] = AnsibleModule(
    argument_spec={},
  )
  check_command(m, 'tar')


# Generated at 2022-06-23 03:06:50.203179
# Unit test for function check_command
def test_check_command():
    check_command_test = AnsibleModule(
        argument_spec=dict(
            command=dict(type='list'),
        ),
        supports_check_mode=True,
    )
    commandline = ['curl', 'http://foo.com/']
    check_command(check_command_test, commandline)


# Generated at 2022-06-23 03:07:01.806424
# Unit test for function main

# Generated at 2022-06-23 03:07:02.500325
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:07:08.138004
# Unit test for function main
def test_main():
    from ansible.modules.remote_management.notifier import AnsibleModule
    import ansible.module_utils.basic

# Generated at 2022-06-23 03:07:20.062649
# Unit test for function main
def test_main():
    args = ['/usr/bin/ansible', 'all', '-m', 'command', '-a', '/bin/uname -s']
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.params['_raw_params'] = '/bin/uname -s'
    main()

# Generated at 2022-06-23 03:07:29.232243
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    check_command(module,'/bin/chmod --version')
    assert module.warnings[0] == "Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check_command(module,'/usr/bin/curl --version')

# Generated at 2022-06-23 03:07:41.275116
# Unit test for function main
def test_main():
    import sys
    import json
    import shlex

    # The following three dictionaries represent the input and expected output of each test case
    test_cases = []

# Generated at 2022-06-23 03:07:52.435988
# Unit test for function main
def test_main():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def run_command(args, **kwargs):
        if args and args[0] == 'test_fail':
            return 1, 'stdout', 'stderr'
        return args[0] == 'test_rc' and int(args[1]), 'stdout', 'stderr'

    def check_command(module, args):
        check_command.called = True
        check_command.args = args
    check_command.called = False
    check_command.args = None

    module = AnsibleModule(argument_spec=dict())
    module.run_command = run_command
    module.warn = check_command
    r = main()
    assert r['changed']

# Generated at 2022-06-23 03:07:54.446944
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule({})
    check_command(test_module, ['test_command'])



# Generated at 2022-06-23 03:08:06.132044
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, commandline):
            self.commandline = commandline

        def warn(self, msg):
            self.msg = msg

        def _get_commandline(self):
            return self.commandline

    # Basic testing of the check_command function
    t = TestModule(['/bin/chmod'])
    check_command(t, t._get_commandline())
    assert(t.msg == "Consider using the file module with mode rather than running 'chmod'.  "
                    "If you need to use 'chmod' because the file module is insufficient you can add"
                    " 'warn: false' to this command task or set 'command_warnings=False' in"
                    " the defaults section of ansible.cfg to get rid of this message.")

# Generated at 2022-06-23 03:08:10.167785
# Unit test for function check_command
def test_check_command():
    """
    Module function check_command
    """
    check_command()



# Generated at 2022-06-23 03:08:12.090031
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(module, "command")

# Generated at 2022-06-23 03:08:15.345610
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    assert check_command(module, "/bin/echo hello")



# Generated at 2022-06-23 03:08:28.302500
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chmod o+r /etc/foo')
    check_command(module, 'chown user /etc/foo')
    check_command(module, 'chgrp foo /etc/foo')
    check_command(module, 'ln /usr/bin/foo /etc/foo')
    check_command(module, 'mkdir /usr/bin/foo')
    check_command(module, 'rmdir /usr/bin/foo')
    check_command(module, 'rm -f /usr/bin/foo')
    check_command(module, 'touch /usr/bin/foo')
    check_command(module, 'curl https://www.example.com/')

# Generated at 2022-06-23 03:08:40.341222
# Unit test for function main
def test_main():
    test_command_module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )  

# Generated at 2022-06-23 03:08:44.852642
# Unit test for function check_command
def test_check_command():
    args = {}
    args['check_command'] = True
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, **args)
    check_command(module, ['command'])
    check_command(module, 'command')


# Generated at 2022-06-23 03:08:58.156594
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})

    commandline = "/usr/bin/make_database.sh db_user db_name creates=/path/to/database"
    check_command(module, commandline)

# Generated at 2022-06-23 03:09:09.949966
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    commands = ['curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
                'tar', 'unzip', 'sed', 'dnf', 'zypper']
    arguments = ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch']

    for cmd in commands:
        commandline = [cmd, "args"]
        check_command(module, commandline)
        commandline = cmd + " args"
        check_command(module, commandline)

    for cmd in arguments:
        commandline = [cmd, "args"]
        check_command(module, commandline)
        commandline = cmd + " args"
       

# Generated at 2022-06-23 03:09:20.033530
# Unit test for function check_command
def test_check_command():
    command_list = ['chown']
    command_list_2 = ['chown', 'owner']
    command_strings = ['chown owner']
    command_strings_2 = 'chown owner'

    module = AnsibleModule(argument_spec={})

    check_command(module, command_strings)
    check_command(module, command_strings_2)
    check_command(module, command_list)
    check_command(module, command_list_2)

# end


# Generated at 2022-06-23 03:09:25.657933
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            cmd = dict(required=True),
            creates = dict(default=None),
            removes = dict(default=None),
            chdir = dict(default=None),
            warn = dict(type='bool', default=True)
        ),
        supports_check_mode=True
    )
    commandline = ["/sbin/some-command", "with_args"]
    check_command(module, commandline)



# Generated at 2022-06-23 03:09:38.572343
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo this is a test',
        _uses_shell=True,
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )

# Generated at 2022-06-23 03:09:44.049240
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': dict(type='str')})
    check_command(module, 'file')
    check_command(module, 'command')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'ls')


# Generated at 2022-06-23 03:09:50.177406
# Unit test for function check_command
def test_check_command():
    _module = AnsibleModule(supports_check_mode=True)
    check_command(_module, ['curl', 'https://github.com/'])
    check_command(_module, ['wget', 'https://github.com/'])
    check_command(_module, ['svn', 'url'])
    check_command(_module, ['service', 'foo'])
    check_command(_module, ['mount', 'url'])
    check_command(_module, ['rpm', '-q', 'foo'])
    check_command(_module, ['yum', '-y', 'install', 'foo'])
    check_command(_module, ['apt-get', '-y', 'install', 'foo'])
    check_command(_module, ['tar', 'xvzf', 'foo'])

# Generated at 2022-06-23 03:10:00.074385
# Unit test for function main
def test_main():
    #Suppress stderr for all but the original call to main()
    with open(os.devnull, 'wb') as devnull:
        stderr = sys.stderr
        sys.stderr = devnull


# Generated at 2022-06-23 03:10:12.297978
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = "chown root /etc/passwd"
    check_command(module, commandline)
    commandline = "chmod 0644 /etc/passwd"
    check_command(module, commandline)
    commandline = "chgrp root /etc/passwd"
    check_command(module, commandline)
    commandline = "ln -s /etc/passwd /etc/passwd.new"
    check_command(module, commandline)
    commandline = "mkdir /etc/newdir"
    check_command(module, commandline)
    commandline = "rmdir /etc/newdir"
    check_command(module, commandline)
    commandline = "rm /etc/passwd"

# Generated at 2022-06-23 03:10:22.305135
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(module, 'chown root *')
    check_command(module, '/usr/bin/chown root *')
    check_command(module, 'curl http://localhost')
    check_command(module, 'svn update /path/to/svnroot')
    check_command(module, 'service foo start bar')
    check_command(module, 'mount /dev/sda /mnt/foo')
    check_command(module, 'rpm -ivh /tmp/pkg.rpm')
    check_command(module, 'yum install foo')
    check_command(module, 'apt-get install foo')
    check_command(module, 'tar xzf foo.tgz')

# Generated at 2022-06-23 03:10:33.666012
# Unit test for function main
def test_main():
    real_stdout = sys.stdout

# Generated at 2022-06-23 03:10:43.056970
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    import base64
    import json
    from io import StringIO
    from ansible.module_utils.basic import AnsibleModule

    class MyModule(object):
        def __init__(self, data=None):
            self.ansible_version = ansible_version
            self.run_command_stat = None
            self.fail_json_stat = None
            self.exit_json_stat = None
            self.warn_stat = None
            self.check_mode = False
            if data:
                self.params = json.load(StringIO(data))
            else:
                self.params = {}

        def fail_json(self, **kwargs):
            self.fail_json_stat = kwargs


# Generated at 2022-06-23 03:10:52.367586
# Unit test for function main

# Generated at 2022-06-23 03:10:53.965560
# Unit test for function check_command
def test_check_command():
    user_command = ['/usr/bin/test_command']
    check_command(AnsibleModule, user_command)



# Generated at 2022-06-23 03:10:56.068843
# Unit test for function main
def test_main():
    with mock.patch.object(sys, 'argv', ["ansible-test", "command"]):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:02.199950
# Unit test for function check_command
def test_check_command():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_bytes, to_text
    from ansible.module_utils.common.collections import is_iterable

    def fakewarn(msg):
        print("%s: %s" % (sys.argv[0], msg))

    x = AnsibleModule(
        argument_spec = dict(),
    )
    x.warn = fakewarn
    check_command(x, "sed")
    check_command(x, "curl")
    check_command(x, "svn")
    check_command(x, "yum")
    check_command(x, "dnf")
    # check_command(x, "rpm")
    # check_command(x, "ln")

# Generated at 2022-06-23 03:11:05.847417
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    mymod = basic.AnsibleModule(
        argument_spec = dict(),
    )
    check_command(mymod, 'curl')


# Generated at 2022-06-23 03:11:09.168231
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'touch /tmp/foo')
    check_command(module, ['rm', '/tmp/foo'])



# Generated at 2022-06-23 03:11:21.900077
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = lambda x: x
    check_command(module, "tar")
    check_command(module, "tar --version")
    check_command(module, "machinectl")
    check_command(module, "chown file.txt")
    check_command(module, "chmod file.txt")
    check_command(module, "chgrp file.txt")
    check_command(module, "ln file.txt /tmp")
    check_command(module, "mkdir /tmp")
    check_command(module, "rm /tmp")
    check_command(module, "touch /tmp")
    check_command(module, "rpm -ivh file.txt")
    check_command(module, "yum list")

# Generated at 2022-06-23 03:11:32.144709
# Unit test for function check_command

# Generated at 2022-06-23 03:11:34.917494
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    for cmd in ['pbrun', 'machinectl']:
        yield(check_command, module, [cmd])


# Generated at 2022-06-23 03:11:39.642159
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    module.warn = lambda x: x
    command = 'test:test'
    check_command(module, command)
    module.warn = lambda x: 'test'
    command = command.split()
    check_command(module, command)


# ===========================================
# AnsibleModule entry point
#



# Generated at 2022-06-23 03:11:47.526021
# Unit test for function main
def test_main():
    def test_run_command(*args, **kwargs):
        returncode = kwargs.get('returncode', 0)
        return returncode, '', ''

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = test_run_command
    module.params['args'] = 'echo hello world'
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:56.549661
# Unit test for function main
def test_main():
    argv = ['ansible-test','command','--no-log','cat','a','b','c','--','d']
    args = {'_ansible_syslog_facility': 'LOG_USER', '_ansible_debug': False, '_raw_params': 'cat a b c -- d', '_ansible_check_mode': False, '_ansible_no_log': True, '_ansible_verbosity': 0, 'invocation': Invocation(module_name='command', args=argv, module_args=None), '_ansible_module_name': 'command'}
    run_command_mock = mock.MagicMock()
    run_command_mock.return_value = (0, '', '')

# Generated at 2022-06-23 03:12:00.478062
# Unit test for function main
def test_main():
    (t_module, t_result) = run_command(["echo", "Hello"])
    assert (t_module.exit_json.called)
    assert (t_result['rc'] == 0)

# Load module for unit test

# Generated at 2022-06-23 03:12:10.377984
# Unit test for function check_command
def test_check_command():
    class FakeModule():
        def __init__(self, *args, **kwargs):
            pass
        def fail_json(self, *args, **kwargs):
            pass
        def exit_json(self, *args, **kwargs):
            pass
        def warn(self, msg):
            print(msg)
        def set_result(self, *args, **kwargs):
            pass
        def run_command(self, *args, **kwargs):
            pass
    module = FakeModule()
    check_command(module, ['touch', 'somefile'])
    check_command(module, ['sed', '-i', 'somefile'])
    check_command(module, ['cp', 'somefile'])


# Generated at 2022-06-23 03:12:11.268590
# Unit test for function check_command
def test_check_command():
    assert True


# Generated at 2022-06-23 03:12:21.852777
# Unit test for function check_command
def test_check_command():
    check_command(AnsibleModule(argument_spec=dict()), ['foo'])
    check_command(AnsibleModule(argument_spec=dict()), ['wget'])
    check_command(AnsibleModule(argument_spec=dict()), ['apt-get'])
    check_command(AnsibleModule(argument_spec=dict()), ['ln'])
    check_command(AnsibleModule(argument_spec=dict()), ['rm'])
    check_command(AnsibleModule(argument_spec=dict()), ['chmod'])
    check_command(AnsibleModule(argument_spec=dict()), ['chown'])
    check_command(AnsibleModule(argument_spec=dict()), ['curl'])

# Generated at 2022-06-23 03:12:25.444073
# Unit test for function main
def test_main():
    import tempfile
    import time
    assert main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:27.978517
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:37.124845
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'test_arg': {'type': 'str'}})
    check_command(module, 'touch /tmp/file')
    assert module.warnings == [
        "Consider using the file module with state=touch rather than running 'touch'.  If you need to use 'touch' "
        "because the file module is insufficient you can add 'warn: false' to this command task or set "
        "'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    ]



# Generated at 2022-06-23 03:12:40.239597
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_main()
# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.urls import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:40.842125
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-23 03:12:49.803066
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict()
    )
    check_command(module, ['/usr/bin/apt-get', 'install', 'nginx'])
    result = module.warn.call_count
    assert result == 1
    check_command(module, ['yum', 'install', 'nginx'])
    result = module.warn.call_count
    assert result == 2
    check_command(module, ['chown', 'root', 'nginx'])
    result = module.warn.call_count
    assert result == 3
    check_command(module, ['/usr/bin/wget', 'nginx'])
    result = module.warn.call_count
    assert result == 4
    check_command(module, ['runas', 'root'])
    result = module.warn.call

# Generated at 2022-06-23 03:12:59.100997
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    # basics
    check_command(module, "apt-get install foo")
    check_command(module, ["apt-get", "install", "foo"])
    check_command(module, "curl http://foo.com/")
    check_command(module, "wget http://foo.com/")
    check_command(module, "service httpd restart")
    check_command(module, "svn checkout http://foo.com/")
    check_command(module, "mount /dev/foo /mnt/bar")
    check_command(module, "rpm -ivh foo.rpm")
    check_command(module, "yum install -y foo")
    check_command(module, "tar xzf foo.tar.gz")

# Generated at 2022-06-23 03:13:10.217645
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="echo hello",
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        # The default for this really comes from the action plugin
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )

    module = AnsibleModule(argument_spec=args)

# Generated at 2022-06-23 03:13:14.698138
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "echo hello")


# Generated at 2022-06-23 03:13:16.080177
# Unit test for function main
def test_main():
    assert main() is True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:16.455574
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-23 03:13:19.784032
# Unit test for function main
def test_main():
    # Test with '_raw_params' == 'echo -n "foo"'
    with pytest.raises(AnsibleExitJson) as excinfo:
        main()
    assert excinfo.value.args[0]['changed']


# Generated at 2022-06-23 03:13:32.917777
# Unit test for function main
def test_main():
    # Test help message was correct
    return_values = [['no command given', 256, '']]
    mock_module = MagicMock(**{'run_command.return_value': return_values[0]})
    with patch.object(sys, 'argv', ['command', '--help']):
        with pytest.raises(SystemExit) as pytest_wrapped_e:
            main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    # Test arguments passed to run_command
    command = ['ls', '-l']
    module_args = {'_raw_params': command}
    mock_module = MagicMock(argument_spec=module_args)
    main()
    assert mock_module.run_command.call_

# Generated at 2022-06-23 03:13:38.214554
# Unit test for function main
def test_main():
    args = "{'_uses_shell': False, 'chdir': None, 'executable': None, 'creates': None, 'removes': None, 'warn': False, 'stdin': None, 'stdin_add_newline': True, 'strip_empty_ends': True, '_raw_params': 'ls', 'argv': None}"
    r = "{'changed': True, 'stdout': '', 'stderr': '', 'rc': 256, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': 'no command given'}"
    assert(main(args)==r)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:49.776464
# Unit test for function main

# Generated at 2022-06-23 03:13:59.210807
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='cat /etc/motd',
        creates='/dev/null',
        removes='/dev/null',
        chdir='/etc',
        executable='/bin/bash',
    )
    with pytest.raises(AnsibleExitJson) as exc:
        main()
    print('Info: %s' % exc.value.args[0])
    assert exc.value.args[0]['cmd'] == ['cat', '/etc/motd']
    assert exc.value.args[0]['rc'] == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:14:03.244629
# Unit test for function check_command
def test_check_command():
    module = type('module', (object,), {'fail_json': None, 'warn': None})()
    module.fail_json = lambda *args, **kwargs: None
    module.warn = lambda warning: None
    check_command(module, None)


# Generated at 2022-06-23 03:14:14.739216
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    check_command(m, 'chown')
    check_command(m, 'chmod')
    check_command(m, 'chgrp')
    check_command(m, 'ln')
    check_command(m, 'mkdir')
    check_command(m, 'rmdir')
    check_command(m, 'rm')
    check_command(m, 'touch')

    check_command(m, 'curl')
    check_command(m, 'wget')
    check_command(m, 'svn')
    check_command(m, 'service')
    check_command(m, 'mount')
    check_command(m, 'rpm')
    check_command(m, 'yum')

# Generated at 2022-06-23 03:14:23.459505
# Unit test for function check_command
def test_check_command():
    commandline = 'ping localhost'
    module = AnsibleModule(argument_spec={'dummy': {'type': 'str'}})
    module.check_mode = True
    check_command(module, commandline)
    # Expected output:
    # {
    #     '_ansible_verbose_always': True,
    #     'warnings': ['Consider using the file module rather than running \'ping\'.']
    # }
    # We cannot test this as the module is not being run properly



# Generated at 2022-06-23 03:14:33.988859
# Unit test for function main
def test_main():
    # Here is one sample test to show you how to test the whole function
    # To test all the cases and functions, add more of your tests here.
    # Test case:
    #   1. Test the function main()
    #   2. Expect the function return a
    #      a. changed=True
    #      b. end=<a datetime>
    #      c. rc=0
    #      d. start=<a datetime>
    #      e. stderr=''
    #      f. stdout='********************************************************'
    #      g. msg=''
    # Module_utils from ansible
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_iterable
   

# Generated at 2022-06-23 03:14:42.105748
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    # Dummy function to replace the real module.warn
    def dummy_warn_func(msg):
        module.warnings.append(msg)
    module.warnings = []
    module.warn = dummy_warn_func
    check_command(module, 'echo hello')
    assert len(module.warnings) == 1
    assert 'dependencies.' == module.warnings[0]
    check_command(module, ['grep', 'hello'])
    assert len(module.warnings) == 2
    assert 'dependencies.' == module.warnings[1]


# Generated at 2022-06-23 03:14:52.627213
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    check_command_params = ImmutableDict(check_command=dict(WARNS=['msg']), commandline=['command', 'arg1', 'arg2'])
    m = AnsibleModule(check_command_params,
                      check_invalid_arguments=False,
                      no_log=True,
                      )
    check_command(m, 'command')
    try:
        assert m.warn.call_count == 1
    except AssertionError:
        raise AssertionError('check_command does not issue warning')



# Generated at 2022-06-23 03:14:55.777204
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:06.397899
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    class FakeModule(object):
        params = None
        check_mode = False
        no_log = False
        def exit_json(self, **kwargs):
            assert 'warnings' in kwargs, kwargs
            return
        def fail_json(self, **kwargs):
            raise ValueError(kwargs)
        def warn(self, msg):
            assert 'this message' in msg
        @staticmethod
        def tmpdir():
            return '/tmp'
    module.warnings = []
    check_command(FakeModule(), 'ls')
    assert len(module.warnings) == 0
    check_command(FakeModule(), 'chown')
    assert len(module.warnings) == 1

# Generated at 2022-06-23 03:15:15.244929
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    args = dict(
        _raw_params='cat ../test_file',
        _uses_shell=False,
        argv=None,
        chdir='/home/test',
        executable=None,
        creates='/home/test/file',
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-23 03:15:26.382831
# Unit test for function main
def test_main():
    from ansible.modules.command import main


# Generated at 2022-06-23 03:15:36.006929
# Unit test for function check_command
def test_check_command():
    tmpfile = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-23 03:15:46.574375
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_bytes
    from ansible.module_utils.common.collections import is_iterable
    import io
    import sys


# Generated at 2022-06-23 03:15:54.783567
# Unit test for function check_command
def test_check_command():

    assert check_command('yum') == 'Consider using the yum module rather than running yum'
    assert check_command('apt-get') == 'Consider using the apt module rather than running apt-get'
    assert check_command('dnf') == 'Consider using the dnf module rather than running dnf'
    assert check_command('zypper') == 'Consider using the zypper module rather than running zypper'
    assert check_command('rpm') ==  'Consider using the yum, dnf or zypper module rather than running rpm'
    assert check_command('chown') == 'Consider using the file module with owner rather than running chown'
    assert check_command('chgrp') == 'Consider using the file module with group rather than running chgrp'

# Generated at 2022-06-23 03:15:58.609031
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ch = CommandRunner(m, 'a_command')
    ch.check_command(m, 'cmd')



# Generated at 2022-06-23 03:16:10.672146
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common