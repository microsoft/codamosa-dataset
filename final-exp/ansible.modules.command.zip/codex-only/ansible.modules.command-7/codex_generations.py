

# Generated at 2022-06-23 03:06:09.680040
# Unit test for function check_command
def test_check_command():
    module = MagicMock()
    check_command(module, ['echo', 'hello'])
    module.warn.assert_called_with("Consider using 'become', 'become_method', and 'become_user' rather than running echo")



# Generated at 2022-06-23 03:06:12.306968
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec = dict())
    # This shouldn't segfault
    check_command(m, 'ls /some/path')



# Generated at 2022-06-23 03:06:19.564244
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def __init__(self):
            self.warnings = []

        def warn(self, warning):
            self.warnings.append(warning)

    module = FakeModule()
    check_command(module, 'echo hello')
    assert len(module.warnings) == 1
    assert module.warnings[0] == "Consider using 'shell' rather than running echo"



# Generated at 2022-06-23 03:06:27.788867
# Unit test for function check_command
def test_check_command():
    import pytest
    from ansible.modules.commands import check_command
    mock_module = pytest.Mock()
    test_command = ['chmod']
    check_command(mock_module, test_command)
    mock_module.warn.assert_called_once_with("Consider using the file module with mode rather than running 'chmod'.  "
                                             "If you need to use 'chmod' because the file module is insufficient you can "
                                             "add 'warn: false' to this command task or set 'command_warnings=False' in "
                                             "the defaults section of ansible.cfg to get rid of this message.")



# Generated at 2022-06-23 03:06:36.990442
# Unit test for function main
def test_main():
    args = dict(
      _raw_params=u'echo hello',
      _uses_shell=False,
      argv=None,
      chdir=None,
      executable=None,
      creates=None,
      removes=None,
      warn=True,
      stdin=None,
      stdin_add_newline=True,
      strip_empty_ends=True,
    )

    result = dict(
      changed=False,
      delta='0:00:00.002789',
      cmd=['echo', 'hello'],
      end='2019-12-11 14:38:04.249975',
      stderr='',
      rc=0,
      start='2019-12-11 14:38:04.246481',
      stdout='hello',
    )


# Generated at 2022-06-23 03:06:47.431989
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='str'),
            executable=dict(type='str'),
            creates=dict(type='str'),
            removes=dict(type='str'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:06:53.613399
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec={
                "_raw_params": dict(),
                "_uses_shell": dict(type='bool', default=False),
                "argv": dict(type='list', elements='str'),
                "chdir": dict(type='path'),
                "executable": dict(),
                "creates": dict(type='path'),
                "removes": dict(type='path'),
                "warn": dict(type='bool', default=False),
                "stdin": dict(required=False),
                "stdin_add_newline": dict(type='bool', default=True),
                "strip_empty_ends": dict(type='bool', default=True),
                }
            )

# Generated at 2022-06-23 03:07:03.506768
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Container
    import warnings

    # create a mock module to return warnings
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        bypass_checks=True
    )
    module.params = Container(warnings=True)

    # test check_command

# Generated at 2022-06-23 03:07:08.696953
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    class MockModule(AnsibleModule):
        @staticmethod
        def warn(msg):
            pass

    try:
        check_command(MockModule, 'sudo ls /')
        check_command(MockModule, 'su -')
        check_command(MockModule, 'pbrun ls /')
        check_command(MockModule, 'pfexec ls /')
        check_command(MockModule, 'runas ls /')
        check_command(MockModule, 'pmrun ls /')
        check_command(MockModule, 'machinectl ls /')
    except:
        raise



# Generated at 2022-06-23 03:07:13.150991
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as context:
        main()
    assert "unable to open shell" in str(context.value)

# Generated at 2022-06-23 03:07:23.874698
# Unit test for function main
def test_main():
    test_file = '/tmp/test'
    with open(test_file, 'w+') as test_file_obj:
        test_file_obj.write("""#!/usr/bin/python
import os
import sys
import json
from ansible.module_utils.basic import AnsibleModule
nick_name = {"name": "nick"}
name = "nick"
if os.path.isfile(test_file) and name in nick_name["name"]:
    print '1'
    sys.exit(1)
elif name in nick_name["name"]:
    print '0'
    sys.exit(0)
""")
    test_args = [test_file]
    test_kwargs = {"_raw_params": test_file}

# Generated at 2022-06-23 03:07:36.037795
# Unit test for function check_command
def test_check_command():
    module = DummyModule()
    # Command with 'creates' argument
    check_command(module, '/usr/bin/make_database.sh db_user db_name creates=/path/to/database')
    assert "Consider using the" not in module.warnings[0]
    assert "because the file module" in module.warnings[0]
    assert "module is insufficient" in module.warnings[0]
    assert "rather than running 'make_database.sh'" in module.warnings[0]
    assert "If you need to use 'make_database.sh' because the file module is insufficient you can add 'warn: false' to this command task" in module.warnings[0]
    assert "or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message." in module.warnings

# Generated at 2022-06-23 03:07:46.675896
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert(check_command(module, ['chown', 'user:group', 'some_file']))
    assert(check_command(module, ['chmod', '0755', 'some_file']))
    assert(check_command(module, ['chgrp', 'group', 'some_file']))
    assert(check_command(module, ['ln', '-s', 'source_file', 'target_file']))
    assert(check_command(module, ['mkdir', 'some_dir']))
    assert(check_command(module, ['rm', 'some_file']))
    assert(check_command(module, ['rmdir', 'some_dir']))

# Generated at 2022-06-23 03:07:56.540777
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 03:07:57.628169
# Unit test for function check_command
def test_check_command():
    assert check_command == check_command



# Generated at 2022-06-23 03:08:10.467882
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import ModuleFailException
    module = AnsibleModule(
        argument_spec={
            'command': dict(required=True, type='list'),
            'command_warnings': dict(required=False, type='bool', default=True)
        },
        supports_check_mode=True
    )
    module.warnings = []
    try:
        check_command(module, ['chown', 'bob', 'myfile'])
    except ModuleFailException:
        pass
    assert len(module.warnings) == 1
    assert 'warn: false' in module.warnings[0]

    module.warnings = []
    try:
        check_command(module, ['wget', 'url'])
    except ModuleFailException:
        pass
    assert len(module.warnings)

# Generated at 2022-06-23 03:08:23.127208
# Unit test for function main

# Generated at 2022-06-23 03:08:36.303363
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 03:08:44.974109
# Unit test for function main
def test_main():

    # get parameters info
    args = dict(
        _raw_params=dict(),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
    )
    # run module
    m = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True,
    )
    m.exit_json(changed=True)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:47.452379
# Unit test for function main
def test_main():
    print("Test main")
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:59.835135
# Unit test for function check_command
def test_check_command():
    module = MockModule()
    commandline = 'bash'
    check_command(module, commandline)
    module.fail_json.assert_called_with(msg="Unsupported become method '%s'" % commandline)
    assert module.warn.call_count == 0

    module = MockModule(check_command_warnings=False)
    commandline = 'bash'
    check_command(module, commandline)
    assert not module.fail_json.called
    assert module.warn.call_count == 0

    commandline = 'touch'
    module = MockModule()
    check_command(module, commandline)
    assert module.warn.call_count == 1

# Generated at 2022-06-23 03:09:09.314006
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic

    # The module argument spec will be initialized from ANSIBLE_MODULE_ARGS
    # environment variable when unit test framework loads this module so we
    # need to update the argument spec before calling main() function.
    module = basic.AnsibleModule(
        argument_spec={},
    )
    mocker.patch.object(module, 'warn')

    # Test with a real command
    check_command(module, "foo")
    module.warn.assert_has_calls([
        call("Consider using 'become', 'become_method', and 'become_user' rather than running foo")
    ])
    module.warn.reset_mock()

    # Test with a non-existent command
    check_command(module, "foobar")
    module.warn.assert_has

# Generated at 2022-06-23 03:09:22.681095
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        _uses_shell=False,
        argv=[],
        check_mode=True,
    )
    m = AnsibleModule(**args)

# Generated at 2022-06-23 03:09:30.740755
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'echo')
    check_command(module, ['svn', 'commit', '-m', '"foo"'])
    check_command(module, 'sudo service')
    check_command(module, '/usr/bin/sudo su user')
    check_command(module, 'sudo')


# Generated at 2022-06-23 03:09:40.830005
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "svn co https://foo.bar.baz")
    check_command(module, "svn co http://foo.bar.baz")
    check_command(module, "wget http://repo.bar.baz/centos/6/os/x86_64/repodata/repomd.xml")
    check_command(module, "rpm -q --whatprovides redhat-release")
    check_command(module, "yum clean all")
    check_command(module, "apt-get install -y python")
    check_command(module, "tar xzf foo.tar.gz")
    check_command(module, "unzip foo.zip")

# Generated at 2022-06-23 03:09:44.900778
# Unit test for function main
def test_main():
    # unit tests for function main
    # Please add your test here
    print('No unit test for function main')


if __name__ == '__main__':
    main()
    # unit tests for function main
    test_main()

# Generated at 2022-06-23 03:09:54.897122
# Unit test for function check_command
def test_check_command():
    ''' test_check_command(module, commandline) '''
    import tempfile
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.warn = lambda msg: None
    module.fail_json = lambda msg: None
    current_path = os.path.dirname(os.path.realpath(__file__))
    tempdir = tempfile.mkdtemp(dir=current_path)
    tempfile = os.path.join(tempdir, "tempfile")
    os.environ['ANSIBLE_COMMAND_WARNINGS'] = 'False'

# Generated at 2022-06-23 03:10:07.689529
# Unit test for function main
def test_main():
    # Function to set environment variables, so that tests can run
    def set_env(var_name, var_value):
        os.environ[var_name] = var_value

    # Function to delete environment variables, so that tests can run
    def del_env(var_name):
        del os.environ[var_name]

    module_args = dict(
        _raw_params="/usr/bin/make_database.sh db_user db_name creates=/path/to/database creates=/path/to/database"
    )
    set_env("ANSIBLE_MODULE_ARGS", json.dumps(module_args))
    set_env("ANSIBLE_REMOTE_TEMP", "tests/")
    set_env("ANSIBLE_KEEP_REMOTE_FILES", "True")

# Generated at 2022-06-23 03:10:11.651922
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    m.check_command(m, ['command','a','b','c','d','e','f','g','h','i','j','k'])
    m.check_command(m, ['command'])


# Generated at 2022-06-23 03:10:21.845890
# Unit test for function main
def test_main():
  rec = {}
  rec['args'] = "ansible.builtin.command --version"
  rec['ansible_facts']= {'version': {'full': '2.8.0','major': '2','minor': '8','revision': '0','string': '2.8.0'}}
  rec['changed'] = False
  rec['invocation']= {'module_args': {'_raw_params': "ansible.builtin.command --version",'_uses_shell': False,'argv': None,'chdir': None,'executable': None,'creates': None,'removes': None,'warn': False,'stdin': None,'stdin_add_newline': True,'strip_empty_ends': True},'module_name': 'ansible.builtin.command'}
  rec['rc'] = 0
 

# Generated at 2022-06-23 03:10:24.821406
# Unit test for function check_command
def test_check_command():
    command = ['ignored', 'foo', 'bar']
    expected = dict(changed=False, warnings=['command only handles the first command given'])
    try:
        import ansible.modules.system.command as command_module
        command_module.check_command(module, command)
        assert False, "Exception should have been raised but wasn't"
    except Exception as e:
        assert e.args[0] == expected['warnings'][0]



# Generated at 2022-06-23 03:10:35.117266
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(parallel=True)
    commandline = ['curl']
    check_command(module, commandline)
    assert module._warnings == ["Consider using the get_url or uri module rather than running 'curl'.  If you need to use 'curl' because the get_url or uri module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]
    module._warnings = []
    commandline = ['svn']
    check_command(module, commandline)

# Generated at 2022-06-23 03:10:40.709256
# Unit test for function check_command
def test_check_command():
    import ansible.module_utils.basic as basic
    args = {}
    args['warn'] = True
    module = basic.AnsibleModule(argument_spec=args)
    check_command(module, ['curl'])
    check_command(module, ['yum'])
    check_command(module, ['sed'])
    check_command(module, ['sudo'])
    check_command(module, ['chown'])



# Generated at 2022-06-23 03:10:47.897601
# Unit test for function main
def test_main():
    args = {
        '_uses_shell': True,
        'chdir': 'somedir/',
        'executable': '/bin/sh',
        'creates': '/path/to/database',
        'warn': True,
        'stdin': 'echo test',
        'stdin_add_newline': False,
        'strip_empty_ends': False,
    }
    result = dict(
        ansible_facts=dict(
            module_setup=True,
            async_seconds=120,
        ),
        changed=True,
        msg="non-zero return code",
        stderr="ls cannot access foo: No such file or directory",
        stdout="Clustering node rabbit@slave1 with rabbit@master …",
        rc=0
    )

# Generated at 2022-06-23 03:10:59.870360
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, warn_args):
            self.warn_args = warn_args
            self.warn_called = False
            self.changed = False

        def warn(self, msg):
            self.warn_called = True
            self.warn_args.append(msg)

    # We are testing the behaviour of check_command so the messages are intentionally not translated

# Generated at 2022-06-23 03:11:13.358363
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    result = main

# Generated at 2022-06-23 03:11:14.394465
# Unit test for function main
def test_main():
    main()
main()

# Generated at 2022-06-23 03:11:29.683774
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ['/usr/bin/chown', 'mdehaan', 'foo.txt'])
    check_command(module, '/usr/bin/chown mdehaan foo.txt')
    check_command(module, '/bin/chmod 755 foo.txt')
    check_command(module, '/bin/chgrp wheel foo.txt')
    check_command(module, '/usr/bin/ln -s foo.txt bar.txt')
    check_command(module, '/usr/bin/mkdir -p somedir')
    check_command(module, '/usr/bin/rmdir somedir')
    check_command(module, '/usr/bin/rm foo.txt')

# Generated at 2022-06-23 03:11:39.235789
# Unit test for function main
def test_main():
    def do_run_command(args, executable=None, use_unsafe_shell=False, data=None, binary_data=False):
        if args in [['/usr/bin/false'], ['false'],
                    ['/usr/bin/true'], ['true'],
                    ['test', '-e', 'mypath'], ['test', '-f', 'myfile'],
                    ['test', '-d', 'mydir'],
                    ['test', '-e', 'myfile'], ['test', '-f', 'mypath'],
                    ['test', '-d', 'myfile'],
                    ['test', '-e', 'mydir'], ['test', '-f', 'mydir'],
                    ['test', '-d', 'mypath']]:
            return (1, '', '')
       

# Generated at 2022-06-23 03:11:52.196092
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
            creates=dict(type='path'),
            chdir=dict(type='path'),
            executable=dict(type='path'),
        )
    )
    check_command(module, ['/bin/chown', 'username', '/path/to/file'])
    check_command(module, ['/bin/chmod', '+x', '/path/to/file'])
    check_command(module, ['/bin/chgrp', 'groupname', '/path/to/file'])
    check_command(module, ['/bin/ln', 'src', 'dest'])
    check_command(module, ['/usr/bin/mkdir', '/path/to/dir'])

# Generated at 2022-06-23 03:12:01.451086
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(
        command=dict(type='str'),
        argv=dict(type='list', elements='str'),
    ))
    check_command(module, 'echo')
    check_command(module, ['echo'])
    check_command(module, ['curl', '-v'])
    check_command(module, ['service', '--status-all'])
    check_command(module, ['svn', 'co', 'http://svn.red-bean.com/repos/test'])
    check_command(module, ['tar', 'xf', '/tmp/foo.tgz'])
    check_command(module, ['rpm', '-Uvh', 'http://repo.webtatic.com/yum/centos/5/latest.rpm'])
   

# Generated at 2022-06-23 03:12:07.383610
# Unit test for function main
def test_main():
  test_params = dict(
    _raw_params = dict(value = None),
    _uses_shell = dict(type='bool', default=False),
    argv = dict(type='list', elements='str'),
    chdir=dict(type='path'),
    executable=dict(),
    creates=dict(type='path'),
    removes=dict(type='path'),
    warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
    stdin=dict(required=False),
    stdin_add_newline=dict(type='bool', default=True),
    strip_empty_ends=dict(type='bool', default=True),
  )
  set_module_args(test_params)

# Generated at 2022-06-23 03:12:10.843423
# Unit test for function check_command
def test_check_command():
    t = AnsibleModule(
        argument_spec=dict(),
    )
    check_command(t, "grep --exclude-dir .svn -ri TODO: .")



# Generated at 2022-06-23 03:12:23.895706
# Unit test for function main
def test_main():
    for arg in ["/bin/echo hello", "/bin/echo \"hello world\""]:
        result = main._ansible_module.params = {
            '_uses_shell': False,
            'argv': None,
            'chdir': None,
            'executable': None,
            'creates': None,
            'removes': None,
            'warn': False,
            'stdin': None,
            'stdin_add_newline': True,
            'strip_empty_ends': True,
            '_raw_params': arg
        }
        main()
        assert result['changed']
        assert result['rc'] == 0
        assert result['stdout'] == 'hello\n'


# Primary function to be invoked
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:27.868662
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as ex:
        main()
    assert ex.value.args[0]['rc'] == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:35.884153
# Unit test for function check_command
def test_check_command():
    module = MockAnsibleModule()
    commandline = '/usr/bin/make_database.sh'
    check_command(module, commandline)
    commandline = ['wget']
    check_command(module, commandline)
    commandline = '/bin/sed'
    check_command(module, commandline)
    commandline = '/usr/bin/sudo'
    check_command(module, commandline)


# Generated at 2022-06-23 03:12:46.705814
# Unit test for function check_command
def test_check_command():
    # Without test-tools
    if False:
        module = AnsibleModule(argument_spec=dict())
        check_command(module, 'curl http://foo.com')
        check_command(module, 'wget http://foo.com')
        check_command(module, 'ls')
        check_command(module, 'svn co http://foo/bar')
        check_command(module, 'service foo start')
        check_command(module, 'mount /dev/foo /mnt/bar')
        check_command(module, 'rpm -ivh foo.rpm')
        check_command(module, 'yum install foo')
        check_command(module, 'apt-get install foo')
        check_command(module, 'tar -xzf foo.tar.gz /mnt/bar')

# Generated at 2022-06-23 03:12:52.877472
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    check_command(module, '/bin/foo')
    cmdline = ['/bin/foo', 'bar=baz']
    check_command(module, cmdline)


# Generated at 2022-06-23 03:13:06.863242
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.warnings import AnsibleFilterDeprecationWarning
    module = AnsibleModule(argument_spec=dict())
    import warnings


# Generated at 2022-06-23 03:13:19.485894
# Unit test for function main

# Generated at 2022-06-23 03:13:25.498008
# Unit test for function main
def test_main():
    args = dict(
        _raw_params=dict(default='/usr/bin/ls'),
        _uses_shell=dict(default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(),
        executable=dict(),
        creates=dict(),
        removes=dict(),
        stdin=dict(),
        strip_empty_ends=dict(default=True)
        )
    module = AnsibleModule(argument_spec=args,)

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:31.559262
# Unit test for function main
def test_main():
    
    # Expected results of test inputs
    expected_results_1 = {
    'msg': 'non-zero return code',
    'rc': 1,
    'stderr': u'ls: cannot access foo: No such file or directory'
    }
    

# Generated at 2022-06-23 03:13:34.419543
# Unit test for function check_command
def test_check_command():
    args = {'command': 'echo hello', 'warn': 'yes'}
    module = AnsibleModule(argument_spec={'command': {}})
    check_command(module, 'echo hello')
    assert module.params['warn'] == False

# Generated at 2022-06-23 03:13:44.624761
# Unit test for function check_command
def test_check_command():

    def append_to_stderr(line, text):
        if not isinstance(text, str):
            text = to_native(text)
        append_to_stderr.stderr_lines.append("%s: %s" % (line, text))

    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    module.warn = append_to_stderr
    # Populate the stderr_lines array with test data
    append_to_stderr.stderr_lines = []

    # Test function with free form command line
    check_command(module, ["/bin/cp", "/test/testfile", "/test/testfile_new"])
    assert len(append_to_stderr.stderr_lines) == 1
    assert append

# Generated at 2022-06-23 03:13:54.515157
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict(
            args = dict(type='str'),
        ),
    )
    # list form
    check_command(module, ['chown', 'user', 'path/to/file'])
    check_command(module, ['chmod', '644', 'path/to/file'])
    check_command(module, ['chgrp', 'users', 'path/to/file'])
    check_command(module, ['mkdir', 'path/to/directory'])
    check_command(module, ['rmdir', 'path/to/directory'])
    check_command(module, ['rm', 'path/to/file'])
    check_command(module, ['touch', 'path/to/file'])

# Generated at 2022-06-23 03:14:05.338263
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    # usage: ansible-test clean [options]
    # Remove temporary test directory and reset configuration.
    # Use this to remove any temporary directories or files created during testing.
    #
    # Options:
    # -h, --help        show this help message and exit
    # -q, --quiet       do not display any output
    # -v, --verbose     verbose mode (-vvv for more)
    # -C NAME, --collection=NAME
    #                   specify collection name to clean
    # -D, --debug       enable connection debugging
    # --explain         print parsed arguments and exit
    # -l PATH, --library=PATH
    #                   path to module/plugin library (default:
    #                   /Users/hank/Documents/ansible-edge/lib/ansible/modules)


# Generated at 2022-06-23 03:14:16.124523
# Unit test for function check_command
def test_check_command():
    """Test the functionality of check_command()"""
    # Set up a test module
    module = AnsibleModule(
        argument_spec={
            'command_warnings': {'type': 'bool', 'default': True},
        },
        supports_check_mode=True
    )

    # Check for warnings for command that should warn
    check_command(module, "curl")
    check_command(module, "wget")
    check_command(module, "ln -s")
    check_command(module, "svn")
    check_command(module, "service")
    check_command(module, "rpm")
    check_command(module, "tar")
    check_command(module, "sed")
    check_command(module, ["/usr/bin/curl"])

# Generated at 2022-06-23 03:14:23.089390
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "/bin/chown root:root foo")
    check_command(module, ["/bin/chown", "root:root", "foo"])
    check_command(module, "/usr/bin/curl foo")
    check_command(module, "/usr/bin/zypper install -y foo")


# Generated at 2022-06-23 03:14:30.305701
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_native, to_bytes, to_text
    from ansible.module_utils.six import PY3

    n = basic.AnsibleModule(argument_spec={})
    n.warn = lambda x : x
    n.fail_json = lambda x : x

    check_command(n, 'chown user /path')
    check_command(n, 'chmod 0775 /path')
    check_command(n, 'chmod u+x /path')
    check_command(n, 'chgrp group /path')
    check_command(n, 'ln -s /path1 /path2')
    check_command

# Generated at 2022-06-23 03:14:41.586492
# Unit test for function main

# Generated at 2022-06-23 03:14:54.060442
# Unit test for function main
def test_main():

    test_params = {
        '_raw_params': 'echo hello',
        '_uses_shell': True,
        'argv': ['echo', 'hello'],
        'chdir': os.getcwd(),
        'creates': '',
        'removes': '',
        'warn': False,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True
    }

    test_args = {
        'supports_check_mode': True
    }


# Generated at 2022-06-23 03:14:55.523103
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.check_command(module, [''])



# Generated at 2022-06-23 03:15:06.397594
# Unit test for function main
def test_main():
    # check env variables sets
    assert os.environ["ANSIBLE_STRICT_TOML"] == '1'

# Generated at 2022-06-23 03:15:14.968808
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)
    # Test with command
    fake_module = FakeModule()
    check_command(fake_module, 'chown')
    assert len(fake_module.warnings) == 1
    # Test with list command
    fake_module = FakeModule()
    check_command(fake_module, ['chown'])
    assert len(fake_module.warnings) == 1
    # Test with bad command
    fake_module = FakeModule()
    check_module(fake_module, 'foo')
    assert len(fake_module.warnings) == 0


# Generated at 2022-06-23 03:15:17.430837
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    commandline = 'sudo ls'
    check_command(module, commandline)



# Generated at 2022-06-23 03:15:30.330363
# Unit test for function main
def test_main():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.module_utils.basic import AnsibleModule

    class TestCommandModule(unittest.TestCase):

        def setUp(self):
            self.mock_args = dict(
                    _raw_params='echo hi',
                    _uses_shell=False,
                    argv=None,
                    chdir=None,
                    executable=None,
                    creates=None,
                    removes=None,
                    # The default for this really comes from the action plugin
                    warn=False,
                    stdin=None,
                    stdin_add_newline=True,
                    strip_empty_ends=True,
                )
            self.mock_module = AnsibleModule(**self.mock_args)

       

# Generated at 2022-06-23 03:15:34.159294
# Unit test for function check_command
def test_check_command():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
    )
    check_command(module, 'chown')


# Generated at 2022-06-23 03:15:46.162653
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "touch /tmp/testfile")
    check_command(module, "rm /tmp/testfile")
    check_command(module, "unzip /tmp/testfile.zip")
    module.warn = lambda msg: msg

# Generated at 2022-06-23 03:15:57.714720
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.six.moves import StringIO
    module = AnsibleModule(argument_spec={})
    module.params['warn'] = True
    # fake out the result so that we can test if we are running the proper warning
    module._result = {'warnings': []}
    orig_stdout = sys.stdout
    sys.stdout = StringIO()
    check_command(module, commandline="method chown /dev/foo")
    assert "Consider using the file module with owner rather than" in sys.stdout.getvalue()
    check_command(module, commandline="method chmod /dev/foo")
    assert "Consider using the file module with mode rather than" in sys.stdout.getvalue()
    check_command(module, commandline="method chgrp /dev/foo")

# Generated at 2022-06-23 03:16:09.857230
# Unit test for function main