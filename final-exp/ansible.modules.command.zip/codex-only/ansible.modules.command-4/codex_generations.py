

# Generated at 2022-06-23 03:06:17.340460
# Unit test for function check_command
def test_check_command():
    def build_commandline(args):
        return ['/bin/{0}'.format(args[0])] + args[1:]
    module = AnsibleModule(argument_spec={'command': dict()})
    check_command(module, build_commandline(['chmod', 'some_args']))
    check_command(module, build_commandline(['chmod']))
    check_command(module, build_commandline(['chmod', 'some_other_args']))
    check_command(module, build_commandline(['chmod', 'some_other_args']))
    check_command(module, build_commandline(['chmod', 'some_args']))
    check_command(module, build_commandline(['chown', 'some_args']))

# Generated at 2022-06-23 03:06:18.035412
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-23 03:06:20.420741
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:29.507813
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = MagicMock()
    check_command(module, 'touch')
    check_command(module, 'echo')
    assert module.warn.called is False
    check_command(module, 'rm')
    check_command(module, 'ln')
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'touch')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command

# Generated at 2022-06-23 03:06:38.570836
# Unit test for function check_command
def test_check_command():
    """Unit test for check_command"""
    # This is needed so the imports happen on the worker
    from ansible.modules.commands import check_command

    # Load the module itself so we can call it directly
    from ansible.modules.commands.command import Command

    # We need to fake a module
    module = Command()

    # We also need a fake connection class
    class Connection:
        def __init__(self):
            self.conn = self

        def __call__(self):
            return self

        def exec_command(self, cmd, tmp_path=None, sudoable=False):
            return 0, '', ''

    module.check_mode = False
    module.no_log = True
    module.connection = Connection()

    mycmd = "chown"
    check_command(module, mycmd)



# Generated at 2022-06-23 03:06:49.510000
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def __init__(self):
            self.warn = []
        def warn(self, msg):
            self.warn.append(msg)
    mod = FakeModule()
    def mod_warn_matcher(msg):
        return any([w for w in mod.warn if msg in w])
    check_command(mod, "tar xf remote-file.tar")
    assert len(mod.warn) == 1
    assert mod_warn_matcher("Consider using the unarchive module")
    mod.warn = []
    check_command(mod, "rm /tmp/a_file")
    assert len(mod.warn) == 1
    assert mod_warn_matcher("Consider using the file module")
    mod.warn = []
    check_command(mod, "sudo rm /tmp/a_file")


# Generated at 2022-06-23 03:07:01.711054
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    class FakeArgs(object):
        def __init__(self, cmd):
            self.cmd = cmd

    module.params = FakeArgs('echo')
    check_command(module, 'echo')
    module.params = FakeArgs('/bin/echo')
    check_command(module, '/bin/echo')
    module.params = FakeArgs('/bin/echo')
    check_command(module, ['/bin/echo'])
    module.params = FakeArgs(['echo'])
    check_command(module, 'echo')

    module.params = FakeArgs('chown')
    check_command(module, 'chown')
    module.params = FakeArgs('chmod')
    check_command(module, 'chmod')
    module.params

# Generated at 2022-06-23 03:07:06.466457
# Unit test for function main
def test_main():
    # Create a fake class
    class FakeModule(object):
        # Fake the return code
        def run_command(self, args, executable=None, use_unsafe_shell=False, encoding=None, data=None, binary_data=False):
            return 0, '', ''

    # Create an instance of the fake class
    fake_module = FakeModule()

    # Execute the main function
    main(fake_module)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:07:16.986598
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.check_command = check_command
    check_command(module, 'curl --foo')
    check_command(module, 'mount blah')
    check_command(module, 'service blah')
    check_command(module, 'sudo service blah')
    check_command(module, 'wget http://www.example.com/foo')
    check_command(module, 'svn checkout http://svn.example.com/svn/trunk')
    check_command(module, 'chmod go+x')
    check_command(module, 'chown user')
    check_command(module, 'ln -s /tmp /var/tmp')
    check_command(module, 'mv /tmp/foo /var/tmp/foo')
   

# Generated at 2022-06-23 03:07:26.715027
# Unit test for function main
def test_main():
    import sys

    import ansible.module_command
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from units.mock.patch import Patch
    from units.mock.mock import MagicMock
    import units.compat.mock

    def setUpModule():
        sys.modules['ansible.module_utils.basic'] = basic
        sys.modules['ansible.module_command'] = ansible.module_command
        sys.modules['ansible.module_utils.basic'] = basic
        sys.modules['ansible.module_utils._text'] = to_bytes

    def tearDownModule():
        del sys.modules['ansible.module_utils.basic']
        del sys.modules['ansible.module_command']


# Generated at 2022-06-23 03:07:38.449313
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def __init__(self):
            self.warnings = []
        def warn(self, warning):
            self.warnings.append(warning)
        def fail_json(self, **args):
            pass

    m = FakeModule()
    check_command(m, '/usr/bin/chmod 666 /tmp/something')
    assert m.warnings[0] == "Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check_command(m, '/usr/bin/make_database.sh db_user db_name creates=/path/to/database')
   

# Generated at 2022-06-23 03:07:40.113218
# Unit test for function check_command
def test_check_command():
    # this won't work without a module object.
    assert None



# Generated at 2022-06-23 03:07:51.709691
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="ls -l",
        chdir="/root",
        executable="/bin/bash",
        creates="/root/test",
        removes="/usr/test",
        warn=True,
        stdin="None",
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-23 03:08:04.149083
# Unit test for function check_command
def test_check_command():
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-23 03:08:07.445571
# Unit test for function check_command
def test_check_command():
    args = dict(command='echo "hello"')
    module = AnsibleModule(**args)
    check_command(module, 'echo "hello"')
    assert not module.fail_json.called



# Generated at 2022-06-23 03:08:14.601211
# Unit test for function check_command
def test_check_command():
    mock_module = AnsibleModule(argument_spec=dict())
    mock_module.warn = lambda warning: None
    check_command(mock_module, ['curl', 'http://example.com/'])
    check_command(mock_module, 'touch /tmp/file')



# Generated at 2022-06-23 03:08:27.427933
# Unit test for function main

# Generated at 2022-06-23 03:08:39.033008
# Unit test for function check_command
def test_check_command():
    check_command("/bin/chown")
    check_command("/bin/chmod")
    check_command("/bin/chgrp")
    check_command("/bin/ln")
    check_command("/bin/mkdir")
    check_command("/bin/rmdir")
    check_command("/bin/touch")

    check_command("/usr/bin/curl")
    check_command("/usr/bin/wget")
    check_command("/usr/bin/svn")
    check_command("/sbin/service")
    check_command("/sbin/mount")
    check_command("/bin/rpm")
    check_command("/usr/bin/yum")
    check_command("/usr/bin/apt-get")

# Generated at 2022-06-23 03:08:51.487796
# Unit test for function check_command
def test_check_command():
    import io
    import sys

    module = AnsibleModule(argument_spec={})
    test_out = io.StringIO()
    test_in = io.StringIO('{"msg": "this is a test"}')
    sys.stdout = test_out
    sys.stdin = test_in
    check_command(module, ['rm', '-rf', '/some/path'])
    check_command(module, ['chown', 'foo:bar', '/some/path'])
    check_command(module, ['chmod', 'g+w', '/some/path'])
    check_command(module, ['chgrp', 'foo', '/some/path'])
    check_command(module, ['touch', '/some/path'])

# Generated at 2022-06-23 03:08:55.663717
# Unit test for function check_command
def test_check_command():
    import ansible.module_utils
    ansible.module_utils.basic = AnsibleModule
    module = AnsibleModule(command_warnings=True)
    assert check_command(module, ['service', 'foo', 'stop']) == None


# Generated at 2022-06-23 03:08:57.525826
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:07.736007
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warnings = []
        def warn(self, warning) -> None:
            self.warnings.append(warning)


# Generated at 2022-06-23 03:09:18.326588
# Unit test for function check_command
def test_check_command():
  """
  Test check_command
  """
  results = []
  commands = ['curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
              'tar', 'unzip', 'sed', 'dnf', 'zypper', 'sudo', 'su', 'pbrun',
              'pfexec', 'runas', 'pmrun', 'machinectl']
  file_commands = ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch']
  for command in commands:
    results.append(check_command(AnsibleModule(argument_spec={}), ['command', command]))

# Generated at 2022-06-23 03:09:21.475715
# Unit test for function main
def test_main():
    r = main()
    assert r['rc'] == 0
    assert r['skipped'] == False
    assert r['changed'] == False

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:31.461065
# Unit test for function main
def test_main():
  args = dict(
    _raw_params="ls -lrt /etc",
    _uses_shell="False",
    argv=dict(
        type="list",
        elements="str"
    ),
    chdir=None,
    executable=None,
    creates=None,
    removes=None,
    warn="True",
    stdin=None,
    stdin_add_newline="True",
    strip_empty_ends="True"
  )
  main(None, args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:41.276363
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.params['warn'] = True
    check_command(module, "ls foo")
    check_command(module, "wget www.google.com")
    check_command(module, "svn checkout foo/bar")
    check_command(module, "chown foo bar")
    check_command(module, "chmod a+x bar")
    check_command(module, "chgrp foo bar")
    check_command(module, "ln -s bar baz")
    check_command(module, "dnf install foo")
    check_command(module, "rpm -ivh foo.rpm")
    check_command(module, "yum install foo")
    check_command(module, "apt-get install foo")

# Generated at 2022-06-23 03:09:50.440422
# Unit test for function main
def test_main():
    args = {}
    r = {}

# Generated at 2022-06-23 03:10:00.257324
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-23 03:10:01.389345
# Unit test for function check_command
def test_check_command():
    assert check_command()



# Generated at 2022-06-23 03:10:05.225256
# Unit test for function main
def test_main():
    arguments = dict(args=dict(type='str'))
    module = AnsibleModule(argument_spec=arguments)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:14.950181
# Unit test for function main

# Generated at 2022-06-23 03:10:21.904495
# Unit test for function main
def test_main():
    import json
    import random
    import string
    from datetime import datetime
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock

    class TestCommandModule(unittest.TestCase):
        def setUp(self):
            self.module = Mock()
            self.module.check_mode = False
            self.module.run_command = MagicMock()
            self.module.fail_json = Mock(side_effect=Exception('fail_json'))
            self.module.exit_json = Mock(side_effect=Exception('exit_json'))
            self.module.warn = Mock()

# Generated at 2022-06-23 03:10:33.618233
# Unit test for function main
def test_main():

    # Test case to ensure key is not given
    def test_command_key_given():
        _raw_params = dict()
        _raw_params['args'] = dict()
        _raw_params['args']['executable'] = dict()
        _raw_params['args']['executable'] = "some_executable_path"
        _raw_params['_ansible_sys_executable'] = dict()
        _raw_params['_ansible_sys_executable'] = "/usr/bin/python"
        _raw_params['_ansible_no_log'] = dict()
        _raw_params['_ansible_no_log'] = False
        _raw_params['_ansible_verbosity'] = dict()
        _raw_params['_ansible_verbosity'] = 0
        args = dict()

# Generated at 2022-06-23 03:10:39.964348
# Unit test for function main
def test_main():
    """
    Test case: main
    """
    args = {'executable': '/bin/bash', 'strip_empty_ends': False}
    module = AnsibleModule(argument_spec=args)
    module.warn = MagicMock()
    assert main() == module.exit_json(
        cmd=None,
        end=None,
        msg='',
        rc=None,
        start=None,
        stderr=None,
        stdout=None,
        changed=False,
        delta=None)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:42.011087
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:52.125965
# Unit test for function check_command
def test_check_command():
    # create a dummy module object to use inside the function
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs.get('params', {})
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    module = FakeModule(params={'warn': True})
    check_command(module, ['chown'])
    assert 'Consider using the file module with owner rather than running' in module.warnings[0]

    module = FakeModule(params={'warn': True})
    check_command(module, ['curl'])
    assert 'Consider using the get_url or uri module rather than running' in module.warnings[0]

    module = FakeModule(params={'warn': True})
    check_command

# Generated at 2022-06-23 03:11:03.235547
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    # Check the module's idempotence by running it twice with the same input
    module = AnsibleModule(
        argument_spec=dict(
            test_string=dict(type='str', required=False),
        ),
    )
    check_command(module, "curl test.example.com")
    check_command(module, "wget test.example.com")
    check_command(module, "svn test.example.com")
    check_command(module, "service test.example.com")
    check_command(module, "mount test.example.com")
    check_command(module, "rpm test.example.com")
    check_command(module, "yum test.example.com")

# Generated at 2022-06-23 03:11:13.911447
# Unit test for function main

# Generated at 2022-06-23 03:11:21.308499
# Unit test for function check_command
def test_check_command():
    check_command(mock_module, ['curl'])
    check_command(mock_module, ['curl', 'https://www.google.com'])
    check_command(mock_module, ['touch'])
    check_command(mock_module, 'curl https://www.google.com')
    check_command(mock_module, ['curl', 'https://www.google.com'])
    check_command(mock_module, 'touch')



# Generated at 2022-06-23 03:11:31.834453
# Unit test for function main
def test_main():
    # Test with empty arguments
    assert main() == dict(
        changed=False, cmd=None, delta='0:00:00.000', end=None, msg='no command given'
        , rc=256, start=None, stderr='', stdout='', warn=False
    )
    # Test with a command on one line

# Generated at 2022-06-23 03:11:43.010206
# Unit test for function main

# Generated at 2022-06-23 03:11:54.325307
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule()
    check_command(m, 'chown')
    assert m.warnings[0].startswith('Consider using')
    check_command(m, 'curl')
    assert m.warnings[1].startswith('Consider using')
    check_command(m, 'zypper install')
    assert m.warnings[2].startswith('Consider using')
    check_command(m, ['/bin/bash', '-c', 'rm', '/foo/bar'])
    assert m.warnings[3].startswith('Consider using')
    # TODO: We should also test the disable_suffix.  But that requires changing the
    # warnings handling in basic.py to not strip off the runtime warnings.



# Generated at 2022-06-23 03:12:02.147855
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict()
    )
    cmd_list = ['curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip', 'sed', 'dnf', 'zypper']
    for cmd in cmd_list:
        check_command(module, cmd)
    assert module.fail_json.call_count == 13



# Generated at 2022-06-23 03:12:07.772796
# Unit test for function main

# Generated at 2022-06-23 03:12:21.590047
# Unit test for function main

# Generated at 2022-06-23 03:12:34.852996
# Unit test for function main
def test_main():
    """Tokenization can be used to divide text into tokens.  This
    method returns a list of all tokens found in the text.  Each token
    is a separate word or punctuation symbol.
    """

    # We need a temporary directory for the test suite
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # Going to create a simple config file for test_command
    import os
    os.chdir(tmpdir)
    configfile = open("ansible.cfg", "w")
    configfile.write("[defaults]\n")
    configfile.write("command_warnings = False\n")
    configfile.close()


# Generated at 2022-06-23 03:12:40.032336
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo "Hello World"',
        warn=False,
        executable='/bin/sh',
        _uses_shell=True,
        check_mode=True
    )
    module = AnsibleModule(**args)
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:41.799765
# Unit test for function main
def test_main():
    import ansible.modules.system.command as command
    command.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:43.187585
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:12:51.183571
# Unit test for function check_command
def test_check_command():
    # Use a class to test module
    class TestModule():
        def __init__(self):
            self._warnings = []
        def warn(self, text):
            self._warnings.append(text)

    # Create an instance
    tm = TestModule()

    # Now run our tests
    check_command(tm, "cp myfile")
    check_command(tm, "mv myfile")
    check_command(tm, "tar xvf myfile.tar")
    check_command(tm, "tar xvf myfile.tar")
    check_command(tm, "unzip myfile.zip")
    check_command(tm, "sed -i '1,10d' myfile")
    check_command(tm, "sed -i '1,10d' myfile")

# Generated at 2022-06-23 03:13:02.127891
# Unit test for function main
def test_main():
    # Create an instance of our fake module
    module = FakeModule()
    # use the actual main function
    main()

# USAGE EXAMPLE
# Run this module with a command line like below:
#
# >python -m ansible.modules.commands.command args="whoami"
#
# Expected output
#
# {
#     "changed": true,
#     "stderr": "",
#     "rc": 0,
#     "stdout": "username",
#     "cmd": "whoami"
# }

# Unit test class

# Generated at 2022-06-23 03:13:03.427971
# Unit test for function check_command
def test_check_command():
    assert 1==1


# Generated at 2022-06-23 03:13:12.637622
# Unit test for function main

# Generated at 2022-06-23 03:13:22.582482
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self._ansible_check_mode = True

        def warn(self, msg):
            pass

    def check_warn_msg(command, expected_msg):
        check_command(FakeModule(), command)
        assert expected_msg in FakeModule.warn.call_args[0][0]

    check_warn_msg('install', "become, become_method, and become_user")
    check_warn_msg('tar', "unarchive")
    check_warn_msg('tar', "If you need to use 'tar' because the unarchive module is insufficient you can add")
    check_warn_msg('wget', "get_url or uri")

# Generated at 2022-06-23 03:13:29.406894
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default='yes'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    result = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:41.403347
# Unit test for function main

# Generated at 2022-06-23 03:13:51.570349
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    args = module.params['_raw_params']
    check_command(module, args)


# Generated at 2022-06-23 03:14:00.077795
# Unit test for function check_command
def test_check_command():
    # Test warnings with string command
    module = AnsibleModule(argument_spec=dict())
    command = "touch /tmp/textfile"
    check_command(module, command)
    assert 'Consider using the file module with state=touch rather than running' in module.warnings[0]
    assert 'command_warnings=False' in module.warnings[0]
    assert len(module.warnings) == 1

    # Test warnings with list command
    module = AnsibleModule(argument_spec=dict())
    command = ["touch", "/tmp/textfile"]
    check_command(module, command)
    assert 'Consider using the file module with state=touch rather than running' in module.warnings[0]
    assert 'command_warnings=False' in module.warnings[0]

# Generated at 2022-06-23 03:14:10.818861
# Unit test for function main
def test_main():
    command = 'whoami'
    args = {'_raw_params': 'whoami',
            '_uses_shell': True,
            'chdir': os.path.abspath(os.sep),
            'creates': None,
            'removes': None,
            'warn': True}
    module = AnsibleModule(argument_spec=args)
    # Mock the functions used in main
    mock_fail_json = MagicMock()
    mock_run_command = MagicMock(return_value=[0, 'testuser', 'teststderr'])
    mock_exit_json = MagicMock()
    module.fail_json = mock_fail_json
    module.run_command = mock_run_command
    module.exit_json = mock_exit_json
    # Run main
    main()


# Generated at 2022-06-23 03:14:20.039725
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    command = "rm"
    commandline = "rm foo"
    check_command(module, commandline)
    assert module.warnings[0] == "Consider using the file module with state=absent rather than running 'rm'"
    command = "yum"
    commandline = "yum install foo"
    check_command(module, commandline)
    assert module.warnings[1] == "Consider using the yum module rather than running 'yum'"
    command = "pbrun"
    commandline = "pbrun ls"
    check_command(module, commandline)
    assert module.warnings[2] == "Consider using 'become', 'become_method', and 'become_user' rather than running pbrun"


# Generated at 2022-06-23 03:14:29.212770
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable
    import ansible.modules.system.command
    import ansible.modules.system.command as command

    module = basic.AnsibleModule(argument_spec=dict())
    command.warn = check_command
    # Check function check_command works
    check_command(module, "curl")
    check_command(module, "wget")
    check_command(module, ["wget"])
    check_command(module, "svn")
    check_command(module, "service")
    check_command(module, "mount")
    check_command(module, "rpm")
    check_command(module, "yum")
    check_command(module, "apt-get")
    check_

# Generated at 2022-06-23 03:14:38.446802
# Unit test for function main
def test_main():

    mymodule = AnsibleModule(argument_spec=dict(
        _raw_params=dict(type='str', default=''),
        _uses_shell=dict(type='bool', default=0),
        argv=dict(type='list', default=[]),
        chdir=dict(type='path', default=None),
        executable=dict(type='str', default=None),
        creates=dict(type='path', default=None),
        removes=dict(type='path', default=None),
        warn=dict(type='bool', default=0),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    ))


# Generated at 2022-06-23 03:14:47.924708
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    args = dict(
        stdin='hello\nworld',
        args='echo hello',
        _raw_params='echo hello',
        executable='/bin/bash',
        chdir='/tmp',
        shell=False,
    )
    x = AnsibleModule(argument_spec=dict())
    orig = x.run_command
    x.run_command = lambda *a, **kw: (0, 'ok', '')
    main(x)
    assert x.exit_json.called
    x.run_command = lambda *a, **kw: (1, '', 'bad')
    main(x)
    assert x.fail_json.called
    x.run_command = orig

    args = basic

# Generated at 2022-06-23 03:14:59.939768
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str')
        ),
        supports_check_mode=True
    )
    check_command(m, 'rm /tmp/foo')
    check_command(m, ['/usr/bin/rm', '/tmp/foo'])
    check_command(m, 'touch /tmp/foo')
    check_command(m, 'chown user /tmp/foo')
    check_command(m, 'chmod 0644 /tmp/foo')
    check_command(m, 'svn status')
    check_command(m, 'service nginx start')
    check_command(m, 'mount /dev/sda1 /mnt/usb')
    check_command(m, ['dnf', 'install', 'httpd'])
    check

# Generated at 2022-06-23 03:15:10.446270
# Unit test for function main
def test_main():
    import json
    import shutil
    import tempfile
    fd, fname = tempfile.mkstemp()
    result = {
        'changed': True,
        'cmd': ['touch', fname],
        'delta': '0:00:00.000001',
        'end': 'Fri, 08 Jan 2016 20:21:23 GMT',
        'rc': 0,
        'start': 'Fri, 08 Jan 2016 20:21:23 GMT',
        'stderr': '',
        'stderr_lines': [],
        'stdout': '',
        'stdout_lines': []
    }
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    m.run_command = lambda x, **kwargs: (0, '', '')
    m.exit_

# Generated at 2022-06-23 03:15:22.821717
# Unit test for function main
def test_main():
    # Mock module class
    class module():
        def fail_json(self, **kwargs):
            self.fail_json = kwargs
            return 0
        def exit_json(self, **kwargs):
            self.exit_json = kwargs
            return 0
        def run_command(self, args, executable=None, use_unsafe_shell=shell, encoding=None, data=stdin, binary_data=(not stdin_add_newline)):
            return 0, 'stdout', 'stderr'

    # Mock module class objects
    module = module()
    shoulda = "Would"
    # Create object of main function
    command = Command()
    # Store results of main function
    results = command.main(module, shoulda)
    # Assert for positive result

# Generated at 2022-06-23 03:15:28.584750
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    module.warn = lambda msg: None
    tests = [
        ([u'touch', u'foo'], u'foo'),
        (u'touch foo', u'foo'),
        ([u'sed', u'-i', u'foo'], u'foo'),
        (u'sed -i foo', u'foo'),
    ]
    for cmd, result in tests:
        assert check_command(module, cmd) == result



# Generated at 2022-06-23 03:15:41.935765
# Unit test for function check_command
def test_check_command():
    ''' Unit test for function check_command '''
    # Create a simple fake module object
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {'foo': 'bar'}
    test_module.check_command = check_command
    test_warnings = []

    def mock_warn(msg):
        test_warnings.append(msg)

    # Set the function we want to test to the mock_warn function we created
    test_module.warn = mock_warn
    # Test with an empty command
    check_command(test_module, '')
    assert len(test_warnings) == 0
    # Test with a normal command
    check_command(test_module, 'ls')
    assert len(test_warnings) == 0
    # Test with command that should trigger a warning


# Generated at 2022-06-23 03:15:53.832265
# Unit test for function main
def test_main():
    args = {"_raw_params": "df -h", "chdir": "", "executable": "", "creates": "", "removes": "", "warn": "yes"}
    module = AnsibleModule(argument_spec=args)
    r = {"changed": False, "stdout": "", "stderr": "", "rc": None, "cmd": None, "start": None, "end": None, "delta": None, "msg": ''}

    # special skips for idempotence if file exists (assumes command creates)
    if "creates":
        if glob.glob("creates"):
            r['msg'] = "Did not run command since 'creates' exists"
            r['stdout'] = "skipped, since creates exists"  # TODO: deprecate

            r['rc']

# Generated at 2022-06-23 03:15:54.492037
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-23 03:16:02.179459
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, "curl")
    check_command(module, "touch /foo/bar")
    check_command(module, "tar xvf some.tar")
    check_command(module, "mount /dev/sda /mnt/drive")
    check_command(module, "rpm -ivh some-package.rpm")
    check_command(module, "su - someuser -c 'ls -la'")
    check_command(module, "sed s/foo/bar/g /tmp/file")


# Generated at 2022-06-23 03:16:04.315021
# Unit test for function check_command
def test_check_command():
    commandline = ["command","--param", "value", "arg1", "arg2"]
    module = None
    check_command(module, commandline)



# Generated at 2022-06-23 03:16:15.479351
# Unit test for function check_command