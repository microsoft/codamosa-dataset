

# Generated at 2022-06-23 03:06:13.534869
# Unit test for function check_command
def test_check_command():
    fake_module = type('', (), {'warn':None})
    for cmd in ['chown','chmod','chgrp','ln','mkdir','rmdir','rm','touch','curl','wget','svn','service','rpm','dnf','zypper','mount','yum','apt-get','tar','unzip','sed']:
        check_command(fake_module, cmd)
    for cmd in ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        check_command(fake_module, cmd)


# Generated at 2022-06-23 03:06:25.598895
# Unit test for function main
def test_main():

    # Test the case when args is empty and argv isn't
    args = {}
    argv = ['test_command']
    r = {}
    r['changed'] = False
    r['cmd'] = argv
    r['rc'] = None
    r['stderr'] = ""
    r['stdout'] = ""
    module = AnsibleModule(argument_spec=args)

    def run_command_mock(args, executable, use_unsafe_shell, encoding, data, binary_data):
        return (0, "", "")
    setattr(module, "run_command", run_command_mock)

    main()

    # Test the case when argv is empty and args isn't
    args = {}
    argv = []
    r = {}
    r['changed'] = False
    r['cmd']

# Generated at 2022-06-23 03:06:33.349449
# Unit test for function main
def test_main():
  class MockModule:
    def __init__(self):
      self.params = dict()
      self.check_mode = False
    def fail_json(self, **kwargs):
      pass
    def run_command(self, args, executable=None, use_unsafe_shell=None, encoding=None, data=None, binary_data=None):
      return (0, "", "")
    def exit_json(self, **kwargs):
      pass
  module = MockModule()
  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:42.942006
# Unit test for function main

# Generated at 2022-06-23 03:06:49.823024
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    setattr(module, 'warn', _record_warnings)
    command = '/usr/bin/ls /tmp'
    command_list = command.split()
    check_command(module, command)
    check_command(module, command_list)
    # we should have gotten a warning
    assert len(module._warnings) == 2
    # now turn off warnings and make sure we don't get any
    module.params['warn'] = False
    check_command(module, command)
    check_command(module, command_list)
    assert len(module._warnings) == 2



# Generated at 2022-06-23 03:07:01.753993
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule({})
    # Check command in arguments
    check_command(m, 'command test does not exist')
    check_command(m, 'chown test')
    # Check command in commands
    check_command(m, 'curl')
    check_command(m, 'wget')
    check_command(m, 'svn')
    check_command(m, 'service')
    check_command(m, 'mount')
    check_command(m, 'rpm')
    check_command(m, 'yum')
    check_command(m, 'apt-get')
    check_command(m, 'tar')
    check_command(m, 'unzip')
    check_command(m, 'sed')

# Generated at 2022-06-23 03:07:07.365457
# Unit test for function check_command
def test_check_command():
    class AnsibleModuleMock():
        def __init__(self):
            pass
        def warn(self, msg):
            assert msg

    module = AnsibleModuleMock()
    check_command(module, '/bin/chown')
    check_command(module, '/bin/chmod')
    check_command(module, '/bin/chgrp')
    check_command(module, '/bin/ln')
    check_command(module, '/bin/mkdir')
    check_command(module, '/bin/rmdir')
    check_command(module, '/bin/rm')
    check_command(module, '/bin/touch')

    check_command(module, '/usr/bin/curl')
    check_command(module, '/usr/bin/wget')

# Generated at 2022-06-23 03:07:11.250182
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    commandline = "echo 'hello world'"
    check_command(module, commandline)
    commandline = ['echo', 'hello world']
    check_command(module, commandline)


# ===========================================
# AnsibleModule boilerplate
#


# Generated at 2022-06-23 03:07:20.683463
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    ansiblemodule = AnsibleModule({},{})
    check_command(ansiblemodule, "/usr/local/bin/python")
    check_command(ansiblemodule, "/usr/bin/make_database.sh db_user db_name creates=/path/to/database")
    check_command(ansiblemodule, ["/usr/bin/make_database.sh", "db_user", "db_name", "creates=/path/to/database"])
    check_command(ansiblemodule, ["/usr/bin/tar","-xvf","foo.tar", "bar/baz"])
    check_command(ansiblemodule, ["tar","-xvf","foo.tar", "bar/baz"])

# Generated at 2022-06-23 03:07:35.505334
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:07:46.367465
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3

    if PY3:
        long = int

    module = AnsibleModule(argument_spec=dict())

    module.warn = lambda msg: module.fail_json(msg=msg)

    # Test single string command
    check_command(module, '/bin/echo test')

    # Test single list as command
    check_command(module, ['/bin/echo', 'test'])

    # Test list of strings as command
    check_command(module, ['/bin/echo' 'test'])

    # Test single string command with kwargs

# Generated at 2022-06-23 03:07:54.488673
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def __init__(self):
            self.params = {}
        def warn(self, msg):
            self.msg = msg
        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_message = kwargs.get('msg', '')
        def fail_json(self, **kwargs):
            self.fail_args = kwargs
            self.fail_message = kwargs['msg']

    def fake_test_command(command, shell=False):
        if command:
            return True
        else:
            return False


# Generated at 2022-06-23 03:08:07.049558
# Unit test for function main
def test_main():
    import ansible.module_utils
    # Ansible.module_utils.basic.AnsibleModule
    def run_command(self, args, executable=None, use_unsafe_shell=False, encoding=None, data=None, binary_data=False):
        return '', '', 0

    import ansible.module_utils.basic
    real_AnsibleModule = ansible.module_utils.basic.AnsibleModule
    ansible.module_utils.basic.AnsibleModule = ansible.module_utils.basic.AnsibleModuleTest
    ansible.module_utils.basic.AnsibleModule.run_command = run_command

    # args
    args = [
        'a=b',
        'c=d',
    ]

    # module

# Generated at 2022-06-23 03:08:12.785768
# Unit test for function main
def test_main():
    # Mock
    command = dict(
        _raw_params='',
        _uses_shell=False,
        argv=['find', './'],
        chdir='/tmp',
        executable='/bin/sh',
        creates='/tmp/file1',
        removes='/tmp/file2',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

    expected = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )
    # Test execution
    result = main()
    # Check assertions
    assert result == expected

# Generated at 2022-06-23 03:08:20.426020
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(executable='/bin/echo', args=['foobar'])
    test_module = AnsibleModule(**module_args)
    test_module.run_command = lambda args, executable, **kw: (0, 'stdout', 'stderr')

    test_module.main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:08:22.642321
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec={}
    )
    check_command(module, ['command'])



# Generated at 2022-06-23 03:08:33.081001
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec = dict())
    check_command(module, 'ln -s /a/b/c /x/y/z')
    check_command(module, 'mkdir -p /a/b/c')
    check_command(module, 'rm -rf /x/y/z')
    check_command(module, 'mount /dev/sda1 /x/y/z')
    check_command(module, 'rpm -i /a/b/c')
    check_command(module, 'yum install -y /a/b/c')
    check_command(module, 'apt-get install /a/b/c')
    check_command(module, 'tar xf /a/b/c')
    check_command(module, 'unzip /a/b/c')
   

# Generated at 2022-06-23 03:08:43.088051
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:08:53.970179
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, "ln -s /tmp /somepath/")
    check_command(module, "curl -f https://www.google.com")
    check_command(module, "wget https://www.google.com")
    check_command(module, "dnf install -y httpd")
    check_command(module, "zypper install -y httpd")
    check_command(module, "tar -xzf /tmp/etc.tar.gz -C /etc")
    check_command(module, "apt-get install -y httpd")
    check_command(module, "rpm -ivh /tmp/http.rpm")
    check_command(module, "yum install -y httpd")

# Generated at 2022-06-23 03:09:03.730483
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = lambda x: x
    check_command(module, b"curl")
    checks = module._warnings
    assert len(checks) == 1
    assert checks[0] == "Consider using the get_url or uri module rather than running 'curl'.  If you need to use 'curl' because the get_url or uri module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    del module._warnings[:]
    check_command(module, b"chmod")
    checks = module._warnings
    assert len(checks) == 1

# Generated at 2022-06-23 03:09:11.510953
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': True}})
    # Test substitution of module name
    check_command(module, b"/usr/bin/chmod")
    assert module.deprecations['msg'] == "Consider using the file module with mode rather than running '/usr/bin/chmod'.  If you need to use '/usr/bin/chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check_command(module, b"/usr/bin/unzip")

# Generated at 2022-06-23 03:09:20.227191
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ['/bin/echo', 'hello'])
    assert module._warnings == []

    # Test for module arguments
    check_command(module, ['/bin/chown', 'nobody', 'file'])
    assert module._warnings == ['Consider using the file module with owner rather than running chown.  '
                                'If you need to use chown because the file module is insufficient you can '
                                "add 'warn: false' to this command task or set 'command_warnings=False' in "
                                "the defaults section of ansible.cfg to get rid of this message."]
    module._warnings = []

    # Test for module commands
    check_command(module, ['/usr/bin/curl', 'http://foo'])
   

# Generated at 2022-06-23 03:09:22.888998
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    check_command(commandline='ls')


# ===========================================
# Main control flow


# Generated at 2022-06-23 03:09:35.983129
# Unit test for function main
def test_main():
    from ansible import context
    from ansible.module_utils.basic import AnsibleModule as dummy_module
    from ansible.module_utils.six.moves import builtins

    #-------------------------------------
    # Save module globals
    #-------------------------------------
    global module
    module_tmp=module

    #-------------------------------------
    # Check function's result
    #-------------------------------------
    def _function(module_args, **kwargs):
        x = main()
        if x:
            return 0
        else:
            return 1
    #-------------------------------------
    # Test
    #-------------------------------------
    # with raises(NameError):

# Generated at 2022-06-23 03:09:36.536694
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:09:41.959433
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = '/usr/bin/make_database.sh db_user db_name'
    check_command(module, commandline)

# ===========================================
# Main control flow


# Generated at 2022-06-23 03:09:53.005685
# Unit test for function check_command
def test_check_command():
    commandline = 'cat /etc/motd'
    command = os.path.basename(commandline.split()[0])
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-23 03:10:05.706488
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = ['make_database.sh', 'db_user', 'db_name']
    test_commandline = to_bytes(os.path.basename(commandline[0]))
    command_basename = to_native(test_commandline)
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-23 03:10:15.376274
# Unit test for function main
def test_main():
    """ Function main """

    # Create the module mock
    module = MagicMock()
    module.params = {'_raw_params':'test', '_uses_shell':False, 'chdir':'test',
        'executable':'test', 'creates':'test', 'removes':'test', 'warn':False, 'argv':'test',
        'stdin':'test', 'stdin_add_newline':True, 'strip_empty_ends':True}
    module.check_mode = False

    # Create the Ansible module
    AnsibleModule = MagicMock()
    AnsibleModule.return_value = module

    # Mock the AnsibleModule
    with patch.object(ansible.module_utils.basic, 'AnsibleModule', AnsibleModule):
        main()

# Generated at 2022-06-23 03:10:26.545556
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, "chown foo bar")
    assert module.warnings[0].startswith("Consider using the file module")

    module = AnsibleModule(argument_spec=dict())
    check_command(module, "chmod 045 bar")
    assert module.warnings[0].startswith("Consider using the file module")

    module = AnsibleModule(argument_spec=dict())
    check_command(module, "chgrp foo bar")
    assert module.warnings[0].startswith("Consider using the file module")

    module = AnsibleModule(argument_spec=dict())
    check_command(module, "ln -s bar")
    assert module.warnings[0].startswith("Consider using the file module")

    module = Ansible

# Generated at 2022-06-23 03:10:36.892758
# Unit test for function main
def test_main():
    import unittest
    import tempfile

    class TestCommandModule(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            import shutil
            shutil.rmtree(self.tempdir, ignore_errors=True)

        def test_command_module_with_shell(self):
            from ansible.module_utils.basic import EnvironmentConfig
            from ansible.module_utils.six import string_types
            from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-23 03:10:47.168813
# Unit test for function main
def test_main():
    args = dict(
        _raw_params = 'hello',
        _uses_shell = True,
        argv = '',
        chdir = '/home/ansible/ansible-modules-core/',
        executable = '/bin/bash',
        creates = '',
        removes = '',
        warn = True,
        stdin = 'stdin',
        stdin_add_newline = True,
        strip_empty_ends = True)
    module = AnsibleModule(**args)
    main()


# Generated at 2022-06-23 03:10:59.121220
# Unit test for function main

# Generated at 2022-06-23 03:11:13.353941
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec={},
    )
    commandline = ["/usr/bin/yum", "install", "somepackage"]
    check_command(module, commandline)
    commandline = ["zypper", "install", "somepackage"]
    check_command(module, commandline)
    commandline = "/usr/bin/wget somepackage"
    check_command(module, commandline)
    commandline = ["/usr/bin/curl", "somepackage"]
    check_command(module, commandline)
    commandline = ["/bin/rm", "/path/to/file"]
    check_command(module, commandline)
    commandline = ["/bin/chmod", "700", "/path/to/file"]
    check_command(module, commandline)

# Generated at 2022-06-23 03:11:29.098093
# Unit test for function check_command
def test_check_command():
    check_command(['touch', 'foo'])
    check_command(['ln', 'foo'])
    check_command(['chmod', 'foo'])
    check_command(['mkdir', 'foo'])
    check_command(['rmdir', 'foo'])
    check_command(['rm', 'foo'])
    check_command(['curl', 'http://www.example.com/foo'])
    check_command(['wget', 'http://www.example.com/foo'])
    check_command(['svn', 'checkout', 'svn://svn.zope.org/repos/main/ZConfig/trunk/', 'ZConfig'])
    check_command(['service', 'nginx', 'start'])

# Generated at 2022-06-23 03:11:38.849884
# Unit test for function check_command
def test_check_command():
    module = CommandModule(argument_spec=dict())
    check_command(module, 'sudo vim /etc/hosts')
    check_command(module, 'bash -c ls -l')
    check_command(module, 'tar xzvf /tmp/file.tgz')
    check_command(module, 'unzip file.zip')
    check_command(module, 'touch /tmp/file')
    check_command(module, 'mkdir /tmp/directory')
    check_command(module, 'sed -i s/foo/bar/ /tmp/file')
    check_command(module, 'ln -s /tmp/source /tmp/destination')
    check_command(module, 'rpm -ivh /tmp/file.rpm')
    check_command(module, 'curl -L http://foo.bar')
   

# Generated at 2022-06-23 03:11:39.647993
# Unit test for function main
def test_main():
    assert 0 == 0

# Generated at 2022-06-23 03:11:43.481823
# Unit test for function main
def test_main():
    print(main())
# Boilerplate code to execute the main function
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-23 03:11:54.973816
# Unit test for function main
def test_main():

    # Define arguments and parameter values that will be passed to the module
    _raw_params = 'cat /etc/motd'

    _uses_shell = False

    argv = ['cat', '/etc/motd']

    chdir = None

    executable = None

    creates = None

    removes = None

    warn = False

    stdin = None

    stdin_add_newline = True

    # AnsibleModule object will be created

# Generated at 2022-06-23 03:12:07.263570
# Unit test for function main

# Generated at 2022-06-23 03:12:10.078754
# Unit test for function check_command
def test_check_command():
    module = DummyModule()
    check_command(module, "touch hello")
    check_command(module, "echo hello")
    check_command(module, "sudo echo hello")



# Generated at 2022-06-23 03:12:20.700770
# Unit test for function check_command
def test_check_command():
    commandline = 'ls -al /'
    rc, out, err = test_check_command_assert(commandline)
    assert rc == 0
    assert to_native(out) == ''

    commandline = 'sudo ls -al /'
    rc, out, err = test_check_command_assert(commandline)
    assert rc == 1
    assert to_native(out) == "Consider using 'become', 'become_method', and 'become_user' rather than running sudo"

    commandline = 'cat /etc/motd'
    rc, out, err = test_check_command_assert(commandline)
    assert rc == 0
    assert to_native(out) == ''

    commandline = 'chmod 777 /etc/motd'

# Generated at 2022-06-23 03:12:22.104238
# Unit test for function check_command
def test_check_command():
    assert check_command('curl') == 'get_url or uri'



# Generated at 2022-06-23 03:12:35.195426
# Unit test for function main

# Generated at 2022-06-23 03:12:46.616400
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(command=dict(type='str')))
    check_command(module, 'curl foo')
    assert module.warnings == ["Consider using the get_url or uri module rather than running 'curl'.  "
                               "If you need to use 'curl' because the get_url or uri module is insufficient you can add "
                               "'warn: false' to this command task or set 'command_warnings=False' in the defaults "
                               "section of ansible.cfg to get rid of this message."]
    module.warnings = []
    check_command(module, 'chmod foo')

# Generated at 2022-06-23 03:12:58.337885
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(free_form=dict()))
    check_command(module, ['yum'])
    check_command(module, ['rm', '-rf'])
    check_command(module, ['curl', 'google.com'])
    check_command(module, ['wget', 'google.com'])
    check_command(module, ['svn', 'google.com'])
    check_command(module, ['service', 'apache2', 'restart'])
    check_command(module, ['mount', '-t', 'ext4'])
    check_command(module, ['rpm', '-Uvh'])
    check_command(module, ['yum', 'install'])

# Generated at 2022-06-23 03:13:09.269340
# Unit test for function main
def test_main():
    r = dict(changed=False, ansible_facts=dict())
    r['rc'] = 0
    args = ['echo', 'hello']
    r['cmd'] = args
    r['start'] = None
    r['end'] = None
    r['stderr'] = ""
    r['stdout'] = "hello"
    assert(main() == r)
    args = ['echo', 'hello']
    r['start'] = '2017-09-29 22:03:48.083128'
    r['end'] = '2017-09-29 22:03:48.084657'
    r['delta'] = '0:00:00.001529'
    assert(main() == r)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:22.264239
# Unit test for function main
def test_main():
    import json
    import parameterize
    import pytest

    args = {}


# Generated at 2022-06-23 03:13:24.249597
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:36.722875
# Unit test for function main

# Generated at 2022-06-23 03:13:45.623797
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, "touch file")
    check_command(module, "rm file")
    check_command(module, "mkdir file")
    check_command(module, "chmod file")
    check_command(module, "curl file")
    check_command(module, "wget file")
    check_command(module, "svn file")
    check_command(module, "service file")
    check_command(module, "mount file")
    check_command(module, "rpm file")
    check_command(module, "yum file")
    check_command(module, "apt-get file")
    check_command(module, "tar file")
    check_command(module, "unzip file")

# Generated at 2022-06-23 03:13:56.619852
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.warnings import set_warning_messages
    ansible_module = AnsibleModule({})
    module = ansible_module
    set_warning_messages(module, True)
    check_command(module, '/bin/echo /bin/echo')
    assert module._warnings == ["Consider using the file module with state=link rather than running '/bin/echo'.  If you need to use '/bin/echo' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]
    set_warning_messages(module, False)
    check_command(module, '/bin/echo /bin/echo')
    assert module

# Generated at 2022-06-23 03:14:01.206304
# Unit test for function main
def test_main():
  with pytest.raises(AnsibleExitJson) as exec_info:
    main()
  assert exec_info.value.args[0]['end'] == '2017-09-29 22:03:48.084657'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:14:10.910377
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    check_command(module, 'touch /tmp/foo') # checks for 'touch'
    check_command(module, 'tar -xv') # checks for 'tar'
    check_command(module, 'curl') # checks for 'curl'
    check_command(module, 'chgrp') # checks for 'chgrp'
    check_command(module, 'unzip') # checks for 'unzip'
    check_command(module, 'sed') # checks for 'sed'
    check_command(module, 'dnf') # checks for 'dnf'
    check_command(module, 'zypper') # checks for 'zypper'
    check_command(module, 'pmrun') # checks for 'pmrun'
    check_command

# Generated at 2022-06-23 03:14:19.063578
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec=dict())
    m.warn = lambda x: x
    check_command(m, "/usr/bin/make_database db_user db_name")
    check_command(m, ["/usr/bin/make_database", "db_user", "db_name"])
    check_command(m, ["sudo", "/usr/bin/make_database", "db_user", "db_name"])
    try:
        check_command(m, "/usr/bin/make_database db_user db_name warn=no")
    except:
        pass



# Generated at 2022-06-23 03:14:28.542711
# Unit test for function check_command
def test_check_command():
    import types
    m = types.ModuleType('ansible.modules.extras.command')
    m.warn = lambda x: x
    m.check_command = check_command
    m.AnsibleModule = types.ModuleType('ansible.module_utils.basic')

    m.check_command(m, 'chown user /tmp')
    m.check_command(m, 'chmod 770 /tmp')
    m.check_command(m, 'chgrp user /tmp')
    m.check_command(m, 'ln -s /tmp')
    m.check_command(m, 'mkdir -p /tmp')
    m.check_command(m, 'rmdir /tmp')
    m.check_command(m, 'rm -f /tmp')

# Generated at 2022-06-23 03:14:37.557609
# Unit test for function check_command
def test_check_command():

    module = AnsibleModule(argument_spec={})
    module.warn = lambda msg: msg
    assert check_command(module, 'chown root file') == "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    assert check_command(module, 'chmod 600 file') == "Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

# Generated at 2022-06-23 03:14:46.864048
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)
    module = FakeModule()
    check_command(module, 'chown daemon /etc/zabbix_agentd.conf')
    assert module.warnings == ["Consider using the file module with owner rather than running 'chown'.  "
                               "If you need to use 'chown' because the file module is insufficient you can add "
                               "'warn: false' to this command task or set 'command_warnings=False' in the "
                               "defaults section of ansible.cfg to get rid of this message."]

# Generated at 2022-06-23 03:14:59.027329
# Unit test for function main
def test_main():
    rc = 0
    stdout = "Sending build context to Docker daemon  2.048kB"
    stderr = ""
    r = {'stdout': stdout, 'stdout_lines': stdout.splitlines(), 'stderr': stderr, 'stderr_lines': stderr.splitlines(), 'rc': rc, 'changed': False, 'cmd': 'docker build -t hello-world .', 'msg': ''}
    with patch('os.chdir') as mock_chdir:
        with patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
            mock_module.run_command.return_value = (rc, stdout, stderr)
            main()

# Generated at 2022-06-23 03:15:09.343420
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        '_raw_params': 'ls -1 /etc',
        '_uses_shell': False,
        'creates': '/etc/sudoers',
        'executable': None,
        'argv': None,
        'chdir': None,
        'warn': False,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True
    })
    test_module.run_command = lambda args, executable=None, use_unsafe_shell=False, encoding=None, data=None, binary_data=False: ('', '', '')
    test_module.exit_json = lambda **kwargs: 0
    test_module.fail_json = lambda **kwargs: 0

# Generated at 2022-06-23 03:15:20.169880
# Unit test for function main
def test_main():
    args = {'chdir': '/home/bob',
            '_raw_params': 'ls /home/bob',
            'executable': '/bin/bash',
            'creates': '/home/bob/file.txt',
            '_uses_shell': True,
            'warn': True}
    kwargs = {'rc': 0, 'changed': True}
    module = AnsibleModule(argument_spec=args)
    # mock run_command
    module.run_command = MagicMock(return_value=(0, 'hi', ''))
    main()
    # test
    assert module.exit_json.called
    for k, v in kwargs.items():
        assert module.exit_json.call_args[1][k] == v


# Generated at 2022-06-23 03:15:31.126912
# Unit test for function main
def test_main():
    with open(os.devnull, 'wb') as dev_null:
        with mock.patch.object(builtins, 'open', mock.mock_open(read_data='foo')) as m:
            with mock.patch.object(os.path, 'isfile', mock.Mock(return_value=True)):
                with mock.patch.object(subprocess, 'Popen', return_value=mock.Mock()) as mock_popen:
                    mock_popen.return_value.communicate.return_value = (b'output', b'error')
                    mock_popen.return_value.returncode = 0
                    main()
                assert m.called

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:32.276587
# Unit test for function check_command
def test_check_command():
    #TODO
    pass



# Generated at 2022-06-23 03:15:33.991977
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:39.801422
# Unit test for function check_command
def test_check_command():
    module=AnsibleModule([],{})
    check_command(module,"/usr/bin/cat hello.txt")
    check_command(module,"/usr/bin/rmdir /tmp/testing_dir")
    check_command(module,"/usr/bin/tar xvzf hello.tar.gz")
    check_command(module,"/usr/bin/touch /tmp/hello.txt")


# Generated at 2022-06-23 03:15:49.383863
# Unit test for function check_command
def test_check_command():
    class args:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    module = args(
        warn=True,
        command_warnings=True,
        no_log=True
    )
    check_command(module, ['mv', '/tmp/foo', '/tmp/bar'])
    assert not hasattr(module, 'warnings'), \
        "check_command produced a warning with 'mv' command"

    check_command(module, ['touch', '/tmp/foo'])

# Generated at 2022-06-23 03:15:53.245894
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = "command"
    check_command(module, commandline.split())
    commandline = "command"
    check_command(module, commandline)


# Generated at 2022-06-23 03:16:03.157857
# Unit test for function check_command
def test_check_command():
    # TODO: move this to a test
    # test the check_command warning messages
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(
        argument_spec=dict(),
    )
    check_command(m, 'chown user')
    check_command(m, 'chmod 644')
    check_command(m, 'chgrp group')
    check_command(m, 'ln -s /path')
    check_command(m, 'mkdir /path')
    check_command(m, 'rmdir /path')
    check_command(m, 'rm /path')
    check_command(m, 'touch /path')
    check_command(m, 'curl http://example.com/foo')