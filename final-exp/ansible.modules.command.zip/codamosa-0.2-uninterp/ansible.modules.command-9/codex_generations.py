

# Generated at 2022-06-17 04:02:48.526949
# Unit test for function main

# Generated at 2022-06-17 04:03:00.219716
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:10.168071
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')
    check_command(module, 'pbrun')

# Generated at 2022-06-17 04:03:19.220621
# Unit test for function main
def test_main():
    # Test with a command that returns a non-zero exit code
    args = dict(
        _raw_params='/bin/false',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    r = main()
    assert r['rc'] == 256
    assert r['msg'] == 'non-zero return code'
    assert r['changed'] == True
    assert r['stdout'] == ''
    assert r['stderr'] == ''
    assert r['cmd'] == ['/bin/false']

# Generated at 2022-06-17 04:03:24.588635
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:32.004988
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/usr/bin/make_database.sh db_user db_name',
        chdir='somedir/',
        creates='/path/to/database',
        executable='/bin/bash',
        removes='/path/to/database',
        warn=True,
        stdin='some text',
        stdin_add_newline=False,
        strip_empty_ends=False,
    )

# Generated at 2022-06-17 04:03:43.800929
# Unit test for function main

# Generated at 2022-06-17 04:03:51.023205
# Unit test for function main

# Generated at 2022-06-17 04:03:59.245148
# Unit test for function main

# Generated at 2022-06-17 04:04:11.672689
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/file',
        removes='/tmp/file',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:04:25.618032
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=False,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:04:36.080632
# Unit test for function main

# Generated at 2022-06-17 04:04:46.072786
# Unit test for function main

# Generated at 2022-06-17 04:04:54.745424
# Unit test for function main

# Generated at 2022-06-17 04:05:08.125081
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=True,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:05:19.655063
# Unit test for function main

# Generated at 2022-06-17 04:05:33.316765
# Unit test for function main

# Generated at 2022-06-17 04:05:44.875904
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:54.741874
# Unit test for function main

# Generated at 2022-06-17 04:06:03.566701
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_listlike
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_string
    from ansible.module_utils.common.collections import is_text
    from ansible.module_utils.common.collections import is_binary
    from ansible.module_utils.common.collections import is_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_listlike

# Generated at 2022-06-17 04:06:21.521244
# Unit test for function main

# Generated at 2022-06-17 04:06:32.473838
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/hello',
        removes='/tmp/hello',
        warn=False,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:06:41.042509
# Unit test for function main

# Generated at 2022-06-17 04:06:50.617760
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:07:02.036362
# Unit test for function main

# Generated at 2022-06-17 04:07:10.290542
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:07:21.510604
# Unit test for function main

# Generated at 2022-06-17 04:07:34.095004
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "echo hello")
    check_command(module, "echo hello world")
    check_command(module, "curl http://www.example.com")
    check_command(module, ["curl", "http://www.example.com"])
    check_command(module, "wget http://www.example.com")
    check_command(module, ["wget", "http://www.example.com"])
    check_command(module, "svn co http://www.example.com")
    check_command(module, ["svn", "co", "http://www.example.com"])
    check_command(module, "service httpd start")
    check_command(module, ["service", "httpd", "start"])
   

# Generated at 2022-06-17 04:07:42.841011
# Unit test for function main

# Generated at 2022-06-17 04:07:49.903699
# Unit test for function main

# Generated at 2022-06-17 04:08:27.640966
# Unit test for function main

# Generated at 2022-06-17 04:08:39.249729
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:08:48.008992
# Unit test for function main

# Generated at 2022-06-17 04:08:57.919471
# Unit test for function main

# Generated at 2022-06-17 04:09:07.810121
# Unit test for function main

# Generated at 2022-06-17 04:09:13.409333
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:21.925570
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:09:33.614180
# Unit test for function main

# Generated at 2022-06-17 04:09:45.229363
# Unit test for function main
def test_main():
    # Test with no parameters
    args = dict(
        _raw_params='',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:09:56.895025
# Unit test for function main

# Generated at 2022-06-17 04:10:29.646014
# Unit test for function main

# Generated at 2022-06-17 04:10:34.597721
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:10:41.656452
# Unit test for function main

# Generated at 2022-06-17 04:10:48.640520
# Unit test for function main
def test_main():
    # Test with no args
    module = AnsibleModule(argument_spec={})
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    r['rc'] = 256
    r['msg'] = "no command given"
    module.fail_json.assert_called_with(**r)

    # Test with args and argv
    module = AnsibleModule(argument_spec={'_raw_params': dict(), 'argv': dict(type='list', elements='str')})

# Generated at 2022-06-17 04:10:57.986843
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:11:08.293098
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-17 04:11:20.384215
# Unit test for function main

# Generated at 2022-06-17 04:11:29.989832
# Unit test for function main

# Generated at 2022-06-17 04:11:39.618900
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:11:48.497183
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')