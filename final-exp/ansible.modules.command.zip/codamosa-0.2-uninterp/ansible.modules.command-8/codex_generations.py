

# Generated at 2022-06-17 04:02:46.099100
# Unit test for function main

# Generated at 2022-06-17 04:02:57.958559
# Unit test for function main
def test_main():
    # Test case 1
    # Test case with no command given
    args = dict(
        _raw_params='',
        _uses_shell=False,
        argv='',
        chdir='',
        executable='',
        creates='',
        removes='',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:08.739214
# Unit test for function main

# Generated at 2022-06-17 04:03:18.122981
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:29.461901
# Unit test for function main

# Generated at 2022-06-17 04:03:35.075574
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:40.795033
# Unit test for function main

# Generated at 2022-06-17 04:03:49.030735
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-17 04:03:59.027260
# Unit test for function main

# Generated at 2022-06-17 04:04:11.264688
# Unit test for function main

# Generated at 2022-06-17 04:04:34.183192
# Unit test for function main

# Generated at 2022-06-17 04:04:45.945603
# Unit test for function main

# Generated at 2022-06-17 04:04:54.626578
# Unit test for function main

# Generated at 2022-06-17 04:05:08.036998
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls',
        _uses_shell=False,
        argv=['ls'],
        chdir='/home/user',
        executable='/bin/bash',
        creates='/home/user/test',
        removes='/home/user/test',
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:05:19.568855
# Unit test for function main

# Generated at 2022-06-17 04:05:28.030706
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=False,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:05:39.574600
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:50.782224
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=True,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:05:59.237915
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import time

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Create a temporary environment
    tmpenv = tempfile.mkdtemp(dir=tmpdir)
    # Write a temporary script
    tmpscript = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpscript.write(b'#!/bin/sh\n')
    tmpscript.write(b'echo "Hello, world!"\n')
    tmpscript.close()
    # Write a temporary script
    tmpscript2 = tempfile.Named

# Generated at 2022-06-17 04:06:10.268332
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/chown')
    check_command(module, '/usr/bin/chmod')
    check_command(module, '/usr/bin/chgrp')
    check_command(module, '/usr/bin/ln')
    check_command(module, '/usr/bin/mkdir')
    check_command(module, '/usr/bin/rmdir')
    check_command(module, '/usr/bin/rm')
    check_command(module, '/usr/bin/touch')
    check_command(module, '/usr/bin/curl')
    check_command(module, '/usr/bin/wget')
    check_command(module, '/usr/bin/svn')

# Generated at 2022-06-17 04:06:37.581361
# Unit test for function main

# Generated at 2022-06-17 04:06:47.030659
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:06:54.616453
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:07:02.745987
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:07:11.906889
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import time
    import datetime

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a temporary environment
    tmpenv = tempfile.mkdtemp(dir=tmpdir)

    # Write a temporary file
    tmpfile.write(b"#!/bin/sh\necho hello world\n")
    tmpfile.flush()

    # Write a temporary environment file
    with open(os.path.join(tmpenv, "test.env"), "w") as f:
        f.write("TEST_ENV=test")

    # Write a temporary environment file

# Generated at 2022-06-17 04:07:20.639801
# Unit test for function main

# Generated at 2022-06-17 04:07:32.989868
# Unit test for function main

# Generated at 2022-06-17 04:07:39.593847
# Unit test for function main

# Generated at 2022-06-17 04:07:50.543088
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="echo hello",
        _uses_shell=True,
        argv=["echo", "hello"],
        chdir="/tmp",
        executable="/bin/bash",
        creates="/tmp/foo",
        removes="/tmp/bar",
        warn=True,
        stdin="hello",
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:08:00.508428
# Unit test for function main

# Generated at 2022-06-17 04:08:36.614474
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if not PY3:
        reload(sys)
        sys.setdefaultencoding('utf8')

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary symlink
    temp_link = os.path.join(temp_dir, 'temp_link')
    os.symlink(temp_path, temp_link)

    # Create a temporary executable file
    fd,

# Generated at 2022-06-17 04:08:45.642178
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l /tmp',
        _uses_shell=True,
        argv=['ls', '-l', '/tmp'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    r = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )

# Generated at 2022-06-17 04:08:56.530014
# Unit test for function main

# Generated at 2022-06-17 04:09:04.783144
# Unit test for function main

# Generated at 2022-06-17 04:09:18.783277
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=True,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:09:23.340937
# Unit test for function main
def test_main():
    # Test with no args
    with pytest.raises(SystemExit):
        main()

    # Test with no command
    with pytest.raises(SystemExit):
        main(dict(_raw_params=None))

    # Test with command
    with pytest.raises(SystemExit):
        main(dict(_raw_params='echo hello'))

    # Test with command and argv
    with pytest.raises(SystemExit):
        main(dict(_raw_params='echo hello', argv=['echo', 'hello']))

    # Test with command and argv
    with pytest.raises(SystemExit):
        main(dict(_raw_params='echo hello', argv=['echo', 'hello']))

    # Test with command and argv

# Generated at 2022-06-17 04:09:34.464229
# Unit test for function main

# Generated at 2022-06-17 04:09:44.577749
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:09:56.832051
# Unit test for function main

# Generated at 2022-06-17 04:10:07.853741
# Unit test for function main

# Generated at 2022-06-17 04:11:32.651934
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:11:41.754376
# Unit test for function main

# Generated at 2022-06-17 04:11:51.852819
# Unit test for function main

# Generated at 2022-06-17 04:12:02.261033
# Unit test for function main

# Generated at 2022-06-17 04:12:11.257404
# Unit test for function main

# Generated at 2022-06-17 04:12:21.417491
# Unit test for function main