

# Generated at 2022-06-17 04:02:41.619811
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(**args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:02:46.643670
# Unit test for function main

# Generated at 2022-06-17 04:02:57.987028
# Unit test for function main

# Generated at 2022-06-17 04:03:08.775825
# Unit test for function main

# Generated at 2022-06-17 04:03:17.613498
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test.txt',
        removes='/tmp/test.txt',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:27.781507
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:37.896908
# Unit test for function main

# Generated at 2022-06-17 04:03:49.117321
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:04:01.077904
# Unit test for function main

# Generated at 2022-06-17 04:04:12.975831
# Unit test for function main

# Generated at 2022-06-17 04:04:46.123825
# Unit test for function main

# Generated at 2022-06-17 04:04:54.802528
# Unit test for function main

# Generated at 2022-06-17 04:05:08.125178
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:17.732745
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:29.116140
# Unit test for function main

# Generated at 2022-06-17 04:05:41.185273
# Unit test for function main

# Generated at 2022-06-17 04:05:51.840365
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:06:03.122976
# Unit test for function main

# Generated at 2022-06-17 04:06:09.727943
# Unit test for function main

# Generated at 2022-06-17 04:06:20.463206
# Unit test for function main

# Generated at 2022-06-17 04:07:16.742655
# Unit test for function main
def test_main():
    # Test with no args
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == "no command given"

    # Test with args
    module = AnsibleModule(argument_spec={'_raw_params': 'ls'})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == "changed"
    assert result['stdout'] != ""
    assert result['stderr'] == ""

    # Test with argv
    module = AnsibleModule(argument_spec={'argv': ['ls']})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == "changed"
    assert result['stdout'] != ""
    assert result['stderr'] == ""

    #

# Generated at 2022-06-17 04:07:23.091191
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:07:34.459175
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True
    )

# Generated at 2022-06-17 04:07:43.048665
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls',
        _uses_shell=False,
        argv=['ls'],
        chdir='/',
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:07:52.925386
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:08:00.645532
# Unit test for function main

# Generated at 2022-06-17 04:08:10.503951
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:08:21.434003
# Unit test for function main

# Generated at 2022-06-17 04:08:31.765612
# Unit test for function main

# Generated at 2022-06-17 04:08:42.468298
# Unit test for function main

# Generated at 2022-06-17 04:09:25.670858
# Unit test for function main

# Generated at 2022-06-17 04:09:35.340663
# Unit test for function main

# Generated at 2022-06-17 04:09:46.374488
# Unit test for function main

# Generated at 2022-06-17 04:09:56.980206
# Unit test for function main

# Generated at 2022-06-17 04:10:05.527914
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:10:18.794275
# Unit test for function main

# Generated at 2022-06-17 04:10:27.352111
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=True,
        stdin='foo',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:10:37.145995
# Unit test for function main
def test_main():
    # Test with no args
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == "no command given"

    # Test with args
    module = AnsibleModule(argument_spec={'_raw_params': dict(type='str', default='echo hello')})
    result = main()
    assert result['rc'] == 0
    assert result['stdout'] == 'hello'

    # Test with argv
    module = AnsibleModule(argument_spec={'argv': dict(type='list', elements='str', default=['echo', 'hello'])})
    result = main()
    assert result['rc'] == 0
    assert result['stdout'] == 'hello'

    # Test with argv and _raw_params
    module = AnsibleModule

# Generated at 2022-06-17 04:10:43.757928
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == "no command given"

    # Test with args and argv

# Generated at 2022-06-17 04:10:55.331832
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')