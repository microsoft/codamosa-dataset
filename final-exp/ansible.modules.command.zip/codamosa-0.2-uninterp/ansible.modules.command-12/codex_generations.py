

# Generated at 2022-06-17 04:02:47.669580
# Unit test for function main

# Generated at 2022-06-17 04:02:59.015706
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown root /tmp/foo')
    check_command(module, 'chmod 755 /tmp/foo')
    check_command(module, 'chgrp root /tmp/foo')
    check_command(module, 'ln -s /tmp/foo /tmp/bar')
    check_command(module, 'mkdir /tmp/foo')
    check_command(module, 'rmdir /tmp/foo')
    check_command(module, 'rm /tmp/foo')
    check_command(module, 'touch /tmp/foo')
    check_command(module, 'curl http://www.example.com/')
    check_command(module, 'wget http://www.example.com/')

# Generated at 2022-06-17 04:03:09.307440
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils import connection
    from ansible.module_utils import loader
    from ansible.module_utils import lookup
    from ansible.module_utils import vars
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import shlex

# Generated at 2022-06-17 04:03:19.730936
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:25.065955
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:32.417993
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/bin/false',
        _uses_shell=False,
        argv=['/bin/false'],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:44.171795
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:53.607150
# Unit test for function main

# Generated at 2022-06-17 04:04:04.270951
# Unit test for function main

# Generated at 2022-06-17 04:04:14.838349
# Unit test for function main
def test_main():
    # Test with no command
    args = dict(
        _raw_params='',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:04:34.220365
# Unit test for function main

# Generated at 2022-06-17 04:04:45.958258
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:04:57.125796
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:05:08.545525
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/usr/bin/make_database.sh db_user db_name',
        chdir='somedir/',
        executable='/bin/bash',
        creates='/path/to/database',
        removes='/path/to/database',
        warn=True,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:05:19.813982
# Unit test for function main

# Generated at 2022-06-17 04:05:24.769163
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "chown")
    check_command(module, "chmod")
    check_command(module, "chgrp")
    check_command(module, "ln")
    check_command(module, "mkdir")
    check_command(module, "rmdir")
    check_command(module, "rm")
    check_command(module, "touch")
    check_command(module, "curl")
    check_command(module, "wget")
    check_command(module, "svn")
    check_command(module, "service")
    check_command(module, "mount")
    check_command(module, "rpm")
    check_command(module, "yum")

# Generated at 2022-06-17 04:05:35.986565
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:05:46.052567
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "chown")
    check_command(module, "chmod")
    check_command(module, "chgrp")
    check_command(module, "ln")
    check_command(module, "mkdir")
    check_command(module, "rmdir")
    check_command(module, "rm")
    check_command(module, "touch")
    check_command(module, "curl")
    check_command(module, "wget")
    check_command(module, "svn")
    check_command(module, "service")
    check_command(module, "mount")
    check_command(module, "rpm")
    check_command(module, "yum")

# Generated at 2022-06-17 04:05:55.885536
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:06:08.055040
# Unit test for function main

# Generated at 2022-06-17 04:06:29.917071
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:06:39.785611
# Unit test for function main

# Generated at 2022-06-17 04:06:49.593937
# Unit test for function main

# Generated at 2022-06-17 04:07:00.686690
# Unit test for function main

# Generated at 2022-06-17 04:07:12.371282
# Unit test for function main

# Generated at 2022-06-17 04:07:21.015086
# Unit test for function main

# Generated at 2022-06-17 04:07:33.470881
# Unit test for function main

# Generated at 2022-06-17 04:07:45.383388
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:55.748924
# Unit test for function main

# Generated at 2022-06-17 04:08:04.395562
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:08:46.714978
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:08:57.298024
# Unit test for function main

# Generated at 2022-06-17 04:09:07.738543
# Unit test for function main

# Generated at 2022-06-17 04:09:13.974213
# Unit test for function main

# Generated at 2022-06-17 04:09:21.954665
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:33.615176
# Unit test for function main

# Generated at 2022-06-17 04:09:45.233269
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/chown')
    check_command(module, '/usr/bin/chmod')
    check_command(module, '/usr/bin/chgrp')
    check_command(module, '/usr/bin/ln')
    check_command(module, '/usr/bin/mkdir')
    check_command(module, '/usr/bin/rmdir')
    check_command(module, '/usr/bin/rm')
    check_command(module, '/usr/bin/touch')
    check_command(module, '/usr/bin/curl')
    check_command(module, '/usr/bin/wget')
    check_command(module, '/usr/bin/svn')

# Generated at 2022-06-17 04:09:56.893965
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    assert module.warnings[0] == "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check_command(module, 'chmod')
    assert module.warnings[1] == "Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check

# Generated at 2022-06-17 04:10:08.116639
# Unit test for function main

# Generated at 2022-06-17 04:10:18.645366
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:12:00.257282
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=True,
        stdin='foo',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:12:08.298149
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')

# Generated at 2022-06-17 04:12:20.066292
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/',
        executable='/bin/bash',
        creates='/tmp/hello',
        removes='/tmp/hello',
        warn=True,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:12:28.474036
# Unit test for function main