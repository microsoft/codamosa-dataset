

# Generated at 2022-06-17 04:02:43.397500
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:02:52.452530
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:03.900957
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/hello',
        removes='/tmp/hello',
        warn=True,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:15.009221
# Unit test for function main

# Generated at 2022-06-17 04:03:21.021077
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')
    check_command(module, 'pbrun')

# Generated at 2022-06-17 04:03:27.106937
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:33.379099
# Unit test for function main

# Generated at 2022-06-17 04:03:39.174216
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:47.784363
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    assert module.warnings == ["Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]
    check_command(module, 'chmod')

# Generated at 2022-06-17 04:03:58.931968
# Unit test for function main

# Generated at 2022-06-17 04:04:26.939602
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_text

# Generated at 2022-06-17 04:04:35.328561
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ['touch', 'foo'])
    assert module.warnings == [
        "Consider using the file module with state=touch rather than running 'touch'.  If you need to use 'touch' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    ]



# Generated at 2022-06-17 04:04:46.006242
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = ['/usr/bin/chown', 'root', '/tmp/foo']
    check_command(module, commandline)
    assert module.warnings == ["Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]
    module.warnings = []
    commandline = ['/usr/bin/chmod', '777', '/tmp/foo']
    check_command(module, commandline)

# Generated at 2022-06-17 04:04:54.401165
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/usr/bin/make_database.sh db_user db_name',
        _uses_shell=True,
        argv=['/usr/bin/make_database.sh', 'db_user', 'db_name'],
        chdir='somedir/',
        executable='/usr/bin/make_database.sh',
        creates='/path/to/database',
        removes='/path/to/database',
        warn=True,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:05:07.896806
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls',
        _uses_shell=False,
        argv=['ls'],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:05:20.401584
# Unit test for function main

# Generated at 2022-06-17 04:05:30.238862
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:05:42.139018
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:05:52.711712
# Unit test for function main

# Generated at 2022-06-17 04:06:00.446938
# Unit test for function main

# Generated at 2022-06-17 04:06:35.236911
# Unit test for function main

# Generated at 2022-06-17 04:06:42.593710
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    import tempfile

    # Save the original command line arguments so we can restore them after
    # we're done (otherwise pytest will try to parse them).
    orig_args = sys.argv

    # Create a temporary file to use as stdin.
    stdin_fd, stdin_path = tempfile.mkstemp()
    os.close(stdin_fd)

    # Create a temporary file to use as the creates parameter.
    creates_fd, creates_path = tempfile.mkstemp()
    os.close(creates_fd)

    # Create a temporary file to use as the removes parameter.
    removes_fd, removes_path = tempfile.mkstemp()
    os.close(removes_fd)

    # Create a temporary directory to use

# Generated at 2022-06-17 04:06:51.972708
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable
    import shlex
    import os
    import glob
    import datetime

# Generated at 2022-06-17 04:07:02.590616
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:12.204232
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:07:21.321643
# Unit test for function main

# Generated at 2022-06-17 04:07:33.926648
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:07:42.747212
# Unit test for function main

# Generated at 2022-06-17 04:07:53.167783
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:08:03.235125
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:08:56.812892
# Unit test for function main

# Generated at 2022-06-17 04:09:07.706792
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:13.355622
# Unit test for function main
def test_main():
    # Test with no args
    args = dict(
        _raw_params='',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:09:18.409724
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:09:25.208773
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:34.702576
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:44.761896
# Unit test for function main
def test_main():
    # Test with no args
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == "no command given"

    # Test with args
    module = AnsibleModule(argument_spec={'_raw_params': 'ls'})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == "changed"

    # Test with argv
    module = AnsibleModule(argument_spec={'argv': ['ls']})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == "changed"

    # Test with argv and executable
    module = AnsibleModule(argument_spec={'argv': ['ls'], 'executable': '/bin/bash'})
    result = main()

# Generated at 2022-06-17 04:09:56.864420
# Unit test for function main

# Generated at 2022-06-17 04:10:08.065133
# Unit test for function main

# Generated at 2022-06-17 04:10:13.641830
# Unit test for function main