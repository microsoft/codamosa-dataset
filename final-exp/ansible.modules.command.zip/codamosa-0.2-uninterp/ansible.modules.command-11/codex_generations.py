

# Generated at 2022-06-17 04:02:48.773358
# Unit test for function main

# Generated at 2022-06-17 04:02:58.128766
# Unit test for function main

# Generated at 2022-06-17 04:03:08.842676
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:17.643332
# Unit test for function main

# Generated at 2022-06-17 04:03:27.782059
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/file',
        removes='/tmp/file',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:38.894105
# Unit test for function main
def test_main():
    # Test with no args
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == "no command given"

    # Test with args
    module = AnsibleModule(argument_spec={'_raw_params': 'ls'})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == ''
    assert result['stdout'] != ''
    assert result['stderr'] == ''

    # Test with argv
    module = AnsibleModule(argument_spec={'argv': ['ls']})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == ''
    assert result['stdout'] != ''
    assert result['stderr'] == ''

    # Test with argv

# Generated at 2022-06-17 04:03:49.735680
# Unit test for function main

# Generated at 2022-06-17 04:03:59.083990
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    import os
    import shlex
    import glob
    import datetime

# Generated at 2022-06-17 04:04:10.763471
# Unit test for function main

# Generated at 2022-06-17 04:04:21.552474
# Unit test for function main

# Generated at 2022-06-17 04:04:38.265583
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:04:48.834738
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:04:56.626338
# Unit test for function main

# Generated at 2022-06-17 04:05:08.335316
# Unit test for function main

# Generated at 2022-06-17 04:05:19.782690
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:25.936929
# Unit test for function main

# Generated at 2022-06-17 04:05:33.201815
# Unit test for function main

# Generated at 2022-06-17 04:05:45.260302
# Unit test for function main

# Generated at 2022-06-17 04:05:55.223353
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:06:03.598372
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:06:28.968354
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:06:39.692776
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:06:49.414774
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:00.393208
# Unit test for function main

# Generated at 2022-06-17 04:07:08.941545
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:16.692508
# Unit test for function main

# Generated at 2022-06-17 04:07:23.512203
# Unit test for function main

# Generated at 2022-06-17 04:07:34.496873
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:41.737844
# Unit test for function main
def test_main():
    # Test with no command
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == 'no command given'

    # Test with command
    module = AnsibleModule(argument_spec={'_raw_params': 'ls'})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == ''
    assert result['stdout'] != ''
    assert result['stderr'] == ''

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:07:53.056093
# Unit test for function main

# Generated at 2022-06-17 04:08:36.844107
# Unit test for function main

# Generated at 2022-06-17 04:08:45.837943
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')
    check_command(module, 'pbrun')

# Generated at 2022-06-17 04:08:56.556105
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/',
        executable=None,
        creates='',
        removes='',
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:09:04.810522
# Unit test for function main

# Generated at 2022-06-17 04:09:18.782555
# Unit test for function main

# Generated at 2022-06-17 04:09:25.527552
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "touch /tmp/test")
    check_command(module, "mkdir /tmp/test")
    check_command(module, "chown root /tmp/test")
    check_command(module, "chmod 0644 /tmp/test")
    check_command(module, "chgrp root /tmp/test")
    check_command(module, "ln -s /tmp/test /tmp/test2")
    check_command(module, "rm /tmp/test")
    check_command(module, "rmdir /tmp/test")
    check_command(module, "curl http://www.example.com/")
    check_command(module, "wget http://www.example.com/")

# Generated at 2022-06-17 04:09:35.237191
# Unit test for function main

# Generated at 2022-06-17 04:09:43.400709
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/bin/false',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:09:56.761808
# Unit test for function main

# Generated at 2022-06-17 04:10:07.810763
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="echo hello",
        _uses_shell=False,
        argv=["echo", "hello"],
        chdir="/tmp",
        executable="/bin/bash",
        creates="/tmp/hello",
        removes="/tmp/hello",
        warn=False,
        stdin="hello",
        stdin_add_newline=True,
        strip_empty_ends=True,
    )