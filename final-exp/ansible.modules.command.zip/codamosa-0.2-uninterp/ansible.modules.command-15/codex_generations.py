

# Generated at 2022-06-17 04:02:47.313145
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/foo',
        removes='/tmp/bar',
        warn=False,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:02:58.312081
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:10.212082
# Unit test for function main

# Generated at 2022-06-17 04:03:19.215408
# Unit test for function main
def test_main():
    import json
    import os
    import sys
    import tempfile
    import textwrap
    import time

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Make sure we can write to a temp file
    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'command_unit_test')
    with open(tmpfile, 'w') as f:
        f.write('foo')

    # Make sure we can write to a temp dir
    tmpdir2 = tempfile.mkdtemp()
    tmpfile2 = os.path.join(tmpdir2, 'command_unit_test2')

    # Make sure we can write to a temp file in a temp dir
    tmpdir3 = tempfile.mkdtemp()
    tmp

# Generated at 2022-06-17 04:03:28.315207
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:39.585854
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "touch /tmp/test")
    check_command(module, "chmod 777 /tmp/test")
    check_command(module, "chown root /tmp/test")
    check_command(module, "chgrp root /tmp/test")
    check_command(module, "ln -s /tmp/test /tmp/test2")
    check_command(module, "mkdir /tmp/test")
    check_command(module, "rmdir /tmp/test")
    check_command(module, "rm /tmp/test")
    check_command(module, "curl http://www.example.com")
    check_command(module, "wget http://www.example.com")

# Generated at 2022-06-17 04:03:48.215437
# Unit test for function main

# Generated at 2022-06-17 04:04:00.905243
# Unit test for function main

# Generated at 2022-06-17 04:04:12.783917
# Unit test for function main

# Generated at 2022-06-17 04:04:22.421622
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/',
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:04:40.715335
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True
    )
    module = AnsibleModule(**args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:04:48.501865
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:04:58.684087
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "chown")
    check_command(module, "chmod")
    check_command(module, "chgrp")
    check_command(module, "ln")
    check_command(module, "mkdir")
    check_command(module, "rmdir")
    check_command(module, "rm")
    check_command(module, "touch")
    check_command(module, "curl")
    check_command(module, "wget")
    check_command(module, "svn")
    check_command(module, "service")
    check_command(module, "mount")
    check_command(module, "rpm")
    check_command(module, "yum")

# Generated at 2022-06-17 04:05:10.815152
# Unit test for function main

# Generated at 2022-06-17 04:05:20.396064
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    import ansible.module_utils.common.collections
    import ansible.module_utils.basic
    import ansible.module_utils._text
    import ansible.module_utils.common.text
    import ansible.module_utils.common.process
    import ansible.module_utils.common.file
    import ansible.module_utils.common.json_utils
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.sys_info
    import ansible.module_utils.common.removed_key

# Generated at 2022-06-17 04:05:29.250586
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:41.321636
# Unit test for function main

# Generated at 2022-06-17 04:05:51.974386
# Unit test for function main

# Generated at 2022-06-17 04:06:03.122405
# Unit test for function main

# Generated at 2022-06-17 04:06:08.087048
# Unit test for function main

# Generated at 2022-06-17 04:06:25.012619
# Unit test for function main

# Generated at 2022-06-17 04:06:35.594240
# Unit test for function main

# Generated at 2022-06-17 04:06:42.765871
# Unit test for function main

# Generated at 2022-06-17 04:06:52.103718
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:02.590773
# Unit test for function main

# Generated at 2022-06-17 04:07:11.734002
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')

# Generated at 2022-06-17 04:07:20.439253
# Unit test for function main

# Generated at 2022-06-17 04:07:32.691307
# Unit test for function main

# Generated at 2022-06-17 04:07:39.406230
# Unit test for function main

# Generated at 2022-06-17 04:07:48.078828
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-17 04:08:20.472107
# Unit test for function main

# Generated at 2022-06-17 04:08:26.088938
# Unit test for function main

# Generated at 2022-06-17 04:08:37.617798
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:08:46.495334
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:08:54.566198
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chmod')
    check_command(module, 'chown')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:00.704799
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:07.966715
# Unit test for function main

# Generated at 2022-06-17 04:09:12.358355
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:09:21.826510
# Unit test for function main
def test_main():
    # Test with no args
    args = dict(
        _raw_params='',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:09:33.577914
# Unit test for function main

# Generated at 2022-06-17 04:10:28.851792
# Unit test for function main
def test_main():
    # Test case 1
    args = {
        '_raw_params': '',
        '_uses_shell': False,
        'argv': [],
        'chdir': '',
        'creates': '',
        'executable': '',
        'removes': '',
        'warn': False,
        'stdin': '',
        'stdin_add_newline': True,
        'strip_empty_ends': True,
    }

# Generated at 2022-06-17 04:10:37.461069
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "touch /tmp/test")
    check_command(module, "mkdir /tmp/test")
    check_command(module, "rm /tmp/test")
    check_command(module, "ln -s /tmp/test /tmp/test2")
    check_command(module, "chown root /tmp/test")
    check_command(module, "chmod 0600 /tmp/test")
    check_command(module, "chgrp root /tmp/test")
    check_command(module, "curl http://localhost")
    check_command(module, "wget http://localhost")
    check_command(module, "svn co http://localhost")
    check_command(module, "service httpd restart")

# Generated at 2022-06-17 04:10:47.354086
# Unit test for function main

# Generated at 2022-06-17 04:10:51.766778
# Unit test for function main

# Generated at 2022-06-17 04:10:59.916244
# Unit test for function main

# Generated at 2022-06-17 04:11:08.838129
# Unit test for function main
def test_main():
    # Test case 1
    # Test with no command
    args = dict(
        _raw_params='',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:11:20.536294
# Unit test for function main

# Generated at 2022-06-17 04:11:30.085837
# Unit test for function main

# Generated at 2022-06-17 04:11:39.705635
# Unit test for function main

# Generated at 2022-06-17 04:11:44.826331
# Unit test for function main