

# Generated at 2022-06-17 04:02:44.623697
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:02:54.086170
# Unit test for function main

# Generated at 2022-06-17 04:03:06.915860
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:16.557487
# Unit test for function main

# Generated at 2022-06-17 04:03:22.196804
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:31.190908
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:42.804885
# Unit test for function main

# Generated at 2022-06-17 04:03:52.202298
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.params = {'warn': True}
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')


# Generated at 2022-06-17 04:04:00.043232
# Unit test for function main

# Generated at 2022-06-17 04:04:11.841342
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    import ansible.module_utils.basic

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    ansible_cfg = os.path.join(tmpdir, "ansible.cfg")
    with open(ansible_cfg, 'w') as f:
        f.write("[defaults]\n")
        f.write("command_warnings = False\n")

    # Create a temporary ansible module
    module_name = os.path.join(tmpdir, "ansible_test_command_module.py")

# Generated at 2022-06-17 04:04:38.906294
# Unit test for function main

# Generated at 2022-06-17 04:04:46.566158
# Unit test for function main

# Generated at 2022-06-17 04:04:55.145200
# Unit test for function main

# Generated at 2022-06-17 04:05:08.126507
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:19.653696
# Unit test for function main

# Generated at 2022-06-17 04:05:33.266821
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:44.797167
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'touch /tmp/test')
    check_command(module, 'ln -s /tmp/test /tmp/test2')
    check_command(module, 'wget http://www.example.com/')
    check_command(module, 'rpm -ivh http://www.example.com/')
    check_command(module, 'yum install -y http://www.example.com/')
    check_command(module, 'dnf install -y http://www.example.com/')
    check_command(module, 'zypper install -y http://www.example.com/')
    check_command(module, 'apt-get install http://www.example.com/')

# Generated at 2022-06-17 04:05:54.797590
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:06:06.834903
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "touch /tmp/test")
    check_command(module, "mkdir /tmp/test")
    check_command(module, "rm /tmp/test")
    check_command(module, "rmdir /tmp/test")
    check_command(module, "chown root /tmp/test")
    check_command(module, "chmod 600 /tmp/test")
    check_command(module, "chgrp root /tmp/test")
    check_command(module, "ln -s /tmp/test /tmp/test2")
    check_command(module, "curl http://www.example.com/test")
    check_command(module, "wget http://www.example.com/test")

# Generated at 2022-06-17 04:06:17.577318
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')
    check_command(module, 'pbrun')

# Generated at 2022-06-17 04:07:19.692037
# Unit test for function main

# Generated at 2022-06-17 04:07:30.406910
# Unit test for function main

# Generated at 2022-06-17 04:07:42.003341
# Unit test for function main

# Generated at 2022-06-17 04:07:53.131593
# Unit test for function main

# Generated at 2022-06-17 04:08:03.195849
# Unit test for function main

# Generated at 2022-06-17 04:08:12.013668
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:08:23.038549
# Unit test for function main

# Generated at 2022-06-17 04:08:31.859481
# Unit test for function main

# Generated at 2022-06-17 04:08:42.550842
# Unit test for function main

# Generated at 2022-06-17 04:08:50.382121
# Unit test for function main

# Generated at 2022-06-17 04:10:20.260471
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:10:29.542305
# Unit test for function main

# Generated at 2022-06-17 04:10:37.486202
# Unit test for function main

# Generated at 2022-06-17 04:10:47.355125
# Unit test for function main

# Generated at 2022-06-17 04:10:56.415032
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:11:08.180964
# Unit test for function main

# Generated at 2022-06-17 04:11:20.337791
# Unit test for function main

# Generated at 2022-06-17 04:11:29.955529
# Unit test for function main

# Generated at 2022-06-17 04:11:38.554849
# Unit test for function main

# Generated at 2022-06-17 04:11:44.141582
# Unit test for function main