

# Generated at 2022-06-17 04:02:45.712890
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-17 04:02:55.489622
# Unit test for function main

# Generated at 2022-06-17 04:03:07.884987
# Unit test for function main

# Generated at 2022-06-17 04:03:17.002321
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-17 04:03:27.681657
# Unit test for function main

# Generated at 2022-06-17 04:03:37.787715
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import stat
    import time
    import datetime
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_iterable

    def _create_test_file(path, content):
        with open(path, 'wb') as f:
            f.write(to_bytes(content))

    def _create_test_executable(path, content):
        _create_test_file(path, content)
        os.chmod(path, stat.S_IRWXU)

    def _create_test_directory(path):
        os.mk

# Generated at 2022-06-17 04:03:48.189590
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:58.963449
# Unit test for function main

# Generated at 2022-06-17 04:04:10.504011
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:04:21.488438
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:04:38.058503
# Unit test for function main

# Generated at 2022-06-17 04:04:43.260730
# Unit test for function main

# Generated at 2022-06-17 04:04:52.473583
# Unit test for function main

# Generated at 2022-06-17 04:05:02.758410
# Unit test for function main

# Generated at 2022-06-17 04:05:14.585192
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:23.046737
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:05:30.180483
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_unicode
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_text
   

# Generated at 2022-06-17 04:05:42.097340
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:05:52.711883
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-17 04:06:03.402246
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:06:25.263895
# Unit test for function main

# Generated at 2022-06-17 04:06:29.749472
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')
    check_command(module, 'pbrun')

# Generated at 2022-06-17 04:06:39.785366
# Unit test for function main
def test_main():
    # Test with no args
    args = dict(
        _raw_params='',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:06:49.594077
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:00.686830
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:12.377312
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == 'no command given'

    # Test with args
    module = AnsibleModule(argument_spec={'_raw_params': 'ls -l'})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == ''
    assert result['changed'] == True
    assert result['stdout'] != ''
    assert result['stderr'] == ''
    assert result['cmd'] == ['ls', '-l']

    # Test with argv
    module = AnsibleModule(argument_spec={'argv': ['ls', '-l']})
    result = main()
    assert result['rc'] == 0
    assert result['msg']

# Generated at 2022-06-17 04:07:22.414290
# Unit test for function main

# Generated at 2022-06-17 04:07:34.422265
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:46.800252
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:55.515370
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    r = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )

# Generated at 2022-06-17 04:09:07.884316
# Unit test for function main

# Generated at 2022-06-17 04:09:13.484751
# Unit test for function main

# Generated at 2022-06-17 04:09:18.518538
# Unit test for function main

# Generated at 2022-06-17 04:09:25.296650
# Unit test for function main

# Generated at 2022-06-17 04:09:34.807208
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'dnf')
    check_command(module, 'zypper')
    check_command(module, 'sudo')
    check_command(module, 'su')
    check_command(module, 'pbrun')

# Generated at 2022-06-17 04:09:44.862213
# Unit test for function main

# Generated at 2022-06-17 04:09:56.863855
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=True,
        argv=['echo', 'hello'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:10:08.066957
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:10:18.591129
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:10:28.771748
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    r = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )

# Generated at 2022-06-17 04:12:12.440067
# Unit test for function main

# Generated at 2022-06-17 04:12:21.876166
# Unit test for function main