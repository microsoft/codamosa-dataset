

# Generated at 2022-06-17 04:02:45.198393
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == "no command given"
    assert result['failed'] == True
    # Test with a command
    module = AnsibleModule(argument_spec={'_raw_params': 'ls'})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == ""
    assert result['failed'] == False

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:02:54.653938
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=False,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=False,
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    r = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg='',
    )

# Generated at 2022-06-17 04:03:02.858446
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    module = AnsibleModule(**args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:03:14.598723
# Unit test for function main

# Generated at 2022-06-17 04:03:20.648967
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:26.684126
# Unit test for function main

# Generated at 2022-06-17 04:03:33.045224
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l',
        _uses_shell=True,
        argv=['ls', '-l'],
        chdir='/tmp',
        executable='/bin/bash',
        creates='/tmp/test',
        removes='/tmp/test',
        warn=True,
        stdin='test',
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

# Generated at 2022-06-17 04:03:44.927069
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:03:53.682711
# Unit test for function main

# Generated at 2022-06-17 04:04:04.308923
# Unit test for function main

# Generated at 2022-06-17 04:04:39.909022
# Unit test for function main

# Generated at 2022-06-17 04:04:51.858181
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['rc'] == 256
    assert result['msg'] == "no command given"

    # Test with args
    module = AnsibleModule(argument_spec={'_raw_params': 'ls'})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == "changed"

    # Test with argv
    module = AnsibleModule(argument_spec={'argv': ['ls']})
    result = main()
    assert result['rc'] == 0
    assert result['msg'] == "changed"

    # Test with args and argv
    module = AnsibleModule(argument_spec={'_raw_params': 'ls', 'argv': ['ls']})
    result = main()


# Generated at 2022-06-17 04:04:58.280923
# Unit test for function main

# Generated at 2022-06-17 04:05:10.448935
# Unit test for function main

# Generated at 2022-06-17 04:05:20.129321
# Unit test for function main

# Generated at 2022-06-17 04:05:33.309692
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = lambda x: x
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')


# Generated at 2022-06-17 04:05:44.876936
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:05:54.741951
# Unit test for function main

# Generated at 2022-06-17 04:06:01.393886
# Unit test for function main

# Generated at 2022-06-17 04:06:10.418686
# Unit test for function main

# Generated at 2022-06-17 04:07:21.016055
# Unit test for function main

# Generated at 2022-06-17 04:07:33.465376
# Unit test for function main

# Generated at 2022-06-17 04:07:42.435386
# Unit test for function main

# Generated at 2022-06-17 04:07:49.695693
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:07:56.263775
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'touch /tmp/test')
    check_command(module, 'ln -s /tmp/test /tmp/test2')
    check_command(module, 'chmod 777 /tmp/test')
    check_command(module, 'chown root /tmp/test')
    check_command(module, 'chgrp root /tmp/test')
    check_command(module, 'mkdir /tmp/test')
    check_command(module, 'rmdir /tmp/test')
    check_command(module, 'rm /tmp/test')
    check_command(module, 'curl http://www.example.com')
    check_command(module, 'wget http://www.example.com')

# Generated at 2022-06-17 04:08:08.774053
# Unit test for function main

# Generated at 2022-06-17 04:08:21.279443
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:08:31.739957
# Unit test for function main

# Generated at 2022-06-17 04:08:42.434109
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:08:50.291314
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:09:46.850812
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'echo hello')
    check_command(module, ['echo', 'hello'])
    check_command(module, 'chown root /etc/passwd')
    check_command(module, 'chmod 600 /etc/passwd')
    check_command(module, 'chgrp root /etc/passwd')
    check_command(module, 'ln -s /etc/passwd /tmp/passwd')
    check_command(module, 'mkdir /tmp/test')
    check_command(module, 'rmdir /tmp/test')
    check_command(module, 'rm /tmp/test')
    check_command(module, 'touch /tmp/test')

# Generated at 2022-06-17 04:09:57.002335
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils import connection
    from ansible.module_utils import crypto
    from ansible.module_utils import json_utils
    from ansible.module_utils import lookup_loader
    from ansible.module_utils import module_loader
    from ansible.module_utils import module_utils_loader
    from ansible.module_utils import package_common
    from ansible.module_utils import pkg_resources
    from ansible.module_utils import pycompat24
    from ansible.module_utils import pycompat24
    from ansible.module_utils import pycompat24
    from ansible.module_utils import pycompat24
    from ansible.module_utils import pycompat24

# Generated at 2022-06-17 04:10:08.205005
# Unit test for function main

# Generated at 2022-06-17 04:10:18.942059
# Unit test for function main

# Generated at 2022-06-17 04:10:28.797686
# Unit test for function main

# Generated at 2022-06-17 04:10:33.884082
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 04:10:43.010696
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown')
    check_command(module, 'chmod')
    check_command(module, 'chgrp')
    check_command(module, 'ln')
    check_command(module, 'mkdir')
    check_command(module, 'rmdir')
    check_command(module, 'rm')
    check_command(module, 'touch')
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')

# Generated at 2022-06-17 04:10:54.819527
# Unit test for function main

# Generated at 2022-06-17 04:11:03.851244
# Unit test for function main

# Generated at 2022-06-17 04:11:10.721944
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'command')
    check_command(module, ['command'])
    check_command(module, 'command arg1 arg2')
    check_command(module, ['command', 'arg1', 'arg2'])
    check_command(module, 'command arg1 arg2 arg3')
    check_command(module, ['command', 'arg1', 'arg2', 'arg3'])
    check_command(module, 'command arg1 arg2 arg3 arg4')
    check_command(module, ['command', 'arg1', 'arg2', 'arg3', 'arg4'])
    check_command(module, 'command arg1 arg2 arg3 arg4 arg5')