

# Generated at 2022-06-20 21:20:02.004210
# Unit test for function check_command
def test_check_command():
    class TestModule:
        def __init__(self):
            self.warns = []
            self.called_warns = 0
        def warn(self, msg):
            self.warns.append(msg)
            self.called_warns += 1
    module = TestModule()
    check_command(module, "ls")
    assert module.warns[0] == "Consider using the file module with state=directory rather than running 'ls'."
    assert module.called_warns == 1
    check_command(module, "curl http://www.ansible.com/")
    assert module.warns[0] == "Consider using the get_url or uri module rather than running 'curl'."
    assert module.called_warns == 2
    check_command(module, "sudo rpm -e python")

# Generated at 2022-06-20 21:20:10.622235
# Unit test for function main
def test_main():
    a = dict()
    a['_raw_params'] = ['ls', '-l']
    a['_uses_shell'] = False
    a['chdir'] = ''
    a['executable'] = None
    a['creates'] = ''
    a['removes'] = ''
    a['warn'] = False
    a['stdin'] = False
    a['stdin_add_newline'] = False
    a['strip_empty_ends'] = False

    # test idempotence of command

# Generated at 2022-06-20 21:20:20.831869
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self, commandline):
            self.commandline = commandline
            self.warns = []
        def warn(self, msg):
            self.warns.append(msg)


# Generated at 2022-06-20 21:20:29.947347
# Unit test for function main
def test_main():
    test_module = """
- name: Run command if /path/to/database does not exist (with 'cmd' parameter)
  ansible.builtin.command:
    cmd: /usr/bin/make_database.sh db_user db_name
    creates: /path/to/database
"""
    set_module_args(dict(
        executable='/bin/bash',
        chdir='/tmp',
        strip_empty_ends=False,
        stdin=None,
        stdin_add_newline=True,
        _raw_params=test_module,
        _uses_shell=False,
        argv=None,
        warn=False,
        creates="",
        removes=""
    ))

    command_mock = MagicMock(return_value=(0, '', ''))
    chdir_m

# Generated at 2022-06-20 21:20:35.557609
# Unit test for function main
def test_main():
    module=AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
            _uses_shell=dict(type='bool'),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(type='str'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            # The default for this really comes from the action plugin
            warn=dict(type='bool', default=False, removed_in_version='2.14'),
            stdin=dict(type='str', required=False),
            stdin_add_newline=dict(type='bool'),
            strip_empty_ends=dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    result

# Generated at 2022-06-20 21:20:42.967305
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(argument_spec={})
    module.warn = lambda x: check_command.warnings.append(x)
    check_command.warnings = []
    command = 'command'

    # check_command with arguments
    check_command(module, 'chmod')
    assert len(check_command.warnings) == 1
    assert "Consider using the file module with mode rather than running 'chmod'." in check_command.warnings[0]

    # check_command with commands
    check_command.warnings = []
    check_command(module, 'zip')
    assert len(check_command.warnings) == 1
    assert "Consider using the unarchive module rather than running 'zip'."

# Generated at 2022-06-20 21:20:50.414542
# Unit test for function main
def test_main():
    argument_spec = dict(
        _raw_params=dict(),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        # The default for this really comes from the action plugin
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )

# Generated at 2022-06-20 21:21:01.223192
# Unit test for function main

# Generated at 2022-06-20 21:21:12.548411
# Unit test for function main

# Generated at 2022-06-20 21:21:17.639492
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.check_command(test_module, ['echo', 'hello'])
    test_module.check_command(test_module, 'echo hello')

# END of UT for check_command()


# Generated at 2022-06-20 21:21:38.009241
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'cmd': {'type': 'str'}})
    commandline = "/usr/bin/git diff"
    check_command(module, commandline)

    commandline = ["/usr/bin/git", "diff"]
    check_command(module, commandline)

# Find the command to run the module in check mode.

# Generated at 2022-06-20 21:21:45.458911
# Unit test for function check_command
def test_check_command():
    check_command(None, 'chown')
    check_command(None, 'chmod')
    check_command(None, 'chgrp')
    check_command(None, 'ln')
    check_command(None, 'mkdir')
    check_command(None, 'rmdir')
    check_command(None, 'rm')
    check_command(None, 'touch')
    check_command(None, 'curl')
    check_command(None, 'wget')
    check_command(None, 'svn')
    check_command(None, 'service')
    check_command(None, 'mount')
    check_command(None, 'rpm')
    check_command(None, 'yum')
    check_command(None, 'apt-get')
    check_command(None, 'tar')

# Generated at 2022-06-20 21:21:54.931665
# Unit test for function main
def test_main():
  import sys
  import tempfile

# Generated at 2022-06-20 21:22:03.190276
# Unit test for function main

# Generated at 2022-06-20 21:22:10.926031
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='my_raw_params',
        _uses_shell=False,
        argv='my_argv',
        chdir='my_chdir',
        executable='my_executable',
        creates='my_creates',
        removes='my_removes',
        warn=True,
        stdin='my_stdin',
        stdin_add_newline=True,
        strip_empty_ends=True
    )
    module = AnsibleModule(argument_spec=args)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:20.662046
# Unit test for function main

# Generated at 2022-06-20 21:22:23.603007
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    result = check_command(module, ['/bin/echo', 'hello'])
    assert not result



# Generated at 2022-06-20 21:22:32.257142
# Unit test for function main
def test_main():
    # one of the cases (when there is no args and no argv)
    module = AnsibleModule(
        argument_spec = dict(
            _raw_params = dict(),
            argv = dict(type = 'list', elements = 'str'),
            executable = dict()
        ),
        supports_check_mode = True,
    )
    module.params['argv'] = None
    module.params['_raw_params'] = ''
    # NEEDS TO BE UPDATED: must fail since no args and no argv
    main()
    
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:44.725781
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/bin/false',
    )


# Generated at 2022-06-20 21:22:53.301798
# Unit test for function check_command
def test_check_command():
    import json
    # Create a module fixture
    module = AnsibleModule(argument_spec = dict(), supports_check_mode = True)
    # We need to record what was sent to the module function, so we can emulate it's calls with our test function
    # This class is used to create the wrapped function mentioned above
    class test_dict(dict):
        def __init__(self):
            super(test_dict, self).__init__()
            self['warnings'] = []
        def warn(self, warning):
            self['warnings'].append(warning)
    # Create our test function
    def check_command(self, commandline):
        # All outputs from the module function are saved in this dictionary and returned to the unit test function
        result = test_dict()
        # Call our unit test function in the manner that the module function would


# Generated at 2022-06-20 21:23:13.799688
# Unit test for function main
def test_main():
    set_module_args({
        "_raw_params": "This is a test string"
    })
    result = main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 21:23:23.585008
# Unit test for function check_command
def test_check_command():
    # FIXME: This is not a good unit test because it uses a real AnsibleModule
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown junk /bin')
    check_command(module, 'chmod 777 /bin')
    check_command(module, 'chgrp users /data')
    check_command(module, 'ln -s /old /new')
    check_command(module, 'mkdir /tmp/test')
    check_command(module, 'rmdir /tmp/notfound')
    check_command(module, 'rm /files/test.txt')
    check_command(module, 'touch /files/test.txt')
    check_command(module, 'curl http://www.example.com')

# Generated at 2022-06-20 21:23:29.137518
# Unit test for function main
def test_main():
    argument_spec = dict(
        _raw_params=dict(),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        warn=dict(type='bool', default=False),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    shell = module.params['_uses_shell']
    chdir

# Generated at 2022-06-20 21:23:40.797599
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    result = dict(
        rc=0,
        stdout='',
        stderr='',
        start='',
        end='',
        delta='',
        msg='',
        command=''
    )
    ansible_module = AnsibleModule(argument_spec=dict())
    ansible_module.warn = lambda x: result.update(dict(msg=str(x)))
    check_command(ansible_module, "sudo")
    assert "become" in result['msg']
    # reset the result message before next test
    result.update(msg='')
    check_command(ansible_module, "su")
    assert "become" in result['msg']
    # reset the result message before next test

# Generated at 2022-06-20 21:23:52.591450
# Unit test for function main
def test_main():
    string_io = StringIO()
    module = AnsibleModule(argument_spec=dict(_raw_params=dict(), _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'), chdir=dict(type='path'), executable=dict(), creates=dict(type='path'),
        removes=dict(type='path'), warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'), 
        stdin=dict(required=False), stdin_add_newline=dict(type='bool', default=True), 
        strip_empty_ends=dict(type='bool', default=True)),
        supports_check_mode=True)

    return_value = main()
    assert return_value == None


# Generated at 2022-06-20 21:24:02.239314
# Unit test for function check_command
def test_check_command():
    from collections import namedtuple
    from ansible.module_utils._text import to_bytes
    from ansible.compat.tests import unittest

    FakeModule = namedtuple('FakeModule', ['warn'])

    class TestCheckCommand(unittest.TestCase):
        def setUp(self):
            self.module = FakeModule(warn=self._warn)
            self.warnings = []

        def _warn(self, msg):
            self.warnings.append(msg)

        def test_check_command(self):
            check_command(self.module, ['chown', 'bob'])

# Generated at 2022-06-20 21:24:16.731818
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert check_command(module, ['/usr/bin/chown']) is None
    assert check_command(module, ['/usr/bin/chmod']) is None
    assert check_command(module, ['/usr/bin/chgrp']) is None
    assert check_command(module, ['/bin/ln']) is None
    assert check_command(module, ['/bin/mkdir']) is None
    assert check_command(module, ['/bin/rmdir']) is None
    assert check_command(module, ['/bin/rm']) is None
    assert check_command(module, ['/usr/bin/touch']) is None
    assert check_command(module, ['/usr/bin/curl']) is None

# Generated at 2022-06-20 21:24:32.722287
# Unit test for function main
def test_main():


    # set up
    module = AnsibleModule(argument_spec=dict())
    args = ['echo', 'hello']
    module.params['argv'] = args
    module.params['_raw_params'] = args
    module.params['_uses_shell'] = False
    module.params['creates'] = None
    module.params['removes'] = None
    module.params['warn'] = False
    module.params['strip_empty_ends'] = True
    module.params['stdin'] = None
    module.params['stdin_add_newline'] = True
    module.params['chdir'] = None
    module.params['executable'] = None


    # Test cases
    # Arguments
    # Case 1: execute a command
    module.check_mode = False
    main()

    # Case 2

# Generated at 2022-06-20 21:24:42.669787
# Unit test for function check_command
def test_check_command():
    import sys
    class ModuleMock(object):
        def warn(self, msg):
            print(msg)
    module = ModuleMock()
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}
    for cmd in arguments:
        check_command(module, cmd)
    sys.exit()


# Generated at 2022-06-20 21:24:54.108771
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 21:25:30.979591
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Test for basic execution
    args = {'argv': ['echo', 'hello']}

# Generated at 2022-06-20 21:25:37.590276
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/chown user1 /path/to/file')
    assert module.warnings[0] == "Consider using the file module with chown rather than running '/usr/bin/chown'."
    assert module.warnings[1] == "Consider using the file module with owner rather than running '/usr/bin/chown'."
    module = AnsibleModule(argument_spec={})
    check_command(module, '/usr/bin/chmod 600 /path/to/file')
    assert module.warnings[0] == "Consider using the file module with chmod rather than running '/usr/bin/chmod'."
    assert module.warnings[1] == "Consider using the file module with mode rather than running '/usr/bin/chmod'."
    module = Ans

# Generated at 2022-06-20 21:25:41.953860
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, ["command1", "arg1", "arg2"])
    assert module.warnings[0] == "Consider using the file module with state=absent rather than running 'command1'.  If you need to use 'command1' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

    check_command(module, ["awk", "arg1", "arg2"])
    assert module.warnings == []



# Generated at 2022-06-20 21:25:50.123039
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chown root:root /path/to/file')
    assert module.warnings == ['Consider using the file module with owner rather than running \'chown\'.  If you need to use \'chown\' because the file module is insufficient you can add \'warn: false\' to this command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get rid of this message.']



# Generated at 2022-06-20 21:25:59.031977
# Unit test for function main
def test_main():
    argv = ''' ansible.builtin.command:
        cmd: |
            date
            date -R
            date -u
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(cmd=dict(required=True)))
    r = main()
    assert r['rc'] == 0
    assert r['changed'] == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:09.637688
# Unit test for function main
def test_main():
    test_cases = [
        {
            "args": [
                "echo",
                "hello"
            ],
            "executable": None
        }
    ]

# Generated at 2022-06-20 21:26:25.378066
# Unit test for function check_command
def test_check_command():
    args = {'command': 'command'}

# Generated at 2022-06-20 21:26:33.239264
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        _raw_params=dict(type='str'),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        warn=dict(type='bool', removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    ))

# Generated at 2022-06-20 21:26:36.679469
# Unit test for function check_command
def test_check_command():
    check_command(dict(), ['banned_command'])



# Generated at 2022-06-20 21:26:38.777016
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:28:12.007115
# Unit test for function main
def test_main():
    args = {
    "_raw_params": "cat {{ myfile|quote }}",
    "argv": "",
    "chdir": "",
    "creates": "",
    "removes": "",
    "warn": "",
    "stdin": "",
    "stdin_add_newline": "",
    "strip_empty_ends": "",
    }
    args = dict((k,v) for (k, v) in args.items() if v)

    res = main(args)
    pprint(res)


# Generated at 2022-06-20 21:28:15.944535
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warn = lambda x: None

    command = FakeModule()
    check_command(command, 'sudo /bin/ls /')



# Generated at 2022-06-20 21:28:23.375737
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            args=dict(),
            executable=dict(type='path'),
            removes=dict(type='path'),
            creates=dict(type='path'),
            chdir=dict(type='path'),
            warn=dict(type='bool'),
            stdin=dict(type='str', no_log=True),
        )
    )
    check_command(module, "/bin/chmod")
    check_command(module, "/bin/mount")
    check_command(module, ["touch", "file"])
    check_command(module, ["/bin/mount", "file", "dir"])
    check_command(module, "kill")
    check_command(module, "pmrun /bin/date")

# Generated at 2022-06-20 21:28:24.842380
# Unit test for function check_command
def test_check_command():
  assert check_command('echo') == 0



# Generated at 2022-06-20 21:28:35.966262
# Unit test for function check_command
def test_check_command():
    commandline = 'curl http://example.com/path'
    m = AnsibleModule(argument_spec={})
    m.warn = lambda msg: msg
    res = check_command(m, commandline)
    assert "Consider using the {mod} module with {subcmd} rather than running '-warn: disable_command_warnings'" in res
    assert "If you need to use '-warn: disable_command_warnings' because the {mod} module is insufficient" in res


# Generated at 2022-06-20 21:28:44.482246
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(check_command=[{'command': ['command']}])
    module.check_command(['command'])
    module.check_command("command")
    module.check_command("sudo command")
    module.check_command("chmod command")
    module.check_command("apt-get command")
    module.check_command("touch command")
    module.check_command("mkdir command")
    module.warn("")

# import module snippets
from ansible.module_utils.basic import *


# Generated at 2022-06-20 21:28:53.648775
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Fake test data
    class FakeAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
    module = FakeAnsibleModule()

    # Fake r value
    r = {}
    try:
        main()
        assert False
    except SystemExit as e:
        r = e.code

# Generated at 2022-06-20 21:28:57.821937
# Unit test for function main
def test_main():
    argv = ["command.yml","/usr/sbin/apachectl","-D","FOREGROUND"]
    sys.argv = argv
    main()

if __name__ == '__main__':
    import sys
    test_main()
    sys.exit(main())

# Generated at 2022-06-20 21:29:04.711943
# Unit test for function check_command
def test_check_command():
    module = get_module([])
    check_command(module, '/usr/bin/curl')
    assert 'Consider using the get_url or uri module rather than running' in module.warnings[-1]
    check_command(module, 'yum')
    assert 'Consider using the yum module rather than running' in module.warnings[-1]
    check_command(module, ['/bin/chown', 'harry', 'filename'])
    assert 'Consider using the file module with owner rather than running' in module.warnings[-1]
    check_command(module, '/bin/rpm')
    assert 'Consider using the yum, dnf or zypper module rather than running' in module.warnings[-1]


# Generated at 2022-06-20 21:29:09.222401
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    command = "echo hello"
    check_command(module, command)
    out = module._result['warnings']
