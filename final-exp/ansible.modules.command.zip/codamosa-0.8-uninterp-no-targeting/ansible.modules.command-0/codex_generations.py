

# Generated at 2022-06-20 21:19:48.237075
# Unit test for function check_command
def test_check_command():
    from .warn import NoArgsCls
    check_command(NoArgsCls(), ['chown'])
    check_command(NoArgsCls(), ['chmod'])
    check_command(NoArgsCls(), ['chgrp'])
    check_command(NoArgsCls(), ['ln'])
    check_command(NoArgsCls(), ['mkdir'])
    check_command(NoArgsCls(), ['rmdir'])
    check_command(NoArgsCls(), ['rm'])
    check_command(NoArgsCls(), ['touch'])
    check_command(NoArgsCls(), ['curl'])
    check_command(NoArgsCls(), ['wget'])
    check_command(NoArgsCls(), ['svn'])
    check_command(NoArgsCls(), ['service'])

# Generated at 2022-06-20 21:19:55.982018
# Unit test for function check_command
def test_check_command():
    # Initialize some classes
    AnsibleModule = collections.namedtuple('AnsibleModule', ['warn'])
    module = AnsibleModule(warn=ansible_module_warn)
    commandline = 'wget'
    check_command(module, commandline)
    assert(module.warn_count == 1)


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:20:04.797658
# Unit test for function main

# Generated at 2022-06-20 21:20:12.691707
# Unit test for function main

# Generated at 2022-06-20 21:20:22.401556
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='foo',
        _uses_shell=True,
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )
    main(args=args)
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:31.006286
# Unit test for function main
def test_main():
    print("Testing main")
    
    # Test 1
    # Test that the module can handle a single command
    print("Test 1")

# Generated at 2022-06-20 21:20:43.653782
# Unit test for function main
def test_main():
    import json
    import os
    import sys
    import subprocess
    import tempfile
    from ansible.module_utils import basic
    # Skip test for python 2.6
    if sys.version_info[0] == 2 and sys.version_info[1] < 7:
        return
    # Skip test for windows, because we execute command on linux container
    if sys.platform == 'win32':
        return
    # Need to pass connection info to ansible module
    ansible_requirements = os.getcwd() + '/../../../test/ansible_module_requirements.txt'
    # Need to pass argument_spec, check_in and params to ansible module

# Generated at 2022-06-20 21:20:49.016723
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    import mock
    import io

    import ansible.modules.system.command as command
    # If we would use 'command' to import the module, the unit test won't work since it will find the wrong module

    mock_module = mock.Mock()
    mock_module.warn.side_effect = lambda x: print(x)

    command.check_command(mock_module, 'chown')
    command.check_command(mock_module, 'svn')
    command.check_command(mock_module, 'touch')
    command.check_command(mock_module, 'sudo')



# Generated at 2022-06-20 21:20:55.234193
# Unit test for function main
def test_main():
    args = {
        '_raw_params': 'ls /tmp/',
        '_uses_shell': False,
        'argv': None,
        'chdir': None,
        'creates': None,
        'executable': None,
        'removes': None,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True,
        'warn': False,
        }
    rc1 = main()
    assert rc1 == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:55.845472
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-20 21:21:18.968334
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chmod')
    check_command(module, 'chmod foo')
    check_command(module, '/bin/chmod')
    check_command(module, ['/bin/chmod', 'foo'])
    check_command(module, ['chmod', 'foo'])
    check_command(module, 'rm')
    check_command(module, ['rm', 'foo'])
    check_command(module, 'ln')
    check_command(module, 'ln foo')
    check_command(module, 'wget')
    check_command(module, ['wget', 'foo'])
    check_command(module, ['curl', 'foo'])
    check_command(module, ['svn', 'foo'])
    check_

# Generated at 2022-06-20 21:21:20.239299
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:20.796107
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-20 21:21:32.767176
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 21:21:41.898890
# Unit test for function main
def test_main():
    monkeypatch.setattr('ansible.module_utils.basic.AnsibleModule.run_command', lambda *args, **kwargs: (0, '', ''))
    assert main({}) == {
        'changed': True,
        'stdout': '',
        'stderr': '',
        'rc': 0,
        'cmd': None,
        'start': None,
        'end': None,
        'delta': None,
        'msg': ''
    }

# Generated at 2022-06-20 21:21:46.098486
# Unit test for function check_command
def test_check_command():
    ''' ansible.module_utils.common.command unit test'''
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(mod, 'wget -O local/path')
    check_command(mod, 'ln -s /tmp/src /tmp/dst')
    check_command(mod, 'mount /dev/sda /mnt')
    check_command(mod, 'zypper -n in www')


# ===========================================
# main

# Generated at 2022-06-20 21:21:48.638803
# Unit test for function main
def test_main():
    ret = main()
    assert ret == None

# import module snippets
from ansible.module_utils.basic import *
main()

# Generated at 2022-06-20 21:21:55.732694
# Unit test for function main

# Generated at 2022-06-20 21:22:01.946707
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo hello',
        strip_empty_ends=True
    )
    module = AnsibleModule(argument_spec={})
    module.params = args
    r_value = dict(
        changed=False,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg=''
    )
    assert r_value == main(module)


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:02.882361
# Unit test for function check_command
def test_check_command():
    module = None
    assert check_command(module, 'service')



# Generated at 2022-06-20 21:22:21.177156
# Unit test for function main

# Generated at 2022-06-20 21:22:32.380164
# Unit test for function check_command
def test_check_command():
    # Dummy module for testing
    module = AnsibleModule(
        argument_spec=dict(
            warn=dict(default=True, type='bool'),
            executable=dict(),
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            _uses_delegate=dict(type='bool', default=False),
            _uses_changed_when=dict(type='bool', default=False),
            chdir=dict(),
            creates=dict(),
            removes=dict()
        )
    )

    commandlines = ('/bin/sh', ['sh', 'arg1', 'arg2'])
    for commandline in commandlines:
        check_command(module, commandline)



# Generated at 2022-06-20 21:22:44.905391
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.collections import Set

    # Test case #1:
    #   - args:
    #       - command:
    #           - cat
    #           - /etc/motd
    #   - register: mymotd


# Generated at 2022-06-20 21:22:50.657699
# Unit test for function main
def test_main():
    test_input = {"argv":"hehe","rc":0,"msg":"non-zero return code","stdout":"hehe\n"}
    test_output = {"argv":"hehe","rc":0,"msg":"non-zero return code","stdout":"hehe\n","stderr":"","changed":True,"start":None,"end":None,"delta":None}
    assert main(test_input) == test_output

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:59.971385
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())

    # Test normal command
    check_command(module, "echo hello")

    # Test command that outputs warning
    check_command(module, "chown user1 /path/to/file")

    # Test command against multiple warning types
    check_command(module, "apt-get install openssh-server")

    # Test command that outputs warning against multiple modules
    check_command(module, "sed -i 's/hello/world/g' /path/to/file")

    # Test command against multiple warning types including become
    check_command(module, "sudo apt-get install openssh-server")



# Generated at 2022-06-20 21:23:12.137953
# Unit test for function check_command
def test_check_command():
    commandline = 'wget something'
    args = {'warn': True, 'command_warnings': True}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    class Warn:
        def __init__(self, module):
            self.data = []

        def __call__(self, msg):
            self.data.append(msg)
            return

        def __nonzero__(self):
            return False

    def exit_json(*args, **kwargs):
        return

    def fail_json(*args, **kwargs):
        raise Exception('fail_json called')

    module.exit_json = exit_json
    module.fail_json = fail_json
    module.params = args

    module.params = args
    module.warn = Warn(module)

    check_command

# Generated at 2022-06-20 21:23:22.609775
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule({'command':['command_name'], 'warn':True})
    check_command(m, 'command_name')
    m = AnsibleModule({'command':['command_name']})
    check_command(m, 'command_name')
    m = AnsibleModule({'command':['command_name'], 'warn':True})
    check_command(m, ['command_name'])
    m = AnsibleModule({'command':['command_name']})
    check_command(m, ['command_name'])
    m = AnsibleModule({'command':'command_name', 'warn':True})
    check_command(m, 'command_name')
    m = AnsibleModule({'command':'command_name'})
    check_command(m, 'command_name')

# Generated at 2022-06-20 21:23:28.560056
# Unit test for function main
def test_main():
    test1 = {u"_raw_params": "", "argv": {"type": "list", "elements": "str"},
             "creates": {"type": "path"}, "removes": {"type": "path"}, "strip_empty_ends": {"type": "bool", "default": True},
             "chdir": {"type": "path"}, "executable": {},
             "_uses_shell": {"type": "bool", "default": False}, "warn": {"type": "bool", "default": False, "removed_in_version": "2.14",
                                                                          "removed_from_collection": "ansible.builtin"}}

# Generated at 2022-06-20 21:23:40.278297
# Unit test for function main
def test_main():
    """This method is for testing main"""

# Generated at 2022-06-20 21:23:52.085762
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    args = dict(
        _raw_params='uname',
        _uses_shell=False,
        argv=None,
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )

    mymodule = basic.AnsibleModule(argument_spec={})
    mymodule.params = args
    mymodule.check_mode = False
    mymodule.warn = lambda x: print(x)
    mymodule.fail_json = lambda x: print(x)
    mymodule.exit_json = lambda x: print(x)

# Generated at 2022-06-20 21:24:17.398392
# Unit test for function main

# Generated at 2022-06-20 21:24:33.441537
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='echo 1',
        chdir='/',
    )
    module = AnsibleModule(
        argument_spec = dict(
            _raw_params=dict(required=True),
            chdir=dict(required=True),
            executable=None,
            creates=None,
            removes=None,
            warn=dict(type='bool', default=True),
            stdin=None,
            stdin_add_newline=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

    set_module_args(args)
    m = module
    result = main()

    assert result['changed'] is True
    assert result['rc'] == 0

    # Check stderr
    assert result['stderr'] == ''

   

# Generated at 2022-06-20 21:24:45.375353
# Unit test for function check_command
def test_check_command():

    # WARNING: the to_native('\xaa\xaa\xaa\xaa') below
    # is required to ensure that the command is not
    # interpreted as a unicode string.  This exact change
    # is required because otherwise it fails on Python 3.
    # According to the python 3 standard, the
    # to_unicode will not do anything if the command
    # is already a unicode string.
    # This is the appropriate behavior for the situation
    # so do not change the to_bytes('\xaa\xaa\xaa\xaa')
    # to a non-ascii value.
    args = {'warnings': []}
    commandline = 'chown'

# Generated at 2022-06-20 21:24:48.106706
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert check_command(self, module) == None  # The function doesn't return anything



# Generated at 2022-06-20 21:24:57.962083
# Unit test for function main

# Generated at 2022-06-20 21:25:05.436980
# Unit test for function main

# Generated at 2022-06-20 21:25:16.225050
# Unit test for function main
def test_main():
    import subprocess
    import sys
    import json
    import os

    test_id = 'Test'
    cmd = sys.executable + ' ' + __file__ + ' --id=' + test_id
    out = subprocess.check_output(cmd, shell=True)
    result = json.loads(out.decode('utf-8'))

    print(result)

    assert result['changed']

    assert result['rc'] == 0

    stdout = result['stdout']
    stderr = result['stderr']

    assert stdout == test_id

    assert stderr == ''


# Generated at 2022-06-20 21:25:25.846962
# Unit test for function main
def test_main():

    if not os.path.exists('/tmp/test_hosts'):
        os.mkdir('/tmp/test_hosts')

    os.system('touch /tmp/test_hosts/hosts')

    class args:
        _raw_params = ''
        _uses_shell = ''
        argv = ''
        chdir = ''
        executable = ''
        creates = '/tmp/test_hosts/hosts'
        removes = ''
        warn = ''
        stdin = ''
        stdin_add_newline = ''
        strip_empty_ends = ''

    module = AnsibleModule(argument_spec={})
    module.params = args
    main()

    os.system('rm -rf /tmp/test_hosts')

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:25:35.135149
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common as common_utils
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.connection import ConnectionError

    # get all the ansible.builtin.* modules
    module_loader, paths = basic._load_ansible_module_sources()

    # create a list of all the modules
    module_list = ['async_wrapper', 'command', 'copy', 'fetch', 'file', 'meta', 'raw', 'script', 'shell', 'win_command']
    # create a list of all the modules
    module_list += ['async_wrapper', 'command', 'copy', 'fetch', 'file', 'meta', 'raw', 'script', 'shell', 'win_command']
    #

# Generated at 2022-06-20 21:25:41.876907
# Unit test for function main
def test_main():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('ansible.builtin.command.shlex', wraps=shlex) as mock_shlex:
        mock_module = MagicMock()
        test_command = "echo hello world"
        test_argv = ["echo", "hello", "world"]
        test_shlex = shlex.split(test_command)

        test_mod_params = dict(
            _raw_params=test_command,
            _uses_shell=False,
            argv=test_argv,
            chdir=False,
            executable=None,
            creates=None,
            removes=None,
            warn=True,
            stdin=None,
            stdin_add_newline=True,
        )

# Generated at 2022-06-20 21:26:25.664391
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    results = check_command(m, 'foo')
    assert results is None, results

# ---- AnsibleModule support functions ----



# Generated at 2022-06-20 21:26:33.295249
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='path/to/command',
        _uses_shell='False',
        argv='path/to/command',
        chdir='path/to/directory',
        executable='False',
        creates='path/to/file',
        removes='path/to/file',
        warn='True',
        stdin='text for stdin',
        stdin_add_newline='True',
        strip_empty_ends='True',
        msg='string',
        start='timestamp',
        end='timestamp',
        delta='timestamp',
        stdout='string',
        stderr='string',
        rc='int',
        cmd='path/to/command',
    )
    module = namespace_load(args)
    result = main()

# import module snippets

# Generated at 2022-06-20 21:26:44.953404
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils import stubs
    from ansible.module_utils.parsing.convert_bool import boolean
    import ansible.module_utils.ansible_release
    import sys
    import imp
    argv = ['/usr/bin/ansible-test']
    if len(sys.argv) > 1:
        argv = sys.argv
    command_line = argv[1]
    sys.argv = argv

    # load the test_utils.py module
    testutils_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_utils.py')
    testutils = imp.load_

# Generated at 2022-06-20 21:26:55.766149
# Unit test for function main
def test_main():
    os.system('rm -f /tmp/ansible-test-module-ansible.builtin.command.stdout')
    os.system('rm -f /tmp/ansible-test-module-ansible.builtin.command.stderr')
    os.system('rm -f /tmp/ansible-test-module-ansible.builtin.command.rc')
    os.system('rm -f /tmp/ansible-test-module-ansible.builtin.command.stdin_add_newline')
    os.system('rm -f /tmp/ansible-test-module-ansible.builtin.command.strip_empty_ends')

# Generated at 2022-06-20 21:27:02.611681
# Unit test for function main

# Generated at 2022-06-20 21:27:15.898308
# Unit test for function check_command
def test_check_command():
    _module = AnsibleModule(argument_spec = dict())

# Generated at 2022-06-20 21:27:21.397394
# Unit test for function check_command
def test_check_command():
    module=AnsibleModule(argument_spec=dict())
    check_command(module, 'curl')
    check_command(module, 'mount')
    check_command(module, ['touch', '/tmp'])
    check_command(module, ['chmod', '-R', '777'])



# Generated at 2022-06-20 21:27:35.361411
# Unit test for function main
def test_main():

    # Set up for testing 'command' module
    test_dir = tempfile.TemporaryDirectory()
    test_dir_path = test_dir.name
    test_file_name = "test_file.txt"
    test_file_path = os.path.join(test_dir_path, test_file_name)

    args = "echo \"Test String\" > " + test_file_path
    test_command = ['/bin/sh', '-c', args]

    # Create a test file
    r = {'rc': 0, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None,
         'msg': ''}
    r['rc'], r['stdout'], r['stderr'] = module.run

# Generated at 2022-06-20 21:27:43.983790
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.warnings import AnsibleParserWarning

    # We need access to module object inside the function under test
    # and we cannot use Mock here because it does not allow to override
    # the __module__ attribute. So here's a little hack to allow us to
    # override the warn() method and thus test the function.
    class Module(object):
        def __init__(self):
            self.warnings = []

        def warn(self, msg, *args, **kwargs):
            self.warnings.append(msg % args)

    m = Module()
    check_command(m, 'service foo start')
    check_command(m, 'service foo start bar')
    check_command(m, 'chown')
    check_command(m, 'wget')

# Generated at 2022-06-20 21:27:55.492417
# Unit test for function check_command
def test_check_command():
    class FakeModule:
        def warn(self, msg):
            self.msg = msg
    cmds = ['touch', 'ln', 'mkdir', 'rmdir', 'rm', 'chown', 'chmod', 'chgrp']
    modules = ['file', 'get_url', 'uri', 'subversion', 'service', 'mount',
               'yum', 'dnf', 'zypper', 'apt', 'unarchive', 'replace',
               'lineinfile', 'template']
    become = ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']

    for cmd in cmds:
        fake = FakeModule()
        check_command(fake, cmd)
        assert cmd in fake.msg

    for mod in modules:
        fake = FakeModule()


# Generated at 2022-06-20 21:29:25.608525
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule([])
    # Check arguments commands
    check_command(module, ['chown', 'root', 'ansible'])
    check_command(module, ['chmod', '700', 'ansible'])
    check_command(module, ['chgrp', 'root', 'ansible'])
    check_command(module, ['ln', '-sf', 'root', 'ansible'])
    check_command(module, ['mkdir', '-p', 'ansible'])
    check_command(module, ['rmdir', 'ansible'])
    check_command(module, ['rm', '-rf', 'ansible'])
    check_command(module, ['touch', 'testfile'])
    # Check commands