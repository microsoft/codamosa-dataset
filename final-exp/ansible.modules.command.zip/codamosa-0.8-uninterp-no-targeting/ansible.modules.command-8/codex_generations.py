

# Generated at 2022-06-20 21:19:47.157382
# Unit test for function main
def test_main():
    def test_run_command(args, **kwargs):
        if args[0] == 'fail':
            return (1, 'stdout', 'stderr')
        return (0, 'stdout', 'stderr')

    def test_exists(arg):
        if arg == 'exists':
            return True
        return False

    class Run_Command:
        pass

    M = Run_Command()
    M.run_command = test_run_command

    module = type('', (object,), {
        'check_mode': False,
        'exit_json': lambda x: x,
        'fail_json': lambda x: x,
        'warn': lambda x: x
    })()
    module.run_command = test_run_command
    module.exists = test_exists


# Generated at 2022-06-20 21:20:01.842605
# Unit test for function main
def test_main():
    import json
    import subprocess

    with open('/tmp/result.json', 'r') as f:
        module_results = json.load(f)
    f.close()


# Generated at 2022-06-20 21:20:10.438597
# Unit test for function main

# Generated at 2022-06-20 21:20:20.660838
# Unit test for function check_command
def test_check_command():
    #redirect_stdout_stderr()
    module = AnsibleModule(argument_spec={'warn': {'type': 'bool', 'default': True},
                                          'command': {'type': 'str'},
                                          'other_arg': {'type': 'str'}})
    check_command(module, '/usr/bin/yum')
    assert module.warnings[0] == "Consider using the yum module rather than running 'yum'.  If you need to use 'yum' because the yum module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

# Generated at 2022-06-20 21:20:29.821609
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(required=True),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    result = main()
    module.exit_json(changed=True, **result)



# Generated at 2022-06-20 21:20:42.577932
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

# Generated at 2022-06-20 21:20:54.303901
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(argument_spec={})
    test_module.warn = lambda x: x
    check_command(test_module, 'curl')
    check_command(test_module, 'ln')
    check_command(test_module, 'touch')
    check_command(test_module, 'svn')
    check_command(test_module, 'service')
    check_command(test_module, 'rpm')
    check_command(test_module, 'yum')
    check_command(test_module, 'apt-get')
    check_command(test_module, 'tar')
    check_command(test_module, 'unzip')
    check_command(test_module, 'sed')
    check_command(test_module, 'dnf')

# Generated at 2022-06-20 21:20:56.763741
# Unit test for function check_command
def test_check_command():
    module = ansible.parsing.dataloader.DataLoader()
    commandline=['echo', 'hello']
    check_command(module, commandline)



# Generated at 2022-06-20 21:21:03.698875
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    import json
    import os

    def fake_run_command(*args, **kwargs):
        return 0, '', ''

    def fake_warn(msg):
        warnings.append(msg)

    current_directory = os.path.dirname(os.path.realpath(__file__))
    test_directory = os.path.join(current_directory, 'test_command_module')

    with open(os.path.join(test_directory, 'arguments.json')) as arg_file:
        arg_data = json.load(arg_file)


# Generated at 2022-06-20 21:21:07.482511
# Unit test for function main
def test_main():
    module = AnsibleModule({})
    result = main()
    module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:22.228558
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    check_command(module, ['touch'])
    check_command(module, ['yum'])
    check_command(module, ['zypper'])
    check_command(module, ['chown'])
    # Should not have set any warnings
    assert not module._warnings



# Generated at 2022-06-20 21:21:25.807358
# Unit test for function main
def test_main():
    # Test 1:
    # A non-zero return code
    returncode = 1
    # The command should fail
    check = False
    test1 = main(returncode, check)
    assert test1 == returncode


# Generated at 2022-06-20 21:21:28.163736
# Unit test for function main
def test_main():
    print("STUB: main")

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:38.353783
# Unit test for function main
def test_main():
    test_dict = dict(
        _raw_params='uptime',
        _uses_shell=False,
        argv=[],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        changed='NO',
        rc=0,
        start=None,
        end=None,
        delta=None,
        msg='',
        cmd='uptime',
        stdout=' 10:41:57 up 19 days, 22:09,  1 user,  load average: 0.00, 0.01, 0.05\n',
        stderr=''
    )

# Generated at 2022-06-20 21:21:45.743770
# Unit test for function check_command
def test_check_command():
    args = {'command': ['yum', 'update'], 'executable': None, 'warn': True, '_ansible_check_mode': True}

# Generated at 2022-06-20 21:21:49.435778
# Unit test for function check_command
def test_check_command():
    my_module = AnsibleModule(argument_spec={'command': {'type': 'str'}})
    my_module.check_command(my_module.params['command'])
    assert my_module.fail_json.called is False



# Generated at 2022-06-20 21:21:50.562080
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-20 21:21:51.553956
# Unit test for function check_command
def test_check_command():
    assert True


# Generated at 2022-06-20 21:22:01.475627
# Unit test for function main

# Generated at 2022-06-20 21:22:12.701779
# Unit test for function main
def test_main():
    # Clean out the module namespace so we can import it again
    new_globals = {}
    #in main: module.exit_json(**r)
    #main() creates module.run_command but does not use it
    #in main: module.warn("Consider using 'become', 'become_method', and 'become_user' rather than running %s" % (command,))
    #in main: r['stdout'] = to_text(r['stdout']).rstrip("\r\n")
    #in main: module.exit_json(**r)
    #in main: r['delta'] = to_text(r['end'] - r['start'])
    #in main: r['end'] = to_text(r['end'])
    #in main: r['start'] = to_text(

# Generated at 2022-06-20 21:22:40.831302
# Unit test for function main
def test_main():
    from ansible import context
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    loader = DataLoader() # Takes care of finding and reading yaml, json and ini files
    passwords = dict(vault_pass='secret')

    # Instantiate our ResultCallback for handling results as they come in
    results_callback = ResultCallback()

    # create inventory, use path to host config file as source or hosts in a comma separated

# Generated at 2022-06-20 21:22:51.133473
# Unit test for function check_command
def test_check_command():
    import warnings
    warnings.warn = lambda msg, cat, stacklevel=1: cat.append(to_text(msg))
    module_args = dict()
    module = AnsibleModule(argument_spec={}, **module_args)

# Generated at 2022-06-20 21:22:56.429696
# Unit test for function main

# Generated at 2022-06-20 21:22:58.875432
# Unit test for function check_command
def test_check_command():
    assert 1 == 1
    #assert 1 == 0


# =================


# Generated at 2022-06-20 21:23:00.238864
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


main()

# Generated at 2022-06-20 21:23:12.418384
# Unit test for function check_command
def test_check_command():
    assert check_command('command','ansible.builtin.chmod') == None
    assert check_command('command','ansible.builtin.chown') == None
    assert check_command('command','ansible.builtin.chgrp') == None
    assert check_command('command','ansible.builtin.ln') == None
    assert check_command('command','ansible.builtin.mkdir') == None
    assert check_command('command','ansible.builtin.rmdir') == None
    assert check_command('command','ansible.builtin.rm') == None
    assert check_command('command','ansible.builtin.touch') == None
    assert check_command('command','ansible.builtin.curl') == None
    assert check_command('command','ansible.builtin.wget') == None


# Generated at 2022-06-20 21:23:22.812905
# Unit test for function main
def test_main():
    args = ["ansible-doc", "shell"]
    args1 = ["ansible-doc"]
    args_pass = ' '.join(["ansible-doc", "shell"])
    args_fail = "ansible-doc shell"
    error_msg = ("only command or argv can be given, not both")
    chdir = "tmp/ansible/test"
    executable = "ansible-doc"
    creates = "tmp/ansible/test/2.8.0/"
    removes = "tmp/ansible/test/2.8.0/"


# Generated at 2022-06-20 21:23:28.693322
# Unit test for function main
def test_main():
    r = {
        'changed': False,
        'msg': 'non-zero return code',
        'rc': 1,
        'stderr': '',
        'stdout': ''
    }


# Generated at 2022-06-20 21:23:40.380435
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': dict})
    check_command(module, "chown foo")
    check_command(module, "chgrp foo")
    check_command(module, "chmod foo")
    check_command(module, "ln foo")
    check_command(module, "mkdir foo")
    check_command(module, "rmdir foo")
    check_command(module, "rm foo")
    check_command(module, "touch foo")
    check_command(module, "curl foo")
    check_command(module, "wget foo")
    check_command(module, "svn foo")
    check_command(module, "service foo")
    check_command(module, "mount foo")
    check_command(module, "rpm foo")
    check_command

# Generated at 2022-06-20 21:23:52.181657
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert not module.warns

# Generated at 2022-06-20 21:24:42.337814
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(command=dict(required=True, type='str'),),
                           supports_check_mode=True)
    check_command(module, ["/usr/bin/yum", "install", "-y", "epel-release"])
    check_command(module, "mv /etc/hosts /tmp/hosts")
    check_command(module, "/usr/bin/wget -O /tmp/wget.log https://github.com")



# Generated at 2022-06-20 21:24:48.108485
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert check_command(module, 'wget -O index.html https://www.ansible.com/') == None
    assert check_command(module, 'tar zxf /tmp/test.tar.gz -C /opt/test') == None
# End of unit test for function check_command



# Generated at 2022-06-20 21:24:57.962646
# Unit test for function check_command
def test_check_command():
    # Ignore pylint warnings for badly designed unit test method
    # pylint: disable=too-many-branches,too-many-statements
    module = AnsibleModule(
        argument_spec=dict(
            cmd=dict(type='list', required=True),
            warn=dict(type='bool', default=False),
        )
    )
    module.params['warn'] = True
    # Warnings not expected
    command = '/bin/cat'
    check_command(module, command)
    # Check warning are handled
    command = '/bin/chown'
    check_command(module, command)
    command = '/bin/chmod'
    check_command(module, command)
    command = '/bin/chgrp'
    check_command(module, command)
    command = '/bin/ln'


# Generated at 2022-06-20 21:25:05.476820
# Unit test for function main

# Generated at 2022-06-20 21:25:11.728175
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.path import unfrackpath

    dummy_command = "whatever"
    dummy_args = [{}]
    for dummy_path in ["/bin/false", "/usr/bin/false"]:
        dummy_param_args = {"command": dummy_command, "args": dummy_args}
        dummy_module = AnsibleModule(argument_spec=dummy_args, supports_check_mode=True)
        check_command(dummy_module, unfrackpath(dummy_path, follow=False))

    dummy_command = ["/bin/false", "whatever"]
    dummy_param_args = {"command": dummy_command, "warn": False}
    dummy_args = [dummy_param_args]

# Generated at 2022-06-20 21:25:24.430326
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
            _uses_shell=dict(type='bool'),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(type='str'),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool'),
            strip_empty_ends=dict(type='bool'),
        ),
        supports_check_mode=True,
    )

    if platform.system() == 'Windows':
        test_argv = ["echo", "hello"]

# Generated at 2022-06-20 21:25:32.210148
# Unit test for function main
def test_main():
    data = dict(
        _raw_params='date',
        _uses_shell=False,
        argv=['date'],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
    )

    module = AnsibleModule(argument_spec=data)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:25:45.147886
# Unit test for function main
def test_main():
    test_case = dict()
    test_case['module'] = dict()
    test_case['module']['argument_spec'] = dict()
    test_case['module']['argument_spec']['_raw_params'] = dict()
    test_case['module']['argument_spec']['_raw_params']['choices'] = list()
    test_case['module']['argument_spec']['_raw_params']['choices'].append('command')
    test_case['module']['argument_spec']['_raw_params']['required'] = True
    test_case['module']['argument_spec']['_raw_params']['default'] = None
    test_case['module']['argument_spec']['_uses_shell'] = dict()
   

# Generated at 2022-06-20 21:25:56.147630
# Unit test for function check_command
def test_check_command():
    import sys
    import unittest
    import ansible.module_utils.basic as basic_module
    module = basic_module.AnsibleModule(argument_spec={})
    def warn_function(msg):
        check_command.warnings.append(msg)
    setattr(module, 'warn', warn_function)
    setattr(check_command, 'warnings', [])
    check_command(module, 'ls -al')
    assert 'Consider using the file module with state=directory rather than running' in check_command.warnings[0]
    assert 'Consider using the get_url or uri module rather than running' in check_command.warnings[1]
    check_command.warnings = []

# Generated at 2022-06-20 21:26:02.815235
# Unit test for function main
def test_main():
    # Assigning the actual return values to variables
    m_args = to_text('')
    m_check_mode = False
    m_chdir = to_text('')
    m_executable = to_text('')

# Generated at 2022-06-20 21:28:11.257308
# Unit test for function main
def test_main():
    args = dict()
    args["_raw_params"] = "touch"
    args["argv"] = "touch"
    args["creates"] = "/tmp/test"
    args["chdir"] = "/tmp"
    module = AnsibleModule(argument_spec=args, supports_check_mode=True)
    r = main()
    assert r['changed'] == True
    assert r['rc'] == 0
    assert r['start'] != r['end']

# Generated at 2022-06-20 21:28:20.993184
# Unit test for function check_command
def test_check_command():
    assert check_command(AnsibleModule(argument_spec={}), ['chown', 'root:root', 'test']) is None
    assert check_command(AnsibleModule(argument_spec={}), ['chmod', 'go-w', 'foobar']) is None
    assert check_command(AnsibleModule(argument_spec={}), ['chgrp', 'root', 'foobar']) is None
    assert check_command(AnsibleModule(argument_spec={}), ['ln', '-s', 'test', 'foo']) is None
    assert check_command(AnsibleModule(argument_spec={}), ['mkdir', 'test']) is None
    assert check_command(AnsibleModule(argument_spec={}), ['rmdir', 'test']) is None

# Generated at 2022-06-20 21:28:22.323281
# Unit test for function check_command
def test_check_command():
    assert check_command(module=None, commandline='echo') == None
# END


# Generated at 2022-06-20 21:28:37.508190
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "/usr/bin/chown adele")
    check_command(module, "/usr/bin/chmod 0755")
    check_command(module, "/usr/bin/chgrp users")
    check_command(module, "ln -s something")
    check_command(module, "mkdir -p")
    check_command(module, "rmdir somedir")
    check_command(module, "rm -rf somedir")
    check_command(module, "touch")
    check_command(module, "curl http://example.com/")
    check_command(module, "wget http://example.com/")
    check_command(module, "svn co http://example.com/trunk")
    check_command

# Generated at 2022-06-20 21:28:47.256540
# Unit test for function main
def test_main():
    cmd = ['echo', 'hello']
    module = AnsibleModule(argument_spec={'_raw_params': dict(type='str', default=''),
                                          '_uses_shell': dict(type='bool', default=False)})
    args = module.params['_raw_params']
    shell = module.params['_uses_shell']

    if not shell and args:
        args = shlex.split(args)

    args = args or cmd
    # All args must be strings
    if is_iterable(args, include_strings=False):
        args = [to_native(arg, errors='surrogate_or_strict', nonstring='simplerepr') for arg in args]

    # actually executes command (or not ...)
    if not module.check_mode:
        r = {}

# Generated at 2022-06-20 21:28:55.596733
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', default='ls')
        )
    )
    main()

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.basic import get_exception
from ansible.module_utils.common.collections import is_iterable
from ansible.module_utils._text import to_bytes, to_native, to_text
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:29:02.620001
# Unit test for function check_command
def test_check_command():
    command = '/usr/bin/curl'
    mod = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    check_command(mod, command)
    assert mod.warnings == [
        "Consider using the get_url or uri module rather than running 'curl'.  If you need to use 'curl' because the "
        "get_url or uri module is insufficient you can add 'warn: false' to this command task or set "
        "'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    ]


# Generated at 2022-06-20 21:29:07.167020
# Unit test for function check_command
def test_check_command():
    class WarnModule:
        def warn(self, message):
            return False
    module = WarnModule()
    commandline = ['touch', '/tmp/foo']
    check_command(module, commandline)
    commandline = ['chmod', '+111', '/tmp/foo']
    check_command(module, commandline)
    commandline = ['chown', 'nobody', '/tmp/foo']
    check_command(module, commandline)
    commandline = ['chgrp', 'nogroup', '/tmp/foo']
    check_command(module, commandline)
    commandline = ['ln', '/tmp/foo']
    check_command(module, commandline)
    commandline = ['mkdir', '/tmp/foo']
    check_command(module, commandline)

# Generated at 2022-06-20 21:29:09.628275
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:29:15.387668
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as exec_info:
        main()
    assert exec_info.value.args[0]['changed']

if __name__ == '__main__':
    main()