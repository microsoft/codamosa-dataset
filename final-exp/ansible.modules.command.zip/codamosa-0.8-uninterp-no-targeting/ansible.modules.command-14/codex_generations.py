

# Generated at 2022-06-20 21:19:41.940367
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.parsing.convert_bool import boolean
    module = AnsibleModule(argument_spec=dict(check_command=dict(type='bool', default=False)))
    module.check_mode = boolean(module.params['check_command'])
    if module.check_mode:
        check_command(module, ['/usr/bin/chown', 'user', '/some/path'])
    else:
        check_command(module, ['/usr/bin/chmod', '0755', '/some/path'])



# Generated at 2022-06-20 21:19:47.894610
# Unit test for function check_command
def test_check_command():
    import mock
    module = mock.MagicMock()
    module.warn.return_value = None
    for cmd in ['chown', 'chmod', 'chgrp']:
        check_command(module, cmd)
        assert module.warn.called
        module.warn.called = False
    for cmd in ['ln', 'mkdir', 'rm']:
        check_command(module, cmd)
        assert module.warn.called
        module.warn.called = False
    for cmd in ['curl', 'wget', 'svn', 'service', 'mount']:
        check_command(module, cmd)
        assert module.warn.called
        module.warn.called = False

# Generated at 2022-06-20 21:20:02.059571
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    check_command(module, "/bin/echo")
    check_command(module, "/bin/uname")
    check_command(module, "/bin/mkdir -p")
    check_command(module, "/bin/chmod 777")
    check_command(module, "/usr/bin/svn up")
    check_command(module, "/usr/bin/service foo start")
    check_command(module, "/bin/rpm -q")
    check_command(module, "/usr/bin/yum install")
    check_command(module, "/usr/bin/zypper install")
    check_command(module, "/usr/bin/dnf install")
    check_command(module, "/usr/bin/apt-get install")
    check_command

# Generated at 2022-06-20 21:20:10.655247
# Unit test for function check_command
def test_check_command():
    module_mock = AnsibleModule({})
    module_mock.warn = lambda msg: None
    for cmd in ['chmod', 'chgrp', 'chown', 'ln', 'mkdir', 'touch', 'rmdir', 'rm']:
        check_command(module_mock, [cmd])
    for cmd in ['curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
                'tar', 'unzip', 'sed', 'dnf', 'zypper']:
        check_command(module_mock, [cmd])
    for cmd in ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        check_command(module_mock, [cmd])



# Generated at 2022-06-20 21:20:14.144276
# Unit test for function check_command
def test_check_command():
    import ansible.utils.module_docs_fragments
    mod = ansible.utils.module_docs_fragments
    mod.ModuleDocFragment._warnings = []
    check_command(mod, 'ansible.builtin.command')
    assert len(mod.ModuleDocFragment._warnings) == 1
    assert mod.ModuleDocFragment._warnings[0].startswith("Consider using the shell module")


# Generated at 2022-06-20 21:20:24.991182
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ["touch"])
    assert module.warnings[0] == "Consider using the file module with state=touch rather than running 'touch'.  " \
                                 "If you need to use 'touch' because the file module is insufficient you can add 'warn: false' " \
                                 "to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg " \
                                 "to get rid of this message."

    module = AnsibleModule(argument_spec={})
    check_command(module, ["chown"])

# Generated at 2022-06-20 21:20:32.541699
# Unit test for function check_command
def test_check_command():
    # Return an AnsibleModule object used for testing
    def __init__(self, *args, **kwargs):
        super(AnsibleModule, self).__init__(*args, **kwargs)
        self.params = {'command': args[0][0]}
        self.warnings = []

    def warn(self, msg):
        self.warnings.append(msg)

    module = type('MyModule', (AnsibleModule,), dict(__init__=__init__, warn=warn))

# Generated at 2022-06-20 21:20:44.746133
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic

    class TestModule(object):
        def __init__(self, result=None, params=None):
            self.params = params or {}
            self.result = result or {}

        def exit_json(self, **kwargs):
            self.exit_args = kwargs

        def fail_json(self, **kwargs):
            self.fail_args = kwargs

        def warn(self, msg):
            self.warn_args = msg

    def get_module_mock(result=None, params=None):
        module = TestModule(result=result, params=params)
        return module


# Generated at 2022-06-20 21:20:48.292501
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    result = check_command(module, ["touch", "file"])
    assert not result



# Generated at 2022-06-20 21:20:56.403223
# Unit test for function main
def test_main():
    # Test 1
    # Inputs:
    args={'_raw_params':'','_uses_shell':False,'argv':['ansible_module_command_check_command.py'],'chdir':'','executable':'','creates':'','removes':'','warn':False,'stdin':'','stdin_add_newline':True,'strip_empty_ends':True}
    sys.argv=['test1']

# Generated at 2022-06-20 21:21:22.544734
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, '/bin/chown root:root')
    check_command(module, '/bin/chmod 755')
    check_command(module, '/bin/chgrp root')
    check_command(module, '/bin/ln -s /bin/foo /bin/bar')
    check_command(module, '/bin/mkdir /tmp/dir')
    check_command(module, '/bin/touch /tmp/file')
    check_command(module, '/bin/rm /tmp/file')
    check_command(module, '/bin/rmdir /tmp/dir')
    check_command(module, '/bin/curl http://foo/file.txt')
    check_command(module, '/bin/wget http://foo/file.txt')
   

# Generated at 2022-06-20 21:21:33.553305
# Unit test for function main
def test_main():
    command_line = ["ps", "-ef"]

# Generated at 2022-06-20 21:21:42.575030
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "chown root /etc/passwd")
    check_command(module, ["chown", "root", "/etc/passwd"])
    check_command(module, "chmod 644 /etc/passwd")
    check_command(module, ["chmod", "644", "/etc/passwd"])
    check_command(module, "chgrp root /etc/passwd")
    check_command(module, ["chgrp", "root", "/etc/passwd"])
    check_command(module, "ln -s /etc/passwd foo")
    check_command(module, ["ln", "-s", "/etc/passwd", "foo"])
    check_command(module, "mkdir /etc/passwd")
    check_

# Generated at 2022-06-20 21:21:46.630536
# Unit test for function check_command
def test_check_command():
    class Module(object):
        def __init__(self):
            self.warn_msg = []
        def warn(self, msg):
            self.warn_msg.append(msg)

    command = 'touch'

    module = Module()
    check_command(module, command)
    assert module.warn_msg[0].startswith("Consider using the {mod} module with {subcmd} rather "
                                         "than running '{cmd}'.".format(mod='file',
                                                                        subcmd='state=touch',
                                                                        cmd=command))

    module = Module()
    check_command(module, ['cmd', 'arg'])

# Generated at 2022-06-20 21:21:57.320148
# Unit test for function main
def test_main():
    # Ignore ImportError as AnsibleModule is not available outside a running Ansible module
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        pass
    # Ignore ImportError as module is not available outside a running Ansible module
    try:
        from ansible.module_utils.command import check_command_module
    except ImportError:
        pass
    # Ignore ImportError as module is not available outside a running Ansible module
    try:
        from ansible.module_utils.command import check_command_plugin
    except ImportError:
        pass
    # Ignore AttributeError as AnsibleModule is not available outside a running Ansible module
    try:
        AnsibleModule
    except AttributeError:
        pass


# Generated at 2022-06-20 21:22:03.061583
# Unit test for function main
def test_main():
    command = """
"""
    argv = []
    args = {}
    command = "sudo ls /root"
    args = dict(
        executable="sudo",
        _raw_params=command,
        _uses_shell="True",
        argv=argv,
    )
    main()
    print ("success")


# Generated at 2022-06-20 21:22:12.614177
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ['curl', 'https://docs.ansible.com'])
    assert module.warn.called_with('Consider using the {} module rather than running \'{}\'.'.format('get_url or uri', 'curl'))

    module = AnsibleModule(argument_spec={})
    check_command(module, ['sudo', 'service', 'reboot'])
    assert module.warn.call_count == 2
    assert module.warn.call_args_list[0][0] == ('Consider using \'become\', \'become_method\', and \'become_user\' rather than running {}'.format('sudo'),)

# Generated at 2022-06-20 21:22:19.113080
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(
        argument_spec = dict(),
    )
    test_commandline = 'chown test:test test1'
    test_commandline_list = ['chown', 'test:test', 'test1']
    check_command(test_module, test_commandline)
    check_command(test_module, test_commandline_list)

# Run unit tests directly
if __name__ == '__main__':
    test_check_command()



# Generated at 2022-06-20 21:22:31.710980
# Unit test for function check_command
def test_check_command():
  module = AnsibleModule(argument_spec={'c': {'type': 'string', 'required': True}})
  check_command(module, 'curl http://example.com')
  check_command(module, 'curl http://example.com -o /tmp/example.com')
  check_command(module, 'curl -O http://example.com/')
  check_command(module, 'wget http://example.com/')
  check_command(module, 'wget -O http://example.com/')
  check_command(module, 'svn co http://example.com/repo')
  check_command(module, 'service apache2 restart')
  check_command(module, 'mount /dev/sda1 /tmp/test')

# Generated at 2022-06-20 21:22:44.117627
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    class TestAnsibleModule(AnsibleModule):
        def run_command(self, args, executable=None, use_unsafe_shell=True, encoding=None, data=None, binary_data=False):
            return 1, "Test", "Test"


# Generated at 2022-06-20 21:22:58.753565
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils._text import to_text
    module = DummyModule(**dict(command_warnings=True))
    check_command(module, "cat")
    assert to_text(module.warnings[0]) == "Consider using the file module with content rather than running 'cat'."



# Generated at 2022-06-20 21:23:09.847446
# Unit test for function check_command
def test_check_command():
    class M(object):
        def __init__(self):
            self.warns = []
            self.cmd = None
            self.failed = False

        def warn(self, msg):
            self.warns.append(msg)

    m = M()

    check_command(m, [b'/bin/ls', b'-l'])
    assert len(m.warns) == 0, "One of %s should have warned that a module exists" % m.warns
    m.warns = []

    check_command(m, [b'/bin/rm', b'-rf', b'/tmp/foo'])
    assert len(m.warns) == 1
    expected = "Consider using the file module with state=absent rather than running"

# Generated at 2022-06-20 21:23:23.335576
# Unit test for function main
def test_main():
    args = { '_raw_params': 'echo hello', '_uses_shell': False, 'argv': [ 'echo', 'hello' ],
             'chdir': None, 'executable': None, 'creates': None, 'removes': None,
             'warn': False, 'stdin': None, 'stdin_add_newline': True, 'strip_empty_ends': True }
    mock_module = Mock(**args)

    with patch.multiple(__builtin__, open=DEFAULT, exit=DEFAULT, glob=DEFAULT, datetime=DEFAULT, access=DEFAULT) as mock_funcs:
        mock_funcs['glob.glob'].return_value = False

# Generated at 2022-06-20 21:23:34.727269
# Unit test for function main

# Generated at 2022-06-20 21:23:38.335449
# Unit test for function main
def test_main():
    # Use the AnsibleModule utility to initialize
    module = AnsibleModule(dict(), False)
    # call the main function
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:49.815266
# Unit test for function check_command
def test_check_command():
    import warnings
    warnings.simplefilter('error')
    check_command(None, '/bin/chmod')
    check_command(None, '/bin/ln')
    check_command(None, '/usr/bin/svn')
    check_command(None, '/bin/rpm')
    check_command(None, '/bin/yum')
    check_command(None, '/usr/bin/apt-get')
    check_command(None, '/bin/mount')
    # Some versions of wget are in /usr/bin, some in /usr/local/bin
    check_command(None, '/usr/bin/wget')
    check_command(None, '/usr/local/bin/wget')
    check_command(None, '/bin/curl')
    check_command(None, '/bin/tar')
    check

# Generated at 2022-06-20 21:23:56.469377
# Unit test for function check_command
def test_check_command():
    commandline = "/usr/bin/some_command arg1 arg2"
    module = AnsibleModule(
        argument_spec = dict(
            free_form = dict(required=True, type='str'),
        )
    )
    module.params = {'free_form': commandline}
    module.deprecate('Command', 'ansible.builtin.command module has been deprecated', version='2.14')
    check_command(module, module.params['free_form'])



# Generated at 2022-06-20 21:23:57.596096
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-20 21:23:59.046382
# Unit test for function main
def test_main():
    assert(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:09.872813
# Unit test for function main
def test_main():
    args = ['ansible-test', 'command', '/bin/ls', '--skipp']
    if not PARSED_ARGS:
        # Run module directly, missing required args
        with pytest.raises(SystemExit):
            main()
    else:
        with pytest.raises(SystemExit):
            main()

        with pytest.raises(SystemExit):
            PARSED_ARGS.skipp = True
            if PARSED_ARGS.args:
                PARSED_ARGS.args.append('skipp')
            main()

        PARSED_ARGS.skipp = False
        PARSED_ARGS.args = args
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:23.370555
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['changed']


# Generated at 2022-06-20 21:24:37.242062
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.args = {'warn': True}

        def warn(self, msg):
            self.msg = msg

    def mock_check_command(module, commandline):
        return check_command(module, commandline)

    test_module = FakeModule()
    for command in ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch',
                    'curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
                    'tar', 'unzip', 'sed', 'dnf', 'zypper']:
        mock_check_command(test_module, command)
        assert test_module.msg is not None

# ===========================================

# Generated at 2022-06-20 21:24:52.691403
# Unit test for function check_command
def test_check_command():
    # Import module without json and yaml
    #import imp
    #command = imp.load_source('ansible.builtin.command', 'library/ansible/modules/commands/command.py')

    # Create a module
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    # Replace the method 'warn' to allow test
    module.warn = lambda x: None
    check_command(module, ['yum'])
    check_command(module, ['dnf'])
    check_command(module, ['zypper'])
    check_command(module, ['rpm'])
    check_command(module, ['apt-get'])
    check_command(module, ['wget'])
    check

# Generated at 2022-06-20 21:24:56.462568
# Unit test for function main
def test_main():
    try:
        return_value = main()
        # AssertionError: assert False
    except AssertionError as ae:
        # return False
        pass
    else:
        raise ValueError("Expected to fail")

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:57.860344
# Unit test for function main
def test_main():
    assert callable(main)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:25:05.363459
# Unit test for function main
def test_main():
    # unit tests use the current directory as the ansible root
    test_command = ("/bin/ls /home/ansible/test_dir", None, 0)
    test_command_fail = ("/bin/ls /home/ansible/nonvalid", None, 255)

    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default=test_command[0]),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', default=None),
            executable=dict(),
            chdir=dict(type='path'),
            creates=dict(),
            warn=dict(type='bool', default=False),
            removess=dict(type='path'),
        ),
        supports_check_mode=True,
    )
    r = {}

# Generated at 2022-06-20 21:25:09.966100
# Unit test for function main
def test_main():
    """
    Unit tests for main()
    """
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:25:16.677764
# Unit test for function check_command
def test_check_command():
    args = dict(
        commandline='/usr/bin/make_database.sh db_user db_name creates=/path/to/database',
    )
    module = AnsibleModule(argument_spec=args)
    check_command(module, args['commandline'])



# Generated at 2022-06-20 21:25:27.473716
# Unit test for function check_command
def test_check_command():
    # initialize argument spec
    module = AnsibleModule({})

    # define argument spec
    module.argument_spec = dict(
        name=dict(),
    )

    # check command
    check_command(module, ['/bin/bash', '-c', 'mount'])
    check_command(module, ['/bin/bash', '-c', 'yum'])
    check_command(module, ['/bin/bash', '-c', 'rpm'])
    check_command(module, ['/bin/bash', '-c', 'curl'])
    check_command(module, ['/bin/bash', '-c', 'wget'])
    check_command(module, ['/bin/bash', '-c', 'svn'])

# Generated at 2022-06-20 21:25:43.484335
# Unit test for function main

# Generated at 2022-06-20 21:26:20.960169
# Unit test for function main
def test_main():
    # A bit unneccessary, but still
    args = []

    class MyModule(object):
        def __init__(self):
            self.run_command = mock.Mock(return_value=(0, '', ''))
            self.fail_json = mock.Mock()
            self.exit_json = mock.Mock()
            self.check_mode = False
            self.params = {
                '_uses_shell': False,
                'chdir': '',
                'executable': None,
                'creates': '',
                'removes': '',
                'warn': False,
                'stdin': ''
            }

        def warn(self, msg):
            pass

    m = MyModule()
    main()
    assert m.run_command.call_count == 1

# Generated at 2022-06-20 21:26:30.389386
# Unit test for function check_command
def test_check_command():
    (changed, rc, stdout, stderr) = check_command(module, ['rm', '-rf', '/'])
    assert not changed
    (changed, rc, stdout, stderr) = check_command(module, ['curl', 'www.google.com'])
    assert not changed
    (changed, rc, stdout, stderr) = check_command(module, ['touch', '/tmp/foo'])
    assert not changed
    (changed, rc, stdout, stderr) = check_command(module, ['sed', '/tmp/foo', 's/bar/baz'])
    assert not changed
    (changed, rc, stdout, stderr) = check_command(module, ['chown', 'foo'])
    assert not changed
    (changed, rc, stdout, stderr)

# Generated at 2022-06-20 21:26:45.593029
# Unit test for function main
def test_main():
    args_dict = {
        '_raw_params': 'echo hello',
        '_uses_shell': 'False',
        'argv': '',
        'chdir': '',
        'executable': '',
        'creates': '',
        'removes': '',
        'warn': 'False',
        'stdin': '',
        'stdin_add_newline': 'True',
        'strip_empty_ends': 'True',
    }
    with mock.patch.object(AnsibleModule, 'run_command') as mock_rc:
        mock_rc.return_value = (0, 'stdout', 'stderr')
        main()
    assert mock_rc.called == True


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:58.183218
# Unit test for function check_command
def test_check_command():
    args = dict(
        warn=False,
    )
    m = AnsibleModule(argument_spec=dict(), supports_check_mode=True, **args)

    check_command(m, to_bytes('/usr/bin/ls'))
    check_command(m, to_bytes('/usr/bin/chmod'))
    check_command(m, to_bytes('/usr/bin/chmod 775'))
    check_command(m, to_bytes('/usr/bin/chmod 0644 /tmp/file'))
    check_command(m, to_bytes('/usr/bin/chmod'))
    check_command(m, to_bytes('/usr/bin/curl'))
    check_command(m, to_bytes('/usr/bin/wget'))

# Generated at 2022-06-20 21:27:13.511127
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = "mkdir"
    check_command(module, commandline)
    commandline = "/usr/bin/mkdir"
    check_command(module, commandline)
    commandline = "touch"
    check_command(module, commandline)
    commandline = "/usr/bin/touch"
    check_command(module, commandline)
    commandline = ["tar", "--transform", "s,^.,new_name,S", "-xvf",
                   "/tmp/test.tar.gz"]
    check_command(module, commandline)
    commandline = ["tar", "--transform", "s,^.,new_name,S", "-xvf",
                   "/tmp/test.tar.gz", "--absolute-names"]

# Generated at 2022-06-20 21:27:24.356705
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, ['echo', 'hello'])
    assert module.warnings == []

    check_command(module, ['touch', 'file'])
    assert module.warnings == [
        "Consider using the file module with state=touch rather than running 'touch'.  "
        "If you need to use 'touch' because the file module is insufficient you can add 'warn: false' to this command task or "
        "set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]

    check_command(module, ['curl', 'http://example.com'])

# Generated at 2022-06-20 21:27:35.474606
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils import connection
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def _call_check_mode(self, *args, **kwargs):
            pass

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

        def exit_json(self, **kwargs):
            self.exit_json_args = kwargs


# Generated at 2022-06-20 21:27:40.423799
# Unit test for function check_command
def test_check_command():
    commandline = 'sed'
    module = AnsibleModule(command_warnings=True)
    check_command(module, commandline)
    assert 'Consider using the replace, lineinfile or template module rather than running' in module.warn.call_args[0][0]


# Generated at 2022-06-20 21:27:54.259605
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    # no warning
    #
    # The following are commented out because they generate a warning on the LOG... maybe they need additional parameters
    # or an appropriate playbook/task/role. For example, the 'dnf' test fails on Fedora because dnf is not installed.
    #
    # check_command(module, ["curl", "http://www.ansible.com"])
    # check_command(module, ["wget", "http://www.ansible.com"])
    # check_command(module, ["chown", "teacher", "file"])
    # check_command(module, ["chmod", "700", "file"])
    # check_command(module, ["chgrp", "teachers", "file"])
    # check_command(module, ["

# Generated at 2022-06-20 21:28:04.529619
# Unit test for function check_command
def test_check_command():
    import ansible.module_utils.basic
    test_args = dict(cmd=["test-command"])
    test_module = AnsibleModule(argument_spec=dict())
    result = check_command(test_module, test_args.pop("cmd"))

    assert result is True
    test_args = dict(cmd=["test-command", "arg", "arg2=val2"])
    result = check_command(test_module, test_args.pop("cmd"))

    assert result is True
