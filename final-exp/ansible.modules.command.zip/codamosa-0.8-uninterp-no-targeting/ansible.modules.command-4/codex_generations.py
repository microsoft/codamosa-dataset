

# Generated at 2022-06-20 21:19:45.387038
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.warn = lambda x: x
    check_command(test_module, 'chown')
    check_command(test_module, 'chmod')
    check_command(test_module, 'chgrp')
    check_command(test_module, 'ln')
    check_command(test_module, 'mkdir')
    check_command(test_module, 'rmdir')
    check_command(test_module, 'rm')
    check_command(test_module, 'touch')

    check_command(test_module, 'curl')
    check_command(test_module, 'wget')
    check_command(test_module, 'svn')
    check_command(test_module, 'service')

# Generated at 2022-06-20 21:19:47.156741
# Unit test for function check_command
def test_check_command():
    pass


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:20:01.852770
# Unit test for function main
def test_main():
    test_args = ["ansible-test", "command", "/usr/bin/ansible-test", "--debug"]
    test_kwargs = {
        "_raw_params": "echo 'This is a test.'",
        "_uses_shell": False,
        "argv": ["echo", "This is a test."],
        "chdir": "",
        "executable": "",
        "creates": "",
        "removes": "",
        "stdin": None,
        "stdin_add_newline": True,
        "strip_empty_ends": True
    }
    test_result = {"msg": 'non-zero return code', "rc": 1}

# Generated at 2022-06-20 21:20:04.405185
# Unit test for function check_command
def test_check_command():
    test_check = AnsibleModule({}, {'command': 'foo'})
    check_command(test_check, 'foo')
    assert not test_check.fail_json.called



# Generated at 2022-06-20 21:20:12.421332
# Unit test for function main
def test_main():

    # Disable these lint checks due to the, not always needed,
    # imports in the module.
    # pylint: disable=import-error,redefined-builtin,unused-import
    import textwrap

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception


# Generated at 2022-06-20 21:20:13.388056
# Unit test for function main
def test_main():
  check_command(module, args)

# Generated at 2022-06-20 21:20:23.610554
# Unit test for function main
def test_main():
    args = {'_raw_params': 'command', '_uses_shell': False, 'argv': '', 'chdir': '', 'executable': '', 'creates': '', 'removes': '', 'warn': False, 'stdin': '', 'stdin_add_newline': True, 'strip_empty_ends': True}

# Generated at 2022-06-20 21:20:27.403586
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    module = FakeModule()
    check_command(module, 'test')
    assert module.warnings



# Generated at 2022-06-20 21:20:29.821468
# Unit test for function main
def test_main():
    # NOTE: we are not testing the edge cases of the module,
    # see the module test for that
    # assert ...
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:42.578070
# Unit test for function check_command
def test_check_command():
    # mock a module
    module = AnsibleModule(argument_spec={})
    # test a simple command
    check_command(module, '/usr/bin/make_database.sh db_user db_name')
    # test i18n
    check_command(module, u'/usr/bin/make_database.sh db_user db_name')
    # test non-ascii bytes command
    check_command(module, to_bytes(u'/usr/bin/make_database.sh db_user db_name', encoding='utf-8'))
    # test a simple command with arguments
    check_command(module, '/usr/bin/make_database.sh db_user db_name creates=/path/to/database')
    # test a simple command with arguments using shell module

# Generated at 2022-06-20 21:21:01.672791
# Unit test for function main
def test_main():
    import sys

    import ansible.module_utils.basic
    import ansible.module_utils.shell
    sys.path.append('../../')

# Generated at 2022-06-20 21:21:02.797422
# Unit test for function check_command
def test_check_command():
    check_command('test')


# Generated at 2022-06-20 21:21:13.886773
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    shell = module

# Generated at 2022-06-20 21:21:26.854899
# Unit test for function main
def test_main():
    test_command_data = dict (
        arguments = dict(
            command = dict (
                module = dict(
                    
                )
            )
        )
    )

    # argument spec - everything is set to None

# Generated at 2022-06-20 21:21:37.806950
# Unit test for function main
def test_main():
    test_args = "test_arg"
    m = AnsibleModule(argument_spec={'_raw_params': {'type': 'str'}, 'argv': {'type': 'list'}, 'chdir': {'type': 'path'}, 'executable': {'type': 'str'}, 'creates': {'type': 'path'}, 'removes': {'type': 'path'}, 'warn': {'type': 'bool', 'default': False}, 'stdin': {'required': False}, 'stdin_add_newline': {'type': 'bool', 'default': True}, 'strip_empty_ends': {'type': 'bool', 'default': True}, '_uses_shell': {'type': 'bool', 'default': False}})
    m.params['_raw_params'] = test_args

# Generated at 2022-06-20 21:21:45.321765
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str')
        ),
        supports_check_mode=True
    )
    m.exit_json = lambda exit_args: exit_args
    check_command(m, "sed")
    assert m.warnings == ['Consider using the replace, lineinfile or template module rather than running \'sed\'.  If you need to use \'sed\' because the replace, lineinfile or template module is insufficient you can add \'warn: false\' to this command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get rid of this message.']
    m.warnings = []
    check_command(m, "yum")

# Generated at 2022-06-20 21:21:54.084386
# Unit test for function main
def test_main():
    # unit test for command module
    from ansible.modules.command import main
    from ansible.module_utils.common.collections import AnsibleModule
    import json
    import datetime
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping

    fake_args = {
        '_raw_params': 'echo hello',
        '_uses_shell': True,
        'chdir': '/tmp/',
        'executable': None,
        'creates': None,
        'removes': None,
        'warn': False,
        'strip_empty_ends': True
    }

    module = AnsibleModule(fake_args, supports_check_mode=True)
    main(module)
    assert module.exit

# Generated at 2022-06-20 21:21:55.612743
# Unit test for function main
def test_main():
    assert "AnsibleModule"


# Generated at 2022-06-20 21:22:02.852412
# Unit test for function main
def test_main():
    args = {
        "_raw_params": "",
        "_uses_shell": "False",
        "argv": "str",
        "chdir": "",
        "executable": "",
        "creates": "",
        "removes": "",
        "warn": "False",
        "stdin": "False",
        "stdin_add_newline": "True",
        "strip_empty_ends": "True"
    }
    module = AnsibleModule(argument_spec=args)
    result = main()
    #assert result['rc'] == 256
    #assert result['msg'] ==  "no command given"
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:12.578032
# Unit test for function main
def test_main():
    """ this is a simple test for main function """
    commandline = ['echo', 'hello']
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    shell = module.params['_uses_shell']

# Generated at 2022-06-20 21:22:32.730057
# Unit test for function main
def test_main():
    with pytest.raises(ansible.module_utils.common.missing_required_lib) as excinfo:
        main()
    assert to_text(excinfo.value) == 'The Python module "%s" is required. Install via your package manager or pip.' % ('shlex',)
    assert 'changed' in excinfo.value.kwargs
    assert excinfo.value.kwargs['changed'] == False
    assert 'delta' in excinfo.value.kwargs
    assert excinfo.value.kwargs['delta'] == None
    assert 'end' in excinfo.value.kwargs
    assert excinfo.value.kwargs['end'] == None
    assert 'rc' in excinfo.value.kwargs
    assert excinfo.value.kwargs['rc'] == None
    assert 'start' in excinfo.value.kw

# Generated at 2022-06-20 21:22:45.416990
# Unit test for function main

# Generated at 2022-06-20 21:22:47.291046
# Unit test for function main
def test_main():
    assert False, "TBD"


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:54.234686
# Unit test for function main
def test_main():
    import os
    import copy
    import sys

    # Fake module
    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class FakeModule(object):
        def __init__(self):
            self._ansible_version = "2.2.1.0"
            self.params = {"creates": "fake_creates", "removes": "fake_removes", "warn": "fake_warn"}

        def fail_json(self, **kwargs):
            raise AnsibleFailJson(kwargs)

        def exit_json(self, **kwargs):
            raise AnsibleExitJson(kwargs)

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False


# Generated at 2022-06-20 21:22:58.112432
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            warn=dict(default=True, type='bool'),
            command=dict(required=True),
        ),
    )
    check_command(module, "sudo bcs")


# Generated at 2022-06-20 21:23:09.212000
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:17.787424
# Unit test for function check_command
def test_check_command():
    # make sure warning is raised when using chmod
    module = AnsibleModule(argument_spec={})
    check_command(module, '/bin/chmod 755 /tmp')
    assert module.warn.call_args[0][0].startswith("Consider using the file module with mode")
    module.warn.reset_mock()

    # make sure warning is raised when using chgrp
    check_command(module, '/bin/chgrp root /tmp')
    assert module.warn.call_args[0][0].startswith("Consider using the file module with group")
    module.warn.reset_mock()

    # make sure warning is raised when using chown
    check_command(module, '/bin/chown root /tmp')

# Generated at 2022-06-20 21:23:25.666573
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:23:28.592391
# Unit test for function check_command
def test_check_command():
    assert True


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:23:34.454032
# Unit test for function main
def test_main():
    is_travis = os.environ.get('TRAVIS', False)
    if is_travis:
        pass
    else:
        print("ansible_builtin_command_unit_test")

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:01.207948
# Unit test for function check_command
def test_check_command():
    class ModuleMock(object):
        def __init__(self):
            self.warn_messages = []
            self.params = dict()
        def warn(self, msg):
            self.warn_messages.append(msg)

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = dict()

    module = ModuleMock()
    commandline = "touch /tmp/destination.txt"
    check_command(module, commandline)
    assert len(module.warn_messages) == 1
    assert "file" in module.warn_messages[0]
    assert "touch" in module.warn_messages[0]

    module = ModuleMock()
    commandline = "/bin/tar -xzf /tmp/abc.tar.gz"
    check_

# Generated at 2022-06-20 21:24:13.483280
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import base64
    from ansible.module_utils import common
    from ansible.module_utils._text import to_bytes, to_native


    # mock module builtins
    module_builtins = basic.AnsibleModule.__dict__

# Generated at 2022-06-20 21:24:25.112043
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = False

        def warn(self, msg):
            self.warnings.append(msg)

    # Test function without warnings
    module = TestModule(command_warnings=False)
    check_command(module, 'echo $TERM')
    assert not hasattr(module, 'warnings')

    # Test function with warnings
    module = TestModule(command_warnings=True)

# Generated at 2022-06-20 21:24:36.260461
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    command = "svn ls"
    check_command(module, command)
    command = "svn"
    check_command(module, command)
    command = "wget"
    check_command(module, command)
    command = "apt-get"
    check_command(module, command)
    command = "yum"
    check_command(module, command)
    command = "dnf"
    check_command(module, command)
    command = "zypper"
    check_command(module, command)
    command = "curl"
    check_command(module, command)
    command = "service"
    check_command(module, command)
    command = "mount"
    check_command(module, command)
    command = "rpm"
    check_

# Generated at 2022-06-20 21:24:47.264891
# Unit test for function main

# Generated at 2022-06-20 21:24:49.816799
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(command=dict(type='list')))
    check_command(module, ['echo', 'hello'])



# Generated at 2022-06-20 21:24:52.231875
# Unit test for function check_command
def test_check_command():
    assert(isinstance(check_command(AnsibleModule(argument_spec = dict()), "foo"), dict))


# Generated at 2022-06-20 21:25:00.344362
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import lib.ansible_module_command as amc
    module = amc.AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 21:25:09.322811
# Unit test for function main

# Generated at 2022-06-20 21:25:19.892042
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys
    test_module_path = os.path.join(os.path.dirname(__file__), 'test_check_command.py')
    test_module_path = os.path.abspath(test_module_path)
    test_module_dir = os.path.dirname(test_module_path)
    sys.path.insert(0, test_module_dir)
    module_mock = type('module_mock', (object,), {})()
    module_mock.check_mode = False
    module_mock.params = {}
    module_mock.warnings = ''
    module_mock.debug = False

# Generated at 2022-06-20 21:25:57.334972
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__': 
    main()

# Generated at 2022-06-20 21:26:05.200513
# Unit test for function main
def test_main():
    import json
    from ansible.modules.command import main
    _raw = """module.params={}"""
    _params = json.loads(_raw.replace('module.params=', '', 1))
    main(module=_params)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:06.109925
# Unit test for function check_command
def test_check_command():
    check_command('foo')



# Generated at 2022-06-20 21:26:17.497117
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping


# Generated at 2022-06-20 21:26:24.085877
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''

# Generated at 2022-06-20 21:26:29.720908
# Unit test for function main
def test_main():
    '''
    This is a dummy unit test for function main
    '''
    call_object = MagicMock()
    call_object.message = 'A message'
    call_object.fail_json.side_effect = SystemExit
    setattr(builtins, '__builtins__', {'True': True, 'False': False})
    import ansible.modules.system.command as command
    with pytest.raises(SystemExit):
        command.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:45.513008
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    test

# Generated at 2022-06-20 21:26:48.912978
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(module, "chown")


# Generated at 2022-06-20 21:26:54.509154
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def warn(self, msg):
            assert 'msg' in msg
        def __init__(self):
            self.warn = FakeModule.warn
    module = FakeModule()
    check_command(module, 'sudo echo "test"')


# Generated at 2022-06-20 21:27:11.983311
# Unit test for function check_command
def test_check_command():
    mock = MagicMock()
    m = ModuleStub({'warn': {}, 'warnings': []}, mock)
    check_command(m, "/usr/bin/chmod u+rwx")
    check_command(m, "/usr/bin/chmod u+rwx creates=/foo/bar")
    check_command(m, ["/usr/bin/chmod", "u+rwx", "creates=/foo/bar"])
    check_command(m, "/usr/bin/chgrp apache")
    check_command(m, ["/usr/bin/chgrp", "apache", "creates=/foo/bar"])
    check_command(m, "sudo /usr/bin/chgrp apache")
    check_command(m, "/usr/bin/mkdir /etc/foo")
    check_

# Generated at 2022-06-20 21:29:02.488208
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    args = [
        'echo', 'hello', 'world'
    ]
    r = {
        'changed': False,
        'cmd': args,
        'delta': '0:00:00.001529',
        'end': '2017-09-29 22:03:48.084657',
        'msg': '',
        'rc': 0,
        'start': '2017-09-29 22:03:48.083128',
        'stderr': '',
        'stdout': 'Clustering node rabbit@slave1 with rabbit@master …'
    }

# Generated at 2022-06-20 21:29:07.033449
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec = dict(
            warning = dict(type='bool', default=True)
        )
    )
    check_command(module, ['cat', '/etc/motd'])
    check_command(module, 'cat /etc/motd')
    check_command(module, 'cat /etc/motd && ls /tmp')
    check_command(module, 'yum remove -y mypackage')
    check_command(module, 'touch /path/to/database')
    check_command(module, 'echo hello')
    check_command(module, 'echo hello | grep hello')
    check_command(module, 'sudo cat /etc/motd')
    check_command(module, 'chmod 755 /etc/motd')

# Generated at 2022-06-20 21:29:13.947037
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    for cmd in ["ansible", "ansible-playbook", "ansible-pull"]:
        check_command(module, cmd)
        assert "can't be used" in module.warnings[0]



# Generated at 2022-06-20 21:29:24.693130
# Unit test for function main
def test_main():
    args = ["/usr/bin/make_database.sh db_user db_name"]
    executable = None
    shell = False
    chdir = "somedir/"
    creates = "/path/to/database"
    removes = None
    warn = False
    stdin = None
    stdin_add_newline = True
    strip = True

    class TestModule(object):

        def __init__(self):

            class TestParameters(object):

                def __init__(self):
                    self._raw_params = None
                    self._uses_shell = False
                    self.argv = None
                    self.chdir = None
                    self.executable = None
                    self.creates = None
                    self.removes = None
                    self.warn = False
                    self.stdin = None
                    self.stdin_add