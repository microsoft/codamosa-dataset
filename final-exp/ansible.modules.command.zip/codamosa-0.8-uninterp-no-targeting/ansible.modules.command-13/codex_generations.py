

# Generated at 2022-06-20 21:19:39.180220
# Unit test for function check_command
def test_check_command():
    """
    Check command.
    """
    module = AnsibleModule(argument_spec={})
    module.warn = lambda msg: msg
    module.exit_json = lambda: None

    commandline = ["/bin/chmod", "777", "file"]
    check_command(module, commandline)

    commandline = ["/bin/chgrp", "group", "file"]
    check_command(module, commandline)

    commandline = ["/bin/ln", "-sf", "file", "link"]
    check_command(module, commandline)

    commandline = ["/bin/mkdir", "dir"]
    check_command(module, commandline)

    commandline = ["/bin/rm", "-rf", "file"]
    check_command(module, commandline)


# Generated at 2022-06-20 21:19:45.845701
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={'command': dict(type='str', default='module name')})
    func = globals()['check_command']
    func(m, 'module name')
    assert m.warnings[0] == ("Consider using the module_utils module with module_utils rather than running 'module name'.  If you need to use 'module name' because the module_utils module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message.")



# Generated at 2022-06-20 21:19:58.045027
# Unit test for function main
def test_main():
    import pytest
    import os, sys, shutil
    from tempfile import mkdtemp
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_iterable

    # make sure we can handle unicode (we are not in a shell)
    command = u'echo hello'
    args = shlex.split(command)

# Generated at 2022-06-20 21:20:05.433240
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    for x in ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch']:
        check_command(module, [x, 'foo', 'bar'])
    for x in ['curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip', 'sed', 'dnf', 'zypper']:
        check_command(module, [x, 'foo', 'bar'])
    for x in ['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        check_command(module, [x, 'foo', 'bar'])


# Generated at 2022-06-20 21:20:08.122725
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(argument_spec={})
    test_module.warn = mock_warn
    check_command(test_module, '/bin/ls')


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:20:19.353899
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, 'touch foo')
    check_command(module, ['touch', 'foo'])
    check_command(module, ['tar', '--extract', '--file=/tmp/foo.tar'])
    check_command(module, ['rm', '-rf', '/tmp/bar/'])
    check_command(module, ['curl', 'http://localhost/'])
    check_command(module, 'rm -rf foo')
    check_command(module, ['svn', 'checkout', 'http://foo/bar/'])
    check_command(module, ['rpm', '-q', '--whatprovides', 'smtp', 'sendmail'])
    check_command(module, ['wget', 'http://foo/bar/'])


# Generated at 2022-06-20 21:20:28.701935
# Unit test for function check_command
def test_check_command():

    class WarningModule:
        def __init__(self):
            self.warnings = []

        def warn(self, warning):
            self.warnings.append(warning)

        def get_warnings(self):
            return self.warnings

    module = WarningModule()

    check_command(module, None)
    assert len(module.get_warnings()) == 0

    check_command(module, "")
    assert len(module.get_warnings()) == 0

    check_command(module, [])
    assert len(module.get_warnings()) == 0

    check_command(module, " ")
    assert len(module.get_warnings()) == 0

    check_command(module, [" "])
    assert len(module.get_warnings()) == 0


# Generated at 2022-06-20 21:20:42.439281
# Unit test for function check_command
def test_check_command():
    command = 'rm'
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-20 21:20:50.380772
# Unit test for function main
def test_main():
    # Test module args
    module_args = {
        '_raw_params': 'echo hello',
        '_uses_shell': True,
        'argv': ['/usr/bin/echo', 'hello'],
        'chdir': '/etc',
        'executable': '/bin/bash',
        'creates': '/tmp/foo',
        'removes': '/tmp/bar',
        'warn': True,
        'stdin': 'this is the stdin',
        'stdin_add_newline': False,
        'strip_empty_ends': True
        }
    # FAIL_JSON

# Generated at 2022-06-20 21:21:00.414665
# Unit test for function check_command
def test_check_command():
    module = DummyModule()
    check_command(module, 'sudo ls')
    assert module.warnings == ['Consider using \'become\', \'become_method\', and \'become_user\' rather than running sudo']
    check_command(module, 'ln -s foo bar')
    assert module.warnings == ['Consider using the file module with state=link rather than running \'ln\'.  If you need to use \'ln\' because the file module is insufficient you can add \'warn: false\' to this command task or set \'command_warnings=False\' in the defaults section of ansible.cfg to get rid of this message.']


# Generated at 2022-06-20 21:21:30.981325
# Unit test for function main
def test_main():
    # NOQA
    from . import command

# Generated at 2022-06-20 21:21:40.283704
# Unit test for function main

# Generated at 2022-06-20 21:21:43.415931
# Unit test for function check_command
def test_check_command():
    pass


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:21:52.867582
# Unit test for function main
def test_main():
    import json
    import subprocess
    fd, path = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-20 21:22:07.940893
# Unit test for function check_command
def test_check_command():
    import collections
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_native
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    # The module uses the module snippet to load a module in a different
    # environment.  To unit test it we need to create a "real" module.
    module_args = dict(
        argv=dict(
            type='list',
            elements='str',
            required=False,
        ),
    )


# Generated at 2022-06-20 21:22:19.103162
# Unit test for function check_command
def test_check_command():
    args = dict(
        command='/bin/echo "Hello world!"',
        warn=True
    )
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        bypass_checks=False,
    )
    check_command(module, args['command'])
    if args['warn']:
        assert module.warn.call_count == 1
        assert to_text(module.warn.call_args) == \
            to_text("(u'Consider using the file module rather than running %s.',)" % (os.path.basename(args['command'].split()[0]),))
    else:
        check_command('module', 'command')
        assert module.warn.call_count == 0



# Generated at 2022-06-20 21:22:31.710650
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    module.run

# Generated at 2022-06-20 21:22:33.907794
# Unit test for function main
def test_main():
    pass


# import module snippets
if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-20 21:22:46.513972
# Unit test for function main

# Generated at 2022-06-20 21:22:47.877458
# Unit test for function main
def test_main():
    assert True == True


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:18.244141
# Unit test for function check_command
def test_check_command():
    class Creds(object):
        def __init__(self):
            self.warnings = []
        def warn(self, warning):
            self.warnings.append(warning)
    creds = Creds()
    module = Creds()
    module.warn = creds.warn
    check_command(module, ["/bin/ls", "-l"])
    assert len(creds.warnings) == 0

    check_command(module, ["/usr/bin/chown", "me", "myfile"])
    assert "Consider using the file module with owner" in creds.warnings[0]

    creds.warnings = []
    check_command(module, ["/usr/bin/curl", "http://www.google.com"])

# Generated at 2022-06-20 21:23:18.907705
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:33.231271
# Unit test for function check_command
def test_check_command():

    class TestModule(object):
        def __init__(self):
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    def check_warnings(expected):
        assert len(tm.warnings) == len(expected)
        for warning in expected:
            assert warning in tm.warnings

    tm = TestModule()
    check_command(tm, 'curl google.com -o foo.txt')

# Generated at 2022-06-20 21:23:34.681518
# Unit test for function main
def test_main():
    assert main(['command']) == 0


# Generated at 2022-06-20 21:23:46.455413
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': {}, 'warn': {'type': 'bool', 'default': True}})
    check_command(module, ["service", "foo", "bar"])
    assert module.warnings == [
        "Consider using the service module rather than running 'service'.  If you need to use 'service' "
        "because the service module is insufficient you can add 'warn: false' to this command task or "
        "set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    ]
    check_command(module, ["echo", "foo", "bar"])

# Generated at 2022-06-20 21:23:57.032025
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.basic
    test_params = {'_raw_params': u'echo hi', '_uses_shell': False, 'argv': None, 'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': False}

# Generated at 2022-06-20 21:24:13.393480
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, ['chown'])
    check_command(module, ['chmod'])
    check_command(module, ['chgrp'])
    check_command(module, ['ln'])
    check_command(module, ['mkdir'])
    check_command(module, ['rmdir'])
    check_command(module, ['rm'])
    check_command(module, ['touch'])
    check_command(module, ['curl'])
    check_command(module, ['wget'])
    check_command(module, ['svn'])
    check_command(module, ['service'])
    check_command(module, ['mount'])
    check_command(module, ['rpm'])

# Generated at 2022-06-20 21:24:19.704129
# Unit test for function check_command
def test_check_command():

    commandline = ['foo', 'bar']

    module = AnsibleModule(
        argument_spec=dict(
            _ansible_check_mode=dict(type='bool'),
        ),
        supports_check_mode=True
    )

    check_command(module, commandline)



# Generated at 2022-06-20 21:24:23.888912
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            test_func=dict()
        )
    )
    r = main()
    assert r['rc'] == 0
    assert r['msg'] == 'non-zero return code'
    assert r['skipped'] == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:32.059799
# Unit test for function check_command
def test_check_command():
    module = type('', (), {})
    module.warn = lambda x: True
    check_command(module, u'wget http://someurl/')
    check_command(module, u'/usr/bin/wget http://someurl/')
    check_command(module, u'ls')
    check_command(module, u'runas')
    check_command(module, u'pbrun')
    check_command(module, u'foo')



# Generated at 2022-06-20 21:25:18.450987
# Unit test for function main
def test_main():
    # Correct input
    args1 = dict(
        _uses_shell=False,
        executable=None,
        argv=None,
        chdir=None,
        creates=None,
        removes=None,
        warn=False,
        _raw_params='ls',
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
        check_mode=True,
    )

    # Incorrect input

# Generated at 2022-06-20 21:25:26.486127
# Unit test for function main
def test_main():
    class AnsibleModuleMock():
        class _AnsibleModuleMock():
            def __init__(self):
                self.params = {'_raw_params': None, '_uses_shell': True, 'argv': None, 'chdir': None, 'executable': '.bashrc', 'creates': None, 'removes': None, 'warn': False, 'stdin': None, 'stdin_add_newline': False, 'strip_empty_ends': False}
                self.check_mode = True
        def __init__(self):
            self.exit_json = lambda a, **kwargs: (None, a, kwargs)
            self.fail_json = lambda a, **kwargs: (None, a, kwargs)

# Generated at 2022-06-20 21:25:30.731939
# Unit test for function check_command
def test_check_command():
    """
    This is a unit test for the check_command function,
    which tests the command
    """
    for i in check_command.__doc__, check_command.__name__:
        assert i is not None



# Generated at 2022-06-20 21:25:37.436555
# Unit test for function check_command
def test_check_command():

    check_command(ModuleStub(), ['echo', 'hello'])
    assert ModuleStub.warnings == []

    check_command(ModuleStub(), 'echo hello')
    assert ModuleStub.warnings == []

    check_command(ModuleStub(), ['curl'])
    assert len(ModuleStub.warnings) == 1
    assert 'Consider using the get_url or uri module' in ModuleStub.warnings[0]

    check_command(ModuleStub(), 'curl')
    assert len(ModuleStub.warnings) == 2
    assert 'Consider using the get_url or uri module' in ModuleStub.warnings[1]

    check_command(ModuleStub(), ['chown', 'root', 'filename'])
    assert len(ModuleStub.warnings) == 3

# Generated at 2022-06-20 21:25:39.558075
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    function_obj = globals()['check_command']
    function_obj(module, "echo hello")



# Generated at 2022-06-20 21:25:44.834381
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    args = ['ln', '-sf', '/etc/alternatives/java', '/usr/bin/java']
    check_command(module, args)
    args = ['yum', 'install', '-y', 'java-1.8.0-openjdk']
    check_command(module, args)



# Generated at 2022-06-20 21:25:55.944943
# Unit test for function main
def test_main():
    _raw_params = 'ls'
    _uses_shell = False
    argv = ['ls', '*']
    chdir = '/etc'
    executable = 'sudo'
    creates = ''
    removes = ''
    warn = False
    stdin = ''
    stdin_add_newline = True
    strip_empty_ends = True
    args = {'_raw_params':_raw_params, '_uses_shell':_uses_shell, 'argv':argv, 'chdir':chdir, 'executable':executable, 'creates':creates, 'removes':removes, 'warn':warn, 'stdin':stdin, 'stdin_add_newline':stdin_add_newline, 'strip_empty_ends':strip_empty_ends}
    main(args)


# Generated at 2022-06-20 21:25:58.894071
# Unit test for function check_command
def test_check_command():
    # Test importing function
    module = AnsibleModule(argument_spec={})
    # Test warning message
    result = check_command(module, ["chmod"])
    assert 'Consider using the file instead' in result

# =================================================================================


# Generated at 2022-06-20 21:26:08.689373
# Unit test for function main
def test_main():
    os.system('rm -rf /tmp/command')
    os.system('mkdir /tmp/command')
    os.system('touch /tmp/command/test.txt')
    r = {}
    r['changed'] = False
    r['stdout'] = ''
    r['stderr'] = ''
    r['rc'] = None
    r['cmd'] = None
    r['start'] = None
    r['end'] = None
    r['delta'] = None
    r['msg'] = ''
    args = ["echo", "test"]
    creates = "/tmp/command/test.txt"
    removes = ""
    if creates:
        if glob.glob(creates):
            r['msg'] = "Would not run command since '%s' exists" % (creates)

# Generated at 2022-06-20 21:26:19.617201
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule()
    module.warn = lambda x: print(x)
    module.params = {'warn': True}
    check_command(module, 'touch /var/tmp/foo')
    check_command(module, 'ln -s /var/tmp/foo /tmp/bar')
    check_command(module, 'mkdir /tmp/dir')
    check_command(module, 'rmdir /tmp/dir')
    check_command(module, 'rm /tmp/bar')
    check_command(module, 'chown root /tmp/bar')
    check_command(module, 'chgrp root /tmp/bar')
    check_command(module, 'chmod 755 /tmp/bar')
    check_command(module, 'curl -O http://localhost/foo.tgz')
    check_

# Generated at 2022-06-20 21:28:35.247159
# Unit test for function main
def test_main():
    assert main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:28:46.367065
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'ln -s foo bar')
    assert module.warnings[0] == "Consider using the file module with state=link rather than running 'ln'.  Consider using the file module with state=link rather than running 'ln' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    module.params.update({'warn': False})
    module = AnsibleModule(argument_spec={})
    check_command(module, 'ln -s foo bar')
    assert module.warnings == []
    module.params.update({'warn': False})



# Generated at 2022-06-20 21:28:47.236783
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-20 21:28:48.150055
# Unit test for function check_command
def test_check_command():
    assert False


# Generated at 2022-06-20 21:29:01.035331
# Unit test for function main

# Generated at 2022-06-20 21:29:07.299016
# Unit test for function main
def test_main():
    test_args = {'argv': 'ls', 'executable': '', 'chdir': '.', 'creates': '/etc/resolv.conf', 'removes': '', 'warn': 'False', 'stdin': '', 'stdin_add_newline': '', '_uses_shell': 'False', '_raw_params': ''}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    m_run_command = MagicMock(return_value=(0,'','',))
    m_exit_json = MagicMock()
    m_fail_json = MagicMock()

# Generated at 2022-06-20 21:29:10.170176
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    module = basic.AnsibleModule(argument_spec=dict(),
                                 supports_check_mode=True)
    module.params = {'chdir': None,
                     'executable': None,
                     'args': None,
                     'warn': True}
    module.check_mode = False
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:29:23.182713
# Unit test for function check_command
def test_check_command():
    import imp
    import os
    import tempfile

    test_file = os.path.join(tempfile.gettempdir(), "test-ansible-command-module.py")