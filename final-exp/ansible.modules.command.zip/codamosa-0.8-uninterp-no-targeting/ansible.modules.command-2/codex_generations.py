

# Generated at 2022-06-20 21:19:32.281189
# Unit test for function check_command
def test_check_command():
    mock_module = type('', (), {})()
    mock_module.check_mode = False
    def mock_warn(arg): return arg
    mock_module.warn = mock_warn
    check_command(mock_module, 'sudo ls')
    check_command(mock_module, ['sudo', 'ls'])


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:19:34.757921
# Unit test for function check_command
def test_check_command():
    pass


# Generated at 2022-06-20 21:19:45.385770
# Unit test for function main

# Generated at 2022-06-20 21:20:01.192086
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            pass
        def fail_json(self, **kwargs):
            pass
        def warn(self, *args):
            pass
    import __builtin__
    setattr(__builtin__, 'module', FakeModule())
    check_command(FakeModule(), ['chown', 'owner'])
    check_command(FakeModule(), ['chmod', 'mode'])
    check_command(FakeModule(), ['chgrp', 'group'])
    check_command(FakeModule(), ['ln', 'state=link'])
    check_command(FakeModule(), ['mkdir', 'state=directory'])
    check_command(FakeModule(), ['rmdir', 'state=absent'])

# Generated at 2022-06-20 21:20:09.738575
# Unit test for function check_command
def test_check_command():
    check_command(None, ["/bin/ls"])
    check_command(None, ["/bin/chown"])
    check_command(None, ["/bin/chmod"])
    check_command(None, ["/bin/chgrp"])
    check_command(None, ["/bin/ln"])
    check_command(None, ["/bin/mkdir"])
    check_command(None, ["/bin/rmdir"])
    check_command(None, ["/bin/rm"])
    check_command(None, ["/bin/touch"])
    check_command(None, ["/bin/curl"])
    check_command(None, ["/bin/wget"])
    check_command(None, ["/bin/svn"])

# Generated at 2022-06-20 21:20:14.998253
# Unit test for function main
def test_main():
    r = {"cmd": ["foo", "bar"]}
    args = {"_raw_params": r["cmd"]}
    module = AnsibleModule(argument_spec=dict())
    module.params = args
    check_command(module, r["cmd"])
    module.exit_json(**r)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:24.888289
# Unit test for function check_command
def test_check_command():
    assert check_command(None, 'chown') == None
    assert check_command(None, 'chmod') == None
    assert check_command(None, 'chgrp') == None
    assert check_command(None, 'ln') == None
    assert check_command(None, 'mkdir') == None
    assert check_command(None, 'rmdir') == None
    assert check_command(None, 'rm') == None
    assert check_command(None, 'touch') == None
    assert check_command(None, 'curl') == None
    assert check_command(None, 'wget') == None
    assert check_command(None, 'svn') == None
    assert check_command(None, 'service') == None
    assert check_command(None, 'mount') == None

# Generated at 2022-06-20 21:20:32.513573
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule(argument_spec=dict())
    check_command(mod, '/bin/cat')
    check_command(mod, '/bin/chmod')
    check_command(mod, '/bin/chmod 666')
    check_command(mod, '/bin/ln')
    check_command(mod, '/bin/ln -s /foo/bar')
    check_command(mod, '/bin/mkdir')
    check_command(mod, '/bin/rmdir')
    check_command(mod, '/bin/rm')
    check_command(mod, '/bin/touch')
    check_command(mod, '/usr/bin/dnf install a')
    check_command(mod, '/usr/bin/yum install a')
    check_command(mod, '/usr/bin/apt-get install b')
   

# Generated at 2022-06-20 21:20:44.703891
# Unit test for function main
def test_main():
    import StringIO

    mock_stdout = StringIO.StringIO()
    mock_stderr = StringIO.StringIO()
    (sys.stdout, sys.stdin) = (mock_stdout, mock_stdout)
    (sys.stderr, sys.stdin) = (mock_stderr, mock_stderr)

# Generated at 2022-06-20 21:20:55.098182
# Unit test for function main
def test_main():
    #pylint: disable=undefined-variable
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            # The default for this really comes from the action plugin
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:21:15.066672
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())

    check_command(module, "chown username /path/to/file")
    check_command(module, "chmod 755 /path/to/file")
    check_command(module, "chgrp groupname /path/to/file")
    check_command(module, "wget http://www.example.com/index.html")
    check_command(module, "apt-get install -y qemu")
    check_command(module, "yum install -y qemu")
    check_command(module, "zypper in -y qemu")
    check_command(module, "dnf install -y qemu")
    check_command(module, "tar -xvf /path/to/file.tar")

# Generated at 2022-06-20 21:21:27.810498
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', required=True),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=False,
    )


# Generated at 2022-06-20 21:21:37.963514
# Unit test for function main
def test_main():
    # Construct a mock arguments object
    args = {"_raw_params": "date", "_uses_shell": False, "argv": "date", "chdir": "/Users/Sean/dev/ansible-examples", "executable": None,
            "creates": None, "removes": None, "warn": True, "stdin": None, "stdin_add_newline": True, "strip_empty_ends": True}

    # Construct a mock module object
    mock_module = AnsibleModule(argument_spec=args)
    mock_module.run_command = MagicMock(return_value=[0, b'', b''])
    mock_module.exit_json = MagicMock()
    mock_module.fail_json = MagicMock()
    mock_module.check_mode = False

    # Run module under test


# Generated at 2022-06-20 21:21:45.447426
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import set_module_args
    import json
    import pytest
    import os

    # AnsibleModule() can be used with no argument, but
    # ansible-test would not be able to handle it

# Generated at 2022-06-20 21:21:54.157323
# Unit test for function main

# Generated at 2022-06-20 21:21:58.332622
# Unit test for function check_command
def test_check_command():
    run = 0  # number of tests run
    failed = []  # list of failed tests
    check_command('mod', 'yum install skype')
    run += 1
    if 'mod' not in failed:
        failed.append("yum 'skpe'")



# Generated at 2022-06-20 21:21:59.262781
# Unit test for function check_command
def test_check_command():
    pass


# Generated at 2022-06-20 21:22:10.115805
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

        def warn(self, warning):
            pass


# Generated at 2022-06-20 21:22:13.105427
# Unit test for function main
def test_main():
    r = {"changed":False,"stdout":"","stderr":"","rc":None,"cmd":None,"start":None,"end":None,"delta":None,"msg":""}
    r['stdout'] = "skipped, since /home/test/test.txt does not exist"
    result = main()
    assert result == r

# Generated at 2022-06-20 21:22:15.486057
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as cm:
        main()
        assert cm.exconly() == ""



# Generated at 2022-06-20 21:22:34.541821
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
        ),
        supports_check_mode=True,
    )
    m.exit_json = lambda **args: args
    r = main()
    for k in r.keys():
        assert r[k]


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:39.596030
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec=dict(
        cmd=dict(type='str', required=True)
    ))
    check_command(m, m.params['cmd'])


# Generated at 2022-06-20 21:22:45.696333
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warnings = []

        def warn(self, warning):
            self.warnings.append(warning)

    commandline = ['foo']
    module = FakeModule()
    check_command(module, commandline)
    assert len(module.warnings) == 0

    commandline = 'foo'
    module = FakeModule()
    check_command(module, commandline)
    assert len(module.warnings) == 0

    commandline = ['chown']
    module = FakeModule()
    check_command(module, commandline)
    assert "Consider using the file module with owner rather than running 'chown'." in module.warnings[0]

    commandline = ['chmod']
    module = FakeModule()

# Generated at 2022-06-20 21:22:53.461358
# Unit test for function main

# Generated at 2022-06-20 21:22:56.217987
# Unit test for function check_command
def test_check_command():
    check_command(AnsibleModule(argument_spec={}), "rm -rf /")



# Generated at 2022-06-20 21:23:03.561725
# Unit test for function check_command
def test_check_command():
    module = MagicMock()
    check_command(module, 'chown')
    call_args, call_kwargs = module.warn.call_args
    assert call_args
    assert call_kwargs
    assert 'file' in call_args[0]

    module.reset_mock()
    check_command(module, 'tar')
    call_args, call_kwargs = module.warn.call_args
    assert call_args
    assert call_kwargs
    assert 'unarchive' in call_args[0]

    module.reset_mock()
    check_command(module, 'curl')
    call_args, call_kwargs = module.warn.call_args
    assert call_args
    assert call_kwargs
    assert 'get_url' in call_args[0]


# Generated at 2022-06-20 21:23:16.039944
# Unit test for function check_command
def test_check_command():
    try:
        import ansible.modules.commands.shell
        from ansible.utils.display import Display
    except ImportError:
        raise AssertionError("Unable to import ansible modules")

    # test commands
    display = Display()
    module = ansible.modules.commands.shell.Command(boolean=True, display=display)
    check_command(module, ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch'])

    # test arguments

# Generated at 2022-06-20 21:23:31.918635
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.warnings = []
        def warn(self, warning):
            self.warnings.append(warning)

    test_module = TestModule()
    check_command(test_module, "svn co repo")
    check_command(test_module, "svn co repo /tmp/foo")
    check_command(test_module, "svn co --username bob repo /tmp/foo")
    check_command(test_module, "yum update --security")
    check_command(test_module, "yum install mariadb mariadb-server")
    check_command(test_module, "yum --disableplugin=fastestmirror install mariadb mariadb-server")

# Generated at 2022-06-20 21:23:32.907606
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:23:44.864037
# Unit test for function main

# Generated at 2022-06-20 21:24:16.939583
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    cmd = '/bin/chmod'
    check_command(module, cmd)
    assert "Consider using the file module with mode rather than running '/bin/chmod'." in module.warnings[-1]
    cmd = '/bin/ln'
    check_command(module, cmd)
    assert "Consider using the file module with state=link rather than running '/bin/ln'." in module.warnings[-1]
    cmd = '/bin/rm'
    check_command(module, cmd)
    assert "Consider using the file module with state=absent rather than running '/bin/rm'." in module.warnings[-1]
    cmd = '/bin/curl'
    check_command(module, cmd)

# Generated at 2022-06-20 21:24:21.367357
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chmod')
    check_command(module, ['chmod'])



# Generated at 2022-06-20 21:24:36.144970
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({},{})
    # Should not raise a warning
    check_command(module, 'ansible-doc')
    # Should raise a warning
    check_command(module, 'yum')
    # Should raise a warning
    check_command(module, 'chown')
    # Should raise a warning
    check_command(module, 'touch')
    # Should raise a warning
    check_command(module, 'svn')
    # Should raise a warning
    check_command(module, 'chmod')
    # Should raise a warning
    check_command(module, 'chgrp')
    # Should raise a warning
    check_command(module, 'ln')
    # Should raise a warning
    check_command(module, 'mkdir')
    # Should raise a warning

# Generated at 2022-06-20 21:24:47.146673
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # Create the Ansible module

# Generated at 2022-06-20 21:24:57.317361
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': {'required': True, 'type': 'str'}})
    check_command(module, 'sudo cat /etc/passwd')
    # check_command(module, 'sudo ls /tmp')
    # check_command(module, 'echo')
    # check_command(module, 'foo.sh')
    # check_command(module, '/opt/foo.py')
    # check_command(module, 'foo')
    # check_command(module, '/opt/foo.sh')
    # check_command(module, '/bin/ls')
    # check_command(module, ['/bin/ls', '/etc'])
    # check_command(module, {'command': '/bin/ls'})
    # check_command(module, {'command': ['/bin/

# Generated at 2022-06-20 21:25:04.546686
# Unit test for function main
def test_main():
    args_support_check_mode=dict(
        _raw_params=dict(),
        _uses_shell=dict(type='bool', default=False),
        argv=dict(type='list', elements='str'),
        chdir=dict(type='path'),
        executable=dict(),
        creates=dict(type='path'),
        removes=dict(type='path'),
        # The default for this really comes from the action plugin
        warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
        stdin=dict(required=False),
        stdin_add_newline=dict(type='bool', default=True),
        strip_empty_ends=dict(type='bool', default=True),
    )

# Generated at 2022-06-20 21:25:17.146903
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:25:26.127955
# Unit test for function main
def test_main():
    command_module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool'),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
            state=dict()
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:25:33.683594
# Unit test for function main
def test_main():
  module_args={
    "_raw_params" : "ls -a",
    "_uses_shell" : False,
    "creates" : None,
    "removes" : None,
    "chdir" : None,
    "executable" : None,
    "argv" : None,
    "warn" : False,
    "stdin" : None,
    "stdin_add_newline" : True,
    "strip_empty_ends" : True,
  }
  if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:25:45.415848
# Unit test for function main
def test_main():

    # Test for idempotence, when creates is not a file
    test_dict = {
        '_raw_params': '/usr/bin/make_database.sh db_user db_name creates=/path/to/database',
        '_uses_shell': False,
        'argv': None,
        'chdir': None,
        'creates': '/path/to/database',
        'executable': None,
        'removes': None,
        'warn': False,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True,
    }
    global module
    module = AnsibleModule(test_dict)
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:38.198304
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({})
    check_command(module, 'chmod')
    assert module.warnings[0] == "Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    del module.warnings[:]

    check_command(module, 'chown')

# Generated at 2022-06-20 21:26:46.667414
# Unit test for function check_command
def test_check_command():
    import unittest
    import sys
    import tempfile
    import json

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.json_utils import json_loads

    from ansible.module_utils.basic import AnsibleModule

    # Test case with multiple warning messages, test that all of them are displayed

    # Override AnsibleModule's internal implements_check_mode to prevent
    # skipping of test in check mode
    AnsibleModule.implements_check_mode = lambda self: True

    # Override AnsibleModule's internal supports_check_mode to prevent
    # skipping of test in check mode
    AnsibleModule.supports_check_mode = lambda self: True


# Generated at 2022-06-20 21:26:55.005690
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.params = None
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)
    module = FakeModule()
    check_command(module, 'ln -s /usr/bin/python /tmp/python')
    assert module.warnings[0].startswith("Consider using the file module with")



# Generated at 2022-06-20 21:26:57.651215
# Unit test for function main
def test_main():
    test_module = AnsibleModule({})
    args = ['/bin/echo', 'hello']
    main(test_module, args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:27:13.351738
# Unit test for function main

# Generated at 2022-06-20 21:27:19.939753
# Unit test for function check_command
def test_check_command():
    class FakeModule(object):
        def __init__(self):
            self.warnings = []

        def warn(self, warning):
            self.warnings.append(warning)

    module = FakeModule()
    commandline = '/usr/bin/yum -y install foo'
    expected_warning = "Consider using the yum module rather than running 'yum'.  If you need to use 'yum' because the yum module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

    check_command(module, commandline)

    assert expected_warning == module.warnings[0]


# Generated at 2022-06-20 21:27:34.926968
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, "/usr/bin/make_database.sh db_user db_name")
    check_command(module, "/usr/bin/make_database.sh db_user db_name creates=/path/to/database")
    check_command(module, "/usr/bin/make_database.sh db_user db_name removes=/path/to/database")
    check_command(module, "/usr/bin/make_database.sh db_user db_name")
    check_command(module, "/usr/bin/make_database.sh db_user db_name")
    check_command(module, "/usr/bin/make_database.sh db_user db_name")

# Generated at 2022-06-20 21:27:39.097036
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({}, check_mode=True)
    check_command(module, ['chmod', 'u+w+r', '/path/to/file'])



# Generated at 2022-06-20 21:27:40.038615
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-20 21:27:54.148945
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert check_command(module, 'chown') is None
    assert check_command(module, 'chmod') is None
    assert check_command(module, 'chgrp') is None
    assert check_command(module, 'ln') is None
    assert check_command(module, 'mkdir') is None
    assert check_command(module, 'rmdir') is None
    assert check_command(module, 'rm') is None
    assert check_command(module, 'touch') is None
    assert check_command(module, 'curl') is None
    assert check_command(module, 'wget') is None
    assert check_command(module, 'svn') is None
    assert check_command(module, 'service') is None