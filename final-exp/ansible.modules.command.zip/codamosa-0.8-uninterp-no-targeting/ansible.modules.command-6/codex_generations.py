

# Generated at 2022-06-20 21:19:32.577984
# Unit test for function check_command
def test_check_command():
    # We need to load this here as it is not always available at import time
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(module, 'tar')
    check_command(module, 'apt-get')
    check_command(module, 'chown')
    check_command(module, 'curl')



# Generated at 2022-06-20 21:19:38.907362
# Unit test for function check_command
def test_check_command():
    """
    This is a unit test for the function "check_command" in the module "command.py".
    It should have a test for each part of the function.

    :return: Boolean value of test result.
    """
    # prepare params
    module = AnsibleModule(argument_spec={})
    commandline = "commandline"
    # execute test
    check_command(module, commandline)
    # verify results


# Generated at 2022-06-20 21:19:48.651167
# Unit test for function main
def test_main():
    # Prepare test variables and mock functions
    module = AnsibleModule(
        supports_check_mode=True,
    )
    shell = module.params['_uses_shell']
    chdir = module.params['chdir']
    executable = module.params['executable']
    args = module.params['_raw_params']
    argv = module.params['argv']
    creates = module.params['creates']
    removes = module.params['removes']
    warn = module.params['warn']
    stdin = module.params['stdin']
    stdin_add_newline = module.params['stdin_add_newline']
    strip = module.params['strip_empty_ends']

    # Return values of function call
    r = dict()
    r['changed'] = True
    r['stdout']

# Generated at 2022-06-20 21:20:02.364117
# Unit test for function check_command
def test_check_command():
    class Module(object):
        def __init__(self):
          self.call_args = None
          self.called = False
        def warn(self, *args, **kwargs):
          self.called = True
          self.call_args = args[0]
        def exit_json(self, *args, **kwargs):
          pass
        def fail_json(*args, **kwargs):
          pass

# Generated at 2022-06-20 21:20:05.727400
# Unit test for function main
def test_main():
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:11.338441
# Unit test for function check_command
def test_check_command():
    class args: pass
    class module:
        def __init__(self):
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)
    commandline = ["/bin/foo", "bar"]
    m = module()
    check_command(m, commandline)
    assert len(m.warnings) == 1
    expected = "Consider using the file module with state=touch rather than running '/bin/foo'."
    assert m.warnings[0].startswith(expected)



# Generated at 2022-06-20 21:20:21.466208
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test a command that does not have an associated module warning
    check_command(module, 'date')
    assert module._warnings == []
    assert module._deprecations == []

    # Test a command that has a module as a warning suggestion
    check_command(module, 'touch /tmp/test.txt')

# Generated at 2022-06-20 21:20:30.415365
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule(argument_spec={
        'commandline': dict(type='list')
    })

    for cmd in ['chown', 'chgrp', 'chmod', 'ln', 'mkdir', 'rmdir', 'touch', 'yum', 'apt-get', 'dnf', 'zypper']:
        check_command(test_module, [cmd])
    for cmd in ['curl', 'wget', 'svn']:
        check_command(test_module, [cmd, '-s'])
    for cmd in ['-su', 'sudo', 'su', 'runas', 'pbrun', 'pfexec', 'pmrun', 'machinectl']:
        check_command(test_module, [cmd, '-u'])

# Generated at 2022-06-20 21:20:34.911582
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    cm = AnsibleModule(
        argument_spec = dict(),
    )
    (out, err) = check_command(cm, 'ls /tmp')
    assert err == None
    assert out == None


# Generated at 2022-06-20 21:20:46.335662
# Unit test for function main
def test_main():
    # Test case for ansible 2.9.9+
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 21:21:06.853560
# Unit test for function main
def test_main():
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    shoulda = 'Would'
    module.check_mode = True
    command = ['echo', 'hello']
    check_command(module, command)
    module.params['_raw_params'] = command
    module.params['_uses_shell'] = False
    module.params['creates'] = 'argv'
    module.params['removes'] = 'argv'
    module.params['warn'] = True
    module.params['chdir'] = False
    main()

# Generated at 2022-06-20 21:21:22.494557
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, 'chmod a+x somedir')
    check_command(module, ['chmod', 'a+x', 'somedir'])
    check_command(module, 'chown a+x somedir')
    check_command(module, 'chgrp a+x somedir')
    check_command(module, 'ln -s somedir somefile')
    check_command(module, 'mkdir somedir')
    check_command(module, 'rmdir somedir')
    check_command(module, 'rm somefile')
    check_command(module, 'touch somefile')
    check_command(module, 'curl http://ansible.com/index.html')

# Generated at 2022-06-20 21:21:33.512154
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls',
        executable='/bin/bash',
        strip_empty_ends=True,
    )
    mock_module = Mock(params=args)
    mock_module.run_command = MagicMock(return_value = (0, '', ''))
    with patch.object(Command, '__del__', return_value=None):
        with patch.object(glob, 'glob', return_value=False):
            with patch.object(AnsibleModule, '__del__', return_value=None):
                with patch.object(command, 'os', autospec=True) as os_mock:
                    with patch.object(command, 'shlex', autospec=True) as shlex_mock:
                        test_cmd = Command(mock_module)
                       

# Generated at 2022-06-20 21:21:34.601981
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-20 21:21:36.185119
# Unit test for function check_command
def test_check_command():
    check_command("/usr/bin/command")


# Generated at 2022-06-20 21:21:44.192618
# Unit test for function check_command

# Generated at 2022-06-20 21:21:53.347250
# Unit test for function check_command
def test_check_command():
    results = dict(
        creating=False,
        checking=False,
        changed=False,
        skipped=True,
        failed=False,
        msg=''
    )
    testmodule = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    check_command(testmodule, 'foobar')
    assert to_native(testmodule.warn.call_args) == "Consider using the file module with foobar rather than running 'foobar'.  " \
                                                   "If you need to use 'foobar' because the file module is insufficient you can add " \
                                                   "'warn: false' to this command task or set 'command_warnings=False' in the defaults " \
                                                   "section of ansible.cfg to get rid of this message."


# Generated at 2022-06-20 21:22:02.578354
# Unit test for function check_command
def test_check_command():
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    setattr(module, '_display', Display())
    setattr(module, 'params', ImmutableDict(dict(command=['echo'])))
    check_command(module, module.params['command'])



# Generated at 2022-06-20 21:22:13.517140
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/bin/false',
        chdir='/some/cwd',
        executable='/bin/bash',
        creates='/path/to/file',
        removes="/path/to/file",
        warn=True,
        stdin='hello',
        stdin_add_newline=True,
        strip_empty_ends=True
    )

# Generated at 2022-06-20 21:22:23.602815
# Unit test for function main
def test_main():
    # Check basic functionality
    cmd_args = ['command', '/path/to/chdir', 'args', 'yay']
    module_args = {'chdir': '/path/to/chdir', 'argv': ['command', 'args', 'yay']}
    module = AnsibleModule(argument_spec=module_args)
    r = main()
    assert r == (module_args, 'success', cmd_args), 'test_main failed!'
    # Check for error on no command
    cmd_args = ['command', '/path/to/chdir', 'args', 'yay']
    module_args = {'chdir': '/path/to/chdir', 'argv': []}
    module = AnsibleModule(argument_spec=module_args)
    r = main()
    return r[1] == 'error',

# Generated at 2022-06-20 21:22:44.617251
# Unit test for function main
def test_main():
    with mock.patch("ansible.module_utils.basic.AnsibleModule") as mock_module:
        mock_module.params = {'_uses_shell': False, 'chdir': None, 'executable': None, 'argv': None, 'creates': None, 'removes': None, 'warn': None, 'stdin': None, 'stdin_add_newline': True, 'strip_empty_ends': True, '_raw_params': None}
        mock_module.run_command.return_value = (0, "")
        with mock.patch("ansible.module_utils.basic.AnsibleModule.exit_json") as mock_exit_json:
            with mock.patch("ansible.module_utils.basic.AnsibleModule.fail_json") as mock_fail_json:
                main()


# Generated at 2022-06-20 21:22:45.671204
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-20 21:22:58.634763
# Unit test for function check_command
def test_check_command():
    class ModuleMock(object):
        def __init__(self):
            self.warnings = []

        def warn(self, message):
            self.warnings.append(message)

    module = CommandModule(argument_spec={})
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-20 21:23:09.708217
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-20 21:23:23.323702
# Unit test for function main

# Generated at 2022-06-20 21:23:23.802419
# Unit test for function check_command
def test_check_command():
    pass


# Generated at 2022-06-20 21:23:35.525869
# Unit test for function check_command
def test_check_command():
    # command is not on the list of destructive commands
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.check_command = check_command
    module.check_command(module, "foo bar")
    assert module.warnings == []

    # command is on the list of destructive commands
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.check_command = check_command
    module.check_command(module, "rm -rf foo bar")
    assert len(module.warnings) == 1

# Generated at 2022-06-20 21:23:47.223003
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default='ls'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path', default=''),
            executable=dict(default=None),
            creates=dict(type='path', default=''),
            removes=dict(type='path', default=''),
            warn=dict(type='bool', default=False),
            stdin=dict(required=False, default=None),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    result

# Generated at 2022-06-20 21:23:49.473408
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:51.666533
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:15.613056
# Unit test for function main
def test_main():
    def run_command(*args, **kwargs):
        output = '''
        This is a stdout message
        This is a stderr message
        '''
        if 'fail' in args[0]:
            return 126, output, output
        else:
            return 0, output, output


# Generated at 2022-06-20 21:24:27.139321
# Unit test for function check_command
def test_check_command():
    class Module(object):
        def __init__(self, **kwargs):
            args = kwargs.pop('args', [])
            self.params = dict(args=args, **kwargs)

        def warn(self, msg):
            assert isinstance(msg, str)
            self.warnings.append(msg)

    module = Module(args=[])
    check_command(module, ['files/cp.sh'])
    assert module.warnings == []

    module = Module(args=[])
    check_command(module, ['touch'])
    assert module.warnings == []

    module = Module(args=[])
    check_command(module, ['wget'])

# Generated at 2022-06-20 21:24:36.907272
# Unit test for function main

# Generated at 2022-06-20 21:24:47.615109
# Unit test for function main

# Generated at 2022-06-20 21:24:51.028738
# Unit test for function main
def test_main():
    key = '123'
    pos = 0
    r = next_key(key,pos)
    print('key is %s', r)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:59.714456
# Unit test for function check_command
def test_check_command():
    module = None
    command = 'tar'
    check_command(module, command)
    command = 'unzip'
    check_command(module, command)
    command = 'curl'
    check_command(module, command)
    command = 'wget'
    check_command(module, command)
    command = 'sudo'
    check_command(module, command)
    command = 'su'
    check_command(module, command)
    command = 'pbrun'
    check_command(module, command)
    command = 'pfexec'
    check_command(module, command)
    command = 'runas'
    check_command(module, command)
    command = 'pmrun'
    check_command(module, command)
    command = 'machinectl'
    check_command

# Generated at 2022-06-20 21:25:09.422217
# Unit test for function check_command
def test_check_command():
    check_command(AnsibleModule, 'answer')
    check_command(AnsibleModule, 'ansible-doc')
    check_command(AnsibleModule, 'ansible-playbook')
    check_command(AnsibleModule, 'ansible-pull')
    check_command(AnsibleModule, 'ansible-vault')
    check_command(AnsibleModule, 'ansible')
    check_command(AnsibleModule, ['ansible-vault', 'view'])
    check_command(AnsibleModule, 'ansible-console')
    check_command(AnsibleModule, 'ansible-connection')
    check_command(AnsibleModule, 'ansible-inventory')
    check_command(AnsibleModule, 'ansible-galaxy')



# Generated at 2022-06-20 21:25:19.892444
# Unit test for function main

# Generated at 2022-06-20 21:25:26.867284
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.parsing.convert_bool import boolean
    import os
    import sys
    import platform

    def check_for_collections(module_name):
        """Backwards compatibility support for Ansible < 2.9"""
        try:
            if module_name in sys.modules:
                del sys.modules[module_name]
            from importlib import util
            found = util.find_spec(module_name)
            if found:
                return True
        except ImportError:
            pass
        return False


# Generated at 2022-06-20 21:25:33.913318
# Unit test for function check_command
def test_check_command():
    module = MockModule({})
    cmd = ['ls', '-a']
    check_command(module, cmd)
    module.warn.assert_called_with("Consider using the file module with 'state=directory' rather than running 'ls'.  "
                                   "If you need to use 'ls' because the file module is insufficient you can add "
                                   "'warn: false' to this command task or set 'command_warnings=False' in the "
                                   "defaults section of ansible.cfg to get rid of this message.")



# Generated at 2022-06-20 21:26:03.654638
# Unit test for function main
def test_main():
    def test_module(args):
        command = args["command"]
        module = Mock()
        module.params = args
        module.check_mode = False
        module.run_command = Mock(return_value=(0, command, ""))
        module.exit_json = Mock()
        module.fail_json = Mock()
        module.warn = Mock()

        main()

        # Assert that function was called with correct parameters.
        module.exit_json.assert_called_once_with(changed=True, cmd=command, delta='0:00:00.000000', end='1970-01-01 00:00:00', msg='', rc=0, start='1970-01-01 00:00:00', stderr='', stdout=command)

    # Test executing command without chdir or check_mode.
    test_module

# Generated at 2022-06-20 21:26:10.981921
# Unit test for function main

# Generated at 2022-06-20 21:26:15.727000
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    # Note: No Exception should be raised for success
    assert result.value.args[0]['changed']
# end of unit test for function main

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:22.811234
# Unit test for function check_command
def test_check_command():
    obj = AnsibleModule(argument_spec={})
    obj.warn = lambda x: x
    assert 'Consider using the file module with state=link rather than running ln.' in check_command(obj, '/bin/ln')
    assert 'Consider using the file module with mode=0644 rather than running chmod.' in check_command(obj, '/bin/chmod')
    assert 'Consider using the file module with owner=foo rather than running chown.' in check_command(obj, '/bin/chown')
    assert 'Consider using the file module with group=foo rather than running chgrp.' in check_command(obj, '/bin/chgrp')
    assert 'Consider using the file module with state=touch rather than running touch.' in check_command(obj, '/bin/touch')

# Generated at 2022-06-20 21:26:31.252397
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.warnings = []
        def warn(self, msg):
            self.warnings.append(msg)

    module = TestModule()
    check_command(module, 'chown')
    assert 'Consider using' in module.warnings[-1]
    check_command(module, 'chmod')
    assert 'Consider using' in module.warnings[-1]
    check_command(module, 'chgrp')
    assert 'Consider using' in module.warnings[-1]
    check_command(module, 'ln')
    assert 'Consider using' in module.warnings[-1]
    check_command(module, 'mkdir')
    assert 'Consider using' in module.warnings[-1]

# Generated at 2022-06-20 21:26:47.321857
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': dict(type='str')})
    check_command(module, 'chown')
    assert module.warnings[0] == "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    module = AnsibleModule(argument_spec={'command': dict(type='str')})
    check_command(module, 'rm')

# Generated at 2022-06-20 21:26:58.910024
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            commandline=dict(),
        ),
        supports_check_mode=True
    )
    module.run_command = MagicMock()
    check_command(module, 'command')
    assert module.run_command.called is False
    check_command(module, 'curl')
    assert module.run_command.called is False
    check_command(module, 'svn')
    assert module.run_command.called is False
    check_command(module, 'mount')
    assert module.run_command.called is False
    check_command(module, 'rpm')
    assert module.run_command.called is False
    check_command(module, 'tar')
    assert module.run_command.called is False

# Generated at 2022-06-20 21:27:13.730177
# Unit test for function main
def test_main():
    current_dir = os.getcwd()
    module_utils_path = os.path.dirname(os.path.dirname(current_dir))
    test_module_path = module_utils_path + "/ansible_collections/ansible/builtin/tests/files/test_module.py"

# Generated at 2022-06-20 21:27:29.861597
# Unit test for function main
def test_main():
    module_mock = MagicMock()
    module_mock.params = {'creates': None, 'removes': None, 'argv': None, 'chdir': None, 'executable': None, 'stdin': None, 'stdin_add_newline': True, '_raw_params': 'ls -l -a', 'strip_empty_ends': True}
    module_mock.check_mode = False
    module_mock.fail_json.side_effect = SystemExit
    module_mock.run_command.return_value = (1, 'ok', '')
    sys.modules['ansible.modules.system.command'] = module_mock

    command = Command()
    try:
        command.main()
    except SystemExit as e:
        assert e.code == 1

    module_mock

# Generated at 2022-06-20 21:27:36.622363
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str', required=True),
        ),
        supports_check_mode=False,
        no_log=True,
    )
    check_command(m, "touch /tmp/foo")
    check_command(m, "yum install blar")
    check_command(m, "yum -y install blar")
    check_command(m, "curl http://abc")
    check_command(m, "curl -L http://abc")
    check_command(m, "curl -fL http://abc")
    check_command(m, "svn update /tmp/foo")
    check_command(m, "svn co http://abc")

# Generated at 2022-06-20 21:28:13.748361
# Unit test for function check_command
def test_check_command():
    import unittest
    import sys
    import os
    from ansible.module_utils import basic

    class TestCheckCommand(unittest.TestCase):
        def setUp(self):
            self.m = AnsibleModule(argument_spec=dict())

        def test_had_warnings(self):
            self.m.warn = self.warning
            self.warnings = []

            check_command(self.m, 'chown root /path/to/file')

            self.assertIn('Consider using the file module with owner rather than running', self.warnings[0])

        def test_no_warnings(self):
            self.m.warn = self.warning
            self.warnings = []

            check_command(self.m, 'echo "hello"')


# Generated at 2022-06-20 21:28:18.682836
# Unit test for function main

# Generated at 2022-06-20 21:28:25.665909
# Unit test for function main
def test_main():
    test_main.mock_run_command = None
    def run_command(args, **kwargs):
        """
        Returns a tuple of (exit_code, stdout, stderr)
        """
        return test_main.mock_run_command

    with patch('ansible.module_utils.basic.AnsibleModule.run_command', new=run_command):
        module = get_module_mock()
        module.params = {'_raw_params': 'foo', '_uses_shell': True}
        rc, stdout, stderr = (0, 'bar', 'biz')
        test_main.mock_run_command = [rc, stdout, stderr]
        main()
        assert module.exit_json.called

# Generated at 2022-06-20 21:28:39.197718
# Unit test for function check_command
def test_check_command():
    class TestModule:
        def __init__(self):
            self.exit_args = None
            self.fail_json_args = None
        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs
            raise Exception('fail_json called')
        def exit_json(self, *args, **kwargs):
            self.exit_json_args = args
            self.exit_json_kwargs = kwargs

    # Check command when command contains string in module_utils/command.py's arguments
    module = TestModule()
    commandline = 'mkdir /tmp/test_command'

# Generated at 2022-06-20 21:28:48.366859
# Unit test for function main

# Generated at 2022-06-20 21:29:01.059119
# Unit test for function main
def test_main():
    cmd = ('ansible-doc', 'ansible.builtin.command')
    doc = subprocess.check_output(cmd).decode().splitlines()
    name_line = [ln for ln in doc if ln.startswith('- name:')][0]
    name = name_line.split('- name:')[1].strip()


# Generated at 2022-06-20 21:29:11.409949
# Unit test for function main

# Generated at 2022-06-20 21:29:14.495515
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()
# end of module