

# Generated at 2022-06-20 21:19:43.220148
# Unit test for function main
def test_main():
    args = dict(
        executable=None,
        removes=None,
        chdir=None,
        argv=None,
        args="echo hello",
        stdin_add_newline=True,
        _uses_shell=False,
        strip_empty_ends=True,
        warn=False,
        creates=None)

# Generated at 2022-06-20 21:19:48.712927
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    check_command(m, "git checkout foo")
    assert m.warnings == ["Consider using the git module instead of running 'git'.  If you need to use 'git' because the git module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]
    check_command(m, "svn co bar")

# Generated at 2022-06-20 21:19:58.380539
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.source_control import ansible_module_command
    from ansible.module_utils.common.collections import is_iterable

    m = AnsibleModule(
        argument_spec = dict(
            cmd = dict(type='str'),
            argv = dict(type=list),
        ),
        supports_check_mode=True,
    )
    args = {"cmd": "touch", "argv": "touch"}
    check_command(m, args['cmd'])
    check_command(m, args['argv'])



# Generated at 2022-06-20 21:20:05.510908
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping

    args = ["test.sh"]
    # Note: there is no easy way to test the way main() handles argv because
    #       it doesn't accept the "args" argument in the argument_spec.
    #       If that is ever added, add a test here.
    # Test case 1:
    #  raw_params = None
    #  use_shell = None
    #  chdir = None
    #  executable = None
    #  warn = None
    #  stdin = None
    #  stdin_add_newline = None
    #  strip = None
    #  creates = "/path/to/directory"
    #  removes = None

# Generated at 2022-06-20 21:20:12.188814
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    module = basic.AnsibleModule({})
    module.run_command = lambda *args, **kwargs: (0, 'stdout', 'stderr')
    result = main()
    assert result['changed'] == False
    assert result['stdout'] == 'stdout'
    assert result['stderr'] == 'stderr'
    assert result['rc'] == 0
    assert result['cmd'] == None
    assert result['start'] == None
    assert result['end'] == None
    assert result['delta'] == None
    assert result['msg'] == ''

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:17.695525
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 21:20:19.009772
# Unit test for function main
def test_main():
    assert 1 == 1


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:21.297624
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert not result.value.args[0]['changed']


# Generated at 2022-06-20 21:20:29.227129
# Unit test for function check_command
def test_check_command():
    # Use a class to isolate variables
    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            kwargs['argument_spec'] = dict()
            super(TestAnsibleModule, self).__init__(*args, **kwargs)

    import copy
    test_command = 'touch /tmp/test_check_command'
    module = TestAnsibleModule()
    # Pass a string to check_command
    check_command(module, test_command)
    module = TestAnsibleModule()
    # Pass a list to check_command
    check_command(module, test_command.split())



# Generated at 2022-06-20 21:20:42.535396
# Unit test for function check_command
def test_check_command():
    class Module(object):
        def __init__(self):
            self.warnings = []
        def warn(self, message):
            self.warnings.append(message)

    module = Module()
    check_command(module, "/bin/chown root:root /etc/foo")
    assert module.warnings == ["Consider using the file module with state=touch rather than running '/bin/chown'.",
                               "If you need to use '/bin/chown' because the file module is insufficient you can add "
                               "'warn: false' to this command task or set 'command_warnings=False' in the defaults "
                               "section of ansible.cfg to get rid of this message."]

    module = Module()
    check_command(module, ["/usr/bin/curl", "http://example.com"])


# Generated at 2022-06-20 21:21:04.356987
# Unit test for function main

# Generated at 2022-06-20 21:21:15.373810
# Unit test for function main

# Generated at 2022-06-20 21:21:28.121426
# Unit test for function main

# Generated at 2022-06-20 21:21:28.680191
# Unit test for function check_command
def test_check_command():
    pass



# Generated at 2022-06-20 21:21:35.421169
# Unit test for function check_command
def test_check_command():
    args = dict(
        become=False,
        become_user=None,
        become_method=None,
    )
    module = AnsibleModule(argument_spec={}, supports_check_mode=False, check_invalid_arguments=False, **args)
    check_command(module, ['/bin/chown', 'root'])
    check_command(module, ['/bin/chmod', '777'])
    check_command(module, ['/bin/chgrp', 'root'])
    check_command(module, ['/bin/ln', 'root'])
    check_command(module, ['/bin/mkdir', 'root'])
    check_command(module, ['/bin/rmdir', 'root'])
    check_command(module, ['/bin/rm', 'root'])
   

# Generated at 2022-06-20 21:21:46.178157
# Unit test for function main

# Generated at 2022-06-20 21:21:54.563921
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec=dict(
            foo=dict(required=True)
        )
    )

    check_command(m, '/usr/bin/make_database.sh db_user db_name')
    assert m.warnings == []

    check_command(m, 'touch /tmp/do_not_create')

    assert m.warnings[0] == "Consider using the file module with state=touch rather than running 'touch'.  " \
                            "If you need to use 'touch' because the file module is insufficient you can add " \
                            "'warn: false' to this command task or set 'command_warnings=False' in the defaults " \
                            "section of ansible.cfg to get rid of this message."
    assert len

# Generated at 2022-06-20 21:22:02.999217
# Unit test for function main

# Generated at 2022-06-20 21:22:09.256398
# Unit test for function check_command
def test_check_command():
    mod = AnsibleModule({})
    check_command(mod, 'echo foo')
    check_command(mod, ['echo', 'foo'])
    check_command(mod, 'tar xf foo.tgz')
    check_command(mod, ['tar', 'xf', 'foo.tgz'])
    check_command(mod, ['chmod', '777', '/tmp/foo'])



# Generated at 2022-06-20 21:22:09.960395
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-20 21:22:44.699059
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import mock

    module = mock.MagicMock(spec=AnsibleModule, params=dict())
    module.fail_json.side_effect = Exception('fail_json')
    module.warn = mock.MagicMock()

    # Shouldn't warn
    check_command(module, 'ls')
    assert module.warn.called is False

    # Should warn the lineinfile module replaces sed
    check_command(module, 'sed -i')
    assert module.warn.called is True
    args, kwargs = module.warn.call_args
    assert 'lineinfile' in args[0]

    # Should warn to use the yum module with rpm

# Generated at 2022-06-20 21:22:58.246503
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ['/usr/bin/curl'])
    check_command(module, ['/usr/bin/wget'])
    check_command(module, ['/usr/bin/chmod'])
    check_command(module, ['/usr/bin/chown'])
    check_command(module, ['/usr/bin/chgrp'])
    check_command(module, ['/usr/bin/ln', '-s'])
    check_command(module, ['/usr/bin/mkdir'])
    check_command(module, ['/usr/bin/rmdir'])
    check_command(module, ['/usr/bin/rm'])
    check_command(module, ['/usr/bin/svn'])
    check

# Generated at 2022-06-20 21:23:09.227765
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, ["chown", "fred", "foo"])
    assert module.warnings == ['Consider using the file module with owner rather than running \'chown\'.  '
                               'If you need to use \'chown\' because the file module is insufficient you can add '
                               "'warn: false' to this command task or set 'command_warnings=False' in the "
                               "defaults section of ansible.cfg to get rid of this message."]

    check_command(module, ["mkdir", "bar"])

# Generated at 2022-06-20 21:23:13.588296
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    assert check_command(m, "command") == None
    assert m.warn.called


# ===========================================
# Main control flow



# Generated at 2022-06-20 21:23:18.241713
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={
        'command': dict(type='str', default='yum update'),
        },
    )
    commandline = 'yum update'
    check_command(module, commandline)


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:23:25.708362
# Unit test for function main
def test_main():
    args = dict(_raw_params='echo hello', _uses_shell=True, executable='/bin/sh')
    r = dict(changed=False, stdout='', stderr='', rc=None, cmd=None, start=None, end=None, delta=None)
    r['cmd'] = '/bin/sh'
    r['start'] = '2017-09-30 06:47:38.574562'
    r['end'] = '2017-09-30 06:47:38.576590'
    r['delta'] = '0:00:00.002028'
    r['stdout'] = 'hello'
    r['rc'] = 0
    assert main(args) == r
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:38.802742
# Unit test for function main
def test_main():
    import sys
    import json

    # Save the original arguments so we can restore them in finally
    orig_args = list(sys.argv)


# Generated at 2022-06-20 21:23:50.482512
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls',
        _uses_shell=False,
        argv=['ls'],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
    )
    r = dict(
        changed=False,
        msg='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        stdout='',
        stderr='',
    )

# Generated at 2022-06-20 21:24:00.324306
# Unit test for function check_command
def test_check_command():
    """
        This function is used to test check_command() function
    """
    module = AnsibleModule(
        argument_spec=dict(
            commandline=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    from ansible.cli import CLI
    from ansible.utils.display import Display
    cli = CLI(args=[])
    cli.options.verbosity = 4
    display = Display()
    display.verbosity = 4
    cli.options.inventory = "/dev/null"
    module.DeprecationWarning = cli.display.warning
    module.ActiveWarnings = cli.display.warning

    check_command(module, 'cat /etc/hosts')
    check_command(module, 'chgrp group_name /etc/hosts')
   

# Generated at 2022-06-20 21:24:15.133670
# Unit test for function check_command
def test_check_command():
    import json
    import collections

    commandline = ['curl', '-s', '-S', '-L', '--connect-timeout', '10', '--retry', '3', '--retry-delay', '1', '-X', 'GET',
                   '-o', '/tmp/foo.txt', '-w', '%{http_code}', 'http://www.google.com/']
    args = collections.namedtuple('args', ['module'])
    args.module = AnsibleModule(argument_spec={})
    check_command(args.module, commandline)
    check_command(args.module, ' '.join(commandline))


# Generated at 2022-06-20 21:24:45.840542
# Unit test for function main
def test_main():
    r = {}
    r['changed'] = False
    r['stdout'] = ''
    r['stderr'] = ''
    r['rc'] = None
    r['cmd'] = None
    r['start'] = None
    r['end'] = None
    r['delta'] = None
    r['msg'] = ''

# Generated at 2022-06-20 21:24:52.046315
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.warns = []
            self.params = {}
        def warn(self, msg):
            self.warns.append(msg)

    testmod = TestModule()

    print("Test check_command with curl")
    check_command(testmod, ["curl", "-d", "test", "localhost"])
    assert("Consider using the uri or get_url module rather than running 'curl'."
           in testmod.warns[len(testmod.warns)-1])
    assert("If you need to use 'curl' because the uri or get_url module is insufficient you can add"
           in testmod.warns[len(testmod.warns)-1])

    print("Test check_command with service")

# Generated at 2022-06-20 21:25:00.249162
# Unit test for function main

# Generated at 2022-06-20 21:25:09.193910
# Unit test for function main

# Generated at 2022-06-20 21:25:19.842388
# Unit test for function main
def test_main():
    file_args = {'_raw_params': 'cat /etc/motd', 'chdir': '', 'creates': '', 'removes': '', '_uses_shell': False, 'argv': None, 'executable': None}
    r = {"cmd": ['cat', '/etc/motd'], "changed": True, "stdout": '', "stderr": '', "rc": 0, "start": '', "end": '', "delta": '', "msg": '', "warnings": [u"[DEPRECATED]: 'warn' is deprecated.  Use 'warnings' instead"]}
    file_module = AnsibleModule(argument_spec=dict(file_args))
    test_result = main()
    # assert if test_result == r:
    #     print("Test succeeded")
    # else:


# Generated at 2022-06-20 21:25:26.849901
# Unit test for function main
def test_main():

    # create mock object
    test_object = type('', (object,), {})()
    test_object._raw_params = 'echo hello'

    # set up return object
    test_dict = dict(
        changed=True,
        msg='',
        rc=0,
        start='',
        end='',
        delta='',
        stdout='hello\n',
        stderr='',
        cmd='echo hello'
    )

    # mock the return of the function
    def mock_run_command(args=None, executable=None, use_unsafe_shell=None, encoding=None, data=None, binary_data=None):
        return 0, 'hello\n', ''

    # mock the function
    def mock_exit_json(*args, **kwargs):
        return True

    # mock the exit

# Generated at 2022-06-20 21:25:43.179313
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            warn=dict(type='bool', default=True),
            cmd=dict(),
            argv=dict(type='list'),
            executable=dict(),
            _uses_shell=dict(type='bool'),
            chdir=dict(type='path'),
            _raw_params=dict(),
            _raw_params_list=dict(type='list'),
        ),
        add_file_common_args=True,
        supports_check_mode=True
    )
    commandline = ['yum', '-y', 'install', 'python3']
    check_command(module, commandline)
    commandline = ['yum', '-y', 'remove', 'python2']
    check_command(module, commandline)

# Generated at 2022-06-20 21:25:46.658152
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({
        'command' : 'chown kranthi /tmp/file'
    })
    check_command(module, 'chown kranthi /tmp/file')



# Generated at 2022-06-20 21:25:57.663827
# Unit test for function main
def test_main():
    args = {'_raw_params': 'ansible-galaxy install galaxy.test',
            '_uses_shell': True,
            '_ansible_check_mode': False,
            '_ansible_verbosity': 3,
            'argv': None,
            'chdir': None,
            'creates': None,
            'executable': None,
            'removes': None,
            'warn': True}

    from ansible.module_utils.basic import AnsibleModule
    module=AnsibleModule(**args)
    import pdb; pdb.set_trace()
    try:
        main()
    except:
        import pdb; pdb.set_trace()


if __name__ == '__main__':
    # Unit test to check above code
    #test_main()
    main

# Generated at 2022-06-20 21:26:01.414594
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str'),
            _uses_shell=dict(type='bool', default=False)
        ),
        supports_check_mode=True,
    )
    mod.params['_raw_params'] = 'date'
    main()

# Test module-less execution of main
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:53.193262
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(type='str', default='ls'),
            _uses_shell=dict(type='bool', default=False),
        ),
        supports_check_mode=False,
    )

    m.run_command = lambda *args, **kwargs: (0, 'stdout', 'stderr')

    set_module_args(dict(
        _raw_params='ls',
    ))

    main()
    out = m.exit_json.call_args[0][0]
    assert out['stderr'] == 'stderr'


# Generated at 2022-06-20 21:27:01.624221
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils._text import to_native, to_text
    # return code, stdout, stderr
    cmd_result = [0, 'hello world', '']

    def run_command(args, **kwargs):
        return cmd_result


# Generated at 2022-06-20 21:27:15.459737
# Unit test for function main
def test_main():
    import json
    import os
    import tempfile

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    def adjust_argv(argv):
        # argv will depend on the current shell and the environment.
        # this adjusts the argv for the test environment
        argv = list(argv)
        if os.path.exists('/usr/bin/python2'):
            argv[0] = '/usr/bin/python2'
        else:
            if os.path.exists('/usr/bin/python3'):
                argv[0] = '/usr/bin/python3'
        return argv

    def check_result(cmd, result, **kwargs):
        assert result['rc'] == 0
       

# Generated at 2022-06-20 21:27:25.483270
# Unit test for function main
def test_main():
    # mimic arguments for the args param for the command module
    args = "/bin/ls /root/boundfiles"

    # mimic arguments for the term param for the ansible module
    # module. params is a dictionary that is passed to the ansible module
    module_params = {'_raw_params':args,
                     '_uses_shell':False,
                     'chdir':'/root/',
                     'executable':None,
                     'creates':'/root/boundfiles/baz',
                     'removes':None,
                     'warn':False,
                     'stdin':None,
                     'stdin_add_newline':True,
                     'strip_empty_ends':True}

    # we mimic the ansible class

# Generated at 2022-06-20 21:27:31.910548
# Unit test for function main
def test_main():

    args = dict(
        chdir='/usr/local',
        cmd='/usr/bin/make_database.sh db_user db_name creates=/path/to/database'
    )

    check_command(module, args)


if '__main__' == __name__:
    main()

# Generated at 2022-06-20 21:27:42.058439
# Unit test for function check_command
def test_check_command():
    """
    Some unit tests for check_command ansible.module_utils.command.check_command
    """
    mod_args = dict(cmd='/bin/true', warn=True)
    module = AnsibleModule(mod_args)
    msg = 'consider using the {{ mod }} module rather than running \'{{ cmd }}\''
    check_command(module, ['ls', '-ld'])
    check_command(module, ['yum', '-y', 'install', 'git'])
    assert module.warnings[-1] == msg.format(mod='command', cmd='ls -ld')
    assert module.warnings[-2] == msg.format(mod='yum', cmd='yum -y install git')
    assert len(module.warnings) == 2


# Generated at 2022-06-20 21:27:54.844470
# Unit test for function check_command

# Generated at 2022-06-20 21:28:10.887543
# Unit test for function main

# Generated at 2022-06-20 21:28:20.748850
# Unit test for function check_command
def test_check_command():
    check_command(AnsibleModule(argument_spec={'check_command': {'type': 'bool', 'default': False}}),
                  "/usr/bin/chown root /tmp/foo")
    check_command(AnsibleModule(argument_spec={'check_command': {'type': 'bool', 'default': False}}),
                  ["/usr/bin/chmod", "0644", "/tmp/foo"])
    check_command(AnsibleModule(argument_spec={'check_command': {'type': 'bool', 'default': False}}),
                  ["/bin/rm", "-f", "/tmp/foo"])

# Generated at 2022-06-20 21:28:36.870935
# Unit test for function check_command
def test_check_command():
    """ test return of check_command """
    global _ansibullbot_has_run
    _ansibullbot_has_run = 'true'
    m = AnsibleModule(
        argument_spec={},
    )
    m._ansible_debug = True
    cmnd = ['/bin/echo', 'hello']
    check_command(m, cmnd)
    assert _ansibullbot_has_run == 'true'
    _ansibullbot_has_run = 'true'
    cmnd = 'echo hello'
    check_command(m, cmnd)
    assert _ansibullbot_has_run == 'true'
    _ansibullbot_has_run = 'true'
    cmnd = ['/bin/mount', '-a']
    check_command(m, cmnd)
   