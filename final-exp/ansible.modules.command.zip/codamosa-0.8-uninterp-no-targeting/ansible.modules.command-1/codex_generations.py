

# Generated at 2022-06-20 21:19:46.590918
# Unit test for function main

# Generated at 2022-06-20 21:20:00.653763
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleModule
    class FakeModule(object):
        def __init__(self):
            self.warns = []
        def warn(self, msg):
            self.warns.append(msg)
    module = FakeModule()
    check_command(module, 'touch /tmp/test')
    assert len(module.warns) == 2
    assert 'ansible.builtin.file' in to_text(module.warns[0])
    assert 'ansible.builtin.get_url' in to_text(module.warns[1])


# Generated at 2022-06-20 21:20:09.224125
# Unit test for function main
def test_main():
    import ansible.utils
    from ansible.module_utils.basic import AnsibleModule

    ansible.utils.get_config_type = lambda *args, **kwargs: ''


# Generated at 2022-06-20 21:20:19.741661
# Unit test for function check_command
def test_check_command():
    """Validate check_command function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    # Test command and arguments
    module.params['args'] = 'touch /tmp/test_check_command'
    print(module.params)

    check_command(module, module.params['args'])
    check_command(module, shlex.split(module.params['args']))
    module.params['args'] = ['touch', '/tmp/test_check_command']
    check_command(module, module.params['args'])

    # Test commands

# Generated at 2022-06-20 21:20:29.070046
# Unit test for function main
def test_main():
    import mock
    import os

    os.environ["ADMIN_EMAIL"] = "admin@example.com"
    os.environ["HOST_URL"] = "www.example.com"
    os.environ["SYSTEM_VERSION"] = "2.0.0"
    os.environ["DATA_PATH"] = "/data"

    with mock.patch.object(AnsibleModule, "run_command") as mock_module, \
         mock.patch.object(AnsibleModule, "exit_json") as mock_exit_json, \
         mock.patch.object(AnsibleModule, "fail_json") as mock_fail_json:

        class AnsibleModuleTest(AnsibleModule):
            '''Override AnsibleModule to provide arguments needed by our main test'''

# Generated at 2022-06-20 21:20:32.993133
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default='cmd'),
            _uses_shell=dict(default=False, type='bool'),
            argv=dict(type='list'),
            chdir=dict(),
            executable=dict(),
            creates=dict(),
            removes=dict(),
            warn=dict(default=False, type='bool'),
            stdin=dict(),
            stdin_add_newline=dict(default=True, type='bool'),
            strip_empty_ends=dict(default=True, type='bool'),
        ),
        supports_check_mode=True
    )
    res = main()
    assert res['cmd'] == 'cmd'

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:45.116228
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic
    args = {}
    args['file'] = '/tmp/testfile'
    args['content'] = 'foo'
    args['chdir'] = '/tmp'
    args['check_mode'] = False
    args['diff_mode'] = False
    module = AnsibleModule(**args)

    check_command(module, ['touch', 'a'])
    assert module.warnings[0] == "Consider using the file module with state=touch rather than running 'touch'.  If you need to use 'touch' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

    check_command(module, ['chown', 'a'])

# Generated at 2022-06-20 21:20:51.786064
# Unit test for function main
def test_main():

    # Replaces all calls to exit_json.  side_effect is required to prevent calling exit_json which just ends the test prematurely
    def exit_json(*args, **kwargs):
        return str(args[0])

    # Replaces all calls to fail_json.  side_effect is required to prevent calling fail_json which just ends the test prematurely
    def fail_json(*args, **kwargs):
        return str(args[0])

    # Replaces all calls to AnsibleModule.  side_effect is required to return object for it to be used by the test
    def AnsibleModule(*args, **kwargs):
        class AnsibleModuleMock():
            def __init__(self, *args, **kwargs):
                self.params = kwargs['argument_spec']
                self.check_mode = False


# Generated at 2022-06-20 21:21:01.761325
# Unit test for function main

# Generated at 2022-06-20 21:21:02.360133
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:21:17.660838
# Unit test for function main

# Generated at 2022-06-20 21:21:25.408333
# Unit test for function main
def test_main():
    args = {
        "_raw_params": "ansible",
        "chdir": "/home/ansible",
        "creates": "/home/abc",
        "removes": "/home/xyz",
        "argv": "ansible",
        "_uses_shell": False,
        "warn": False
    }
    r = {
        "changed": False,
        "stdout": "",
        "stderr": "",
        "rc": None
    }
    result = main()
    assert result == r

# Generated at 2022-06-20 21:21:35.374144
# Unit test for function check_command
def test_check_command():
    import sys
    import io
    mod = AnsibleModule(argument_spec={})

    # detect warnings
    sys.stderr = io.StringIO()
    mod.check_command(mod, '/bin/chown foo')
    result = sys.stderr.getvalue()
    assert 'warn: Consider using the file module with owner rather than running \'chown\'' in result
    assert 'warn: Consider using the get_url or uri module rather than running \'curl\'' in result
    assert "warn: Consider using 'become', 'become_method', and 'become_user' rather than running sudo" in result

    sys.stderr = sys.__stderr__


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:21:40.603202
# Unit test for function check_command
def test_check_command():
    os.path.basename = lambda x: x
    module = AnsibleModule(argument_spec={})
    command_list = ['svn', 'service', 'mount', 'rpm', 'yum', 'apt-get',
                    'tar', 'dnf', 'zypper', 'su']
    for x in command_list:
        yield check_command, module, x
        yield check_command, module, [x]



# Generated at 2022-06-20 21:21:52.099787
# Unit test for function main

# Generated at 2022-06-20 21:22:07.675075
# Unit test for function check_command
def test_check_command():
    # Command to run function
    commandline = ['grep', 'pattern', 'filename']
    command = commandline[0]
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-20 21:22:09.171966
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:22:11.762049
# Unit test for function check_command
def test_check_command():
    assert check_command({'warn': lambda x: x}, ['wget']) == None



# Generated at 2022-06-20 21:22:21.284051
# Unit test for function check_command
def test_check_command():
    assert check_command(True, 'mkdir foo') == None
    assert check_command(True, 'rm foo') == None
    assert check_command(True, 'rmdir foo') == None
    assert check_command(True, 'touch foo') == None
    assert check_command(True, 'ln foo') == None
    assert check_command(True, 'chmod foo') == None
    assert check_command(True, 'chown foo') == None
    assert check_command(True, 'svn foo') == None
    assert check_command(True, 'wget foo') == None
    assert check_command(True, 'curl foo') == None
    assert check_command(True, 'service foo') == None
    assert check_command(True, 'mount foo') == None

# Generated at 2022-06-20 21:22:33.107694
# Unit test for function check_command
def test_check_command():
    class ModuleMock(object):
        def __init__(self):
            self.called = []

        def warn(self, msg):
            self.called.append(msg)

    module = ModuleMock()

    check_command(module, ['curl', 'foo'])
    assert 'module is insufficient' in module.called[0]

    module.called = []
    check_command(module, ['wget', 'foo'])
    assert 'module is insufficient' in module.called[0]

    module.called = []
    check_command(module, ['rm', 'foo'])
    assert 'module is insufficient' in module.called[0]

    module.called = []
    check_command(module, ['sed', 'foo'])
    assert 'module is insufficient' in module.called[0]

    module.called

# Generated at 2022-06-20 21:22:53.313570
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    args = dict(
        _raw_params="ls -la",
        _uses_shell=True,
        executable='/bin/bash',
        chdir='/etc/ansible',
        creates='/etc/ansible/apache2.conf',
        removes='/etc/ansible/apache.fake.conf',
        warn=True,
        stdin='foo',
        stdin_add_newline=True,
        strip_empty_ends=False,
    )

    with basic.mocked_command():
        with basic.mocked_module(**args) as m:
            m.run_command.side_effect = [
                (1, 'stderr', 'stdout'),
                (0, 'stderr', 'stdout')
            ]
            run_

# Generated at 2022-06-20 21:22:58.815175
# Unit test for function main
def test_main():
    try:
        # check for windows
        import os, sys
        sys.platform = 'win32'
    except:
        pass

    # case 1: check_mode is not enabled, should return True and rc should be None

# Generated at 2022-06-20 21:23:09.854440
# Unit test for function main
def test_main():
    import json
    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.results = {}
            self._error = False

        def fail_json(self, *args, **kwargs):
            self._error = True
            self.results = kwargs
            self.results['failed'] = True

        def exit_json(self, *args, **kwargs):
            self.results = kwargs
            self.results['failed'] = False


# Generated at 2022-06-20 21:23:21.704891
# Unit test for function main

# Generated at 2022-06-20 21:23:34.606478
# Unit test for function check_command
def test_check_command():
    from ansible.utils import plugin_docs
    # need a module with a warn method
    module = plugin_docs.AnsibleModule({})
    check_command(module, ['test_command'])
    assert module.warn.call_count == 6
    assert "Consider using the become module rather than running test_command." in module.warn.call_args_list[0][0][0]
    assert "Consider using the apt module rather than running test_command." in module.warn.call_args_list[1][0][0]
    assert "Consider using the dnf module rather than running test_command." in module.warn.call_args_list[2][0][0]
    assert "Consider using the file module with chown rather than running test_command." in module.warn.call_args_list[3][0][0]
   

# Generated at 2022-06-20 21:23:46.370315
# Unit test for function main

# Generated at 2022-06-20 21:23:53.178385
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.common._collections_compat import MutableMapping
    module = MutableMapping()
    module.warn = lambda x: x
    commandline = 'echo hello'
    rc = check_command(module, commandline)
    assert rc is None



# Generated at 2022-06-20 21:24:02.710388
# Unit test for function check_command
def test_check_command():
    class AnsibleModuleFake:
        def __init__(self):
            self.params = {}

        def warn(self, msg):
            assert self.params['warn']
            expected = "Consider using the {mod} module rather than running '{cmd}'.  If you need to use '{cmd}' because the {mod} module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
            assert msg.format(mod='file', cmd='chown') == expected.format(mod='file', cmd='chown')
            assert msg.format(mod='get_url or uri', cmd='wget') == expected.format(mod='get_url or uri', cmd='wget')

# Generated at 2022-06-20 21:24:08.054930
# Unit test for function main
def test_main():
  with pytest.raises(AnsibleFailJson) as excinfo:
    main()
  assert 'non-zero return code' in str(excinfo.value)

# --- Ansible action plugin ---


# Generated at 2022-06-20 21:24:16.488995
# Unit test for function main
def test_main():
    def test_main_failure_case(mocked_module_args, mocked_ansible_module, mocked_exception, mocker, mocked_run_command):
        mocker.patch('ansible.module_utils.common.dict_transformations.to_bytes')
        mocker.patch('ansible.module_utils.common.dict_transformations.to_text')
        mocker.patch('os.chdir')
        mocker.patch('shlex.split')
        mocker.patch('glob.glob')
        mocker.patch('ansible.module_utils.basic._ANSIBLE_ARGS', new_callable=dict)

        mocker.patch.object(mocked_ansible_module, 'warn')

# Generated at 2022-06-20 21:24:36.740628
# Unit test for function main
def test_main():
    unit_test = AnsibleModuleMock
    unit_test.params = {'_raw_params': 'cat /etc/motd',
                        '_uses_shell': False,
                        'chdir': None,
                        'creates': '',
                        'removes': '',
                        'warn': True,
                        'stdin': None,
                        'stdin_add_newline': True,
                        'strip_empty_ends': True }
    r = {'changed': False, 'stdout': '', 'stderr': '', 'rc': None, 'cmd': None, 'start': None, 'end': None, 'delta': None, 'msg': ''}
    unit_test.run_command = lambda cmd, executable=None, data=None, binary_data=True:  return_tuple

# Generated at 2022-06-20 21:24:38.768387
# Unit test for function check_command
def test_check_command():
    module=AnsibleModule({})
    check_command(module,'chown')



# Generated at 2022-06-20 21:24:42.670012
# Unit test for function check_command
def test_check_command():
    commandline = ['/usr/bin/svn', 'info']
    command = commandline[0]
    command = os.path.basename(command)
    assert command == 'svn'



# Generated at 2022-06-20 21:24:43.973221
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:55.013935
# Unit test for function main
def test_main():
    import os
    import sys
    import ansible.constants
    ansible.constants.HOST_KEY_CHECKING = False
    ansible.constants.ANSIBLE_FORCE_COLOR = False
    to_bytes = lambda s: s if isinstance(s, bytes) else s.encode('utf-8')
    stdin = to_bytes("helloworld") if sys.version_info[0] < 3 else "helloworld"

# Generated at 2022-06-20 21:25:07.091460
# Unit test for function check_command
def test_check_command():

    class TestModule(object):
        def __init__(self):
            self.warn_count = 0

        def warn(self, msg):
            self.warn_count += 1

    module = TestModule()
    check_command(module, 'curl')
    check_command(module, 'wget')
    check_command(module, 'svn')
    check_command(module, 'service')
    check_command(module, 'mount')
    check_command(module, 'rpm')
    check_command(module, 'yum')
    check_command(module, 'apt-get')
    check_command(module, 'tar')
    check_command(module, 'unzip')
    check_command(module, 'sed')
    check_command(module, 'chown')

# Generated at 2022-06-20 21:25:09.406505
# Unit test for function check_command
def test_check_command():
    assert check_command(commandline="xyz") is None



# Generated at 2022-06-20 21:25:13.684307
# Unit test for function main
def test_main():
    import ansible.module_command
    command = ansible.module_command.Command()


# Generated at 2022-06-20 21:25:16.771199
# Unit test for function check_command
def test_check_command():
    check_command(['command1','command2','command3','command4','command5','command6'])

# Generated at 2022-06-20 21:25:26.000491
# Unit test for function main
def test_main():
    import tempfile
    import shutil

    global module, r

    class FakeModule(object):
        def __init__(self):
            self.check_mode = False
            self.fail_json = lambda **kwargs: self.fail(kwargs)

        def fail(self, params):
            self.exited = True
            self.params = params

    class FakeAnsibleModule(object):
        __init__ = FakeModule.__init__
        fail_json = FakeModule.fail_json

        def __call__(self):
            self.exited = False
            return FakeModule()

    class FakeArgs(object):
        def __init__(self, args_list):
            self.args = args_list

        def __getitem__(self, key):
            return self.args[key]

    module = Fake

# Generated at 2022-06-20 21:25:55.643263
# Unit test for function main
def test_main():
    try:
        args = {'removes':'', 'creates':'', 'chdir':'.', 'module_args':{'executable':'', '_uses_shell':True, '_raw_params':'ls -a', 'creates':'', 'removes':'', 'chdir':'.'}, 'strip_empty_ends':True, 'stdin_add_newline':True, 'executable':'', 'stdin':'standard input', '_raw_params':'ls -a', '_uses_shell':True, 'strip_empty_ends':True, 'stdin_add_newline':True}
        main()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-20 21:26:06.891721
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.called = False
            self.warncount = 0

        def warn(self, msg):
            self.called = True
            self.warncount += 1


# Generated at 2022-06-20 21:26:08.109100
# Unit test for function check_command
def test_check_command():
    assert check_command(module, commandline) == arguments



# Generated at 2022-06-20 21:26:23.595272
# Unit test for function check_command
def test_check_command():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    from ansible.module_utils import basic

    # create a temp directory
    tmpdir = tempfile.mkdtemp()
    # create a temp file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # create a fake module like object to call functions
    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            return

        def fail_json(self, msg):
            raise AnsibleModuleFail(msg)

        def warn(self, msg):
            os.write(2, to_bytes(msg + "\n"))

    module = FakeModule()

    # write a test script to tmpdir

# Generated at 2022-06-20 21:26:31.963708
# Unit test for function check_command
def test_check_command():
    cmd = '/bin/chown'
    mock_module = MagicMock(warn_args=[])
    check_command(mock_module, cmd)
    assert mock_module.warn.call_count == 1
    cmd = '/bin/chmod'
    check_command(mock_module, cmd)
    assert mock_module.warn.call_count == 2
    cmd = '/bin/chgrp'
    check_command(mock_module, cmd)
    assert mock_module.warn.call_count == 3
    cmd = '/bin/ln'
    check_command(mock_module, cmd)
    assert mock_module.warn.call_count == 4
    cmd = '/bin/mkdir'
    check_command(mock_module, cmd)
    assert mock_module.warn.call_count == 5

# Generated at 2022-06-20 21:26:38.186966
# Unit test for function main
def test_main():
    r = dict(changed=True, msg='', rc=0)
    id = 'rpms/mypkg-1.130.7-0.x86_64.rpm'
    args = 'rm -f ' + id

# Generated at 2022-06-20 21:26:46.667634
# Unit test for function main
def test_main():
    main(['', '-a', 'uname'])
    main(['', '-a', 'uname', '-e', 'executable=/bin/bash'])
    main(['', '-a', 'uname', '-r'])
    main(['', '-a', 'echo hello'])
    main(['', '-a', 'echo hello', '-b'])
    main(['', '-a', 'echo hello', '-b', '-s'])
    main(['', '-a', 'echo hello; echo world'])
    main(['', '-a', 'echo hello; echo world', '-b'])
    main(['', '-a', 'echo hello; echo world', '-b', '-s'])

# Generated at 2022-06-20 21:26:58.643415
# Unit test for function check_command
def test_check_command():

    class TestModule(object):
        warn = None

        def __init__(self):
            self.warn = []

        def check_command(self, command):
            check_command(self, command)

    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-20 21:27:06.992485
# Unit test for function check_command
def test_check_command():
    # Create a dummy ansible module for testing
    module_args = dict(
        free_form=['ls', '-la'],
        warn="True"
    )
    module = AnsibleModule(argument_spec=module_args)
    check_command(module, module.params.get('free_form'))


# Generated at 2022-06-20 21:27:10.009290
# Unit test for function main
def test_main():
    r = main()
    print(r)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:27:57.625411
# Unit test for function check_command
def test_check_command():
    arguments = {'chown': 'owner', 'chmod': 'mode', 'chgrp': 'group',
                 'ln': 'state=link', 'mkdir': 'state=directory',
                 'rmdir': 'state=absent', 'rm': 'state=absent', 'touch': 'state=touch'}

# Generated at 2022-06-20 21:28:13.416577
# Unit test for function check_command
def test_check_command():
    cm = AnsibleModule(argument_spec={'cmd': dict(type='str'), 'warn': dict(type='bool', default=True)},
                       supports_check_mode=True)
    commandline = 'chdir /path/to/file'
    check_command(cm, commandline)
    commandline = 'chmod 0755 /path/to/file'
    check_command(cm, commandline)
    commandline = 'chgrp mygroup /path/to/file'
    check_command(cm, commandline)
    commandline = 'chown owner /path/to/file'
    check_command(cm, commandline)
    commandline = 'curl http://somesite.com/'
    check_command(cm, commandline)
    commandline = 'wget http://somesite.com/'

# Generated at 2022-06-20 21:28:18.944713
# Unit test for function check_command
def test_check_command():

    class TestModule(object):
        def __init__(self):
            self.called = False

        def warn(self, msg):
            self.called = True

    module = TestModule()
    check_command(module, 'rm /tmp')
    assert module.called

    module = TestModule()
    check_command(module, ['service', 'httpd', 'start'])
    assert module.called



# Generated at 2022-06-20 21:28:25.808678
# Unit test for function check_command
def test_check_command():
    # Create a module for testing
    from ansible.modules.commands import command

    module = AnsibleModule(argument_spec={})

    command_list = ['curl', 'http://www.example.com']
    check_command(module, command_list)

    command_list = ['wget', 'http://www.example.com']
    check_command(module, command_list)

    command_list = ['svn', 'checkout', 'http://www.example.com']
    check_command(module, command_list)

    command_list = ['service', 'apache2', 'stop']
    check_command(module, command_list)

    command_list = ['mount', '/dev/sdb1', '/media/data']
    check_command(module, command_list)


# Generated at 2022-06-20 21:28:29.775000
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    mock_command = ""
    check_command(module, mock_command)



# Generated at 2022-06-20 21:28:40.142466
# Unit test for function main

# Generated at 2022-06-20 21:28:56.422994
# Unit test for function main
def test_main():
    import logging
    import os
    import re
    import shutil
    import tempfile
    from ansible.module_utils.basic import EnvironmentConfig
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import StringIO

    # Get environment variables and create temp files
    test_dir = tempfile.mkdtemp()
    env = os.environ.copy()
    env["ANSIBLE_STDOUT_CALLBACK"] = "json"
    env["PYTHONUNBUFFERED"] = "1"
    env["ANSIBLE_LOG_PATH"] = os.path.join(test_dir, "test.log")
    # Create test file
    args_file = os.path.join(test_dir, "args")

# Generated at 2022-06-20 21:29:00.264514
# Unit test for function check_command
def test_check_command():
    fqdn = 'fake-host'
    connection = 'local'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    check_command(module, 'sed')
    assert module.warn.called



# Generated at 2022-06-20 21:29:06.752660
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "/bin/chmod +x file.py")
    check_command(module, ["/bin/chmod", "+x", "file.py"])
    check_command(module, "/bin/chown me:root file.py")
    check_command(module, ["/bin/chown", "me:root", "file.py"])
    check_command(module, "/bin/ln -s file.py link.py")
    check_command(module, ["/bin/ln", "-s", "file.py", "link.py"])
    check_command(module, "/bin/touch file.py")
    check_command(module, ["/bin/touch", "file.py"])

# Generated at 2022-06-20 21:29:18.642400
# Unit test for function check_command
def test_check_command():
    # Static params, we are not running the module, just want to test the check
    params = dict(
        warn=True,
        changed=False,
        command=None,
        argv=None
    )
    cmd = 'git clone ssh://git@github.com/ansible-collections/community.general.git'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Test function to see if it raises warnings as expected
    check_command(module, cmd)
