

# Generated at 2022-06-20 21:19:45.938731
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    

# Generated at 2022-06-20 21:20:01.496540
# Unit test for function check_command
def test_check_command():
    """
    Test check command function corner cases
    """
    class FakeModule(object):
        def __init__(self):
            self.warnings = []
            self.params = {}

        def warn(self, warning):
            self.warnings.append(warning)
    fake_module = FakeModule()
    # Check that it warns on first occurrence of curl
    check_command(fake_module, 'curl')
    assert len(fake_module.warnings) == 1
    assert "curl" in fake_module.warnings[0]
    check_command(fake_module, 'curl')
    assert len(fake_module.warnings) == 1
    check_command(fake_module, 'svn')
    assert len(fake_module.warnings) == 2

# Generated at 2022-06-20 21:20:05.004246
# Unit test for function main
def test_main():
    argv = 'ansible-playbook test.yml'
    script_args = argv.split()
    module = AnsibleModule(argument_spec=dict())
    module.run_command([script_args[0], '-h'])

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:12.124727
# Unit test for function main
def test_main():
    current_dir = os.getcwd()
    command_module_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(command_module_dir)
    try:
        # enable loading the module
        os.environ['ANSIBLE_LIBRARY'] = os.path.join(command_module_dir, '..', 'library')
        os.environ['ANSIBLE_MODULE_UTILS'] = os.path.join(command_module_dir, '..', 'module_utils')
        main()
    finally:
        os.chdir(current_dir)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 21:20:21.677159
# Unit test for function main
def test_main():
    # The module_utils import forces the plugin to load otherwise it will not be a valid module in Ansible
    from ansible.module_utils.common.collections import ImmutableDict
    module_args = dict(
            _raw_params="uptime",
            warn=True
        )
    # Create a MagicMock object to replace the builtin open function and
    # return the desired result
    mock_open = MagicMock(return_value=MagicMock())
    # This makes the mock_open call appear as it was a call to open
    with patch("__builtin__.open", mock_open, create=True):
        # Call the main function with the MagicMock object as input
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:25.498861
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    check_command(module, "echo hello")
    check_command(module, "wget hello")
    check_command(module, "sudo echo hello")
    check_command(module, ["echo", "hello"])



# Generated at 2022-06-20 21:20:28.066186
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    commandline = ['chmod']
    check_command(module, commandline)
    command = commandline[0]
    assert command == 'file'



# Generated at 2022-06-20 21:20:29.266630
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:20:42.533821
# Unit test for function main
def test_main():
    import tempfile
    temp_file_path = tempfile.mktemp()
    with open(temp_file_path, 'w') as temp_file:
        temp_file.write("foo bar baz")

    # This should be mocked out
    def run_command(args, executable=None, use_unsafe_shell=False, encoding=None, data=None, binary_data=False):
        return 0, "hello", ""


# Generated at 2022-06-20 21:20:49.150484
# Unit test for function main
def test_main():
    args = {}
    args['_raw_params'] = 'free -m'
    args['_uses_shell'] = True
    args['argv'] = None
    args['chdir'] = None
    args['executable'] = None
    args['creates'] = None
    args['removes'] = None
    args['warn'] = True
    args['stdin'] = False
    args['stdin_add_newline'] = True
    args['strip_empty_ends'] = True
    r = {}
    r['changed'] = False
    r['stdout'] = ''
    r['stderr'] = ''
    r['rc'] = None
    r['cmd'] = None
    r['start'] = None
    r['end'] = None
    r['delta'] = None
    r['msg'] = ''

# Generated at 2022-06-20 21:21:03.864214
# Unit test for function check_command
def test_check_command():
    tested = AnsibleModule(
        argument_spec=dict(),
    )
    check_command(tested, 'ping')



# Generated at 2022-06-20 21:21:14.943090
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import filecmp
    name = "test_main"
    temp_dir = tempfile.mkdtemp()
    print("Created tmp dir {0}".format(temp_dir))


# Generated at 2022-06-20 21:21:27.676639
# Unit test for function main

# Generated at 2022-06-20 21:21:35.150016
# Unit test for function check_command
def test_check_command():
    class Module:
        def __init__(self):
            self.warn_count = 0
            self.warn_list = []
        def warn(self, msg):
            self.warn_list.append(msg)
            self.warn_count += 1

    # Unit tests
    module = Module()
    check_command(module, to_text('echo hello'))
    assert module.warn_count == 0
    check_command(module, to_text('touch foo'))
    assert module.warn_count == 1
    check_command(module, to_text('/bin/chown bar'))
    assert module.warn_count == 2
    check_command(module, to_text('wget http://url/file'))
    assert module.warn_count == 3



# Generated at 2022-06-20 21:21:43.690958
# Unit test for function main

# Generated at 2022-06-20 21:21:45.010191
# Unit test for function main
def test_main():
  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:53.874337
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    check_command(module, 'touch /tmp/foo')
    assert module.warnings[0] == "Consider using the file module with state=touch rather than running 'touch'.  If you need to use 'touch' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    check_command(module, 'rpm -iv http://xxx/xxx/xxx')

# Generated at 2022-06-20 21:22:00.551793
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    test_commands = [ 'curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip', 'sed', 'dnf', 'zypper' ]
    for test_command in test_commands:
        commandline = [test_command]
        check_command(module, commandline)

# Global variables
__metaclass__ = type



# Generated at 2022-06-20 21:22:03.092456
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    assert not check_command(module, '/bin/ls')
    assert not check_command(module, '/bin/cat')
    assert not check_command(module, 'service --status-all | grep httpd')


# Generated at 2022-06-20 21:22:06.979856
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={},
    )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:47.411359
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self, commandline):
            self.commandline = commandline

    class TestModuleWarn(object):
        def __init__(self, commandline):
            self.commandline = commandline
            self.warnings = []

        def warn(self, msg):
            self.warnings.append(msg)

    class TestModuleNoWarn(object):
        def __init__(self, commandline):
            self.commandline = commandline
            self.warnings = []


    module = TestModule(['/bin/echo', 'hello'])
    assert check_command(module, module.commandline) == None
    assert module.warnings == []

    module = TestModule(['/bin/echo', 'hello'])

# Generated at 2022-06-20 21:22:54.896930
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, ModuleFailException

    module_args = dict(
        argv = ['/usr/bin/echo', 'hello', 'world'],
        strip_empty_ends = True
    )
    module = AnsibleModule(argument_spec=dict(**module_args))
    if module._name != 'command':
        raise Exception("Unexpected module name: " + module._name)
    with module.main() as result:
        assert result['stdout'] == "hello world"
        assert result['stderr'] == ""
        assert result['rc'] == 0
        assert result['changed'] == True
    module_args = dict(
        argv = ['/usr/bin/echo', 'hello', 'world'],
        strip_empty_ends = True
    )

# Generated at 2022-06-20 21:23:06.498209
# Unit test for function main
def test_main():
    args = dict(
        _raw_params="command",
        _uses_shell=False,
        argv=['string'],
        chdir="/path/to/dir",
        executable="/path/to/exec",
        creates="/path/to/file",
        removes="/path/to/file",
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=False,
    )
   

# Generated at 2022-06-20 21:23:12.552876
# Unit test for function main
def test_main():
    result = main()
    assert result == """{
  "changed": True,
  "rc": 0,
  "end": "2018-02-11 22:21:35",
  "stdout": "",
  "stdout_lines": [],
  "start": "2018-02-11 22:21:35"
}"""


# Generated at 2022-06-20 21:23:22.914141
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    sys.modules['ansible'] = type('FakeAnsible', (), {'__version__': '2.4.1.0', '__file__': __file__})
    sys.modules['ansible.module_utils'] = basic
    sys.modules['ansible.module_utils.basic'] = basic
    sys.modules['ansible.module_utils._text'] = to_bytes
    sys.modules['ansible.module_utils.common.collections'] = is_iterable
    sys.modules['ansible.module_utils.common'] = is_iterable
    from ansible.module_utils import basic

# Generated at 2022-06-20 21:23:28.993048
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule({}, check_mode=True)
    check_command(module, '/usr/bin/chown foo:bar {}'.format(module.params['path']))
    check_command(module, '/usr/bin/chmod foo:bar {}'.format(module.params['path']))
    check_command(module, '/usr/bin/chgrp foo:bar {}'.format(module.params['path']))
    check_command(module, '/usr/bin/ln foo:bar {}'.format(module.params['path']))
    check_command(module, '/usr/bin/mkdir foo:bar {}'.format(module.params['path']))
    check_command(module, '/usr/bin/rmdir foo:bar {}'.format(module.params['path']))

# Generated at 2022-06-20 21:23:40.670823
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = lambda x: None
    check_command(module, '/usr/bin/chmod 0755 /etc/hosts')
    check_command(module, '/usr/bin/chown root /etc/hosts')
    check_command(module, '/usr/bin/chgrp root /etc/hosts')
    check_command(module, '/usr/bin/ln -s /etc /etc/rc.d')
    check_command(module, '/usr/bin/mkdir /etc/rc.d/init.d')
    check_command(module, '/usr/bin/rmdir /etc/rc.d/init.d')
    check_command(module, '/usr/bin/rm -f /etc/hosts')

# Generated at 2022-06-20 21:23:51.277456
# Unit test for function main
def test_main():
    from ansible.modules.command import main
    from ansible.module_utils.basic import AnsibleModule
    test1 = {
        "_raw_params": "echo hello",
        "_uses_shell": False,
        "argv": None,
        "chdir": None,
        "creates": None,
        "executable": None,
        "removes": None,
        "stdin": None,
        "stdin_add_newline": True,
        "strip_empty_ends": True,
        "warn": False,
    }
    main(AnsibleModule(argument_spec={}), test1)


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:52.301375
# Unit test for function check_command
def test_check_command():
    assert 0 == 1



# Generated at 2022-06-20 21:24:01.985594
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            creates=dict(type='str'),
            removes=dict(type='str'),
            _raw_params=dict(type='str'),
            _uses_shell=dict(type='bool'),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='str'),
            executable=dict(type='str'),
            stdin=dict(type='str'),
            stdin_add_newline=dict(type='bool'),
            strip_empty_ends=dict(type='bool'),
            warn=dict(type='bool', removed_in_version='2.14'),
        ),
        supports_check_mode=True,
    )
    if not module._socket_path:
        module.exit_json(changed=False)
    main

# Generated at 2022-06-20 21:25:07.492132
# Unit test for function check_command
def test_check_command():
    fake_module = type('module', (object,), {
        'check_mode': False,
        'warn': lambda self, msg: msg,
    })()
    check_command(fake_module, ['echo', 'hello'])
    assert fake_module.warn.call_count == 0
    check_command(fake_module, ['touch', '/tmp/foo.txt'])
    assert fake_module.warn.call_count == 0
    check_command(fake_module, ['chmod', 'a=rwx', '/tmp/a', '/tmp/b'])
    assert fake_module.warn.call_count == 1
    check_command(fake_module, ['chown', 'bob:adm', '/tmp/a', '/tmp/b'])
    assert fake_module.warn.call_count == 2
    check

# Generated at 2022-06-20 21:25:22.850282
# Unit test for function main

# Generated at 2022-06-20 21:25:34.199844
# Unit test for function main

# Generated at 2022-06-20 21:25:45.761763
# Unit test for function main
def test_main():
    # Mock module for function main
    class MockModule():
        def __init__(self):
            self.params = {}
            self.fail_json = Mock()
            self.exit_json = Mock()
            self.check_mode = False
            self.run_command = Mock()
            self.warn = Mock()

    # Mock module for function check_command
    class MockModuleCheckCommand():
        def __init__(self):
            self.params = {}
            self.fail_json = Mock()
            self.exit_json = Mock()
            self.check_mode = False
            self.run_command = Mock()

    # Create instance of MockModule
    mock_module = MockModule()

    # Create instance of MockModuleCheckCommand
    mock_module_check_command = MockModuleCheckCommand()

    # Set module arguments
   

# Generated at 2022-06-20 21:25:51.361375
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    module.warn = lambda x: None
    check_command(module, 'curl http://127.0.0.1/')
    check_command(module, 'rm /tmp/spam')
    check_command(module, 'chmod 0777 /tmp/spam')



# Generated at 2022-06-20 21:25:56.182740
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(
        argument_spec=dict(
        )
    )
    s = os.path.join(os.path.dirname(__file__), 'command_data.py')
    with open(s, 'rb') as f:
        for line in f.readlines():
            check_command(m, line.strip())



# Generated at 2022-06-20 21:26:00.113918
# Unit test for function check_command
def test_check_command():
    # This is not a test.  It is just a place to dump unit tests for
    # the command check.  Remove this when unit tests are added to
    # the tree.
    assert to_text(check_command(['touch'], None)) == to_text(True)
    assert to_text(check_command(['sed'], None)) == to_text(True)



# Generated at 2022-06-20 21:26:09.196037
# Unit test for function check_command
def test_check_command():
    # Fakes test
    class FakeModule(object):
        def __init__(self):
            self.warn_messages = []
            self.deprecations = []

        def warn(self, msg):
            self.warn_messages.append(msg)

        def deprecate(self, msg, date=None, version=None):
            self.deprecations.append((msg, date, version))

    fake_module = FakeModule()
    check_command(fake_module, '/bin/foo')
    assert len(fake_module.warn_messages) == 0
    assert len(fake_module.deprecations) == 0
    check_command(fake_module, ['touch', '/tmp/foo'])
    assert len(fake_module.warn_messages) == 1

# Generated at 2022-06-20 21:26:19.649810
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    module = basic.AnsibleModule({
        '_raw_params': 'echo hello',
        '_uses_shell': False,
        'chdir': None,
        'executable': None,
        'argv': None,
        'creates': None,
        'removes': None,
    })

    setattr(module, 'run_command', lambda *args, **kw: (0, 'stdout', 'stderr'))

    r = main()
    assert r['cmd'] == 'echo hello'
    assert r['stdout'] == 'stdout'
    assert r['stderr'] == 'stderr'
    assert r['rc'] == 0
    assert r['start']
    assert r['end']
    assert r['delta']


# Generated at 2022-06-20 21:26:29.611493
# Unit test for function check_command
def test_check_command():
    from ansible.modules.remote_management.ansible import command
    import mock
    mock_module = mock.Mock()
    command.check_command(mock_module, ['sleep'])
    args, kwargs = mock_module.warn.call_args
    assert "Consider using 'become', 'become_method', and 'become_user' rather than running sleep" in args[0]
    command.check_command(mock_module, ['chown'])
    args, kwargs = mock_module.warn.call_args
    assert "Consider using the file module with owner rather than running 'chown'.  " in args[0]
    command.check_command(mock_module, ['curl'])
    args, kwargs = mock_module.warn.call_args

# Generated at 2022-06-20 21:28:56.965208
# Unit test for function check_command
def test_check_command():
    assert check_command(dict(), None) is None



# Generated at 2022-06-20 21:29:05.068629
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(m, '/bin/rm /tmp/foo')
    assert m.warnings == ['Consider using the file module with state=absent rather than running \'rm\'.  '
                          'If you need to use \'rm\' because the file module is insufficient you can add '
                          "'warn: false' to this command task or set 'command_warnings=False' in the defaults "
                          "section of ansible.cfg to get rid of this message."]

    check_command(m, ['/usr/bin/curl', 'http://www.example.com'])
    assert len(m.warnings) == 2

# Generated at 2022-06-20 21:29:09.401146
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['changed'] is True


# Generated at 2022-06-20 21:29:23.125830
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})

    check_command(module, ['chown', 'root', '/some/path'])
    check_command(module, 'chmod 777 /some/path')
    check_command(module, 'chgrp root /some/path')
    check_command(module, 'ln -s /some/path /some/other/path')
    check_command(module, 'mkdir /some/path')
    check_command(module, 'rmdir /some/path')
    check_command(module, 'rm /some/path')
    check_command(module, 'touch /some/path')
    check_command(module, 'curl http://www.ansible.com')
    check_command(module, 'wget http://www.ansible.com')
    check_command