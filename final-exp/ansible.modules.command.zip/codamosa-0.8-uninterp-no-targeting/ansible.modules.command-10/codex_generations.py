

# Generated at 2022-06-20 21:19:45.992524
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'check_mode': {'type': 'bool'}})
    check_command(module, "touch /etc/test")
    check_command(module, ["touch", "/etc/test"])



# Generated at 2022-06-20 21:20:01.569637
# Unit test for function main

# Generated at 2022-06-20 21:20:08.261980
# Unit test for function check_command
def test_check_command():
    args = dict(cmd='/usr/bin/chown root:bob file')
    module = type('AnsibleModule', (), args)
    check_command(module, '/usr/bin/chown root:bob file')
    assert module.warnings[0] == "Consider using the file module with owner=root group=bob rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."


# Generated at 2022-06-20 21:20:19.314538
# Unit test for function main
def test_main():
    class Args(object):
        def __init__(self):
            self.shell = False
            self.chdir = None
            self.executable = None
            self.creates = None
            self.removes = None
            self.warn = False
            self.stdin = None
            self.stdin_add_newline = True
            self.strip_empty_ends = True
            self.raw_params = None
            self.argv = None


# Generated at 2022-06-20 21:20:25.625779
# Unit test for function main
def test_main():
    # get input params
    args = {
        '_raw_params': '',
        '_uses_shell': False,
        'argv': [],
        'chdir': '',
        'executable': '',
        'creates': '',
        'removes': '',
        'warn': False,
        'stdin': None,
        'stdin_add_newline': True,
        'strip_empty_ends': True
    }
    # execute function main
    main(args)


# Generated at 2022-06-20 21:20:32.863387
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import os
    import shutil
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../lib'))
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 21:20:45.042785
# Unit test for function main

# Generated at 2022-06-20 21:20:55.540851
# Unit test for function main
def test_main():
    # Make AnsibleModule callable
    class AnsibleModuleFake(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.params = dict()
            self.check_mode = False
            self.called_exit_json = False
            self.called_fail_json = False

        def exit_json(self, **kwargs):
            self.result = kwargs
            self.called_exit_json = True

        def fail_json(self, **kwargs):
            self.result = kwargs
            self.called_fail_json = True


# Generated at 2022-06-20 21:21:02.795825
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(command_warnings=True)
    assert module.warn_args == {'category': UserWarning}
    commandline = "/usr/bin/service"
    check_command(module, commandline)
    warnings = module.warnings
    assert len(warnings) == 1
    assert warnings[0] == "Consider using the service module rather than running 'service'.  If you need to use 'service' because the service module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

    module = AnsibleModule(command_warnings=False)
    assert module.warn_args == {'category': None}
    commandline = "/usr/bin/curl"
    check_command(module, commandline)


# Generated at 2022-06-20 21:21:18.443322
# Unit test for function check_command
def test_check_command():
    test_module = type('M', (object,), dict(warn=print, get_bin_path=lambda x: '/bin/%s' % x))()
    def wn(*args):
        args = [str(a) for a in args]
        return ' '.join(args)
    # A kludge to print the args passed to module.warn()

# Generated at 2022-06-20 21:21:38.345773
# Unit test for function main
def test_main():
    from ansible.modules.commands.command import main
    from ansible.modules.commands.command import check_command
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native, to_bytes, to_text

# Generated at 2022-06-20 21:21:43.806852
# Unit test for function main
def test_main():
    args = dict(
        _uses_shell = False,
        chdir=None,
        executable=None,
        args = "ls",
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True
    )
    module = Mock(params=args)
    r = main()
    assert r['msg'] == "no command given"

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:51.374198
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    for cmd in ['chown', 'chmod', 'chgrp', 'ln', 'mkdir', 'rmdir', 'rm', 'touch', 'curl', 'wget', 'svn', 'service', 'mount', 'rpm', 'yum', 'apt-get', 'tar', 'unzip', 'sed', 'dnf', 'zypper', 'sudo', 'su', 'pbrun', 'pfexec', 'runas', 'pmrun', 'machinectl']:
        check_command(module, [cmd, "something"])



# Generated at 2022-06-20 21:22:01.475943
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 21:22:10.772203
# Unit test for function check_command
def test_check_command():
    # Mock module for call to check_command
    module = type('module', (object,), {
        'warn.call_count': 0,
    })
    setattr(module, 'warn', lambda *args: setattr(module, 'warn.call_count', module.warn.call_count + 1))

    check_command(module, '/usr/bin/chown root:root /tmp/file1')
    assert(module.warn.call_count == 1)

    check_command(module, ['tar', 'xf', '/tmp/archive.tar', '-C', '/tmp'])
    assert(module.warn.call_count == 2)

    check_command(module, '/usr/bin/svn update /opt/myproject')
    assert(module.warn.call_count == 3)


# Generated at 2022-06-20 21:22:20.549671
# Unit test for function main
def test_main():
    test_args = ["ansible-test", "command", "arg1", "arg2", "arg3"]
    with patch.object(sys, 'argv', test_args):
        with patch.object(CommandModule, "exit_json") as mock_exit_json:
            with patch.object(CommandModule, "fail_json") as mock_fail_json:
                with patch.object(CommandModule, "run_command") as mock_run_command:
                    mock_run_command.return_value = 0, "stdout", "stderr"
                    main()
                    mock_exit_json.assert_called_once()
                    mock_run_command.assert_called_once()
                    mock_fail_json.assert_not_called()
    # TODO: how to test default value for arg3?
    #test_args

# Generated at 2022-06-20 21:22:32.986224
# Unit test for function main

# Generated at 2022-06-20 21:22:42.366354
# Unit test for function check_command
def test_check_command():
    import ansible.module_utils.basic

    module = AnsibleModule(
        argument_spec=dict(x=dict(type='str', required=True)),
        supports_check_mode=True,
    )
    check_command(module, "sudo echo")
    assert module.warn.called
    module.warn.assert_called_once_with("Consider using 'become', 'become_method', and 'become_user' rather than running sudo")



# Generated at 2022-06-20 21:22:44.633851
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as ex:
        assert ex.code == 0

# Generated at 2022-06-20 21:22:58.246873
# Unit test for function check_command
def test_check_command():
    class args:
        check = False
    mod = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # No messages
    check_command(mod, './library/command')
    assert mod.warnings == []

    # Warnings
    check_command(mod, 'curl')
    assert len(mod.warnings) == 1

    # Warnings with 'warn: no'
    mod.params['warn'] = False
    check_command(mod, 'curl')
    assert len(mod.warnings) == 1

    # No warning with 'command_warnings = False'
    mod.ansible.cfg.runner.command_warnings = False
    mod.warnings = []
    check_command(mod, 'curl')

# Generated at 2022-06-20 21:23:32.952971
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self.warnings = []

        def warn(self, message):
            self.warnings.append(message)

    test_module = TestModule()
    check_command(test_module, 'wget http://www.example.com/')
    assert len(test_module.warnings) == 1
    assert test_module.warnings[0].startswith('Consider using the get_url')

    test_module = TestModule()
    check_command(test_module, 'rm /tmp/*')
    assert len(test_module.warnings) == 1
    assert test_module.warnings[0].startswith('Consider using the file')

    test_module = TestModule()
    check_command(test_module, 'sudo make install')

# Generated at 2022-06-20 21:23:44.910407
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/usr/bin/make_database.sh db_user db_name',
        creates='/path/to/database'
    )

# Generated at 2022-06-20 21:23:48.328660
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:57.302798
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls',
        chdir='~/',
        executable=None,
        creates=None,
        removes=None,
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True,
    )
    r = dict(
        changed=True,
        stdout='',
        stderr='',
        rc=None,
        cmd=None,
        start=None,
        end=None,
        delta=None,
        msg=''
    )
    print(main(args, r))

if '__main__' == __name__:
    main()

# Generated at 2022-06-20 21:24:09.169364
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    import sys


# Generated at 2022-06-20 21:24:17.137971
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='/usr/bin/whoami',
        _uses_shell=False,
        argv='/usr/bin/whoami',
        chdir='/usr/bin',
        executable='/usr/bin/whoami',
        creates='/usr/bin/whoami',
        removes='/usr/bin/whoami',
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True
    )


# Generated at 2022-06-20 21:24:33.209675
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    check_command(am, 'chmod +x /tmp/test.sh')
    check_command(am, 'chown /tmp/test.sh')
    check_command(am, 'chgrp /tmp/test.sh')
    check_command(am, ['curl', 'http://example.com/test'])
    check_command(am, ['wget', 'http://example.com/test'])
    check_command(am, ['svn', 'update'])
    check_command(am, ['service', 'nginx', 'start'])

# Generated at 2022-06-20 21:24:39.011401
# Unit test for function main
def test_main():
  with patch.object(builtins, 'open') as mock_open:
    instance = mock_open.return_value
    instance.read.return_value = 'some test data'
    assert main(['a', 'b', 'c']) == 0
    assert main(['a', 'b', 'c']) == 0


# Generated at 2022-06-20 21:24:48.729991
# Unit test for function check_command
def test_check_command():

    def _create_module(**kwargs):
        arguments = dict()
        arguments.update(kwargs)
        module = AnsibleModule(argument_spec=dict())
        return module

    module = _create_module()
    check_command(module, '/bin/false')
    assert module._warnings == []

    module = _create_module()
    check_command(module, '/bin/chown')
    assert module._warnings == ['Consider using the file module with owner rather than running \'chown\'.  '
                                'If you need to use \'chown\' because the file module is insufficient you can add '
                                ' \'warn: false\' to this command task or set \'command_warnings=False\' in '
                                ' the defaults section of ansible.cfg to get rid of this message.']

    module = _create_

# Generated at 2022-06-20 21:24:50.189514
# Unit test for function main
def test_main():
    assert main is not None

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:25:30.229418
# Unit test for function main
def test_main():
    import os
    import tempfile
    import ansible.utils
    import ansible.module_utils.common
    import ansible.action
    import ansible.plugins.action
    import ansible.plugins.action.command

    class MockRunner(object):
        def __init__(self):
            self.runner_queue = None

        def run(self, module_name, module_args, tmp, task_vars, *_):
            return ansible.plugins.action.command.ActionModule(tmp, task_vars).run(module_args, tmp, task_vars)

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = os._exit
            self.fail_json = os._exit
            self.check_mode = False
            self.tmp

# Generated at 2022-06-20 21:25:44.479792
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict()
    )
    commandline = ['curl', 'http://example.com/']
    check_command(module, commandline)
    assert module.warnings[0] == "Consider using the get_url or uri module rather than running 'curl'.  " \
                                 "If you need to use 'curl' because the get_url or uri module is insufficient you can add " \
                                 "'warn: false' to this command task or set 'command_warnings=False' in the defaults section " \
                                 "of ansible.cfg to get rid of this message."
    commandline = ['wget', 'http://example.com']
    check_command(module, commandline)

# Generated at 2022-06-20 21:25:55.642183
# Unit test for function main

# Generated at 2022-06-20 21:26:02.488758
# Unit test for function main

# Generated at 2022-06-20 21:26:10.365517
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(required=True),
        )
    )
    module.set_defaults(warnings=[])
    check_command(module, ['echo', 'arg1'])
    assert len(module.warnings) == 1
    assert module.warnings[0] == "Consider using the shell module rather than running 'echo'.  If you need to use 'echo' because the shell module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."


# Generated at 2022-06-20 21:26:26.134567
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    # This is just a minimal smoketest

# Generated at 2022-06-20 21:26:37.243740
# Unit test for function main
def test_main():
    r={}
    agvs=['/usr/bin/make_database.sh', 'db_user db_name']
    executable=None
    shell=False
    creates=None
    removes=None
    warn=False
    stdin=None
    stdin_add_newline=True
    strip=False

    if not shell and executable:
        module.warn("As of Ansible 2.4, the parameter 'executable' is no longer supported with the 'command' module. Not using '%s'." % executable)
        executable = None

    if (not args or args.strip() == '') and not argv:
        r['rc'] = 256
        r['msg'] = "no command given"
        module.fail_json(**r)

    if args and argv:
        r['rc'] = 256

# Generated at 2022-06-20 21:26:52.275525
# Unit test for function main

# Generated at 2022-06-20 21:27:01.276387
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={'commandline': dict(required=True)})
    check_command(m, to_bytes('ls -lah'))
    check_command(m, to_bytes('sudo ls -lah'))
    check_command(m, to_bytes('/bin/ls -lah'))
    check_command(m, to_bytes('/usr/bin/ls -lah'))
    check_command(m, to_bytes('touch /tmp/testfile.txt'))
    check_command(m, to_bytes('chmod u=rw,g=rw,o=r /tmp/testfile.txt'))
    check_command(m, to_bytes('chown foo:bar /tmp/testfile.txt'))
    check

# Generated at 2022-06-20 21:27:04.105947
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
