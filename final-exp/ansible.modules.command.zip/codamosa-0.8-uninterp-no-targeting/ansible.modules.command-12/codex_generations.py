

# Generated at 2022-06-20 21:19:43.274161
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls',
        executable='',
        chdir='',
        creates='',
        removes='',
        warn=False,
        _uses_shell=False,
        argv=[],
        stdin='',
        stdin_add_newline=True,
        strip_empty_ends=True
    )
    module = AnsibleModule(argument_spec=args)
    # TODO: should make function return something
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:19:51.458078
# Unit test for function main
def test_main():
    import json, io

# Generated at 2022-06-20 21:20:01.413578
# Unit test for function main

# Generated at 2022-06-20 21:20:07.742508
# Unit test for function check_command
def test_check_command():
    check_command(AnsibleModule(argument_spec={}), 'foo')
    check_command(AnsibleModule(argument_spec={}), 'wget')
    check_command(AnsibleModule(argument_spec={}), 'apt-get')
    check_command(AnsibleModule(argument_spec={}), 'yum')
    check_command(AnsibleModule(argument_spec={}), 'rm')
    check_command(AnsibleModule(argument_spec={}), 'chown')


# ===========================================
# AnsibleModule boilerplate
#

# Generated at 2022-06-20 21:20:19.271455
# Unit test for function check_command
def test_check_command():
    global AnsibleModule
    module_mock = AnsibleModule.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    check_command(module=module_mock, commandline="echo hello")
    assert module_mock.warn.call_count == 1
    # TODO get warnings to work here
    module_mock = AnsibleModule.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    check_command(module=module_mock, commandline=["echo", "hello"])
    assert module_mock.warn.call_count == 1
    # TODO get warnings to work here

# Generated at 2022-06-20 21:20:28.617759
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    import os
    import sys
    import warnings

    args = {}
    args['_raw_params'] = 'ls /root'
    args['_uses_shell'] = True
    args['chdir'] = None
    args['executable'] = None
    args['creates'] = None
    args['removes'] = None
    args['warn'] = False
    args['stdin'] = None
    args['argv'] = None
    args['strip_empty_ends'] = True
    args['stdin_add_newline'] = True


# Generated at 2022-06-20 21:20:43.540817
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})
    assert check_command(module, 'curl -k google.com')
    assert check_command(module, 'wget -k google.com')
    assert check_command(module, 'svn checkout google.com')
    assert check_command(module, 'service --status-all')
    assert check_command(module, 'mount -a')
    assert check_command(module, 'rpm --rebuilddb')
    assert check_command(module, 'yum list installed')
    assert check_command(module, 'apt-get update')
    assert check_command(module, 'tar -xf foo.tar')
    assert check_command(module, 'unzip -f foo.zip')
    assert check_command(module, 'sed -i "s/foo/bar/"')
   

# Generated at 2022-06-20 21:20:55.114986
# Unit test for function check_command
def test_check_command():
    dummy_module = AnsibleModule(argument_spec=dict())
    check_command(dummy_module, "curl")
    check_command(dummy_module, "ls")
    check_command(dummy_module, "rm")
    check_command(dummy_module, "yum")
    check_command(dummy_module, "dnf")
    check_command(dummy_module, "zypper")
    check_command(dummy_module, "svn")
    check_command(dummy_module, "touch")
    check_command(dummy_module, "sudo")
    check_command(dummy_module, "su")
    check_command(dummy_module, "apt")
    check_command(dummy_module, "pbrun")

# Generated at 2022-06-20 21:21:02.566957
# Unit test for function main
def test_main():
    # Run command
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(default='pwd'),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            stdin=dict(required=False),
            warn=dict(type='bool', default=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:08.041659
# Unit test for function main
def test_main():
    argv = ["cat /etc/motd"]

    args = dict(
        executable = "/bin/sh",
        chdir="/",
        creates="/etc/motd",
        removs="/etc/motd",
        args=argv,
    )

    m = AnsibleModule(**args)
    x = main()
    assert m == x
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:31.966068
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, "chmod u+rwx /path/to/file")
    assert module.warnings == ["Consider using the file module with mode rather than running 'chmod'.  If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."]
    module.warnings = []
    check_command(module, "mv /path/to/src /path/to/dst")

# Generated at 2022-06-20 21:21:41.064780
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='ls -l /',
        executable='/bin/bash',
    )

# Generated at 2022-06-20 21:21:53.333205
# Unit test for function main
def test_main():
    # create a fake ansible module
    class ansibleModule(object):

        def __init__(self):
            self.params = {
                '_raw_params': '',
                '_uses_shell': False,
                'argv': '',
                'chdir': '',
                'executable': '',
                'creates': '',
                'removes': '',
                'warn': False,
                'stdin': '',
                'stdin_add_newline': True,
                'strip_empty_ends': True
            }

            self.check_mode = False

        def fail_json(self, **kwargs):
            self.fail = True
            self.fail_kwargs = kwargs
            return kwargs

        def exit_json(self, **kwargs):
            self.exit

# Generated at 2022-06-20 21:22:03.019446
# Unit test for function main
def test_main():

    import builtins
    import mock
    import json
    import os

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    def load_fixture(file):
        path = os.path.join(os.path.dirname(__file__), 'fixtures', file)
        if os.path.exists(path):
            with open(path) as fh:
                return json.loads(fh.read())


# Generated at 2022-06-20 21:22:12.577680
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec={})
    m.params = {'command': ['/bin/command', 'args']}
    check_command(m, m.params['command'])
    assert not m.fail_json.called
    m.params = {'command': '/bin/command args'}
    check_command(m, m.params['command'])
    assert not m.fail_json.called
    m.params = {'command': ["/bin/command", "args"]}
    check_command(m, m.params['command'])
    assert not m.fail_json.called
    m.params = {'command': "/bin/chown username file"}
    check_command(m, m.params['command'])
    assert not m.fail_json.called


# Generated at 2022-06-20 21:22:13.191773
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-20 21:22:20.625607
# Unit test for function main
def test_main():
    try:
        os.remove("./file.txt")
        os.remove("./file.tmp")
    except:
        pass

    # TODO: check how to make mocks work
    # args = "./file.txt"
    # module.params = dict(
    #     chdir=".",
    #     creates="./file.txt",
    #     removes="./file.txt",
    #     _raw_params="./file.tmp",
    #     _uses_shell=True
    # )
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:32.986917
# Unit test for function main
def test_main():
    import mock
    import base64
    from ansible.module_utils import basic

    class FakeParams(object):
        def get(self, key, default=None):
            if key == '_raw_params':
                return ''
        def getbool(self, key, default=False):
            return False

    # Create a new FakeModule
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = FakeParams()

    # Create a new FakeModule
    patcher = mock.patch(basic.__name__ + '.AnsibleModule', side_effect=FakeModule)
    patcher.start()


# Generated at 2022-06-20 21:22:34.289770
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:22:47.044227
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(type='bool', default=False),
            argv=dict(type='list', elements='str'),
            chdir=dict(type='path'),
            executable=dict(),
            creates=dict(type='path'),
            removes=dict(type='path'),
            warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'),
            stdin=dict(required=False),
            stdin_add_newline=dict(type='bool', default=True),
            strip_empty_ends=dict(type='bool', default=True),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:23:14.611952
# Unit test for function main
def test_main():
    # Test case - check_command
    check_command(module, args = [])
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:16.662488
# Unit test for function main
def test_main():
    assert main() == None, "Return value must be None"

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:23.215167
# Unit test for function main
def test_main():
    module_argv = dict(
            _raw_params='/bin/echo hello',
            _uses_shell=False,
            chdir='/',
            executable=None,
            creates='',
            removes='',
            warn=True,
            strip_empty_ends=True
    )
    module = AnsibleModule(argument_spec={})
    for key in module_argv:
        module.params[key] = module_argv[key]
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:23:25.550302
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    test_command = 'rpm -q'
    check_command(module, test_command)



# Generated at 2022-06-20 21:23:38.637981
# Unit test for function check_command
def test_check_command():
    module = type('AnsibleModule', (object,), {
            "check_mode": False,
            "no_log": False,
            "fail_json": None,
            "warn": None
    })()

    module.warn = lambda msg: msg
    assert check_command(module, 'sudo') == "Consider using 'become', 'become_method', and 'become_user' rather than running sudo"
    assert check_command(module, 'su') == "Consider using 'become', 'become_method', and 'become_user' rather than running su"
    assert check_command(module, 'pbrun') == "Consider using 'become', 'become_method', and 'become_user' rather than running pbrun"

# Generated at 2022-06-20 21:23:48.099866
# Unit test for function check_command
def test_check_command():

    test = AnsibleModule(argument_spec = dict())
    test.warn = lambda x: x
    mock = {'MODULE_ARGS': {'command': "touch foo"}}
    test.params = AnsibleModule.params_to_args(mock['MODULE_ARGS'])

    check_command(test, "echo hello")
    check_command(test, ["echo", "hello"])
    check_command(test, "touch foo")
    check_command(test, ["touch", "foo"])
    check_command(test, "yum -y install foo")
    check_command(test, ["yum", "-y", "install", "foo"])



# Generated at 2022-06-20 21:23:58.785573
# Unit test for function main
def test_main():
    import argparse
    import sys
    import pytest
    import os
    import tempfile

    # Create a temporary file to run the command on.
    tmpdir = tempfile.gettempdir()
    tmpfile_path = os.path.join(tmpdir, "test_file.txt")
    with open(tmpfile_path, "wb") as f:
        f.write(b"test file\n")

    parser = argparse.ArgumentParser(description='Ansible module for running commands on remote nodes',
                                     usage='%(prog)s [options]')
    parser.add_argument('--version', action='version', version='%(prog)s 0.0.1')

    # TODO: stub out sys.argv?

# Generated at 2022-06-20 21:24:10.590974
# Unit test for function main

# Generated at 2022-06-20 21:24:20.116424
# Unit test for function check_command
def test_check_command():
    from ansible.errors import AnsibleError
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    from ansible.modules.commands.command import Command
    from ansible.utils import module_docs
    import datetime
    import os
    import pytest
    import shutil
    import sys

    # Command is a subclass of AnsibleModule, so we just create a new subclass
    # that overrides the check_command function (which is what we are testing)
    class CustomCommand(Command):
        def check_command(self, commandline):
            return True

    module_warn_msg = 'module warning'
    module_fail_msg = 'module failed'
    module_exit_failed = 1



# Generated at 2022-06-20 21:24:31.870434
# Unit test for function check_command
def test_check_command():
    """
    Unit test for command module
    """
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    check_command(module, "tac")
    check_command(module, "rm")
    check_command(module, "svn")
    check_command(module, "ping")
    check_command(module, "mv")
    check_command(module, "tar")
    check_command(module, "curl")
    check_command(module, "wget")
    check_command(module, "ln")
    check_command(module, "touch")
    check_command(module, "rpm")
    check_command(module, "yum")
    check_command(module, "apt-get")
    check_command(module, "unzip")
   

# Generated at 2022-06-20 21:25:24.301750
# Unit test for function main
def test_main():
    # noinspection PyUnresolvedReferences
    from ansible.module_utils import basic

    # set up test environment
    class Options:
        def __init__(self):
            self.host_key_checking = False
            self.forks = 10
            self.become = True
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.diff = False
    basic._ANSIBLE_ARGS = Options()


    # test module
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:25:40.496303
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-20 21:25:53.581349
# Unit test for function check_command
def test_check_command():
    def testwarn(self, msg, *args, **kwargs):
        ''' place to store a message so the unit test can assert on it'''
        self.last_message = msg

    def fakewarn(self, msg, *args, **kwargs):
        '''place to store a message so the unit test can assert on it'''
        self.last_message = msg

    module = AnsibleModule(argument_spec=dict())

    # Inject a warning function into the module.
    # We can't use the normal module.warn because that would issue a deprecation
    # message and fail the test.
    module.last_message = None
    module.warn = testwarn
    check_command(module, 'echo hello')
    # Check that running a 'safe' command did not emit a warning
    assert module.last_message == None

# Generated at 2022-06-20 21:26:07.717872
# Unit test for function main

# Generated at 2022-06-20 21:26:15.872898
# Unit test for function check_command
def test_check_command():
    args = dict(
        commandline='ls -l /root/',
        task_vars={}
    )
    m = AnsibleModule(
        argument_spec={
            'commandline': {'required': True, 'type': 'str'},
        },
    )
    check_command(m, args['commandline'])
    assert m.module_args['commandline'] == args['commandline']



# Generated at 2022-06-20 21:26:28.525872
# Unit test for function main

# Generated at 2022-06-20 21:26:44.104833
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable


# Generated at 2022-06-20 21:26:57.495324
# Unit test for function main
def test_main():
    class TestModule(object):
        def __init__(self):
            self.params = {
                '_uses_shell': False,
                '_raw_params': '',
                'chdir': '/var/tmp/',
                'executable': '',
                'creates': '',
                'removes': '',
                'warn': False,
                'stdin': None,
                'strip_empty_ends': True
            }
            self.check_mode = False
            self.fail_json = lambda **kwargs: self.fail_json_args.update(kwargs)
            self.fail_json_args = {}
            self.exit_json = lambda **kwargs: self.exit_json_args.update(kwargs)
            self.exit_json_args = {}

# Generated at 2022-06-20 21:27:03.775736
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict()
        )
    )
    check_command(module, "touch /file/path")
    check_command(module, ["touch", "/file/path"])



# Generated at 2022-06-20 21:27:05.070546
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:29:01.433082
# Unit test for function main
def test_main():

    import ansible.module_utils.basic
    import ansible.module_utils.common
    import ansible.module_utils.common.collections

    def test_func(self):
        test_func.counter += 1
        return dict(command_warnings=False)

    test_func.counter = 0
    ansible.module_utils.basic.AnsibleModule = mock_objects.MockAnsibleModule
    ansible.module_utils.common.run_command = mock_objects.Mockrun_command
    ansible.module_utils.common.get_config_defined_facts = test_func
    ansible.module_utils.common.collections = collections
    obj = main()
    assert test_func.counter == 1


# Generated at 2022-06-20 21:29:05.031223
# Unit test for function check_command
def test_check_command():
    assert True



# Generated at 2022-06-20 21:29:21.441952
# Unit test for function check_command
def test_check_command():
    module = None
    check_command(module, ['wget', 'http://foo.com'])
    check_command(module, 'wget http://foo.com')
    check_command(module, 'svn co http://foo.com')
    check_command(module, 'service httpd start')
    check_command(module, 'sudo service httpd start')
    check_command(module, 'mount /dev/sdb /mountpoint')
    check_command(module, 'rpm -ivh http://foo.com/bar.rpm')
    check_command(module, 'yum install httpd.x86_64')
    check_command(module, 'apt-get install apache2')
    check_command(module, 'tar -xf /tmp/foo.tar')