

# Generated at 2022-06-20 21:19:47.821216
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-20 21:19:49.571766
# Unit test for function main
def test_main():
    print(main)

# Generated at 2022-06-20 21:20:02.625363
# Unit test for function main

# Generated at 2022-06-20 21:20:04.059598
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    check_command(module, ['/usr/bin/wget'])


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:20:06.070521
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as context:
        main()
    assert context.value.args[0]['changed']

# Generated at 2022-06-20 21:20:18.922299
# Unit test for function check_command
def test_check_command():
    import ansible.module_utils
    print(dir(ansible.module_utils))
    a = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(a=dict()))
    check_command(a, '/usr/bin/rpm')
    check_command(a, '/usr/bin/yum')
    check_command(a, '/usr/bin/wget')
    check_command(a, '/usr/bin/svn')
    check_command(a, '/usr/bin/chown')
    check_command(a, '/usr/bin/curl')
    check_command(a, '/usr/bin/tar')
    check_command(a, '/usr/bin/unzip')
    check_command(a, '/usr/bin/ln')

# Generated at 2022-06-20 21:20:19.835697
# Unit test for function check_command
def test_check_command():
    assert check_command() == None


# Generated at 2022-06-20 21:20:29.189138
# Unit test for function main
def test_main():
    test_module_name = "ansible.builtin.command"
    test_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    # Test case 1:
    # arguments:
    #   _raw_params: ''
    #   _uses_shell: False
    #   argv: [u'sed', '-i', '/test/d']
    #   chdir: 'test_dir'
    #   executable: ''
    #   creates: '/test_dir/test'
    #   removes: '/test_dir/test'
    #   warn: False
    #   stdin: ''
    #   stdin_add_newline: True
    #   strip_empty_ends: True
    # exp:
    #   changed: False
    #   cmd: [u'sed

# Generated at 2022-06-20 21:20:34.980386
# Unit test for function check_command
def test_check_command():
    # Mock
    class MockAnsibleModule():
        def __init__(self, *args, **kwargs):
            self._AnsibleModule__warnings = []
        def warn(self, message):
            self._AnsibleModule__warnings.append(message)
        def get_warnings(self):
            return self._AnsibleModule__warnings
    # Test
    module = MockAnsibleModule()
    commandline = "chmod +x /etc/runme.sh"
    check_command(module, commandline)
    assert "Consider using the file module with mode rather than running 'chmod'." in module.get_warnings()
    assert "If you need to use 'chmod' because the file module is insufficient you can add 'warn: false' to this command task" in module.get_warnings()



# Generated at 2022-06-20 21:20:42.897987
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())
    module.check_command(module, 'echo')
    module.check_command(module, 'chmod 777')
    module.check_command(module, 'chown root')
    module.check_command(module, 'chgrp root')
    module.check_command(module, 'ln -s /')
    module.check_command(module, 'mkdir /')
    module.check_command(module, 'rmdir /')
    module.check_command(module, 'rm /')
    module.check_command(module, 'touch /')
    module.check_command(module, 'curl -O')
    module.check_command(module, 'wget -O')
    module.check_command(module, 'svn co')
    module.check

# Generated at 2022-06-20 21:21:01.845029
# Unit test for function check_command
def test_check_command():
    environment = {'ANSIBLE_HOST_KEY_CHECKING': 'False', 'ANSIBLE_SSH_ARGS': '-C -o ControlMaster=auto -o ControlPersist=60s'}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-20 21:21:04.754708
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    check_command(module, ['dont_warn_me_bro'])



# Generated at 2022-06-20 21:21:08.656980
# Unit test for function main
def test_main():
    inp = dict(
        argv=['ls'],
        check_mode=True,
    )
    m = AnsibleModule(argument_spec=dict())
    try:
        m.exit_json = lambda x: sys.stdout.write(json.dumps(x))
        main()
    except SystemExit:
        pass

# Generated at 2022-06-20 21:21:12.759273
# Unit test for function check_command
def test_check_command():
  import sys

# Generated at 2022-06-20 21:21:24.909397
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import connection
    from ansible.module_utils.common.collections import is_iterable


# Generated at 2022-06-20 21:21:35.970569
# Unit test for function main
def test_main():

    # mock_module is created by Ansible in the unit test template
    # mock_run_command is also created by Ansible in the unit test template
    # mock_get_bin_path is a function created here
    # https://docs.ansible.com/ansible/latest/dev_guide/testing_unit.html#unit-testing-using-a-mock-module-and-run-command
    monkeypatch.setattr(AnsibleModule, 'run_command', mock_run_command)
    monkeypatch.setattr(AnsibleModule, 'get_bin_path', mock_get_bin_path)
    monkeypatch.setenv("PATH", os.pathsep.join(["/fake/bin", "/fake/sbin", "/usr/bin", "/usr/sbin"]))

# Generated at 2022-06-20 21:21:44.039769
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils import basic

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    m = TestModule(check_mode=True, diff=False)
    check_command(m, ['chown', 'bob'])
    m = TestModule(check_mode=True, diff=False)
    check_command(m, ['chmod', '0777'])

# Generated at 2022-06-20 21:21:53.219276
# Unit test for function main
def test_main():

    class AnsibleModuleMock(object):
        """Mocking object for AnsibleModule.
        """
        # pylint: disable=too-few-public-methods
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.check_mode = False
            self.params = {}
            self.return_value = None

        @staticmethod
        def fail_json(**kwargs):
            """
            Fail with the given arguments.
            """
            raise Exception(kwargs)

        @staticmethod
        def exit_json(**kwargs):
            """
            Exit with the given arguments.
            """
            raise Exception(kwargs)


# Generated at 2022-06-20 21:22:02.851407
# Unit test for function main
def test_main():

    import tempfile

    tmpdir = tempfile.mkdtemp(prefix='ansible')
    bin_path = os.path.join(tmpdir, "test_bin")
    with open(bin_path, "w") as f:
        f.write("#!/bin/sh\n")
        f.write("echo SUCCESS")
    os.chmod(bin_path, 0o755)

    test_args = dict(
        _raw_params='echo HELLO > {}'.format(bin_path),
        executable=None,
        chdir=None,
    )

    test_args.update(dict(
        _raw_params='{}'.format(bin_path),
        executable=bin_path,
        chdir=tmpdir,
    ))


# Generated at 2022-06-20 21:22:04.034593
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:22:23.648018
# Unit test for function main
def test_main():
    module_args = dict(
        _raw_params='ls -ltr /',
        _uses_shell=True,
        argv=['ls', '-ltr', '/'],
        chdir=None,
        executable=None,
        creates=None,
        removes=None,
        warn=True,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True
    )
    from ansible.modules.system.command import main
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

# Generated at 2022-06-20 21:22:34.210850
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(command_warnings=True)
    check = check_command(module, 'curl http://www.google.com')
    assert 'Consider using the get_url or uri module rather' in check.get('warnings')[0]
    check = check_command(module, 'wget http://www.google.com')
    assert 'Consider using the get_url or uri module rather' in check.get('warnings')[0]
    check = check_command(module, 'svn update')
    assert 'Consider using the subversion module rather' in check.get('warnings')[0]
    check = check_command(module, 'service apache2 restart')
    assert 'Consider using the service module rather' in check.get('warnings')[0]

# Generated at 2022-06-20 21:22:41.116801
# Unit test for function check_command
def test_check_command():
   commandline = "wget -q --tries=10 --timeout=20 --retry-connrefused -O- http://127.0.0.1:1880/info"
   module = type('', (), {})
   module.warn = lambda x: print(x)
   check_command(module, commandline.split())


# Generated at 2022-06-20 21:22:51.260888
# Unit test for function main
def test_main():
  from ansible.module_utils import basic

# Generated at 2022-06-20 21:23:01.729939
# Unit test for function check_command
def test_check_command():
  module = AnsibleModule(argument_spec={})
  def test_arguments():
    # test with chown
    commandline = "/sbin/chown root:root /etc/passwd"
    check_command(module, commandline)
    result = module.fail_json.called
    assert result is False
    commandline = ["/sbin/chown", "root:root", "/etc/passwd"]
    check_command(module, commandline)
    result = module.fail_json.called
    assert result is False

    # test with chmod
    commandline = "/bin/chmod 0400 /etc/passwd"
    check_command(module, commandline)
    result = module.fail_json.called
    assert result is False

# Generated at 2022-06-20 21:23:10.690962
# Unit test for function check_command
def test_check_command():
    from ansible.module_utils.basic import AnsibleModule
    commandline = ["/usr/bin/make_database.sh", "db_user", "db_name", "creates=/path/to/database"]
    check_command(AnsibleModule, commandline)


# Generated at 2022-06-20 21:23:23.324398
# Unit test for function check_command
def test_check_command():
    class Module:
        def __init__(self, params={}):
            self.params = params
        def warn(self, msg):
            self.warn_msg = msg

    module = Module()
    # Dictionary of input command and expected warning message
    # Note: message is not identical to the one printed in Ansible
    # because the version number is set programmatically in the code

# Generated at 2022-06-20 21:23:29.078931
# Unit test for function check_command
def test_check_command():
    import sys
    import os
    #cmd = os.path.join(os.path.dirname(sys.executable), 'ansible-test')
    cmd = os.path.join(os.path.dirname(__file__), '../../test/ansible-test')
    cmd += " sanity --test command -t 'warn as always' --python %s" % sys.executable
    os.system(cmd)
    cmd = os.path.join(os.path.dirname(__file__), '../../test/ansible-test')
    cmd += " sanity --test command -t 'warn as always with python3' --python3 %s" % sys.executable
    os.system(cmd)


# ===========================================
# Main Control Flow


# Generated at 2022-06-20 21:23:40.706145
# Unit test for function main
def test_main():
    # Dummy variables
    args = '''[
        "echo",
        "hello"
    ]'''


# Generated at 2022-06-20 21:23:44.007189
# Unit test for function main
def test_main():
    # Unit tests do not yet exist for this module
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:18.994541
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    check_command(module, "/usr/bin/chmod")
    check_command(module, "/sbin/service")
    check_command(module, "/usr/bin/make_database.sh")
    check_command(module, "/usr/bin/sudo")
    check_command(module, ["/usr/bin/chmod", "--help"])
    check_command(module, ["/sbin/service", "postgresql", "start"])
    check_command(module, ["./make_database.sh", "username", "dbname", "creates=/path/to/database"])
    check_command(module, ["/usr/bin/sudo", "systemctl", "reload", "nginx"])
    check_command

# Generated at 2022-06-20 21:24:23.370686
# Unit test for function main
def test_main():
    args = dict(
        _raw_params='pwd',
        warn=True,
    )
    module = AnsibleModule(**args)
    try:
        main()
    except SystemExit as e:
        assert e.code == 1


# Generated at 2022-06-20 21:24:34.892575
# Unit test for function main

# Generated at 2022-06-20 21:24:46.384599
# Unit test for function check_command
def test_check_command():
    class FakeAnsibleModule():
        def __init__(self):
            self.message = None
        def warn(self, message):
            self.message = message

    command = ["chown", "foo", "bar"]
    module = FakeAnsibleModule()
    check_command(module, command)
    assert module.message == "Consider using the file module with owner rather than running 'chown'.  If you need to use 'chown' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."

    command = ["chmod", "foo", "bar"]
    module = FakeAnsibleModule()
    check_command(module, command)

# Generated at 2022-06-20 21:24:55.619982
# Unit test for function main
def test_main():
    # slist is a list of strings
    # alist is a list of AnsibleModule(dicts)
    slist = [
        # This test is based on the example in the EXAMPLES section above.
        'ansible.builtin.command /usr/bin/make_database.sh db_user db_name creates=/path/to/database',
        'ansible.builtin.command /usr/bin/make_database.sh db_user db_name creates=/path/to/database chdir=/tmp',
    ]
    for s in slist:
        parsed = AnsibleModule(s, check_invalid_arguments=False)
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:24:58.899395
# Unit test for function check_command
def test_check_command():
    test_module = AnsibleModule({})
    test_commandline = ['echo', 'hello']
    check_command(test_module, test_commandline)


# Generated at 2022-06-20 21:25:06.350190
# Unit test for function main

# Generated at 2022-06-20 21:25:23.295694
# Unit test for function check_command
def test_check_command():
    class TestModule(object):
        def __init__(self):
            self._result = {'warnings': []}
        def warn(self, msg):
            self._result['warnings'].append(msg)
    module = TestModule()
    check_command(module, 'echo "hello"')
    check_command(module, 'yum install python')
    check_command(module, 'sudo yum install python')

# Generated at 2022-06-20 21:25:27.139305
# Unit test for function check_command
def test_check_command():
    m = AnsibleModule(argument_spec=dict(free_form=dict(type='str', required=False),))
    check_command(m, 'yum update')


# Generated at 2022-06-20 21:25:43.364098
# Unit test for function check_command
def test_check_command():
    class ModuleMock:
        def __init__(self, module_name):
            self.module_name = module_name

        def warn(self, msg):
            print(msg)

    module = ModuleMock('ansible.builtin.command')
    check_command(module, 'foo')
    check_command(module, 'touch file')
    check_command(module, 'chown user file')
    check_command(module, 'chgrp group file')
    check_command(module, 'chmod 755 file')
    check_command(module, 'rm file')
    check_command(module, 'rmdir directory')
    check_command(module, 'mkdir directory')
    check_command(module, 'ln new_name exists_name')
    check_command(module, 'pbrun command')


# Generated at 2022-06-20 21:26:10.748110
# Unit test for function main
def test_main():
    return main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:26.575324
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command':{}})
    check_command(module, "rm -rf")
    assert module.warnings[0] == "Consider using the file module with state=absent rather than running 'rm'.  If you need to use 'rm' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    check_command(module, "curl -O")

# Generated at 2022-06-20 21:26:37.292386
# Unit test for function main
def test_main():
    import argparse
    parser = argparse.ArgumentParser()
    args = parser.parse_args()

    # initialize arguments
    args.check = ''
    args.chdir = ''
    args.executable = ''
    args.removes = ''
    args.creates = ''
    args.warn = ''
    args.stdin = ''
    args.stdin_add_newline = True
    args.strip_empty_ends = True

    args._raw_params = "echo hello"
    args._uses_shell = True

    args.argv = ""

    # test when ansible is not checking nor running in shell mode
    args.check = False
    args._uses_shell = False
    r = main()
    assert r['cmd'] == "echo hello"
    assert r['failed'] == False
    assert r

# Generated at 2022-06-20 21:26:52.315917
# Unit test for function main
def test_main():
  invalid_command_value = {}
  invalid_command_value['_raw_params'] = None
  invalid_command_value['_uses_shell'] = False
  invalid_command_value['argv'] = None
  invalid_command_value['chdir'] = None
  invalid_command_value['executable'] = None
  invalid_command_value['creates'] = None
  invalid_command_value['removes'] = None
  invalid_command_value['warn'] = False
  invalid_command_value['stdin'] = None
  invalid_command_value['stdin_add_newline'] = True
  invalid_command_value['strip_empty_ends'] = True
  module_params = {}

# Generated at 2022-06-20 21:26:57.125002
# Unit test for function main
def test_main():
    command = 'ls -al'
    res = main(command, True)
    assert 'stdout' in res
    assert 'stderr' in res
    assert res['rc'] == 0

# Generated at 2022-06-20 21:27:13.127887
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 21:27:19.788176
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec={'command': dict()})
    check_command(module, 'wget https://github.com/ansible/ansible')
    check_command(module, 'yum install ansible')
    check_command(module, 'rm /tmp/test')
    check_command(module, 'sudo -i test')



# Generated at 2022-06-20 21:27:23.414395
# Unit test for function check_command
def test_check_command():
    pass  # Since this function is just generating warnings, we don't need to test it.



# Generated at 2022-06-20 21:27:28.765656
# Unit test for function main
def test_main():
  args = ['hello']
  module = AnsibleModule(argument_spec=dict(_raw_params=dict(), _uses_shell=dict(type='bool', default=False), argv=dict(type='list', elements='str'), chdir=dict(type='path'), executable=dict(), creates=dict(type='path'), removes=dict(type='path'), warn=dict(type='bool', default=False, removed_in_version='2.14', removed_from_collection='ansible.builtin'), stdin=dict(required=False), stdin_add_newline=dict(type='bool', default=True), strip_empty_ends=dict(type='bool', default=True), ))

# Generated at 2022-06-20 21:27:41.738507
# Unit test for function check_command
def test_check_command():
    def test_module(**kw):
        return AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
            **kw
        )
    mod = test_module()
    mod.warn = lambda x: x
    assert check_command(mod, "/bin/echo") is None
    assert check_command(mod, "echo") is None
    assert check_command(mod, ["echo"]) is None
    assert check_command(mod, "ln -s /etc /tmp/test") == "Consider using the file module with state=link rather than running 'ln'.  If you need to use 'ln' because the file module is insufficient you can add 'warn: false' to this command task or set 'command_warnings=False' in the defaults section of ansible.cfg to get rid of this message."
    assert check_

# Generated at 2022-06-20 21:28:33.402081
# Unit test for function main
def test_main():
    # AnsibleModule will easily mock the module_utils functions
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import get_platform

    platform = get_platform()

    # mock the module input parameters
    module_params = dict(
        _raw_params='ifconfig',
        _uses_shell=False,
        argv=['ifconfig'],
        chdir='/root',
        executable='/bin/bash',
        creates='/root/foo',
        removes='/root/bar',
        warn=False,
        stdin=None,
        stdin_add_newline=True,
        strip_empty_ends=True
    )

    # Mock module and execute the function with the above parameters

# Generated at 2022-06-20 21:28:37.227475
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as exec_info:
        main()
    assert exec_info.value.args[0]['changed'] == False

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:28:47.128425
# Unit test for function check_command
def test_check_command():
    import inspect
    import re

    fake_module = FakeModule()

    # Try to make sure that any new commands added to the file are in this list.
    # We try to do this so that we see deprecation warnings when we add new ones
    # so we remember to add them to the docs, etc
    all_commands = []
    in_argument_mapping = False
    in_command_mapping = False
    for line in inspect.getsourcelines(check_command)[0]:
        if 'in arguments' in line:
            in_argument_mapping = True
            continue
        elif 'in commands' in line:
            in_argument_mapping = False
            in_command_mapping = True
            continue
        elif 'become' in line:
            in_command_mapping = False
            continue
       

# Generated at 2022-06-20 21:29:00.705802
# Unit test for function main

# Generated at 2022-06-20 21:29:07.067557
# Unit test for function check_command
def test_check_command():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 21:29:12.790891
# Unit test for function main
def test_main():
    test_dict = {'_raw_params': 'cd $HOME', '_uses_shell': False, 'argv': ['cd', '$HOME'], 'chdir': '$HOME', 'executable': None, 'creates': None, 'removes': None, 'warn': False, 'stdin': None, 'stdin_add_newline': True, 'strip_empty_ends': True}
    test_mod = AnsibleModule(argument_spec={})
    test_mod.params = test_dict
    result = main()
    assert result['msg'] == 'non-zero return code'
    assert result['rc'] == 1
    assert result['stderr'] == 'shell invocation failed: cd $HOME\n'
    assert result['stdout'] == ''

# Generated at 2022-06-20 21:29:24.353003
# Unit test for function main

# Generated at 2022-06-20 21:29:26.353509
# Unit test for function check_command
def test_check_command():
    # set up
    # code under test
    # assertions
    pass
