

# Generated at 2022-06-21 01:34:51.695794
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    ti = TaskInclude(block=block)
    ti.action = 'include'
    ti.statically_loaded = False
    new_me = ti.copy()
    assert new_me.action == 'include'
    assert new_me.statically_loaded == False
    assert isinstance(new_me, TaskInclude)
    assert isinstance(new_me.block, Block)
    assert new_me.block != block
    assert isinstance(new_me.block.parent, TaskInclude)
    assert new_me.block.parent != new_me

# Generated at 2022-06-21 01:34:56.498776
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert task_include.action == ''
    assert task_include.args == {}
    assert task_include.statically_loaded is False

# Generated at 2022-06-21 01:35:04.445541
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play = Play().load({}, variable_manager=None, loader=None)
    host = '192.168.57.3'
    play_context._set_hosts([host])
    play_context.set_host_variable('192.168.57.3', 'foo', 'bar')
    my_task = dict(name='foo', action='include', file='a.yml')
    my_block = Block.load(
            dict(block=[]),
            play=play,
            task_include=None,
            role=None,
            variable_manager=None,
            loader=None,
        )

# Generated at 2022-06-21 01:35:11.975969
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # TaskInclude.load() should not allow any extra arguments
    # other than 'file' and '_raw_params'
    import ansible.playbook.play_context as pc
    import ansible.playbook.play as p
    import ansible.playbook.role as r
    import ansible.playbook.block as b
    import ansible.playbook.task as t
    import ansible.vars.hostvars as h
    import ansible.vars.manager as m
    import ansible.template as tpl
    import ansible.plugins.loader as pl
    import ansible.vars as v
    from ansible.inventory.host import Host

    hvars = h.HostVars(Host(), {})

# Generated at 2022-06-21 01:35:24.759682
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Verify that get_vars(self) take the attributes 'tags' and 'when'
    out of self.vars if 'include'
    '''

    # Test code
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_

# Generated at 2022-06-21 01:35:36.548562
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Simple test to exercise the whole method
    tsi = TaskInclude()
    tsi.args = dict(test1='value1',test2='value2')
    tsi.vars = dict(test3='value3',test4='value4')
    tsi.action = 'include'
    tsi._parent = None
    vars = tsi.get_vars()
    assert vars['test1'] == 'value1'
    assert vars['test2'] == 'value2'
    assert vars['test3'] == 'value3'
    assert vars['test4'] == 'value4'

    # Now override the values of test1, test2 in vars
    tsi.vars = dict(test1='nv1',test2='nv2')
    vars = tsi.get_vars()

# Generated at 2022-06-21 01:35:46.445581
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude

    # Create a task with invalid options to test the check_options
    ti_1 = TaskInclude()
    ti_data_1 = {'action': 'include_role', 'args': {'foo': 1, 'bar': 2}}
    ti_1.load_data(ti_data_1)
    # Try to validate the task and expect an AnsibleParserError
    try:
        ti_1.check_options(ti_1, ti_data_1)
        assert False, "Expected an AnsibleParserError for task with invalid options"
    except AnsibleParserError:
        pass

    # Create a task with valid options to test the check_options
    ti_2 = TaskInclude()

# Generated at 2022-06-21 01:35:52.969508
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Unit test to assert that get_vars is called when the included tasks
    needs the params
    '''
    # Mock TaskInclude instance
    class TaskIncludeMock(TaskInclude):
        def __init__(self):
            pass
        def get_vars(self):
            return {'key1': 'value1'}

    # Mock Block instance
    class BlockMock(Block):
        def __init__(self):
            pass
        def get_vars(self):
            return {'key2': 'value2'}

    # Mock Role instance
    class RoleMock(object):
        def __init__(self):
            pass
        def get_vars(self):
            return {'key3': 'value3'}

    # Create and initialize mocking a Block instance
    block_

# Generated at 2022-06-21 01:35:57.732998
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    check_data = {'action': 'include', 'file': 'test.yml', 'tags': ['a', 'b'], 'when': 'True'}

    ti.preprocess_data(check_data)

# Generated at 2022-06-21 01:36:04.596981
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = {'action': 'include',
            'lines': [['include', ' test_file']],
            'args': {'apply': {'debugger': 'on'},
                     'file': 'test_file',
                     'debugger': 'off'},
            'file': 'test_file',
            'ignore_errors': False,
            'when': 'test_when'}

    ti = TaskInclude()
    ti.load_data(data)

    # check that the class attributes default values are set
    assert ti.action == 'include', 'unexpected action, got %s' % ti.action
    assert ti.args == {'file': 'test_file', 'debugger': 'off'}, "unexpected args, got %s" % ti.args

# Generated at 2022-06-21 01:36:14.947575
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources="localhost")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=None)
    # add a TaskInclude to the play

# Generated at 2022-06-21 01:36:24.288945
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    display = Display()
    display.verbosity = 4

    ti = TaskInclude()

    ti.args = {}
    assert ti.build_parent_block() == ti

    ti.args = {'apply': {}}
    assert ti.build_parent_block()._parent.__class__.__name__ == 'Block'

    ti.args = {'apply': {'block': 'placeholder'}}
    assert ti.build_parent_block()._parent.__class__.__name__ == 'Block'

    ti.args = {'apply': {'block': []}}
    assert ti.build_parent_block()._parent.__class__.__name__ == 'Block'

# Generated at 2022-06-21 01:36:36.492865
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def check_get_vars(action, expected_vars):
        base = dict(action='include', file='abc', var1='abc', var2='abc')
        base[action] = ''
        t = TaskInclude.load(base)
        assert t.get_vars() == expected_vars

    assert TaskInclude.VALID_INCLUDE_KEYWORDS == ('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                                  'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                                  'when')
    check_get_vars('vars', dict(var1='abc', var2='abc'))

# Generated at 2022-06-21 01:36:43.791937
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test that args of the include are present in the vars and that include
    # specific attributes are not
    display = Display()  # Test case do not have access to global display var
    # Dummy parent block
    parent = Block(play=None)
    parent.vars = {'parent_var1': 'value1', 'parent_var2': 'value2'}
    # Create include with action 'include'
    include = TaskInclude(block=parent, role=None)
    include.vars = {'include_var1': 'value1', 'include_var2': 'value2'}
    include.args = {'param1': 'value1', 'param2': 'value2'}
    include.action = 'include'


# Generated at 2022-06-21 01:36:56.904551
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.utils import context_objects as co

    # Simply samples how to use the preprocess_data method directly.
    # We do not check that it does the correct job. This is fully tested
    # by Ansible's test framework.

# Generated at 2022-06-21 01:37:04.931009
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    # check the class constructor
    task = TaskInclude()
    assert type(task) == TaskInclude
    assert task.__class__ is TaskInclude

    # check data setter
    task.set_loader(None)
    task.set_loader(None)
    assert task._loader is None

    # check action getter
    assert task.action == 'include'

    # check method deprecated
    with Display(error=True):
        assert task.get_vars() == dict()

# Generated at 2022-06-21 01:37:14.649635
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Test if TaskInclude() preprocess_data method filters out invalid keywords
    """

    # Valid keywords for include tasks
    valid_include_keywords = frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                        'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                        'when'))

    class FakeTaskInclude(TaskInclude):
        def __init__(self):
            super(FakeTaskInclude, self).__init__()

        @staticmethod
        def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
            ti = FakeTaskInclude()
            task = ti.check

# Generated at 2022-06-21 01:37:24.957411
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # create a task_include
    task_include = TaskInclude()
    # set the value for statically_loaded
    task_include.statically_loaded = Sentinel()
    # the dict attr of the class TaskInclude
    dict_attr = {'action': 'action', 'args': {"file": "file"}, 'name': "name", 'when': "when"}
    # assign a value to _attributes object of task_include
    task_include._attributes = dict_attr
    # make a copy of task_include
    copy = task_include.copy()
    # check that value of dynamically added attr 'statically_loaded'
    # is copied to the new object
    assert task_include.statically_loaded == copy.statically_loaded
    # check that value of dict attr is copied to the new object
    assert task_

# Generated at 2022-06-21 01:37:36.569451
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = dict(action='include', include_tasks=None)
    ti = TaskInclude(block=None, role=None, task_include=None)
    ds = ti.preprocess_data(ds)
    assert 'include_tasks' not in ds

    ds = dict(action='include', ignore_errors=False)
    ti = TaskInclude(block=None, role=None, task_include=None)
    ds = ti.preprocess_data(ds)
    assert 'ignore_errors' in ds

    ds = dict(action='include_role', ignore_errors=False)
    ti = TaskInclude(block=None, role=None, task_include=None)
    ds = ti.preprocess_data(ds)
    assert 'ignore_errors' in ds

#

# Generated at 2022-06-21 01:37:38.247560
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude(block=Block(), role=None, task_include=Task())
    assert t

# Generated at 2022-06-21 01:37:54.975290
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    class FakeAction(object):
        @staticmethod
        def _assert_valid_action_keyword(keyword):
            return keyword

        @staticmethod
        def _assert_valid_action(action):
            return action

    fake_action = FakeAction()
    def assertEqual(a, b):
        assert a == b

    def assertRaises(exc, func, *args, **kwargs):
        try:
            func(*args, **kwargs)
        except exc:
            return
        except Exception as e:
            raise AssertionError('{!r} is not raised: {!r}'.format(exc, e))
        else:
            raise AssertionError('{!r} is not raised'.format(exc))

    # test _assert_valid_action_keyword

# Generated at 2022-06-21 01:38:01.132935
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.playbook.role.include as role_include
    import ansible.playbook.role.tasks as role_tasks
    import ansible.playbook.role as role
    import ansible.playbook.handler as handler
    import ansible.playbook.handler.task_include as handler_task_include

    # Playbook object
    p_obj = Play()
    # PlayContext object
    pc_obj = PlayContext()

    # Block object
    b_obj = block.Block()

    # RoleInclude object
    r_obj = role.Include()

    # RoleTasks object
   

# Generated at 2022-06-21 01:38:10.188555
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # create base block and tasks
    b = Block()

    t0 = Task()
    t0.args = dict(a0=True)

    t1 = Task()
    t1.args = dict(a1=True)

    t2 = Task()
    t2.args = dict(a2=True)

    t3 = Task()
    t3.args = dict(a3=True)
    t3.action = 'include'

    # add tasks to block and set block as parent for tasks
    b.block = [t0, t1, t2, t3]
    for t in b.block:
        t._parent = b

    # test that tasks without parent block have same values for get_vars
    assert t0.get_vars() == t1.get_vars() == t2.get_

# Generated at 2022-06-21 01:38:11.612446
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # It should not raise any error
    TaskInclude()



# Generated at 2022-06-21 01:38:25.150045
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude.load(None)
    assert task is not None

    task = TaskInclude.load({'action': 'include'})
    assert task.action == 'include'

    task = TaskInclude.load({'action': 'include_tasks'})
    assert task.action == 'include_tasks'

    task = TaskInclude.load({'action': 'include_role'})
    assert task.action == 'include_role'

    task = TaskInclude.load({'action': 'import_role'})
    assert task.action == 'import_role'

    task = TaskInclude.load({'action': 'import_tasks'})
    assert task.action == 'import_tasks'

    task = TaskInclude.load({'action': 'include', 'apply': 'yes'})

# Generated at 2022-06-21 01:38:37.220434
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    mock_data = {'action': 'include_role', 'name': 'my_role'}
    mock_data_w_bad_key = {'action': 'include_role', 'name': 'my_role', 'bad_key': 'foo'}
    mock_data_w_many_bad_keys = {'action': 'include_role', 'name': 'my_role', 'bad_key': 'foo', 'another_bad_key': 'bar'}
    mock_data_w_apply = {'action': 'include_role', 'name': 'my_role', 'apply': 'foo'}

    mock_task = TaskInclude()
    assert mock_task.check_options(mock_task.load_data(mock_data), None) is not None
    # No 'file' key and action is import_role

# Generated at 2022-06-21 01:38:44.331624
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager


    p = PlayContext()
    p.remote_addr = '10.1.1.1'
    manager = VariableManager()
    manager.set_inventory(inventory=None)
    manager._extra_vars = dict(ansible_ssh_host='10.1.1.1')
    f = FieldAttribute(
        isa='string',
        default='default',
        name='attr_name'
    )

    manager.set_task_and_variable_override(p=p, loader=None, templar=None, task_vars={'attr_name': 'attr1'})
    manager.set_nonpersistent_

# Generated at 2022-06-21 01:38:57.207028
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Make sure we can load a block in a role with no args
    ds = dict(
        action = 'block',
        block = [],
    )
    t = TaskInclude.load(ds)
    assert isinstance(t, TaskInclude)
    assert len(t.args) == 0
    assert len(t._blocks) == 1
    assert isinstance(t._blocks[0], Block)
    assert len(t._blocks[0].block) == 0

    # Make sure we can load a role with no args
    ds = dict(
        action = 'include_role',
        name = 'test_role',
    )
    t = TaskInclude.load(ds)
    assert isinstance(t, TaskInclude)
    assert len(t.args) == 1

# Generated at 2022-06-21 01:39:01.087430
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t = TaskInclude()
    assert t.preprocess_data({}) == {}
    assert t.preprocess_data({'action': 'include'}) == {'action': 'include'}
    assert t.preprocess_data({'action': 'include_role', 'file': 'foo.yml'}) == \
        {'action': 'include_role', 'file': 'foo.yml'}
    assert t.preprocess_data({'action': 'import_role', 'file': 'foo.yml'}) == \
        {'action': 'import_role', 'file': 'foo.yml'}

# Generated at 2022-06-21 01:39:06.120538
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():   # because base class Task has get_vars, so this testcase needs to cover all methods
    from ansible.playbook.play_context import PlayContext  # import PlayContext for testing purposes
    from ansible.vars.manager import VariableManager  # import VariableManager for testing purposes
    from ansible.parsing.dataloader import DataLoader  # import DataLoader for testing purposes

    context = PlayContext()  # initialize PlayContext for testing purposes
    loader = DataLoader()  # initialize DataLoader for testing purposes
    variable_manager = VariableManager()  # initialize VariableManager for testing purposes

    task_data = dict(
        include='test.yml',
        tags=['test_tag']
    )


# Generated at 2022-06-21 01:39:21.829516
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    correct_output_dicts = [
        dict(action='include', file='/some/file'),
    ]

    tmp_ti = TaskInclude(block=None, role=None, task_include=None)

    for test_dict in correct_output_dicts:
        assert sorted(test_dict.items()) == sorted(tmp_ti.preprocess_data(test_dict).items())

    # file keyword has been renamed to _raw_params
    test_dict = dict(action='include', file='/some/file')
    remaining_keys = set(test_dict.keys()) - set(['action'])
    assert set(tmp_ti.preprocess_data(test_dict).keys()) == remaining_keys

    # file keyword is required for include
    failed_test_dict = dict(action='include')

# Generated at 2022-06-21 01:39:32.853336
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition


# Generated at 2022-06-21 01:39:41.121508
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test method preprocess_data of class TaskInclude.
    This test ensures that method preprocess_data of class TaskInclude
    correctly checks that only allowed keywords are present in the dictionary
    given to it, and raises a AnsibleParserError otherwise.
    '''
    from ansible.plugins.loader import include_tasks_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    display.verbosity = 3
    target_var_manager = VariableManager()
    target_loader = DataLoader()
    include_tasks_loader.find_plugin()

# Generated at 2022-06-21 01:39:51.927464
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

# Generated at 2022-06-21 01:40:01.251466
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test cases for method check_options of class TaskInclude
    '''

# Generated at 2022-06-21 01:40:13.439188
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import yaml
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Test with File
    task_include = yaml.load("""
        include: example.yml
    """)
    ti = TaskInclude.load(task_include)
    assert isinstance(ti, Task), "Failed to create a TaskInclude with file"
    assert not isinstance(ti, AnsibleBaseYAMLObject), "Unexpected YAML object for TaskInclude with file"
    assert isinstance(ti.args['_raw_params'], AnsibleUnsafeText), "Unexpected unsafe_text value for TaskInclude.file"

# Generated at 2022-06-21 01:40:18.921482
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert isinstance(ti, TaskInclude)
    assert isinstance(ti, Task)
    assert ti.action is None
    assert ti.args == dict()
    assert ti.block is None
    assert ti.loop is None
    assert ti.notify is None
    assert ti.when is None
    assert ti.loop_control is None
    assert ti._parent is None
    assert ti._role is None
    assert ti._task_include is None

# Generated at 2022-06-21 01:40:28.641624
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-21 01:40:40.896488
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.definition import RoleDefinition

    fake_block = None
    fake_role = RoleDefinition.load(dict(), None, None, None, None)
    fake_task_include = None

    # All valid args
    data_good = {
        'action': 'include',
        '_raw_params': 'file',
        'apply': {},
    }
    # This test works because the attribute apply is assigned to a matching property.
    # That is why it differs from the previous test where no property is mapped to that attribute
    task = TaskInclude.load(data_good, fake_block, fake_role, fake_task_include)
    assert task.args.keys() == TaskInclude.OTHER_ARGS.union(TaskInclude.BASE)

    # invalid args, should raise exception
    data_

# Generated at 2022-06-21 01:40:49.884968
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Preprocess_data() should throw an error when it encounters an invalid option for include
    task_include = TaskInclude()
    data = dict()
    data['action'] = 'include'
    data['pre_tasks'] = 'some data'
    try:
        task_include.preprocess_data(data)
        raise AssertionError('TaskInclude.preprocess_data() should throw an error when it encounters an invalid option')
    except AnsibleParserError:
        pass
    # Preprocess_data() should throw an error when it encounters an invalid option for include_role
    task_include = TaskInclude()
    data = dict()
    data['action'] = 'include_role'
    data['pre_tasks'] = 'some data'

# Generated at 2022-06-21 01:41:16.274282
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.plugins.action.include_role import ActionModule as include_role

    # Test with an import_role
    def test_import_role(action):
        data = dict(action=action, role='network')
        return TaskInclude.preprocess_data(data, loader=FakeLoader())

    data = test_import_role(include_role.IMPORT_ROLE_NAME)
    assert data['action'] == include_role.IMPORT_ROLE_NAME
    assert data['role'] == 'network'

    # Test with an import_role with a variable
    data = test_import_role(include_role.IMPORT_ROLE_NAME)
    assert data['action'] == include_role.IMPORT_ROLE_NAME
    assert data['role'] == 'network'

    # Test with an import_role with invalid

# Generated at 2022-06-21 01:41:26.378392
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()

    data_without_task_keyword = {'random': 'value'}
    assert data_without_task_keyword == task_include.preprocess_data(data_without_task_keyword)

    data_with_random_task_keyword = {'random': 'value', 'task': 'value'}
    assert data_with_random_task_keyword == task_include.preprocess_data(data_with_random_task_keyword)

    data_with_valid_task_keyword = {'random': 'value', 'task': 'value', 'meta': {'tags': True}}
    assert data_with_valid_task_keyword == task_include.preprocess_data(data_with_valid_task_keyword)

    # These tests do not work because the action

# Generated at 2022-06-21 01:41:38.479548
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # first, create a plain old TaskInclude with no args
    task = TaskInclude()

    # create a valid ds for that task

# Generated at 2022-06-21 01:41:44.212801
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude()

    # Set the task arg and verify it
    t.args = dict(test_key='test_value')
    assert t.args['test_key'] == 'test_value'

    # Test load_data
    ti = TaskInclude.load_data({"include": "test_value"})
    assert ti.args['test_key'] == 'test_value'
    assert ti.action == 'include'

# Generated at 2022-06-21 01:41:56.426921
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    task_ds = {'delegate_to': 'localhost', 'action': 'include'}
    ti = TaskInclude()

    # This is the right way
    ti.check_options(ti.load_data(task_ds), task_ds)
    assert ti.action == 'include'
    assert '_raw_params' in ti.args
    assert ti.args['_raw_params'] == None

    # No 'file' option specified
    task_ds = {'delegate_to': 'localhost', 'action': 'include'}
    ti = TaskInclude()

# Generated at 2022-06-21 01:42:07.400905
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Check if TaskInclude.preprocess_data() can handle an action of 'include'
    """
    import ansible.plugins
    ti = TaskInclude() # Create TaskInclude instance

    # Create fake data.
    ds = {'action': 'include', 'args': {'var1': 'foo', 'var2': 'bar'}, 'action_plugin_config': {
        'class': 'ansible.plugins.action.include',
        'plugin_config': {'lookup_plugins': [
            {'class': 'ansible.plugins.lookup.file', 'plugin_config': {}},
            {'class': 'ansible.plugins.lookup.template', 'plugin_config': {}}
        ]}
    }}

    new_ds = ti.preprocess_data(ds) # Execute function

   

# Generated at 2022-06-21 01:42:13.627772
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-locals
    # pylint: disable=unused-variable
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    # Setup
    play_context = PlayContext()
    play_context._options = {}
    play_context._options['connection_user'] = 'ansible'
    play_context._options['remote_user'] = 'ansible'
    play = Play().load({'name': 'all'}, templar=Templar(loader=None), variable_manager=None)
    loader = None
    variable_manager = None
    role = None

# Generated at 2022-06-21 01:42:14.501087
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pass

# Generated at 2022-06-21 01:42:22.565491
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    """
    Test TaskInclude.copy
    """
    ti = TaskInclude()
    ti.args = {'arg1': 'val1', 'arg2': 'val2', 'arg3': 'val3'}
    ti.vars = {'var1': 'val1', 'var2': 'val2', 'var3': 'val3'}
    ti.action = 'action 1'
    ti.name = 'task name 1'
    ti.statically_loaded = True
    ti.tags = {'tag1', 'tag2', 'tag3'}
    ti.when = 'when value'

    ti2 = ti.copy()
    assert ti2 is not ti
    assert ti2.args == ti.args
    assert ti2.vars == ti.vars
    assert ti2.action == ti.action

# Generated at 2022-06-21 01:42:32.058803
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()
    with pytest.raises(AnsibleParserError) as excinfo:
        task_include.load(dict())
    assert 'No file specified for include' in str(excinfo.value)

    with pytest.raises(AnsibleParserError) as excinfo:
        task_include.load(dict(file='file.yml', invalid_option='invalid'))
    assert 'Invalid options for include: invalid_option' in str(excinfo.value)

    with pytest.raises(AnsibleParserError) as excinfo:
        task_include.load(dict(file='file.yml', apply='invalid'))
    assert 'Expected a dict for apply but got' in str(excinfo.value)


# Generated at 2022-06-21 01:42:55.842210
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {'include': 'something', 'when': 'ok'}
    task = TaskInclude(block=None, role=None, task_include=None)
    out = task.preprocess_data(data)
    assert out['extra_vars'] == {}
    assert out['when'] == 'ok'

# Generated at 2022-06-21 01:43:08.902623
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Global constants and methods used to setup an env for testing
    # _load_tasks and create a task class
    C.INVALID_TASK_ATTRIBUTE_FAILED = False
    C.INVALID_HANDLER_ATTRIBUTE_FAILED = False
    from ansible import errors as ae
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.play_context import PlayContext
    from ansible.config.manager import ConfigManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role


# Generated at 2022-06-21 01:43:18.825172
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text
    import ansible.executor.task_queue_manager as tqm

    class TaskIncludeMock(object):
        def __init__(self, data):
            self.task = TaskInclude(task_include=None).load(data)
            self.data = data

        def __repr__(self):
            return to_text(self.task)

    class DataMock(object):
        def __init__(self, data):
            self._data = data

        def get_data(self):
            return self._data

        def __getitem__(self, k):
            return self._data[k]


# Generated at 2022-06-21 01:43:23.475946
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {'apply': {'block': []}}
    assert task_include.build_parent_block().args == {'block': []}

# Generated at 2022-06-21 01:43:31.802816
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    taskInclude = TaskInclude()
    assert taskInclude.__dict__['BASE'] == frozenset(('file', '_raw_params'))
    assert taskInclude.__dict__['VALID_ARGS'] == frozenset(('file', '_raw_params', 'apply'))
    assert taskInclude.__dict__['VALID_INCLUDE_KEYWORDS'] == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                        'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                        'when'))
    assert taskInclude.__dict__['statically_loaded'] == False

# Generated at 2022-06-21 01:43:39.744831
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import json
    from ansible.playbook.play_context import PlayContext

    # Data Structure

# Generated at 2022-06-21 01:43:49.910005
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:43:57.047663
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude()
    new_task = task.copy()
    assert not hasattr(new_task, '_parent')

    task = TaskInclude()
    task._parent = 'dummy'
    new_task = task.copy()
    assert hasattr(new_task, '_parent')

    task = TaskInclude()
    new_task = task.copy(exclude_parent=True)
    assert not hasattr(new_task, '_parent')

    task = TaskInclude()
    task._parent = 'dummy'
    new_task = task.copy(exclude_parent=True)
    assert not hasattr(new_task, '_parent')


# Generated at 2022-06-21 01:44:06.733204
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test method build_parent_block of class TaskInclude.
    """
    class MockBlock(Block):
        def __init__(self, block=None, play=None, task_include=None, role=None, variable_manager=None, loader=None):
            super(MockBlock, self).__init__(block=block, play=play, task_include=task_include, role=role, variable_manager=variable_manager, loader=loader)

        @staticmethod
        def load(data, block=None, play=None, task_include=None, role=None, variable_manager=None, loader=None):
            return MockBlock(block=block, play=play, task_include=task_include, role=role, variable_manager=variable_manager, loader=loader)

    task_include = TaskInclude()

# Generated at 2022-06-21 01:44:16.391069
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()

    # Test with invalid args
    invalid_data = {'action': 'include', 'no_such_option': 'foo'}
    result = task_include.load(
        invalid_data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert (result.args == {'_raw_params': 'foo'})

    # Test with invalid apply keyword
    invalid_data = {'action': 'include', 'apply': 'foo'}