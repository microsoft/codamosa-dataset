

# Generated at 2022-06-21 01:34:54.373682
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.template import AnsibleTemplate
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.extra_vars = {'a_var': 'a_val'}

    fake_loader = lambda x: dict(
        collections=[],
        vars_files=[],
        defaults=dict(
            a_default='a_default_val'
        )
    )

    # Fake the loader method to get a custom 'options'
    loader.set_basedir('/')
    loader.set_variable_manager(variable_manager)
    loader.set_find_file_in_search_path(fake_loader)

    #

# Generated at 2022-06-21 01:34:58.324775
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_def = dict(action=dict(module='mytest', args='test'))
    task_def['action']['args'] = 'test'
    task = TaskInclude.load(task_def, None, None, None, None)
    test_copy = task.copy(exclude_parent=True)
    assert isinstance(test_copy, TaskInclude)

# Generated at 2022-06-21 01:35:05.149613
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test for method ``TaskInclude.build_parent_block``. This test is purely for
    coverage and does not intend to validate the correctness of the method.
    """
    ti = TaskInclude(block=None, role=None, task_include=None)

    # Test with apply
    ti.args = {
        'apply': {
            'to_ip_list': {'name': 'node-01'}, 'include_roles': {'name': 'common'},
            'tags': ['all'], 'when': 'always'},
        'file': '~/roles/common/tasks/main.yml'
        }
    ti.build_parent_block()

    # Test without apply

# Generated at 2022-06-21 01:35:12.648344
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task_test = Task()

    # 'file' option
    task_test.args = {
        'file': 'test_file',
        'apply': {}
    }
    task = task_include.check_options(task_test, 'data')
    assert task.args['_raw_params'] == 'test_file'

    # '_raw_params' option
    task_test.args = {
        '_raw_params': 'test_file',
        'apply': {}
    }
    task = task_include.check_options(task_test, 'data')
    assert task.args['_raw_params'] == 'test_file'

    # 'file' and '_raw_params' options are mutually exclusive

# Generated at 2022-06-21 01:35:23.435367
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    my_block = Block()
    my_ti = TaskInclude(block=my_block)
    my_ti.statically_loaded = True
    my_ti.action = 'include_role'
    my_ti.statically_loaded = True
    my_ti.args['apply'] = {'block': []}
    new_copy = my_ti.copy()

    assert new_copy.statically_loaded == True
    assert new_copy.action == 'include_role'
    assert new_copy.args['apply'] == {'block': []}
    assert new_copy._parent == my_ti._parent


# Generated at 2022-06-21 01:35:31.150055
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    t0 = TaskInclude()
    t1 = TaskInclude()
    t0.statically_loaded = True
    t1.statically_loaded = False

    t2 = t0.copy()
    t3 = t1.copy()

    assert t0 is not t1 and t0 is not t2 and t0 is not t3 and t1 is not t2 and t1 is not t3
    assert t2 is not t3
    assert t0.statically_loaded
    assert t1.statically_loaded is False
    assert t2.statically_loaded
    assert t3.statically_loaded is False

# Generated at 2022-06-21 01:35:42.149404
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Constructor test
    mytask = TaskInclude()
    assert mytask
    assert mytask.block is None
    assert mytask.role is None
    assert mytask.task_include is None
    assert not mytask.statically_loaded

    myblock = Block()
    mytask = TaskInclude(block=myblock)
    assert mytask.block is myblock
    assert mytask.role is None
    assert mytask.task_include is None
    assert not mytask.statically_loaded

    myrole = Role()
    mytask = TaskInclude(role=myrole)
    assert mytask.block is None
    assert mytask.role is myrole
    assert mytask.task_include is None
    assert not mytask.statically_loaded

    mytaskinclude = TaskInclude()
    mytask = Task

# Generated at 2022-06-21 01:35:54.098946
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import sys

    if sys.version_info >= (3, 0):
        # The module '__builtin__' is not accessible in python3.
        # To test the method preprocess_data of class TaskInclude
        # we need to mock it.
        from unittest.mock import patch
        mock_module = '__builtin__'
    else:
        from mock import patch
        mock_module = '__builtin__'

    from ansible.playbook.task_include import TaskInclude

    obj = TaskInclude()
    task_data_with_unknown_keyword = {"unknown_keyword": "unknown_value"}
    with patch(mock_module + '.display.warning') as mock_display_warning:
        obj.preprocess_data(task_data_with_unknown_keyword)
        mock_

# Generated at 2022-06-21 01:36:04.469969
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    t = TaskInclude(block=Block(play=Play()))

    t.load({"include": "test.json", "apply": { "logging": "info" }})
    assert t.action == "include"
    assert t.get_vars() == { "include": "test.json", "logging": "info"}

    t.args = {}
    t.load({"include": "test.json", "tags": [ "test" ], "apply": { "logging": "info" }})
    assert t.action == "include"
    assert t.get_vars() == { "include": "test.json", "logging": "info"}

    t.args = {}

# Generated at 2022-06-21 01:36:15.802895
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import task_loader, action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader.add_directory(C.DEFAULT_MODULE_PATH)
    task_loader.add_directory(C.DEFAULT_TASK_PATH)
    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)

    context = PlayContext()
    context._vault = VaultLib("")
    context.hostv

# Generated at 2022-06-21 01:36:22.407231
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display.verbosity = 3

    task = TaskInclude()
    loaded_data = task.preprocess_data({'foo': 'bar'})
    assert 'foo' not in loaded_data

# Generated at 2022-06-21 01:36:35.502276
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    assert ti._parent is None
    assert not ti._role
    assert ti._loader is None
    assert ti._variable_manager is None
    assert ti._block is None
    assert ti.action == 'include'
    assert ti.args == dict()
    assert ti.notify is None
    assert isinstance(ti._tmp_path, Sentinel)
    assert ti.run_once is False
    assert not ti.register
    assert ti.ignore_errors is False
    assert ti.always_run is None
    assert ti._context is None
    assert ti.free_form is None
    assert isinstance(ti.dep_chain, Sentinel)
    assert isinstance(ti.loop, Sentinel)
    assert ti.loop_with is None

# Generated at 2022-06-21 01:36:42.654847
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    host = 'localhost'
    playbook = 'test_playbook.yml'
    block = Block()
    display = Display()

    from ansible.playbook.task_include import TaskInclude
    include_task = TaskInclude()
    include_task.display = display
    include_task.action = 'include'
    include_task.args = {'_raw_params' : '/home/vars.yml'}
    include_task.statically_loaded = True
    include_task._parent = block

    new_include_task = include_task.copy()

    assert new_include_task.__dict__ == include_task.__dict__
    assert new_include_task.args == include_task.args
    assert new_include_task._parent == include_task._parent



# Generated at 2022-06-21 01:36:56.332165
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.utils.vars import combine_vars

    dl = DataLoader()
    vm = VariableManager()
    ih = InventoryManager(loader=dl, sources=[])
    play = Play().load({'name': 'foo', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=vm, loader=dl)

    # first test the basic case
    ti = TaskInclude(block=play)
    ti.action = 'include'

# Generated at 2022-06-21 01:37:09.397080
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Testing method load for class TaskInclude.
    '''

    # TODO: refactor test

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    ti = TaskInclude()

    # Test error handling
    # 1. Invalid keyword options

# Generated at 2022-06-21 01:37:14.466766
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    for action in C._ACTION_INCLUDE_TASKS:
        # Test constructor with valid actions
        TaskInclude(action=action, file="foo")

        # Test constructor with the wrong action
        try:
            TaskInclude(action="not-one-of-the-" + action, file="foo")
            assert False
        except ValueError:
            assert True

# Generated at 2022-06-21 01:37:17.947542
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = False

    new_ti = ti.copy()

    assert new_ti.statically_loaded == False

# Generated at 2022-06-21 01:37:23.693203
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # just make sure that doing this doesn't cause an error
    ti = TaskInclude()
    ti.preprocess_data({'action': 'include'})
    ti.preprocess_data({'action': 'include_role'})
    ti.preprocess_data({'action': 'import_tasks'})
    # and make sure that doing this does cause an error
    ti = TaskInclude()
    ti.preprocess_data({'action': 'include', 'foo': 'bar'})

# Generated at 2022-06-21 01:37:36.032387
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    test TaskInclude's method copy
    '''

    # setup a task include
    ti = TaskInclude(block=None, role=None, task_include=None)
    assert ti.is_meta == False
    assert ti.has_triggered == False
    assert ti.loop is None
    assert ti.when is None
    assert ti.changed_when is None
    assert ti.always_run is False
    assert ti.name is None
    assert ti.notify is None
    assert ti.handlers == []
    assert len(ti.vars) == 0
    assert ti.default_vars == []
    assert ti.action is None
    assert ti.args == {}
    assert ti.any_errors_fatal is False
    assert ti.any_errors_fatal is False

# Generated at 2022-06-21 01:37:37.479704
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude(None)
    assert t



# Generated at 2022-06-21 01:37:54.619340
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play = Play().load({
        'name': 'test play',
        'hosts': 'localhost',
        'gather_facts': 'no'
    }, variable_manager=dict(), loader=dict())

    block = Block.load({
        'name': 'test block',
        'block': [
            {
                'include': 'test.yml'
            }
        ]
    }, play=play, task_include=None, role=dict(), variable_manager=dict(), loader=dict())


# Generated at 2022-06-21 01:38:01.279593
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # We create a task with a parent block and include a task with apply
    # This should create a nested block and we need to ensure that the
    # task include vars are taken into account too
    vars1 = dict(a=1, b=2, c=3)
    vars2 = dict(b=42)

# Generated at 2022-06-21 01:38:13.249085
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """ test the TaskInclude.get_vars to include the args"""

    # Create a variable manager for
    variable_manager = DummyVariableManager()

    # Create our fake loader
    loader = DummyLoader()

    # Create our fake play
    play = DummyPlay("test")

    # Create our fake block
    block = Block.load({ "action": "include",
                         "args": { "arg1": "test",
                                   "arg2": "test2" },
                         "tags": [],
                         "when": [] },
                       play=play,
                       task_include=None,
                       variable_manager=variable_manager,
                       loader=loader)

    # Create a task include

# Generated at 2022-06-21 01:38:25.363277
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.vars.manager
    import ansible.vars.option_validator

    # Create a play with no role and no task include
    p = ansible.playbook.play.Play().load(dict(
                name = "test play",
                hosts = 'localhost',
                gather_facts = 'no',
                vars = dict(),
            ), loader=None)
    r = ansible.playbook.role.Role()
    t = ansible.playbook.task.Task()
    ti = ansible.playbook.task_include.TaskInclude()

    # Inject fake objects for the parameter 'loader'

# Generated at 2022-06-21 01:38:37.407725
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    block = Block()
    role = None
    task_include = None

    # Valid options
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    task_data = {
        'action': 'include',
        'file': 'foo.yml',
        'apply': {},
    }
    task = ti.check_options(ti.load_data(task_data), task_data)
    assert isinstance(task, TaskInclude)
    assert task.args['file'] == 'foo.yml'
    assert task.args['_raw_params'] == 'foo.yml'

# Generated at 2022-06-21 01:38:46.915452
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    role = None
    task_include = None
    task_include = TaskInclude(block=block, role=role, task_include=task_include)
    assert task_include.action == 'include'
    # assert task_include.name == 'include'
    assert task_include.tags == tuple()
    assert task_include.when == ()
    assert task_include.post_validate is False
    assert task_include.statically_loaded is False
    assert task_include.has_triggered is False
    assert task_include.triggered_by is None
    assert task_include.loop is None
    assert task_include.notified_by is None
    assert task_include.notify is None
    assert task_include.loop_control is None
    assert task_include.ignore_errors

# Generated at 2022-06-21 01:38:54.655335
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    yaml = """
    - name: test
      include_tasks: test.yml
    """
    task = TaskInclude.load(yaml)
    assert isinstance(task, TaskInclude)
    assert isinstance(task._loader, type(None))
    assert task.action == 'include'
    assert task.args['_raw_params'] == "test.yml"



# Generated at 2022-06-21 01:39:08.333162
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task._parent = Block()
    task._parent.vars = {"a": "b"}
    task.vars = {"c": "d"}
    task.args = {"e": "f"}

    assert task.get_vars() == {"a": "b", "c": "d", "e": "f"}

    task._parent.vars = {"a": "b"}
    task.vars = {"c": "d"}
    task.args = {"e": "f"}
    task.action = "include_role"

    assert task.get_vars() == {"a": "b", "c": "d"}

    task._parent.vars = {"a": "b"}
    task.vars = {"c": "d"}
    task.args = {"e": "f"}


# Generated at 2022-06-21 01:39:19.218568
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    variable_manager = None
    loader = None

    # Test a simple include task
    data = dict()
    data['include'] = 'foobar.yml'
    ti = TaskInclude.load(data)

    assert ti.action == 'include'
    assert ti.args['file'] == 'foobar.yml'
    assert ti.block is None

    # Test an include task with block and with apply
    data = dict()
    data['include'] = 'foobar.yml'
    data['block'] = dict()
    data['block']['rescue'] = []
    data['block']['rescue'].append(dict(action='debug', msg='error'))
    data['apply'] = dict()
    data['apply']['block'] = []

# Generated at 2022-06-21 01:39:23.011656
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded == True

    ti2 = TaskInclude()
    ti2.statically_loaded = False
    new_ti2 = ti2.copy(exclude_parent=True)
    assert new_ti2.statically_loaded == False


# Generated at 2022-06-21 01:39:37.862364
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # pylint: disable=protected-access
    # test: only valid include keys are found
    task = TaskInclude()
    data = {
        'when': 'foo',
        'action': 'include',
        'args': {'file': 'bar'}
    }
    data = task.preprocess_data(data)
    assert len(data) == 2
    assert 'action' in data
    assert 'args' in data
    assert 'when' not in data

    # test: only valid include keys are found but invalid key is allowed
    task = TaskInclude()
    data = {
        'action': 'include',
        'args': {'file': 'bar'},
        'invalid': 'baz'
    }

# Generated at 2022-06-21 01:39:50.289511
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import pytest

    # Create a simple task to load
    data = dict(
        name="test",
        include="tests/test_task_include.yml",
        when="True",
        test_attr="Test attribute",
    )

    # Load the task in a include task to test it.
    include_task = TaskInclude.load(data, variable_manager=None, loader=None)

    # Check if attribute 'test_attr' is not present
    assert include_task.test_attr is None

    # Raise exception if we try to access to 'test_attr'
    with pytest.raises(AnsibleParserError) as excinfo:
        include_task.test_attr
    assert "is not a valid attribute for a" in str(excinfo)

# Generated at 2022-06-21 01:39:56.772789
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Test function test_TaskInclude_copy of class TaskInclude.
    '''
    obj = TaskInclude()
    obj.exclude_parent = False
    obj.exclude_tasks = False
    obj.statically_loaded = False
    new_obj = obj.copy(exclude_parent = False, exclude_tasks = False)
    assert new_obj.exclude_parent == obj.exclude_parent
    assert new_obj.exclude_tasks == obj.exclude_tasks
    assert new_obj.statically_loaded == obj.statically_loaded


# Generated at 2022-06-21 01:40:08.369046
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.variable_manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play

    # Setup test
    play = Play.load(dict())
    varmanager = VariableManager()
    task = TaskInclude.load(dict(file='test.yml', apply=dict()), play=play, variable_manager=varmanager)
    parent = task.build_parent_block()

    # Test assertion
    assert isinstance(parent, Block)
    assert parent.vars == parent.get_vars()
    assert parent.args == task.args
    assert parent.action == 'include'

# Generated at 2022-06-21 01:40:18.794868
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    ti_action = 'include'
    data = dict(name='task_include_test', action=ti_action, file='test_path/test_file.yml')
    p = Play().load(data, variable_manager=None, loader=None)
    b = Block(p)
    task_t = TaskInclude.load(data, block=b)
    assert task_t.get_vars() == dict(name='task_include_test', action=ti_action, file='test_path/test_file.yml')

    ti_action = 'import_role'

# Generated at 2022-06-21 01:40:28.531099
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # we mock the _parent attribute of class Block to return the same value
    # as the one provided to the get_vars method
    parent = None

    # we use the method Block.get_vars to store the expected result
    b = Block()
    b.args = {'tags': ['a', 'b'], 'when': 'c'}
    b._parent = parent
    b_get_vars_result = b.get_vars()

    t = TaskInclude()
    t.args = {'tags': ['a', 'b'], 'when': 'c'}
    t._parent = parent
    t.build_parent_block()

    # test for action 'include'
    t.action = 'include'
    t_get_vars_result = t.get_vars()
    assert t_get

# Generated at 2022-06-21 01:40:40.859987
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class Parent:
        pass
    task = TaskInclude(parent=Parent())
    task.action = 'include'
    task.name = 'test_task'

    # file path is required
    task.args = {'include': 'test.yml'}
    try:
        task.check_options(task, None)
        assert(False)
    except AnsibleParserError:
        pass

    # valid args
    task.args = {'_raw_params': 'test.yml'}
    task.check_options(task, None)

    # unknown args
    task.args.update({'bad_attr': 'something', 'foo': 'bar'})
    try:
        task.check_options(task, None)
        assert(False)
    except AnsibleParserError:
        pass

    # unknown args

# Generated at 2022-06-21 01:40:48.144878
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    yaml_include = dict(
        action= 'include',
        file = 'tests/test_data/include_dir/dir2/test_meta.yml'
    )

    yaml_include_vars = dict(
        action= 'include_vars',
        file = 'tests/test_data/include_dir/dir1/vars.yml'
    )


# Generated at 2022-06-21 01:40:59.493872
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    example_data = {
        "include": "some.yml",
        "loop": "{{some_var}}",
        "some_var": "foo",
        "other_var": "bar"
    }

    task = TaskInclude.load(example_data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert task.action == "include"
    assert task.args == {
        "_raw_params": "some.yml",
        "loop": "{{some_var}}"
    }
    assert task.some_var == "foo"
    assert task.some_var == task.get_vars()["some_var"]
    assert task.other_var == "bar"

# Generated at 2022-06-21 01:41:11.148595
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    # validate good options
    task = Task()
    task.args = {'file': 'new_tasks.yaml'}
    task.action = 'include'
    task_include.check_options(task, dict())
    assert task.args == {'_raw_params': 'new_tasks.yaml'}

    # validate bad options
    task = Task()
    task.args = {'store': 'something'}
    task.action = 'include'
    try:
        task_include.check_options(task, dict())
        assert False
    except AnsibleParserError as e:
        assert 'Invalid options for include: store' in str(e)

    # validate apply options for include action
    task = Task()

# Generated at 2022-06-21 01:41:27.871092
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    # Check task with invalid attributes
    ds = {'action': 'include', 'loop': 'a', 'tags': 'c'}
    try:
        ti.preprocess_data(ds)
        assert False
    except Exception:
        pass

    # Check task with invalid attributes
    ds = {'action': 'include_role', 'loop': 'a', 'tags': 'c'}
    try:
        ti.preprocess_data(ds)
        assert False
    except Exception:
        pass

    # Check task with invalid attributes
    ds = {'action': 'import_tasks', 'loop': 'a', 'tags': 'c'}
    try:
        ti.preprocess_data(ds)
        assert False
    except Exception:
        pass

# Generated at 2022-06-21 01:41:39.527554
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    display.verbosity = 3
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    example_task = {"block": "", "args": {"apply":{"name": "name for the block",
                                                   "block": "",
                                                   "when": "when expr for the block"}},
                    "include": {"block": "", "static": "True",
                                 "include": {"file": "file to include"}}}

    class Play(object):
        pass

    class Role(object):
        pass

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 01:41:48.991375
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import pytest
    from ansible.playbook.task import Task

    ti = TaskInclude()
    data = dict(file='tasks/main.yml')
    task = Task()
    task = ti.check_options(task, data)

    data = dict(ignore_errors=True)
    task = Task()
    with pytest.raises(AnsibleParserError):
        task = ti.check_options(task, data)

    # This is an error because the include action is not a valid action when 'apply' keyword is used
    data = dict(action='include', apply={})
    task = Task()
    with pytest.raises(AnsibleParserError):
        task = ti.check_options(task, data)

    # This is an error because the 'apply' keyword requires a dictionnary
    data

# Generated at 2022-06-21 01:42:00.364332
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    ans_var_mgr = VariableManager()
    ans_var_mgr.set_nonpersistent_facts(dict(a=1, b=2))

    ans_var_mgr.set_vardefs({
        'my_var': dict(
            default=43,
            type="int",
        ),
        'another_var': dict(
            default="default_value",
            type='str',
        ),
    })

    ans_var_mgr.set_host_variable('localhost', 'host_var', 'host_value')

    # create an instance of TaskInclude and call the method 'get_vars'

# Generated at 2022-06-21 01:42:05.689727
# Unit test for method load of class TaskInclude

# Generated at 2022-06-21 01:42:08.624798
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # create object of TaskInclude
    ti = TaskInclude()
    ti_copy = ti.copy()

    # confirm that ti and ti_copy are different objects
    assert ti is not ti_copy

    # confirm that ti and ti_copy are instances of TaskInclude
    assert isinstance(ti, TaskInclude)
    assert isinstance(ti_copy, TaskInclude)

# Generated at 2022-06-21 01:42:18.947475
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Imports
    from ansible.playbook import Play

    # Setup
    display.verbosity = 3
    ti = TaskInclude()

# Generated at 2022-06-21 01:42:30.153451
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    role = None
    task_include = None
    task_include = TaskInclude(block=block, role=role, task_include=task_include)

    # Test with exclude_parent = False, exclude_tasks = False
    new_task = task_include.copy(exclude_parent=False, exclude_tasks=False)
    assert new_task.statically_loaded == task_include.statically_loaded
    assert new_task._parent == task_include._parent
    assert new_task._dep_chain == task_include._dep_chain

    # Test with exclude_parent = True, exclude_tasks = True
    new_task = task_include.copy(exclude_parent=True, exclude_tasks=True)
    assert new_task.statically_loaded == task_include.statically

# Generated at 2022-06-21 01:42:39.719006
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()

    ti.check_options(ti.load_data({
        'action': 'include',
        'file': '/path/to/nowhere'
    }, loader=None), {
        'action': 'include',
        'file': '/path/to/nowhere'
    })

    # Action will be different from C._ACTION_INCLUDE
    ti.check_options(ti.load_data({
        'action': 'import_playbook',
        'file': '/path/to/nowhere'
    }, loader=None), {
        'action': 'import_playbook',
        'file': '/path/to/nowhere'
    })

    # an exception will be thrown, because '_raw_params' is not set, but 'file' is

# Generated at 2022-06-21 01:42:47.039220
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude.load({'include': Sentinel, 'when': Sentinel})
    ti.statically_loaded = True
    ti.args = {'a': 1, 'b': 2, 'tags': ['tag1', 'tag2'], 'when': 'True'}
    ti._parent = Block()
    ti._parent.vars = {'z': 5, 'y': 4}
    ti.vars = {'x': 3}

    result = ti.get_vars()

    assert result == {'a': 1, 'b': 2, 'z': 5, 'y': 4, 'x': 3}

# Generated at 2022-06-21 01:43:05.488380
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = {'action': 'include_role', 'name': 'foo', 'apply': {'collect_facts': True}}
    task = TaskInclude()

    # Check that 'check_options' raises an exception on an invalid option
    task.check_options(task.load_data(data), data)
    data['foo'] = 'bar'
    try:
        task.check_options(task.load_data(data), data)
        assert(False)
    except AnsibleParserError:
        pass

# Generated at 2022-06-21 01:43:17.564986
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.include import RoleInclude

    task = TaskInclude.load(dict(file='/etc/hosts'))

    # check file that is renamed to _raw_params
    assert(task.args['_raw_params'] == '/etc/hosts')
    assert('file' not in task.args)

    # try to use an invalid keyword
    _data = dict(file='/etc/hosts', invalid_keyword='test')
    try:
        TaskInclude(block=None, role=RoleInclude()).check_options(TaskInclude.load(_data), _data)
        assert(False)
    except AnsibleParserError:
        assert(True)

    # an empty file with a block

# Generated at 2022-06-21 01:43:29.235759
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import os
    os.environ['ANSIBLE_CONFIG'] = os.path.join(os.path.dirname(__file__),'..','..','ansible.cfg')

    # Create tasks
    # https://docs.ansible.com/ansible/latest/user_guide/playbooks_blocks.html#including-files-and-tasks
    task1_data = { 'action': 'include' }
    task1 = TaskInclude.load(task1_data)
    task1_args = {}
    apply_attrs = {}
    task2_data = { 'action': 'include', 'args': task1_args }
    task2 = TaskInclude.load(task2_data)
    task2_args = {'apply': apply_attrs }

# Generated at 2022-06-21 01:43:32.899894
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(action='include_role', src='*')
    ti = TaskInclude()
    ti.preprocess_data(data)


# Generated at 2022-06-21 01:43:36.697607
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    task = TaskInclude(None, None)

    x = {'file': 'some_path', 'action': 'include', 'apply': {'x': 'y'}}

    ti = TaskInclude.load(x, block=None, role=None, task_include=None)

# Generated at 2022-06-21 01:43:48.787530
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import HostVarsResolver
    from ansible.vars.resolver import VaultAwareVariableManagerMixin
    from ansible.vars.resolver import VariableResolver
    from ansible.vars.resolver import ParseableVarsBackendMixin
    from ansible.vars.resolver import FactsVarsBackend
    from ansible.vars.resolver import FileVarsBackend
    from ansible.vars.resolver import YAMLVarsBackend
    from ansible.vars.resolver import EnvVarsBack

# Generated at 2022-06-21 01:43:57.971058
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    # empty data structure
    ds = dict()
    ti.preprocess_data(ds)
    assert not ds

    # minimal data structure
    ds = {'action': 'include',
          'file': 'somefile'}
    ti.preprocess_data(ds)
    assert 'action' in ds
    assert 'file' in ds
    assert 'args' in ds
    assert '_raw_params' in ds['args']
    assert ds['args']['_raw_params'] == ds['file']
    assert 'tags' in ds
    assert 'when' in ds
    assert 'async' in ds
    assert 'poll' in ds
    assert 'ignore_errors' in ds

    # minimum data structure with just a variable
   

# Generated at 2022-06-21 01:44:07.860807
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # get a dict with valid keys to use in the test
    valid_keys = TaskInclude.VALID_INCLUDE_KEYWORDS
    # create a dict to use in the test
    test_include_dict = {}
    # make sure that dict will include Sentinel as value for one of the valid keys
    for k in valid_keys:
        test_include_dict[k] = Sentinel()
        if k == 'when':
            break  # make sure not all keys will have Sentinel
    # test that preprocess_data will accept the dict
    TaskInclude.preprocess_data(test_include_dict)
    # add invalid key to the test dict
    test_include_dict['test'] = 'test'
    # create InvalidActionException

# Generated at 2022-06-21 01:44:17.033695
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.args = {'a':'b', 'c':'d'}
    tintegers = TaskInclude()
    tintegers.args = {'action':'include', 'a':2, 'b':'test'}
    tdict = TaskInclude()
    tdict.args = {'a':{'b':'c'}}
    tdict.action = 'include_role'
    tdict.when = 'b == "test"'

    assert(set(ti.get_vars()) == {'a', 'c'})
    assert(set(tintegers.get_vars()) == {'a', 'b'})
    assert(set(tdict.get_vars()) == {'a', 'when'})

# Generated at 2022-06-21 01:44:21.930334
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    copy_ti = ti.copy()
    assert copy_ti is not ti
    assert copy_ti.statically_loaded is True

# Generated at 2022-06-21 01:44:39.335447
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    # The test dictionary of task attributes contains valid and invalid task attributes
    task_attrs = {
        'action': 'include_tasks',
        'name': 'My Preprocessing task',
        'tasks': 'tasks.yml',
        'tags': ['tag1', 'tag2'],
        'loop': '{{my_list}}',
        'loop_with_items': '{{my_list}}',
        'when': 'ansible_os_family == "RedHat"',
        'vars': {'var1': 'value1', 'var2': 'value2'},
        'var3': 'value3',  # This is an invalid attribute for TaskInclude
    }

    # Create a new TaskInclude object and call its preprocess_data method
