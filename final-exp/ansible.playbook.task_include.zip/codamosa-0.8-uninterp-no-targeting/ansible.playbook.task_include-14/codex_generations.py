

# Generated at 2022-06-21 01:34:53.957409
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # 1. Check if error is raised with invalid options
    task_include = TaskInclude(block=None, role=None, task_include=None)
    data = {'action': 'include_role', 'name': 'my_role', 'invalid_option': 'invalid value'}
    with pytest.raises(AnsibleParserError):
        task_include.check_options(task_include.load_data(data), data)

    # 2. Check if no error is raised with valid options
    task_include = TaskInclude(block=None, role=None, task_include=None)
    data = {'action': 'include', 'name': 'my_role', 'loop': '{{ my_loop_var }}'}
    task_include.check_options(task_include.load_data(data), data)



# Generated at 2022-06-21 01:35:02.842219
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = Task()

    task.args['zap'] = 2
    task.action = 'freeze'

    try:
        ti.check_options(task, task.args)
        assert False, "TaskInclude.check_options() did not raise AnsibleParserError exception"
    except AnsibleParserError:
        pass

    task.args = {}
    task.action = 'include_role'

    try:
        ti.check_options(task, task.args)
        assert False, "TaskInclude.check_options() did not raise AnsibleParserError exception"
    except AnsibleParserError:
        pass

    task.args = {}
    task.action = 'include'


# Generated at 2022-06-21 01:35:14.451038
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    t = {'block': [],  'vars': {'var1': 'val1'}, 'meta': {'meta1': 'meta1_val'}, 'rescue': [],
         'always': [], 'register': 'reg', 'any_errors_fatal': False, 'tags': ['tag1'],
         'when': ['when1'], 'post_tasks': [], 'pre_tasks': []}
    pb = Play().load({'name': 'pb_name', 'hosts': 'pb_hosts', 'roles': []}, variable_manager=None, loader=None)
   

# Generated at 2022-06-21 01:35:26.722347
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    def _create_ti_obj(action, vars_):
        from ansible.plugins import ActionModule

        loader = DictDataLoader({})
        variable_manager = VariableManager(loader=loader)
        play = Play().load({}, variable_manager=variable_manager, loader=loader)
        play._variable_manager = variable_manager
        play_context = PlayContext()
        play_context._task_vars = combine_vars(play.get_variable_manager().get_vars(), vars_)

# Generated at 2022-06-21 01:35:38.274977
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Check `TaskInclude.build_parent_block()`.
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class ParentTask(object):
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self):
            return self.vars

    context = PlayContext()
    # create a fake play

# Generated at 2022-06-21 01:35:47.813158
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude({'action': 'include'})
    good_data = {'when': 'a flag'}
    assert good_data == task.preprocess_data(good_data)

    good_data = {'tags': ['always']}
    assert good_data == task.preprocess_data(good_data)

    good_data = {'ignore_errors': True}
    assert good_data == task.preprocess_data(good_data)

    good_data = {'when': 'a flag', 'tags': ['always'], 'ignore_errors': True}
    assert good_data == task.preprocess_data(good_data)

    bad_data = {'unknown': 'something'}
    C.INVALID_TASK_ATTRIBUTE_FAILED = False
    assert bad_data

# Generated at 2022-06-21 01:35:56.276353
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Test the method TaskInclude.copy()
    '''
    TaskInclude._task_meta = FieldAttribute(isa='dict', default={})
    TaskInclude.name = FieldAttribute(isa='string')
    TaskInclude.action = FieldAttribute(isa='string')
    blk = Block()
    ti = TaskInclude(blk, task_include=None)
    ti.statically_loaded = False
    ti.name = 'TaskInclude Test'
    ti.action = 'action_test'
    TaskInclude._task_meta.load(ti, {})

    # Test default copy
    copy_ti = ti.copy()
    assert copy_ti.name == ti.name
    assert copy_ti.action == ti.action
    assert copy_ti._task_meta == ti._task_meta
   

# Generated at 2022-06-21 01:36:05.272855
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # create a fake task with an invalid action
    data = {'action': 'some_invalid_action', 'some_random_arg': 1}
    task = Task()
    task = task.check_options(task.load_data(data, variable_manager=None, loader=None), data)

    # verify that the task was not modified
    assert task.action == 'some_invalid_action'
    assert 'some_random_arg' in task.args
    assert task.args['some_random_arg'] == 1

    # create a fake task with a valid action other than include
    data = {'action': 'setup', 'some_random_arg': 1, 'apply': 'some_value'}
    task = Task()

# Generated at 2022-06-21 01:36:09.177239
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded == True


# Generated at 2022-06-21 01:36:20.063038
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='sleep 300'), register='my_block_result'),
            dict(action=dict(module='debug', args=dict(msg='{{my_block_result.stdout}}')))
        ]
    )

# Generated at 2022-06-21 01:36:36.063587
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Setup
    from ansible.playbook.task_include import Task , TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os
    playbook_path = '/modules'
    pb_executor = PlaybookExecutor(playbooks=[playbook_path], inventory=InventoryManager(loader=DataLoader(), sources=['localhost']), variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-21 01:36:43.356803
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task1 = Task()
    task1.action = 'include_tasks'
    task1.args = {'file': 'val'}
    task2 = task_include.check_options(task1, task1)
    assert task2.args['_raw_params'] == 'val'

    task1 = Task()
    task1.action = 'include_role'
    task1.args = {'file': 'val'}
    task2 = task_include.check_options(task1, task1)
    assert task2.args['_raw_params'] == 'val'

    task1 = Task()
    task1.action = 'include'
    task1.args = {'file': 'val', 'all': 'infra'}
    task2 = task_include.check

# Generated at 2022-06-21 01:36:56.686102
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    def check_opts(task, data, _raw_params=None, apply=None):
        assert isinstance(task, TaskInclude)
        assert isinstance(task._parent, Block)
        args = task.args
        assert isinstance(args, dict)
        assert args['_raw_params'] == _raw_params
        assert args['apply'] == apply
        return task

    # TaskInclude.load when action is 'include'
    # (not a statically loaded task)
    ti = TaskInclude.load(
        {"action": "include"},
        variable_manager="var_manager",
        loader="loader"
    )
    # check_options is called
    assert ti.check_options.call_count == 1
    # preprocess_data is called
    assert ti.preprocess_data.call_count == 1


# Generated at 2022-06-21 01:37:09.397897
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block

    ti = TaskInclude()
    task_include_block = ansible.playbook.block.Block()
    play = ansible.playbook.Play()
    task_include_block._play = play
    play._variable_manager = ansible.vars.VariableManager()

    task_include_block.args = dict(file='foo.yml')
    ti.check_options(task_include_block, dict())

    task_include_block.args = dict(file='foo.yml', apply='bar.yml')
    ti.check_options(task_include_block, dict())

    task_include_block.args = dict(file='foo.yml', apply=dict())
    ti.check_options(task_include_block, dict())


# Generated at 2022-06-21 01:37:10.628874
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    print("Test for TaskInclude constructor")
    a = TaskInclude()
    print(a)


# Generated at 2022-06-21 01:37:21.314493
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # set up
    class FakeRole:
        def __init__(self, name, tasks=None):
            if tasks is None:
                tasks = []
            self.name = name
            self.tasks = tasks
            self._parent = None
            self.path = 'test/path'
            self.vars = {}

        def copy(self):
            return FakeRole(self.name, tasks=self.tasks)

        def get_vars(self):
            return self.vars

        def get_path(self):
            return self.path

    class FakePlay:
        def __init__(self, roles=None):
            if roles is None:
                roles = []
            self.vars = {}
            self.roles = roles

        def copy(self):
            return FakePlay(self.roles)

# Generated at 2022-06-21 01:37:35.211471
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # We test that parent block is not created if apply is not in the task
    ti = TaskInclude.load(
        {"action": "include", "_raw_params": "test.yml"},
        loader=MockLoader(),
        variable_manager=MockVariableManager(),
    )
    block = ti.build_parent_block()
    assert block == ti

    # We test that parent block is created with the expected attributes
    apply_attrs = {"when": "test", "block": "test2", "rescue": "test3", "always": "test4"}
    ti = TaskInclude.load(
        {"action": "include", "_raw_params": "test.yml", "apply": apply_attrs},
        loader=MockLoader(),
        variable_manager=MockVariableManager(),
    )
    p_block

# Generated at 2022-06-21 01:37:46.008146
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Unit test for method ``preprocess_data`` of class ``TaskInclude``.
    """

    def _check_dict_contains_only(d: dict, keys: list):
        """
        Checks that the given dictionary contains only the keys in the given list.

        :param d: The dictionary for the test.
        :param keys: The allowed keys in the dictionary.
        :return: ``True`` if the dictionary contains only the given keys, ``False`` otherwise.
        """
        for key in d.keys():
            if key not in keys:
                return False
        return True

    # Since the method TaskInclude.preprocess_data does not do any
    # preprocessing for 'include' task except for the parent
    # (Task.preprocess_data), we do not need the tests for 'include' task.

# Generated at 2022-06-21 01:37:50.598096
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    ti.load(dict(action='include', file='test.yml', apply=dict(a=1), b=2), block=['test'])
    assert ti.action == 'include'
    assert ti.args.get('file') == 'test.yml'
    assert ti.args.get('apply') == dict(a=1)
    assert not ti.args.get('b')


# Generated at 2022-06-21 01:37:58.727585
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti.action = 'include'
    ti._parent = PlayContext()

    # Valid include keyword dict
    ds = {
        'action': 'include',
        'debugger': 'never',
        'ignore_errors': None,
        'loop': 1,
        'loop_with': 'a',
        'file': '/dev/null',
        'tags': ['tag1', 'tag2', 'tag 3'],
        'when': 'success',
        'args': {'arg1': 'val1'},
        'invalid_task_keyword': 'invalid_keyword',
    }
    ti.preprocess_data(ds)
    assert isinstance(ds, dict)

# Generated at 2022-06-21 01:38:13.495708
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # test with a static include
    data = {'include': 'roles/webservers.yml'}
    ti = TaskInclude()
    processed_data = ti.preprocess_data(data)
    assert processed_data == data, "data is not the same as preprocessed_data"

    # test with a static import_tasks
    data = {'import_tasks': 'roles/webservers.yml'}
    ti = TaskInclude()
    processed_data = ti.preprocess_data(data)
    assert processed_data == data, "data is not the same as preprocessed_data"

    # test with a dynamic import_tasks

# Generated at 2022-06-21 01:38:22.514523
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t = TaskInclude()
    ds = {'action': 'include', 'loop': '{{ my_loops }}'}
    result = t.preprocess_data(ds)
    assert result == ds

    ds = {'action': 'include_role', 'loop': '{{ my_loops }}'}
    result = t.preprocess_data(ds)
    assert result == ds

    ds = {'action': 'import_playbook', 'loop': '{{ my_loops }}'}
    result = t.preprocess_data(ds)
    assert result == ds

    ds = {'action': 'import_tasks', 'loop': '{{ my_loops }}'}
    result = t.preprocess_data(ds)
    assert result == ds


# Generated at 2022-06-21 01:38:35.553471
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Create instance of TaskInclude class
    ti = TaskInclude(block=None, role=None, task_include=None)

    # Set attributes of the class
    ti._parent = None
    ti._role = None
    ti._variable_manager = None
    ti._loader = None
    ti.action = "include"
    ti.args = {}

    # Call method to be tested
    p_block = ti.build_parent_block()

    # Check the result
    assert (p_block is ti)

    # Define the data for the test
    data = {}
    data['action'] = "include"
    data['apply'] = {}
    data['apply']['block'] = []
    data['apply']['when'] = None
    data['apply']['block'] = []

# Generated at 2022-06-21 01:38:43.258541
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Using - include_tasks: role.yml
    task = TaskInclude.load(
        data={
            'include_tasks': 'role.yml',
            'action': 'include_tasks',
            'args': {
                'some_arg_key': 'some_arg_value'
            }
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert task.get_vars() == {'some_arg_key': 'some_arg_value'}

    # Using - import_tasks: role.yml

# Generated at 2022-06-21 01:38:56.865381
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Unit test for Preprocess data in TaskInclude
    """
    task_incl = TaskInclude()
    ds = {'when': 'ok', 'tags': ['a', 'b'], 'action': 'include'}
    res = task_incl.preprocess_data(ds)
    # nothing should change in ds
    assert(res == ds)

    ds = {'when': 'ok', 'tags': ['a', 'b'], 'action': 'import_role'}
    res = task_incl.preprocess_data(ds)
    # nothing should change in ds
    assert(res == ds)

    ds = {'when': 'ok', 'tags': ['a', 'b'], 'action': 'include_role'}
    res = task_incl.preprocess_

# Generated at 2022-06-21 01:39:05.906160
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude(block=None, role=None, task_include=None)
    task.action = 'include'
    task._parent = MockBlock()
    task.args = {'var_key': 'var_value'}
    task.vars = {'var_key2': 'var_value2'}
    assert task.get_vars() == {'var_key': 'var_value', 'var_key2': 'var_value2'}



# Generated at 2022-06-21 01:39:18.109064
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = Task()
    task.action = 'include'

    # Valid options
    task.args = dict(a=1, file='example.yml')
    task_include.check_options(task, dict(a=1, file='example.yml'))
    assert task.args['_raw_params'] == 'example.yml'

    # Invalid option
    task.args['a'] = 1
    try:
        task_include.check_options(task, dict(a=1, file='example.yml'))
        assert False
    except AnsibleParserError:
        assert True

    # No option
    task.args = dict()

# Generated at 2022-06-21 01:39:30.010952
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play.load(dict(name="test"), loader=loader, variable_manager=variable_manager)
    block = Block()
    TaskInclude.load(dict(
        tasks=dict(action="include_tasks", file="./include.yml", tags="test", when="not fail", apply=dict(
            block=dict(serial=10)
        )),
    ), block, variable_manager=variable_manager, loader=loader)
    task = block.block[0]
    assert task.get_vars() == dict()


# Generated at 2022-06-21 01:39:34.567368
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook.task
    ti = ansible.playbook.task.TaskInclude(None, None, None)
    assert isinstance(ti,ansible.playbook.task.TaskInclude)
    assert isinstance(ti,ansible.playbook.task.Task)


# Generated at 2022-06-21 01:39:41.888651
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.constants as C

    task_data = {
        'args': {
            'apply': {
                'when': 'go_ahead',
                'register': 'blah',
                'loop': {'var': 'item', 'in': [1, 2, 3]},
            },
            # other args
            'file': '/tmp/tasks.yml',
            'no_log': False,
        }
    }
    task = TaskInclude.load(task_data, loader=None, variable_manager=None)
    parent_block = task.build_parent_block()

    assert parent_block.action == 'include'
    assert parent_block.has_tasks() is True
    assert isinstance(parent_block._parent, TaskInclude) is True

# Generated at 2022-06-21 01:39:48.484654
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    t = TaskInclude()
    assert t.statically_loaded == False

    t = TaskInclude(statically_loaded=True)
    assert t.statically_loaded == True



# Generated at 2022-06-21 01:40:00.082641
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_loader

    ti = TaskInclude()
    fake_loader = get_loader('')
    ti._loader = fake_loader

    play_obj = Play.load({'name': 'fakeplay'}, loader=fake_loader)
    play_context_obj = PlayContext(play=play_obj)
    play_obj._variable_manager = play_context_obj.variable_manager


# Generated at 2022-06-21 01:40:11.706173
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    def pl(name):
        # this is the load(data, ...) method of class Play
        pass

    def rl(name):
        # this is the load(data, ...) method of class Role
        pass

    block = p = r = vm = l = None
    task_include = TaskInclude(block=block, role=r, task_include=task_include)
    task_include.statically_loaded = False
    new_task_include = task_include.copy(exclude_parent=True, exclude_tasks=True)

    assert not hasattr(new_task_include, '_parent')
    assert not hasattr(new_task_include, '_role')
    assert not hasattr(new_task_include, '_block')

# Generated at 2022-06-21 01:40:21.082344
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader=DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    block = None
    role = None
    task_include = None
    # This should raise an error
    data_dict = {
        'action': 'include',
        'file': 'foo'
    }
    play_ds = data=loader.load(data_dict)
    ti = TaskInclude(block=block, role=role, task_include=task_include)
   

# Generated at 2022-06-21 01:40:30.005129
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Basic TaskInclude
    task_data = dict(action='include_tasks', include='some/path.yaml')
    task = TaskInclude.load(task_data)
    import pytest
    with pytest.raises(AnsibleParserError):
        task = task.check_options(task, task_data)

    # TaskInclude with file option
    task_data = dict(action='include_tasks', file='some/file.yaml')
    task = TaskInclude.load(task_data)
    expected_task_data = dict(action='include_tasks', _raw_params='some/file.yaml')
    assert task.action == expected_task_data['action']
    assert task.args['_raw_params'] == expected_task_data['_raw_params']

    # Task

# Generated at 2022-06-21 01:40:35.639494
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook.task_include
    import ansible.playbook.block

    result = isinstance(ansible.playbook.task_include.TaskInclude(), ansible.playbook.task_include.TaskInclude)
    assert result == True

# Generated at 2022-06-21 01:40:46.658700
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    ti.check_options(ti.load_data({'include': 'foo'}))
    ti.check_options(ti.load_data({'include': 'foo', 'loop': 'bar'}))
    try:
        ti.check_options(ti.load_data({'include': 'foo', 'bad_key': 'bar'}))
        assert False  # this should never be reached
    except AnsibleParserError:
        assert True
    try:
        ti.check_options(ti.load_data({'include': 'foo', 'bad_key': 'bar'}), {'bad_key': 'bar'})
        assert False  # this should never be reached
    except AnsibleParserError:
        assert True
    # _raw_params and file

# Generated at 2022-06-21 01:40:58.324598
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    class FakeVarManager:
        pass

    class FakeRole:
        pass

    class FakeLoader:
        pass

    args = dict(file='foo.yml')
    block = None
    role = FakeRole()
    variable_manager = FakeVarManager()
    loader = FakeLoader()
    ti = TaskInclude.load(
        args,
        block=block,
        role=role,
        variable_manager=variable_manager,
        loader=loader,
    )

    assert isinstance(ti, TaskInclude)
    assert isinstance(ti._variable_manager, FakeVarManager)
    assert isinstance(ti._role, FakeRole)
    assert isinstance(ti._loader, FakeLoader)
    assert ti._raw_params == 'foo.yml'


# Generated at 2022-06-21 01:41:07.395506
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    result = ti.preprocess_data({"action":"include", "a":1})
    assert(result["a"] is Sentinel)
    result = ti.preprocess_data({"action":"import_tasks", "b":2})
    assert(result["b"] is 2)
    try:
        result = ti.preprocess_data({"action":"include", "c":3})
        assert(False)
    except:
        pass
    result = ti.preprocess_data({"action":"include_role", "d":4})
    assert(result["d"] is Sentinel)

# Generated at 2022-06-21 01:41:14.994768
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # test validation errors, with and without failed parameter
    data = {'include': 'foofile'}
    with C.INVALID_TASK_ATTRIBUTE_FAILED:
        TaskInclude.load(data)
    with C.INVALID_TASK_ATTRIBUTE_FAILED:
        TaskInclude.load(data, failed=True)
    C.INVALID_TASK_ATTRIBUTE_FAILED = False
    TaskInclude.load(data)


# Generated at 2022-06-21 01:41:26.375968
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    All tasks preprocess_data method must be testable independently
    """

    test_data = dict(
        name="Test task",
        action="include",
        file="test_tasks.yml",
        when="not failed",
        tags=["test", "task"],
        test_invalid_attribute=True,
        test_invalid_attribute_dict=['test'],
        test_invalid_attribute_list=dict(test='test')
    )

    ti = TaskInclude()
    # must not raise a AnsibleParserError
    ti.preprocess_data(test_data)


# Generated at 2022-06-21 01:41:38.479588
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ''' test a simple copy
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    t = Task()
    assert t.copy() is not t

    t = TaskInclude()
    assert t.copy() is not t

    t = TaskInclude()
    t.action = 'foobar'
    t.statically_loaded = True

    t2 = t.copy()
    assert t.action == t2.action
    assert t2.action == 'foobar'
    assert t.statically_loaded
    assert t2.statically_loaded

    t = TaskInclude()
    t.action = 'foobar'

    t2 = t.copy()
    assert t.action == t2.action
    assert t2.action == 'foobar'


# Generated at 2022-06-21 01:41:39.629486
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    TaskInclude()
    TaskInclude()

# Generated at 2022-06-21 01:41:49.081075
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    task_vars = dict(task_name='foo', task_action='bar')
    play_context = PlayContext()
    host_vars = {}
    host = 'all'
    result = {}
    ti = TaskInclude()
    task = ti.load(dict(action='fake_action', file='foo', other='bar', apply=dict(var=1)), variable_manager=VariableManager(loader=None, host_vars=host_vars, task_vars=task_vars), loader=None)
    assert isinstance(task, Task)
    assert task.name == 'foo'

# Generated at 2022-06-21 01:41:54.090355
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    x = TaskInclude(task_include=sentinel.task_include,
                    role=sentinel.role,
                    block=sentinel.block)
    assert x._parent == sentinel.task_include
    assert x._role == sentinel.role
    assert x._block == sentinel.block

# Generated at 2022-06-21 01:42:01.922190
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    file = dict(
        _raw_params='test_file.yml',
        action='include',
        apply=[
            {'action': 'include', 'block': []},
            [
                dict(action='include', _raw_params='test_file.yml'),
                dict(action='include', _raw_params='test_file2.yml'),
            ],
        ],
    )
    block = Block.load(file, loader=MockLoader())
    task = block.block[0]
    p_block = task.block[0]
    assert task.apply == p_block.block



# Generated at 2022-06-21 01:42:12.942692
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    block_name = 'test'
    ti = TaskInclude(block=Block.load({'name': block_name}))

    # we need to mock the variables_manager object only for the sake of passing it to `load`.
    from ansible.playbook.play_context import PlayContext
    variables_manager = PlayContext()

    # setting the values of the variables
    my_var = {'var1': 10}
    my_var_name = 'vars'
    ti.args[my_var_name] = my_var

    ti_action = 'include'
    ti.args['_raw_params'] = 'file.yml'
    ti.action = ti_action

# Generated at 2022-06-21 01:42:23.457100
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(include='foo.yml'))]
    )


# Generated at 2022-06-21 01:42:30.936224
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    module_args = dict(
        _raw_params='foo/bar.yml',
        apply=dict(),
    )

    ti = TaskInclude()
    ret = ti.load(module_args)
    assert ret.args == dict(_raw_params='foo/bar.yml', apply=dict())
    assert ret.statically_loaded is False

    ti = TaskInclude()
    ti.action = 'include_role'
    ret = ti.load(module_args)
    assert ret.args == dict(_raw_params='foo/bar.yml', apply=dict())
    assert ret.statically_loaded is False

# Generated at 2022-06-21 01:42:39.187247
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    result = ti.preprocess_data({'action': 'include', 'tags': 'foobar'})
    assert 'action' in result
    assert 'tags' in result
    assert 'ignore_errors' not in result

    result = ti.preprocess_data({'action': 'include', 'ignore_errors': 'foobar'})
    assert 'action' in result
    assert 'ignore_errors' in result
    assert 'tags' not in result

    result = ti.preprocess_data({'action': 'import_tasks', 'tags': 'foobar'})
    assert 'tags' not in result
    assert 'ignore_errors' not in result

# Generated at 2022-06-21 01:42:57.612041
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    data1 = {'action': 'include', 'file': "tasks/main.yml"}
    ti1 = TaskInclude.load(data1)
    ti1.statically_loaded = True

    ti2 = ti1.copy()
    assert ti1.action == ti2.action
    assert ti1.args == ti2.args
    assert ti1.when == ti2.when
    assert ti1.statically_loaded == ti2.statically_loaded

    ti3 = ti1.copy(exclude_parent=True)
    assert ti3.action == ti2.action
    assert ti3.args == ti2.args
    assert ti3.when == ti2.when
    assert ti3.statically_loaded == ti2.statically_loaded
    assert ti3._parent == ti2._parent

    ti4

# Generated at 2022-06-21 01:43:09.626083
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    print("test_TaskInclude_get_vars")
    print("Case 1: include action")
    task_include1 = TaskInclude()
    task_include1.action = 'include'
    task_include1.vars = dict()
    task_include1.args = dict()

    task_include1.args['tags'] = ['selftest']
    task_include1.args['when'] = 'ansible_os_family == "RedHat"'

    # Use parent block to create a value for args to check that it is ignored
    task_include1._parent = Block()
    task_include1._parent.vars = dict()
    task_include1._parent.vars['port'] = 8080

    all_vars = task_include1.get_vars()
    assert 'tags' not in all_v

# Generated at 2022-06-21 01:43:11.093359
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Currently, method build_parent_block is effectively tested by test_playbook_v2_loader_include_apply.
    pass


# Generated at 2022-06-21 01:43:16.951242
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    def load_task_include(ti_data, action):
        '''
        Loads TaskInclude with ``ti_data`` and validates against ``action``
        '''
        block_data = {
            action: {
                'include': ti_data,
            }
        }
        block = Block.load(
            block_data,
            play=None,
            task_include=None,
            role=None,
            variable_manager=None,
            loader=None,
        )

        return block.block[0]

    # Valid cases

# Generated at 2022-06-21 01:43:18.047730
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task1 = TaskInclude()
    task1.statically_loaded = True
    task2 = task1.copy()
    assert task2.statically_loaded

# Generated at 2022-06-21 01:43:29.463481
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for tasks
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        obj = TaskInclude()
        obj.action = action
        obj.args = dict()
        obj.vars = dict()
        assert obj.get_vars() == dict()
        #
        obj.vars = dict(a='b')
        assert obj.get_vars() == dict(a='b')
        #
        obj.vars = dict(a='b', tags='foo')
        assert obj.get_vars() == dict(a='b')
        #
        obj.vars = dict(a='b', when='foo')
        assert obj.get_vars() == dict(a='b')
        #
        obj.args = dict(xyz='abc')
        obj

# Generated at 2022-06-21 01:43:36.496943
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Arrange
    data = '{"action":"include_role", "name":"web", "collections":["geerlingguy.apache", "geerlingguy.repo-epel"]}'
    data = TaskInclude.load(data)

    # Assert
    assert(data.action == 'include_role')
    assert(data.args.get('name') == 'web')
    assert(data.args.get('collections')[0] == 'geerlingguy.apache')
    assert(data.args.get('collections')[1] == 'geerlingguy.repo-epel')
    assert(data._role is None)

# Generated at 2022-06-21 01:43:37.355911
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass

# Generated at 2022-06-21 01:43:49.073737
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options of class TaskInclude
    '''
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.block

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager

    ###############################################################
    # CREATE PLAYBOOK OBJECT
    ###############################################################
    # Create a simple playbook

# Generated at 2022-06-21 01:43:57.037263
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    queue_manager = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=None,
        passwords=None,
    )

    data = {'include': 'my-file'}


# Generated at 2022-06-21 01:44:13.522802
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a simple play
    play_vars = dict(
        play_name='test_play_name',
        play_hosts=['test_play_hosts'],
        test_var='test_value'
    )
    pb_loader = DataLoader()
    play = Play.load(play_vars, loader=pb_loader, variable_manager=VariableManager())

    # Create a simple role

# Generated at 2022-06-21 01:44:20.864319
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    # Prepare test object
    play_context = PlayContext()
    play_context._vault_password = 'VaultPassword'
    play = Play().load({'name': 'TestPlay'}, variable_manager=VariableManager(), loader=DataLoader())
    block = Block()

    task = TaskInclude

# Generated at 2022-06-21 01:44:26.422362
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    skip_class_setup = False
    data = dict(file="./test.include")
    try:
        ti = TaskInclude()
    except Exception as e:
        skip_class_setup = True

    if skip_class_setup:
        raise ValueError("setup class failed. please check. ")
    else:
        task = ti.load(data)

# Generated at 2022-06-21 01:44:37.444260
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create a dummy task
    display = Display()
    display.verbosity = 2
    task = TaskInclude(block='yadayadayada', role=None, task_include=None)

    # Create a basic parent block
    task_block = {
         u'name': u'foo',
        u'apply': {
             u'collect_facts': True,
            u'block': u'omg'
        }
    }

    # Test to build the parent block
    parent_block = task.build_parent_block()

    # Assertions
    assert parent_block.name is None
    assert parent_block.block is None
    assert parent_block.collect_facts is None
