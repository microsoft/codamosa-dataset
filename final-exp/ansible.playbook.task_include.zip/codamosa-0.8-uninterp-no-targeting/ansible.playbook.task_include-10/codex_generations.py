

# Generated at 2022-06-21 01:34:53.846374
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 1
    block = Block()
    target = TaskInclude(block,action='include',args={'a':'b'})
    target._variable_manager = dict(a=1)
    target._parent = dict(a=2)
    all_vars = target.get_vars()
    expected_result = dict(a='b')
    assert all_vars == expected_result

    # Test case 2
    target = TaskInclude(block,action='include',args={'a':'b','tags':'all','when':'always'})
    target._variable_manager = dict(a=1)
    target._parent = dict(a=2)
    all_vars = target.get_vars()
    expected_result = dict(a='b')
    assert all_vars == expected_result

# Generated at 2022-06-21 01:34:59.540472
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude(block=None, role=None, task_include=None)
    ret = ti.preprocess_data(dict(name="test", a=1, b=2, c=3))
    assert 'a' in ret
    assert 'b' in ret
    assert 'c' in ret

# Generated at 2022-06-21 01:35:03.854868
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Test data
    data = dict(action="include_role", name="/home/user/role_name", staticallly_loaded=False)
    # Test case
    ti = TaskInclude.load(data)
    new_ti = ti.copy()
    # Test assertion
    assert new_ti.action == ti.action, "action was not correctly copied"
    assert new_ti.statically_loaded == ti.statically_loaded, "statically_loaded was not correctly copied"

# Generated at 2022-06-21 01:35:14.949379
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    task0 = TaskInclude()
    task0.action = 'include_role'
    data_dict = {'apply': {},
                 'name': 'test',
                 'no_log': True,
                 'ignore_errors': False,
                 'any-other-key': False
                 }

    assert task0.action in C._ACTION_INCLUDE_ROLE_TASKS
    task0.check_options(task0.load_data(data_dict), data_dict)

    data_dict = {'no_log': True,
                 'no-other-key': False
                 }

    asserttask0.action in C._ACTION_INCLUDE_ROLE_TASKS
    task0.check_options(task0.load_data(data_dict), data_dict)
    assert not data_dict

# Generated at 2022-06-21 01:35:26.259330
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    import pytest
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    action_loader._add_directory(os.path.join(filedir, 'actions'))

    inventory = InventoryManager(loader=DataLoader(), sources=os.path.join(filedir, 'hosts'))
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    play

# Generated at 2022-06-21 01:35:30.175869
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Use constructor to create a new object
    task_include = TaskInclude()

    # Call the setter of file using the property
    task_include.file = 'test_file'
    # Access the value of file using the property
    assert task_include.file == 'test_file'

    # Change the value of _raw_params via direct assignment
    task_include.args['_raw_params'] = 'test_raw_params'
    # Access the value of _raw_params using the property
    assert task_include._raw_params == 'test_raw_params'

    # Change the value of apply via direct assignment
    task_include.args['apply'] = {'apply': Sentinel}
    # Access the value of apply using the property
    assert isinstance(task_include.apply, dict)

    # Check if value of dynamically created properties

# Generated at 2022-06-21 01:35:41.358702
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugin.loader import get_all_plugin_loaders

    # Make sure that we get the correct loader for our plugin (action/task)
    cls_loader = get_all_plugin_loaders()['action']

    # Go to base-class because 'include' is not a valid option
    # in 'action' plugins (only in task plugins)
    class MyTaskInclude(cls_loader.get('include')):
        pass

    # Initialize some variables
    tmp_vars = dict(a=1, b=2)
    my_data = dict(_raw_params='test.yml', other='other')
    to_check = dict(_raw_params='test.yml', other=Sentinel)

    my_obj

# Generated at 2022-06-21 01:35:49.511168
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class MockParent(object):
        def __init__(self):
            self.vars = {'a': 1, 'b': 2}

        def get_vars(self):
            return self.vars


    task = TaskInclude()
    # Test when self.action is not in C._ACTION_INCLUDE
    # Expected Behaviour: return self.vars
    # This is the same as the get_vars() of parent class Task
    task._action = 'something else'
    task.vars = {'c': 3}
    # Test without parent
    result_dict = task.get_vars()
    assert result_dict['c'] == 3
    # Test with parent
    task._parent = MockParent()
    result_dict = task.get_vars()

# Generated at 2022-06-21 01:36:00.629796
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # create a test TaskInclude
    ti = TaskInclude()
    ti.args = {'hello': 'world'}
    ti.action = 'include'
    ti.statically_loaded = True

    # copy it
    new_me = ti.copy()

    # verify that the parent was not copied
    assert new_me._parent is None

    # verify that the args were copied
    assert new_me.args['hello'] == 'world'

    # verify that the statically-loaded flag was copied
    assert new_me.statically_loaded is True

    # verify that the action was copied
    assert new_me.action == 'include'

# Generated at 2022-06-21 01:36:08.320528
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class FakeParent:
        def __init__(self):
            self.vars = {'a': 1}
            self.get_vars = lambda : self.vars

    class FakeIncludedFile:
        def __init__(self):
            self.parent = FakeParent()

    FakeTask1 = TaskInclude(task_include=FakeIncludedFile())
    FakeTask2 = TaskInclude(task_include=FakeIncludedFile())
    FakeTask2.action = 'include'
    FakeTask2.vars = {'b': 2}
    FakeTask2.args  = {'c': 3, 'ignore_errors': False}

    assert FakeTask1.get_vars() == {'a': 1}

# Generated at 2022-06-21 01:36:25.648287
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()

    # base test
    ti.vars = dict(key='value')
    ti.args = dict(key1='value1', key2='value2')
    assert ti.get_vars() == dict(key='value', key1='value1', key2='value2')

    # test with parent
    ti2 = TaskInclude()
    ti.args = dict(key1='value1', key2='value2')
    ti._parent = ti2
    ti2.vars = dict(parent_key='parent_value')
    assert ti.get_vars() == dict(key='value', parent_key='parent_value', key1='value1', key2='value2')

    # test with action not in include
    ti = TaskInclude()
    ti.action = 'include'


# Generated at 2022-06-21 01:36:35.981807
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class TaskInclude.
    '''
    task = TaskInclude()
    ds = dict()
    result = task.preprocess_data(ds)

    assert result == ds

    ds = dict({'action': 'include', 'x': 'y'})
    result = task.preprocess_data(ds)

    assert result == dict({'action': 'include'})

    ds = dict({'action': 'import_tasks', 'x': 'y'})
    result = task.preprocess_data(ds)

    assert result == dict({'action': 'import_tasks', 'x': 'y'})

# Generated at 2022-06-21 01:36:40.356337
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args['foo'] = 'bar'
    # Here we mimic the parent get_vars return value to ensure it is taken into account
    task_include._parent = object()
    task_include._parent.get_vars = lambda: dict(baz='qux')

    vars = task_include.get_vars()

    assert vars == dict(foo='bar', baz='qux')

# Generated at 2022-06-21 01:36:46.626692
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # imports
    from ansible.playbook.play_context import PlayContext

    # create TaskInclude class instance
    ti = TaskInclude()

    # create test cases

# Generated at 2022-06-21 01:36:57.766644
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import unittest

    data = {
        'action': 'include',
        'bad_data': 'bad',
        'debugger': True,
        'ignore_errors': True,
        'no_log': True,
        'tags': ['tag1', 'tag2'],
        'when': 'when1',
        'file': './myfile.yml',
    }

    class TestTaskInclude(unittest.TestCase):

        def test_TaskInclude_preprocess_data(self):
            '''
            Assert that TaskInclude preprocess_data returns the expected dict
            '''

# Generated at 2022-06-21 01:37:10.446214
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_data = dict(
        action=dict(
            meta=True,
            module=True,
        ),
        args=dict(
            _raw_params='/path/to/include',
        )
    )

    # test valid task
    TaskInclude.check_options(task=Task.load(task_data), data=task_data)
    assert 'file' not in task_data['args']
    assert '_raw_params' in task_data['args']

    # test with invalid option

# Generated at 2022-06-21 01:37:21.815600
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    variables = {'test_var': 'test_value'}
    include_task = TaskInclude()
    include_task.vars = {'task_include_task_var': 'task_include_task_var_value'}
    include_task.block = Block()

    parent_block = include_task.build_parent_block()
    assert include_task.args == {}
    assert type(parent_block) is TaskInclude
    assert parent_block.vars == {'task_include_task_var': 'task_include_task_var_value'}
    assert parent_block.block == []

    include_task.args.update({'apply': {'vars': variables}})
    parent_block = include_task.build_parent_block()
    assert include_task.args == {}

# Generated at 2022-06-21 01:37:35.489219
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block

    ti = TaskInclude(Block())
    task = ti.check_options(
        ti.load_data({'action': 'include_tasks', 'file': 'test.yml', 'apply': {'foo': 'bar'}}),
        {'action': 'include_tasks', 'file': 'test.yml', 'apply': {'foo': 'bar'}}
    )

    assert type(task) == TaskInclude
    assert task.action == 'include_tasks'
    assert task.args['file'] == 'test.yml'
    assert task.args['apply'] == {'foo': 'bar'}

    task = ti.check_options

# Generated at 2022-06-21 01:37:46.369953
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    task = TaskInclude()
    assert(task)

    task = TaskInclude(role=None, block=None, task_include=None)
    assert(task)

    task = TaskInclude(role="role_name", block=None, task_include=None)
    assert(task)

    task = TaskInclude(role=None, block=Block(play=None), task_include=None)
    assert(task)


# Generated at 2022-06-21 01:37:57.180792
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    module = TaskInclude.load(
        {'file': 'test_file'},
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert isinstance(module, TaskInclude)

    # Validate that TaskInclude.load updates action from 'include' to 'include_tasks'
    module_with_action = TaskInclude.load(
        {'file': 'test_file', 'action': 'include'},
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert module_with_action.action == 'include_tasks'
    assert module_with_action.args['action'] == 'include_tasks'



# Generated at 2022-06-21 01:38:14.136310
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Test with valid attributes for include task
    include_task = dict(action='include', apply=dict(a=0), args=dict(b=1), collections=dict(c=2), debugger=False,
                        ignore_errors=False, loop=dict(), loop_control=dict(loop_var=dict(key='value')),
                        loop_with=dict(with_sequence=[1,2,3], with_indexed_items=dict(the_list=[4,5,6])), name='name',
                        no_log=dict(), register=dict(), run_once=False, tags=['tag1', 'tag2'], timeout=1, vars=dict(),
                        when=[dict(q=4), dict(w=5)])
    preproceed_include_task = TaskInclude.preprocess_data(include_task)



# Generated at 2022-06-21 01:38:18.081550
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_text
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    option_parser = AdHocCLI()

    (options, args) = option_parser.parse_args([])
    options.inventory = "/etc/ansible/hosts"
    options.module_name = "command"
    options.module_args = 'ls'

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-21 01:38:28.800417
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class FakeTask(object):
        def __init__(self, vars):
            self.vars = vars

    class FakeBlock(object):
        def __init__(self, vars):
            self.vars = vars

    class FakeRole(object):
        def __init__(self, vars):
            self.vars = vars

    play_vars = dict(pvar1='pvar1', pvar2='pvar2')
    block_vars = dict(bvar1='bvar1', bvar2='bvar2')
    role_vars = dict(rvar1='rvar1', rvar2='rvar2')

    include_obj = TaskInclude()
    include_obj.action = 'include'

# Generated at 2022-06-21 01:38:39.164138
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.playbook.play
    try:
        TaskInclude.load({'name': 'foobar', 'include': "foo.yml", 'when': 'a condition', 'tags': 'a_tag'})
    except AnsibleParserError as e:
        assert "when is not a valid attribute for a TaskInclude" in str(e)
    try:
        TaskInclude.load({'name': 'foobar', 'include': "foo.yml", 'tags': 'a_tag'})
    except AnsibleParserError as e:
        assert "tags is not a valid attribute for a TaskInclude" in str(e)

# Generated at 2022-06-21 01:38:43.918314
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block

    task = TaskInclude.load({
        'apply': {
            'name': 'test-parent-block'
        }
    })
    assert isinstance(task, TaskInclude)
    assert isinstance(task.build_parent_block(), Block)

# ---- instantiation testing


# Generated at 2022-06-21 01:38:56.604091
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    def test_TaskInclude_constructor(task):
        assert isinstance(task, TaskInclude)
        assert isinstance(task._parent, Block)
        assert isinstance(task._block, Block)
        assert isinstance(task._role, Role)
        assert isinstance(task._task_include, TaskInclude)

    block = Block()
    role = Role()
    task_include = TaskInclude()

    # normal constructor
    test_TaskInclude_constructor(TaskInclude())

    # constructor with block
    test_TaskInclude_constructor(TaskInclude(block=block))
    test_TaskInclude_constructor(TaskInclude(block=block, role=role, task_include=task_include))


# Generated at 2022-06-21 01:39:09.508763
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Tests for TaskInclude class's load() method.
    '''
    # invalid options for include tasks
    data = {'action': 'include', 'include': 'abc.yml', 'file': 'abc.yml',
            'debugger': 'off', 'other': 'option', 'loop_control': {'loop_var': 'item'}}
    ti = TaskInclude(task_include=None)
    mock_task = None
    with pytest.raises(AnsibleParserError):
        ti.check_options(mock_task, data)

    # invalid options for import_tasks tasks

# Generated at 2022-06-21 01:39:17.049232
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class Mock(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(Mock, self).__init__(block=block, role=role, task_include=task_include)
            self.vars = {}

        def load_data(self, ds, variable_manager=None, loader=None):
            super(Mock, self).load_data(ds, variable_manager=variable_manager, loader=loader)
            return self

    class MockLoader:
        def get_basedir(self):
            return ''

    class MockVariableManager:
        def __init__(self):
            self.vars = {}

    data = {'action': 'include_tasks', 'file': 'test.yaml'}

    # test load for action 'include_

# Generated at 2022-06-21 01:39:29.606951
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    def test_TaskInclude_check_options_included_file(include, action_type):
        '''
        @include: Instance of IncludedFile
        @action_type: String to indicate the type of test
        '''
        data = {
            'action': action_type,
            'file': 'dummy.yml',
            'apply': dict(),
        }
        try:
            include.check_options(include.load_data(data), data)
            assert False, 'AnsibleParserError expected for %s' % action_type
        except AnsibleParserError:
            pass


# Generated at 2022-06-21 01:39:39.882208
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    # By default the task should have _parent property set to None
    assert task._parent is None

    # Action of task is set to 'include' by default
    assert task.action == 'include'

    task.args = {'tags':'tag1', 'when':'not tag2'}
    # The method get_vars() of Task should return a dict of the form {'tags':'tag1', 'when':'not tag2'}
    assert task.get_vars() == {'tags':'tag1', 'when':'not tag2'}

    # Setting the action to 'include_role' to test the behaviour of get_vars() when action != 'include'
    task.action = 'include_role'

# Generated at 2022-06-21 01:39:59.603032
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play_context
    import ansible.playbook.block

    task = TaskInclude(block=None, role=None, task_include=None)
    task.action = "include_role"
    task.statically_loaded = True
    task.name = "role1"

# Generated at 2022-06-21 01:40:11.376751
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_include = """
    - include: test.yml
      test_var: test_val
    """
    test_include_play = """
    - hosts: all
      tasks:
      - include: test.yml
        test_var: test_val
    """
    test_include_play2 = """
    - hosts: all
      tasks:
      - include: test.yml
        test_var: test_val
    """
    test_include_play2_tasks = """
    - include: test.yml
        test_var: test_val
    """
    test_include_play_tasks = """
    - include: test.yml
        test_var: test_val
    """

# Generated at 2022-06-21 01:40:20.797196
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    block = Block()
    role = None
    task_include = None
    ti = TaskInclude(block, role, task_include)
    data = dict({'file': '/home/a/b.yaml', 'action': 'include'})
    data2 = dict(data)

    ti.preprocess_data(data)
    assert data == data2

    data = dict({'file': '/home/a/b.yaml', 'action': 'import_tasks', 'my_attr': 'my_val'})
    data2 = dict(data)

    ti.preprocess_data(data)
    assert data == data2

    # file attribute is not defined
    data = dict({'action': 'include'})

# Generated at 2022-06-21 01:40:29.711134
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Load a TaskInclude with 'apply' specified
    from ansible.playbook import Play
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.loader import task_loader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:40:41.380931
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    pb = Playbook.load(
        '../../../test/units/parsing/playbooks/include_role_module.yml',
        loader=DataLoader(),
    )
    v_m = VariableManager()
    v_m._fact_cache = dict()

    # Set up a valid task with faked arguments
    task = Task()
    task.args = dict(file='testfile')
    task.vars = dict(test_var='test_val')

# Generated at 2022-06-21 01:40:48.501259
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include_1 = TaskInclude()
    task_include_2 = task_include_1.copy()

    assert task_include_1.__dict__ == task_include_2.__dict__
    assert task_include_1.statically_loaded == task_include_2.statically_loaded

    task_include_1.statically_loaded = True
    task_include_3 = task_include_1.copy()

    assert task_include_1.__dict__ != task_include_3.__dict__
    assert task_include_1.statically_loaded == task_include_3.statically_loaded

# Generated at 2022-06-21 01:40:59.676074
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    def _task(module_args, **kwargs):
        task = Task()
        task.vars = combine_vars(task.vars, kwargs)
        task.args = module_args
        return task

    def _block(block_vars, *tasks, **kwargs):
        block = Block()
        block.vars = combine_vars(block.vars, block_vars)
        block.block = list(tasks)
        return block


# Generated at 2022-06-21 01:41:11.323714
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-21 01:41:22.549012
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # Test for no file specified for include
    task_ds = dict(action='include', other_arg='bar', more_arg='foo')
    ti = TaskInclude()
    try:
        ti.load(task_ds)
    except AnsibleParserError as e:
        assert "No file specified for include" in str(e)

    # Test for invalid options for include
    task_ds = dict(action='include', file='bar', more_arg='foo', bad_arg='blah')
    ti = TaskInclude()
    try:
        ti.load(task_ds)
    except AnsibleParserError as e:
        assert "Invalid options for include: bad_arg" in str(e)

    # Test for invalid options for import_role

# Generated at 2022-06-21 01:41:29.549689
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.block import Block

    block = Block()
    task = TaskInclude(block=block)
    assert task.copy() == task.copy()
    assert task.copy() != task
    assert task.copy() == task.copy(exclude_parent=True)
    assert task.copy() != task.copy(exclude_tasks=True)
    assert task.copy(exclude_parent=True) == task.copy(exclude_parent=True)
    assert task.copy(exclude_parent=True) != task.copy(exclude_parent=False)
    assert task.copy(exclude_tasks=True) == task.copy(exclude_tasks=True)
    assert task.copy(exclude_tasks=True) != task.copy(exclude_tasks=False)

# Generated at 2022-06-21 01:41:42.485702
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    block = Block()
    role = FieldAttribute(None)
    task_include = FieldAttribute(None)

    ti = TaskInclude(block, role, task_include)
    ti_json = ti.to_json()
    ti_recon = TaskInclude.from_json(ti_json)
    ti_recon_json = ti_recon.to_json()

    assert ti_recon_json == ti_json

# Generated at 2022-06-21 01:41:43.103183
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    obj = TaskInclude()
    assert obj != None

# Generated at 2022-06-21 01:41:51.826625
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import  Role
    from ansible.plugins.loader import action_loader

    play_data = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = dict(
            include='foo.yml'
        )
    )
    play = Play.load(play_data, variable_manager=None, loader=None)
    block = play.get_block_list()[0]
    task = block.get_task_by_name('include')

    assert task.args.get('file') is None
    assert task.args.get('_raw_params') == 'foo.yml'
    assert task.action == 'include'

# Generated at 2022-06-21 01:41:53.629896
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args = dict()

    assert type(task_include.get_vars()) is dict


# Generated at 2022-06-21 01:41:59.394462
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    example_data = {
        'block': [{
            'hosts': "example.com",
            'tasks': [{
                'name': "Task A",
                'action': "debug",
                'args': {
                    'msg': "{{ test }}"
                }
            }, {
                'action': "debug",
                'args': {
                    'msg': "{{ other }}"
                }
            }],
            'vars': {
                'test': "example"
            }
        }]
    }


# Generated at 2022-06-21 01:42:06.264948
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    This is a test for class TaskInclude
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    ti = TaskInclude(play_context)

    assert(ti.name == '')
    assert(ti.action == 'include')
    assert(isinstance(ti.args, dict))



# Generated at 2022-06-21 01:42:09.285414
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Test with empty args
    ti = TaskInclude()
    ti.args = {}
    assert ti.build_parent_block() == ti, "Unexpected block"

    # Test with 'apply' in args
    ti.args = {'apply': {'name': 'test'}}
    assert ti.build_parent_block() is not ti, "Unexpected block"

# Generated at 2022-06-21 01:42:19.552547
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude(task_include={'args': {'x': 1, 'bla': 'bla', 'tags': [], 'when': ['not x']}})
    ti.vars = {'blub': 'bla', 'x': 2, 'y': 3}

    vars = ti.get_vars()
    assert 'x' in vars and vars['x'] == 2
    assert 'y' in vars and vars['y'] == 3
    assert 'blub' in vars and vars['blub'] == 'bla'
    assert 'bla' in vars and vars['bla'] == 'bla'
    assert 'tags' not in vars
    assert 'when' not in vars

# Test that get_vars' handling of 'include' tasks is correct
# Use

# Generated at 2022-06-21 01:42:30.388371
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()
    task_include.load({
        'action': 'include',
        'debugger': Sentinel(),
        'args': {
            'foo': 'bar'
        },
        'apply': {
            'bar': 'baz'
        },
        'file': '/foo/bar.yaml'
    })

    assert task_include.action == 'include'
    assert 'debugger' not in task_include.args
    assert 'debugger' not in task_include.vars
    assert task_include.args.get('foo') == 'bar'
    assert task_include.vars.get('foo') == 'bar'
    assert 'file' not in task_include.args
    assert task_include.args.get('_raw_params') == '/foo/bar.yaml'


# Generated at 2022-06-21 01:42:39.680773
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.statically_loaded = True
    new_task_include = task_include.copy()
    assert task_include.action == new_task_include.action
    assert task_include.statically_loaded == new_task_include.statically_loaded
    assert 'name' in task_include.args
    assert 'name' in new_task_include.args
    assert task_include.args['name'] == new_task_include.args['name']
    assert 'tags' in task_include.args
    assert 'tags' in new_task_include.args
    assert task_include.args['tags'] == new_task_include.args['tags']


# Generated at 2022-06-21 01:43:08.914350
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    field = FieldAttribute()
    block = Block()
    dict_task = dict(name='test', test='test', debug='test')
    task_include = TaskInclude(block=block, role=None, task_include=None)
    assert task_include.vars is not None
    assert task_include.role is not None
    assert task_include.block is not None
    assert task_include.task_include.action is not None
    assert task_include.task_include.args is not None
    assert task_include.task_include.collections is not None
    assert task_include.task_include.debugger is not None
    assert task_include.task_include.ignore_errors is not None
    assert task_include.task_include.loop is not None

# Generated at 2022-06-21 01:43:18.823401
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This tests the get_vars() method of TaskInclude to make sure it
    behaves as expected.
    '''
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.role.include as role_include
    from ansible.playbook.task_include import TaskInclude

    task_block = Block()
    play_context = PlayContext()
    task1 = TaskInclude()
    task1.action = 'include'
    task1.vars.update({'foo': 'bar'})
    task1.args.update({'file': 'test_include.yml'})
    task1.set_loader(None)
    task1.set_play_context(play_context)
    task1.set_block(task_block)
    task_block._parent

# Generated at 2022-06-21 01:43:27.550226
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    task = dict(
        name='foobar',
        action='include',
        args=dict(
            file='/path/to/file'
        )
    )

    ti = TaskInclude(block=None, role=None, task_include=None)

    ti = ti.load(task, variable_manager=None, loader=None)
    assert ti.name is 'foobar'
    assert ti.action == 'include'
    assert ti.args == dict(file='/path/to/file')


# Generated at 2022-06-21 01:43:38.438740
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    fake_root = {}

    ti = TaskInclude()
    assert ti._parent == fake_root
    assert ti.action == 'include'
    assert ti.args == {'_raw_params': None}

    fake_parent = {'name': 'fake_task'}
    ti = TaskInclude(block=fake_parent)
    assert ti._parent == fake_parent
    assert ti.action == 'include'
    assert ti.args == {'_raw_params': None}

    del fake_root['name']
    del fake_parent['name']
    ti = TaskInclude(role=fake_root)
    assert ti._parent == fake_root
    assert ti.action == 'include'
    assert ti.args == {'_raw_params': None}

    ti = TaskInclude(role=fake_parent)


# Generated at 2022-06-21 01:43:49.436281
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''Unit test for method preprocess_data of class TaskInclude'''
    import pytest
    from collections import namedtuple

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.task_include import TaskInclude

    # fake objects needed
    variable_manager = None
    loader = None
    play_context = PlayContext()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [],
        tasks = [],
    ), variable_manager=variable_manager, loader=loader)
    block = None

# Generated at 2022-06-21 01:43:57.398199
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    obj = dict(action='include_tasks', file='foo.yml', bar=None)
    ti = TaskInclude(block=None, role=None, task_includes=None)
    obj2 = ti.preprocess_data(obj)
    assert obj['file'] == obj2['_raw_params']
    assert not obj2['bar']

    # check that valid keywords are not removed
    obj = dict(action='include_role', file='foo.yml', name='foo', tasks_from='bar', bar=None, check_mode=True)

# Generated at 2022-06-21 01:43:59.669702
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task1 = TaskInclude()
    task1.statically_loaded = False
    task2 = task1.copy()
    assert task1.statically_loaded == task2.statically_loaded

# Generated at 2022-06-21 01:44:10.066428
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Test pre-existing TaskInclude
    class TestTaskInclude(TaskInclude):
        my_custom_attribute = FieldAttribute(isa='string', default='value_default')

    task_include = TestTaskInclude()

    # Create a TaskInclude to test
    task_include.action = 'include'
    task_include.name = 'test'
    task_include.my_custom_attribute = 'value'
    task_include.args['apply'] = {
        'name': 'apply_name'
    }

    # Create a TaskInclude to use as parent
    parent_task_include = TestTaskInclude()
    parent_task_include.name = 'parent_test'
    task_include._parent = parent_task_include

    # Test copy
    copy_task_include = task_include.copy()

   

# Generated at 2022-06-21 01:44:14.642022
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_1 = TaskInclude.load({
        'action': 'include',
        'file': 'roles/foo/tasks/bar.yml'
    })
    assert task_1.action == 'include'
    assert task_1.args['_raw_params'] == 'roles/foo/tasks/bar.yml'

    task_2 = TaskInclude.load({
        'action': 'include',
        'file': 'roles/foo/tasks/bar.yml',
        'apply': {
            'block': []
        }
    })
    assert task_2.action == 'include'
    assert task_2.args['_raw_params'] == 'roles/foo/tasks/bar.yml'
    assert isinstance(task_2.args['apply'], Block)

   

# Generated at 2022-06-21 01:44:27.603054
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.vars.manager
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    import ansible.parsing.dataloader
    import ansible.playbook.role.definition
    import ansible.utils.vars
    import ansible.playbook.handlerlist
    import ansible.template.template
    import ansible.errors


    # create a role definition
    role_definition = ansible.playbook.role.definition.RoleDefinition()
    # assign a name for the role definition
    role_definition._role_name = 'some.name'

    # create a fake play