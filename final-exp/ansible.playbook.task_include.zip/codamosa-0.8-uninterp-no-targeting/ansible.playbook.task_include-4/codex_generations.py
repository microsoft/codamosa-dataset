

# Generated at 2022-06-21 01:34:54.003624
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host = ansible.inventory.host.Host('testhost')
    play = Play().load({}, variable_manager=VariableManager(), loader=DataLoader())
    play._variable_manager.extra_vars = combine_vars(play._variable_manager.extra_vars, dict(parent_var=True))


# Generated at 2022-06-21 01:34:56.124938
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    class TestApply():
        pass

    t_apply=TestApply()
    ti = TaskInclude(apply=t_apply)
    assert ti.apply == t_apply

# Generated at 2022-06-21 01:35:04.154122
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.role.include import IncludeRole
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role_context

    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:35:14.937519
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(
        loop_control=dict(
            loop_var='item'
        ),
        loop='{{ my_list }}',
        name='name',
        become='yes',
        _raw_params='include.yml',
        file='file',
    )

    ti = TaskInclude()

    # Action is needed to trigger validation, only set it to 'include' as this
    # method is also used by HandlerTaskInclude which should not change.
    data['action'] = 'include'

    # Case 1: Action is 'include' and 'include' keyword is present
    data['include'] = 'yes'
    result = ti.preprocess_data(data)
    assert 'include' not in result

    # Case 2: Action is 'include' and 'include' keyword is not present
    data.pop('include')


# Generated at 2022-06-21 01:35:27.014997
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti_include = TaskInclude()
    ti_import_playbook = TaskInclude()
    ti_import_role = TaskInclude()
    ti_includ_role = TaskInclude()

    ti_include.action = 'include'
    ti_import_playbook.action = 'import_playbook'
    ti_import_role.action = 'import_role'
    ti_includ_role.action = 'include_role'

    ti_include.vars = {'x' : 'y'}
    ti_include.args = {'a' : 'b'}

    ti_import_playbook.vars = {'x' : 'y'}
    ti_import_playbook.args = {'a' : 'b'}


# Generated at 2022-06-21 01:35:33.270256
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    t = TaskInclude()
    assert t
    assert t.action == ''
    assert not t.statically_loaded

    # FIXME: This test is incomplete...
    # We need to mock a simple playbook and provide it to the test
    # Playbook.load
    #     Playbook.set_loader
    #         Playbook._load_tasks_from_block
    #             TaskInclude.load

# Generated at 2022-06-21 01:35:44.195536
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    display.verbosity = 3
    valid_yaml_data = dict(
    action='include_role',
    name='common_services',
    apply=dict(
        import_playbook='/etc/ansible/playbooks/common_services.yaml',
        import_tasks=[
            dict(block=[]),
            dict(block=[]),
        ],
    ),
    )
    task = TaskInclude.load(
        valid_yaml_data,
        play=None,
        task_include=None,
        role=None,
        variable_manager=None,
        loader=None,
    )
    assert task.action == 'include_role'
    assert task.name == 'common_services'
    assert task.build_parent_block() is task

# Generated at 2022-06-21 01:35:51.505140
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test the method `build_parent_block` of class `TaskInclude`.
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import TaskIncludeRole
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader.lookup_loader import LookupModule
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar

    class PluginLookup(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            print(str(terms))
            print(str(variables))

# Generated at 2022-06-21 01:35:57.942235
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext, DefaultVars

    ti = TaskInclude(block=Block(), role=Role(), task_include=TaskInclude())
    ti.action = 'include'
    ti.args = { 'file': '/tmp/included_tasks/main.yml' }
    ti.vars = { 'var1': 'val1' }
    ti.statically_loaded = True

    ti.block_type = 'tasks'
    ti.tags = ['include']
    ti.when = 'always'
    ti.delegate_to = '127.0.0.1'

# Generated at 2022-06-21 01:36:03.451739
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    data = {}
    apply_attrs = {}
    data['apply'] = apply_attrs
    # 1. without block
    ti = TaskInclude()
    ti.args = data
    result = ti.build_parent_block().__class__.__name__
    expected_result = 'TaskInclude'
    assert result == expected_result

    # 2. with block
    apply_attrs['block'] = []
    result = ti.build_parent_block().__class__.__name__
    expected_result = 'Block'
    assert result == expected_result

# Generated at 2022-06-21 01:36:13.524251
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = Task()
    # Invalid options
    data = dict(action='include_tasks', _raw_params='test.yml', bad_option=1)
    task = Task.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    with pytest.raises(AnsibleParserError) as exec_info:
        ti.check_options(task, data)
    assert exec_info.value.message == 'Invalid options for include_tasks: bad_option'
    # Valid options
    data = dict(action='include_tasks', _raw_params='test.yml', apply={'a': 1}, other={'b':2})

# Generated at 2022-06-21 01:36:24.203595
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Given:
    # Class `TaskInclude()`
    attributes = {
        'action': 'include',
        'args': {
            'arg1': 'value1',
            'arg2': 'value2'
        },
        'block': None,
        'name': 'included task',
        'role': None,
        'task_include': None,
        'vars': {
            'var1': 'value1'
        }
    }

    # When:
    ti = TaskInclude(**attributes)

    # Then:
    assert ti.get_vars() == {
        'arg1': 'value1',
        'arg2': 'value2',
        'var1': 'value1'
    }

# Generated at 2022-06-21 01:36:36.458946
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()

    play = Play.load({
        'hosts': 'localhost',
        'name': 'Test include',
        'gather_facts': 'no',
        'tasks': [{'include_tasks': 'include_test.yml'}],
    }, variable_manager=VariableManager(), loader=None)


# Generated at 2022-06-21 01:36:44.825681
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti1 = TaskInclude()
    ti2 = ti1.copy()
    assert ti1.statically_loaded == ti2.statically_loaded
    # test 'exclude_parent=True' and 'exclude_tasks=True'
    ti1.statically_loaded = True
    ti1._parent = True
    ti1._block = True
    ti2 = ti1.copy(exclude_parent=True, exclude_tasks=True)
    assert ti1.statically_loaded == ti2.statically_loaded
    assert ti1._parent != ti2._parent
    assert ti1._block != ti2._block


# Generated at 2022-06-21 01:36:57.188604
# Unit test for method copy of class TaskInclude

# Generated at 2022-06-21 01:37:09.397191
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    class TaskInclude
    tests:
    TaskInclude.load()
    '''
    import json

    data = '''
        - include: '/home/daniel/myfile2.yml'
          name: "should be ignored"
          tags: "a tag"
          ignore_errors: yes
          no_log: yes
          when: "1 == 1"
          apply:
            block:
              - debug: msg: "Inside the block"
          args:
            some_var: "some_value"
      '''
    data = json.loads(data)
    data = '\n'.join(json.dumps(data).split())
    data = '\n'.join(data.split())
    data = load_from_file(data, "/tmp/test.yml")

# Generated at 2022-06-21 01:37:20.849861
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    p = Play().load({
        'name': 'test play',
        'connection': 'local',
        'hosts': ['localhost'],
        'gather_facts': 'no',
        'tasks': [
            {'include': 'some_filename', 'unknown_key': 1234},
        ]
    }, variable_manager=None, loader=None)

    ti = TaskInclude()
    ti2 = TaskInclude()

    # check with invalid args
    task = ti.copy()
    task.validate_attributes(task.static_data)
    with pytest.raises(AnsibleParserError):
        ti.check_

# Generated at 2022-06-21 01:37:31.014245
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t_i = TaskInclude()
    vars = { 'a': 10 }
    t_i.vars = vars
    args = { 'b': 20 }
    t_i.args = args

    all_vars = t_i.get_vars()
    assert('a' in all_vars)
    assert('b' in all_vars)
    assert('tags' not in all_vars)
    assert('when' not in all_vars)

# Generated at 2022-06-21 01:37:44.469479
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # testcase 1
    ds = {'action': 'include', 'file': 'file1'}
    ti = TaskInclude()
    assert ds == ti.preprocess_data(ds)
    # testcase 2
    ds = {'action': 'include', 'file': 'file1', 'a': 'b', 'c': 'd'}
    assert ds == ti.preprocess_data(ds)
    # testcase 3
    ds = {'action': 'include', 'file': 'file1', 'a': 'b', 'c': 'd'}
    ti = TaskInclude()
    ti._role = True
    ds.pop('a')
    ds.pop('c')
    assert ds == ti.preprocess_data(ds)
    # testcase 4

# Generated at 2022-06-21 01:37:56.616224
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import VariableResolver
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    task = Task()
    task.action = 'include'
    task.args = {'file': 'include.yml', 'apply': {'hosts': 'host1'}}
    task._role = None
    task._block = None
    task._parent = None
    task._play = None
    task._play_context = PlayContext()
    task._play_context._

# Generated at 2022-06-21 01:38:13.830782
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    global_block = Block()

    def data_factory(action, args_dict=None, file_name='unit test include'):
        args_dict = args_dict if args_dict is not None else {}
        data = {'action': action, 'args': args_dict}
        if action in C._ACTION_INCLUDE:
            data['args']['_raw_params'] = file_name
        return data


# Generated at 2022-06-21 01:38:24.900529
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    variable_manager = None
    loader = None

    assert TaskInclude.load(
        dict(action='include_tasks', file='./modules/action.yml', name='test-task-include', tags=['test_include']),
        variable_manager=variable_manager,
        loader=loader,
    ) is not None

    # should fail with invalid kwarg
    try:
        TaskInclude.load(
            dict(action='include_tasks', file='./modules/action.yml', name='test-task-include', tags=['test_include'], invalid_kwarg='Invalid'),
            variable_manager=variable_manager,
            loader=loader,
        )
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-21 01:38:33.761402
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block(play=None, parent_block=None, role=None, task_include=None)
    task_include = TaskInclude(block=block, role=None, task_include=None)
    task_include.action = "some_task"
    task_include.args = {'param1': 1}
    assert {'param1': 1} == task_include.get_vars()

    task_include.action = "include"
    task_include.args = {'param1': 1}
    block.vars = {'block_var': 2}
    block.get_vars = lambda : {'block_var': 3}
    assert {'param1': 1, 'block_var': 3} == task_include.get_vars()

# Generated at 2022-06-21 01:38:42.019929
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    d_vars = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': 'g'
        }
    }
    d_args = {
        'h': 'i',
        'j': {
            'k': 'l',
            'm': 'n'
        }
    }

    # 1. Action 'include'
    ti = TaskInclude()
    ti._parent = Block()
    ti.action = 'include'
    ti.vars = d_vars
    ti.args = d_args
    # Calling get_vars should return variables from the root block, task, and given args
    # (skipping tags and when)
    assert ti.get_vars() == d_vars
    ti._parent.vars = d_args


# Generated at 2022-06-21 01:38:47.411611
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    class MyTaskInclude(TaskInclude):

        def __init__(self, variable_manager=None, loader=None, play_context=None, new_play=None, templar=None, args=None):
            self._play_context = play_context
            self._variable_manager = variable_manager
            self._loader = loader
            self._templar = templar
            self._parent = new_play
            self.vars = {}
            self.action = 'include'
            self.args = {'a': 'b'}

# Generated at 2022-06-21 01:38:58.331900
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    block = Block()
    role = object()
    task_include = object()
    task = TaskInclude(block, role, task_include)

    # Valid ansible action, no error expected
    data = {'action': 'debug'}
    task.check_options(task.load_data(data), data)

    # Invalid ansible action, error expected
    data = {'action': 'foo'}
    try:
        task.check_options(task.load_data(data), data)
        assert False
    except AnsibleParserError:
        assert True

    # Invalid ansible action (include), no error expected
    data = {'action': 'include'}
    task.check_options(task.load_data(data), data)

    # Valid ansible action, but bad options, no error expected

# Generated at 2022-06-21 01:39:10.390155
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Test load() method of class TaskInclude
    """
    #test TaskInclude with action=import_tasks and no apply
    task = {
        'include': 'path/to/tasks/main.yml',
        'tags': ['tag1', 'tag2']
    }
    ti = TaskInclude()
    task_include = ti.load(task)
    assert task_include.action == 'include'
    assert task_include.args['_raw_params'] == 'path/to/tasks/main.yml'
    assert task_include.args['apply'] == {}
    assert task_include.tags == ['tag1', 'tag2']

    #test TaskInclude with action=import_tasks and apply

# Generated at 2022-06-21 01:39:20.466413
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class MockSentinel(object):
        def __str__(self):
            return 'sentinel'

        def __repr__(self):
            return 'sentinel'

    sentinel = MockSentinel()

    # Static include
    include_data = {
        'include': {
            'action': 'include',
            'args': {
                'file': 'some_file',
            },
        },
    }
    expected_all_vars = {'file': 'some_file'}

    task = TaskInclude.load(
        include_data,
        loader=None,
        variable_manager=None,
    )
    all_vars = task.get_vars()
    assert all_vars == expected_all_vars

    # Static include role

# Generated at 2022-06-21 01:39:30.545006
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.role_include import Task as HandlerTask

    # create the Block for our fake parent task
    parent_block = Block([])
    parent_block._play = Play().load({}, variable_manager=VariableManager(), loader=DataLoader())
    parent_block._play._inventories = InventoryManager()
    del parent_block._role
    parent_block._loop = None
    parent_block._parent = None

    # create the parent Task
    parent_task = Task({}, block=parent_block)

    # create the role

# Generated at 2022-06-21 01:39:40.033935
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''make sure the get_vars method of TaskInclude yields a dict
    of the expected structure.
    '''
    from ansible.playbook.block import Block

    b = Block()
    b.vars = dict(a=1, b=2)

    ti = TaskInclude(block=b)
    ti._parent = b

    # make sure the lookup of parent.get_vars is not used for either
    # of the derived TaskInclude classes
    ti.action = "import_tasks"
    assert ti.get_vars() == dict(a=1, b=2)
    ti.action = "import_role"
    assert ti.get_vars() == dict(a=1, b=2)

    ti.action = "include"

# Generated at 2022-06-21 01:39:58.975428
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import mock as m

    data = m.Mock()
    data.args = {'file': 'mock'}

    def load_data(data):
        return TaskInclude.load_data(data, m.Mock(), m.Mock())
    task_include = m.Mock(side_effect=load_data)
    task_include.VALID_ARGS = TaskInclude.VALID_ARGS
    task_include.BASE = TaskInclude.BASE
    task_include.OTHER_ARGS = TaskInclude.OTHER_ARGS

    with m.patch('ansible.playbook.task_include.TaskInclude.load_data', task_include):
        task_include.check_options(task_include.load_data(data), data)


# Generated at 2022-06-21 01:40:10.988534
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class Object(object):
        pass

    pc = PlayContext() # mock
    loader = None # mock
    my_vars = dict(a=1, b='2')
    vm = VariableManager(loader=loader, inventory=InventoryManager())
    vm.set_vars(my_vars)

    task = TaskInclude.load(
        data=dict(
            action='include_tasks',
            file='test.yml',
        ),
        block=None,
        role=None,
        task_include=None,
        variable_manager=vm,
        loader=loader,
    )
    assert task.action == 'include_tasks'


# Generated at 2022-06-21 01:40:11.558094
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    pass

# Generated at 2022-06-21 01:40:20.960250
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Set up mocks
    block_mock = Mock()
    block_mock.load.return_value = 'test_parent_block'
    self_mock = Mock()
    self_mock._parent = 'test_parent'
    self_mock._role = 'test_role'
    self_mock._variable_manager = 'test_variable_manager'
    self_mock._loader = 'test_loader'

    # Test with apply specified
    self_mock.args = {'apply': True}
    res = TaskInclude.build_parent_block(self_mock)
    assert res == 'test_parent_block'

# Generated at 2022-06-21 01:40:29.829957
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test for preprocessing of action, vars and import_playbook
    ds = {'action': 'include', 'tags': ['baz'], 'vars': {'var': 'val'}, 'import_playbook': 'hello.yml'}
    ti = TaskInclude()
    ret = ti.preprocess_data(ds)
    assert ret == {'action': 'include', 'tags': ['baz'], 'vars': {'var': 'val'}}
    assert ds == {'action': 'include', 'tags': ['baz'], 'vars': {'var': 'val'}, 'import_playbook': 'hello.yml'}

    # Test for preprocessing of other keywords

# Generated at 2022-06-21 01:40:41.411073
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Testing TaskInclude.check_options
    ti = TaskInclude(block=Block(name='test-block'), role=None, task_include=None)
    task = Task(block=None, role=None, task_include=None)
    task.args = {'_raw_params': 'test-file.yml', 'tasks-on-error': 'ignore'}
    task.action = 'include_tasks'

# Generated at 2022-06-21 01:40:50.080300
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Each test will have a dictionary with the following properties:
    # 'ds': the dictionary to be used to create a task include
    # 'expected_result': the dictionary that is expected as a result.
    # 'expected_error': the exception class that is expected to be thrown by preprocess_data
    # 'expected_error_msg': the error message that is expected to be thrown by preprocess_data
    # 'expected_warning': a

# Generated at 2022-06-21 01:40:55.807523
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    assert TaskInclude.load(data={'action': 'include_role', 'name': 'myRole', 'tasks_from': 'some_file', 'vars': {'foo': 'bar'}})
    assert TaskInclude.load(data={'action': 'include', 'name': 'myRole', 'tasks_from': 'some_file', 'vars': {'foo': 'bar'}})
    assert TaskInclude.load(data={'action': 'import_tasks', 'name': 'myRole', 'tasks_from': 'some_file', 'vars': {'foo': 'bar'}})
    assert TaskInclude.load(data={'action': 'import_role', 'name': 'myRole', 'tasks_from': 'some_file', 'vars': {'foo': 'bar'}})


# Generated at 2022-06-21 01:41:03.325731
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude, HandlerTaskInclude

    all_tasks_classes = {
        'include': TaskInclude,
        'import_playbook': TaskInclude,
        'import_tasks': TaskInclude,
        'import_role': TaskInclude,
        'meta': TaskInclude,
        'include_role': TaskInclude,
        'include_tasks': TaskInclude,
        'include_vars': TaskInclude,
        'block': TaskInclude,
        'role': TaskInclude,
        'handler': HandlerTaskInclude,
    }


# Generated at 2022-06-21 01:41:10.501184
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t = TaskInclude.load(
        {'action': 'include', 'file': 'somedir/somefile.yml'},
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )
    copy = t.copy()
    assert copy.action == t.action
    assert copy.args == t.args
    assert copy.statically_loaded == t.statically_loaded

# Generated at 2022-06-21 01:41:29.631067
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    data = dict(
        apply=dict(
            name='include_role1',
            tags=['role1'],
            ignore_errors=True,
            force_handlers=False,
        ),
        name='role1',
    )

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)   
    # Check if the ActionBase attributes are static or dynamic
    assert isinstance(task._attributes, dict)
    for attr_name, attr_val in task._attributes.items():
        assert isinstance(attr_name, str)

# Generated at 2022-06-21 01:41:41.118988
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    myblock = Block()
    mytask = Task()
    mytask.set_loader(None)
    mytask.action = 'shell'
    mytask._parent = myblock
    myblock._play = None
    myblock._role = None
    myblock.vars = dict()
    myblock.args = dict()
    myblock.block = [mytask]
    myblock.always_run = True
    myblock._loop = None
    myblock._when = []
    myblock._attributes = FieldAttribute(myblock)
    myblock._dep_chain = None

    mytaskin = TaskInclude()
    mytaskin.set_loader(None)
    mytaskin.action = 'include'
    mytaskin._parent = myblock
    mytaskin._play = None

# Generated at 2022-06-21 01:41:42.743035
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.statically_loaded == False

# Generated at 2022-06-21 01:41:51.160747
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # initialize a TaskInclude instance, and set args attribute
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.args = {
        'a': 0,
        'b': 1,
        'tags': ['tag1'],
        'when': 'ansible_test == 1'
    }

    # test 'include' task, expect to get vars including args
    ti.action = 'include'
    assert ti.get_vars() == {
        'a': 0,
        'b': 1,
    }

    # test 'include_role' task, expect to get vars without args
    ti.action = 'include_role'
    assert ti.get_vars() == {
    }


# Generated at 2022-06-21 01:42:01.624083
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = dict(
      file='./tasks/main.yml',
      apply=dict(
        action='all',
      )
    )
    variable_manager = "mock_variable_manager"
    loader = "mock_loader"

    # When call to load and it passes validation
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task._parent is None
    assert task.statically_loaded is False
    assert 'action' in task.args
    assert 'args' in task.args
    assert 'collections' in task.args
    assert 'debugger' in task.args
    assert 'ignore_errors' in task.args
    assert 'loop' in task.args
    assert 'loop_control' in task.args
    assert 'loop_with'

# Generated at 2022-06-21 01:42:12.768532
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import unittest
    import copy
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    class TestTaskIncludeOptions(unittest.TestCase):
        def setUp(self):
            class Play(object):
                pass
            self.play_context = PlayContext()
            self.play = Play()
            self.play._ds = dict()
            self.play._play = self.play
            self.play._play_context = self.play_context
            self.variable_manager = VariableManager(
                loader=DictDataLoader({}),
                play_context=self.play_context
            )


# Generated at 2022-06-21 01:42:21.805396
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    # test checks for action `include`
    task = ti.load(data=dict(action='include', file='file'), loader=None)
    assert task.statically_loaded is False
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'file'
    # test checks for action `import_role`
    task = ti.load(data=dict(action='import_role', file='file', name='name', apply=dict(s=1)), loader=None)
    assert task.statically_loaded is False
    assert task.action == 'import_role'
    assert task.args['file'] == 'file'
    assert task.args['_raw_params'] == 'file'
    assert task.args['name'] == 'name'
    assert task.args

# Generated at 2022-06-21 01:42:31.702899
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    playbook_code = '''
    - include: ./block_vars_with_include_role.yml
    '''
    variable_manager = VariableManager()
    loader = DataLoader()

    p = Play().load(playbook_code, variable_manager=variable_manager, loader=loader)
    pc = PlayContext()
    t = p.get_tasks()[0]
    t.post_validate(pc)
    from ansible.plugins.loader import include_role_plugin
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-21 01:42:37.394448
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.utils.sentinel import Sentinel
    from ansible.playbook.play import Play

    class Args:
        pass

    class VarManager(object):
        def get_vars(self, loader, play, task_vars=None, include_hostvars=True):
            pass

    my_args = Args()
    my_ti = TaskInclude()
    my_vs = VarManager()
    my_pb = Play.load(dict(name='my_play'), variable_manager=my_vs, loader=None)
    my_pb._tasks = [my_ti]
    my_ti.block = my_pb
    my_ti.action = 'include'
    my_ti._role = None

    my_ds = dict()

# Generated at 2022-06-21 01:42:47.394173
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Checks if the TaskInclude.check_options method properly returns
    the expected Exception in case of invalid options.
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Fixture
    class DummyTaskInclude(TaskInclude):

        def __init__(self):
            self.args = {'bad_option': ''}
            self.action = 'include'
            self.name = 'dummy'

        def check_options(self, task, data):
            return super(DummyTaskInclude, self).check_options(task, data)

    class DummyIncludeTask(Task):

        def __init__(self):
            self.args = {'bad_option': ''}

# Generated at 2022-06-21 01:43:11.541374
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    playbook1 = Play()
    playbook2 = Play()
    task1 = TaskInclude()
    task2 = TaskInclude()
    playbook1.tasks = [task1]
    playbook2.tasks = [task2]
    task1.context = PlayContext()
    task2.context = PlayContext()
    task1.context.become = True
    task1.context.become_method = 'sudo'
    task1.context.become_user = 'root'
    task1.context.remote_user = 'user'
    task1.context.connection = 'local'
    task1.context.module_name = 'command'
    task1.context.module_args = 'whoami'


# Generated at 2022-06-21 01:43:18.751236
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import sys
    import pytest

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    block = Block()
    block.args = {}
    block.action = 'import_role'

    task = TaskInclude(block=block)

    data = dict(
        ignore_errors=False,
        file='foo.yml',
        action='import_playbook',
        tags='all',
        args=dict(
            foobar='foo',
        ),
    )

    try:
        task.check_options(task._load_data(data), data)
        assert False
    except AnsibleParserError as e:
        assert 'Invalid options for import_playbook: foobar' in str(e)


# Generated at 2022-06-21 01:43:21.511864
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Test a TaskInclude without _parent
    ti1 = TaskInclude()
    ti2 = ti1.copy()
    assert ti1.__dict__.keys() == ti2.__dict__.keys()

    # Test a TaskInclude with _parent
    ti3 = TaskInclude()
    ti4 = ti3.copy()
    assert ti3.__dict__.keys() == ti4.__dict__.keys()

# Generated at 2022-06-21 01:43:24.568703
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.statically_loaded = True
    task = task_include.copy()
    assert task.action == 'include'
    assert task.statically_loaded

# Generated at 2022-06-21 01:43:29.360437
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    fields = ['action', 'args', 'block', 'dynamic_block', 'failed_when', 'ignore_errors',
              'include', 'loop', 'loop_args', 'name', 'notify', 'role', 'register', 'run_once',
              'statically_loaded', 'include_tasks', 'tags', 'task_include', 'tasks', 'until', 'when']
    assert set(TaskInclude()._fields) == set(fields)

# Generated at 2022-06-21 01:43:34.234407
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = Task(action='import_tasks')
    with pytest.raises(AnsibleParserError):
        ti.check_options(task, obj={})

    task = Task(action='include_tasks')
    with pytest.raises(AnsibleParserError):
        ti.check_options(task, obj={})

    task = Task(action='include_role')
    with pytest.raises(AnsibleParserError):
        ti.check_options(task, obj={})

    task = Task(action='import_role')
    with pytest.raises(AnsibleParserError):
        ti.check_options(task, obj={})

    task = Task(action='include')
    with pytest.raises(AnsibleParserError):
        ti.check

# Generated at 2022-06-21 01:43:40.929975
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_name = 'test play'
    play_context = PlayContext()
    play_source = {'name': play_name, 'hosts': 'all', 'gather_facts': 'no'}
    my_play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())

    play_context.become = False
    play_context.become_user = None
    play_context.connection = 'ssh'
    play_context.remote_addr = '10.0.0.1'
    play_context.port = 22

# Generated at 2022-06-21 01:43:48.141539
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    data = {'action': 'include_tasks', 'file': 'myfile', 'new_key': 'new_value'}
    processed_data = task_include.preprocess_data(data)
    assert 'new_key' not in processed_data
    assert 'action' in processed_data
    assert processed_data['action'] == 'include_tasks'
    assert 'file' in processed_data
    assert processed_data['file'] == 'myfile'

# Generated at 2022-06-21 01:43:57.739547
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # When `apply` is specified, it is expected that a `Block` is created with the
    # attributes specified in `apply`
    block_attrs = {
        'block': [],
        'name': 'set_fact',
        'always_run': True
    }

    task_attrs = {
        'action': 'include_role',
        '_raw_params': 'tests/test_tasks/test_role/tasks/set_fact.yml',
        'apply': block_attrs
    }

    ti = TaskInclude()
    ti.args = task_attrs

    assert isinstance(ti.build_parent_block(), Block)

    # When `apply` is not specified, it is expected that the TaskInclude is returned
    del task_attrs['apply']

    ti = TaskInclude()

# Generated at 2022-06-21 01:44:07.620972
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # action and file are allowed, because they are not static
    # but no other options are allowed and must be skipped
    # when action is not static
    data1 = dict(
        action="include",
        something_else="foo",
        file="file.yml",
    )
    task_include = TaskInclude(block=None, role=None, task_include=None)
    data1_result = task_include.preprocess_data(ds=data1)
    data1_expected = dict(
        action="include",
        file="file.yml",
    )
    assert data1_result == data1_expected

    # all options are allowed for static includes
    data2 = dict(
        action="include_tasks",
        something_else="foo",
        file="file.yml",
    )
   

# Generated at 2022-06-21 01:44:45.628918
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display = Display()
    display.verbosity = 4
    task_include = TaskInclude()
    task_include.action = 'include_role'
    original_ds = {'name': 'good', 'action': 'include_role', 'bad_option': 'some_value'}
    ds = task_include.preprocess_data(original_ds.copy())
    assert(ds == {'name': 'good', 'action': 'include_role'}, "TaskInclude.preprocess_data() failed to keep expected attributes")