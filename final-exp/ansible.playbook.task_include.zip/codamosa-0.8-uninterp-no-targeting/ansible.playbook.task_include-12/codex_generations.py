

# Generated at 2022-06-21 01:34:54.761135
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test for TaskInclude.get_vars
    '''
    # Setup
    def get_tasks(**kwargs):
        d = dict(
            action='include_tasks',
            args=dict(
                _raw_params='test.yml',
                tags=['test'],
                when='test'
            ),
            static=True,
            include_role=dict(name='test')
        )
        d.update(kwargs)
        data = d
        block = None
        role = None
        task_include = None
        variable_manager = None
        loader = None

        return TaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    # Test for action 'include_tasks

# Generated at 2022-06-21 01:35:03.199404
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    ti.action = 'include'

    # no raw params
    ti.args = dict()
    try:
        ti.check_options(ti, {})
        assert False, 'No file option should have raised an error'
    except AnsibleParserError as e:
        assert str(e) == 'No file specified for include', 'Got the wrong error message: %s' % str(e)

    # file option present, but not as an arg
    ti.args = dict(not_file='test')
    try:
        ti.check_options(ti, {})
        assert False, 'No file option should have raised an error'
    except AnsibleParserError as e:
        assert str(e) == 'No file specified for include', 'Got the wrong error message: %s' % str(e)



# Generated at 2022-06-21 01:35:10.202773
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    attrs = { 'file':'filename', 'ignore_errors': True }
    new_ti = ti.copy(exclude_parent=True, exclude_tasks=True)
    assert new_ti.statically_loaded == ti.statically_loaded


# Generated at 2022-06-21 01:35:18.320503
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    TaskInclude: Test for method build_parent_block
    """
    for action in C._ACTION_ALL_INCLUDE_TASKS:
        if action != 'include':
            ti = TaskInclude()
            ti.action = action
            ti.set_loader(None)
            parent = Task()
            parent.set_loader(None)
            parent._play = None
            parent._role = None
            parent._variable_manager = None
            ti.set_parent(parent)
            ti.args['apply'] = {'block': None}

            # test if required arg 'block' is present in args
            assert 'block' in ti.args['apply']
            p_block = ti.build_parent_block()

            # test value of p_block
            assert p_block.block == None

# Generated at 2022-06-21 01:35:30.328080
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class DummyTask(TaskInclude):
        def __init__(self, action):
            super(DummyTask, self).__init__()
            self.action = action
        @staticmethod
        def load(data, action):
            return DummyTask(action).check_options(
                DummyTask(action).load_data(data),
                data,
            )

    d = {
        'action': 'include',
        'file': 'foo'
    }
    ti = DummyTask.load(d, action='include')
    assert(ti.preprocess_data(d) == {'action': 'include', 'file': 'foo'})
    assert(ti.action == 'include')
    assert(ti.args['file'] == 'foo')


# Generated at 2022-06-21 01:35:41.354324
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.play

    ti = ansible.playbook.task.TaskInclude()
    ti.action = 'include'
    ti.vars = dict(a=1)
    ti.args = dict(b=2)
    ti.tags = ['test']
    ti.when = 'test'
    ansible.playbook.block.Block._add_parent_attribute(ti) # NOTE: mocking
    assert ti.get_vars() == dict(a=1, b=2)

    ti = ansible.playbook.task.TaskInclude()
    ti.action = 'include_role'
    ti.vars = dict(a=1)
    ti.args = dict

# Generated at 2022-06-21 01:35:54.891986
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class FakePlay:
        pass

    class FakeParent:
        def get_vars(self):
            return dict(dummy_parent_vars=True)
    fake_play = FakePlay()
    fake_parent = FakeParent()

    fake_data = dict(
        include_data='include_data_value',
        apply={'dummy': 'dummy_value'}
    )

    ti = TaskInclude()
    ti._parent = fake_parent
    ti._play = fake_play
    ti.args = fake_data

    p_block = ti.build_parent_block()

    assert p_block.args['dummy'] == 'dummy_value'
    assert p_block.args['block'] == []
    assert p_block.vars == fake_parent.get_vars()
    assert p

# Generated at 2022-06-21 01:36:01.658093
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def _assertEqual(action, args, expected):
        new_me = TaskInclude()
        new_me.action = action
        new_me.args = args
        assert new_me.get_vars() == expected

    _assertEqual("include", {}, {})
    _assertEqual("include", {"a": 1}, {"a": 1})
    _assertEqual("include_role", {"a": 1}, {})

# Generated at 2022-06-21 01:36:14.606852
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_ti = TaskInclude()
    task_ti.action = 'include_role'

    data = dict(
                pre_tasks=[],
                roles=[],
                post_tasks=[]
            )
    data = task_ti.preprocess_data(data)

    assert data is not None
    assert data['pre_tasks'] == []
    assert data['roles'] == []
    assert data['post_tasks'] == []

    data = dict(
        pre_tasks=[],
        roles=[],
        post_tasks=[],
        invalid_key='value'
    )

    data = task_ti.preprocess_data(data)
    assert data is not None
    assert data['pre_tasks'] == []
    assert data['roles'] == []

# Generated at 2022-06-21 01:36:25.186842
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # create TaskInclude from TaskInclude (cloning)
    t = TaskInclude.load(
        dict(
            include="somefile", file="somefile", name="test",
            apply=dict(foo="bar"), bar="baz"
        ),
        block=Block()
    )
    assert t.static_include is False
    assert t.args == dict(_raw_params="somefile", apply=dict(foo="bar"))
    assert t.action == "include"
    assert t.name == "test"

    # create TaskInclude from HandlerTaskInclude (cloning)
    t = TaskInclude.load(
        dict(
            include="somefile", file="somefile", name="test",
            apply=dict(foo="bar"), bar="baz"
        ),
        block=Block()
    )


# Generated at 2022-06-21 01:36:34.397970
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True

    assert ti.copy()
    assert ti.copy().statically_loaded is True
    assert ti.copy(exclude_parent=True, exclude_tasks=True).statically_loaded is True


# Generated at 2022-06-21 01:36:45.220987
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,',)
    ti = TaskInclude()
    ti._role = None
    ti._block = None
    ti._task_include = None
    ti._loader = loader
    ti._variable_manager = variables
    ti._role = None
    ti._block = None
    ti._task_include = None

    # Example of number for a task include that the 'include_tasks' key is invalid
    # task include directly from playbook

# Generated at 2022-06-21 01:36:57.360390
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Test when apply is not specified
    assert TaskInclude().build_parent_block() is TaskInclude()

    task = TaskInclude()

# Generated at 2022-06-21 01:37:08.405884
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=C.DEFAULT_INVENTORY_SOURCES)
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)


# Generated at 2022-06-21 01:37:17.158335
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    play_ds = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
       ]
    )

    p = TaskInclude()
    assert p is not None

    p.load(play_ds)
    assert p.name == 'Ansible Play'

# Generated at 2022-06-21 01:37:26.334973
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class FakeBlock(object):
        def __init__(self):
            self.instance_vars = dict()
            self._role = None
            self._play = None
            self._variable_manager = None
            self._loader = None

        def get_vars(self):
            return {'test':''}

    class FakePlay(object):
        def __init__(self):
            self.instance_vars = dict()
            self._role = None
            self._variable_manager = None
            self._loader = None

        def get_vars(self):
            return {'test':''}

    import ansible.playbook.role
    class FakeRole(ansible.playbook.role.Role):
        def __init__(self):
            self.get_vars = lambda: {'test':''}



# Generated at 2022-06-21 01:37:37.606512
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test for option 'file':
    task = TaskInclude(block=None, role=None, task_include=None)
    task_data = {'action': 'include', 'file': ''}
    ti_cke = task.check_options(task.load_data(task_data, variable_manager=None, loader=None), task_data)
    assert ti_cke.check_option('_raw_params')

    # Test for option 'apply'
    task_data = {'action': 'include', 'apply': {}}
    ti_cke = task.check_options(task.load_data(task_data, variable_manager=None, loader=None), task_data)
    ti_cke.check_option('apply', 'action')
    ti_cke.check_option('apply', 'playbook')

# Generated at 2022-06-21 01:37:43.863605
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    assert task.check_options({'a': 1}, {'a': 1, 'b': 2, 'c': 3}) == {'a': 1}
    assert task.check_options({'a': 1, 'c': 'p'}, {'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'c': 'p'}
    assert task.check_options({'a': 1}, 'do_stuff') == {'a': 1}
    assert task.check_options({'a': 1}, 'include') == {'a': 1}
    assert task.check_options({'a': 1}, 'import_role') == {'a': 1}
    assert task.check_options({'a': 1}, 'import_playbook') == {'a': 1}


# Generated at 2022-06-21 01:37:56.294328
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Test for the `- import_tasks: ...` action
    ds = dict(
        action='import_tasks',
        file='test.yml'
    )
    task = TaskInclude.load(data=ds)
    assert task.action == 'import_tasks'
    assert len(task.args) == 2
    assert task.args['name'] == 'test.yml'

    # Test for the `- include_tasks: ...` action
    ds = dict(
        action='include_tasks',
        file='test.yml',
        tags=['tag1', 'tag2']
    )
    task = TaskInclude.load(data=ds)
    assert task.action == 'include_tasks'
    assert len(task.args) == 3

# Generated at 2022-06-21 01:38:04.691215
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Equivalence Partitioning:
    #      Variables:
    #          apply_attrs = {
    #              'block': [],
    #              'tags': 'include_tags',
    #              'when': 'include_when'
    #          }
    apply_attrs = {
        'block': [],
        'tags': 'include_tags',
        'when': 'include_when'
    }
    task_args = {'apply': apply_attrs}

    # Preparation:
    task_include = TaskInclude()
    task_include.args = task_args
    task_include._parent = Mock()

    result = task_include.build_parent_block()

    # Assertion:
    assert result.block == []
    assert result.tags == 'include_tags'
    assert result

# Generated at 2022-06-21 01:38:19.420871
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 01:38:29.620374
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Load an action plugin to prevent the default action plugin from being used instead
    try:
        ansible.plugins.action.ActionModule = ansible.plugins.action.copy.ActionModule
    except:
        pass

    task = TaskInclude.load(dict(
        action='include',  # task 'action' is required
        file='foo',
        when='something',  # this is ignored for the included tasks
    ), variable_manager=DummyVars())
    assert {'file': 'foo'} == task.get_vars()

    task = TaskInclude.load(dict(
        action='include_role',  # task 'action' is required
        name='foo',
        when='something',  # this is ignored for the included tasks
    ), variable_manager=DummyVars())

# Generated at 2022-06-21 01:38:37.360065
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'first': 'one', 'second': 'two'}
    task.args = {'third': 'three', 'fourth': 'four'}
    task.post_validate()
    vars = task.get_vars()
    assert vars['first'] == 'one'
    assert vars['second'] == 'two'
    assert vars['third'] == 'three'
    assert vars['fourth'] == 'four'
    assert len(vars) == 4


# Generated at 2022-06-21 01:38:46.915996
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import unittest

    mock_loader = unittest.mock.MagicMock()
    mock_variable_manager = unittest.mock.MagicMock()
    mock_task_ds = unittest.mock.MagicMock()

    # Mock parent task which will be given to task_include.
    mock_parent_task = unittest.mock.MagicMock()
    mock_parent_task.get_vars.return_value = {
        'vars_overridden_in_task_include': 'omg'
    }
    mock_parent_task.vars = {
        'vars_in_task_include': 'wtf',
        'vars_overridden_in_task_include': 'bbq',
    }


# Generated at 2022-06-21 01:38:49.182198
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert not ti.statically_loaded

# Generated at 2022-06-21 01:38:54.424725
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = dict()
    block = Block()
    role = None
    task_include = None
    t = TaskInclude(block=block, role=role, task_include=task_include)
    t.load_data(data)
    assert t.statically_loaded == False

# Generated at 2022-06-21 01:39:04.210819
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create TaskInclude object
    ti = TaskInclude()

    # Create dummy data
    ds = {
        'name': 'foo',
        'param_a': 'bar',
        'action': 'include'
    }

    # call method preprocess_data
    ds = ti.preprocess_data(ds)

    # Assert that param_a is not in data anymore
    assert 'param_a' not in ds



# Generated at 2022-06-21 01:39:17.308032
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti_orig = TaskInclude()
    ti_orig.set_loader(None)
    ti_orig._parent = 'TestParent'
    ti_orig.action = 'TestAction'
    ti_orig.statically_loaded = True

    ti_copy = ti_orig.copy()

    assert ti_orig != ti_copy
    assert ti_orig._loader == ti_copy._loader
    assert ti_orig._parent != ti_copy._parent
    assert ti_orig.action != ti_copy.action
    assert ti_orig.statically_loaded == ti_copy.statically_loaded

    ti_copy = ti_orig.copy(exclude_parent=True)
    assert ti_orig._parent != ti_copy._parent

    ti_copy = ti_orig.copy(exclude_tasks=True)
    assert ti_

# Generated at 2022-06-21 01:39:20.309650
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-21 01:39:28.600372
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()

    task_include.vars = {}
    task_include.args = {'apply': {'block': [{'name': 'foo'}], 'debugger': 'on', 'no_log': 'on', 'register': 'result'}}

    block, = task_include.build_parent_block()
    assert isinstance(block, Block)
    assert block.block == [{'name': 'foo'}]
    assert block.debugger == 'on'
    assert block.no_log == 'on'
    assert block.register == 'result'

# Generated at 2022-06-21 01:39:36.420633
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude(block=None, task_include=None)

    # The method just returns the input dict, so we just need to call it.
    ds = dict()
    task.preprocess_data(ds)

# Generated at 2022-06-21 01:39:49.691198
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import LoaderTaskInclude
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.sentinel import Sentinel


# Generated at 2022-06-21 01:40:00.498625
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import sys
    import os

    fake_loader = None
    fake_ds = dict()
    fake_block = None
    fake_role = None
    fake_task_include = None
    variable_manager = None

    fake_ds1 = dict()
    fake_ds2 = dict()
    fake_ds3 = dict()
    fake_ds4 = dict()
    fake_ds5 = dict()
    fake_ds6 = dict()
    fake_ds7 = dict()
    fake_ds8 = dict()
    fake_ds9 = dict()
    fake_ds10 = dict()
    fake_ds11 = dict()
    fake_ds12 = dict()
    fake_ds13 = dict()
    fake_ds14 = dict()
    fake_ds15 = dict()
    fake_ds16 = dict()
    fake

# Generated at 2022-06-21 01:40:06.220833
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    task = TaskInclude.load({
        'name': 'test'
    })

    task.statically_loaded = True
    copied_task = task.copy()

    assert id(task) != id(copied_task)
    assert task.statically_loaded == copied_task.statically_loaded

# Generated at 2022-06-21 01:40:17.751847
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    check = TaskInclude()
    bad_data = {'action': 'include_role', 'foo': 'bar'}
    ansible_fail = False

    try:
        check.preprocess_data(bad_data)
    except AnsibleParserError:
        ansible_fail = True
    assert ansible_fail

    bad_data = {'action': 'include_tasks', 'foo': 'bar'}
    ansible_fail = False

    try:
        check.preprocess_data(bad_data)
    except AnsibleParserError:
        ansible_fail = True
    assert ansible_fail

    bad_data = {'action': 'import_playbook', 'foo': 'bar'}
    ansible_fail = False


# Generated at 2022-06-21 01:40:29.001365
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    block = None
    role = None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    task = dict()
    task['args'] = dict()
    task['action'] = 'import_playbook'

    # 1. No action (should default to import_playbook)
    task['args'] = {'file': 'test'}
    task = ti.check_options(task, task)
    assert task['args']['_raw_params'] == 'test'
    assert task['args'].get('apply', {}) == {}

    # 2. Invalid action
    task['action'] = 'include'

# Generated at 2022-06-21 01:40:41.063556
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    This test case tests the behavior of preprocess_data method of class TaskInclude.
    :return:
    """
    # Create an instance of 'TaskInclude'
    ti = TaskInclude()

    # Create a dictionary which contains some valid and invalid arguments
    my_dict = {'action': 'include', 'debug': Sentinel, 'when': 'this_is_a_when_condition'}

    # Call method 'preprocess_data' on the instance of 'TaskInclude' with the above dictionary
    # as input
    new_dict = ti.preprocess_data(my_dict)

    # Check that the 'debug' entry is removed from the new_dict
    assert Sentinel not in new_dict

    # Check that the 'when' entry is not removed from the new_dict
    assert my_dict['when'] == new_dict

# Generated at 2022-06-21 01:40:49.972202
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    ti = TaskInclude()
    ti._role = 'dummy_role'

    # test with an action different from 'include' and 'import_role': no error
    ds = {'action': 'role'}
    ret = ti.preprocess_data(ds)
    assert(ret == ds)

    # test with an action equal to 'include' or 'import_role': error
    ds = {'action': 'include', 'name': 'abc'}
    try:
        ret = ti.preprocess_data(ds)
        assert(False)
    except AnsibleParserError:
        assert(True)

    ds = {'action': 'import_role', 'name': 'abc'}

# Generated at 2022-06-21 01:41:00.068297
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    def load_task_include(task_include, action=None, validate_options=None):
        task_include.action = action
        if validate_options:
            return task_include.check_options(task_include, task_include.args)

        return task_include

    def load_data(data, action=None, task_include=None, validate_options=None):
        return load_task_include(TaskInclude(task_include=task_include), action=action, validate_options=validate_options)

    data = dict(
        action='include',
        _raw_params='something.yaml',
    )


# Generated at 2022-06-21 01:41:05.799979
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # test with include action and applied attributes
    data = dict(
        include=dict(
            apply=dict(
                with_items=[
                    dict(item='test_item'),
                    dict(item='test_item2'),
                ],
                block=[]
            ),
            file="test_file",
            debug=dict(
                msg="test message"
            )
        )
    )

# Generated at 2022-06-21 01:41:22.144624
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import BaseInclude

    task = TaskInclude.load(dict(action='include', file='test_TaskInclude_copy.yml'))
    task.name = 'testing_TaskInclude'
    task.set_loader(None)
    task._parent = BaseInclude.load(dict(name='test_TaskInclude_copy'), task_include=task, role=None, variable_manager=None, loader=None)
    task._play = PlayContext()
    task._role = 'role'

    new_task = task.copy()
    assert new_task.name == task.name
    assert new_task._parent.name == task._parent.name
    assert new_task.action == task.action
    assert new_task.args

# Generated at 2022-06-21 01:41:30.286831
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    task_data = {'apply': {'block': [], 'vars': {'first_var': 'true'}, 'when': 'not_included_parent_block_failed'}}
    p_block_data = {'block': []}
    pm = Playbook._load_playbook_from_file('test/ansible/playbooks/block.yml')
    play = pm.get_plays()[0]
    ti = TaskInclude(task_include=play.get_tasks()[0], block=play)
    block = Block.load(p_block_data, play=play, task_include=ti, role=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 01:41:42.215748
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.plugins.loader as plugins
    my_plugin = plugins.get_plugin_loader('action')

    # Set up a task to include so we have a parent to play with
    action_plugin_name = 'command' # will get overridden by the action below
    action_plugin_args = dict(cmd='echo hi')
    action_plugin = my_plugin.get(action_plugin_name, class_only=True)()
    action_plugin.set_loader(plugins.get_loader())
    action_plugin.finalize(action_plugin_args)

    # include a task
    task_include_action_plugin_name = 'copy'

# Generated at 2022-06-21 01:41:50.972470
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    This function is used to test preprocess_data method of class TaskInclude
    """
    class TestTaskInclude(object):
        """
        This class is used to create objects for TaskInclude class for testing
        in the preprocess_data method.
        """
        def __init__(self, action):
            self.action = action
            self.args = {}

    task_include_obj1 = TestTaskInclude(action='include')
    task_include_obj2 = TestTaskInclude(action='include_role')
    task_include_obj3 = TestTaskInclude(action='import_role')

    test_data = {'file': 'test.yml', 'tags': 'test'}

    # Testing for include action
    # Here the preprocess_data method should execute and a warning should be displayed

# Generated at 2022-06-21 01:42:01.502854
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file("../../../examples/ansible_hosts"))
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)

    example = {'include': 'tasks_included_in_this_task', 'action': 'include'}
    task = TaskInclude.load(example, play_context=play_context, variable_manager=variable_manager, loader=loader)
    task.preprocess_data(example)
    assert list(example.keys()) == ['action', 'include']


# Generated at 2022-06-21 01:42:12.643741
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # setup:
    block = Block()
    block.root_dir = '/some/path'
    block._play = 'not_a_play'
    task = Task()
    task._block = block
    task._role = 'not_a_role'
    task._variable_manager = HostVars()
    task.action = 'include'
    data = {'foo': 'bar', 'when': True, 'pause': True}
    ti = TaskInclude()

    # test
    ti.check_options(task, data)
    assert task.args

# Generated at 2022-06-21 01:42:14.075777
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    obj = TaskInclude()
    assert obj.statically_loaded == False

# Generated at 2022-06-21 01:42:23.457464
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # set up test objects
    variable_manager = VariableManager()
    loader = DataLoader()

    # set up task
    task = TaskInclude()
    task.action = 'include_tasks'

    # test
    task.preprocess_data({'tasks': 'tasks_file.yml'})
    assert task.args['tasks'] == 'tasks_file.yml'
    task.preprocess_data({'tags': 'test'})
    assert task.args['tags'] == 'test'
    task.preprocess_data({'ignore_errors': True})
    assert task.args['ignore_errors'] is True
    task.preprocess_data({'unknown_attr': 'value'})

# Generated at 2022-06-21 01:42:33.462847
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    task = TaskInclude(block=block)
    parent = TaskInclude(block=block)
    parent.vars = dict(a=1, b=2)
    task._parent = parent
    task.args = dict(c=3, d=4)
    task.action = 'include'
    all_vars = task.get_vars()
    assert all_vars == dict(a=1, b=2, c=3, d=4)


# Generated at 2022-06-21 01:42:44.384442
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()

    task_include.name = 'task_include_name'
    task_include.action = 'name'
    task_include.vars = dict(a=1, b=2)
    task_include.args = dict(c=3, d=4)
    task_include._parent = FieldAttribute(parent=True)
    task_include._parent.get_vars = lambda: dict(e=5, f=6)
    task_include._parent.tags = []
    task_include._parent.when = ''

    result = task_include.get_vars()

    assert dict(a=1, b=2, c=3, d=4, e=5, f=6) == result

# Generated at 2022-06-21 01:43:08.570410
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # The test task
    task = TaskInclude(block=None, role=None, task_include=None)

    # Different dicts
    dict_ok = dict(action='include_role', name='test', option1='value1', option2='value2')
    dict_dont_exist = dict(action='include_role', name='test', option1='value1', option2='value2', dont_exist='whatever')
    dict_dont_exist_no_options = dict(action='include_role', name='test', dont_exist='whatever')
    dict_debugger = dict(action='include_role', name='test', option1='value1', option2='value2', debugger='false')

    # Check for positive outcome
    result = task.preprocess_data(dict_ok)

# Generated at 2022-06-21 01:43:14.691198
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.task_include

    # setup
    task = ansible.playbook.task_include.TaskInclude()
    task._task_include = True

    # one
    task.action = 'include'
    task.vars = dict(
        key1 = 'value1',
        key2 = 'value2',
    )
    task.args = dict(
        arg1 = 'value1',
        arg2 = 'value2',
    )

    # When
    actual = task.get_vars()

    # Then
    expected = dict(
        key1 = 'value1',
        key2 = 'value2',
        arg1 = 'value1',
        arg2 = 'value2',
    )
    assert expected == actual

    # two with _parent

# Generated at 2022-06-21 01:43:28.130862
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test TaskInclude.check_options without apply
    '''
    # Assume test_TaskInclude_load_data runs without error first
    task = TaskInclude.load(
        {
            'action': 'include',
            'file': '/etc/ansible/foo.yaml'
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )

    # Check options with action = include, apply = None
    task2 = TaskInclude.check_options(task, data={})
    assert task2.action == 'include'
    assert task2.args['_raw_params'] == '/etc/ansible/foo.yaml'
    assert not task2.args.get('apply', None)

    #

# Generated at 2022-06-21 01:43:36.877704
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    hash_data_original = {'action': 'include', 'file': 'tasks/main.yml', 'tags': ['debug', 'fix'], 'when': 'ansible_os_family == "Debian"'}
    hash_data_expected = {'action': 'include', 'file': 'tasks/main.yml', 'tags': ['debug', 'fix'], 'when': 'ansible_os_family == "Debian"'}
    assert task_include.preprocess_data(hash_data_original) == hash_data_expected

# Generated at 2022-06-21 01:43:48.883879
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method tests the creation of the parent block for the included tasks
    when ``apply`` is specified
    '''
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader


# Generated at 2022-06-21 01:43:56.788907
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with include action
    task_include = TaskInclude(block=None, role=None)
    task_include.action = 'include'
    task_include.args = {'var1': 'value1', 'var2': 'value2'}
    task_include.vars = {'var3': 'value3'}
    block = Block(task_include=task_include)
    task_include.block = block
    assert task_include.get_vars() == {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}

    # Test with import_tasks action
    task_include.action = 'import_tasks'
    assert task_include.get_vars() == {'var3': 'value3'}

    # Test with include_role action


# Generated at 2022-06-21 01:44:06.031879
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.task_include import TaskInclude

    def ansible_assert(a, b):
        assert a == b, "%s != %s" % (a, b)

    # create needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_

# Generated at 2022-06-21 01:44:16.007379
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    from ansible.playbook.role.definition import TaskDefinition
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.vars import combine_vars

    display.verbosity = 3

    # task without apply
    # no errors should be raised for invalid attributes
    task = TaskInclude.load({
        'ignore_errors': True,
        'action': 'include',
        'args': {},
        'loop': '{{ geese }}',
        'no_log': False,
        'when': '{{ goose }}',
        'loop_with': 'item',
        'register': 'goose_loop',
        'invalid_attr': '{{ goose }}',
    })
    assert 'loop' in task.args
    assert 'loop_with' in task.args

# Generated at 2022-06-21 01:44:27.979228
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Tests valid args
    data = {'file': '/path/to/tasks/file'}
    task = TaskInclude(None)
    task = task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == '/path/to/tasks/file'

    data = {'file': '/path/to/tasks/file', 'apply': {}}
    task = TaskInclude(None)
    task = task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == '/path/to/tasks/file'
    assert len(task.args['apply']) == 0


# Generated at 2022-06-21 01:44:38.886808
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Unit test to exercise the build_parent_block method of class TaskInclude
    :return:
    """

    class FooTask(Task):
        pass

    class MyTask(TaskInclude):

        def __init__(self, **kwargs):
            self.statically_loaded = False
            for k in kwargs:
                setattr(self, k, kwargs[k])
        def copy(self, exclude_parent=True, exclude_tasks=False):
            return MyTask(
                args=self.args.copy(),
                _block=self._block,
                delegate_to=self.delegate_to,
                environment=self.environment,
                when=self.when,
                jinja2_extensions=self.jinja2_extensions
            )