

# Generated at 2022-06-21 01:34:47.588796
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    preprocess_data_return = task_include.preprocess_data({'include': 'a_playbook.yaml', 'tags': ['a_tag']})
    assert preprocess_data_return == {'include': 'a_playbook.yaml', 'tags': ['a_tag']}

# Generated at 2022-06-21 01:34:56.190641
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    data = {
        'action': 'block',
        'block': [
            {'task': {'action': 'debug', 'msg': 'foo'}}
        ]
    }
    task = TaskInclude.load(data)
    assert task.action == 'block'
    assert task.args == {}
    assert len(task.block) == 1
    assert task.block[0].action == 'debug'
    assert task.block[0].args == {'msg': 'foo'}
    assert task.block[0]._parent.action == 'block'
    assert task.block[0]._parent.args == {}


# Generated at 2022-06-21 01:35:04.273951
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    display.verbosity = 4
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-21 01:35:11.790324
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    import pytest
    from collections import namedtuple

    Task = namedtuple("Task", "action args delegate_to")
    host_config = namedtuple("host_config", "connection")
    block = namedtuple("block", "parent_block")
    role = namedtuple("role", "task_blocks exclude_parent")
    loader = namedtuple("loader", "paths")
    variable_manager = namedtuple("variable_manager", "")
    play = namedtuple("play", "")

    with pytest.raises(AssertionError) as exc:
        task = Task(action="include", args={"apply":{"include":"test.yaml"}, "tags":"test"}, delegate_to="localhost")

# Generated at 2022-06-21 01:35:24.629930
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # vars are a combination of vars and args
    task = TaskInclude.load(dict(
        action='include_role',
        vars=dict(
            a='b',
        ),
        args=dict(
            a='b',
            b='c',
        )
    ))
    vars = task.get_vars()
    assert len(vars) == 2
    assert vars['a'] == 'b'
    assert vars['b'] == 'c'

    # vars is updated with args
    task = TaskInclude.load(dict(
        action='include',
        vars=dict(
            a='b',
            c='d',
        ),
        args=dict(
            a='b',
            b='c',
        )
    ))
    vars = task.get

# Generated at 2022-06-21 01:35:36.403722
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class TestTaskInclude(TaskInclude):
        pass

    test_block = None
    test_role = None
    test_task_include = None
    test_data = {'action': 'include', 'include_role': {}, 'args': {'test': 'test'}}
    test_task = TestTaskInclude(block=test_block, role=test_role, task_include=test_task_include)
    test_task.preprocess_data(test_data)

    assert test_data == {'action': 'include', 'args': {'test': 'test'}}

    test_data = {'action': 'include', 'include_role': {}, 'args': {'test': 'test', 'tags': 'true'}}
    test_task.preprocess_data(test_data)

    assert test_data

# Generated at 2022-06-21 01:35:46.325536
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Unit test for method build_parent_block of class TaskInclude
    """
    import ansible.playbook.role
    import ansible.playbook.block

    task1 = Block()
    task1.apply_vars = {
        'block': [],
        'ignore_errors': True,
        'any_errors_fatal': False,
        'when': 'this is task1',
    }

    task2 = Block()
    task2.apply_vars = {
        'block': [],
        'ignore_errors': True,
        'any_errors_fatal': False,
        'when': 'this is task2',
    }

    task_include1 = TaskInclude(block=task1)

# Generated at 2022-06-21 01:35:55.806495
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Prerequisites
    import ansible.playbook
    from ansible.playbook.helpers import load_list_of_tasks

    # Setup

# Generated at 2022-06-21 01:36:04.043065
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockTask1(TaskInclude):
        '''
        This is a class to mock TaskInclude, with action 'action1' in C._ACTION_INCLUDE_TASK
        '''
        def __init__(self, *args, **kwargs):
            super(MockTask1, self).__init__(*args, **kwargs)
            self.args = dict()
            self.action = 'action1'

    mock_task_include_args = {'file': 'abc', 'apply': 'abc'}
    mock_task_include_data = dict(action1=mock_task_include_args)

    mock_task_include = MockTask1()
    assert mock_task_include.check_options(mock_task_include, mock_task_include_data)


# Generated at 2022-06-21 01:36:15.600750
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import shared_loader
    from ansible.template import Templar

    # Create variables
    fake_loader = shared_loader.PluginLoader('.', '.', '.')
    fake_loader.add_directory('./')
    fake_play_context = PlayContext()
    fake_variable_manager = fake_loader.variable_manager
    fake_variable_manager.set_inventory(fake_loader.inventory)
    fake_variable_manager.extra_vars = dict()
    fake_variable_manager.options_vars = dict()

    # Create templar
    fake_templar = Templar(loader=fake_loader, variables=fake_variable_manager.all_vars)

    # Create data

# Generated at 2022-06-21 01:36:26.850605
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play as pl
    import ansible.playbook.task_include as ti
    task_vars = {
        'variable1': 'test',
        'variable2': 'test'
    }
    play_context = PlayContext()
    play_context.set_variables(task_vars)

# Generated at 2022-06-21 01:36:38.345944
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.role
    import ansible.parsing.dataloader
    import ansible.vars
    import ansible.inventory

    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.VariableManager()
    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    playbook = ansible.playbook.PlayBook(
        playbook='',
        loader=loader,
        inventory=inventory,
        variable_manager=variable_manager,
        callbacks=None,
        runner_callbacks=None,
        stats=None,
    )
    role = ansible.playbook.role.Role()

    ti = TaskInclude()

# Generated at 2022-06-21 01:36:47.557651
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class FakeParentTask(object):
        def __init__(self, vars=None):
            self._play = Sentinel
            self._role = Sentinel
            self._variable_manager = Sentinel
            self._loader = Sentinel
            self.vars = vars or {}

    class FakeLoader(object):
        pass

    class FakeVariableManager(object):
        pass

    test_vars = {'roles_paths': [u'/etc/ansible/roles']}

    test_task = TaskInclude(role=u'example-role', task_include=FakeParentTask(vars=test_vars))
    test_task._loader = FakeLoader()
    test_task._variable_manager = FakeVariableManager()
    test_task.block = Sentinel
    test_task.action = u'include'

# Generated at 2022-06-21 01:36:58.082254
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    fake_loader = dict(
        path_dwim = lambda x: '/dev/null'
    )
    ti = TaskInclude.load(dict(
        include="foobar.yml",
        action="include",
        with_items=[1,2,3],
        _raw_params='foobar.yml',
        apply=dict(
            name='target'
        )
    ), loader=fake_loader)

    assert ti.get_vars() == dict(
        with_items=[1,2,3],
        name='target'
    )


# Generated at 2022-06-21 01:37:09.215699
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    a = TaskInclude()
    assert a is not None
    assert isinstance(a, Base)
    assert isinstance(a, Task)
    assert isinstance(a, TaskInclude)
    assert a.action == 'include'
    assert a.args == dict()
    assert isinstance(a._block, Block)
    assert a._block._parent is None
    assert a._block.role is None
    assert a._block.task_include is None

# Generated at 2022-06-21 01:37:20.362343
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-21 01:37:34.547459
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.tests.unit.test_tasks import (
        TestPlay,
        TestRoleDeps,
    )
    from ansible.playbook.role.definition import Task
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import combine_vars
    import os

    # TaskInclude.load
    # Tests:
    #   - A TaskInclude object has 'file' attribute set
    #   - A TaskInclude object has '_raw_params'

# Generated at 2022-06-21 01:37:45.714606
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Verify that invalid arguments to an include task raise an error
    """
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play = Play.load(dict(
        name="Ansible Play",
        hosts=['localhost'],
        gather_facts='no',
        tasks=[dict(action='include', bad_option='foo')]),
        variable_manager=variable_manager,
        loader=loader,
    )
    play._inject_facts()

# Generated at 2022-06-21 01:37:56.813739
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=''))
    variable_manager.extra_vars = {'action':'include'}
    variable_manager.extra_vars = {'_raw_params':'file.yaml'}
    context = PlayContext()
    ti = TaskInclude(loader=loader, variable_manager=variable_manager, context=context)
    ti.check_options(ti,data="sample data")
    ti.preprocess_data(data="data")
   

# Generated at 2022-06-21 01:38:04.831387
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class TestTaskInclude1(TaskInclude):
        pass
    class TestTaskInclude2(TaskInclude):
        pass

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    block = Block()
    block._play = TestTaskInclude1()
    block._play._role = Task()

    task1a = Task(action='include_tasks', args=dict(file='tasks1.yml'), block=block)
    task1b = Task(action='include_role', args=dict(name='my_role'), block=block)

    task2a = Task(action='import_tasks', args=dict(file='tasks2.yml'), block=block)

# Generated at 2022-06-21 01:38:25.220236
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Testing TaskInclude.preprocess_data() in different modes:
    - with action: include
    - with action: import_tasks
    - with action: import_role
    - with action: include_role
    - with action: include_tasks
    """
    test_cases = (1, 2, 3, 4)

    for case in test_cases:
        task = TaskInclude()
        class_action = task.__class__.__name__
        if case == 1:
            invalid_kw = 'invalid'
            action = 'include'
        elif case == 2:
            invalid_kw = 'invalid'
            action = 'import_tasks'
        elif case == 3:
            invalid_kw = 'invalid'
            action = 'import_role'

# Generated at 2022-06-21 01:38:37.265255
# Unit test for method copy of class TaskInclude

# Generated at 2022-06-21 01:38:44.046934
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # In this test we try to create a TaskInclude object and call method "copy" to create a new
    # object and compare the two objects.

    # Create a new Role object
    role = Role()

    # creating a new Block object passing role created above
    block = Block(parent_block=role)

    # creating a new TaskInclude object passing block created above
    taskInclude = TaskInclude(block=block)

    # set dynamically_loaded for the object created
    taskInclude.statically_loaded = True

    # call method "copy" to create a new object based on the object created before
    new_taskInclude = taskInclude.copy()

    assert(taskInclude.statically_loaded == new_taskInclude.statically_loaded)

# Generated at 2022-06-21 01:38:57.207057
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    task_include_dict = task_include.__dict__

    # test action: import_playbook
    action = 'import_playbook'
    test_dict = {'name': 'test', 'action': action}
    expected_result = {'action': action}
    assert task_include.preprocess_data(test_dict) == expected_result
    assert task_include_dict == task_include.__dict__

    # test action: include_role
    action = 'include_role'
    test_dict = {'name': 'test', 'action': action}
    expected_result = {'action': action}
    assert task_include.preprocess_data(test_dict) == expected_result
    assert task_include_dict == task_include.__dict__

    # test action

# Generated at 2022-06-21 01:39:10.131319
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Test for cases with exclude_parent=True and exclude_tasks=True
    ti = TaskInclude()
    ti.exclude_parent = True
    ti.exclude_tasks = True

    ti_copy = ti.copy()
    assert ti_copy is not ti
    assert ti_copy.exclude_parent == ti.exclude_parent
    assert ti_copy.exclude_tasks == ti.exclude_tasks
    assert isinstance(ti_copy, TaskInclude)

    ti_copy = ti.copy(exclude_parent=False, exclude_tasks=False)
    assert ti_copy is not ti
    assert ti_copy.exclude_parent is False
    assert ti_copy.exclude_tasks is False
    assert isinstance(ti_copy, TaskInclude)

    ti_copy = ti

# Generated at 2022-06-21 01:39:17.344161
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # check VALID_ARGS
    data = {
        'file': 'a.txt',
    }
    # first parameter 'task' should not be changed, the second parameter should be changed
    task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == 'a.txt'
    assert data['_raw_params'] == 'a.txt'
    assert 'file' not in data
    assert 'file' not in task.args

    data = {
        'file': 'b.txt',
        'apply': {
            'other': 'something',
            'name': 'something-else',
        },
    }

# Generated at 2022-06-21 01:39:29.709015
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play

    play_obj = Play().load({
        'name': 'myplay',
        'hosts': 'somehost',
        'roles': {
            'role001': None
        },
        'tasks': [
            {
                'include_role': {'name': 'role001', 'apply': {'block': []}}
            }
        ]
    }, variable_manager=None, loader=None)
    play_obj._role_names = ['role001']
    play_obj._role_names.reverse()
    play_obj._prepare_free_variables()

    print(play_obj._entries)
    print(play_obj._entries[0]._entries[0].get_vars())


# Generated at 2022-06-21 01:39:39.944820
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test for task with action "include"
    raw_data = {
        'action': 'include',
        'name': 'test_name',
        'tags': ['tag1', 'tag2'],
        'when': 'when1',
        'loop': 'loop1',
    }
    data = {
        'action': 'include',
        'name': 'test_name',
        'tags': ['tag1', 'tag2'],
        'when': 'when1',
        'loop': 'loop1',
    }
    ti = TaskInclude()
    ti_preprocess_data = ti.preprocess_data(raw_data)
    assert ti_preprocess_data == data

    # Test for task with action "import_playbook"

# Generated at 2022-06-21 01:39:47.111556
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    ds = {u'include': {u'my_include_task': [u'action: ping']}}
    ds_preprocessed = task_include.preprocess_data(ds)
    assert ds_preprocessed == {u'include': {u'my_include_task': {u'action': u'ping'}}}



# Generated at 2022-06-21 01:39:51.740956
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    # Create a new object of the class TaskInclude
    task = TaskInclude()

    # Check the type of class TaskInclude
    assert isinstance(task, TaskInclude)


# Generated at 2022-06-21 01:40:13.848278
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    # create inventory, and feed host vars
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task = {'action': 'include_role', 'name': 'example_role', 'apply': {'foo': 'bar'}}
    t = TaskInclude.load(task, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:40:23.377440
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test method TaskInclude.preprocess_data(ds)

    :returns: True if all tests pass, else False
    :rtype: bool
    '''
    try:
        ti = TaskInclude()
    except Exception as e:
        print(repr(e))
        return False

    try:
        ds = ti.preprocess_data({'action': 'include', 'loop': '{{ range(0,10) }}', 'file': '../tasks/dummy_include.yaml'})
    except Exception as e:
        print(repr(e))
        return False

    if not isinstance(ds, dict):
        print('%s is not a dict' % repr(ds))
        return False


# Generated at 2022-06-21 01:40:31.835495
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.playbook.helpers import load_list_of_tasks
    import ansible.constants as C

    hosts = ["localhost"]

# Generated at 2022-06-21 01:40:35.125092
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    test_TaskInclude_data = {
        'action': 'include',
        'file': 'test_file.yml',
        'apply': None,
        'other': 1
    }
    ti = TaskInclude.load(test_TaskInclude_data)
    assert (ti.data == test_TaskInclude_data)

# Generated at 2022-06-21 01:40:36.128096
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti

# Generated at 2022-06-21 01:40:43.941974
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    name = "test-task-include"
    file_or_include = {"action": "include"}
    play = {"name": "test-task-include", "hosts": "127.0.0.1"}

    # The method to test
    task_include = TaskInclude.load(file_or_include, block=play)

    assert task_include.name == name
    assert task_include.action == "include"


# Generated at 2022-06-21 01:40:51.169931
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ds = dict(
        action='include',
        file='main.yml',
        apply={'block': {'name': 'test', 'debug': 'msg={{m}}'}},
        m=10,
    )

    ti = TaskInclude.load(ds)

    assert ti._role is None
    assert ti.action == 'include'
    assert ti.statically_loaded is False
    assert ti._parent is None
    assert ti.args['file'] == 'main.yml'
    assert ti.args['_raw_params'] == 'main.yml'
    assert 'm' in ti.args
    assert 'task' not in ti.args
    assert 'block' in ti.args['apply'].keys()
    assert 'name' in ti.args['apply']['block'].keys()
   

# Generated at 2022-06-21 01:41:02.100451
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext

    block = Block()
    role = Role()
    role._role_path = 'role-path'
    task_include = TaskInclude()
    task_include._parent = block
    task_include._role = role
    task_include._play_context = PlayContext()
    task_include.action = 'include_role'
    task_include.args = {'name': 'xxx'}

    block.vars = {'xxx':'yyy'}
    task_include.vars = {'yyy':'zzz'}

    assert 'yyy' == task_include.get_vars()['xxx']
    assert 'zzz' == task_include.get_vars()['yyy']
    assert 'xxx' == task_include.get_v

# Generated at 2022-06-21 01:41:13.795024
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    names = ['foo', 'bar', 'baz']
    display.verbosity = 3


# Generated at 2022-06-21 01:41:24.459461
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test method TaskInclude._check_options. Checking all the validations
    that TaskInclude._check_options performs.
    '''
    Block.ONE_PARENT_ALLOWED = False
    b = Block()
    b.vars.update({'a': 1, 'b': 2})
    t = TaskInclude(block=b)
    ti = TaskInclude(block=b, task_include=t)
    # Test with action 'include'

# Generated at 2022-06-21 01:41:59.785051
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook
    import ansible.playbook.task_include

    def create_task_include(args):
        import ansible.playbook
        import ansible.playbook.task_include

        return ansible.playbook.task_include.TaskInclude(block=ansible.playbook.Block(play=ansible.playbook.Play()), task_include=ansible.playbook.task_include.TaskInclude())

    ti = create_task_include({'when': 'xyz', '_raw_params': 'foo.yml'})
    assert ti.check_options(ti, None) == ti
    ti = create_task_include({})

# Generated at 2022-06-21 01:42:11.312148
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert task_include.statically_loaded == False
    assert task_include.BASE == frozenset(('file', '_raw_params'))
    assert task_include.OTHER_ARGS == frozenset(('apply',))
    assert task_include.VALID_ARGS == frozenset(('file', '_raw_params', 'apply',))
    assert task_include.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                        'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                        'when'))
    assert task_include.block.parent == None

# Generated at 2022-06-21 01:42:16.265786
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.block import Block
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude

    playbook = Playbook()
    play = Play()
    included_file = IncludedFile(path = "test/test.yml")
    block = Block()
    block.role = "test"
    block._role = "test"
    context = PlayContext()
    ti = TaskInclude()

    ti._parent = block
    ti.action = "include"
    ti.statically_loaded = False

    ti_copy = ti.copy()

    # assert that if exclude parent

# Generated at 2022-06-21 01:42:23.346077
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Create a simple task to be used as a 'task_include' fixture
    task_include = TaskInclude()

    # Create a simple play to be used as a '_play' fixture
    play = {'hosts': ['host']}

    # Create a simple role to be used as a role fixture
    role = {'name': 'role'}

    # Initialize a variable manager to be used as a variable manager fixture
    variable_manager = {'_fact_cache': {}}

    # Initialize a loader to be used as a loader fixture
    loader = {'_basedir': 'basedir'}

    # Create a simple dictionary to be used as a 'data' fixture
    data = {'_raw_params': 'raw_params'}

    # Create a simple task to be used as a 'task' fixture
    task = TaskInclude

# Generated at 2022-06-21 01:42:32.229802
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders

    play = Play.load(dict(name='test', hosts=['localhost']), variable_manager=None, loader=get_all_plugin_loaders())
    ti = TaskInclude(block=None, role=None, task_include=None)

    # check data without apply option
    d = dict(action='include', file='test.yml', tags=['test-tag'], when='test-condition')
    t = ti.check_options(ti.load_data(d, variable_manager=None), d)
    assert t.action == 'include'
    assert t.args.get('apply') == {}

    # check data with apply option

# Generated at 2022-06-21 01:42:39.680252
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Unit test for method build_parent_block of class TaskInclude
    task = TaskInclude()
    parser = FakeParser()
    role_name = 'role_name'
    role = FakeRole(role_name)
    role._role_path = 'role_path'
    role._parent_role = ParsedRole(role_name, role._role_path, parser)
    task._role = role
    task._play = FakePlay()
    task.vars = {}
    task.action = 'include'
    task.args = {'apply': {'block': []}}
    task.dep_chain = []
    task.statically_loaded = False
    parent_block = task.build_parent_block()
    assert parent_block.get_name() == 'apply'



# Generated at 2022-06-21 01:42:44.745909
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    validate that the static params to the include are added to the
    variables
    '''

    class FakeParentTask(object):
        def get_vars(self):
            return dict(a=1, b=2)

    t = TaskInclude()
    t._parent = FakeParentTask()
    t.args = dict(c=3, d=4)
    assert t.get_vars() == dict(a=1, b=2, c=3, d=4)

    # but not for 'include_role'
    t = TaskInclude()
    t._parent = FakeParentTask()
    t.action = 'include_role'
    t.args = dict(c=3, d=4)
    assert t.get_vars() == dict(c=3, d=4)

# Generated at 2022-06-21 01:42:57.151252
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    t = TaskInclude(block=None, role=None, task_include=None)

    orig_data = {'action': 'include', 'apply': {'test': 'test'}, 'file': 'test', '_raw_params': 'test', 'test': 'test'}
    data = orig_data.copy()
    data['file'] = None
    try:
        t.load(data=data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    except AnsibleParserError as e:
        assert str(e) == 'No file specified for include'
    else:
        raise AssertionError("TaskInclude.load method didn't raise AnsibleParserError when file not specified for 'include'")

    data = orig_data.copy()

# Generated at 2022-06-21 01:43:09.595711
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import os
    import sys
    import tempfile
    sys_path_orig = sys.path
    sys.path = [os.path.expanduser('~'), tempfile.gettempdir()]
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from collections import namedtuple

    FakeParent = namedtuple('FakeParent', ['get_vars'])
    FakeRole = namedtuple('FakeRole', ['default_vars', 'vars_files'])
    FakeBlock = namedtuple('FakeBlock', ['vars'])
    FakeInclude = namedtuple('FakeInclude', ['args', 'action', 'vars'])

    play_context = PlayContext()
    variable_manager = VariableManager()

   

# Generated at 2022-06-21 01:43:15.805854
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # This test covers the following situation:
    # self.args.pop('apply', {}) returns an empty dict so self._parent._play, self, self._role,
    # self._variable_manager, self._loader are passed as args to be stored in the Block object.
    # Since the dict is empty, the block has no attributes and is therefore just a block.

    task_include = TaskInclude(block=None, role=None, task_include=None)
    # set task_include._parent._play to a dummy object
    task_include._parent = type('', (), {})()
    task_include._parent._play = True
    # set task_include._role, task_include._variable_manager and task_include._loader to True
    task_include._role = True
    task_include._variable_manager = True
    task_include

# Generated at 2022-06-21 01:44:11.562222
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    assert isinstance(task, TaskInclude)
    
    assert '- include: file=somescript.yml' == task.check_options(task.load_data({'include': 'file=somescript.yml'}), {})

# Generated at 2022-06-21 01:44:19.409366
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Dummy import for params validation testing
    from ansible.playbook.include import task_include
    from ansible.playbook.include import static_include

    def make_task_include(action, args):
        data = dict(action=action, args=args)
        return TaskInclude.load(data, loader=None, variable_manager=None, task_include=None)

    # Include action tests
    task = make_task_include("", {"include": "something"})
    assert task.action == "include"
    assert task.args == {"_raw_params": "something"}

    task = make_task_include("include", {"file": "something"})
    assert task.action == "include"
    assert task.args == {"file": "something"}

    # Import related actions tests
    task = make_task_include

# Generated at 2022-06-21 01:44:29.055132
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class DummyVariableManager(object):
        pass
    class DummyLoader(object):
        pass
    class DummyBlock(object):
        def __init__(self, loader=None, variable_manager=None):
            super(DummyBlock, self).__init__()
            self._loader = loader or DummyLoader()
            self._variable_manager = variable_manager or DummyVariableManager()

    class DummyTask(object):
        def __init__(self):
            self.args = {'_raw_params': '../x'}
            self.action = 'include_role'
            self.DUMMY_ATTR = 'DummyAttr'

        @property
        def loader(self):
            return self
        @loader.setter
        def loader(self, value):
            pass


# Generated at 2022-06-21 01:44:35.757912
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # remove the parent block
    ti = TaskInclude({
        'action': 'include',
        'args': {
            '_raw_params': '/some/include/file',
            'a': 1,
            'b': 2,
            'tags': [],
            'when': 'always',
        },
    })

    assert ti.args == ti.get_vars()

    # add the parent block
    ti._parent = Task({})
    ti._parent.vars.update({'c': 3})
    ti._parent.get_vars = lambda: {'p': 'pvar'}

    assert ti.args == ti.get_vars()
    ti.vars.update({'d': 4})
    assert len(ti.get_vars()) == 5
    assert 'p' in ti.get_