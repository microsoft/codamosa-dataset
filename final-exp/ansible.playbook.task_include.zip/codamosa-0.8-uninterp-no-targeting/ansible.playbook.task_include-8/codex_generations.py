

# Generated at 2022-06-21 01:34:54.777665
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DictDataLoader({
        "/etc/ansible/roles/foobar/tasks/main.yaml": """
        - debug: msg="I'm in the included file"
        """
    })

    variable_manager = VariableManager()

    inventory = Inventory(loader, variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 01:34:58.884312
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    yaml_str = """
    - include: paths-from-role.yml
    """

    if PY3:
        yaml_str = yaml_str.encode('utf-8')
    data = AnsibleConstructor(yaml_str).get_single_data()
    # Valid only the args 'file' and '_raw_params' are used
    assert data[0]['include']['file'] is None
    assert data[0]['include']['_raw_params'] == 'paths-from-role.yml'

    # Invalid args are not used
    assert 'apply' not in data[0]['include']

# Generated at 2022-06-21 01:35:03.995254
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    block._parent = 'fake_parent'
    task_obj = TaskInclude(block)
    task_obj._role = 'fake_role'
    assert task_obj.copy() == task_obj._copy()
    assert task_obj.copy(exclude_parent=True) == task_obj._copy(exclude_parent=True)
    assert task_obj.copy(exclude_tasks=True) == task_obj._copy(exclude_tasks=True)


# Generated at 2022-06-21 01:35:11.486343
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    """
    Prepare test data for TaskInclude.copy() and for TaskInclude.get_vars()
    Call TaskInclude.copy()
    Call TaskInclude.get_vars() to get _attributes of TaskInclude obj
    which is static obj's attribute
    """
    static_obj = TaskInclude({})
    static_obj.action = 'include'
    static_obj._task_include.action = 'include'
    static_obj.vars = {'static_vars': 'static_value'}
    static_obj.args = {'static_args': 'static_value'}
    static_obj.statically_loaded = True
    static_obj._task_include.statically_loaded = True
    static_obj.statically_loaded = False

    test_obj = static_obj.copy()


# Generated at 2022-06-21 01:35:16.930588
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude(task_include=Task())
    assert task.copy().statically_loaded is False
    task.statically_loaded = True
    assert task.copy().statically_loaded is True


# Unit tests for method get_vars of class TaskInclude

# Generated at 2022-06-21 01:35:28.648709
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()

    path1 = './test_action_include_get_vars_1.yml'
    path2 = './test_action_include_get_vars_2.yml'

    # Test action include with parameter 'file'
    data = """
- include: %s
  vars:
    foo: bar
    """ % path1
    display.verbosity = 3

    pb = Play().load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:35:40.097583
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    data = {
        'block': [
            {'action': 'included_task_action', 'some': 'other', 'args': {'include_task_arg': 'foo'}},
            {'action': 'some_other_included_task_action', 'some': 'other', 'args': {'other_include_task_arg': 'bar'}}
        ],
        'some': {'nested': 'dict'},
        'apply': {
            'name': 'apply_parent_block'
        }
    }

    parent_block = TaskInclude.load(data).build_parent_block()

    # Check type
    assert isinstance(parent_block, Block)

    # Check that the parent block has been correctly initialized (based on 'block': [&lt;TaskInclude&gt;])

# Generated at 2022-06-21 01:35:52.899062
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # a simple test with no 'apply'
    ds = dict(
        action='include',
        file='tasks.yaml',
        loop_control=dict(loop_var='loop_var'),
        when='ansible_facts["os_family"] == "RedHat"',
        tags='tasks',
    )
    include = TaskInclude.load(ds)
    p_block = include.build_parent_block()
    assert p_block._attributes['loop_control']['loop_var'].value == 'loop_var'
    assert p_block._attributes['when'] == ds['when']
    assert p_block._attributes['tags'].value == ds['tags']

    # a test with 'apply'

# Generated at 2022-06-21 01:36:01.618944
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    setattr(task, 'action', 'include')
    setattr(task, 'args', {'a': 'b'})
    result = task.get_vars()
    assert result == {'a': 'b'}

    task = TaskInclude()
    setattr(task, 'action', 'include')
    setattr(task, 'args', {'a': 'b'})
    setattr(task, 'vars', {'c': 'd'})
    result = task.get_vars()
    assert result == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-21 01:36:07.366660
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(action='include', file='tasks.yaml')
    ti = TaskInclude()
    ti.preprocess_data(data)
    assert data.get('_raw_params') == 'tasks.yaml'


# Generated at 2022-06-21 01:36:24.123234
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Test get_vars method of class TaskInclude
    """
    import collections
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars

    class Host():
        def __init__(self):
            self.get_vars = lambda: {
                'ansible_myvar_1': 1,
                'ansible_myvar_2': 2,
            }


# Generated at 2022-06-21 01:36:36.421403
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    t = TaskInclude.load(
        {
            'action': 'include',
            'tags': ['tag1', 'tag2'],
            'name': 'My task name',
            'loop': 'item',
            'loop_with_items': [1, 2, 3],
            'apply': {'loop_control': {'loop_var': 'item'}},
            'when': 'item == 2',
            'block': [
                {
                    'action': 'debug',
                    'name': 'My debug'
                }
            ]
        },
        variable_manager=None,
        loader=None
    )

    assert 'action' in t.args
    assert t.args['action'] == 'include'
    assert 'tags' in t.args

# Generated at 2022-06-21 01:36:43.736781
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    import ansible.plugins.action
    from ansible.playbook.play import Play

    from ansible.plugins.action.normal import ActionModule
    import ansible.plugins.loader as plugin_loader

    # FIXME: this depends on the action plugins being loaded before unit tests
    #        are run, which is not guaranteed to be the case as unit tests
    #        are typically run before the action plugins are loaded
    p = plugin_loader.get(ActionModule, 'normal')()

    p = Play()
    p._ds = {
        'apply': {},
        '_raw_params': 'test_file',
    }
    p._task = TaskInclude(block=p)

    # Action 'include' is using '- include: ...' syntax
    p._task.action = 'include'

# Generated at 2022-06-21 01:36:49.245569
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    b = Block()
    task = TaskInclude(b)
    assert task.statically_loaded == False
    assert task._block == b
    assert task._play == None
    assert task._role == None
    assert task._task_include == None
    assert task._loader == None
    assert task._variable_manager == None
    assert task.action == None
    assert task.args == {}
    assert task.delegate_to == None
    assert task.delegate_facts == None
    assert task.loop == None
    assert task.loop_args == None
    assert task.loop_control == None
    assert task.loop_with_items == None
    assert task.name == None
    assert task.notify == []
    assert task.notified_by == []
    assert task.register == None
    assert task.run_

# Generated at 2022-06-21 01:37:00.652756
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    import ansible.constants as C

    ds = dict(
        include='foobar',
        include_relative='foobar2',
        include_tasks='foobar3',
        import_playbook='foobar4',
        import_role='foobar5',
        import_tasks='foobar6',
        include_role='foobar7',
        include_static='foobar8',
        include_tasks_static='foobar9',
    )


# Generated at 2022-06-21 01:37:13.010376
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Instantiate the TaskInclude class
    ti = TaskInclude()
    # Check if the object is an instance of its class
    assert isinstance(ti, TaskInclude)
    # Check attributes of the object
    assert ti.BASE == frozenset(('file', '_raw_params'))
    assert ti.OTHER_ARGS == frozenset(('apply',))
    assert ti.VALID_ARGS == frozenset(('apply', 'file', '_raw_params'))

# Generated at 2022-06-21 01:37:23.435431
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    parent_task = Task()
    parent_task.action = 'include'
    parent_task.vars = { 'parent_task_var': 'bar' }
    parent_task.args = { 'parent_task_arg': True }
    parent_task.tags = ['tag1', 'tag2']
    parent_task.when = '{{foo}}'
    task.action = 'include'
    task.vars = { 'task_var': 'foo' }
    task.args = { 'task_arg': False }
    task.tags = ['tagX', 'tagY']
    task.when = '{{foo2}}'
    # Do the parent_task.task setup
    task._parent = parent_task
    # Let's check the get_vars method of TaskInclude.
   

# Generated at 2022-06-21 01:37:35.923331
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {
        'action': 'include_tasks',
        'file': 'main.yml',
        'apply': {},
        'tags': [],
        'when': '',
        'unknown': ''
    }

    # Action: include_tasks
    # Attribute: unknown
    # Result: exception
    ti1 = TaskInclude()
    ti1.action = 'include_tasks'
    ok = False
    try:
        ti1.preprocess_data(data)
    except AnsibleParserError:
        ok = True
    assert ok

    # Action: import_tasks
    # Attribute: unknown
    # Result: exception
    ti2 = TaskInclude()
    ti2.action = 'import_tasks'
    ok = False

# Generated at 2022-06-21 01:37:46.584267
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    def ti_check_options(t, d):
        '''
        Utility function for testing.
        '''
        try:
            t.check_options(t, d)
            return 'ok'
        except AnsibleParserError as e:
            return 'error: {}'.format(e)

    apply_block_params = {
        'include_tasks': {'apply': {}},
        'import_tasks': {'apply': {}},
        'include_role': {'apply': {}},
        'import_role': {'apply': {}},
    }

# Generated at 2022-06-21 01:37:57.265588
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    task = TaskInclude.load({'name': 'test'})

    try:
        task.preprocess_data({'action': 'include_tasks', 'tags': ['t1'], 'invalid_attr': 'dummy'})
        assert False
    except AnsibleParserError:
        pass

    # Check that all attributes are allowed for 'import_tasks'
    all_attributes = list(set(C._INVALID_TASK_ATTRIBUTES).union(set(C._VALID_TASK_ATTRIBUTES)))
    task

# Generated at 2022-06-21 01:38:13.360982
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='shell', args='ls'))]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:38:22.478949
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Setup
    task_include = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'abc.yml'}
    task.block = None

    # Test
    task2 = task_include.check_options(task, {})

    # Verify
    assert task2 is task
    assert task.args == {'_raw_params': 'abc.yml'}

    # Test
    task.action = 'import_task'
    task.args = {'file': 'abc.yml'}
    task.block = None
    task2 = task_include.check_options(task, {})

    # Verify
    assert task2 is task
    assert task.args == {'_raw_params': 'abc.yml'}
    assert task.action

# Generated at 2022-06-21 01:38:35.553940
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude()
    new_task = task.copy()
    assert new_task.action == task.action
    assert new_task.loop is task.loop
    assert new_task.when is task.when
    assert new_task.name == task.name
    assert new_task.notify is task.notify
    assert new_task.loop_with is task.loop_with
    assert new_task.loop_control is task.loop_control
    assert new_task.run_once is task.run_once
    assert new_task.ignore_errors is task.ignore_errors
    assert new_task.always_run is task.always_run
    assert new_task.delegate_to is task.delegate_to
    assert new_task.delegate_facts is task.delegate_facts
    assert new

# Generated at 2022-06-21 01:38:45.863907
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    cj = TaskInclude.load(dict(
        include='test_example.yml',
   ), task_name='Test')
    cjnew = cj.copy()

    assert cj.include == cjnew.include
    assert cjnew.statically_loaded == cj.statically_loaded
    assert cjnew.action == cj.action
    assert cjnew.loop == cj.loop
    assert cjnew.loop_with == cj.loop_with
    assert cjnew.no_log == cj.no_log
    assert cjnew.ignore_errors == cj.ignore_errors
    assert cjnew.register == cj.register
    assert cjnew.run_once == cj.run_once
    assert cjnew.vars == cj.vars
   

# Generated at 2022-06-21 01:38:57.844142
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """Unit test for method load of class TaskInclude"""
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block

    obj_loaded = TaskInclude.load(
        {'include': {'apply': None, 'debug': 'yes', 'ignore_errors': True, 'tags': ['tag1', 'tag2'], 'file': 'roles.yml'}},
        block=Block(),
    )

    # Check the obj_loaded is an instance of TaskInclude
    assert isinstance(obj_loaded, TaskInclude)

    # Check the action is set to include
    assert 'include' == obj_loaded.action

    # Check the property '_role_include' is set to an IncludeRole object
    assert isinstance(obj_loaded._role_include, IncludeRole)

   

# Generated at 2022-06-21 01:39:02.953784
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    ti = TaskInclude()
    ti.action = 'include'
    ti.args = dict(x=10, y=20)
    ti.vars = { 'a': 1, 'b': 2 }
    # parent task is required to include vars from parent block
    ti._parent = Block()
    ti._parent._play = Play()
    ti._parent._play.context = PlayContext()
    ti._parent._play.context.update_vars({'c': 3, 'd': 4})
    task_block = Block()


# Generated at 2022-06-21 01:39:12.422698
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    block = Block()
    task = Task(block=block)
    ti = TaskInclude(block, task_include=task)
    ti.statically_loaded = True

    assert(isinstance(ti, TaskInclude))
    assert(isinstance(ti, Task))
    assert(ti.statically_loaded)

    ti2 = ti.copy()
    assert(isinstance(ti2, TaskInclude))
    assert(isinstance(ti2, Task))
    assert(ti2.statically_loaded)

    ti3 = ti.copy(exclude_tasks=True)
    assert(isinstance(ti3, TaskInclude))
    assert(not isinstance(ti3, Task))

# Generated at 2022-06-21 01:39:21.440146
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=None, variable_manager=variable_manager))

    play_context = PlayContext()

    ti = TaskInclude(block=Block(play=Play.load(dict(name="Test Play", hosts=['all'], gather_facts='no', connection='local',
                                      tasks=[{'name': 'test_task', 'action': 'test'}]), variable_manager=variable_manager, loader=None)))
    play_context.set_play(ti._play)


# Generated at 2022-06-21 01:39:30.887460
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # test empty data
    assert task.check_options({}, {}) is task
    # test valid args
    data = {'action': 'include', 'args': {'x': 'y', 'file': 'foo', 'tags': []}}
    assert task.check_options(task.load_data(data), data) is task

    # test invalid args
    data = {'action': 'import_role', 'args': {'x': 'y', 'file': 'foo'}}
    assert task.check_options(task.load_data(data), data) is task

    # test not specifying file
    data = {'action': 'include', 'args': {'x': 'y'}}

# Generated at 2022-06-21 01:39:40.166390
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ti.args = {
        'loop': '{{ bar }}',
        'ignore_errors': True
    }

    ds = {
        'when': '{{ foo }}',
        'action': 'include',
        'loop': '{{ baz }}',
        'bla': 'somevalue'
    }

    # It should not delete the action attribute
    assert 'action' in ti.preprocess_data(ds)

    # It should not delete the already specified loop attribute
    assert 'loop' in ti.preprocess_data(ds)

    # It should not delete the ignore_errors attribute
    assert 'ignore_errors' in ti.preprocess_data(ds)

    # It should delete the unknown attribute bla
    assert 'bla' not in ti.preprocess_data(ds)

# Generated at 2022-06-21 01:39:53.372810
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    """
    this is just a sanity check, as most of the arg handling is done
    by the metaclass.
    """

    t = TaskInclude()
    assert t._parent is None
    assert t._role is None
    assert t.action == 'Include'
    assert t._block is None
    assert t.name is None
    assert isinstance(t.args, FieldAttribute)
    assert isinstance(t._parent, FieldAttribute)
    assert isinstance(t._role, FieldAttribute)
    assert isinstance(t._loader, FieldAttribute)
    assert isinstance(t._block, FieldAttribute)
    assert isinstance(t._task_include, FieldAttribute)
    assert isinstance(t.deprecated_args, FieldAttribute)

# Generated at 2022-06-21 01:40:00.277940
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block

    play_context = PlayContext()
    play = Play().load({'name': 'foobar', 'connection': 'local'}, variable_manager=None, loader=None)
    play.included_roles = []

    def create_task(action, **kwargs):
        my_task = TaskInclude(None)
        my_task.action = action
        my_task.set_loader(None)
        my_task.args = kwargs

        return my_task


# Generated at 2022-06-21 01:40:11.792574
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # In this test case, the "include" task has no args and the parent block has
    # no vars.

    taskinclude1 = TaskInclude(block=None, role=None, task_include=None)
    taskinclude1.action = 'include'
    taskinclude1.args = {}
    taskinclude1._parent = None
    taskinclude1.vars = {'key1': 'value1'}
    assert taskinclude1.get_vars() == {'key1': 'value1'}

    # In this test case, the "include" task has args and the parent block has
    # no vars.

    taskinclude2 = TaskInclude(block=None, role=None, task_include=None)
    taskinclude2.action = 'include'

# Generated at 2022-06-21 01:40:21.168093
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    def get_variable_manager():
        loader, inventory, variable_manager = C.load_extra_vars()
        variable_manager.extra_vars = dict(one=1, two=2, three=3)
        return variable_manager

    def get_loader():
        loader = DataLoader()
        return loader

    def get_play_context():
        variable_manager = get_variable_manager()
        loader = get_loader()
        inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
        variable_manager.set_inventory(inventory)
        play_context = PlayContext()
        play_context.network_os = 'ios'
        play_context.remote_

# Generated at 2022-06-21 01:40:30.253105
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Run unit-tests TaskInclude.preprocess_data()
    """
    from ansible.module_utils.compat.six import PY3

    # Define test-cases

# Generated at 2022-06-21 01:40:41.500620
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext

    def TaskInclude_init(self, block=None, role=None, task_include=None):
        self._load_name = 'fake_load_name'
        self.action = 'fake_action'
        self._role = role
        self.dep_chain = []
        self.any_errors_fatal = False
        self.loop = None
        self._loop_with = None
        self._parent = block
        self._play = self._parent._play
        self._task_include = task_include
        self.notify = []
        self.tags = []
        self.when = None
        self.args = dict()
        self.vars = dict()
        self._variable_manager = None
        self._loader = None

    # we need to

# Generated at 2022-06-21 01:40:50.132895
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    def make_data_for_SetInclude(**kwargs):
        data = {
            # valid args with values
            'file':'../tasks/main.yml',
            'apply': {},
            # args with valid values not in VALID_ARGS
            'when': "False",
            'name': "test_task",
            'ignore_errors': True,
            'tags': ['tag1'],
            'any_plugins': 'value',  # not in VALID_INCLUDE_KEYWORDS
        }
        # Add keyword arguments to data
        data.update(kwargs)
        return data


# Generated at 2022-06-21 01:40:55.848274
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Prepare
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    playbook = Playbook.load(loader, inventory, variable_manager, 'test_task_include_get_vars.yaml')

    play = playbook[0]
    play._variable_manager = variable_manager
    play._variable_manager.set_inventory(inventory)
    play._variable_manager.set_play_context(PlayContext())



# Generated at 2022-06-21 01:41:08.015823
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Test task include module
    """
    # Test invalid args
    test_data = {
        'include': 'included tasks',
        'include_tasks': 'included tasks',
        'include_role': 'included roles',
        'include_vars': 'included vars',
        'import_tasks': 'imported tasks',
        'import_role': 'imported roles',
    }
    for action in test_data:
        for invalid_arg in ('foo', '_raw_params', 'bar', 'apply', 'file'):
            data = {
                'action': action,
                invalid_arg: 'value',
            }
            try:
                TaskInclude.load(data)
                assert False, 'Exception not raised'
            except AnsibleParserError as e:
                assert invalid_

# Generated at 2022-06-21 01:41:10.111561
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert isinstance(ti, TaskInclude)


# Generated at 2022-06-21 01:41:24.751406
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    d = dict()

    # Test file attribute validation
    # No file specified
    d['action'] = 'include'
    d['apply'] = None
    d['args'] = None
    d['at'] = None
    d['async'] = None
    d['async_seconds'] = None
    d['block'] = None
    d['changed_when'] = None
    d['collections'] = None
    d['connection'] = None
    d['delegate_to'] = None
    d['delimiter'] = None
    d['environment'] = None
    d['failed_when'] = None
    d['first_available_file'] = None
    d['follow'] = None
    d['ignore_errors'] = None
    d['loop'] = None
    d['loop_control'] = None

# Generated at 2022-06-21 01:41:36.105393
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti_dict = {'action': 'include', 'args': {'file': 'test_file.yml'}, 'async': 15, 'async_seconds': 10, 'changed_when': 'changed_when', 'delegate_to': 'delegate_to', 'failed_when': 'failed_when', 'ignore_errors': 'ignore_errors', 'loop': 'loop', 'loop_control': 'loop_control',
         'name': 'name', 'notify': 'notify', 'poll': 1, 'register': 'register', 'retries': 1, 'run_once': 'run_once', 'until': 'until', 'tags': 'tags', 'with_items': 'with_items', 'when': 'when'}
    ti = TaskInclude.load(ti_dict)
    assert (ti.action == 'include')
   

# Generated at 2022-06-21 01:41:43.318060
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    role = None
    block = None
    loader = None
    variable_manager = None
    task_include = None
    ti_dict = {"action": "include", "file": "blah", "thevar": "dummy"}

    ti = TaskInclude.load(ti_dict, block=block, role=role, task_include=task_include)
    ti.load_data(ti_dict, variable_manager=variable_manager, loader=loader)
    ti_vars = ti.get_vars()

    assert ti_vars['thevar'] == "dummy"

# Generated at 2022-06-21 01:41:50.475108
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    ds = dict()

    # Test that no error is raised for empty dataset
    task.preprocess_data(ds)
    assert True

    # Test that no error is raised for valid dataset
    ds = {'action': 'include_role', 'name': 'testRole'}
    ds = task.preprocess_data(ds)
    assert True

    # Test that an error is raised for invalid dataset
    ds['invalid_keyword'] = 'randomValue'
    try:
        task.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-21 01:41:57.190973
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options in class TaskInclude
    '''
    # Create the task that will be passed to method check_options
    task = TaskInclude()
    task.action = 'include_tasks'
    task.args = { '_raw_params': None, 'apply': {}, 'tags': 'tag1' }

    # Run method check_options without fail
    task.check_options(task, {})
    assert task.args['_raw_params']

    # Run method check_options with a bad option
    task.args['bad_option'] = None
    try:
        task.check_options(task, {})
        assert False
    except AnsibleParserError:
        assert True
    else:
        assert False

    # Run method check_options with 'apply' and no include (bad

# Generated at 2022-06-21 01:42:08.151098
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    role = "my role"
    task_include = "my task include"
    task = TaskInclude(block=block, role=role, task_include=task_include)
    task.static = True
    task.args['file'] = 'my file'

    task_copy = task.copy()
    assert task_copy.args['file'] == task.args['file']
    assert task_copy.statically_loaded == task.statically_loaded
    assert task_copy._role == role
    assert task_copy._parent == block
    assert task_copy._task_include == task_include

    task_copy = task.copy(exclude_parent=True, exclude_tasks=True)
    assert task_copy.args['file'] == task.args['file']
    assert task_copy.statically

# Generated at 2022-06-21 01:42:17.536063
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Monkey patching the display class
    def mock_warning(msg):
        assert msg == 'Ignoring invalid attribute: foo'
    display.warning = mock_warning

    # Simulating the env
    values = {
        'file': 'test.yml',
        'foo': 'bar',
    }
    data = {
        'action': 'include',
        'file': 'test.yml',
        'foo': 'bar'
    }

    # Instantiating the class
    task_include = TaskInclude()

    expected = {
        'action': 'include',
        'file': 'test.yml',
    }

    assert task_include.preprocess_data(data) == expected

# Generated at 2022-06-21 01:42:29.434560
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    data = dict(
        name='test',
        some_value='some_value'
    )
    variable_manager = 'variable_manager'
    loader = 'loader'
    ti1 = TaskInclude()
    ti1 = ti1.load_data(data, variable_manager=variable_manager, loader=loader)
    ti1.statically_loaded = True
    ti2 = ti1.copy()

    assert ti1 is not ti2
    assert ti1.name == ti2.name
    assert ti1.some_value == ti2.some_value
    assert ti1.variable_manager == ti2.variable_manager
    assert ti1.loader == ti2.loader
    assert ti1.statically_loaded == ti2.statically_loaded

    ti2.name = 'name2'
    assert ti1.name

# Generated at 2022-06-21 01:42:39.680509
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def _get_object(cls, *fixtures):
        data = dict()
        for fixture in fixtures:
            data.update(fixture)
        pm = ansible.playbook.Playbook.load(data, variable_manager=variable_manager, loader=loader)
        return pm.get_plays()[0].get_tasks()[0]

    loader = DataLoader()
    pm = ansible.playbook.Playbook.load({}, variable_manager=None, loader=loader)
    variable_manager = ansible.playbook.variable_manager.VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,'))
   

# Generated at 2022-06-21 01:42:48.092049
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t = TaskInclude()
    data = {
        'action': 'include_tasks',
        'file': 'example.yml',
        'args': {
            'something': {'bar': 'baz'},
            'author': 'some-guy',
        },
        'loop': ['value1', 'value2'],
        'loop_with': 'item'
    }
    pr_data = t.preprocess_data(data)

    assert pr_data == {
        'action': 'include_tasks',
        'file': 'example.yml',
        'args': {
            'something': {'bar': 'baz'},
            'author': 'some-guy',
        },
        'loop': ['value1', 'value2'],
        'loop_with': 'item'
    }

# Generated at 2022-06-21 01:43:01.129800
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True

    # Check that the method copy() returns a value of type TaskInclude
    assert isinstance(ti.copy(), TaskInclude)

# Generated at 2022-06-21 01:43:10.894818
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ti.args = {'not_valid_arg': True}

    assert ti.preprocess_data({}) == {'not_valid_arg': True}

    for ti_task in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        # test INVALID_TASK_ATTRIBUTE_FAILED = True
        C.INVALID_TASK_ATTRIBUTE_FAILED = True

        try:
            ti.preprocess_data({'action': ti_task})
        except AnsibleParserError as ex:
            assert ex.message == "'not_valid_arg' is not a valid attribute for a TaskInclude"
        else:
            assert False, 'AnsibleParserError was not raised'

        # test INVALID_TASK

# Generated at 2022-06-21 01:43:15.178017
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True

    new_ti = ti.copy()
    assert ti.statically_loaded == new_ti.statically_loaded, "TaskInclude.statically_loaded doesn't match after copy"

# Generated at 2022-06-21 01:43:28.252637
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Construct a task with no data
    task = TaskInclude()
    assert task.use_block() == False
    assert task.always_run == False
    assert task.action == 'meta'
    assert task.args == dict()
    assert task.notify == []
    assert task.when == []
    assert task.dep_chain == []
    assert task._parent == None
    assert task._role == None

    # Construct a task with data
    task = TaskInclude(
        {'action': 'include', 'args': {'ignore_errors': True, 'async': 10, 'poll': 0},
         'when': '{{ foo }}', 'notify': ['bar'], 'use_block': True, 'always_run': True}
    )
    assert task.use_block() == True
    assert task.always_

# Generated at 2022-06-21 01:43:38.750859
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    assert isinstance(ti, TaskInclude)  # should be a TaskInclude object
    assert ti.load(dict(include='some/file'))  # should not raise an error

    # param 'file' not specified
    invalid_dict = dict(action='include')
    try:
        ti.load(invalid_dict)
    except AnsibleParserError as e:
        pass
    else:
        raise AssertionError('no exception raised for file not specified')

    # param 'file' is None
    invalid_dict = dict(action='include', file=None)
    try:
        ti.load(invalid_dict)
    except AnsibleParserError as e:
        pass
    else:
        raise AssertionError('no exception raised for file not specified')

    # invalid options


# Generated at 2022-06-21 01:43:49.577276
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Correct usage
    for ds in [
        {'action': 'include_role',
         'name': 'Awesome Ansible Role',
         'tags': ['foo'], 'when': True},
        {'action': 'import_role', 'name': 'import_role_task'},
        {'action': 'import_tasks', 'file': 'tasks/something.yml'},
        {'action': 'include_tasks', 'name': 'include_tasks_task'},
        {'action': 'include_vars', 'name': 'include_vars_task'},
        {'action': 'include_playbook', 'name': 'include_playbook_task'},
    ]:
        result = TaskInclude.preprocess_data(ds)

# Generated at 2022-06-21 01:43:51.621637
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Proof by example
    >>> task = TaskInclude(None)
    >>> task
    <TaskInclude: None>
    '''
    pass

# Generated at 2022-06-21 01:43:56.707404
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()

    # check constructor
    assert ti.block is None
    assert ti.role is None
    assert ti.task_include is None
    assert not ti.statically_loaded

    # check method copy
    ti_copy = ti.copy()
    assert ti_copy.block is None
    assert ti_copy.role is None
    assert ti_copy.task_include is None
    assert not ti_copy.statically_loaded

# Generated at 2022-06-21 01:44:02.976500
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_data = {
        "action": "include",
        "args": {
            "name": "test",
            "apply": {
                "block": "test_block"
            }
        }
    }
    display.verbosity = 3
    task = Task.load(task_data)
    assert task.build_parent_block().parent.name == 'test_block'

# Generated at 2022-06-21 01:44:12.791687
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """Check TaskInclude.preprocess_data will raise an error if the attribute is not allowed
    """
    my_inc = TaskInclude()

    try:
        my_inc.preprocess_data({'action': 'include', 'include': 'my_file.yml'})
    except AnsibleParserError as e:
        assert "Invalid options" in str(e)
    except:
        assert False, 'Unexpected exception'

    try:
        my_inc.preprocess_data({'action': 'include', 'include': 'my_file.yml', 'args': {'foo': 1}})
    except AnsibleParserError as e:
        assert "Invalid options" in str(e)
    except:
        assert False, 'Unexpected exception'


# Generated at 2022-06-21 01:44:27.528796
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
  ti = TaskInclude()
  ti2 = ti.copy()
  assert ti2.statically_loaded == False
  
  ti.statically_loaded = True
  ti3 = ti.copy()
  assert ti3.statically_loaded == True
  
  ti4 = ti.copy(exclude_tasks=True)
  assert ti4.statically_loaded == True


# Generated at 2022-06-21 01:44:35.879126
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Set up necessary mocks
    task = TaskInclude()
    task._parent = Mock()
    task._parent.get_vars.return_value = {'some_var': 'foo'}

    # Run test
    vars = task.get_vars()
    # Assert result
    assert vars == {'some_var': 'foo'}

    # Clean up
    task._parent.get_vars.assert_called_once_with()



# Generated at 2022-06-21 01:44:44.611475
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = {'action': 'include', 'args': {'_raw_params': 'test.yml'}}
    include = TaskInclude(None, None, None)
    task = include.load(data)
    assert task._role is None
    assert task.action == data['action']
    assert task.args == data['args']
    assert task._parent is None
    assert task.static is False