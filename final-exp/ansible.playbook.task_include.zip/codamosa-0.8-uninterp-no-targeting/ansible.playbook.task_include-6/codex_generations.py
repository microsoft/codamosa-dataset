

# Generated at 2022-06-21 01:34:53.776861
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task

    def _check(data, task_class=TaskInclude):
        # No loader is provided because we don't need it and it would be a hassle to have to mock it
        task = TaskInclude.load(
            data,
            task_include=None,
            variable_manager=None,
            loader=None,
        )
        assert isinstance(task, task_class)
        return task.args

    def _test_include_args(data, expected_args, error=None):
        if error is not None:
            try:
                _check(data)
                assert False, 'Should have raised an error'
            except error:
                pass
        else:
            assert expected_args == _check(data)


# Generated at 2022-06-21 01:35:02.677523
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Basic test
    # We can't test the whole method because we need a valid Play object
    # and also a valid Task object.
    # However we can test the returned parent block
    data = {
        'block': [
            {'hosts': 'localhost', 'tasks': [{'action': 'shell', 'args': {'_raw_params': 'echo test'}}]},
        ],
        'apply': None,
        'block': [
            {'action': 'block', 'args': {'block': [{'action': 'debug', 'args': {'msg': 'This is a block'}}]}},
        ],
    }
    ti = TaskInclude(task_include=None)
    p_block = ti

# Generated at 2022-06-21 01:35:14.355359
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task=TaskInclude()
    task.action='include'
    task.args['_raw_params']='{{ playbook_dir }}/file.yml'
    task.args['apply']={}
    task.vars={'var1':'val1'}
    task.block=None
    task.conditional=None
    task.when={'condition': 'false'}
    task.notify={}
    task.loop={}
    task.statically_loaded = True
    task.tags=[]
    task.ignore_errors = False
    task.register=None
    task.delegate_to=None
    task.environment=None
    task.local_action=None
    task.transport='ssh'
    task.run_once=False
    task.always_run=False

# Generated at 2022-06-21 01:35:26.681194
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    
    class FakePlay(object):
        pass
    
    class FakeRole(object):
        pass
        
    class FakeVariable(object):
        pass
    
    class FakeLoader(object):
        pass
    
    f_play = FakePlay()
    f_role = FakeRole()
    f_variable = FakeVariable()
    f_loader = FakeLoader()
    
    task_include_obj = TaskInclude(
        block=Block(), 
        role=f_role, 
        task_include=Task(block=Block(block=[]), role=f_role, task_include=None), 
    )

# Generated at 2022-06-21 01:35:38.224198
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This unit test demonstrates how the vars from an include are not copied to
    the included task, unless it is an include.

       - include: include-vars.yaml
         vars:
           foo: this is foo
         tags:
           - tag1
       - include: include-vars.yaml
         vars:
           foo: this is foo
         tags:
           - tag1
         when: 1 == 0
       - include_role:
           name: include-vars.yaml
           vars:
             foo: this is foo
           tags:
             - tag1

    '''
    # Note: This code snippet of a playbook is just a place-holder.
    # The real code is never executed.
    # We deliberately ignore the code-quality and naked-statement errors.
    # pylint:

# Generated at 2022-06-21 01:35:47.786601
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = C.DEFAULT_LOADER
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'item': 'test'}
    display = Display()
    tqm = MockTQM()

    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.loader = C.DEFAULT_LOADER
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    block = Block('play', [])
    block.vars.update({'item': 'test'})
    block._play = MockPlay()


# Generated at 2022-06-21 01:35:51.069887
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManag

# Generated at 2022-06-21 01:35:53.610546
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Test that TaskInclude constructor behaves as expected
    '''
    task_include = TaskInclude(block=None, role=None, task_include=None)
    assert task_include.action == 'include'

# Generated at 2022-06-21 01:36:04.067407
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test for method get_vars of class TaskInclude
    '''
    from ansible.playbook.play import Play
    play_data = dict(
        name = "Ansible Play - test get_vars of class TaskInclude",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action='debug', msg="hostvar: {{ hostvar }}"),
        ],
    )
    play = Play().load(play_data, variable_manager=None, loader=None)
    play.post_validate(variable_manager=None, loader=None)
    ti = play.get_blocks()[0].get_tasks()[0]
    assert ti.action == 'debug'
    assert 'hostvar' not in ti.get_vars()
    ti._

# Generated at 2022-06-21 01:36:11.310968
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    def run_task_include_load(action, args, fail=False):
        ds = {
            'action': action,
            'args': args,
        }

        if fail:
            with pytest.raises(AnsibleParserError):
                TaskInclude.load(ds)
        else:
            ti = TaskInclude.load(ds)
            assert ti.action == action
            assert getattr(ti, 'apply', {}) == {}

    yield from run_task_include_load('include', {}, True)
    yield from run_task_include_load('include', {'file': 'hello.yml'})
    yield from run_task_include_load('include', {'file': 'hello.yml', 'apply': {}})

# Generated at 2022-06-21 01:36:24.647023
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.exclude_parent = True
    task_include.exclude_tasks = True
    task_include.statically_loaded = False  # Those attributes are set in the method 'copy'

    task_include_copied = task_include.copy()

    assert task_include_copied.exclude_parent == task_include.exclude_parent
    assert task_include_copied.exclude_tasks == task_include.exclude_tasks
    assert task_include_copied.statically_loaded == task_include.statically_loaded

# Generated at 2022-06-21 01:36:30.146246
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude(block=Block(), role=None, task_include=None)
    task.vars = None
    all_vars = task.get_vars()
    assert all_vars == dict()
    return all_vars

# Generated at 2022-06-21 01:36:39.069625
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.plugins.loader import find_plugin
    from ansible.playbook.role import Role

    class Dummy(object):
        '''
        Dummy class to work as block object in class TaskInclude test
        '''
        def __init__(self, role_name, role_path):
            self.role_name = role_name
            self.role_path = role_path

    class DummyRole(Role):
        '''
        Dummy class to work as Role object in class Role test
        '''

        def __init__(self, role_name, role_path):
            self.name = role_name
            self.role_path = role_path
            self.original_path = role_path

    role = DummyRole('foo', '/bar')
    block = Dummy('foo', '/bar')

# Generated at 2022-06-21 01:36:45.537936
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    class DummyVarsModule(Base):
        pass

    class DummyVariableManager(Base):
        def get_vars(self, loader, play, host, task):
            vars_module = VarsModule()
            vars_module.vars = {}
            vars_module.vars['dummy_var_manager'] = 'dummy_var_manager'
            return vars_module


    class DummyLoader:
        pass

    class DummyPlay(Play):
        def __init__(self):
            pass
        def get_variable_manager(self):
            return DummyVariableManager()


# Generated at 2022-06-21 01:36:57.490656
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    data = {'action': 'include', 'file': '/some/file'}

    assert isinstance(ti.load(data, None), TaskInclude)
    assert ti.args['file'] == '/some/file'

    # no file specified
    data = {'action': 'include'}
    try:
        ti.load(data, None)
    except AnsibleParserError:
        pass
    else:
        assert False, "TaskInclude.load did not raise an AnsibleParserError when no file was specified"

    data = {'action': 'include', 'other': 'something', 'ignore_errors': True}
    try:
        ti.load(data, None)
    except AnsibleParserError:
        pass

# Generated at 2022-06-21 01:37:09.839543
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    assert task.get_vars() == {}
    # now, we check that it works in the parent Task class, which is enough
    task._play = Mock()
    task._parent = Mock()
    task._parent.get_vars.return_value = {'i_am': 'the_parent'}
    task._role = False
    task.vars = {'i_am': 'the_task', 'i_am_also_a': 'task_var'}
    task.args = {'i_am': 'the_task_include', 'i_am_also_an': 'include_arg'}

# Generated at 2022-06-21 01:37:21.264189
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-21 01:37:35.172352
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play

    task_include = TaskInclude()
    task = Task()
    task.action = 'include'

    # empty args
    task.args = dict()
    assert task_include.check_options(task, dict()) == task

    # empty dict in args
    task.args = dict(apply=dict())
    assert task_include.check_options(task, dict()) == task

    # bad args
    task.args = dict(foo='bar')
    try:
        task_include.check_options(task, dict())
    except AnsibleParserError as e:
        assert 'Invalid options for include: foo' in str(e)
    else:
        assert False, 'Failed to raise AnsibleParserError for invalid options'

    # dict and action not in C._ACTION_INCL

# Generated at 2022-06-21 01:37:42.245278
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude()
    data = dict(
        apply = {'predefine': 'my_var', 'predefined': 'my_var'}
    )
    task.load(data)
    assert task.args['apply'] == {'predefine': 'my_var'}
    assert task.args['predefined'] == 'my_var'

# Generated at 2022-06-21 01:37:55.079226
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test get_vars when include is not specified
    task = TaskInclude()
    task.action = 'shell'
    task.vars = {'a': 'b'}
    task.args = {'c': 'd'}
    assert task.get_vars() == {'a': 'b', 'c': 'd'}

    # Test get_vars when include is not specified and parent is set
    task = TaskInclude()
    task.action = 'shell'
    task.vars = {'a': 'b'}
    task.args = {'c': 'd'}
    parent = Task()
    parent.vars = {'a': 'x', 'e': 'f'}
    task._parent = parent

# Generated at 2022-06-21 01:38:09.966808
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.sentinel import Sentinel

    assert TaskInclude()

    ti = TaskInclude()
    ti.args = {'_raw_params': 'foo.yml', 'tags': ['a', 'b', 'c'], 'action': 'include'}
    ds = {'tags': ['d', 'e', 'f'], 'other': 1234}
    assert ti.preprocess_data(ds) == {'tags': ['d', 'e', 'f'], 'other': Sentinel, 'action': 'include'}

    ti.args = {'_raw_params': 'foo.yml', 'tags': ['a', 'b', 'c'], 'action': 'import_playbook'}

# Generated at 2022-06-21 01:38:19.604592
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    def create_task_include(data):
        ti = TaskInclude()
        ti.load_data(data)
        return ti

    def validate_task_include(data, raises, task_action=None):
        if task_action is None:
            task_action = data.get('action')
        if raises:
            with pytest.raises(AnsibleParserError):
                create_task_include(data)
        else:
            task = create_task_include(data)
            assert task.action == task_action
            assert task.args['_raw_params'] == 'static_file.yml'

    # No file
    validate_task_include({'action': 'static_include'}, raises=True)
    # Invalid options

# Generated at 2022-06-21 01:38:29.744942
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader

    PrivilegedBlock = namedtuple('PrivilegedBlock', ['get_vars'])
    role = Role()
    p_block = PrivilegedBlock(lambda : {})
    variable_manager = VariableManager()
    loader = DataLoader()

    # Valid `apply`
    task = TaskInclude.load(
        {'apply': {'name': 'foo'}, 'file': 'baz'},
        play=Play(),
        block=p_block,
        role=role,
        variable_manager=variable_manager,
        loader=loader,
    )
    p_block

# Generated at 2022-06-21 01:38:39.651708
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.task_include as task_include
    import ansible.playbook.task as task

    variable_manager = Sentinel
    loader = Sentinel
    task_vars = dict()
    blocks = list()

    role = Sentinel
    play = Sentinel
    apply_attrs = dict()
    task_include.Block = Block.load
    task_include.Task = Task
    task_include.TaskInclude = TaskInclude.load

    # Testing when action is different from 'include'
    data = dict(name="", action="", args={}, ignore_errors=None)
    block = Block(play=play, role=role, task_include=Sentinel)
    ti = task_include.TaskInclude(block=block, role=role, task_include=Sentinel)

    # _get_parent_block()

# Generated at 2022-06-21 01:38:45.926563
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext

    task = TaskInclude()
    task.action = 'include'
    task.post_validate(PlayContext())
    task.args = dict(apply=dict(block=[dict(name='test')]))
    p_block = task.build_parent_block()
    assert hasattr(p_block, 'block')
    assert isinstance(p_block.block, list)
    assert len(p_block.block) == 1
    assert isinstance(p_block.block[0], Task)
    assert p_block.block[0].name == 'test'

    task.args = dict(apply=dict(ignore_errors=True))
    p_block = task.build_parent_block()
    assert p_block.ignore_errors is True


# Generated at 2022-06-21 01:38:56.562121
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for the method TaskInclude.build_parent_block
    '''
    # first test: task without apply
    task = TaskInclude()
    result = task.build_parent_block()
    assert result == task

    # second test: task with apply
    task_args = {'apply': {}}
    task.args = task_args
    result = task.build_parent_block()
    assert result == task._parent_block

    # third test: task with apply, no parent play
    task._parent_play = None
    result = task.build_parent_block()
    assert result == task


# Generated at 2022-06-21 01:39:09.405449
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()

    # 1. Test invalidate check for 'action' attribute with value in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    task_data = dict(action='include_role', foo='bar')
    expected_task_data = dict(action='include_role', foo='bar')
    actual_task_data = task_include.preprocess_data(task_data)
    assert actual_task_data == expected_task_data

    # 2. Test invalidate check for 'action' attribute with value in C._ACTION_ALL_INCLUDE_IMPORT_TASKS
    task_data = dict(action='import_tasks', foo='bar')
    expected_task_data = dict(action='import_tasks')
    actual_task_data = task_include.pre

# Generated at 2022-06-21 01:39:19.706330
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.base import Base
    from units.mock.loader import DictDataLoader

    block_args = dict(
        block=['some block'],
        role=IncludedFile(),
        task_include=TaskInclude(),
        loader=DictDataLoader(),
        variable_manager=Base()
    )

    assert block_args['role'] == None, 'role is assigned to block_args before value is set'

    block = Block.load(block_args)
    task = TaskInclude.load(
        dict(action = 'apt',
             file = 123),
        block=block
    )

    new_task

# Generated at 2022-06-21 01:39:26.257501
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook

    # Mock the necessary objects
    test_play = Play()
    test_play.name = 'test'

    test_play_context = PlayContext()

    test_task = TaskInclude(block=test_play)
    test_task.action = 'include'

    test_task_args = {
        '_raw_params': 'test_params',
        'vars': {
            'test_var': 123
        },
        'apply': {
            'name': 'test_parent_block',
            'block': []
        }
    }
    test_task

# Generated at 2022-06-21 01:39:37.667352
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Here we test the behavior of TaskInclude.get_vars() method
    '''
    # Here we check that get_vars for 'include' action
    # will return a dict with keys 'a', 'b', 'c', '_raw_params'
    # and with values 1, 2 and 4
    task = TaskInclude(args={'_raw_params': 'file.yml', 'a': 1, 'b': 2}, action='include')
    assert task.get_vars().keys() == ['a', 'b', '_raw_params']
    assert task.get_vars()['a'] == 1
    assert task.get_vars()['b'] == 2
    assert task.get_vars()['_raw_params'] == 'file.yml'

    # Here we check that the parent

# Generated at 2022-06-21 01:39:53.747443
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.tasks import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import action_loader
    # Create random play instance to use as parent in TaskInclude instances
    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': []
    }, variable_manager=None, loader=None)
    # Create random role instance to use as parent in TaskInclude instances
    role = Role().load({
        'name': 'test role',
        'tasks': []
    }, variable_manager=None, loader=None)
    # Create random task instance to

# Generated at 2022-06-21 01:39:58.992317
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # creating object for TaskInclude class
    task_include = TaskInclude()

    # check for the object type
    assert isinstance(task_include, TaskInclude) == True

    # check for the object attribute
    assert isinstance(task_include.BASE, frozenset) == True
    assert isinstance(task_include.OTHER_ARGS, frozenset) == True
    assert isinstance(task_include.VALID_ARGS, frozenset) == True
    assert isinstance(task_include.VALID_INCLUDE_KEYWORDS, frozenset) == True

# Generated at 2022-06-21 01:40:00.985588
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task = TaskInclude(block=None)
    assert task is not None

# Generated at 2022-06-21 01:40:12.297707
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.utils.vars as vars_mod
    import ansible.vars.manager
    import ansible.vars.unsafe_proxy

    sample_task_args = dict(
        apply=dict(
            block=[]
        )
    )
    sample_block_args = dict(
        block=[]
    )
    fake_play = dict(
        hosts='localhost',
        roles=[],
        vars_files=[],
        vars=dict(),
        tasks=[],
        handlers=[],
    )
    fake_loader = dict()
    fake_variable_manager = ansible.vars.unsafe_proxy.UnsafeProxy(ansible.vars.manager.VariableManager())

    ti = TaskInclude()
    ti.args = sample_task_args
    ti._parent = dict()


# Generated at 2022-06-21 01:40:14.211578
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # TODO: test for constructor of class TaskInclude
    assert False, "Test for constructor of class TaskInclude not implemented"


# Generated at 2022-06-21 01:40:27.797574
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    The defined test_TaskInclude_load() method tests the load method of
    the TaskInclude class.
    '''

    task_include = TaskInclude()

    # Case of an invalid option
    try:
        task_include.check_options(task_include.load_data({'meta': 'bad_opt'}, {}), {'meta': 'bad_opt'})
    except AnsibleParserError as e:
        assert 'Invalid options for include: meta' == str(e)

    # Case of an invalid apply option
    try:
        task_include.check_options(task_include.load_data({'apply': 'bad_opt'}, {}), {'apply': 'bad_opt'})
    except AnsibleParserError as e:
        assert 'Expected a dict for apply but got <class' in str

# Generated at 2022-06-21 01:40:40.485661
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Set-up
    task = TaskInclude()
    # These are the defaults
    test_args = {
        'file': '/path/to/somefile.yml',
        'apply': {
            'block': 'hosts: localhost',
        },
        'tags': 'tag1, tag2',
    }
    action = 'include'
    task.action = action
    task.args = test_args
    task._parent = Block()
    task._parent.apply_defaults(task)
    # These won't be changed
    expected_action = action
    expected_args = test_args
    # This will be added
    expected_args['_raw_params'] = expected_args.pop('file')

    # Round 1 - testing 'include' and 'import_role'
    expected_action = 'include'

# Generated at 2022-06-21 01:40:46.546730
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict()
    task_include.args['debug'] = 'msg={{ hello }}'
    task_include.statically_loaded = True

    task_include_copied = task_include.copy()
    assert task_include_copied.args['debug'] == 'msg={{ hello }}'
    assert task_include_copied.statically_loaded == True

# Generated at 2022-06-21 01:40:58.607947
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    blocks = [{
        'block': [],
        'always': [],
        'rescue': [],
    }]
    blocks_data = []
    for block in blocks:
        b = Block.load(block, play=Play())
        blocks_data.append(b)

    def test_func(task, blocks_data):
        p_block = task.build_parent_block()

        if task.args.pop('apply', {}):
            assert isinstance(p_block, Block)
        else:
            assert isinstance(p_block, TaskInclude)

    task = TaskInclude()
    for block in blocks_data:
        task._parent = block
        test_func(task, blocks_data)

# Generated at 2022-06-21 01:41:09.297148
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = dict(action='include', file='test')
    task = TaskInclude.load(data)
    assert task._parent is None
    assert task.action == 'include'
    assert task.name is None
    assert task.file == 'test'
    assert task.loop_control == dict(loop_var=Sentinel)
    assert task.tags == []
    assert task.when == []
    assert task.register == None
    assert task.ignore_errors == False
    assert task.args == dict(file='test')
    assert task.notify == []
    assert task.delegate_to is None
    assert task.dependent_role is None
    assert task.delegate_facts is None



# Generated at 2022-06-21 01:41:24.246494
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # # Simplistic test, check that the above list of key names is not empty
    assert(TaskInclude.VALID_INCLUDE_KEYWORDS)

    # Other tests from Ansible project
    # (mostly exact copies from other tests as Ansible does not test TaskInclude, does not have separate TaskInclude tests)

# Generated at 2022-06-21 01:41:35.394047
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders

    play = Play.load(dict(name="test_play", hosts=["localhost"], gather_facts="no",
        tasks=[dict(action="test task", apply=dict(block=[]))]))
    block = Block.load(play.get_block_list()[0])
    task = Task.load(block.block)
    task_include = TaskInclude.load(task.task_include)
    p_block = task_include.build_parent_block()
    assert isinstance(p_block, Block)

# Generated at 2022-06-21 01:41:38.695267
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict(action=None, vars=None, some_stuff='test', other_stuff='test2')
    task.check_options(task.load_data(data), data)

# Generated at 2022-06-21 01:41:45.937443
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class MockDisplay():
        def __getattr__(self, name):
            return super(MockDisplay, self).__getattr__(name)
        def verbose(self, msg, *args, **kwargs):
            return 'Verbose: %s' % msg
        def warning(self, msg, *args, **kwargs):
            return 'Warning: %s' % msg

    vars_mock = dict(
        test_var=1
    )

    data = dict(
        action='include_role',
        role='foo.bar'
    )
    t = TaskInclude()
    t.load(
        data,
        variable_manager=vars_mock,
    )

    assert t._task_include is None
    assert t.action == 'include_role'

# Generated at 2022-06-21 01:41:58.290109
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # The class 'TaskInclude' does not have any property which is not read-only
    # Hence, the test cases do not need to test any failures as the fixtures
    # themselves are not modifiable.
    from ansible.playbook.task_include import TaskInclude

    # To verify method 'preprocess_data' works as expected
    taskInclude = TaskInclude()

    # To verify the method handles empty values
    ds_empty_dict = {}
    assert(taskInclude.preprocess_data(ds_empty_dict) == ds_empty_dict)

    # To verify the method handles valid values
    ds_valid = {
        'include': 'roles/common/tasks/main.yml',
        'tags': ['some_tag'],
    }

# Generated at 2022-06-21 01:41:59.699469
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.statically_loaded == False
    return ti

# Generated at 2022-06-21 01:42:11.216409
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from .. import DataLoader
    from .. import Play
    from .. import Playbook
    from .. import VariableManager

    mock_loader = DataLoader()
    mock_vm = VariableManager()
    mock_play = Play().load({}, variable_manager=mock_vm, loader=mock_loader)
    mock_ti = TaskInclude(block=mock_play)

    # Test block creation with 'apply'
    apply_attrs = dict(block=dict(), play=dict(), role=dict(), task_include=dict(),
                       loader=dict(), variable_manager=dict())
    mock_ti.args = dict(apply=apply_attrs)
    mock_ti._parent = mock_play
    p_block = mock_ti.build_parent_block()
    assert isinstance(p_block, Block)

    # Test block creation

# Generated at 2022-06-21 01:42:20.700044
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)
    play = Play().load({'name': 'test', 'hosts': 'all'}, loader=loader, variable_manager=variable_manager)

    # Simple include, no options

# Generated at 2022-06-21 01:42:31.054549
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    # Including the task include in case it is not already there
    from ansible.playbook.task_include import TaskInclude

    ti = TaskInclude()
    ti.args = {'apply': {}, 'file': 'blah.yaml'}  # for simplicity
    ti.statically_loaded = True

    ti_copy = ti.copy(False, False)

    # The new task include should have the same args, as a new object, i.e. a copy of the original
    assert ti_copy.args == {'apply': {}, 'file': 'blah.yaml'}

    # The new task include should have the same statically_loaded variable, in this case True
    assert ti_copy.statically_loaded == True

    # Now, let's repeat the test but we will use different args, so we can identify that the args were

# Generated at 2022-06-21 01:42:39.794764
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Case 1: "apply" specified but empty
    apply_attrs = {}
    apply_attrs['block'] = []
    apply_attrs['some_attr'] = 'some_value'
    block = Block()
    block.args = apply_attrs
    block_loaded = Block.load(apply_attrs)
    assert block_loaded.some_attr == 'some_value'
    assert block_loaded.block == []
    assert block._parent is None
    assert block._role is None
    assert block._loader is None
    assert block._variable_manager is None

    # Case 2: "apply" not specified
    block = Block()
    apply_attrs = {}
    p_block = block.build_parent_block(apply_attrs)
    assert block == p_block

# Generated at 2022-06-21 01:42:51.844488
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    t_block = {
        'apply': {
            'environment': 'prod',
            'tags': ['pre-prod', 'db'],
            'when': 'env_is_prod',
        }
    }
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.action = 'include_tasks'
    ti.args = t_block
    ti._parent = Block()

    # Create a block object, which will be used to create the parent
    # block for the included tasks
    ti._parent._play = Play()
    ti._parent._play._loader = module_loader
    ti

# Generated at 2022-06-21 01:42:55.908058
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.static_include_task = True
    ti.statically_loaded = True
    ti_copy = ti.copy()
    assert ti_copy.static_include_task
    assert ti_copy.statically_loaded


# Generated at 2022-06-21 01:43:09.412107
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    # Build the playbook
    pb = {"name": "test_pb_block",
          "hosts": ["one", "two"],
          "gather_facts": "no",
          "tasks": [
              {"action": "include_tasks",
               "name": "test_it",
               "apply": {
                   "block": [
                   ],
               }
               }
          ]
          }

    # Load the playlist
    play = Play().load(pb, variable_manager=None, loader=None)

    # Gets the task
    task = play.get_tasks()[0]

    # Gets the parent block
    parent_block = task.build_parent_block()

    # Verify that parent_block is really

# Generated at 2022-06-21 01:43:15.648310
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    display = Display()
    display.verbosity = 4

    task_proper = TaskInclude.load(
        dict(
            include_tasks="role.yml",
        ),
        variable_manager=None,
        loader=None,
    )

    assert not task_proper.args.get('_raw_params')
    assert task_proper.args.get('file') == "role.yml"
    assert len(task_proper.args.keys()) == 1

    task_proper = TaskInclude.load(
        dict(
            include_tasks="role.yml",
            foo=1,
        ),
        variable_manager=None,
        loader=None,
    )

    assert not task_proper.args.get('_raw_params')
    assert task_proper.args

# Generated at 2022-06-21 01:43:28.456269
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-21 01:43:38.807386
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    task_vars = dict()
    play_context = PlayContext(variable_manager=variable_manager, options=dict())

# Generated at 2022-06-21 01:43:49.601837
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # This test is just for 'include' action
    assert TaskInclude.load({'include': 'myplay.yml'}, block=None).preprocess_data({'include': 'myplay.yml'}) == {'action': 'include', '_raw_params': 'myplay.yml'}
    assert TaskInclude.load({'include': 'myplay.yml'}, block=None).preprocess_data({'include': 'myplay.yml',
                                                                                     'tags': ['include_tags']}) == {'action': 'include', '_raw_params': 'myplay.yml', 'tags': ['include_tags']}
    # This test is for 'import_playbook' action
    assert TaskInclude.load({'import_playbook': 'myplay.yml'}, block=None).pre

# Generated at 2022-06-21 01:43:57.515726
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Validate a valid include task
    # _raw_params is defined as a FieldAttribute in Task class
    TaskInclude._validate_tags = lambda *args, **kwargs: True
   

# Generated at 2022-06-21 01:44:07.345920
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ds = {
        'block': [],
        'apply': [],
        'file': '/path/to/the_file',
        'no_log': True,
        'tags': ['tag1', 'tag2'],
        'when': 'some_condition'
    }
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:44:10.674452
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    assert ti.copy().statically_loaded is True
    assert ti.copy(True, True).statically_loaded is True

# Generated at 2022-06-21 01:44:30.616352
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a task
    from ansible.playbook.play_context import PlayContext

    p = Play()
    r = Role()
    r._role_path = os.path.join(os.getcwd(), '../test/support/test-role-1')
    p._entries = [r]
    r._parent = p
    t = Task()
    t._parent = r
    setattr(P, 'vars', dict())
    setattr(P, 'vars_prompt', dict())
    setattr(P, 'vars_files', list())
    t._play_context = PlayContext(play=p)

    # Create an instance of TaskInclude
    tinc = TaskInclude()
    tinc._parent = t
    tinc.action = 'include'

# Generated at 2022-06-21 01:44:39.637403
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.register = 'ignoreme'
    task_include.action = 'include'

    # includes the args of the include into the vars
    # 'x' and 'y' are included in the vars
    task_include.args = dict(x=1, y=2)
    task_include.vars = dict(a=1, b=2)
    assert task_include.get_vars() == dict(x=1, y=2, a=1, b=2)
    assert task_include.vars == dict(a=1, b=2)

    # exclude the args of the include into the vars
    # when action is not 'include'
    task_include.action = 'ignoreme'