

# Generated at 2022-06-21 01:34:53.740657
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    vm = VariableManager()
    im = InventoryManager(vm)
    loader = DataLoader()

    # Emulate the hostvars inventory cache
    vm.set_inventory(im)

    class Dummy:
        pass

    class Dummy2:
        pass

    host = Dummy()
    host.get_vars = lambda: {'foo': 'bar'}
    host.name = 'localhost'
    host.is_localhost = lambda: True


# Generated at 2022-06-21 01:35:02.649900
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    TaskInclude: loading data with invalid options
    '''
    import copy
    data = dict(
        action='include_role',
        file='include.yml',
        apply=dict(y=42),
        tasks=dict(x=1),
        unknown=dict(z=42),
    )
    # check that 'apply' is not accepted for 'include'
    if 'include' in C._ACTION_INCLUDE_TASKS:
        data['action'] = 'include'
        try:
            TaskInclude.load(copy.deepcopy(data), role=None)
        except AnsibleParserError:
            pass
        else:
            raise AssertionError('Failed to detect invalid options for %s' % data['action'])

    # check that 'tasks' is not accepted for '

# Generated at 2022-06-21 01:35:10.935132
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(
        action='include',
        debug=True,
        apply=dict(do_something=True),
    )

    task = TaskInclude()
    ds = task.preprocess_data(data)

    assert ds['debug'] == True
    assert ds['apply'] == dict(do_something=True)
    assert 'debug' in task.VALID_INCLUDE_KEYWORDS



# Generated at 2022-06-21 01:35:24.131399
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    ti = TaskInclude(
        block=Block(
            role=None,
            parent=Play().load(
                {'name': 'fooplay',
                 'hosts': 'localhost',
                 'gather_facts': 'no'},
                variable_manager=VariableManager(),
                loader=None
            )
        )
    )
    ti.args = {'action': 'include_tasks', 'file': 'bar.yaml'}
    ti.statically_loaded = True

    new_ti = ti.copy()

    assert new_ti is not ti
    assert isinstance(new_ti, TaskInclude)
    assert new_ti.args == ti.args
    assert new_ti.statically_loaded

# Generated at 2022-06-21 01:35:32.668874
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    from ansible.playbook.attribute import FieldAttribute

    # Test case 1: action is not in [include, import_playbook]
    ds_1 = dict(name="fake task", action="action1")
    ti = TaskInclude()
    try:
        ti.preprocess_data(ds_1)
    except AnsibleParserError as e:
        assert False, "AnsibleParserError is raised that is not expected"
    else:
        assertTrue(True)

    # Test case 2: action is not in [include, import_playbook] but loop is not Sentinel
    ds_2 = dict(name="fake task", action="action2", loop="{{foo}}")
    ti_2 = TaskInclude()

# Generated at 2022-06-21 01:35:43.655245
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context._play = True
    context._play_hosts = {}
    context._hostvars = {}

    ds = {
        'action': 'include_tasks',
        'args': {
            'file': 'tasks/static_including.yml',
            'apply': {
                'serial': 1,
                'name': 'test',
            },
            # 'tags': 'test',  # TODO: Not sure why this is commented out.
            # 'when': 'test',  # TODO: Not sure why this is commented out.
        }
    }

    task = TaskInclude.load(ds, variable_manager=None, loader=None)

# Generated at 2022-06-21 01:35:54.767510
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    if not C.DEFAULT_DEBUG:
        return

    # Create an fake inventory
    from ansible.inventory.manager import InventoryManager
    frozenset_of_groups = frozenset([])
    host_pattern = 'all'
    hostlist = ["127.0.0.1"]
    # Create a fake inventory
    inv_manager = InventoryManager(loader=None, sources=hostlist)
    inv_manager.hosts = inv_manager.inventory.get_hosts(host_pattern)

    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    frozenset_of_hosts =  frozenset(inv_manager.hosts)

# Generated at 2022-06-21 01:36:04.946949
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task = TaskInclude(block=None, role=None, task_include=None)

    task._parent = None
    task.vars = {'a': 'b'}
    task.args = {'c': 'd'}
    task.action = 'include'

    assert task.get_vars() == {'a': 'b', 'c': 'd'}

    task._parent = None
    task.vars = {'a': 'b'}
    task.args = {'c': 'd'}
    task.action = 'include_role'

    assert task.get_vars() == {'a': 'b'}

    task._parent = None
    task.vars = {'a': 'b'}
    task.args = {'c': 'd'}

# Generated at 2022-06-21 01:36:15.999495
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    loader = DictDataLoader({
        "test.yml": '''
        - include: test2.yml
          foo: '{{x}}'
        ''',
        "test2.yml": '''
        - ping:
        ''',
    })

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))
    p = Play.load(dict(
        name="foobar",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(args=dict(x=42), include="test.yml"),
        ]
    ), loader=loader, variable_manager=variable_manager)

    assert len(p.get_tasks()) == 2
    assert isinstance(p.get_tasks()[0], TaskInclude)

# Generated at 2022-06-21 01:36:25.686838
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    task = TaskInclude()
    all_valid_args = frozenset(task.VALID_ARGS)
    all_valid_include_keywords = frozenset(task.VALID_INCLUDE_KEYWORDS)

    def assert_valid_options(options):
        new_task = TaskInclude(task_include=task)
        for k, v in options.items():
            new_task.args[k] = v
        new_task.action = action
        if expect:
            assert task.check_options(new_task, data=new_task.args) == new_task
        else:
            with pytest.raises(AssertionError, match=error_msg):
                assert task.check_options(new_task, data=new_task.args) == new_task

    # test no

# Generated at 2022-06-21 01:36:38.968433
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.handler import HandlerTaskInclude

    # Assume we have the action 'include_tasks' in the list of all
    # include_tasks, import_tasks and proper_tasks.
    task = TaskInclude()
    data = dict()

    data['action'] = 'include_tasks'

    # Case 1: all valid options
    data['args'] = dict(file='/etc/foo.yml', _raw_params='/etc/foo.yml')
    options = task.check_options(task.load_data(data), data)
    assert options.args == dict(file='/etc/foo.yml', _raw_params='/etc/foo.yml', action='include_tasks')

    # Case 2: plugin options

# Generated at 2022-06-21 01:36:47.881846
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def _new_task(ansible_action, **args):
        return TaskInclude(loader=DummyLoader(), variable_manager=DummyVariableManager(),
                           block=DummyBlock(**args), task_include=DummyTaskInclude(action=ansible_action))

    def _check_vars_with(expected, **args):
        assert _new_task('include', **args).get_vars() == expected

    _check_vars_with({'a': 1}, a=1)
    _check_vars_with({'a': 1}, action='include', a=1)
    # check_vars on other actions is same as parent's:
    for action in ['import_tasks', 'import_role', 'include_role']:
        _check_vars_with({}, action=action)
       

# Generated at 2022-06-21 01:36:59.802281
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude

    # Single validation for both global and per-task options
    def _assertValidateOption(option, expect):
        task = TaskInclude.load(
            task_data={
                'name': 'test',
                'include': 'test.yml',
                option: True,
            },
            variable_manager=None,
            loader=None
        )
        assert expect == bool(task.args.get(option)), "Unexpected result for \"%s\": %s" % (option, task.args)

    def _assertValidateTaskIncludeOptions(option, expect=True):
        _assertValidateOption(option, expect)

    def _assertValidateHandlerTaskIncludeOptions(option, expect=True):
        _assertValidateOption(option, expect)

   

# Generated at 2022-06-21 01:37:12.081303
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a fake parent task
    test_parent_task = Task()
    test_parent_task.vars = dict(key1='value1', key2='value2')

    test_include = TaskInclude()
    test_include.args = dict(key3='value3', key4='value4')
    test_include._parent = test_parent_task

    # Test get_vars for action 'include'
    test_include.action = 'include'
    assert test_include.get_vars() == dict(key1='value1', key2='value2', key3='value3', key4='value4')

    # Test get_vars for action 'import_tasks'
    test_include.action = 'import_tasks'
    assert test_include.get_vars() == dict()

    # Test

# Generated at 2022-06-21 01:37:22.710723
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role.definition import RoleDefinition

    data = {
        'action': 'include',
        'mykey': 'myvalue',
        'debugger': [{}],
        'ignore_errors': 'no',
    }

    role_definition = RoleDefinition('role')
    task = TaskInclude(role=role_definition)
    role_definition.set_loader(task._loader)

    new_data = task.preprocess_data(data)
    assert 'mykey' not in new_data
    assert 'debugger' in new_data
    assert 'ignore_errors' in new_data

    data = {
        'action': 'include_role',
        'mykey': 'myvalue',
        'ignore_errors': 'no',
    }

    role_definition = RoleDefinition('role')


# Generated at 2022-06-21 01:37:35.721043
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.factory import Factory
    from ansible.plugins.strategy.linear import StrategyModule

    context = PlayContext()
    play = Play.load({
        'name': 'test',
        'hosts': 'all'
    }, variable_manager={}, loader=None)

    ti = TaskInclude(
        block=None,
        role=None,
        task_include=None,
    )


# Generated at 2022-06-21 01:37:46.479042
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # tests TaskInclude class method 'check_options'
    assert callable(TaskInclude.check_options)

    ti = TaskInclude()

    ti.check_options(
        ti.load_data({'action': 'include_tasks', 'file': 'some.yml'}),
        {'action': 'include_tasks', 'file': 'some.yml'}
    )


# Generated at 2022-06-21 01:37:57.207257
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude(task_include=Sentinel)
    ti.action = 'include'
    ti.args = {'_raw_params': 'vars/main.yml'}
    ti.vars = {'foo': 'bar'}
    ti.tags = ['always']
    ti.when = 'yesterday'
    ti.dep_chain = [Sentinel]

    ti.statically_loaded = True

    assert ti.args == {'_raw_params': 'vars/main.yml'}
    assert ti.vars == {'foo': 'bar'}
    assert ti.dep_chain == [Sentinel]
    assert ti.statically_loaded is True

    new_ti = ti.copy()


# Generated at 2022-06-21 01:38:00.697041
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Unit test for method copy of class TaskInclude
    '''
    task = TaskInclude()
    task.statically_loaded = True
    task.copy()
    assert "copy" == task.name

# Generated at 2022-06-21 01:38:09.784856
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class FakeTaskInclude(TaskInclude):
        _parent = None
        _shared_loader_obj = None
        _role = None
        _variable_manager = None

    ti = FakeTaskInclude()
    # Base case: no vars, no _parent
    assert ti.get_vars() == {}

    # Base case: no vars, _parent with vars
    ti2 = FakeTaskInclude()
    ti2._parent = FakeTaskInclude()
    ti2._parent._vars = dict(foo='bar')
    assert ti2.get_vars() == dict(foo='bar')

    # Base case: vars, no _parent
    ti3 = FakeTaskInclude()
    ti3.vars = dict(bar='baz')

# Generated at 2022-06-21 01:38:23.334714
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = {
        'action': 'include_role',
        'name': 'some_role_name',
        'apply': {'collection': 'some_collection'}
    }
    ti = TaskInclude.load(data)

    assert ti.action == 'include_role'
    assert ti.args['name'] == 'some_role_name'
    assert len(ti.args) == 2
    assert ti.args['name'] == 'some_role_name'
    assert ti.args['apply']['collection'] == 'some_collection'



# Generated at 2022-06-21 01:38:28.061552
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    play_context = dict()
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext(play_context)
    display.verbosity = 4

    # for include
    t = TaskInclude.load(dict(action = 'include', file = 'some.yml'))
    t.vars = dict(a='a')
    t.args = dict(b='b', c='c')
    t._parent = True
    t._role = None
    assert t.get_vars() == dict(a = 'a', b = 'b', c = 'c')

    # for include_role
    t = TaskInclude.load(dict(action = 'include_role', file = 'some.yml'))
    t.vars = dict(a='a')

# Generated at 2022-06-21 01:38:39.353309
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = []
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # Test invalid options for include_tasks with raise exception

# Generated at 2022-06-21 01:38:45.725608
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test for incorrectly specified options for include
    def test_load_with_incorrect_option():
        data = {'include': 'tests/test.yaml', 'my_option': None}
        TaskInclude.load(data=data)
    ae = AnsibleParserError if C.INVALID_TASK_ATTRIBUTE_FAILED else None
    assertRaisesExc(ae, 'Invalid options for include: my_option', test_load_with_incorrect_option)

    # Test for correctly specified options for include
    data = {'include': 'tests/test.yaml', 'no_log': True, 'tags': ['my_tag'], 'when': 'True'}
    ti = TaskInclude.load(data=data)

# Generated at 2022-06-21 01:38:49.977576
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert task_include is not None
    assert task_include.action == 'include'
    assert task_include.statically_loaded is False

# Generated at 2022-06-21 01:38:59.853174
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Load the task
    data = dict(
        _raw_params='test.yml',
        apply=dict(
            filename='apply.yml',
            # FIXME - it seems that dataloader is a mandatory parameter here and is
            # causing problems with the RefSpec test
        ),
        other=dict(
            filename=None,
        )
    )
    context = PlayContext()
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 01:39:08.150415
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task, field = TaskInclude.load({'action': 'include', 'file': 'myfile.yml', 'loop': 'var1'}, variable_manager=None, loader=None)
    assert task._attributes['action'] == FieldAttribute(parent_name='TaskInclude', name='action', field_class=str, value='include')
    assert task._attributes['name'] == FieldAttribute(parent_name='TaskInclude',name='name',field_class=str,value=None)
    assert task.args == {'loop':'var1','_raw_params':'myfile.yml'}

# Generated at 2022-06-21 01:39:16.609407
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Test the method load of class TaskInclude.
    """
    def load_fixture(name): return load_fixture_base(TaskInclude, name)

    # "file" is mandatory
    task = load_fixture('file_mandatory')
    assert task.args['_raw_params'] == './included-tasks.yml'

    # "file" is optional
    task = load_fixture('file_optional')
    assert task.args['_raw_params'] == './included-tasks.yml'

    # "file" is "when"
    task = load_fixture('file_when')
    assert task.args['_raw_params'] == 'when'

    # _raw_params are passed
    task = load_fixture('file_raw_params')
    assert task

# Generated at 2022-06-21 01:39:29.428746
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class MockLoader():
        @staticmethod
        def get_basedir(path):
            return "/home/test/ansible"

    class MockPlay():
        def __init__(self, play_context, variable_manager):
            self._play_context = play_context
            self._variable_manager = variable_manager
            self._loader = MockLoader()

        @property
        def loader(self):
            return self._loader

        @property
        def variable_manager(self):
            return self._variable_manager

    class MockParent():
        def __init__(self, variable_manager):
            self.role = "TEST_ROLE"
            self._variable_manager

# Generated at 2022-06-21 01:39:38.788689
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test1
    # Testing with apply tag
    data = dict(
        action='include_tasks',
        file='./goatbox/tasks/test3.yml',
        apply=dict(
            block=dict()
        )
    )
    task = TaskInclude.load(data, variable_manager=None, loader=None)
    assert task._parent.__class__.__name__ == 'Block'
    assert task._parent._block == apply_attrs['block']
    assert task._parent._parent == task
    assert task._parent._role == task._role
    assert task._parent._variable_manager == task._variable_manager
    assert task._parent._loader == task._loader
    assert task._parent._play == task._play
    # test2
    # Testing without any apply tag

# Generated at 2022-06-21 01:39:59.311553
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    # Basic task include
    task = task_include.load(dict(action='include', file='example_include.yaml'))
    assert task.args['file'] == task.args['_raw_params'] == 'example_include.yaml'
    assert '_raw_params' in task.args

    # Task include, with 'apply'
    task = task_include.load(dict(action='include', file='example_include.yaml', apply=dict(collect_facts=True)))
    assert task.args['file'] == 'example_include.yaml'
    assert 'apply' in task.args
    assert task.args['apply']['collect_facts'] is True

    # Bad option
    with pytest.raises(AnsibleParserError):
        task_include.load

# Generated at 2022-06-21 01:40:11.202000
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude

    task_include = TaskInclude()
    task_include._role = RoleInclude()
    task_include._role._play = Play()
    task_include._role._play._play_context = PlayContext()
    task_include.args = {'apply': {'tags': ['mytag'], 'when': 'my when'}}

    assert task_include._parent == None

    task_include.build_parent_block()

    assert task_include._parent == task_include

    task_include = TaskInclude()
    task_include._role = RoleInclude()
    task_include._role._play = Play()
    task_include._role._play

# Generated at 2022-06-21 01:40:13.588733
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude(block=None, role=None, task_include=None)
    assert isinstance(task_include, TaskInclude)


# Generated at 2022-06-21 01:40:22.735179
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # 1. Test for tasks which are not 'include', 'import_tasks', 'include_role'
    # 1.1 Case: exclude_tasks = True
    # 1.2 Case: exclude_tasks = False
    # 1.3 Case: exclude_tasks = False, role is passed
    # 2. Test for tasks which are 'include', 'import_tasks', 'include_role'
    # 2.1 Case: 'include' and 'vars' are not passed, role is not passed
    # 2.2 Case: 'import_tasks' and 'vars' are passed, role is passed
    # 2.3 Case: 'include_role' and 'vars' are passed, role is not passed
    test_vars = {"a1": 1, "a2": 2, "v3": 3}

# Generated at 2022-06-21 01:40:31.294424
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.host import Host

    host = Host(name="example.com")
    play_context = PlayContext(remote_addr="example.com", port=22, become=False)

    # load with implicit include
    data = dict(
        include='/path/to/tasks.yml'
    )
    task = TaskInclude.load(data, block=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(task, TaskInclude)
    assert task.action == 'include'
    assert task.args['_raw_params'] == '/path/to/tasks.yml'
    assert task.apply == dict()
   

# Generated at 2022-06-21 01:40:41.836177
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test of the TaskInclude class when loading the default action
    # The default action is named 'include'
    task_include = TaskInclude(block=None, role=None, task_include=None)
    data = {'action': 'include', 'file': '', 'apply': {}, 'tags': [], 'when': ''}
    task_include.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task_include.args['file'] == ''
    assert task_include.get_vars() == {'file': '', 'tags': [], 'when': ''}

    # Test of the TaskInclude class when loading the action with the name 'include_role'
    # The default action is named 'include_role'
    task_include = TaskIn

# Generated at 2022-06-21 01:40:50.366120
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude(block=None, role=None, task_include=None)

    # Example of configuration using static include
    static_data = {
        'action': 'include_tasks',
        'file': 'roles/foo/tasks/main.yml',
    }
    static_data = ti.preprocess_data(static_data)
    assert static_data == {'action': 'include_tasks',
                           '_raw_params': 'roles/foo/tasks/main.yml'}, "Static include preprocess data failed"

    # Example of configuration using dynamic include
    include_action = 'include'
    dynamic_data = {
        'action': include_action,
        'file': '{{ name_of_file }}',
    }
    dynamic_data = ti.preprocess_data

# Generated at 2022-06-21 01:40:56.041480
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory

    from units.mock.loader import DictDataLoader

    pb = Play.load(dict(
        name = "foobar",
        hosts = "all",
        gather_facts = False,
        roles = ['include_role']
    ), variable_manager=None, loader=DictDataLoader())

    assert len(pb.get_roles()) == 1
    assert pb.get_roles()[0].get_name() == 'include_role'

    r = pb.get_roles()[0]
    assert len(r.get_tasks()) == 1

    t = r.get_tasks()[0]


# Generated at 2022-06-21 01:41:07.222128
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Setup
    d1 = dict(action='include', file='foo.yml')
    d2 = dict(action='include', file='foo.yml', tags=['tag1', 'tag2'])
    d3 = dict(action='include', file='foo.yml', args='bar')
    d4 = dict(action='include', file='foo.yml', apply='apply1')
    d5 = dict(action='include_tasks', file='foo.yml', apply=dict(tags='tags1'))
    d6 = dict(action='include_tasks', file='foo.yml', args='bar')
    d7 = dict(action='include_tasks', file='foo.yml', args='bar', apply='apply1')

# Generated at 2022-06-21 01:41:18.026052
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    block = Block()
    task_include = TaskInclude(block=block)

    # Test with 'include' action
    data = {'action': 'include', 'args': {'file': 'somefile.yml', 'apply': 'some_apply_dict'}}
    task = TaskInclude.load(data=data, block=block, task_include=task_include)
    assert task.action == 'include'
    assert task.args == {'file': 'somefile.yml', '_raw_params': 'somefile.yml', 'apply': 'some_apply_dict'}

    # Test with invalid action
    data = {'action': 'invalid_action', 'args': {'file': 'somefile.yml', 'apply': 'some_apply_dict'}}

# Generated at 2022-06-21 01:41:42.584061
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class MockTask(TaskInclude):
        pass

    my_host = Host(name="my_host")
    my_group = Group(name="my_group")
    my_group.add_host(my_host)
    my_inventory = Inventory(loader=DataLoader(), groups=[my_group])
    my_vars = VariableManager(loader=DataLoader(), inventory=my_inventory)

# Generated at 2022-06-21 01:41:51.343153
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-21 01:42:01.709834
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleParserError

    # Set up the class being tested
    class TaskIncludeSubclass(TaskInclude):
        def __init__(self, action, args):
            super(TaskIncludeSubclass, self).__init__()
            # init block attributes
            self.action = action  # type: str
            self.args = args  # type: dict
            self.__parent = None

    # Set up a mock PlayContext
    pc = PlayContext()
   

# Generated at 2022-06-21 01:42:12.767197
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # get_vars will return vars as per action and args

    # 1. For first case we will have action as 'include' and
    #    and args as {}
    #    so it will return vars as per action and args.
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = {}
    all_vars = ti.get_vars()

    assert all_vars == {}, \
        "Failed: get_vars will return vars as per action and args"

    # 2. For this case we will have action as 'include_tasks' and
    #    and args as {'a': 1, 'b': 2}
    #    so it will return vars as per action and args.
    ti = TaskInclude()
    ti.action = 'include_tasks'

# Generated at 2022-06-21 01:42:15.651776
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    # TaskInclude.__init__() creates 2 variables
    assert hasattr(ti, "_parent")
    assert hasattr(ti, "statically_loaded")

# Generated at 2022-06-21 01:42:23.093972
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test method build_parent_block of class TaskInclude
    '''
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    p = Play.load(dict(
        hosts='all',
        gather_facts='no',
        tasks=[dict(action='shell', args=dict(cmd='whoami'))],
    ), variable_manager=tqm.variable_manager, loader=tqm._loader)
    t = TaskInclude.load(dict(action='include', file='shell', apply=dict(block=dict(var1='v1',var2='v2'))), task_include=None, variable_manager=tqm.variable_manager, loader=tqm._loader)
   

# Generated at 2022-06-21 01:42:26.440008
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Make sure TaskInclude is a subclass of Task
    assert issubclass(TaskInclude, Task)
    # Make sure TaskInclude is an instance of Task
    assert isinstance(TaskInclude(), Task)

# Generated at 2022-06-21 01:42:35.683697
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    t._role = MagicMock()
    t._role.get_default_vars = MagicMock(return_value=dict())
    t._parent = MagicMock()
    t._parent.get_vars = MagicMock(return_value=dict(p=1))
    t.vars = dict(v=1)
    t.args = dict(a=1)

    assert t.get_vars() == dict(p=1, v=1, a=1)

# Generated at 2022-06-21 01:42:46.432024
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()

    data = dict(
        apply=dict(
            block=dict()
        ),
        file='a',
    )

    task = ti.load(data, variable_manager=None, loader=None)
    assert hasattr(task, 'args')
    assert 'file' in task.args
    assert task.args['file'] == 'a'
    assert task.args['_raw_params'] == 'a'
    assert task._parent

    # Test Exception for missing file attribute
    data = dict(
        apply=dict(
            block=dict()
        )
    )
    try:
        task = ti.load(data, variable_manager=None, loader=None)
        assert False
    except AnsibleParserError:
        assert True

# Generated at 2022-06-21 01:42:57.922870
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    
    play_context = PlayContext()
    ti = TaskInclude()
    ti_copy = ti.copy()

    assert(ti_copy.statically_loaded == False)
    assert(ti_copy._parent == None)
    assert(ti_copy.action == None)
    assert(ti_copy.any_errors_fatal == None)
    assert(ti_copy.args == dict())
    assert(ti_copy.become == None)
    assert(ti_copy.become_user == None)
    assert(ti_copy.block == None)
    assert(ti_copy.changed_when == None)
    assert(ti_copy.connection == None)
    assert(ti_copy.delegate_to == None)

# Generated at 2022-06-21 01:43:36.532576
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Testing construction of TaskInclude
    block = Block()
    task = TaskInclude(block=block)
    assert task.block is block
    assert task.get_name() is None
    task._role = 'role'
    assert task.get_name() is None
    task_include = TaskInclude()
    task = TaskInclude(task_include=task_include)
    assert task.get_name() is None
    assert task.action is None
    task_include.action = 'action'
    task = TaskInclude(task_include=task_include)
    assert task.get_name() is None
    assert task.action == 'action'
    task._role = 'role'
    assert task.get_name() == 'role'


# Generated at 2022-06-21 01:43:41.166275
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ansible_dict = {
        'include': {
            'file': 'test_file',
        }
    }
    TaskInclude.load(data=ansible_dict)

# Generated at 2022-06-21 01:43:50.297419
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import sys
    import os
    import io
    import tempfile

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class Options(object):
        """Simple object to hold options for test_module utility"""

        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 1
            self.become = None
            self.become_method = None
            self.become

# Generated at 2022-06-21 01:43:50.840838
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-21 01:43:55.988960
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_without_apply = TaskInclude()
    assert task_include_without_apply is task_include_without_apply.build_parent_block()

    apply_attrs = {'remote_user': 'root'}
    task_include_with_apply = TaskInclude(args={'apply': apply_attrs})
    assert isinstance(task_include_with_apply.build_parent_block(), Block)
    assert task_include_with_apply.args == {}

# Generated at 2022-06-21 01:44:05.019828
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # test: when - import_role
    data = dict(
        action='import_role',
        name='role_name',
        args=dict(
            file='role_file',
            apply=dict(
                block=[]
            )
        )
    )
    TaskInclude.load(data)

    # test: when - import_role, but file is not specified
    data = dict(
        action='import_role',
        name='role_name',
        args=dict(
            apply=dict(
                block=[]
            )
        )
    )
    try:
        TaskInclude.load(data)
    except AnsibleParserError:
        pass

    # test: when - include, but file is not specified

# Generated at 2022-06-21 01:44:16.141200
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'item': 'foo'}

    yaml_str = '''
    - include: insert_a.yml
      tags: [ bar ]
    - import_tasks: insert_b.yml
      when: false
      loop: "{{ list }}"
      loop_control:
          label: "{{ item }}"
    - import_role: insert_c.yml
      apply:
          block: [ asdf, fdsa ]
    '''
    data = yaml.safe_load(yaml_str)

# Generated at 2022-06-21 01:44:28.039118
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    my_play = Play().load({
        'name': 'test',
        'hosts': 'dummy',
        'gather_facts': 'no',
        'tasks': [
            {
                'name': 'test_task',
                'include_tasks': 'tasks/test_task.yml',
                'apply': {
                    'name': 'test_block',
                    'block': []
                }
            }
        ]
    }, variable_manager=None, loader=None)

    my_play.post_validate()
    my_play.compile()

    test_task = my_play.get_blocks()[0].block[0]

    # Test with apply
    my_play.get

# Generated at 2022-06-21 01:44:38.885532
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # creating a dummy TaskInclude
    ti = TaskInclude()

    # args dictionary of the task include to be passed to TaskInclude's constructor
    args_dict = dict()
    # adding arguments to args_dict 
    args_dict["name"] = list()
    args_dict["action"] = ["raw"]
    args_dict["run_once"] = [True]
    args_dict["ignore_errors"] = [True]
    args_dict["args"] = dict()
    args_dict["args"]["_raw_params"] = ["echo \"hi\""]

    Task.__init__(ti,**args_dict)

    # calling get_vars of Task class
    vars_dict = ti.get_vars()

    # comparing the result of get_vars