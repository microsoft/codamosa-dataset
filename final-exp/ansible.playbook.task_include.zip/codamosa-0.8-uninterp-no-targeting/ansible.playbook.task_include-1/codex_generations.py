

# Generated at 2022-06-21 01:34:53.637002
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DictDataLoader({
        "test": """
        - include_tasks:
            file: task.yml
            apply:
                block:
                    - command: echo world
        """,
        "task.yml": """
        - name: Hello world
          command: echo hello
        """,
    })

    play_source =  """
    - hosts: all
      tasks:
        - include_tasks: test
    """

    play = Play.load(play_source, variable_manager=None, loader=loader, use_deprecated_parser=True)

# Generated at 2022-06-21 01:35:03.402894
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # pylint: disable=protected-access
    data = dict(action='include', file='foo.yml')
    task = TaskInclude.load(data, loader=None)
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'foo.yml'
    assert task._parent is None
    data['ignore_errors'] = True
    data['tags'] = ['bar']
    data['when'] = 'baz'
    task = TaskInclude.load(data, loader=None)
    assert task.args.get('ignore_errors') is True
    assert task.args.get('tags') == ['bar']
    assert task.args.get('when') == 'baz'

# Generated at 2022-06-21 01:35:14.766331
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # we need to create a fake play context, otherwise parents and children don't work
    display.verbosity = 3
    fake_loader = DictDataLoader({})
    context = PlayContext()
    context._vars = {}
    context._hostvars = {}

    task_include = TaskInclude()
    task_include._variable_manager = VariableManager(loader=fake_loader, inventory=None)
    task_include._loader = fake_loader


# Generated at 2022-06-21 01:35:26.888665
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # For example, action 'include', 'include_tasks', 'include_role' and 'import_tasks' are
    # proper tasks. Therefore, TaskInclude.load() fails when we give invalid option or parameter
    # to them. To check this, we use the same `data` and pass different value to 'action' field
    # of `data` dict.
    #
    # This test will fail when TaskInclude.load() is changed
    for action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS:
        data = {
            'action': action,
            'file': '',
        }

        # non-allowed options are not allowed
        data['host'] = 'my-host'
        ti = TaskInclude()

# Generated at 2022-06-21 01:35:38.528063
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-21 01:35:47.939150
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti_copy = ti.copy()
    assert ti is not ti_copy
    assert ti.__class__ is ti_copy.__class__
    assert ti.args == ti_copy.args
    assert ti.action == ti_copy.action
    assert ti.notify == ti_copy.notify
    assert ti.loop == ti_copy.loop
    assert ti.items == ti_copy.items
    assert ti.when == ti_copy.when
    assert ti.first_available_file == ti_copy.first_available_file
    assert ti.changed_when == ti_copy.changed_when
    assert ti.failed_when == ti_copy.failed_when
    assert ti.always_run == ti_copy.always_run
    assert ti.poll == ti_copy.poll

# Generated at 2022-06-21 01:35:54.489155
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    play1 = dict(
        name = "play",
        hosts = 'all',
        gather_facts = 'no',
        tasks=[
            dict(name='t1', action=dict(module='shell', args='ls')),
            dict(name='t2', action=dict(module='shell', args='ls')),
        ]
    )

    myblock = Block()
    myblock.load(play1, variable_manager=None, loader=None)

    ti = TaskInclude()
    ti.statically_loaded = True

# Generated at 2022-06-21 01:36:03.890810
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    play_book    = Play()
    role         = Role()
    block        = Block(play=play_book)

    task = TaskInclude(block=block, role=role, task_include=None)
    task.statically_loaded = True

    task_copy = task.copy(exclude_parent=False, exclude_tasks=False)

    assert task_copy.statically_loaded == True

    task_copy = task.copy(exclude_parent=False, exclude_tasks=True)

    assert task_copy.statically_loaded == True

# Generated at 2022-06-21 01:36:11.157259
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Load playbook
    DATA = """
    - import_playbook: test-import.yml
    """
    pb = ansible.playbook.PlayBook.load(DATA, variable_manager=variable_manager, loader=loader)
    play = pb.get_plays()[0]

    # Load task
    DATA = """
    - import_tasks:
        file: test-import.yml
        apply:
          block:
            - import_tasks: test2.yml
    """

    task = Task.load(DATA, play=play, variable_manager=variable_manager, loader=loader)
    # Check if parent block is correct for the first "include"

    parent = task.build_parent_block()

    assert isinstance(parent, Block) is True
    assert isinstance(parent._parent, Task)

# Generated at 2022-06-21 01:36:23.861226
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    This method tests the preprocess_data method of the TaskInclude class.
    Since TaskInclude class is derived from the Task class, it's important to test
    if the TaskInclude class' preprocess_data method calls the Task class'
    preprocess_data method as well. Otherwise, the TaskInclude class might
    silently ignore some tests.
    '''

    ti = TaskInclude()
    ti2 = TaskInclude()

    # This is to differentiate the test results to avoid unexpected exceptions
    ti2_preprocess_data_method_called = False

    # This is a mock method for re-creating the Task.preprocess_data() method
    def mock_preprocess_data(self, ds):
        nonlocal ti2_preprocess_data_method_called

        ti2_preprocess_data_method_called

# Generated at 2022-06-21 01:36:38.034962
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Variable assignment
    class test_block:
        def __init__(self):
            self.vars = {'a': 1}
            self.get_vars = lambda: {'b': 2}

    class test_task_include(TaskInclude):
        def __init__(self, action='include'):
            self.args = {'c': 3}
            self._role = None
            self.action = action
            self._parent = test_block()

    # Test for action 'include'
    assert test_task_include().get_vars() == {'b': 2, 'c': 3}

    # Test for action 'import_role'
    assert test_task_include('import_role').get_vars() == {'a': 1, 'b': 2}

# Generated at 2022-06-21 01:36:47.236388
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t = TaskInclude()

    test_data = {
        'action': 'include_role',
        'ignore_errors': True
    }
    # Differenct set
    assert t.preprocess_data(test_data) == test_data

    test_data = {
        'action': 'include_role',
        'ignore_errors': True,
        'tags': ['role1']
    }
    # Differenct set
    assert t.preprocess_data(test_data) == test_data

    test_data = {
        'action': 'include_role',
        'ignore_errors': True,
        'meta': 'data'
    }

    # Differenct set
    result = {
        'action': 'include_role',
        'ignore_errors': True
    }

    assert t.pre

# Generated at 2022-06-21 01:36:58.641304
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode

    include_str = '''
---
- include: other_play.yml
  when: foo is defined
'''
    data = include_str
    loader = C.get_config(None, C.DEFAULT_LOADER_NAME, paths=[])
    variable_manager = VariableManager()

    role = Role().load(data, loader=loader)
    task = role._include_tasks[0].copy()


# Generated at 2022-06-21 01:37:04.130845
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    data = {'include': '/home/foo/bar.yml'}
    task = ti.load(data)
    assert task.action == 'include'
    assert task.args['_raw_params'] == '/home/foo/bar.yml'
    # note: task.args.get('file') would return None



# Generated at 2022-06-21 01:37:15.746046
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    def test_get_vars_statically_loaded(param_file=None):
        params = {'action': 'include', 'file': param_file}
        task = TaskInclude.load(
            params,
            block=None,
            role=None,
            task_include=None,
        )

        task.statically_loaded = True
        task.args['tags'] = ['include']
        task._parent = object()

        expected_vars = {
            'tags': ['include']
        }
        assert task.get_vars() == expected_vars

    def test_get_vars_dynamically_loaded(param_file=None):
        t = Block()
        t.vars = {
            'x': 'dynamic_loaded'
        }
        t._parent = None
        params

# Generated at 2022-06-21 01:37:25.697742
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    #No 'include'
    no_include = TaskInclude()
    no_include.args = {'name': 'test'}
    no_include.vars = {'name': 'toto'}
    parent_vars = {'name': 'tata'}

    assert no_include.get_vars() == {'name': 'toto'}
    no_include._parent = Mock()
    no_include._parent.get_vars = Mock(side_effect = lambda : parent_vars)
    assert no_include.get_vars() == {'name': 'toto', 'name': 'tata'}

    #'include'
    include = TaskInclude()
    include.action = 'include_role'
    include.args = {'name': 'test'}

# Generated at 2022-06-21 01:37:37.274158
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-21 01:37:39.782333
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude(block=None, role=None, task_include=None)



# Generated at 2022-06-21 01:37:47.270555
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play

    play_source = {}
    play_ds = {}
    play_source['name'] = 'foo'
    play_source['hosts'] = 'bar'
    play_source['gather_facts'] = 'no'
    play_source['tasks'] = [
        {'block': [
            {'include': 'role1'},
            {'include': 'role2'},
        ]}
    ]

    play = Play.load(play_source, play_ds, variable_manager=None, loader=None)
    assert play.tasks[0].block[0].action in C._ACTION_INCLUDE_ROLE_TASKS



# Generated at 2022-06-21 01:37:59.679119
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    task_ok = {'action': 'include', 'args': {'file': 'file1.yaml'}}
    task_ok_all = {'action': 'include_tasks', 'args': {'file': 'file1.yaml'}}

    task_missing_file_include = {'action': 'include', 'args': {}}
    task_missing_file_all = {'action': 'include_tasks', 'args': {}}

    task_bad_opt = {'action': 'include', 'args': {'file': 'file1.yaml', 'bad_opt': 'bad'}}
    task_bad_opt_all = {'action': 'include_tasks', 'args': {'file': 'file1.yaml', 'bad_opt': 'bad'}}



# Generated at 2022-06-21 01:38:13.575608
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    my_play_ds = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts='no'
    )
    play = Play().load(my_play_ds, variable_manager=variable_manager)


# Generated at 2022-06-21 01:38:22.585826
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test task which has the default attributes, here ``block`` is None
    task = TaskInclude.load(
        data={
            'action': 'include_role',
            'args': {
                'apply': {}
            }
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert task.action == 'include_role'
    assert task.args['apply'] == {}

    raised = False
    try:
        p_block = task.build_parent_block()
    except Exception:
        raised = True

    # p_block should be a Block object
    assert isinstance(p_block, Block)
    assert not raised

    # Test task which has an argument ``apply`` and ``block`` is empty
    task

# Generated at 2022-06-21 01:38:25.237094
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
  ti1 = TaskInclude()
  ti1.statically_loaded = True
  ti2 = ti1.copy()
  assert(ti1.statically_loaded == ti2.statically_loaded)

# Generated at 2022-06-21 01:38:34.317352
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    ds = dict(
        name = 'Test Task Include',
        connection = 'local',
        hosts = 'localhost',
        gather_facts = 'no',
        tasks=[dict(
            include='test1',
            version=2.0,
            imports='test1'
        )]
    )
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'], vault_password='pass')

# Generated at 2022-06-21 01:38:36.650455
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded == True

# Generated at 2022-06-21 01:38:43.969483
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    yaml_data = """
    - hosts: all
      tasks:
       - include: test.yml
    """

    inventory = Inventory(host_list=[])
    play = Play.load(yaml_data, variable_manager=None, loader=None)
    all_hosts = inventory.get_hosts()
    play = play.serialize()
    ti = TaskInclude.load(play.get_blocks()[0].block[0], block=play.get_blocks()[0], task_include=None)
    assert ti is not None
    assert ti.args['file'] == 'test.yml'

# Generated at 2022-06-21 01:38:57.174911
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    result = {
        'when': 'ansible_distribution != "Debian"',
        'tags': ['example_tag'],
        'block': [
            {
                'block': [],
                'name': 'debug',
                'action': 'debug',
                'args': {
                    'msg': 'I am executed in a block'
                }
            },
            {
                'name': 'debug',
                'action': 'debug',
                'args': {
                    'msg': 'I am executed in a block too'
                }
            }
        ]
    }
    task_include = TaskInclude.load(result, variable_manager=None, loader=None)
    p_block = task_include.build_parent_block()
    assert p_block == task_include.block[0]

# Generated at 2022-06-21 01:39:10.130934
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    class FakeVariableManager(VariableManager):
        def __init__(self):
            pass

    class FakeTaskQueueManager(TaskQueueManager):
        def __init__(self):
            pass

    class FakeOptions():
        def __init__(self):
            pass

    options = FakeOptions()
    loader = DataLoader()
    variable_manager = FakeVariableManager()
    task_queue_manager = FakeTaskQueueManager()

    block = Block()

    dictionary = {'include': 'some_file'}

# Generated at 2022-06-21 01:39:17.347015
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    my_block = Block()
    my_block.vars = {
        'strvar' : 'str value',
        'numvar' : 42,
        'boolvar' : True,
        'nestedvar' : { 'subvar' : 'sub value' },
        'listvar' : [1, 2],
    }

    # unit test for issue https://github.com/ansible/ansible/issues/18671

# Generated at 2022-06-21 01:39:29.704796
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.plugins
    ti = TaskInclude()

    # For now, ti won't have ansible.plugins.include_role in its action
    # attribute, so use 'include_role' to simulate the case
    action_include_role = 'include_role'
    ti.action = action_include_role
    ds = dict(action=action_include_role)

    # Should not raise an error
    ti.preprocess_data(ds)

    # For now, ti won't have ansible.plugins.import_role in its action
    # attribute, so use 'import_role' to simulate the case
    action_import_role = 'import_role'
    ti.action = action_import_role
    ds = dict(action=action_import_role)

    # Should not raise an error
    ti.preprocess

# Generated at 2022-06-21 01:39:49.370735
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    def test_task_include_load(args, expected_msg, expected_exc=AnsibleParserError, expected_err_msg=None):
        display.verbosity = 3

        try:
            TaskInclude().load(args)
        except expected_exc as e:
            if expected_err_msg:
                assert(expected_err_msg in str(e))
            assert(expected_msg in str(e))
        else:
            raise AssertionError('Expected %s to be raised' % expected_exc)

    # Arguments for test_task_include_load, see docstring
    args = dict(
        action = 'include',
        file = 'foo.yml',
        apply = dict(block=[]),
        _raw_params = 'bar.yml',
    )

    # Test 1
    test

# Generated at 2022-06-21 01:40:00.356446
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.plays import Play
    from ansible.playbook.block import Block
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.playbook.play_context import PlayContext

    # required for the method __deepcopy__ to work
    add_all_plugin_dirs()

    # First Test: Test if the parent Block is returned
    p = Play().load({}, variable_manager=None, loader=None)
    task_include = TaskInclude()
    task_include._parent = p
    p_block = task_include.build_parent_block()
    assert p_block == task_include

    # Second Test: Test if the parent Block has apply attributes

# Generated at 2022-06-21 01:40:11.831358
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    ti_args = dict(file='foo')
    task = dict(action='include', args=ti_args)

    task_result = ti.check_options(task, task)
    assert task_result == {'action': 'include', 'args': {'file': 'foo', '_raw_params': 'foo'}}

    ti_args = dict(file='foo', apply={'some_attr': 'some_val'})
    task = dict(action='include', args=ti_args)

    task_result = ti.check_options(task, task)
    assert task_result == {'action': 'include', 'args': {'file': 'foo', 'apply': {'some_attr': 'some_val'}, '_raw_params': 'foo'}}


# Generated at 2022-06-21 01:40:21.165529
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars import VariableManager

    mock_loader = DictDataLoader({})
    mock_vvars = dict(
        foo='foo',
        bar='bar',
        bam=dict(
            name='bam'
        ),
    )
    variable_manager = VariableManager()
    variable_manager._extra_vars = mock_vvars

    block = Block()
    block.vars = dict(
        foo=dict(
            name='foo'
        ),
    )

    # test for valid action

# Generated at 2022-06-21 01:40:30.120068
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.task import Task

    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.statically_loaded = True

    # Create a copy of the TaskInclude instance (task_include) and
    # compare the original and the copy
    task_include_copy = task_include.copy()

    assert task_include.action == task_include_copy.action
    assert task_include.statically_loaded == task_include_copy.statically_loaded

    # Create a copy of the TaskInclude instance (task_include) and
    # compare the original and the copy
    task = Task()
    task.action = 'include_role'
    task.statically_loaded = True


# Generated at 2022-06-21 01:40:41.472301
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Test the default constuctor of class TaskInclude
    d = dict()
    task_include = TaskInclude(block='block', role='role', task_include='task_include')
    task_include.load(d)

    # Test the first and second parameter of the constructor are required
    try:
        task_include = TaskInclude()
    except Exception as e:
        assert type(e) is TypeError

    try:
        task_include = TaskInclude('block')
    except Exception as e:
        assert type(e) is TypeError

    try:
        task_include = TaskInclude('block', 'role')
    except Exception as e:
        assert type(e) is TypeError

    # Test whether the returned value is right
    assert task_include.__dict__['_parent'] == 'block'

# Generated at 2022-06-21 01:40:44.228938
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    print("TaskInclude: constructor")
    t = TaskInclude()
    assert t._parent is None
    assert t._role is None
    assert t._block is None


# Generated at 2022-06-21 01:40:49.798092
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Unit test for method TaskInclude.load
    Test the task include for the invalid option
    :return:
    """
    try:
        TaskInclude.load({
            'include': 'playbooks/tasks/other_task.yaml',
            'some_random_key': 'some_random_value',
        })
    except AnsibleParserError as e:
        assert "Invalid options for include" in str(e)
        assert "'some_random_key' is an invalid option" in str(e)



# Generated at 2022-06-21 01:41:00.039136
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()

    mock_inventory = InventoryManager(loader=loader, sources='')

    context = PlayContext()

    variable_manager = VariableManager()
    variable_manager.set_inventory(mock_inventory)


# Generated at 2022-06-21 01:41:04.407782
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method tests TaskInclude.build_parent_block()
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    play = Play()
    role = Role()

    task_include = TaskInclude(play=play, role=role)
    task_include.args = dict()
    block = task_include.build_parent_block()
    assert task_include == block

    task_include.args = dict(apply=dict(block=[]))
    block = task_include.build_parent_block()
    assert type(block) is Block
    assert block._parent == task_include._parent
    assert block._role == task_include._role
    assert block._play == task_include._play



# Generated at 2022-06-21 01:41:17.157800
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    assert TaskInclude()

# Generated at 2022-06-21 01:41:26.986127
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti.action = 'include'
    ti.static = False

    # Test 1: If a non-include task is provided, the method should return the same data.
    #         This test also checks that 'include' action is handled correctly.
    ds = {
        'action': 'foobar',  # Not a valid include action
        'var1': 'val1',
        'var2': 'val2',
    }

    expected_result = {
        'action': 'foobar',
        'var1': 'val1',
        'var2': 'val2',
    }
    result = ti.preprocess_data(ds)

    assert result == expected_result

    # Test 2: If a list of valid include keywords are provided,

# Generated at 2022-06-21 01:41:38.696559
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    block = Block()
    ti = TaskInclude(block)
    # Incorrect parameters when action is 'include_tasks'
    # Missing 'file' parameter
    data = dict(action='include_tasks', ignore_errors=True)
    with pytest.raises(AnsibleParserError) as exc:
        ti.check_options(ti.load_data(data), data)
    assert exc.value.message == "No file specified for include_tasks"
    # Invalid parameter
    data = dict(action='include_tasks', file='/tmp/my_include.yml', invalid_param=True)
    with pytest.raises(AnsibleParserError) as exc:
        ti.check_options(ti.load_data(data), data)

# Generated at 2022-06-21 01:41:44.480565
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude({
        'action': 'include',
        'name': 'test',
        'tags': ['test'],
        'when': 'True',
        'apply': {},
    })
    assert task_include.get_vars() == {
        'action': 'include',
        'name': 'test',
        'tags': ['test'],
        'when': 'True',
        'apply': {},
    }
    assert task_include.get_vars() is not None


# Generated at 2022-06-21 01:41:52.906503
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.handler import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    hti = HandlerTaskInclude(block=None, role=None, task_include=None)

    valid_task = Task()
    valid_task.action = 'include'
    valid_task.annotation = 'test'
    valid_task.args = {'_raw_params': 'test_action.yml'}
    valid_ti = TaskInclude(block=None, role=None, task_include=None)
    # Test valid options

# Generated at 2022-06-21 01:42:02.387176
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.vars import combine_vars

    class AnsibleOptions:
        connection='local'
        module_path=C.DEFAULT_MODULE_PATH
        forks=100
        become=None
        become_method='sudo'
        become_user='root'
        check=False
        diff=False
        listhosts=None
        listtasks=None
        listtags=None
        syntax=None


# Generated at 2022-06-21 01:42:12.253615
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Test the method copy

    :setup: None
    :steps:
        1. Create a TaskInclude instance
        2. Store a copy of this instance
        3. Create a new instance with the copy
        4. Check that the original instance and the new one are equals
    :expectedresults:
        1. TaskInclude instance is created successfully
        2. TaskInclude instance is copied
        3. New TaskInclude instance is created with the copy
        4. The two instances are equals
    '''
    taskinclude = TaskInclude()
    copy = taskinclude.copy()
    new_taskinclude = TaskInclude(None, None, copy)
    assert taskinclude == new_taskinclude

# Generated at 2022-06-21 01:42:21.442193
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude.load(
        dict(
            apply=dict(
                block_on_error=True,
                name="test",
            ),
            file="/path/to/include.yml"
        )
    )
    vars = task.get_vars()
    assert vars == dict(block_on_error=True, file="/path/to/include.yml")

    task = TaskInclude.load(
        dict(
            file='/path/to/include.yml',
            block_on_error=True,
        )
    )
    vars = task.get_vars()
    assert vars == dict(block_on_error=True, file="/path/to/include.yml")

    # task_include of task

# Generated at 2022-06-21 01:42:27.651457
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    results = []
    task_include = TaskInclude()
    task_include.args['apply'] = {'block': []}
    results.append(isinstance(task_include.build_parent_block(), Block))
    task_include.args['apply'] = {'block': []}
    results.append(task_include.build_parent_block() is task_include)
    return all(results)

# Generated at 2022-06-21 01:42:38.856688
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class TaskIncludeMock(TaskInclude):
        # To be able to mock method load_data
        def load_data(self, data, variable_manager=None, loader=None):
            return super(TaskIncludeMock, self).load_data(data, variable_manager, loader)

    class BlockMock(object):
        def __init__(self):
            self._play = None
            self._role = None

    # Test load method
    class BlockMock(object):
        def __init__(self):
            self._play = None
            self._role = None

    # Test load method
    class PlayContextMock(PlayContext):
        variable_manager = VariableManager()

    variable_manager

# Generated at 2022-06-21 01:42:57.222575
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible_collections.testns.testcoll.plugins.module_utils._text import to_text

    # This is the data structure (ds) we will be testing

# Generated at 2022-06-21 01:43:09.606197
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    # set some properties
    task_include._parent = 'parent'
    task_include.loop = 'my_loop'
    task_include.statically_loaded = True
    # copy task_include
    new_mi = task_include.copy()

    # assert nothing has changed
    assert id(task_include) != id(new_mi), 'TaskInclude.copy() should not return the same object'
    assert task_include._parent == new_mi._parent, 'TaskInclude.copy() should not change the attribute parent'
    assert task_include.loop == new_mi.loop, 'TaskInclude.copy() should not change the attribute loop'

# Generated at 2022-06-21 01:43:12.620103
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    result = task_include.load({
        'include_tasks': 'hello_world.yaml',
        'apply': { 'arg1': 1, 'arg2': 2 }
    })
    assert isinstance(result, TaskInclude)
    assert result.action == 'include_tasks'
    assert result.args['_raw_params'] == 'hello_world.yaml'
    assert result.args['apply'] == { 'arg1': 1, 'arg2': 2 }
    assert result.args['tags'] == []
    assert result.args['when'] == True



# Generated at 2022-06-21 01:43:20.242330
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # No 'file' option
    data = dict(action='include_tasks')
    task = TaskInclude.load(data)
    assert '_raw_params' in task.args
    assert 'file' not in task.args

    # No 'file' option with 'apply' option
    data = dict(action='include_tasks', apply=dict(ignore_errors=True))
    task = TaskInclude.load(data)
    assert '_raw_params' in task.args
    assert 'file' not in task.args
    assert 'apply' in task.args

    # 'file' option with 'apply' option
    data = dict(action='include_tasks', file='some_file', apply=dict(ignore_errors=True))
    task = TaskInclude.load(data)

# Generated at 2022-06-21 01:43:30.388780
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_instance
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude

    play_ds = dict(name="Test Play #1")
    play_inst = Play.load(play_ds, variable_manager=None, loader=None)
    # play holds a reference to play_inst so pass this test
    assert play_inst == play_inst.load(play_ds, variable_manager=None, loader=None)._play

    # create a test play instance
    test_play = Play_instance()
    test_play.name = 'test play'
    test_play.connection = 'local'

    # create a test block instance
    test_block = Block()

# Generated at 2022-06-21 01:43:39.693941
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    # when no parent
    assert {} == task_include.get_vars()

    # when parent and not in C._ACTION_INCLUDE
    class Task:
        def __init__(self):
            self.vars = {'vars': 'vars'}
        def get_vars(self):
            return self.vars
    parent_task = Task()
    task_include._parent = parent_task

# Generated at 2022-06-21 01:43:46.991661
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    new_task = TaskInclude()
    new_task.action = 'include_role'
    data = {'include_role': {'name': 'webservers', 'x': 'y'}}
    assert 'x' not in new_task.preprocess_data(data['include_role'])
    new_task.action = 'include'
    assert 'x' in new_task.preprocess_data(data['include_role'])

# Generated at 2022-06-21 01:43:57.417844
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    data = dict(
        name='test',
        include='testfile.yml'
    )
    variable_manager = VariableManager()
    loader = DataLoader()
    context = PlayContext()
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert isinstance(task, TaskInclude)
    assert task.args['_raw_params'] == 'testfile.yml'
    assert task.action == 'include'
    assert task.name == 'test'
    # pretty sure this won't ever happen in normal usage


# Generated at 2022-06-21 01:44:07.186448
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # pylint: disable=protected-access
    data = dict(
        action='include',
        file='/some/path/to/file'
    )
    loader = None
    variable_manager = None
    task = TaskInclude.load(data, loader=loader, variable_manager=variable_manager)
    assert sorted(task.args.keys()) == ['action', 'file']
    assert task.args.get('apply') is None

    task.args['apply'] = {}
    task.check_options(task, data)  # shouldn't raise an exception
    task.args['apply'] = dict(foo='bar')
    task.check_options(task, data)  # shouldn't raise an exception
    task.args['apply'] = 'foo'
    with pytest.raises(AnsibleParserError):
        task

# Generated at 2022-06-21 01:44:16.794263
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager

    yaml_data = {
        'hosts': 'all',
        'tasks': [
            {'name': "task1"},
            {'name': "task2"},
            {'include': "task3", 'apply': {'block': []}},
        ],
    }

    p = Play().load(yaml_data, variable_manager=VariableManager(), loader=None)

# Generated at 2022-06-21 01:44:29.756641
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    test_data = dict(include="testfile.yml", tags=["test-tag"])
    ti = TaskInclude()
    ti.load(test_data)

    assert ti.vars == {}
    assert ti.block is None
    assert ti.role is None
    assert ti.task_include is None
    assert isinstance(ti.args, dict)
    assert isinstance(ti.args['tags'], FieldAttribute)
    assert isinstance(ti.args['include'], FieldAttribute)
    assert ti.args['tags'].name == "tags"
    assert ti.args['include'].name == "include"
    assert ti.args['tags'].private
    assert ti.args['include'].private
    assert ti.args['tags'].value == test_data['tags']

# Generated at 2022-06-21 01:44:34.124816
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import unittest

    class TestTaskIncludeload(unittest.TestCase):
        def test_basic(self):
            import yaml

            yml = """
            - name: task name
              include:
                file: test.yml
            """
            ds = yaml.safe_load(yml)
            ti = TaskInclude()
            task = ti.load(data=ds)
            self.assertEqual(task.action, 'include')

# Generated at 2022-06-21 01:44:45.572203
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict()
    data['actions'] = dict()
    data['actions']['action_1'] = dict()
    data['actions']['action_1']['action'] = "include_role"
    data['actions']['action_1']['name'] = "role"
    data['actions']['action_1']['file'] = "file"
    data['actions']['action_1']['unknown_key'] = "unknown_key"

    ti = TaskInclude()
    data_processed = ti.preprocess_data(data)
    assert 'unknown_key' not in data_processed['actions']['action_1']