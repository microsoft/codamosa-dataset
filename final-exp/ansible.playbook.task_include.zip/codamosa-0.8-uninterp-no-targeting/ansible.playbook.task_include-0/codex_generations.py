

# Generated at 2022-06-21 01:34:50.953305
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    role = 'r1'
    task_include = 'ti'
    ti = TaskInclude(block, role, task_include)
    ti.copy()
    ti.copy(True)
    ti.copy(exclude_tasks=True)

# Generated at 2022-06-21 01:35:02.630563
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    my_play = Play()
    my_play._loader = "setup"
    my_play._hosts = "all"
    my_play._inventory = InventoryManager("localhost,", "setup")
    my_play._variable_manager = VariableManager("setup", "localhost")
    my_play._play_context = PlayIterator("setup", my_play)._play_context

    # set variables for the test
    my_play._variable_manager.set_nonpersistent_facts(dict(a="valueA", b="valueB", c="valueC", d="valueD"))


# Generated at 2022-06-21 01:35:14.354986
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # I will use a Block object as self._parent
    # in order to make the test easier
    # In addition, to create a Block object we need to create a Host object and a Play object, too
    my_host = 'localhost'
    my_play = Play()
    my_play.hosts = [my_host]
    my_play.post_validate()
    my_block = Block(play=my_play, task_include=None, role=None, create_block=True, role_block=False)

    my_apply_attrs = {'block': [], 'tags': ['apply1'], 'when': 'apply2', 'vars': {'apply3': 'apply4'}}
    my_vars = {'hello': 'world'}
    my_args = {'a': 'b'}
   

# Generated at 2022-06-21 01:35:25.156595
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """Make sure that the right errors are raised on invalid input"""
    def assert_error(data, error):
        task_include = TaskInclude(None)
        data = dict((k, None) if v == Sentinel else (k, v) for k, v in data.items())
        try:
            task_include.preprocess_data(data)
            assert False, "AnsibleParserError was not raised"
        except AnsibleParserError as e:
            assert error == str(e)

    # Using include_tasks
    assert_error({'action': 'include_tasks'}, "'file' is not a valid attribute for a TaskInclude")
    assert_error({'action': 'include_tasks', 'file': 'file.yml', 'debug': None}, "'debug' is not a valid attribute for a TaskInclude")



# Generated at 2022-06-21 01:35:25.944422
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-21 01:35:33.313430
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    t = Task()
    t._play = PlayContext()
    t.apply = {'a': 1}
    t.args = {'file': '1.yml'}
    t.action = 'include_role'

    assert t.args.get('file') == '1.yml'
    assert t.apply == {'a': 1}

    TaskInclude.check_options(t, None)

    assert t.args.get('_raw_params') == '1.yml'
    assert t.args.get('apply') == {'a': 1}

    t.apply = None

# Generated at 2022-06-21 01:35:42.002140
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    Block.load({'name': 'test_task_include',
                'hosts': 'all',
                'tasks': [{'include': {'file': 'some_include.yml',
                                       'apply': {'foo': 'bar'}}}]},
                                       #'run_once': 'yes'}]},
                                       #'task_include': 'yes'}]},
                                       #'tags': ['test_tag'],
                                       #'when': 'ansible_distribution == "Ubuntu"'},
                                       #'vars': {'test_var': 'test_value1'}}]}
               )

# Generated at 2022-06-21 01:35:51.370065
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
   valid_data = dict(action='include', args=dict(file='file'))
   ti = TaskInclude()
   ti.preprocess_data(valid_data)

   inv_data = dict(action='include', args=dict(file='file'), invalid_attr=dict())
   if C.INVALID_TASK_ATTRIBUTE_FAILED:
      with pytest.raises(AnsibleParserError):
         ti.preprocess_data(inv_data)
   else:
      ti.preprocess_data(inv_data)

# Generated at 2022-06-21 01:36:01.048866
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_block import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role_block import RoleBlock
    from ansible.playbook import role

    # - include: test_role/test_task_include.yml
    #   apply: {}
    data = {
        'apply': {},
        'file': 'test_role/test_task_include.yml'
    }

    p = Play()
    p._role = role.Role()
    ri = IncludeRole()
    rb = RoleBlock()
    ti = TaskInclude.load(data, role=ri, block=rb, task_include=ri)

    assert isinstance(ti, TaskInclude)
    assert hasattr(ti, 'args')

# Generated at 2022-06-21 01:36:14.298252
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()


# Generated at 2022-06-21 01:36:25.193277
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti_action = ti.action
    ti.action = 'include'

    t = Task()
    t_vars = t.get_vars()

    assert isinstance(ti_action, str)
    assert 'include' == ti.action
    assert isinstance(t, Task)
    assert isinstance(t_vars, dict)
    assert isinstance(ti.get_vars(), dict)
    assert len(ti.get_vars()) > 0
    assert 'include' == ti.action
    assert ti.action in C._ACTION_INCLUDE
    assert ti.get_vars() == ti.get_vars()

# Generated at 2022-06-21 01:36:37.069139
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play


# Generated at 2022-06-21 01:36:46.822738
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    def assert_build_parent_block(ds, exp_block):
        # Mock objects
        class MockBlock:
            def __init__(self):
                self.loop = 'item'
            def get_vars(self):
                return {'item':'foo'}
            def name(self):
                return 'block'
        class MockRole:
            def __init__(self):
                self._role_name = 'mockrole'
        class MockTask:
            def __init__(self):
                self._role = MockRole()
                self._play = 'play'
                self._variable_manager = 'vm'
                self._loader = 'loader'
                self._parent = MockBlock()

# Generated at 2022-06-21 01:36:57.823201
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    options = {'connection': 'local', 'module_path': '', 'forks': 1, 'become': False,
               'become_method': 'sudo', 'become_user': None, 'check': False, 'listhosts': None,
               'listtasks': None, 'listtags': None, 'syntax': None, 'diff': False}
    loader = None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 01:37:09.091076
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import json
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    task_data = json.loads("""
        {
            "action": "include",
            "args": {
                "_raw_params": "./tasks/main.yml"
            }
        }
    """)

    play_context = PlayContext()
    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)

# Generated at 2022-06-21 01:37:20.495905
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import os
    import yaml

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    from units.mock.loader import DictDataLoader

    # args
    playbook = 'include_task_apply.yml'
    loader = DictDataLoader({host_list: dict(vars=dict(foo='bar')) for host_list in C.DEFAULT_HOST_LIST})
    inventory = InventoryManager(loader=loader, sources=[host_list])

    # test
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    pb_executor

# Generated at 2022-06-21 01:37:26.943244
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''Test case for constructor of class TaskInclude'''
    task_include = TaskInclude()
    assert task_include.statically_loaded == False

    task_include = TaskInclude(task_include="task_include")
    assert task_include.statically_loaded == False

# Generated at 2022-06-21 01:37:28.434593
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Do nothing for now
    assert True is True

# Generated at 2022-06-21 01:37:38.424726
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    To maintain backward compat we don't want to break old style includes while fixing the new style

    But in new style, apply attributes are allowed, validating them here in above method
    '''
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = AnsibleLoader(None, None)

    # Test for issue #22773 - we shouldn't be modifying the original task data
    #                        so we should have a different task after the load()
    #                        call
    data = {'action': 'include', 'file': 'foo'}
    task = loader.load(data, '', True).get_

# Generated at 2022-06-21 01:37:47.389423
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import Play
    from ansible.playbook.block import Block

    # method is static
    assert hasattr(TaskInclude.check_options, '__self__') == False

    # test no wrong key
    t = TaskInclude()
    task = t.check_options(TaskInclude(block=Block()), {'a':2})
    assert task._parent._task == task
    assert task.args['_raw_params'] == 2

    # test wrong 1 key
    try:
        t.check_options(TaskInclude(block=Block()), {'a':2, 'b':0})
        assert False
    except:
        assert True

    # test wrong 2 keys

# Generated at 2022-06-21 01:38:03.422027
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.parsing.yaml.objects
    ti = TaskInclude()

    # empty task
    data = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject()
    with pytest.raises(AnsibleParserError):
        ti.load(data)

    # simple
    data = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject('include_tasks')
    res = ti.load(data)
    assert '_raw_params' in res.args
    assert '_file' in res.args  # deprecated
    assert 'file' not in res.args

    # simple with file
    data = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject('include_tasks: foo')
    res = ti

# Generated at 2022-06-21 01:38:13.701045
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = Task()
    task.args = {'_raw_params': 'test.yml'}
    task.action = 'include_role'
    task = ti.check_options(task, None)
    assert task.args['_raw_params'] == 'test.yml'

    task.args = {'file': 'test.yml'}
    task = ti.check_options(task, None)
    assert task.args['_raw_params'] == 'test.yml'

    task.args = {'_raw_params': 'test.yml', 'apply': {'a': 1}}
    task.action = 'include_tasks'
    task = ti.check_options(task, None)

# Generated at 2022-06-21 01:38:14.288866
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-21 01:38:23.119084
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import os
    import sys
    import tempfile
    import yaml
    from ansible.module_utils.six import PY3
    try:
        from yaml import CSafeLoader as SafeLoader, CSafeDumper as SafeDumper
    except ImportError:
        from yaml import SafeLoader, SafeDumper

    # Create temp file to store data
    (fd, path) = tempfile.mkstemp()
    os.close(fd)

    # Create data

# Generated at 2022-06-21 01:38:35.859860
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    def test(data, expected):
        '''helper function to test preprocess_data method'''
        my_data = dict(data)
        result = ti.preprocess_data(my_data)
        assert result == expected, '%s != %s' % (result, expected)
        assert my_data == data, '%s != %s' % (my_data, data)

    test({'foo': 1, 'action': 'include'}, {'action': 'include', 'foo': Sentinel})
    test({'action': 'include', 'ignore_errors': True}, {'action': 'include', 'ignore_errors': True})
    test({'action': 'include', 'foo': 1}, {'action': 'include', 'foo': Sentinel})

    # same tests for other tasks that use TaskIn

# Generated at 2022-06-21 01:38:46.005697
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    def test_errors(*args, **kwargs):
        for a in args:
            ti = TaskInclude()
            ti.args = a
            try:
                ti.check_options(ti, {})
                assert False, 'Should have thrown an exception'
            except AnsibleParserError as e:
                assert e.message.startswith(kwargs['message']), 'Got {}'.format(e.message)

    def test_success(*args, **kwargs):
        ti = TaskInclude()
        ti.args = {}
        for a, v in kwargs['args'].items():
            ti.args[a] = v
        ti.check_options(ti, {})

    # 'include' action should not throw any exceptions

# Generated at 2022-06-21 01:38:51.422161
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.inventory
    from ansible.vars.manager import VariableManager

    ti = TaskInclude()
    pb = ansible.inventory.PlaybookInventory([])
    role = ansible.inventory.RoleInclude()
    role._role = role
    role._role._role = role
    role._role._role._role = role
    role._role._role._role._role = role
    role._role._role._play = pb
    role._role._play = pb
    role._play = pb
    role._role._role._role._variable_manager = VariableManager(loader=None, inventory=pb)
    role._role._role._variable_manager = VariableManager(loader=None, inventory=pb)
    role._role._variable_manager = VariableManager(loader=None, inventory=pb)
    role._

# Generated at 2022-06-21 01:38:56.642977
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.vars = {'x': 2, 'y': 3}
    task_include.args = {'z': 'a'}

    assert task_include.get_vars() == {'x': 2, 'y': 3, 'z': 'a'}

# Generated at 2022-06-21 01:39:05.740857
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {
        'apply': {},
        'loop_with': {},
        'loop': {},
        'loop_control': {}
    }
    p_block = task_include.build_parent_block()
    assert p_block.args == {
        'block': [],
        'loop_with': {},
        'loop': {},
        'loop_control': {}
    }

# Generated at 2022-06-21 01:39:09.239893
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True

    new_ti = ti.copy()

    assert new_ti.statically_loaded == True

# Generated at 2022-06-21 01:39:29.831343
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Function to test the get_vars function of class TaskInclude.
    '''
    # Create an instance of a dictionary.
    # The dictionary have the same structure as the dict 'ds' of function preprocess_data in class TaskInclude.
    ds = dict(
        action='debug',
        other='test_get_vars_other',
        task_name='test_get_vars_task_name',
        vars={
            'test_get_vars_vars_var1': 'hello',
            'test_get_vars_vars_var2': 'world'
        },
        when='test_get_vars_when',
        tags='test_get_vars_tags'
    )

    # Create an instance of class TaskInclude.
    task_include = TaskIn

# Generated at 2022-06-21 01:39:39.945424
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    This method is used to test the class TaskInclude and its method copy
    '''
    # Create an object TaskInclude source and destination
    task_src = TaskInclude()
    task_dst = TaskInclude()

    # Create a block and add it to the tasksource
    block_src = Block()
    task_src.block = block_src

    # Create the parent block and add it to the tasksource
    parent_block_src = Block()
    block_src._parent = parent_block_src

    # Create the task_include object and add it to the block
    task_include_src = TaskInclude()
    block_src._task_include = task_include_src

    # Create and add 2 tasks to the block
    task_src1 = Task()
    task_src2 = Task()
   

# Generated at 2022-06-21 01:39:49.370874
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Validates that method TaskInclude.load() returns a correct TaskInclude object
    """
    task_data = {
        'include': 'test_TaskInclude_load_data.yml',
        'tags': ['mytags'],
        'ignore_errors': True,
    }
    task = TaskInclude.load(task_data)

    assert task
    assert task.include == 'test_TaskInclude_load_data.yml'
    assert task.tags == ['mytags']
    assert task.ignore_errors


# Generated at 2022-06-21 01:40:00.356330
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    # ===========================================
    # Setup test environment
    display.verbosity = 3

    # Data structure used by TaskInclude to create tasks
    ds = {
        'include': 'some_include_file.yml',
        'with_items': ['item1','item2'],
        'with_dict': {'key1': 'value1', 'key2': ['value2', 'value3']},
        'ignore_errors': False,
        'tags': ['tag1', 'tag2']
    }

# Generated at 2022-06-21 01:40:11.831544
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task.include.static import StaticTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    import pytest

    # no 'file' option
    ti1 = TaskInclude()
    ti1.action = 'include_tasks'
    ti1.args = {'apply': {'x': 'y'}}
    with pytest.raises(AnsibleParserError) as exc:
        ti1.check_options(ti1, DataLoader().load_from_file('/tmp/foo'))
    assert str(exc.value) == 'No file specified for include_tasks'

    # 'file' is ok for include_tasks
    ti1 = TaskInclude()

# Generated at 2022-06-21 01:40:23.227856
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude.load(dict(
        action='include',
        file='playbook.yml'
    ))

    new_task_include = task_include.copy()

    assert task_include.as_dict() == new_task_include.as_dict()
    assert task_include.action == new_task_include.action
    assert task_include.args == new_task_include.args
    assert task_include.default_vars == new_task_include.default_vars
    assert task_include.vars == new_task_include.vars
    assert task_include.block == new_task_include.block
    assert task_include.ignore_errors == new_task_include.ignore_errors
    assert task_include.delegate_to == new_task_include.delegate_to


# Generated at 2022-06-21 01:40:31.015098
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Given
    data = {
        'action': 'include',
        'file': 'file.yml',
        'apply': {
            'ignore_errors': False,
            'no_log': False,
            'loop': '{{ loop_var }}',
            'loop_control': {
                'loop_var': 'item'
            },
            'serial': 20,
        },
    }
    # When
    ti = TaskInclude.load(data)
    # Then
    assert ti.action == 'include'

# Generated at 2022-06-21 01:40:40.135567
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    For issue #25220, this test will only pass if a KeyError is raised,
    since the ``include`` attribute is not allowed and is not expected.

    :param ds:
    :return:
    '''
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    ds = dict(
        name='foo',
        include='tests/roles/test_include',
    )
    task = TaskInclude.load(
        ds,
        variable_manager=None,
        loader=loader,
    )
    task.get_vars()

# Generated at 2022-06-21 01:40:49.204863
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext

    task = TaskInclude()
    # action = include
    data = {'action': 'include', 'file': 'some_file'}
    task_include = task.check_options(task.load_data(data, variable_manager=None, loader=None), data)

    assert task_include.action == 'include'
    assert task_include.args['_raw_params'] == 'some_file'

    # action = import_tasks
    data = {'action': 'import_tasks', 'file': 'some_file'}
    task_include = task.check_options(task.load_data(data, variable_manager=None, loader=None), data)

    assert task_include.action == 'import_tasks'
    assert task_include.args

# Generated at 2022-06-21 01:40:59.979991
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:41:26.855010
# Unit test for method load of class TaskInclude

# Generated at 2022-06-21 01:41:38.695458
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # I need to use 'configuration' instead of 'include' as the later breaks jenkins
    t = TaskInclude.load({'action': 'configuration', 'args': {'file': 'static_include_task.yml'}}, loader=None, variable_manager=None)

    t._role = MagicMock()
    t._role.get_vars.return_value = {"role_var1": "role_var1_value", "role_var2": "role_var2_value"}

    t._parent = MagicMock()
    t._parent.get_vars.return_value = {"parent_var1": "parent_var1_value", "parent_var2": "parent_var2_value"}


# Generated at 2022-06-21 01:41:42.382994
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    statically_loaded = True
    ti = TaskInclude()
    ti.statically_loaded = statically_loaded

    new_task_include = ti.copy()
    assert new_task_include.statically_loaded == statically_loaded

# Generated at 2022-06-21 01:41:51.123544
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import sys
    import os
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils import context_objects as co

    loader = DataLoader()
    if PY2:
        inventory = InventoryManager(loader=loader, sources='localhost,')
    else:
        inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 01:42:01.594928
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Tests that method check_options runs correctly for valid arguments.
    '''
    block = Block()
    role = None
    task_include = None

    task1_data = {'action': 'include', 'file': 'example.yml'}
    task2_data = {'action': 'import_playbook', 'file': 'example.yml'}
    task3_data = {'action': 'include_tasks', 'file': 'example.yml', 'tags': ['tag1', 'tag2'], 'ignore_errors': True}
    task4_data = {'action': 'import_role', 'name': 'role_1', 'tasks_from': 'example.yml'}

# Generated at 2022-06-21 01:42:12.726954
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import yaml
    from ansible.plugins.action import ActionModule
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    my_task_include = TaskInclude()

    apply_attrs = {
        'block': []
    }

    with open('./test/tasks_include.yml', 'r') as f:
        data = yaml.load(f)

    data = my_task_include.preprocess_data(data)

    args = data.pop('args', {})
    task = my_task_include.check_options(
        my_task_include.load_data(data),
        data
    )

    task.apply_attrs = apply_attrs


# Generated at 2022-06-21 01:42:21.775430
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude()
    copied_task = task.copy()

    # Check if the task and copied_task are the same
    assert task is not copied_task
    assert task == copied_task

    # Check the task's deepcopy
    assert task.args is copied_task.args
    assert task.action is copied_task.action
    assert task._parent is copied_task._parent
    assert task._role is copied_task._role
    assert task._block is copied_task._block
    assert task._always_run is copied_task._always_run
    assert task.name is copied_task.name
    assert task.loop is copied_task.loop
    assert task.notify is copied_task.notify
    assert task.poll is copied_task.poll
    assert task.tags == copied_task.tags
    assert task

# Generated at 2022-06-21 01:42:31.670721
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class MockPlay:
        def __init__(self):
            self.name = 'mock_play'
            self.id = 'mock_id'
            self.vars = {}

    class MockTaskInclude:
        def __init__(self):
            self._parent = MockPlay()
            self._role = MockRole()
            self._loader = MockLoader()
            self._variable_manager = 'mock_variable_manager'
            self.args = {}

    # Args and apply are set
    mock_play = MockPlay()
    mock_role = MockRole()
    mock_loader = MockLoader()
    mock_variable_manager = 'mock_variable_manager'
    apply_attrs = {'block': 'some_block'}
    ti = MockTaskInclude()

# Generated at 2022-06-21 01:42:35.466081
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti._parent is None
    assert ti._role is None
    assert ti._task_include is None
    assert ti.statically_loaded is False



# Generated at 2022-06-21 01:42:40.709020
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Create an empty task
    task = TaskInclude('statically_loaded')

    # Create a task with arguments
    task_arg = TaskInclude('statically_loaded_arg')
    # Add arguments to task
    task_arg.args = dict(
        {
            'a': 'b'
        }
    )

    # Add a sub block to task
    task.block = Block('test')
    task_arg.block = Block('test')
    block_args = dict(
        {
            'tasks': {},
            'when': 'test'
        }
    )
    task.block.block = block_args
    task_arg.block.block = block_args

    # Tests without parameters
    # Parameters tested : exclude_parent=False, exclude_tasks=False
    new_task = task.copy

# Generated at 2022-06-21 01:43:20.815159
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_in_1 = {
        'include': 'file-name-1',
    }
    task_in_2 = {
        'include': 'file-name-2',
        'when': 'when-value',
    }
    task_in_3 = {
        'include': 'file-name-3',
        'other-option': 'other-value',
    }
    task_in_4 = {
        'import_tasks': 'file-name-4',
        'apply': {
            'block': [{
                'task': {
                    'name': 'task-name',
                }
            }],
        },
    }

# Generated at 2022-06-21 01:43:29.379332
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Create a mock for a AnsibleParserError
    class AnsibleParserErrorMock(Exception):
        def __init__(self, message, obj={}):
            pass

    # Create a mock for class FieldAttribute
    class FieldAttributeMock():
        def __init__(self,name, *args, **kwargs):
            pass
        def from_data(self, my_data):
            return my_data

    # Create a mock for class TaskInclude
    class TaskIncludeMock():
        VALID_ARGS = frozenset([]) # This attribute will be used to validate the options
        VALID_INCLUDE_KEYWORDS = frozenset([]) # This attribute will be used to validate the keys
        def __init__(self):
            pass

# Generated at 2022-06-21 01:43:34.253477
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    my_task = TaskInclude(action='include_tasks', args={'apply': '', 'static': True}, block=None, role=None, task_include=None)
    new_my_task = my_task.copy()
    assert new_my_task.args == {'apply': '', 'static': True}
    assert new_my_task.statically_loaded == my_task.statically_loaded == True
    assert new_my_task.action == my_task.action == 'include_tasks'
    assert new_my_task.block == new_my_task._parent == my_task.block == my_task._parent == None
    assert new_my_task.role == my_task.role == None
    assert new_my_task.task_include == my_task.task_include == None

   

# Generated at 2022-06-21 01:43:38.333418
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_dependency import RoleDependencyList
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    #######################
    ## Static inventory
    #######################

# Generated at 2022-06-21 01:43:49.377704
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Note:
    Test case using a playbook with only one task and one handler
    (ref: test_include.yml)
    This is the same test case as test_execute_task()
    """
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/ansible_test/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 01:43:49.873441
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-21 01:43:53.895516
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = {'action': 'include_tasks', 'file': 'test.yml', 'apply': {'block': []}}
    task = TaskInclude.load(data)
    assert task.args['_raw_params'] == data['file']
    assert task.args['apply'].to_data() == data['apply']

# Generated at 2022-06-21 01:44:00.042151
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role_context import RoleContext
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.port = 0
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'dummy'
    play_context.password = 'pwd'
    play_context.become = False

# Generated at 2022-06-21 01:44:10.809642
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    ti = TaskInclude()
    ti.play = Play().load({}, variable_manager=None, loader=None)
    ti.role = Role().load({}, play=ti.play, variable_manager=None, loader=None)

    # test with a proper TaskInclude
    task = ti.check_options(Block().load("""
        - hosts: all
          import_role:
            name: test_role
          tasks:
            - include: "test_file"
              no_log: false
    """, play=ti.play, task_include=ti, role=ti.role, variable_manager=None, loader=None), {})
    assert task.action == ti.action

# Generated at 2022-06-21 01:44:18.949509
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.task as task_plugins
    plugin_loader.add_directory(C.DEFAULT_TASK_PLUGIN_PATH)
    plugin_loader.add_directory(C.DEFAULT_TASK_PLUGINS_PATH)
    plugin_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    plugin_loader.add_directory(C.DEFAULT_ACTION_PLUGINS_PATH)
    plugin_loader.add_directory(C.DEFAULT_CACHE_PLUGIN_PATH)
    plugin_loader.add_directory(C.CACHE_PLUGIN_PATH)

    # Below