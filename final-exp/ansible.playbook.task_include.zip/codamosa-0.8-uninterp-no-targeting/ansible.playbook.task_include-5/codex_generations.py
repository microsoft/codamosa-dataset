

# Generated at 2022-06-21 01:34:56.124898
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    filename = 'tasks/test.yml'
    file_data = '''
- name: test
  include: "{{base_dir}}/%s"
''' % filename
    file_contents = '''
- name: file include test
  debug:
    msg: "include test"
'''
    playbook_path = '/tmp/file_include'
    import os
    import tempfile
    import shutil
    import jinja2

    # Create playbook and task file

# Generated at 2022-06-21 01:35:02.815575
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'file': 'copy_test'}
    task_include.statically_loaded = True

    # Run TaskInclude.copy method
    task_include_copy = task_include.copy()

    # Compare copy with original
    assert isinstance(task_include_copy, TaskInclude)
    assert task_include_copy.action == 'include'
    assert task_include_copy.args == {'file': 'copy_test'}
    assert task_include_copy.statically_loaded == True

# Generated at 2022-06-21 01:35:13.840010
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Check that the Block created for apply is:
    - the one which implicit attribute _parent is the one of TaskInclude
    '''
    import ansible.playbook
    import ansible.playbook.task

    t = ansible.playbook.TaskInclude()
    t.args = dict()
    t.args['apply'] = {'a':'1', 'b':'2', 'block':[], 'c':'3'}
    p_block = t.build_parent_block()
    assert p_block._parent is t

    t.args['apply'] = {'a':'1', 'b':'2'}
    p_block = t.build_parent_block()
    assert p_block == t

# Generated at 2022-06-21 01:35:26.393391
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Set up to instantiate TaskInclude
    T = TaskInclude
    T.action = 'include'

# Generated at 2022-06-21 01:35:35.037074
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    assert 'include' not in TaskInclude.VALID_INCLUDE_KEYWORDS
    data = dict(
        action='include',
        include=dict(name='foo.yml')
    )
    ti = TaskInclude()
    ti.statically_loaded = False
    processed_data = ti.preprocess_data(data)
    assert 'include' in processed_data.keys()
    ti.statically_loaded = True
    processed_data = ti.preprocess_data(data)
    assert 'include' not in processed_data.keys()

# Generated at 2022-06-21 01:35:45.274078
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'block': []}
    TaskInclude(block=None, role=None, task_include=None)._preprocess_data(ds)

    ds = {'block': [{'when': 'sometest', 'include': 'somewhere'}]}
    TaskInclude(block=None, role=None, task_include=None)._preprocess_data(ds)

    ds = {'action': 'include', 'block': [{'when': 'sometest', 'action': 'include', 'other_valid_arg': True}]}
    TaskInclude(block=None, role=None, task_include=None)._preprocess_data(ds)


# Generated at 2022-06-21 01:35:55.418671
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    task_include = TaskInclude()

    test_data = dict(action='include',
                     args=dict(file='/dev/null'),
                     )

    expected_data = dict(action='include',
                         args=dict(file='/dev/null'),
                         )

    returned_data = task_include.preprocess_data(test_data)
    assert returned_data == expected_data

    test_data = dict(action='include',
                     args=dict(file='/dev/null'),
                     foo='bar',
                     )

    expected_data = dict(action='include',
                         args=dict(file='/dev/null'),
                         )

    returned_data = task_include.preprocess_data(test_data)
    assert returned_data == expected_data


# Generated at 2022-06-21 01:36:04.982624
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    variables = {}
    play = Play().load({
        'name': 'create-vm',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {
                'include': {
                    'name': 'apply-changes',
                    'apply': {
                        'block': [
                            {
                                'debug': {
                                    'msg': 'Ran a task'
                                }
                            }
                        ]
                    }
                }
            }
        ]
    }, variable_manager=variables, loader=None)

    assert play.tasks[0]._parent._parent.__class__.__name__ == 'Play'

# Generated at 2022-06-21 01:36:05.730888
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-21 01:36:16.418836
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    import ansible.plugins.action as action_plugins
    import ansible.plugins.connection as connection_plugins
    import ansible.plugins.lookup as lookup_plugins
    import ansible.plugins.strategy as strategy_plugins
    import ansible.plugins.test as test_plugins
    import ansible.plugins.vars as vars_plugins

    from ansible.plugins.loader import action_loader, connection_loader, lookup_loader, strategy_loader, test_loader, var_loader

    action_loader.add_directory(action_plugins._PLUGIN_PATH)
    connection_loader.add_directory(connection_plugins._PLUGIN_PATH)
    lookup_loader.add_directory(lookup_plugins._PLUGIN_PATH)
    strategy_loader.add_directory(strategy_plugins._PLUGIN_PATH)
    test

# Generated at 2022-06-21 01:36:27.141004
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    def assert_init(action, args, data, display_expected):
        '''
        Checks if passed parameters are initialized correctly
        '''
        task = TaskInclude.load(data)

        assert action == task.action
        assert args == task.args
        assert display_expected == task.display

    # Test without data
    assert_init(None, {}, {}, '')

    # Test with empty data
    assert_init('include', {'_raw_params': ''}, {'': ''}, '')

    # Test with data
    assert_init('include', {'_raw_params': 'hello.yml'}, {'': 'hello.yml'}, 'hello.yml')

    # Test with list of tasks

# Generated at 2022-06-21 01:36:37.863074
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import variable_manager
    from ansible.vars import VariableManager

    # Static inclusion
    iki = '''
    - hosts: localhost

      pre_tasks:
        - debug: msg="This is a pre task"

      tasks:
        - include: tasks.yml tasks=main

      post_tasks:
        - debug: msg="This is a post task"
    '''
    iki_file = 'iki.yml'
    with open(iki_file, 'w') as stream:
        stream.write(iki)

    # Dynamic inclusion

# Generated at 2022-06-21 01:36:44.241425
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # test TaskInclude class without arguments
    try:
        TaskInclude()
    except Exception as e:
        assert False, "TaskInclude class cannot be initialized without an argument, error: %s" % e

    # test TaskInclude class with argument
    try:
        TaskInclude(block="block")
    except Exception as e:
        assert False, "TaskInclude class with argument 'block' cannot be initialized, error: %s" % e
    finally:
        assert True

# Generated at 2022-06-21 01:36:49.609388
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = dict(
        name='test_TaskInclude_get_vars',
        action='include',
        include_vars='include_vars.yaml',
        vars={'var1': 'value1'},
        other_var='value2',
        when={'x': 'y'},
    )

    loader = DataLoader()
    inc_vars = {'include_var': 'include_var_value'}
    loader.set_basedir('tests/lib/ansible/modules/test/auxiliary')

# Generated at 2022-06-21 01:36:55.381613
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    var_manager = None
    loader = None
    data = {'include_tasks': '/test/test.yml'}
    block = None
    role = None
    task_include = None
    task = TaskInclude.load(data, block, role, task_include, var_manager, loader)
    assert task.static
    assert not task.statically_loaded
    assert task.action == 'include_tasks'


# Generated at 2022-06-21 01:37:07.408003
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    display_attr = TaskInclude.VALID_INCLUDE_KEYWORDS
    tasks_with_display_attr = C.INCLUDE_TASKS + C.IMPORT_TASKS + C.ROLE_TASKS
    tasks_without_display_attr = C.ALL_TASKS.difference(tasks_with_display_attr)

    # Check display attributes are allowed
    for task_action in tasks_with_display_attr:
        task = TaskInclude(block=None, task_include=None, role=None)
        task.action = task_action
        ds = dict(task.VALID_INCLUDE_KEYWORDS)
        ds = task.preprocess_data(ds)
        assert task.args != {}

# Generated at 2022-06-21 01:37:18.677278
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # The top level play
    parent_p_block = Block.load(dict(hosts='localhost'), loader=None, variable_manager=None, play=None)
    parent_p_block.vars = dict(x=1) # This is the parent vars
    # The parent block
    p_block = Block.load(dict(block=[]), loader=None, variable_manager=None)
    p_block._parent = parent_p_block
    p_block.vars = dict(y=2)
    # The task
    task = TaskInclude.load(dict(action='include', x=3, y=4, z=5), loader=None, variable_manager=None)
    task._parent = p_block

    expected_vars = dict(x=1, y=2, z=5)

# Generated at 2022-06-21 01:37:23.584786
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    obj = TaskInclude()
    assert hasattr(obj, '_role')
    assert hasattr(obj, 'apply')
    assert hasattr(obj, 'block')
    assert hasattr(obj, 'include_role')
    assert hasattr(obj, 'import_role')
    assert hasattr(obj, 'include')
    assert hasattr(obj, 'import_tasks')
    assert hasattr(obj, 'meta')

# Generated at 2022-06-21 01:37:35.996755
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    with pytest.raises(AnsibleParserError) as e:
        TaskInclude.load(
            {
                'include': 'file.yml',
                'invalid_opt': 'fake_value'
            },
            variable_manager=pytest_shared_ansible_globals.variable_manager,
            loader=pytest_shared_ansible_globals.loader
        )

    assert 'Invalid options for include: invalid_opt' in to_native(e.value)


# Generated at 2022-06-21 01:37:46.616471
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    variable_manager.set_inventory(inventory)

    # Create a dict to use in our tests
    base_task = dict(
        action='include',
        file='file.yml'
    )

    # Base test
    task = TaskInclude.load(base_task, variable_manager=variable_manager, loader=loader)
    for key in TaskInclude.BASE:
        assert key in task.args  # Checks only the items of TaskInclude.BASE

    # Test with

# Generated at 2022-06-21 01:38:03.846384
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager
    task_include = TaskInclude(block=Block(), role=None, task_include=None)
    variable_manager = VariableManager()
    variable_manager.set_host_variable('host0', 'hostname', 'host0')
    loader = None
    task = task_include.load({'include': '/path/to/file'}, block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:38:13.798436
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()

    p_block = Block()
    p_block._parent = None
    p_block.vars = dict(a=1, b=2)
    p_block.action = 'include_role'
    p_block.tags = ['tag1', 'tag2']
    p_block.when = True

    ti._parent = p_block
    ti.vars = dict(c=3, d=4)
    ti.action = 'include'

    # _parent is not None
    assert ti._parent is not None
    # _parent is Block
    assert isinstance(ti._parent, Block)

    # _parent._parent is None
    assert ti._parent._parent is None
    # _parent.vars is dict
    assert isinstance(ti._parent.vars, dict)
    #

# Generated at 2022-06-21 01:38:25.448297
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Verify option 'ignore_errors' is not accepted with 'import_tasks'
    ti = TaskInclude()
    task = {
        'action': 'import_tasks',
        'args': { 'ignore_errors': True },
    }
    try:
        ti.check_options(task, None)
        assert False, 'Expected exception has not been raised'
    except AnsibleParserError:
        pass
    except Exception:
        assert False, 'An unexpected exception has been raised'

    # Verify unknown options are accepted with 'import_tasks'
    ti = TaskInclude()
    task = {
        'action': 'import_tasks',
    }
    try:
        ti.check_options(task, None)
    except Exception:
        assert False, 'An unexpected exception has been raised'

# Generated at 2022-06-21 01:38:34.421455
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.utils.vars import combine_vars
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    task = TaskInclude.load(
        dict(
            action=C.ACTION_INCLUDE_TASK,
            file='foo.yml',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    assert task.args['file'] == 'foo.yml'


# Generated at 2022-06-21 01:38:42.488536
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    data = {'action': AnsibleUnsafeText('include_role'), 'args': {'foo': AnsibleUnsafeText('bar'), 'baz': AnsibleUnsafeText('zee')}}
    expect_data = {'action': AnsibleUnsafeText('include_role'), 'args': {'foo': AnsibleUnsafeText('bar'), 'baz': AnsibleUnsafeText('zee')}}

    obj = IncludeRole()
    assert(obj.preprocess_data(data) == expect_data)


# Generated at 2022-06-21 01:38:56.602868
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Construct a task_include attribute 'args' with apply keyword
    task_include_args = { 'file': 'test', 'apply': {'vars': {'key1': 'val1', 'key2': 'val2'}} }
    # Construct an attribute for parent class Task
    parent_class_attribute = {'block': [], 'vars': {'test': 'test'}, 'task_vars': {'test': 'test'}}
    # Create a parent block by invoking method build_parent_block of class TaskInclude
    parent_block = TaskInclude.build_parent_block(task_include_args, parent_class_attribute)
    assert parent_block is not None
    assert parent_block.vars == {'key1': 'val1', 'key2': 'val2', 'test': 'test'}
   

# Generated at 2022-06-21 01:39:09.508983
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    play_ds = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        connection = 'local',
        roles = []
    )
    play = Play.load(play_ds, variable_manager=VariableManager(), loader=None)

    block_ds = dict(
        name = 'TaskInclude parent block',
        tasks = [
          {
            'include': 'fake.yml',
            'name': 'include fake',
            'foo': 'first_value',
            'when': 'always'
          }
        ]
    )

# Generated at 2022-06-21 01:39:13.440078
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # This test only checks that the method doesn't raise any exception
    class Dummy:
        pass

    t = TaskInclude()
    # Passing an action that is not a normal task
    t.action = 'include'
    t.preprocess_data({})

    t.action = 'import_tasks'
    t.preprocess_data({})

    t.action = 'include_role'
    t.preprocess_data({})

    t.action = 'include_tasks'
    t.preprocess_data({})

    t.action = 'import_playbook'
    t.preprocess_data({})

    t.action = 'include_playbook'
    t.preprocess_data({})

    # Passing an action that is a normal task
    t.action = 'debug'
    t.preprocess_data

# Generated at 2022-06-21 01:39:21.732947
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a parent Task object
    parent_task = Task()

    # Create a variable dictionary
    variable = {'x': 'value'}

    # Set the variable dictionary and parent task in TaskInclude object
    task_include.vars = variable
    task_include._parent = parent_task

    # Set action in TaskInclude object
    task_include.action = 'include'

    # Create a TaskInclude object's args dictionary
    task_include.args = {'_raw_params': 'test', 'tags': 'tag', 'when': 'when'}

    # Assert the TaskInclude object's method 'get_vars' returns the expected value

# Generated at 2022-06-21 01:39:30.980268
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockTask(object):
        pass

    my_args = dict(file='/some/file')

    ti = TaskInclude()
    task = MockTask()
    task.action = 'include'
    task.args = my_args

    with pytest.raises(AnsibleParserError) as exec_info:
        ti.check_options(task, {})
    assert "Invalid options for include" in str(exec_info.value)
    assert "file" in str(exec_info.value)

    my_args = dict(file='/some/file')
    task.action = 'import_tasks'
    task.args = my_args
    ti.check_options(task, {})

    my_args = dict(file='/some/file')
    task.action = 'include_role'
   

# Generated at 2022-06-21 01:39:50.799552
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    We have several cases that task_include need to handle for method get_vars
    1. task action is not include, then get_vars of super class should be called.
    2. task action is include, then parameters of this task should be included.
    '''
    class ParentTask:
        def get_vars(self):
            return {'parent_vars': 'parent_vars_value'}

    raw_task_include_data = dict(action='include', args=dict(a='a', b='b', c='c'))
    # Test case 1.
    ti = TaskInclude(role='test_role', task_include=ParentTask())
    ti.action = 'test_action'

# Generated at 2022-06-21 01:40:00.900128
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.task_include as ti
    import ansible.playbook.task as t
    try:
        # Check invalid options: these cases should raise an exception
        ti.TaskInclude.check_options(t.Task(), {'file': 'test.yml'})  # no action
        assert False, 'Expected AnsibleParserError exception'
    except (AnsibleParserError, AssertionError):
        pass

# Generated at 2022-06-21 01:40:02.335702
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    ti.load()

# Generated at 2022-06-21 01:40:13.096101
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block

    task_include = TaskInclude(block=Block(), role=None)
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    data = AnsibleMapping({
        u'action': u'include',
        u'file': u'tasks/foo.yml',
        u'_ansible_no_log': True,
    })

    task = task_include.load_data(data)
    assert task.action == data['action']
    assert task.args['_raw_params'] == data['file']
    assert task.args['_ansible_no_log'] == data['_ansible_no_log']

    # Test validation error in check_options

# Generated at 2022-06-21 01:40:22.225051
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test options validation
    '''
    import ansible.parsing.yaml.objects

    attrs_ds = dict(file='foo.yml', when='something')
    attrs_ds['apply'] = dict(bar='something')
    # 'file' is missing and we are expecting an exception from check_options
    ds = dict(apply=dict(bar='something'))
    ds['action'] = 'include'
    t = TaskInclude.load(ds)
    assert isinstance(t.args, dict)
    assert not t.args.get('file')
    t.check_options(t, ds)
    # This throws an exception as expected
    try:
        t.check_options(t, ds)
    except AnsibleParserError:
        pass
    # This has a

# Generated at 2022-06-21 01:40:30.663267
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_data = {
        "tasks": [
            # Include '_raw_params' is implicitly an include
            {'include': 'foo.yml'},
            # As above, with 'file' explicitly
            {'include': {'file': 'foo.yml'}},
            # Include with arguments
            {'include': 'foo.yml', 'vars': {'bar': 'baz'}},
            # Include with apply, as specified on issue #12642
            {'include': {'file': 'foo.yml', 'apply': {'loop': '{{ some_data }}'}}}
        ]
    }
    task_incl = TaskInclude(Block())

    # Make sure that TaskInclude._validate_options raises on invalid options
    for task in task_data["tasks"]:
        task

# Generated at 2022-06-21 01:40:32.515604
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook.block
    import ansible.playbook.task
    tp = TaskInclude()
    assert type(tp) is TaskInclude


# Generated at 2022-06-21 01:40:34.771086
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    data = dict(func='func_name', loop='loop_name', static='static')
    result = ti.preprocess_data(data)
    assert len(result) == 2
    assert 'func' in result
    assert 'loop' in result

# Generated at 2022-06-21 01:40:42.778156
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    play_context = PlayContext()
    play_context.remote_addr = "192.168.1.1"
    play_obj = Play.load({}, variable_manager=None, loader=None)
    block_parent_obj = Block.load({}, play=play_obj, task_include=None, variable_manager=None, loader=None)
    block_parent_obj._parent = play_obj

# Generated at 2022-06-21 01:40:50.920266
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Simple case - empty task
    task = TaskInclude()
    assert task.check_options(task, None) == task

    task = TaskInclude()
    task.args['_raw_params'] = 'some_file'
    assert task.check_options(task, None) == task

    # Now with invalid args
    task = TaskInclude()
    task.args['_raw_params'] = 'some_file'
    task.args['foobar'] = 'baz'
    try:
        task.check_options(task, None)
        assert False
    except AnsibleParserError:
        assert True

    # Now with 'apply' that is not a dict
    task = TaskInclude()
    task.args['_raw_params'] = 'some_file'

# Generated at 2022-06-21 01:41:11.756035
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t1 = TaskInclude()
    t1.action = 'test'
    t1.args = {'key': 'value'}
    t1.statically_loaded = True
    t1.role = None
    v = t1.copy()
    assert v.action == 'test'
    assert v.statically_loaded == True
    assert v.args == {'key': 'value'}
    assert v.role == None

# Generated at 2022-06-21 01:41:24.876816
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # 1st test: apply specified
    # input data
    data = { 'file': 'file', 'apply': { 'name': 'name' } }

    # expected outcome to assert in loop
    expected_attrs = { k: data[k] for k in set(data.keys()).difference(('file', 'apply')) }
    expected_block_attrs = { k: data['apply'][k] for k in data['apply'] }
    expected_block_attrs['block'] = []
    expected_block_attrs.update(expected_attrs)

    # create task
    task = TaskInclude.load(data)
    p_block= task.build_parent_block()

    # assert outcome

# Generated at 2022-06-21 01:41:29.933393
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    task_include = TaskInclude()
    assert task_include
    task_include = TaskInclude(block=Block())
    assert task_include
    task_include = TaskInclude(role=dict())
    assert task_include
    task_include = TaskInclude(task_include=TaskInclude())
    assert task_include


# Generated at 2022-06-21 01:41:38.707108
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # init the TaskInclude class
    ti = TaskInclude()

    # create the data for the TaskInclude class
    task_include__data = dict()
    task_include__data['include'] = dict()
    task_include__data['include']['file'] = "./test_load.yml"
    task_include__data['include']['action'] = "include"

    # call the load method for the TaskInclude class to make sure the method is working
    ti.load(task_include__data)


# Generated at 2022-06-21 01:41:45.936949
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # check for static include
    static_data = {
        'include': 'vars/static.yml',
    }
    ti = TaskInclude()
    ti.preprocess_data(static_data)
    assert static_data.get('action') in C._ACTION_STATIC_INCLUDE_TASKS

    # check for not static include
    dynamic_data = {
        'include': 'vars/dynamic.yml',
    }
    ti = TaskInclude()
    ti.preprocess_data(dynamic_data)
    assert dynamic_data.get('action') in C._ACTION_DYNAMIC_INCLUDE_TASKS

    # check for include_role
    include_role_data = {
        'include_role': 'role',
    }
    ti = TaskInclude

# Generated at 2022-06-21 01:41:53.878088
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Load plugin to register the include action
    action_plugin = 'include'
    C.ACTION_PLUGINS[action_plugin] = __import__("ansible.plugins.action.%s" % action_plugin, fromlist=["ActionBase"])

    # Create task instance
    load_data = {'action': 'include', 'args': {'apply': {'block': []}, 'file': 'foo'}}
    block = None
    task_include = None
    role = None
    task_include = TaskInclude(block=block, role=role, task_include=task_include)
    task = task_include.check_options(task_include.load_data(load_data), load_data)
    assert task

    # Check parent block creation
    assert isinstance(task.build_parent_block(), Block)
   

# Generated at 2022-06-21 01:41:54.875155
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass
    # TODO: fill in unit test here


# Generated at 2022-06-21 01:42:00.170832
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a Block object
    b = Block()

    # Create an object of class Block and set it as the parent
    b.set_parent(Block())

    # Checking its parent
    assert isinstance(b.get_parent(), Block)

    # Create a TaskInclude object
    task_include = TaskInclude(block=b)

    # Create a Task object and set it as the parent of task_include
    task = Task()
    task_include.set_parent(task)

    # Checking its parent
    assert isinstance(task_include._parent, Task)

    # Set some values for its attributes
    task_include.action = 'include'

    # Set some values to its variables
    task_include.vars = {'var1': 'value1'}

# Generated at 2022-06-21 01:42:08.107084
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Unit test for constructor of class TaskInclude
    '''
    block = [
        {
            'include': 'my-include-task.yml',
            'apply': 'my-apply.yml'
        }
    ]

    task = TaskInclude.load(data=block)

    assert task is not None
    assert task.action == 'include'
    assert task.args == {
        '_raw_params': 'my-include-task.yml',
        'apply': 'my-apply.yml'
    }

# Generated at 2022-06-21 01:42:18.464852
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display.verbosity = 3
    display.deprecated = True
    TaskInclude.VALID_INCLUDE_KEYWORDS = frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                        'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                        'when', 'include'))


# Generated at 2022-06-21 01:42:47.446616
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ds_1 = dict(
        file='test_file',
        action='test_action',
        vars={'test_var': 'test_val'},
        statically_loaded=True,
        args={
            '_raw_params': 'test_raw_params',
            'test_arg': 'argument'
        }
    )

    task_1 = TaskInclude.load(
        ds_1,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    task_2 = task_1.copy()

    assert task_2.action == 'test_action'
    assert task_2.statically_loaded == True

# Generated at 2022-06-21 01:42:52.760008
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    result_field = FieldAttribute(
        FieldAttribute.SKIP_ATTRIBUTE,
    )
    result = TaskInclude(
        task_include=TaskInclude(
            task_include=TaskInclude(
                task_include=TaskInclude(
                    task_include=TaskInclude(
                        task_include=TaskInclude(
                            task_include=TaskInclude(
                                task_include=TaskInclude(
                                    task_include=result_field
                                )
                            )
                        )
                    )
                )
            )
        )
    )

    assert result is result_field

# Generated at 2022-06-21 01:43:00.296545
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Check if method TaskInclude.build_parent_block creates the parent
    block with content of the apply dictionary, if it is present.
    '''
    import json
    import sys
    import os
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase


# Generated at 2022-06-21 01:43:02.689057
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include=TaskInclude()
    assert task_include

# Generated at 2022-06-21 01:43:10.921236
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    def assert_equal(a,b,msg=None):
        if not a == b:
            assert False, "{} \n {} \n != \n {}".format(msg, str(a), str(b))

    data = {'include': 'test.yml'}
    task_include = TaskInclude.load(data)
    assert_equal(task_include.action, 'include')
    assert_equal(task_include.args, data)
    assert_equal(task_include.name, 'include')
    assert_equal(task_include.tags, [])
    assert_equal(task_include.when, [])
    assert_equal(task_include.notify, [])
    assert_equal(task_include.listen, [])

# Generated at 2022-06-21 01:43:13.842704
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    data = dict(name='hello', action='include_role', foo='bar')
    res = task_include.preprocess_data(data)
    assert res == dict(name='hello', action='include_role')

# Generated at 2022-06-21 01:43:20.667126
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

# Generated at 2022-06-21 01:43:29.333556
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Make the inventory mock object
    class FakeInventory():
        def __init__(self):
            self.hosts = {}
        def get_host(self, key):
            return self.hosts[key]

    inventory = FakeInventory()

    # Make the variable manager mock object
    class FakeVariableManager():
        def __init__(self):
            self.hostvars = {}
        def set_host_variable(self, name, varname, value):
            self.hostvars[name][varname] = value
        def get_vars(self, loader, path, entities, cache=True):
            return {}
        def get_host_variables(self, host, include_hostvars=False, include_delegate_to=True):
            return self.hostvars[host]

# Generated at 2022-06-21 01:43:34.209375
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    For this test we use TaskInclude.load because it is already imported by the Task class
    '''
    import ansible.playbook.block
    class MockBlock:
        def __init__(self):
            self._play = {'hosts': 'myhost'}
            self._role= None
            self._variable_manager = ''
            self._loader= {'cached_result': ''}
    class MockTask:
        def __init__(self):
            self._parent = MockBlock()
            self.action = 'include'
            self._role= None
            self._variable_manager = ''
            self._loader= {'cached_result': ''}
        def get_vars(self):
            return {}

# Generated at 2022-06-21 01:43:41.534258
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Test TaskInclude.load() method
    '''
    # Test load of an invalid task
    invalid_task = {'action': 'fail_test'}
    try:
        TaskInclude.load(invalid_task)
        # Should not be reached
        assert 1 == 2
    except AnsibleParserError as e:
        assert e.message == 'Invalid or unsupported action specified: "fail_test"'

    # Test load of an invalid apply dict
    data = {
        'action': 'include_role',
        'apply': 'foo'
    }
    try:
        task = TaskInclude.load(data)
    except AnsibleParserError as e:
        assert e.message == 'Expected a dict for apply but got %s instead' % type('foo')

    # Test load of a valid task and check

# Generated at 2022-06-21 01:43:58.740956
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    assert TaskInclude is not None, "TaskInclude class is defined"
    obj = TaskInclude()
    assert obj._parent is None, "Default _parent is None"
    assert obj._role is None, "Default _role is None"
    assert obj._task_include is None, "Default _task_include is None"

# Generated at 2022-06-21 01:44:05.686760
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Test to check method ``load`` of class TaskInclude
    """
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import copy
    import pytest

    ti = TaskInclude()
    data = {'action': 'include',
            'file': 'test.yml',
            '_raw_params': 'test.yml'}

    task = ti.check_options(ti.load_data(data), data)
    assert task.action == 'include'
    assert task.args == {'file': 'test.yml', '_raw_params': 'test.yml'}

    # Expected error

# Generated at 2022-06-21 01:44:14.761370
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext

    p_block = TaskInclude.load(dict(
        apply=dict(
            block=dict(
                tasks=[
                    dict(action=dict(module='debug', args=dict(msg='debug message')))
                ]
            )
        ),
        file='some-file.yml'
    ))

    block = p_block.build_parent_block()

    assert isinstance(block, Block)
    assert isinstance(block._parent, PlayContext)
    assert len(block.block) == 1
    assert isinstance(block.block[0], Task)
    assert block.block[0].args == dict(msg='debug message')


# Generated at 2022-06-21 01:44:26.747996
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    data = dict()

    data['action'] = 'include'
    data['file'] = '/path/to/file'
    task.preprocess_data(data)
    assert data['action'] == 'include'


    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        data['action'] = action
        task.preprocess_data(data)
        assert data['action'] == action
        assert 'deprecated' not in data

        data['action'] = action
        data['deprecated'] = 'some message'
        task.preprocess_data(data)
        assert data['action'] == action
        assert 'deprecated' not in data

# Generated at 2022-06-21 01:44:38.373935
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This test is to ensure the method get_vars of class TaskInclude works
    by doing the following:
    1. Create a dict for args
    2. Create a dict for vars
    3. Create a parent block
    4. Create a TaskInclude object
    5. Call get_vars on the object created in step 4
    '''
    args = dict(
        action='include',
        file='/home/ubuntu/playbook.yml',
        prefix='pref',
        tags='tag',
        when='when',
        with_items='with_items'
    )

    vars = dict(
        var1=1,
        var2=2
    )

    parent = Block(
        task_include=None,
        role=None,
        play=None
    )

    task