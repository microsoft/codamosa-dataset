

# Generated at 2022-06-21 01:34:54.313579
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    display.verbosity = 3

    task_data = {"file": "include.yml"}
    ti = TaskInclude(block=None, task_include=None, role=None)
    task = ti.load(task_data)

    assert task.args['_raw_params'] == "include.yml"
    assert task.action == "include"
    assert task._parent == None

    data = {}
    my_action = 'include_role'
    data['action'] = my_action
    my_file = "include.yml"
    data['file'] = my_file
    my_loop = '{{ my_var }}'
    data['loop'] = my_loop
    my_apply = {}
    data['apply'] = my_apply


# Generated at 2022-06-21 01:35:02.921276
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TaskInclude.check_options(ti.load_data(data, variable_manager=variable_manager, loader=loader), data)
    # ti.load_data(data, variable_manager=variable_manager, loader=loader)
    # Task.load_data(data, variable_manager=None, loader=None)

    ###############################################
    #### data = {'action': 'include_role', 'name': 'example'}
    data = {'action': 'include_role', 'name': 'example'}
    task = TaskInclude()
    task = TaskInclude.check_options(task, data)
    assert task.action == 'include_role'
    assert task.name == 'example'
    assert task.args == {'_raw_params': 'example'}

# Generated at 2022-06-21 01:35:08.965653
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_block = TaskInclude.load(dict(action='include', args=dict(file='/path/to/file')))
    task_block.statically_loaded = True
    new_task = task_block.copy()
    assert new_task.statically_loaded is True

# Generated at 2022-06-21 01:35:14.843087
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import task_include
    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:35:26.245578
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = dict(action='include', when='foo', name='bar', args=dict(baz='buzz'), weird='foobar', _raw_params='foobar')
    ti = TaskInclude.load(ds)
    preprocessed_ds = ti.preprocess_data(ds)
    assert 'weird' in preprocessed_ds
    ds = dict(action='include_role', when='foo', name='bar', args=dict(baz='buzz'), weird='foobar', _raw_params='foobar')
    ti = TaskInclude.load(ds)
    preprocessed_ds = ti.preprocess_data(ds)
    assert 'weird' not in preprocessed_ds



# Generated at 2022-06-21 01:35:37.702944
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders, PLUGIN_PATH_CACHE
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.executor.task_include

    loader = DataLoader()  # Takes care of finding and reading yaml, json and ini files
    variable_manager = VariableManager()  # Used to load extra vars from files, command line, etc.
    inventory = InventoryManager(loader=loader, sources=[])  # Used to convert hosts to a list of dict

# Generated at 2022-06-21 01:35:38.332493
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pass

# Generated at 2022-06-21 01:35:41.649843
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t1 = TaskInclude(block=None, role=None, task_include=None)
    assert isinstance(t1, TaskInclude)

# Unit test to check that constructor asserts if any argument is provided

# Generated at 2022-06-21 01:35:53.812972
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.playbook.play_context
    ti = TaskInclude()
    ti.name = 'unittest'
    ti.action = 'include'
    ti.task_include = None
    test_data = { 'name': 'start', 'action': 'import_role', 'collections': 'test.collection' }
    ti.preprocess_data(test_data)
    # Resulting dict should have the following keys - 'name', 'action', 'collections'
    assert(set(test_data.keys()) == set(['name', 'action', 'collections']))
    # test_data['name'] should be 'unittest'
    assert(test_data['name'] == 'unittest')
    test_data['name'] = 'end'
    ti.action = 'include_role'

# Generated at 2022-06-21 01:36:01.294900
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    test_task = TaskInclude()
    test_task._role = 'test_role'
    test_task._parent = 'test_parent'
    test_task.statically_loaded = 'test'

    new_task = test_task.copy()

    assert isinstance(new_task, TaskInclude)
    assert new_task.statically_loaded == 'test'
    assert new_task._role == 'test_role'
    assert new_task._parent == 'test_parent'

# Generated at 2022-06-21 01:36:12.145431
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook.play_context as p_context
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar
    from ansible.inventory.host import Host
    import ansible.vars.manager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # setup required objects
    loader = DataLoader()
    play_context = p_context.PlayContext()
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

# Generated at 2022-06-21 01:36:24.157912
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    block = None
    role = None
    ti = TaskInclude(block, role)
    assert isinstance(ti, TaskInclude)
    assert isinstance(ti, Task)
    assert isinstance(ti, Block)
    assert not ti._parent
    assert isinstance(ti._role, Sentinel)
    assert isinstance(ti._dep_chain, Sentinel)
    assert isinstance(ti._had_task_run, Sentinel)
    assert isinstance(ti._loop, Sentinel)
    assert isinstance(ti._loop_with, Sentinel)
    assert isinstance(ti._role_name, Sentinel)
    assert isinstance(ti._block_name, Sentinel)
    assert isinstance(ti._task_name, Sentinel)
    assert isinstance(ti._play, Sentinel)
    assert isinstance(ti._loader, Sentinel)
    assert isinstance

# Generated at 2022-06-21 01:36:24.680339
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TODO implement unit test
    pass

# Generated at 2022-06-21 01:36:36.382021
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    block = Block()
    role = None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    # irrelevant if it finds a file or not
    apply_attrs = {'include_tasks': ['some_file']}
    args = {'apply': apply_attrs}
    task = TaskInclude(block=block, role=role, task_include=task_include)
    task.args = args
    task.action = 'include'
    task = ti.check_options(task, args)
    assert isinstance(task.args.get('apply'), Block)
    assert isinstance(task.args.get('apply').args.get('include_tasks')[0], TaskInclude)

# Generated at 2022-06-21 01:36:43.710922
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display = Display()
    display.verbosity = 3
    task = TaskInclude()

    my_data = {
        'action': 'include_role',
        'tasks': 'tasks/my_task.yml'
    }

    my_data1 = {
        'action': 'include_role',
        'tasks': 'tasks/my_task.yml',
        'tags': ['foo']
    }

    my_data2 = {
        'action': 'include_role',
        'tasks': 'tasks/my_task.yml',
        'ignored': ['foo']
    }

    my_data3 = {
        'action': 'include_role',
        'tasks': 'tasks/my_task.yml',
        'ignored': ['foo']
    }



# Generated at 2022-06-21 01:36:49.102870
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include_copy = task_include.copy()
    assert (task_include.statically_loaded == task_include_copy.statically_loaded)

# Generated at 2022-06-21 01:36:58.560446
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # create a task
    block_ = Block()
    t = TaskInclude(block=block_)
    t.args = {'a': 1, 'b': 2}
    t.vars = {'v': 3}

    # expect the vars to be only the vars in this task
    result = t.get_vars()
    assert result == {'a': 1, 'b': 2, 'v': 3}, "'get_vars' for 'include' task does not return the expected vars"

    # create a task with a play
    play_ = Block()
    block__ = Block(block=play_)
    t = TaskInclude(block=block__)
    t.args = {'a': 1, 'b': 2}
    t.vars = {'v': 3}

    # expect the v

# Generated at 2022-06-21 01:37:09.430801
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    play = Play().load({'name': 'foobar'}, None, variable_manager=variable_manager, loader=loader)
    role = RoleInclude.load(
        {'name': 'foobar'},
        block=play,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )

    task = Task.load(
        {'name': 'foobar'},
        block=play,
        role=role,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )

# Generated at 2022-06-21 01:37:14.161717
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    d = dict(action='include', file='xyz.yml')
    ti = TaskInclude()
    task = ti.load(d)
    assert task.action == 'include'
    assert task._raw_params == 'xyz.yml'
    assert task.args == dict(_raw_params='xyz.yml')


# Generated at 2022-06-21 01:37:24.196506
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.included_file import IncludedFile

    play_context = PlayContext()
    play_context.vars = {'example_var': 'example_value'}
    play_context.included_files = IncludedFile()

    # Test with apply
    data = {'apply': {'name': 'example_name', 'hosts': 'example_hosts', 'vars': {'example_var_in_apply': 'example_value_in_apply'}}}

    task_include = TaskInclude(play=play_context, _loader=None, variable_manager=None)
    task_include = task_include.load_data(data, play_context, None, None)

    p_block = task_include.build_parent_block()


# Generated at 2022-06-21 01:37:36.916282
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook.base_include
    TaskInclude(role=ansible.playbook.base_include.BaseInclude())



# Generated at 2022-06-21 01:37:46.833311
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    class MockTask(object):
        def __init__(self, action="include", args={}):
            self.action = action
            self.args = args

    # Setting up the values we expect to have set by the class constructor
    name_args = {'var_name1': 'var_value1', 'var_name2': 'var_value2'}
    check_args = {'file': 'some/file.yml', '_raw_params': 'some/file.yml'}

    # The task name is the same as the include action, so we expect the name of
    # the TaskInclude to be the same as the other arguments we expect to be set
    task1 = MockTask(args=check_args)
    ti1 = TaskInclude(task_include=task1)

# Generated at 2022-06-21 01:37:58.703273
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # When action is not static
    task_include = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'_raw_params': 'foo', 'non_valid_value': 'bar'}
    with pytest.raises(AnsibleParserError):
        task = task_include.check_options(
            task,
            {'action': 'include', '_raw_params': 'foo', 'non_valid_value': 'bar'}
        )
    # When action is static
    task_include = TaskInclude()
    task = Task()
    task.action = 'include_role'
    task.args = {'_raw_params': 'foo', 'non_valid_value': 'bar'}

# Generated at 2022-06-21 01:38:04.495836
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t = TaskInclude(block=None, role=None, task_include=None)
    assert t.statically_loaded == False
    t.statically_loaded = True

    t2 = t.copy()
    assert t2.statically_loaded == True

    t3 = t.copy(exclude_parent=True)
    assert t3.statically_loaded == True

    t4 = t.copy(exclude_parent=True, exclude_tasks=True)
    assert t4.statically_loaded == True

# Generated at 2022-06-21 01:38:14.828529
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude

    # test without exclude_parent
    play_context = dict(
        become=False,
        become_method=None,
        become_user=None,
        become_flags=None,
        connection='local',
        check=False,
        diff=False,
    )

# Generated at 2022-06-21 01:38:18.863777
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    Task_Include = TaskInclude()
    Task_Include.action = 'include'
    data = {'tags': '', 'when': '', 'include': '', 'action': 'include', 'debugger': ''}
    assert Task_Include.preprocess_data(data) == {'action': 'include', 'include': ''}

# Generated at 2022-06-21 01:38:26.369589
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    global display
    display = Display()

    ti = TaskInclude()
    ti.action = 'include'
    ti.args = {'foo': 'bar'}
    ti.statically_loaded = False
    ti.block = 'block'
    ti.deprecated = False
    ti.tags = ['t1', 't2']
    ti.always_run = False
    ti.notify = {'foo': 'bar'}

    new_me = ti.copy()
    assert new_me is not None
    assert new_me.action == ti.action
    assert new_me.args == ti.args
    assert new_me.statically_loaded == ti.statically_loaded
    assert new_me.block == ti.block
    assert new_me.deprecated == ti.deprecated

# Generated at 2022-06-21 01:38:38.044487
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    d = {'action': 'include', 'file': 'test'}
    d = ti.preprocess_data(d)
    assert set(d.keys()) == {'action', 'file'}

    ti = TaskInclude()
    d = {'action': 'include', 'file': 'test', 'tags': 'test'}
    d = ti.preprocess_data(d)
    assert set(d.keys()) == {'action', 'file', 'tags'}

    ti = TaskInclude()
    d = {'action': 'include_role', 'file': 'test', 'tags': 'test'}
    d = ti.preprocess_data(d)
    assert set(d.keys()) == {'action', 'file', 'tags'}

    ti = TaskInclude()


# Generated at 2022-06-21 01:38:42.816991
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    pb = Block()
    ti = TaskInclude(block=pb)
    ti.statically_loaded = True

    ti_copy = ti.copy()
    assert ti_copy.statically_loaded
    assert pb is ti_copy._parent

# Generated at 2022-06-21 01:38:56.601993
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task_1 = {
        'action': 'import_tasks',
        'file': 'tasks.yml',
        'args': {'action': 'asdf'},
    }
    task_2 = {
        'action': 'import_playbook',
        'file': 'tasks.yml',
        'args': {'apply': {}},
    }
    task_3 = {
        'action': 'include',
        'file': 'tasks.yml',
        'apply': 'not a dict',
    }

# Generated at 2022-06-21 01:39:20.535556
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class TestTaskInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            super(TestTaskInclude, self).__init__(*args, **kwargs)
            self.args['apply'] = {}

    my_play = Play().load({
        'name': 'play',
        'hosts': 'all',
        'tasks': [
            {
                'action': 'include',
                'args': {
                    'file': 'myfile'
                }
            }
        ]
    }, variable_manager=VariableManager(), loader=DataLoader())


# Generated at 2022-06-21 01:39:30.578600
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.role import Role
    from ansible.playbook.role.task_include import TaskIncludeRole
    from ansible.plugins.loader import role_loader

    role = Role()
    role._role_path = role_loader._find_role_paths('test-role-warn-extra-vars')[0]
    role._role_name = 'test_role_warn_extra_vars'

    task_include_role = TaskIncludeRole(block=None, role=role, task_include=None, to_be_taskified=Sentinel)
    task_include_role.action = 'include_role'

# Generated at 2022-06-21 01:39:40.034473
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Unit test for method load of class TaskInclude
    """

    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.tasks import Task as RoleTask
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager

    block_file = """
    - include: "{{ file_1 }}"
      no_log: yes
      ignore_errors: yes
      action: include
      when: morning
      tags: ['morning']
      loop: no
      loop_with: ["ansible", "json"]
      loop_control:
        loop_var: "item"
    """


# Generated at 2022-06-21 01:39:51.451729
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    options = {'verbosity': 3}
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task = TaskInclude.load(dict(
        include='test.yml',
        registering='test',
        action='include'
    ), block=None, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    assert task.get_vars() == {'include': 'test.yml', 'registering': 'test'}

# Generated at 2022-06-21 01:40:01.109808
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Unit test for method build_parent_block of class TaskInclude
    """
    from ansible.playbook import Play, Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import load_plugin
    ansible_playbook_path = load_plugin('action.ansible_playbook')
    playbook = Playbook.load(
        'test_task_include.yml',
        variable_manager=VariableManager(),
        loader=None,
    )
    play = playbook.get_plays()[0]
    play._variable_manager = VariableManager()
    play._variable_manager.set_play_context(PlayContext())
    play._variable_manager.get_vars(play=play)
    play._t

# Generated at 2022-06-21 01:40:09.989858
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Verify that TaskInclude.get_vars misbehaves in the same way as the
    parent Task class.
    """
    ti = TaskInclude()
    ti._parent = ti
    ti.args = {'var1': 'val1'}
    assert ti.get_vars() == {'var1': 'val1'}

    ti = TaskInclude()
    ti.action = 'include'
    ti._parent = ti
    ti.args = {'var1': 'val1'}
    assert ti.get_vars() == {'var1': 'val1'}


# Generated at 2022-06-21 01:40:19.164854
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # data for an action that does not accept include keywords
    test_data1 = {
        'block': [
            {
                'action': 'some_action',
                'task': 'do something',
                'some_action': True,
                'ignore_errors': False,
                'when': ['some_condition']
            }
        ],
        'vars': {
            'name': 'some_name'
        },
        'when': 'some_condition',
    }
    # data for an action that accepts all include keywords

# Generated at 2022-06-21 01:40:28.570238
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = TaskInclude(block=None, role=None, task_include=None)
    task.args = {'apply': {}}
    task._parent = 'test_parent'
    task._variable_manager = 'test_variable_manager'
    task._loader = 'test_loader'
    task._role = 'test_role'
    res = task.build_parent_block()
    assert res.block == []
    assert res._play == 'test_parent'
    assert res._task_include == task
    assert res._role == 'test_role'
    assert res._variable_manager == 'test_variable_manager'
    assert res._loader == 'test_loader'

# Generated at 2022-06-21 01:40:35.953058
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {
        'action': 'task',
        'become': 'no',
        'name': 'test',
        'user': 'test_user'
        }

    # Create an instance of class TaskInclude
    task_include = TaskInclude()
    result = task_include.preprocess_data(ds)
    assert result == ds

# Generated at 2022-06-21 01:40:46.709297
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    pb = Play().load({'name': 'foo', 'hosts': 'all', 'gather_facts': 'no'})
    block = [{'action': 'include', 'include': 'a.yml', 'apply': {}}]
    block = Block.load(block, pb, variable_manager=pb.variable_manager, loader=pb._loader)
    task = block.block[0]
    assert task.build_parent_block().action == 'include'
    assert task.build_parent_block().block == []
    assert task.build_parent_block().handler is None
    assert task.build_parent_block().rescue is None
    assert task.build_parent_block().always is None

# Generated at 2022-06-21 01:41:25.442600
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    tc = Play().load(
        dict(
            name="Test play",
            hosts=['localhost'],
            gather_facts='no'
        ),
        variable_manager=variable_manager,
        loader=loader,
    )
    pc = PlayContext()
    ti = TaskInclude()
    ti._play = tc
    ti._task = Task()
    ti._task._parent = ti

    assert ti._play == tc
    assert ti._task._parent == ti

# Generated at 2022-06-21 01:41:37.348922
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TODO: fix to be more atomic and less dependent on order
    var_manager = DummyVarsModule()
    loader = DummyLoaderModule()

    # invalid action
    data = {
        'action': 'nonsense',
        'file': 'somefile'
    }
    with pytest.raises(AnsibleParserError) as err:
        task = TaskInclude.load(
            data,
            variable_manager=var_manager,
            loader=loader
        )

    assert err.value.message == ("Invalid task attribute: 'nonsense'. "
                                 'The error was: [invalid action (<class \'ansible.parsing.yaml.objects.AnsibleSequence\'>): '
                                 'include, import_role, import_playbook]')

    # valid action

# Generated at 2022-06-21 01:41:42.215008
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    new_ti = ti.copy()
    assert id(new_ti) != id(ti)
    assert isinstance(new_ti, TaskInclude)

    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded == True

# Generated at 2022-06-21 01:41:42.762294
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    assert True

# Generated at 2022-06-21 01:41:51.534756
# Unit test for method load of class TaskInclude

# Generated at 2022-06-21 01:42:01.790806
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    # check_options expects instance attributes of 'block' and 'role' set
    ti.block = None
    ti.role = None

    # check that valid task and options do not raise exceptions
    assert not ti.check_options(
        ti.load_data({
            'include_role': {'name': 'myrole'},
            'apply': {'meta': 'rolemeta'},
        }),
        data={
            'include_role': {'name': 'myrole'},
            'apply': {'meta': 'rolemeta'},
        }
    )

    # check that invalid options raise exceptions regardless of action

# Generated at 2022-06-21 01:42:10.881098
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test TaskInclude.build_parent_block
    '''
    ti = TaskInclude()
    # pylint: disable=protected-access

    # test with no apply arg
    parent_block = ti.build_parent_block()
    assert isinstance(parent_block, TaskInclude)

    # test with apply arg
    ti.args['apply'] = {'block': []}
    parent_block = ti.build_parent_block()
    assert not isinstance(parent_block, TaskInclude)
    assert isinstance(parent_block, Block)
    assert isinstance(parent_block._parent, TaskInclude)

# Generated at 2022-06-21 01:42:19.064375
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Setup
    data = {'action': 'include', 'name': 'dummy_task'}

    ti = TaskInclude(block=None, role=None, task_include=None)
    # Execute and Assert
    try:
        ti.preprocess_data({**data, 'apply': {}})
    except AnsibleParserError as e:
        assert "Invalid options for include: apply" == e.message

    try:
        ti.preprocess_data({**data, 'action': "import_tasks", 'apply': {}})
    except AnsibleParserError as e:
        assert "Invalid options for import_tasks: apply" == e.message

# Generated at 2022-06-21 01:42:30.193877
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    play_vars = dict(
        foo='bar',
    )
    inv_vars = dict()
    inv_data = """
test-group1:
  hosts:
    'test-host1':
    'test-host2':
    'test-host3':
    'test-host4':
"""
    inventory = InventoryManager(loader=loader, sources=inv_data)
    variable_manager = VariableManager(loader=loader, inventory=inventory, variables=play_vars)

    play_context

# Generated at 2022-06-21 01:42:36.349016
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Host(name='127.0.0.1'))

    action = 'include'

    def assert_task_include(dict, file, apply=None):
        data = {action: dict}
        task = TaskInclude.load(
            data=data,
            block=None,
            role=None,
            task_include=None,
            variable_manager=variable_manager,
            loader=loader,
        )
        assert task._load_name == file
        assert task.action == action
        assert task.apply == apply
        assert task.args

# Generated at 2022-06-21 01:43:11.609153
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import copy
    task = dict(action='include', file='vars.yml')
    task_include = TaskInclude()
    result = task_include.check_options(copy.deepcopy(task), dict())

    # Make sure the only option is '_raw_params'
    assert len(result.args.keys()) == 1
    assert result.args['_raw_params'] == 'vars.yml'

    task = dict(action='import_tasks', file='vars.yml', debug='true')

    # No error when include is a proper value for action
    task['action'] = 'include_tasks'
    result = task_include.check_options(copy.deepcopy(task), dict())

    # No error when include_role is a proper value for action
    task['action'] = 'include_role'

# Generated at 2022-06-21 01:43:15.823303
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True

    assert ti.copy() is not ti
    assert ti.copy() != ti

    assert ti.copy().statically_loaded
    assert not ti.copy(exclude_tasks=True).statically_loaded
    assert ti.copy(exclude_parent=True).statically_loaded



# Generated at 2022-06-21 01:43:21.889517
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    my_block = Block()
    my_taskinclude = TaskInclude(block=my_block)
    assert isinstance(my_taskinclude, Block)
    assert my_taskinclude.statically_loaded is False
    assert my_taskinclude.args == {}


# Generated at 2022-06-21 01:43:31.071300
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display = Display()
    display.verbosity = 3

    task = TaskInclude()
    data = dict()

    data = {'action': 'include', 'free_form': 'something'}
    task = task.check_options(task.load_data(data), data)
    assert task.args['free_form'] == 'something'
    assert task.args['_raw_params'] == 'something'

    data = {'action': 'import_tasks', 'free_form': 'something'}
    task = task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == 'something'

    data = {'action': 'import_role', 'free_form': 'something'}
    task = task.check_options(task.load_data(data), data)

# Generated at 2022-06-21 01:43:40.048111
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # All valid args
    # [1] apply is not checked, it is used only with the 'include' action
    data = dict(file='/tmp/playbook.yml', loop=5, loop_with='item', _raw_params='/tmp/playbook.yml', apply=dict(name='foo'))
    task = TaskInclude()
    task.check_options(task.load_data(data), data)
    assert task._attributes == dict(file='/tmp/playbook.yml', loop=5, loop_with='item', _raw_params='/tmp/playbook.yml')

   

# Generated at 2022-06-21 01:43:49.977151
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    test_play = Play().load({'hosts': 'test', 'name': 'test_play'})
    test_play._variable_manager = 'test_variable_manager'
    test_play._loader = 'test_loader'

    test_include = TaskInclude()
    test_include._parent = test_play
    test_include._role = 'test_role'

    test_include.args = {'apply': {'when': 'test_when_apply'}, 'tags': 'test_tags'}
    assert test_include.build_parent_block().args['when'] == 'test_when_apply'


# Generated at 2022-06-21 01:43:52.413346
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    o = TaskInclude(block=None, role=None, task_include=None)
    assert isinstance(o, TaskInclude)
    assert isinstance(o, Task)
    assert hasattr(o, 'action')

# Generated at 2022-06-21 01:43:58.911450
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_block = {
        'when': 'true',
        'name': 'test-block',
        'apply': {
            'when': 'false',
            'name': 'test-apply-block',
        },
    }
    task = TaskInclude.load(test_block)
    result = task.build_parent_block()
    assert result.when == 'false'
    assert result.name == 'test-apply-block'

    test_block = {
        'when': 'true',
        'name': 'test-block',
    }
    task = TaskInclude.load(test_block)
    result = task.build_parent_block()
    assert result.name == 'test-block'
    assert task.args == {}


# Generated at 2022-06-21 01:44:08.977191
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    import ansible.playbook.role.include as role_include
    import yaml
    assert role_include.TaskInclude.load(data=yaml.safe_load("""
    - include: foo
      vars:
        foo: bar
    """)[0]) is not None
    assert role_include.TaskInclude.load(data=yaml.safe_load("""
    - include_role: foo
    """)[0]) is not None
    assert role_include.TaskInclude.load(data=yaml.safe_load("""
    - import_role: foo
    """)[0]) is not None
    assert role_include.TaskInclude.load(data=yaml.safe_load("""
    - include_tasks: foo
    """)[0]) is not None
    assert role_include

# Generated at 2022-06-21 01:44:18.067084
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import mock
    import os
    import tempfile
    from ansible.utils.path import unfrackpath

    def _mock_lookup_loader(self, path):
        if 'include.yml' in path:
            return mock.Mock()
        else:
            return None

    @mock.patch('ansible.plugins.loader.lookup_loader')
    def _unit_test(mock_lookup_loader):
        mock_lookup_loader.side_effect = _mock_lookup_loader

        my_dir = os.path.dirname(os.path.abspath(__file__))
        test_playbook = '%s/../../playbooks/include_playbook.yml' % my_dir
        test_playbook = unfrackpath(test_playbook)

        temp_