

# Generated at 2022-06-21 01:34:53.776874
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Set up a task include with the name attribute set
    data = dict()
    data['name'] = 'test'
    data['_line'] = 1

    variable_manager = VariableManager()
    variable_manager._options = {'verbosity': 0}
    variable_manager._extra_vars = dict(a=1, b=2, c=3, d=4)
    variable_manager._extra_vars = dict(a=1, b=2, c=3, d=4)
    variable_manager._fact_cache = dict(a=1, b=2, c=3, d=4)


# Generated at 2022-06-21 01:35:02.678151
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    role = object()
    task_include = object()

    task = TaskInclude(block=block, role=role, task_include=task_include)
    copied_task = task.copy()

    assert copied_task.statically_loaded == task.statically_loaded
    assert copied_task._parent == task._parent
    assert copied_task._role == task._role
    assert copied_task._task_include == task._task_include
    assert copied_task._dep_chain == task._dep_chain
    assert copied_task._always_run == task._always_run
    assert copied_task._notify == task._notify
    assert copied_task._loop == task._loop
    assert copied_task._run_once == task._run_once
    assert copied_task._tags == task._tags
   

# Generated at 2022-06-21 01:35:09.881153
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    This function tests the load method of class TaskInclude.
    It also checkes if the args file and _raw_params are set correctly
    '''
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task import Task

    test_data = {'include': 'test_file'}
    test_variable_manager = 'test_variable_manager'
    test_loader = 'test_loader'
    ti = TaskInclude()
    ti.args = {'file': 'file 1',
               '_raw_params': 'raw 1',
               'apply': {'l1': 'item1'},
               'bad': 'option',
               'tags': ['tag1', 'tag2'],
               'when': 'True'}

    # Check if a

# Generated at 2022-06-21 01:35:18.166339
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    include_task_vars1 = dict(a='1')
    include_task_vars2 = dict(b='2')
    include_task_vars3 = dict(c='3')
    include_task_vars4 = dict(d='4')
    include_task_vars5 = dict(e='5')
    include_task_vars6 = dict(f='6')

    include_task1 = TaskInclude()
    include_task1.vars = include_task_vars1

    include_task2 = TaskInclude()
    include_task2.vars = include_task_vars2

    include_task3 = TaskInclude()
    include_task3.vars = include_task_vars3

    include_task4 = TaskInclude()
    include_task4.vars

# Generated at 2022-06-21 01:35:30.185310
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Mocked objects
    def mocked_object(id, attrs=None):
        if attrs:
            object = {
                '_%s' % key: value
                for key, value in attrs.items()
            }
        else:
            object = {}

        object.update({
            '__getitem__': lambda self, key: self['_%s' % key],
            '__setitem__': lambda self, key, value: setattr(self, '_%s' % key, value),
            '__contains__': lambda self, key: hasattr(self, '_%s' % key),
            'get_vars': lambda self: {},
            'copy': lambda self, exclude_parent=False, exclude_tasks=False: self
        })
        return object

    # Mocked objects for task

# Generated at 2022-06-21 01:35:32.570543
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    ti = TaskInclude(block=None, role=None, task_include=None)
    assert not ti.statically_loaded

# Generated at 2022-06-21 01:35:43.556692
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler import HandlerTaskInclude
    from ansible.vars.unsafe_proxy import UnsafeProxy

    ti = TaskInclude()
    assert isinstance(ti, TaskInclude)
    assert isinstance(ti, Task)
    assert isinstance(ti, Block)

    try:
        ti2 = TaskInclude(block=ti, task_include=ti)
    except:
        ti2 = None
    assert ti2 is not None


# Generated at 2022-06-21 01:35:51.025223
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    assert TaskInclude.__name__ in ('TaskInclude', 'ansible.playbook.include.TaskInclude')
    assert TaskInclude.BASE == frozenset(('file', '_raw_params'))
    assert TaskInclude.OTHER_ARGS == frozenset(('apply',))
    assert TaskInclude.VALID_ARGS == frozenset(('file', '_raw_params', 'apply'))
    assert TaskInclude.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                                            'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                                            'when'))




# Generated at 2022-06-21 01:36:02.329693
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    We override the parent Task() classes get_vars here because
    we need to include the args of the include into the vars as
    they are params to the included tasks. But ONLY for 'include'
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_context.override_vars = {'a': 'b'}
    play = Play.load('', play_context=play_context)

    b = Block()
    t = TaskInclude()
    t._play = play
    t.args = {'name': 'test'}
    t.vars = {'1': 1, '2': 2}

    # check with 'action' not in C._ACTION_INCLUDE


# Generated at 2022-06-21 01:36:14.829526
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class MockVariableManager:
        def __init__(self, host_vars):
            self.vars_cache = host_vars

        def set_available_variables(self, variables):
            pass

        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True):
            return self.vars_cache

    class MockHost:
        def __init__(self, hostname):
            self.name = hostname

        def get_name(self):
            return self.name

    class MockPlayContext:
        def __init__(self, ansible_host):
            self.transport = 'local'
            self.connection = 'local'
            self.remote_addr = None
            self.remote_user

# Generated at 2022-06-21 01:36:26.803531
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    ti = TaskInclude()
    ti.vars = dict(a=1)
    ti.action = 'action'
    ti.args = dict(b=2)
    ti.block = Block()
    ti.block._role = 'role'
    ti.block._play = Play().load(dict(name='name'), variable_manager=None, loader=None)
    ti.block._play._context = PlayContext()
    ti.block._parent = 'parent'
    ti.block._role = 'role'
    ti.block._loop = 'loop'
    ti.block._loop_with = 'loop_with'
    ti

# Generated at 2022-06-21 01:36:37.723098
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # when action is not in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    d = {'action': 'some-action', 'key': 'value'}
    ti = TaskInclude()
    ti.preprocess_data(d)
    assert d == {'action': 'some-action', 'key': 'value'}

    # when action is in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    d = {'action': 'import_tasks', 'key': 'value'}

    ti = TaskInclude()
    ti.preprocess_data(d)
    assert d == {'action': 'import_tasks', 'key': 'value'}

    d = {'action': 'include_role', 'key': 'value'}
    ti = TaskInclude()


# Generated at 2022-06-21 01:36:47.163141
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import Play, Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources='')
    variable_manager.set_inventory(inventory)

    # the following options should be invalid for the action include_tasks,
    # and we check that the validate_options method
    # raises AnsibleParserError if options are invalid

# Generated at 2022-06-21 01:36:57.957649
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create the objects that contain the data to load into the TaskInclude object
    play_ds = dict(
        name="Ansible Play name",
        hosts=['all'],
        gather_facts='no',
        tasks=[],
    )
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DataLoader())
    play.post_validate(play._ds, play)


# Generated at 2022-06-21 01:37:10.831819
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskIncludeRole
    import ansible.playbook.role
    from ansible.playbook.play_context import PlayContext
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.parser import parse_retval
    from ansible.utils.vars import combine_vars

    class MockInclude(IncludeRole):
        def __init__(self):
            self._role = ansible.playbook.role.RoleInclude()

    class MockTaskInclude(TaskIncludeRole):
        def __init__(self):
            self._role = ansible.playbook.role.RoleInclude()



# Generated at 2022-06-21 01:37:16.989800
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test without apply
    task1 = TaskInclude(block=None)
    p_block = task1.build_parent_block()
    assert p_block == task1

    # test with apply
    task2 = TaskInclude(block=None)
    task2.args = {'apply': 'foo'}
    p_block = task2.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.block == []



# Generated at 2022-06-21 01:37:26.215587
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    task = ti.check_options(ti.load_data({'include': 'file.yml'}, variable_manager=None, loader=None), {'include': 'file.yml'})
    assert isinstance(task, TaskInclude)
    assert 'include' == task.action
    assert 'file.yml' == task.args['_raw_params']
    assert not task.args.get('apply')

    task = ti.check_options(ti.load_data({'include': 'file.yml', 'apply': {'loop': 'all'}}, variable_manager=None, loader=None),
                            {'include': 'file.yml', 'apply': {'loop': 'all'}})
    assert isinstance(task, TaskInclude)
    assert 'include' == task

# Generated at 2022-06-21 01:37:28.985700
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert task_include is not None


# Generated at 2022-06-21 01:37:38.594431
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requiremenst import RoleRequirement

    # test for action 'include'
    i = TaskInclude()
    data = dict(
        action='include'
    )
    res = i.preprocess_data(data)
    assert res == data

    data = dict(
        action='include',
        name='foo',
        bar='baz'
    )
    res = i.preprocess_data(data)
    assert res == dict(
        action='include',
        name='foo'
    )

    # test for action 'include_role'
    i = IncludeRole()

# Generated at 2022-06-21 01:37:44.490191
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 01:38:00.989517
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    test if the method ``build_parent_block`` builds correctly the parent block
    when ``apply`` attribute is specified.
    '''
    loader = unittest.TestLoader()

    ########################
    # Test case when action is ``include_role``
    ########################

    # Data structure
    ds = {'action': 'include_role',
          'apply': {},
          'file': '/foo/bar.yml'}
    variable_manager = VariableManager()
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    variable_manager.set_host_variable('localhost', 'bar', 'baz')

    # Test when ``include_role`` action is used
    # Should not modify the original ``ds``.
    data = ds.copy()

# Generated at 2022-06-21 01:38:10.041132
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Test for constructor of class TaskInclude
    # Create object without parameters
    from ansible.playbook.include import Include
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    obj = TaskInclude()
    assert obj._parent == None
    assert obj._role == None
    assert obj._block == None
    assert obj._dep_chain == None
    assert obj._loop is None
    assert obj._use_conditional is False
    assert obj._always_run is False
    assert obj._any_errors_fatal is False
    assert obj._ignore_errors is False
    assert obj._notify is None
    assert obj._role is None

# Generated at 2022-06-21 01:38:19.679961
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    def _assertions(task, data, except_types=None, except_message=None, raise_error_called=False):
        # assertions
        assert isinstance(task, TaskInclude)
        if except_types is not None:
            if task._exception is not None:
                assert isinstance(task._exception, except_types)
            else:
                assert raise_error_called is True
        if except_message is not None:
            assert except_message in str(task._exception)

    from ansible.errors import AnsibleParserError

    tio = TaskInclude()

# Generated at 2022-06-21 01:38:26.788022
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''Test TaskInclude.build_parent_block()'''
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    ti = TaskInclude()

    ti._variable_manager = None
    ti._loader = None
    ti._play = Play().load({}, variable_manager=None, loader=None)
    ti._play._parent = Play()
    ti._play._play_context = PlayContext()
    ti._play.default_vars = dict()
    ti._tqm = None
    ti._parent = ti
    ti.args = dict(file='file1.yml', tags=['tag1'], when='when1')
    ti._role = None

    p_block = ti.build_parent_block()


# Generated at 2022-06-21 01:38:35.052221
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleParserError
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import module_loader
    from ansible.template import Templar

    #Create the needed objects to create a parent block for the included tasks
    play_context = PlayContext()
    task_vars = dict(foo='foo', bar='bar')
    loader = DataLoader()
    inventory = None
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    #Create the TaskInclude object
    include_task = TaskInclude()

# Generated at 2022-06-21 01:38:39.687780
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude(block=Block())

    # Test instance attributes are not shared between copies
    task2 = task.copy()
    task2.set_loader(None)
    assert task._loader != task2._loader

    # Test private instance attributes are not shared between copies
    task3 = task._copy_self()
    task3._loader = None
    assert task._loader != task3._loader



# Generated at 2022-06-21 01:38:46.129918
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    loader = FakeLoader()
    display = Display()
    variable_manager = VariableManager()
    ti = TaskInclude.load(
        {'include': 'task'},
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader)
    assert 'a' in ti.get_vars()
    assert 'b' in ti.get_vars()
    assert 'c' in ti.get_vars()
    assert 'my_first_var' in ti.get_vars()
    assert 'my_second_var' in ti.get_vars()
    variable_manager.set_nonpersistent_facts(dict(c=1, b=2, a=3))
    assert not ti.get_vars()['a'] == 3

# Generated at 2022-06-21 01:38:56.642218
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook.play
    import ansible.playbook.task

    fake_loader = "fake_loader"
    fake_variable_manager = "fake_variable_manager"

    task = ansible.playbook.task.Task()
    task.action = "included_task"
    task_include = TaskInclude()
    task_include.load( task.dump(), loader=fake_loader, variable_manager=fake_variable_manager )

    assert task_include.action == "included_task"
    assert task_include._loader == fake_loader
    assert task_include._variable_manager == fake_variable_manager

# Generated at 2022-06-21 01:39:01.614961
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    assert 'include' in C._ACTION_ALL_INCLUDE
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.loader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager.set_inventory(inventory)
    host = inventory.get_host(name='localhost')

    block = dict(
        action = 'include',
        block = [],
        args = dict(
            apply = dict(
                block = [],
                name = 'A block of the included tasks'
            )
        ),
        name = 'A included tasks'
    )
    parent_play

# Generated at 2022-06-21 01:39:06.661168
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Test for method load of class TaskInclude
    '''

    # Test for - include: ...
    data01 = dict(
        action='include',
        file='test.yml',
        apply=dict(
            serial=None
        )
    )
    ti01 = TaskInclude.load(data=data01)

    assert isinstance(ti01, TaskInclude)
    assert isinstance(ti01.parent, Block)

    assert ti01.action == 'include'
    assert ti01.args == dict(
        _raw_params='test.yml',
        apply=dict(
            serial=None
        )
    )

    # Test for - include_role: ...

# Generated at 2022-06-21 01:39:17.966936
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # set test data
    ti = TaskInclude()
    d1 = dict()
    d1['action'] = 'include'
    d2 = dict()
    d2['action'] = 'include'
    d2['tags'] = 'mytags'

    # run the method
    assert ti.preprocess_data(d1) == d1
    assert ti.preprocess_data(d2) == d2

# Generated at 2022-06-21 01:39:25.265159
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    with open('test_include_vars.yml') as data_file:
        data = yaml.safe_load(data_file)
    data['block'] = []
    ti = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert isinstance(ti, TaskInclude)

# Generated at 2022-06-21 01:39:37.981533
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    root_task = TaskInclude()
    root_task.args['param1'] = "value1"
    root_task.args['param2'] = "value2"
    root_task._role = None
    root_task._play = None

    block1 = Block()
    block1._parent = root_task
    block1._role = None
    block1._play = None

    play_context = PlayContext()
    block1.vars = {'var1': 'value1', 'var2': 'value2'}
    block1.set_loader()

    block2 = Block()
    block2._parent = block1
    block2._role = None
    block2._play = None

    block1

# Generated at 2022-06-21 01:39:50.661239
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude(block=None, role=None, task_include=None)
    task.action = 'includ'
    data = dict(action='include', file='test.yml')
    my_arg_names = frozenset(data.keys())
    task.args = dict(data)
    task.check_options(task, data)
    assert not my_arg_names.difference(task.VALID_ARGS)

    data = dict(action='include', file='test.yml', debugger='on')
    my_arg_names = frozenset(data.keys())
    task.args = dict(data)
    try:
        task.check_options(task, data)
    except AnsibleParserError as e:
        assert str(e) == 'Invalid options for include: debugger'

    task

# Generated at 2022-06-21 01:40:00.874250
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.parsing.loader import DataLoader

    my_block = Block(parent_block=None, role=None, task_include=None)
    my_task = Task(block=my_block, task_include=None, role=None)

    my_block_dict = dict()

# Generated at 2022-06-21 01:40:12.258084
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = None
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=''))
    play_context = PlayContext()

# Generated at 2022-06-21 01:40:21.469001
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Case - task_include action is 'include'
    class TestTaskInclude(TaskInclude):
        _valid_actions = frozenset(('include',))
        _parent = '_parent'

    test_task_include = TestTaskInclude(block = None)
    test_task_include._parent = 'parent'
    test_task_include.vars = {'k1': 'v1'}
    test_task_include.args = {'k2': 'v2'}

    assert(test_task_include.get_vars() == {'k1': 'v1', 'k2': 'v2', 'tags': 'all', 'when': True})

    # Case - task_include action is something other than 'include'
    class TestTaskInclude(TaskInclude):
        _valid_actions = fro

# Generated at 2022-06-21 01:40:25.207866
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook
    task_include = ansible.playbook.TaskInclude()
    task_include.load_data({"action": "action", "apply" : {"var" : "value"} })


# Generated at 2022-06-21 01:40:38.821311
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()

    # test with action include (include-tasks)
    ds = {'action': 'include', 'file': 'tasks.yml'}
    res = task_include.preprocess_data(ds)
    assert res == ds

    # test with action import_tasks
    ds = {'action': 'import_tasks', 'file': 'tasks.yml'}
    res = task_include.preprocess_data(ds)
    assert res == ds

    # test with action include_role (include-role)
    ds = {'action': 'include_role', 'name': 'foo'}
    res = task_include.preprocess_data(ds)
    assert res == ds

    # test with action import_role

# Generated at 2022-06-21 01:40:47.620652
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    args = {
        "_raw_params": "relative_namespace.yml",
        "apply": {
            "__opts__": {
                "connection": "local",
                "module_name": "apply_all",
                "module_vars": {
                    "foo": "bar"
                }
            },
            "__role_name__": "relative"
        },
    }

    task_include = TaskInclude(block=None, role=None, task_include=None)
    task_include.action = 'include'
    task_include.args = args
    task_include.statically_loaded = True
    task_include.vars = {'foo': 'bar'}
    task_include_copy = task_include.copy()

    assert task_include_copy.action == 'include'
   

# Generated at 2022-06-21 01:41:11.364963
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_data = {'action': 'include_tasks',
                 'args': {'file': 'playbook.yml'}}
    task = TaskInclude.load(task_data)

    # Use a copy of VALID_ARGS to avoid side-effect on the global state
    # of the class TaskInclude in the following loop
    valid_args_copy = TaskInclude.VALID_ARGS.copy()
    for arg in valid_args_copy:
        data = {'action': 'include_tasks', 'args': {arg: 'abcd'}}
        task.check_options(task.load_data(data), data)

    # Expected error on invalid options
    data = {'action': 'include_tasks', 'args': {'invalid': 'option'}}

# Generated at 2022-06-21 01:41:22.599555
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-21 01:41:32.357629
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    t = Task()
    t.vars = dict(a='a')
    t.args = dict(b='b')
    # include no parents/blocks
    assert t.get_vars() == dict(a='a', b='b')
    # include no parents/blocks and action not in C._ACTION_INCLUDE
    t.action='debug'
    assert t.get_vars() == dict(a='a')

    b = Block()
    b.vars = dict(c='c')
    b.args = dict(d='d')

    # include parents/blocks 
    t1 = TaskInclude(block=b)
    t1.vars

# Generated at 2022-06-21 01:41:40.061114
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    ds = dict()
    assert task.preprocess_data(ds) == ds

    ds = dict(vars=dict(a=dict(b=dict(c=1)), d=1))
    assert task.preprocess_data(ds) == ds

    ds['tags'] = ['include']
    assert task.preprocess_data(ds) == ds

    ds['when'] = False
    assert task.preprocess_data(ds) == ds

    ds['loop'] = 'with_items'
    del ds['tags']

    if C.INVALID_TASK_ATTRIBUTE_FAILED:
        with pytest.raises(AnsibleParserError):
            task.preprocess_data(ds)

# Generated at 2022-06-21 01:41:49.358782
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Create a data structure to pass to the method TaskInclude.load
    data = dict()
    data['action'] = 'include'
    data['_raw_params'] = '{{ my_include }}'

    # Create a block to pass the method TaskInclude.load
    block = Block()

    # Create a task_include to pass to the method TaskInclude.load
    task_include = Task()

    # Construct a task from TaskInclude.load
    task = TaskInclude.load(data, block, task_include)

    # Check if the condition is verified
    assert not(task is None)

    # Check if the type of the task constructed is TaskInclude
    assert isinstance(task, TaskInclude)

    # Check if the action of the task constructed is 'include'
    assert task.action == 'include'

    #

# Generated at 2022-06-21 01:42:00.616944
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    test_task_include = TaskInclude()
    test_task_include2 = test_task_include.copy()

    assert test_task_include is not test_task_include2
    assert test_task_include.__class__ == test_task_include2.__class__
    assert test_task_include.__dict__ == test_task_include2.__dict__
    assert test_task_include.args == test_task_include2.args
    assert test_task_include.action == test_task_include2.action
    assert test_task_include.async_val == test_task_include2.async_val
    assert test_task_include.async_seconds == test_task_include2.async_seconds
    assert test_task_include.block == test_task_include2.block
   

# Generated at 2022-06-21 01:42:11.917262
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Tested method: check_options
    # Tested data: all possible valid or invalid combinations of options
    ti = TaskInclude()
    ti.args = {}

    data = {}
    ti.check_options(ti, data)

    data = {'file': 'path/to/file'}
    ti.check_options(ti, data)

    data = {'src': 'path/to/file'}
    ti.check_options(ti, data)

    data = {'file': 'path/to/file', 'apply': {}}
    ti.check_options(ti, data)

    data = {'file': 'path/to/file', 'apply': {'debugger': "on"}}
    ti.check_options(ti, data)


# Generated at 2022-06-21 01:42:21.157276
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class MyTaskInclude(TaskInclude):
        _VALID_ARGS = TaskInclude.VALID_ARGS.union(frozenset(('extra', 'another_extra')))

    data = dict(
        action='my_include',
        extra=dict(a='a'),
        another_extra=dict(b='b')
    )
    task = MyTaskInclude.load(data)
    assert task.args['another_extra']['b'] == 'b'
    assert task.action == 'my_include'

    data = dict(
        action='include',
        extra=dict(a='a'),
        another_extra=dict(b='b')
    )
    task = MyTaskInclude.load(data)
    assert task.args['another_extra']['b'] == 'b'


# Generated at 2022-06-21 01:42:31.353274
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    ti.args = {
        '_raw_params': 'foobar',
        'apply': 'foo',
        'file': 'bar',
        'foo': 'bar',
    }
    ti.validate_options()
    assert len(ti.args) == 2
    assert ti.args['_raw_params'] == 'foobar'
    assert isinstance(ti.args['apply'], dict)
    assert ti.args['apply']['foo'] == 'bar'

    ti.args = {
        '_raw_params': 'foobar',
        'foo': 'bar',
    }
    ti.validate_options()
    assert len(ti.args) == 2
    assert ti.args['_raw_params'] == 'foobar'

# Generated at 2022-06-21 01:42:40.013814
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Function to test TaskInclude.load
    '''
    class TestTaskInclude(TaskInclude):
        _base_class = TaskInclude
        def __init__(self, *args, **kwargs):
            super(TestTaskInclude, self).__init__(*args, **kwargs)
            self.statically_loaded = False

    task = TestTaskInclude.load({
        'include_tasks': '{{ lookup("file", test.yml) }}',
    }, variable_manager=None, loader=None)
    assert isinstance(task, TestTaskInclude)
    assert task.action == 'include_tasks'
    assert task.args['_raw_params'] == '{{ lookup("file", test.yml) }}'


# Generated at 2022-06-21 01:43:43.713020
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Create a TaskInclude instance.
    display.deprecated("Some deprecated")
    task_include = TaskInclude(
        block=None,
        role=None,
        task_include=None,
    )
    task_include.vars = {
        "key1": "value1",
    }
    task_include.args = {
        "key2": "value2",
        "key3": "value3",
    }
    task_include.action = "testAction"
    task_include.statically_loaded = True

    # Create a copy of the TaskInclude instance.
    task_copy = task_include.copy(exclude_parent=False, exclude_tasks=False)
    task_include_copy = task_copy

    # Check if the variables are copied correctly.
    assert task_include_

# Generated at 2022-06-21 01:43:50.918999
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Check the include tasks
    assert TaskInclude.VALID_INCLUDE_KEYWORDS.issuperset(C._ACTION_INCLUDE)

    # Check when there is an extra attribute in the include task
    ds = {'action': 'include', 'foo': 'bar', 'file': 'test.yml'}
    ti = TaskInclude()
    ti.preprocess_data(ds)
    assert len(ds) == 2

    # Check when there is an extra attribute in the import_role task
    ds = {'action': 'import_role', 'foo': 'bar', 'name': 'test'}
    ti = TaskInclude()
    ti.preprocess_data(ds)
    assert len(ds) == 2

    # Check when there is an extra attribute in the include_role task
    d

# Generated at 2022-06-21 01:43:58.548833
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    yaml_data = """
- hosts: localhost
  gather_facts: false
  vars:
    var1: 1
    var2: 2
  tasks:
    - include:
        file: data
    - name: ansible
      include:
        file: data
      vars:
        var1: 1
        var2: 2
"""
    r_data = """
- name: ansible
  vars:
    var1: 1
    var2: 2
- set_fact:
    var3: 3
    var4: 4
- debug:
    var: var1
"""

    tmp_vars = dict(
        hostvars=dict(
            localhost=dict(),
        ),
    )

    # pylint: disable=unused-argument

# Generated at 2022-06-21 01:44:04.751774
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    ti = TaskInclude()
    ti._role = None
    ti._block  = None
    task_data = dict(name='c', file='d')
    task = ti.load(task_data, variable_manager=None, loader=None)
    task.validate()
    assert task.action == 'include'
    assert task.args['file'] == 'd'
    assert task.name == 'c'
    assert task.statically_loaded == False


# Generated at 2022-06-21 01:44:16.121148
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    ti.check_options(ti.load_data({'action': 'include_role', 'file': 'test.yml'}), {'action': 'include_role', 'file': 'test.yml'})
    ti.check_options(ti.load_data({'action': 'include_role', 'file': 'test.yml', 'apply': {}}), {'action': 'include_role', 'file': 'test.yml', 'apply': {}})

    # 'apply' with invalid value

# Generated at 2022-06-21 01:44:28.041462
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.variables.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mock_variable_manager = None
    mock_loader = None
    mock_play = Play.load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        connection='local',
        tasks=[
            dict(action=dict(include=dict(apply='a', loop="b", loop_control="c", loop_with="d", tags="e", when="f", name="g"))),
        ],
    ), variable_manager=mock_variable_manager, loader=mock_loader)

    mock_play_context = PlayContext()

# Generated at 2022-06-21 01:44:30.332629
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    input_block = Block()
    role = None
    task_include = None

    ti = TaskInclude(input_block, role, task_include)

    assert ti.statically_loaded == False



# Generated at 2022-06-21 01:44:37.407159
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # test that a task include can be copied
    ti = TaskInclude()
    ti_new = ti.copy()

    # test that the attribute statically_loaded is a shallow copy
    ti.statically_loaded = True
    assert ti.statically_loaded == ti_new.statically_loaded
    ti.statically_loaded = False
    assert ti.statically_loaded == ti_new.statically_loaded
    ti.statically_loaded = True
    assert ti.statically_loaded == ti_new.statically_loaded