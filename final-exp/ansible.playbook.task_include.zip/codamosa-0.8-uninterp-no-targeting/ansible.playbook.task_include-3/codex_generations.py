

# Generated at 2022-06-21 01:34:53.766047
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.statically_loaded = True
    ti.action = 'include'
    ti.args = dict(a=1, b=2, c=3)
    ti.block = None
    ti.notified_by = ['a', 'b', 'c']
    ti.when = "some_when"
    ti.loop = None
    ti.loop_control = dict(loop_var="loop_var_value")
    ti.delegate_to = "some_delegate_to"
    ti.first_available_file = "some_file"
    ti.include_role = dict(name="some_role_name")
    ti.include_tasks = "some_include_tasks"

# Generated at 2022-06-21 01:34:57.125083
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.constants as C
    import ansible.errors as errors
    import ansible.playbook.attribute as attribute
    import ansible.playbook.task as task
    import ansible.utils.display as display
    import ansible.utils.sentinel as sentinel

    # TODO: needs to be implemented
    pass

# Generated at 2022-06-21 01:35:04.853473
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    test_block = {
        'name': 'test_block',
        'task_list': [
            {
                'name': 'test_task',
                'include_role': {
                    'name': 'test_role',
                    'apply': {
                        'name': 'test_apply',
                        'block': {
                            'name': 'test_apply_block',
                            'task_list': [
                                {'name': 'test_apply_block_task'}
                            ]
                        }
                    }
                }
            }
        ]
    }
    play = Play.load(test_block)
    task = play.tasks[0].block.block[0].task_list[0]
    parent_block = task.build_parent_block()

# Generated at 2022-06-21 01:35:15.071888
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-21 01:35:27.058546
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class MyTaskInclude(TaskInclude):
        _mock_parents = []
        _mock_roles = []
        _mock_vars = []
        def __init__(self, parent=None, role=None, vars=None, apply=None):
            super(MyTaskInclude, self).__init__()
            self._mock_parents.append(parent)
            self._mock_roles.append(role)
            self._mock_vars.append(vars)
            if apply is not None:
                self.args['apply'] = apply
        def get_vars(self):
            return self._mock_vars.pop()

# Generated at 2022-06-21 01:35:38.684503
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # pylint: disable=too-many-function-args
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Template
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-21 01:35:48.030295
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class MockTaskInclude(TaskInclude):
        def load_data(self, ds):
            return ds

    ds = dict(handler=dict(name='fake_handler',
                           tags=['t1', 't2'],
                           vars=dict(var1='v1', var2=dict(k1='v1'))))
    ti = MockTaskInclude()
    ds_ref = dict(handler=dict(name='fake_handler',
                               tags=['t1', 't2'],
                               vars=dict(var1='v1', var2=dict(k1='v1'))))
    assert ti.preprocess_data(ds) == ds_ref


# Generated at 2022-06-21 01:35:54.608887
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    loader = None
    variable_manager = None
    task_include = TaskInclude()

    # Test getting variables from the parent Task
    from ansible.playbook.task import Task
    parent_task = Task()
    parent_task._parent = Block()
    parent_task._parent._parent = Block()
    parent_task._parent._parent._parent = Block()
    parent_task.vars = {'foo': 'bar', 'as': 'df'}
    parent_task.args = {'g': 'h'}
    task_include._parent = parent_task
    task_include.action = 'include'
    task_include.vars = {'q': 'w'}
    task_include.args = {'e': 'r'}
    task_include.tags = ['first', 'second']
    task_

# Generated at 2022-06-21 01:36:04.908640
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    test_block = Block()
    test_block.block = ['hello']
    test_TaskInclude = TaskInclude(block=test_block)
    test_TiTask = Task()
    test_TiTask.task_include = test_TaskInclude
    test_Block = Block()
    test_Block.block = ['hello']
    test_Block.parent_block = test_TiTask
    test_TaskInclude.statically_loaded = True
    test_TaskInclude.args = {'foo': 'bar'}
    test_TaskInclude._block = test_Block
    test_TaskInclude2 = test_TaskInclude.copy(exclude_parent=True, exclude_tasks=False)
    assert (test_TaskInclude2.statically_loaded == True)

# Generated at 2022-06-21 01:36:16.001280
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.handler import Handler

    # Load playbook

# Generated at 2022-06-21 01:36:27.084786
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Condition when action is not of type "include"
    try:
        class fake_parent:
            def get_vars(self):
                pass

        class fake_task_include(TaskInclude):
            def __init__(self):
                self.action = "Fake_action"
                self.args = {"_raw_params": "", "my_arg": "my_arg_value"}
                self._parent = fake_parent()

        my_task_include = fake_task_include()
        my_task_include.get_vars()
    except Exception as e:
        assert False, "Expected no exception, got %s" % str(e)

    # Condition when include action and _parent is not of type Block

# Generated at 2022-06-21 01:36:37.827561
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for method build_parent_block of class TaskInclude
    '''
    my_task = TaskInclude()
    my_block = Block(name="my_block", parent=my_task)
    my_task._parent = my_block
    # test normal execution
    result = my_task.build_parent_block()
    assert result == my_task
    # test normal execution with apply
    my_task.args["apply"] = {
        "name": "test",
        "when": "test",
        "block": []
    }
    result = my_task.build_parent_block()
    assert result != my_task
    assert isinstance(result, Block)
    assert result.name == "test"
    assert result.when == "test"
    assert result.block is not None


# Generated at 2022-06-21 01:36:47.201368
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    TaskInclude.load({
        'include': 'some_file.yml',
        'action': 'include',
    })

    TaskInclude.load({
        'include': 'some_file.yml',
        'action': 'include',
        'tags': ['include_tags']
    })

    TaskInclude.load({
        'include': 'some_file.yml',
        'action': 'include',
        'when': 'some_condition'
    })

    TaskInclude.load({
        'include': 'some_file.yml',
        'action': 'include',
        'other_option': 'some_value'
    })

    TaskInclude.load({
        'include': 'some_file.yml',
        'action': 'include',
        'apply': {}
    })

   

# Generated at 2022-06-21 01:36:57.957575
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    This method tests the TaskInclude's check_options method and it's
    implementation in the HandlerTaskInclude class.
    '''
    from ansible.playbook.task_include import HandlerTaskInclude

    # test for TaskInclude class
    task = TaskInclude()
    # test for an action that accepts only '_raw_params'
    task_arg = {'_raw_params': 'file'}
    task1 = task.check_options(task, task_arg)
    assert task1.args == task_arg
    # test for an action that accepts other valid parameters
    task_arg = {'_raw_params': 'file', 'apply': 'apply_attrs'}
    task2 = task.check_options(task, task_arg)
    assert task2.args == task_arg

    #

# Generated at 2022-06-21 01:36:59.304988
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-21 01:37:04.479557
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    # Test with empty arg
    task_include = TaskInclude()
    assert task_include is not None

    # Test with invalid arg
    try:
        TaskInclude(None)
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False

# Test the load function of class TaskInclude

# Generated at 2022-06-21 01:37:13.955240
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-21 01:37:24.021392
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''Test TaskInclude.check_options()'''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import HandlerTaskInclude
    # test for TaskInclude.check_options
    # check for TaskInclude.VALID_ARGS
    assert TaskInclude.VALID_ARGS == frozenset(('file', '_raw_params', 'apply'))
    # check for TaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-21 01:37:36.169695
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block

    ti = TaskInclude(block=Block())

    # invalid options
    invalid_options = {
        'a': 'A',
        'b': 'B',
    }
    data = {
        'tasks': [
            {
                'include': invalid_options,
            }
        ]
    }
    task = {
        'action': 'include',
        'args': invalid_options,
        'include': invalid_options,
    }

    for action in C._ACTION_ALL_INCLUDE_TASKS:
        task['action'] = action
        try:
            ti.check_options(task, data)
        except AnsibleParserError:
            pass

# Generated at 2022-06-21 01:37:43.654397
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = dict(
        action='include_role',
        file='test.yml'
    )
    context = dict(
        ignore_errors=True
    )
    task_include = TaskInclude.load(
        data=data,
        variable_manager=None,
        loader=None,
    )

    assert task_include.action == 'include_role'
    assert task_include.args == dict(ignore_errors=True, file='test.yml')



# Generated at 2022-06-21 01:38:03.307426
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import sys
    import os
    import shutil

    fd, test_path = tempfile.mkstemp()
    os.close(fd)

    test_data = {
        'raw_params': 'test_path',
        'apply': {'tags': ['test_tag']},
    }

    test_TaskInclude_instance = TaskInclude.load(
        test_data,
        task_include=None,
        role=None,
        block=None,
    )

    test_parent_block = test_TaskInclude_instance.build_parent_block()

    try:
        assert test_parent_block.tags == ['test_tag']
    except AssertionError:
        sys.stdout.write("TaskInclude.build_parent_block test failed")
        sys.exit(1)
   

# Generated at 2022-06-21 01:38:12.775096
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()

    with pytest.raises(AnsibleParserError):
        ti.load(data={'action': 'include_tasks', 'file': 'f', 'apply': 's'},
                variable_manager=dict(), loader=dict())
    with pytest.raises(AnsibleParserError):
        ti.load(data={'action': 'include_tasks', 'file': 'f', 'something': 's'},
                variable_manager=dict(), loader=dict())
    with pytest.raises(AnsibleParserError):
        ti.load(data={'action': 'include_tasks'},
                variable_manager=dict(), loader=dict())

# Generated at 2022-06-21 01:38:25.289252
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # Invalid case with the action 'import_role'
    data = {
        'action': 'import_role',
        'file': 'test.yml',
        'apply': {'matter': 'Test'},
    }

    try:
        task = TaskInclude.load(data)
        assert False
    except AnsibleParserError as e:
        assert e.message == 'Invalid options for import_role: apply'

    # Invalid case with the action 'import_tasks'
    data = {
        'action': 'import_tasks',
        'file': 'test.yml',
        'apply': {'matter': 'Test'},
    }


# Generated at 2022-06-21 01:38:34.343587
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    user = os.environ.get('USER', 'someuser')
    display.verbosity = 3
    task = ansible.playbook.task.Task()
    task._role = None
    task._parent = None
    task.vars = dict()
    task.args = dict(a="A", b="B")
    task.action = "include"
    assert task.get_vars() == dict(a="A", b="B")
    task._parent = ansible.playbook.block.Block()
    task._parent.vars = dict(c="C")
    assert task.get_vars() == dict(c="C", a="A", b="B")
    task._parent._parent = ansible.playbook.play.Play()
    task._parent._parent.vars = dict(d="D")


# Generated at 2022-06-21 01:38:42.462795
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Tests for TaskInclude.build_parent_block()
    - generates a proper parent block for each case of apply
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    import ansible.constants as C
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    ti = TaskInclude()
    ti.vars = dict()
    ti.action = 'include'
    ti.args = dict()

    # create a mock play, task and block
    task = Task()
    task.action = 'mock'
    task.args = dict

# Generated at 2022-06-21 01:38:56.579504
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Scenario 1: include_tasks and include_role
    # No 'include' in key, value is a string
    data_1_1 = dict(action='include_tasks', file='/path/to/tasks/main.yml')
    ds_1_1 = TaskInclude.load(data_1_1)
    preprocess_data_1_1 = ds_1_1.preprocess_data(data_1_1)
    display.debug('ds_1_1: %s\n preprocess_data_1_1: %s\n' % (str(ds_1_1), str(preprocess_data_1_1)))
    assert preprocess_data_1_1 == dict(action='include_tasks', file='/path/to/tasks/main.yml')

   

# Generated at 2022-06-21 01:39:09.509772
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.statically_loaded = True
    ti.role = True
    ti.task_include = True
    ti._parent = True
    ti._role = True
    ti._task_include = True
    ti._loader = True
    ti._variable_manager = True
    ti.action = 'include'
    ti.args = dict()
    ti.block = 'block'
    ti.changed_when = True
    ti.deprecate_msg = True
    ti.delegate_to = True
    ti.become = True
    ti.become_method = True
    ti.become_user = True
    ti.environment = True
    ti.failed_when = True
    ti.always_run = True

# Generated at 2022-06-21 01:39:11.445420
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # TaskInclude is not a standalone object so don't test with it
    pass

# Generated at 2022-06-21 01:39:16.015541
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Test for constructor of class TaskInclude
    '''
    task = TaskInclude()
    assert not task.args
    assert task.action in C._ACTION_INCLUDE_TASKS
    assert task._attributes

# Generated at 2022-06-21 01:39:20.305047
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.block == None
    assert ti.role == None
    assert ti.task_include == None

# Generated at 2022-06-21 01:39:38.925821
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task = TaskInclude()
    assert task

# Generated at 2022-06-21 01:39:50.963420
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # check valid options
    task = ti.check_options(Task(), {'action': 'include', 'apply': {}, 'file': 'test'})
    assert isinstance(task, Task)
    assert task.action == 'include'
    assert task.args.get('file') == 'test'
    assert isinstance(task.args.get('apply'), dict)

    # check invalid options
    try:
        task = ti.check_options(Task(), {'action': 'include', '_bad_opt': 'test'})
        raise AssertionError('AnsibleParserError not raised')
    except AnsibleParserError as exc:
        assert 'Invalid options for include' in str(exc)

    # check 'apply' option for wrong action

# Generated at 2022-06-21 01:40:00.950124
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-21 01:40:12.298328
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    data = {u'action': u'include_role', u'name': u'common', u'tags': [u'foo']}

    # Test with valid data
    # action will be changed to include_role
    task = TaskInclude.load(data, variable_manager=None, loader=None)
    assert task.action == 'include_role'
    assert task.tags == ['foo']

    # Test with invalid data
    data[u'foo'] = u'bar'
    # action will be changed to include_role
    task = TaskInclude.load(data, variable_manager=None, loader=None)
    assert task.action == 'include_role'
    assert task.tags == ['foo']

    # Test with invalid data
    data[u'action']

# Generated at 2022-06-21 01:40:21.508512
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager as TQM

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    #from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    #inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=None)


# Generated at 2022-06-21 01:40:30.454672
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockVariableManager(object):
        def __init__(self, loader):
            pass

    class MockLoader(object):
        def __init__(self, basedir, variable_manager):
            pass

    def _assert_TaskInclude_checks(include_type, data, exception_message, exception_obj=None):
        varmgr = MockVariableManager(loader=MockLoader(basedir='/', variable_manager=varmgr))
        loader = MockLoader(basedir='/', variable_manager=varmgr)
        task = TaskInclude.TaskInclude(
            block=None,
            role=None,
            task_include=None
        )


# Generated at 2022-06-21 01:40:38.273986
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    method_to_test = TaskInclude()
    assert method_to_test.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                                               'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout',
                                                               'vars', 'when'))

# Generated at 2022-06-21 01:40:42.814487
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    # Create a TaskInclude
    task_include = TaskInclude()
    task_include._variable_manager = VariableManager()

    # Create a Host with specific vars
    host = object()
    host.get_name = lambda: 'test_host'
    host_vars = dict(
        host = 'localhost',
        port = 1234,
    )

# Generated at 2022-06-21 01:40:48.654144
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # pylint: disable=no-member
    data = {'action': 'include', 'file': 'my/file.yml'}
    ti = TaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    task = data
    task = ti.check_options(task, data)
    assert task == {'action': 'include', '_raw_params': 'my/file.yml'}

# Generated at 2022-06-21 01:40:59.745690
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test the method preprocess_data of class TaskInclude. We test that we can obtain the task name
    and the loop keyword after this preprocessing.
    '''
    import ansible.playbook.task_include as task_include
    import ansible.utils.display as display
    #We initialize the object with task name and loop keyword
    t = task_include.TaskInclude(block=None, role=None, task_include=None, name='include task', loop=['a','b','c'])
    #We have a dictionary with a name that does not correspond to a attribute of the TaskInclude class
    ds = {'name':'include_task', 'c':[1,2,3]}
    res = t.preprocess_data(ds)
    #We check that the valid attribute name appears in the result
   

# Generated at 2022-06-21 01:41:43.799951
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play_context
    from ansible.parsing.dataloader import DataLoader
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DataLoader()

    mock_loader = DictDataLoader({
        "/path/to/project/group_vars/all": """
        var1: all
        var2: all
        """,
        "/path/to/project/host_vars/host1": """
        var1: host1
        var2: host1
        """,
        "/path/to/project/host_vars/host2": """
        var1: host2
        var2: host2
        """,
    })

# Generated at 2022-06-21 01:41:52.386726
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import TaskInclude
    from ansible.playbook import Task
    from ansible.playbook.task_include import TaskInclude

    task = Task()
    task.args = {'_raw_params': 'file1.yml', 'toto': 1}
    task.action = 'include'
    new_task = TaskInclude.check_options(task, task)
    assert not new_task.args.get('toto') and new_task.args.get('_raw_params')

    task = Task()
    task.args = {'_raw_params': 'file2.yml', 'apply': 'bug'}
    task.action = 'import_tasks'

# Generated at 2022-06-21 01:41:55.246792
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # class is tested by `test_playbook_compatability` here as it is used there and
    #  `TestPlaybook` has more mocking available
    pass

# Generated at 2022-06-21 01:42:04.349891
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # define some data needed to create an instance of the TaskInclude class
    data = {'action': 'include'}

    # create an instance of the TaskInclude class and pass the data
    task = TaskInclude.load(data)

    # test the method 'check_options'
    # check if the invalid options of a task raises an exception
    data['invalid_options'] = 'invalid options'

    # call the method and pass data to test the exception 'AnsibleParserError'
    try:
        task = TaskInclude.load(data)
    except AnsibleParserError:
        pass

# Generated at 2022-06-21 01:42:15.212020
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-21 01:42:28.232535
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import os
    import sys
    import ansible.constants as C
    from unittest.mock import MagicMock

    class MockDataloader():
        def __init__(self):
            self.loaders = {}

    class MockInventory():
        def __init__(self):
            self.hosts = []
            self.groups = []

    class MockVariablemanager():
        def __init__(self, inventory):
            self.inventory = inventory

    class MockContext():
        def __init__(self, task, block=None, role=None, task_include=None):
            self._loader = MockDataloader()
            self._variable_manager = MockVariablemanager(MockInventory())
            self._role = role
            self._task_include = task_include
            self._block = block

   

# Generated at 2022-06-21 01:42:35.427484
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_attrs  = {'block': []}
    task = Task(block=Block(task_include=TaskInclude(args={'apply': apply_attrs})))
    p_block = task.args['apply'].build_parent_block()
    assert 'TaskInclude' == p_block.__class__.__name__, "build_parent_block should return a TaskInclude object"

# Generated at 2022-06-21 01:42:37.770290
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude(block=None, role=None, task_include=None)
    assert ti != None

# Generated at 2022-06-21 01:42:44.713686
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    This method tests if build_parent_block method of TaskInclude class returns a Block
    while apply without loop_control is passed as argument
    """
    task_include = TaskInclude()
    task_include.args = {'apply': {'block': []}}
    parent_block = task_include.build_parent_block()
    assert isinstance(parent_block, Block)


# Generated at 2022-06-21 01:42:45.563536
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-21 01:44:04.580865
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.constants as C

    # test case 1: included with apply to 'all'
    hosts = ['localhost']

# Generated at 2022-06-21 01:44:14.120186
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude.
    '''
    action = 'include'
    data = {'file': 'file', '_raw_params': '_raw_params'}

    # Define TaskInclude object
    task_include = TaskInclude()

    # Run test function
    task = TaskInclude.load(data, task_include=task_include, loader=None)

    # Check results
    assert task.action == action



# Generated at 2022-06-21 01:44:24.817413
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    a = TaskInclude()
    a.statically_loaded = True
    b = a.copy()
    b.statically_loaded = False
    assert a.statically_loaded == True
    assert b.statically_loaded == False
    b.statically_loaded = True
    c = a.copy()
    assert a.statically_loaded == True
    assert b.statically_loaded == True
    assert c.statically_loaded == True

# Generated at 2022-06-21 01:44:37.407379
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display = Display()
    display.verbosity = 1
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task

    test_play_path = os.path.join(os.path.dirname(__file__), 'data/play_include_pre.yml')
    test_play = ansible.playbook.play.Play().load(test_play_path, variable_manager=ansible.vars.VariableManager(), loader=ansible.parsing.dataloader.DataLoader())
    test_play.post_validate(templar=ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader()))

    assert len(test_play._tasks) == 2
    assert test_play._tasks