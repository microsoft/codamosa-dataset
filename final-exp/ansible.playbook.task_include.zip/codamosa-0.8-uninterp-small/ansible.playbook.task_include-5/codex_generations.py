

# Generated at 2022-06-25 06:16:02.335570
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    input_dict = {'action': 'include_role', 'name': '', 'async': 10, 'poll': 15}
    expected_result = {'action': 'include_role', 'name': '', 'poll': 15}
    output_dict = task_include.preprocess_data(input_dict)
    assert output_dict == expected_result



# Generated at 2022-06-25 06:16:11.861076
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    for action_name in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS:
        task_include_0 = TaskInclude(None, None)

        task_dict_0 = dict({})
        task_dict_0['action'] = action_name
        task_dict_0['args'] = dict([('file', 'file_0')])
        task_dict_0['when'] = 'when_1'
        task_dict_0['async'] = 100
        task_dict_0['async_poll_interval'] = 100
        task_dict_0['async_status_poll'] = 100
        task_dict_0['delegate_to'] = 'delegate_to_2'

# Generated at 2022-06-25 06:16:21.346774
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_host = Sentinel('host', 'host', 'host')
    test_block = Sentinel('block', 'block', 'block')
    test_task = TaskInclude()
    test_task.action = 'include'

    assert test_task.get_vars() == {}

    test_task._parent = test_block
    test_block._play = test_host
    test_host.get_vars.return_value = {'test_host_var': 'value'}
    test_task.vars = {'test_task_var': 'value'}
    test_task.args = {'test_task_args': 'value'}


# Generated at 2022-06-25 06:16:27.475159
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.args = dict()
    task_include_0.action = 'include'
    task_include_0.tasks = list()
    task_include_0.post_validate()
    task_include_0.copy(exclude_parent=True)
    assert task_include_0.preprocess_data(dict()) == dict()

# Generated at 2022-06-25 06:16:32.459049
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()

    # test with no args
    block_instance = task_include.build_parent_block()
    assert block_instance is task_include

    # test with apply attrs
    apply_dict = {'name': 'foobar'}
    task_include.args['apply'] = apply_dict
    block_instance = task_include.build_parent_block()
    assert isinstance(block_instance, Block)
    assert block_instance.name == apply_dict['name']



# Generated at 2022-06-25 06:16:35.767516
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    # Try to run get_vars method against class TaskInclude without
    #   an action set
    #
    try:
        task_include_0.get_vars()
    except AnsibleError as e:
        assert type(e) == AnsibleError
    else:
        raise AssertionError()


# Generated at 2022-06-25 06:16:39.100221
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    # Testing with valid block
    block_data = {'block': [], 'name': 'include', 'action': 'include', 'args': {'file': 'roles.yml'}}
    result = task_include.preprocess_data(block_data)
    assert result == block_data


# Generated at 2022-06-25 06:16:44.902362
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.sentinel import Sentinel
    task_1 = TaskInclude()
    task_1.action = 'include_role'
    test_data = AnsibleMapping(
        'test',
        'test', {
            'include_role': 'apache',
            'tags': ['install'],
            'when': 'ansible_os_family == "RedHat"'
        },
    )
    processed_data = task_1.preprocess_data(test_data)
    assert(type(processed_data) == dict)
    assert('tags' in processed_data.keys())
    assert(type(processed_data['tags']) == list)
    assert('when' in processed_data.keys())

# Generated at 2022-06-25 06:16:55.418412
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    tc0 = TaskInclude.load({'action': 'include',
                            'args': {
                                'file': 'some-file',
                                'apply': {
                                    'tags': ['sometag'],
                                },
                            }})
    tc1 = TaskInclude.load({'action': 'include',
                            'args': {
                                '_raw_params': 'some-file',
                            }})
    tc2 = TaskInclude.load({'action': 'meta',
                            'args': {
                                'somekey': 'some-file',
                            }})
    tc3 = TaskInclude.load({'action': 'include',
                            'args': {
                                '_raw_params': 'some-file',
                                'apply': [],
                            }})
   

# Generated at 2022-06-25 06:17:05.687156
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    data = dict(
        apply = dict(
            tags = ['test_taskInclude_build_parent_block']
        ),
        action = 'include',
        file = 'unit_tes.yml'
    )
    
    task_include = TaskInclude()
    task_include.load(data)

    assert isinstance(task_include.build_parent_block(), Block)
    assert task_include.build_parent_block().block[0].action == 'include'
    assert task_include.build_parent_block().block[0].args['file'] == 'unit_tes.yml'
    assert task_include.build_parent_block().args['tags'][0] == 'test_taskInclude_build_parent_block'


# Generated at 2022-06-25 06:17:19.647275
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.action = "include"

    task_include_2 = TaskInclude()
    task_include_2.action = "include_role"

    task_include_3 = TaskInclude()
    task_include_3.action = "import_tasks"

    task_include_4 = TaskInclude()
    task_include_4.action = "include_tasks"

    assert task_include_1.get_vars() == task_include_2.get_vars() == task_include_3.get_vars() == task_include_4.get_vars()



# Generated at 2022-06-25 06:17:25.749372
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.args = {'tags': ['test_tag'], 'when': 'test_when', 'test_var': 'test_value'}
    task_include_1._parent = None
    task_include_1.vars = {'tags': ['test_tag'], 'when': 'test_when'}
    task_include_1.action = 'include'
    task_include_1.statically_loaded = False
    res_get_vars = task_include_1.get_vars()
    assert res_get_vars == {'tags': ['test_tag'], 'when': 'test_when', 'test_var': 'test_value'}

# Test case for method TaskInclude.check_options

# Generated at 2022-06-25 06:17:31.624366
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude(task_include=Sentinel())
    ti.action = 'include'
    ti.args = dict(var1='abc', var2={'a':'b'})
    ti._parent = TaskInclude()
    ti._parent.vars = dict(var1=1, var2=2)
    assert 'var1' in ti.get_vars()
    assert 'var2' in ti.get_vars()
    assert len(ti.get_vars()) == 2

if __name__ == '__main__':
    test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:17:41.026395
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    print("Test get_vars")

    # Init
    task_include = TaskInclude()

    # create variables and put them into task_include.vars
    vars = dict()
    vars['var1'] = "Foo"
    vars['var2'] = 2
    vars['var3'] = 3.14
    vars['var4'] = [1, 2]
    vars['var5'] = (1, 2)
    vars['var6'] = {'a': 1, 'b': 2}
    task_include.vars = vars

    # create the args and put them into task_include.args
    args = dict()
    args['arg1'] = "Bar"
    args['arg2'] = 3
    args['arg3'] = 3.1415
    args['arg4']

# Generated at 2022-06-25 06:17:46.142747
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_include_1.vars = {}
    task_include_1.args = {'foo': 'bar', '_raw_params': 'file.yml', 'invalid': 'bar'}
    task_include_1.action = 'include'
    with pytest.raises(AnsibleParserError) as e:
        task_include_1.check_options(task_include_1, 'data')
    assert task_include_1.args['_raw_params'] == 'file.yml'
    assert 'invalid' in e.value.message


# Generated at 2022-06-25 06:17:48.888639
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    obj = TaskInclude()
    obj._parent = object()
    obj.vars = dict()
    obj.args = dict()
    obj.action = 'handler'
    actual = obj.get_vars()
    expected = dict()
    obj.action = 'include'
    actual = obj.get_vars()
    expected = dict()

# Generated at 2022-06-25 06:17:58.131304
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    f = FieldAttribute(name='file',
                           include_in=['all'],
                           required=False,
                           default=None,
                           private=True,
                           aliases=['src', 'name'],
                           attr_class=dict,
                           always_post_validate=True,
                           rstrip=False)
    apply_ti = TaskInclude(task_include=ti)

# Generated at 2022-06-25 06:18:08.610548
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args = dict()
    task_include.args['arg1'] = 'val1'
    task_include.action = 'include'
    parent = Block()
    parent.vars = dict()
    parent.vars['var1'] = 'var_val1'
    task_include._parent = parent
    task_include.vars = dict()
    task_include.vars['arg1'] = 'val1'
    task_include.vars['var2'] = 'var_val2'
    expected_result = dict()
    expected_result['arg1'] = 'val1'
    expected_result['var1'] = 'var_val1'
    expected_result['var2'] = 'var_val2'
    result = task_include.get_v

# Generated at 2022-06-25 06:18:15.929593
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test no attributes
    include_data = {}
    task_include = TaskInclude.load(include_data)
    p_block = task_include.build_parent_block()
    assert p_block is task_include

    # Test 'apply' attribute
    apply_attrs = {'apply': {}}
    task_include = TaskInclude.load(apply_attrs)
    p_block = task_include.build_parent_block()
    assert not p_block is task_include
    assert p_block.apply is not None
    assert p_block.block is not None
    assert len(p_block.block) == 0


# Generated at 2022-06-25 06:18:23.010534
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args = {'a':1,'b':2}
    task_include_0.args.pop('a')
    task_include_0.args.pop('b')
    assert task_include_0.build_parent_block() == task_include_0

if __name__ == '__main__':
    test_case_0()
    test_TaskInclude_build_parent_block()

# Generated at 2022-06-25 06:18:30.557477
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    test = TaskInclude()
    test.load({
        'action': 'something',
        'file': 'something',
        'bar': 'something',
        'foobar': 'something',
    }, None, None, None)


# Generated at 2022-06-25 06:18:32.231117
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    blocking_task_include = TaskInclude.load(dict(action='include'))
    blocking_task_include.get_vars()



# Generated at 2022-06-25 06:18:41.487900
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()
    variable_manager._options_vars = dict()

    play_context = PlayContext()

    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-25 06:18:48.373358
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = "include"
    task_include___00 = dict(a=None, b=None)
    task_include_0.vars = task_include___00
    task_include__00 = dict(a=None, b=None)
    task_include_0.args = task_include__00

    result = task_include_0.get_vars()

    assert isinstance(result,dict)
    assert result == {'a': None, 'b': None}

# Generated at 2022-06-25 06:18:57.430234
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    #
    # Make sure that 'apply' args are handled properly
    #
    # input args
    task_data = dict()
    task_data["apply"] = dict()
    task_data["apply"]["block"] = []
    task_data["apply"]["apply_filter"] = "one"
    task_data["apply"]["when"] = "two"
    # task_data["apply"]["loop"] = "three"
    # task_data["apply"]["loop_control"] = "four"
    # task_data["apply"]["loop_with"] = "five"

    # expected result
    expected_result = dict()
    expected_result["block"] = []
    expected_result["apply_filter"] = "one"
    expected_result["when"] = "two"
    # expected_

# Generated at 2022-06-25 06:19:05.572538
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Note: This test assumes the following include (untested)
    # include: /path/to/tasks/main.yml tags=foo_tag
    task_include_0 = TaskInclude()
    task_include_0.args['tags'] = 'foo_tag'
    task_include_0.args['_raw_params'] = '/path/to/tasks/main.yml'
    assert task_include_0.get_vars()['tags'] == 'foo_tag'

# Generated at 2022-06-25 06:19:10.856884
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task_include.args = {'file': "playbook-0.yml", 'ignore_errors': True}
    task_include.action = 'include'
    task_include.check_options(task_include, {})
    assert ("file" in task_include.args)
    assert ("_raw_params" in task_include.args)
    assert ("ignore_errors" in task_include.args)


# Generated at 2022-06-25 06:19:15.927964
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    test_data_0 = {'action': 'include', 'key': 'value'}
    result = task_include_0.check_options(task_include_0, test_data_0)
    assert result.args == {'key': 'value'}
    assert result._task.args == {'key': 'value'}
    assert result.action == 'include'

# Generated at 2022-06-25 06:19:22.236532
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_data = {'file': 'some_file'}
    task_include_1 = TaskInclude.load(task_include_data)
    print ("task_include_1.args==%s" % task_include_1.args)
    assert task_include_1.args['_raw_params'] == 'some_file'


# Generated at 2022-06-25 06:19:23.964024
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    assert task_include_0.load() != None

# Generated at 2022-06-25 06:19:37.238010
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Verify that get_vars method of class TaskInclude returns a dict
    task_include_dict = TaskInclude.get_vars(task_include_0)
    assert isinstance(task_include_dict, dict)
    # Verify that get_vars method of class TaskInclude returns a type of AnsibleParserError when a key is a invalid attribute
    task_include_error = TaskInclude.get_vars(task_include_dict['invalid attribute'])
    assert issubclass(task_include_error.__class__, AnsibleParserError)
    assert isinstance(task_include_error, AnsibleParserError)


# Generated at 2022-06-25 06:19:40.774378
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict()
    ti = TaskInclude()
    ti.check_options(ti, data)

# Generated at 2022-06-25 06:19:45.866033
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ds = dict(
        action='include_tasks',
        apply={},
        args={
            'foo': 'bar',
            'apply': {}
        },
        include_tasks='task_1.yml',
    )
    ti = TaskInclude()
    ti.load_data(ds)
    bpb_block = ti.build_parent_block()

    assert isinstance(bpb_block, Block)
    assert bpb_block.module_args['block'] == []
    assert bpb_block.module_args['apply'] == {}

# Generated at 2022-06-25 06:19:48.074352
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == dict()


# Generated at 2022-06-25 06:19:53.727730
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_0 = TaskInclude()
    task_0.action = 'include'
    task_0.args = {'_raw_params': 'rspec/example.yml', 'ignore_errors': 'yes', 'sudo': '', '_variable_manager': ''}
    display.display(task_0.validate_options())


# Generated at 2022-06-25 06:20:04.573412
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    result = TaskInclude.check_options(TaskInclude(), TaskInclude.load(dict(
        action='include_role',
        name='example',
        tags=True,
        when=True,
        apply=True,
        file='/path/to/role/example',
    ), variable_manager=variable_manager, loader=loader))


from ansible.module_utils.basic import AnsibleModule
import json

# Generated at 2022-06-25 06:20:06.404326
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    assert TaskInclude().get_vars() == {}

# Generated at 2022-06-25 06:20:07.919302
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()


# Generated at 2022-06-25 06:20:18.872739
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()

    # calling load with bad parameter
    try:
        rc = task_include_0.load('Hello')
    except AnsibleParserError as e:
        assert isinstance(e, AnsibleParserError)
    except Exception as e:
        assert isinstance(e, AssertionError)

    rc = task_include_0.load({'include': 'Hello'})
    assert(isinstance(rc, TaskInclude))
    assert(rc.args == {'_raw_params': 'Hello'})

    # calling load with extra parameters
    rc = task_include_0.load({'include': {'file': 'Hello', 'other': 'world'}})
    assert(isinstance(rc, TaskInclude))

# Generated at 2022-06-25 06:20:29.616227
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    file_content = b'---\n- name: foo\n  hosts: localhost\n  connection: local\n  tasks:\n    - include: included_tasks.yml sleep=5\n          no_log: False\n'
    test_file = "/tmp/test_task_include_get_vars.yml"
    with open(test_file, "wb") as f:
        f.write(file_content)

    file_loaded = TaskInclude.load({"tasks": {"include": "included_tasks.yml sleep=5 no_log=false"}},
                                   block=Block(), loader=False, variable_manager=False)
    #{'sleep': '5', 'no_log': 'False'}

# Generated at 2022-06-25 06:20:42.072303
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test case for default scenario
    task_include_args = {'apply': {'name': 'test_TaskInclude_build_parent_block', 'block': []}}
    task_include_instance = TaskInclude(args=task_include_args)
    response = task_include_instance.build_parent_block()
    assert response == task_include_instance

test_case_0()

# Generated at 2022-06-25 06:20:48.449561
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = dict()
    task_include.args['apply'] = dict()
    task_include.args['apply']['block'] = []
    task_include.args['apply']['attributes'] = {}
    p_block = task_include.build_parent_block()
    assert p_block.block == []


# Generated at 2022-06-25 06:20:58.682556
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    # create a mock task
    task = Task()

    # create some mock data
    data = dict()

    # validate bad args, otherwise we silently ignore
    task.args = {'bad_opt_1': 'bad_opt_1'}
    task = task_include.check_options(task, data)

    # validate good args
    task.args = {'file': 'good_arg'}
    task = task_include.check_options(task, data)

    # validate good args
    task.args = {'_raw_params': 'good_arg'}
    task = task_include.check_options(task, data)

    # validate good args
    task.args = {'apply': {'good_arg': 'good_arg'}}

# Generated at 2022-06-25 06:21:06.245448
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    data = dict()
    data['action'] = 'include'
    data['apply'] = dict()
    data['apply']['_hosts'] = '{{host}}'
    data['vars'] = dict()
    data['vars']['var'] = 'value'
    data['register'] = 'result'
    data['args'] = dict()
    data['args']['other'] = 'value'
    data['args']['_raw_params'] = 'somefile'
    task = task_include.load(data, variable_manager='variable_manager', loader='loader')

    assert task.action == 'include'
    assert task.apply['_hosts'] == '{{host}}'
    assert task.vars == {'var': 'value'}
    assert task

# Generated at 2022-06-25 06:21:14.683955
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()

# Generated at 2022-06-25 06:21:18.686193
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()

# Generated at 2022-06-25 06:21:26.378654
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_1._parent = Block()
    task_include_1._parent._play = play()
    task_include_1._role = role()
    task_include_1._variable_manager = variable_manager()
    task_include_1._loader = loader()
    task_include_1.args = {'apply': {}}
    task_include_1.build_parent_block()


# Generated at 2022-06-25 06:21:29.596597
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti_x = TaskInclude()
    ti_x.args['apply'] = {'a': 1, 'block': []}
    ti_x._parent = '_parent'
    result = ti_x.build_parent_block()
    assert result.name == 'block'
    assert result.a == 1
    assert result.block == []

# Generated at 2022-06-25 06:21:34.862252
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_dict_0 = {'action': 'include_role', 'args': {'name': 'webserver'}}
    test_task_include_0 = TaskInclude.load(test_dict_0)
    result = test_task_include_0.preprocess_data(test_dict_0)
    assert result == test_dict_0

# Generated at 2022-06-25 06:21:39.353541
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = Task(action="include")
    assert task_include.check_options(task, task)
    task.args['file'] = "test.yml"
    assert task_include.check_options(task, task)
    task.args['apply'] = {'block': []}
    assert task_include.check_options(task, task)
    task.action = 'include_tasks'
    assert task_include.check_options(task, task)
    task.args['invalid_option'] = 'test'
    task.action = 'include'
    try:
        task_include.check_options(task, task)
    except Exception as ex:
        assert isinstance(ex, AnsibleParserError)
    task.action = 'include_role'

# Generated at 2022-06-25 06:21:48.002871
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    a = TaskInclude()
    assert a.get_vars() == {}, a.get_vars()


# Generated at 2022-06-25 06:21:58.829635
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include_tasks'

    # NOTE: We don't check args property since it's a 'FieldAttribute' object
    # and so it has a complicated structure

    task_include_0.args = {}
    task_include_0.check_options(task_include_0, {})


    task_include_0.args = {'file': 'tasks/setup.yml'}
    task_include_0.check_options(task_include_0, {})

    task_include_0.args = {'file': 'tasks/setup.yml', 'apply': {'include': 'roles/common/tasks/main.yml'}}
    task_include_0.action = 'include_tasks'
    task_include

# Generated at 2022-06-25 06:22:02.541723
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    apply_attrs = {}
    task_include_1.action = "include"
    task_include_1.args = {'apply':apply_attrs}
    task_include_1.build_parent_block()



# Generated at 2022-06-25 06:22:11.589124
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test get_vars() method of class TaskInclude
    '''
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {
        'a': 'b',
        'c': 'd',
    }
    root = Block(play=None)
    block = Block(parent=root)
    task_include_0.block = block
    task_include_0.vars = {
        'e': 'f',
        'g': 'h',
    }
    result = task_include_0.get_vars()
    assert result == {
        'e': 'f',
        'g': 'h',
        'a': 'b',
        'c': 'd',
    }


# Generated at 2022-06-25 06:22:13.976421
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()

    assert isinstance(task_include_0.get_vars(), dict)
    assert isinstance(task_include_1.get_vars(), dict)



# Generated at 2022-06-25 06:22:24.217169
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude(block=None, role=None, task_include=False)
    task_0 = Task()
    task_0._parent = None
    task_0.tags = ['test_0']
    task_0.when = ['test_1']
    task_0.args = {'test_2': 'test_3', 'test_4': 'test_5'}
    task_0.action = 'test_6'
    task_0.loop = None
    task_0.async_val = None
    task_0.poll = None
    task_0.notify = None
    task_0.first_available_file = None
    task_0.sudo = None
    task_0.sudo_user = None
    task

# Generated at 2022-06-25 06:22:33.584115
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
 
    task_include_0 = TaskInclude(block=None, role=None, task_include=None)

    tasks_file = dict(
        action=dict(__ansible_action=dict(__ansible_arguments={'_raw_params': '../../tasks/main.yml', 'loop': '{{ hostdefaults_webservers }}', 'loop_control': dict(__ansible_arguments=dict(loop_var='item'), __ansible_module=dict(args='', name='loop_control')), 'with_items': '{{ hostdefaults_webservers }}'})),
        delegate_to='{{ item }}',
        delegate_facts=True,
        with_items='{{ hostdefaults_webservers }}'
    )


# Generated at 2022-06-25 06:22:40.956390
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()

    file_0 = {'action': 'include', '_raw_params': 'test_path_0'}
    file_1 = None
    file_2 = {'action': 'include', '_raw_params': 'test_path_2'}
    vars_0 = {'var_0': 'var_value'}
    var_1 = False
    var_2 = 'test_ansible_path_0'
    var_3 = 'var_2'
    var_4 = 'param_0'
    var_5 = {'param_0': 'test_path_2'}
    var_6 = 'args'
    var_7 = 'file'
    var_8 = {'param_0': 'test_path_0'}
    var_9

# Generated at 2022-06-25 06:22:46.155979
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude(args={'apply': {}})
    task_include_0_block = task_include_0.build_parent_block()
    assert task_include_0_block is not None
    expected = {'block': []}
    actual = task_include_0_block.attributes
    assert expected == actual


# Generated at 2022-06-25 06:22:53.705185
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    fake_loader = Sentinel
    var_manager = Sentinel
    test_ds = {'action': 'include_role', 'args': {'apply': {'block': 'BOOL', 'vars': {'tia_var': 'tia_val'}}}}
    test_task_include = TaskInclude.load(test_ds, TaskInclude(None, None, None), var_manager=var_manager, loader=fake_loader)

    # check with wrong apply type
    test_ds = {'action': 'include_role', 'args': {'apply': 'some', 'vars': {'tia_var': 'tia_val'}}}

# Generated at 2022-06-25 06:23:15.706400
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    # No exception is expected here
    task_include_0.load(
        data={'action': 'include'},
        role=None,
        block=None,
        task_include=None,
        loader=None,
        variable_manager=None
    )
    # No exception is expected here
    task_include_0.load(
        data={'action': 'import_role'},
        role=None,
        block=None,
        task_include=None,
        loader=None,
        variable_manager=None
    )
    # No exception is expected here

# Generated at 2022-06-25 06:23:26.042883
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import datetime
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    class MockPlaybookExecutorNoBlock:
        def get_host_list(self):
            pass
        def get_variable_manager(self):
            return MockVariableManager()
        def get_loader(self):
            return MockLoader()
        def filter_tasks(self):
            pass
        def get_inventory(self):
            pass

# Generated at 2022-06-25 06:23:28.058018
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    data_0 = {}
    task_include_0.check_options(task_0, data_0)

# Generated at 2022-06-25 06:23:29.115611
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()

# Generated at 2022-06-25 06:23:30.237393
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == dict()


# Generated at 2022-06-25 06:23:32.282680
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    assert (task_include_0.check_options({'action': 'include', 'file': 'somefile.yml'}, {}))



# Generated at 2022-06-25 06:23:41.978626
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    parent = Block(task_include=None, role=None, play=None, parent=None)
    parent.block = '/home/pradeep/test.yml'
    parent.role = None
    parent.play = None
    parent.parent = None

    task_include = TaskInclude(parent, None, None)
    task_include.args = {'block': [], 'apply': {'block': []}}
    #print(task_include.__dict__)
    assert (task_include.build_parent_block() == task_include)



# Generated at 2022-06-25 06:23:54.057409
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    myargs = {'_raw_params':'abc','apply':dict(),'tags':['tag1','tag2','tag3'], 'when': 'True'}

    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.statically_loaded = False
    task_include_1.args = myargs
    task_include_1.block = Block()
    task_include_1.role = None
    task_include_1.task_include = None
    task_include_1.has_run = False
    task_include_1.loop = None
    task_include_1.notified_handlers = []
    task_include_1.always_run = False
    task_include_1.ignore_errors = False

# Generated at 2022-06-25 06:24:04.103285
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # instantiate the task include
    task_include_1 = TaskInclude()

    # empty task
    task_1 = Task()

    # check if task options are empty
    task_include_1.check_options(task_1, task_1.data)

    # populate some task args - both allowed and disallowed
    task_2 = Task()
    task_2.args = {'file': 'abc.yml', '_raw_params': 'abc.yml', 'apply': {'a': 1, 'b': 2}, 'bad_option': 'test', 'action': 'test'}

    # check if task options are not empty
    task_include_2 = TaskInclude()
    task_include_2.check_options(task_2, task_2.data)

    # populate some task args - only allowed
   

# Generated at 2022-06-25 06:24:11.841864
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    task_include_1 = TaskInclude()
    # We first initialize the task_include_1 with no parent block
    assert task_include_1._parent == None
    # We define an empty block
    apply_attrs = {}
    task_include_1.args['apply'] = apply_attrs
    # We check that the parent block is the same instance of the original task_include_1
    assert id(task_include_1) == id(task_include_1.build_parent_block())
    # We define a block with one item
    apply_attrs = {}
    apply_attrs['block'] = ['test']
    task_include_1.args['apply'] = apply_attrs
    # We check that the parent block is not the same instance of the original task_include_1

# Generated at 2022-06-25 06:24:34.797490
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    block = task_include.build_parent_block()
    assert type(block) == Block

# Generated at 2022-06-25 06:24:37.870426
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Create a TaskInclude and call get_vars()
    task_include_0 = TaskInclude()
    task_include_0.get_vars()

    # Create a TaskInclude and call get_vars() again
    task_include_1 = TaskInclude()
    task_include_1.get_vars()

# Generated at 2022-06-25 06:24:42.261535
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_check_0 = TaskInclude()
    data_check_0 = dict()
    task_check_0.check_options(
        task=TaskInclude(),
        data=data_check_0,
    )


# Generated at 2022-06-25 06:24:50.895867
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # This test assumes that the class TaskInclude has only one method
    # which is the method get_vars. Currently the method get_vars of the class
    # TaskInclude does have only one code path (one if-statement) so this test
    # does only test that code path.
    # TODO: If the method get_vars of class TaskInclude is extended to have
    #       more code paths, then this test case should be extended accordingly.

    # create class TaskInclude
    task_include = TaskInclude()

    # create the mock-objects needed by the method get_vars
    dict_mock = dict()
    # class TaskInclude inherits from the class Task
    # so we need to mock the method get_vars which is inherited by TaskInclude

# Generated at 2022-06-25 06:25:00.089973
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test case: 'apply' attr is a dict (non-empty)
    task_include_0 = TaskInclude()
    task_include_0.args["apply"] = {"a":1}
    assert task_include_0.build_parent_block().args == {"block":[]}

    # test case: 'apply' attr is a dict (empty)
    task_include_1 = TaskInclude()
    task_include_1.args["apply"] = {}
    assert task_include_1.build_parent_block().args == {"block":[]}

    # test case: no 'apply' attr
    task_include_2 = TaskInclude()
    assert task_include_2.build_parent_block().args == {}

# Generated at 2022-06-25 06:25:10.061317
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.block = Block()
    task_include_1.block.parent = task_include_1
    task_include_1.args = {}
    task_include_1.args['apply'] = {
        'block': [],
        'meta': '',
        'name': '',
        'tags': '',
        'when': '',
        'vars': {},
    }
    p_block = task_include_1.build_parent_block()
    assert p_block is not task_include_1


# Generated at 2022-06-25 06:25:14.250213
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    block_0 = task_include.build_parent_block()
    if not isinstance(block_0, TaskInclude):
        raise AssertionError("'' is not a instance of TaskInclude")


# Generated at 2022-06-25 06:25:17.227912
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_0 = TaskInclude()
    task_include_0 = TaskInclude()
    # task_include_0.check_options(task_0)


# Generated at 2022-06-25 06:25:25.122037
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_class = TaskInclude()
    task_include_class.args = {"apply":{"name":"test"}}
    res=task_include_class.build_parent_block()
    assert(res.block == [])
    assert(res.name == "test")
    assert(res.action == "apply")

# Generated at 2022-06-25 06:25:35.686470
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    action = 'import_role'
    apply_attrs = {}
    apply_attrs['block'] = []
    apply_attrs['block'] = [1,2]
    apply_attrs['block'] = [3,4]
    # display.display("Printing apply_attrs\n")
    # display.display(apply_attrs)
    task_include_obj = TaskInclude()
    task_include_obj.action = action
    task_include_obj.args = apply_attrs
    # display.display("Printing task_include_obj\n")
    # display.display(task_include_obj)
    p_block = task_include_obj.build_parent_block()
    # display.display("Printing p_block\n")
    # display.display(p_block)
