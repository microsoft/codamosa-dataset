

# Generated at 2022-06-25 06:16:11.824612
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = dict(action='include', args=dict(file='somefile'), file='somefile', action='include', _raw_params='anotherfile')

    task_include_0 = TaskInclude()

    # Test case 1 - Calling preprocess_data with action not in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    ds['action'] = 'copy'
    result = task_include_0.preprocess_data(ds)

    assert result == ds

    # Test case 2 - Calling preprocess_data with action in C._ACTION_ALL_INCLUDE_ROLE_TASKS & INVALID_TASK_ATTRIBUTE_FAILED is False
    ds['action'] = 'include'
    ds['someattr'] = 'someval'
    C.INVALID_

# Generated at 2022-06-25 06:16:20.938446
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    #### Data 3rdparty module ####
    input_vars = dict()
    input_vars['foo'] = {'test1': 1, 'test2': 2, 'test3': 3, 'test4': 4}
    input_vars['bar'] = {'test1': '1', 'test2': '2', 'test3': '3', 'test4': '4'}
    input_vars['baz'] = {'test1': [], 'test2': ['2'], 'test3': {}, 'test4': {'4':'4'}}
    input_vars['fname'] = 'ansible'
    input_vars['lname'] = 'ansible'
    input_vars['age'] = 10

# Generated at 2022-06-25 06:16:27.783910
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Case 0 - Test invalid args
    task_include_0 = TaskInclude()
    task_include_0.args = {'bad_arg': 'foo'}

    with pytest.raises(AnsibleParserError) as execinfo:
        task_include_0.check_options(task_include_0, "")

    assert "Invalid options for include: bad_arg" in str(execinfo.value)



# Generated at 2022-06-25 06:16:34.439928
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()

# Generated at 2022-06-25 06:16:44.017277
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Create TaskInclude object
    # No error
    task_include = TaskInclude()

    # Create object to be added to the block variable
    # No error
    block = Block()

    # Add block variable to the TaskInclude object
    # No error
    task_include.block = block

    task_include_block = task_include.build_parent_block()

    # Check if the block variable in the TaskInclude object is equal to the block variable in the object returned by build_parent_block
    assert task_include.block == task_include_block, "Test case 0 failed"


# Generated at 2022-06-25 06:16:53.186649
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include._parent = None
    task_include._role = None
    task_include._loader = None
    task_include._variable_manager = None
    task_include.default_vars = dict()
    task_include.vars = dict()
    task_include.args = dict()
    task_include.action = 'include'
    block = task_include.build_parent_block()
    assert block is task_include
    task_include.action = 'include_tasks'
    block = task_include.build_parent_block()
    assert block is task_include
    task_include.action = 'import_tasks'
    block = task_include.build_parent_block()
    assert block is task_include
    task_include.action = 'include_role'

# Generated at 2022-06-25 06:16:59.191463
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict()
    result = task_include_0.preprocess_data(ds)
    assert result == {}, "Preprocessing of data set failed"
#
# # Unit test for method copy of class TaskInclude
# def test_TaskInclude_copy():
#     task_include_0 = TaskInclude()
#     result = task_include_0.copy()
#     assert result == {}, "Preprocessing of data set failed"
#
# # Unit test for method is_meta of class TaskInclude
# def test_TaskInclude_is_meta():
#     task_include_0 = TaskInclude()
#     arg = 0
#     result = task_include_0.is_meta()
#     assert result == {}, "Preprocessing of data set failed"


# Generated at 2022-06-25 06:17:05.189450
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    data_0 = dict()
    task_include_0.check_options(task_0, data_0)


# Generated at 2022-06-25 06:17:07.851068
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    task_include_0.load([{'action': 'include_tasks', 'file': 'a_file_name', 'when': 'something'}])


# Generated at 2022-06-25 06:17:15.267599
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()

    apply_attrs = {}
    task_include.args['apply'] = apply_attrs
    p_block = task_include.build_parent_block()
    assert task_include == p_block
    assert 'block' not in apply_attrs

    apply_attrs = {}
    task_include.args['apply'] = apply_attrs
    apply_attrs['block'] = 'some value'
    p_block = task_include.build_parent_block()
    assert p_block.args['block'] == 'some value'
    assert 'block' not in apply_attrs

# Generated at 2022-06-25 06:17:25.785290
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    TaskInclude().preprocess_data({
        'action': 'include',
        'file': 'my_file'
    })

    TaskInclude().preprocess_data({
        'action': 'import_playbook',
        'file': 'my_file',
        'name': 'test1'
    })

    TaskInclude().preprocess_data({
        'action': 'include',
        'file': 'my_file',
        'name': 'test1'
    })

    TaskInclude().preprocess_data({
        'action': 'include_tasks',
        'file': 'my_file',
        'name': 'test1'
    })


# Generated at 2022-06-25 06:17:26.733952
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    assert task_include.get_vars() == {}


# Generated at 2022-06-25 06:17:33.579822
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Assign
    task_include_1 = TaskInclude()
    task_include_1._parent = Task()
    task_include_1.vars = {'var1': 'val1', 'var2': 'val2'}
    task_include_1.args = {'arg1': 'val1', 'arg2': 'val2'}
    task_include_2 = TaskInclude()
    task_include_2._parent = Task()
    task_include_2.vars = {'var1': 'val1', 'var2': 'val2'}
    task_include_2.args = {'arg1': 'val1', 'arg2': 'val2'}
    task_include_2.action = 'include_role'
    task_include_3 = TaskInclude()
    task_include_

# Generated at 2022-06-25 06:17:35.968681
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ds = {}
    ti = TaskInclude()
    ti.check_options(ti.load_data(ds, None, None), ds)


# Generated at 2022-06-25 06:17:41.890667
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()

    data_0 = {
        'action' : 'include',
        'when' : "{{ include_when }}"
    }
    data_1 = {
        'action' : 'include',
        'when' : "{{ include_when }}",
        'some_invalid_attribute' : 'value'
    }

    with pytest.warns(UserWarning) as record:
        task_include_0.preprocess_data(data_1)
        assert record.pop(0).message.args[0] == "Ignoring invalid attribute: some_invalid_attribute"

# Generated at 2022-06-25 06:17:50.488205
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {'include': 'a'}
    task_include = TaskInclude()
    ds = task_include.preprocess_data(data)
    assert ds['action'] == 'include'
    assert ds['include'] is None
    assert ds['args'] is None

    data = {'action': 'block'}
    task_include = TaskInclude()
    ds = task_include.preprocess_data(data)
    assert ds['action'] == 'block'
    assert ds['block'] is None
    assert ds['args'] is None

    data = {'tasks': 'tasks.yml'}
    task_include = TaskInclude()
    ds = task_include.preprocess_data(data)
    assert ds['action'] == 'include_tasks'
   

# Generated at 2022-06-25 06:17:55.448565
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    data = {'action': 'include_tasks', 'args': {'tasks': 'tasks/main.yml', '_raw_params': 'tasks/main.yml'}, 'block': []}
    actual_result = task_include_0.preprocess_data(data)
    expected_result = {'action': 'include_tasks', 'args': {'tasks': 'tasks/main.yml', '_raw_params': 'tasks/main.yml'}, 'block': []}
    assert actual_result == expected_result


# Generated at 2022-06-25 06:17:56.898599
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict()
    task_include_0.preprocess_data(ds)



# Generated at 2022-06-25 06:18:07.822158
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.playbook.task_include as a
    from ansible.playbook.task_include import TaskInclude
    ti=TaskInclude()
    ti.action='include'
    ti.tags='tag'
    ti.ignore_errors='true'
    ti.no_log='0'
    ti.name='check if elastic search is running'
    ti.loop_with='var_loop'
    _data = {'tags':'tags','no_log':'0','ignore_errors':'1','loop_with':'var_loop','name':'check if elastic search is running'}
    _ds = {}
    for k in _data.keys():
        _ds[k] = _data[k]

# Generated at 2022-06-25 06:18:16.467038
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    test_data0 = dict(action='include', file='blah.yml', apply=dict(block=[]))
    result0 = task_include_0.check_options(task_include_0.load_data(test_data0), test_data0)
    assert (result0.args['_raw_params'] == 'blah.yml')

    test_data1 = dict(action='include', file='blah.yml')
    result1 = task_include_0.check_options(task_include_0.load_data(test_data1), test_data1)
    assert (result1.args['_raw_params'] == 'blah.yml')

    test_data2 = dict(action='include', _raw_params='blah.yml')

# Generated at 2022-06-25 06:18:26.640398
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    display.display(display.title("CASE: Test of method build_parent_block() of class TaskInclude"))
    task_include_0 = TaskInclude()
    display.display(task_include_0.build_parent_block())


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:18:32.573330
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    def get_parent_get_vars(self):
        return dict()

    task_include_0._parent = type('', (), {})()
    task_include_0._parent.get_vars = get_parent_get_vars.__get__(task_include_0._parent, task_include_0._parent.__class__)
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0.action = 'include'
    task_include_0.action = 'include_role'
    task_include_0.action = 'import_role'
    task_include_0.action = 'noop'



# Generated at 2022-06-25 06:18:39.212166
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    role = None
    task_include = None
    task_data = {'include': 'Ansible'}
    task_include_obj = ti.load(data=task_data, block=None, role=role, task_include=task_include, variable_manager=None, loader=None)
    assert task_include_obj.action == 'include'


# Generated at 2022-06-25 06:18:49.383856
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    assert TaskInclude.check_options({'args': 'dummy_task_include'}, 'dummy_obj_data').args == {'args': 'dummy_task_include'}
    assert TaskInclude.check_options({'_raw_params': 'dummy_task_include', 'apply': {'test': 'test'}}, 'dummy_obj_data').args == {'_raw_params': 'dummy_task_include', 'apply': {'test': 'test'}}
    assert TaskInclude.check_options({'args': 'dummy_task_include', 'apply': {'test': 'test'}}, 'dummy_obj_data').args == {'args': 'dummy_task_include', 'apply': {'test': 'test'}}


# Generated at 2022-06-25 06:18:58.372984
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    class _Block:
        # Initialize _play, _role and _loader attributes to avoid AttributeError
        _play = _role = _loader = None

        def get_vars(self):
            return dict()

    class _Play:
        _variable_manager = None

    play_0 = _Play()
    task_include_0 = TaskInclude()
    task_include_0._parent = _Block()
    task_include_0._play = play_0
    task_include_0.args = dict()
    try:
        task_include_0.build_parent_block()
    except AttributeError as e:
        display.error('AttributeError: ' + str(e))

# Generated at 2022-06-25 06:19:07.313050
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Set args for test case method load of class TaskInclude
    data = {'task': {'meta': 'include', 'block': [{'task': {'args': 'file=test.yml'}}]}, 'version': '1.0'}

    # Call method load of class TaskInclude
    ti = TaskInclude.load(
        data=data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )

    # Validate method load of class TaskInclude



# Generated at 2022-06-25 06:19:16.597193
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude()

    task_include_1.load(
        {
            "include_role": {
                "_raw_params": "foo"
            }
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
        )

    task_include_1.load(
        {
            "include_role": {
                "file": "foo"
            }
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
        )


# Generated at 2022-06-25 06:19:27.560297
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_2 = Task()
    task_2.action = 'include'
    task_2.args = {'_raw_params': 'abc',
                   'ignore_errors': '123'}
    task_include_1.check_options(task_2, 'fake_data')
    assert task_2.args == {'file': 'abc',
                           'ignore_errors': '123'}
    task_include_1.check_options(task_2, 'fake_data')
    assert task_2.args == {'file': 'abc',
                           'ignore_errors': '123'}
    task_2.args = {'file': 'abc',
                   'ignore_errors': '123'}

# Generated at 2022-06-25 06:19:37.020247
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    from ansible.playbook.task import Task


# Generated at 2022-06-25 06:19:47.013230
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Call method check_options of class TaskInclude
    ti = TaskInclude()
    task = {'action': 'include', 'args': {'file': 'foo.yml'}}
    assert ti.check_options(task, task) == {'action': 'include', 'args': {'file': 'foo.yml', '_raw_params': 'foo.yml'}}
    task = {'action': 'include_role', 'args': {'name': 'foo'}}
    assert ti.check_options(task, task) == {'action': 'include_role', 'args': {'name': 'foo'}}
    task = {'action': 'import_role', 'args': {'name': 'foo'}}

# Generated at 2022-06-25 06:19:56.450767
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0_args = {"_parent": "task_include_0_parent",
                            "args": {"myarg": "myvalue"},
                            "action": "include",
                            "vars": {"myvar": "myvalue"}}
    task_include_0 = TaskInclude(task_include_0_args)
    task_include_0_result = task_include_0.get_vars()
    assert task_include_0_result == {"myarg": "myvalue",
                                        "myvar": "myvalue"}

# Generated at 2022-06-25 06:20:01.980962
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Arrange
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'charset': 'utf-8', 'file': 'file.yml'}
    data = {}

    # Act
    ti.check_options(task, data)
    # Assert
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == task.args['file']


# Generated at 2022-06-25 06:20:13.284811
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    tasks = [{'include': 'foobar'}]
    block = Block(play=None, task_include=None, role=None)
    task_include = TaskInclude(block=block, role=None)
    task_include.args['file'] = 'foobar'
    task_include.args['apply'] = {'block': 'foobar'}
    task_include.build_parent_block()

    tasks = [{'import_tasks': '/testing.yaml'}]
    block = Block(play=None, task_include=None, role=None)
    task_include = TaskInclude(block=block, role=None)
    task_include.args['file'] = '/testing.yaml'
    task_include.build_parent_block()


#test_case_0()

# Generated at 2022-06-25 06:20:21.549229
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    playbook_path = './test/ansible_module_include/test_case_2/simple_playbook.yml'
    inventory_path = './test/ansible_module_include/test_case_2/hosts'
    loader, variable_manager, inventory = C.import_playbook_path_and_inventory(playbook_path, inventory_path)
    task_include_0 = TaskInclude()
    task_include_0.block = Block()
    task_include_0.block.vars = {}
    task_include_0.vars = {}
    task_include_0.action = '#action'
    task_include_0.args = {}
    task_include_0._variable_manager = variable_manager
    task_include_0._parent = Block()
    task_include_0._parent

# Generated at 2022-06-25 06:20:30.640320
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    apply_attrs = task_include_0.args
    apply_attrs = task_include_0.args.pop('apply', {})
    if apply_attrs:
        apply_attrs['block'] = []
        p_block = Block.load(
            apply_attrs,
            play=task_include_0._parent._play,
            task_include=task_include_0,
            role=task_include_0._role,
            variable_manager=task_include_0._variable_manager,
            loader=task_include_0._loader,
        )
    else:
        p_block = task_include_0

    task_include_0.build_parent_block()


# Generated at 2022-06-25 06:20:42.030031
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.vars = {
        'var_0': {
            'hostvars': {
                'host_1': {
                    'key_1': 'val_1',
                    'key_2': 2
                }
            }
        },
        'var_1': {
            'hostvars': {
                'host_1': {
                    'key_1': 'val_2',
                    'key_2': 20
                }
            }
        }
    }
    task_include_0.args = {
        'file': 'include_file.yaml',
        'apply': {
            'loop': 'result.stdout'
        }
    }
    task_include_0

# Generated at 2022-06-25 06:20:49.514162
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # This method is used to create the parent block for the included tasks
    # when ``apply`` is specified
    task_include_0 = TaskInclude()
    # Default parameter value is None
    task_include_0_apply_attrs = None
    # TODO: Fix type of variable_manager and loader
    task_include_0_apply_attrs = task_include_0.build_parent_block(task_include_0_apply_attrs, task_include_0)
    # assert isinstance(task_include_0_apply_attrs, Block)


# Generated at 2022-06-25 06:21:00.022331
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    print("\nUnit test for method get_vars of class TaskInclude")

    task_include_1 = TaskInclude()
    role_1 = None
    task_include_1.set_loader(None)
    task_include_1.set_parent(None)
    task_include_1.set_play(None)
    task_include_1.set_role(role_1)

    result = task_include_1.get_vars()
    assert result == {}, "Expected {}, but got {}".format({}, result)

    task_include_1.set_parent(task_include_1)
    result = task_include_1.get_vars()
    assert result == {}, "Expected {}, but got {}".format({}, result)


# Generated at 2022-06-25 06:21:03.641721
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Testcase setUp
    task_include_0 = TaskInclude()
    task_include_0.args = dict(
        file="/path/to/include",
        name="Test Name",
    )

    # Testing the method
    task_include_0.get_vars()

    # Testcase tearDown



# Generated at 2022-06-25 06:21:13.197884
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = task_include.check_options(
        task_include.load_data({'include': 'foo'}, variable_manager={}, loader={}),
        {'include': 'foo'}
    )
    assert {
        '_raw_params': 'foo',
        'action': 'include',
        'collections': [],
        'loop': [],
        'loop_control': {},
        'loop_with': 'inventory_hostname',
        'name': None,
        'register': '',
        'run_once': False,
        'tags': [],
        'when': None
    } == task.args


# Generated at 2022-06-25 06:21:28.497920
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude(block=None, role=None, task_include=None)
    task_include_0.build_parent_block()

# Generated at 2022-06-25 06:21:39.594207
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()

    # test with apply option
    apply_option = {
        "block": [
            {"action": {"module": "name", "args": "args"}}
        ],
        "ignore_errors": True
    }
    task_include_0.args['apply'] = apply_option

    # Call method
    parent_block = task_include_0.build_parent_block()

    # Assert expected values
    assert parent_block.block == [{'action': {'module': 'name', 'args': 'args'}}]
    assert parent_block.ignore_errors is True

    # Call method again
    parent_block = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:21:48.513606
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with action == 'include'
    test_task_include_0 = TaskInclude()
    test_task_include_0._parent = Block()
    test_task_include_0._parent.vars = {
        'var_parent': 'var_value_parent',
    }
    test_task_include_0.vars = {
        'var_self': 'var_value_self',
    }
    test_task_include_0.action = 'include'
    test_task_include_0.args = {
        'var_args': ['var_value_args_0', 'var_value_args_1'],
    }

# Generated at 2022-06-25 06:21:53.359944
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude(role=None, task_include=None)
    task_include_0._parent = [None]
    task_include_0._variable_manager = [None]
    task_include_0._loader = [None]
    task_include_0._role = [None]
    task_include_0.action = 'include'
    task_include_0.args = {'apply': {'anything': '', 'tags': [], 'when': []}}
    block_0 = task_include_0.build_parent_block()
    assert block_0 is not None


# Generated at 2022-06-25 06:21:56.634075
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()
    assert task_include_1.build_parent_block() is task_include_1
    assert task_include_2.build_parent_block() is task_include_2
    assert task_include_3.build_parent_block() is task_include_3

# Generated at 2022-06-25 06:22:06.742067
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_1.args = {u'some_var': u'1234', u'file': u'pouet.yml'}
    task_include_2 = TaskInclude()
    task_include_2.vars = {u'foo': u'bar'}
    task_include_2.args = {u'file': u'pouet.yml'}
    task_include_3 = TaskInclude()
    task_include_3.action = u'include_role'
    task_include_3.args = {u'some_var': u'1234', u'file': u'pouet.yml'}

# Generated at 2022-06-25 06:22:10.918199
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0_0 = TaskInclude()
    options_0_0 = {}
    data_0_0 = {}
    options_0_0 = task_include_0_0.check_options(options_0_0, data_0_0)
    options_0_0['action'] = 'include'

    assert( options_0_0['action'] == 'include' )


# Generated at 2022-06-25 06:22:13.932987
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args.update({
        'foo': 'bar',
        'baz': 'qux'
    })
    expected = {
        'foo': 'bar',
        'baz': 'qux'
    }
    assert expected == task_include_0.get_vars()

# TODO(retr0h): Implement this test

# Generated at 2022-06-25 06:22:14.842689
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # ToDo : TaskInclude.get_vars needs to be tested
    test_case_0()

# Generated at 2022-06-25 06:22:19.615310
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = "import_playbook"
    task_include_0.args = {"name": "a", "tags": "a", "_raw_params": "b"}
    task_include_0.register = "a"
    task_include_0._parent = object()
    result_vars = task_include_0.get_vars()
    assert result_vars == {"register": "a", "name": "a", "_raw_params": "b"}, "get_vars returned unexpected result_vars"


# Generated at 2022-06-25 06:22:37.188517
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}


# Generated at 2022-06-25 06:22:39.001562
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()
    assert result == {}


# Generated at 2022-06-25 06:22:48.855706
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block_0 = Block()
    block_0._parent = Block()
    block_0._parent._play = Play()
    block_0._parent._play._variable_manager = VariableManager()
    block_0._parent._play._variable_manager._fact_cache = {}
    block_0._parent._play._yaml_loader = DictDataLoader({})
    block_0.vars = dict()
    block_0.vars['ansible_play_hosts'] = ['host1', 'host2', 'host3']
    block_0._role = Role()
    block_0._parent._play._variable_manager.extra_vars = {'foo': 'bar'}
    block_0.statically_loaded = True
    block_0.action = 'include'
    block_0.loop = 'item'


# Generated at 2022-06-25 06:22:53.457249
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = ()
    cls_0 = task_include_0.__class__
    cls_1 = task_include_0.__class__
    ans_0 = cls_0.build_parent_block(cls_1)
    assert ans_0 == task_include_0
    ans_1 = cls_1.build_parent_block(cls_1)
    assert ans_1 == task_include_1



# Generated at 2022-06-25 06:23:03.080226
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    ti = TaskInclude()
    data = {
        'action': 'include_role',
        'file': '/some/file',
        'apply': {
            'ignore_errors': False,
        },
    }
    task = ti.check_options(
        ti.load_data(data, variable_manager=None, loader=None),
        data
    )
    assert task.args.get('_raw_params') == '/some/file'

    data = {
        'action': 'include',
        'file': '/some/file',
        'apply': {
            'ignore_errors': False,
        },
    }
    task = ti.check_options(
        ti.load_data(data, variable_manager=None, loader=None),
        data
    )

# Generated at 2022-06-25 06:23:06.729792
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Arrange
    test_task_include = TaskInclude()

    # Act
    test_task_include.action = 'include'
    test_task_include.vars = {'key_one': 'value_one'}
    test_task_include.args = {'key_two': 'value_two'}

    # Assert
    assert len(test_task_include.get_vars()) == 2
    assert test_task_include.get_vars()['key_one'] == 'value_one'
    assert test_task_include.get_vars()['key_two'] == 'value_two'


# Generated at 2022-06-25 06:23:12.449832
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_incl_1 = TaskInclude()
    assert task_incl_1.get_vars() == {}

    arg_dict_1 = {"a": 1, "b": 2, "c": 3}
    task_incl_2 = TaskInclude(args=arg_dict_1)
    assert task_incl_2.get_vars() == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-25 06:23:23.348107
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pb_attrs = {'name': 'parent_block', 'vars': {'key1': 'value1'}, 'block': [], 'ignore_errors': False}
    pb_data = {'block': pb_attrs, 'apply': {'vars': {'key2': 'value2'}, 'apply': {'key3': 'value3'}}}
    task_include_0 = TaskInclude()
    task_include_0.args = {'_raw_params': 'params', 'apply': {'key3': 'value3'}}
    task_include_0._loader = None
    task_include_0._variable_manager = None
    task_include_0._role = None
    task_include_0._play = object()
    # Test case with expected result
    task_include_0._parent

# Generated at 2022-06-25 06:23:31.174326
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.action = "include_tasks"
    task_include.args = {'apply': {'name': 'include_tasks', 'action': 'include_tasks', 'fork': 10}}
    parent_block = task_include.build_parent_block()
    assert(parent_block.__class__.__name__ == "Block")
    assert(parent_block.parent == None)
    assert(parent_block.args['name'] == 'include_tasks')

    task_include.args = {'apply': {'name': 'include_tasks', 'action': 'include_tasks', 'fork': 10, 'block': []}}
    parent_block = task_include.build_parent_block()

# Generated at 2022-06-25 06:23:35.895055
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.vars = dict()
    task_include_0.args = dict()
    expected = dict()
    result = task_include_0.get_vars()
    assert result == expected


# Generated at 2022-06-25 06:24:37.148931
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    #
    # Test with apply not specified
    #
    task_include_1.args['file'] = 'foo'
    parent_block_1 = task_include_1.build_parent_block()

    assert task_include_1.args['file'] == 'foo'
    assert parent_block_1 is task_include_1

    #
    # Test with apply specified
    #
    task_include_2 = TaskInclude()
    task_include_2.args['file'] = 'foo'
    task_include_2.args['apply'] = dict()
    parent_block_2 = task_include_2.build_parent_block()

    assert task_include_2.args['file'] == 'foo'

# Generated at 2022-06-25 06:24:40.059689
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.action = "run_once"
    task_include_0.args["apply"] = {"a": "b"}
    task_include_0.args["_raw_params"] = "file"
    task_include_0.check_options(task_include_0, {})


# Generated at 2022-06-25 06:24:48.210123
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    parent = Block()
    parent._vars = dict()
    task_include_0 = TaskInclude()
    task_include_0._parent = parent
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0.action = 'include'
    task_include_0.args['tags'] = 'all'
    task_include_0.args['when'] = 'any'
    assert task_include_0.get_vars() == dict()


# Generated at 2022-06-25 06:24:59.045374
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create empty instance of class TaskInclude
    task_include_0 = TaskInclude()
    # Initialize variable `block_0` with empty Block
    block_0 = Block()
    # Set attribute `_parent` of `task_include_0` to `block_0`
    task_include_0._parent = block_0
    # Initialize variable `p_block` with method build_parent_block of task_include_0
    p_block = task_include_0.build_parent_block()
    # Assert that `p_block` has attribute `_parent`
    assert hasattr(p_block, '_parent')
    # Assert that `p_block` has attribute `_task_include`
    assert hasattr(p_block, '_task_include')


# Generated at 2022-06-25 06:25:03.961739
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    # Assert if build_parent_block does not raise errors when called with empty parameters
    assert task_include_0.build_parent_block()


# Generated at 2022-06-25 06:25:09.820372
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    # TODO check error handling for task_include_0.build_parent_block()
    # TODO check error handling for task_include_1.build_parent_block()
    # TODO check error handling for task_include_2.build_parent_block()
    pass


# Generated at 2022-06-25 06:25:20.575243
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test_case_0
    task_include_0 = TaskInclude()
    task_include_0.args = {'block' : [], 'apply' : {}}
    assert task_include_0.build_parent_block() == task_include_0
    # test_case_1
    task_include_1 = TaskInclude()
    task_include_1.args = {'block' : [], 'apply' : {}}
    assert task_include_1.build_parent_block() == task_include_1
    # test_case_2
    task_include_2 = TaskInclude()
    task_include_2.args = {'block' : [], 'apply' : {}}
    assert task_include_2.build_parent_block() == task_include_2
    # test_case_3

# Generated at 2022-06-25 06:25:30.669074
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_input_0 = {
        'args': {
            'file': 'foo.yml',
        },
        'action': 'include',
    }
    test_input_1 = {
        'args': {
            'file': 'foo.yml',
        },
        'action': 'include',
        'loop': '{{ my_hosts }}',
    }
    test_input_2 = {
        'args': {
            'file': 'foo.yml',
        },
        'action': 'import_role',
    }
    test_input_3 = {
        'args': {
            'file': 'foo.yml',
        },
        'action': 'import_tasks',
    }

# Generated at 2022-06-25 06:25:40.210848
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    # test correct args
    task_include_0.check_options(task_include_0, {})
    # test empty arg
    task_include_0.check_options(task_include_0, {'file': 'a'})
    # test arg apply
    task_include_0.check_options(task_include_0, {'file': 'a', 'apply': {'b': 'c'}})
    # test arg _raw_params
    task_include_0.check_options(task_include_0, {'_raw_params': 'a'})

    # test incorrect arg
    try:
        task_include_0.check_options(task_include_0, {'a': 'b'})
    except AnsibleParserError:
        pass
   

# Generated at 2022-06-25 06:25:46.471565
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # setup
    task_include_0 = TaskInclude()
    task_include_0.args = {
        'k1': 'v1',
        'k2': 'v2'
    }
    task_include_0.action = 'include'
    task_include_0.role = None
    task_include_0.tags = []
    task_include_0.when = None
    task_include_0.parent = 'Unknown'
    task_include_0._role_name = ''
    task_include_0._play = None
    task_include_0._loader = None
    task_include_0._variable_manager = None
    task_include_0._block = None

    # test