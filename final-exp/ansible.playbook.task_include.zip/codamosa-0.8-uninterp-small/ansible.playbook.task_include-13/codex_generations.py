

# Generated at 2022-06-25 06:15:59.921519
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
        test_case_5()
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-25 06:16:04.932757
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(
        action = 'include',
        file = 'foo.yml',
    )
    task_include_0 = TaskInclude()
    task_0 = task_include_0._check_options(task_0, data)


# Generated at 2022-06-25 06:16:15.878392
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.include_role_tasks = True
    task_include_1 = TaskInclude()
    task_include_0.include_tasks = True
    task_include_1.include_tasks = False
    task_include_0.roles = {}
    task_include_0.import_tasks = True
    task_include_1.tasks = []
    task_include_1.include_role_tasks = False
    task_include_1.import_tasks = False
    task_include_0.preprocess_data(ds=0)
    task_include_0.preprocess_data(ds=1)
    task_include_0.preprocess_data(ds=2)

# Generated at 2022-06-25 06:16:19.038380
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()

    # call method with arguments of wrong type
    try:
        task_include_0.build_parent_block("str")
    except TypeError as err:
        assert(str(err) == 'wrong argument type str')



# Generated at 2022-06-25 06:16:20.308817
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    all_vars = task_include_0.get_vars()


# Generated at 2022-06-25 06:16:26.443890
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0._parent = None
    task_include_0.vars = dict()
    task_include_0.args = dict()
    assert(task_include_0.get_vars() is not False)


# Generated at 2022-06-25 06:16:28.099800
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    assert not task_include_0.preprocess_data(None)


# Generated at 2022-06-25 06:16:29.656931
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # This method will be re-implemented with the real logic, remember to change the static file tag in task_include.load
    pass
	

# Generated at 2022-06-25 06:16:33.739113
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert isinstance(task_include_0.build_parent_block(), Block) == True


# Generated at 2022-06-25 06:16:45.915206
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    task_include_0 = TaskInclude()
    task_include_0.module_vars = {}
    task_include_0.args = {
        'tags': ['a', 'b', 'c'],
        'when': ['a', 'b', 'c'],
    }
    Block.load = lambda *args, **kwargs: task_include_0
    task_include_0.statically_loaded = True
    task_include_0._loader = None
    task_include_0._variable_manager = None
    task_include_0._parent = {}
    task_include_0._role = None
    task_include_0.action = 'include'
    task_include_0.statically_loaded = False


# Generated at 2022-06-25 06:16:56.565989
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case = task_include_0 = TaskInclude()

    # Test with self.action is not one of the _ACTION_INCLUDE
    try:
        # Test with self._parent
        test_case._parent = test_case
        test_case.action = 'include_role'
        test_case.vars = {'foo': 'bar'}
        assert test_case.get_vars() == {'foo': 'bar'}, "Result: %s" % test_case.get_vars()

        # Test without self._parent
        test_case._parent = None
        test_case.action = 'import_role'
        assert test_case.get_vars() == {'foo': 'bar'}, "Result: %s" % test_case.get_vars()
    except:
        raise

# Generated at 2022-06-25 06:17:06.026805
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # NOTE: The following values are expected to change:
    #       float_0 and float_1
    task_include_0 = TaskInclude()
    float_0 = -662.078
    float_1 = -94.559
    dict_0 = {}
    assert task_include_0.preprocess_data(dict_0) is dict_0

    # NOTE: The following values are expected to change:
    #       bool_0 and bool_1
    task_include_1 = TaskInclude()
    bool_0 = -16.303
    bool_1 = -55.054
    dict_1 = {}
    assert task_include_1.preprocess_data(dict_1) is dict_1

    # NOTE: The following values are expected to change:
    #       list_0 and list_1
    task_

# Generated at 2022-06-25 06:17:16.184801
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test when self._parent is null
    task_include_0 = TaskInclude()
    task_include_0.action = 'set_fact'
    dict_0 = dict()
    dict_0["test"] = "test"
    task_include_0.args = dict_0
    task_include_0._parent = None
    task_include_0.vars = dict_0
    assert task_include_0.get_vars()["test"] == 'test'

    # Test when self._parent is not null and action is not in C._ACTION_INCLUDE
    task_include_0 = TaskInclude()
    task_include_0.action = 'set_fact'
    dict_0 = dict()
    dict_0["test"] = "test"
    task_include_0.args = dict_0

# Generated at 2022-06-25 06:17:25.426975
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.action = Sentinel('action_0')
    task_include_0.handler = Sentinel('handler_0')
    task_include_0.include_role = Sentinel('include_role_0')
    task_include_0.include_tasks = Sentinel('include_tasks_0')
    task_include_0.noop = Sentinel('noop_0')
    task_include_0.register = Sentinel('register_0')
    task_include_0.retry = Sentinel('retry_0')
    task_include_0.tags = Sentinel('tags_0')
    task_include_0.until = Sentinel('until_0')
    task_include_0.vars = Sentinel('vars_0')

# Generated at 2022-06-25 06:17:32.757604
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('-inf')
    float_3 = float('nan')
    float_4 = float('inf')
    float_5 = float('-inf')
    float_6 = float('inf')
    float_7 = float('inf')
    float_8 = float('-inf')
    float_9 = float('nan')
    float_10 = float('nan')
    float_11 = float('-inf')
    float_12 = float('inf')
    float_13 = float('-inf')
    float_14 = float('-inf')
    float_15 = float('nan')
    float_16 = float('inf')
    float_17 = float('nan')
    float_18 = float('-inf')
    float

# Generated at 2022-06-25 06:17:38.304238
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    role_tasks_0 = list()
    role_tasks_0 = TaskInclude.load(role_tasks_0)
    assert role_tasks_0.get_vars() is not None
    # AssertionError()



# Generated at 2022-06-25 06:17:45.089094
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from collections import OrderedDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['hosts'])
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load

# Generated at 2022-06-25 06:17:47.522733
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    float_0 = -149.6456
    task_include_0 = TaskInclude()
    assert False # TODO: implement your test here


# Generated at 2022-06-25 06:17:53.814453
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    my_dict = {}
    my_Module_0 = TaskInclude()
    my_dict['action'] = 'include'
    my_dict['collections'] = []
    my_dict['debugger'] = Sentinel
    my_dict['ignore_errors'] = Sentinel
    my_dict['loop'] = Sentinel
    my_dict['loop_control'] = Sentinel
    my_dict['loop_with'] = Sentinel
    my_dict['name'] = Sentinel
    my_dict['no_log'] = Sentinel
    my_dict['register'] = Sentinel
    my_dict['run_once'] = Sentinel
    my_dict['tags'] = Sentinel
    my_dict['timeout'] = Sentinel
    my_dict['vars'] = Sentinel
    my_dict['when'] = Sentinel
    my_dict['x'] = Sentinel

# Generated at 2022-06-25 06:17:57.174500
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds_0 = {}
    res = task_include_0.preprocess_data(ds_0)
    assert res == {}
    task_include_1 = TaskInclude()
    ds_1 = {}
    res = task_include_1.preprocess_data(ds_1)
    assert res == {}
    task_include_2 = TaskInclude()
    ds_2 = {}
    res = task_include_2.preprocess_data(ds_2)
    assert res == {}


# Generated at 2022-06-25 06:18:10.338454
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    try:
        test_case_0()
        # AssertionError raised
        assert False
    except AssertionError:
        # if assertion is raised -> test success
        assert True
    except:
        # if exception is not raised -> test fail
        assert False

if __name__ == '__main__':
    test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:18:14.422619
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()


# Generated at 2022-06-25 06:18:18.264283
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude(
        block = None,
        role = None,
        task_include = None
    )
    # Input Params:
    #   (object) task_include
    # Expected Return Value: None
    # Return: (object) parent_block
    parent_block = task_include.build_parent_block()


# Generated at 2022-06-25 06:18:25.221367
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    dict_0 = dict()
    dict_0['action'] = 'include'
    dict_0['args'] = dict()
    dict_0['file'] = -994
    dict_1 = dict()
    dict_1['action'] = 'include'
    dict_1['args'] = dict()
    dict_1['file'] = Senti
    assert task_include_0.preprocess_data(dict_0) == dict_0
    assert task_include_0.preprocess_data(dict_1) == dict_1
    float_0 = -662.078


# Generated at 2022-06-25 06:18:34.493962
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_1['action'] = 'async_poll'
    dict_2['filter'] = 'facter'
    dict_1['register'] = 'shell_out'
    dict_2['when'] = True
    dict_2['_uuid'] = 'b1a654fe82ea2b6cedaec9e9c6a06e3c'
    dict_1['_uuid'] = 'f4d4e79e4d9e9b8f97b6453d5d1544d2'
    dict_2['when_file'] = '/etc/ansible/roles/role_under_test/defaults/main.yml'
    dict

# Generated at 2022-06-25 06:18:41.973791
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    float_0 = float('inf')
    float_1 = float('NaN')
    float_2 = float('-inf')
    float_3 = float('nan')
    float_4 = float('-inf')
    list_0 = [float_1, float_0, float_0]
    list_1 = [float_2, float_0, 1.0]
    list_2 = [float_2, float_0, float_0]
    list_3 = [float_3, float_0, float_2]
    list_4 = [float_3, float_0, float_1]
    list_5 = [float_3, float_0, float_0]



# Generated at 2022-06-25 06:18:47.858981
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict()
    task = task.check_options(task, data)


# Generated at 2022-06-25 06:18:51.423954
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = dict()
    try:
       ti.preprocess_data(ds)
    except AnsibleParserError as e:
        assert False, "Unable to execute TaskInclude.preprocess_data(). Error was: " + str(e)
    assert True


# Generated at 2022-06-25 06:18:56.844050
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    dict_0 = dict()
    dict_0['action'] = 'action'
    dict_0['name'] = 'name'
    dict_0['args'] = dict()
    dict_0.setdefault('debugger', dict_0['debugger'])
    dict_0['tags'] = dict_0['tags']
    dict_0['when'] = 'when'
    result = task_include_0.preprocess_data(dict_0)
    assert (result.get('action') == dict_0.get('action'))
    assert (result.get('debugger') == dict_0.get('debugger'))
    assert (result.get('name') == dict_0.get('name'))

# Generated at 2022-06-25 06:18:59.949958
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert isinstance(task_include_0.get_vars(), dict)


# Generated at 2022-06-25 06:19:16.402492
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = {
      'args': {
        'file': 'example.yml',
        'tags': [
          'something3',
          'something4'
        ]
      },
      'action': 'include_tasks',
      'loop_args': {},
      'loop': '',
      'delegate_to': '',
      'loop_control': {},
      'when': True,
      'loop_with': '',
      'ignore_errors': False,
      'register': 'some_var',
      'name': 'say hello'
    }
    task_1 = task_0

# Generated at 2022-06-25 06:19:23.635292
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    TaskInclude.copy = MagicMock()
    TaskInclude.copy.return_value = task_include_0
    dict_0 = {}
    TaskInclude.get_vars = MagicMock()
    TaskInclude.get_vars.return_value = dict_0

    # Call method
    dict_1 = task_include_0.get_vars()

    assert dict_0 == dict_1



# Generated at 2022-06-25 06:19:29.966389
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    my_arg_names_0 = frozenset(sentinel.args.keys())
    my_arg_names_1 = my_arg_names_0.difference(sentinel.VALID_ARGS)
    if my_arg_names_1:
        raise AnsibleParserError()
    apply_attrs_0 = sentinel.args.get('apply', {})
    if apply_attrs_0:
        raise AnsibleParserError()



# Generated at 2022-06-25 06:19:32.385416
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict()
    task_include_0.preprocess_data(ds)




# Generated at 2022-06-25 06:19:39.983677
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    ds_0 = { 'action': 'include_tasks', 'include': '', 'tags': 'debug', 'when': '', }
    ti_0 = task_include_1.load(ds_0, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task_include_1.action == 'include_tasks'
    assert task_include_1.apply == {}
    assert task_include_1.args == { 'tags': 'debug', 'when': '', }
    assert task_include_1.block == None
    assert task_include_1.delayed_set == False
    assert task_include_1.ignore_errors == False
    assert task_include

# Generated at 2022-06-25 06:19:42.925002
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    var_17 = TaskInclude.load(Sentinel('apply', 'apply'), Sentinel())
    var_17.build_parent_block()


# Generated at 2022-06-25 06:19:48.523288
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    int_0 = 962
    task_include_0 = TaskInclude()
    var_dict_0 = task_include_0.get_vars()
    assert isinstance(var_dict_0, dict)


# Generated at 2022-06-25 06:19:58.099596
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    dict_0 = dict()
    dict_0['include'] = 'include'
    dict_0['action'] = 'action'
    dict_0['when'] = 'when'
    dict_0['tags'] = 'tags'
    dict_0['register'] = 'register'
    dict_0['timeout'] = 'timeout'
    dict_0['vars'] = 'vars'
    dict_0['no_log'] = 'no_log'
    dict_0['run_once'] = 'run_once'
    dict_0['debugger'] = 'debugger'
    dict_0['ignore_errors'] = 'ignore_errors'
    dict_0['loop'] = 'loop'
    dict_0['name'] = 'name'

# Generated at 2022-06-25 06:19:59.905125
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert type(task_include_0) == TaskInclude

# Generated at 2022-06-25 06:20:02.594325
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Tests instantiating a TaskInclude w/no args, then calls TaskInclude.build_parent_block
    task_include_0 = TaskInclude()
    assert(task_include_0.build_parent_block())
    return True



# Generated at 2022-06-25 06:20:29.682650
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    dict_1 = dict()
    dict_1['_raw_params'] = 'json=json;content=json;'
    task_0.args = dict_1
    task_0.action = 'include'
    task_0.statically_loaded = False
    dict_2 = dict()
    dict_1 = dict()
    dict_1['_raw_params'] = 'json=json;content=json;'
    dict_1['apply'] = 'json=json;content=json;'
    dict_2['_raw_params'] = dict_1['_raw_params']
    dict_2['apply'] = dict_1['apply']

# Generated at 2022-06-25 06:20:32.459104
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {}
    task_include_0 = TaskInclude()
    ds = task_include_0.preprocess_data(ds)


# Generated at 2022-06-25 06:20:37.919156
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    dict_0 = dict()
    dict_0['apply'] = dict_0
    dict_0['_raw_params'] = 'L4yatTt:|qMwq'
    dict_0['__ansible_module__'] = dict_0

# Generated at 2022-06-25 06:20:39.820485
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    # Test edge cases
    assert(True)

    # Test normal cases
    assert(True)




# Generated at 2022-06-25 06:20:43.699354
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    dict_0 = {"include": "test_case_0"}
    dict_1 = task_include_0.preprocess_data(dict_0)


# Generated at 2022-06-25 06:20:51.411268
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-25 06:20:59.219723
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    dict_0 = dict()
    dict_1 = dict()
    dict_0['action'] = 'include'

    # Test for exceptions
    with pytest.raises(AnsibleParserError) as excinfo:
        task_include_0 = TaskInclude(block=None, role=None, task_include=None)
        task_include_0.preprocess_data(dict_0)

    # Test for exception with attribute message
    assert excinfo.value.message == 'No file specified for include'

# Generated at 2022-06-25 06:21:01.286379
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    dict_0 = task_include_0.get_vars()

# Generated at 2022-06-25 06:21:12.412563
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.name = '- name: test_task_name'
    task_include_0._task_type = 'include'
    task_include_0.action = 'include'

    # Test with assert_equal
    task_include_0.statically_loaded = 0
    assert_equal(task_include_0.get_vars(), {})

    # Test with assert_true
    task_include_0.statically_loaded = 0
    assert_true(task_include_0.get_vars() == {})

    # Test with assert_raises
    task_include_0.statically_loaded = 1

    with assert_raises(AnsibleParserError) as cm:
        task_include_0.get_vars()

    assert_

# Generated at 2022-06-25 06:21:22.626346
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:21:42.279259
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    attrs_0 = dict()
    task_include_0.args['apply'] = attrs_0

    p_block = task_include_0.build_parent_block()
    assert task_include_0 == p_block


# Generated at 2022-06-25 06:21:43.360337
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()

# Generated at 2022-06-25 06:21:46.884733
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Data
    task_include_0 = TaskInclude()
    data_0 = {'action': 'include'}

    for data in [data_0,]:
        task_include_0.check_options(task_include_0, data)


# Generated at 2022-06-25 06:21:58.011524
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    int_0 = 0
    dict_0 = dict()
    dict_1 = dict()
    list_0 = list()
    tuple_0 = ()
    task_0 = Task()
    dummy_0 = None
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    str_0 = ''
    task_include_0.task_include = task_0

# Generated at 2022-06-25 06:22:02.364869
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    data_0 = dict()
    task_include_0.check_options(task_0, data_0)


# Generated at 2022-06-25 06:22:06.075527
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    integer_0 = -8
    dictionary_0 = {}
    task_include_0.check_options(dictionary_0, dictionary_0)


# Generated at 2022-06-25 06:22:06.899850
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()


# Generated at 2022-06-25 06:22:15.754755
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    str_0 = '7e84.-'
    str_1 = 'YzCw7'
    str_2 = 'Lf.Of'
    str_3 = '9t^*v$e'
    str_4 = '&'
    str_5 = 'y0&'
    str_6 = 'dck*z'
    str_7 = '35'
    str_8 = '-'
    str_9 = 'X'
    str_10 = '~'
    str_11 = 'Rb'
    str_12 = 'kEc'
    str_13 = 'F'
    str_14 = 'G'
    str_15 = 'W'
    str_16 = 'Tk'
    float_1 = -273.484
   

# Generated at 2022-06-25 06:22:26.076439
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()  # build object TaskInclude
    # test get_vars()
    answer_1 = task_include_0.get_vars()
    assert answer_1 == sorted([], key=lambda x: str(type(x)) + ' ' + str(x)), 'Expected answer_1 to be [], but it was ' + str(answer_1)
    # test get_vars()
    answer_1 = task_include_0.get_vars()
    assert answer_1 == sorted([], key=lambda x: str(type(x)) + ' ' + str(x)), 'Expected answer_1 to be [], but it was ' + str(answer_1)
    answer_1 = task_include_0.get_vars()

# Generated at 2022-06-25 06:22:28.694042
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_1 = Task()
    data_1 = {}
    task_include_1.check_options(task_1, data_1)


# Generated at 2022-06-25 06:23:09.204988
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['name'] = 'include_role'
    dict_2['ignore_errors'] = False
    dict_2['debugger'] = 'include_tasks'
    dict_2['action'] = 'include_tasks'
    dict_2['loop_with'] = 'include_tasks'
    dict_2['timeout'] = 'include_role'
    dict_2['tags'] = 'include_tasks'
    dict_2['vars'] = 'include_role'
    dict_2['register'] = 'include_role'
    dict_2['loop_control'] = None
    dict_2['run_once'] = True
    dict_2['when']

# Generated at 2022-06-25 06:23:16.964419
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    dict_0 = dict()
    dict_0['always_run'] = 1
    dict_0['action'] = 'include_role'
    dict_0['static'] = True
    dict_0['loop'] = 'value'
    dict_0['tags'] = 'tag'
    dict_0['when'] = 'when'
    dict_0['name'] = 'value'
    dict_0['no_log'] = 1
    dict_0['register'] = 'result'
    dict_0['timeout'] = 5
    dict_0['_raw_params'] = 'value'
    dict_0['_ansible_no_log'] = 1
    dict_0['_ansible_verbosity'] = 1
    dict_0['_ansible_selinux_special_fs'] = 1

# Generated at 2022-06-25 06:23:19.853486
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    str_0 = task_include_0.build_parent_block()
    assert str_0 == task_include_0


# Generated at 2022-06-25 06:23:24.509550
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    data_0 = dict()
    task_1 = task_include_0.check_options(task_0, data_0)
    pylab_0 = pylab.imshow()


# Generated at 2022-06-25 06:23:28.121650
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.task import Task
    task_0 = Task()
    task_2 = TaskInclude.load(data=task_0)
    #print(task_2)
    pass



# Generated at 2022-06-25 06:23:33.625296
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    float_0 = -662.078
    block_0 = Block()
    task_include_0._parent = block_0
    task_include_0.args = dict()
    block_0._play = task_include_0
    block_0._role = task_include_0
    task_include_0._variable_manager = task_include_0
    task_include_0._loader = task_include_0
    block_1 = block_0.build_parent_block()
    assert block_1._play is task_include_0
    assert block_1._role is task_include_0
    assert block_1.vars is task_include_0
    assert block_1.args is task_include_0
    assert block_1.block is task_include_

# Generated at 2022-06-25 06:23:43.236962
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test case 0
    task_include_0 = TaskInclude()
    task_include_0.args = dict(file='/home/darahab/Videos/data.gz')
    task_include_0.action = 'include'
    try:
        task_include_0.check_options(task_include_0, dict(file='/home/darahab/Videos/data.gz'))
        print("Test 0 failed. No exception")
    except SystemExit:
        print("Test 0 passed.")


# Generated at 2022-06-25 06:23:50.874272
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ti.action = 'include_role'
    data = {'file': 'foo.yml', 'tags': ['all', 'foo'], 'become': None}
    ti.preprocess_data(data)
    assert ti.action == 'include_role'
    assert ti.get_path() == 'foo.yml'
    assert 'become' not in ti._attributes.keys()


# Generated at 2022-06-25 06:23:53.412459
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}
    assert task_include_0.get_vars() == {}
    assert task_include_0.get_vars() == {}


# Generated at 2022-06-25 06:24:03.634239
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    block_0 = Block()
    block_0.block = []
    block_0.vars = dict()
    block_0.vars = {}
    block_0.args = dict()
    block_0.args = {}
    task_include_0._parent = block_0
    task_include_0.args = dict()
    task_include_0.args = dict()
    task_include_0.args['apply'] = None
    task_include_0.args['apply'] = {}
    task_include_0.args['apply']['block'] = []
    task_include_0.args['apply'] = {'block': []}
    task_include_0.args['_raw_params'] = 'file'

# Generated at 2022-06-25 06:25:08.073587
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    float_0 = -662.078


# Generated at 2022-06-25 06:25:10.144857
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = task_include.check_options(task_include, None)


# Generated at 2022-06-25 06:25:16.741815
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    print("Inside test_TaskInclude_build_parent_block")
    task_include_0 = TaskInclude()
    
    # Call method build_parent_block on task_include_0 - the output should be of type Block
    block_0 = task_include_0.build_parent_block()
    print("Returned object is of type " , str(type(block_0)))
    assert isinstance(block_0, Block)


# Generated at 2022-06-25 06:25:21.559623
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    float_0 = -341.0737
    float_1 = 0.127444928155
    float_2 = -60.931
    float_3 = 0.0255617063573
    float_4 = -100.0
    float_5 = 0.0
    float_6 = -64.6074389
    float_7 = 0.0
    float_8 = -0.0109599767025
    float_9 = -0.0
    # AssertionError: assert -0.0109599767025 == -0.0
    # assert False



# Generated at 2022-06-25 06:25:31.095866
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude(block=Block(parent=task_include_1))
    task_include_2.task_include = task_include_1

# Generated at 2022-06-25 06:25:34.389810
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    block_0 = task_include_0.build_parent_block()
    assert isinstance(block_0, TaskInclude)


# Generated at 2022-06-25 06:25:41.507054
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0._role = None
    float_0 = -662.078
    task_include_0.action = 'include'
    task_include_0.statically_loaded = True
    task_include_0._parent = task_include_0
    task_include_0.vars = {'test':float_0}
    task_include_0.args = {'test':float_0}
    dict_0 = task_include_0.get_vars()
    dict_1 = dict_0
    assert dict_1 == {'test':float_0}

if __name__ == '__main__':
    # Unit test for method get_vars of class TaskInclude
    test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:25:44.161926
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test: Basic test of the method
    # Init
    task_include_0 = TaskInclude()
    # Test
    task_include_0.build_parent_block()

# Generated at 2022-06-25 06:25:48.115459
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    task_include_0.check_options(task_0, None)


# Generated at 2022-06-25 06:25:59.047284
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def assert_raises_match(msg, _callable, *args, **kwargs):
        try:
            _callable(*args, **kwargs)
            assert False, 'exception was not raised'
        except Exception as e:
            assert msg in str(e)

    task_include_1 = TaskInclude()
    assert_raises_match('not a valid attribute for a TaskInclude', task_include_1.get_vars)
    task_include_1.action = 'include'
    task_include_1.vars = {}
    task_include_1.args = {}
    assert task_include_1.get_vars() == {}
    task_include_1.action = 'include'
    task_include_1.vars = {}
    task_include_1.args = {}