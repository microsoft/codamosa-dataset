

# Generated at 2022-06-25 06:16:05.726594
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # NOTE: in this case we need to use the inherited 'load' method
    # TODO: refactor both 'load' and 'check_options' to make
    # this test more straightforward to write
    task_include_0 = TaskInclude.load(
        {
            u'include': u'otherplay',
            u'apply': None,
        }
    )


# Generated at 2022-06-25 06:16:08.504645
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    var_0 = task_include_0.check_options(task_include_1, 'raw|args')


# Generated at 2022-06-25 06:16:14.356791
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    data_0 = {}
    var_0 = task_include_0.check_options(
        task_include_0.load_data(data_0),
        data_0
    )

# Generated at 2022-06-25 06:16:17.386886
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {"action":"include"}
    ds = data.copy()
    task_include_0 = TaskInclude()
    ds = task_include_0.preprocess_data(ds)
    return ds


# Generated at 2022-06-25 06:16:20.366518
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:16:23.749306
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.preprocess_data(task_include_0)



# Generated at 2022-06-25 06:16:32.062350
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = {
        'action': 'include',
        'args': {
            'file': 'ansible/test/units/modules/utility/test_template.yml',
            'apply': {
                'name': 'include_apply_example'
            }
        }
    }
    ti = TaskInclude()
    ti.load(data, variable_manager={})


# Generated at 2022-06-25 06:16:37.475184
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    print('')
    print('Test build_parent_block')
    print('=======================')


    # Set up variables
    test_var_0 = set(())
    test_var_1 = {}
    test_var_2 = []
    test_var_3 = {}
    test_var_4 = 'Test file'
    test_var_5 = []
    test_var_6 = {}
    test_var_7 = {}
    test_var_8 = []

    # Test case for method build_parent_block
    print('-- Method build_parent_block')

    # Initialise instance attribute 'statically_loaded'
    # of class TaskInclude
    TaskInclude_instance = TaskInclude()
    TaskInclude_instance.statically_loaded = False

    # Initialise instance attribute 'action'


# Generated at 2022-06-25 06:16:42.044094
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_0_task_include = TaskInclude()
    test_0_data = {'action': 'include', 'include': 'dummy_data'}
    test_0_copy = test_0_task_include.copy()
    test_0_task_include.task_include = test_0_task_include
    var_0 = test_0_task_include.preprocess_data(test_0_data)


# Generated at 2022-06-25 06:16:51.178672
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    context = PlayContext()
    context._loader = DataLoader()
    context._variable_manager = VariableManager()

    task_include_0 = TaskInclude(task_include=task_include_0)
    data_0 = '''dummy'''
    var_0 = task_include_0.load(data_0, context=context)
    print(var_0)



# Generated at 2022-06-25 06:17:05.874391
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    task_include_dic = dict([
        ('_raw_params', '../tasks/foo.yml'),
        ('tags', 'all'),
        ('no_log', True),
    ])

    task_include_0 = TaskInclude()

    task_include_1 = TaskInclude()

    task_include_2 = TaskInclude()

    task_include_3 = TaskInclude()

    task_include_4 = TaskInclude()

    task_include_0.action = 'include'

    # Negative test:
    #   Action not in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    assert task_include_0.preprocess_data(task_include_dic) == task_include_dic

    task_include_1.action = 'include_tasks'

    # Positive

# Generated at 2022-06-25 06:17:13.235154
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    if len(task_include_1.get_vars()) != 0:
        raise Exception("Unit test for method get_vars of class TaskInclude failed: Code: Expected 0, Got " + str(len(task_include_1.get_vars())))


# Generated at 2022-06-25 06:17:23.036359
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test get_vars method of TaskInclude with action 'include'
    Test passes if method get_vars returns a dict with 'tags' and 'when' attributes
    removed from the attribute args
    '''
    block_0 = Block()
    block_0.vars = {'b_var' : 'b_val'}

    task_include_0 = TaskInclude(block=block_0)
    task_include_0.action = 'include'
    task_include_0.args = {'tags' : 'exc_tag', 'when' : 'exc_when', 'incl_arg' : 'incl_val'}

    test_dict = {'tags' : 'exc_tag', 'when' : 'exc_when', 'incl_arg' : 'incl_val'}
    ret

# Generated at 2022-06-25 06:17:31.306392
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create an empty TaskInclude object
    task_include_0 = TaskInclude()
    # Validate that it is empty
    assert not task_include_0.args

    # Assign args to the TaskInclude object
    task_include_0.args = {'apply': {}}
    # Validate that the args are assigned correctly
    assert task_include_0.args == {'apply': {}}

    # Call the build_parent_block method
    block = task_include_0.build_parent_block()
    # Validate that the args are still assigned correctly
    assert task_include_0.args == {'apply': {}}

    # Validate that the block is now assigned correctly
    assert block
    assert block.parent == task_include_0
    assert len(block) == 0



# Generated at 2022-06-25 06:17:39.350646
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test case 1 that there is no apply attribute
    task_include = TaskInclude()
    parent_block = task_include.build_parent_block()
    assert parent_block == task_include
    assert task_include.args == dict()
    # Test case 2 that apply attribute is specified
    task_include = TaskInclude(args={"apply": {"test":"test value"}})
    parent_block = task_include.build_parent_block()
    assert parent_block._parent == task_include
    assert parent_block.block == []
    assert task_include.args == dict()

# Generated at 2022-06-25 06:17:45.944473
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping
    # TaskInclude check_options should not modify the passed task argument
    task_include_0 = TaskInclude.load({u'_raw_params': u'common.yml', u'action': u'include'})
    task_include_1 = TaskInclude.load({u'_raw_params': u'common.yml', u'action': u'include'})
    task_include_0.check_options(task_include_1, AnsibleMapping())
    assert id(task_include_0) != id(task_include_1)
    for k in task_include_0.args.keys():
        assert task_include_0.args[k] == task_include_1.args[k]
    # For

# Generated at 2022-06-25 06:17:52.264314
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_0_args = {'optional_arg': 'optional'}
    task_1_args = {'optional_arg': 'optional', 'action': 'include',
                   'file': './test/files/test_playbook_include.yml'}
    task_2_args = {'optional_arg': 'optional', 'action': 'import_tasks',
                   'file': './test/files/test_playbook_include.yml'}
    task_0 = TaskInclude.load(data=task_0_args)
    task_1 = TaskInclude.load(data=task_1_args)
    task_2 = TaskInclude.load(data=task_2_args)
    assert task_0.get_vars() == task_0_args
    assert task_1.get_vars

# Generated at 2022-06-25 06:17:55.639451
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0._parent = Block()
    task_include_1 = TaskInclude()
    task_include_1._parent = Block()
    task_include_1.args = {'block':[]}
    assert True == isinstance(task_include_0.build_parent_block(), TaskInclude)
    assert True == isinstance(task_include_1.build_parent_block(), Block)

# Generated at 2022-06-25 06:18:01.264604
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block_2 = Block.load({}, play=None, task_include=None, role=None, variable_manager=None, loader=None)
    args_0 = dict()
    args_0['apply'] = dict()
    args_0['apply']['block'] = []
    args_0['apply']['block'].append(block_2)
    task_include_0 = TaskInclude()
    task_include_0.args = dict()
    task_include_0.args['apply'] = dict()
    task_include_0.args['apply']['block'] = []
    task_include_0.args['apply']['block'].append(block_2)
    task_include_0._parent = block_2
    task_include_0._role = None
    task_include_0._variable

# Generated at 2022-06-25 06:18:03.747096
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # FIXME: implement this test
    # assert TaskInclude.build_parent_block() == None
    pass



# Generated at 2022-06-25 06:18:09.872491
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    x = TaskInclude()
    assert x.get_vars() == {}



# Generated at 2022-06-25 06:18:19.803685
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args = {'a_key': 'a_val'}
    task_include_0.action = 'include'

    # calling parent class' get_vars to test if it works in the expected way
    all_vars = task_include_0.get_vars()
    assert 'a_key' in all_vars
    assert all_vars['a_key'] == 'a_val'
    del task_include_0.args
    # test if get_vars() returns an empty dict when action is not 'include'
    # and args is not available
    all_vars = task_include_0.get_vars()
    assert type(all_vars) == dict
    assert len(all_vars) == 0

#

# Generated at 2022-06-25 06:18:29.536841
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.vars = {'key1': 'value1'}
    task_include_1.args = {'param1': 'value1'}
    assert (task_include_1.get_vars() == {'key1': 'value1', 'param1': 'value1'})
    task_include_1.action = 'include_role'
    assert (task_include_1.get_vars() == {'key1': 'value1'})
    task_include_1.action = 'include_tasks'
    assert (task_include_1.get_vars() == {'key1': 'value1'})
    task_include_1.action = 'import_role'
   

# Generated at 2022-06-25 06:18:31.290519
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}



# Generated at 2022-06-25 06:18:37.284934
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    task_include_0 = TaskInclude()

    # test expected behavior
    task_include_0.args = {'apply': {'block': []}}
    task_include_0._parent = { '_play': [] }
    assert(task_include_0.build_parent_block() == task_include_0.args['apply'])

    # test expected behavior
    task_include_0.args = {'other_args': {'block': []}}
    task_include_0._parent = { '_play': [] }
    assert(task_include_0.build_parent_block() == task_include_0)

    # test expected behavior
    task_include_0.args = {'other_args': {'block': []}}
    task_include_0._parent = None

# Generated at 2022-06-25 06:18:42.788793
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    p_block = task_include_1.build_parent_block()
    assert p_block is task_include_1


# Generated at 2022-06-25 06:18:53.521249
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    # initialize the dictionary to test
    test_dict = {
        'args': {
            'apply': 'not a real apply',
            'file': 'not a real file',
            '_raw_params': 'not a real raw_params'
        },
        'action': 'include'
    }

    # test for a bad apply value
    with pytest.raises(AnsibleParserError) as exec_info:
        task_include.check_options(task_include.load_data(test_dict, loader=DictDataLoader(), variable_manager=VariableManager()), test_dict)
    assert 'Invalid options for include: apply' in str(exec_info.value)

    # test for a mismatched 'file' and '_raw_params'

# Generated at 2022-06-25 06:19:00.797888
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 2
    # To test the case where task.action is not in C._ACTION_INCLUDE
    task_include_2 = TaskInclude()
    task_include_2._parent = FieldAttribute(name="_parent", public=False, private=True, parent=FieldAttribute(name="_parent", public=False, private=True, default=None), default=None, serialize_when_none=True)
    task_include_2.vars = FieldAttribute(name="vars", public=False, private=True, default=None)
    task_include_2.args = FieldAttribute(name="args", public=False, private=True, default=None)
    task_include_2.action = "command"
    all_vars_2 = task_include_2.get_vars()

# Generated at 2022-06-25 06:19:11.197423
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Parse the test case (from Create an object of class TaskInclude and cache it in variable task_obj0)
    test_case_0()
    task_obj0 = TaskInclude(block=None, role=None, task_include=None)

    # Get the value of variable 'VALID_INCLUDE_KEYWORDS' for class TaskInclude
    task_obj0_VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS

    # Call method preprocess_data of object task_obj0 and store the result in variable task_obj0_preprocess_data0.
    task_obj0_preprocess_data0 = task_obj0.preprocess_data(task_obj0_VALID_INCLUDE_KEYWORDS)

    # Check if 'task

# Generated at 2022-06-25 06:19:13.214616
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    vars = task_include_0.get_vars()
    assert vars is None


# Generated at 2022-06-25 06:19:17.638483
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    result = task_include_0.build_parent_block()
    assert isinstance(result, TaskInclude)


# Generated at 2022-06-25 06:19:20.404201
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data_0 = {
        'action': 'include',
        'file': 'foo.yml',
        'task_name': 'some task',
        'tags': ['foo', 'bar']
    }
    TaskInclude_0 = TaskInclude()
    TaskInclude_0.preprocess_data(data_0)

# Generated at 2022-06-25 06:19:25.952840
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    data = dict(
        apply = dict(
            block = [
                dict(
                task = dict(
                    name = "Task included in the parent block",
                    action = "debug",
                    args = dict(
                        msg = "Testing 'apply' option"
                        )
                    )
                )
            ]
        )
    )
    task_include_0 = TaskInclude.load(data)
    task_include_0_block_0 = task_include_0.build_parent_block()
    assert isinstance(task_include_0_block_0, Block)

# Generated at 2022-06-25 06:19:26.897911
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    TaskInclude.build_parent_block(None)



# Generated at 2022-06-25 06:19:30.294254
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    ans_block_0 = task_include_0.build_parent_block()
    assert isinstance(ans_block_0, Block)


# Generated at 2022-06-25 06:19:38.608992
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    p_block = task_include_0._parent
    all_vars = task_include_0.get_vars()
    assert(all_vars == {})
    task_include_0._parent = None
    all_vars = task_include_0.get_vars()
    assert(all_vars == {})
    task_include_0._parent = p_block
    all_vars = task_include_0.get_vars()
    assert(all_vars == {})
    task_include_0.args['tags'] = 'install'
    task_include_0.args['when'] = 'install'
    all_vars = task_include_0.get_vars()
    assert(all_vars == {})
    task

# Generated at 2022-06-25 06:19:47.617409
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # First task include with get_vars function
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.args = { 'a': 1, 'b': 2, 'tags': 1, 'when': 1 }
    task_include_1.role = "Web"

    task_include_2 = TaskInclude()
    task_include_2.action = 'include'
    task_include_2.args = { 'a': 1, 'b': 2, 'tags': 1, 'when': 1 }
    task_include_2.role = "App"

    task_include_3 = TaskInclude()
    task_include_3.action = 'include'

# Generated at 2022-06-25 06:19:57.318833
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Check that preprocess_data runs without error, and that it returns the same object
    # as was passed
    test_data_0 = {'action': 'import_role'}
    TaskInclude_obj_0 = TaskInclude()
    test_data_processed_0 = TaskInclude_obj_0.preprocess_data(test_data_0)
    assert test_data_processed_0 == test_data_0

    # Check that preprocess_data runs with data instead of file
    test_data_1 = {'action': 'import_role', 'data': 'import_role_data'}
    TaskInclude_obj_1 = TaskInclude()
    test_data_processed_1 = TaskInclude_obj_1.preprocess_data(test_data_1)
    assert test_data_process

# Generated at 2022-06-25 06:20:05.138014
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Set up
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds=dict()
    ds['action'] = 'include_role'
    ds['apply'] = {'debugger': 'on'}
    ds['apply']['block'] = []

    task_include_0 = TaskInclude()
    task_include_0.args = ds['apply']
    task_include_0._role = None
    task_include_0._loader = DataLoader()
    task_include_0._variable_manager = VariableManager()
    task_include_0._play = Play

# Generated at 2022-06-25 06:20:13.397678
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude(block=None, role=None, task_include=None)
    task._parent = Task(block=None, role=None, task_include=None)
    task._parent.args['a'] = 'b'
    task._parent.vars['c'] = 'd'
    task.vars['e'] = 'f'
    task.args['g'] = 'h'
    task.action = 'action'
    result = task.get_vars()
    expected = {'g': 'h', 'e': 'f'}
    assert result == expected


# Generated at 2022-06-25 06:20:29.545534
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    line = dict(
        name="get_vars",
        become=False,
        become_user='root',
        args=dict(a=1, b='xyz'),
        action='setup',
        local_action=None,
    )
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude(task_include=task_include_0)
    task_include_2 = TaskInclude(task_include=task_include_1)
    task_include_3 = TaskInclude(task_include=task_include_2)
    task_include_4 = TaskInclude(task_include=task_include_3)
    task_include_5 = TaskInclude(task_include=task_include_4)


# Generated at 2022-06-25 06:20:40.471896
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_10 = TaskInclude()
    task_include_10.vars = {'name': 'ansible'}
    task_include_10.args = {'_raw_params': '/tmp/included_file'}
    expected = {'name': 'ansible', '_raw_params': '/tmp/included_file'}
    result = task_include_10.get_vars()
    assert expected == result
    task_include_10.action = "include_role"
    expected = {'name': 'ansible'}
    result = task_include_10.get_vars()
    assert expected == result
    task_include_10_include = TaskInclude()
    task_include_10_include.vars = {'name': 'ansible'}
    task_include_10_include

# Generated at 2022-06-25 06:20:49.403024
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.args['apply'] = {}
    task_include_1.vars = dict()
    task_include_1.action = 'include'
    task_include_1._parent = Task()
    task_include_1._parent.get_vars = dict()
    task_include_1.args = dict()
    task_include_1.args['tags'] = 'tags'
    task_include_1.args['when'] = 'when'
    task_include_1.get_vars()

# Generated at 2022-06-25 06:20:50.877289
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ### Default Index
    task_include_0 = TaskInclude()
    
    # get_vars method call
    task_include_0.get_vars()


# Generated at 2022-06-25 06:20:58.326400
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-25 06:21:05.955912
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    print("Testing TaskInclude::preprocess_data()")

    # test 1 - include
    task_include_data = {
        'include': { 'file': 'defaults/main.yml' }
    }
    task_include = TaskInclude().load(task_include_data)
    assert task_include.thing is Sentinel
    assert task_include.action == 'include'
    assert task_include._has_magic is False
    assert task_include.name is None
    assert task_include.args == { 'file': 'defaults/main.yml', '_raw_params': 'defaults/main.yml', 'when': None, 'tags': [] }
    assert task_include.block is None
    assert task_include.notify is None
    assert task_include.loop is None

# Generated at 2022-06-25 06:21:13.766876
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    TEST CASE : TaskInclude get_vars
    '''
    task_include = TaskInclude()
    task_include.vars = {'var1': 'value1'}
    task_include.action = 'include'
    task_include.args = {'_raw_params': 'ansible/test_include.yml'}
    result = task_include.get_vars()
    if result != {'var1': 'value1', '_raw_params': 'ansible/test_include.yml'}:
        raise AssertionError("Unit test failed to test task include get_vars.")
    return True


# Generated at 2022-06-25 06:21:23.652923
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    repr_0 = repr(task_include_0)
    repr_1 = repr(task_include_0._loader)
    repr_2 = repr(task_include_0._block)
    repr_3 = repr(task_include_0._role)
    repr_4 = repr(task_include_0._play)
    repr_5 = repr(task_include_0._task_include)
    ansible_0 = C.ANSIBLE_VERSION
    ansible_1 = C.DEFAULT_CALLBACK_WHITELIST
    ansible_2 = C.DEFAULT_CALLBACK_PLUGINS
    ansible_3 = C.DEFAULT_HOST_LIST
    ansible_4 = C.DEFAULT_UNLOCALHOST_BINARY
    ans

# Generated at 2022-06-25 06:21:30.865761
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create an instance of TaskInclude
    task_include_1 = TaskInclude()
    task_include_1.set_loader(DataLoader())

    # Create a 'parent' play and a 'parent' block for the instance of TaskInclude
    parent_play_1 = Play()
    parent_play_1.set_loader(DataLoader())
    parent_block_1 = Block()
    parent_block_1.set_loader(DataLoader())
    task_include_1._play = parent_play_1
    task_include_1._parent = parent_block_1

    # Load an example task into the instance of TaskInclude
    task_include_1.load(dict(action='include', file='/some_file'))

    # Check that there is no parent block created by default
    assert task_include_1.get

# Generated at 2022-06-25 06:21:34.537125
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    data_0 = {}
    task_include_0.preprocess_data(data_0)



# Generated at 2022-06-25 06:21:47.706001
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    for test_case in [{'include_args': {'apply': {'other':'data', 'block':[]}, 'name':'my_play', 'play':'my_play'}}]:
        task_include = TaskInclude()
        task_include.args = test_case['include_args']
        task_include._parent = Task()
        task_include.statically_loaded = False
        parent_block = task_include.build_parent_block()
        assert same_type_obj(parent_block, Block()), "Incorrect type of object"
        assert parent_block.name == 'my_play', "Object has incorrect name"


# Generated at 2022-06-25 06:21:58.631132
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = dict()
    task_include.args['apply'] = dict()
    task_include.args['apply']['block'] = []

    task_include._parent = dict()
    task_include._parent.get_vars = dict()
    task_include._parent.get_vars.return_value = dict()
    task_include._parent.get_vars.return_value['tags'] = dict()
    task_include._parent.get_vars.return_value['when'] = dict()
    task_include._parent.get_vars.return_value['when'] = dict()

    task_include.vars = dict()
    task_include.vars['tags'] = dict()
    task_include.vars['when'] = dict()
   

# Generated at 2022-06-25 06:22:08.800568
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class Parent():
        def __init__(self):
            self.vars = {'foo': 'bar'}
            self.parent = None
        def get_vars(self):
            return self._do_get_vars(self.vars, self.parent)
        def _do_get_vars(self, vars, parent):
            if parent is not None:
                vars.update(parent.get_vars())
            return vars

    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.vars = {"a":"b"}
    task_include_0.args = {"c":"d", "e":"f"}
    parent = Parent()
    parent.parent = None

# Generated at 2022-06-25 06:22:11.234416
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    block = task_include.build_parent_block()
    assert(block is not None)



# Generated at 2022-06-25 06:22:15.291718
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
   t = TaskInclude()

   assert t.get_vars() == dict()


# Generated at 2022-06-25 06:22:20.724427
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    display.verbosity = 3
    task_include = TaskInclude()

    # Test: When 'action' is in C._ACTION_INCLUDE_TASKS
    attr_map = task_include.preprocess_data({'action': 'include', 'file': 'test', 'not_a_valid_attribute': 'test'})
    assert attr_map['not_a_valid_attribute'] is Sentinel

    # Test when 'action' is not in C._ACTION_INCLUDE_TASKS
    attr_map = task_include.preprocess_data({'action': 'test', 'file': 'test', 'not_a_valid_attribute': 'test'})
    assert attr_map['not_a_valid_attribute'] is not Sentinel

# Generated at 2022-06-25 06:22:28.942837
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    b = Block(parent=None)
    b.vars = dict(a=1, b=2)
    ti = TaskInclude(block=b)
    ti.vars = dict(c=0, d=1)
    ti.args = dict(e=4, f=5)
    ti.action = 'include'
    ti.statically_loaded = False
    all_vars = ti.get_vars()
    assert all_vars == dict(a=1, b=2, c=0, d=1, e=4, f=5)

# Generated at 2022-06-25 06:22:38.314377
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test case: all options are allowed for 'action'
    my_arg_names = frozenset(['file','_raw_params','tags','when','apply','args','collections','debugger','ignore_errors','loop','loop_control','loop_with',
                              'name','no_log','register','run_once','timeout','vars'])
    my_action = 'include'
    valid_opts = C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS

# Generated at 2022-06-25 06:22:48.258370
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test case where action is not in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    task_include_0 = TaskInclude()
    ds_0 = {}
    ds_0['name'] = 'fist'
    task_include_0.action = 'include_role'
    task_include_0.preprocess_data(ds_0)

    ds_1 = {}
    ds_1['name'] = 'fist'
    ds_1['tags'] = 'first'
    task_include_0.action = 'include_tasks'
    task_include_0.preprocess_data(ds_1)

    ds_2 = {}
    ds_2['name'] = 'fist'
    ds_2['tags'] = 'first'
    ds

# Generated at 2022-06-25 06:22:54.610573
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict(action = 'include', file = 'roles/av-server/tasks/post-install.yml', apply = dict(operator = 'and', str = "{{ ansible_hostname == 'avsrv1' and ansible_os_family == 'Debian' }}"))
    result = task_include_0.preprocess_data(ds)
    assert result == ds, "Failed TaskInclude preprocess_data() test"


# Generated at 2022-06-25 06:23:14.546259
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # a block without a parent block or role context
    test_case_1 = dict (
        block=dict(
            name="top-level block",
            block=[]),
        apply=dict())

    # a block with a parent block
    test_case_2 = dict (
        block=dict(
            name="top-level block",
            block=[]),
        apply=dict(
            block=dict(
                name="parent block",
                block=[])))

    # a block with a parent block and apply
    test_case_3 = dict (
        block=dict(
            name="top-level block",
            block=[]),
        apply=dict(
            block=dict(
                name="parent block",
                block=[]),
            register="myblock"))

    # a block with a parent block, apply,

# Generated at 2022-06-25 06:23:24.800106
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockTaskInclude:
        def __init__(self, block=None, role=None, task_include=None):
            self.block = block
            self.role = role
            self.task_include = task_include
            self.args = {}
            self.action = 'action'

    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()
    task_include_4 = TaskInclude()
    task_include_5 = TaskInclude()
    task_include_6 = TaskInclude()
    task_include_7 = TaskInclude()
    task_include_8 = TaskInclude()
    task_include_9 = TaskInclude()

    # the 'action' keyword

# Generated at 2022-06-25 06:23:32.315060
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude(block=None, role=None, task_include=None)
    p_block_0 = task_include_0.build_parent_block()
    assert p_block_0.__class__.__name__ == 'TaskInclude'
    task_include_1 = TaskInclude(block=None, role=None, task_include=None)
    p_block_1 = task_include_1.build_parent_block()
    assert p_block_1.__class__.__name__ == 'TaskInclude'
    task_include_2 = TaskInclude(block=None, role=None, task_include=None)
    p_block_2 = task_include_2.build_parent_block()

# Generated at 2022-06-25 06:23:34.540421
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include_role'
    ds = dict({'action': 'include_role'})
    assert task_include_0.preprocess_data(ds) == ds

# Generated at 2022-06-25 06:23:39.764728
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This test verifies the following edge case:
      - When ``apply`` is set, a block is created as parent object
    '''
    task_include_1 = TaskInclude()
    task_include_1.vars = {'var1': 'var1_val'}
    task_include_1.args = {'apply': {'var2': 'var2_val', 'var3': 'var3_val'}}

    p_block = task_include_1.build_parent_block()
    assert p_block.args['var2'] == 'var2_val'
    assert p_block.args['var3'] == 'var3_val'
    assert p_block.vars['var1'] == 'var1_val'

# Generated at 2022-06-25 06:23:49.072102
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args['apply'] = 'YamlDict'
    task_include_0.args['ignore_errors'] = 'YamlBool'
    task_include_0.args['loop'] = 'YamlDict'
    task_include_0.args['loop_control'] = 'YamlDict'
    task_include_0.args['loop_with'] = 'YamlDict'
    task_include_0.args['name'] = 'YamlString'
    task_include_0.args['no_log'] = 'YamlBool'
    task_include_0.args['register'] = 'YamlString'

# Generated at 2022-06-25 06:23:53.566404
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    t.action = 'include'
    assert  t.get_vars() == {}, "get_vars works incorrectly"
    t.action = 'import_role'
    assert  t.get_vars() == {}, "get_vars works incorrectly"
    t.action = 'include_role'
    assert  t.get_vars() == {}, "get_vars works incorrectly"

# Generated at 2022-06-25 06:23:58.938077
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    block = ti.build_parent_block()
    assert type(block) is TaskInclude


# Generated at 2022-06-25 06:24:10.092415
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    #
    # Test 'action' attribute on null task
    #
    task = task_include._load_data({}, False)

    task.action = 'include'
    task.args = dict(file='file')
    task = task.check_options(task, {})
    assert task.args['_raw_params'] == 'file'
    #
    # Test 'action' is None
    #
    task.action = None
    task = task.check_options(task, {})
    assert task.args['_raw_params'] == 'file'
    #
    # Test 'action' attribute with include
    #
    task.action = 'include'
    task.args = dict(file='file', tags=['tag'])

# Generated at 2022-06-25 06:24:20.459721
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    other_arg_names_0 = frozenset({'_raw_params', 'file'})
    data_0 = {'apply': {'ignore_errors': False}, 'block': [], 'vars': {'include_vars': '{{ ... }}', 'vars': '{{ ... }}'}, 'action': 'include', 'args': {'_raw_params': '{{ ... }}', 'file': '{{ ... }}'}, 'delegate_to': None, 'ignore_errors': False, 'loop': '{{ ... }}', 'when': '{{ ... }}', 'loop_with_dict': None, 'register': 'a', 'timeout': '{{ ... }}', 'run_once': False, 'tags': 'all'}

# Generated at 2022-06-25 06:24:48.570512
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TaskInclude with 'action' that are not in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    # should not raise any exception
    task_include_1 = TaskInclude()
    task_include_1.action = 'copy'
    task_include_1.args = {'apply': {}, 'file': 'dummy_file', 'vars': [], 'when': 'dummy_when',
                           'tags': ['dummy_tag']}
    assert task_include_1.check_options(task_include_1, {}) == task_include_1

    # 'apply' key should be in self.args
    task_include_2 = TaskInclude()
    task_include_2.action = 'include'
    # create fake args (missing apply)
    args = task

# Generated at 2022-06-25 06:24:56.251231
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.args = {'some_key': 'some_value', 'other_key': 'other_value'}
    task_include_1.build_parent_block()
    #print("args=", task_include_1.args)

if __name__ == "__main__":
    test_case_0()
    test_TaskInclude_build_parent_block()

# Generated at 2022-06-25 06:24:57.665771
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-25 06:25:01.750196
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create TaskInclude instance
    task_include_1 = TaskInclude()
    # Check TaskInclude.get_vars() returns dict
    assert type(task_include_1.get_vars()) is dict



# Generated at 2022-06-25 06:25:10.966196
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.vars = dict(foo='bar')
    task_include.args = dict(bar='foo')
    task_include.action = 'include'
    assert task_include.action in C._ACTION_INCLUDE
    result = task_include.get_vars()
    expected_keys = set(task_include.vars.keys() + task_include.args.keys())
    assert set(result.keys()) == expected_keys
    assert result.get('foo') == 'bar'
    assert result.get('bar') == 'foo'

# Generated at 2022-06-25 06:25:19.832830
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Setup the TaskInclude object
    task_include = TaskInclude()
    task_include._parent = type('', (object,), {'get_vars': lambda self: {'foo': 'bar'}})()
    task_include.vars = {'a1': 'b1'}
    task_include.args = {'a2': 'b2'}
    # Execution of the method
    result = task_include.get_vars()
    # Test the result
    assert len(result) == 3

if __name__ == '__main__':
    import pytest, sys
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-25 06:25:30.594970
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # init
    task_include_0 = TaskInclude()

    # config
    task_include_0.vars = dict()
    task_include_0.vars = dict()
    task_include = task_include_0
    task_include.action = 'include'
    task_include.vars = dict()

    # test
    try:
        var = task_include.get_vars()
    except Exception as e:
        assert type(e) == KeyError

    # config
    task_include.action = 'action'
    task_include.vars = dict()

    # test
    try:
        var = task_include.get_vars()
    except Exception as e:
        assert type(e) == KeyError

    # config
    task_include.action = 'include'
    task_

# Generated at 2022-06-25 06:25:40.155467
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()

    class PreClass:
        def get_vars(self):
            return "get_vars"

    class ParentClass:
        _parent = PreClass()
        _task_includes = None
        action = "include"
        args = {"ar1": "arg1", "ar2": "arg2"}
        vars = {"var1": "value1", "var2": "value2"}

        def get_vars(self):
            return {"pvar1": "pvalue1", "pvar2": "pvalue2"}

    class PostClass:
        def get_vars(self):
            return "get_vars"

    # include
    ParentClass._task_includes = [PostClass()]
    task_include = ParentClass()
    assert task_include.get_v

# Generated at 2022-06-25 06:25:41.879685
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    assert task_include_1.build_parent_block() is task_include_1


# Generated at 2022-06-25 06:25:47.511302
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    b = Block()

    ti = TaskInclude(block = b)

    p = Block()
    p.block = [ti]
    b.block = [p]

    apply_attrs = {
        'block': [],
        'do_something': 'True',
        'when': 'do_something is defined'
    }

    ti._variable_manager = True
    ti._loader = True
    ti.args['apply'] = apply_attrs

    p_block = ti.build_parent_block()

    assert apply_attrs == p_block.args

    assert p_block.action is None
    assert p_block.delegate_to is None
    assert p_block.when is None

    assert apply_attrs['when'] == p_block.block[0].when