

# Generated at 2022-06-25 06:16:09.687960
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    data_0 = dict(action='include', name='p', args=dict(file='m'))
    data_1 = TaskInclude.preprocess_data(task_include_0, data_0)
    assert data_1 == {'args': {'file': 'm'}, 'action': 'include', 'name': 'p'}
    data_2 = dict(action='include_role', name='a', args=dict(file='b', something=None))
    data_3 = TaskInclude.preprocess_data(task_include_0, data_2)
    assert data_3 == {'args': {'file': 'b'}, 'action': 'include_role', 'name': 'a'}

# Generated at 2022-06-25 06:16:18.498405
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Create instance of TaskInclude
    task_include_1 = TaskInclude()

    # Create a variable for argument 'ds'
    ds_1 = {'tags':['mytag']}

    # Call method TaskInclude.preprocess_data with arguments task_include_1,ds_1
    # Create variable 'result_of_TaskInclude_preprocess_data_1' with return value of TaskInclude.preprocess_data()
    result_of_TaskInclude_preprocess_data_1 = task_include_1.preprocess_data(ds_1)

    assert result_of_TaskInclude_preprocess_data_1 == {'tags':['mytag']}



# Generated at 2022-06-25 06:16:28.317075
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Check that a dict is returned
    task_include_0 = TaskInclude()
    # Check that the content of the dictionary returned is correct
    data = {'a': 1}
    task_include_1 = TaskInclude()
    res = task_include_1.preprocess_data(data)
    assert isinstance(res, dict)
    assert res == data
    # Check that the content of the dictionary returned is correct
    data = {'tags': 'foo', 'when': ['bar']}
    task_include_2 = TaskInclude()
    res = task_include_2.preprocess_data(data)
    assert isinstance(res, dict)
    assert res == data
    # Check that the content of the dictionary returned is correct
    data = {'action': 'include_tasks'}
    task_include_3

# Generated at 2022-06-25 06:16:33.116384
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """check_options should raise error if unknown args are found"""
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task_include import TaskInclude
    data = dict(action='include', file='foo', unknown_arg='bar')
    task_include = TaskInclude()
    with pytest.raises(AnsibleParserError) as execinfo:
        task_include.check_options(task_include, data)
    assert "Invalid options for include: unknown_arg" in str(execinfo.value)



# Generated at 2022-06-25 06:16:35.427886
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    expected_ret_value = None
    ret_value = task_include_0.check_options(task_include_0, Sentinel)
    assert ret_value == expected_ret_value


# Generated at 2022-06-25 06:16:46.070810
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ta = TaskInclude()
    arg1 = {'action': 'include_role', 'name': 'myrole'}
    arg2 = {'action': 'include_role', 'name': 'myrole', 'yaml': 'hello', 'action': 'include_role'}
    arg3 = {'action': 'include_role', 'name': 'myrole', 'yaml': 'hello', 'action': 'import_role'}

    assert ta.preprocess_data(arg1) == {'action': 'include_role', 'name': 'myrole'}
    assert ta.preprocess_data(arg2) == {'action': 'include_role', 'name': 'myrole', 'action': 'include_role'}

# Generated at 2022-06-25 06:16:58.515217
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti_1 = TaskInclude()
    ti_2 = TaskInclude()
    ti_3 = TaskInclude()
    ti_4 = TaskInclude()
    ti_5 = TaskInclude()
    ti_6 = TaskInclude()
    ti_7 = TaskInclude()

    ds_1 = {"action": "include"}
    ds_2 = {"action": "import_tasks"}
    ds_3 = {"action": "include_role"}
    ds_4 = {"action": "import_role"}
    ds_5 = {"action": "import_playbook"}
    ds_6 = {"action": "include_role", "a": "b"}
    ds_7 = {"action": "include", "a": "b"}


# Generated at 2022-06-25 06:17:10.529018
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.utils.vars import combine_vars

    task_include_0 = TaskInclude()
    task_include_0.args = {'action': 'include_role', '_raw_params': Sentinel(), 'name': Sentinel()}

    # Empty nested vars
    result = task_include_0.get_vars()
    assert isinstance(result, dict)
    assert result == {}

    # Update the nested vars
    task_include_0.vars = {'test_key': 'test_value'}
    result = task_include_0.get_vars()
    assert isinstance(result, dict)
    assert result == {'test_key': 'test_value'}
    # Default 'name' var should be removed
    assert task_include_0.args.get('name') is None



# Generated at 2022-06-25 06:17:21.191510
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # In this test_case, 
    # the action of task_include_0 is 'include',
    # so the method get_vars() should return {'user': 'root'},
    # because the 'args' of task_include_0 is {'user': 'root'}
    # and the 'vars' of task_include_0 is None
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {'user': 'root'}
    task_include_0.vars = None
    ret_0 = task_include_0.get_vars()

    # The expected result of get_vars()
    exp_ret_0 = {'user': 'root'}

    assert ret_0 == exp_ret_0




# Generated at 2022-06-25 06:17:30.065706
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
     task_include_0 = TaskInclude()

     # TEST 1:
     task_include_0.args = [{'apply': {'block': []}}]
     p_block_0 = task_include_0.build_parent_block()
     assert p_block_0.__class__.__name__ == "Block"
     assert p_block_0.block == []
     assert p_block_0.play == None
     assert p_block_0.task_include == task_include_0
     assert p_block_0.role == None
     assert p_block_0.variable_manager == None
     assert p_block_0.loader == None
     assert p_block_0.loop_control == None
     assert p_block_0.vars == {}
     assert p_block_0.default_vars

# Generated at 2022-06-25 06:17:41.440853
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'

    task_include.args = dict()
    task_include.vars = dict()

    all_vars = task_include.get_vars()
    assert all_vars == dict()

    task_include.args = dict(a=1, b=2)
    task_include.vars = dict(c=3, d=4)
    all_vars = task_include.get_vars()
    assert all_vars == dict(a=1, b=2, c=3, d=4)


# Generated at 2022-06-25 06:17:50.459406
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """Unit test for method build_parent_block of class TaskInclude"""

    # (1) build from empty task_include

    # Given
    args = {}
    task_include_1 = TaskInclude()
    task_include_1.args = args

    # When
    parent_block = task_include_1.build_parent_block()

    # Then
    assert task_include_1 == parent_block
    assert 'apply' not in task_include_1.args

    # (2) build from task_include with apply specified but no block specified

    # Given
    args = {'apply': {}}
    task_include_2 = TaskInclude()
    task_include_2.args = args

    # When
    parent_block = task_include_2.build_parent_block()

    # Then
    assert parent

# Generated at 2022-06-25 06:17:59.774101
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    fake_play = None
    fake_role = None
    fake_variable_manager = None
    fake_loader = None
    single_task_attrs = {
        'apply': {'block': []}
    }
    single_task_attrs_define_vars = {
        'apply': {'block': [], 'vars': {'foo': 'bar'}}
    }
    task_include_0 = TaskInclude(block=None, role=fake_role, task_include=None)
    task_include_1 = TaskInclude(block=fake_play, role=fake_role, task_include=None)
    task_include_1.vars = single_task_attrs
    task_include_2 = TaskInclude(block=fake_play, role=fake_role, task_include=None)

# Generated at 2022-06-25 06:18:03.300330
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {'apply': {}}
    task_include._parent = 'parent'
    p_block = task_include.build_parent_block()
    assert p_block == task_include

# Generated at 2022-06-25 06:18:13.279080
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.vars = None
    task_include_1.action = "include"
    task_include_1.args = {"arg1": "value1", "arg2": "value2"}

    task_include_1.args["tags"] = "indirect"
    task_include_1.args["when"] = "indirect"
    task_include_1.get_vars()

    task_include_2 = TaskInclude()
    task_include_2.vars = {"key1": "value1", "key2": "value2"}
    task_include_2.action = "include"
    task_include_2.args = {"arg1": "value1", "arg2": "value2"}

    task_include_2.args["tags"]

# Generated at 2022-06-25 06:18:16.935602
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    for action in C._ACTION_INCLUDE_TASKS:
        task = TaskInclude(block=Block())
        task.action = action
        task.args = dict(foo='bar', action=action)
        vars = task.get_vars()
        assert vars['action'] == action
        assert vars['foo'] == 'bar'
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        task = TaskInclude(block=Block())
        task.action = action
        task.args = dict(foo='bar', action=action)
        vars = task.get_vars()
        assert not vars.keys() or 'action' not in vars
        assert not vars.keys() or 'foo' not in vars

# Generated at 2022-06-25 06:18:26.508202
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0_ds_0 = dict()
    task_include_0_ds_0['action'] = 'wrong action'
    task_include_0_ds_1 = dict()
    task_include_0_ds_1['action'] = 'include'
    task_include_0_ds_2 = dict()
    task_include_0_ds_2['action'] = 'include_role'
    task_include_0_ds_3 = dict()
    task_include_0_ds_3['action'] = 'import_tasks'
    task_include_0_ds_4 = dict()
    task_include_0_ds_4['action'] = 'import_role'


# Generated at 2022-06-25 06:18:35.196653
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()
    task_include_4 = TaskInclude()
    task_include_5 = TaskInclude()
    task_include_6 = TaskInclude()
    task_include_7 = TaskInclude()

    task_include_1.action = 'include'
    task_include_1.args = {"file":"include_task.yaml", "apply":{"ignore_errors":[]} }
    task_include_1.check_options(task_include_1, task_include_1.action)

    task_include_2.action = 'include_role'
    task_include_2.args = {"file":"include_task.yaml", "apply":{"ignore_errors":[]} }
    task_

# Generated at 2022-06-25 06:18:43.036490
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.vars = {'foo': 'bar', 'baz': 'qux'}
    task_include.args = {'file': './playbooks/test.yml', 'tags': ['tag1', 'tag2']}

    assert 'foo' in task_include.get_vars()
    assert 'bar' in task_include.get_vars().values()
    assert 'baz' in task_include.get_vars()
    assert 'qux' in task_include.get_vars().values()

    assert 'tags' not in task_include.get_vars()
    assert 'when' not in task_include.get_vars()

# Generated at 2022-06-25 06:18:48.537524
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_5 = TaskInclude()
    task_include_6 = task_include_5.load({'action':'include_tasks'})


# Generated at 2022-06-25 06:18:59.096522
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Test no apply section
    t = TaskInclude()

    p_block = t.build_parent_block()
    assert p_block is t

    # Test apply section
    t.args['apply'] = {"debugger": "1", "register": "dtr"}
    p_block = t.build_parent_block()
    assert p_block.block is not None
    assert p_block.block[0] is t
    assert p_block._parent is None
    assert p_block.role is None
    assert p_block.vars is None

# Generated at 2022-06-25 06:19:04.113263
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    block = task_include.build_parent_block()

    assert(block.__class__.__name__ == 'Block')
    assert(isinstance(block, TaskInclude))


# Generated at 2022-06-25 06:19:15.609434
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    playbook_dir = '.'
    playbook_filename = 'test.yml'
    inventory_filename = 'inventory'
    file_name = os.path.join(playbook_dir, playbook_filename)
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=inventory_filename)

    with open(file_name) as f:
        yaml_data = yaml.load(f)

    block = Block()
    role = None
    task_include = None
    task_include_0 = TaskInclude.load(yaml_data[0], block=block, role=role, task_include=task_include,
                                      variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 06:19:26.732092
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.task_include as ti
    import ansible.playbook.task as t
    import ansible.vars.unsafe_proxy as uap

    data = {
        "name": "A",
        "invalid_option": "bad",
        "file": "B",
        "apply": "C",
        "tags": "D",
        "action": "include_tasks",
    }
    variable_manager = uap.VarsModule()
    task = ti.TaskInclude.load(
        data, variable_manager=variable_manager, loader=None)
    assert(task.action == 'include_tasks')
    assert(task.name == 'A')
    # "invalid_option" should have been removed
    assert(not task.args.get('invalid_option'))

# Generated at 2022-06-25 06:19:31.645264
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()
    dict_23 = dict()
    dict_24 = dict()

# Generated at 2022-06-25 06:19:39.529524
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Build a task_include object
    loader = None
    variable_manager = None
    play_context = None
    new_loader = True
    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext(play=None, options=None, variable_manager=None, loader=None)
    task_include_0 = TaskInclude(block=None, role=None, task_include=None, loader=loader, variable_manager=variable_manager, play_context=play_context)
    # Build a parent block
    possible_parent_block = Block()
    possible_parent_block.name = "Parent_Block_name"
    possible_parent_block.block = []
    possible_parent_block.tags = []
    possible_parent_block.always = []
    possible_parent_block.res

# Generated at 2022-06-25 06:19:48.317460
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test that parent block is created for normal tasks when apply is specified
    task_include_data = {'action': 'include', 'apply': {'tags': ['test'], 'block': []}}
    task_include = TaskInclude.load(task_include_data)
    parent_block = task_include.build_parent_block()
    assert task_include.block == task_include
    assert task_include.block != parent_block
    assert parent_block.name == 'test'
    assert parent_block.parent.name == 'include'
    assert parent_block.block == parent_block
    assert parent_block.parent.block == parent_block
    # Test that parent block is created for include tasks when apply is specified

# Generated at 2022-06-25 06:19:57.916680
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    id = 'id'
    name = 'name'
    args = dict(param = 'param')
    action = 'action'
    loop = 'loop'
    loop_args = 'loop_args'
    when = 'when'
    async_val = 'async_val'
    async_poll_interval = 'async_poll_interval'
    poll_interval = 'poll_interval'
    retries_delay = 'retries_delay'
    until = 'until'
    run_once = 'run_once'
    ignore_errors = 'ignore_errors'
    tags = 'tags'
    register = 'register'
    environment = 'environment'
    vars = dict(my_var = 'my_value')

# Generated at 2022-06-25 06:20:05.599920
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import collections
    from ansible.playbook.task import Task

    data = {'action': 'action', 'args': {'_raw_params': 'file'}}
    task = Task(block=None, role=None)
    task.__dict__ = data.copy()
    task.args = collections.defaultdict(list)
    for k,v in data['args'].items():
        task.args[k] = v

    task_include_0 = TaskInclude(block=None, role=None)

    # Test when action is not in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    task.action = 'action_0'
    task_include_0.check_options(task, data)
    # Test when action is in C._ACTION_ALL_PROPER_INCLU

# Generated at 2022-06-25 06:20:09.766036
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # these methods are not implemented yet, so we're just making sure they
    # don't explode
    ti = TaskInclude()
    ti.get_vars()
    ti.get_vars_files()
    ti.get_vars_from_argspec()

# Generated at 2022-06-25 06:20:25.195303
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    assert not task_include_1.build_parent_block()

    task_include_1.args['apply'] = {
        'name': 'Test',
        'hosts': 'localhost',
        'block': None,
        'attributes': {
            'foo': None,
            'bar': 1
        }
    }

    assert isinstance(task_include_1.build_parent_block(), Block)
    assert task_include_1.build_parent_block().attributes['bar'] == 1



# Generated at 2022-06-25 06:20:36.485602
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.warning('This test is based on tests/functional/action_plugins/test_include.py')
    # exclude_tasks
    task_include_1 = TaskInclude()
    task_include_1.name = 'include_1'
    task_include_1.action = 'include_role'
    task_include_1.block = Block(
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        loops=dict(),
        loop_vars=dict(),
        vars=dict(),
    )
    task_include_1.args = {'name': 'https://gitlab.com/gitlab-org/security-products/gitlab-ansible-roles/-/blob/master/gitlab.yml'}
    task_include

# Generated at 2022-06-25 06:20:47.769482
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # create the tasks
    task_include = TaskInclude()
    parent_block = Block()
    task = Task()
    parent_block.block = [task]
    task_include.parent_block = parent_block
    parent_block._parent = task_include
    parent_block.args = {"a": 1, "b": 2, "c": 3,}
    task.args = {"d": 4, "e": 5, "f": 6,}

    # run the test
    #assert task_include.get_vars() == {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6,}
    task_include_get_vars = task_include.get_vars()
    assert task_include_get_vars["a"] == 1
   

# Generated at 2022-06-25 06:20:57.410729
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_task_include = TaskInclude(task_include={'apply':{'scope':{'path':'some/path'}}, 'tags': ['a', 'b']})
    assert test_task_include.get_vars() == {'apply': {'scope': {'path': 'some/path'}}, 'tags': ['a', 'b']}
    test_task_include = TaskInclude(task_include={'action': 'include', 'apply':{'scope':{'path':'some/path'}}, 'tags': ['a', 'b']})
    assert test_task_include.get_vars() == {'scope': {'path': 'some/path'}, 'tags': ['a', 'b']}

# Generated at 2022-06-25 06:21:01.048439
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''Unit test for method get_vars of class TaskInclude'''
    task_include_0 = TaskInclude()
    # get_vars should return dict without throwing exception
    test_value = task_include_0.get_vars()
    assert isinstance(test_value, dict)

# Generated at 2022-06-25 06:21:12.265097
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class TestTaskInclude:
        pass

    task_include = TaskInclude()
    task_include._parent = TestTaskInclude()
    task_include._parent.get_vars = TaskInclude.get_vars

    task_include.vars = {'k1': 'v1'}
    task_include.args = {'k2': 'v2'}
    task_include.action = 'include'
    assert task_include.get_vars() == {'k1': 'v1', 'k2': 'v2'}
    task_include.action = 'include_role'
    assert task_include.get_vars() == {'k1': 'v1', 'k2': 'v2'}
    task_include.action = 'include_tasks'
    assert task_include.get

# Generated at 2022-06-25 06:21:14.450737
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    my_task_include = TaskInclude()
    my_task_include.args['my_var'] = 'my_value'
    my_task_include.action = 'include'
    my_var = my_task_include.get_vars()['my_var']
    assert my_var == 'my_value'

# Generated at 2022-06-25 06:21:25.368156
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Input: {
            apply = {
                tags = 'abc'
                when = 'def'
            }
        }

    Output: {
            _parent = {
                block = [
                    tags  : 'abc'
                    when  : 'def'
                ]
            }
        }
    """

    task_include_1 = TaskInclude()

    task_include_1.args['apply'] = {
        'tags': 'abc',
        'when': 'def',
    }

    p_block_0 = task_include_1.build_parent_block()

    assert p_block_0._parent is None
    assert len(p_block_0.block) == 1

# Generated at 2022-06-25 06:21:29.730201
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_1.args['apply'] = {'foo': 'bar'}
    p_block = task_include_1.build_parent_block()
    assert p_block.block is not None
    assert p_block.block == []
    assert p_block.args == {'foo': 'bar'}
    assert task_include_1.args == {}
    assert p_block.task_include is task_include_1
    assert p_block.task_include.args == {}


# Generated at 2022-06-25 06:21:34.202122
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task = Task()
    task.action = 'include'
    data = {'action': 'include', 'file' : 'test_file'}
    task_include_1.check_options(task, data)


# Generated at 2022-06-25 06:21:56.958890
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'_raw_params':'file', 'apply':{'block':[]}}
    task_include._parent._play = 'play'
    task_include._parent._role = 'role'
    task_include._parent.vars = 'vars'
    task_include._parent.tags = 'tags'
    task_include._parent.when = 'when'
    task_include._parent.deprecated_vars = 'deprecated_vars'
    task_include._parent.handler_vars = 'handler_vars'
    task_include._parent.deprecated_task_vars = 'deprecated_task_vars'
    task_include._role = 'role'

# Generated at 2022-06-25 06:22:00.431422
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test = TaskInclude(invalid_var='invalid_value')
    test.args['arg1'] = 'arg1_value'
    test.args['arg2'] = 'arg2_value'
    test.action = 'include'
    result = test.get_vars()
    assert result == {'arg1': 'arg1_value',
                      'arg2': 'arg2_value'}


# Generated at 2022-06-25 06:22:10.331918
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test to validate the error case of check_options with invalid action
    task_include_1 = TaskInclude()
    with pytest.raises(AnsibleParserError) as error_info:
        task_include_1.check_options({'action': 'include_role'}, {})
    assert error_info.match('Invalid options for include_role') is not None

    # Test to validate the error case of check_options with invalid option for action
    task_include_2 = TaskInclude()
    with pytest.raises(AnsibleParserError) as error_info:
        task_include_2.check_options({'action': 'include_role', 'file': 'foo.yml', 'bar': 'baz'}, {})
    assert error_info.match('invalid keys for a TaskInclude') is not None

# Generated at 2022-06-25 06:22:20.890340
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()

    apply_attrs = task_include_0.args.pop('apply', {})
    if apply_attrs:
        apply_attrs['block'] = []
        p_block = Block.load(
            apply_attrs,
            play=task_include_0._parent._play,
            task_include=task_include_0,
            role=task_include_0._role,
            variable_manager=task_include_0._variable_manager,
            loader=task_include_0._loader,
        )
    else:
        p_block = task_include_0

    assert type(p_block) is TaskInclude


# Generated at 2022-06-25 06:22:25.108115
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()
    assert(result != None)


# Generated at 2022-06-25 06:22:34.354125
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # create a mock task object
    task_include_obj = TaskInclude()

    # create a mock args dictionary
    args_dict = {'apply' : {'block': [], 'name' : 'test_block_name'}}

    #  set the args to task_include_obj
    task_include_obj.args = args_dict

    #  create a mock parent_object for task_include_obj
    task_include_obj.parent = 'parent_object'

    #  create a mock variable_manager for task_include_obj
    task_include_obj.variable_manager = 'variable_manager'

    #  create a mock role object
    role_obj = {'role' : 'role'}

    #  set the role to task_include_obj
    task_include_obj._role = role_obj

    #

# Generated at 2022-06-25 06:22:37.742259
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    TaskInclude_instance = TaskInclude()
    result = TaskInclude_instance.get_vars()


# Generated at 2022-06-25 06:22:44.042107
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    loader = DictDataLoader({
        "templates/include_with_apply.json": """
        { "include": "{{ tasks_dir }}/main.yml",
          "vars": { "tasks_dir": "tasks" },
          "apply": {
            "block": { "start": 1, "end": 100, "step": 1 }
          }
        }
        """
    })
    variable_manager = VariableManager()

    # 1 - build_parent_block should return parent block with expected
    #     attributes

# Generated at 2022-06-25 06:22:52.380080
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_obj = TaskInclude()
    task_include_obj.args = {
        '_parent': True,
        '_raw_params': '- hosts: test1',
        'apply': {
            'block': [],
            'collections': [],
            'debugger': 'on_error',
            'loop': '{{ groups[group_name] }}',
            'loop_control': {
                'loop_var': 'inventory_hostname'
                },
            'name': 'Hosts as inventory',
            'tags': [],
            'when': True
        },
        }
    task_include_obj._parent = True
    expected_result = type(task_include_obj)
    result = type(task_include_obj.build_parent_block())
    assert result == expected_result

# Generated at 2022-06-25 06:22:56.577177
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0.build_parent_block() == task_include_0
    task_include_0.args = {'apply': {}}
    assert isinstance(task_include_0.build_parent_block(), Block)


# Generated at 2022-06-25 06:23:29.095253
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Initialize the task include instance calling one of its __init__ methods
    # then initialize the attributes needed for the method to be tested
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'apply': {'block': 'block_0', 'something': 'something_0'}, 'tags': 'tags_0', 'when': 'when_0'}
    task_include._parent = {'_play': 'play_0'}
    task_include._variable_manager = 'variable_manager_0'
    task_include._loader = 'loader_0'
    # Run the task include method being tested, passing the attributes needed
    task_include.build_parent_block()
    # Check for the expected result
    assert(task_include.args['apply'] == {})
   

# Generated at 2022-06-25 06:23:32.013359
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti._validate_args = {}
    ti._validate_vars = {}
    result = ti.get_vars()
    assert result == {}
    ti._action = 'include'
    result = ti.get_vars()
    assert result == {}

# Generated at 2022-06-25 06:23:37.875975
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args['a'] = 'b'
    assert task_include_0.get_vars() == {'a': 'b'}
    task_include_0.action = 'include'
    result = task_include_0.get_vars()
    assert 'a' not in result
    assert 'when' not in result
    assert 'tags' not in result

# Generated at 2022-06-25 06:23:43.706995
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args['apply'] = {'a': 'b'}
    parent_block = task_include.build_parent_block()
    assert parent_block.a == 'b'



# Generated at 2022-06-25 06:23:53.996383
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    data = {
        'action': 'include',
        'args': {
            'a': 1, 'b': 2
        }
    }
    task_include.check_options(task_include, data)

    data = {
        'action': 'import_role',
        'args': {
            'a': 1, 'b': 2
        }
    }
    task_include.check_options(task_include, data)

    data = {
        'action': 'include',
        'args': {
            'a': 1, 'b': 2, 'foo': 'bar'
        }
    }

# Generated at 2022-06-25 06:23:57.910908
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()


# Generated at 2022-06-25 06:24:03.339347
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.args = {'_uses_shell': False, '_raw_params': '{{ playbook_dir }}./delete_old_snapshots.sh', '_task_fields': []}
    task_include_0.action = 'include'
    task_include_0.loop = '{{ my_mongo_servers }}'
    task_include_0.tasks = [{'failed_when': '{{ "false" not in result.stdout }}',
                             'name': 'Listing Files',
                             'register': 'result',
                             'shell': 'ls -l /var/log/'}]
    task_include_0.when = 'successful_replica_set'

# Generated at 2022-06-25 06:24:11.381677
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0._parent = None
    task_include_0.vars = {}
    task_include_0.args = {}
    result = task_include_0.get_vars()
    assert result == {}

    task_include_1 = TaskInclude()
    task_include_1.BASE = frozenset()
    task_include_1.OTHER_ARGS = frozenset()
    task_include_1._parent = None
    task_include_1.vars = {}
    task_include_1.args = {}
    result = task_include_1.get_vars()
    assert result == {}

    task_include_2 = TaskInclude()
    task_include_2.BASE = frozenset(())
    task_include_

# Generated at 2022-06-25 06:24:19.135631
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Initialization of a dict for the test
    dict_for_test={
        "action": "include",
        "file": "C:\\Users\\hmas\\Desktop\\Ansible-script\\example\\tasks\\hoge.yml"
    }
    
    # Instanciation of the TaskInclude class
    task_include = TaskInclude()
    
    # Load the data in the task_include
    task_include.load_data(dict_for_test)
    
    # Assert on the result of the test
    assert task_include.get_vars() == dict_for_test

# Generated at 2022-06-25 06:24:20.380999
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    assert(task_include_1.get_vars() == {})


# Generated at 2022-06-25 06:25:15.509543
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Tests for TaskInclude.build_parent_block(self)
    # Block.load is called in TaskInclude.build_parent_block(self)
    # TaskInclude.__init__() is called in Block.load
    # TaskInclude._load_data is called in TaskInclude.__init__
    # Task._load_data is called in TaskInclude._load_data
    # TaskInclude.check_options is called in TaskInclude._load_data
    # Task._load_data is called in TaskInclude.check_options
    block = Block()

# Generated at 2022-06-25 06:25:21.065065
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include._parent = Block()
    task_include._parent.get_vars = lambda: {'vars': 'vars'}
    task_include.vars = {'vars': 'vars'}
    task_include.args = {'args': 'args'}

    assert task_include.get_vars() == {'vars': 'vars', 'args': 'args'}
    task_include.action = 'include'
    assert task_include.get_vars() == {'vars': 'vars', 'args': 'args'}



# Generated at 2022-06-25 06:25:30.773614
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    ti = TaskInclude()

    # test case with data dict, no apply and no valid args.
    data = dict(
        action='include_role',
        file='some_path',
        no_log=True,
    )
    task = ti.check_options(ti.load_data(data), data)

    # test case with data dict, no apply and with valid args.
    data = dict(
        action='include_role',
        file='/some/dir/task.yml',
        name='test_role',
        tags=['a', 'b'],
        no_log=True,
    )
    task = ti.check_options(ti.load_data(data), data)

    # test case with data dict, apply with no args.

# Generated at 2022-06-25 06:25:33.276022
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.build_parent_block()

# Generated at 2022-06-25 06:25:36.582999
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}


# Generated at 2022-06-25 06:25:48.035298
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    display.verbosity = 3

    task_include_0 = TaskInclude()
    apply_attrs_0 = {}

    args_0 = {}
    args_0.update(apply_attrs_0)

    task_include_0.args.update(args_0)

    p_block_0 = task_include_0.build_parent_block()

    # Second order check for method 'build_parent_block' of class TaskInclude,
    # a variable of type Block
    assert isinstance(p_block_0, Block)
    assert p_block_0.parent is None
    assert p_block_0.always_run is False
    assert p_block_0.any_errors_fatal is False
    assert p_block_0.auto_finalize is False

# Generated at 2022-06-25 06:25:59.047545
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test 1
    task_include_1 = TaskInclude.load({
        'apply': {
            'meta': {},
            'block': [{'meta': {}, 'rescue': [{}, {}]}]
        },
        'file': 'something.yml',
        'something_else': 'abcd'
    })
    assert task_include_1.get_vars() == {'something_else': 'abcd'}

    # Test 2
    task_include_2 = TaskInclude.load({
        'apply': {
            'meta': {},
            'block': []
        },
        'file': 'something.yml',
        'something_else': 'abcd'
    })
    assert task_include_2.get_vars() == {'something_else': 'abcd'}