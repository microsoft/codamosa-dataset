

# Generated at 2022-06-25 06:15:59.077417
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    block_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:16:04.080918
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    dict_0 = task_include_0.get_vars()
    print(dict_0)


# Generated at 2022-06-25 06:16:10.749046
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block_0 = Block()
    block_0.vars = {'y': 'vars', }
    block_0.post_validate = MagicMock(name='post_validate')
    block_0.post_validate.return_value = None
    block_0.load = MagicMock(name='load')
    block_0.load.return_value = None
    block_0.filter_tagged_tasks = MagicMock(name='filter_tagged_tasks')
    block_0.filter_tagged_tasks.return_value = None
    task_include_0 = TaskInclude(block_0)
    task_include_0.action = '- include: x'
    task_include_0.args = {'x': {}, '_raw_params': 'foo', }
   

# Generated at 2022-06-25 06:16:14.490681
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    data = dict()
    task = dict()
    assert task_include_0.check_options(task, data) == task


# Generated at 2022-06-25 06:16:22.998177
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:16:26.618310
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    ds = Sentinel()
    task_include_0.preprocess_data(ds)


# Generated at 2022-06-25 06:16:27.960307
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.check_options


# Generated at 2022-06-25 06:16:31.574566
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # create a TaskInclude object
    # use known values
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    # execute the method load
    try:
        task_include_0.load()
    except Exception as e:
        display.debug(e)
    else:
        raise Exception("Expected exception")


# Generated at 2022-06-25 06:16:37.114167
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    attrib = task_include_0._validate_vars(dict())
    assert attrib == {}
    attrib = task_include_0._validate_when(dict())
    assert attrib == {}
    attrib = task_include_0._validate_tags(dict())
    assert attrib == {}
    attrib = task_include_0._validate_import_role(dict())
    assert attrib == {}
    attrib = task_include_0._validate_always_run(dict())
    assert attrib == {}
    attrib = task_include_0._validate_any_errors_fatal(dict())
    assert attrib == {}

# Generated at 2022-06-25 06:16:37.570177
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass

# Generated at 2022-06-25 06:16:47.205687
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {'key': 'value'}
    task = TaskInclude()
    display.display(data)
    task.preprocess_data(data)
    display.display(data)

# Generated at 2022-06-25 06:16:53.444748
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data_0 = dict()
    action_0 = 'include_tasks'
    task_include_0 = TaskInclude(data_0)
    task_include_0.action = action_0
    args_0 = dict()
    task_include_0.args = args_0
    variables_0 = dict()
    task_include_0.vars = variables_0
    temp_0 = dict()
    task_include_0.templar = temp_0
    task = task_include_0.preprocess_data(data_0)
    assert task.action == 'include_tasks'

# Generated at 2022-06-25 06:16:59.385312
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class non_empty_iterable:
        def __iter__(self):
            return [1, 2, 'a', 'b'][__iter__()]

        def __len__(self):
            return None

    try:
        # input arguments for the test case
        ds = [{'action': 'copy', '_ansible_ignore_errors': None, 'apply': {}}]
        task_include_0 = TaskInclude()
        task_include_0.preprocess_data(ds)
    except AnsibleParserError as e:
        assert type(e) == AnsibleParserError
        display.display(str(e))
    else:
        raise Exception('Expected a AnsibleParserError to be raised')


# Generated at 2022-06-25 06:17:00.146754
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    pass



# Generated at 2022-06-25 06:17:11.820272
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
  # Create an instance of class TaskInclude
  task_include_0 = TaskInclude()
  task_include_1 = TaskInclude()

  # get_vars of TaskInclude class returns a dict
  assert isinstance(task_include_0.get_vars(),dict)
  assert isinstance(task_include_1.get_vars(),dict)

  # copy method of TaskInclude class returns an object of class TaskInclude
  assert isinstance(task_include_0.copy(),TaskInclude)
  assert isinstance(task_include_1.copy(),TaskInclude)

  # build_parent_block method of TaskInclude class returns an object of class TaskInclude
  assert isinstance(task_include_0.build_parent_block(),TaskInclude)

# Generated at 2022-06-25 06:17:12.977824
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TODO
    pass


# Generated at 2022-06-25 06:17:20.411592
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    my_arg_names = ['YWJjZGVm']
    bad_opts = ['bW9yZA==']
    data = '\x02\x03\x05\x07\x0b\x0d\x11\x13\x17\x1d\x1f'
    task = task_include_0.check_options(task_include_0, data)


# Generated at 2022-06-25 06:17:27.954158
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    We override the parent Task() classes get_vars here because
    we need to include the args of the include into the vars as
    they are params to the included tasks. But ONLY for 'include'
    '''
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    expected_result = dict()
    assert task_include_0.get_vars() == expected_result


# Generated at 2022-06-25 06:17:40.217511
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.args = {}
    task_include_0.action = 'include_role'
    str_0 = task_include_0.check_options(task_include_0, list_0)
    print('task_include_0.args {%s}' % task_include_0.args)
    print('task_include_0.action {%s}' % task_include_0.action)
    print('str_0 {%s}' % str_0)
    str_1 = task_include_0.check_options(task_include_0, list_0)
    print('task_include_0.args {%s}' % task_include_0.args)

# Generated at 2022-06-25 06:17:43.999543
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.action = 'include'
    print("\n")
    print("TEST CASE 0")
    print("\n")
    print("Testing get_vars:")
    print(task_include_0.vars)
    print(task_include_0.get_vars())

# Generated at 2022-06-25 06:17:53.441129
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    dict_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:18:00.067708
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Assert that Sentinel is not a valid attribute for TaskInclude
    _s = Sentinel()
    ds = {'action': 'include', 'vars': _s, 'tags': _s}
    list_0 = []
    ti = TaskInclude(list_0)
    try:
        ti.preprocess_data(ds)
    except AnsibleParserError as ae:
        assert "is not a valid attribute for a" in ae.msg, ae.msg
    else:
        assert False, "Should have failed"


# Generated at 2022-06-25 06:18:02.941367
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {}
    task_include_0 = TaskInclude(None)
    task_include_0.preprocess_data(ds)


# Generated at 2022-06-25 06:18:03.876105
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pass


# Generated at 2022-06-25 06:18:06.426320
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.build_parent_block()


# Generated at 2022-06-25 06:18:13.135921
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    We override the parent Task() classes get_vars here because
    we need to include the args of the include into the vars as
    they are params to the included tasks. But ONLY for 'include'
    '''
    # Populate the arguments
    args = {}
    args["file"] = "test_file"
    args["_raw_params"] = "test_raw_params"
    args["apply"] = {}
    args["vars"] = "test_vars"
    args["tags"] = "test_tags"
    args["ignore_errors"] = "test_ignore_errors"
    args["when"] = "test_when"
    args["action"] = "static"
    action_args = {}
    action_args["name"] = "test_name"

# Generated at 2022-06-25 06:18:15.890938
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    dict_0 = dict()
    task_block_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:18:26.374254
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-25 06:18:34.221290
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)

    # Unit test for method get_vars of class TaskInclude
    args_0 = dict()
    args_0['action'] = 'include'
    args_0['file'] = 'foo.yml'
    task_include_0.vars = dict()
    task_include_0.args = args_0
    assert isinstance(task_include_0.get_vars(), dict) == True
    assert task_include_0.vars.get('action') == 'include'
    assert task_include_0.vars.get('file') == 'foo.yml'


# Generated at 2022-06-25 06:18:39.325273
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create an instance of class TaskInclude
    list_0 = []
    task_include_0 = TaskInclude(list_0)

    dict_0 = {}
    dict_0['apply'] = dict_0
    task_include_0.args = dict_0
    # Call unit test of method build_parent_block of class TaskInclude
    task_include_0.build_parent_block()


# Generated at 2022-06-25 06:18:50.030071
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    vars = task_include_0.get_vars()
    ##
    assert_equal(vars, {})


# Generated at 2022-06-25 06:18:50.897136
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    pass



# Generated at 2022-06-25 06:18:52.545170
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # TaskInclude.build_parent_block()
    test_case_0()
# End of test 1


# Generated at 2022-06-25 06:18:54.406835
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass # nothing to test at the moment?


# Generated at 2022-06-25 06:18:59.276297
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TaskInclude_load() returns Task
    test_variable_manager = None
    test_loader = None
    test_data = {}
    test_block = None
    test_role = None
    test_task_include = None

    test_TaskInclude_load = TaskInclude.load(test_data, test_block, test_role, test_task_include, test_variable_manager, test_loader)
    assert isinstance(test_TaskInclude_load, Task)


# Generated at 2022-06-25 06:19:06.199040
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.args['file'] = 'file'
    task_include_0.action = C._ACTION_INCLUDE
    var_0 = task_include_0.get_vars()
    assert (var_0 == {'file': 'file'})
    assert (var_0['file'] == 'file')


# Generated at 2022-06-25 06:19:10.461549
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    get_vars_r_0 = task_include_0.get_vars()
    get_vars_r_0 = task_include_0.get_vars()
    get_vars_r_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:19:20.398363
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create an instance of class TaskInclude
    task_include_0 = TaskInclude()
    # Inject needed dependencies
    task_include_0._parent = Mock_TaskInclude()
    task_include_0.vars = dict()
    task_include_0.args = dict()

    # Call the method
    assert task_include_0.get_vars() == {}
    # Inject needed dependencies
    task_include_0._parent = Mock_TaskInclude()
    task_include_0.vars = dict()
    task_include_0.args = {'tags': 'tags', 'when': 'when'}

    # Call the method
    assert task_include_0.get_vars() == {}


# Generated at 2022-06-25 06:19:26.492417
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = {
        'action': 'include',
        'file': 'hello',
        'args': {
            'test': 'world'
        },
        'apply': {
            'block': [
                {
                    'action': 'include',
                    'file': 'hello',
                    'args': {
                        'test': 'world'
                    }
                }
            ]
        }
    }
    task_include_0 = TaskInclude.load(data)
    task_include_0.dump()
    task_include_0.post_validate(templar=None, shared_loader_obj=None)



# Generated at 2022-06-25 06:19:30.618693
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    assert not task_include_0.get_vars(), 'Expected get_vars to return False, got %s' % ('%s' % task_include_0.get_vars())

# Generated at 2022-06-25 06:19:48.447363
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    dict_0 = {}
    assert not task_include_0.get_vars() == dict_0

# Generated at 2022-06-25 06:19:54.950739
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    list_0 = []
    task_include_0 = TaskInclude(list_0)

    str_0 = 'include'
    dict_0 = {'action': str_0}
    result = task_include_0.preprocess_data(dict_0)



# Generated at 2022-06-25 06:20:01.440022
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    # Test return value of method get_vars.
    #
    # Returns:  None
    # Assertion:
    # - Confirm that data type of return value is dict
    '''

    list_0 = []
    task_include_0 = TaskInclude(list_0)
    list_1 = []
    task_0 = Task(list_1)
    # Test return value of method get_vars.
    assert(isinstance(task_include_0.get_vars(), dict))
    assert(isinstance(task_0.get_vars(), dict))



# Generated at 2022-06-25 06:20:04.901553
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    try:
        task_include_1.check_options()
    except TypeError:
        # No arguments, only self is required
        pass


# Generated at 2022-06-25 06:20:10.415467
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TODO: mock these attributes
    loop = "loop"
    tags = "tags"

    task_include_0 = TaskInclude()
    task_include = task_include_0.load(
        {"action":"include","loop":loop,"tags":tags}
    )
    assert isinstance(task_include, TaskInclude)


# Generated at 2022-06-25 06:20:13.606744
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    # Unknown keyword argument: _raw_params
    task_include_0._load_data(extra_vars=None,variable_manager=None,loader=None)

# Generated at 2022-06-25 06:20:25.651494
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    ds_0 = \
        {
            'action': 'include_role',
            'args': {
                'collections': ['galaxy.roles.aadamko.sensu_go'], 
                'defaults': {
                    'rabbitmq_ssl_cert_path': '/usr/local/etc/sensu/ssl/cert.pem', 
                    'rabbitmq_ssl_key_path': '/usr/local/etc/sensu/ssl/key.pem', 
                    'rabbitmq_ssl_verify': True
                }
            }, 
            'tags': ['all']
        }


# Generated at 2022-06-25 06:20:35.756495
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    block_0 = Block()
    block_0._role = task_include_0._role
    block_0._play = task_include_0._play
    block_0._loader = task_include_0._loader
    block_0._variable_manager = task_include_0._variable_manager
    task_include_0._parent = block_0
    task_include_0.args = {"key1": "value1"}
    block_0.vars = {"key3": "value3"}
    assert task_include_0.build_parent_block() is task_include_0


# Generated at 2022-06-25 06:20:47.281756
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    def test_method(name, args, vars, expected_result):
        block = []
        task_include = TaskInclude(block)
        task_include._play = 'play'
        task_include.action = name
        task_include.args = args
        task_include.vars = vars
        actual_result = task_include.get_vars()
        assert actual_result == expected_result


# Generated at 2022-06-25 06:20:50.982259
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    assert True


# Generated at 2022-06-25 06:21:14.168702
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ds_0 = {}
    task_include_0 = TaskInclude(ds_0)
    task_include_0.action = 'include_role'
    task_include_0.args = {'ignore_errors': False, 'register': 'test_var'}
    task_include_0.block = []
    task_include_0.delegate_to = 'localhost'
    task_include_0.delegate_facts = True
    task_include_0.failed_when = {'test_condition': False}
    task_include_0.ignore_errors = True
    task_include_0.loop = 'loop_var_0'
    task_include_0.loop_control = 'loop_control_0'
    task_include_0.name = 'include_task_name'
    task_include_0

# Generated at 2022-06-25 06:21:17.803383
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    args_0 = {}
    args_0['key_0'] = 'val_0'
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.args = args_0
    var_0 = task_include_0.get_vars()
    print(var_0)

test_case_0()
#test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:21:21.893813
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    dict_0 = {}
    dict_0['action'] = 'include'
    dict_0['debugger'] = None
    dict_0['_uses_shell'] = False
    dict_0['_raw_params'] = 'roles/webserver/tasks/main.yml'
    dict_0['ignore_errors'] = False
    dict_0['name'] = None
    dict_0['no_log'] = 'False'
    dict_0['register'] = None
    dict_0['run_once'] = False
    dict_0['collections'] = None
    dict_0['tags'] = None
    dict_0['when'] = None
    dict_0['_ansible_verbosity'] = 0

# Generated at 2022-06-25 06:21:24.571405
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.action = 'include'
    result = task_include_0.get_vars()



# Generated at 2022-06-25 06:21:27.990125
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test case 0
    # In the test case 0, we create a TaskInclude object. Then we call
    # the method get_vars of the object and we should get the expected
    # result.
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    all_vars_0 = task_include_0.get_vars()
    assert all_vars_0 == {}, 'In the test case 0, we get the expected result.'



# Generated at 2022-06-25 06:21:31.327177
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    class_0 = task_include_0.build_parent_block()

    print(class_0)


if __name__ == "__main__":
    test_TaskInclude_build_parent_block()

# Generated at 2022-06-25 06:21:43.398155
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = {"action": "include_role", "tasks": "tasks/main.yml", "name": "test"}
    (task_include_0, task_include_1, task_include_2, task_include_3) = TaskInclude.load(data)
    (task_include_4, task_include_5, task_include_6, task_include_7) = TaskInclude.load(data)
    data = {"action": "include_tasks", "tasks": "tasks/main.yml", "name": "test", "apply": {"loop": "{{ loop_idx }}"}}
    (task_include_4, task_include_5, task_include_6, task_include_7) = TaskInclude.load(data)
    assert "apply" in task_include_0.__

# Generated at 2022-06-25 06:21:45.135207
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = {'action': 'include', 'file': 'new_file.yml'}
    task_include_0 = TaskInclude()
    task_include_0.check_options(task_include_0.load_data(data), data)


# Generated at 2022-06-25 06:21:47.428822
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    data_0 = {}
    assert task_include_0.preprocess_data(data_0) == {}




# Generated at 2022-06-25 06:21:49.449720
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    block_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:22:20.923983
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # key: expected, val: input
    tests_ds = {
        #TODO: add unit tests for this method
    }

    for key, value in tests_ds.items():
        # run the test
        answer = TaskInclude.preprocess_data(value)

        # verify the test output against expectations
        assert key == answer


# Generated at 2022-06-25 06:22:25.788596
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    file_0 = 'file_0'
    task_include_0 = TaskInclude()
    data_0 = {}
    task_include_1 = task_include_0.check_options(task_include_0, data_0)


# Generated at 2022-06-25 06:22:26.667499
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass


# Generated at 2022-06-25 06:22:32.217968
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import pytest

    list_0 = []
    task_include_0 = TaskInclude(list_0)
    with pytest.raises(AttributeError) as attribute_error:
        task_include_0.build_parent_block()
    # Missing: role, loader, variable_manager
    assert attribute_error.value.args[0] == 'Missing required attribute(s): role, loader, variable_manager'



# Generated at 2022-06-25 06:22:42.659832
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.args = {'apply': {'block': [], 'name': 'switch', 'when': 'inventory_hostname in groups[\'switches\']', 'loop': '{{ lookup(\'file\', \'hosts/{{ inventory_hostname }}.yml\').split() }}', }, }
    task_include_0.other_vars = dict()
    task_include_0._role = None
    task_include_0.statically_loaded = False
    task_include_0._loader = FixtureLoaderNone()
    task_include_0._variable_manager = InventoryVariableManager(loader=None, variable_manager=None)
    task_include_0._shared_loader_obj = None
    task_include_

# Generated at 2022-06-25 06:22:45.933713
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    try:
        task_include_0.build_parent_block()
    except Exception:
        display.expected_exception()


# Generated at 2022-06-25 06:22:47.634135
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    get_vars_0 = task_include_0.get_vars()



# Generated at 2022-06-25 06:22:51.856682
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.args = {
      'apply': {'tags': 'tag1'},
      'file':   'file1'
    }
    task_include_0._parent = None
    task_include_0.action = 'include'
    task_include_0._role = None
    task_include_0._variable_manager = None
    task_include_0._loader = None

    ret_type = type(task_include_0.build_parent_block())
    assert ret_type == Block

# Generated at 2022-06-25 06:22:54.610958
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class_args = []
    task_include_0 = TaskInclude(class_args)
    assert task_include_0.get_vars() == []


# Generated at 2022-06-25 06:23:00.262523
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.args['apply'] = {}
    task_include_0._parent = None
    task_include_0._role = None
    task_include_0._variable_manager = None
    task_include_0._loader = None

    assert task_include_0.build_parent_block() == task_include_0


# Generated at 2022-06-25 06:24:29.714317
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    options_0 = dict()
    options_0['file'] = 'PLAYBOOKS'
    test_TaskInclude_0 = TaskInclude(options_0)
    options_1 = dict()
    options_1['_raw_params'] = 'PLAYBOOKS'
    test_TaskInclude_1 = TaskInclude(options_1)
    options_2 = dict()
    options_2['file'] = 'PLAYBOOKS'
    options_2['_raw_params'] = 'PLAYBOOKS'
    options_2['action'] = 'PLAYBOOKS'
    options_2['apply'] = 'PLAYBOOKS'
    test_TaskInclude_2 = TaskInclude(options_2)
    options_3 = dict()
    options_3['file'] = 'PLAYBOOKS'

# Generated at 2022-06-25 06:24:34.146759
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    with pytest.raises(AnsibleParserError):
        task_include_0.get_vars()
    ds = {'action': 'include'}
    task_include_1 = TaskInclude(list_0, ds)
    assert task_include_1.get_vars() is not None

# Generated at 2022-06-25 06:24:40.300189
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.action = "include_tasks"
    task1_0 = TaskInclude(list_0)
    task1_0.action = "import_playbook"
    task1_0.args = {'_raw_params':"playbook", 'apply':{}}
    try:
        task_include_0.check_options(task1_0, "playbook")
        raise Exception("Failed to raise an exception when calling TaskInclude.check_options()")
    except AnsibleParserError:
        pass
    task2_0 = TaskInclude(list_0)
    task2_0.action = "include_role"

# Generated at 2022-06-25 06:24:46.070659
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    dict_0 = task_include_0.get_vars()
    dict_1 = dict_0.copy()


# Generated at 2022-06-25 06:24:55.111628
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # In this test, we have the following constants:
    ARGS_CONST = {'a': 1, 'b': 2}
    VARS_CONST = {'c': 3, 'd': 4}
    PARENT_VARS_CONST = {'e': 5, 'f': 6}

    # TODO: Manage inheritance and add more tests
    def _generate_task_included(action='include', args=Sentinel.missing, vars=Sentinel.missing, parent_vars=Sentinel.missing,
                                parent=Sentinel.missing):
        task = TaskInclude()
        task.action = action
        if args is not Sentinel.missing:
            task.args = args
        if vars is not Sentinel.missing:
            task.vars = vars

# Generated at 2022-06-25 06:24:58.406574
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    args = dict(apply=dict(block=[]))
    parent = Sentinel
    task_include_0 = TaskInclude(args, parent)
    p_block = task_include_0.build_parent_block()
    assert not p_block

# Generated at 2022-06-25 06:25:05.220473
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    list_0 = []
    task_include_0 = TaskInclude(list_0)

    task_include_0.args = dict()
    task_include_0.args['file'] = ''

    task_include_0.action = 'include'
    task_include_0.check_options(task_include_0, dict())



# Generated at 2022-06-25 06:25:15.700466
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    dict_0 = {}
    # The following line raises an error if if you are using Ansible 2.10 or older.
    dict_1 = dict(tags = None, run_once = None, when = None, register = None, ignore_errors = None, action = 'include', args = dict(_raw_params = 'raw_params_0'), file = 'file_0', apply = dict(ignore_errors = None, loop = None, run_once = None))

# Generated at 2022-06-25 06:25:22.302896
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    list_0 = []
    task_include_1 = TaskInclude(list_0)
    task_include_1.action = 'include'
    task_include_1.args = {'a':1}
    dict_2 = task_include_1.get_vars()
    assert dict_2 == {'a':1}
    task_include_1.action = 'import_playbook'
    task_include_1.args = {'a':1}
    dict_2 = task_include_1.get_vars()
    assert dict_2 == {}


# Generated at 2022-06-25 06:25:26.783241
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    list_0 = []
    task_include_0 = TaskInclude(list_0)
    task_include_0.args['apply'] = {}
    try:
        task_include_0.build_parent_block()
    except Exception as exception_0:
        assert False
