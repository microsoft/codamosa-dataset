

# Generated at 2022-06-25 06:16:06.292176
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    task_include_1.preprocess_data({
        'include': '{{ playbook_dir }}/tasks/main.yml',
        'action': 'include',
        'tags': 'include',
        'when': 'include'
    })


# Generated at 2022-06-25 06:16:08.203891
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}


# Generated at 2022-06-25 06:16:14.992945
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {'_raw_params': 'TestPlaybook.yml'}
    assert task_include_0.check_options(task_include_0, 'TestPlaybook.yml')


# Generated at 2022-06-25 06:16:23.713380
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()

    # not assigning file to task_include_1.args['_raw_params']
    # not assigning _raw_params to task_include_1.args['file']
    try:
        task_include_1.check_options(task_include_1, data = 1)
    except AnsibleParserError as e:
        print(e)
    else:
        print("Test case 1 passed. File/_raw_params not specified for action = include")

    task_include_1.args['_raw_params'] = 'test'
    task_include_1.action = 'include'
    task_include_2.action = 'import_tasks'

    # not assigning file to task_include_2.args['_raw_params']

# Generated at 2022-06-25 06:16:32.232096
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test case 1: Include with apply attrs
    task_include_1 = TaskInclude()
    task_include_1.args = {'apply': {'prefix': 'all'}}
    block_from_task_1 = task_include_1.build_parent_block()
    assert isinstance(block_from_task_1, Block)
    assert block_from_task_1.args['prefix'] == 'all'

    # Test case 2: Include without apply attrs
    task_include_2 = TaskInclude()
    task_include_2.args = {'task_name': 'some_task'}
    block_from_task_2 = task_include_2.build_parent_block()
    assert isinstance(block_from_task_2, TaskInclude)


# Generated at 2022-06-25 06:16:35.025058
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result_0 = task_include_0.get_vars()
    assert result_0 == [], \
        "expected {} but got '{}'".format([], result_0)


# Generated at 2022-06-25 06:16:46.024665
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    test_data = [
        # test: sentences different from both valid include tasks and valid import tasks
        ('include_data', False, True),
        ('import_data', False, True),

        # test: valid include tasks
        ('include', True, False),
        ('include_role', True, False),
        ('include_tasks', True, False),

        # test: valid import tasks
        ('import_playbook', True, False),
        ('import_tasks', True, False),

        # test: valid arguments
        ('file', True, False),
        ('apply', True, False),

        # test: invalid arguments
        ('test', False, False),
    ]

    task_include_0 = TaskInclude()

    for test in test_data:
        test_dict = { test[0]: '' }

        # test:

# Generated at 2022-06-25 06:16:49.307741
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {'action': 'include',
            'file': '/tmp/foo.yml'}
    plugin = TaskInclude()
    result = plugin.preprocess_data(data)
    assert result == data


# Generated at 2022-06-25 06:16:56.099472
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:16:59.412772
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:17:12.287773
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    invalid_opts = ['register', 'when', 'no_log']

    # Testing the TaskInclude.check_options method with a task that has
    # some invalid options (e.g. register, when, no_log). The method should
    # raise an error when it's called.
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        ti = TaskInclude()
        ti.args = {'file': 'foo.yaml', 'apply': {}}

        # Setting up the task used to call the check_options method
        class TaskToCheck(Task):
            def __init__(self):
                self.action = action
        t = TaskToCheck()
        for kw in invalid_opts:
            t.args[kw]

# Generated at 2022-06-25 06:17:22.323952
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    task_include.action = 'include'
    data = {'action': 'include', 'args': {'vars': {'a': 1}, 'debugger': {'enabled': False}}}
    processed_data = task_include.preprocess_data(data)
    assert processed_data == {'action': 'include', 'args': {'vars': {'a': 1}, 'debugger': {'enabled': False}}}
    data = {'action': 'import_role', 'args': {'tasks_from': 'foo'}, 'register': 'bar', 'something': 'else'}
    processed_data = task_include.preprocess_data(data)
    # Note that 'something' is not a valid keyword for 'import_role' and we should have removed
    # it from the processed data

# Generated at 2022-06-25 06:17:27.031572
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(
        action=None,
        file=None
    )
    block = None
    role=None
    task_include = None
    task_include_1 = TaskInclude(block=block, role=role, task_include=task_include)

    task_include_1.check_options(task_include_1, data)


# Generated at 2022-06-25 06:17:32.172762
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.check_options({'file': 'file_0'}, {'file': 'file_0'})
    task_include_1 = TaskInclude()
    task_include_1.check_options({'file': 'file_0', 'action': 'action_0', 'apply': 'apply_0'}, {'file': 'file_0', 'action': 'action_0', 'apply': 'apply_0'})
    task_include_2 = TaskInclude()
    task_include_2.check_options({'file': 'file_0', 'action': 'action_0', 'apply': {'key': 'value'}}, {'file': 'file_0', 'action': 'action_0', 'apply': {'key': 'value'}})


# Generated at 2022-06-25 06:17:37.963112
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    parent_block_0 = task_include_0.build_parent_block()
    assert isinstance(parent_block_0, TaskInclude), parent_block_0


# Generated at 2022-06-25 06:17:44.832120
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()

    #test_parent = Task()

    task_include_0.action = 'include'
    task_include_1.action = 'include_role'
    task_include_2.action = 'import_tasks'
    task_include_3.action = 'import_playbook'

    task_include_0.args = {
        'name': 'tests',
        '_raw_params': 'test.yml'
    }
    task_include_1.args = {
        'name': 'tests',
        '_raw_params': 'test.yml'
    }

# Generated at 2022-06-25 06:17:50.876531
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    yaml_data = """
- hosts: localhost
  tasks:
    - include_tasks: "{{ test_dir }}/static_include_arg.yml"
      vars:
        a: "{{ hostvars[inventory_hostname]['a'] }}"
""".strip()
    yaml_data2 = """
---
- include_tasks: "{{ test_dir }}/static_include_arg.yml"
  vars:
    a: "{{ hostvars[inventory_hostname]['a'] }}"
""".strip()
    yaml_data3 = """
---
- include_tasks: "{{ test_dir }}/static_include_arg.yml"
  vars:
    b: "{{ hostvars[inventory_hostname]['b'] }}"
""".strip()

# Generated at 2022-06-25 06:18:00.152839
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Reduce code duplication between tests by using a function
    def do_preprocessing(action_name):
        task_include_0 = TaskInclude()
        task_include_0.action = action_name
        task_include_0.preprocess_data(ds={'action': action_name,
                                           'name': 'test',
                                           'tags': ['A', 'B', 'C'],
                                           'when': 'not_this_and_that'})
        return task_include_0

    # preprocess data for action include_tasks
    task_include_0 = do_preprocessing('include_tasks')
    assert 'when' in task_include_0.args
    assert 'tags' in task_include_0.args

    # preprocess data for action import_tasks
    task_include_0

# Generated at 2022-06-25 06:18:10.587340
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # First we need to generate some valid data for TaskInclude
    file_data = "---\n- name: test\n"
    task_data = {
        'action': 'include',
        'file': file_data,
    }
    task_include = TaskInclude()
    task_include_data = task_include.load(data=task_data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task_include_data.args == task_data
    assert task_include_data.action == 'include'
    assert task_include_data.file == file_data


if __name__ == '__main__':

    # First we need to generate some valid data for TaskInclude
    file_data = "---\n- name: test\n"


# Generated at 2022-06-25 06:18:18.602094
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    test_play = dict(
        name = 'test_play',
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(
                action = 'include_vars',
                file = 'vars.yml'
            ),
            dict(
                action = 'set_fact',
                test = '{{ test_var }}'
            )
        ]
    )

    test_vars = dict(
        test_var = 'test_value'
    )

    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    display.verbosity = 3
    loader = DataLoader()
    play = Play.load(test_play, loader=loader)
    variable_manager

# Generated at 2022-06-25 06:18:25.458085
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_2 = TaskInclude()
    assert(isinstance(task_include_2.get_vars(), dict))



# Generated at 2022-06-25 06:18:34.612292
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0._parent is None
    assert task_include_0._action == 'noop'
    assert task_include_0.args == {}
    #assert task_include_0._role is None
    assert task_include_0.block is None
    assert task_include_0.statically_loaded is False
    assert task_include_0._task_include is None
    assert task_include_0._ds is None
    assert task_include_0._uuid == 'c4bb0eb4-7f35-4b49-8563-08f9f97d9b50'
    assert task_include_0._play is None
    assert task_include_0._dep_chain is None
    assert task_include_0._always_run is False
   

# Generated at 2022-06-25 06:18:42.527622
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create task
    task = TaskInclude()

    # Set attribute '_parent' to mock
    task._parent = Mock()

    # Create apply_attrs
    apply_attrs = {
        'some': 'value',
        'some_other': 'value'
    }

    # Set attribute 'args' to apply_attrs
    task.args = apply_attrs

    # Call test method
    task.build_parent_block()

    # Check that pop has been called with expected arguments
    task.args.pop.assert_called_with('apply', apply_attrs)

    # Check that attribute 'block' has been called with expected arguments
    task.args['block'].assert_called_with('apply', 'value', 'value')

# Mock class

# Generated at 2022-06-25 06:18:51.626541
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
	# Test with 'include' task
	TaskInclude.action = 'include'
	# Test with _parent block defined
	task_include_01 = TaskInclude()
	task_include_01._parent = Block()
	task_include_01._parent.get_vars = MagicMock()
	test_vars_01 = {'name': 'test', 'loop': 'test', 'register': 'test', 'debugger': 'test', 'run_once': 'test'}
	task_include_01.vars = test_vars_01
	task_include_01.get_vars()
	assert test_vars_01.pop('name') == 'test'
	assert test_vars_01.pop('loop') == 'test'
	assert test_vars_01.pop('register') == 'test'

# Generated at 2022-06-25 06:18:59.815051
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()
    task_include_4 = TaskInclude()
    task_include_5 = TaskInclude()
    task_include_6 = TaskInclude()
    task_include_7 = TaskInclude()

    apply_attrs_0 = {
        'a': 1,
        'b': 2,
        'c': 3
    }


# Generated at 2022-06-25 06:19:10.383196
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # create task_include object
    task_include_obj = TaskInclude()

    # create a dict of ActionInclude key/value pairs
    task_include_data = dict()
    task_include_data["apply"] = "test_apply"
    task_include_data["name"] = "test_name"
    task_include_data["tags"] = "test_tags"
    task_include_data["when"] = "test_when"

    # add invalid keys to the dict
    task_include_data["invalidKey1"] = "invalidKey1"
    task_include_data["invalidKey2"] = "invalidKey2"

    task_include_data["action"] = "include"
    # call preprocess_data method

# Generated at 2022-06-25 06:19:15.047422
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {'tasks': {'a':'b'}}
    
    res = task_include_0.get_vars()
    
    assert res['tasks'] == {'a': 'b'}
    assert res['action'] == 'include'

# Generated at 2022-06-25 06:19:26.016011
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    valid_actions = frozenset({'import_tasks', 'import_role', 'include_role', 'include_tasks'})

    for action in valid_actions.difference({'import_role'}):
        i_block = Block()
        valid_args = TaskInclude.VALID_ARGS.union(TaskInclude.VALID_INCLUDE_KEYWORDS)
        data = {'block': i_block, 'action': action, 'args': {'file': '/path/to/file', 'debug': '{{ debug }}', 'ignore_errors': True}}
        task = task_include_0.load(data)
        my_arg_names = frozenset(task.args.keys())

        # validate bad args, otherwise we silently ignore
        bad_op

# Generated at 2022-06-25 06:19:35.735923
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test without 'apply'
    t_args = {'_raw_params': 'test_file_1'}
    t_include_0 = TaskInclude(task_include=None, args=t_args)
    assert (t_include_0._parent is None)
    p_block_0 = t_include_0.build_parent_block()
    assert (p_block_0 == t_include_0)

    # test with 'apply'
    t_args = {'_raw_params': 'test_file_2',
              'apply': {'block': None, 'when': None}}
    t_include_0 = TaskInclude(task_include=None, args=t_args)
    assert (t_include_0._parent is None)
    p_block_0 = t_include_0.build

# Generated at 2022-06-25 06:19:40.430410
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude()
    try:
        task_include_1.load(None, None, None, None)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-25 06:19:52.719146
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    task_include_0 = TaskInclude()
    task_include_0.action = 'include_role'
    task_include_0.args = {'_raw_params': 'sysctl', 'not_valid': 'param'}
    task_include_0.check_options(task_include_0, None)
    assert task_include_0.args == {'_raw_params': 'sysctl'}


# Generated at 2022-06-25 06:20:04.232042
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'y': 'value-of-y', 'x': 'value-of-x'}

    assert ('y' in task_include.get_vars())
    assert ('x' in task_include.get_vars())
    assert ('tags' not in task_include.get_vars()) and ('when' not in task_include.get_vars())

    task_include.action = 'not an include action'

    assert ('y' not in task_include.get_vars()) and ('x' not in task_include.get_vars())
    assert ('tags' in task_include.get_vars()) and ('when' in task_include.get_vars())

# Generated at 2022-06-25 06:20:06.732535
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    block_0 = task_include_0.build_parent_block()



# Generated at 2022-06-25 06:20:11.442287
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    data = {
        'action': 'meta',
        'flush_cache': 'yes'
    }
    variable_manager = False
    loader = False
    returned = task_include_0.load(data,variable_manager,loader)
    assert returned


# Generated at 2022-06-25 06:20:17.171070
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    try:
        task_include_0.build_parent_block()
    except AttributeError as e:
        print(e)
        assert False



# Generated at 2022-06-25 06:20:29.029353
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    with pytest.raises(AnsibleParserError) as err:
        ti = TaskInclude()
        ti.args = {'_raw_params': 'file', 'apply': 'hello'}
        ti.check_options(ti, ti.args)
    assert 'apply is not a valid option for import_tasks' in str(err)

    with pytest.raises(AnsibleParserError) as err:
        ti = TaskInclude()
        ti.args = {'_raw_params': 'file', 'apply': 'hello'}
        ti.action = 'include_role'
        ti.check_options(ti, ti.args)
    assert 'apply is not a valid option for include_role' in str(err)


# Generated at 2022-06-25 06:20:34.989473
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test method TaskInclude.preprocess_data() of class TaskInclude.
    '''
    # Test for invalid keys for include option
    data = {"action": "include", "file": "./tasks/foo.yaml", "foo": "bar", "baz": "foo"}
    task_include = TaskInclude(block=Block())
    if C.INVALID_TASK_ATTRIBUTE_FAILED:
        assert_raises(AnsibleParserError, task_include.preprocess_data, data)
    else:
        output = task_include.preprocess_data(data)
        assert(output["foo"] == "bar")
        assert(output["baz"] == "foo")

    # Test for invalid keys for import_tasks option

# Generated at 2022-06-25 06:20:38.315532
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    # Here, we assume that the method returns a dict.
    result = task_include_1.get_vars()
    assert isinstance(result, dict)

# Generated at 2022-06-25 06:20:45.991619
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    By setting the task attribute value for action to 'include', we can test the
    get_vars method of class TaskInclude
    '''
    task_include_0 = TaskInclude()
    task_include_0._parent = None
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0.action = 'include'
    assert task_include_0.get_vars() == dict()

# Generated at 2022-06-25 06:20:56.997494
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args = {'apply': {'vars': None, 'block': [], 'block_vars': None, 'include_role': None, 'include_tasks': None, '_role': False, '_play': False}}
    task_include_0.args['apply']['block'] = []

    # Test if the include and include_role attributes are not populated
    p_block = task_include_0.build_parent_block()
    assert(p_block.include_role is None)
    assert(p_block.include_tasks is None)
    # Test if the role attribute is set to False
    assert(p_block._role is False)
    # Test if the play attribute is set to False

# Generated at 2022-06-25 06:21:04.616399
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    class MockLoader(object):
        def __init__(self):
            self.template = lambda x: x
            self.path_dwim = lambda x: x

    data = {
        'action': 'include_role',
        'when': 'foo',
        '_raw_params': 'bar',
        'apply': {
            'baz': 'bam'
        }
    }
    task_include = TaskInclude.load(data, loader=MockLoader())
    assert isinstance(task_include, TaskInclude)


# Generated at 2022-06-25 06:21:07.179238
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Test TaskInclude class method get_vars
    """
    task_include_0 = TaskInclude()
    task_include_0._play = Play()
    task_include_0.vars = dict()

    if task_include_0.get_vars() != dict():
        raise AssertionError('get_vars() does not return dict')

# Generated at 2022-06-25 06:21:17.941919
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.args = {'file' : 'test_file.yaml', 'debugger' : 'on'}
    task_include_1.preprocess_data(task_include_1.args)
    if task_include_1.args.get('debugger') != None:
        raise AssertionError("Could not preprocess data")
    task_include_1.action = 'include_role'
    task_include_1.args = {'file' : 'test_file.yaml', 'debugger' : 'on'}
    task_include_1.preprocess_data(task_include_1.args)

# Generated at 2022-06-25 06:21:18.699747
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    assert True

# Generated at 2022-06-25 06:21:26.409007
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    include_0 = TaskInclude()
    assert include_0.get_vars() == {}

    include_0 = TaskInclude(args={'action': 'include', 'file': 'foo'})
    assert 'file' in include_0.get_vars()

    include_0 = TaskInclude(args={'action': 'import_tasks', 'file': 'foo'})
    assert 'file' not in include_0.get_vars()

# Generated at 2022-06-25 06:21:28.616390
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.check_options(
        AnsibleParserError(
            'Invalid options',
            obj=data
        ),
        data
    )


# Generated at 2022-06-25 06:21:30.930078
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_include_data = dict(action="include", file="file")

    task_include_1 = TaskInclude()
    task_include_1.preprocess_data(test_include_data)



# Generated at 2022-06-25 06:21:40.104938
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    data = {
        'apply': {
            'some_action': {}
        },
        'block': [
            {
                'some_task': {}
            }
        ]
    }

    task_include_0 = TaskInclude.load(data, task_include=TaskInclude())
    block = task_include_0.build_parent_block()

    assert type(task_include_0._parent) is Block
    block_2 = block.block[0]
    assert type(block_2) is Task
    assert block_2._parent is block


# Generated at 2022-06-25 06:21:45.319035
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    data = {
        'action': 'include_tasks',
        'apply':
        {
            'block': []
        }
    }

    task = TaskInclude.load(data)

    assert task._get_parent_attribute('action') == 'include_tasks'
    assert isinstance(task._get_parent_attribute('block'), list) == True


# Generated at 2022-06-25 06:21:51.797118
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    block_0 = Block()
    task_include_0._parent = block_0
    block_0.apply = {}
    assert task_include_0 is task_include_0.build_parent_block()
    assert block_0._parent is block_0
    assert block_0.vars == {'tags': [], 'when': [], 'apply': {}, 'ignore_errors': False, 'register': 'my_result', 'name': None, 'block': [], 'match': 'all', 'loop': None}
    assert block_0.args == {'apply': {}, 'block': [], 'ignore_errors': False, 'loop': None, 'match': 'all', 'name': None, 'register': 'my_result'}

# Generated at 2022-06-25 06:22:00.474350
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    test_block = {
        'block': [
            {
                'block': [
                    {'task': {'debug': {'msg': 'Testtask'}}},
                    {'task': {'debug': {'msg': 'Testtask2'}}}
                ],
                'any_errors_fatal': 'yes',
                'ignore_errors': 'yes'
            }
        ],
        'connection': 'network_cli',
        'remote_user': 'einstein',
        'forks': '100',
        'serial': '1',
        'delay': '3'
    }

    test_block_parent = Block(play=None)

    # Setup test_TaskInclude_build_parent_block
    test_TaskInclude_0 = TaskInclude(task_include=test_block_parent)
    test_

# Generated at 2022-06-25 06:22:07.880035
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Initializing a task include
    task_include_0 = TaskInclude()
    # Checking action attribute is present in _base_keywords
    base_keywords = task_include_0.BASE.union(task_include_0.OTHER_ARGS)
    assert 'action' in base_keywords
    # Checking _base_keywords is not changed
    base_keywords_old = task_include_0.BASE.union(task_include_0.OTHER_ARGS)
    assert base_keywords == base_keywords_old
    # Preprocessing data
    data = {'action': 'include', 'file': 'test', 'a': 1}
    result = task_include_0.preprocess_data(data)
    # Checking result has 'a' attribute deleted
    assert 'a' not in result
    # Checking

# Generated at 2022-06-25 06:22:15.800247
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.vars = {'a':'yes', 'b':'no'}
    ti.action = 'include_tasks'
    ti.args = {'_raw_params': 'a.yml', 'c':'maybe', 'd':'no'}
    assert ti.get_vars() == {'a':'yes', 'b':'no', '_raw_params': 'a.yml', 'c':'maybe', 'd':'no'}


# Generated at 2022-06-25 06:22:21.879401
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    options = {'apply': {'a': 1}}

    task_include = TaskInclude(block=None, role=None, task_include=None)
    task_include.args = options
    task_include.action = "include_role"

    # Test if the returned task is the same as the original task
    assert TaskInclude.check_options(task_include, options).args == options

# Test the method check_options to ensure it raises an error when
# an invalid option is passed

# Generated at 2022-06-25 06:22:33.377005
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Set hostvars
    hostvars = {}
    hostvars['foo'] = {'myvar': 'myval'}

    # Set facts
    facts = {}
    facts['foo'] = {}

    # Set include in task
    include = {}
    include['action'] = 'inc'
    include['args'] = {}
    include_args = include['args']
    include_args['foo'] = 'bar'

    # this is how the task is created in action_loader.py
    task_apply = TaskInclude()
    task_apply.vars = {}
    task_apply.action = 'include'
    task_apply.args = include['args']
    task_apply.args['apply'] = include
    task_apply._parent = {}
    task_apply._parent.get_vars = Task.get_

# Generated at 2022-06-25 06:22:40.810307
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    loader = DictDataLoader({
        "test_task.yml": """
- hosts: all
  tasks:
   - include_tasks: test_task_1.yml
  apply:
    block:
      - apply_all:
          x: 1
      - apply_all:
          x: 2
"""
    })
    ti = TaskInclude()
    ti.args = {'file': 'test_task.yml',
               'apply': {'block': [{'apply_all': {'x': 1}}, {'apply_all': {'x': 2}}],
                         'apply_all': {'x': 1}}}

# Generated at 2022-06-25 06:22:50.071327
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test_case_0: when action not in C._ACTION_INCLUDE
    task_include_0 = TaskInclude()
    task_include_0.action = 'no_include'

    expected_0 = {}
    assert task_include_0.get_vars() == expected_0
    # test_case_1: when action in C._ACTION_INCLUDE
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.vars = {}
    task_include_1.args = {'file': 'file_path'}

    expected_1 = {'file': 'file_path'}
    assert task_include_1.get_vars() == expected_1

# Generated at 2022-06-25 06:22:56.158027
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockClass:
        def __init__(self, name):
            self.name = name
            self.args = dict()
            self.action = Sentinel()

    task_include = TaskInclude()
    example_dict = dict(file = 'file_name')
    # The test:
    task_include.check_options(MockClass('MockClass'), example_dict)
    # This should not raise any exception, because the dict has only
    # valid arguments and the Sentinel action is in the constant

    task_include.check_options(MockClass('MockClass'), dict(file = 'file_name', apply='content'))
    # This also should not raise any exception, because the dict has
    # one valid argument and the Sentinel action is in the constant


# Generated at 2022-06-25 06:22:59.917585
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Initialize class object and create instances of input data
    task_include_0 = TaskInclude()
    data = {'block': [], 'play': '_play', 'task_include': 'task_include', 'role': '_role', 'variable_manager': '_variable_manager', 'loader': '_loader'}
    # Check for expected results
    assert task_include_0.build_parent_block(data) == data


# Generated at 2022-06-25 06:23:08.431366
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(action='include', file='/some_file')
    task_include = TaskInclude(block=None, role=None, task_include=None)
    assert task_include.preprocess_data(data) == data

    data = dict(action='include', file='/some_file', foo='bar')
    assert task_include.preprocess_data(data) == dict(action='include', file='/some_file')

    data = dict(action='include_role', file='/some_file', foo='bar')
    assert task_include.preprocess_data(data) == dict(action='include_role', file='/some_file')


# Generated at 2022-06-25 06:23:19.367224
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_attrs = {'a': 'b'}
    task_include = TaskInclude()
    with pytest.raises(Exception) as exception_info:
        task_include.build_parent_block()
    assert exception_info.value.args[0] == 'TaskInclude requires a parent block'


# Generated at 2022-06-25 06:23:29.170964
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    assert TaskInclude.load({'action': 'include', 'file': 'a.yml'})
    assert not TaskInclude.load({'action': 'include', 'file': 'a.yml', 'ignore_errors': 'x'})
    assert not TaskInclude.load({'action': 'include_tasks', 'file': 'a.yml', 'ignore_errors': 'x'})
    assert TaskInclude.load({'action': 'include_tasks', 'file': 'a.yml'})
    assert TaskInclude.load({'action': 'include_role', 'file': 'a.yml'})
    assert not TaskInclude.load({'action': 'include_tasks', 'file': 'a.yml', 'x': 'y'})

# Generated at 2022-06-25 06:23:33.470152
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'foo': 'bar'}
    data = {'action': 'include', 'foo': 'bar'}
    result = task_include.preprocess_data(data)
    expected = {'action': 'include', 'args': data}
    assert result == expected

task = TaskInclude()
task.register_updater('vars', lambda data: 'replacement')
data = {'vars': Sentinel}
result = task.load_data(data)
assert result.vars == 'replacement'
assert result.args['vars'] is Sentinel

task = TaskInclude()
task.register_updater('args', lambda data: 'replacement')
data = {'vars': Sentinel}
result

# Generated at 2022-06-25 06:23:39.414323
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.plugins.action.include import ActionModuleInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    host = Host(name='localhost', port=22)


# Generated at 2022-06-25 06:23:49.925183
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include = TaskInclude()
    task_include._parent = TaskInclude()
    task_include._parent.vars = {'a': 1}
    task_include.vars = {'b': 2}
    task_include.args = {'c': 3}
    task_include.action = 'include'
    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': 3}
    assert task_include.get_vars() != {'a': 1, 'b': 2, 'c': 3, 'tags': []}

    task_include.action = 'import_tasks'
    assert task_include.get_vars() == {'a': 1, 'b': 2}

# Generated at 2022-06-25 06:23:58.421222
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    var_manager = None
    loader = None
    task_ds = {'action': 'include_tasks', 'tasks': [{'include': 'common.yml'}]}
    ti = TaskInclude()
    task = ti.load(data=task_ds, block=None, role=None, task_include=None, variable_manager=var_manager, loader=loader)
    # assert task[0].action == 'include_tasks'
    # assert task[0].args['_raw_params'] == 'common.yml'


# Generated at 2022-06-25 06:24:04.726599
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude.load(
        dict(
            action='include_tasks',
            file='./test/resources/test_include_apply.yml',
            apply=dict(
                block=dict(
                    ignore_errors=False,
                    rescue=None,
                    always=None,
                ),
            ),
        )
    )
    task_include_2 = TaskInclude.load(
        dict(
            action='include_role',
            file='./test/resources/test_include_apply.yml',
            apply=dict(
                block=dict(
                    ignore_errors=False,
                    rescue=None,
                    always=None,
                ),
            ),
        )
    )
    task_include_3 = Task

# Generated at 2022-06-25 06:24:14.421715
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_include_1.action = "include"
    task_include_1.args = {"file":"test_include.yml"}
    assert(task_include_1.check_options(task_include_1, "test") == task_include_1)
    task_include_1.action = "include_role"
    assert(task_include_1.check_options(task_include_1, "test") == task_include_1)
    task_include_1.action = "include"
    task_include_1.args = {"file":"test_include.yml", "apply": ""}
    assert(task_include_1.check_options(task_include_1, "test") == task_include_1)

# Generated at 2022-06-25 06:24:26.263168
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    global display
    display = Display()
    task_include = TaskInclude()
    task_include.vars = dict(one='1', two='2', three='3')
    task_include.action = 'include'

    # test all task include methods
    for action in C._ACTION_INCLUDE:
        task_include.action = action
        task_include.args = task_include.vars
        all_vars = task_include.get_vars()
        assert all_vars == dict(one='1', two='2', three='3')

    # test all other task include methods
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        if action not in C._ACTION_INCLUDE:
            task_include.action = action
            task_include.args

# Generated at 2022-06-25 06:24:32.203722
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    value = dict(
        __ansible_module__='include',
        _raw_params='test.yaml',
        action='include',
        file='test.yaml',
        name='test.yaml'
    )
    task_include_0 = TaskInclude()
    assert task_include_0.check_options(task_include_0, value) != None


# Generated at 2022-06-25 06:24:47.879142
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args['apply'] = {}
    task_include._parent = type('Play', (object,), {'_play': 'some_play', 'get_vars': lambda self: {'foo': 'bar', 'baz': 'buzz'}})()
    task_include._play = task_include._parent._play
    task_include._role = type('Role', (object,), {'get_vars': lambda self: {'baz': 'bizz', 'ping': 'pong'}})
    task_include._variable_manager = None
    task_include._loader = None

    parent_block = task_include.build_parent_block()
    assert isinstance(parent_block, Block)

# Generated at 2022-06-25 06:24:55.705255
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import json
    data = json.load(open('/home/derrick/Downloads/ansible_source/lib/ansible/playbook/task_include.json', 'r'))
    task_include_0 = TaskInclude.load(data, block=Block(), task_include=TaskInclude(), role=Role(),
                                      variable_manager=VariableManager())
    assert task_include_0.action == 'include'
    assert task_include_0.loop is None
    assert task_include_0.loop_control is None
    assert task_include_0.loop_with is None
    assert task_include_0.name == 'include'
    assert task_include_0.tags == []
    assert task_include_0.when == {}
    assert task_include_0.register == 'R0'
    assert task_

# Generated at 2022-06-25 06:25:04.110924
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ds0 = dict({'apply': {'name': 'myblock0', 'block': [], 'vars': {}}})
    block0 = Block.load(ds0, play=None, task_include=None, role=None, variable_manager=None, loader=None)
    task_include0 = TaskInclude()
    task_include0._parent = None
    task_include0._role = None
    task_include0.args = {'apply': {'name': 'myblock0', 'block': [], 'vars': {}}}
    task_include0.vars = {}
    p_block0 = task_include0.build_parent_block()
    if isinstance(p_block0, Block):
        print("pass")
    else:
        print("fail")



# Generated at 2022-06-25 06:25:14.493739
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with invalid args
    task_include_1 = TaskInclude()
    task_include_1.args = {'file': 'test.yml', 'bad_opt': 'wrong_value'}

# Generated at 2022-06-25 06:25:20.492086
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # create task_include 
    task_include = TaskInclude()
    task_include.args = {'apply': {}}
    assert task_include._parent is None
    p_block = task_include.build_parent_block()
    # Is task_include._parent still None?
    assert task_include._parent is None
    assert p_block is task_include
    # Is task_include._parent still None?
    assert task_include._parent is None

# Generated at 2022-06-25 06:25:30.669042
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # tests for scenarios when apply keyword is present
    # scenario 2: apply present and apply is dictionary
    task_include_1 = TaskInclude()
    task_include_1.args = {}
    task_include_1.args['apply'] = {}
    assert task_include_1.build_parent_block()

    # tests for scenarios when apply keyword is absent
    # scenario 1: apply absent
    task_include_2 = TaskInclude()
    assert task_include_2.build_parent_block() == task_include_2

    # scenario 2: apply present and apply is not dictionary
    task_include_3 = TaskInclude()
    task_include_3.args = {}
    task_include_3.args['apply'] = ""
    assert task_include_3.build_parent_block() == task_include_3

# Generated at 2022-06-25 06:25:40.211177
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # fixture for the test
    # create a dummy task
    dummy_task = TaskInclude()
    dummy_task.action = 'include'

    # create a dummy play
    dummy_play = {}
    dummy_play['name'] = 'test play'

    # create a dummy block
    dummy_block = Block()
    dummy_block.block = []

    # create a dummy role
    dummy_role = {}
    dummy_role['name'] = 'test role'
    dummy_role['vars'] = {}
    dummy_role['vars']['a'] = '1'
    dummy_role['vars']['b'] = '2'
    dummy_role['default_vars'] = {}
    dummy_role['default_vars']['c'] = '3'

# Generated at 2022-06-25 06:25:46.470496
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    # Set up playbook to test against

# Generated at 2022-06-25 06:25:52.586950
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    # self.MAX_DEPTH = 5

    # data = []
    # my_arg_names = None
    # bad_opts = ''
    # try:
    #     task_include_0.check_options(task=None, data=data)
    # except AnsibleParserError as e:
    #     print("ERROR: " + str(e))
    #     pass
    #
    # data = {}
    # try:
    #     task_include_0.check_options(task=None, data=data)
    # except AnsibleParserError as e:
    #     print("ERROR: " + str(e))
    #     pass
    #
    # data = {'action': 'include',
    #         'threshold': '40%',
   

# Generated at 2022-06-25 06:26:03.342300
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    # check empty dictionary is returned when self.action not in ['include', 'include_role']
    assert task_include_1.get_vars() == {}, "test_TaskInclude_get_vars failed"
    
    # set action to 'include'
    task_include_1.action = 'include'
    # check empty dictionary is returned for self.action == 'include' and self._parent is None
    assert task_include_1.get_vars() == {}, "test_TaskInclude_get_vars failed"

    parent_1 = Block()
    task_include_1._parent = parent_1
    # check empty dictionary is returned for self.action == 'include' and self._parent != None