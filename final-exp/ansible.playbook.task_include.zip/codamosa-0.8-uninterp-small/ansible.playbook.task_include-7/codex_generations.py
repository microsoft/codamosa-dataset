

# Generated at 2022-06-25 06:16:11.896462
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'

    data_0 = {}
    data_1 = {'action': 'include'}

    try:
        task_include_0.preprocess_data(data_0)
        task_include_0.preprocess_data(data_1)
    except AnsibleParserError:
        assert True
    else:
        assert False, 'AnsibleParserError not raised'

    data_2 = {'action': 'include', 'foo': 'bar'}
    data_3 = {'action': 'include', 'bar': 'baz'}
    data_4 = {'action': 'include', 'include': 'something'}


# Generated at 2022-06-25 06:16:21.744760
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.statically_loaded = False
    task_include_0.action = 'include'
    task_include_0.args = dict({'_raw_params': 'test_include_0', 'tags': ['test_tag_0'], 'when': ['test_when_0']})
    task_include_0.vars = {'test_vars_0': 'test_vars_1', 'test_vars_2': 'test_vars_3'}
    task_include_0.name = 'test_task_include_0'
    # try to access protected attribute _parent of class TaskInclude. This will raise an exception

# Generated at 2022-06-25 06:16:31.027137
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()

    # Test a TaskInclude action=include and no include_role
    ds_0 = {u'debug': Sentinel, 'tags': [u'tag1', u'tag2'], 'apply': {'block': []}, 'when': Sentinel, u'name': Sentinel, u'static': u'all', u'files': [u'file1', u'file2']}
    ds_1 = task_include_0.preprocess_data(ds_0)
    assert ds_1['action'] == 'include'
    assert 'include_role' not in ds_1

    # Test a TaskInclude action=include_role and no include_tasks

# Generated at 2022-06-25 06:16:32.978524
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    task_include_0.load("test",block="test",role="test",task_include="test",variable_manager="test",loader="test")


# Generated at 2022-06-25 06:16:40.113985
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()

    # Test empty arguments
    vars_0 = {}
    task_include_0.vars = vars_0
    args_0 = {}
    task_include_0.args = args_0
    assert task_include_0.build_parent_block() == task_include_0

    # Test only apply
    vars_1 = {}
    task_include_0.vars = vars_1
    args_1 = {
        'apply': {},
    }
    task_include_0.args = args_1
    assert hasattr(task_include_0.build_parent_block(), "block")

    # Test only file
    vars_2 = {}
    task_include_0.vars = vars_2

# Generated at 2022-06-25 06:16:44.089977
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude()
    task_include_1_result = task_include_1.load(dict(action='include', file='/path/to/include'))
    assert task_include_1_result.__class__.__name__ == 'TaskInclude'
    assert task_include_1 == task_include_1_result
    assert task_include_1_result.action == 'include'
    assert task_include_1_result.args['file'].path == '/path/to/include'


# Generated at 2022-06-25 06:16:54.628513
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Init a new task include to test method check_options
    task_include = TaskInclude()

    # Validating with include action
    data = {
        "name": "test_task_include",
        "action": "include",
        "_raw_params": "test",
    }
    task = task_include.load_data(data, variable_manager=None, loader=None)
    assert task.args == {'_raw_params': 'test'}

    # Validating with include_role action
    data = {
        "name": "test_task_include",
        "action": "include_role",
        "_raw_params": "test",
    }
    task = task_include.load_data(data, variable_manager=None, loader=None)

# Generated at 2022-06-25 06:17:00.299039
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:17:06.223105
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = task_include_0.check_options(task_include_0, {})
    assert isinstance(task_0, TaskInclude)


# Generated at 2022-06-25 06:17:12.017976
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args = {'include': 'test'}
    task_include.action = 'include'
    task_include.vars = {'key1': 'value1'}
    task_include._parent = {}
    task_include._parent.get_vars = lambda : {'foo': 'bar'}
    expected_result = {'key1': 'value1', 'include': 'test', 'foo': 'bar'}
    result = task_include.get_vars()
    assert result == expected_result


# Generated at 2022-06-25 06:17:21.553097
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_1_args = dict()
    assert task_include_1.VALID_ARGS == task_include_1.check_options(task_include_1, task_1_args).args
    task_include_2 = TaskInclude()
    task_2_args = dict(file="file_path")
    assert task_include_2.VALID_ARGS == task_include_2.check_options(task_include_2, task_2_args).args
    task_include_3 = TaskInclude()
    task_3_args = dict(apply=dict(a="a_value"))
    assert task_include_3.VALID_ARGS == task_include_3.check_options(task_include_3, task_3_args).args
    task_

# Generated at 2022-06-25 06:17:22.685127
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    pass


# Generated at 2022-06-25 06:17:28.152679
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.action = "include"
    task_include_1.args = {'_raw_params': 'foo.yml'}
    # Expected vars
    expected_all_vars = {'_raw_params': 'foo.yml'}
    actual_all_vars = task_include_1.get_vars()
    assert actual_all_vars == expected_all_vars


# Generated at 2022-06-25 06:17:30.678096
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    data_var_0 = dict()
    task_include_1 = TaskInclude.check_options(task_include_0, task_0, data_var_0)

# Generated at 2022-06-25 06:17:37.083239
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = {}
    ds['action'] = 'include'
    ds['some_invalid_keyword'] = ''
    ds = task_include_0.preprocess_data(ds)
    assert ds['action'] == 'include'
    assert ds['some_invalid_keyword'] == Sentinel
    if not C.INVALID_TASK_ATTRIBUTE_FAILED:
        assert 'some_invalid_keyword' not in ds

# Generated at 2022-06-25 06:17:44.150772
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude.load(
        {
            "when": "{{ansible_os_family}} == 'RedHat'",
            "notify": [
                "Restart tomcat"
            ],
            "include": "../tasks/tomcat.yml"
        },
        role=None,
    )

    assert hasattr(task_include_0, 'vars')
    assert hasattr(task_include_0, 'block')
    assert hasattr(task_include_0, 'free_form')
    assert hasattr(task_include_0, 'static_task')
    assert hasattr(task_include_0, 'tags')
    assert hasattr(task_include_0, 'when')
    assert hasattr(task_include_0, 'always_run')
    assert hasattr

# Generated at 2022-06-25 06:17:51.819711
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    print ('########## ########## ########## ##########')
    print ('########## Testing TaskInclude.check_options()')
    print ('########## ########## ########## ##########')
    task_include_1 = TaskInclude()
    ds = {'action': 'include', '_raw_params': 'test_file.yml'}
    data = {'action': 'include', '_raw_params': 'test_file.yml', 'apply': {'test_apply': 'test_value'}}
    task_include_1.check_options(ds, data)

if __name__ == '__main__':
    sys.exit(test_TaskInclude_check_options())

# Generated at 2022-06-25 06:18:01.104926
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Valid parameters for 'include'
    task = dict(
        action = 'include',
        file = '/path/to/somewhere',
        name = 'Value for my name',
        register = 'some_value',
        apply = dict(
            # must be a dict
        )
    )
    task = TaskInclude.check_options(TaskInclude(), task, task)
    assert task.file == '/path/to/somewhere'
    assert task.action == 'include'
    assert task.name == 'Value for my name'
    assert task.register == 'some_value'

    # Invalid parameter for 'include'
    task = dict(
        action = 'include',
        invalid_param = 'some_value',
        file = '/path/to/somewhere',
    )

# Generated at 2022-06-25 06:18:04.752422
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test 1 - Test for base/default case without params
    test_case_0 = TaskInclude()

    # Test 2 - Test for include case
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'

# Generated at 2022-06-25 06:18:13.237664
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Instanciate test class
    task_include_0 = TaskInclude()
    # Initialize test variable
    task_0 = Task(block=None, role=None, task_include=None)
    task_0.action = 'include'
    task_0.args = {'_raw_params': 'test_value_2'}
    # Call method
    task_include_0.check_options(task=task_0, data='test_value_3')
    # Verify results
    assert task_0.action == 'include'
    assert task_0.args == {'_raw_params': 'test_value_2'}


# Generated at 2022-06-25 06:18:20.234326
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Setup test
    task_include_2 = TaskInclude()
    task_include_2.args = {'apply': {}}

    # Execute code under test
    p_block = task_include_2.build_parent_block()

    # Verify assertions
    assert isinstance(p_block, Block)
    assert p_block == task_include_2

# Generated at 2022-06-25 06:18:28.440916
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.block
    # Establish that method 'build_parent_block' of class TaskInclude exists
    assert hasattr(TaskInclude, "build_parent_block")
    # Establish that var 'block' of ansible.playbook.block.Block class is type list
    assert isinstance(ansible.playbook.block.Block.block, list)
    # Establish that var 'block' of ansible.playbook.block.Block class is writable
    assert ansible.playbook.block.Block.block.__class__.__name__ == 'list'


# Generated at 2022-06-25 06:18:30.656119
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    p_block = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:18:32.303278
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()

if __name__ == "__main__":
    test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:18:40.457769
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Test case for method get_vars of class TaskInclude
    """
    test_vars = {"var_1": "val_1", "var_2": 2, "var_3": True}
    test_args = {"args_1": "arg_1", "args_2": "arg_2"}
    
    ti_obj = TaskInclude()
    ti_obj.vars = test_vars
    ti_obj.args = test_args
    ti_obj.action = "include"

    assert test_vars.keys() == ti_obj.get_vars().keys()

# Generated at 2022-06-25 06:18:45.788255
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    host_obj = TaskInclude(block=None, role=None, task_include=None)
    host_obj.args = dict()
    host_obj.args['apply']= {}
    assert host_obj.build_parent_block() is host_obj

    host_obj.args = dict()
    assert host_obj.build_parent_block() is host_obj


# Generated at 2022-06-25 06:18:47.182824
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    display.display('Getting vars from empty TaskInclude')
    assert TaskInclude().get_vars() == dict()

# Generated at 2022-06-25 06:18:50.730576
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_5 = TaskInclude()
    data = {'tags': 'tag'} # inputs
    expected_9 = data # expected output
    real_9 = task_include_5.preprocess_data(data)
    assert expected_9 == real_9


# Generated at 2022-06-25 06:18:59.304498
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    data = {"action": "include"}
    new_ds = task_include_1.preprocess_data(data)
    assert new_ds == data
    data = {"action": "include", "tags": Sentinel}
    new_ds = task_include_1.preprocess_data(data)
    assert new_ds == data
    data = {"action": "include", "myparam": "myvalue"}
    new_ds = task_include_1.preprocess_data(data)
    assert new_ds == {"action": "include"}
    data = {"action": "import_tasks", "tags": Sentinel, "myparam": "myvalue"}
    new_ds = task_include_1.preprocess_data(data)

# Generated at 2022-06-25 06:19:04.281537
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude.load(data={'action': 'include', 'file': 'file'})
    assert task_include is not None, 'Expected task_include to be not None but is instead %s' % task_include

# Generated at 2022-06-25 06:19:10.973221
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    my_data = dict(name='test_include')
    task_include_0 = TaskInclude()
    task_include_0.check_options(task_include_0, my_data)
    return True


# Generated at 2022-06-25 06:19:16.578867
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    result = task_include_1.build_parent_block()
    assert isinstance(result, Block)
    assert result is task_include_1

    task_include_2 = TaskInclude()
    task_include_2.args = {'apply': {}}
    result = task_include_2.build_parent_block()
    assert isinstance(result, Block)
    assert task_include_2._parent_block is result

# Generated at 2022-06-25 06:19:25.307717
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # generate a TaskInclude object
    p_block = Block.load(dict(name='asd'), play=None, task_include=None, role=None, variable_manager=None, loader=None)
    ti = TaskInclude(block=p_block, role=None, task_include=None)

    apply_attrs = dict(fallback='yes')
    apply_attrs['block'] = []
    ti._parent = ti.build_parent_block()
    assert 'block' in ti._parent.args and ti._parent.args['block'] == [] and isinstance(ti._parent, Block)


# Generated at 2022-06-25 06:19:35.144495
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import find_plugin_files
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.action.include_role import ActionModule
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_native
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-25 06:19:36.252993
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # TaskInclude._instance_count = 0
    task_include_0 = TaskInclude()
    assert task_include_0.build_parent_block() == task_include_0

# Generated at 2022-06-25 06:19:37.174559
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    assert TaskInclude.load()

# Generated at 2022-06-25 06:19:47.483151
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude({'block': []})
    task_include_3 = TaskInclude(role={'loop': '{{ role_loop | default() }}'})
    task_include_4 = TaskInclude({'block': []}, role={'loop': '{{ role_loop | default() }}'})
    task_include_5 = TaskInclude({'block': []}, role={'main': {'block': {'block': 'main.block.block'}}})
    task_include_6 = TaskInclude({'block': {'block': {'block': 'block.block.block'}}}, role={'main': {'block': {'block': 'main.block.block'}}})
    task_include

# Generated at 2022-06-25 06:19:49.555851
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0.build_parent_block() == task_include_0

# Generated at 2022-06-25 06:19:58.487165
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Testing with defaults
    task_include_1 = TaskInclude()
    task_include_1.vars = {'key1': 'value1'}
    task_include_1.args = {}
    task_include_1.action = 'include_role'
    task_include_1.parent = None

    all_vars = task_include_1.get_vars()
    assert 'key1' in all_vars
    assert 'value1' == all_vars['key1']
    assert 'tags' not in all_vars
    assert 'when' not in all_vars

    # Testing with include
    task_include_2 = TaskInclude()
    task_include_2.vars = {'key2': 'value2'}

# Generated at 2022-06-25 06:20:05.915477
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include_0 = TaskInclude()
    task_include_0.action="include"
    task_include_0.vars = {'first' : 'one', 'second' : 'two'}
    task_include_0.args = {'file' : 'test.yml', 'debugger' : 'pdb'}

    task_include_1 = TaskInclude()
    task_include_1.action="include_role"
    task_include_1.vars = {'first' : 'one', 'second' : 'two'}
    task_include_1.args = {'file' : 'test.yml', 'debugger' : 'pdb'}

    # Add vars to parent block
    block_0 = Block(task_include_0)

# Generated at 2022-06-25 06:20:25.738963
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    check_options_0 = TaskInclude()
    data_0 = {'args': {'_raw_params': 'include.yml', 'tags': ['handlers']}, 'action': 'include_role', 'block': [{'block': [{'tags': ['handlers'], 'action': 'debug', 'args': {}, 'ignore_errors': False, 'when': 'is_redhat'}], 'when': 'is_redhat'}], 'name': 'test', 'register': 'test', 'ignore_errors': False, 'when': False, 'tags': ['handlers']}

# Generated at 2022-06-25 06:20:37.171864
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_data = {}
    test_data['block'] = [{'task': {'name': 'Ansible hello world', 'action': {'module': 'shell', 'args': 'echo "hello world"'}}}]
    test_data['ignore_errors'] = True
    test_data['delegate_to'] = '127.0.0.1'
    test_data['register'] = 'shell_out'
    test_data['_ansible_verbose_always'] = True
    test_data['_ansible_no_log'] = False
    test_data['_ansible_debug'] = True

    # test_data['ignore_errors'] = True
    # test_data['delegate_to'] = '127.0.0.1'
    # test_data['register'] = 'shell_out'
    #

# Generated at 2022-06-25 06:20:46.455121
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args = {
        'file': 'file_val',
        'apply': 'apply_val',
    }
    task_include_0.action = 'include'
    result = task_include_0.get_vars()
    assert result['file'] == 'file_val'
    assert result['apply'] == 'apply_val'
    task_include_0.action = 'import_tasks'
    result = task_include_0.get_vars()
    assert 'file' not in result
    assert 'apply' not in result

# Generated at 2022-06-25 06:20:53.453360
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    block = Block()
    task_include.args['apply'] = {}
    task_include._parent = block
    task_include._role = None
    task_include._loader = None
    task_include._variable_manager = None
    assert isinstance(task_include.build_parent_block(), TaskInclude)

# Generated at 2022-06-25 06:20:55.554420
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    taskinclude_obj_1=TaskInclude()
    task_obj_1=Task()
    taskinclude_obj_1.check_options(task_obj_1)

# Generated at 2022-06-25 06:21:04.476034
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_0 = task_include_0.load(
        dict(file='test_file_0')
    )
    task_1 = task_include_1.load(
        dict(file='test_file_1', invalid_option='invalid_option_1')
    )
    task_2 = task_include_2.load(
        dict(file='test_file_2', action='include', apply='apply_2')
    )

# Generated at 2022-06-25 06:21:09.594266
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()
    # verify if result is not None
    assert result is not None


if __name__ == '__main__':

    test_case_0()
    test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:21:12.399526
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert isinstance(task_include_0.get_vars(), dict)


# Generated at 2022-06-25 06:21:21.659386
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    t = TaskInclude()
    d = {'action': 'include_tasks', '_raw_params': '/home/user/tasks/main.yml', 'apply': {'discount': {'type': 'percent', 'amount': '10'}}}
    task_include_instance = t.check_options(t.load_data(d), d)
    assert task_include_instance.action == 'include_tasks'
    assert task_include_instance.args['_raw_params'] == '/home/user/tasks/main.yml'
    assert task_include_instance.args['apply'] == {'discount': {'type': 'percent', 'amount': '10'}}


# Generated at 2022-06-25 06:21:29.877848
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_2 = TaskInclude()
    with pytest.raises(AnsibleParserError) as excinfo:
        task_include_2.build_parent_block()

    assert 'No parent to build a parent block for' in str(excinfo)
    task_include_3 = TaskInclude()
    task_include_3._parent = True
    task_include_4 = TaskInclude()
    task_include_4._play = True
    task_include_5 = TaskInclude()
    task_include_5.build_parent_block()
    task_include_0 = TaskInclude()
    task_include_0.build_parent_block()
    task_include_1 = TaskInclude()
    task_include_1.build_parent_block()
    task_include_6 = TaskInclude()

# Generated at 2022-06-25 06:21:39.540905
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()



# Generated at 2022-06-25 06:21:42.782178
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    block_0 = Block()
    block_0.vars = dict(test=1)
    block_0.block = []
    task_include_0 = TaskInclude(block=block_0)
    task_include_0.args = dict(apply=dict())
    block_1 = task_include_0.build_parent_block()
    assert block_1.vars == {'test': 1}
    assert block_1.block == []

# Generated at 2022-06-25 06:21:47.767411
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test_case_0: No apply_attrs is specified
    task_include_0 = TaskInclude()
    task_include_0._role = Sentinel
    task_include_0._variable_manager = Sentinel
    task_include_0._loader = Sentinel
    task_include_0._parent = Sentinel
    parent_block_0 = task_include_0.build_parent_block()
    assert parent_block_0 == task_include_0

# Generated at 2022-06-25 06:21:58.691428
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = {'a': 1, 'b': 2}
    task_include_0.args = {'a': 1, 'b': 2}
    task_include_0.action = 'include'

    parent_0 = Block()
    parent_0.vars = {'b': 2, 'a': 1}
    task_include_0._parent = parent_0

    result = task_include_0.get_vars()
    assert result == {'a': 1, 'b': 2}

    task_include_0.action = 'import_role'

    result = task_include_0.get_vars()
    assert result == {'a': 1, 'b': 2, 'tags': None, 'when': None}

# Unit

# Generated at 2022-06-25 06:22:08.876391
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    my_arg_names = frozenset()
    data_0 = {'any_key': None}
    # validation
    if task_include_0._validate_action('include') is False or task_include_0._validate_action('import_playbook') is False:
        # exception
        raise AnsibleParserError('Invalid options for %s: %s' % (task_include_0._validate_action, ','.join(list(my_arg_names))), obj=data_0)
    # validation

# Generated at 2022-06-25 06:22:20.958997
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    # Initialize the args
    task_include.args = {
        'apply': {
            'block': [
                {
                    'action': 'debug',
                    'msg': 'This is the main task'
                },
                {
                    'action': 'debug',
                    'msg': 'This is the main task'
                }
            ],
            'name': 'Include with apply'
        }
    }

    p_block = task_include.build_parent_block()
    assert p_block is not None, "No parent block is returned"
    assert p_block._parent is None, "The parent block is not initialized with the value None"
    assert p_block._role is None, "The parent block is not initialized with the value None"
    assert p_block.block is not None

# Generated at 2022-06-25 06:22:26.538193
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude()
    arg_1 = {
        u'file': 'test_file'
    }
    task_ret_1 = task_include_1.load(arg_1)
    assert isinstance(task_ret_1, TaskInclude)


# Generated at 2022-06-25 06:22:29.438517
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Create a new TaskInclude object and call `load` method
    task_include_0 = TaskInclude()
    task_include_1 = task_include_0.load({u'tags': [u'always'], u'include_role': {u'name': u'../roles/openstack'}, u'name': u'Include OpenStack'})
    assert task_include_1.args == {u'name': u'../roles/openstack'}


# Generated at 2022-06-25 06:22:38.673951
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test case method 'copy'
    task_include_0 = TaskInclude()
    task_include_0.statically_loaded = False
    task_include_0.action = 'include'

    # Test case method 'load'
    task_include_1 = TaskInclude()
    task_include_1.block = None
    task_include_1.role = None
    task_include_1.task_include = None

    # Test case method 'load'
    task_include_0 = TaskInclude()
    task_include_0.statically_loaded = False
    task_include_0.action = 'include'
    task_include_0.args = {}
    task_include_0.args['_raw_params'] = task_include_0.args.pop('file', None)

# Generated at 2022-06-25 06:22:41.532114
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()
    assert type(result) is dict
    assert result == {}



# Generated at 2022-06-25 06:22:54.587379
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0=TaskInclude()
    #Test 'include' action
    task_include_0._task_action="include"
    task_include_0.vars = {"var_1": "val_1", "var_2": "val_2"}
    task_include_0.args = {"_raw_params": "", "arg_1": "arg_1"}
    assert task_include_0.get_vars()=={"_raw_params": "", "arg_1": "arg_1", "var_1": "val_1", "var_2": "val_2"}
    #Test 'include' action
    task_include_0._task_action="include_role"

# Generated at 2022-06-25 06:22:57.089468
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert callable(task_include_0.build_parent_block)


# Generated at 2022-06-25 06:23:03.443993
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t2 = TaskInclude()
    t3 = TaskInclude()
    t3._parent = t2
    t3.vars = {"t3_var1" : "t3_value1", "t3_var2" : "t3_value2"}
    t3.args = {"t3_arg1" : "t3_value1", "t3_arg2" : "t3_value2"}
    t2.vars = {"t2_var1" : "t2_value1"}
    res = t3.get_vars()
    assert(res['t3_arg1'] == 't3_value1')
    assert(res['t3_arg2'] == 't3_value2')
    assert(res['t3_var1'] == 't3_value1')

# Generated at 2022-06-25 06:23:07.522432
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Marked as no cover because we don't have a test case for it yet
    # Also it is exercise code as an exmaple for how to implement this method
    # when you need it
    # assert task_include_0.build_parent_block() == "some result"
    pass

# Generated at 2022-06-25 06:23:16.104966
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # "apply" attribute is not specified
    task_include_1 = TaskInclude()
    task_include_1.args = {
        'a': 'b'
    }
    assert isinstance(task_include_1.build_parent_block(), TaskInclude)
    assert task_include_1.args == {
        'a': 'b'
    }
    # "apply" attribute is specified without "block" sub-attribute
    task_include_2 = TaskInclude()
    task_include_2.args = {
        'apply': {
            'a': 'b',
        }
    }
    assert isinstance(task_include_2.build_parent_block(), Block)
    assert task_include_2.args == {
        'a': {
            'a': 'b',
        }
    }

# Generated at 2022-06-25 06:23:18.179916
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}



# Generated at 2022-06-25 06:23:20.451063
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    TaskInclude_0 = TaskInclude()
    TaskInclude_0.check_options()

# Generated at 2022-06-25 06:23:27.688646
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args['apply'] = {'name': '', 'debugger': 'on', 'when': '', 'ignore_errors': '', 'loop': '',
                                    'loop_control': '', 'action': 'include_tasks', 'async_poll_interval': '30',
                                    'register': '', 'tags': '', 'no_log': ''}
    p_block = task_include_0.build_parent_block()

    assert p_block.action == 'block'
    assert p_block.loop == {}


# Generated at 2022-06-25 06:23:33.264561
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = Task(action='include', args={'tasks': 'tasks/main.yml', 'file': 'override_main.yml'})
    my_arg_names = frozenset(task.args.keys())
    print(task.args)
    print(task.action)
    print(task_include.check_options(task, task.args))
    if task_include.check_options(task, task.args):
        print('Success')
    else:
        print('Fail')


test_TaskInclude_check_options()

# Generated at 2022-06-25 06:23:34.720664
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.check_options(None,None)


# Generated at 2022-06-25 06:23:50.350893
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = task_include_0
    task_include._parent = None
    task_include._play = None
    task_include._loader = None
    task_include._role = None
    task_include._variable_manager = None
    task_include.args = {'apply': None}


# Generated at 2022-06-25 06:23:59.200749
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ds = dict()
    ds['action'] = 'include_role'
    task_include = TaskInclude.load(ds)
    p_block = task_include.build_parent_block()
    assert isinstance(p_block, TaskInclude)
    assert p_block.action == 'include_role'

    ds = dict()
    ds['action'] = 'include_role'
    ds['apply'] = dict()
    task_include = TaskInclude.load(ds)
    p_block = task_include.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.action == 'include_role'

# Generated at 2022-06-25 06:24:02.087298
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {'tags': 'all', 'apply': {'block': []}}
    result = task_include_0.build_parent_block()
    assert result is not None


# Generated at 2022-06-25 06:24:11.054015
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # create a block with name 'foo'
    block = Block()
    block['name'] = 'foo'
    # create a static task include with action 'include'
    task_include_0 = TaskInclude(block=block, statically_loaded=True)
    task_include_0['action'] = 'include'
    # set the parent block to be the one used before
    task_include_0._parent_block = block
    # create a parent block with the same name as the task include
    parent_block = Block()
    parent_block['name'] = 'foo'
    # set the parent block to be the one used before
    task_include_0._parent_block = parent_block
    # add the task include to the parent block
    parent_block.block += (task_include_0,)
    # call the method build_parent

# Generated at 2022-06-25 06:24:17.460346
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test the first use case when including a task
    task_include_0 = TaskInclude(
        action='include',
        args={'_raw_params': 'hello', 'a': 'b', 'c': 'd'}
    )
    task_include_0.vars = {'vars': 'the vars'}
    assert task_include_0.get_vars() == {
        '_raw_params': 'hello',
        'a': 'b',
        'c': 'd',
        'vars': 'the vars'
    }

    # test the second use case when including a role
    task_include_1 = TaskInclude(
        action='include_role',
        args={'_raw_params': 'hello', 'a': 'b', 'c': 'd'}
    )


# Generated at 2022-06-25 06:24:28.230179
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test for TaskInclude.build_parent_block()

    # Create an instance of class TaskInclude
    task_include_1 = TaskInclude()

    # Set the values of attributes for the class TaskInclude
    task_include_1.args = {
        '_raw_params': 'To be or not to be',
        'foo': 'bar',
        'apply': {
            'block': [],
            'name': 'should become parent block',
            'other_attrs': 'do we care?',
        },
    }
    task_include_1.action = 'include'

# Generated at 2022-06-25 06:24:30.666764
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    all_vars = task_include_0.get_vars()
    assert len(all_vars) == 0

# Generated at 2022-06-25 06:24:37.393106
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.vars = {
        'no_log': True,
        'vars_prompt': True
    }
    task_include_0.args = {
        'gather_facts': True,
        'module_setup': True,
    }
    p_block = task_include_0.build_parent_block()
    assert p_block == task_include_0
    assert task_include_0.vars == {
        'no_log': True,
        'vars_prompt': True,
        'gather_facts': True,
        'module_setup': True
    }


# Generated at 2022-06-25 06:24:41.804220
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.action not in C._ACTION_INCLUDE
    assert task_include_0.get_vars() == dict()

# Generated at 2022-06-25 06:24:44.707389
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    # build_parent_block return a TaskInclude object
    assert isinstance(task_include_0.build_parent_block(), TaskInclude)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:25:13.366103
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    expected_result_1 = None
    try:
        result_1 = task_include_1.build_parent_block()
    except Exception as e:
        result_1 = e
    assert isinstance(result_1, AttributeError)
    assert result_1.args == ("'NoneType' object has no attribute 'build_parent_block'",)
    task_include_2 = TaskInclude()
    expected_result_2 = None
    try:
        result_2 = task_include_2.build_parent_block()
    except Exception as e:
        result_2 = e
    assert isinstance(result_2, AttributeError)
    assert result_2.args == ("'NoneType' object has no attribute 'build_parent_block'",)
    task_

# Generated at 2022-06-25 06:25:16.477625
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    assert TaskInclude().get_vars() == {}

# Generated at 2022-06-25 06:25:23.982324
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    parent_block_0 = task_include_0.build_parent_block()
    assert parent_block_0 is task_include_0, 'TaskInclude.build_parent_block returned incorrectly'

    task_include_1 = TaskInclude()

    apply_attrs = {'block': []}
    task_include_1.args = {'apply': apply_attrs}
    parent_block_0 = task_include_1.build_parent_block()
    assert parent_block_0 is not task_include_1, 'TaskInclude.build_parent_block returned incorrectly'

    task_include_2 = TaskInclude()
    task_include_2.args = {'apply': {'block': [], 'bla': 'blah'}}

# Generated at 2022-06-25 06:25:31.230531
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_data = {
        'action': 'include_role',
        'name': 'Django',
        'apply': {},
        'collections': 'geerlingguy.django',
        'tags': 'setup'
    }
    task = TaskInclude.load(task_data)
    assert task.check_options(task, task_data) == task
    assert task.action == 'include_role'
    assert task.args['apply'] == {}
    assert task.args['collections'] == 'geerlingguy.django'
    assert task.args['tags'] == 'setup'


# Generated at 2022-06-25 06:25:40.564391
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {
        'apply': {
            'block': 'test_parent'
        }
    }
    parent_block = task_include.build_parent_block()
    assert isinstance(parent_block, Block)
    assert parent_block.block == 'test_parent'
    assert parent_block.block_type == 'test_parent'
    assert parent_block.parent is None
    assert parent_block.children == []
    assert parent_block.skipped is False
    assert isinstance(parent_block.vars, dict)
    assert parent_block.vars == {}
    assert isinstance(parent_block.always_run, list)
    assert parent_block.always_run == []
    assert isinstance(parent_block.loop, list)
   

# Generated at 2022-06-25 06:25:44.200757
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    c = TaskInclude()
    c.ds = {
        'include': 'foo.yml',
        'tags': ['bar']
    }
    d = c.preprocess_data(c.ds)

    assert 'include' not in d
    assert 'tags' in d


# Generated at 2022-06-25 06:25:50.261736
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = dict()
    task_include.args['apply'] = {'collect_facts': 'no'}
    task_include.args['block'] = []
    block_result = task_include.build_parent_block()
    assert block_result.__class__.__name__ == 'Block'
    assert block_result.collect_facts == 'no'
    assert block_result._attributes['block'] == []

# Generated at 2022-06-25 06:25:52.371799
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    assert task_include.get_vars() == {}

# Generated at 2022-06-25 06:26:03.320900
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class TaskInclude(object):
        def __init__(self):
            self.VALID_INCLUDE_KEYWORDS = ['foo', 'bar', 'action', 'args']

        def preprocess_data(self, ds):
            ds = self.preprocess_data(ds)

            diff = set(ds.keys()).difference(self.VALID_INCLUDE_KEYWORDS)