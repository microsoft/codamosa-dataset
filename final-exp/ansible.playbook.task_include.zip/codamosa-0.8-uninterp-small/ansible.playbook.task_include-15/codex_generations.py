

# Generated at 2022-06-25 06:16:11.897520
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    str_0 = 'i7'
    str_1 = 'T=;HrFBdK^'
    str_2 = 'p'
    str_3 = 'K,z'
    str_4 = ','
    str_5 = 'P,i<'
    str_6 = 'y}'
    str_7 = '*Q'
    str_8 = '}'
    str_9 = 'G'
    str_10 = 'o'
    str_11 = 'm*'
    str_12 = '<7'
    str_13 = '6]FX'
    str_14 = 'FFJ'
    str_15 = '#L'
    str_16 = 'c'
    str_17 = 'M'
    str_18 = 'Kj+'

# Generated at 2022-06-25 06:16:21.743659
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    t1 = TaskInclude("play.block.task")
    t1.apply = {
        'block': ['d2', 'd3'],
        '_raw_params': 'd1',
        'a': 'd4',
        'b': 'd5',
    }
    t1.vars = {'a': 'v1', 'b': 'v2'}
    t1.args = {'a': 'a1', 'b': 'a2', 'c': 'a3'}
    t1._parent = "play"

    t2 = t1.build_parent_block()
    assert t2.args == {'_raw_params': 'd1', 'c': 'a3'}
    assert t2.vars == {'a': 'a1', 'b': 'a2'}

# Generated at 2022-06-25 06:16:26.033610
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    arg = {'block': '', 'action': 'include_tasks', 'file': 'main.yaml', 'apply': {'ignore_errors': 'yes'}, '_ansible_check_mode': False, '_ansible_no_log': False, '_ansible_verbosity': 0, '_ansible_diff': False}
    TaskInclude.load(arg, str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 06:16:31.415842
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Initialize a TaskInclude. Passing None for the args attribute results in an
    # empty list.

    task_include_0 = TaskInclude(None, None, None)

    # Apply the 'check_options' method to task_include_0.
    # The 'check_options' method may throw an exception, so we
    # perform a try and except block.
    try:
        task_include_0.check_options(None, None)
    except Exception as e:
        print("An exception occurred")
        print(str(e))


# Generated at 2022-06-25 06:16:37.033156
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    str_0 = 'U9yA<6M{2G^b\\}jN]:c'
    task_include_0 = TaskInclude(str_0, str_0)
    dict_0 = {'J@,}w{p4(O\x0bo?`F2c9': 'S_,?h^g\x0bQZ|w&', 'd8W,]\x0bs`y&t+r-%5': 'J??,*\x0b&z$qGQ!n*'}
    dict_1 = task_include_0.preprocess_data(dict_0)

# Generated at 2022-06-25 06:16:40.341633
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    str_0 = 'W@k$yv7Bfh]^F(3q.s\'='
    task_include_1 = TaskInclude(str_0, str_0)
    task_include_1.preprocess_data(str_0)


# Generated at 2022-06-25 06:16:41.799378
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()

if __name__ == '__main__':
    # Unit test
    test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:16:46.920512
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    str_0 = 'name'
    task_include_0 = TaskInclude(str_0, str_0)



# Generated at 2022-06-25 06:16:54.371508
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    str_0 = 'r&Z6g^B?->*P4V(s\r/p'
    task_include_0 = TaskInclude(str_0, str_0)
    data = {}
    task_include_0.check_options('r&Z6g^B?->*P4V(s\r/p', data)


# Generated at 2022-06-25 06:16:59.829257
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    str_0 = '?fP-;m(y'
    task_include_0 = TaskInclude(str_0, str_0)
    assert task_include_0.build_parent_block() == None


# Generated at 2022-06-25 06:17:09.082009
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = TaskInclude()
    # Create a fake parent block to test the method
    task._parent = Block()
    task._parent.attributes = FieldAttribute(block=task._parent, parent=task._parent, field_name="attributes", loader=task._loader, attribute=None)
    task._parent.vars = {"test": 1}
    apply_attrs = {'block': []}
    task.args['apply'] = apply_attrs

    result = task.build_parent_block()

    assert result is not None
    assert result is not task
    assert "test" in result.vars


# Generated at 2022-06-25 06:17:21.032346
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.display("Test TaskInclude check_options")

    display.display("No file provided, error expected")

    task_include_0 = TaskInclude()
    task_include_0.args = dict(
        file = None
    )
    task_include_0.action = "include"

    try:
        task_include_0.check_options(task_include_0, {})
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert "No file specified for include" in str(e)

    display.display("Invalid arguments, error expected")

    task_include_1 = TaskInclude()
    task_include_1.args = dict(
        file = "goodfile.yml",
        bad_key = "bad_val"
    )

# Generated at 2022-06-25 06:17:29.879169
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args['apply'] = {}
    task_include_0._parent = Task()
    task_include_0._role = Role()
    task_include_0._variable_manager = VariableManager()
    task_include_0._loader = DataLoader()
    p_block_0 = task_include_0.build_parent_block()
    print(p_block_0)
    assert isinstance(p_block_0, Block)
    assert p_block_0._parent == task_include_0
    assert p_block_0._play == task_include_0._parent._play
    assert p_block_0._task_include == task_include_0
    assert p_block_0._variable_manager == task_include_0._variable_manager

   

# Generated at 2022-06-25 06:17:37.326132
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test function with inputs:
    #   ds:{'action': 'include', 'tasks': ['tasks/main.yml']}
    # Expected:
    #   {'action': 'include', 'tasks': ['tasks/main.yml']}
    ds = {'action': 'include', 'tasks': ['tasks/main.yml']}
    result = TaskInclude().preprocess_data(ds)
    assert result == {'action': 'include', 'tasks': ['tasks/main.yml']}


# Generated at 2022-06-25 06:17:46.516375
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display.verbosity = 3
    task_include_0 = TaskInclude()
    task_include_0._loader = None
    task_include_0._variable_manager = None
    task_include_0.args['_raw_params'] = 'foo'
    task_include_0.args['apply'] = {}
    task_include_0.action = 'include'
    ds = {}
    ret = task_include_0.preprocess_data(ds)
    assert ret == {}
    task_include_0.action = 'import_playbook'
    ds = {}
    ret = task_include_0.preprocess_data(ds)
    assert ret == {}
    task_include_0.action = 'include'
    ds = {u'a': Sentinel}
    ret = task_include_0.pre

# Generated at 2022-06-25 06:17:54.824795
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    # Apply the method to be tested
    data = {'register': 'my_fact', 'action': 'include_vars', 'name': 'var_name'}
    task_include_0.preprocess_data(data)

    assert task_include_0.action == 'include_vars'
    assert task_include_0.args.get('name') == 'var_name'

    data = {'register': 'my_fact', 'action': 'include_role', 'name': 'var_name'}
    task_include_0.preprocess_data(data)

    assert task_include_0.action == 'include_role'
    assert task_include_0.args.get('name') == 'var_name'



# Generated at 2022-06-25 06:18:00.772063
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    my_task_include = TaskInclude()
    my_task_include.args = {'file':'test_file', 'other_arg':'test_value'}
    my_task_include.action = 'include'
    my_task_include.post_validate()
    my_task_include.check_options(my_task_include, {'file':'test_file', 'other_arg':'test_value'})
    assert my_task_include.args['_raw_params'] == 'test_file'
    assert 'file' not in my_task_include.args

    my_task_include.args = {'file':'test_file', 'random_arg':'test_value'}
    my_task_include.action = 'include'
    my_task_include.post_validate()


# Generated at 2022-06-25 06:18:11.208875
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_include_0 = TaskInclude()
    data_1 = {'action': 'include', 'args': {'_raw_params': 'myinclude.yml', 'apply': {'ignore_errors': False, 'first_available_file': False, 'delegate_to': '127.0.0.1', 'first_available_file_sort:': 'desc', 'with_items': [{'with_first_found': '{{ lookup("first_found", item) }}', 'file:': '{{ item }}', 'vars:': {'a': 'b'}}, {'with_first_found': '{{ lookup("first_found", item) }}', 'file:': '{{ item }}', 'vars:': {'a': 'b'}}]}}}

# Generated at 2022-06-25 06:18:19.030888
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-25 06:18:27.382787
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(action='include_role', file='role1.yaml', ignore_errors='yes')

    task = TaskInclude()
    task = task.check_options( task.load_data(data), data)
    assert isinstance(task, TaskInclude)
    assert task.action == 'include_role'
    assert task.args == {'file': 'role1.yaml', 'ignore_errors': 'yes'}


# Generated at 2022-06-25 06:18:40.756257
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.args = {
        '_raw_params': 'raw_params_0',
        'file': 'file_1',
        'other': 'other_2',
    }
    task_include_0.action = 'include'
    task_include_0.check_options(task_include_0, None)
    assert len(task_include_0.args) == 2
    assert task_include_0.args['_raw_params'] == 'raw_params_0'
    assert task_include_0.args['file'] == 'file_1'

# Generated at 2022-06-25 06:18:44.625302
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.args
    dict_vars = task_include_1.get_vars()
    assert dict_vars == {}, 'SOMETHING HAS GONE WRONG'


# Generated at 2022-06-25 06:18:48.685858
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    vars_0 = task_include_0.get_vars()

# Generated at 2022-06-25 06:18:55.277785
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    try:
        task_include_1 = TaskInclude()
        task_include_1.action = 'task_include'
        task_include_1.args = {'test_var' : 'test_value'}
        variable_manager_1 = None
        variable_manager_1 = task_include_1.get_vars(variable_manager_1)
        assert variable_manager_1[0].get('test_var') == 'test_value'
    except:
        print('TaskInclude.get_vars failed')



# Generated at 2022-06-25 06:18:59.348826
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    action_type = 'import_tasks'
    args = dict()

    task_include_0 = TaskInclude(task_include=None, action=action_type, args=args)

    task_include_0.build_parent_block()


# Generated at 2022-06-25 06:19:05.257698
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'_raw_params': 'foobar'}
    expected_p_block = task_include
    actual_p_block = task_include.build_parent_block()
    assert expected_p_block is actual_p_block


# Generated at 2022-06-25 06:19:13.813181
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()

    temp_args = dict()
    temp_args['_raw_params'] = 'test'
    temp_args['debugger'] = 'true'
    temp_args['ignore_errors'] = 'true'
    temp_args['loop'] = 'with_items'
    temp_args['loop_control'] = dict()
    temp_args['loop_control']['loop_var'] = 'item'
    temp_args['loop_with'] = 'inventory_hostname'
    temp_args['name'] = 'Task Name'
    temp_args['no_log'] = 'true'

# Generated at 2022-06-25 06:19:20.397780
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    task_include_0 = TaskInclude(play=Play())
    task_include_0.args = dict()
    task_include_0.args['apply'] = dict()
    task_include_0.args['apply']['block'] = []
    expected = task_include_0
    actual = task_include_0.build_parent_block()
    assert actual == expected



# Generated at 2022-06-25 06:19:28.123420
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ds = {'action': 'include_role', 'apply': 'foo', 'file': 'foo.yaml'}
    task_include1 = TaskInclude()
    assert task_include1.check_options(task_include1.load_data(ds), ds) == task_include1

    task_include2 = TaskInclude()
    assert task_include2.check_options(task_include2.load_data(dict(action='include_tasks', file='foo.yaml')), dict(action='include_tasks', file='foo.yaml')) == task_include2

    task_include3 = TaskInclude()

# Generated at 2022-06-25 06:19:32.209276
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    data = {}
    task_include_0.check_options(task_include_1, data)
    return True


# Generated at 2022-06-25 06:19:46.593086
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    class RosterItem:
        def __init__(self, host_name):
            self.host_name = host_name
    ti = TaskInclude()
    ti.action = 'include_role'
    task = Task()

# Generated at 2022-06-25 06:19:54.861253
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    data_0 = {
        'ignore_errors': True,
        'register': None,
        'loop': Sentinel,
        'when': None,
        'action': 'include_role',
        'file': 'foo',
        'tags': Sentinel,
        '_raw_params': 'foo',
        'apply': None,
        'name': Sentinel,
        'vars': Sentinel,
        'args': Sentinel,
        'debugger': None,
        'no_log': False,
        'loop_with': Sentinel,
        'timeout': None,
        'collections': Sentinel,
        'run_once': False,
        'loop_control': Sentinel
    }
    result = task_include_0.preprocess_data(data_0)

# Generated at 2022-06-25 06:20:04.658956
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 1
    # set up variables
    data1 = dict(
        file = 'test.yaml',
        action = 'include',
        task_attributes = dict(
            ignore_errors = True,
            register = 'test'
        ),
    )
    task_include_1 = TaskInclude.load(data1)
    assert task_include_1.get_vars() == {
        'ignore_errors': True,
        'register': 'test',
        'file': 'test.yaml'
    }

    # test case 2
    # set up variables
    data2 = dict(
        file = 'test.yaml',
        action = 'include_tasks',
        task_attributes = dict(
            ignore_errors = True,
            register = 'test'
        ),
    )


# Generated at 2022-06-25 06:20:08.089512
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    return_value__ = Sentinel(False)
    res = task_include_0.check_options(return_value__, return_value__)
    return res

# Generated at 2022-06-25 06:20:19.076418
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.vars = {}

# Generated at 2022-06-25 06:20:29.648891
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # For 'include', 'include_tasks', 'import_role' action
    #   wrong arguments should raise an error
    for action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS:
        ti = TaskInclude()
        ti.action = action
        ti.args = {'_raw_params': 'file', 'key': 'value'}

        with pytest.raises(AnsibleParserError) as exc:
            ti.check_options(ti, None)

    # For 'include', 'include_tasks', 'import_role' action
    #   'apply' should raise an error
    for action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS:
        ti = TaskInclude()
        ti.action = action

# Generated at 2022-06-25 06:20:41.163615
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Create a task_include object
    task_include_0 = TaskInclude()

    # Create a block object
    block_0 = Block()
    block_0.parent_block = block_0

    # Create a task object
    task_0 = Task()
    task_0.default_args = dict()
    task_0.action = 'setup'
    task_0.args = dict()
    task_0.args['host'] = ''
    task_0.args['gather_subset'] = 'all'
    task_0.block = block_0
    task_0.block._parent = block_0
    task_0.block.parent_block = block_0
    task_0.block.vars = dict()
    task_0.block.vars['aaa'] = 'bbb'
    task

# Generated at 2022-06-25 06:20:47.463171
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    check_options() is defined in super class ``Task`` and should not be
    overridden by ``TaskInclude``.
    """
    task_include_0 = TaskInclude()
    assert not hasattr(task_include_0, 'check_options')


# Generated at 2022-06-25 06:20:54.912794
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict()
    try:
        task_include_0.preprocess_data(ds)
    except Exception as e:
        display.display('Caught exception: %s' % e, color='red')
        display.display(traceback.format_exc(), color='red')
        raise
    return task_include_0



# Generated at 2022-06-25 06:21:03.973915
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = task_include_0.check_options(
        task_include_0.load_data(
            {
                'file': 'include1.yaml',
                'action': 'include1.yaml',
            },
            variable_manager=None,
            loader=None
        ),
        {
            'file': 'include1.yaml',
            'action': 'include1.yaml',
        }
    )

    assert task_include_1.args['_raw_params'] == 'include1.yaml'


# Generated at 2022-06-25 06:21:18.233298
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Setup
    task_include_0 = TaskInclude()
    task_include_0.action = "include"
    task_include_0.args = {'var1': "val1", 'var2': "val2", 'tags': "tag1", 'when': "cond1"}

    # Invocation
    result = task_include_0.get_vars()

    # Verification
    assert 'var1' in result
    assert 'var2' in result
    assert 'tags' not in result
    assert 'when' not in result
    assert result['var1'] == "val1"
    assert result['var2'] == "val2"

# Generated at 2022-06-25 06:21:26.701103
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create task_include object
    task_include_1 = TaskInclude()
    # Has no parent block
    assert task_include_1.BASE == frozenset({'file', '_raw_params'})
    assert task_include_1.OTHER_ARGS == frozenset({'apply'})
    assert task_include_1.VALID_ARGS == frozenset({'file', '_raw_params', 'apply'})
    assert task_include_1.VALID_INCLUDE_KEYWORDS == frozenset({'action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                        'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                        'when'})

# Generated at 2022-06-25 06:21:33.736799
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create mock object for 'TaskInclude'
    task_include_mock = TaskInclude()

    # Create empty dictionary
    ds = {}

    # Test TaskInclude.preprocess_data() with empty dictionary
    with pytest.raises(AnsibleParserError) as e:
        task_include_mock.preprocess_data(ds)
    assert e.value.message == 'No action specified in task'

    # Test TaskInclude.preprocess_data() with correct dictionary
    ds = {'action': 'include'}
    task_include_mock.preprocess_data(ds)

# Generated at 2022-06-25 06:21:44.998314
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    task_include_0_include_file_v0 = AnsibleUnicode('chore.yml')
    task_include_0_include_file_v1 = AnsibleUnicode('chore.yml')
    task_include_0_include_file_v2 = AnsibleUnicode('chore.yml')
    task_include_0_include_file_v3 = AnsibleUnicode('chore.yml')
    task_include_0_include_file_v4 = AnsibleUnicode('chore.yml')
    task_include_0_include_file_v5 = AnsibleUnicode('chore.yml')

# Generated at 2022-06-25 06:21:51.466141
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-25 06:22:01.968094
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.action = "include_role"
    data = {
        'import_role': Sentinel,
        'debugger': Sentinel,
        'static': Sentinel,
        'loop': Sentinel,
        'loop_control': Sentinel,
        'register': Sentinel,
        'tags': Sentinel,
        'when': Sentinel,
        'ignore_errors': Sentinel,
        'run_once': Sentinel,
        'collections': Sentinel,
        'timeout': Sentinel,
        'name': Sentinel,
        'new_property': Sentinel
    }
    task_include_1 = task_include_0.preprocess_data(data)
    assert task_include_1['import_role'] is Sentinel and task_include_1['debugger']\
        is Sentinel and task_include_

# Generated at 2022-06-25 06:22:08.110839
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_attrs = {'a':1,'b':2,'block':[]}
    task = TaskInclude()
    task_include = TaskInclude(apply_attrs,apply=apply_attrs)

    assert task_include.args == {}
    assert task_include.build_parent_block() == task_include
    task_include.args['apply'] = apply_attrs
    #assert task_include.build_parent_block() == task

# Generated at 2022-06-25 06:22:11.272215
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    options = dict()
    options['file'] = 'nodes.yml'
    task_include_0.check_options(task=None, data=options)


# Generated at 2022-06-25 06:22:22.360158
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Ensure we can call the get_vars() method of TaskInclude and receive
    appropriate results for various scenarios.
    """
    # initialize fields of TaskInclude
    task_include_0 = TaskInclude(block=Block(), role=None, task_include=None)

    # initialize fields of Block
    block_0 = Block()
    block_0.parent = None
    block_0.role = None
    block_0.dep_chain = []
    block_0.statically_loaded = False
    block_0.block = None
    block_0.always_run = False
    block_0.any_errors_fatal = None
    block_0.any_errors_fatal_defined = False
    block_0.any_errors_fatal_override = False

# Generated at 2022-06-25 06:22:33.408003
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins import loader

    variable_manager = VariableManager()
    loader.add_directory(C.DEFAULT_MODULE_PATH)

    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['test_host']))


# Generated at 2022-06-25 06:23:00.354301
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # Check if all valid args are accepted
    valid_args = dict(file='foo.yml', apply={'a': 1, 'b': 2})
    task = ti.check_options(
        ti.load_data(valid_args, variable_manager=None, loader=None),
        valid_args,
    )
    assert sorted(task.args.keys()) == ['apply', 'file']

    # Check if apply is only accepted for include/include_tasks, not for others
    apply_attrs = dict(file='foo.yml', apply={'a': 1, 'b': 2})
    task = ti.check_options(
        ti.load_data(apply_attrs, variable_manager=None, loader=None),
        apply_attrs,
    )

# Generated at 2022-06-25 06:23:10.611663
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Given
    task_include = TaskInclude()
    task_include.args = {'apply': {'_line': 1, 'block': []}, 'block': {'_line': 1, 'block': []}}
    # When
    p_block = task_include.build_parent_block()
    # Then
    assert p_block.args == task_include.args
    # When
    task_include.args = {'block': {'_line': 1, 'block': []}}
    p_block = task_include.build_parent_block()
    # Then
    assert p_block == task_include
    # When
    task_include.args['apply'] = None
    # Then

# Generated at 2022-06-25 06:23:14.822267
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    block_attrs = {
        'block': [],
        'always': True,
        'failed_when': False,
        'rescue': [],
        'when': 'false'
    }

    mock_role = Sentinel()
    mock_variable_manager = Sentinel()
    mock_loader = Sentinel()
    mock_play = Sentinel()

    # Init task_include_1
    task_include_1 = TaskInclude(
        {
            'block': [],
            'block': block_attrs,
            'apply': block_attrs,
            'role': mock_role,
            '_variable_manager': mock_variable_manager,
            '_loader': mock_loader,
            '_parent': {
                '_play': mock_play
            }
        },
    )

    # Call method
   

# Generated at 2022-06-25 06:23:23.740191
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_obj_0 = TaskInclude()
    apply_attrs_str_0 = 'block'
    apply_attrs_str_1 = 'loop'
    apply_attrs_str_2 = 'loop_with'
    apply_attrs_str_3 = 'when'
    apply_attrs_dict = {apply_attrs_str_0: [
        apply_attrs_str_1, apply_attrs_str_2, apply_attrs_str_3]}
    task_include_obj_0.args = apply_attrs_dict
    TaskInclude.build_parent_block(task_include_obj_0)


# Generated at 2022-06-25 06:23:34.110356
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action     = 'include_role'

    task_include_0.args       = dict()
    task_include_0.args['name'] = 'foo'
    task_include_0.args['tasks'] = 'foo'
    task_include_0.args['become'] = 'foo'
    task_include_0.args['become_user'] = 'foo'
    task_include_0.args['become_flags'] = 'foo'

    task_include_0.vars       = dict()
    task_include_0.vars['name'] = 'foo'

    task_include_1 = TaskInclude()
    task_include_1.action     = 'include'

    task_include_1.args       = dict()


# Generated at 2022-06-25 06:23:45.975927
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import inspect
    import sys
    import os

    source_file = os.path.join(C.DEFAULT_ROLES_PATH,
                               os.path.join('common', 'tasks', 'main.yml'))
    role_0_path = os.path.join(C.DEFAULT_ROLES_PATH, 'role_0')
    role_0_meta_path = os.path.join(role_0_path, 'meta')
    role_0_tasks_path = os.path.join(role_0_path, 'tasks')
    role_0_handlers_path = os.path.join(role_0_path, 'handlers')
    role_0_templates_path = os.path.join(role_0_path, 'templates')
    role_0_files

# Generated at 2022-06-25 06:23:54.443282
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

# Generated at 2022-06-25 06:24:04.390112
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.plugins import module_loader
    from ansible import constants as C

    # Create a Play
    play_0 = Play().load({
        'name': 'test_case_0',
        'hosts': 'localhost',
        'gather_facts': False,
        'tasks': [
            {
                'name': 'test_task',
                'action': 'copy',
                'args': {},
                'ignore_errors': True,
            },
        ],
    }, variable_manager=None, loader=module_loader)

    # Create a TaskInclude object
    task_include_0 = TaskInclude(block=play_0._block, task_include=play_0._block._parent_block)

   

# Generated at 2022-06-25 06:24:14.102671
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.preprocess_data({u'include_with_items': u'{{ my_list }}', u'action': u'include_with_items', u'include_with_items_without_vars': u'{{ my_list | map(attribute=\'name\') | list }}', u'include_with_items_with_vars': u'{{ my_list | map(attribute=\'name\') | list }}', u'include_with_params': u'{{ my_include_params }}', u'include_with_nested_vars': u'{{ my_nested_list }}', u'include_with_vars': u'{{ my_include_params }}', u'loop': u'{{ my_list }}'})

# Generated at 2022-06-25 06:24:25.875471
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Run some validations to check the options for TaskInclude
    '''
    # pylint: disable=no-self-use
    task_include_0 = TaskInclude()

    # Check all keywords are valid

# Generated at 2022-06-25 06:25:11.612381
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    vars2 = dict()
    vars2['name'] = 'test1'
    vars2['debug'] = 'true'
    vars2['timeout'] = 300

    task_include_0 = TaskInclude()
    task_include_0.args = vars2
    assert task_include_0.get_vars() == vars2
    task_include_0.action = 'run'
    assert task_include_0.get_vars() == vars2
    task_include_0.action = 'include'
    assert task_include_0.get_vars() == dict((('name', 'test1'), ('debug', 'true')))
    task_include_0.register = 'name'

# Generated at 2022-06-25 06:25:12.643761
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # TODO
    pass



# Generated at 2022-06-25 06:25:22.186154
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    lines = []
    task = TaskInclude.load(
        {
            'include': './some_file.yml',
            'name': 'task name',
            'tags': ['tag1', 'tag2'],
            'when': True,
            'apply': {},
            'debugger': True
        },
        loader=None,
        variable_manager=None,
    )
    assert len(task.args) == 5
    assert task.name == 'task name'
    assert task.tags == ['tag1', 'tag2']
    assert task.when
    assert task.action == 'include'
    assert 'apply' in task.args
    assert task.args['apply'] == {}
    assert task.debugger


# Generated at 2022-06-25 06:25:27.375323
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    ti = TaskInclude.load({'action': 'include', 'file': 'test.yml'},
                          task_include=task_include_0)
    assert ti.statically_loaded is False
    assert ti.args.get('_raw_params') == 'test.yml'


# Generated at 2022-06-25 06:25:36.472132
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args = dict()
    task_include_0._parent = '_parent'
    task_include_0.args.update(dict())
    task_include_0.vars = dict()
    task_include_0.vars.update(dict())
    task_include_0._parent.get_vars = lambda: dict()
    task_include_0._parent.get_vars().update(dict())
    task_include_0.get_vars()
    task_include_0._parent.get_vars().update(dict())
    task_include_0.get_vars()

# Generated at 2022-06-25 06:25:47.710669
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    data_0 = {'a': 'aaaaaaaaaa', 'b': 'bbbbbbbbbb'}
    task_0 = task_include_0.check_options(task_include_0, data_0)
    assert task_0.get('action') == 'include'
    assert task_0.get('_raw_params') == 'file'
    assert task_0.get('block') == 'task_include'
    assert task_0.get('role') == 'task_include'
    assert task_0.get('task_include') == 'task_include'
    assert task_include_0.check_options(task_0, data_0).action == 'include'
    assert task_include_0.check_options(task_0, data_0)._raw_

# Generated at 2022-06-25 06:25:52.559290
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude({'action': 'include', 'args': {'apply': 'something'}})
    task_include_1.build_parent_block()
    assert(task_include_1.args['apply'] == {})


# Generated at 2022-06-25 06:25:57.494611
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create an instance of TaskInclude
    task_include_0 = TaskInclude(
        apply={"key": "value"},
        _raw_params="include: {{ file_name }}",
        action="include",
        vars={"key": "value"},
        _parent=None,
        _role=None,
        _loader=None,
        _variable_manager=None,
        _block=None,
        _task_include=None,
        _included_file=None,
        statically_loaded=False
    )

    # The vars of included tasks should be set to a dict
    task_include_0_vars = task_include_0.get_vars()
    assert isinstance(task_include_0_vars, dict)