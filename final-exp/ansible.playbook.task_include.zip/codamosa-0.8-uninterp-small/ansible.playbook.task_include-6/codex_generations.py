

# Generated at 2022-06-25 06:16:09.848503
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import pytest
    import sys
    import ansible.modules.cgroup as ansible_cgroup
    import ansible.modules.system as ansible_system
    from ansible.module_utils.facts import ansible_architecture
    from ansible.module_utils.facts import ansible_selinux as ansible_selinux_orig
    from ansible.module_utils.facts import ansible_virtualization as ansible_virtualization_orig
    from ansible.module_utils.facts import ansible_system as ansible_system_orig
    import ansible.module_utils.basic as ansible_basic
    import ansible.module_utils.facts as ansible_facts
    import ansible.module_utils.facts.system as facts_system
    import ansible.module_utils.facts.virtual as facts_virtual
   

# Generated at 2022-06-25 06:16:18.323809
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """Unit test for method build_parent_block of class TaskInclude

    :param task_include_0: instance of class TaskInclude
    :type task_include_0: TaskInclude
    :param var_0: instance of class Block
    :type var_0: Block
    """
    task_include_0 = TaskInclude.load({"action": "include"}, task_include=None, block=None, role=None, variable_manager=None, loader=None)
    assert isinstance(task_include_0, TaskInclude)
    var_0 = task_include_0.build_parent_block()
    assert isinstance(var_0, Block)


# Generated at 2022-06-25 06:16:28.100278
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    var_1 = dict()
    var_2 = dict()
    var_2['action'] = 'set_fact'
    var_1['action'] = 'set_fact'
    var_3 = dict()
    var_3['action'] = 'include'
    var_4 = dict()
    var_4['action'] = 'include'

    task_include_0 = TaskInclude()
    var_5 = task_include_0.preprocess_data(var_1)

    # First test: 'set_fact'
    assert var_5['action'] == 'set_fact'

    # Second test: 'include'
    task_include_1 = TaskInclude()
    var_6 = task_include_1.preprocess_data(var_3)
    assert var_6 == {'action': 'include'}

# Generated at 2022-06-25 06:16:34.219105
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # test with 'include: file'
    display.display("Testing TaskInclude class load method")
    data_0_1 = {'include': 'file'}
    ti_0_1 = TaskInclude()
    ti_0_1.load(data_0_1)


# Generated at 2022-06-25 06:16:39.952520
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    tp = TaskInclude()
    r = tp.build_parent_block()
    assert(isinstance(r, Block) or isinstance(r, Task))

# Generated at 2022-06-25 06:16:41.659430
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert var_0 is not None


# Generated at 2022-06-25 06:16:46.065942
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    args_0 = {'_raw_params': None, 'file': '2'}
    data_0 = {'action': '3'}
    task_include_0 = TaskInclude()
    task_include_0.args = args_0
    task_0 = task_include_0.check_options(task_include_0, data_0)
    var_0 = task_0.args.get('_raw_params')
    assert var_0 == '2'


# Generated at 2022-06-25 06:16:56.519604
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    check_error_msg = "Unable to load task include file for action 'static_include' (could not open file #: No such file or directory)"
    task_include_0 = TaskInclude()
    action_1 = 'static_include'
    file_0 = 'some_file'
    try:
        task_include_1 = task_include_0.load(
            {'action': action_1, 'file': file_0},
            loader=None,
            variable_manager=None,
            )
    except (IOError, AnsibleParserError) as e:
        assert e.message == check_error_msg

# Generated at 2022-06-25 06:16:58.388988
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {}
    obj = TaskInclude()
    ret = obj.preprocess_data(ds)

    assert ret is None

# Generated at 2022-06-25 06:17:06.154744
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test for action in C._ACTION_INCLUDE, key 'tags' existing in all_vars, 'when' existing in all_vars
    task_include_0 = TaskInclude()
    all_vars_0 = task_include_0.get_vars()
    assert (all_vars_0['tags'] == None)
    # test for action in C._ACTION_INCLUDE, key 'tags' existing in all_vars, 'when' not existing in all_vars
    task_include_1 = TaskInclude()
    all_vars_1 = task_include_1.get_vars()
    assert (all_vars_1['tags'] == None)
    # test for action not in C._ACTION_INCLUDE, key 'tags' existing in all_vars, 'when'

# Generated at 2022-06-25 06:17:14.266390
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert var_0 == {}


# Generated at 2022-06-25 06:17:15.687297
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_case_0()



# Generated at 2022-06-25 06:17:17.350007
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()

# Generated at 2022-06-25 06:17:26.600255
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Case 0
    task_include_0 = TaskInclude()
    data_0 = dict()
    actual_0 = task_include_0.check_options(None, data=data_0)
    expected_0 = None
    assert actual_0 == expected_0
    # Case 1
    task_include_1 = TaskInclude()
    data_1 = dict()
    actual_1 = task_include_1.check_options(None, data=data_1)
    expected_1 = None
    assert actual_1 == expected_1
    # Case 2
    task_include_2 = TaskInclude()
    data_2 = dict()
    actual_2 = task_include_2.check_options(None, data=data_2)
    expected_2 = None
    assert actual_2 == expected_2
   

# Generated at 2022-06-25 06:17:33.473485
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = "not_in"
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0._parent = None
    var_0 = task_include_0.get_vars()
    assert var_0 == dict()
    task_include_1 = TaskInclude()
    task_include_1.action = "include"
    task_include_1.vars = dict()
    task_include_1.args = dict()
    task_include_1._parent = None
    var_1 = task_include_1.get_vars()
    assert var_1 == dict()
    task_include_2 = TaskInclude()

# Generated at 2022-06-25 06:17:39.973591
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = { "_ansible_check_mode": "True", "_ansible_no_log": "True", "_ansible_verbosity": "0", "_raw_params": "file.yml", "action": "include_tasks" }
    task_1 = task_include_0.check_options(task_0, task_0)
    assert task_1['_raw_params'] == 'file.yml'

# Generated at 2022-06-25 06:17:43.808907
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.warning('Unit test may not be reliable: '
                    'TaskInclude.check_options (parsing/task_include.py)')

    # test case 0
    task_include_0 = TaskInclude.load(dict())
    attr_0 = task_include_0.check_options(task_include_0, dict())
    assert attr_0 is task_include_0

# Generated at 2022-06-25 06:17:50.375008
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {'file': 'file_0.yml'}
    task_include_0.when = 'any'
    task_include_0.tags = ['tag_0']
    task_include_0.vars = {'var_0': 'val_0'}
    var_0 = task_include_0.get_vars()
    assert var_0 == {'var_0': 'val_0', 'file': 'file_0.yml'}


# Generated at 2022-06-25 06:17:59.688002
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Check if file argument is present
    data = {'file': 'some_path'}
    task = TaskInclude(block=None, role=None, task_include=None)
    task = task.check_options(task, data)

    assert task.action == 'include'
    assert task.statically_loaded is False
    assert task.args == {'_raw_params': 'some_path'}

    # Check if file argument is missing
    data = {'key1': 'val1', 'key2': 'val2'}
    task = TaskInclude(block=None, role=None, task_include=None)
    task = task.check_options(task, data)

    assert task.action == 'include'
    assert task.statically_loaded is False

# Generated at 2022-06-25 06:18:03.920601
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds_0 = {'action': 'some_value'}
    test_value_0 = task_include_0.preprocess_data(ds_0)
    assert test_value_0 is not None
    assert test_value_0 is ds_0

# Generated at 2022-06-25 06:18:11.109508
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # set up object
    task_include_1 = TaskInclude()

    # set up params
    ds_1 = dict()

    # invoke the test function
    result_1 = task_include_1.preprocess_data(ds_1)

    # assertions
    assert result_1 == ds_1


# Generated at 2022-06-25 06:18:14.747890
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_case_0()


# Generated at 2022-06-25 06:18:21.507454
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def compare_vars(vars_expected, vars_result):
        if isinstance(vars_expected, dict) and isinstance(vars_result, dict):
            if vars_expected != vars_result:
                return False
        else:
            return False

        return True

    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()

    var_1 = {
    }
    assert compare_vars(var_0, var_1)

    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    var_0 = task_include_1.get_vars()

    var_1 = {
    }
    assert compare_vars(var_0, var_1)

    task_include_

# Generated at 2022-06-25 06:18:26.727480
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    print('Test: get_vars')
    # Setup test
    # Test implementation
    print('Implementation not yet written')
    # Test assertions
    # Cleanup test
    print('Cleanup not yet implemented')
    # Teardown test
    print('teardown not yet implemented')


# Generated at 2022-06-25 06:18:31.513088
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args = {
        '_raw_params': 'file',
        'apply': {
            'block': [],
            'action': 'include'
        },
        'file': 'file'
    }
    var_0 = task_include_0.build_parent_block()
    assert(var_0.__class__.__name__ == 'Block')
    assert(var_0.args == {'block': []})



# Generated at 2022-06-25 06:18:32.518932
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    var_0 = task_include_0.get_vars()

# Generated at 2022-06-25 06:18:37.196197
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    print("Test build_parent_block")
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:18:49.497117
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    sample_args = {
        'args': {},
        'apply': {},
        'collections': [],
        'debugger': None,
        'ignore_errors': False,
        'loop': [],
        'loop_control': {},
        'loop_with': {},
        'name': None,
        'no_log': False,
        'register': None,
        'run_once': False,
        'tags': [],
        'timeout': None,
        'vars': {},
        'when': []
    }

    # Create test object

# Generated at 2022-06-25 06:18:54.865610
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args['_raw_params'] = 'include'
    task_include_0.args['tags'] = 'tag-0'
    task_include_0.args['when'] = 'when-0'
    task_include_0.vars = dict()
    var_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:19:03.719479
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()

    var_0 = task_include_0.build_parent_block()
    assert isinstance(var_0, TaskInclude)
    assert var_0.args == {}
    assert var_0.delegate_to is None
    assert var_0.no_log is False
    assert var_0.notify is None
    assert var_0.poll is None
    assert var_0.run_once is False
    assert var_0.tags == []
    assert var_0.transport is None
    assert var_0.until is None
    assert var_0.use_proxy is False
    assert var_0.vars == {}
    assert var_0.when is None
    assert var_0.with_items is None
    assert var_0.with_first_found

# Generated at 2022-06-25 06:19:13.857866
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_2 = task_include_1.check_options(Sentinel.task,Sentinel.data)
    assert type(task_2) == Task


# Generated at 2022-06-25 06:19:14.693166
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_case_0()


# Generated at 2022-06-25 06:19:16.207146
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0.build_parent_block() is None


# Generated at 2022-06-25 06:19:19.469880
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:19:21.795558
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:19:24.238601
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = dict()
    task_include_0 = TaskInclude()
    result = task_include_0.preprocess_data(ds)
    assert result == ds


# Generated at 2022-06-25 06:19:28.143060
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # create an instance of TaskInclude
    task_include_0 = TaskInclude()
    sample_task_data = {}
    # call the method preprocess_data of class TaskInclude
    var_0 = task_include_0.preprocess_data(sample_task_data)


# Generated at 2022-06-25 06:19:30.803529
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:19:38.953935
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:19:45.619150
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'a': 10}  # dict
    task = TaskInclude()
    # Test if assertion error is raised when 'action' is not in C._ACTION_INCLUDE
    task.action = 'include_role'
    try:
        task.preprocess_data(ds)
    except AssertionError:
        pass

    # Test if assertion error is raised when 'action' is in C._ACTION_INCLUDE
    task.action = 'include'
    try:
        task.preprocess_data(ds)
    except AssertionError:
        pass



# Generated at 2022-06-25 06:20:06.178483
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Arrange
    task_1 = TaskInclude()
    task_1.action = 'include_tasks'
    dict_1 = {'action': 'include_tasks', '_ignore_errors': True, '_raw_params': 'role_2/tasks/tasks.yml'}
    dict_2 = {'action': 'include_tasks', '_ignore_errors': True, '_raw_params': 'role_2/tasks/tasks.yml', '_role_path': ''}
    dict_3 = {'action': 'include_tasks', '_ignore_errors': True, '_raw_params': 'role_2/tasks/tasks.yml', '_role_path': '', '_play': None}

# Generated at 2022-06-25 06:20:15.883766
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    var_0 = {}
    var_0['action'] = 'action_0'
    var_0['author'] = 'author_0'
    var_0['ignore_errors'] = True
    var_0['loop'] = 'loop_0'
    var_0['meta'] = 'meta_0'
    var_0['run_once'] = True
    var_0['when'] = 'when_0'
    var_0['with_items'] = 'with_items_0'
    var_0['with_subelements'] = 'with_subelements_0'
    var_0['with_dict'] = 'with_dict_0'
    var_0['with_sequence'] = 'with_sequence_0'

# Generated at 2022-06-25 06:20:22.238810
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    dict_0 = dict(file=Sentinel, no_log=False, action='include')
    dict_0['action'] = 'include_role'
    task_include_0 = TaskInclude()
    dict_1 = task_include_0.preprocess_data(dict_0)


# Generated at 2022-06-25 06:20:24.185222
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.preprocess_data()


# Generated at 2022-06-25 06:20:32.469422
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_obj = TaskInclude()
    task_obj = Task()
    data_obj = {}

    # Test for case: task is not an instance of ansible.playbook.task.Task
    # This is not a validation case, so the method should return.
    assert task_include_obj.check_options(task=None, data=data_obj) is None

    # Test for case: data is not an instance of dict
    # This is not a validation case, so the method should return.
    assert task_include_obj.check_options(task=task_obj, data=None) is None

    # Test for case: no file is specified for task.action
    # Test for AnsibleParserError

# Generated at 2022-06-25 06:20:35.573545
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_test = TaskInclude()
    task = Block()
    data = dict()
    task = task_include_test.check_options(task, data)


# Generated at 2022-06-25 06:20:47.156459
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0._parent = Sentinel()
    task_include_0.action = "include"
    task_include_0.vars = {"var1": "value1", "var2": "value2", "var3": "value3"}
    task_include_0.tags = ["tag1", "tag2", "tag3"]
    task_include_0.when = "var1 == value1"
    task_include_0.args = {"arg1": "value1"}


# Generated at 2022-06-25 06:20:51.933900
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()



# Generated at 2022-06-25 06:20:59.046392
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = {}
    task_include_0.vars_prompt = {}
    task_include_0.vars_files = []
    task_include_0.args = {}
    task_include_0.action = 'include'
    task_include_0.name = 'test'
    task_include_0.action = 'include'
    task_include_0.action = 'include'
    task_include_0.action = 'include'
    task_include_0.action = 'import_role'
    task_include_0.action = 'import_role'
    task_include_0.action = 'import_tasks'
    task_include_0.action = 'import_tasks'
    task_include_0.action

# Generated at 2022-06-25 06:21:06.499570
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    block_0 = Block(
        action='block',
        name='block'
    )
    role_0 = Role(
        block=block_0,
        name='role'
    )
    task_0 = Task(
        block=block_0,
        action='action',
        name='task'
    )
    task_include_0.args = {
        'apply': {'name': 'task'}
    }
    task_include_0.action = 'include'
    task_include_0.check_options(
        task_include_1,
        task_0
    )

# Generated at 2022-06-25 06:21:36.536921
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:21:39.449542
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()
    assert var_0 == task_include_0


# Generated at 2022-06-25 06:21:48.486031
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    data_dict_0 = {'action': 'include', 'name': 'include_role'}
    task_include_0.preprocess_data(data_dict_0)
    # Ensure that the different keys display the appropriate warning instead of a parser error
    data_dict_1 = {'action': 'include', 'name': 'include_role', 'arguments': {} }
    task_include_0.preprocess_data(data_dict_1)
    var_0 = task_include_0.get_vars()
    # Create a custom action and make sure the ActionBase error is shown
    data_dict_2 = {'action': 'my_include', 'name': 'include_role'}
    task_include_1 = TaskInclude()
    task_include_1.pre

# Generated at 2022-06-25 06:21:49.686395
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()

# Generated at 2022-06-25 06:21:55.635525
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # import pudb;pudb.set_trace()
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()
    task_include_4 = TaskInclude()
    task_include_5 = TaskInclude()
    task_include_6 = TaskInclude()
    task_include_7 = TaskInclude()
    task_include_8 = TaskInclude()
    task_include_9 = TaskInclude()
    task_include_10 = TaskInclude()
    task_include_11 = TaskInclude()
    task_include_12 = TaskInclude()
    task_include_13 = TaskInclude()
    task_include_14 = TaskInclude()
    task_

# Generated at 2022-06-25 06:22:06.468357
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    dictionary = dict()
    dictionary['1'] = 'abc'
    var_0 = TaskInclude.load(dictionary)
    var_1 = var_0.get_vars()
    assert '1' in var_1
    dictionary['1'] = 'def'
    var_2 = var_0.get_vars()
    assert '1' in var_2
    dictionary.update(dict())
    dictionary['1'] = var_1['1']
    dictionary['2'] = 'bcd'
    var_3 = var_0.get_vars()
    assert '2' in var_3
    dictionary['2'] = var_2['2']
    dictionary['3'] = 'cde'
    var_4 = var_0.get_vars()


# Generated at 2022-06-25 06:22:10.486918
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    task_include_0 = TaskInclude()

    # Check with default value of args
    # args_0 is an instance of dict
    task_include_0.args = dict()
    result_0 = task_include_0.check_options(task_include_0, task_include_0)
    assert isinstance(result_0, TaskInclude)


# Generated at 2022-06-25 06:22:17.338543
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0.action = "include"
    var_0 = task_include_0.get_vars()
    var_1 = task_include_0.args
    assert var_0 == var_1 


# Generated at 2022-06-25 06:22:21.363754
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Test the TaskInclude.get_vars
    """
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:22:25.150499
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result_1 = task_include_0.get_vars()

# Generated at 2022-06-25 06:22:57.408116
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    instance = TaskInclude()
    task = None
    data = None
    try:
        instance.check_options(task, data)
    except AnsibleParserError:
        pass
    except Exception as e:
        print('Caught exception: {0}'.format(e))
    else:
        print('TaskInclude.check_options raised no exception')


# Generated at 2022-06-25 06:23:01.165479
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.vars
    var_0 = task_include_0.statically_loaded
    var_0 = task_include_0.loop

    try:
        var_0 = task_include_0.build_parent_block()
    except Exception as e_0:
        print(e_0)


# Generated at 2022-06-25 06:23:07.624734
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    with pytest.raises(AnsibleParserError):
        task_include_0.check_options({'ignore_errors': 'yes'}, {})
    with pytest.raises(AnsibleParserError):
        task_include_0.check_options({'_raw_params': 'x.yml'}, {})
    with pytest.raises(AnsibleParserError):
        task_include_0.check_options({'apply': {}})

# Generated at 2022-06-25 06:23:12.715175
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    # Test the method get_vars of class TaskInclude

    # Get the value of attribute vars of class TaskInclude
    var_0 = task_include_0.vars
    # Set the value of attribute vars of class TaskInclude
    task_include_0.vars = var_0
    # Get the value of attribute vars of class TaskInclude
    var_1 = task_include_0.vars
    # Set the value of attribute vars of class TaskInclude
    task_include_0.vars = var_1
    # Get the value of attribute vars of class TaskInclude
    var_2 = task_include_0.vars
    # Set the value of attribute vars of class TaskInclude
    task_include_0.vars = var_

# Generated at 2022-06-25 06:23:15.590951
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    _data = {'action': 'include', 'file': './sample.yml'}
    task_include_0 = TaskInclude()
    task_include_0.preprocess_data(_data)


# Generated at 2022-06-25 06:23:25.931769
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    data = {'action': 'ansible.builtin.include_role'}
    task = task_include.load(data)
    assert task.action == 'ansible.builtin.include_role'
    assert task.args == {}
    task_include.check_options(task, data)
    assert task.action == 'ansible.builtin.include_role'
    assert task.args == {'_raw_params': None}
    assert task_include.VALID_ARGS == frozenset({'file', '_raw_params'})
    assert task_include.OTHER_ARGS == frozenset({'apply'})

# Generated at 2022-06-25 06:23:27.779248
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:23:30.143605
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test cases for get_vars method
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    print(var_0)

# Generated at 2022-06-25 06:23:32.221646
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    with pytest.raises(AnsibleParserError) as excinfo:
        test_case_0()
    assert 'No file specified for include' in str(excinfo.value)


# Generated at 2022-06-25 06:23:44.253795
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = {}
    # Test with action == include
    data['action'] = 'include'
    data['vars'] = {}
    task.check_options(task, data)
    # Test with action == import_role
    data['action'] = 'import_role'
    data['vars'] = {}
    task.check_options(task, data)
    # Test with action == import_tasks
    data['action'] = 'import_tasks'
    data['vars'] = {}
    task.check_options(task, data)
    # Test with action == include_role
    data['action'] = 'include_role'
    data['vars'] = {}
    task.check_options(task, data)


# Generated at 2022-06-25 06:24:44.672397
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    dict_0 = task_include_0.get_vars()
    assert not dict_0
    task_include_1 = TaskInclude()
    dict_1 = task_include_1.get_vars()
    assert not dict_1
    task_include_2 = TaskInclude()
    dict_2 = task_include_2.get_vars()
    assert not dict_2

# Generated at 2022-06-25 06:24:50.543230
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.vars = dict(a=2)
    task_include_0.args = dict(b=2)
    res_0 = task_include_0.get_vars()
    expected_0 = dict(a=2, b=2)
    assert res_0 == expected_0

if __name__ == "__main__":
    case_0()
    case_task_include()
    case_task_include_1()

    test_case_0()
    test_case_task_include_0()
    test_case_task_include_1()

# Generated at 2022-06-25 06:25:00.458990
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import pytest
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader)

    playbook = Playbook.load(playbook_file_0, variable_manager=variable_manager, loader=loader)
    playbook._tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=Options(),
        passwords={},
    )
    playbook._variable_manager = variable_manager
    variable_manager._set_inventory(inventory)
    variable_manager.set_playbook_basedir(basedir_0)

   

# Generated at 2022-06-25 06:25:09.666016
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # create '_data'
    _data = {"args": {"file": "test"}}

    # create '_variable_manager'
    _variable_manager = None

    # create '_loader'
    _loader = None

    # create '_task'
    _task = TaskInclude(block=None, role=None, task_include=None)
    _task.args = {"file": "test"}

    # preprocess_data()
    ret = _task.preprocess_data(_data)

    print(ret)
    assert ret == _task.args


# Generated at 2022-06-25 06:25:11.493163
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    var = task_include.get_vars()



# Generated at 2022-06-25 06:25:14.445622
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:25:23.064465
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a variable of type TaskInclude
    task_include_0 = TaskInclude()
    # Create a variable of type dict or None
    var_0 = task_include_0.vars
    # Create a variable of type dict or dict
    var_1 = {'var_a': 'foo'}
    # Create a variable of type dict or dict
    var_2 = {'var_b': 'bar'}
    # Create a variable of type dict or dict
    var_3 = {'var_c': 'baz'}
    # Create a variable of type dict or dict
    var_4 = task_include_0.args
    # Create a variable of type dict or dict
    var_5 = {'var_d': 'qux'}
    # Set the value of task_include_0._parent to var_1

# Generated at 2022-06-25 06:25:25.999060
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()
    assert var_0 is not None



# Generated at 2022-06-25 06:25:36.448966
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t1 = TaskInclude()
    # change TaskInclude.VALID_INCLUDE_KEYWORDS
    t1.VALID_INCLUDE_KEYWORDS = {"action1", "action2"}
    # create a dict
    ds = {"action1": True, "action3": False}
    # check if action3 is set to Sentinel
    assert (t1.preprocess_data(ds)["action3"] == Sentinel)
    # check if action1 remains unchanged
    assert (t1.preprocess_data(ds)["action1"] == True)
    # create a dict with no changes
    ds = {"action1": True, "action2": False}
    # check if action1 remains unchanged
    assert (t1.preprocess_data(ds)["action1"] == True)
    # check if action

# Generated at 2022-06-25 06:25:41.591528
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_case_0()
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()
