

# Generated at 2022-06-25 06:16:11.095886
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert len(var_0) == 0
    # check if attribute exists
    assert hasattr(task_include_0, 'get_vars')
    # check return type of function get_vars
    assert isinstance(task_include_0.get_vars(), dict)
    assert 'action' not in task_include_0.get_vars().keys()
    assert 'args' not in task_include_0.get_vars().keys()
    assert 'tags' not in task_include_0.get_vars().keys()
    assert 'when' not in task_include_0.get_vars().keys()



# Generated at 2022-06-25 06:16:14.059051
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds_0 = dict()
    task_include_0.preprocess_data(ds_0)


# Generated at 2022-06-25 06:16:15.995025
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'a': 14, 'b': 'text', 'c': 1}
    task_include_0 = TaskInclude()
    result = task_include_0.preprocess_data(ds)  # noqa


# Generated at 2022-06-25 06:16:21.966793
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data_0 = {'action': 'include_role', 'apply': {'block': 8}, 'file': 'tasks/main.yml', 'name': 2, 'tags': 'tags'}
    task_include_0 = TaskInclude()
    display.deprecated("Deprecation warning")
    task_0 = task_include_0.check_options(task_include_0.load_data(data_0), data_0)

# Generated at 2022-06-25 06:16:23.725464
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert var_0 == { }


# Generated at 2022-06-25 06:16:29.022330
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()



# Generated at 2022-06-25 06:16:35.406775
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # 1. try/except block to catch and print exception raised by method call
    try:
        # 1.1. instance creation for argument 'task' and call to method
        task = TaskInclude()
        task_include_0 = TaskInclude()
        task_include_0.check_options(task=task, data=None)
    except Exception as e:
        print('!!! Exception !!!')
        print(str(e))
        assert False

    # 2. 'data' argument of type AnsibleParserErrorTestCase
    # 2.1. instance creation for argument 'task' and call to method
    # 2.1.1. instance creation for argument 'data'
    data = AnsibleParserErrorTestCase()
    task = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_1.check_

# Generated at 2022-06-25 06:16:46.061564
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    # array of test cases

# Generated at 2022-06-25 06:16:53.994547
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    parameter_1 = TaskInclude()
    parameter_2 = {}
    parameter_3 = {'action': 'include_tasks'}
    parameter_4 = {'action': 'include_tasks'}
    parameter_5 = {'action': 'include_role'}
    parameter_6 = {'action': 'import_playbook'}
    parameter_7 = {'action': 'import_playbook'}
    parameter_8 = {}
    parameter_9 = {'action': 'include_role'}
    parameter_10 = {'action': 'include_tasks'}
    parameter_11 = {'action': 'include_role'}
    parameter_12 = {'action': 'import_playbook'}
    parameter_13 = {'action': 'include_tasks', 'tags': 'stub'}
   

# Generated at 2022-06-25 06:16:54.685478
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    pass


# Generated at 2022-06-25 06:17:05.428321
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()

    var_0 = task_include_0.get_vars()
    var_1 = task_include_1.get_vars()
    var_2 = task_include_2.get_vars()
    var_3 = task_include_3.get_vars()

    assert ((var_0 == var_1) == (var_2 == var_3)) == True, 'TaskInclude.get_vars() has non-deterministic behavior'


# Unit test code for TaskInclude class

# Generated at 2022-06-25 06:17:15.317093
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.display import Display
    display = Display()
    ds_0 = {'tags': ['ford'], 'when': True, 'action': 'include_role', 'apply': {'name': 'scooby'}}
    task_include_0 = TaskInclude.load(ds_0)
    assert task_include_0.tags == ['ford']
    assert task_include_0.when == True
    assert task_include_0.action == 'include_role'
    assert task_include_0.args == {'apply': {'name': 'scooby'}}


# Generated at 2022-06-25 06:17:18.121430
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    print('')
    print('UNIT TESTING FOR TASKINCLUDE.GET_VARS')
    test_case_0()
    print('get_vars SUCCESSFUL')


# Generated at 2022-06-25 06:17:27.326481
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    data_0 = {'file': 'main.yml'}
    try:
        task_include_0.check_options(task_0, data_0)
    except Exception as e:
        print(e)
    task_1 = Task()
    data_1 = {'action': 'include_role'}
    try:
        task_include_0.check_options(task_1, data_1)
    except Exception as e:
        print(e)
    task_2 = Task()
    data_2 = {'action': 'include', 'file': 'main.yml'}
    try:
        task_include_0.check_options(task_2, data_2)
    except Exception as e:
        print

# Generated at 2022-06-25 06:17:33.557339
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args = dict()
    var_0 = task_include_0.get_vars()
    assert type(var_0) == dict
    assert len(var_0) >= 0


# Generated at 2022-06-25 06:17:42.809430
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_1 = Task.load({'action': 'include', 'file': 'file_1'})
    task_2 = Task.load({'action': 'include', 'file': 'file_1', 'apply': 'apply_1'})
    task_3 = Task.load({'action': 'import_playbook', 'file': 'file_1'})
    task_4 = Task.load({'action': 'import_playbook', 'file': 'file_1', 'apply': 'apply_1'})

    task_include_1.check_options(task_1, 'data_1')
    task_include_1.check_options(task_2, 'data_1')
    task_include_1.check_options(task_3, 'data_1')
    task

# Generated at 2022-06-25 06:17:51.346588
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    print('Testing method preprocess_data of class TaskInclude')
    print('Check expected behavior when action is \'include\'')
    task_include_0 = TaskInclude()
    from ansible.playbook.task_include import TaskInclude
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.statically_loaded = True
    ds = {'action': 'include', 'statically_loaded': True}
    ds = task_include_0.preprocess_data(ds)

# Generated at 2022-06-25 06:17:57.226569
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Test that preprocess_data returns the expected result.
    """

    # Case 1.
    data_1 = dict(a="1", b="2")
    task_include_1 = TaskInclude()
    result_1 = task_include_1.preprocess_data(data_1)
    if result_1 != data_1:
        raise AssertionError("Expected %r, got %r" % (data_1, result_1))

    # Case 2.
    data_2 = dict(a="1")
    task_include_2 = TaskInclude(block=None, role=None, task_include=None)
    task_include_2.action = "include"
    result_2 = task_include_2.preprocess_data(data_2)

# Generated at 2022-06-25 06:18:00.193763
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    d_0 = {}
    task_include_0 = TaskInclude()
    result_0 = task_include_0.preprocess_data(d_0)
    assert result_0 is d_0


# Generated at 2022-06-25 06:18:10.629311
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Tests for method check_options of class TaskInclude
    # Loads, validates and returns the data,
    # or throws errors if things are not correct.
    ds = dict(
        action='include',
        file='some_file.yml',
        tags=['tag1', 'tag2'],
        when='some_condition'
    )
    task_include_1 = TaskInclude()
    task_1 = task_include_1.check_options(task_include_1.load_data(ds), ds)

    # validate the include task which is the 'default' action
    task_1.args['_raw_params'] = 'some_file.yml'
    task_1.args.pop('file')


# Generated at 2022-06-25 06:18:15.097730
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()

# Generated at 2022-06-25 06:18:17.860802
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    parent_block_0 = task_include_0.build_parent_block()
    assert parent_block_0._parent is None


# Generated at 2022-06-25 06:18:21.069675
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    task_1 = task_include_0.check_options(
        task=task_0,
        data=None
    )


# Generated at 2022-06-25 06:18:23.919349
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    assert task_include_0.preprocess_data({'action': 'include_role', 'name': 'test'}) == {'action': 'include_role', 'name': 'test'}


# Generated at 2022-06-25 06:18:32.622907
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    var_0 = task_include_0.get_vars()
    assert task_include_0.action not in C._ACTION_INCLUDE

    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1._parent = task_include_0  # type: Block
    task_include_1.vars = dict()
    task_include_1.args = dict()
    var_1 = task_include_1.get_vars()

    assert var_1['tags'] == var_0['tags']


# Generated at 2022-06-25 06:18:38.981201
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    my_arg_names = frozenset()
    bad_opts = set()
    data = Sentinel()
    ti = TaskInclude()

    # test a normal case
    task = ti.check_options(
        ti.load_data(data, variable_manager=Sentinel(), loader=Sentinel()),
        data
    )
    assert(task is not None)


# Generated at 2022-06-25 06:18:49.985698
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.args = {'apply' : {}, 'file' : 'file_0'}
    task_include_0.action = 'include'
    var_0 = task_include_0.check_options(task_include_0, None)
    assert var_0.action == 'include'
    assert var_0.args == {'file' : 'file_0', '_raw_params' : 'file_0'}
    task_include_1 = TaskInclude()
    task_include_1.args = {'file' : 'file_1'}
    task_include_1.action = 'import_role'
    var_1 = task_include_1.check_options(task_include_1, None)
    assert var_1.action

# Generated at 2022-06-25 06:18:52.607927
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    block_0 = Block()
    role_0 = Role()

    task_include_0.check_options( task = task_0, data = block_0 )  # expected exception AnsibleParserError



# Generated at 2022-06-25 06:18:55.157039
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    Block_0 = task_include_0.build_parent_block()



# Generated at 2022-06-25 06:18:57.210879
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Define a test case
    task_include = TaskInclude()
    result = task_include.get_vars()
    assert result == {}



# Generated at 2022-06-25 06:19:05.922422
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create the instance
    task_include_0 = TaskInclude()

    # Invoke method
    var_0 = task_include_0.get_vars()

    assert var_0 == {}


# Generated at 2022-06-25 06:19:09.894339
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.file = Sentinel
    task_include_0.syntax = 'Always'
    task_include_0.args = {'apply': Sentinel, '_raw_params': Sentinel}
    p_block_0 = task_include_0.build_parent_block()



# Generated at 2022-06-25 06:19:20.669942
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test params
    task = TaskInclude()
    data = {
        'action': 'include_role',
        '_raw_params': 'test_0',
        'foo': 'test_1',
    }
    # Testing implementation
    result = task.check_options(task, data)
    # Test expectations
    expected = {
        'action': 'test_0',
        '_raw_params': 'test_1',
    }
    assert result == expected, 'Test failed because expected %s and got %s' % (expected, result)

    # Test params
    task = TaskInclude()
    data = {
        'action': 'import_role',
        '_raw_params': 'test_0',
        'foo': 'test_1',
    }
    # Testing implementation
    result = task.check

# Generated at 2022-06-25 06:19:25.952249
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_0 = Task()
    data = {
        "tags": [
            "all"
        ],
        "ignore_errors": True,
        "roles": [
            {
                "with_items": [
                    "r0"
                ],
                "role": "r0"
            }
        ],
        "action": "include_role"
    }
    task = task_include_1.check_options(task_0, data)


# Generated at 2022-06-25 06:19:28.054104
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    block_0 = task_include_1.build_parent_block()


# Generated at 2022-06-25 06:19:37.421202
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()

    # TODO: Remove commented code
    # with pytest.raises(AnsibleParserError) as ans_err:
    #     task_include_0.preprocess_data(None)

    # with pytest.raises(AnsibleParserError) as ans_err:
    #     task_include_0.preprocess_data([])

    # with pytest.raises(AnsibleParserError) as ans_err:
    #     task_include_0.preprocess_data({'action': 'include_role'})

    # task_include_1 = TaskInclude()
    # with pytest.raises(AnsibleParserError) as ans_err:
    #     task_include_1.preprocess_data({'include': 'test'})

#

# Generated at 2022-06-25 06:19:41.043200
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    var = task_include.get_vars()
    assert isinstance(var, dict)


# Generated at 2022-06-25 06:19:43.537727
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()

# Generated at 2022-06-25 06:19:54.300494
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    data_0 = dict(
        file='/etc/foo.yml',
        _raw_params='/etc/foo.yml',
        ignore_errors='yes'
    )
    block_0 = Block()
    task_0 = task_include_0.load(data_0, block_0)

    assert 'file' in task_0.args
    assert task_0.args['file'] == '/etc/foo.yml'
    assert '_raw_params' in task_0.args
    assert task_0.args['_raw_params'] == '/etc/foo.yml'
    assert 'ignore_errors' in task_0.args
    assert task_0.args['ignore_errors'] == 'yes'


# Generated at 2022-06-25 06:20:02.208493
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method is used to create the parent block for the included tasks
    when ``apply`` is specified
    '''
    task_include_0 = TaskInclude()
    # Pop the apply argument off the task args
    apply_attrs = task_include_0.args.pop('apply', {})
    # If apply_attrs is not empty, create a parent_block using the apply_attrs
    if apply_attrs:
        apply_attrs['block'] = []
        parent_block = Block.load(apply_attrs,play=task_include_0._parent._play,task_include=task_include_0,role=task_include_0._role,variable_manager=task_include_0._variable_manager,loader=task_include_0._loader)
    # else, parent_block is the original task

# Generated at 2022-06-25 06:20:12.545529
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_2 = task_include_1.check_options('task_2', 'data_3')


# Generated at 2022-06-25 06:20:19.243233
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    try:
        import ansible.errors
        import ansible.playbook
        import ansible.utils
        import ansible.utils.display
        import ansible.utils.sentinel
        test_case_0()
    except (AnsibleParserError, AttributeError, ImportError):
        pass
    except Exception as e:
        assert False


# Generated at 2022-06-25 06:20:21.981403
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    assert isinstance(task_include_1.get_vars(), dict)


# Generated at 2022-06-25 06:20:31.173482
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    TaskInclude.check_options(task, data)
    """
    task_include_0 = TaskInclude()
    task_include_0.action = "include"
    task_include_0.args['_raw_params'] = "include.yml"
    data_0 = "include.yml"
    task_include_0.check_options(
        task_include_0,
        data_0
    )

    # TaskInclude.check_options(task, data)
    task_include_1 = TaskInclude()
    task_include_1.action = "include_role"
    task_include_1.args['_raw_params'] = "include.yml"
    data_1 = "include.yml"

# Generated at 2022-06-25 06:20:34.087053
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()



# Generated at 2022-06-25 06:20:45.948472
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # test with invalid action
    invalid_action = 'my_action'
    data = {
        'action': invalid_action,
        'file': 'my_file',
    }
    # test_me is used to trick the Object.__init__ call
    test_me = Block()
    test_me.action = invalid_action
    task_include = TaskInclude(test_me)
    # test with invalid action
    if C.INVALID_TASK_ATTRIBUTE_FAILED:
        try:
            task_include.preprocess_data(data)
        except AnsibleParserError as e:
            assert 'is not a valid attribute for' in e.message
        else:
            raise Exception('AnsibleParserError was not raised')

# Generated at 2022-06-25 06:20:52.173013
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Instantiate a real TaskInclude class for the test
    task_include_0 = TaskInclude()

    # Call method on a TaskInclude object
    result = task_include_0.build_parent_block()

    assert isinstance(result, TaskInclude)


# Generated at 2022-06-25 06:20:54.272190
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    task_include_0.check_options( task=task_0, data=dict())


# Generated at 2022-06-25 06:20:59.470082
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    task_include_0.args = dict(
        _raw_params='',
        apply=dict(
            name='',
            tags='',
            when='',
            vars='',
        )
    )
    task_include_0.action = 'include_role'
    task_include_0.statically_loaded = False
    task_include_0.vars = dict()
    task_include_0.role = None
    task_include_0.block = None
    task_include_0.task_include = None
    task_include_0.when = ''
    task_include_0.block_vars = dict()
    task_include_0.task_vars = dict()
    task_include_0.failed_when = False
    task_

# Generated at 2022-06-25 06:21:06.719317
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # 1. Testing when no parent block is present and no apply data is specified
    task_include_0 = TaskInclude()
    parent_block_0 = task_include_0.build_parent_block()
    assert parent_block_0 == task_include_0

    # 2. Testing when a parent block is present but no apply data is specified
    task_0 = Task()
    task_include_1 = TaskInclude(block=task_0)
    parent_block_1 = task_include_1.build_parent_block()
    assert parent_block_1 == task_0

    # 3. Testing when a parent block is present and apply data is specified
    task_include_2 = TaskInclude(block=task_0)
    task_include_2.args = {'apply': {'block': []}}
    parent_block

# Generated at 2022-06-25 06:21:27.186251
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 06:21:31.787945
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    data_0 = dict()
    task_0 = Task()
    assert task_include_0.check_options(task_0, data_0) == task_0


# Generated at 2022-06-25 06:21:37.745117
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds_0 = dict()
    ds_0['action'] = 'include_role'
    task_include_0 = TaskInclude()
    result_0 = task_include_0.preprocess_data(ds_0)
    assert 'action' in result_0


# Generated at 2022-06-25 06:21:40.567264
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert var_0 == {}


# Generated at 2022-06-25 06:21:45.510123
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    args = dict()
    apply_attrs = dict(
        block = [],
        name = 'test name',
        rescue = [],
        always = [],
        tags = ['a', 'b', 'c'],
        until = [],
        delegate_to = 'test delegate_to',
        environment = dict(
            key_0 = 'value_0',
            key_1 = 'value_1',
            key_2 = 'value_2',
        ),
        run_once = True,
        register = 'test register',
        ignore_errors = True,
        delegate_facts = True,
    )
    args['apply'] = apply_attrs

    p_block = TaskInclude(args=args)

    # Call method with arguments.
    result = p_block.build_parent_block()
    #

# Generated at 2022-06-25 06:21:48.243243
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Support calling instance or classmethod
    dc = None  # type: TaskInclude
    try:
        dc = TaskInclude()
        dc.load(None)
    except:
        dc = None

    if dc is None:
        dc = TaskInclude.load(None)
    return

# Generated at 2022-06-25 06:21:49.057966
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_case_0()

# Generated at 2022-06-25 06:21:51.063172
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.build_parent_block()
    #var_0 = TaskInclude_build_parent_block


# Generated at 2022-06-25 06:21:56.486917
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert var_0 == None, task_include_0.get_vars()


# Generated at 2022-06-25 06:22:06.718081
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager

    try:
        task_include_0 = TaskInclude()
    except TypeError:
        assert False, "Unable to instantiate TaskInclude"

    var_manager_0 = VariableManager()
    try:
        task_include_0.set_loader(None)
    except TypeError:
        assert False, "Unable to call TaskInclude set_loader method"
    task_include_0.set_variable_manager(var_manager_0)
    try:
        task_include_0.preprocess()
    except TypeError:
        assert False, "Unable to call TaskInclude preprocess method"


# Generated at 2022-06-25 06:22:39.103276
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data_0 = {}
    task_include_0 = TaskInclude()

    # This is the expected result of the preprocess_data of TaskInclude.
    pd_result_0 = {}

    # Verify the result
    assert pd_result_0 == task_include_0.preprocess_data(data_0)



# Generated at 2022-06-25 06:22:39.915314
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_case_0()



# Generated at 2022-06-25 06:22:47.569335
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    data_0 = {'debugger': '', 'when': '', 'collections': '', 'loop': '', 'timeout': '', 'no_log': '', 'loop_with': '', 'action': 'include', 'run_once': '', 'vars': '', 'apply': '', '_raw_params': '', 'loop_control': '', 'register': ''}

    task_1 = task_include_0.check_options(task_0, data_0)

# Generated at 2022-06-25 06:22:48.893362
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()


# End TaskInclude class

# Generated at 2022-06-25 06:22:59.156385
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Default constructor
    task_include_0 = TaskInclude()
    var_0 = task_include_0.check_options(task_include_0, data = None)
    assert var_0.action == 'include'

    # Default constructor
    task_include_1 = TaskInclude()
    task_include_1.args['_raw_params'] = None
    var_1 = task_include_1.check_options(task_include_1, data = None)
    assert isinstance(var_1, AnsibleParserError)

    # Default constructor
    task_include_2 = TaskInclude()
    task_include_2.args['_raw_params'] = None
    task_include_2.action = 'import_playbook'

# Generated at 2022-06-25 06:23:09.253274
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    data_0 = {}
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = VariableManager()
    loader = DataLoader()
    task_include_2 = TaskInclude.load(data_0, block, role, task_include, variable_manager, loader)
    assert task_include_2 is not None
    assert task_include_2 == task_include_1


# Generated at 2022-06-25 06:23:13.141380
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create an instance of the TaskInclude class
    task_include_0 = TaskInclude()
    # Call the get_vars method of the instance task_include_0
    try:
        var_0 = task_include_0.get_vars()
    except Exception as exception:
        raise exception


# Generated at 2022-06-25 06:23:15.052507
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    try:
        test_case_0()
    except Exception as e:
        print('Failed test case 0')
        raise e

# Generated at 2022-06-25 06:23:25.352637
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test for valid option for task 'include', and for those which should be ignored for other tasks
    task_include_0 = TaskInclude.load({'action': 'include', 'loop_control': {}, 'vars': {}, 'when': '', 'name': 'test_include_0'})
    test_task_include_0 = {
        'action': 'include',
        'loop_control': {},
        'vars': {},
        'when': '',
        'name': 'test_include_0'
    }

    task_include_1 = TaskInclude.load({'action': 'include', 'loop_control': {}, 'vars': {}, 'when': '', 'name': 'test_include_1', '_raw_params': 'test_include_raw_params'})
    test_task_include

# Generated at 2022-06-25 06:23:27.061474
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    p_block_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:24:21.667556
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert 'block' in task_include_0.args


# Generated at 2022-06-25 06:24:26.705183
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert var_0 == {}, f"Expected: {'{}'}, Actual: {var_0}"


# Generated at 2022-06-25 06:24:29.151918
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    # Testing if the method returns the correct type
    assert isinstance(task_include_1.build_parent_block(), Block)

# Generated at 2022-06-25 06:24:34.112990
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Set up test variables
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args['apply'] = {}
    task_include_0.args['_raw_params'] = 'file'
    data = dict()
    # Test execution
    task_include_0.check_options(task_include_0, data)
    assert {} == task_include_0.args



# Generated at 2022-06-25 06:24:40.575064
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = "include"
    task_include_0.depth = 2
    task_include_0.statically_loaded = False
    task_include_0.args = dict(a=2, b=3, c=5)
    task_include_0.action = "include"
    task_include_0.action = "a"
    task_include_0.action = "include"
    task_include_0.args = dict(a="c", b="d")
    task_include_0.action = "a"
    var_0 = task_include_0.get_vars()
    assert 'a' in var_0
    assert 'b' in var_0
    assert 'c' in var_0

# Generated at 2022-06-25 06:24:50.122751
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:24:58.570971
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    var = TaskInclude()
    attr_1 = {'file': 'a', 'apply': {'b': 'c'}}
    attr_2 = {'file': 'a', '_raw_params': 'b', 'apply': {'b': 'c'}}
    var.check_options(Task(), attr_1)
    var.check_options(Task(), attr_2)
    attr_1 = {'file': 'a', 'b': 'b'}
    try:
        var.check_options(Task(), attr_1)
    except SystemExit:
        pass


# Generated at 2022-06-25 06:25:02.780364
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    var_0 = task_include_0.get_vars()
    assert var_0 == {}


# Generated at 2022-06-25 06:25:05.693909
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    assert task_include.build_parent_block() == task_include


# Generated at 2022-06-25 06:25:12.164846
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    # Testing if an exception is raised
    try:
        task_include_0.build_parent_block()
        assert False
    except NotImplementedError as e:
        assert True
    # Testing if an exception is raised
    try:
        task_include_1 = TaskInclude(block=None, role=None, task_include=None)
        task_include_1.build_parent_block()
        assert False
    except NotImplementedError as e:
        assert True
