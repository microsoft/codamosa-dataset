

# Generated at 2022-06-25 06:16:02.857297
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.warning("todo: TaskInclude.check_options() not tested")


# Generated at 2022-06-25 06:16:05.471979
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    str_0 = '8Mi*w3jW:'
    # int_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:16:07.317255
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    str_0 = task_include_0.get_vars()


# Generated at 2022-06-25 06:16:09.918905
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    # Test for method build_parent_block of class TaskInclude
    block_0 = task_include_0.build_parent_block()
    assert isinstance(block_0, TaskInclude)



# Generated at 2022-06-25 06:16:12.026211
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    test_case_0()


# Generated at 2022-06-25 06:16:16.673688
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data_0 = dict(
        arg_0=dict(),
        arg_1=None,
        arg_2=None,
        arg_3=None,
    )
    task_include_0 = TaskInclude.load(data_0)


# Generated at 2022-06-25 06:16:23.116589
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    str_0 = 't/>^c[,u&'
    task_include_2_0 = TaskInclude.load(str_0, variable_manager=variable_manager_0, loader=loader_0)
    task_include_2_0.check_options(task_include_1, str_0)
    task_include_2_0.check_options(task_include_2, str_0)
    assert(task_include_1 is not None)


# Generated at 2022-06-25 06:16:31.855051
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    str_0 = '8Mi*w3jW:'
    task_include_0.vars = dict()
    task_include_0.file = str_0
    str_0 = '8Mi*w3jW:'
    task_include_0.args = dict()
    task_include_0.args['file'] = str_0
    str_0 = '8Mi*w3jW:'
    task_include_0.action = str_0

    # Test get_vars when action not in action_include
    dict_0 = {
        'file': '8Mi*w3jW:',
        'args': {
            'file': '8Mi*w3jW:'
            }
        }
    assert task_include_0.get_vars

# Generated at 2022-06-25 06:16:33.287792
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    block_0 = task_include_0.build_parent_block()


# Generated at 2022-06-25 06:16:35.343937
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    preprocess_data_0 = TaskInclude(block='sew#sI', role=256)
    TaskInclude.preprocess_data(preprocess_data_0)


# Generated at 2022-06-25 06:16:44.746062
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-25 06:16:47.195360
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # assert task.check_options() == None
    assert test_case_0() == None


# Generated at 2022-06-25 06:16:58.817805
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude(Block())
    # create a fake parent for the task
    ti._parent = Block()
    ti._parent._play = Block()
    ti._parent._play._variable_manager = None
    ti._parent._play._loader = None
    ti._parent._task_include = None
    ti._parent._role = None
    ti._parent._loop = None
    ti._parent.include_role = False
    ti._parent.block = None
    ti.ARGS_ATTRIBUTES = [
        FieldAttribute('apply', dict)
        ]
    # no apply specified
    res = ti.build_parent_block()
    assert res == ti
    ti.args['apply'] = {}
    res = ti.build_parent_block()
    assert res != ti


# Generated at 2022-06-25 06:17:10.480218
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Define some mock arguments and values
    dict_args = dict(action='a', name='n', file='f', action_plugin='ap', vars={})
    variable_manager = 'vm'
    loader = 'l'
    test_case_0()

    # Try to run the TaskInclude.load() method with some objects:
    # Create a TaskInclude object
    ti = TaskInclude()
    # Call TaskInclude.load() with some args:
    result = ti.load(dict_args, variable_manager=variable_manager, loader=loader)

    # Check that the result is what we wanted
    assert result.name == 'n'
    assert result.action == 'include'
    assert result.args['file'] == 'f'
    assert result.action_plugin == 'ap'
    assert result.vars

# Generated at 2022-06-25 06:17:13.510379
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Load test data
    test_cases = []

    # Execute tests
    for test_case in test_cases:
        test_case()


# Generated at 2022-06-25 06:17:19.969602
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    str_0 = task_include_0.get_name()
    block_0 = task_include_0.build_parent_block()
    str_1 = block_0.get_name()
    bool_0 = str_0 == str_1
    str_2 = 'todo: TaskInclude.build_parent_block() not tested'


# Generated at 2022-06-25 06:17:29.671330
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create an instance of class PlaybookIncludeLoader
    task_include = TaskInclude()

    # Create an instance of class dict
    ds = dict()

    # Call method preprocess_data of class TaskInclude
    returned_value = task_include.preprocess_data(ds)

    # Check if returned_value is dict
    try:
        assert isinstance(returned_value, dict)
    except AssertionError:
        print('Test case 0 failed: returned_value is not dict.')

    # Check if returned_value is equal to ds
    try:
        assert returned_value == ds
    except AssertionError:
        print('Test case 1 failed: returned_value is not equal to ds.')

    # Create an instance of class dict

# Generated at 2022-06-25 06:17:35.196951
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Set values for testing method  preprocess_data of class TaskInclude
    ti = TaskInclude()
    ds = {}

    # Testing return value of method  preprocess_data of class TaskInclude
    preprocess_data_ret_value = ti.preprocess_data(ds)
    assert preprocess_data_ret_value == {}


# Generated at 2022-06-25 06:17:44.286437
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    str_0 = '''- include: test.yml
  tags: foo
  when: todo
  ignore_errors: True
  args:
    one: two
    three: four
'''
    task_0 = dict()
    task_0['args'] = dict()
    task_0['args']['_raw_params'] = 'test.yml'
    task_0['args']['args'] = dict()
    task_0['args']['args']['one'] = 'two'
    task_0['args']['args']['three'] = 'four'
    task_0['args']['ignore_errors'] = True
    task_0['args']['tags'] = 'foo'
    task_0['args']['when'] = 'todo'
    task_0

# Generated at 2022-06-25 06:17:49.195453
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Initialize a sample task
    task_test = TaskInclude()

    # Create a data structure for the test
    data_test = {'action': 'include'}

    # Invoke the test
    test_0 = task_test.check_options({}, data_test)

    # Check the result
    assert test_0 == {'action': 'include',
                      '_raw_params': None}, 'Test failed: test_0'


# Generated at 2022-06-25 06:17:57.722254
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block_0 = Block()
    block_0.parents = []
    block_0.vars = dict()
    block_0.loop = dict()
    block_0.when = dict()
    role_0 = None
    task_include_0 = None
    task_include_1 = TaskInclude(block=block_0, role=role_0, task_include=task_include_0)
    task_include_1.action = 'include'
    task_include_1.vars = dict()
    task_include_1.args = dict()
    task_include_1.tags = dict()
    task_include_1.when = dict()
    task_include_1.always = dict()
    task_include_1.register = dict()
    task_include_1.delegate_to = dict()


# Generated at 2022-06-25 06:18:04.884694
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Calling TaskInclude.check_options(self, task, data)
    '''
    ti = TaskInclude()
    task = {
        'action': 'include',
        'args': {
            'apply': {
            },
        },
        'block': None,
        'register': None,
    }
    data = {}
    ti.check_options(task, data)
    assert task == {'action': 'include', 'args': {'apply': {}, '_raw_params': None}, 'block': None, 'register': None}

# Generated at 2022-06-25 06:18:14.652056
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from .. import task_include
    from .. import block
    from .. import role

    # Test #0: test with an arg that is not a valid attribute for a TaskInclude
    #     object
    ti_1 = task_include.TaskInclude()
    ds_1 = {"empty_var": "blah"}
    assert ds_1 == ti_1.preprocess_data(ds_1)

    # Test #1: test with an arg that is a valid attribute for a TaskInclude
    #     object
    ti_2 = task_include.TaskInclude()
    ds_2 = {'action': 'include', 'nothing': 'blah'}
    assert ds_2 == ti_2.preprocess_data(ds_2)

    # Test #2: test with an arg that is a valid attribute for a Task

# Generated at 2022-06-25 06:18:25.112869
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    # We don't have a static include, then let's try with a include_tasks
    ds = {
        'action': 'include_tasks',
        'name': 'test',
        'file': 'test'
    }
    ds_res = ti.preprocess_data(ds)
    ds_expected = {
        'action': 'include_tasks',
    }
    assert ds_res == ds_expected
    # Now let's test the static include
    ds = {
        'action': 'include',
        'name': 'test',
        'file': 'test'
    }
    ti.statically_loaded = True
    ds_res = ti.preprocess_data(ds)
    ds_expected = ds
    assert ds_res

# Generated at 2022-06-25 06:18:29.663147
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    ti.load(
        {
            'include': 'file.yml',
            'apply': "todo: TaskInclude.check_options() not tested",
        },
    )


# Generated at 2022-06-25 06:18:35.399315
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Check TaskInclude.get_vars()
    '''
    # Test: action is no included
    data_0 = dict(action='include_role', name='foo_name')
    t_inc_0 = TaskInclude.load(data_0, loader=DictDataLoader())
    assert t_inc_0.get_vars() == dict()

    # Test: action is 'include'
    data_1 = dict(action='include', name='foo_name')
    t_inc_1 = TaskInclude.load(data_1, loader=DictDataLoader())
    assert t_inc_1.get_vars() == dict()

# Generated at 2022-06-25 06:18:41.162950
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Set task.statically_loaded to False and test that
    # AnsibleParserError is raised when action is 'include_role'
    task = TaskInclude
    task.statically_loaded = False
    ds = {'action': 'include_role'}

    try:
        task.preprocess_data(ds)
    except Exception:
        pass
    else:
        assert False

    # Set task.statically_loaded to True and test that
    # no exception is raised when action is 'include_role'
    task.statically_loaded = True
    try:
        task.preprocess_data(ds)
    except Exception:
        assert False
    else:
        pass


# Generated at 2022-06-25 06:18:50.770722
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    # Testing with good arguments
    ti = TaskInclude()
    array_0 = {'action': 'include_role', 'name': 'toto'}
    test_value = 0
    for i in range(10):
        if ti.preprocess_data(array_0) == {'action': 'include_role', 'name': 'toto'}:
            test_value = 1
    if test_value != 1:
        raise AssertionError('TaskInclude.preprocess_data() #0 failed')

    # Testing with bad arguments
    array_1 = {'action': 'include_role', 'name': 'toto', 'foo': 'bar'}
    array_2 = {'action': 'include_role'}

# Generated at 2022-06-25 06:18:55.646338
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # file=None, block=None, task_include=None, variable_manager=None, loader=None
    ti = TaskInclude(file = None, block = None, task_include = None, variable_manager = None, loader = None)
    task = ti.check_options(ti.load_data(data, variable_manager = variable_manager, loader = loader), data)


# Generated at 2022-06-25 06:19:07.355622
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object to test
    ti = TaskInclude()

    # Create some test variables
    ti_vars = dict()
    role_vars = dict()
    play_vars = dict()
    parent_vars = dict()

    parent_task = Task()
    parent_task.vars = parent_vars

    ti_args = dict()
    ti_tags = dict()
    ti_when = dict()

    ti_action = 'include'
    ti_block = None
    ti_role = None
    ti_task_include = None

    ti_statically_loaded = False

    # Test without parents
    ti.vars = ti_vars
    ti.args = ti_args
    ti.tags = ti_tags
    ti.when = ti_when
    ti.action = ti

# Generated at 2022-06-25 06:19:17.342961
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Tests TaskInclude.get_vars() in task_include.py
    """
    tinc = TaskInclude()
    tinc.action = 'include'
    tinc.vars = dict(var1=1, var2=2)
    tinc.args = dict(arg1=1, arg2=2)
    task_vars = tinc.get_vars()
    if task_vars != dict(var1=1, var2=2, arg1=1, arg2=2):
        raise AssertionError('Expected value {}. Got value {}'.format(dict(var1=1, var2=2, arg1=1, arg2=2), task_vars))

# Generated at 2022-06-25 06:19:25.393324
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for module ansible.playbook.task_include.TaskInclude.build_parent_block
    Function: build_parent_block of class TaskInclude
    '''
    data_0 = {'_parent': None, 'vars': {'test_var_2': 3}, 'when': 'test_when', 'action': 'include'}
    TaskInclude_o = TaskInclude(data=data_0)
    assert TaskInclude_o.build_parent_block() == TaskInclude_o


# Generated at 2022-06-25 06:19:35.185566
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()

    # action==include (returns)
    task.action = 'include'
    task.vars = {'a': 'b'}
    task.args = {'c': 'd', 'tags': 'x', 'when': 'y'}
    task._parent = type('FakeParent', (), {'get_vars': lambda self: {'e': 'f'}})()
    result = task.get_vars()
    assert result == {'a': 'b', 'c': 'd', 'e': 'f'}, result

    # action==import_playbook (returns)
    task.action = 'import_playbook'
    result = task.get_vars()
    assert result == {'a': 'b', 'c': 'd', 'e': 'f'}, result



# Generated at 2022-06-25 06:19:40.984506
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    a = "{ apply: { ignore_errors: yes, tags: [ { name: test } ] }, name: - include: todo.yml }"
    data = AnsibleLoader(a).get_single_data()
    ti = TaskInclude.load(data)

    ti.preprocess_data(data)

    # Test that if we add a key not in VALID_INCLUDE_KEYWORDS, it doesn't blow up
    data['bleh'] = True
    ti.preprocess_data(data)

# Generated at 2022-06-25 06:19:43.593744
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    str_0 = 'todo: TaskInclude.load() not tested'



# Generated at 2022-06-25 06:19:54.352404
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-25 06:19:55.746661
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    obj = TaskInclude()
    result = obj.build_parent_block()




# Generated at 2022-06-25 06:20:03.034920
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude.load({"action": "include_tasks"}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task.get_vars() == {}

    task = TaskInclude.load({"action": "include_role"}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task.get_vars() == {}

    task = TaskInclude.load({"action": "import_tasks"}, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert task.get_vars() == {}


# Generated at 2022-06-25 06:20:05.802821
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    tf = TaskInclude()

    str_0 = 'todo: TaskInclude.get_vars() not tested'



# Generated at 2022-06-25 06:20:07.746377
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    test_case_0()

# Unit tests for method get_vars of class TaskInclude

# Generated at 2022-06-25 06:20:22.627454
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Define a dictionary of source data:
    data_source = {
        'action' : 'include',
        'name' : 'test',
        'file' : 'test.yml'
    }

    # Create a new TaskInclude object and load into it the data in data_source:
    task = TaskInclude.load(data=data_source, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # Call the preprocess_data method of the created TaskInclude object:
    res = task.preprocess_data(data_source)

    # Create a new dictionary with the expected outcome of preprocess_data:

# Generated at 2022-06-25 06:20:31.524381
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    str_0 = '''- include: foo
- include: foo
                with_items:
                  - a
                  - b
- include: foo
                with_items:
                  - c
                  - d
                when: foo
- include: foo
              with_items:
                - c
                - d
                when: foo
- include: foo
                with_items:
                  - c
                  - d
- include: foo
              with_items:
                - c
                - d
- include: foo
              with_items:
                - c
                - d
- include: foo
              with_items:
                - c
                - d
'''
    #todo: Fix this test (it fails, see the comments below)
    # from ansible.parsing.yaml.dumper import AnsibleDumper
    #

# Generated at 2022-06-25 06:20:43.320494
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    str_0 = TaskInclude.build_parent_block(apply_attrs={"block": "block"}, task_include={"_parent": {"_play": "play"}, "_role": {"role_name": "role_name"}, "_variable_manager": "variable_manager", "_loader": "loader", "args": {"apply": "apply"}}, data={"_play": "play", "task_include": {"_parent": {"_play": "play"}, "_role": {"role_name": "role_name"}, "_variable_manager": "variable_manager", "_loader": "loader", "args": {"apply": "apply"}},})

# Generated at 2022-06-25 06:20:51.132698
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    print('testing TaskInclude.check_options()')
    # We will not test the 'No file specified' case as it does not involve
    # the main functionality of check_options (validation of options)

    raw_data_0 = {'apply': 99}  # 99 is not a dict
    raw_data_1 = {'apply': {'test': 99}, 'action': 'import_tasks'}
    raw_data_2 = {'apply': {'test': 99}, 'action': 'include'}

    try:
        TaskInclude.load(raw_data_0)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('TaskInclude.check_options() failed to raise AnsibleParserError')

    task_1 = TaskInclude.load(raw_data_1)
   

# Generated at 2022-06-25 06:20:51.658250
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    pass

# Generated at 2022-06-25 06:20:53.136234
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    str_0 = 'todo: TaskInclude.get_vars() not tested'
    print(str_0)

# Generated at 2022-06-25 06:20:58.464442
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # -------------------------------------------------------------------
    # Test 0
    include_file = "file/path"
    task_data = dict(action=Sentinel, _raw_params=include_file)

    ti = TaskInclude()
    ti.load(task_data)

    assert isinstance(ti, TaskInclude) is True
    assert ti.action == Sentinel
    assert ti._raw_params == include_file
    assert ti.args.get('file') == include_file
    assert ti.args.get('_raw_params') == include_file

    # -------------------------------------------------------------------
    # Test 1

    # -------------------------------------------------------------------
    # Test 2

    # -------------------------------------------------------------------
    # Test 3

    # -------------------------------------------------------------------
    # Test 4

    # -------------------------------------------------------------------
    # Test 5

    # -------------------------------------------------------------------
    # Test 6

    # -------------------------------------------------------------------
    # Test 7

   

# Generated at 2022-06-25 06:21:04.671292
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    p = Play().load({
        'name': 'play_1',
        'hosts': 'all',
        'roles': [
            {'name': 'role_1',
             'tasks': [
                 {'include': {'action': 'include',
                              'file': 'hello.yml',
                              'apply': {'block': [
                                  {'name': 'sub_task_0'},
                                  {'name': 'sub_task_1'}
                              ]}}}
             ]
             }
        ]
    })
    role_1 = p.get_roles_by_name('role_1')[0]
    include_task = role_1.get_block_tasks()[0]
    p_block = include_task.build_parent_block()
    assert p_

# Generated at 2022-06-25 06:21:07.170850
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """Test of class TaskInclude"""
    display.display("Test of method TaskInclude_build_parent_block()")

    ti = TaskInclude()
    ti.args = {
        'apply': {
        },
    }
    p_block = ti.build_parent_block()
    assert p_block == ti

# Generated at 2022-06-25 06:21:17.185671
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    ti.args = {
        'file': 'main.yml',
        'apply': {'block': 'to be ignored', 'tags': ['tag_0', 'tag_1'], 'when': 'tag_0'},
    }
    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.block != 'to be ignored'
    assert p_block.tags == ['tag_0', 'tag_1']
    assert p_block.when == 'tag_0'
    assert len(p_block.block) == 0

test_case_0()
test_TaskInclude_build_parent_block()

# Generated at 2022-06-25 06:21:23.625747
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # build_parent_block method not implemented
    assert False

# Generated at 2022-06-25 06:21:30.844952
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # prepare test objects
    host0 = Host('hostname')
    host1 = Host('hostname')
    group0 = Group('groupname')
    group1 = Group('groupname')

# Generated at 2022-06-25 06:21:42.787771
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    parent_block = Block()
    task_include._parent = parent_block

    task_include.args = {u'apply': {}}
    parent_block.block = {'task': [], 'always': []}
    p_block = task_include.build_parent_block()
    assert p_block is not task_include
    assert task_include._parent is p_block
    assert p_block.block['task'] == []
    assert p_block.block['always'] == []
    assert len(task_include.args) == 0

    task_include.args = {u'apply': {u'block': [], 'name': 'test'}}
    parent_block.block = {'task': [], 'always': []}
    p_block = task_include.build_parent

# Generated at 2022-06-25 06:21:47.055005
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    task_0.args = {'_raw_params': './test_files/test_playbook.yml'}
    task_0.action = 'include_tasks'
    task_include_0.check_options(task_0, None)


# Generated at 2022-06-25 06:21:55.312976
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    task_include_0 = TaskInclude()

    try:
        task_include_0.check_options(task_include_0, None)
        assert False
    except AnsibleParserError as e:
        assert True

    task_include_0.args = {'_raw_params': '', 'apply': dict()}
    try:
        task_include_0.check_options(task_include_0, None)
        assert False
    except AnsibleParserError as e:
        assert True

# Generated at 2022-06-25 06:21:58.836308
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    data_0 = {'action': 'include'}
    task_0 = task_include_0.load(data_0, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(task_0, TaskInclude)
    assert task_0.action == 'include'
    assert task_0.args == {}
    assert task_0.statically_loaded == False


# Generated at 2022-06-25 06:22:03.243547
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    yaml_data = """
    - include:
        file: "{{ base_dir }}/tasks/main.yml"
    """
    parse = AnsibleParser(yaml_data)
    tasks = list(parse.parse_playbook(yaml_data))
    assert tasks[0].get_vars() is not None

# Generated at 2022-06-25 06:22:14.150858
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.task_include import TaskInclude
    myPlaybook = {"hosts": "all", "remote_user": "not_root", "user": "root"}
    myBlock = Block()
    myBlock._play = test_case_0()
    myBlock._play.__init__(myPlaybook)
    myPlay = myBlock._play
    myBlock._loader = test_case_0()
    myBlock._loader.__init__()
    myBlock._variable_manager = test_case_0()
    myBlock._variable_manager.__init__('playbooks/ansible.cfg')
    apply_attrs = {"block": [test_case_0(),test_case_0()]}
    myTaskInclude = TaskInclude()
    myTaskInclude._parent = myBlock
    myTaskIn

# Generated at 2022-06-25 06:22:24.287854
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """Unit test for method 'preprocess_data'"""
    display.notify('Start test_TaskInclude_preprocess_data')

    # Create an instance of TaskInclude
    task_include = TaskInclude()

    # Create an empty dictionary
    ds = {}

    # Add some key-value pairs
    ds['action'] = 'include_role'
    ds['collections'] = ['my_collection', 'my_other_collection']
    ds['ignore_errors'] = True
    ds['tags'] = ['some_tag', 'another_tag']
    ds['when'] = ['my_var', 'my_other_var']

    # Add a key-value pair with a value that's not allowed
    ds['loop'] = 'my_var'

    # Preprocess the data

# Generated at 2022-06-25 06:22:28.567209
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.vars = {'key_1': 'value_1'}
    ti.args = {'key_2': 'value_2'}
    ti.action = 'include'
    assert ti.get_vars() == {'key_1': 'value_1', 'key_2': 'value_2'}


# Generated at 2022-06-25 06:22:38.821193
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test 1
    # Declare a Task include object
    tk = TaskInclude()
    # Test 2
    # Access method get_vars
    # print tk.get_vars()
    # Expected result

# test_TaskInclude_get_vars()


# Generated at 2022-06-25 06:22:48.738815
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Empty input
    ds = {}
    task_include_1 = TaskInclude()
    ds = task_include_1.preprocess_data(ds)
    assert ds == {}

    # Not empty input - when action is include
    ds = {'action': 'include', 'some_key': 'value'}
    task_include_2 = TaskInclude()
    ds = task_include_2.preprocess_data(ds)
    assert ds == {'action': 'include'}

    # Not empty input - when action is not include
    C.INVALID_TASK_ATTRIBUTE_FAILED = False
    ds = {'action': 'task', 'some_key': 'value'}
    task_include_3 = TaskInclude()
    ds = task_include_

# Generated at 2022-06-25 06:22:53.876699
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    ds = {"action": "include", "when": "bla"}
    diff = set(ds.keys()).difference(task_include.VALID_INCLUDE_KEYWORDS)
    assert(diff == {"when"})
    assert(task_include.preprocess_data(ds) == {"action": "include"})
    ds = {"action": "include_role", "args": {"bla": "bla"}}
    assert(task_include.preprocess_data(ds) == ds)
    ds = {"action": "include_role", "bla": "bla"}
    assert(task_include.preprocess_data(ds) == {"action": "include_role"})

# Generated at 2022-06-25 06:23:03.480717
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_build_parent_block = TaskInclude()

    # case 0: no apply attribute
    task_include_build_parent_block.args = dict(file="/no/path/to/include.yml")
    assert task_include_build_parent_block.build_parent_block() == task_include_build_parent_block

    # case 1: with apply attribute
    args = dict(
        file="/no/path/to/include.yml",
        apply=dict(
            tags=["test_apply_attr"],
            block=[dict(
                action=dict(module="copy",
                            args=dict(
                                src="/tmp/src_file.txt",
                                dest="/tmp/dest_file.txt")))],
            name="Test apply attr"
        )
    )
    task_

# Generated at 2022-06-25 06:23:06.768840
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = {u'action': u'include_role', u'name': u'nginx'}
    task_include_0.preprocess_data(ds)

# Generated at 2022-06-25 06:23:13.452953
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    TaskInclude_object = TaskInclude()
    TaskInclude_object.apply = {'block': []}
    TaskInclude_object._parent = TaskInclude()
    TaskInclude_object._parent._play = TaskInclude()
    TaskInclude_object._role = TaskInclude()
    TaskInclude_object._variable_manager = TaskInclude()
    TaskInclude_object._loader = TaskInclude()
    ret = TaskInclude_object.build_parent_block()
    #FIXME: assert something here


# Generated at 2022-06-25 06:23:15.375998
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0.build_parent_block()


# Generated at 2022-06-25 06:23:25.703933
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = { u'bar': True, u'foo': u'bar' }
    task_include_0.action = 'include'
    task_include_0.args = { u'_raw_params': u'/home/ubuntu/ansible/test/integration/targets/include_variables_syntax/tasks/main.yml',
        'apply': {} }
    expected = {u'foo': u'bar', u'bar': True}
    assert task_include_0.get_vars() == expected
    task_include_0.action = 'not_include'
    expected = {u'foo': u'bar', u'bar': True}
    assert task_include_0.get_vars() == expected
    task_

# Generated at 2022-06-25 06:23:33.105138
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class TaskInclude
    '''
    task_include_preprocess_data = TaskInclude()
    test_dict1 = {'action': 'include_role'}
    task_include_preprocess_data.preprocess_data(test_dict1)
    assert task_include_preprocess_data.vars == {'action': 'include_role'}
    # test when test_dict1 = {'action': 'include_role', 'include': {'name': 'role_1'}} is not allowed

# Generated at 2022-06-25 06:23:39.161150
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude(action='include')
    task_include_1.args['my_var'] = 'my_value'
    assert 'my_var' in task_include_1.get_vars()
    assert task_include_1.get_vars()['my_var'] == 'my_value'

    task_include_2 = TaskInclude(action='include_tasks')
    task_include_2.args['my_var'] = 'my_value'
    assert 'my_var' in task_include_2.get_vars()
    assert task_include_2.get_vars()['my_var'] == 'my_value'
    assert 'my_value' not in task_include_2.get_vars()['include_tasks']


# Generated at 2022-06-25 06:23:48.141035
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(file='test_case.yml')
    ti = TaskInclude()
    ti.check_options(ti.load_data(data), data)


# Generated at 2022-06-25 06:23:51.932926
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    data = dict()
    data['args'] = dict()
    data['action'] = 'action'
    data['args']['a'] = 'b'
    data['args']['c'] = 'd'

    task_include_0.check_options(data, data)


# Generated at 2022-06-25 06:23:57.530914
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ds = {'action': 'include'}
    task_include_0 = TaskInclude()
    task_include_0.preprocess_data(ds)
    task_include_0.get_vars()

    ds = {'action': 'include_role'}
    task_include_1 = TaskInclude()
    task_include_1.preprocess_data(ds)
    task_include_1.get_vars()

# Generated at 2022-06-25 06:24:04.641126
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    # Test Option 1: Check that it accepts the TaskInclude.BASE options
    task_include_0.args['file'] = 'foo.yml'
    task_include_0.check_options(task_include_0, None)

    # Test Option 2: Check that it accepts the TaskInclude.OTHER_ARGS options
    task_include_0.args = dict()
    task_include_0.args['apply'] = dict()
    task_include_0.check_options(task_include_0, None)

    # Test Option 3: Check that it accepts both TaskInclude.BASE and TaskInclude.OTHER_ARGS options
    task_include_0.args = dict()
    task_include_0.args['file'] = 'foo.yml'
    task

# Generated at 2022-06-25 06:24:14.411536
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    :avocado: tags=precise
    '''
    ti_0 = TaskInclude()
    args_dict_0 = {
        'args': {
            'test': '123',
            'test_3': 'xxx'
        },
        'file': 'test'
    }
    data_0 = ''
    task_0 = ti_0.check_options(args_dict_0, data_0)
    assert task_0['_raw_params'] == 'test'
    assert task_0['args']['test'] == '123'
    assert 'file' not in task_0


# Generated at 2022-06-25 06:24:16.508594
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    print(task_include_1.get_vars())

# Generated at 2022-06-25 06:24:25.443704
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args = {
        'a' : '1',
        'b' : '2',
        'c' : '3'
    }
    task_include.vars = {
        'x' : '10',
        'y' : '20',
        'z' : '30'
    }
    assert task_include.get_vars() == {'a': '1', 'b': '2', 'c': '3', 'x': '10', 'y': '20', 'z': '30'}

# Generated at 2022-06-25 06:24:30.923615
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method is used to create the parent block for the included tasks
    when ``apply`` is specified
    '''
    # create TaskInclude object
    task_include = TaskInclude()
    # create new attribute
    task_include.args = {'apply': {'block': [], 'play': [], 'task_include': task_include}}
    # call build_parent_block
    task_include.build_parent_block()



# Generated at 2022-06-25 06:24:37.378891
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    # TaskInclude.check_options() takes the following positional arguments:
    #    task: (TaskInclude) - instance of TaskInclude
    #    data: (structure) - arbitrary JSON-like structure

    # check no exception raised

    task = TaskInclude()
    task.action = "include"
    task.args = {
        "file": "/path/to/file"
    }
    data = dict()

    task_include_0.check_options(task, data)



# Generated at 2022-06-25 06:24:46.849847
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()

    # Test valid data when action is 'include':
    # Expected result: return the task_include_2
    task_include_2 = Task(block=None, role=None, task_include=None)
    task_include_2._parent = None
    task_include_2.action = 'include'
    task_include_2.args = {'apply': {}, '_raw_params': 'some_filename'}
    task_include_2.vars = {}
    task_include_2.tags = []
    task_include_2.when = None


# Generated at 2022-06-25 06:24:57.573930
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    data = {'action': 'import_tasks', 'file': 'test.yml'}
    res = task_include_1.check_options(task_include_1.load_data(data), data)
    assert res is not None
    assert '_raw_params' in res.args
    assert 'import_tasks' == res.args['_raw_params']
    assert 'import_tasks' == res.action


# Generated at 2022-06-25 06:25:09.818487
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

# Generated at 2022-06-25 06:25:20.143283
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Create a TaskInclude object
    task_include_0 = TaskInclude()

    # Test 1. TaskInclude.check_options(task, data) method raises an AnsibleParserError when parameter 'task' has an
    #         invalid argument
    data = {
        '_raw_params': 'a_file.yml',
        'invalid_option_1': 'value1',
        'invalid_option_2': 'value2'
    }
    task = {
        'action': 'include',
        'args': data
    }
    try:
        task_include_0.check_options(task, data)
        assert False
    except AnsibleParserError as e:
        assert 'Invalid options for include' in str(e)

# Generated at 2022-06-25 06:25:24.482516
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    dict_0 = dict()
    dict_0.update(dict())
    task_include_0 = TaskInclude()
    try:
        task_include_0.get_vars()
    except Exception:
        pass


# Generated at 2022-06-25 06:25:28.273513
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()

# Generated at 2022-06-25 06:25:37.926606
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args["ansible_test"] = "test"
    task_include_0.action = "not_include"
    task_include_0.vars = {"ansible_var": "var"}
    parent_task_include_0 = TaskInclude()
    parent_task_include_0.args["ansible_test"] = "test"
    parent_task_include_0.action = "not_include"
    parent_task_include_0.vars = {"ansible_var": "var"}
    parent_task_include_0.tasks = [task_include_0]
    task_include_0._parent = parent_task_include_0

    all_vars = task_include_0.get_vars()

# Generated at 2022-06-25 06:25:41.472651
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_load_1 = TaskInclude.load({})
    assert isinstance(task_include_load_1, TaskInclude)

# Generated at 2022-06-25 06:25:46.820152
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.action not in C._ACTION_INCLUDE
    result = task_include_0.get_vars()
    assert isinstance(result, dict)
    assert result == {}

    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.vars = {'foo': 'bar'}
    task_include_1.args = {'baz': 'qux'}
    result = task_include_1.get_vars()
    assert isinstance(result, dict)
    assert result == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-25 06:25:51.689803
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Check for empty vars and args
    task_include_1 = TaskInclude()
    assert task_include_1.get_vars() == {}

    # Check for non empty vars and args
    task_include_2 = TaskInclude()
    # Emulate vars
    task_include_2.vars = {'a': None, 'b': None}
    # Emulate args
    task_include_2.args = {'c': None, 'd': None}
    assert task_include_2.get_vars() == {'a': None, 'b': None, 'c': None, 'd': None}

