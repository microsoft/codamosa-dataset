

# Generated at 2022-06-25 06:16:09.952890
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    float_0 = -3765.45913
    task_include_0 = TaskInclude(float_0)

    float_1 = 0.270583488
    task_include_0.action = float_1
    float_2 = 0.861243
    task_include_0.loop = float_2
    float_3 = 0.446460456
    task_include_0.async_val = float_3
    float_4 = 0.586736
    task_include_0.delegate_to = float_4
    float_5 = -0.31182079
    task_include_0.first_available_file = float_5
    float_6 = -0.5953317
    task_include_0.register = float_6
    float_7 = 0.107598484

# Generated at 2022-06-25 06:16:17.067370
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    float_0 = -45.4880051005
    dict_0 = {'a': 'b', 'c': 'd', 'e': 'f'}

    task_include_0 = TaskInclude(float_0)
    preprocess_data_return_0 = task_include_0.preprocess_data(dict_0)
    assert preprocess_data_return_0 == dict_0


# Generated at 2022-06-25 06:16:20.771957
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    float_0 = -3765.45913
    task_include_0 = TaskInclude(float_0)
    result = task_include_0.get_vars()
    assert result == None


# Generated at 2022-06-25 06:16:30.935156
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    float_0 = -3765.45913
    task_include_0 = TaskInclude(float_0)

    # Test for 'TaskInclude' get_vars method
    task_include_1 = TaskInclude(float_0)
    task_include_1.get_vars()
    assert task_include_1._parent == None
    assert task_include_1.action == ''
    assert task_include_1.args == {}
    assert task_include_1.notify == []
    assert task_include_1.name == ''
    assert task_include_1.run_once == False
    assert task_include_1.delegate_to == None
    assert task_include_1.changed_when == ''
    assert task_include_1.failed_when == ''
    assert task_include_1.until

# Generated at 2022-06-25 06:16:33.344213
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    float_0 = -3765.45913
    task_include_0 = TaskInclude(float_0)
    task_0 = Task.load(None)
    task_include_0.check_options(task_0, task_0)


# Generated at 2022-06-25 06:16:35.793532
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    float_0 = -3765.45913
    task_include_0 = TaskInclude(float_0)
    # parent block creation test
    try:
        task_include_0.build_parent_block()
    except Exception:
        assert False


# Generated at 2022-06-25 06:16:37.305809
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    float_0 = -3765.45913
    task_include_0 = TaskInclude(float_0)
    task_include_0.build_parent_block()


# Generated at 2022-06-25 06:16:43.578299
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    print('Testing method load of class TaskInclude')
    float_0 = -2064.423938
    task_include_0 = TaskInclude(float_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['file'] = 'targets.yml'
    dict_0['tasks'] = dict_1
    block_0 = Block(dict_0)
    role_0 = None
    task_include_0.load(dict_0, block_0, role_0)
    task_include_0.load_data(dict_0, block_0, role_0)
    display.display(task_include_0.args)



# Generated at 2022-06-25 06:16:45.709799
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude()


# Generated at 2022-06-25 06:16:53.739151
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    set_0 = set()
    int_0 = 20
    int_0 = -20
    key_value_0 = KeyValue(int_0, d_1)
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()

# Generated at 2022-06-25 06:17:01.459369
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = "include"
    expect_0 = {}

    result_0 = task_include_0.get_vars()
    assert result_0 == expect_0

# Generated at 2022-06-25 06:17:08.638236
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ti._load_name('include', Sentinel)
    ds = {'include': 'tasks/main.yml', 'action': 'tasks/main.yml', 'invalid': Sentinel}
    result = ti.preprocess_data(ds)
    assert result == {'action': 'tasks/main.yml', 'include': 'tasks/main.yml'}

# Generated at 2022-06-25 06:17:20.827449
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_1.name = 'task_include_name_1'
    task_include_1.vars = {
        'x': 'a',
        'y': 'b',
    }
    task_include_1.action = 'include'
    task_include_1.args = {
        'apply': {
            'fail_on_undefined_vars': False,
            'free_form': True,
            'loop_control': {
                'loop_var': 'inventory_hostname'
            }
        }
    }

    task_include_1_parent = task_include_1.build_parent_block()
    assert isinstance(task_include_1_parent, Block)

# Generated at 2022-06-25 06:17:27.954715
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args['file'] = 'test_file'
    task_include_0.vars = {'name1': 'val1'}
    assert task_include_0.get_vars() == {'file': 'test_file', 'name1': 'val1'}

test_case_0()

# Generated at 2022-06-25 06:17:37.167194
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0._parent = Sentinel(0)
    task_include_0._parent.get_vars = lambda : dict()
    task_include_0.action = 'include'
    task_include_0.vars = dict()
    task_include_0._role = Sentinel(0)
    task_include_0._role.get_vars = lambda : dict()
    task_include_0.args = dict()

    x = task_include_0.get_vars()
    assert x == dict()


# Generated at 2022-06-25 06:17:39.099783
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_2 = TaskInclude(task_include=task_include_0)
    assert task_include_2.get_vars() == {}


# Generated at 2022-06-25 06:17:42.392583
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_data = {'action': 'include_tasks', 'file': 'my_first_include', 'tags': ['first-tag'], 'args': {'foo': 1}}
    task_include = TaskInclude()
    task_include.check_options(task_include.load_data(task_data), task_data)


# Generated at 2022-06-25 06:17:50.515218
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = Block()
    role = Role()
    variable_manager = VariableManager()
    loader = DataLoader()
    # TaskInclude.check_options doesn't handle 'include' in ansible.constants._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS so this case doesn't raise an AnsibleParserError
    task_include = TaskInclude.load({'testing': 'test'}, block=block, role=role)
    task_include1 = TaskInclude.load({'include': 'test'}, block=block, role=role, variable_manager=variable_manager, loader=loader)
    task_include2 = TaskInclude.load({'include_role': 'test'}, block=block, role=role, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 06:17:52.450642
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    type = task_include_0.get_vars()


# Generated at 2022-06-25 06:18:02.277364
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Method get_vars of class TaskInclude
    """
    task_include = TaskInclude()

    # Testing with no action
    task_include.action = None
    vars_result_good = task_include.get_vars() # No action provided
    assert vars_result_good == {}, "Method get_vars failed to get vars with no action"

    # Testing with action 'include'
    task_include.action = 'include'
    task_include.args = {'myargs': ['myarg1', 'myarg2']}
    vars_result_good = task_include.get_vars()
    assert vars_result_good == {'myargs': ['myarg1', 'myarg2']}, "Method get_vars failed to get vars with action 'include'"

    #

# Generated at 2022-06-25 06:18:12.148597
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # populate the task
    # include dictionary
    include_dict = dict()
    include_dict['action'] = 'include'
    include_dict['file'] = '../library/test.py'
    include_dict['name'] = 'test'

    # invalid attr
    include_dict['invalid_attr'] = 'not-allowed'

    task_include = TaskInclude()
    include_dict = task_include.preprocess_data(include_dict)

    invalid_attr = include_dict.get('invalid_attr')
    assert invalid_attr is None


# Generated at 2022-06-25 06:18:15.156895
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    display.deprecated("Please use 'import tests.lib.loader.load_tests' instead")
    from tests.lib.loader.load_tests import test_TaskInclude_load
    return test_TaskInclude_load()


# Generated at 2022-06-25 06:18:18.110289
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    test_data = {
        'action': 'include',
        'file': 'file.yml'
    }

    task_include = TaskInclude()
    task_include.check_options(task_include, test_data)


# Generated at 2022-06-25 06:18:27.331243
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Test method preprocess_data of class TaskInclude
    """
    task_include_0 = TaskInclude()

    # Test 1 - Test Key Error invalid attribute
    # Test 1.1
    try:
        task_include_data_0_0 = {'action': 'include', 'include_role': {'bar': 'foo'}, 'foo': 'bar'}
    except AssertionError:
        pass
    else:
        raise AssertionError("Test 1.1: Expected AssertionError but didn't get it")

    # Test 1.2
    try:
        task_include_data_0_1 = {'action': 'include', 'import_tasks': {'bar': 'foo'}, 'foo': 'bar'}
    except AssertionError:
        pass

# Generated at 2022-06-25 06:18:32.672400
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    test = TaskInclude()
    data = {
        u'name': u'Create a pool',
        u'action': u'zfs pool create {{ name }} {{ disks | join(" ") }}',
    }
    task_include = test.load(data)
    assert task_include.action == u'zfs pool create {{ name }} {{ disks | join(" ") }}'
    assert  task_include.name == u'Create a pool'


# Generated at 2022-06-25 06:18:34.157197
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.check_options(None, None)


# Generated at 2022-06-25 06:18:40.570578
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_id = TaskInclude()
    data = dict(include = 'xyz', name='test', no_log='True', tags='xyz', when='xyz')
    processed_data = task_include_id.preprocess_data(data=data)
    #assert processed_data['action'] == 'include'
    assert processed_data['name'] == 'test'
    assert processed_data['no_log'] == True
    assert processed_data['tags'] == 'xyz'
    assert processed_data['when'] == 'xyz'
    assert 'include' not in processed_data


# Generated at 2022-06-25 06:18:45.595248
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()

    ds = {
        'debugger': Sentinel,
        'loop_control': Sentinel,
        'file': Sentinel
    }

    try:
        task_include_0.preprocess_data(ds)
    except AnsibleParserError:
        pass
    else:
        assert False, 'expected failure'

# Generated at 2022-06-25 06:18:52.907223
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display.debug(u"test_TaskInclude_preprocess_data")
    task_include_0 = TaskInclude()
    #
    # Test with a correct argument:
    #
    task_include_1 = task_include_0.preprocess_data({"action": "include", "ignore_errors": True})
    display.debug(task_include_1)
    assert isinstance(task_include_1, dict)
    # Test with a wrong argument:
    #
    task_include_2 = task_include_0.preprocess_data({"action": "include", "foo": "bar"})
    assert isinstance(task_include_2, dict)

# Generated at 2022-06-25 06:18:57.875747
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    This is a test for TaskInclude.preprocess_data
    """

    test_cases = [{'include': 'something', 'other_key': 'something else'}, {'include': 'something', 'tags': 'test'}]

    for test_case in test_cases:
        test_obj = TaskInclude()
        assert test_obj.preprocess_data(test_case) != None

# Generated at 2022-06-25 06:19:09.779130
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Load static block
    static_block = Block.load(dict(
        apply=dict(
            block=[]
        )
    ), task_include=None)
    # Load task_include with static block
    task_include = TaskInclude()
    task_include._parent = static_block
    task_include_result = task_include.build_parent_block()
    assert task_include_result == static_block
    # Load task_include with apply and block
    task_include = TaskInclude()
    task_include._parent = static_block
    task_include.args = dict(
        apply=dict(
            block=[]
        ),
    )
    parent_block = task_include.build_parent_block()
    assert isinstance(parent_block, Block)
    assert 'apply' not in task_include

# Generated at 2022-06-25 06:19:13.582180
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(action='include', apply=dict(foo='bar'))
    task_include = TaskInclude()
    task_include.preprocess_data(data)
    assert(isinstance(task_include.args['apply'], dict))
    assert(task_include.args['apply']['foo'] == 'bar')



# Generated at 2022-06-25 06:19:15.176981
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.action == 'include'

# Generated at 2022-06-25 06:19:16.909754
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}


# Generated at 2022-06-25 06:19:24.607931
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_obj = TaskInclude()
    data_dict = {"foo": "bar", "baz": 1234}
    returned_value = task_include_obj.preprocess_data(data_dict)
    assert returned_value == data_dict
    data_dict = {"foo": "bar", "baz": 1234, "include": "baz"}
    returned_value = task_include_obj.preprocess_data(data_dict)
    assert returned_value == data_dict


# Generated at 2022-06-25 06:19:26.683538
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == dict()


# Generated at 2022-06-25 06:19:29.745155
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    task_include.preprocess_data({"action": "include", 
        "loop": "hosts", "name": "hosts"
    })

# Generated at 2022-06-25 06:19:36.835036
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Create a TaskInclude object
    test_data_0 = {'meta': {},
                   'other_attrs': {},
                   'name': 'test-task-include',
                   'action': 'include',
                   'args': {'collections': [{'name': 'my_collection'}]},
                   'tags': [],
                   'when': []}

    task_include_0 = TaskInclude.load(data=test_data_0)

    # Call function
    actual_result = task_include_0.build_parent_block()

    # Verify the result
    assert actual_result == task_include_0



# Generated at 2022-06-25 06:19:45.437024
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create a task:
    task = TaskInclude()
    task.action = 'include_tasks'
    task._parent = object()
    task._role = object()
    task._variable_manager = object()
    task._loader = object()
    task.args = dict()
    task.args['apply'] = dict()
    task.args['apply']['block'] = list()
    # Call the method:
    result = task.build_parent_block()
    # Check the result:
    assert type(result) is Block
    assert result.action == 'meta'
    assert result.block == []
    assert result.always is None
    # cleanup
    task = None


# Generated at 2022-06-25 06:19:54.810596
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Example test case #1
    task = TaskInclude()
    data = dict(
        action='include_tasks',
        args=dict(
            _raw_params='/path/to/include_task.yml',
        ),
    )
    task = task.check_options(task.load_data(data), data)

    # Example test case #2
    task = TaskInclude()
    data = dict(
        action='include_role',
        args=dict(
            _raw_params='/path/to/include_role.yml',
            apply=dict(),
        ),
    )
    task = task.check_options(task.load_data(data), data)

    # Example test case #3
    task = TaskInclude()

# Generated at 2022-06-25 06:20:04.738790
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.args = {'debugger': True}
    task_include_1_actual = task_include_1.get_vars()
    assert task_include_1_actual == {'debugger': True}

    task_include_2 = TaskInclude()
    task_include_2.vars = {'hello': 'world'}
    task_include_2.args = {'debugger': True}
    task_include_2_actual = task_include_2.get_vars()
    assert task_include_2_actual == {'debugger': True, 'hello': 'world'}


# Generated at 2022-06-25 06:20:10.244992
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    result = task_include_0.build_parent_block()
    assert result is task_include_0


task_include_1 = TaskInclude()
task_include_1.args['apply'] = {'name': 'build_parent_block', 'block': []}


# Generated at 2022-06-25 06:20:21.394994
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for method build_parent_block of class TaskInclude
    '''

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    play_0 = Play().load({'name': 'test_play'})
    task_0 = Task().load({'name': 'task_0'})
    assert task_0._play is None
    assert task_0._parent is None
    assert task_0._role is None
    assert task_0._loader is None
    assert task_0._block is None

    play_0._add_task(task_0)

    block_0 = Block().load({'block': []})

    task_0._add_block(block_0)

    task_include_0 = TaskInclude()

    task_include_0._play

# Generated at 2022-06-25 06:20:30.835637
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.template.vars import VaultAwareVariableManager

    def combine_include_vars(obj):
        return combine_vars(obj.get_vars())

    # setting up the task
    task_include_0 = TaskInclude()
    task_include_0._block = Block()
    task_include_0._block._parent = Block()
    task_include_0._block._parent._parent = Block()
    task

# Generated at 2022-06-25 06:20:35.621586
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()

    assert task_include_0.build_parent_block() == task_include_0
    assert task_include_1.build_parent_block() == task_include_1

# Generated at 2022-06-25 06:20:46.345800
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    obj = TaskInclude()
    task = TaskInclude(block = None, role = None, task_include = obj)
    task.args = {"key1":"value1", "key2":"value2"}
    task.action = "include"
    result = task.get_vars()
    expected = {"key1":"value1", "key2":"value2"}
    if result != expected:
        raise Exception("Expected %s, got %s." % (expected, result))
    task.action = "import_tasks"
    result = task.get_vars()
    expected = {}
    if result != expected:
        raise Exception("Expected %s, got %s." % (expected, result))


# Generated at 2022-06-25 06:20:51.028632
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude.load("", "", "", "")


# Generated at 2022-06-25 06:20:56.591563
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.attribute as attribute
    import ansible.playbook.block as block
    import ansible.playbook.play as play
    import ansible.playbook.role as role

    # setup the objects
    play_obj = play.Play.load(
        dict(
            name = "Ansible Play",
            hosts = "all"
        ),
        variable_manager = None,
        loader = None
    )
    role_obj = role.Role.load(
        dict(
            name = "foobar"
        ),
        None, # ignores the data_loader
        play_obj, # uses the play for getting the ROLE_CACHE
        'foobar', # the base path to the role
        None, # vars
        False # def_vars
    )
    block_obj = block

# Generated at 2022-06-25 06:21:02.496157
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.vars = dict(a=123, b='var_b')
    task_include_1.args = dict(a=456, c='var_c')
    task_include_1.role = None

    task_include_1.preprocess_data(task_include_1.args)
    assert task_include_1.args == dict(a=456, b='var_b', c='var_c')

# Generated at 2022-06-25 06:21:06.462363
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()

    # Test case #0
    arg_dict = dict()
    arg_dict['a'] = dict()
    arg_dict['a'][''] = dict()
    arg_dict['a']['']['block'] = dict()
    arg_dict['a']['']['block']['b'] = 'c'
    arg_dict['a']['']['block']['d'] = dict()
    arg_dict['a']['']['block']['d']['e'] = 'f'
    arg_dict['a']['']['block']['g'] = list()
    arg_dict['a']['']['block']['g'].append('h')
    ti.args = arg_dict
    ti.build_parent_block()

#

# Generated at 2022-06-25 06:21:18.999528
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    case_0 = {
        'action': 'task',
        'args': {
            'stuff': [
                'a',
                'b',
                'c'
            ],
            'things': [
                'd',
                'e',
                'f'
            ]
        },
        'loop': '{{x}}'
    }
    include_0 = TaskInclude()
    include_0._parent = Task()
    include_0._parent.vars = {
        'x': [
            'a',
            'b',
            'c'
        ],
        'y': [
            'd',
            'e',
            'f'
        ]
    }
    include_0.vars = {
        'a': 'b',
        'c': 'd'
    }
    include

# Generated at 2022-06-25 06:21:29.465695
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test cases
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}
    task_include_0.vars = {u'a': u'b'}
    assert task_include_0.get_vars() == {u'a': u'b'}
    task_include_0 = TaskInclude()
    task_include_0.vars = {u'a': u'b'}
    task_include_0._parent = {}
    assert task_include_0.get_vars() == {u'a': u'b'}
    task_include_0 = TaskInclude()
    task_include_0.args = {u'item': u'1'}

# Generated at 2022-06-25 06:21:40.920416
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.name = "task_include_0"
    task_include_0.action = "include"
    task_include_0.block = None
    task_include_0.args = dict()
    task_include_0.args["tags"] = ["tag_0"]
    task_include_0.args["when"] = "when_0"
    task_include_0.args["vars"] = "vars_0"
    task_include_0.vars = dict()
    task_include_0.vars["name"] = "name_0"
    task_include_0.vars["file"] = "file_0"
    task_include_0.vars["ignore_errors"] = "ignore_errors_0"
    task_include

# Generated at 2022-06-25 06:21:49.203527
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    task_include_0 = TaskInclude()

    task_include_0._parent = RoleInclude()
    task_include_0._parent._parent = RoleDefinition()
    task_include_0._parent._parent._parent = Block()
    task_include_0._parent._parent._parent._parent = Task()

    task_include_0._parent._parent._parent._parent._parent = Task()
    task_include_0._parent._parent._parent._parent._parent._parent = RoleDefinition()
    task_include_0._parent._parent

# Generated at 2022-06-25 06:21:55.262007
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from .ansible_test_mock import AnsibleV2ModuleTestCase
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text

    class TestTaskIncludePreprocessData(AnsibleV2ModuleTestCase):

        def test_include_without_role(self):
            ds = dict(
                action='include',
                name='some_name',
                no_log=False,
                ignore_errors=False,
                when=False,
                register='some_result',
                include_role=dict(
                    name='test-role',
                    tasks_from='some_name',
                )
            )
            ti = TaskInclude()
            ti.load_data(ds)
            self.assertEqual(ti.action, 'include_role')

# Generated at 2022-06-25 06:22:00.430166
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude(block=Block(), task_include=TaskInclude())
    task_include.args = {'apply': None}

    x = task_include.build_parent_block()
    assert x.block == []
    assert x._task_include == task_include
    assert x._play == task_include._parent._play
    assert x._role == task_include._role
    assert x._variable_manager == task_include._variable_manager
    assert x._loader == task_include._loader

    task_include.args = {'apply': {}}
    x = task_include.build_parent_block()
    assert x.block == []
    assert x._task_include == task_include
    assert x._play == task_include._parent._play
    assert x._role == task_include._role
   

# Generated at 2022-06-25 06:22:10.331920
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Define test data
    data = dict()
    data['args'] = dict()
    data['action'] = 'include'

    # Define valid attributes
    valid_attributes = dict()
    valid_attributes['file'] = 'test_file'

    # Define invalid attributes
    invalid_attributes = dict()
    invalid_attributes['file'] = 'test_file'
    invalid_attributes['other_attribute'] = 'invalid_attribute'

    # Define apply attributes
    apply_attributes = dict()
    apply_attributes['file'] = 'test_file'
    apply_attributes['apply'] = dict()

    # Invalid apply attributes
    invalid_apply_attributes = dict()
    invalid_apply_attributes['file'] = 'test_file'
    invalid_apply_attributes['apply']

# Generated at 2022-06-25 06:22:21.673905
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    include_test_args = {
        'free-form': {'no-apply': {'include': 'no_apply.yml', 'action': 'include'}},
        'apply': {'include': 'apply.yml', 'action': 'include', 'apply': {'block': []}}
    }

    task_include_0 = TaskInclude({'action': 'include', 'args': include_test_args['free-form']['no-apply']})

    # Test with apply
    task_include_0.args = include_test_args['apply']
    block_0 = task_include_0.build_parent_block()
    assert type(block_0) == ansible.playbook.block.Block

    # Test without apply

# Generated at 2022-06-25 06:22:32.792407
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # Test that all the valid keywords work
    for kw in TaskInclude.VALID_INCLUDE_KEYWORDS:
        data = dict(kw=kw)
        task.check_options(task, data)
    # Test that invalid keywords fail
    data = dict(kw='foo')
    try:
        task.check_options(task, data)
        raise AssertionError("AnsibleParserError not raised when an invalid keyword is passed")
    except AnsibleParserError:
        pass
    data = dict(apply="foobar")
    try:
        task.check_options(task, data)
        raise AssertionError("AnsibleParserError not raised when an invalid keyword is passed")
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 06:22:40.955856
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    # Setting attributes
    task_include_1._parent = "parent"
    task_include_1.vars = "vars"
    task_include_1.args = "args"

    expected = {"vars": "vars", "args": "args"}
    # This call to get_vars() is in test_case_2
    assert task_include_1.get_vars() == expected


if __name__ == '__main__':
    test_case_0()
    test_TaskInclude_get_vars()

# Generated at 2022-06-25 06:23:02.516236
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Build an example TaskInclude
    task_include = TaskInclude()

    # Build a custom args for this TaskInclude and assign apply attribute
    custom_args = {
        'file': '{{test_var}}',
        'apply': {
            'block': [],
            'when': 'test'
        }
    }
    task_include.args = custom_args

    # Check the result of build_parent_block method
    parent_block = task_include.build_parent_block()
    assert isinstance(parent_block, Block)

    # Build a custom args for this TaskInclude and assign apply attribute
    custom_args = {
        'file': '{{test_var}}',
        'when': 'test'
    }
    task_include.args = custom_args

    # Check the result of build_parent

# Generated at 2022-06-25 06:23:07.677456
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    display.vvv(task_include_0.__dict__)
    display.vvv(task_include_0.get_vars())
    display.vvv(task_include_0.args)
    # display.vvv(task_include_0._task)
    task_include_0.validate_attrs()

# Generated at 2022-06-25 06:23:12.243094
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    assert task_include_1.preprocess_data([{'name': 'example'}]) == []
    assert task_include_1.preprocess_data([{'name': 'example', 'action': 'include'}]) == [{'name': 'example', 'action': 'include'}]

# Generated at 2022-06-25 06:23:14.769951
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    result = task_include_1.get_vars()


# Generated at 2022-06-25 06:23:25.037602
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # FIXME: this should be split into multiple tests
    task_include_0 = TaskInclude()
    # Apply attribute set in args, create parent_block
    task_include_0.args = {'apply': {'action': 'debug', 'debug_level': 1, 'name': None, 'tags': []}}
    parent_block_0 = task_include_0.build_parent_block()
    if not isinstance(parent_block_0, Block):
        raise AssertionError()
    # Apply attribute not set in args, parent_block is self
    task_include_1 = TaskInclude()
    parent_block_1 = task_include_1.build_parent_block()
    if parent_block_1 is not task_include_1:
        raise AssertionError()


# Generated at 2022-06-25 06:23:34.251304
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Py 2.7 compatibility
    try:
        TaskInclude.__init__.__func__.__globals__['display'] = Display()
    except:
        TaskInclude.__init__.__globals__['display'] = Display()
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1._parent = Sentinel
    task_include_1._role = Sentinel
    task_include_1.statically_loaded = True
    task_include_1.args = {'_raw_params': 'file', 'apply': {}}

    # !!!: test when task.action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS

# Generated at 2022-06-25 06:23:35.366702
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass


# Generated at 2022-06-25 06:23:44.581896
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    t.action = "include"
    t.args = {"k1": "v1", "k2": "v2"}
    t.vars = {"k2": "v2", "k3": "v3"}
    res = t.get_vars()
    assert res["k1"] == "v1"
    assert res["k2"] == "v2"
    assert res["k3"] == "v3"
    assert "tags" not in res
    assert "when" not in res


# Generated at 2022-06-25 06:23:54.063931
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for method get_vars of class TaskInclude
    # Test when action is 'include'
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.args = {'a': 1, 'b': 2, 'c': 3}
    task_include_1.vars = {'x': 1, 'y': 2, 'z': 3}

    extra_vars = {'a': 11, 'b': 22, 'c': 33, 'x': 11, 'y': 22, 'z': 33}

    assert task_include_1.get_vars() == extra_vars

    # Test when action is 'include_tasks'
    task_include_2 = TaskInclude()

# Generated at 2022-06-25 06:23:59.965772
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    # method get_vars of class TaskInclude

# Generated at 2022-06-25 06:24:20.590930
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_preprocess_data_0 = TaskInclude()
    task_include_preprocess_data_0.action = 'include'
    task_include_preprocess_data_0.args = dict()
    file_0 = task_include_preprocess_data_0.args['file'] = 'test_value'
    apply_0 = task_include_preprocess_data_0.args['apply'] = dict()
    task_include_preprocess_data_1 = TaskInclude()
    task_include_preprocess_data_1.action = 'import_tasks'
    task_include_preprocess_data_1.args = dict()
    file_1 = task_include_preprocess_data_1.args['file'] = 'test_value'
    apply_1 = task_include_preprocess_data_

# Generated at 2022-06-25 06:24:22.203541
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_1.build_parent_block()


# Generated at 2022-06-25 06:24:30.125091
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    data = {'task_include': {'apply': {}, 'ignore_errors': True, 'action': 'include_tasks'}}

# Generated at 2022-06-25 06:24:34.813407
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Run preprocess_data method and check if expected value is returned
    :return:
    '''
    display.vvv('Test : TaskInclude class')
    task_include_0 = TaskInclude()
    # Test for use case 0
    input_data = dict()
    expected_value = dict()

    result = task_include_0.preprocess_data(input_data)
    assert (expected_value == result)

# Generated at 2022-06-25 06:24:46.547269
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Make a variable_manager without data passed to its constructor
    variable_manager = Sentinel()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}

    # Test case 0: Valid args
    task = TaskInclude()
    task.args = {'_raw_params': 'some/path/some_file.yml', 'myarg': 'myval'}
    task.action = 'include_tasks'
    task = task.check_options(task, 'data')
    assert(task.args == {'_raw_params': 'some/path/some_file.yml', 'myarg': 'myval'})

    # Test case 1: action not set
    task = TaskInclude()

# Generated at 2022-06-25 06:24:53.006225
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """Test TaskInclude get_vars function"""
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {'var1' : 'value1', 'var2' : 'value2'}
    try:
        task_include_0.get_vars()
    except Exception as e:
        e = e


# Generated at 2022-06-25 06:25:01.602131
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    data = dict(action='include',
                name='test',
                file='test.yml',
                force_handlers=False,
                loop=dict(key='k', value='v'),
                ignore_errors=True,
                no_log=True,
                debug_var='debug_val',
                others='others',
                apply=dict(one=1, two=2),
                no_such_prop='no_such_prop'
                )

    task = task_include_0.load_data(data, variable_manager=None, loader=None)

    # check if all the valid options are present in the args
    task_include_0.validate_options(task.args.keys())

    # check if the static options are present

# Generated at 2022-06-25 06:25:12.997997
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    test_ds = {'action': 'include_tasks'}
    task_include.preprocess_data(test_ds)
    assert test_ds['action'] == 'include_tasks'
    assert 'name' in test_ds
    test_ds = {'action': 'include_role', 'name': 'test_role'}
    task_include.preprocess_data(test_ds)
    assert test_ds['action'] == 'include_role'
    assert 'name' in test_ds
    test_ds = {'action': 'include_role', 'name': 'test_role', 'other': 'this_option_should_be_ignored'}
    task_include.preprocess_data(test_ds)
    assert 'other' not in test_ds
    test

# Generated at 2022-06-25 06:25:21.999252
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Build an instance where arguments are empty
    task_include_0 = TaskInclude()
    # Build an instance where arguments are not empty
    task_include_1 = TaskInclude()
    # Build a Block instance
    block_0 = Block()
    block_0.block = []
    task_include_1.args['apply'] = block_0
    # Run the method under test
    result_0 = task_include_0.build_parent_block()
    result_1 = task_include_1.build_parent_block()
    assert isinstance(result_0, Block)
    assert isinstance(result_1, Block)
    assert result_0 is not task_include_0
    assert result_1 is task_include_1


# Generated at 2022-06-25 06:25:24.483050
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_vars = TaskInclude()
    assert task_include_vars.get_vars() is None


# Generated at 2022-06-25 06:25:45.262638
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude.load(
        {
            'action': 'include',
            'file': 'somefile.yml',
        },
        role=None
    )
    data = dict(action='include', file='somefile.yml')
    check_options_output = task_include_1.check_options(task=task_include_1, data=data)
    assert '_raw_params' in check_options_output.args
    assert check_options_output.args['_raw_params'] == 'somefile.yml'


# Generated at 2022-06-25 06:25:50.356192
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # create an instance of TaskInclude
    task_include_0 = TaskInclude()

    # load test data
    with open('get_vars_data.json') as data_file:
        data = json.load(data_file)

    # call method with test data
    result = task_include_0.get_vars(data)

    # check result
    assert result == 1, "expected differ from result"

    # cleanup
    del task_include_0



# Generated at 2022-06-25 06:25:52.497932
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0.args['apply'] == "vars"

# Generated at 2022-06-25 06:25:55.238879
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_include_1.args = {}
    task_include_1.args['myargname'] = 'myargvalue'
    assert task_include_1.check_options({}, 'mydata') == {}, "method check_options expected to return {} but returned '{}'".format({}, task_include_1.check_options({}, 'mydata'))