

# Generated at 2022-06-25 06:16:02.075711
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-25 06:16:11.327873
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # test without 'apply' key
    TASK_INCLUDE_DATA_1 = {
        'action': 'include',
        'file': 'a/b/c.yml',
        'tags': ['tag1'],
    }
    task_include_1 = TaskInclude.load(TASK_INCLUDE_DATA_1)
    assert task_include_1.check_options(task_include_1, TASK_INCLUDE_DATA_1) == task_include_1

    # test with 'apply' key

# Generated at 2022-06-25 06:16:20.277527
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args = {'a': '1', 'b': 2}
    assert task_include_0.action not in C._ACTION_INCLUDE
    task_include_0._parent = TaskInclude()
    task_include_0._parent.vars = {'c': '3'}
    assert task_include_0.get_vars() == {u'c': u'3', u'a': u'1', u'b': 2}
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.args = {'a': '1', 'b': 2}
    task_include_1._parent = TaskInclude()
    task_include_1._parent.vars

# Generated at 2022-06-25 06:16:30.227792
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict()
    task_include_0._invalid_attributes = dict()
    task_include_0._parent = Block()
    task_include_0._parent._role = Role()
    task_include_0._parent._role._role_path = "/opt/stack/ansible/playbooks"
    task_include_0._role = Role()
    task_include_0._role._role_path = "/opt/stack/ansible/playbooks"
    task_include_0.action = "include"
    task_include_0.action = "include_role"
    task_include_0.action = "import_role"

    task_include_0.preprocess_data(ds)

# Generated at 2022-06-25 06:16:36.118324
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict()
    task_include_0.VALID_INCLUDE_KEYWORDS = C._ACTION_ALL_INCLUDE_IMPORT_TASKS
    ds['action'] = 'include_tasks'
    ds['args'] = 'x'
    ds['name'] = 'x'
    ds['include_tasks'] = 'x'
    # Call the preprocess_data method of class TaskInclude
    TaskInclude.preprocess_data(task_include_0, ds)
    # Check if the method returns the expected value
    ds['action'] = 'include'
    ds['static'] = 'x'
    # Call the preprocess_data method of class TaskInclude

# Generated at 2022-06-25 06:16:46.121035
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()
    task_include_3 = TaskInclude()
    task_include_4 = TaskInclude()

    '''
    We override the parent Task() classes get_vars here because
        we need to include the args of the include into the vars as
        they are params to the included tasks. But ONLY for 'include'
    '''
    task_include_1.action = 'include'
    task_include_1.vars = {
        'a': 'a',
        'b': 'b',
        'c': 'c'
    }
    task_include_1.args = {
        'd': 'd',
        'e': 'e',
        'f': 'f'
    }

    task_include_1

# Generated at 2022-06-25 06:16:51.977258
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Setup
    task_include_0 = TaskInclude()
    ds = {'action': 'include_tasks', '_ansible_linecol': (0, 0), '_ansible_lineno': 0}

    # Exercise
    actual = task_include_0.preprocess_data(ds)

    # Verify
    assert actual == {'action': 'include_tasks', '_ansible_linecol': (0, 0), '_ansible_lineno': 0}, "TaskInclude.preprocess_data() produces wrong result"

# Generated at 2022-06-25 06:16:56.145511
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    data = {'action': 'include', 'file': 'file.yml'}
    assert task_include.preprocess_data(data) == {'action': 'include', 'file': 'file.yml'}


# Generated at 2022-06-25 06:16:59.705299
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.args['include'] = "include"
    task_include_0.args['tasks'] = None
    task_include_0.args['name'] = "name"
    task_include_0.get_vars()


# Generated at 2022-06-25 06:17:08.326689
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    kwargs = dict(action='include', args=dict(_raw_params='test', apply=dict(), other='test'))
    task_include_0 = TaskInclude(**kwargs)
    try:
        task_include_0.check_options(task_include_0, **kwargs)
        assert False, 'AnsibleParserError not raised'
    except AnsibleParserError as e:
        assert 'Invalid options for include: other' in str(e)


# Generated at 2022-06-25 06:17:16.908732
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    ti.args = {'apply':{'block':[]}}
    assert(ti.args['apply']['block'] == [])
    ti.build_parent_block()
    assert(ti.args['apply']['block'] != [])

# Generated at 2022-06-25 06:17:18.522972
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    t = TaskInclude.load({'action': 'include', 'args': {'file': 'test.yml'}})

# Generated at 2022-06-25 06:17:25.186896
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    task_include_0 = TaskInclude()

    task_include_1 = TaskInclude()
    # Test should fail with ValueError
    try:
        task_include_1.check_options('task_include_1_data', 'task_include_1_action')
    except ValueError:
        pass

    task_include_2 = TaskInclude()
    # Test should fail with SyntaxError
    try:
        task_include_2.check_options('task_include_2_data', 'task_include_2_action')
    except SyntaxError:
        pass

    task_include_3 = TaskInclude()
    # Test should fail with ImportError

# Generated at 2022-06-25 06:17:31.213778
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.module_vars = dict()
    task_include_0.args = {"test_arg": "test_value"}
    task_include_0.action = "import_playbook"
    task_include_0._parent = Task()
    task_include_0._parent.vars = {"test_var": "test_value"}
    vars = task_include_0.get_vars()
    assert type(vars) == dict
    assert vars == {"test_arg" : "test_value"}



# Generated at 2022-06-25 06:17:39.240174
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args = {'apply':{'block':[]}, 'include': ['role1', 'role2']}
    task_include_0.action = 'include'
    task_include_0._loader = 'loader'
    task_include_0._variable_manager = 'variable_manager'
    task_include_0._parent = 'parent'
    task_include_0._role = 'role'
    block = task_include_0.build_parent_block()
    assert block == task_include_0


# Generated at 2022-06-25 06:17:45.840764
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()

    ds = dict()
    task_include_1 = TaskInclude().load(ds)
    task_include_1.check_options(task_include_1, ds)
    # task-include-1 does not have any attribute file, hence the method raises exception
    try:
        task_include_1.check_options(task_include_1, ds)
    except AnsibleParserError as e:
        display.display(str(e))
    ds = dict(file='/etc/passwd')
    task_include_1 = TaskInclude().load(ds)
    #

# Generated at 2022-06-25 06:17:54.335149
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # initialize
    display.display("Test loading of task with - include:", color='green', screen_only=True)
    display.display("-----------------------------------", color='green', screen_only=True)

    t1 = dict(
        action='include',
        args={
            'file': 'example.yml',
            '_raw_params': 'example.yml',
            'ignore_errors': 'yes',
            'tags': 'tag1'
        }
    )
    t2 = dict(
        action='include_role',
        args={
            'name': 'banana',
            'collections': ['col1', 'col2'],
            '_raw_params': 'banana',
            'ignore_errors': 'yes',
            'tags': 'tag1'
        }
    )

# Generated at 2022-06-25 06:17:54.980901
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()

# Generated at 2022-06-25 06:18:00.867929
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # No tags and no when
    task_include_0 = TaskInclude()
    task_include_0._parent = Sentinel()
    task_include_0._parent.get_vars = lambda: {'foo': 'bar'}
    task_include_0.args = {'_raw_params': 'xxx', 'baz': 'qux'}
    task_include_0.vars = {'foo': 'bar'}

    result_0 = task_include_0.build_parent_block()
    expected_0 = {'foo': 'bar', '_raw_params': 'xxx', 'baz': 'qux'}
    assert result_0.get_vars() == expected_0

    # Tags and when

# Generated at 2022-06-25 06:18:11.301417
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # GIVEN
    ds = dict()
    block = TaskInclude()
    task_include_0 = TaskInclude(block=block)
    task_include_1 = TaskInclude(block=block)
    task_include_2 = TaskInclude(block=block)
    task_include_3 = TaskInclude(block=block)
    task_include_4 = TaskInclude(block=block)
    task_include_5 = TaskInclude(block=block)
    task_include_6 = TaskInclude(block=block)
    task_include_7 = TaskInclude(block=block)
    task_include_8 = TaskInclude(block=block)
    task_include_9 = TaskInclude(block=block)
    task_include_10 = TaskInclude(block=block)
    task

# Generated at 2022-06-25 06:18:26.580631
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    try:
        task_include_0.check_options(task_include_1, 's_data')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-25 06:18:32.803528
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test case for method check_options'
    '''
    # Test that "apply" works with - include:
    data = {"action":"include", "apply": {}}
    ti = TaskInclude()
    task = ti.check_options(TaskInclude.load_data(data), data)
    assert u'apply' in task.args.keys()

    # Test that "apply" doesn't work with - import_playbook:
    data = {"action":"import_playbook", "apply": {}}
    task = ti.check_options(TaskInclude.load_data(data), data)
    assert u'apply' not in task.args.keys()

    # Test that - include: works with "args":
    data = {"action":"include", "args": {"foo": "bar"}}
    task = ti.check

# Generated at 2022-06-25 06:18:37.377167
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    instance = TaskInclude()
    instance.get_load_name = lambda: 'task_include'
    instance.action = 'action_name'
    data = {'invalid_key': 'invalid_value'}
    result = instance.preprocess_data(data)
    assert result == {}

    result = instance.preprocess_data({'action': 'name'})
    assert result['action'] == 'name'

    result = instance.preprocess_data({'action': 'name', 'names': ['name1', 'name2']})
    assert result['action'] == 'name'
    assert len(result['names']) == 2


# Generated at 2022-06-25 06:18:49.496584
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0._play is None
    assert task_include_0._parent is None
    assert task_include_0._role is None
    assert task_include_0._loader is None
    assert task_include_0._variable_manager is None
    assert task_include_0._block is None
    assert task_include_0.action is None
    assert task_include_0.args == {}
    assert task_include_0.any_errors_fatal is None
    assert task_include_0.become is None
    assert task_include_0.become_method is None
    assert task_include_0.become_user is None
    assert task_include_0.delegate_to is None
    assert task_include_0.delegate_facts is None

# Generated at 2022-06-25 06:18:52.691257
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude()
    data = {'action': 'include', 'ignore_errors': 'yes', 'tags': 'abc', 'when': 'xyz'}
    loader_2 = AnsibleLoader()
    variable_manager_3 = VariableManager()
    task_include_1.load(data, loader=loader_2, variable_manager=variable_manager_3)

# Generated at 2022-06-25 06:18:57.062841
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    ti.args = {'apply': {'test': 'test'}}
    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.block.test == 'test'
    assert p_block.block.block == []


# Generated at 2022-06-25 06:19:08.109558
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    arg_dict = dict(
        {'_raw_params': 'test', 'file': 'test', 'tags': 'test', 'when': 'test',
         'apply': {'block': [], 'blockabcs': [], 'block': 'test'},
         'block': [], 'blockabcs': [], 'block': 'test',
         })

    task_include = TaskInclude(args = arg_dict)
    p_block = task_include.build_parent_block()
    assert p_block.block == [], "Block is not empty"
    assert task_include.args == {'_raw_params': 'test', 'tags': 'test', 'when': 'test', 'file': 'test'}, "args is not right"

# Generated at 2022-06-25 06:19:12.386619
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude()
    ds = {'file': 'task_include_1.yaml'}
    block_1 = task_include_1.load(data=ds)
    assert 'task_include_1.yaml' == block_1.args.get('file') or block_1.args.get('_raw_params')


# Generated at 2022-06-25 06:19:18.756038
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Setup variables for test
    task = TaskInclude()
    data = {'apply': {'collect_facts': 'no'}}
    task.action = 'include'
    expected_result = {'apply': {'collect_facts': 'no'}}
    # Execute and verify test
    result = task.check_options(task, data)
    assert result.args == expected_result,\
        'TaskInclude.check_options() did not return expected result'


# Generated at 2022-06-25 06:19:29.523950
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-25 06:19:41.013697
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    test = task_include_0.get_vars()
    assert test == {}


# Generated at 2022-06-25 06:19:47.349401
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test 1: no parent
    task_include_1 = TaskInclude()
    parent_vars_1 = task_include_1.get_vars()
    assert parent_vars_1 == {}, "test_TaskInclude_get_vars: test 1"

    # Test 2: parent with vars
    test_string = "task include"
    task_include_2 = TaskInclude(test_string)
    task_include_2.vars = {'a': 1}
    parent_vars_2 = task_include_2.get_vars()
    assert parent_vars_2 == {}, "test_TaskInclude_get_vars: test 2"

    # Test 3: parent with vars, should not include vars from args if action is not 'include'

# Generated at 2022-06-25 06:19:51.621162
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = "include"
    task_include_0.args = {"file":"tasks/test.yml"}
    assert task_include_0.get_vars() == {"file":"tasks/test.yml"}


# Generated at 2022-06-25 06:19:58.878872
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.args = {}
    task_include_0.action = 'include'
    task_include_0_task = task_include_0.check_options(task_include_0, {})
    assert task_include_0_task == task_include_0
    assert task_include_0_task.args.get('_raw_params') == None
    task_include_1 = TaskInclude()
    task_include_1.args = {}
    task_include_1.action = 'import_playbook'
    task_include_1_task = task_include_1.check_options(task_include_1, {})
    assert task_include_1_task == task_include_1

# Generated at 2022-06-25 06:20:02.583917
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    assert hasattr(TaskInclude, 'load')
    task_include_load_0 = TaskInclude.load(data=None, block=None, role=None, task_include=None, variable_manager=None, loader=None)


# Generated at 2022-06-25 06:20:12.545089
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.args = {'file': 'test_include_file.yml'}
    task_include_0.vars = {'task_var': 'test_task_var'}

    block_0 = test_TaskInclude_build_parent_block_0()
    block_0.block = [task_include_0]

    task_include_0._parent = block_0

    dict_0 = task_include_0.get_vars()

    assert dict_0 == {'task_var': 'test_task_var'}


# Generated at 2022-06-25 06:20:17.091717
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    #assert task_include_0.get_vars() == ''


# Generated at 2022-06-25 06:20:21.683546
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # build an instance of TaskInclude
    task_include_inst = TaskInclude()
    # test method
    task_include_inst.build_parent_block()


# Generated at 2022-06-25 06:20:29.931263
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()

    with pytest.raises(AttributeError):
        task_include_0.action = None
        assert task_include_0.get_vars()
    with pytest.raises(AttributeError):
        task_include_0.args = None
        assert task_include_0.get_vars()
    with pytest.raises(AttributeError):
        task_include_0.vars = None
        assert task_include_0.get_vars()
    with pytest.raises(AttributeError):
        task_include_0._parent = None
        assert task_include_0.get_vars()


# Generated at 2022-06-25 06:20:41.434516
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args = {
        '_raw_params': 'roles/a_role/tasks/main.yml',
        'action': 'include',
        'apply': {
            'name': 'apply_name_0'
        }
    }
    task_include_0._parent = Task()
    task_include_0._parent._play = 'play_0'
    task_include_0._role = 'role_0'
    task_include_0._variable_manager = 'variable_manager_0'
    task_include_0._loader = 'loader_0'
    block_1 = task_include_0.build_parent_block()
    assert len(block_1.block) == 0


# Generated at 2022-06-25 06:20:51.261442
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    TaskInclude().preprocess_data({'action':"include_tasks", 'apply':'hello', 'some_value':'some_value', 'loop':'yes'})

# Generated at 2022-06-25 06:20:56.646767
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    unit test for get_vars method of TaskInclude class
    '''
    # initialize task_include obj
    task_include = TaskInclude()
    # assert vars
    assert task_include.get_vars() == dict()

# Generated at 2022-06-25 06:21:01.595584
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test the method "build_parent_block" of class "TaskInclude"
    :return:
    '''
    task_include = TaskInclude()
    task_include.args = {'apply': {}}
    assert type(task_include.build_parent_block()) == Block

    task_include.args = {'apply': None}
    assert type(task_include.build_parent_block()) == TaskInclude


# Generated at 2022-06-25 06:21:04.877320
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    try:
        obj = TaskInclude()
        data = {}
        obj.load(data)
        task_include_0 = obj
    except Exception as e:
        task_include_0 = str(e)
    assert task_include_0 == 'Invalid task include statement: include requires more than just a name'


# Generated at 2022-06-25 06:21:08.734332
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args = {}
    if not task_include_0.build_parent_block():
        raise AssertionError()


# Generated at 2022-06-25 06:21:14.654019
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.template.template import Templar

    test_play_0 = Play().load({
        'name': 'test_play_0',
        'role': 'test_role_0',
        'hosts': ['localhost', 'test_host_0']
    }, variable_manager={'test_var_1': 'test_value_1'}, loader=None)
    test_task_0 = Task()
    test_task_1 = Task()
    test_task_0._role = test_task_1._role = IncludeRole()
    test_

# Generated at 2022-06-25 06:21:26.182547
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    data = {'action': 'include', 'file': '/home/user/test_case'}
    task = task_include_0.check_options(task_include_0.load_data(data, None, None), data)
    assert task.action == 'include'
    assert task.args['file'] == '/home/user/test_case'
    assert task.args['_raw_params'] == '/home/user/test_case'

    # Verify that 'apply' keyword has been removed and is converted to a property
    data = {'action': 'include', 'file': '/home/user/test_case', 'apply': {'environment': {'SOME_VAR': 'SOME_VALUE'}}}

# Generated at 2022-06-25 06:21:29.110109
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    TODO: Move to integration tests.
    """
    task_include_0 = TaskInclude()
    assert task_include_0.load({'action': 'include', 'args': {'file': 'debug.yml'}}, task_include=None)



# Generated at 2022-06-25 06:21:34.921032
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = dict(action="include", file="file_var", ignore_errors=True, loop="loop_var", name="name_var", no_log=True, register="register_var", run_once="run_once_var", tags="tags_var", when="when_var")
    task_include_0.preprocess_data(ds)


# Generated at 2022-06-25 06:21:37.595007
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    my_task_include = TaskInclude(block=None, role=None, task_include=None)

    # Test the case where the value of action is not 'include'
    # Call method get_vars of class TaskInclude
    my_task_include.args['action'] = 'import_tasks'
    my_result = my_task_include.get_vars()

    # Check the result
    assert my_result == dict()

# Generated at 2022-06-25 06:21:50.799866
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test valid data
    data = {
        'include': 'some_file',
    }
    task = TaskInclude()
    result = task.preprocess_data(data)
    assert result == data

    # Test invalid data
    data = {
        'include': 'some_file',
        'not_supported': 'should_be_ignored',
    }
    task = TaskInclude()
    result = task.preprocess_data(data)
    assert result == data

    # Test valid data
    data = {
        'include_role': 'some_role',
    }
    task = TaskInclude()
    result = task.preprocess_data(data)
    assert result == data

    # Test invalid data

# Generated at 2022-06-25 06:21:57.937263
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    myBlock = Block(parent_block=Block(parent_block=Sentinel()))
    myTaskInclude = TaskInclude(args={ 'apply': { 'block':[] } }, block=myBlock)

    assert(type(myTaskInclude.build_parent_block()) is Block)
    assert(myTaskInclude.build_parent_block()._parent is myBlock)

# Generated at 2022-06-25 06:22:02.609876
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    try:
        task_include_0.get_vars()
    except NotImplementedError:
        pass
    else:
        assert False, "Did not raise NotImplementedError"


# Generated at 2022-06-25 06:22:11.645063
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # creating a sample block and its parent at the same time
    task_include_0 = TaskInclude()

    # this is the "v1" value expected for the dict returned by get_vars
    dict_v1 = dict()
    dict_v1['a'] = 'a'
    dict_v1['b'] = 'b'

    # This is the "v2" value expected for the dict returned by get_vars
    dict_v2 = dict()
    dict_v2['b'] = 'b'
    dict_v2['a'] = 'a'

    # Create the first task
    task_include_0.vars.update(dict_v1)
    task_include_0.action = 'include'

    # Create the second task
    task_include_1 = TaskInclude()
    task_include

# Generated at 2022-06-25 06:22:23.287170
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    parser = Parser()
    # This is the test-case for 'include'
    data = {'action': 'include',
            'apply': {'block': None,
                      'loop': [], 'loop_with': '', 'when': [],
                      'debugger': '', 'ignore_errors': False,
                      'register': '', 'tags': [],
                      'timeout': 10,
                      'name': '', 'run_once': False,
                      'collections': '',
                      'vars': {
                          'var_name': 'some_var_name'}},
            'file': 'roles/common/tasks/main.yml'}

    ti0 = TaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-25 06:22:28.735300
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()

    # trivial test case
    assert task_include.get_vars() == dict(), "Unit test for method get_vars of class TaskInclude failed"

    # another trivial test case
    task_include.action = 'include'
    assert task_include.get_vars() == dict(), "Unit test for method get_vars of class TaskInclude failed"


# Generated at 2022-06-25 06:22:36.908451
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude(task_include = None)
    apply_attrs = {}
    apply_attrs['block'] = []
    apply_attrs['name'] = 'test'
    p_block = task_include.build_parent_block()
    assert p_block == task_include
    apply_attrs['block'] = []
    task_include._parent._play = None
    task_include._role = None
    task_include._variable_manager = None
    task_include._loader = None
    p_block = task_include.build_parent_block()
    assert p_block == task_include


# Generated at 2022-06-25 06:22:43.725219
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Constructor
    '''
    task_include_0 = TaskInclude()
    task_include_0.action = 'include_tasks'
    task_include_0.args = {
        '_raw_params': 'test-file-1',
        'apply': {
            'num_tries': 2,
            'timeout': 5
        }
    }

    # Validate with action 'include_tasks'
    try:
        task_include_0._validate_apply_attrs = True
        task_include_0.check_options(task_include_0, task_include_0)
    except AnsibleParserError:
        pytest.fail('Validation with action "include_tasks" raised AnsibleParserError unexpectedly!')

    # Validate with action 'include_role'
    task

# Generated at 2022-06-25 06:22:45.979165
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert isinstance(task_include_0.build_parent_block(), Block)

# Generated at 2022-06-25 06:22:53.583079
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    with pytest.raises(AnsibleParserError) as err:
        task_include_0.check_options({'_raw_params': 'include_tasks.yml', 'action': 'include_tasks'})
    assert 'Invalid options for include_tasks: _raw_params,action' == str(err.value)
    task_include_1 = TaskInclude()
    task_include_1.check_options({'_raw_params': 'include_tasks.yml', 'action': 'include_tasks', 'file': 'hosts'})
    task_include_2 = TaskInclude()

# Generated at 2022-06-25 06:23:07.220051
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_2 = TaskInclude()

    pass


# Generated at 2022-06-25 06:23:09.147464
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    p = TaskInclude()
    #TODO
    #p.build_parent_block()
    assert True

# Generated at 2022-06-25 06:23:16.043465
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    parent_task = TaskInclude()
    parent_task.args = dict(
        file='/path/to/include/file'
    )
    parent_task.vars = dict(
        role_var_with_no_value=None
    )
    parent_task._parent = Block()
    parent_task._parent.get_vars = lambda: dict(
        play_var='play_var_value'
    )

    assert parent_task.get_vars() == dict(
        role_var_with_no_value=None,
        play_var='play_var_value',
        file='/path/to/include/file'
    )

# Generated at 2022-06-25 06:23:26.387639
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    t = TaskInclude()
    # test with bad args
    task_data = {
        'include': 'some_include',
        'foo': 'bar'
    }
    task = TaskInclude.load(task_data)
    with pytest.raises(AnsibleParserError):
        t.check_options(task, task_data)

    # test with unknown value for action
    task_data = {
        'action': 'unknown',
        'file': 'some_file'
    }
    task = TaskInclude.load(task_data)
    with pytest.raises(AnsibleParserError):
        t.check_options(task, task_data)

    # test with invalid value for apply

# Generated at 2022-06-25 06:23:32.635964
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0  = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_0._parent = task_include_1
    task_include_0.vars = {'attributes': {'var_0': 128}}
    task_include_1.vars = {'attributes': {'var_0': 256}}
    task_include_0.action = 'include'
    task_include_0.args = {'var_0': True}
    result = task_include_0.get_vars()
    assert result == {'attributes': {'var_0': 256}, 'var_0': True}


# Generated at 2022-06-25 06:23:34.110626
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    assert task_include_0.build_parent_block() is task_include_0


# Generated at 2022-06-25 06:23:35.852388
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    t = TaskInclude()
    assert t.build_parent_block() is t


# Generated at 2022-06-25 06:23:47.674879
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()

    data = {'include_tasks': {'apply': {}, 'file': 'test.yml'}}
    task1 = task_include_1.check_options(task_include_1.load_data(data, variable_manager=None, loader=None), data)
    assert task1.args.get('apply') == {}, "test_TaskInclude_check_options: TEST 1 --- Returned invalid value"
    assert task1.args.get('file') == 'test.yml', "test_TaskInclude_check_options: TEST 2 --- Returned invalid value"

    data = {'include_role': {'apply': {}, 'file': 'test.yml'}}

# Generated at 2022-06-25 06:23:52.552740
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_data_0 = dict(
        apply=dict(
            block={ "action": "some_action", "other_attr": "other_value" },
            when="when_value"
        )
    )
    test_task_0 = TaskInclude.load(test_data_0)
    result_0 = test_task_0.build_parent_block()
    assert result_0.action == "some_action"


# Generated at 2022-06-25 06:24:02.976661
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = Task(name='task0')
    block = Block(block=['task0'])
    block.parent_block = None
    task.parent_block = block

    task_include = TaskInclude(action='include', args={'apply':{'block':[]}, 'file':'/home/alice/tasks/home.yml'})
    task_include.action = 'include'
    task_include.args = {}
    task_include._parent = task
    task_include.parent_block = task.parent_block

    task_include.get_vars()

    a = task_include.build_parent_block()
    #assert type(a) == TaskInclude
    #assert a.args == {'block':[]}
    #assert a._parent == task
    #assert a.parent_block == block

# Generated at 2022-06-25 06:24:30.736344
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()

    ti.args = dict(apply=dict(block=[]))
    assert ti._play is None
    assert ti._parent is None
    assert ti._role is None
    assert ti._loader is None
    assert ti._variable_manager is None
    assert ti.action is None

    assert hasattr(ti, 'build_parent_block')
    assert callable(ti.build_parent_block)
    ret = ti.build_parent_block()
    assert isinstance(ret, TaskInclude)
    assert ret == ti

# Generated at 2022-06-25 06:24:39.745808
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create test object
    task_include_1 = TaskInclude()
    # Execute method
    assert task_include_1.get_vars() == dict()

    # Create test object
    task_include_2 = TaskInclude(task_include=task_include_1)
    # Execute method
    assert task_include_2.get_vars() == dict()

    # Create test object
    task_include_3 = TaskInclude(task_include=task_include_2)
    # Execute method
    assert task_include_3.get_vars() == dict()

    # Create test object
    task_include_4 = TaskInclude(task_include=task_include_3)
    # Execute method
    assert task_include_4.get_vars() == dict()

    # Create test object

# Generated at 2022-06-25 06:24:44.411443
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude({'foo': 'bar'})
    assert task_include_1.get_vars() == {'foo': 'bar'}


# Generated at 2022-06-25 06:24:49.305916
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.set_loader()

    # Test when task_include.action is in C._ACTION_INCLUDE:
    task_include.action = 'include_tasks'
    task_include.args = {'tags': 'test_tags', 'when': 'test_when', 'test_k0': 'test_v0'}
    task_include._parent = Block()
    task_include._parent.get_vars = lambda: dict(p_e0='p_v0', test_k0='parent_v0')
    task_include.vars = dict(v_e0='v_v0',test_k0='vars_v0')


# Generated at 2022-06-25 06:24:57.573782
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # create TaskInclude object
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'

    task_include_0.args = {
        '_raw_params': '../tasks/main.yml',
        'tags': 'tag1,tag2'}

    task_include_0.vars = {
        'var1': 'val1',
        'var2': 'val2'}

    # call method
    task_include_0.get_vars()



# Generated at 2022-06-25 06:25:01.643917
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    apply_attrs = {'block': None}

    ti = TaskInclude()
    ti.args = {'apply': apply_attrs}

    assert ti.build_parent_block().args['block'] is None

# Generated at 2022-06-25 06:25:06.196546
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_1._parent = None
    task_include_1._variable_manager = None
    task_include_1._loader = None
    task_include_1._role = None
    task_include_1.args = {}
    # Test case when 'apply' not in args
    assert task_include_1.build_parent_block() == task_include_1
    # Test case when 'apply' in args
    task_include_1.args['apply'] = {}
    assert task_include_1.build_parent_block() != task_include_1



# Generated at 2022-06-25 06:25:16.890999
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    attr_name = 'preprocess_data'
    test_props = [
        {
            'name': 'Test 1: without apply',
            'val': {
                'action': 'include',
                'file': 'file.yaml'
            }
        },
        {
            'name': 'Test 2: with apply',
            'val': {
                'action': 'include_role',
                'file': 'file.yaml',
                'apply': {
                    'free_form': 'test_free_form'
                },
                'tags': ['test_tags'],
                'when': 'test_when'
            }
        }
    ]
    for prop in test_props:
        test_input = prop['val']

# Generated at 2022-06-25 06:25:24.192487
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude.load(
        dict(
            action="include",
            args=dict(
                others="other0",
                _raw_params="file0"
            )
        )
    )
    task_include_1 = TaskInclude.load(
        dict(
            action="include_role",
            args=dict(
                others="other1",
                _raw_params="file1"
            )
        )
    )

    pb = TaskInclude.load(
        dict(
            action="include",
            args=dict(
                others="other0",
                _raw_params="file0"
            )
        ),
        block=task_include_1
    )


# Generated at 2022-06-25 06:25:33.487903
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_TaskInclude = TaskInclude()
    data = {'apply': {'other_key': 'other_value'}}
    new_dict = test_TaskInclude.preprocess_data(data)
    assert new_dict == {'apply': {'other_key': 'other_value'}}
    data = {'apply': {'other_key': 'other_value'}, 'when': ['test_when']}
    new_dict = test_TaskInclude.preprocess_data(data)
    assert new_dict == {'apply': {'other_key': 'other_value'}, 'when': ['test_when']}
    data = {'apply': {'other_key': 'other_value'}, 'tags': ['test_tags']}