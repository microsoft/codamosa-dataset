

# Generated at 2022-06-25 06:16:09.711179
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = {
        'discovered_interpreter_python': '/usr/bin/python',
        'inventory_dir': '/etc/ansible/hosts',
        'inventory_file': '/etc/ansible/hosts',
        'playbook_dir': '/etc/ansible/playbooks',
        'playbook_file': '/etc/ansible/playbooks/app.yml'
    }
    task_include_0.args = {
        '_raw_params': 'tasks/main.yml',
        'free-form': None
    }

# Generated at 2022-06-25 06:16:19.125304
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test if the correct functions are called
    ti = TaskInclude()
    ti.preprocess_data({'tags': ['tag1', 'tag2']})
    ti.preprocess_data({'when': ['tag1 and tag2']})

    # Test if the validation is performed correctly
    ti.preprocess_data({'include': 'tasks.yml'})
    ti.preprocess_data({'action': 'include_tasks', 'include': 'tasks.yml'})
    ti.preprocess_data({'action': 'import_tasks', 'include': 'tasks.yml'})
    ti.preprocess_data({'action': 'include_role', 'include': 'tasks.yml'})

# Generated at 2022-06-25 06:16:25.737581
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    data = dict(
        include="../../tests/sanity/roles/example/tasks/main.yml",
        tags=['collect_info'],
        no_log=True,
        run_once=True,
    )
    result = TaskInclude.load(data, block=Block(), task_include=False, variable_manager=None, loader=None)
    print(result)

# Generated at 2022-06-25 06:16:27.998437
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds__0 = dict()
    task_include_0.preprocess_data(ds__0)

# attributes: static_files



# Generated at 2022-06-25 06:16:30.048735
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    vars = task_include_0.get_vars()
    assert type(vars) == dict


# Generated at 2022-06-25 06:16:39.099691
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = Task()
    task.args = {'_raw_params': ['file_to_include.yml'], 'apply': {}}
    task.action = 'include'
    try:
        task = task_include.check_options(task, None)
    except AnsibleParserError:
        raise AssertionError('Incorrect option validation')

    task = Task()
    task.args = {'_raw_params': ['file_to_include.yml'], 'apply': ['incorrect_type']}
    task.action = 'include'
    try:
        task = task_include.check_options(task, None)
        raise AssertionError('Failed to raise AnsibleParserError for incorrect "apply" option value')
    except AnsibleParserError:
        pass



# Generated at 2022-06-25 06:16:43.355691
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_check_options_0 = TaskInclude.check_options({'action': 'include', 'loop': 'all'}, {'action': 'include', 'loop': 'all'})
    task_include_check_options_1 = TaskInclude.check_options({'action': 'include', 'loop': 'all'}, {'action': 'include', 'loop': 'all'})
    task_include_check_options_2 = TaskInclude.check_options({'action': 'include', 'loop': 'all'}, {'action': 'include', 'loop': 'all'}) # Will raise exception
    task_include_check_options_3 = TaskInclude.check_options({'action': 'include'}, {'action': 'include'}) # Will raise exception

test_TaskInclude_check_options()

# Generated at 2022-06-25 06:16:49.509936
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0._parent = None
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0.action = 'include'
    assert list(task_include_0.get_vars()) == []


# Generated at 2022-06-25 06:16:56.246312
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = {'action': 'import_tasks', 'file': 'test.yml'}
    new_ds = ti.preprocess_data(ds)
    assert new_ds == ds

    ds = {'action': 'import_roles', 'file': 'test.yml'}
    new_ds = ti.preprocess_data(ds)
    assert new_ds == ds

    ds = {'action': 'include_role', 'file': 'test.yml'}
    new_ds = ti.preprocess_data(ds)
    assert new_ds == ds

    ds = {'action': 'include_roles', 'file': 'test.yml'}
    new_ds = ti.preprocess_data(ds)
    assert new_ds

# Generated at 2022-06-25 06:17:05.996744
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """preprocess_data() logic of TaskInclude class"""

    import json
    import pytest
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.sentinel import Sentinel

    # valid input
    input_data = {
        "_ansible_parsed": False,
        "action": "include",
        "apply": {},
        "args": {"loop": "yes"},
        "block": [],
        "delegate_to": "localhost",
        "file": "../../../roles/role/tasks/main.yml",
        "ignore_errors": False,
        "tasks": [],
    }

    # check if a valid input is not changed
    ti0 = TaskInclude()
    input_data_cp = input_data.copy()
    ti0

# Generated at 2022-06-25 06:17:22.512771
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    This test checks the case where file was not specified in the
    task_include keyword.

    Tests:
        TaskInclude.load()

    Asserts:
        Exception of type AnsibleParserError is thrown because
        file is not specified in the task_include keyword.
    '''
    # Set up valid data for the test
    # File is not specified for the task_include keyword
    t_data = dict(action='include')

    # Create a task_include object to call the load method
    ti = TaskInclude()

    # Execute the code to be tested
    with pytest.raises(AnsibleParserError) as exec_info:
        ti.load(data=t_data)


# Generated at 2022-06-25 06:17:30.901057
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    dict_arg = dict()
    dict_arg['action'] = 'include_role'
    dict_arg['name'] = 'role_name'
    dict_arg['tasks'] = 'tasks'
    dict_arg['vars_files'] = 'vars_files'
    dict_arg['defaults_files'] = 'defaults_files'
    dict_arg['private'] = 'private'
    dict_arg['tags'] = 'tags'
    dict_arg['always_run'] = 'always_run'
    dict_arg['ignore_errors'] = 'ignore_errors'

    expected = dict()
    expected['action'] = 'include_role'
    expected['name'] = 'role_name'
    expected['tasks'] = 'tasks'

# Generated at 2022-06-25 06:17:35.080272
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_d = {'_parent': 'fake_parent', 'action': 'include', '_role': 'fake_role', '_play': 'fake_play', 'args': {'a': 0, 'b': 1}}
    task_i = TaskInclude()
    task_i.check_options(task_d, task_d)

# Generated at 2022-06-25 06:17:37.312222
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    ds = {}
    task_include_0.preprocess_data(ds)


# Generated at 2022-06-25 06:17:44.337555
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ds = dict(
        action='include',
        foo='bar',
        name='baz',
        tags='qux',
        when='is_corge',
        _ansible_no_log=True,
    )
    task_include_0 = TaskInclude()
    task_include_0.action = C.INCLUDE_ROLE
    result = task_include_0.preprocess_data(ds)

# Generated at 2022-06-25 06:17:53.046065
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create instance of AnsibleTaskInclude using mocked data for method
    # build_parent_block
    task_include_0 = TaskInclude()

    generated_parent_block = task_include_0.build_parent_block()

    # Check if generated block is an AnsibleBlock
    assert isinstance(generated_parent_block, Block)
    assert generated_parent_block.parent is None
    assert generated_parent_block.role is None
    assert generated_parent_block.loop is None
    assert generated_parent_block._variables is None
    assert isinstance(generated_parent_block.block, list)
    assert generated_parent_block.block == []
    assert generated_parent_block.always is None
    assert generated_parent_block._role is None
    assert generated_parent_block.loop_control is None

# Generated at 2022-06-25 06:17:55.218860
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    assert isinstance(task_include_1.build_parent_block(), TaskInclude)
    assert isinstance(task_include_1.build_parent_block(), Block)


# Generated at 2022-06-25 06:18:01.021480
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    assert task_include.preprocess_data({"include": "tasks_file.yaml", "tags": "tag1"}) == {'include': 'tasks_file.yaml', 'tags': 'tag1'}
    assert task_include.preprocess_data({"include_tasks": "tasks_file.yaml", "ignore_errors": True}) == {'include_tasks': 'tasks_file.yaml', 'ignore_errors': True}
    assert task_include.preprocess_data({"import_playbook": "tasks_file.yaml", "name": "task1"}) == {'import_playbook': 'tasks_file.yaml', 'name': 'task1'}

# Generated at 2022-06-25 06:18:11.414841
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_0 = TaskInclude()
    ti_task_0 = task_include_0.load(
        {
            'action': 'include',
            'file': 'filename'
        }
    )

    assert ti_task_0.statically_loaded == False
    assert ti_task_0.args == {'_raw_params': 'filename', 'file': 'filename'}
    assert ti_task_0.action == 'include'
    assert ti_task_0._parent is None
    assert ti_task_0.role is None
    assert ti_task_0.task_include is None
    assert ti_task_0.has_triggered_failures() == False
    assert ti_task_0.always_run == False
    assert ti_task_0.async_val == 0

# Generated at 2022-06-25 06:18:17.149968
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Test with happy path 1
    task_include_1 = TaskInclude()
    task_include_1.args['apply'] = dict()
    p_block = task_include_1.build_parent_block()
    assert p_block.__class__.__name__ == 'Block'

    # Test with happy path 2
    task_include_2 = TaskInclude()
    p_block = task_include_2.build_parent_block()
    assert p_block.__class__.__name__ == 'TaskInclude'


# Generated at 2022-06-25 06:18:26.082943
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()
    assert result == dict()


# Generated at 2022-06-25 06:18:32.833277
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_ds = {'ignore_errors': True,'name': 'test',
               'action': 'include',
               'args': {'file':'testfile'}}
    task_include_0 = TaskInclude()
    assert task_include_0.preprocess_data(test_ds) == {'ignore_errors': True,
                                                      'name': 'test',
                                                      'action': 'include',
                                                      'args': {'file':'testfile'}}


# Generated at 2022-06-25 06:18:34.061531
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = TaskInclude()
    task_include_1.load()



# Generated at 2022-06-25 06:18:39.515385
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class Test_TaskInclude_get_vars_init:
        def __init__(self):
            self.args = {'k1': 'v1'}

    test_ti_obj = Test_TaskInclude_get_vars_init()

    def test_case_0():
        assert(test_ti_obj.get_vars() == {'k1': 'v1'})

    test_case_0()



# Generated at 2022-06-25 06:18:46.664031
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = {'a': 3, 'b': 4}
    task_include_0.args = {'a': 3, 'b': 4}
    task_include_0.action = 'include'
    task_include_0._parent = Task()
    task_include_0._parent.get_vars = lambda *args, **kwargs: {'c': 3, 'b': 5}
    task_include_0.get_vars()

# Generated at 2022-06-25 06:18:51.563888
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0.action = 'include'

    # Test with action as 'include'
    expected_result_0 = dict()
    actual_result_0 = task_include_0.get_vars()
    assert expected_result_0 == actual_result_0

# Generated at 2022-06-25 06:18:55.273241
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude(name='do something')
    task_include_2 = TaskInclude(name='deploying')

    task_include_1.add_parent(task_include_2)

    assert(task_include_1.get_vars() == dict(name='do something', tags=[], when=True))
    assert(task_include_1.get_vars() == dict(name='do something', tags=[], when=True))

# Generated at 2022-06-25 06:19:06.740214
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    data_dict = {}
    data_dict['action'] = 'include'
    data_dict['args'] = {}
    data_dict['args']['A'] = 'A'
    data_dict['args']['B'] = 'B'
    data_dict['args']['C'] = 'C'
    data_dict['foo'] = 'foo'

    # Expected error/warning message when TaskInclude._validate_action_is_include is True
    warning_msg = "Ignoring invalid attribute: foo"

    # Expected error/warning message when TaskInclude._validate_action_is_include is False
    error_msg = "'foo' is not a valid attribute for a TaskInclude"


# Generated at 2022-06-25 06:19:15.970466
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # create the task include object
    task_include_0 = TaskInclude()

    # create the args dict for the object
    args_dict_0 = dict()

    # create the vars dict for the object
    vars_dict_0 = dict()

    # add the vars dict to the object
    task_include_0.vars = vars_dict_0

    # add the args dict to the object
    task_include_0.args = args_dict_0

    # create the parent object
    task_0 = Task()

    # add the parent object to the object
    task_include_0._parent = task_0

    # get the vars from the task include object
    vars = task_include_0.get_vars()

    # check if the method is returning the correct dictionary
    assert vars == v

# Generated at 2022-06-25 06:19:18.377953
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.args = {'_raw_params': ['*']}
    task_include_0.action = 'include'
    task_include_0.check_options(task_include_0, [])

# Generated at 2022-06-25 06:19:39.412866
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.block import Block

    field_attribute_0 = FieldAttribute()
    task_include_0 = TaskInclude()
    block_0 = task_include_0.build_parent_block()
    all_vars = block_0.get_vars()
    assert all_vars == {}, 'expected {}, got {}'.format(id({}), id(all_vars))
    ansible_play_hosts_0 = block_0.hosts
    assert ansible_play_hosts_0 == 'all', 'expected \'all\', got {}'.format(ansible_play_hosts_0)
    ansible_play_name_0 = block_0.name

# Generated at 2022-06-25 06:19:43.299775
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include_1 = Task.load(data={
        'include': {
            'file': 'file1.yml',
            'apply': {
                'action': 'createdir'
            }
        }
    }, block=None, role=None, task_include=None, variable_manager=None, loader=None)



# Generated at 2022-06-25 06:19:54.054367
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Testing when action is 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict(apply='attrs')
    task_include._included_file = 'tasks/some_task_included.yml'
    parent_block = task_include.build_parent_block()

    assert task_include.args == dict()
    assert parent_block.task_include == task_include
    assert parent_block._parent is None
    assert parent_block.apply == 'attrs'
    assert parent_block._included_file is None
    assert parent_block.block == list()

    # Testing when action is 'import_tasks'
    task_include = TaskInclude()
    task_include.action = 'import_tasks'
    task_

# Generated at 2022-06-25 06:20:04.603098
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create object (TaskInclude)
    task_include_0 = TaskInclude()

    # Create dict (ds) to use in test
    ds = dict()

# Generated at 2022-06-25 06:20:14.968302
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TaskInclude.check_options takes two arguments:
    #     + task: a task in many cases a TaskInclude object
    #     + data: a dict with include task attributes

    # Test case 1: TaskInclude.check_options without _raw_params
    # Expected result: it should raise AnsibleParserError

    # Create a dict with include task attributes
    data = {'name': 'sample include'}

    # Create a TaskInclude object
    task = TaskInclude(block=None, role=None, task_include=None)

    # test TaskInclude.check_options with no _raw_params provided
    try:
        task.check_options(task, data)
        assert False
    except AnsibleParserError:
        pass

    # Test case 2: TaskInclude.check_options with _raw_params


# Generated at 2022-06-25 06:20:16.763581
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    assert task_include_0.get_vars() == dict()


# Generated at 2022-06-25 06:20:28.780229
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    #create object for test
    task_include = TaskInclude()

    #create parent object for test
    parent = TaskInclude()

    #set parent object
    task_include._parent = parent

    #create dict for test
    #parent dict
    parent_vars = {'var1_1':'val1_1','var1_2':'val1_2'}

    #task include dict
    task_include_vars = {'var1_1':'val1_1_modify','var2_1':'val2_1','var2_2':'val2_2'}

    #set parent vars
    parent.vars = parent_vars

    #set task include vars
    task_include.vars = task_include_vars

    #check method get_vars
    returned_

# Generated at 2022-06-25 06:20:34.322314
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = {}
    task_include_0.action = None
    all_vars = task_include_0.get_vars()
    assert all_vars == {}, 'all_vars should be an empty dict'


# Generated at 2022-06-25 06:20:46.160116
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    #define local vars and method that are to be used in testing
    my_play = {}
    my_play['vars'] = {'var1': 'value1'}
    my_play['vars_prompt'] = {'var1': 'value1'}
    my_play['vars_files'] = {'var1': 'value1'}
    my_play['tasks'] = []
    my_task = {}
    my_task['args'] = {'var2': 'value2'}
    my_task['action'] = 'include'
    my_task['__ansible_argspec'] = {}

    #mock the play so we can use it as the parent
    mock_play = type('obj', (object,), my_play)
    #mock the task so we can use it as a sub

# Generated at 2022-06-25 06:20:57.157386
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_1 = TaskInclude()
    task_include_1.set_loader(None)
    task_include_1.set_block(None)
    task_include_1.set_role(None)
    task_include_1.set_task_include(None)
    task_include_1.action = 'include'
    task_include_1.vars = dict()
    task_include_1.args = dict({u'file': u'name'})
    task_include_1.set_dep_chain(None)

    task_include_2 = TaskInclude()
    task_include_2.set_loader(None)
    task_include_2.set_block(None)

    task_include_3 = TaskInclude()
    task_include_3.set_loader(None)


# Generated at 2022-06-25 06:21:16.257297
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = task_include.check_options(
        task_include.load_data(
            {'action': 'include',
             'file': 'some/file.yml'},
            variable_manager=None,
            loader=None
        ), {'file': 'some/file.yml'}
    )
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == 'some/file.yml'


# Generated at 2022-06-25 06:21:21.885616
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task = Task.load({
        'name': 'test parent block',
        'action': 'include_role',
        'apply': {'ignore_errors': True}
    })
    task_include._parent = task
    parent_block = task_include.build_parent_block()
    assert parent_block.ignore_errors == True
    assert task_include in parent_block._block

# Generated at 2022-06-25 06:21:32.308979
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_0.args = {'file': 'file'}
    task_include_0.action = 'include'
    assert task_include_0.args == {'_raw_params': 'file'}
    task_include_0.action = 'import_playbook'
    task_include_0.args = {'file': 'file'}
    assert task_include_0.args == {'file': 'file', '_raw_params': None}
    task_include_0.action = 'import_tasks'
    task_include_0.args = {'file': 'file'}
    assert task_include_0.args == {'file': 'file', '_raw_params': None}
    task_include_0.action = 'include_role'

# Generated at 2022-06-25 06:21:38.365928
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data_dic = {'action': 'include', 'tags': 'foo'}

    task_include_0 = TaskInclude()
    task_include_0.preprocess_data(data_dic)
    assert data_dic['action'] == 'include'
    assert 'tags' not in data_dic


# Generated at 2022-06-25 06:21:47.857079
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude.load({
        'action': 'include',
        'file': './ansible/test/vars_file/include_0.yml',
        'apply': {
            'name': 'load_file',
            'free_form': './ansible/test/vars_file/apply_0.yml'
        }
    })

    # Make sure the parent block has been built
    task_include_0.build_parent_block()

    actual = task_include_0.get_vars()

# Generated at 2022-06-25 06:21:58.746734
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    x = TaskInclude()
    attrs = {"file":"include_file.yml", "ignore_errors":True, "tags":["tag1", "tag2"], "apply":{"meta":{"test":"meta"}}}
    task = Task()
    task.args = {k:v for k,v in attrs.items()}
    task.action = "include_tasks"
    assert x.check_options(task, task.args) == task
    y = TaskInclude()
    task2 = Task()
    task2.action = "import_playbook"
    task2.args = {k:v for k,v in attrs.items()}
    assert y.check_options(task2, task2.args) == task2
    y = TaskInclude()
    task2.action = "import_tasks"
    task

# Generated at 2022-06-25 06:22:08.948973
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class TaskInclude_Mock(TaskInclude):
        def load_data(self, data, variable_manager=None, loader=None):
            super(TaskInclude, self).load_data(data, variable_manager=variable_manager, loader=loader)
            res = Task()
            res.action = data.get('action')
            res.args = data.get('args')
            return res

    data = {
        'action': 'some_action',
        'file': 'some_file',
        'other': 'some_arg',
        'apply': {},
        'other_2': 3
    }
    task = TaskInclude_Mock.load(data)
    assert task.check_options(task, data) is task
    assert data == task.args


# Generated at 2022-06-25 06:22:17.259024
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    options1 = {'file': 'foo.yaml', 'apply': {}}
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    task_include_1.args = options1
    task_include_1.action = 'include'
    task_include_1 = task_include_0.check_options(task_include_1, options1)
    # FIXME: do some asserts

test_case_0()
test_TaskInclude_check_options()

# Generated at 2022-06-25 06:22:25.270358
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-25 06:22:31.434306
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars={'ANSIBLE_USER': 'john', 'ANSIBLE_GROUP': 'wheel'}
    task_include_0.vars['ANSIBLE_USER']='john'
    task_include_0.vars['ANSIBLE_GROUP']='wheel'
    result = task_include_0.get_vars()
    assert result == {'ANSIBLE_USER': 'john', 'ANSIBLE_GROUP': 'wheel'}



# Generated at 2022-06-25 06:23:29.528647
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Unit test to test successful execution and validation of
    TaskInclude._load_data
    """
    data1 = {
        'include': 'foo.yml',
        'tags': ['tag1', 'tag2'],
        'when': 'is_task_include',
    }
    data2 = {
        'include': 'foo.yml',
        'tags': ['tag1', 'tag2'],
        'when': 'is_task_include',
        'bad_key': 'not_in_valid_set'
    }
    data3 = {
        'include': 'bar.yml',
        'tags': ['tag1'],
        'when': 'is_task_include',
    }
    task_include1 = TaskInclude()
    task_include2 = TaskInclude()
   

# Generated at 2022-06-25 06:23:32.452932
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include = TaskInclude(block='block',role='role',task_include='task_include')

    result = task_include.get_vars()

    assert result is not None, "Return value of method get_vars of class TaskInclude was expected not to be None, but returned None"

    assert isinstance(result, dict), "Return value of method get_vars of class TaskInclude was expected to be of type dict, but returned %s" % type(result)




# Generated at 2022-06-25 06:23:44.774291
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude(action="test_action_0")
    dictobj = dict()
    dictobj["test_attr_0"] = "teststring"
    dictobj["test_attr_1"] = "teststring"
    dictobj["test_attr_2"] = "teststring"
    dictobj["test_attr_3"] = "teststring"
    dictobj["test_attr_4"] = "teststring"
    dictobj["test_attr_5"] = "teststring"
    dictobj["test_attr_6"] = "teststring"
    dictobj["test_attr_7"] = "teststring"
    dictobj["test_attr_8"] = "teststring"
    dictobj["test_attr_9"] = "teststring"


# Generated at 2022-06-25 06:23:54.073782
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    data = {'no_log': 'True', 'action': 'include_role'}
    task = Task()
    task.args = {'_raw_params': 'some/file', 'no_log': 'True'}

    task2 = ti.check_options(task, data)
    assert task2.args['_raw_params'] == 'some/file'

    data = {'no_log': 'True', 'action': 'import_playbook'}

    task = Task()
    task.args = {'_raw_params': 'some/file', 'no_log': 'True', 'apply': {}}

    task2 = ti.check_options(task, data)
    assert task2.args['_raw_params'] == 'some/file'
    assert 'apply' in task2

# Generated at 2022-06-25 06:24:01.149899
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    task_include_1.action = "include_role"
    result = task_include_1.preprocess_data({'debugger': None, 'action': 'include_role', 'ignore_errors': True})
    assert result == {'debugger': None, 'action': 'include_role', 'ignore_errors': True}

# Generated at 2022-06-25 06:24:11.006369
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Try using 'include' action
    task_include_0 = TaskInclude()
    task_0 = {}
    task_0['action'] = 'include'
    task_0['args'] = {}
    task_0['args']['file'] = 'some_file'
    task_0['args']['apply'] = {}
    task_0['args']['debugger'] = {}
    task_0 = task_include_0.check_options(task_0, {})
    assert (task_0 == {'action': 'include', 'args': {'_raw_params': 'some_file', 'apply': {}, 'debugger': {}}})

    # Try using 'include_role' action
    task_include_1 = TaskInclude()
    task_1 = {}

# Generated at 2022-06-25 06:24:14.390073
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    ti.args = {"apply":{"other_attr":"attr"}}
    actual_res = ti.build_parent_block()
    expected_res = Block(apply={"block":[]},other_attr="attr")
    assert actual_res.as_dict() == expected_res.as_dict()


# Generated at 2022-06-25 06:24:21.340035
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    # test_data
    test_data_0 = {'action': 'include', 'args': {'file': 'file', 'apply': {'block': [], 'when': 'when', 'name': 'name'}}, 'block': []}

    # Testing for exceptions raised:
    test_data_1 = {}
    try:
        task_include_0.check_options(test_data_1, test_data_0)
    except AnsibleParserError as e:
        if str(e) != 'Invalid options for include: apply':
            raise Exception("Unexpected exception raised: " + str(e))
    else:
        raise Exception("AnsibleParserError not raised")


# Generated at 2022-06-25 06:24:30.067314
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    play = Play.load({'name': 'a',
                      'hosts': 'all',
                      'tasks': [{'include': 'b.yml'}]}, variable_manager=None, loader=None)
    play.set_loader(None)
    task_include = play.get_tasks()[0]
    task_include_preprocess_ds = task_include.preprocess_data({'include': 'b.yml', 'key': 'value'})
    assert 'key' not in task_include_preprocess_ds
    assert 'value' not in task_include_preprocess_ds
    assert 'include' in task_include_preprocess_ds
    assert 'action' in task_include_preprocess_ds
    assert 'key' != 'action'


# Generated at 2022-06-25 06:24:31.493347
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    result = task_include_0.get_vars()
    assert result == {}


# Generated at 2022-06-25 06:25:50.563879
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    block_1 = Block()
    task_include_1.block = block_1
    play_1 = Play()
    task_include_1._play = play_1
    role_1 = Role()
    task_include_1._role = role_1
    variable_manager_1 = VariableManager()
    task_include_1._variable_manager = variable_manager_1
    loader_1 = DataLoader()
    task_include_1._loader = loader_1
    assert isinstance(task_include_1.build_parent_block(), Block) == True


# Generated at 2022-06-25 06:25:59.942615
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0._parent = None
    task_include_0.args = dict()
    task_include_0._role = None
    task_include_0._variable_manager = None
    task_include_0._loader = None
    task_include_0._loop = None
    task_include_0._block = None
    task_include_0._task = None
    block_0 = task_include_0.build_parent_block()
    assert isinstance(block_0, TaskInclude)
    assert block_0.action == ''
    assert block_0.any_errors_fatal == False
    assert block_0.args == dict()
    assert block_0.block == []
    assert block_0.changed_when == ''