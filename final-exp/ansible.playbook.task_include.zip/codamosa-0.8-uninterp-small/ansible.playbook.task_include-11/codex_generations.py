

# Generated at 2022-06-25 06:16:11.279195
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import datetime
    TaskInclude_initial = TaskInclude()
    TaskInclude_initial.action = 'TEST'
    TaskInclude_initial.args = {'a': 1, 'b': datetime.date.today(), 'c': 'TEST', 'd': {'k': 1, 'a': 2, '_raw_params': 1}}
    TaskInclude_initial.block = [1, 2]
    TaskInclude_initial.loop = [1, 2]
    TaskInclude_initial.loop_with_items = {'a': 'b'}
    TaskInclude_initial.name = 'TEST'
    TaskInclude_initial.notify = {'a': 'b'}
    TaskInclude_initial.register = 'TEST'

# Generated at 2022-06-25 06:16:19.084864
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    TaskInclude.VALID_INCLUDE_KEYWORDS = frozenset(('tags',))
    ds = task_include_0.preprocess_data({'tags': 'test'})
    assert(ds['action'] == 'include')
    assert(ds['tags'] == 'test')
    ds = task_include_0.preprocess_data({'tags': 'test', 'invalid': 'test'})
    assert(ds['action'] == 'include')
    assert(ds['tags'] == 'test')
    assert('invalid' not in ds)


# Generated at 2022-06-25 06:16:23.788898
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict()
    data["action"] = "debug"
    data["msg"] = "hello"
    data["no_log"] = True
    data["_ansible_no_log"] = True

    task_include_0 = TaskInclude()
    task_include_0.preprocess_data(data)



# Generated at 2022-06-25 06:16:35.938957
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    dictionary_0 = {}
    dictionary_1 = {'k1': 'v1'}
    dictionary_2 = {'k2': 'v2'}
    dictionary_3 = {'k3': 'v3'}
    dictionary_4 = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    dictionary_5 = {'k1': 'v1', 'k3': 'v3', 'k2': 'v2'}
    dictionary_6 = {'k2': 'v2', 'k1': 'v1', 'k3': 'v3'}
    dictionary_7 = {'k2': 'v2', 'k3': 'v3', 'k1': 'v1'}
    dictionary_8

# Generated at 2022-06-25 06:16:40.379198
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # arrange
    task_include_0 = TaskInclude()
    task_include_0.vars = {}
    task_include_0.args = {'_raw_params': Sentinel, 'apply': 'sentinel'}
    task_include_0.action = 'meta'
    
    # act
    result_0 = task_include_0.get_vars()
    
    # assert
    assert result_0 == {}

# Generated at 2022-06-25 06:16:43.078570
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Create task_include_0 object
    task_include_0 = TaskInclude()
    # Call method to apply the 'apply' option
    task_include_0.args['apply'] = {'block': []}

    return


if __name__ == "__main__":

    # Run test case 0
    test_case_0()

    # Run test method TaskInclude_build_parent_block
    test_TaskInclude_build_parent_block()

# Generated at 2022-06-25 06:16:47.931111
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    expected = isinstance(task_include_0, TaskInclude)
    actual = task_include_0.build_parent_block()
    assert expected == actual


# Generated at 2022-06-25 06:16:55.208955
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # First check that we don't accept 'action' when its not an include
    data = {'action': 'not_include', 'args': {'action': 'include'}}
    task_include_0 = TaskInclude()
    test_task_0 = TaskInclude.load(data, task_include=task_include_0, variable_manager=None, loader=None)
    try:
        task_include_0.check_options(test_task_0, data)
        assert False
    except AnsibleParserError:
        assert True

    # Make sure that 'action' is accepted when its an include
    data = {'action': 'include', 'args': {'action': 'not_include'}}
    task_include_1 = TaskInclude()

# Generated at 2022-06-25 06:17:01.595019
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_attrs = {}
    task_include_0 = TaskInclude()
    task_include_0.build_parent_block()
    apply_attrs = {'block': []}
    task_include_1 = TaskInclude()
    task_include_1.build_parent_block()



# Generated at 2022-06-25 06:17:08.016120
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Fixture
    task_data = {
        'include': 'role_name',
        'import_playbook': 'role_name',
        'static_include': 'role_name',
        'static_import_playbook': 'role_name'
    }

    task_include_instance = TaskInclude()
    task_include_instance.action = 'include'

    # TaskInclude instance has a method 'check_options', which accepts two parameters: task and data
    # 'task' parameter is an instance of TaskInclude
    # 'data' parameter is a dictionary
    for task_action, task_file in task_data.items():
        modified_task = task_include_instance.check_options(task_include_instance, {task_action: task_file})
        assert modified_task.action == task_action

# Generated at 2022-06-25 06:17:14.640545
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ti.preprocess_data({
        'action': 'include',
        'something': 'else',
    })

# Generated at 2022-06-25 06:17:20.656875
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    test_data = {'include': 'test file'}
    # test expected exception
    # cause:
    # Invalid options for include: include
    with pytest.raises(AnsibleParserError) as ans_err:
        task_include_0.check_options(
            task_include_0.load_data(test_data, variable_manager=None, loader=None),
            test_data
        )



# Generated at 2022-06-25 06:17:23.445890
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    vars_0 = task_include_0.get_vars()
    assert (FieldAttribute.FAILED == vars_0)

# Generated at 2022-06-25 06:17:27.023319
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()


# Generated at 2022-06-25 06:17:32.138846
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_0 = TaskInclude()
    assert task_include_0.action == 'meta'
    assert task_include_0.args == {u'_raw_params': u''}
    assert task_include_0.block == None
    assert task_include_0.block_args == None
    assert task_include_0.deprecated == False
    assert task_include_0.delegate_to == None
    assert task_include_0.delegate_facts == False
    assert task_include_0.ignore_errors == False
    assert task_include_0.notify == []
    assert task_include_0.poll == 0
    assert task_include_0.run_once == False
    assert task_include_0.register == None
    assert task_include_0.retries == 0
    assert task_

# Generated at 2022-06-25 06:17:42.690563
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()

    # Test 1 mandatory include keyword 'file' is missing
    ds = task_include.preprocess_data({})
    if ds is None:
        raise(AssertionError("Failed to catch exception"))

    # Test 2 mandatory include keyword 'file' is present
    ds = task_include.preprocess_data({"file" : "test.yml"})
    if ds is None:
        raise(AssertionError("Failed to catch exception"))

    # Test 3 static include keyword 'tags' is present
    ds = task_include.preprocess_data({"file" : "test.yml", "tags" : "test"})
    if ds is None:
        raise(AssertionError("Failed to catch exception"))

    # Test 4 dynamic include keyword 'tags

# Generated at 2022-06-25 06:17:51.217314
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    ds = dict()
    assert task_include.preprocess_data(ds) == {}

    ds = dict(name="test_case_0")
    assert task_include.preprocess_data(ds) == {'name': "test_case_0"}

    ds = dict(action="include")
    assert task_include.preprocess_data(ds) == {'action': "include"}

    ds = dict(action="include", args="test_case")
    assert task_include.preprocess_data(ds) == {'action': "include", 'args': "test_case"}

    ds = dict(action="include", foo="test_case")

# Generated at 2022-06-25 06:17:56.146184
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task_include.args = {'file': './test_include', 'apply': ''}
    assert task_include.check_options(task_include, 'None') == task_include
    task_include.args = {'file': './test_include', '_raw_params': './test_include'}
    assert task_include.check_options(task_include, 'None') == task_include


# Generated at 2022-06-25 06:18:00.109670
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    data1 = {"action":"include","file":"fake.yml"}
    task_include._task_data = data1
    task_include.check_options(task_include,data1)


# Generated at 2022-06-25 06:18:07.103764
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create a data structure
    ds = dict(action='include', loop='with_items', _raw_params='{{ include_variable }}', when='success')

    # Create a TaskInclude
    task_include = TaskInclude()

    # Invoke preprocess_data and confirm result
    assert task_include.preprocess_data(ds) == {'action': 'include', 'loop': 'with_items', '_raw_params': '{{ include_variable }}'}

# Generated at 2022-06-25 06:18:14.530286
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'
    task_include_1.args = {'_raw_params': 'raw_params', 'key': 'value'}
    task_include_1.check_options(task_include_1, None)


# Generated at 2022-06-25 06:18:21.354997
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {'apply': {}}
    task_include._loader = None
    task_include._parent = None
    task_include._play = None
    task_include._role = None
    task_include._variable_manager = None
    parent_block_0 = task_include.build_parent_block()
    assert parent_block_0.__class__.__name__ == 'Block', '''TaskInclude instance method build_parent_block() failed to return an instance of type Block!'''
    assert parent_block_0.attributes.__class__.__name__ == 'Attributes', '''TaskInclude instance method build_parent_block() failed to return an instance of type Attributes!'''

# Generated at 2022-06-25 06:18:30.695064
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include_1 = TaskInclude()
    data_1 = {'action': 'include',
              'param': 'value'}
    expected_1 = {'action': 'include',
                  'param': 'value'}
    actual_1 = task_include_1.preprocess_data(data_1)
    assert(actual_1 == expected_1)

    task_include_2 = TaskInclude()
    data_2 = {'action': 'include_role',
              'param': 'value'}
    expected_2 = {'action': 'include_role',
                  'param': 'value'}
    actual_2 = task_include_2.preprocess_data(data_2)
    assert(actual_2 == expected_2)

# Generated at 2022-06-25 06:18:38.651911
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test scenario 1: Tasks in include has only parent
    # Expected result: vars of parent should be included in returned dict
    task_include_1 = TaskInclude()
    task_include_1.action = 'include'

    new_block = Block()
    new_block.vars = {'k': 'v'}

    task_include_1._parent = new_block

    assert task_include_1.get_vars() == {'k': 'v'}

    # Test scenario 2: Tasks in include has only self
    # Expected result: vars of self should be included in returned dict
    task_include_2 = TaskInclude()
    task_include_2.action = 'include'
    task_include_2.vars = {'k': 'v'}

    assert task_include_2

# Generated at 2022-06-25 06:18:49.605724
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Before we call check_options method, we need to prepare the test case.
    task_include_1 = TaskInclude()

    # Now we call the check_options method.
    # It should return True.
    taskInclude_expected_result_01 = True
    taskInclude_result_01 = task_include_1.check_options({'foo': 'bar'})

    # Now we call the check_options method.
    # It should return True.
    taskInclude_expected_result_02 = True
    taskInclude_result_02 = task_include_1.check_options({'_raw_params': 'foobar'}, data={'_raw_params': 'foobar'})

    # Expected results:
    assert taskInclude_expected_result_01 == taskInclude_result_01
    assert taskIn

# Generated at 2022-06-25 06:18:51.157915
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    assert task_include_0.get_vars() == {}


# Generated at 2022-06-25 06:18:56.700988
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    class _ans_module():
        def _load_params(self, params):
            self.params = params
    ans_module = _ans_module()
    task_include_0._load_params = ans_module._load_params

    def check_options(task, data):
        return task_include_0.check_options(task, data)

    task = Task()
    data = dict(args=dict(_raw_params='/path/to/role', file='path/to/library', apply=True))
    expected_output = dict(args=dict(_raw_params='/path/to/role', apply={}))

    assert check_options(task, data) == expected_output

# Generated at 2022-06-25 06:19:03.125977
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    result = task_include_0.build_parent_block()
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_TaskInclude_build_parent_block()

# Generated at 2022-06-25 06:19:10.119490
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Unit test for TaskInclude.preprocess_data(data)
    # case 1: 'include' has a non-valid attribute.
    my_data = {'include': {'foo': 'bar'}}
    my_obj = TaskInclude()
    try:
        my_obj.preprocess_data(my_data)
        assert False, "TaskInclude.preprocess_data did not catch invalid attribute 'foo'."
    except AnsibleParserError:
        assert True

    # case 2: 'include_role' has a non-valid attribute.
    my_data = {'include_role': {'foo': 'bar'}}
    my_obj = TaskInclude()

# Generated at 2022-06-25 06:19:20.973853
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    args = dict()
    args['block'] = []
    args['apply'] = {'block': [], 'rescue': [], 'always': [], 'any_errors_fatal': False, 'when': True}
    args['apply']['name'] = 'test_apply_name'
    args['apply']['_role'] = None
    args['apply']['_play'] = None
    args['apply']['_ds'] = None
    args['apply']['_hosts'] = None
    task_include_0.args = args
    parent_block = dict()
    parent_block['hosts'] = ['host_0']
    parent_block['roles'] = ['role_0']
    task_include_0.parent = parent_block
   

# Generated at 2022-06-25 06:19:32.297902
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Populate data needed for this test
    b = Block()
    r = None
    t = None

    # Create an object of class TaskInclude
    object_to_test = TaskInclude(block=b, role=r, task_include=t)

    # Prepare data for the test
    task_to_test = Task()
    task_to_test.args = {'a': 1}
    data_to_test = {}

    with pytest.raises(AnsibleParserError):
        # Call the function to be tested
        object_to_test.check_options(task=task_to_test, data=data_to_test)


# Generated at 2022-06-25 06:19:39.944154
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    #Call the method under test
    task_include_0 = TaskInclude()
    task_0_data = dict()
    task_0_data['action'] = 'my_test'
    task_0_data['args'] = dict()
    task_0_data['args']['_raw_params'] = 'test_file'
    task_0_data['args']['test_args'] = 'test_arg_value'
    task_1 = task_include_0.check_options(Task.load(d=task_0_data), task_0_data)

    # Assertion
    if not task_1.args['_raw_params'] == 'test_file':
        raise AssertionError("task_1.args['_raw_params'] != 'test_file'")


# Generated at 2022-06-25 06:19:48.653458
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.action = 'include'
    task_include_0.action = 'import_playbook'
    task_include_0.action = 'import_tasks'
    task_include_0.action = 'include_role'
    task_include_0.action = 'include_tasks'


# Generated at 2022-06-25 06:19:52.450640
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include0 = TaskInclude()
    block = task_include0.build_parent_block()
    assert block == task_include0


# Generated at 2022-06-25 06:19:58.796865
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # defining the test case
    data = dict(
        apply=dict(
            block=dict(
                name="test"
            )
        )
    )

    task_include_0 = TaskInclude()
    task_include_0.args = data

    # creating the expected result
    block_0 = Block()
    block_0.name = "test"
    block_0.block = []

    # running the test
    result = task_include_0.build_parent_block()

    # comparing the result with the expected result
    assert result.name == block_0.name
    assert result.block == block_0.block

#Unit test for method check_options of class TaskInclude

# Generated at 2022-06-25 06:20:02.006913
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    result = task_include_0.build_parent_block()
    assert (result is task_include_0)


# Generated at 2022-06-25 06:20:13.322739
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_playbook = '''
- hosts: localhost
  tasks:
  - debug: msg="Test build_parent_block"
  - import_playbook:
      name: second_playbook.yml
      apply:
        block:
        - debug:
            msg: "This is the parent task block"
        tags:
          - always
        when: onetime
    '''
    test_playbook_1 = '''
- hosts: localhost
  tasks:
  - debug: msg="Test build_parent_block"
  - import_playbook:
      name: second_playbook.yml
      apply:
        block:
        - debug:
            msg: "This is the parent task block"
        tags: always
        when: onetime
    '''

# Generated at 2022-06-25 06:20:17.995528
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    task_0 = Task()
    task_include_0.check_options(task_0, str())


# Generated at 2022-06-25 06:20:28.520084
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    # test with bad option: bar
    data = {
        'bar': 'baz'
    }
    task = task_include.load_data(data, None, None)
    try:
        task_include.check_options(task, data)
        assert False
    except AnsibleParserError:
        assert True

    # test with good option: file
    data = {
        'file': 'baz'
    }
    task = task_include.load_data(data, None, None)
    task_include.check_options(task, data)
    assert task._raw_params == 'baz'

#  Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-25 06:20:40.114134
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-25 06:20:49.186205
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args = {'apply': {}}
    task_include_0._variable_manager = Sentinel()
    task_include_0._loader = Sentinel()
    task_include_0._parent = Sentinel()
    task_include_0._role = None
    task_include_0._play = Sentinel()
    p_block = task_include_0.build_parent_block()
    assert p_block == task_include_0


# Generated at 2022-06-25 06:20:53.095177
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {'apply': {'debugger': False, 'block': [],
                                    'tags': ['always'], 'when': {'conditional': 'True'},
                                    'block': [{'name': 'debugger shell', 'action': 'shell',
                                                'args': {'_raw_params': 'cat /etc/hosts'}}]}}
    block = task_include.build_parent_block()
    assert block == task_include


# Generated at 2022-06-25 06:20:56.461371
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_1 = TaskInclude()
    task_include_1.block = []
    task_include_1._parent = []
    task_include_1._role = None
    task_include_1.args = {
        'apply': {
            'ignore_errors': True,
        },
    }
    res = task_include_1.build_parent_block()
    assert res[0] == 'Block: ignore_errors=True'


# Generated at 2022-06-25 06:21:04.601494
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = dict(a=1, b=2, c=3)
    task_include.args['apply'] = dict(d=1, e=2, f=3)
    assert task_include.args == dict(a=1, b=2, c=3, apply=dict(d=1, e=2, f=3))
    assert len(task_include.args) == 4
    assert task_include.args['apply'] == dict(d=1, e=2, f=3)
    assert len(task_include.args['apply']) == 3
    block = task_include.build_parent_block()
    assert task_include.args == dict(a=1, b=2, c=3)

# Generated at 2022-06-25 06:21:14.294364
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    expected_result = [
        "parent block",
        "parent block",
        "parent block",
        "parent block",
        "parent block",
    ]

    task_include_1 = TaskInclude()
    task_include_1.args = {"apply": {"block": expected_result[0]}}

    task_include_2 = TaskInclude()
    task_include_2.args = {"apply": {"block": expected_result[1]}}

    task_include_3 = TaskInclude()
    task_include_3.args = {"apply": {"block": expected_result[2]}}

    task_include_4 = TaskInclude()
    task_include_4.args = {"apply": {"block": expected_result[3]}}

    task_include_5 = TaskInclude()

# Generated at 2022-06-25 06:21:22.624719
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(
        action='include', 
        file='/home/username/playbooks/users/tasks/main.yml'
    )

    task_include = TaskInclude.load(data)
    task_include_check_options_result = task_include.check_options(task_include, data)

    assert task_include_check_options_result.action == 'include'
    assert task_include_check_options_result.args['_raw_params'] == '/home/username/playbooks/users/tasks/main.yml'



# Generated at 2022-06-25 06:21:24.316853
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pi = TaskInclude()
    pi.args = {}
    assert pi.build_parent_block() is pi

# Generated at 2022-06-25 06:21:29.032793
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.args = {'name': 'test', 'fail_when': 'foo'}
    task.vars = {'bar': 1}
    all_vars = task.get_vars()
    assert len(all_vars) == 2
    assert all_vars['name'] == 'test'
    assert all_vars['bar'] == 1


# Generated at 2022-06-25 06:21:35.318124
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include_0 = TaskInclude()
    task_include_0.vars = dict()
    task_include_0.args = dict()
    task_include_0._parent = Task()

    # Try to run method get_vars()
    try:
        task_include_0.get_vars()
    except Exception as e:
        print("Exception caught!")
        print(e)


# Generated at 2022-06-25 06:21:46.007469
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    test_cases = dict(
        # This case is to test empty apply
        # expected result: p_block = self
        test_case_1=dict(
            apply_attrs=dict(),
            expected_p_block=Block()
        ),
        # This case is to test apply with block
        # expected result: p_block = Block() object with 'block' set to empty list
        test_case_2=dict(
            apply_attrs=dict(block=[]),
            expected_p_block=Block(block=[])
        ),
        test_case_3=dict(
            apply_attrs=dict(block=[]),
            expected_p_block=Block(block=[])
        ),
    )

    # Pre-test preparation
    ti = TaskInclude()
    ti.args = dict()

    #

# Generated at 2022-06-25 06:21:55.847926
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {'tags': ['server']}
    ti = TaskInclude()
    ti.preprocess_data(data)

# Generated at 2022-06-25 06:22:06.690311
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    data = dict()
    ar = dict()
    task = TaskInclude.check_options(task_include, ar, data)
    assert task == ar
    # Test asserts with None as raw_params
    task = dict()
    task['action'] = 'include'
    task['args'] = dict()
    task['args']['_raw_params'] = None
    with pytest.raises(AnsibleParserError):
        task_include.check_options(task, data)
    # Test asserts with bad_opts
    task = dict()
    task['action'] = 'include'
    task['args'] = dict()
    task['args']['_raw_params'] = "random"
    task['args']['_bad'] = "random"

# Generated at 2022-06-25 06:22:11.929588
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {'apply': '', 'file': 'testfile'}
    task_include.action = 'include_role'
    assert isinstance(task_include.build_parent_block(), Block)

# Generated at 2022-06-25 06:22:22.756674
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Initial test data
    obj = TaskInclude()

    # Define the test behaviour of method build_parent_block
    def side_effect(*args):
        side_effect.called = True
        if(side_effect.counter == 0):
            side_effect.counter += 1
            return Sentinel
        elif(side_effect.counter == 1):
            side_effect.counter += 1
            return None
        else:
            raise Exception('Unexpected number of calls to build_parent_block')

    # Call the method
    obj.args = {'apply': {}}
    obj.build_parent_block = side_effect
    TaskInclude.build_parent_block(obj)

    # Perform assertions
    assert side_effect.called



# Generated at 2022-06-25 06:22:33.444908
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()
    ti_task = TaskInclude.load({"action": "include_role", "name": "roleA"})
    ti_task = task_include_0.check_options(ti_task, {"action": "include_role", "name": "roleA"})
    assert ti_task.action == "include_role"
    assert ti_task.args['name'] == "roleA"
    assert ti_task.task_type == "include_role"

    ti_task = TaskInclude.load({"action": "import_role", "name": "roleA"})
    ti_task = task_include_0.check_options(ti_task, {"action": "import_role", "name": "roleA"})
    assert ti_task.action == "import_role"

# Generated at 2022-06-25 06:22:42.741657
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task_include.args = {
        'file': 'some file',
        'apply': {'name':'some name'},
        'some_invalid_arg': True
    }
    data = {}
    task = task_include.check_options(task_include, data)
    assert task.args['_raw_params'] == 'some file'
    assert task.args['apply']['name'] == 'some name'
    assert 'some file' in task.args
    assert 'some_invalid_arg' not in task.args
    assert '_raw_params' in task.args
    with pytest.raises(AnsibleParserError) as execinfo:
        task_include.action = 'some action'

# Generated at 2022-06-25 06:22:51.387901
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0_build_parent_block = TaskInclude()
    # Verifies that task_include_0_build_parent_block is an instance of TaskInclude
    assert type(task_include_0_build_parent_block) == TaskInclude
    task_include_1_build_parent_block = TaskInclude()
    # Verifies that task_include_1_build_parent_block is an instance of TaskInclude
    assert type(task_include_1_build_parent_block) == TaskInclude
    task_include_2_build_parent_block = TaskInclude()
    # Verifies that task_include_2_build_parent_block is an instance of TaskInclude
    assert type(task_include_2_build_parent_block) == TaskInclude
    task_include_3_build_parent

# Generated at 2022-06-25 06:22:54.438117
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {'apply': {}}
    task_include.build_parent_block()


# Generated at 2022-06-25 06:23:03.992651
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # TaskInclude init
    task_include_1 = TaskInclude()

# Generated at 2022-06-25 06:23:14.012107
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    # Test for valid options for each action
    data_0 = {
        'apply': {},
        'file': '/path/to/include/task/file.yml',
    }
    task_0 = task_include_0.check_options(
        task_include_0.load_data(data_0, variable_manager=None, loader=None),
        data_0
    )

    data_1 = {
        'action': 'include_role',
        'name': 'some.role',
    }
    task_1 = task_include_0.check_options(
        task_include_0.load_data(data_1, variable_manager=None, loader=None),
        data_1
    )


# Generated at 2022-06-25 06:23:32.117128
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_0.args.update({('apply',): Sentinel.task_include_0_apply})
    task_include_0._parent = Sentinel.task_include_0__parent
    task_include_0._role = Sentinel.task_include_0__role
    task_include_0._variable_manager = Sentinel.task_include_0__variable_manager
    task_include_0._loader = Sentinel.task_include_0__loader
    assert task_include_0.build_parent_block() == Sentinel.task_include_0


# Generated at 2022-06-25 06:23:38.399788
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'vars'))
    from ansible.vars.manager import VariableManager
    import ansible.inventory.manager

    task_include_0 = TaskInclude()
    # FIXME: I don't know how to check if display is a set
    #assert task_include_0.display is not None

    # FIXME: I don't know how to check if no_log is a set
    #assert task_include_0.no_log is not None

    task_include_0._role = None

    task_include_0.when = None
    task_include_0.name = 'task_include_0'
    task_include_0._parent = None
    task_include

# Generated at 2022-06-25 06:23:43.323378
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    expected = task_include_0.build_parent_block()
    assert expected == task_include_0


# Generated at 2022-06-25 06:23:48.223708
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include_0 = TaskInclude()

    # call get_vars
    task_include_0.get_vars()
    # check result
    assert True


# Generated at 2022-06-25 06:23:52.406808
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    parent_block_1 = task_include_0.build_parent_block()
    assert str(type(parent_block_1)) == 'ansible.playbook.task.TaskInclude'

if __name__ == '__main__':
    test_case_0()
    test_TaskInclude_build_parent_block()

# Generated at 2022-06-25 06:24:02.918001
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # method 'check_options' of class 'TaskInclude'
    # e.g., with one argument, no required, missing, or invalid options
    test_task_include_0 = TaskInclude(Block(), role)
    test_data_0 = dict(file='test_file_name.yaml', apply=dict(ignore_errors=True), invalid_option='bad_value')
    test_task_include_0_0 = TaskInclude.check_options(test_task_include_0, test_data_0)
    assert test_task_include_0_0._parent == Block()
    assert test_task_include_0_0._role == role
    assert test_task_include_0_0._blocks == []

# Generated at 2022-06-25 06:24:06.306199
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # FIXME: Test should check for AnsibleParserError
    task_include_0 = TaskInclude()

    # Test type of arg task
    task_include_0.check_options('task', 'data')



# Generated at 2022-06-25 06:24:09.632253
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude(block=None, role=None, task_include=None)
    # todo: implement test for TaskInclude.build_parent_block
    raise NotImplementedError



# Generated at 2022-06-25 06:24:11.118862
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    block_0 = task_include_0.build_parent_block()



# Generated at 2022-06-25 06:24:14.171159
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Setup variables
    task_include_0 = TaskInclude()
    block_0 = Block(play=play_0)
    task_include_0._parent = block_0

    # Call method
    assert task_include_0.build_parent_block() == task_include_0


# Generated at 2022-06-25 06:24:30.295952
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    result_0 = task_include_0.build_parent_block()
    assert False


# Generated at 2022-06-25 06:24:39.715747
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost,')
    play_context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=inv)
    block = Block()

# Generated at 2022-06-25 06:24:44.400850
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    all_vars = task.get_vars()
    assert not all_vars, "This should return an empty dict"


# Generated at 2022-06-25 06:24:49.334015
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # case 1:
    task_include_1 = TaskInclude()
    task_1 = dict(action='include', args={'debugger': 'mod', 'file': 'test.yml'})
    task_1_expected = dict(action='include', args={'_raw_params': 'test.yml'})
    task_1_new = task_include_1.check_options(task_1, task_1)
    assert task_1_new == task_1_expected


# Generated at 2022-06-25 06:25:00.088161
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Tests the check_options method of class TaskInclude
    '''
    task_include_1 = TaskInclude()
    # 1. Simple include
    data1 = dict(
        action='include',
        file='/path/to/foo.yml',
        tags='foobar'
    )
    with pytest.raises(AnsibleParserError):
        task_include_1.check_options(task_include_1.load_data(data1), data1)
    # 2. Simple include with 'apply' attribute
    data2 = dict(
        action='include',
        file='/path/to/foo.yml',
        apply=dict(
            block=[]
        ),
        tags='foobar'
    )

# Generated at 2022-06-25 06:25:11.998492
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    ds = dict(
        apply=dict(
            block=[]
        ),
        file='test',
    )

    # Test case with include
    task_include_0_data = dict(
        action='include',
        args=ds,
    )

    task_include_0_var_manager = object()
    task_include_0_loader = object()
    task_include_0 = TaskInclude.load(
        data=task_include_0_data,
        variable_manager=task_include_0_var_manager,
        loader=task_include_0_loader,
    )

    assert isinstance(task_include_0, TaskInclude)
    assert task_include_0.action == 'include'
    assert task_include_0.args['file'] == 'test'
    assert task_include

# Generated at 2022-06-25 06:25:21.841638
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    #test task with apply argument
    apply_attrs = {'apply': {'action': 'copy', 'src': 'copy src', 'dest': 'copy dest'}}
    task = TaskInclude(apply_attrs)
    task._parent = 'some task'
    task._loader = 'some task'
    task._variable_manager = 'some task'
    task._role = 'some task'
    task._block = 'some task'
    block = task.build_parent_block()
    assert task._block == block
    assert block.apply == True
    assert block.block == []
    assert block.action == 'copy'
    assert block.src == 'copy src'
    assert block.dest == 'copy dest'
    assert block.play == task._parent._play
    assert block._loader == task._loader
    assert block

# Generated at 2022-06-25 06:25:30.773420
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block_0 = Block()
    block_0._parent = object()
    block_0._play = object()
    block_0._role = object()
    block_0._variable_manager = object()
    block_0._loader = object()
    block_0.args = {'apply': {'name': 'abc', 'hosts': 'lmnop', 'vars': {}}}
    block_0.exclude_parent = False
    block_0.task_include = object()
    block_0.vars = {'xyz': 'hello world!'}
    block_0.action = 'include'

    parent_block = block_0._build_parent_block()

    assert parent_block == block_0._parent

# Generated at 2022-06-25 06:25:35.133365
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include_0 = TaskInclude()
    task_include_1 = TaskInclude()
    assert task_include_0.build_parent_block() is task_include_0
    assert task_include_1.build_parent_block() is task_include_1

# Generated at 2022-06-25 06:25:38.357221
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_0 = TaskInclude()

    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        data = {'action': action, 'args':{'file': 'some_value'}}
        task = TaskInclude.load(data)
        task_include_0.check_options(task, data)
