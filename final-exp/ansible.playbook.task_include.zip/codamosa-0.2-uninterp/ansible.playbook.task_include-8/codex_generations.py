

# Generated at 2022-06-17 08:28:01.962227
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-17 08:28:11.616856
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False


# Generated at 2022-06-17 08:28:20.418428
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    from ansible.vars.clean import module_response_deepcopy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

# Generated at 2022-06-17 08:28:31.970179
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test with 'include' action
    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action

# Generated at 2022-06-17 08:28:36.853355
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:28:45.830951
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Set the play_context attribute of the task_include object
    task_include._play_context = play_context

    # Set the variable_manager attribute of the task_include object
    task_include._variable_manager = variable_manager

    # Set the action attribute of the task_include object
    task_include.action = 'include'

    # Set the vars attribute of the task_include object
    task_include.vars

# Generated at 2022-06-17 08:28:57.068491
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:29:09.193460
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network

# Generated at 2022-06-17 08:29:20.812814
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test method preprocess_data of class TaskInclude
    '''
    # Test with action 'include'
    task = TaskInclude()
    ds = {'action': 'include', 'name': 'test', 'tags': ['tag1', 'tag2'], 'invalid_attr': 'invalid_value'}
    ds = task.preprocess_data(ds)
    assert ds == {'action': 'include', 'name': 'test', 'tags': ['tag1', 'tag2']}

    # Test with action 'include_role'
    task = TaskInclude()
    ds = {'action': 'include_role', 'name': 'test', 'tags': ['tag1', 'tag2'], 'invalid_attr': 'invalid_value'}
    ds = task.preprocess_

# Generated at 2022-06-17 08:29:33.959418
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:29:46.345135
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World!'))),
        ]
    )

# Generated at 2022-06-17 08:29:51.519438
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:30:03.529293
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a task with apply

# Generated at 2022-06-17 08:30:11.065459
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import TaskInclude

# Generated at 2022-06-17 08:30:22.272519
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with invalid options
    data = {'action': 'include_tasks', 'file': 'test.yml', 'invalid_option': 'invalid_option'}
    task = TaskInclude.load(data, block=Block(), role=None, task_include=None, variable_manager=VariableManager(), loader=DataLoader())
    assert task.args['file'] == 'test.yml'
    assert task.args['_raw_params'] == 'test.yml'
    assert 'invalid_option' not in task.args

# Generated at 2022-06-17 08:30:34.221756
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test TaskInclude
    task = TaskInclude()
    data = dict(action='include', file='test.yml')
    task = task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == 'test.yml'

    data = dict(action='include', file='test.yml', apply=dict(block=[]))
    task = task.check_options(task.load_data(data), data)
   

# Generated at 2022-06-17 08:30:44.221415
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for 'include'
    task = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            vars=dict(
                foo='bar',
            ),
        ),
        variable_manager=variable_manager,
        loader=loader,
    )
    all_vars = task.get_vars()
   

# Generated at 2022-06-17 08:30:58.157348
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context._set_task_and_variable_override(
        variable_manager=variable_manager,
        loader=loader,
    )

    # Test that an invalid option is removed
    data = dict(
        action='include',
        file='/path/to/file',
        invalid_option='invalid',
    )

# Generated at 2022-06-17 08:31:06.634336
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()


# Generated at 2022-06-17 08:31:14.224691
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context._task_vars = dict()

    task_include_obj = TaskInclude()
    task_include_obj._variable_manager = variable_manager
    task_include_obj._loader = loader
    task_include_obj._play_context = play_context

    task_include_obj.action = 'include'

# Generated at 2022-06-17 08:31:32.337426
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:31:43.019311
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load({}, variable_manager=variable_manager, loader=loader)
    block = Block.load({'block': []}, play=play, variable_manager=variable_manager, loader=loader)
    task = Task.load({'action': 'include_role', 'name': 'myrole'}, block=block, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:31:51.998449
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test with action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'a': 1}}
    task = task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'a': 1}}

    # Test with action 'import_playbook'
    task = TaskInclude()
    task.action = 'import_playbook'
    task.args = {'file': 'test.yml', 'apply': {'a': 1}}
    task = task.check_options(task, {})

# Generated at 2022-06-17 08:32:05.248764
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:32:14.006540
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with action 'include'
    task_include = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'some_file.yml', 'apply': {'some_key': 'some_value'}}
    task = task_include.check_options(task, {})
    assert task.args == {'_raw_params': 'some_file.yml', 'apply': {'some_key': 'some_value'}}

    # Test with action 'include_t

# Generated at 2022-06-17 08:32:24.695963
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 08:32:37.169818
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-17 08:32:47.749466
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Block()
    task._parent.vars = {'e': 5, 'f': 6}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test for action 'import_tasks'
    task = TaskInclude()
    task.action = 'import_tasks'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
   

# Generated at 2022-06-17 08:33:00.354586
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict(a=1, b=2)
    task_include.vars = dict(c=3, d=4)

    task_include.set_loader(loader)
    task_include.set_play_context(play_context)
    task_include.set_variable_manager(variable_manager)


# Generated at 2022-06-17 08:33:05.381741
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:33:29.960176
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'a': 'b'}}
    TaskInclude.check_options(task, task.args)
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args['apply'] == {'a': 'b'}

    task = Task()
    task.action = 'include_role'
    task.args = {'file': 'test.yml', 'apply': {'a': 'b'}}
    TaskInclude.check_options(task, task.args)

# Generated at 2022-06-17 08:33:40.512727
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()
    data = {'action': 'include_role', 'name': 'test_role'}
    task = task_include.load(data)
    assert task.action == 'include_role'
    assert task.args['name'] == 'test_role'
    assert task.args['_raw_params'] == 'test_role'
    assert task.statically_loaded is False
    assert task.has_triggered_flag() is False
    assert task.notify is None
    assert task.loop is None
    assert task.until is None
    assert task.retries == 3
    assert task.delay == 3
    assert task.first_available_file is None
    assert task.tags == []
    assert task.when is None
    assert task.register is None
    assert task.ignore_

# Generated at 2022-06-17 08:33:46.454100
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with a TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task = ti.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'test': 'test'}}

    # Test with a HandlerTaskInclude
    ti = TaskInclude()
    task = Task()
   

# Generated at 2022-06-17 08:33:58.691922
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-17 08:34:05.906071
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:34:16.762464
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    ds = {'action': 'include', 'name': 'test_name', 'tags': 'test_tags', 'when': 'test_when', 'invalid_attr': 'test_invalid_attr'}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert ds == {'action': 'include', 'name': 'test_name', 'tags': 'test_tags', 'when': 'test_when'}


# Generated at 2022-06-17 08:34:31.009116
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Test with valid options

# Generated at 2022-06-17 08:34:40.157056
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test with apply
    task_include = TaskInclude()
    task_include.args = {'apply': {'block': []}}
    assert isinstance(task_include.build_parent_block(), Block)

    # Test without apply
    task_include = TaskInclude()
    task_include.args = {}
    assert isinstance(task_include.build_parent_block(), TaskInclude)

# Generated at 2022-06-17 08:34:51.372295
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    play_context = PlayContext()
    play_context.network_os = 'ios'


# Generated at 2022-06-17 08:35:00.056121
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 1: action is not in C._ACTION_INCLUDE
    task = TaskInclude()
    task.action = 'include_role'
    task.vars = {'a': 1}
    task._parent = Block()
    task._parent.get_vars = lambda: {'b': 2}
    task.args = {'c': 3}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3}

    # Test case 2: action is in C._ACTION_INCLUDE
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'a': 1}
    task._parent = Block()
    task._parent.get_vars = lambda: {'b': 2}

# Generated at 2022-06-17 08:35:20.303456
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import RoleTask
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.handlers import RoleHandler
    from ansible.playbook.become import Become

# Generated at 2022-06-17 08:35:31.376074
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with action 'include'
    data = {'action': 'include', 'name': 'test', 'tags': ['test'], 'invalid_attr': 'test'}
    ti = TaskInclude()
    ds = ti.preprocess_data(data)
    assert ds == {'action': 'include', 'name': 'test', 'tags': ['test']}

    # Test with action 'include_role'
    data = {'action': 'include_role', 'name': 'test', 'tags': ['test'], 'invalid_attr': 'test'}
    ti = TaskInclude()
    ds = ti.preprocess_data(data)
    assert ds == {'action': 'include_role', 'name': 'test', 'tags': ['test']}

    # Test with action 'import_role'


# Generated at 2022-06-17 08:35:40.697177
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:35:50.467669
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # create a play

# Generated at 2022-06-17 08:35:58.350133
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'x': 1, 'y': 2}
    task_include.vars = {'z': 3}
    task_include._parent = Block()
    task_include._parent.vars = {'a': 4}
    task_include._parent._parent = Block()

# Generated at 2022-06-17 08:36:09.187834
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    play_context = PlayContext()
    play_context._task_vars = dict(
        foo='bar',
        baz='qux',
        quux='corge',
    )

    task = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/include',
            foo='bar',
            baz='qux',
            quux='corge',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )


# Generated at 2022-06-17 08:36:16.578975
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:36:29.477969
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Create a dummy play
    play = Play.load({'name': 'test_play', 'hosts': 'all'})

    # Create a dummy role
    role = Role.load({'name': 'test_role'})

    # Create a dummy block
    block = Block.load({'name': 'test_block'}, play=play, task_include=None, role=role)



# Generated at 2022-06-17 08:36:40.544695
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test the method get_vars of class TaskInclude
    '''
    # Create a task include
    task_include = TaskInclude()

    # Create a parent task
    parent_task = Task()
    parent_task.vars = {'parent_var': 'parent_value'}
    parent_task.args = {'parent_arg': 'parent_value'}

    # Create a role
    role = Role()
    role.vars = {'role_var': 'role_value'}
    role.args = {'role_arg': 'role_value'}

    # Create a play
    play = Play()
    play.vars = {'play_var': 'play_value'}
    play.args = {'play_arg': 'play_value'}

    # Create a variable manager

# Generated at 2022-06-17 08:36:53.457928
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options of class TaskInclude
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test with action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task = task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'test': 'test'}}

    # Test with action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'

# Generated at 2022-06-17 08:37:16.580109
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:37:31.010714
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test for TaskInclude
    # Test for 'include' action
    ti = TaskInclude()
    task = Task()
    task.action = 'include'

# Generated at 2022-06-17 08:37:37.238093
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler.task import HandlerTask
    from ansible.playbook.handler.definition import HandlerDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

   

# Generated at 2022-06-17 08:37:47.714874
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with a valid task
    task = TaskInclude.load(
        dict(
            action='include_role',
            file='test.yml',
            apply=dict(
                block=dict(
                    tasks=[
                        dict(action='debug', msg='test')
                    ]
                )
            )
        ),
        block=Block(),
        role=None,
        task_include=None,
        variable_manager=VariableManager(),
        loader=DataLoader()
    )
    assert isinstance(task, TaskInclude)

# Generated at 2022-06-17 08:37:58.777185
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()