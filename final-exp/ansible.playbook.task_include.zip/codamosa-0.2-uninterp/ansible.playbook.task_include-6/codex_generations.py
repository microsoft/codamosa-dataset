

# Generated at 2022-06-17 08:27:59.753730
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with action 'include'
    ds = {'action': 'include', 'file': 'test.yml', 'tags': 'test', 'when': 'test'}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert ds['action'] == 'include'
    assert ds['file'] == 'test.yml'
    assert ds['tags'] == 'test'
    assert ds['when'] == 'test'

    # Test with action 'import_tasks'
    ds = {'action': 'import_tasks', 'file': 'test.yml', 'tags': 'test', 'when': 'test'}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)

# Generated at 2022-06-17 08:28:09.674507
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Test with action 'include'
    task_include = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            other_arg='other_arg_value',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )
    assert task_include.action == 'include'
    assert task_include.args == dict(
        file='/path/to/file',
        _raw_params='/path/to/file',
    )

    #

# Generated at 2022-06-17 08:28:18.948472
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict(action='include', file='foo.yml', apply=dict(a=1, b=2))
    task.check_options(task.load_data(data), data)

    data = dict(action='include', file='foo.yml', apply='foo')
    try:
        task.check_options(task.load_data(data), data)
    except AnsibleParserError as e:
        assert 'Expected a dict for apply but got str instead' in str(e)
    else:
        assert False, 'Expected AnsibleParserError'

    data = dict(action='include', file='foo.yml', apply=dict(a=1, b=2), foo='bar')

# Generated at 2022-06-17 08:28:31.463614
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 08:28:41.335118
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:28:49.504056
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with an action that does not support 'apply'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'apply': {'a': 'b'}}
    try:
        task.check_options(task, {})
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError not raised"

    # Test with an action that supports 'apply'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'apply': {'a': 'b'}}
    try:
        task.check_options(task, {})
    except AnsibleParserError:
        assert False, "AnsibleParserError raised"

    # Test with an action that supports 'apply' and a non-dict value
   

# Generated at 2022-06-17 08:29:02.706835
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'ignore_errors': True}}
    task = ti.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'ignore_errors': True}}


# Generated at 2022-06-17 08:29:11.898617
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play
    play_context = PlayContext()
    play_context._set_task_and_variable_override(task_override={'name': 'test_task_include_load'}, variable_override={'name': 'test_task_include_load'})

# Generated at 2022-06-17 08:29:21.110957
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    # Create a fake play
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World!'))),
        ]
    )
    play = Play.load

# Generated at 2022-06-17 08:29:34.061342
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:29:46.648433
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:30:00.403044
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action='debug', msg='{{shell_out.stdout}}'),
        ]
    )

# Generated at 2022-06-17 08:30:08.508894
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    task = TaskInclude.load(
        dict(
            include='foo.yml',
            name='test',
            foo='bar',
            tags=['tag1', 'tag2'],
            when='foo == bar',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    assert task.action == 'include'

# Generated at 2022-06-17 08:30:21.213863
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.task_include import BlockInclude as RoleBlockInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude

# Generated at 2022-06-17 08:30:31.473593
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a task with a parent block
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 'b'}
    task._parent = Block()
    task._parent.vars = {'c': 'd'}
    task._parent.get_vars = lambda: {'e': 'f'}

    # Create a play context
    play_context = PlayContext()
    play_context.vars = {'g': 'h'}

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'i': 'j'}


# Generated at 2022-06-17 08:30:43.417877
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:30:58.079078
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with a valid action
    task = TaskInclude()
    task.action = 'include'
    data = {'action': 'include', 'file': 'test.yml'}
    task.preprocess_data(data)
    assert data == {'action': 'include', 'file': 'test.yml'}

    # Test with an invalid action
    task.action = 'import_tasks'
    data = {'action': 'import_tasks', 'file': 'test.yml', 'foo': 'bar'}
    try:
        task.preprocess_data(data)
        assert False, 'AnsibleParserError not raised'
    except AnsibleParserError as e:
        assert str(e) == "'foo' is not a valid attribute for a TaskInclude"

    # Test with an invalid action and IN

# Generated at 2022-06-17 08:31:10.171850
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    # Create a play

# Generated at 2022-06-17 08:31:22.577877
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Test for action 'include'
    data = {
        'action': 'include',
        'file': 'test.yml',
        'tags': ['tag1', 'tag2'],
        'when': 'test',
        'vars': {'var1': 'value1', 'var2': 'value2'},
        'args': {'arg1': 'value1', 'arg2': 'value2'},
    }
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-17 08:31:32.521937
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    task_include._variable_manager = variable_manager
    task_include._loader = loader
    task_include._play_context = play_context

    assert task_include.get_vars() == {'a': 'b', 'c': 'd'}

    task_include.action = 'include_role'


# Generated at 2022-06-17 08:31:45.450990
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with valid options
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'_raw_params': 'test.yml', 'apply': {}}
    task = task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {}}

    # Test with invalid options
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'_raw_params': 'test.yml', 'apply': {}, 'invalid': 'option'}
    try:
        task = task.check_options(task, {})
        assert False, 'AnsibleParserError should have been raised'
    except AnsibleParserError:
        pass

    # Test with invalid options


# Generated at 2022-06-17 08:31:54.423156
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 08:32:06.360578
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test with invalid options
    data = dict(
        action='include',
        file='/path/to/file',
        invalid_option='foo',
    )
    task = TaskInclude.load(data)
    try:
        task.check_options(task, data)
        assert False, 'AnsibleParserError should be raised'
    except AnsibleParserError as e:
        assert str(e) == 'Invalid options for include: invalid_option'

    # Test with valid options

# Generated at 2022-06-17 08:32:18.047272
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    data = dict(
        action='include',
        file='test.yml',
        apply=dict(
            block=[]
        )
    )


# Generated at 2022-06-17 08:32:29.697858
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    # Create a play
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:32:40.963806
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a task with valid options
    task_data = {'action': 'include_role', 'file': 'test.yml', 'apply': {'tags': ['test']}}
    task = TaskInclude.load(task_data, variable_manager=VariableManager(), loader=DataLoader())
    assert task.action == 'include_role'
    assert task.args['file'] == 'test.yml'

# Generated at 2022-06-17 08:32:50.017368
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Create a TaskInclude object
    ti = TaskInclude()

    # Create a VariableManager object
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict(foo='bar')
    variable_manager._host_

# Generated at 2022-06-17 08:33:01.205789
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Test with valid options

# Generated at 2022-06-17 08:33:14.980163
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test with action 'include'
    task_data = {
        'action': 'include',
        'args': {
            'file': 'test.yml',
            'apply': {
                'block': [],
                'name': 'test',
                'ignore_errors': True,
            },
            'bad_arg': 'bad_arg',
        },
    }
    task = TaskInclude.load(task_data)

# Generated at 2022-06-17 08:33:25.480640
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test for 'include' action
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    task = task.check_options(task, None)
    assert task.args == {'_raw_params': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}

    # Test for 'include_role' action
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    task = task.check_options(task, None)

# Generated at 2022-06-17 08:33:42.366691
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'

# Generated at 2022-06-17 08:33:47.726206
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Test TaskInclude

# Generated at 2022-06-17 08:33:59.607600
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    class MockVariableManager(VariableManager):
        def __init__(self):
            self._fact_cache = dict()
            self._vars_cache = dict()
            self._extra_vars = dict()
            self._host_vars = dict

# Generated at 2022-06-17 08:34:06.453961
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 08:34:16.795604
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.loader = loader

    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    task_include._parent = None
    task_include._play = None
    task_include._role = None
    task_include._variable_manager = variable_manager
    task_include

# Generated at 2022-06-17 08:34:31.037122
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    task = Task()
    task.action = 'include'
    task.args = {'file': 'some_file', 'apply': {'a': 'b'}}
    task.block = Block()
    task.block.parent_block = Block()
    task.block.parent_block.parent_block = Block()
    task.block.parent_block.parent_block.parent_block = Block()

    task = TaskInclude.check_options(task, task)
    assert task.args['_raw_params'] == 'some_file'
    assert task.args['apply'] == {'a': 'b'}

    task.action = 'include_role'

# Generated at 2022-06-17 08:34:44.711358
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:34:56.699562
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.sentinel import Sentinel

    # Create a task with valid options

# Generated at 2022-06-17 08:35:03.246928
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    task_include = TaskInclude.load(dict(action='include', file='/tmp/test.yml'), variable_manager=variable_manager, loader=loader)
    assert task_include.get_vars() == dict(file='/tmp/test.yml')

    # Test for action 'include_role'
    task_include = TaskIn

# Generated at 2022-06-17 08:35:16.799479
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test TaskInclude
    # Test with action 'include'
    ti = TaskInclude()
    ds = {'action': 'include', 'file': 'test.yml', 'tags': ['test'], 'invalid_attr': 'invalid'}
    ti.preprocess_data(ds)
    assert ds == {'action': 'include', 'file': 'test.yml', 'tags': ['test']}

   

# Generated at 2022-06-17 08:35:40.325552
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '192.168.56.101'
    play_context.port = 22

# Generated at 2022-06-17 08:35:50.293962
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a dummy play

# Generated at 2022-06-17 08:35:58.236012
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    task = Task()
    task.action = 'include'
    task.args = dict()
    task.args['file'] = 'file'
    task.args['apply'] = dict()
    task.args['apply']['a'] = 'a'
    task.args['apply']['b'] = 'b'
    task.args['apply']['c'] = 'c'
    task.args['apply']['block'] = []

# Generated at 2022-06-17 08:36:05.941815
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a mock PlaybookExecutor
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 08:36:13.802669
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:36:21.864583
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-17 08:36:31.743831
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:36:41.752619
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a fake play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict())),
            dict(action=dict(module='debug', args=dict(msg='{{foo}} = {{bar}}'))),
        ]
    )
    play = Play.load(play_ds)


# Generated at 2022-06-17 08:36:53.558060
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:37:06.008102
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action='debug', msg='{{shell_out.stdout}}'),
        ]
    )


# Generated at 2022-06-17 08:37:51.033495
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Set the action of the TaskInclude object to 'include'
    task_include.action = 'include'

    # Set the args of the TaskInclude object
    task_include.args = {'a': 1, 'b': 2}

    # Set the vars of the TaskInclude object
    task_include.vars = {'c': 3, 'd': 4}

    # Set the parent of the TaskInclude object
    task_include._parent = Task()

    # Set the vars of the parent of the TaskInclude object
    task_include._parent.vars = {'e': 5, 'f': 6}

   