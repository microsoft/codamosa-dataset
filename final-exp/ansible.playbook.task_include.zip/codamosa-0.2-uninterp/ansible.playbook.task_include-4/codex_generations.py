

# Generated at 2022-06-17 08:28:03.191073
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

   

# Generated at 2022-06-17 08:28:08.273437
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    task_include = TaskInclude.load(dict(action='include', file='/path/to/file'), variable_manager=variable_manager, loader=loader)
    task_include.vars = dict(a=1, b=2)
    task_include.args = dict(c=3, d=4)
    assert task_include.get

# Generated at 2022-06-17 08:28:18.052619
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Block()
    task._parent.vars = {'e': 5, 'f': 6}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test for action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._

# Generated at 2022-06-17 08:28:29.048189
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test with valid options
    task = TaskInclude.check_options(Task(), {'action': 'include', 'file': 'test.yml'})
    assert task.args['_raw_params'] == 'test.yml'

    # Test with invalid options
    try:
        task = TaskInclude.check_options(Task(), {'action': 'include', 'file': 'test.yml', 'invalid_opt': 'test'})
        assert False
    except AnsibleParserError:
        pass

    # Test with valid options for include_role
    task = TaskInclude.check_options(Task(), {'action': 'include_role', 'name': 'test'})

# Generated at 2022-06-17 08:28:34.970441
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with valid options
    data = dict(
        file='file.yml',
        apply=dict(
            block=dict(
                name='test',
                tasks=[
                    dict(action='debug', msg='test'),
                ],
            ),
        ),
    )
    task = TaskInclude.load(data, block=Block(), role=None, task_include=None, variable_manager=VariableManager(), loader=DataLoader())
    assert isinstance(task, Task)
    assert task.action == 'include'
    assert task

# Generated at 2022-06-17 08:28:44.410943
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Setup
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_

# Generated at 2022-06-17 08:28:55.001632
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._extra_vars = combine_vars(loader=loader, variables=dict())


# Generated at 2022-06-17 08:29:08.641074
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars


# Generated at 2022-06-17 08:29:12.697738
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Create a task with valid options
    task_data = dict(
        action='include_tasks',
        file='/path/to/file',
        apply=dict(
            block=dict(
                rescue=dict(
                    block=dict(
                        ignore_errors=True,
                    ),
                ),
            ),
        ),
    )

# Generated at 2022-06-17 08:29:21.219191
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:29:38.660339
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 08:29:46.905559
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a dummy

# Generated at 2022-06-17 08:30:00.444694
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    # Test case 1: action is not in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.vars = dict()
    task_include.args = dict()
    task_include.vars['foo'] = 'bar'
   

# Generated at 2022-06-17 08:30:08.568675
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Create a Task object
    task = Task()
    # Set the parent of TaskInclude object to Task object
    task_include._parent = task
    # Set the vars of TaskInclude object
    task_include.vars = dict(a=1, b=2)
    # Set the args of TaskInclude object
    task_include.args = dict(c=3, d=4)
    # Set the action of TaskInclude object
    task_include.action = 'include'
    # Call the get_vars method of TaskInclude object
    all_vars = task_include.get_vars()
    # Check the result
    assert all_vars == dict(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 08:30:19.784396
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    assert ti.preprocess_data({'action': 'include_role', 'name': 'foo'}) == {'action': 'include_role', 'name': 'foo'}
    assert ti.preprocess_data({'action': 'include_role', 'name': 'foo', 'bad_key': 'bad_value'}) == {'action': 'include_role', 'name': 'foo'}
    assert ti.preprocess_data({'action': 'include_role', 'name': 'foo', 'bad_key': 'bad_value'}, fail_on_undefined=True) == {'action': 'include_role', 'name': 'foo', 'bad_key': 'bad_value'}

# Generated at 2022-06-17 08:30:30.880700
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Create a task with a valid action
    task = Task()
    task.action = 'include_role'
    task.args = {'name': 'test'}
    task.block = Block()
    task.block.role = None
    task.block.play = None
    task.block.vars = {}
    task.block.parent_block = None
    task.block.task_include = None
    task.block.role = None
    task.block.play

# Generated at 2022-06-17 08:30:42.696291
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.sentinel import Sentinel
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Create a task with a valid option
    data = AnsibleMapping(dict(file='foo.yml'))
    task = TaskInclude.load(data)
    assert task.args['_raw_params'] == 'foo.yml'

    # Create a task with an invalid option
    data = AnsibleMapping(dict(file='foo.yml', invalid_option='bar'))

# Generated at 2022-06-17 08:30:49.271516
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    # Test with valid data
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data)
    assert task.args['_raw_params'] == 'test.yml'

    # Test with invalid data
    data = {'action': 'include', 'file': 'test.yml', 'invalid': 'invalid'}
    try:
        task = TaskInclude.load(data)
        assert False
    except AnsibleParserError:
        assert True

    # Test with invalid data
    data = {'action': 'include', 'invalid': 'invalid'}

# Generated at 2022-06-17 08:30:59.714993
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:31:04.558595
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:31:19.595459
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict())),
            dict(action=dict(module='debug', args=dict(msg='{{foo}}'))),
        ]
    )
    play = Play.load

# Generated at 2022-06-17 08:31:29.131001
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    assert task_include.get_vars() == {'a': 'b', 'c': 'd'}

    # Test for action 'include_role'
    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    assert task_include.get_vars() == {'a': 'b', 'c': 'd'}

    # Test for action 'import_role'
    task_include

# Generated at 2022-06-17 08:31:37.032810
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task = ti.check_options(task, {})
    assert task.args['_raw_params'] == 'test.yml'
    assert 'file' not in task.args

    task = Task()
    task.action = 'include'

# Generated at 2022-06-17 08:31:49.428418
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 1: action is not in C._ACTION_INCLUDE
    task = TaskInclude()
    task.action = 'include_role'
    task.vars = {'a': 'b'}
    task.args = {'c': 'd'}
    assert task.get_vars() == {'a': 'b', 'c': 'd'}

    # Test case 2: action is in C._ACTION_INCLUDE
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'a': 'b'}
    task.args = {'c': 'd'}
    assert task.get_vars() == {'a': 'b', 'c': 'd'}

    # Test case 3: action is in C._ACTION_INCLUDE and

# Generated at 2022-06-17 08:32:04.220437
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Test with valid options
    data = {'action': 'include_role', 'name': 'foo', 'apply': {'a': 'b'}}
    task = TaskInclude.load(data, loader=loader, variable_manager=variable_manager)
    assert isinstance(task, TaskInclude)
    assert task.action == 'include_role'
    assert task.args == {'_raw_params': 'foo', 'apply': {'a': 'b'}}

    # Test with invalid options

# Generated at 2022-06-17 08:32:15.643079
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:32:29.287870
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with 'include' action
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {}}
    task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {}}

    # Test with 'include_role' action
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'file': 'test.yml', 'apply': {}}
    task.check_options(task, {})

# Generated at 2022-06-17 08:32:39.381260
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:32:48.996362
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.utils.sentinel import Sentinel

    # Test with a valid task
    task = Task()
    task.action = 'include'
    task.args = {'_raw_params': 'test.yml', 'tags': ['tag1', 'tag2']}
    task = TaskInclude.check_options(task, task)
    assert task.args == {'_raw_params': 'test.yml', 'tags': ['tag1', 'tag2']}

    # Test with a valid task and apply
    task = Task()
    task.action = 'include'

# Generated at 2022-06-17 08:32:56.677587
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()

    task = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            apply=dict(
                block=dict(
                    name='test',
                    tags=['tag1', 'tag2'],
                    when='{{ foo }} == "bar"',
                ),
            ),
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    vars = task.get_

# Generated at 2022-06-17 08:33:14.937570
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'a': 1, 'b': 2}
    task.args = {'c': 3, 'd': 4}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    # Test for action 'import_tasks'
    task = TaskInclude()
    task.action = 'import_tasks'
    task.vars = {'a': 1, 'b': 2}
    task.args = {'c': 3, 'd': 4}
    assert task.get_vars() == {'a': 1, 'b': 2}

    # Test for action 'include_role'
    task = TaskInclude

# Generated at 2022-06-17 08:33:25.449995
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 'b', 'c': 'd'}
    task.vars = {'a': 'b', 'c': 'd'}
    assert task.get_vars() == {'a': 'b', 'c': 'd'}
    task.action = 'include_role'
    assert task.get_vars() == {'a': 'b', 'c': 'd'}
    task.action = 'import_role'
    assert task.get_vars() == {'a': 'b', 'c': 'd'}
    task.action = 'import_tasks'
    assert task.get_vars() == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 08:33:34.282116
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'_raw_params': 'test.yml'}
    task_include.vars = {'a': 1, 'b': 2}
    task_include._variable_manager = variable_manager
    task_

# Generated at 2022-06-17 08:33:40.416018
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
   

# Generated at 2022-06-17 08:33:50.568990
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ foo }}'))),
            dict(action=dict(module='debug', args=dict(msg='{{ bar }}'))),
        ],
    )

# Generated at 2022-06-17 08:34:01.833553
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:34:07.932387
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Set the attributes of the TaskInclude object
    task_include._parent = None
    task_include.vars = {'var1': 'value1', 'var2': 'value2'}
    task_include.args = {'arg1': 'value1', 'arg2': 'value2'}
    task_include.action = 'include'
    task_include._play_context = play_context
    task_include._variable_manager = variable_manager

    # Test the get_v

# Generated at 2022-06-17 08:34:18.603565
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler.task import HandlerTask
    from ansible.playbook.handler.definition import HandlerDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 08:34:31.560330
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    data = {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:34:44.745573
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:35:04.908828
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test TaskInclude
    # Test with action 'include'
    data = {'action': 'include', 'file': 'test.yml'}

# Generated at 2022-06-17 08:35:17.230397
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 08:35:30.846042
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:35:40.257159
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ foo }}'))),
            dict(action=dict(module='debug', args=dict(msg='{{ bar }}'))),
        ]
    )
    play = Play.load(play_ds, variable_manager=VariableManager())
    role = Role.load(dict(name='test_role', tasks=play_ds['tasks']), play=play)


# Generated at 2022-06-17 08:35:50.498241
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:35:57.748022
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    assert task_include.get_vars() == {'a': 'b', 'c': 'd'}

    # Test with action 'include_role'
    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    assert task_include.get_vars() == {'a': 'b', 'c': 'd'}

    # Test with action 'import_tasks'
    task_

# Generated at 2022-06-17 08:36:05.618250
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.defaults import RoleDefaults

# Generated at 2022-06-17 08:36:13.510234
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:36:19.407590
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    task = TaskInclude.load(
        dict(
            include='/path/to/file',
            name='test',
            action='include',
            ignore_errors=True,
            tags=['tag1', 'tag2'],
            when='1==1',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    assert task.action == 'include'
    assert task.args['_raw_params'] == '/path/to/file'
    assert task.name == 'test'
   

# Generated at 2022-06-17 08:36:30.253145
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskIncludeRole
    from ansible.playbook.role.task_include import HandlerTaskIncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars



# Generated at 2022-06-17 08:36:53.205972
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # create a task include
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include._loader = loader
    task_include._variable_manager = variable_manager
    task_include._play_context = play_context

    # create a block
    block = Block()
    block.vars = {'c': 'd'}
    block.block = [task_include]

# Generated at 2022-06-17 08:36:59.587974
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

    # Create a fake play

# Generated at 2022-06-17 08:37:07.233968
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # test case 1: action is not in C._ACTION_INCLUDE
    task = TaskInclude.load(dict(action='shell', args=dict(cmd='ls')), variable_manager=variable_manager, loader=loader)
    all_vars = task.get_vars()

# Generated at 2022-06-17 08:37:16.483312
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)



# Generated at 2022-06-17 08:37:30.975761
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with a TaskInclude instance
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo.yml', 'apply': {'a': 'b'}}
    task = ti.check_options(task, {})
    assert task.args == {'_raw_params': 'foo.yml', 'apply': {'a': 'b'}}

    # Test with a TaskInclude instance and a bad option
    ti = TaskInclude()
    task = Task()
    task.action = 'include'

# Generated at 2022-06-17 08:37:36.536701
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a play

# Generated at 2022-06-17 08:37:47.683293
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-17 08:37:58.776993
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleParserError