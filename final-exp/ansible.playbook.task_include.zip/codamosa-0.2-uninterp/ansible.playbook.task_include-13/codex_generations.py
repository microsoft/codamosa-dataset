

# Generated at 2022-06-17 08:27:57.867820
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import add_directory

# Generated at 2022-06-17 08:28:04.266574
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test for action 'include'

# Generated at 2022-06-17 08:28:13.203814
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()

    task = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            foo='bar',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    assert task.action == 'include'
    assert task.args['file'] == '/path/to/file'
    assert task.args['foo'] == 'bar'


# Generated at 2022-06-17 08:28:22.218911
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    data = {'action': 'include', 'name': 'test'}
    assert task_include.preprocess_data(data) == data
    data = {'action': 'include', 'name': 'test', 'invalid_key': 'invalid_value'}
    assert task_include.preprocess_data(data) == {'action': 'include', 'name': 'test'}
    data = {'action': 'include_role', 'name': 'test', 'invalid_key': 'invalid_value'}
    assert task_include.preprocess_data(data) == {'action': 'include_role', 'name': 'test'}
    data = {'action': 'import_role', 'name': 'test', 'invalid_key': 'invalid_value'}
   

# Generated at 2022-06-17 08:28:32.539026
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a TaskInclude object
    ti = TaskInclude()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a DataLoader object
    loader = DataLoader()

    # Create a dict with valid options

# Generated at 2022-06-17 08:28:42.386791
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with 'include' action

# Generated at 2022-06-17 08:28:50.342644
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = {'action': 'include', 'tags': 'test', 'when': 'test'}
    ds = ti.preprocess_data(ds)
    assert ds == {'action': 'include', 'tags': 'test', 'when': 'test'}

    ds = {'action': 'include_role', 'tags': 'test', 'when': 'test'}
    ds = ti.preprocess_data(ds)
    assert ds == {'action': 'include_role', 'tags': 'test', 'when': 'test'}

    ds = {'action': 'import_role', 'tags': 'test', 'when': 'test'}
    ds = ti.preprocess_data(ds)

# Generated at 2022-06-17 08:28:58.627437
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude

    # Test for action 'include'
    # Test for action 'include_tasks'
    # Test for action 'include_role'
    # Test for action 'import_tasks'
    # Test for action 'import_role'

# Generated at 2022-06-17 08:29:04.311552
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:29:13.261525
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    task_include._parent = Block()
    task_include

# Generated at 2022-06-17 08:29:30.282606
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    variable_manager.set_play_context(play_context)

    # Test for action 'include'

# Generated at 2022-06-17 08:29:40.504108
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Test with empty args
    task = TaskInclude()
    task.args = {}
    task.action = 'include'
    task = task.check_options(task, {})
    assert task.args == {'_raw_params': None}

    # Test with invalid args
    task = TaskInclude()

# Generated at 2022-06-17 08:29:52.251288
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    parent = Block()
    parent.vars = {'e': 5, 'f': 6}
    task._parent = parent
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test with action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}


# Generated at 2022-06-17 08:30:04.168177
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:30:10.859570
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with a valid task
    task_data = {
        'action': 'include_tasks',
        'file': 'some_file',
        'apply': {
            'block': [],
            'name': 'some_name',
            'tags': ['some_tag'],
            'when': 'some_condition',
        },
    }

# Generated at 2022-06-17 08:30:19.386896
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test with apply
    task_include = TaskInclude()
    task_include.args = {'apply': {'block': []}}
    task_include._parent = 'parent'
    task_include._role = 'role'
    task_include._variable_manager = 'variable_manager'
    task_include._loader = 'loader'
    assert isinstance(task_include.build_parent_block(), Block)

    # Test without apply
    task_include = TaskInclude()
    task_include.args = {}
    assert task_include.build_parent_block() is task_include

# Generated at 2022-06-17 08:30:25.680453
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:30:34.813059
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}
    task_include._parent = Task()
    task_include._parent.vars = {'e': 5, 'f': 6}
    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test with action 'include_role'
    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.args = {'a': 1, 'b': 2}
   

# Generated at 2022-06-17 08:30:46.210404
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task include with a parent task
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'_raw_params': 'test.yml'}
    task_include.vars = {'a': 'b'}

    parent_task = Task()
    parent_task.action = 'debug'
    parent_task.args = {'msg': 'test'}
    parent_task.vars = {'c': 'd'}
    parent_task._parent = None
    parent_task._role = None
    parent_task._play = None
    parent_task._loader = None
    parent_task._block = None
    parent_

# Generated at 2022-06-17 08:30:59.266881
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:31:12.655897
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Test for action 'include'
    data = dict(
        action='include',
        file='/path/to/include',
        tags=['tag1', 'tag2'],
        when='when1',
        var1='var1',
        var2='var2',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.get_vars() == dict(file='/path/to/include', var1='var1', var2='var2')



# Generated at 2022-06-17 08:31:24.252990
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:31:30.856718
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVarsVars


# Generated at 2022-06-17 08:31:37.626853
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a task with a parent block
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task._parent = Block()
    task._parent.vars = {'c': 3, 'd': 4}

    # Create a play context
    play_context = PlayContext()
    play_context.vars = {'e': 5, 'f': 6}

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'g': 7, 'h': 8}

# Generated at 2022-06-17 08:31:49.428470
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, loader=loader, variable_manager=variable_manager)
    role = Role().load({}, play=play, variable_manager=variable_manager, loader=loader)
    block = Block().load({}, play=play, task_include=None, role=role, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:32:04.218630
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude as RoleHandlerTaskInclude

    # Create a fake play

# Generated at 2022-06-17 08:32:13.415009
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader


# Generated at 2022-06-17 08:32:24.974178
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.loader = loader

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include._variable_manager = variable_manager
    task_include._loader = loader
    task_include._play_context = play_context

    # test with no parent
    assert task_include.get_vars()

# Generated at 2022-06-17 08:32:37.295531
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    # Create a task
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}

    # Create a block
    block = Block()
    block.block = [task]

    # Create a play
    play = Play()

# Generated at 2022-06-17 08:32:47.826197
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:33:02.813577
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 08:33:15.992933
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    assert ti.preprocess_data({'action': 'include', 'file': 'test.yml'}) == {'action': 'include', 'file': 'test.yml'}

# Generated at 2022-06-17 08:33:29.394517
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:33:35.785965
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()
    play_context._set_inventory(inventory)

    # test for 'include'
    task_include = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            tags=['tag1', 'tag2'],
            when='when1',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )
   

# Generated at 2022-06-17 08:33:43.723818
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude

    # Test for action 'include'
    # Test for action 'include_role'
    # Test for action 'import_role'
    # Test for action 'import_tasks'
    # Test for action 'include_tasks'
    # Test for action 'include_vars'
    # Test for action 'include_vars'
    # Test for action 'include

# Generated at 2022-06-17 08:33:51.760753
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:34:02.079356
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 08:34:11.347235
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method

# Generated at 2022-06-17 08:34:21.962537
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
   

# Generated at 2022-06-17 08:34:32.989826
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:34:56.660647
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:35:07.112677
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with valid options
    task = TaskInclude()
    data = {'action': 'include_tasks', 'file': 'test.yml'}
    task.check_options(task.load_data(data), data)

    # Test with invalid options
    data = {'action': 'include_tasks', 'file': 'test.yml', 'invalid': 'option'}
    try:
        task.check_options(task.load_data(data), data)
    except AnsibleParserError as e:
        assert e.message == 'Invalid options for include_tasks: invalid'
    else:
        assert False, 'AnsibleParserError not raised'

    # Test with invalid options for action 'import_tasks'

# Generated at 2022-06-17 08:35:18.990558
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test for TaskInclude
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'file.yml', 'apply': {'a': 'b'}}
    task.check_options(task, None)
    assert task.args == {'_raw_params': 'file.yml', 'apply': {'a': 'b'}}

    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'file': 'file.yml', 'apply': {'a': 'b'}}
    task.check_options(task, None)

# Generated at 2022-06-17 08:35:31.201025
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:35:40.586658
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:35:52.038392
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 08:35:57.293454
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test with apply
    task = TaskInclude()
    task.args = {'apply': {'block': []}}
    assert isinstance(task.build_parent_block(), Block)

    # Test without apply
    task = TaskInclude()
    task.args = {}
    assert isinstance(task.build_parent_block(), TaskInclude)

# Generated at 2022-06-17 08:36:05.259499
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude

# Generated at 2022-06-17 08:36:11.734174
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:36:18.773842
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:36:56.581429
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test with 'include' action
    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=dict(
                name='test',
                tags=['tag1', 'tag2'],
            )
        )
    )

# Generated at 2022-06-17 08:37:06.544767
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test for action 'include'

# Generated at 2022-06-17 08:37:19.080955
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test with a valid task
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo.yml'}
    task = TaskInclude.check_options(task, task)
    assert task.args['_raw_params'] == 'foo.yml'

    # Test with a valid task and apply
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo.yml', 'apply': {'a': 'b'}}
    task = TaskInclude.check_options(task, task)
    assert task.args['_raw_params'] == 'foo.yml'

# Generated at 2022-06-17 08:37:31.951331
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'

# Generated at 2022-06-17 08:37:37.292863
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}
    task_include._parent = Block()
    task_include._parent.vars = {'e': 5, 'f': 6}
    task_include._parent._play = PlayContext()
    task_include._parent._play.vars = {'g': 7, 'h': 8}
    task_include._variable_manager = VariableManager()

# Generated at 2022-06-17 08:37:45.950375
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()