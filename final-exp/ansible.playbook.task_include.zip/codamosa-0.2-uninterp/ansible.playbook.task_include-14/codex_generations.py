

# Generated at 2022-06-17 08:27:57.088829
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:28:03.598321
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True

# Generated at 2022-06-17 08:28:12.678540
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:28:19.627942
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a task with valid options
    task_data = {
        'action': 'include_role',
        'file': 'test.yml',
        'apply': {
            'tags': ['tag1', 'tag2'],
            'when': 'when1'
        }
    }
    task = TaskInclude.load(task_data)
    assert task.action == 'include_role'

# Generated at 2022-06-17 08:28:27.836492
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:28:38.688588
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude

    # Test with apply
    apply_attrs = {'apply': {'name': 'test', 'block': []}}
    p_block = Block(play=Play().load({'name': 'test'}))
    ti = TaskInclude(block=p_block, task_include=TaskInclude())
    ti.args = apply_attrs
    assert ti.build_parent_block() is not p_block

    # Test without apply


# Generated at 2022-06-17 08:28:47.247497
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:28:58.264164
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict())),
            dict(action=dict(module='debug', args=dict(msg='{{foo}}'))),
        ]
    )
    play = Play.load

# Generated at 2022-06-17 08:29:09.758169
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    task = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            vars=dict(
                foo='bar',
            ),
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

# Generated at 2022-06-17 08:29:20.966225
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:29:32.933525
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with action 'include'
    task = TaskInclude()
    ds = {
        'action': 'include',
        'file': 'test.yml',
        'tags': ['tag1', 'tag2'],
        'when': 'test_condition',
        'invalid_attr': 'invalid_value',
    }
    ds = task.preprocess_data(ds)
    assert ds['action'] == 'include'
    assert ds['file'] == 'test.yml'
    assert ds['tags'] == ['tag1', 'tag2']
    assert ds['when'] == 'test_condition'
    assert 'invalid_attr' not in ds

    # Test with action 'include_role'
    task = TaskInclude()

# Generated at 2022-06-17 08:29:42.245368
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude

    # Test for TaskInclude
    ti = TaskInclude()

# Generated at 2022-06-17 08:29:49.425101
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:30:00.648969
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:30:08.701427
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:30:14.806263
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with a TaskInclude object
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'block': []}}
    task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'block': []}}

    # Test with a TaskInclude object with invalid options

# Generated at 2022-06-17 08:30:23.748483
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    ti = TaskInclude()
    # Create a parent task
    parent = Task()
    # Set the parent of the TaskInclude object
    ti._parent = parent
    # Set the vars of the TaskInclude object
    ti.vars = dict(a=1, b=2)
    # Set the args of the TaskInclude object
    ti.args = dict(c=3, d=4)
    # Set the action of the TaskInclude object
    ti.action = 'include'
    # Get the vars of the TaskInclude object
    vars = ti.get_vars()
    # Check the result
    assert vars == dict(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 08:30:34.101255
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:30:44.139600
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    block = Block()
    block._play = None
    block._role = None
    block._task_include = None
    block._loader = loader
    block._variable_manager = variable_manager
    block._parent = None
    block._play_context = play_context

    task_include = TaskInclude(block=block)


# Generated at 2022-06-17 08:30:58.158035
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test with valid options
    data = dict(
        action='include',
        file='test.yml',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'

# Generated at 2022-06-17 08:31:12.372363
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:31:18.887946
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '192.168.56.20'
    play_context.port = 22

# Generated at 2022-06-17 08:31:31.310423
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:31:42.955373
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test for TaskInclude

# Generated at 2022-06-17 08:31:48.913265
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    ti = TaskInclude()
    # Set the action to 'include'
    ti.action = 'include'
    # Set the args to a dictionary with a key 'a' and value 'b'
    ti.args = {'a': 'b'}
    # Set the vars to a dictionary with a key 'c' and value 'd'
    ti.vars = {'c': 'd'}
    # Set the parent to a TaskInclude object
    ti._parent = TaskInclude()
    # Set the parent's vars to a dictionary with a key 'e' and value 'f'
    ti._parent.vars = {'e': 'f'}
    # Call the get_vars method
    vars = ti.get_vars()
    # Assert that the returned vars

# Generated at 2022-06-17 08:31:56.577877
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    ds = {'action': 'include', 'file': 'test.yml', 'tags': ['test'], 'invalid_attr': 'test'}
    ds = task_include.preprocess_data(ds)
    assert ds == {'action': 'include', 'file': 'test.yml', 'tags': ['test']}

    # Test for action 'include_role'
    task_include = TaskInclude()
    task_include.action = 'include_role'
    ds = {'action': 'include_role', 'file': 'test.yml', 'tags': ['test'], 'invalid_attr': 'test'}
    ds = task_include.preprocess_data

# Generated at 2022-06-17 08:32:07.588313
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    task_include = TaskInclude()
    task_include.vars = {'a': 'b'}
    task_include.args = {'_raw_params': 'test.yml'}
    task_include.action = 'include'
    task_include.block = Block()

# Generated at 2022-06-17 08:32:19.396544
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var

    # Test TaskInclude.

# Generated at 2022-06-17 08:32:26.146979
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    # Test with valid options
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'tags': ['test']}}
    task.check_options(task, {})

# Generated at 2022-06-17 08:32:37.978326
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with valid options
    task_data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': {
            'block': [],
            'name': 'test',
            'tags': ['test'],
            'when': 'test'
        }
    }
    task = TaskInclude.load(task_data, block=Block(), variable_manager=VariableManager(), loader=DataLoader())
    assert task.action == 'include'

# Generated at 2022-06-17 08:33:01.369189
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '192.168.56.1'
    play_context.port = 22
    play_context.remote_

# Generated at 2022-06-17 08:33:15.020992
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleParserError

    # Create a task with valid options
    task_data = {'action': 'include_tasks', 'file': 'tasks.yml'}
    task = TaskInclude.load(task_data)
    assert task.args == {'_raw_params': 'tasks.yml'}

    # Create a task with

# Generated at 2022-06-17 08:33:25.511164
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude

    # Test for TaskInclude
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'file': 'test.yml'}
    task_include.vars = {'test': 'test'}
    task_include.tags = ['test']
    task_include.when = 'test'

# Generated at 2022-06-17 08:33:35.548377
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    # Test with action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert isinstance(task, TaskInclude)
    assert isinstance(task._parent, Block)
    assert task._parent._parent is None
    assert task._parent._

# Generated at 2022-06-17 08:33:43.583574
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test the method get_vars of class TaskInclude
    '''
    # Create a task include with action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'

    # Create a parent block
    parent_block = Block()
    parent_block.vars = {'parent_block_var': 'parent_block_value'}

    # Create a role
    role = Role()
    role.vars = {'role_var': 'role_value'}

    # Create a play
    play = Play()
    play.vars = {'play_var': 'play_value'}

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'extra_var': 'extra_value'}

    # Set

# Generated at 2022-06-17 08:33:51.649802
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with a static include
    ti = TaskInclude()
    ds = {'action': 'include', 'name': 'test'}
    ds = ti.preprocess_data(ds)
    assert ds['action'] == 'include'
    assert ds['name'] == 'test'

    # Test with a dynamic include
    ti = TaskInclude()
    ds = {'action': 'include_tasks', 'name': 'test'}
    ds = ti.preprocess_data(ds)
    assert ds['action'] == 'include_tasks'
    assert ds['name'] == 'test'

    # Test with a static include and an invalid attribute
    ti = TaskInclude()
    ds = {'action': 'include', 'name': 'test', 'invalid': 'value'}
   

# Generated at 2022-06-17 08:34:02.021038
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=dict(
                name='test',
                tags=['test'],
                when='test',
            )
        )
    )


# Generated at 2022-06-17 08:34:11.346998
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task with a parent block
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task._parent = Block()
    task._parent.vars = {'a': 3, 'c': 4}
    task._parent._parent = Block()
    task._parent._parent.vars = {'a': 5, 'd': 6}

    # Create a play context
    play_context = PlayContext()
    play_context.vars = {'a': 7, 'e': 8}

    # Create a variable manager
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:34:21.961316
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.handlers import RoleHandlers
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 08:34:32.995718
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Test with valid options
    task_data = {'action': 'include', 'file': 'test.yml', 'apply': {'tags': ['test']}}
    task = TaskInclude.load(task_data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:35:06.603252
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = dict(a=1, b=2)
    task.vars = dict(c=3, d=4)
    task._parent = Block()
    task._parent.vars = dict(e=5, f=6)
    assert task.get_vars() == dict(a=1, b=2, c=3, d=4, e=5, f=6)

    # Test for action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = dict(a=1, b=2)
    task.vars = dict(c=3, d=4)
    task._parent = Block()

# Generated at 2022-06-17 08:35:13.198193
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Setup
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Block()
    task._parent.vars = {'e': 5, 'f': 6}
    task._parent._play = PlayContext()
    task._parent._play.vars = {'g': 7, 'h': 8}
    task._parent._play.variable_manager = VariableManager()
    task._parent._play.variable_manager.extra_vars = {'i': 9, 'j': 10}

    # Test
    assert task.get_v

# Generated at 2022-06-17 08:35:23.211898
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler.include import HandlerInclude

    p = Play().load({'name': 'test_play', 'hosts': 'all'}, variable_manager=None, loader=None)
    t = Task().load({'name': 'test_task', 'action': 'include'}, block=p, task_include=None, variable_manager=None, loader=None)
    t.args = {'a': 1, 'b': 2}
    p.block = [t]

# Generated at 2022-06-17 08:35:32.162776
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task include
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2, 'tags': 'tag1'}
    task_include.vars = {'c': 3, 'd': 4, 'tags': 'tag2'}

    # Create a parent block
    parent_block = Block()
    parent_block.vars = {'e': 5, 'f': 6, 'tags': 'tag3'}
    parent_block.parent_block = None

    # Create a play
    play_context = PlayContext()

# Generated at 2022-06-17 08:35:40.517443
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:35:50.383720
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:35:58.292044
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a fake play

# Generated at 2022-06-17 08:36:05.999860
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(loader.load_inventory(host_list=['localhost']))
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.set_options(direct={'no_log': True})

    # Test with action 'include'

# Generated at 2022-06-17 08:36:13.828859
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:36:28.102127
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    task_include = TaskInclude()
    task_include._play = PlayContext()
    task_include._play.action = 'include'

    # Test with 'include' action
    ds = {'action': 'include', 'file': 'test.yml'}
    assert task_include.preprocess_data(ds) == {'action': 'include', 'file': 'test.yml'}

    # Test with 'include_role' action
    ds = {'action': 'include_role', 'file': 'test.yml'}
    assert task_include.preprocess_data(ds) == {'action': 'include_role', 'file': 'test.yml'}

    # Test with 'import_role' action

# Generated at 2022-06-17 08:37:07.260429
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:37:16.484722
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with valid options
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'foo': 'bar'}}
    task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'foo': 'bar'}}

    # Test with invalid options
    task.args = {'file': 'test.yml', 'apply': {'foo': 'bar'}, 'invalid_option': 'value'}
    try:
        task.check_options(task, {})
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('AnsibleParserError not raised')

    # Test with invalid apply value

# Generated at 2022-06-17 08:37:30.977174
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test with apply
    task_include = TaskInclude()
    task_include.args = {'apply': {'block': []}}
    task_include._parent = 'parent'
    task_include._role = 'role'
    task_include._variable_manager = 'variable_manager'
    task_include._loader = 'loader'
    p_block = task_include.build_parent_block()
    assert p_block.block == []
    assert p_block._parent == 'parent'
    assert p_block._role == 'role'
    assert p_block._variable_manager == 'variable_manager'
    assert p_block._loader == 'loader'
    assert p_block._play == 'parent'
    assert p_block._task_include == task_include
    assert p_block.vars == {}

# Generated at 2022-06-17 08:37:44.352040
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsGroupVarsVars
    from ansible.vars.hostvars import HostVarsGroupVarsGroupVars
    from ansible.vars.hostvars import HostVarsGroupVarsGroupVarsVars
    from ansible.vars.hostvars import HostV