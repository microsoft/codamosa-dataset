

# Generated at 2022-06-17 08:28:02.680613
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Test for TaskInclude
    task = TaskInclude()
    # Test for TaskInclude with action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    task.action = 'include'

# Generated at 2022-06-17 08:28:12.633905
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.loader = loader

    # Test with a valid include
    data = dict(
        action='include',
        file='/path/to/file'
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:28:19.601909
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.import_role import ImportRole
    from ansible.playbook.role.include_role import IncludeRole
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.handlers import RoleHandlers

# Generated at 2022-06-17 08:28:25.206456
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a dummy play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World!'))),
        ]
    )
    play = Play.load(play_ds)

    # Create a dummy role

# Generated at 2022-06-17 08:28:37.185048
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with static include
    task = TaskInclude.load(dict(
        include='test.yml',
        action='include',
        tags=['tag1', 'tag2'],
        when='test',
    ), variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:28:46.028893
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a Block object
    block = Block()

    # Create a Task object
    task = Task()

    # Create a Play object
    play = Play()

    # Create a Role object
    role = Role()

    # Create a IncludeRole object
    include_role = IncludeRole()

    #

# Generated at 2022-06-17 08:28:57.318611
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role = Role().load({}, variable_manager=variable_manager, loader=loader)
    block = Block().load({}, play=play, task_include=None, role=role, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:29:09.368364
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with action 'include'
    ds = {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2']}
    task = TaskInclude()
    ds = task.preprocess_data(ds)
    assert ds == {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2']}

    # Test with action 'import_tasks'
    ds = {'action': 'import_tasks', 'file': 'test.yml', 'tags': ['tag1', 'tag2']}
    task = TaskInclude()
    ds = task.preprocess_data(ds)

# Generated at 2022-06-17 08:29:20.936382
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:29:33.985218
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-17 08:29:46.813475
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'_raw_params': 'test.yml', 'apply': {'test': 'test'}}
    task = ti.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'test': 'test'}}


# Generated at 2022-06-17 08:30:00.445354
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_context = PlayContext()
    play_context._vars_plugins = []
    play_context._vars_files = []
    play_context._vars_prompts = {}
    play_context._vars_files_params = {}
    play_context._vars_files_ignore_errors = False
    play_context._vars_files_encoding = 'utf-8'
    play_context._vars_files_extensions = ['.yml', '.yaml', '.json']

# Generated at 2022-06-17 08:30:09.817972
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': {
            'name': 'test',
            'tags': ['test'],
            'when': 'test'
        }
    }


# Generated at 2022-06-17 08:30:21.653100
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    play_context = PlayContext()


# Generated at 2022-06-17 08:30:31.416864
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 08:30:43.417713
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task = ti.check_options(task, None)
    assert task.args == {'_raw_params': 'test.yml'}

    task.args = {'file': 'test.yml', 'apply': {'foo': 'bar'}}

# Generated at 2022-06-17 08:30:58.075196
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 08:31:10.170987
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:31:22.577968
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user

# Generated at 2022-06-17 08:31:32.127789
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler.task import HandlerTask
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.become_task import BecomeTask


# Generated at 2022-06-17 08:31:49.337031
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        tags=['tag1', 'tag2'],
        when='condition',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    vars = task.get_vars()

# Generated at 2022-06-17 08:31:56.860110
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test for action 'include'

# Generated at 2022-06-17 08:32:07.792752
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test with a valid task
    task = Task()
    task.action = 'include_role'
    task.args = {'file': 'foo.yml', 'apply': {'a': 1, 'b': 2}}
    task = TaskInclude.check_options(task, task)
    assert task.args == {'_raw_params': 'foo.yml', 'apply': {'a': 1, 'b': 2}}

    # Test with an invalid task
    task = Task()
    task.action = 'include_role'
    task.args = {'file': 'foo.yml', 'apply': {'a': 1, 'b': 2}, 'invalid': 'option'}

# Generated at 2022-06-17 08:32:19.436179
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.tasks import Task as RoleTask
    from ansible.playbook.role.handlers import Handler as RoleHandler
    from ansible.playbook.role.defaults import Default as RoleDefault

# Generated at 2022-06-17 08:32:26.164979
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:32:38.015739
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}
    task_include._variable_manager = variable_manager
    task_include._loader = loader
    task_include._play_context = play_context

    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4}



# Generated at 2022-06-17 08:32:48.271290
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test for TaskInclude
    task = TaskInclude()
    data = {'action': 'include', 'file': 'some_file'}
    task = task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == 'some_file'

    data = {'action': 'include', 'file': 'some_file', 'apply': {'some_attr': 'some_value'}}
    task = task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == 'some_file'

# Generated at 2022-06-17 08:33:00.677534
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        roles=[
            'role1',
            'role2',
        ],
    )
    play = Play.load(play_ds, variable_manager=VariableManager(), loader=None)


# Generated at 2022-06-17 08:33:14.981656
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    # Test TaskInclude.check_options
    # Test TaskInclude.

# Generated at 2022-06-17 08:33:25.480780
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=dict(
                name='parent block',
                tasks=[
                    dict(action='debug', msg='hello world'),
                ],
            ),
        ),
    )

   

# Generated at 2022-06-17 08:33:43.526469
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:33:51.591927
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    ti = TaskInclude()
    ds = dict(action='include', file='/tmp/foo.yml')
    ti.preprocess_data(ds)
    assert ds == dict(action='include', _raw_params='/tmp/foo.yml')

    ds = dict(action='include_role', file='/tmp/foo.yml')
    ti.pre

# Generated at 2022-06-17 08:34:01.991313
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 08:34:08.050151
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a play

# Generated at 2022-06-17 08:34:17.797347
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:34:31.341496
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test for action 'include'
    data = {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    task = TaskInclude()
    result = task.preprocess_data(data)
    assert result == {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}

    # Test for action 'include_role'
    data = {'action': 'include_role', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    task = TaskInclude()
    result = task.preprocess_data(data)

# Generated at 2022-06-17 08:34:44.713351
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:34:56.698869
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'_raw_params': 'test_include.yml'}
    task_include.vars = {'var1': 'value1'}
    task_include.set_loader(loader=loader)

# Generated at 2022-06-17 08:35:07.112466
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-17 08:35:18.953001
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:35:49.488957
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:36:01.468858
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # test for action 'include'
    task_include = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            apply=dict(
                block=[]
            ),
            tags=['tag1', 'tag2'],
            when='when'
        ),
        variable_manager=variable_manager,
        loader=loader
    )

# Generated at 2022-06-17 08:36:09.523015
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Block()
    task._parent.vars = {'e': 5, 'f': 6}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test for action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._

# Generated at 2022-06-17 08:36:17.846995
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Set the action to 'include'
    task_include.action = 'include'
    # Set the vars to {'a': 1, 'b': 2}
    task_include.vars = {'a': 1, 'b': 2}
    # Set the args to {'c': 3, 'd': 4}
    task_include.args = {'c': 3, 'd': 4}
    # Set the parent to a Block object
    task_include._parent = Block()
    # Set the parent's vars to {'e': 5, 'f': 6}
    task_include._parent.vars = {'e': 5, 'f': 6}
    # Get the vars
    vars = task_include.get_vars()

# Generated at 2022-06-17 08:36:29.732975
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a task with an invalid option
    task_data = {
        'action': 'include_tasks',
        'args': {
            'file': 'foo.yml',
            'bad_option': 'bad_value'
        }
    }
    task = TaskInclude.load(task_data, block=Block(), role=None, task_include=None, variable_manager=VariableManager(), loader=DataLoader())
    # Check that the task is not valid
    assert not task.is_valid()
    # Check that the error

# Generated at 2022-06-17 08:36:40.574935
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # create a TaskInclude object
    task_include = TaskInclude()
    # create a Block object
    block = Block()
    # set the Block object as the parent of the TaskInclude object
    task_include._parent = block
    # set the 'apply' attribute of the TaskInclude object
    task_include.args = {'apply': {'block': []}}
    # call the method build_parent_block of the TaskInclude object
    p_block = task_include.build_parent_block()
    # assert that the returned object is a Block object
    assert isinstance(p_block, Block)
    # assert that the Block object has the TaskInclude object as a parent
    assert p_block._parent == task_include
    # assert that the Block object has the Block object as a parent
    assert p_block._parent._

# Generated at 2022-06-17 08:36:53.458169
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}
    task_include._parent = UnsafeProxy({'e': 'f'})
    task_include._variable_manager = variable_manager
    task_include._loader = loader
    task_include._play_context = play_context

    assert task_

# Generated at 2022-06-17 08:37:05.942691
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test for action 'include'

# Generated at 2022-06-17 08:37:18.281134
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:37:31.675246
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test that a TaskInclude with no 'file' or '_raw_params' raises an error
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {}
    task_include.vars = {}
    task_include._parent = Block()
    task_include._parent._play = None
    task_include._role = None
    task_include._variable_manager = VariableManager()
    task_include._loader = DataLoader()