

# Generated at 2022-06-17 08:27:54.507894
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:28:01.999609
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with an action that is not in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    ds = {'action': 'include_tasks', 'foo': 'bar'}
    ti = TaskInclude()
    ds_new = ti.preprocess_data(ds)
    assert ds_new == ds

    # Test with an action that is in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    ds = {'action': 'include_role', 'foo': 'bar'}
    ti = TaskInclude()
    ds_new = ti.preprocess_data(ds)
    assert ds_new == {'action': 'include_role'}

# Generated at 2022-06-17 08:28:11.648980
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_play_context(play_context)

    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = dict(
        a=1,
        b=2,
        c=3,
        tags=['t1', 't2'],
        when='{{ a == 1 }}',
    )

# Generated at 2022-06-17 08:28:20.452500
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:28:31.990369
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a dict object
    ds = dict(
        action='include',
        args=dict(
            _raw_params='test.yml',
            apply=dict(
                block=[]
            )
        ),
        name='test',
        tags=['test'],
        when='test'
    )

    # Call method preprocess_data of class TaskInclude
    result = task_include.preprocess_data(ds)

    # Assert that the result is a dict object

# Generated at 2022-06-17 08:28:36.810506
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Test TaskInclude
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:28:45.790202
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'file': 'test.yml'}
    task_include.vars = {'test': 'test'}
    task_include.block = []
    task_include.role = None
    task_include.task_include = None
    task_include.notify = []
    task_include.rescue = []
    task_include.always = []
    task_include.tags = []
    task_include.when = []
    task_include.loop = []
    task_include.loop_with = []
    task_include.loop_control = {}
    task_include.ignore_

# Generated at 2022-06-17 08:28:57.003710
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    ti = TaskInclude()
    # Set the action to 'include'
    ti.action = 'include'
    # Set the args to a dict with a key 'foo' and value 'bar'
    ti.args = {'foo': 'bar'}
    # Set the vars to a dict with a key 'baz' and value 'qux'
    ti.vars = {'baz': 'qux'}
    # Set the parent to a Task object
    ti._parent = Task()
    # Set the parent's vars to a dict with a key 'parent' and value 'parent_value'
    ti._parent.vars = {'parent': 'parent_value'}
    # Call the get_vars method
    vars = ti.get_vars()
    # Assert that

# Generated at 2022-06-17 08:29:09.148856
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a TaskInclude object
    ti = TaskInclude()

    # Create a Task object
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}

    # Create a Block object
    block = Block()
    block.parent_block = None
    block.role = None
    block.task_include = None

    # Create a Play object
    play = Play()

# Generated at 2022-06-17 08:29:20.808191
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # test with 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        tags=['tag1', 'tag2'],
        when='some_condition',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    task.vars = dict(
        var1='value1',
        var2='value2',
    )

# Generated at 2022-06-17 08:29:32.857914
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a parent Task object
    parent_task = Task()
    parent_task.vars = {'parent_task_var': 'parent_task_value'}

    # Create a parent Block object
    parent_block = Block()
    parent_block.vars = {'parent_block_var': 'parent_block_value'}

    # Create a parent Play object
    parent_play = Play()
    parent_play.vars = {'parent_play_var': 'parent_play_value'}

    # Create a parent Role object
    parent_role = Role()
    parent_role.vars = {'parent_role_var': 'parent_role_value'}

    # Set the parent of the TaskInclude object
    task_include

# Generated at 2022-06-17 08:29:42.178579
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # Test case 1: action is not in C._ACTION_INCLUDE
    task_include = TaskInclude()
    task_include.action = 'ios_command'
    task_include.vars = {'ansible_network_os': 'ios'}

# Generated at 2022-06-17 08:29:48.970237
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    task_include = TaskInclude()
    task_include._variable_manager = variable_manager
    task_include._loader = loader
    task_include._play_context = play_context
    task_include.action = 'include'

# Generated at 2022-06-17 08:30:00.619620
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock


# Generated at 2022-06-17 08:30:08.677443
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Test with valid options
    data = {'action': 'include_tasks', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include_tasks'
    assert task.args['_raw_params'] == 'test.yml'

    # Test with valid options and apply

# Generated at 2022-06-17 08:30:14.805664
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '192.168.1.1'
    play_context.port = 22
    play_context.remote_user = 'cisco'
   

# Generated at 2022-06-17 08:30:24.146196
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:30:34.664789
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test for TaskInclude
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=VariableManager(), loader=DataLoader())
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'test.yml'

    # Test for TaskInclude with apply

# Generated at 2022-06-17 08:30:46.152359
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display

# Generated at 2022-06-17 08:30:59.264894
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_

# Generated at 2022-06-17 08:31:13.035426
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'

    # Test for action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        name='test_include',
        tags=['tag1', 'tag2'],
        when='ansible_os_family == "RedHat"'
    )

    task = TaskInclude.load

# Generated at 2022-06-17 08:31:25.522504
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six import string_types


# Generated at 2022-06-17 08:31:33.994655
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.CLIARGS = dict(tags=['all'])

    # Test for action 'include'
    task_include = TaskInclude.load(dict(action='include', file='/tmp/test.yml'), variable_manager=variable_manager, loader=loader)
    task_include.set_loader(loader)
    task_include.set_play_context(play_context)
    task_include.set_variable_manager(variable_manager)


# Generated at 2022-06-17 08:31:43.396324
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Test with valid options
    data = {'action': 'include', 'file': 'foo'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert isinstance(task, Task)
    assert task.action == 'include'
    assert task

# Generated at 2022-06-17 08:31:48.932756
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.plugins.loader import action_loader

    # Create a fake host

# Generated at 2022-06-17 08:31:55.202075
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:32:06.878557
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:32:19.117535
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)

    assert task.action == 'include'
    assert task.args['_raw_params'] == 'test.yml'

# Generated at 2022-06-17 08:32:25.998877
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:32:37.904589
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 'b'}
    task.vars = {'c': 'd'}
    parent = Block()
    parent.vars = {'e': 'f'}
    task._parent = parent
    assert task.get_vars() == {'a': 'b', 'c': 'd', 'e': 'f'}

    # Test with action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'a': 'b'}
    task.vars = {'c': 'd'}
    parent = Block()
    parent.vars = {'e': 'f'}

# Generated at 2022-06-17 08:32:59.046545
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Test with a valid task
    data = {
        'action': 'include_tasks',
        'file': 'test.yml',
        'apply': {
            'name': 'test',
            'tags': ['test'],
            'when': 'test',
        }
    }
    task = TaskInclude.load(data, loader=loader, variable_manager=variable_manager)
    assert isinstance(task, TaskInclude)

# Generated at 2022-06-17 08:33:04.142587
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include._variable_manager = variable_manager
    task_include._loader = loader
    task_include._play_context = play_context

    assert task_include.get_vars() == {'a': 1, 'b': 2}

# Generated at 2022-06-17 08:33:16.759370
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'_raw_params': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}

# Generated at 2022-06-17 08:33:29.559197
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-17 08:33:35.836939
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

    play = Play.load(play_ds)
    role = Role()

# Generated at 2022-06-17 08:33:42.187846
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    play_context = PlayContext()
    play_context.network_os = 'ios'

    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 'b'}
    task.vars = {'c': 'd'}
    task._variable_manager = variable_manager
    task._play_context = play_context

    assert task.get_v

# Generated at 2022-06-17 08:33:50.749279
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Set the action to 'include'
    task_include.action = 'include'

    # Set the args to a dict with a key 'a' and value 'b'
    task_include.args = {'a': 'b'}

    # Set the vars to a dict with a key 'c' and value 'd'
    task_include.vars = {'c': 'd'}

    # Create a PlayContext object
    play_context = PlayContext()

    # Set the vars to a dict with a key 'e' and value 'f'
    play

# Generated at 2022-06-17 08:33:55.153890
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False

# Generated at 2022-06-17 08:34:05.377171
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({'name': 'test_play', 'hosts': 'all'}, variable_manager=variable_manager, loader=loader)
    role = Role().load({'name': 'test_role'}, variable_manager=variable_manager, loader=loader)

    task = TaskInclude(play=play, role=role)
    task.args = {'apply': {'block': []}}
    p_block

# Generated at 2022-06-17 08:34:16.724375
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a play

# Generated at 2022-06-17 08:34:36.958764
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    # Test with TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo', 'apply': {'a': 1}, 'bad_opt': 'foo'}
    task = ti.check_options(task, None)
    assert task.args == {'_raw_params': 'foo', 'apply': {'a': 1}}

    # Test with RoleInclude
    ti = RoleInclude()
    task = Task()
    task.action = 'include_role'

# Generated at 2022-06-17 08:34:47.647997
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsGroupVarsVars
    from ansible.vars.hostvars import HostVarsGroupVarsGroupVars
    from ansible.vars.hostvars import HostVarsGroupVarsGroupVarsVars
    from ansible.vars.hostvars import HostV

# Generated at 2022-06-17 08:34:57.630675
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a TaskInclude object to test
    block = Block()
    role = None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)

    # Create a Task object to use as argument
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}

    # Test with valid options
    task_valid

# Generated at 2022-06-17 08:35:03.835309
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 1: action is 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}
    task_include._parent = None
    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    # Test case 2: action is not 'include'
    task_include = TaskInclude()
    task_include.action = 'include_role'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}
    task_include._parent = None


# Generated at 2022-06-17 08:35:16.848530
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks

# Generated at 2022-06-17 08:35:30.628265
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude
    from ansible.playbook.handler.include import Include as HandlerInclude
    from ansible.playbook.handler.task import HandlerTask
    from ansible.playbook.task_include import TaskInclude as PlaybookTaskInclude
    from ansible.playbook.include import Include as PlaybookInclude

    # Test for TaskInclude
    # Test for action '

# Generated at 2022-06-17 08:35:40.270970
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with a valid task
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'some_file'}
    task.check_options(task, {})

    # Test with a valid task and apply
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'some_file', 'apply': {'a': 'b'}}
    task.check_options(task, {})

    # Test with a valid task and apply and other args
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'some_file', 'apply': {'a': 'b'}, 'other': 'other'}
    task.check_options(task, {})

    # Test with a valid

# Generated at 2022-06-17 08:35:51.648929
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = PlayContext()

    task = TaskInclude.load(
        dict(
            action='include',
            file='/tmp/foo.yml',
            vars=dict(
                foo='bar',
            ),
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

# Generated at 2022-06-17 08:36:01.820297
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo.yml'}
    task = ti.check_options(task, {})
    assert task.args['_raw_params'] == 'foo.yml'
    assert 'file' not in task.args

    task = Task()
    task.action = 'include'

# Generated at 2022-06-17 08:36:10.060380
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    # Create a dummy play
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:36:53.706438
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    ti = TaskInclude()
    # Set the action to 'include'
    ti.action = 'include'
    # Set the args to {'a': 'b'}
    ti.args = {'a': 'b'}
    # Set the vars to {'c': 'd'}
    ti.vars = {'c': 'd'}
    # Set the parent to a Block object
    ti._parent = Block()
    # Set the parent's vars to {'e': 'f'}
    ti._parent.vars = {'e': 'f'}
    # Call get_vars()
    vars = ti.get_vars()
    # Check that the result is {'a': 'b', 'c': 'd', 'e': 'f'}
   

# Generated at 2022-06-17 08:37:06.084804
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:37:18.716313
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with a valid action
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'

# Generated at 2022-06-17 08:37:31.830022
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.defaults import RoleDefaults
    from ansible.playbook.role.vars import RoleVars
    from ansible.playbook.role.handlers import RoleHandlers
   

# Generated at 2022-06-17 08:37:44.421630
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()
