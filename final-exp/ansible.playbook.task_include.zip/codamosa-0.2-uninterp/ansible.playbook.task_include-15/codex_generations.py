

# Generated at 2022-06-17 08:27:58.189360
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test with an invalid action

# Generated at 2022-06-17 08:28:05.046833
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    block = Block().load({}, play=play, task_include=None, role=None, variable_manager=variable_manager, loader=loader)
    task = Task().load({}, block=block, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    task_include = TaskInclude().load

# Generated at 2022-06-17 08:28:15.329208
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager

# Generated at 2022-06-17 08:28:19.897935
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test for 'include' action

# Generated at 2022-06-17 08:28:31.858405
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

# Generated at 2022-06-17 08:28:41.741907
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_v

# Generated at 2022-06-17 08:28:49.787498
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    ds = {'action': 'include_role', 'name': 'foo', 'bar': 'baz'}
    assert task.preprocess_data(ds) == {'action': 'include_role', 'name': 'foo'}
    ds = {'action': 'include_tasks', 'name': 'foo', 'bar': 'baz'}
    assert task.preprocess_data(ds) == {'action': 'include_tasks', 'name': 'foo'}
    ds = {'action': 'import_tasks', 'name': 'foo', 'bar': 'baz'}
    assert task.preprocess_data(ds) == {'action': 'import_tasks', 'name': 'foo'}

# Generated at 2022-06-17 08:28:58.587427
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Test with an empty task
    task = Task()
    task = TaskInclude.check_options(task, {})
    assert task.args == {'_raw_params': None}

    # Test with a task with a file
    task = Task()
    task.args = {'file': 'test.yml'}
    task = TaskInclude.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml'}

   

# Generated at 2022-06-17 08:29:03.295624
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict(action='include_role', file='foo.yml')
    task.check_options(task.load_data(data), data)
    data = dict(action='include_role', file='foo.yml', apply=dict(foo='bar'))
    task.check_options(task.load_data(data), data)
    data = dict(action='include_role', file='foo.yml', apply='foo')
    try:
        task.check_options(task.load_data(data), data)
    except AnsibleParserError as e:
        assert 'Expected a dict for apply but got str instead' in str(e)
    data = dict(action='include_role', file='foo.yml', apply=dict(foo='bar'), foo='bar')

# Generated at 2022-06-17 08:29:11.919088
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    # Create a task
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}

    # Create a block
    block = Block()
    block.vars = {'test': 'test'}
    block.block = []
    block.task_include = task

    # Create a play
    play = Play()

# Generated at 2022-06-17 08:29:30.972850
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=dict(
                name='test',
                tags=['test'],
            )
        )
    )

    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'


# Generated at 2022-06-17 08:29:40.828668
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo.yml'}
    task = ti.check_options(task, {})
    assert task.args['_raw_params'] == 'foo.yml'

    task = Task()
    task.action = 'include'

# Generated at 2022-06-17 08:29:48.882801
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:30:00.568082
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a playbook
    pb = Play()
    pb._loader = DataLoader()

# Generated at 2022-06-17 08:30:08.651092
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'


# Generated at 2022-06-17 08:30:14.782413
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-17 08:30:24.151220
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 08:30:32.132364
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': {
            'block': [],
            'name': 'test',
            'when': 'test',
        },
    }

# Generated at 2022-06-17 08:30:43.805407
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 08:30:58.117598
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-17 08:31:12.812241
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Test with a valid include
    task = TaskInclude.load({
        'include': 'some_file.yml',
        'tags': ['tag1', 'tag2'],
        'when': 'some_condition',
    }, block=Block(), role=None, task_include=None, variable_manager=VariableManager(), loader=DataLoader())
    assert task.action == 'include'
    assert task.args == {'_raw_params': 'some_file.yml'}


# Generated at 2022-06-17 08:31:24.318879
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:31:35.714940
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude

    # Create a dummy play
    play_

# Generated at 2022-06-17 08:31:45.786742
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude

    # Create a task

# Generated at 2022-06-17 08:31:54.654507
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:32:06.523348
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 08:32:18.856904
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:32:25.840474
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:32:37.746015
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:32:48.090576
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:33:01.451131
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    ti = TaskInclude()
    # Set the action to 'include'
    ti.action = 'include'
    # Set the args to {'a': 'b'}
    ti.args = {'a': 'b'}
    # Set the vars to {'c': 'd'}
    ti.vars = {'c': 'd'}
    # Set the parent to a mock object
    ti._parent = Mock()
    # Set the parent's get_vars to return {'e': 'f'}
    ti._parent.get_vars = Mock(return_value={'e': 'f'})

    # Call get_vars
    vars = ti.get_vars()

    # Assert that the returned vars are {'a': 'b', 'c':

# Generated at 2022-06-17 08:33:15.059694
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test TaskInclude.load with valid data
    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': {
            'block': [],
            'name': 'test',
            'when': 'test',
        },
    }
    task = TaskInclude.load(data)
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args['apply'] == {
        'block': [],
        'name': 'test',
        'when': 'test',
    }

    # Test TaskInclude.load with invalid data
    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': 'test',
    }

# Generated at 2022-06-17 08:33:25.511130
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import RoleTask
    from ansible.playbook.role.defaults import RoleDefault

# Generated at 2022-06-17 08:33:34.281008
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '192.168.56.101'
    play_context.port = 22

# Generated at 2022-06-17 08:33:42.873113
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        tasks=[dict(action='include', args=dict(apply=dict(block=[])))]
    ), loader=loader, variable_manager=variable_manager)
    role = Role.load(dict(name="Ansible Role"), play=play)

# Generated at 2022-06-17 08:33:51.117826
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # create a task with no parent
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 'b', 'tags': ['c', 'd'], 'when': 'e'}
    task.vars = {'f': 'g', 'tags': ['h', 'i'], 'when': 'j'}
    task.play_context = play_context

# Generated at 2022-06-17 08:34:01.897584
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with a valid task
    task = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            apply=dict(
                block=[]
            )
        ),
        block=Block(play=None),
        role=None,
        task_include=None,
        variable_manager=VariableManager(),
        loader=DataLoader()
    )
    assert isinstance(task, TaskInclude)
    assert isinstance(task._parent, Block)

# Generated at 2022-06-17 08:34:08.000216
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    task = TaskInclude()
    task.action = 'include'
    task.args = {'_raw_params': 'test.yml', 'a': 'b'}
    task.vars = {'a': 'c'}
    task._variable_manager = variable_manager
    task._loader = loader
    task._play = None
    task._parent = None

# Generated at 2022-06-17 08:34:16.960878
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b', 'c': 'd'}
    task_include.vars = {'e': 'f', 'g': 'h'}
    task_include._variable_manager = variable_manager


# Generated at 2022-06-17 08:34:31.091569
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # Test with valid options
    data = {'action': 'include', 'file': 'file.yml'}
    task.check_options(task.load_data(data), data)
    data = {'action': 'include_role', 'name': 'role_name'}
    task.check_options(task.load_data(data), data)
    data = {'action': 'import_role', 'name': 'role_name'}
    task.check_options(task.load_data(data), data)
    data = {'action': 'import_tasks', 'file': 'file.yml'}
    task.check_options(task.load_data(data), data)
    data = {'action': 'include_tasks', 'file': 'file.yml'}

# Generated at 2022-06-17 08:34:48.904247
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Setup
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}
    task_include._parent = MockTask()
    task_include._parent.get_vars.return_value = {'e': 5, 'f': 6}

    # Test
    vars = task_include.get_vars()

    # Assert
    assert vars == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}


# Generated at 2022-06-17 08:34:58.310909
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    # Create a mock task
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'a': 1}}

    # Create a mock block
    block = Block()
    block

# Generated at 2022-06-17 08:35:07.833911
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti._play_context = PlayContext()

    # Test with action 'include'
    ds = dict(action='include', file='test.yml')
    assert ti.preprocess_data(ds) == ds

    # Test with action 'include_role'
    ds = dict(action='include_role', file='test.yml')
    assert ti.preprocess_data(ds) == ds

    # Test with action 'import_role'
    ds = dict(action='import_role', file='test.yml')
    assert ti.preprocess_data(ds) == ds

    # Test with action 'import_tasks'

# Generated at 2022-06-17 08:35:19.570670
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude

    play = Play.load({'name': 'test_play', 'hosts': 'all'}, variable_manager=None, loader=None)
    role = Role.load({'name': 'test_role'}, play=play, variable_manager=None, loader=None)
    block = Block.load({'name': 'test_block'}, play=play, task_include=None, role=role, variable_manager=None, loader=None)

# Generated at 2022-06-17 08:35:30.605199
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.playbook import Playbook
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 08:35:40.038043
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    task_include = TaskInclude.load(dict(action='include', file='/path/to/file'), variable_manager=variable_manager, loader=loader)
    assert task_include.get_vars() == dict(file='/path/to/file')

    # Test for action 'include_tasks'
    task_include = TaskInclude

# Generated at 2022-06-17 08:35:50.129677
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with no options
    task = TaskInclude()
    task.action = 'include'
    task.args = {}
    task.check_options(task, {})
    assert task.args == {'_raw_params': None}

    # Test with valid options
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'a': 'b'}}
    task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'a': 'b'}}

    # Test with invalid options
    task = TaskInclude()
    task.action = 'include'

# Generated at 2022-06-17 08:36:01.673546
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a dummy play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )
    play

# Generated at 2022-06-17 08:36:09.270808
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a dummy PlaybookExecutor to get a loader and variable manager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_

# Generated at 2022-06-17 08:36:16.638416
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test TaskInclude
    task = TaskInclude()
    # Test with no args
    data = dict()
    task = task.check_options(task.load_data(data), data)
    assert task.args == dict()

    # Test with valid args

# Generated at 2022-06-17 08:36:44.505065
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {'bam': 'baz'}
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # Test with 'include'
    data = {'action': 'include', 'file': 'foo.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.get_v

# Generated at 2022-06-17 08:36:52.274534
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:37:02.519845
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:37:16.820116
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a dummy task to test the method
    task = Task()
    task.action = 'include'
    task.args = {'file': 'dummy_file'}
    task.block = Block()
    task.block.vars = {'dummy_var': 'dummy_value'}
    task.block.parent_block = None
    task.block.role = None
    task.block.play = None
    task.block.task_include = None


# Generated at 2022-06-17 08:37:31.113451
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with invalid options
    task = TaskInclude()
    data = {'action': 'include', 'file': 'test.yml', 'invalid_option': 'invalid_value'}
    try:
        task.check_options(task.load_data(data, variable_manager=None, loader=None), data)
        assert False, "AnsibleParserError was not raised"
    except AnsibleParserError as e:
        assert e.message == "Invalid options for include: invalid_option"

    # Test with valid options
    task = TaskInclude()
    data = {'action': 'include', 'file': 'test.yml', 'tags': 'tag1'}
    task.check_options(task.load_data(data, variable_manager=None, loader=None), data)

    # Test with apply option

# Generated at 2022-06-17 08:37:36.625859
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for action 'include'
    task = TaskInclude.load(dict(action='include', file='/tmp/test.yml'), variable_manager=variable_manager, loader=loader)
    assert task.get_vars() == {'file': '/tmp/test.yml'}

    # Test for action 'import_playbook'

# Generated at 2022-06-17 08:37:47.684465
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell