

# Generated at 2022-06-17 08:28:01.896602
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin
    from ansible.playbook.connection_info import ConnectionInfo

# Generated at 2022-06-17 08:28:12.604003
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with a task that is not an include task
    task = TaskInclude()
    task.action = 'shell'
    task.args = {'_raw_params': 'ls', 'file': 'test.yml'}
    try:
        task.check_options(task, None)
        assert False
    except AnsibleParserError:
        assert True

    # Test with a task that is an include task
    task = TaskInclude()
    task.action = 'include'
    task.args = {'_raw_params': 'test.yml', 'file': 'test.yml'}
    try:
        task.check_options(task, None)
        assert True
    except AnsibleParserError:
        assert False

    # Test with a task that is an include task and has an invalid option
    task = Task

# Generated at 2022-06-17 08:28:19.574364
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a fake play
    play_ds = dict(
        name='fake play',
        hosts='all',
        gather_facts='no',
        roles=[],
        tasks=[],
    )
    play = Play.load(play_ds, variable_manager=VariableManager(), loader=DataLoader())

    # Create a fake

# Generated at 2022-06-17 08:28:31.743282
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    loader = DataLoader()
    variable_manager = VariableManager()
   

# Generated at 2022-06-17 08:28:43.571891
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
   

# Generated at 2022-06-17 08:28:49.424962
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars

    add_all_plugin_dirs()

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-17 08:29:02.512073
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:29:12.405847
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleParserError

    # Test with 'include' action

# Generated at 2022-06-17 08:29:21.167676
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # create a task with a parent block

# Generated at 2022-06-17 08:29:26.541849
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    assert ti.preprocess_data({'action': 'include_role', 'name': 'foo'}) == {'action': 'include_role', 'name': 'foo'}
    assert ti.preprocess_data({'action': 'include_role', 'name': 'foo', 'bar': 'baz'}) == {'action': 'include_role', 'name': 'foo'}
    assert ti.preprocess_data({'action': 'include_role', 'name': 'foo', 'bar': 'baz', 'ignore_errors': True}) == {'action': 'include_role', 'name': 'foo', 'ignore_errors': True}

# Generated at 2022-06-17 08:29:40.710388
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    variable_manager.set_play_context(play_context)

    # test for action 'include'

# Generated at 2022-06-17 08:29:46.035837
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 1: action is not in C._ACTION_INCLUDE
    # Expected result: return super(TaskInclude, self).get_vars()
    task = TaskInclude()
    task.action = 'include_role'
    task.vars = {'a': 1}
    task._parent = Task()
    task._parent.get_vars = lambda: {'b': 2}
    task.args = {'c': 3}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3}

    # Test case 2: action is in C._ACTION_INCLUDE
    # Expected result: return all_vars
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'a': 1}
   

# Generated at 2022-06-17 08:29:51.327435
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a fake play

# Generated at 2022-06-17 08:30:03.337117
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': {
            'block': [],
            'name': 'test',
            'tags': ['test'],
            'when': 'test',
        },
    }


# Generated at 2022-06-17 08:30:10.930461
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Set the action of the TaskInclude object to 'include'
    task_include.action = 'include'
    # Set the args of the TaskInclude object to {'a': 1, 'b': 2}
    task_include.args = {'a': 1, 'b': 2}
    # Set the vars of the TaskInclude object to {'c': 3, 'd': 4}
    task_include.vars = {'c': 3, 'd': 4}
    # Set the parent of the TaskInclude object to a Block object
    task_include._parent = Block()
    # Set the vars of the parent of the TaskInclude object to {'e': 5, 'f': 6}

# Generated at 2022-06-17 08:30:22.159552
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:30:34.162942
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:30:44.180399
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Test with a valid task
    task = TaskInclude()
    data = dict(
        action='include_tasks',
        file='some_file'
    )
    task = task.check_options(task.load_data(data), data)
    assert task.action == 'include_tasks'
    assert task.args['_raw_params'] == 'some_file'

    # Test with a valid task and apply
    task = TaskInclude()

# Generated at 2022-06-17 08:30:58.159437
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    task = Task()
    task.action = 'include'
    task.args = {'_raw_params': 'test.yml', 'apply': {'a': 'b'}}

    assert TaskInclude.check_options(task, {}) == task
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'a': 'b'}}

    task.action = 'include_role'
    task.args = {'_raw_params': 'test.yml', 'apply': {'a': 'b'}}

    assert TaskInclude.check_options(task, {}) == task

# Generated at 2022-06-17 08:31:10.299011
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    block = Block().load({}, play=play, task_include=None, role=None, variable_manager=variable_manager, loader=loader)
    task = Task().load({}, block=block, role=None, task_include=None, variable_manager=variable_manager, loader=loader)
    task_include = TaskInclude().load

# Generated at 2022-06-17 08:31:30.082426
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    ti = TaskInclude()
    # Set the action to 'include'
    ti.action = 'include'
    # Set the args of the TaskInclude object
    ti.args = {'a': 'b', 'c': 'd'}
    # Set the vars of the TaskInclude object
    ti.vars = {'e': 'f', 'g': 'h'}
    # Set the parent of the TaskInclude object
    ti._parent = Task()
    # Set the vars of the parent Task object
    ti._parent.vars = {'i': 'j', 'k': 'l'}
    # Call the get_vars method of the TaskInclude object
    vars = ti.get_vars()
    # Assert that the vars are as expected

# Generated at 2022-06-17 08:31:37.205371
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play

# Generated at 2022-06-17 08:31:49.427177
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    task.action = 'import_tasks'
    assert task.get_vars() == {'c': 3, 'd': 4}

    task.action = 'include_role'
    assert task.get_vars() == {'c': 3, 'd': 4}

    task.action = 'include_tasks'
    assert task.get_vars() == {'c': 3, 'd': 4}

    task.action = 'include'

# Generated at 2022-06-17 08:32:04.231158
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    task = Task()
    block = Block()
    role = None

    # Test with valid options
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, block=block, role=role, task_include=task, variable_manager=variable_manager, loader=loader)
    assert task.args['_raw_params'] == 'test.yml'

    # Test with invalid options

# Generated at 2022-06-17 08:32:10.773855
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with action 'include'
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.args['_raw_params'] == 'test.yml'

# Generated at 2022-06-17 08:32:21.633607
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22


# Generated at 2022-06-17 08:32:31.048137
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Test TaskInclude
    # Test valid options

# Generated at 2022-06-17 08:32:44.983143
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create a task
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}

    # Create a block
    block = Block()
    block.block = [task]

    # Create a role
    role = None

    # Create a task_include
    task_include = TaskInclude(block=block, role=role)

    # Create a variable manager
    variable_manager

# Generated at 2022-06-17 08:32:59.341704
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:33:05.978639
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a TaskInclude object
    task_include = TaskInclude()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a HostVars object
    hostvars = HostVars(loader=None, variables=dict())

    # Create a UnsafeProxy object
    unsafe_proxy = UnsafeProxy(variable_manager=variable_manager)

    # Set the attributes of TaskInclude object
    task_include._play_context = play_context
    task_include._variable_

# Generated at 2022-06-17 08:33:24.871891
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude
    from ansible.playbook.handler.task_blocks import HandlerTaskBlocks
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 08:33:34.229752
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleParserError

    display = Display()

# Generated at 2022-06-17 08:33:42.841760
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test the get_vars method of class TaskInclude
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import TaskInclude
    from ansible.playbook.role.include import HandlerTaskInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import TaskIn

# Generated at 2022-06-17 08:33:48.046594
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Create a TaskInclude instance
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = dict(a=1, b=2)
    ti._parent = None
    ti._role = None
    ti._variable_manager = variable_manager
    ti._loader = loader
    ti._play_context = play_context

    # Test the get_vars method
    vars = ti.get_vars()

# Generated at 2022-06-17 08:33:59.853119
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case 1: action is not in C._ACTION_INCLUDE
    task = TaskInclude()
    task.action = 'include_role'
    task.vars = {'a': 1}
    task._parent = Block()
    task._parent.vars = {'b': 2}
    task.args = {'c': 3}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3}

    # Test case 2: action is in C._ACTION_INCLUDE
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'a': 1}
    task._parent = Block()
    task._parent.vars = {'b': 2}
    task.args = {'c': 3}
    assert task

# Generated at 2022-06-17 08:34:11.151426
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    display = Display()
    loader = DataLoader()
    variable_manager = Variable

# Generated at 2022-06-17 08:34:21.933515
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test TaskInclude

# Generated at 2022-06-17 08:34:32.989202
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test for TaskInclude
    # Test for

# Generated at 2022-06-17 08:34:45.031523
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.block import Block as RoleBlock
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

# Generated at 2022-06-17 08:34:56.737728
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    # Create a dummy playbook executor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:35:20.064526
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with action 'include'
    data = {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'invalid_attr': 'invalid_attr'}
    ti = TaskInclude()
    result = ti.preprocess_data(data)
    assert result == {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2']}

    # Test with action 'import_tasks'
    data = {'action': 'import_tasks', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'invalid_attr': 'invalid_attr'}
    ti = TaskInclude()
    result = ti.preprocess_data(data)

# Generated at 2022-06-17 08:35:31.301392
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '192.168.56.101'
   

# Generated at 2022-06-17 08:35:40.651728
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test for TaskInclude
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'file': 'test.yml', 'apply': {'test': 'test'}}

# Generated at 2022-06-17 08:35:50.440442
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a dummy play

# Generated at 2022-06-17 08:35:58.349628
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:36:09.187830
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = dict()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    block = Block()
    block._play = play
    block._role = Role()
    block._task_include = Task()
    block._loader = loader
    block._variable_manager = variable_manager

    # Test with a task include with action 'include'

# Generated at 2022-06-17 08:36:18.047287
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}
    task_include.vars = {'c': 'd'}

# Generated at 2022-06-17 08:36:29.806895
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlaybookExecutor.load_play_context(variable_manager)

    # Test with valid options

# Generated at 2022-06-17 08:36:40.603379
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:36:53.457843
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:37:44.449510
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    play = Play.load(dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[dict(
            include='test.yml',
            apply=dict(
                block=[]
            )
        )]
    ), loader=loader, variable_manager=variable_manager)

    assert play.tasks[0].action == 'include'
    assert play.tasks[0].args

# Generated at 2022-06-17 08:37:50.593653
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test with an empty task
    task = Task()
    task.action = 'include'
    task.args = {}
    task = TaskInclude.check_options(task, {})
    assert task.args.get('_raw_params') is None

    # Test with a task with only valid options
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task = TaskInclude.check_