

# Generated at 2022-06-17 08:27:53.029601
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with valid options
    data = {'action': 'include_role', 'name': 'my_role', 'apply': {'tags': ['my_tag']}}
    task = TaskInclude.load(data, block=Block(), role=None, task_include=None, variable_manager=VariableManager(), loader=DataLoader())
    assert task.args == {'_raw_params': 'my_role', 'apply': {'tags': ['my_tag']}}

    # Test with invalid options

# Generated at 2022-06-17 08:28:01.435998
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:28:12.575945
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:28:21.799871
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:28:32.486438
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Test with action 'include'
    data = {'action': 'include', 'file': 'test.yml'}
    task_include = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task_include.preprocess_data(data) == {'action': 'include', 'file': 'test.yml'}

    # Test with action 'include_role'
    data = {'action': 'include_role', 'file': 'test.yml'}
    task_include = TaskIn

# Generated at 2022-06-17 08:28:42.289743
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:28:50.276069
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {'bam': 'boo'}
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)

    # test TaskInclude.check_options
    task = TaskInclude.load({'include': 'foo.yml'}, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:29:04.160698
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': {
            'name': 'test',
            'block': [],
        },
    }


# Generated at 2022-06-17 08:29:13.408870
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
   

# Generated at 2022-06-17 08:29:21.884813
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context._task_vars = dict()

    task = TaskInclude.load(
        dict(
            action='include_role',
            name='test_role',
            tasks='test_task',
            vars=dict(
                test_var='test_value'
            )
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    assert task.action == 'include_role'
    assert task.args['name'] == 'test_role'
    assert task.args['tasks']

# Generated at 2022-06-17 08:29:38.302611
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 08:29:44.433765
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # test for action 'include'
    task_include = TaskInclude.load(dict(action='include', file='/tmp/foo.yml'), variable_manager=variable_manager, loader=loader)
    assert task_include.get_vars() == dict(file='/tmp/foo.yml')

    # test for action 'include_role'
    task_include = TaskIn

# Generated at 2022-06-17 08:29:52.972404
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test for method check_options of class TaskInclude
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.connection_info import ConnectionInfo
   

# Generated at 2022-06-17 08:30:04.742016
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with valid options

# Generated at 2022-06-17 08:30:18.469893
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with valid data
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.args['_raw_params'] == 'test.yml'

   

# Generated at 2022-06-17 08:30:30.389769
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.role.vars import Vars
    from ansible.playbook.role.defaults import Defaults
    from ansible.playbook.role.meta import RoleMeta

# Generated at 2022-06-17 08:30:40.754340
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test for action 'include'
    ds = {'action': 'include', 'tags': ['tag1', 'tag2'], 'when': 'ansible_os_family == "RedHat"'}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert ds == {'action': 'include', 'tags': ['tag1', 'tag2'], 'when': 'ansible_os_family == "RedHat"'}

    # Test for action 'include_role'
    ds = {'action': 'include_role', 'tags': ['tag1', 'tag2'], 'when': 'ansible_os_family == "RedHat"'}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)

# Generated at 2022-06-17 08:30:48.156217
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.tasks import TaskRoleInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.requiremenets import RoleRequirement
    from ansible.playbook.role.defaults import RoleDefault
    from ansible.playbook.role.vars import RoleVariable
    from ansible.playbook.role.handlers import RoleHandler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
   

# Generated at 2022-06-17 08:30:59.450606
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}
    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    task_include.action = 'import_tasks'
    assert task_include.get_vars() == {'c': 3, 'd': 4}

    task_include.action = 'include_role'
    assert task_include.get_vars() == {'c': 3, 'd': 4}

    task_include.action = 'include_tasks'

# Generated at 2022-06-17 08:31:07.540199
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    task = TaskInclude.load(dict(action='include', file='/tmp/foo.yml'), variable_manager=variable_manager, loader=loader)
    task.preprocess_data(dict(action='include', file='/tmp/foo.yml'))

    # Test that an exception is raised if an invalid attribute is passed
    try:
        task.preprocess_data(dict(action='include', file='/tmp/foo.yml', invalid_attribute='foo'))
    except AnsibleParserError:
        pass

# Generated at 2022-06-17 08:31:22.980268
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test with apply
    task_include = TaskInclude()
    task_include.args['apply'] = {'block': []}
    task_include._parent = 'parent'
    task_include._role = 'role'
    task_include._variable_manager = 'variable_manager'
    task_include._loader = 'loader'
    p_block = task_include.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.block == []
    assert p_block._play == 'parent'
    assert p_block._task_include == task_include
    assert p_block._role == 'role'
    assert p_block._variable_manager == 'variable_manager'
    assert p_block._loader == 'loader'

    # Test without apply
    task_include = TaskInclude

# Generated at 2022-06-17 08:31:30.215615
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:31:37.248556
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test with a valid task
    data = dict(
        action='include',
        file='my_include.yml',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data)
    assert isinstance(task, Task)
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'my_include.yml'
    assert task.args['apply'] == dict(block=[])

    # Test with an invalid task

# Generated at 2022-06-17 08:31:49.428719
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with a task that has no valid options
    task = TaskInclude()
    data = dict(action='include_role')
    task.check_options(task, data)
    assert task.args == dict(_raw_params=None)

    # Test with a task that has valid options
    task = TaskInclude()
    data = dict(action='include_role', file='foo.yml')
    task.check_options(task, data)
    assert task.args == dict(_raw_params='foo.yml')

    # Test with a task that has valid options and invalid options
    task = TaskInclude()
    data = dict(action='include_role', file='foo.yml', foo='bar')

# Generated at 2022-06-17 08:32:04.220236
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:32:10.753051
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.role.include
    import ansible.playbook.role.task
    import ansible.playbook.task_include
    import ansible.playbook.handler
    import ansible.playbook.handler_task
    import ansible.playbook.handler_task_include
    import ansible.playbook.conditional
    import ansible.playbook.included_file
    import ansible.playbook.included_file_task
    import ansible.playbook.included_file_task_include

    # Create a play

# Generated at 2022-06-17 08:32:21.634072
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with static include
    data = dict(
        action='include',
        file='/path/to/file',
        name='test',
        tags=['tag1', 'tag2'],
        when='test',
        invalid_attr='invalid',
    )
    task = TaskInclude.load(data)
    task.preprocess_data(data)
    assert 'invalid_attr' not in data

    # Test with dynamic include
    data = dict(
        action='include_tasks',
        file='/path/to/file',
        name='test',
        tags=['tag1', 'tag2'],
        when='test',
        invalid_attr='invalid',
    )
    task = TaskInclude.load(data)
    task.preprocess_data(data)

# Generated at 2022-06-17 08:32:31.046931
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with valid options

# Generated at 2022-06-17 08:32:41.686148
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a play

# Generated at 2022-06-17 08:32:47.571197
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = module_loader._loaders[0]
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo='bar',
        baz='qux',
    )
    variable_manager.options_vars = dict(
        foo='bar',
        baz='qux',
    )
    variable_manager.set_nonpersistent_facts(dict(
        foo='bar',
        baz='qux',
    ))

# Generated at 2022-06-17 08:33:02.782685
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with a TaskInclude object
    task = TaskInclude()
    data = {'action': 'include_tasks', 'file': 'test.yml', 'apply': {'a': 'b'}}
    task = task.check_options(task.load_data(data), data)
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args['apply'] == {'a': 'b'}

    # Test with a Task object
    task = Task()
    data = {'action': 'include_tasks', 'file': 'test.yml', 'apply': {'a': 'b'}}
    task

# Generated at 2022-06-17 08:33:15.993320
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-17 08:33:29.394570
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context._task_vars = dict()
    play_context._hostvars = dict()
    play_context._hostvars['localhost'] = dict

# Generated at 2022-06-17 08:33:35.343524
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(loader.load_inventory(host_list='/dev/null'))
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # Test with 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict(a=1, b=2)

# Generated at 2022-06-17 08:33:43.438577
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        tags=['tag1', 'tag2'],
        when='some_condition',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:33:51.530671
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a play

# Generated at 2022-06-17 08:34:01.929736
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test for action 'include'

# Generated at 2022-06-17 08:34:07.999237
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test_file'}
    task.vars = {'test_var': 'test_value'}
    task._variable_manager = variable_manager


# Generated at 2022-06-17 08:34:18.605128
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:34:31.560354
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:34:57.593190
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 08:35:07.562115
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a task with valid options
    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data, block=Block(), variable_manager=VariableManager(), loader=DataLoader())

    # Check that the task is valid
    assert task.action == 'include'
    assert task.args['file'] == '/path/to/file'
    assert task.args['apply'] == dict(block=[])

   

# Generated at 2022-06-17 08:35:19.381213
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Task()
    task._parent.vars = {'e': 5, 'f': 6}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test for action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._

# Generated at 2022-06-17 08:35:31.226497
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.CLIARGS = dict(tags=[])
    variable_manager.set_play_context(play_context)

    # Test with valid data
    data = dict(
        action='include',
        file='/path/to/file',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-17 08:35:40.602297
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a task include object
    ti = TaskInclude()
    # Create a parent block object
    p_block = Block()
    # Create a role object
    role = Role()
    # Create a play object
    play = Play()
    # Create a variable manager object
    variable_manager = VariableManager()
    # Create a loader object
    loader = DataLoader()
    # Create a task object
    task = Task()

    # Set the parent block of the task include object
    ti._parent = p_block
    # Set the role of the task include object
    ti._role = role
    # Set the play of the task include object
    ti._play = play
    # Set the variable manager of the task include object
    ti._variable_manager = variable_manager
    # Set the loader of the task include object
    ti._loader = loader

# Generated at 2022-06-17 08:35:52.037635
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with an empty task
    task = Task()
    task = TaskInclude.check_options(task, {})
    assert task.args == {}

    # Test with a task with valid options
    task = Task()
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task = TaskInclude.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'test': 'test'}}

   

# Generated at 2022-06-17 08:36:01.674671
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:36:09.450781
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:36:16.783798
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:36:29.530555
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:37:04.852308
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )

# Generated at 2022-06-17 08:37:17.128936
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 08:37:31.249453
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Set the action of the TaskInclude object
    task_include.action = 'include'
    # Set the args of the TaskInclude object
    task_include.args = {'a': 1, 'b': 2}
    # Set the vars of the TaskInclude object
    task_include.vars = {'c': 3, 'd': 4}
    # Set the parent of the TaskInclude object
    task_include._parent = Task()
    # Set the vars of the parent of the TaskInclude object
    task_include._parent.vars = {'e': 5, 'f': 6}

    # Call the method get_vars of the TaskInclude object
    all_vars = task_include.get_vars()

   

# Generated at 2022-06-17 08:37:44.385780
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskIncludeRole
    from ansible.playbook.role.task_include import HandlerTaskInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    # Create a play context
    play_context