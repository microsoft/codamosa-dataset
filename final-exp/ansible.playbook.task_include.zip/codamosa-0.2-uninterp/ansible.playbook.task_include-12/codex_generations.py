

# Generated at 2022-06-17 08:27:57.982945
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    ti = TaskInclude()
    # Set the action to 'include'
    ti.action = 'include'
    # Set the args
    ti.args = {'a': 'b'}
    # Set the vars
    ti.vars = {'c': 'd'}
    # Set the parent
    ti._parent = Block()
    ti._parent.vars = {'e': 'f'}
    # Call the get_vars method
    vars = ti.get_vars()
    # Check the result
    assert vars == {'a': 'b', 'c': 'd', 'e': 'f'}


# Generated at 2022-06-17 08:28:04.380391
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # test with action 'include'

# Generated at 2022-06-17 08:28:15.246887
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)

    # Test with a valid action
    data = dict(
        action='include',
        file='test.yml',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert isinstance

# Generated at 2022-06-17 08:28:21.372615
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test for include_role

# Generated at 2022-06-17 08:28:32.214114
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Test for valid options

# Generated at 2022-06-17 08:28:36.992995
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:28:45.532397
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude

# Generated at 2022-06-17 08:28:56.656232
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    # Create a fake playbook executor to use for testing
    class FakePlaybookExecutor(PlaybookExecutor):
        def __init__(self):
            self.loader = DataLoader()
            self.inventory = InventoryManager(self.loader, [])
            self.variable_manager = VariableManager(self.loader, self.inventory)
            self.variable_

# Generated at 2022-06-17 08:29:09.070199
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:29:15.765358
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(None)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # test for action 'include'

# Generated at 2022-06-17 08:29:31.941173
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test with valid options
    task_data = {
        'action': 'include_tasks',
        'file': 'some_file',
        'apply': {
            'block': []
        }
    }
    task = TaskInclude.load(task_data)
    assert task.action == 'include_tasks'
    assert task.args['file'] == 'some_file'
    assert task.args['apply'] == {'block': []}

    # Test with invalid options

# Generated at 2022-06-17 08:29:41.430739
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a play

# Generated at 2022-06-17 08:29:48.497788
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Setup
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:30:00.528040
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test with action 'include'
    task = TaskInclude(block=Block(), task_include=Task())
    task.action = 'include'
    task.args = {'_raw_params': 'test_file', 'apply': {'test': 'test'}}
    task = task.check_options(task, {})
    assert task.args == {'_raw_params': 'test_file', 'apply': {'test': 'test'}}

    # Test with action 'include_role'
    task = TaskInclude(block=Block(), task_include=Task())
    task.action = 'include_role'

# Generated at 2022-06-17 08:30:09.882902
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Test with action 'include'
    data = {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    ti = TaskInclude()
    ti.load_data(data, variable_manager=variable_manager, loader=loader)
    ti.preprocess_data(data)
    assert data == {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}



# Generated at 2022-06-17 08:30:15.598913
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
   

# Generated at 2022-06-17 08:30:29.559423
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.loader = loader

    # test for action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        tags=['tag1', 'tag2'],
        when='when_condition',
    )
    task = TaskInclude.load(data, play_context=play_context)

# Generated at 2022-06-17 08:30:35.980131
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with a task that is not an include task
    task = Task()
    task.action = 'shell'
    task.args = {'_raw_params': 'ls -l', 'apply': {'a': 'b'}}
    try:
        TaskInclude.check_options(task, {})
        assert False, 'AnsibleParserError should have been raised'
    except AnsibleParserError:
        pass

    # Test with a task that is an include task
    task = Task()
    task.action = 'include'
    task.args = {'_raw_params': 'ls -l', 'apply': {'a': 'b'}}
   

# Generated at 2022-06-17 08:30:45.307712
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock

    # Create a play

# Generated at 2022-06-17 08:30:58.643896
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test with action 'include'

# Generated at 2022-06-17 08:31:13.073977
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = {'action': 'include_role', 'name': 'test'}
    ds_expected = {'action': 'include_role', 'name': 'test'}
    assert ti.preprocess_data(ds) == ds_expected

    ds = {'action': 'include_role', 'name': 'test', 'bad_key': 'bad_value'}
    ds_expected = {'action': 'include_role', 'name': 'test'}
    assert ti.preprocess_data(ds) == ds_expected

    ds = {'action': 'include_role', 'name': 'test', 'bad_key': 'bad_value', 'C.INVALID_TASK_ATTRIBUTE_FAILED': True}

# Generated at 2022-06-17 08:31:25.559907
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    play_context.remote_addr = '192.168.56.101'
    play_context.port = 22
    play_context.remote_user

# Generated at 2022-06-17 08:31:32.971431
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options of class TaskInclude
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task.block = Block()
    task.block.parent_block = Block()
    task.block.parent_block.parent_block = Block()
    task.block.parent_block.parent_block.parent_block = Block()
    task.block.parent_block.parent_block.parent_block.parent_block = Block()

# Generated at 2022-06-17 08:31:43.082152
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    assert task_include.preprocess_data({'action': 'include_role', 'name': 'test_role'}) == {'action': 'include_role', 'name': 'test_role'}
    assert task_include.preprocess_data({'action': 'include_role', 'name': 'test_role', 'test_key': 'test_value'}) == {'action': 'include_role', 'name': 'test_role'}
    assert task_include.preprocess_data({'action': 'include_role', 'name': 'test_role', 'test_key': 'test_value'}) == {'action': 'include_role', 'name': 'test_role'}

# Generated at 2022-06-17 08:31:52.081990
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a play context
    play_context = PlayContext()

    # Create a play

# Generated at 2022-06-17 08:32:05.337864
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with a valid action
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'

# Generated at 2022-06-17 08:32:14.077510
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:32:24.996590
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    task = TaskInclude.load(dict(action='include', file='/tmp/foo.yml'), variable_manager=variable_manager, loader=loader)
    task.set_loader(loader)
    task.set_play_context(play_context)
    task.set_variable_manager(variable_manager)
    task.vars = dict(foo='bar')
   

# Generated at 2022-06-17 08:32:37.296356
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with a valid action
    data = dict(action='include_role', name='test')
    task = TaskInclude.load(data)
    assert task.preprocess_data(data) == data

    # Test with an invalid action
    data = dict(action='include', name='test')
    task = TaskInclude.load(data)
    assert task.preprocess_data(data) == data

    # Test with an invalid action and invalid attribute
    data = dict(action='include', name='test', invalid_attribute='test')
    task = TaskInclude.load(data)
    assert task.preprocess_data(data) == data

    # Test with an invalid action and invalid attribute and INVALID_TASK_ATTRIBUTE_FAILED
    C.INVALID_TASK_ATTRIBUTE_

# Generated at 2022-06-17 08:32:46.926926
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()
    block = Block()
    task = Task()
    task_include = TaskInclude()

    # Test with valid options
    data = {'action': 'include', 'file': 'test.yml', 'apply': {'test': 'test'}}

# Generated at 2022-06-17 08:33:04.245023
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test the get_vars method of class TaskInclude
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
        ]
    )
   

# Generated at 2022-06-17 08:33:16.827046
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a fake play

# Generated at 2022-06-17 08:33:29.610532
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.task_include
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role_include
    import ansible.playbook.handler_task_include
    import ansible.playbook.handler_task
    import ansible.playbook.handler_block
    import ansible.playbook.role_dependency
    import ansible.playbook.included_file
    import ansible.playbook.conditional
    import ansible.playbook.helpers
    import ansible.playbook.role_entry_task
    import ansible.playbook.role_entry_include
    import ansible.playbook.role_entry
    import ansible.playbook.bec

# Generated at 2022-06-17 08:33:35.862110
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:33:43.775996
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude as PlaybookTaskInclude
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-17 08:33:49.369192
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2}
    task_include.vars = {'c': 3, 'd': 4}

    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 08:34:00.898185
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with 'include' action
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task = task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'test': 'test'}}

    # Test with 'include_role' action
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task = task

# Generated at 2022-06-17 08:34:11.284272
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with 'include' action
    data = {'action': 'include', 'file': 'test.yml'}
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'

# Generated at 2022-06-17 08:34:21.961056
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:34:27.440469
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Test TaskInclude.check_options
    # Test with valid args
    ti = TaskInclude()
    data = {'action': 'include', 'file': 'test.yml'}
    task = Task

# Generated at 2022-06-17 08:35:05.659524
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with valid options

# Generated at 2022-06-17 08:35:17.694376
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        debug='msg="{{foo}}"',
        when='foo is defined',
        tags='bar',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 08:35:31.114181
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    # Create a fake PlaybookExecutor to get a loader and variable manager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')

# Generated at 2022-06-17 08:35:40.493274
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:35:51.970578
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.handler_task_include import HandlerTaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager

# Generated at 2022-06-17 08:36:00.321631
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a task include
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = {'a': 1, 'b': 2}
    ti.vars = {'c': 3, 'd': 4}

    # Create a parent block
    p_block = Block()
    p_block.vars = {'e': 5, 'f': 6}
    ti._parent = p_block

    # Check the vars
    assert ti.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

# Generated at 2022-06-17 08:36:10.530715
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action 'include'
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Block()
    task._parent.vars = {'e': 5, 'f': 6}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test for action 'include_role'
    task = TaskInclude()
    task.action = 'include_role'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._

# Generated at 2022-06-17 08:36:19.031180
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 08:36:30.142210
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:36:40.773399
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        """
        A sample callback plugin used for performing tests.
        """
        CALLBACK_VERSION = 2.0

# Generated at 2022-06-17 08:37:35.084991
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-17 08:37:46.752166
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    # Create a dummy play