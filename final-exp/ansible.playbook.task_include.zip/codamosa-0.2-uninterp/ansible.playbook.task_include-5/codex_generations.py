

# Generated at 2022-06-17 08:27:59.721062
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    import os
    import pytest

    class TestCallbackModule(CallbackBase):
        """
        A sample callback module used for unit tests.
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_

# Generated at 2022-06-17 08:28:09.620009
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    assert ti.preprocess_data({'action': 'include', 'file': 'foo.yml'}) == {'action': 'include', 'file': 'foo.yml'}

# Generated at 2022-06-17 08:28:18.909363
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test for TaskInclude.check_options
    # Test for TaskInclude.check_options with invalid options
    data = dict(
        action='include',
        file='/path/to/file',
        bad_option='bad_value',
    )
    task = TaskInclude.load(data)
    try:
        task.check_options(task, data)
        assert False, "AnsibleParserError should be raised"
    except AnsibleParserError as e:
        assert e.message == "Invalid options for include: bad_option"
        assert e.obj == data

    # Test for TaskInclude.check_options with invalid options for import_t

# Generated at 2022-06-17 08:28:31.427474
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import Callback

# Generated at 2022-06-17 08:28:41.294070
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test with empty task
    task = Task()
    task = TaskInclude.check_options(task, {})
    assert task.args == {}

    # Test with valid args
    task = Task()
    task.args = {'file': 'foo.yml', 'apply': {'a': 'b'}}
    task = TaskInclude.check_options(task, {})
    assert task.args == {'_raw_params': 'foo.yml', 'apply': {'a': 'b'}}

    # Test with invalid args
    task = Task()

# Generated at 2022-06-17 08:28:49.471518
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # Test with valid data

# Generated at 2022-06-17 08:29:02.618269
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Create a TaskInclude object
    ti = TaskInclude()

    # Create a Task object
    task = Task()

    # Create a Block object
    block = Block()

    # Create a dict to use as data
    data = dict()

    # Create a dict to use as task.args
    task_args = dict()

    # Create a dict to use as task.args['apply']
    task_args_apply = dict()

    # Test with an empty task.args
    task.args = task_args
    task = ti.check_options(task, data)
    assert task.args['_raw_params'] is None

    # Test with a task.args

# Generated at 2022-06-17 08:29:12.446337
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:29:21.167004
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection

# Generated at 2022-06-17 08:29:26.542382
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 08:29:40.678003
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )
    play = Play.load(play_ds)

    # Create a role

# Generated at 2022-06-17 08:29:48.319717
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with valid options
    task = TaskInclude()
    data = dict(action='include_tasks', file='/path/to/file')
    task.check_options(task.load_data(data), data)

    # Test with valid options and apply
    data = dict(action='include_tasks', file='/path/to/file', apply=dict(block=[]))
    task.check_options(task.load_data(data), data)

    # Test with invalid options
    data = dict(action='include_tasks', file='/path/to/file', invalid_option=True)
    try:
        task.check_options(task.load_data(data), data)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('AnsibleParserError not raised')

# Generated at 2022-06-17 08:30:00.527780
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 08:30:08.624306
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 08:30:14.757778
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with action 'include'
    task_include = TaskInclude()
    ds = {'action': 'include', 'name': 'test', 'tags': ['test']}
    ds = task_include.preprocess_data(ds)
    assert ds == {'action': 'include', 'name': 'test', 'tags': ['test']}

    # Test with action 'include_role'
    task_include = TaskInclude()
    ds = {'action': 'include_role', 'name': 'test', 'tags': ['test']}
    ds = task_include.preprocess_data(ds)
    assert ds == {'action': 'include_role', 'name': 'test', 'tags': ['test']}

    # Test with action 'import_role'
    task_include = TaskInclude()


# Generated at 2022-06-17 08:30:24.129394
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:30:32.113499
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeTask

# Generated at 2022-06-17 08:30:43.805160
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    play_context = PlayContext()
    play_context._task_vars = dict(a=1, b=2, c=3)
    variable_manager.set_play_context(play_context)

    # test for 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict(x=1, y=2)
    task_include.vars = dict(x=3, y=4)
   

# Generated at 2022-06-17 08:30:49.873857
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play

# Generated at 2022-06-17 08:30:59.846106
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:31:14.360795
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:31:26.466222
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a task with an invalid option
    task_data = {
        'action': 'include_role',
        'name': 'test_role',
        'invalid_option': 'invalid_value',
    }
    task = Task.load(task_data)

    # Check that the invalid option is detected
    try:
        TaskInclude.check_options(task, task_data)
        assert False
    except AnsibleParserError:
        pass

    # Create

# Generated at 2022-06-17 08:31:34.427730
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.vars = {'var1': 'value1', 'var2': 'value2'}
    task_include.args = {'arg1': 'value1', 'arg2': 'value2'}
    assert task_include.get_vars() == {'var1': 'value1', 'var2': 'value2', 'arg1': 'value1', 'arg2': 'value2'}

    # Test with action 'include_role'
    task_include.action = 'include_role'
    assert task_include.get_vars() == {'var1': 'value1', 'var2': 'value2'}

    # Test with action 'import_role'
    task_

# Generated at 2022-06-17 08:31:43.584095
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:31:48.967920
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-17 08:32:04.073357
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler.include import HandlerInclude

    # Test TaskInclude
    # Test with 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        other_arg='other_arg_value',
    )
    task = TaskInclude.load(data)
    assert task.action == 'include'

# Generated at 2022-06-17 08:32:13.379350
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 08:32:24.666546
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    ds = {'action': 'include', 'tags': ['tag1', 'tag2'], 'when': 'True'}
    assert task_include.preprocess_data(ds) == ds
    ds = {'action': 'include', 'tags': ['tag1', 'tag2'], 'when': 'True', 'invalid_key': 'value'}
    assert task_include.preprocess_data(ds) == {'action': 'include', 'tags': ['tag1', 'tag2'], 'when': 'True'}
    ds = {'action': 'include_role', 'tags': ['tag1', 'tag2'], 'when': 'True', 'invalid_key': 'value'}

# Generated at 2022-06-17 08:32:31.269037
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = {'action': 'include_role', 'name': 'my_role', 'tasks': 'main.yml', 'vars': {'var1': 'val1'}, 'tags': ['tag1', 'tag2'], 'when': 'var1 == val1'}
    ds_expected = {'action': 'include_role', 'name': 'my_role', 'tasks': 'main.yml', 'vars': {'var1': 'val1'}, 'tags': ['tag1', 'tag2'], 'when': 'var1 == val1'}
    ds_result = ti.preprocess_data(ds)
    assert ds_result == ds_expected


# Generated at 2022-06-17 08:32:45.366928
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a task
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}

    # Create a play
    play_context = PlayContext()
    play_context.vars = {'a': 10, 'c': 30}
    play_context.extra_vars = {'a': 100, 'd': 400}

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'a': 1000, 'e': 5000}

    # Set the play and variable manager to the task
    task._play = play_context
    task._variable_manager = variable_manager

    # Check the v

# Generated at 2022-06-17 08:33:00.792966
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 08:33:14.980189
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude

    # Test for 'include'

# Generated at 2022-06-17 08:33:25.451330
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.sentinel import Sentinel

    # Create a task with no options
    data = dict(
        action='include_tasks',
        file='file.yml',
    )
    task = TaskInclude.load(data)
    assert task.action == 'include_tasks'
    assert task.args == dict(_raw_params='file.yml')

    # Create a task with an invalid option

# Generated at 2022-06-17 08:33:34.280899
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test that check_options raises an exception when an invalid option is passed
    task = TaskInclude()
    data = dict(action='include', file='test.yml', invalid_option='invalid_value')
    with pytest.raises(AnsibleParserError):
        task.check_options(task.load_data(data), data)

    # Test that check_options raises an exception when an invalid option is passed
    # to a task that is not an include task
    task = TaskInclude()
    data = dict(action='shell', file='test.yml', invalid_option='invalid_value')
    with pytest.raises(AnsibleParserError):
        task.check_options(task.load_data(data), data)

    # Test that check_options raises an exception when an invalid option is passed
    #

# Generated at 2022-06-17 08:33:39.629140
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a fake play
    play_ds = dict(
        name='fake_play',
        hosts=['fake_host'],
        gather_facts='no',
        roles=[],
        tasks=[],
    )
    play = Play.load(play_ds)



# Generated at 2022-06-17 08:33:50.497961
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create a fake play
    play_ds = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )
    play = Play.load(play_ds)

    # Create a fake role

# Generated at 2022-06-17 08:34:01.784511
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:34:11.317602
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a task with a valid option
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task.block = Block()
    task.role = None
    task.task_include = None
    task.statically_loaded = False

    # Create a task with an invalid option
    task2 = Task()
    task2.action = 'include'

# Generated at 2022-06-17 08:34:21.964824
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:34:27.961544
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with valid options
    task = TaskInclude.load(
        dict(
            action='include_role',
            file='test.yml',
            apply=dict(
                block=dict(
                    name='test',
                    tasks=[
                        dict(action='debug', msg='test'),
                    ],
                ),
            ),
        ),
        block=Block(),
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )
    assert task.action == 'include_role'
    assert task.args['file']

# Generated at 2022-06-17 08:34:46.651864
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a fake play context
    play_context = PlayContext()
    play_context._vars_per_host = dict()
    play_context._vars_per_host['host1'] = dict()
    play_context._vars_per_host['host1']['var1'] = 'host1'
    play_context._vars_per_host['host1']['var2'] = 'host1'
    play_context._vars_per_host['host2'] = dict()
    play_context._vars_per_host['host2']['var1'] = 'host2'
    play_context._v

# Generated at 2022-06-17 08:34:57.138672
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.task_include import HandlerTaskInclude
    from ansible.playbook.role.task_include import IncludeRole
    from ansible.playbook.role.task_include import IncludeTask
    from ansible.playbook.role.task_include import IncludeRole
    from ansible.playbook.role.task_include import IncludeTask

# Generated at 2022-06-17 08:35:07.523622
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with a valid task
    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': {
            'tags': ['test'],
        },
    }
    task = TaskInclude.load(data)
    assert isinstance(task, Task)
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args['apply'] == {'tags': ['test']}

    # Test with a valid task but with invalid options

# Generated at 2022-06-17 08:35:19.342608
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    task_include = TaskInclude.load(
        dict(action='include', file='/tmp/foo', tags=['foo'], when='foo'),
        variable_manager=variable_manager,
        loader=loader
    )
    assert task_include.get_vars() == dict(file='/tmp/foo')

    # Test for action '

# Generated at 2022-06-17 08:35:30.575823
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with a valid task
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task = TaskInclude.check_options(task, task)
    assert task.args['_raw_params'] == 'test.yml'
    assert 'file' not in task.args

    # Test with a valid task and apply
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'block': []}}
    task = TaskInclude.check_options(task, task)

# Generated at 2022-06-17 08:35:40.161415
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # test for action 'include'

# Generated at 2022-06-17 08:35:50.196631
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with valid options
    task = TaskInclude.load(
        {
            'action': 'include_role',
            'name': 'myrole',
            'apply': {
                'block': [
                    {'action': 'debug', 'msg': 'my message'}
                ]
            }
        },
        block=Block(),
        role=None,
        task_include=None,
        variable_manager=VariableManager(),
        loader=DataLoader()
    )
    assert task.action == 'include_role'
   

# Generated at 2022-06-17 08:36:01.674249
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import HandlerTaskInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.include import TaskIncludeArgs
    from ansible.playbook.task.include import TaskIncludeVars
    from ansible.playbook.task.include import TaskIncludeTags
    from ansible.playbook.task.include import TaskIncludeWhen
    from ansible.playbook.task.include import TaskIncludeIgnoreErrors
    from ansible.playbook.task.include import TaskIncludeLoop
    from ansible.playbook.task.include import TaskIncludeLoopControl
    from ansible.playbook.task.include import TaskIncludeLoopWith

# Generated at 2022-06-17 08:36:09.710081
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_

# Generated at 2022-06-17 08:36:18.225663
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:36:42.808806
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Test with a TaskInclude instance
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'a': 1}}
    task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml', 'apply': {'a': 1}}

    # Test with a Task instance
    task = Task()
    task.action = 'include_tasks'
    task.args = {'file': 'test.yml', 'apply': {'a': 1}}
    task.check_options(task, {})
    assert task

# Generated at 2022-06-17 08:36:53.706511
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set

# Generated at 2022-06-17 08:37:06.131277
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:37:18.755172
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 08:37:26.564585
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a dummy task to use as a parent for the TaskInclude
    task = Task()
    task._role = None

# Generated at 2022-06-17 08:37:34.649787
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create a dummy play

# Generated at 2022-06-17 08:37:45.070939
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys

# Generated at 2022-06-17 08:37:50.810678
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
