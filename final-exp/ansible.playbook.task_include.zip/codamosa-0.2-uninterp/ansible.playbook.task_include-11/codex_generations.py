

# Generated at 2022-06-17 08:27:57.100836
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'vagrant'
    play_context.connection = 'ssh'
    play_context.become = False

# Generated at 2022-06-17 08:28:04.357515
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude as PlaybookTaskInclude

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'_raw_params': 'test.yml'}
    task = ti.check_options(task, {})
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args.get('file') is None

# Generated at 2022-06-17 08:28:13.266781
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.CLIARGS = {}

    # Test for action 'include'
    task_include = TaskInclude()
    task_include.action = 'include'

# Generated at 2022-06-17 08:28:22.251793
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-17 08:28:29.719022
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    add_all_plugin_dirs()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
   

# Generated at 2022-06-17 08:28:34.051781
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test with apply
    task = TaskInclude()
    task.args = {'apply': {'block': []}}
    assert isinstance(task.build_parent_block(), Block)

    # Test without apply
    task = TaskInclude()
    task.args = {}
    assert isinstance(task.build_parent_block(), TaskInclude)

# Generated at 2022-06-17 08:28:44.029045
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test with action 'include'
    task_include = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'other': 'test'}
    task = task_include.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml'}

    # Test with action 'include_

# Generated at 2022-06-17 08:28:54.338650
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-17 08:29:08.639792
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:29:20.215723
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:29:34.751567
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    # Test for action 'include'
    task = TaskInclude.load(
        dict(
            action='include',
            file='/path/to/file',
            name='test_task',
            tags=['tag1', 'tag2'],
            when='when_condition',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )
    task.vars = dict(
        var1='var1_value',
        var2='var2_value',
    )
    task.args = dict

# Generated at 2022-06-17 08:29:44.110170
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude

    # Create a play
    play_ds = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )
    play = Play().load(play_ds, variable_manager=None, loader=None)

    # Create a role

# Generated at 2022-06-17 08:29:52.884596
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task_include = TaskInclude()
    task_include._variable_manager = variable_manager
    task_include._loader = loader
    task_include._play_context = play_context

    # Test with an action that is not an include
    ds = {'action': 'shell', 'args': {'_raw_params': 'echo "hello world"'}}

# Generated at 2022-06-17 08:30:04.701887
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:30:18.470128
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

# Generated at 2022-06-17 08:30:25.155723
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:30:34.511021
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 08:30:46.003402
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Create a task with a valid action
    task = TaskInclude.load(dict(action='include_tasks', file='/path/to/file'), variable_manager=variable_manager, loader=loader)
    assert task.action == 'include_tasks'

    # Create a task with an invalid action

# Generated at 2022-06-17 08:30:59.178075
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a play

# Generated at 2022-06-17 08:31:07.240973
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    ti = TaskInclude()
    ds = dict(action='include', file='/tmp/foo.yml', tags=['foo', 'bar'], when='{{ foo }}')
    ti.preprocess_data(ds)

# Generated at 2022-06-17 08:31:22.943991
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test with no file specified
    data = dict(action='include')
    ti = TaskInclude()
    try:
        ti.load(data)
        assert False, 'AnsibleParserError should be raised'
    except AnsibleParserError:
        pass

    # Test with invalid options
    data = dict(action='include', file='/tmp/foo', invalid_option='foo')
    ti = TaskInclude()
    try:
        ti.load(data)
        assert False, 'AnsibleParserError should be raised'
    except AnsibleParserError:
        pass

    # Test with valid options
    data = dict(action='include', file='/tmp/foo', tags='foo')
    ti = TaskInclude()
    ti.load(data)

    # Test with apply

# Generated at 2022-06-17 08:31:32.248038
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a task with apply

# Generated at 2022-06-17 08:31:43.019492
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager

    # test for include
    data = dict(
        action='include',
        file='/tmp/foo.yml',
        tags=['tag1', 'tag2'],
        when='foo == bar',
        var1='value1',
        var2='value2',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    task.set_loader(loader)

# Generated at 2022-06-17 08:31:51.998878
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler_block import HandlerBlock
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleHandlerTaskInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleBlockTaskInclude

    # Test TaskInclude
    # Test TaskInclude with action 'include'
    ti = TaskInclude()


# Generated at 2022-06-17 08:32:05.242736
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a play

# Generated at 2022-06-17 08:32:13.970451
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    # Create a fake playbook executor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])

# Generated at 2022-06-17 08:32:24.703403
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a task include
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b'}

    # Create a parent block
    parent_block = Block()
    parent_block.vars = {'c': 'd'}

    # Create a play
    play = Play()
    play.vars = {'e': 'f'}

    # Create a play context
    play_context = PlayContext()
    play_context.vars = {'g': 'h'}

    # Create a variable manager
    variable_manager = VariableManager()
    variable

# Generated at 2022-06-17 08:32:37.171631
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:32:47.749601
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with an include action
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Task()
    task._parent.vars = {'e': 5, 'f': 6}
    assert task.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

    # Test with a role action
    task = TaskInclude()
    task.action = 'role'
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3, 'd': 4}
    task._parent = Task()
   

# Generated at 2022-06-17 08:33:00.355713
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with no file specified
    data = dict(action='include')
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'
    assert task.args['_raw_params'] is None

    # Test with file specified

# Generated at 2022-06-17 08:33:16.510116
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    from ansible.errors import AnsibleParserError

    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()

    # Test with no file specified
    data = dict(
        action='include',
        args=dict(
            apply=dict(
                block=[]
            )
        )
    )

# Generated at 2022-06-17 08:33:29.504379
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Test for TaskInclude
    task_include = TaskInclude()
    data = dict(action='include', file='test.yml')
    task = task_include.check_

# Generated at 2022-06-17 08:33:35.810783
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.tasks import Tasks

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:33:43.751182
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a task with a valid action
    task = TaskInclude()
    task.action = 'include_role'

    # Create a valid data structure
    data = {
        'action': 'include_role',
        'name': 'my_role',
        'tags': ['my_tag'],
        'when': 'my_when',
        'invalid_key': 'invalid_value',
    }

    # Create a valid context
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play

# Generated at 2022-06-17 08:33:55.983733
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action='debug', msg='Hello World')
        ]
    )
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DataLoader())

    # Create a role
    role_ds

# Generated at 2022-06-17 08:34:05.465847
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict())),
            dict(action=dict(module='debug', args=dict(msg='{{foo}}'))),
        ]
    )
    play

# Generated at 2022-06-17 08:34:12.695370
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext

    # Test TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task.vars = {}
    task.set_loader(None)
    task.set_play_context(PlayContext())
    task.set_parent(Block())
    task.set_role(None)
    task.set

# Generated at 2022-06-17 08:34:20.369346
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory

# Generated at 2022-06-17 08:34:31.937909
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    play_context = PlayContext()
    play_context._task_vars = dict(a=1, b=2)
    play_context._hostvars = dict(localhost=dict(c=3, d=4))
    variable_manager.set_play_context(play_context)

    task = TaskInclude()
    task

# Generated at 2022-06-17 08:34:44.778862
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with valid options
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'foo.yml', 'apply': {'foo': 'bar'}}
    task.check_options(task, {})

    # Test with invalid options
    task.args = {'file': 'foo.yml', 'apply': {'foo': 'bar'}, 'invalid': 'option'}
    try:
        task.check_options(task, {})
        assert False, 'AnsibleParserError not raised'
    except AnsibleParserError:
        pass

    # Test with invalid apply
    task.args = {'file': 'foo.yml', 'apply': 'foo'}

# Generated at 2022-06-17 08:35:00.526208
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.clean import module_response_deepcopy

    # Create a task include
    task_include = TaskInclude()
    task_include.action = 'include'

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._host_vars_files = dict()
    variable_manager._host_vars_files['host1'] = HostVars(variable_manager, 'host1')
    variable_manager._host_vars_files['host1'].vars = dict()

# Generated at 2022-06-17 08:35:09.227222
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Test with valid options
    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data, variable_manager=VariableManager(), loader=DataLoader())
    assert isinstance(task, TaskInclude)
    assert isinstance(task._parent, Block)
    assert task._parent.block == []

    # Test with invalid options

# Generated at 2022-06-17 08:35:20.590432
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict(action='include_role', file='foo.yml')
    task.check_options(task.load_data(data), data)

    data = dict(action='include_role', file='foo.yml', apply=dict(foo='bar'))
    task.check_options(task.load_data(data), data)

    data = dict(action='include_role', file='foo.yml', apply='bar')
    try:
        task.check_options(task.load_data(data), data)
    except AnsibleParserError as e:
        assert e.message == 'Expected a dict for apply but got str instead'
    else:
        assert False, 'AnsibleParserError not raised'


# Generated at 2022-06-17 08:35:31.094994
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:35:40.493493
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    # Test with invalid options
    data = {'action': 'include', 'file': 'test.yml', 'invalid_option': 'invalid_value'}

# Generated at 2022-06-17 08:35:52.004691
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test for TaskInclude
    ti = TaskInclude()
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo.yml'}
    task = ti.check_options(task, {})
    assert task.args['_raw_params'] == 'foo.yml'
    assert 'file' not in task.args

    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo.yml', 'apply': {}}
    task = ti.check_options(task, {})
    assert task.args['_raw_params'] == 'foo.yml'
    assert 'file' not in task.args

# Generated at 2022-06-17 08:36:01.679482
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 08:36:09.271248
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:36:18.099698
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Set the action to 'include'
    task_include.action = 'include'
    # Set the args to {'a': 1, 'b': 2}
    task_include.args = {'a': 1, 'b': 2}
    # Set the vars to {'c': 3, 'd': 4}
    task_include.vars = {'c': 3, 'd': 4}
    # Set the parent to a Block object
    task_include._parent = Block()
    # Set the vars of the parent to {'e': 5, 'f': 6}
    task_include._parent.vars = {'e': 5, 'f': 6}
    # Set the action to 'include_role'

# Generated at 2022-06-17 08:36:27.577010
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test with valid options
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task = task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml'}

    task = TaskInclude()
    task.action = 'include_role'

# Generated at 2022-06-17 08:36:53.094765
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.utils.sentinel import Sentinel

    # Test TaskInclude.check_options() with invalid options
    # for action 'include'
    task_include = TaskInclude(block=Block(), role=Role(), task_include=TaskInclude())
    task_include.action = 'include'

# Generated at 2022-06-17 08:37:02.557537
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    ti = TaskInclude()
    ti._variable_manager = variable_manager
    ti._loader = loader
    ti._play_context = play_context

    # Test with 'include' action

# Generated at 2022-06-17 08:37:16.819250
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import find_plugin_filepaths
    from ansible.plugins.loader import load_plugins
    from ansible.plugins.loader import get_all_plugin_loaders

# Generated at 2022-06-17 08:37:31.114994
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar

    play_context = PlayContext()

# Generated at 2022-06-17 08:37:37.353943
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=[]))

    # Test for 'include'
    task = TaskInclude.load(dict(action='include', file='/path/to/file', tags=['tag1', 'tag2'], when='some_condition'),
                            variable_manager=variable_manager, loader=None)
    task._parent = TaskInclude.load(dict(action='include', file='/path/to/file', tags=['tag1', 'tag2'], when='some_condition'),
                                    variable_manager=variable_manager, loader=None)

# Generated at 2022-06-17 08:37:45.950372
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test with an invalid option
    data = dict(
        action='include',
        file='/path/to/file',
        invalid_option='invalid_value',
    )
    try:
        TaskInclude.load(data)
    except AnsibleParserError as e:
        assert e.message == 'Invalid options for include: invalid_option'
        assert e.obj == data

    # Test with a valid option
    data = dict(
        action='include',
        file='/path/to/file',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data)
    assert task.args['file'] == '/path/to/file'
    assert task.args['apply'] == dict(block=[])

    # Test with a non-dict value for 'apply'