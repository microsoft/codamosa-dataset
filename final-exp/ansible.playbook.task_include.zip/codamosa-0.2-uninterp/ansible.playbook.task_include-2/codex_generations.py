

# Generated at 2022-06-17 08:28:00.681924
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude

    # Test TaskInclude
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'file1', 'apply': {'a': 1}}
    task.check_options(task, {})
    assert task.args == {'_raw_params': 'file1', 'apply': {'a': 1}}


# Generated at 2022-06-17 08:28:06.565050
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context

# Generated at 2022-06-17 08:28:16.044748
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:28:30.572074
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.include import IncludeRole

# Generated at 2022-06-17 08:28:40.561308
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
   

# Generated at 2022-06-17 08:28:47.745065
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 08:28:58.467591
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Test with valid options
    task_data = dict(
        action='include',
        file='test.yml',
        apply=dict(
            block=dict(
                name='test',
                tags=['test'],
            ),
        ),
    )
    task = TaskInclude.load(task_data, variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-17 08:29:04.234207
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test with valid options

# Generated at 2022-06-17 08:29:13.202689
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task = TaskInclude.load(
        dict(
            action='include',
            file='/tmp/foo.yml',
            tags=['foo', 'bar'],
            when='foo',
            invalid_attr='invalid',
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    assert task.action == 'include'

# Generated at 2022-06-17 08:29:21.519252
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context._task_vars = dict()

    data = dict(
        apply=dict(
            block=dict(
                ignore_errors=True
            )
        ),
        file='/path/to/file'
    )

    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'


# Generated at 2022-06-17 08:29:39.006095
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    variable_manager.set_play_context(play_context)

    # Test with 'include' action

# Generated at 2022-06-17 08:29:47.178589
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti.action = 'include'

    # Test with an empty dict
    ds = {}
    assert ds == ti.preprocess_data(ds)

    # Test with a dict containing only valid keywords
    ds = {'action': 'include', 'name': 'test', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    assert ds == ti.preprocess_data(ds)

    # Test with a dict containing invalid keywords
    ds = {'action': 'include', 'name': 'test', 'tags': ['tag1', 'tag2'], 'when': 'test', 'invalid': 'test'}
    assert ds == ti.preprocess_data(ds)

    # Test with a dict

# Generated at 2022-06-17 08:30:00.445526
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # Test for action 'include'
    # Test for invalid options
    task_include = TaskInclude()
    data = dict(action='include', file='foo.yml', invalid_option='invalid')
    task = Task()
    task.action = 'include'
    task.args = data

# Generated at 2022-06-17 08:30:09.817581
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler.definition import HandlerDefinition

    # Test for TaskInclude
    ti = TaskInclude()
    ti.action = 'include'
    ds = {'action': 'include', 'file': 'test.yml', 'tags': 'test'}
    d

# Generated at 2022-06-17 08:30:15.550136
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test with a valid task
    task = Task()
    task.action = 'include_role'
    task.args = {'name': 'my_role', 'apply': {'foo': 'bar'}}
    task = TaskInclude.check_options(task, task.args)
    assert task.args['_raw_params'] == 'my_role'
    assert task.args['apply'] == {'foo': 'bar'}

    # Test with an invalid task
    task = Task()
    task.action = 'include_role'
    task.args = {'name': 'my_role', 'apply': {'foo': 'bar'}, 'bad_opt': 'bad_value'}

# Generated at 2022-06-17 08:30:29.534984
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:30:38.956680
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

# Generated at 2022-06-17 08:30:47.098837
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role = Role

# Generated at 2022-06-17 08:30:59.292826
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:31:11.937999
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with valid options
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task.check_options(task, {})
    assert task.args == {'_raw_params': 'test.yml'}

    # Test with invalid options
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'invalid': 'invalid'}
    try:
        task.check_options(task, {})
        assert False, 'AnsibleParserError should have been raised'
    except AnsibleParserError:
        pass

    # Test with invalid options
    task = TaskInclude()
    task.action = 'include_role'

# Generated at 2022-06-17 08:31:29.727910
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 08:31:37.056597
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test for action 'include'
    data = {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    ti = TaskInclude()
    assert ti.preprocess_data(data) == {'action': 'include', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}

    # Test for action 'import_tasks'
    data = {'action': 'import_tasks', 'file': 'test.yml', 'tags': ['tag1', 'tag2'], 'when': 'test'}
    ti = TaskInclude()

# Generated at 2022-06-17 08:31:49.431148
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 08:32:04.220148
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:32:10.804388
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'file': 'test.yml'}
    task_include.vars = {'test': 'test'}
    task

# Generated at 2022-06-17 08:32:21.668261
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 08:32:31.050864
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    task_include = TaskInclude()
    task_include._role = None
    task_include._play = None
    task_include._parent = None
    task_include._block = None
    task_include._loader = None
    task_include._variable_manager = None
    task_include._task_include = None
    task_include._role_name = None
    task_include._task_vars = dict()
    task_include._play_context = PlayContext()

    # Test with action 'include'
    ds = dict(action='include', file='test.yml', tags='test')
    task_include.preprocess_data(ds)
    assert ds == dict(action='include', file='test.yml', tags='test')

    # Test

# Generated at 2022-06-17 08:32:41.686339
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 08:32:48.879910
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # Create a task include

# Generated at 2022-06-17 08:32:55.347107
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 08:33:06.723957
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = PlayContext()

    # Test for action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        tags=['tag1', 'tag2'],
        when='when_condition',
        vars=dict(
            var1='value1',
            var2='value2',
        ),
    )
    task = TaskInclude

# Generated at 2022-06-17 08:33:13.585067
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-17 08:33:24.872076
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    block_vars = dict(
        a=1,
        b=2,
        c=3,
    )
    block_args = dict(
        d=4,
        e=5,
        f=6,
    )

# Generated at 2022-06-17 08:33:34.229931
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test for action 'include'
    task = TaskInclude.load(dict(action='include', file='/tmp/test.yml'), variable_manager=variable_manager, loader=loader)
    task.vars = dict(a='1', b='2')
    task.args = dict(c='3', d='4')

# Generated at 2022-06-17 08:33:42.841912
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:33:48.794021
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test for action 'include'
    ds = {'action': 'include', 'include': 'foo.yml', 'tags': ['bar']}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert ds == {'action': 'include', 'file': 'foo.yml', 'tags': ['bar']}

    # Test for action 'include_role'
    ds = {'action': 'include_role', 'include_role': 'foo', 'tags': ['bar']}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert ds == {'action': 'include_role', 'name': 'foo', 'tags': ['bar']}

    # Test for action 'import_role'

# Generated at 2022-06-17 08:34:00.533690
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import HandlerTaskInclude

    # Test TaskInclude
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task = TaskInclude.check_options(task, {})
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args['apply'] == {'test': 'test'}

    # Test HandlerTaskInclude
    task = Task()
    task.action = 'include_role'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task

# Generated at 2022-06-17 08:34:11.217909
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import HandlerTaskInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.include import TaskIncludeArgs
    from ansible.playbook.task.include import TaskIncludeVars
    from ansible.playbook.task.include import TaskIncludeTags
    from ansible.playbook.task.include import TaskIncludeWhen
    from ansible.playbook.task.include import TaskIncludeIgnoreErrors
    from ansible.playbook.task.include import TaskIncludeNoLog
    from ansible.playbook.task.include import TaskIncludeRegister
    from ansible.playbook.task.include import TaskIncludeRunOnce

# Generated at 2022-06-17 08:34:21.963394
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler.task_include import HandlerTaskInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task.action import Action
    from ansible.playbook.task.loop import Loop
    from ansible.playbook.task.import_role import ImportRole
    from ansible.playbook.task.import_task import ImportTask

# Generated at 2022-06-17 08:34:33.795600
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:34:43.176211
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}'))),
        ]
    )

    play = Play.load(play_ds)
    block = play.get_block_list()[0]
    task = block.block[0]

    assert task.action == 'shell'
    assert task.args == dict(args='ls')

    task_ds

# Generated at 2022-06-17 08:34:56.299257
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Test TaskInclude
    # Test with 'include' action
   

# Generated at 2022-06-17 08:35:06.730442
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Test TaskInclude
    task = Task()
    task.action = 'include'
    task.args = {'file': 'foo'}
    task = TaskInclude.check_options(task, {})
    assert task.args == {'_raw_params': 'foo'}

    task = Task()
    task.action = 'include_role'
    task.args = {'file': 'foo'}
    task = TaskInclude.check_options(task, {})
    assert task.args == {'_raw_params': 'foo'}

    task = Task()

# Generated at 2022-06-17 08:35:18.616989
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 08:35:31.171888
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 08:35:40.548708
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object
    task_include = TaskInclude()
    # Create a parent Task object
    parent_task = Task()
    # Set the parent of the TaskInclude object
    task_include._parent = parent_task
    # Set the vars of the TaskInclude object
    task_include.vars = {'var1': 'value1'}
    # Set the args of the TaskInclude object
    task_include.args = {'arg1': 'value1'}
    # Set the action of the TaskInclude object
    task_include.action = 'include'
    # Call the get_vars method of the TaskInclude object
    vars = task_include.get_vars()
    # Check the result

# Generated at 2022-06-17 08:35:52.005021
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = None

    # Test for action 'include'
    data = dict(
        action='include',
        file='/path/to/file',
        tags=['tag1', 'tag2'],
        when='when_condition',
    )
    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert task.get_vars() == dict(file='/path/to/file')

    # Test for action 'include_role'

# Generated at 2022-06-17 08:36:01.674741
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars

    add_all_plugin_dirs()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])

# Generated at 2022-06-17 08:36:09.747471
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroupVars
    from ansible.vars.hostvars import HostVarsAllGroupVars
    from ansible.vars.hostvars import HostVarsInventory
    from ansible.vars.hostvars import HostVarsVars

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a hostvars object

# Generated at 2022-06-17 08:36:18.274299
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Create a dummy task
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}

    # Create a dummy block
    block = Block()
    block.vars = {'test': 'test'}

    # Create a dummy role
    role = {}

    # Create a dummy variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test': 'test'}

    #

# Generated at 2022-06-17 08:36:31.331475
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

# Generated at 2022-06-17 08:36:41.598069
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # Create a play
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action='debug', msg='Hello World'),
        ]
    )
    play = Play.load(play_ds)

    # Create a role


# Generated at 2022-06-17 08:36:53.524625
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a play

# Generated at 2022-06-17 08:37:05.943621
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with action 'include'
    data = dict(action='include', file='/tmp/test.yml')
    task = TaskInclude.load(data)
    assert task.preprocess_data(data) == data

    # Test with action 'include_role'
    data = dict(action='include_role', file='/tmp/test.yml')
    task = TaskInclude.load(data)
    assert task.preprocess_data(data) == data

    # Test with action 'import_role'
    data = dict(action='import_role', file='/tmp/test.yml')
    task = TaskInclude.load(data)
    assert task.preprocess_data(data) == data

    # Test with action 'import_tasks'

# Generated at 2022-06-17 08:37:15.716815
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.handler.task_include import TaskInclude as HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

    # Test TaskInclude
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'test.yml', 'apply': {'test': 'test'}}
    task.check_options(task, {})

# Generated at 2022-06-17 08:37:24.454872
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 08:37:35.165765
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

# Generated at 2022-06-17 08:37:45.400181
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
