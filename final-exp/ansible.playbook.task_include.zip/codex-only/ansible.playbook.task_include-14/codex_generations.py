

# Generated at 2022-06-23 07:16:18.821329
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import ansible.playbook.task as task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    apply_attrs = {'block': []}
    p_block = Block()
    play = Play().load({'name': 'foobar', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=None, loader=None)
    play_context = PlayContext(play=play)

    ti = task.TaskInclude()
    ti._parent = Block()
    ti._parent._play = play
    ti._parent._play._context = play_context
    ti._variable_manager = None
    ti._loader = action_loader

   

# Generated at 2022-06-23 07:16:29.301798
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template.template import Templar
    from ansible.parsing.splitter import split_args

    pb = Playbook()
    play_ds = dict(
        name="Test Play",
        hosts="localhost",
        gather_facts="no",
    )
    play = Play.load(play_ds, pb)
    play_context = PlayContext()
    play_context._v

# Generated at 2022-06-23 07:16:42.083704
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from v2_utils import load_tasks

    #

# Generated at 2022-06-23 07:16:49.677205
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Tests that include tasks' options can only be either `file` or `apply`
    '''
    # load() is used in `tasks/include.yml`
    # so we can use the existing test data to test the method
    test_data = {
        'action': 'include',
        'file': 'dummy',
    }

    # Test `file` option
    task = TaskInclude.load(
        data=test_data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None)
    assert 'file' in task.args

    # Test `apply` option
    test_data['apply'] = {
        'hosts': 'all',
    }

# Generated at 2022-06-23 07:16:58.757615
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude.load({'include': 'tasks.yml', 'foo': 'bar', 'tags': 'mytag'})
    assert task.get_vars() == dict(foo='bar')

    task = TaskInclude.load({'include_role': 'some_role', 'foo': 'bar', 'tags': 'mytag'})
    assert task.get_vars() == dict(foo='bar')

    task = TaskInclude.load({'include_tasks': 'tasks.yml', 'foo': 'bar', 'tags': 'mytag'})
    assert task.get_vars() == dict()

    task = TaskInclude.load({'import_tasks': 'tasks.yml', 'foo': 'bar', 'tags': 'mytag'})

# Generated at 2022-06-23 07:17:10.288687
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.plugins.loader import action_loader

    config = dict(FOO='foo', BAR='bar', BAZ='baz')
    play = Play().load({'name': 'Test Play'}, variable_manager=None, loader=None)
    role = Role().load({'name': 'Test Role'}, variable_manager=None, loader=None)
    action = action_loader.get('debug') # module: debug, args: var='foo'
    block = Block.load(dict(block=[]), play=play, task_include=None, role=role, variable_manager=None, loader=None)


# Generated at 2022-06-23 07:17:22.439775
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play

    ds1 = {'block': []}
    ds2 = {'apply': ds1}
    ds3 = {'include': ds2}

    play = Play().load(ds3, variable_manager=None, loader=None)

    task = play.get_tasks()[0]

    assert task.block.block == []
    assert task.args == {'file': 'include'}
    assert isinstance(task._parent, TaskInclude)

    # exclude property tests
    assert 'action' in task.exclude_parent
    assert 'apply' in task.exclude_parent
    assert 'block' not in task.exclude_parent
    assert 'debugger' in task.exclude_parent
    assert 'include' in task.exclude_parent


# Generated at 2022-06-23 07:17:29.951292
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Create task
    block = Block()
    role = None
    ti1 = TaskInclude(block, role)

    # Verify member variables are set from constructor
    assert ti1.statically_loaded is False

    # Create second task with task_include
    ti2 = TaskInclude(ti1)

    # Verify member variables are set from constructor
    assert ti2.statically_loaded is False

    # Verify the two tasks are not the same
    assert ti1 is not ti2

# Generated at 2022-06-23 07:17:41.266572
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    data = dict(action='include_role', args=dict(file='foo'))
    result = ti.check_options(ti.load_data(data, variable_manager=None, loader=None), data)
    assert result.args == dict(_raw_params='foo')
    assert result.action == 'include_role'

    data['args']['apply'] = dict(always='bar', msg='foobar')
    result = ti.check_options(ti.load_data(data, variable_manager=None, loader=None), data)
    assert result.args == dict(_raw_params='foo', apply=dict(always='bar', msg='foobar'))
    assert result.action == 'include_role'

    data['args']['bad_opt'] = 'foobar'

# Generated at 2022-06-23 07:17:49.830893
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Prepare mock objects
    block      = MagicMock(spec_set=Block)
    role       = MagicMock(spec_set=Role)
    task_include = MagicMock(spec_set=TaskInclude)

    # Create an instance of TaskInclude
    task_include = TaskInclude(block=block, role=role, task_include=task_include)

    # Create a TaskInclude instance and mock some of its methods in order to test get_vars
    task_include.action = "include_tasks"
    task_include.args = {'something': 'somevalue'}
    task_include._parent = MagicMock(spec_set=Block())
    task_include._parent.get_vars.return_value = {'myvars': 'myvalues'}

# Generated at 2022-06-23 07:17:56.078090
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.statically_loaded = True
    task_include2 = task_include.copy()
    assert task_include2.statically_loaded == True
    task_include.statically_loaded = False
    task_include2 = task_include.copy()
    assert task_include2.statically_loaded == False

# Generated at 2022-06-23 07:18:04.865162
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # no errors for valid options
    task = TaskInclude()
    data = dict(action='include_tasks', file="file")
    task.check_options(task.load_data(data), data)

    task = TaskInclude()
    data = dict(action='include_role', file="file")
    task.check_options(task.load_data(data), data)

    task = TaskInclude()
    data = dict(action='include', file="file")
    task.check_options(task.load_data(data), data)

    task = TaskInclude()
    data = dict(action='import_role', file="file")
    task.check_options(task.load_data(data), data)

    task = TaskInclude()
    data = dict(action='import_tasks', file="file")

# Generated at 2022-06-23 07:18:07.936448
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    t = TaskInclude(block=None, role=None, task_include=None)

    # Test that no error thrown
    assert t.statically_loaded == False

# Generated at 2022-06-23 07:18:17.933157
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Test a None value
    task_include = TaskInclude.load({})
    assert task_include.get_vars() == {}

    # Test a single value
    task_include = TaskInclude.load({'vars': {'x': 1}})
    assert task_include.get_vars() == {'x': 1}

    # Test a parent value that was not overwritten
    parent_task_include = TaskInclude.load({'vars': {'x': 1}})
    task_include = TaskInclude.load({'vars': {'y': 2}}, parent=parent_task_include)
    assert task_include.get_vars() == {'x': 1, 'y': 2}

    # Test a parent value that was overwritten

# Generated at 2022-06-23 07:18:25.631611
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-23 07:18:37.463715
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    attrs = {
        'action': 'include',
        'file': 'somefile',
        'apply': {'tags': ['all']},
        '_uuid': 'someuuid',
        '_role': 'somerole',
        '_play': 'someplay',
    }
    task = TaskInclude.load(attrs)
    assert task._variable_manager is None

    attrs['args'] = {'firstarg': 'firstargvalue'}
    task = TaskInclude.load(attrs)

# Generated at 2022-06-23 07:18:49.050384
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.sentinel import Sentinel

    playbook_hosts = 'all'
    loader = DataLoader()
    loader.set_basedir(os.path.join(os.path.dirname(__file__), '../../..'))
    loader.set_collection_paths(['/tmp/ansible_collections'])
    hosts = [Host(name='localhost', port=22, ssh_host='')]

    main_block = Block()
    main_block.role = Sentinel()
   

# Generated at 2022-06-23 07:18:58.650640
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Note: the following unit test condition is not exhaustive as the validation is also performed in the check_options
    # method.
    ti = TaskInclude()
    data = {'action': 'include', 'apply': 'x', 'tags': 'y', 'when': 'z', 'some_new_attr': 'a'}
    data = ti.preprocess_data(data)
    assert 'action' in data
    assert 'tags' in data
    assert 'when' in data
    assert not hasattr(data, 'apply')
    assert not hasattr(data, 'some_new_attr')

# Generated at 2022-06-23 07:19:08.640567
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    test_TaskInclude_load
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    ti = TaskInclude()

    ti.block = Block()
    ti.block.root_block = ti.block
    ti.block.vars = dict(foo="bar")
    ti.block.defaults = dict()
    ti.block._play = None
    ti.block.parent_block = None

    ti.role = None

    ti._play = None
    ti._parent = None
    ti._role = None
    ti._loader = None
    ti._variable_manager = None

    data = dict(
        action="include",
        file="dummy/file",
        other="dummy/other"
    )

    # test invalid arg


# Generated at 2022-06-23 07:19:21.201676
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = {
        'action': 'include_tasks',
        'file': 'somefile.yml',
        'ignore_errors': True,
        'bad_option': 'will be removed',
        'loop': 'with_somelist',
        'loop_with_items': 'item1,item2',
        'apply': {
            'block': 'will be removed',
            'loop': 'with_items',
            'with_items': ['item1', 'item2'],
            'bad_option': 'will be removed',
        }
    }

# Generated at 2022-06-23 07:19:27.568511
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    play = Play()
    play.vars = dict()
    play.task_vars = dict()
    block = Block(play=play)
    task_include = TaskInclude(block=block)
    assert task_include.statically_loaded == False

# Generated at 2022-06-23 07:19:40.467796
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Create a task using the template 'include'

    ds = dict(
        action='include',
        args=dict(
            _raw_params='import_playbook.yml',
            apply=dict(
                block=[]
            )
        )
    )
    ti = TaskInclude(task_include=TaskInclude(ds))

    t = ti.check_options(ti.load_data(ds), ds)
    assert isinstance(t, TaskInclude)

    # Test with an invalid option (bad_opt)
    ds['args']['bad_opt'] = 'value'
    ti = TaskInclude(task_include=TaskInclude(ds))

# Generated at 2022-06-23 07:19:50.995501
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # For test. Make up some fake data.
    data = {
        'name': 'test name',
        'action': 'test action',
        'attribute1': 'test attribute',
        'when': 'test anywhen',
    }

    # Create instance of TaskInclude to test
    ti = TaskInclude()

    # Load fake data to TaskInclude instance
    ti.load_data(data)

    # Create instance of TaskInclude to compare
    ti_compare = TaskInclude()

    # Load fake data to TaskInclude instance
    ti_compare.load_data(data)

    # Copy original TaskInclude instance to new TaskInclude instance
    ti_copy = ti.copy(exclude_parent=False)

    # Test if the original and copied TaskInclude instances are equal
    assert ti == ti_compare

# Generated at 2022-06-23 07:20:04.913449
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ansible_module = type('FakeModule', (object,), dict(fail_json=lambda *x: None))

    data = dict(
        action='include',
        ignore_errors=True,
        file='tasks/test.yml',
        tags=['bar', 'baz'],
        ignore_errors=True,
        loop='{{ items }}',
        loop_with=dict(var1='test1', var2='test2'),
        when='ansible_os_family=="RedHat"'
    )

    task_include = TaskInclude(block=None, role=None, task_include=None)
    task_include.args = data

    # Test valid args
    assert task_include.preprocess_data(data) == data

    # Test invalid arguments

# Generated at 2022-06-23 07:20:17.045713
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method tests the method build_parent_block of class TaskInclude
    '''

    # Create an instance of TaskInclude
    test_task_include = TaskInclude()

    # One test case where 'apply' is not specified in the args of TaskInclude
    test_task_include.args = {}

    # Calling the method build_parent_block
    test_p_block = test_task_include.build_parent_block()

    # Checking if the parent block is equal to TaskInclude instance
    assert test_p_block == test_task_include

    # One test case where 'apply' is specified in the args of TaskInclude
    test_task_include.args = {'apply': {}}

    # Calling the method build_parent_block
    test_p_block = test_task_include.build_

# Generated at 2022-06-23 07:20:23.257364
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    The `task_include.load()` method has the following validations:
    - Items in `task.args` must be in `TaskInclude.VALID_ARGS` (the set of valid arguments) except when `task.action` is
      `include_tasks`.
    - If `task.action` is in `C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS`, then `task.args` must contain '_raw_params';
    - If `task.args` contains 'apply' and `task.action` is not in `C._ACTION_INCLUDE_TASKS`, then it is raise a
      `AnsibleParserError` exception;
    - If 'apply' is not a dict then it is raise a `AnsibleParserError` exception.
    '''

# Generated at 2022-06-23 07:20:33.179624
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    ti = task.check_options({'action': 'include',
                             '_raw_params': 'included_playbook',
                             'apply': {
                                 'block': []
                             },
                             'bad_attr1': 'bad_value1',
                             'bad_attr2': 'bad_value2',
                             'file': 'file_value'
                             }, {})

    assert ti.args.get('_raw_params') == 'included_playbook'
    assert ti.args.get('bad_attr1') is None
    assert ti.args.get('file') is None

# Generated at 2022-06-23 07:20:41.389751
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(dict())
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)
    ti = TaskInclude()

    # No arg data
    data = {}
    task = ti.check_options(ti.load_data(data, variable_manager=variable_manager), data)
    assert task.args == {'_raw_params': None}

    # No 'file' for 'action' in C._ACTION_ALL_PROPER_INCLUDE_TASKS
    data = {'debug': 'msg'}

# Generated at 2022-06-23 07:20:52.447722
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Check with action `include`
    task_include = TaskInclude.load(
        {
            'include': 'test',
        },
        block=None, role=None, task_include=None,
        variable_manager=None, loader=None
    )
    assert task_include.action == 'include'
    assert task_include.args == {'file': 'test', '_raw_params': 'test'}

    # Check with action `include_role`
    task_include = TaskInclude.load(
        {
            'include_role': 'test',
        },
        block=None, role=None, task_include=None,
        variable_manager=None, loader=None
    )
    assert task_include.action == 'include_role'

# Generated at 2022-06-23 07:21:03.828463
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # validate error raised when no file specified
    yaml_data = """---
- include:
    apply:
        tags: somestuff
        ignore_errors: True
        vars:
            var1: value1
"""
    action = 'include'
    block = None
    role = None

    yaml_ds = loader.load(yaml_data)[0]
    ti = TaskInclude.load(yaml_ds, block=block, role=role, task_include=Sentinel)
    from ansible.playbook.block import Block
    assert isinstance(ti, TaskInclude)

# Generated at 2022-06-23 07:21:09.901523
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.vars = {'a': 'b'}
    task_include.action = 'include'
    task_include.args = {'x': 'y'}

    assert task_include.get_vars() == {'a': 'b', 'x': 'y'}

    task_include.action = 'include_role'
    task_include.args = {'x': 'y'}

    assert task_include.get_vars() == {'a': 'b'}

    task_include.action = 'import_tasks'
    task_include.args = {'x': 'y'}

    assert task_include.get_vars() == {'a': 'b'}

# Generated at 2022-06-23 07:21:18.086853
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti_tasks = [
        {'name': 'copy', 'copy': 'src=a dest=b'},
        {'include_tasks': 'a.yml'},
        {'block': [{'include': 'a.yml'}, {'include': 'b.yml'}]}
    ]

    for ti_task in ti_tasks:
        t = TaskInclude(Task(), TaskInclude())
        t.load(ti_task, variable_manager=None, loader=None)
        new_t = t.copy()
        assert t.action == new_t.action
        assert t._parent is not new_t._parent
        assert t._role is new_t._role
        assert t._unsafe_proxy is new_t._unsafe_proxy
        assert t._block is new_t._

# Generated at 2022-06-23 07:21:28.580293
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Prepare context for load
    pc = PlayContext()
    pc.variable_manager = None
    pc.loader = None
    pc._play = None
    pc.task_vars = dict()
    pc.md5sum = Sentinel()
    # pc.new_stdin = Sentinel()
    pc.new_stdin = True

    # block_data is loaded as a task_include_data
    block_data = dict(
        action='block',
        when=AnsibleUnicode('dummy'),
        block=[]
    )

    # task_include_data is loaded

# Generated at 2022-06-23 07:21:35.302255
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # check TaskInclude.check_options validation with include task
    task_incl = TaskInclude()
    data = {'action': 'include', 'args': {'_raw_params': 'A'}}
    task_incl.check_options(task_incl.load_data(data), data)
    data['args']['apply'] = 'A'
    task_incl.check_options(task_incl.load_data(data), data)
    data['args']['apply'] = {'A': 'B'}
    task_incl.check_options(task_incl.load_data(data), data)
    data['args']['file'] = 'A'
    task_incl.check_options(task_incl.load_data(data), data)

# Generated at 2022-06-23 07:21:46.271990
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    def apply_attrs_dict(d):
        return {k: v for k, v in d.items() if k in ('ignore_errors', 'name', 'tags',  'register', 'run_once', 'when')}

    def load(ti, d, ti_kwargs=None):
        d = dict(d)
        d.update(ti_kwargs or {})
        return ti.load(d)

    task_include = TaskInclude()
    data = dict(action='include_role')

    # action is required
    with pytest.raises(AnsibleParserError) as excinfo:
        load(task_include, dict(action=''))
    assert 'No action detected in task. This often indicates a misspelled module name' in str(excinfo.value)

# Generated at 2022-06-23 07:21:58.580335
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    check_options_call_count = 0
    def dummy_check_options(self, task, data):
        '''
        Method to be used as a side effect of 'TaskInclude.load' as it (check_options)
        is not static and can't be replaced directly in the method.
        '''
        nonlocal check_options_call_count, task_include
        check_options_call_count += 1
        task_include = self

        return task


    task_include = None
    check_options_call_count = 0
    data = dict(
        file='C:\\file.yml',
        action=C.ACTION_INCLUDE,
        _role=dict(name='test', path='/some/path/roles/test')
    )


# Generated at 2022-06-23 07:22:11.317430
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''Test method preprocess_data of class TaskInclude'''
    # Test no change when using an unknown action
    t = TaskInclude()
    assert t.preprocess_data({'file': 'foo', 'action': 'shell'}) == {'file': 'foo', 'action': 'shell'}

    # Test attribute filtering
    changed = t.preprocess_data({'file': 'foo', 'action': 'include_role', 'import_role': 'foo', 'collections': ['foo']})
    assert changed['action'] == 'include_role'
    assert 'import_role' not in changed
    assert changed['collections'] == ['foo']

    # Test import_playbook and import_tasks
    # Attributes 'action', 'freeze_tags' and 'ignore_tags' are static. Other attributes need to be copied.


# Generated at 2022-06-23 07:22:17.881883
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method tests the "build_parent_block" method of the TaskInclude class
    '''
    from ansible.playbook.block import Block
    task_include = TaskInclude()
    task_include_parent = TaskInclude()
    task_include._parent = task_include_parent
    assert type(task_include.build_parent_block()) == Block

TaskInclude.register_attribute(FieldAttribute('static', False, bool, None))
TaskInclude.register_attribute(FieldAttribute('statically_loaded', True, bool, None))

# Generated at 2022-06-23 07:22:29.622604
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    # Setup required objects
    context = PlayContext()
    play = Play.load(dict(name='Test Play', hosts='all'), variable_manager=VariableManager(), loader=DataLoader(), variable_manager=VariableManager(), loader=DataLoader())
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()
    variable_manager._options_vars = dict()
    inventory = InventoryManager(loader=DataLoader())

# Generated at 2022-06-23 07:22:41.723418
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    block = dict(
        name="test.yml",
        parent="",
        action="include",
        tasks=[],
        meta={},
        handlers=[],
        vars={},
    )
    task = TaskInclude(block=block)
    ds = dict(
        action="include",
        file="test.yml",
        noop="True",
        meta=dict(
            bar="baz",
        ),
        foo="bar",
    )
    task.preprocess_data(ds)
    assert len(task.tasks) == 3
    assert task.action == "include"
    assert task.args["file"] == "test.yml"
    assert task.noop == "True"
    assert task.meta == dict(
        bar="baz",
    )

# Generated at 2022-06-23 07:22:47.832371
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import pytest

    # Create task with bad options
    task = TaskInclude()
    data = dict()
    data.update(file='file.yml')
    data.update(bad_option='haha')

    # True case
    data.update(action='include')
    task.preprocess_data(data)
    # False case
    with pytest.raises(AnsibleParserError):
        data.update(action='import_playbook')
        task.preprocess_data(data)

# Generated at 2022-06-23 07:22:52.834506
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude(block=None, role=None, task_include=None)
    assert isinstance(task_include, TaskInclude)

    task_include = TaskInclude(block=Block(), role=Role(), task_include=None)
    assert isinstance(task_include, TaskInclude)

# Generated at 2022-06-23 07:23:01.991349
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from ansible.playbook.role import Role


# Generated at 2022-06-23 07:23:15.571344
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    variable_manager = VariableManager()
    loader = DataLoader()
    path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/playbook/block.py')
    attrs = {u'apply': {u'name': u'some_name', u'block': [], u'vars': {}}}
    ti = TaskInclude()
    ti.args = attrs
    parent_block = ti.build_parent_block()
    assert isinstance(parent_block, Block), "build_parent_block() returned '%s' instead of Block" % type(parent_block)

# Generated at 2022-06-23 07:23:28.066189
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # no error raised when unexpected keyword is passed to include task
    ds = {'include': ['/path/to/file1', {'tags': 'tag1'}], 'tags': ['tag1', 'tag2']}
    task = TaskInclude.load(ds, loader=None)
    new_ds = task.preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert len(new_ds) == 1
    assert 'include' in new_ds

    # error raised when unexpected keyword is passed to role task
    ds = {'include_role': ['/path/to/file1', {'tags': 'tag1'}], 'tags': ['tag1', 'tag2']}
    task = TaskInclude.load(ds, loader=None)

# Generated at 2022-06-23 07:23:41.282747
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # set up test objects
    play_ds = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict(filter='ansible_distribution'))),
        ],
    )

    # normal play
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DataLoader())
    assert play.get_vars() == dict()

    # include with args
    task = Task.load(dict(action='include', args=dict(foo='bar')),
                     play=play, variable_manager=play._variable_manager, loader=play._loader)
    assert task.get_vars() == dict(foo='bar')

    # include with vars
    task = Task

# Generated at 2022-06-23 07:23:45.041768
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    TaskInclude.apply = FieldAttribute(isa='dict')
    task_include = TaskInclude(block=None, role=None, task_include=None)
    task_include.apply = {'blocked': True}
    
    # TODO write this unit test
    #task_include.build_parent_block()

# Generated at 2022-06-23 07:23:58.025919
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name = "Ansible Play 1",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action='include_tasks', args=dict(file='foobar.yml'))
        ]
    )


# Generated at 2022-06-23 07:24:03.770471
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play

    from ansible.tqm.tqm import TaskQueueManager
    from ansible.utils.sentinel import Sentinel

    loader = DummyLoader()
    tqm = TaskQueueManager()
    tqm.loader = loader
    tqm.variable_manager = DummyVariableManager()

    play = Play.load(dict(
        name="Does not matter",
        hosts=['all'],
        gather_facts=False,
        tasks=dict(
            action=dict(
                include="include_task_filename.yml",
            )
        )
    ), tqm, loader=loader)
    play.post_validate(HandlerTaskInclude.SUPPORTED_INCLUDE_TAGS)
    play._compile_roles_handlers()

   

# Generated at 2022-06-23 07:24:14.887559
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Create a TaskInclude object with task_include as None
    ti = TaskInclude()

    # Check whether the type of the object is the same as the class it is instance of
    assert type(ti) == TaskInclude

    # Check whether the statically_loaded attribute is a boolean
    assert isinstance(ti.statically_loaded, bool)

    # Call the load method with __file__ as value of data
    ti1 = TaskInclude.load(__file__)

    # Check whether the type of the object is the same as the class it is instance of
    assert type(ti1) == TaskInclude

    # Call the load method with __file__ as value of data and None as block, role and task_include
    ti = TaskInclude.load(__file__, block=None, role=None, task_include=None)

    #

# Generated at 2022-06-23 07:24:27.102268
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    loader = None
    variable_manager = VariableManager(loader=loader, inventory=Inventory("localhost"))
    playbook = Playbook.load("localhost", variable_manager=variable_manager, loader=loader)
    play_context = PlayContext()
    role = Role()
    block = Block()
    p_block = Block()
    b_block = Block()

# Generated at 2022-06-23 07:24:33.573973
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # When 'apply' attr is not specified
    # Setup vars
    args_1 = {'foo': 'bar', 'baz': 'qux'}
    # Build task
    task = TaskInclude(task_include=None, role=None, block=None)
    task.args = args_1
    # Assertion
    assert task.build_parent_block() is task

    # When 'apply' attr is specified
    # Setup vars
    args_2 = {'foo': 'bar', 'baz': 'qux', 'apply': {'foo': 'baz', 'baz': 'qux'}}
    # Build task
    task = TaskInclude(task_include=None, role=None, block=None)
    task.args = args_2
    # Assertion

# Generated at 2022-06-23 07:24:43.716761
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    t = TaskInclude()

    # Test with no apply
    data = dict(_hosts=["hostname"], name="hostname")
    t.load_data(data)
    assert t == t.build_parent_block()

    # Test with apply with no block
    data = dict(_hosts=["hostname"], name="hostname", apply=dict())
    t.load_data(data)
    assert t == t.build_parent_block()

    # Test with apply with block
    data = dict(_hosts=["hostname"], name="hostname", apply=dict(block=[]))
    t.load_data(data)
    assert t != t.build_parent_block()

# Generated at 2022-06-23 07:24:54.218591
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = dict(
        action='- include: test.yml',
        file='test.yml'
    )
    ti = TaskInclude.load(data)
    assert ti.args['file'] == 'test.yml'
    assert ti.args['_raw_params'] == 'test.yml'

    data['action'] = '- import_playbook: test.yml'
    try:
        TaskInclude.load(data)
        assert False, 'Invalid options for import_playbook should throw an exception'
    except AnsibleParserError:
        assert True

    data = dict(
        action='- import_playbook: test.yml',
        file='test.yml'
    )

# Generated at 2022-06-23 07:25:08.110803
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    This method is used to test preprocess_data method of TaskInclude class
    '''
    ds = {'foo': 'bar'}
    ti = TaskInclude()
    result = ti.preprocess_data(ds)
    assert result == {'foo': 'bar'}, 'Unexpected preprocess_data result when foo present'

    ds = {'action': 'include', 'foo': 'bar'}
    ti = TaskInclude()
    result = ti.preprocess_data(ds)
    assert result == {'foo': Sentinel}, \
        'Unexpected preprocess_data result when foo present and action is include'

    ds = {'action': 'include_role', 'foo': 'bar'}
    ti = TaskInclude()
    result = ti.preprocess_data(ds)

# Generated at 2022-06-23 07:25:18.213980
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    class FakeVariableManager:
        # This is a helper class to test the copy method
        def __init__(self, task_vars):
            self.task_vars = task_vars

        def get_vars(self, loader=None, play=None, task=None, include_hostvars=True, include_delegate_to=True):
            return self.task_vars

        def set_host_variable(self, host, varname, value):
            pass

    class FakeTask:
        # This is a helper class to test the copy method
        def __init__(self, action, args, task_vars):
            self.action = action
            self.args = args
            self.vars = task_vars
            self._parent = None

# Generated at 2022-06-23 07:25:25.977616
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    def check_preprocessing(task_action, ds):
        ti = TaskInclude()
        task_info = ti.preprocess_data(ds)
        return task_info

    # Check that we allow all attributes for include
    ds = dict(action='include', args=dict(file='bla', foo='bar', baz='bat'))
    ret = check_preprocessing('include', ds)
    assert ret['action'] == 'include'
    assert ret['args']['file'] == 'bla'
    assert ret['args']['foo'] == 'bar'
    assert ret['args']['baz'] == 'bat'

    # Check that we allow all attributes for include_tasks

# Generated at 2022-06-23 07:25:38.174313
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    :return:
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.listify import listify_lookup_plugin_terms


# Generated at 2022-06-23 07:25:47.754008
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext

    filename = 'test_TaskInclude_preprocess_data.yml'
    myrole = RoleDefinition.load('test_role', 'ansible.cfg', filename=filename, loader=None)
    myplay = myrole.get_playbook_data()
    myplay = myplay[0]
    myplay._tasks[0].role = myrole
    myplay._tasks[0]._parent = myplay
    myplay._tasks[0]._play = myplay
    myplay.vars = FieldAttribute(myplay)
    myplay.vars.vars = {
        'foo': 'bar',
    }

# Generated at 2022-06-23 07:25:58.808866
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    test_data = {
        'include': 'test-include.yml',
        'loop': 'test-loop.yml',
        'import_playbook': 'test-playbook.yml',
    }
    for task in test_data:
        test_data[task]['action'] = task
        # Unit test for method check_options of class TaskInclude
        def validation_test(task, data, valid_args=None, valid_action=None, valid_attrs=None, invalid_attrs=None):
            p = TaskInclude.load(
                data[task],
                block=None,
                role=None,
                task_include=None,
                variable_manager=None,
                loader=None,
            )
            # Check valid options
            if valid_args is not None:
                assert fro

# Generated at 2022-06-23 07:26:08.573819
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Prepare and setup TaskInclude instance
    block = Block()
    role = None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    ti.action = 'include'

    # Setup data for test cases
    task_data1 = {'action': 'include', 'file': C.DEFAULT_PLAYBOOK_PATH}
    task_data2 = {'action': 'include', 'file': C.DEFAULT_PLAYBOOK_PATH, 'apply': {'block': []}}
    task_data3 = {'action': 'include', 'file': C.DEFAULT_PLAYBOOK_PATH, 'apply': 'some string'}