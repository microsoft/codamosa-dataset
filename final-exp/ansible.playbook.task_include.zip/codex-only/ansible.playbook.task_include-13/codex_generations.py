

# Generated at 2022-06-23 07:16:17.824331
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    import copy
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.utils.hashing import hash_params
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    with open('/etc/passwd', 'r') as f:
        hash_content = hash_params(f.read())


# Generated at 2022-06-23 07:16:28.173943
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class TaskInclude
    '''

    import json
    from ansible.playbook.play_context import PlayContext

    # This test should work if we add new task attributes
    for action in C._ACTION_ALL_INCLUDE_TASKS:
        data = {'action': action, 'task_include': object(), 'block': object()}


# Generated at 2022-06-23 07:16:33.888973
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include._parent = 'parent'
    assert task_include.build_parent_block() == task_include
    # Test the assignation of 'block'
    p_block = task_include.build_parent_block()
    assert p_block.block == []


# Generated at 2022-06-23 07:16:45.020587
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options of class TaskInclude

    This checks that:
    1. Check that check_options raises an exception when "apply" is present and action
       is not in C._ACTION_INCLUDE_TASKS
    2. Check that deduplicating "file" alias works as expected
    3. Check that check_options raise an exception when invalid arguments are present
    '''
    # import needed modules
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Set up mocks for testing
    ti = TaskInclude()

# Generated at 2022-06-23 07:16:51.997623
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Test the module has correct attributes
    '''
    import ansible.playbook.task_include

    t = ansible.playbook.task_include.TaskInclude()

    fields = [ "statically_loaded", "role" ]
    assert hasattr(t, '_role')
    assert hasattr(t, '_statically_loaded')
    assert hasattr(t, '_task_include')
    assert set(fields) == set(t.__dict__.keys())


# Generated at 2022-06-23 07:17:00.011978
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    task_data = dict(
        action='include_role',
        name='myrole'
    )
    task = TaskInclude.load(task_data)
    assert task._parent is None

    play_data = dict(
        name='fakeplay',
        hosts='all',
        roles='myrole',
    )
    play = Play.load(play_data)
    assert play._basedir is None
    assert play._parent_role is None


# Generated at 2022-06-23 07:17:07.679576
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    task_include = TaskInclude(block=None, role=None, task_include=None)

    assert isinstance(task_include, Task)
    assert task_include.__class__.__name__ == 'TaskInclude'
    assert task_include._parent is None
    assert task_include._role is None
    assert task_include._block is None
    assert task_include._name is None
    assert task_include._role_name is None
    assert task_include._task_include is None
    assert task_include.statically_loaded is False

# Generated at 2022-06-23 07:17:18.996452
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class BlockStub:
        def __init__(self, *args, **kwargs):
            print(kwargs)
            self._play = kwargs['play']
            self._task_include = kwargs['task_include']
            self._role = kwargs['role']
            self._variable_manager = kwargs['variable_manager']
            self._loader = kwargs['loader']
            self._parent = kwargs['parent']

        def __repr__(self):
            return 'block'

    Block.load = BlockStub
    TaskInclude._variable_manager = Sentinel('_variable_manager')
    TaskInclude._loader = Sentinel('_loader')

    block = TaskInclude(block=None, role=None, task_include=None)
    block._parent = Sentinel('parent')
    block

# Generated at 2022-06-23 07:17:25.316756
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    with pytest.raises(AnsibleParserError) as excinfo:
        TaskInclude.preprocess_data({
            'action': 'include',
            'file': 'foo',
            'tags': ['all', 'include'],
            'invalid_attr': 'invalid',
        })

    assert 'is not a valid attribute for a TaskInclude' in str(excinfo.value)


# Generated at 2022-06-23 07:17:36.331877
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class MockedVariableManager():
        def __init__(self):
            self.vars = dict()

    class MockedLoader():
        def __init__(self):
            pass

    class MockedPlay():
        def __init__(self):
            self.vars = dict()

    class MockedInclude():
        def __init__(self):
            self.vars = dict()

    # We create a new instance of MockedVariableManager for every test
    variable_manager = MockedVariableManager()

    # We create a new instance of MockedLoader for every test
    loader = MockedLoader()

    # We create a new instance of MockedPlay for every test
    play = MockedPlay()

    # We create a new instance of MockedInclude for every test
    task_include = MockedInclude()

    # Empty

# Generated at 2022-06-23 07:17:47.113320
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.utils.vars
    playbook_file = 'test_build_parent_block.yml'
    display.verbosity = 3
    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = ansible.vars.manager.VariableManager(loader=loader, inventory=inventory)
    play = ansible.playbook.play.Play().load(
            playbook_file,
            variable_manager=variable_manager,
            loader=loader
            )
   

# Generated at 2022-06-23 07:17:58.817918
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.task
    ti = ansible.playbook.task.TaskInclude()
    task = object()
    bad_opts = [1, 2, 3, 4]
    data = object()

    def test_case(action, args, should_raise):
        task.action = action
        task.args = args

        # check options returns task even when raising exception
        try:
            ret = ti.check_options(task, data)
            assert not should_raise
            assert ret == task
        except AnsibleParserError:
            assert should_raise
            assert task.args['_raw_params'] is not None

    # No file path
    test_case('include', {}, True)

    # Bad keyword

# Generated at 2022-06-23 07:18:02.858903
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    my_input = {'include': 'foo.yml'}
    my_output = {'include': 'foo.yml', 'action': 'include', '_raw_params': 'foo.yml', '_uses_shell': False}

    assert ti.preprocess_data(my_input) == my_output

# Generated at 2022-06-23 07:18:05.552431
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude(block=None, role=None, task_include=None)
    assert task_include is not None

# Generated at 2022-06-23 07:18:16.193024
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    variable_manager = VariableManager()
    ti = TaskInclude()

    # create a fake play context for tests
    pc = PlayContext()
    pc.remote_addr = Sentinel()
    pc.connection = Sentinel()
    pc.port = Sentinel()  # not sure why this is needed

    # bare minimum data to cause errors
    data = {}
    task = ti.load(data, variable_manager=variable_manager, loader=loader)
    assert task.action == 'include'
    assert task.args['_raw_params'] is None

    # missing file

# Generated at 2022-06-23 07:18:28.509396
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar


# Generated at 2022-06-23 07:18:39.279849
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    from ansible.playbook.play_context import PlayContext
    from six.moves import StringIO
    from ansible.plugins.loader import get_all_plugin_loaders

    class MockVariableManager(object):
        def __init__(self, loader=None):
            self._loader = loader
            self.extra_vars = dict()
            self.vars_cache = dict()

        def set_loader(self, loader):
            self._loader = loader

        def set_nonpersistent_facts(self, facts):
            pass

        def set_host_variable(self, host, varname, value):
            pass

        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return {'var1': 'val1'}


# Generated at 2022-06-23 07:18:49.916595
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with a task that only has 'file' and 'apply' args
    data = dict(
        action='include',
        file='hello.yml',
        apply=dict(),
    )
    ti = TaskInclude()
    task = ti.check_options(
        ti.load_data(data),
        data
    )
    assert task.args['file'] == 'hello.yml'
    assert task.args['apply'] == {}

    # Test with a task that only has 'file' and 'apply' args
    data = dict(
        action='include',
        file='hello.yml',
        whatever_arg=42,
    )
    ti = TaskInclude()

# Generated at 2022-06-23 07:19:00.670850
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # create a 'fake' play for the tests
    class FakePlay(object):
        pass

    fake_play = FakePlay()

    # create a 'fake' role for the tests
    class FakeRole(object):
        pass

    fake_role = FakeRole()
    # Ansible is using Role to build the lookup path of the include files
    fake_role.get_path = lambda: os.path.join(os.path.dirname(__file__), 'roles', 'a_role')

    # create a 'fake' VariableManager for the tests
    class FakeVarsMgr(object):
        pass

    fake_varsmgr = FakeVarsMgr()

    # create a 'fake' loader for the tests
    class FakeLoader(object):
        pass

    fake_loader = FakeLoader()

    test_module_path

# Generated at 2022-06-23 07:19:02.716276
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert isinstance(ti, TaskInclude)

    ti = TaskInclude(task_include=1)
    assert isinstance(ti, TaskInclude)
    assert ti.task_include == 1

# Generated at 2022-06-23 07:19:11.128013
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    d = {}
    d['action'] = 'include'
    d['vars'] = {'a': 'b'}
    d['args'] = {'file': 'x.yml'}
    t = TaskInclude.load(d)
    assert t.action == 'include'
    assert t.args['file'] == 'x.yml'
    assert t.vars['a'] == 'b'
    d['action'] = 'include_role'
    d['tags'] = ['t1']
    d['when'] = 'blah'
    d['name'] = 'foo'
    d['loop'] = 'wibble'
    t = TaskInclude.load(d)
    assert t.action == 'include_role'
    assert t.name == 'foo'

# Generated at 2022-06-23 07:19:22.828811
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test to check behavior of method check_options for class TaskInclude
    :return:
    '''
    from ansible.playbook.block import Block
    class MockBlock(Block):
        def __init__(self):
            self._parent = None
            self._play = None
            self._role = None
            self._loader = None
            self._variable_manager = None

    b = MockBlock()

    class MockParent(object):
        def __init__(self):
            self.get_vars = lambda: dict()
            self._loader = None
            self._variable_manager = None

    ti = TaskInclude(block=b)
    ti._parent = MockParent()
    ti.statically_loaded = False

    # check_options should fail without a file option

# Generated at 2022-06-23 07:19:33.186239
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    unit test to verify get_vars works as expected
    '''
    loader = None
    variable_manager = None
    play = None
    block_parent = None
    role = None

    # test for task include
    block = Block.load(dict(
        tasks=[
            dict(include=dict(file='test_file', args=dict(test_var='test_val'))),
            dict(include=dict(file='test_file', args=dict(test_var='test_val'))),
        ]
    ), play=play, block_parent=block_parent, role=role, task_include=None, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 07:19:36.551195
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded == True

# Generated at 2022-06-23 07:19:40.877136
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 'b', '_raw_params': './test.yml'}
    task_include.statically_loaded = True

    result = task_include.copy(exclude_parent=True, exclude_tasks=True)
    assert result.action == 'include'
    assert result.args == {'a': 'b', '_raw_params': './test.yml'}
    assert result.statically_loaded is True
    assert result._parent is None
    assert result._tasks == []



# Generated at 2022-06-23 07:19:44.348467
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    task = ti.copy(exclude_parent=False, exclude_tasks=False)
    assert task.statically_loaded == True


# Generated at 2022-06-23 07:19:54.728661
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import sys

    class MockVariableManager(object):
        pass

    class MockLoader(object):
        pass

    # Create a mock of class Block
    blk = block.Block()
    blk._play = block.Block()
    blk._play._hosts = ['localhost']
    blk._play._basedir = './'
    blk._parent = block.Block()
    blk._parent._role = block.Block()
    blk._parent._role._role_name = 'testRole'
    blk._role = block.Block()
    blk._block  = block.Block()

    # Create a mock of class Task
    tsk = task.Task()
    tsk._parent = block.Block()


# Generated at 2022-06-23 07:20:04.463036
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Get the include block and the parent block
    include_block = TaskInclude._find_include_block('test/test_include.yaml', 'test/test.yaml')
    parent_block = include_block.build_parent_block()

    # Test the result
    assert isinstance(parent_block, TaskInclude)
    assert dict(parent_block.args) == dict(include_block.args)
    assert parent_block._parent._role == 'test'
    assert parent_block._parent._task.action == 'include'



# Generated at 2022-06-23 07:20:12.479751
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    fake_loader = DictDataLoader({
        "does/not/exist.yml": "",
    })

    fake_vars_manager = VariableManager()

    actions = ('include', 'import_tasks', 'include_role', 'import_role', 'include_tasks')
    for action in actions:
        play_context = dict(
            ansible_play_hosts='',
        )


# Generated at 2022-06-23 07:20:21.397303
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.utils.vars import combine_vars

    task = TaskInclude()
    task.args = {}
    task.action = 'include'
    task.vars = {'a': 'b'}
    task._role = None
    task._play = None
    task._play_context = PlayContext()
    task._role_params = {}
    task._task_include = None
    task.tags = []
    task.when = None

    new_me = task.copy(exclude_parent=True)

    assert task.action == new_me.action
    assert task.vars == new_me.vars
    assert task._role == new_me._role
   

# Generated at 2022-06-23 07:20:26.107164
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    o = TaskInclude()
    assert o.__class__.__name__ == 'TaskInclude'
    assert isinstance(o, TaskInclude)
    assert isinstance(o, Task)

# Generated at 2022-06-23 07:20:36.047357
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''We need to include the args of the include into the vars as
    they are params to the included tasks. But ONLY for 'include' '''

    task = TaskInclude()
    task.action = 'include'
    task.args = {'t1':'value1', 't2':'value2', 't3':'value3'}
    vars = task.get_vars()
    assert 't1' in vars.keys()
    assert vars['t1'] == 'value1'
    assert 't2' in vars.keys()
    assert vars['t2'] == 'value2'
    assert 't3' in vars.keys()
    assert vars['t3'] == 'value3'



# Generated at 2022-06-23 07:20:48.882867
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-23 07:20:52.451073
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True

    new_me = ti.copy()
    assert new_me.statically_loaded == True


# Generated at 2022-06-23 07:21:03.828050
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # A task include object loaded with a task_data dict
    task_data = dict(
        action='include',
        file='some_file.yml',
        _raw_params='some_file.yml',
        name='task_include_task',
    )
    task_include = TaskInclude.load(
        task_data,
        loader=None,
        variable_manager={},
    )
    assert task_include.action == 'include'
    assert task_include.args['file'] == 'some_file.yml'
    assert task_include.args['_raw_params'] == 'some_file.yml'
    assert task_include.name == 'task_include_task'

    # A task include object loaded with a task_data dict

# Generated at 2022-06-23 07:21:15.051632
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    hosts = []
    def add_host(hostname):
        host = DummyTaskIncludeHost()
        host.name = hostname
        hosts.append(host)
    add_host('host1')
    add_host('host2')

    task_action = 'debug'
    task_args = {'msg': 'hello', 'special': 'value'}


# Generated at 2022-06-23 07:21:27.448822
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play

    play = Play()
    play._variable_manager = None
    play._loader = None

    my_task = TaskInclude.load({'include': 'tasks.yml', 'tags': 'tag1'}, play=play)
    assert my_task.action == 'include'
    assert my_task.args['file'] == 'tasks.yml'
    assert my_task.tags == ['tag1']

    my_task = TaskInclude.load({'include_role': 'role_name', 'tags': 'tag1'}, play=play)
    assert my_task.action == 'include_role'
    assert my_task.args['name'] == 'role_name'
    assert my_task.args['tasks'] == 'main.yml'
    assert my

# Generated at 2022-06-23 07:21:36.978412
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = dict(action="include_tasks", file="/path/to/file")

    # Test with an invalid option with a valid include_tasks action
    task_x = ti.check_options(
        ti.load_data(task, variable_manager=None, loader=None),
        task
    )
    assert 'invalid' not in task_x.args
    assert 'file' in task_x.args
    assert '_raw_params' in task_x.args

    # Test with a not define value in 'file' parameter
    task_x = ti.check_options(
        ti.load_data({'action': 'include_tasks' }, variable_manager=None, loader=None),
        {'action': 'include_tasks' }
    )
    assert 'file'

# Generated at 2022-06-23 07:21:48.038353
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # ignore_errors is valid for all tasks but not for - import_tasks:
    for a in C._ACTION_ALL_INCLUDE_IMPORT_TASKS:
        ti = TaskInclude()
        ti.action = a
        ds0 = {'ignore_errors': True}
        ds0 = ti.preprocess_data(ds0)
        assert ds0['ignore_errors'] == True, 'Preprocessed data does not preserve ignore_errors'
    for a in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        ti = TaskInclude()
        ti.action = a
        ds0 = {'ignore_errors': True}
        ds0 = ti.preprocess_data(ds0)

# Generated at 2022-06-23 07:21:52.463202
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Create a source TaskInclude object and copy it to a new TaskInclude object
    t = TaskInclude()
    t.post_validate(dict(action='include', file='some_file'), False)
    t.statically_loaded = True
    copy_of_t = t.copy()
    # Check the value of the attribute statically_loaded
    assert copy_of_t.statically_loaded == t.statically_loaded, "test_TaskInclude_copy: t.statically_loaded must have the same value in t and copy_of_t"

# Generated at 2022-06-23 07:21:55.582929
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude()
    new_me = task.copy()

    assert task.statically_loaded == new_me.statically_loaded


# Generated at 2022-06-23 07:22:02.567981
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    task = Sentinel()

    task.args = {'apply': {}}

    # It should raise AnsibleParserError if action is not in C._ACTION_INCLUDE_TASKS
    # with invalid attirbute
    task.action = 'include'
    ti.check_options(task, Sentinel())
    task.action = 'import_tasks'
    with pytest.raises(AnsibleParserError) as execinfo:
        ti.check_options(task, Sentinel())
    assert "Invalid options for import_tasks: apply" in str(execinfo)

    # It should raise AnsibleParserError if apply_attrs is not a dict
    task.args = {'apply': 12}

# Generated at 2022-06-23 07:22:13.585166
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    class TestTaskInclude_load():

        def test_failing_param_validation(self, monkeypatch):
            # Configuration
            data = dict(file='nofilehere', apply='BadValue')
            # Monkeypatching
            monkeypatch.setattr(TaskInclude, 'check_options', lambda self, task, data: task)
            # Testing
            try:
                TaskInclude.load(data)
            except AnsibleParserError:
                pass
            except Exception as e:
                raise AssertionError(repr(e))

        def test_statically_loaded_set(self):
            assert TaskInclude.load(dict(file='nofilehere')).statically_loaded
            assert TaskInclude.load(dict(include='nofilehere')).statically_loaded


# Generated at 2022-06-23 07:22:26.634586
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''

    # Valid example
    data = {"action": "include",
            "_raw_params": "test",
            "apply": {"a": "1"},
            "when": "2",
            "tags": "3",
            "debugger": "4",
            "loop": "5",
            "loop_control": "6",
            "collections": "7"}
    task = TaskInclude.load(data)
    assert task.args == {'_raw_params': 'test', 'apply': {"a": "1"}}

    # Valid example

# Generated at 2022-06-23 07:22:29.022584
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t = TaskInclude()
    t.statically_loaded = True
    t2 = t.copy()
    assert t.statically_loaded == t2.statically_loaded

# Generated at 2022-06-23 07:22:41.319192
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    block = Block(name='block')
    task = TaskInclude(block=block)

    assert task.preprocess_data({}) == {}

    assert task.preprocess_data({'action': 'include', 'undeclared_option': 'test'}) == {'action': 'include'}
    assert task.preprocess_data({'action': 'include', 'undeclared_option': 'test', '_ansible_ignore_errors': True}) == {'action': 'include', '_ansible_ignore_errors': True}
    assert task.preprocess_data({'action': 'include', 'undeclared_option': 'test', 'C.INVALID_TASK_ATTRIBUTE_FAILED': True}) == {'action': 'include', 'undeclared_option': 'test'}
   

# Generated at 2022-06-23 07:22:53.553769
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    role_definition = RoleDefinition()
    block = Block()
    block._role = role_definition
    role_definition._parent = block
    role_definition._role_path = '/etc/ansible/roles'
    role_definition._name = 'role'
    block._play = UnsafeProxy({})
    task = Task()
    task._role = role_definition
    task._parent = block
    task.args = {'_raw_params': 'file.yml', 'apply': {'loop': '2'}}
    task.action = 'include'
    task._loader = None


# Generated at 2022-06-23 07:23:02.280628
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    ti = TaskInclude()

    task = Task()
    task.action = 'include'
    task.args = { 'file': '', 'ignore_errors': '' }
    # No error as 'ignore_errors attribute is valid for Action 'include'
    ti.check_options(task, task.args.get('file'))

    task = Task()
    task.action = 'include_role'
    task.args = { 'file': '', 'ignore_errors': '' }
    # No error as 'ignore_errors attribute is valid for Action 'include_role'
    ti.check_options(task, task.args.get('file'))

    task = Task()
    task.action = 'import_playbook'
    task.args = { 'file': '', 'ignore_errors': '' }
    # No error as 'ignore_

# Generated at 2022-06-23 07:23:11.666820
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test preprocessing of args by TaskInclude.preprocess_data
    '''
    # a task include with an invalid key 'foobar'
    ds = dict(action='include', foobar=True)
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert 'foobar' not in ds
    assert 'ignore_errors' in ds
    assert ds['ignore_errors'] is False

    # a task include with an invalid key 'foobar'
    ds = dict(action='include', foobar=True)
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert 'foobar' not in ds
    assert 'ignore_errors' in ds
    assert ds['ignore_errors'] is False

    # a

# Generated at 2022-06-23 07:23:20.790517
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()


# Generated at 2022-06-23 07:23:31.251549
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    import ansible.playbook
    import ansible.playbook.play

    # Replace a method with a mock.
    # the method get_vars of the class Block is replaced by a mock
    # and after the test is done it is replaced back as it was.
    def mock_get_vars(self):
        return {'x': 2}

    ansible.playbook.play.Block.get_vars = mock_get_vars

    # Create task with action not in C._ACTION_INCLUDE
    task_include = TaskInclude()
    task_include.action = 'debug'
    assert task_include.get_vars() == {}

    # Create task with action include
    task_include = TaskInclude()
    task_include.action = 'include'

# Generated at 2022-06-23 07:23:36.631174
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Test TaskInclude().load()
    """
    # fixture
    data = dict(
        apply={}
    )

    # test
    task = TaskInclude.load(data)

    # assert
    assert task.args['_raw_params'] == None
    assert task.args['apply'] == {}

# Generated at 2022-06-23 07:23:45.405430
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    import ansible.playbook.task_include
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    playbook = Playbook.load('/dev/null')
    play = Play().load({'name': 'foo', 'hosts': 'all'}, playbook=playbook, variable_manager=VariableManager(), loader=DataLoader())

    assert Playbook.load == ansible.playbook.playbook.Playbook.load
    assert Play.load == ansible.playbook.play.Play.load

# Generated at 2022-06-23 07:23:58.236227
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    v = VariableManager()
    v.extra_vars = dict(alpha='alpha', beta='beta')

    pc = PlayContext()
    pc.update_vars(v)

    t = TaskInclude()
    t._name = 'test'
    t._role = 'role'
    t._parent = None
    t._variable_manager = v
    t.vars = dict(bravo='bravo', charlie='charlie')
    assert t.get_vars() == dict(alpha='alpha', beta='beta', bravo='bravo', charlie='charlie')

    t = TaskInclude()
    t._name = 'test'
    t._role = 'role'
    t

# Generated at 2022-06-23 07:24:06.613841
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import context_objects as co

    config = {}
    config['DEFAULT_ROLES_PATH'] = ['/etc/ansible/roles']
    config['DEFAULT_HOST_LIST'] = 'hosts'
    config['DEFAULT_MODULE_PATH'] = '/usr/share/ansible'
    config['DEFAULT_PLAYBOOK_PATH'] = '/usr/share/ansible'
    config['DEFAULT_REMOTE_TMP'] = '/tmp/.ansible/tmp'
    config['DEFAULT_LOCAL_TMP'] = '/tmp/.ansible/tmp'

# Generated at 2022-06-23 07:24:16.953077
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    block = Block()
    role = object()
    task_include = object()
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    data = "foo"
    task = ti.load(data)
    assert task.block == block
    assert task.role == role
    assert task.task_include == task_include
    assert task.action == 'foo'
    assert task.args == {}
    assert task.notify == []
    assert task.role == role
    assert task.always_run == False
    assert task.async_val == 0
    assert task.async_seconds == None
    assert task.any_errors_fatal == False
    assert task.delegate_to == None
    assert task.delegate_facts == False

# Generated at 2022-06-23 07:24:28.658450
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    To ensure that Task.load() works as expected.
    '''
    loader = FakeDataLoader()

    # the below should pass without errors

# Generated at 2022-06-23 07:24:36.483477
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    data = dict(
        file='foo',
        apply=dict(
            block=dict(),
            when='bar'
        )
    )

    task = ti.load(data, variable_manager=None, loader=None)

    assert isinstance(task, TaskInclude)
    assert task.static is True
    assert task.action == 'include'
    assert task.file == 'foo'
    assert task._parent is None

    assert isinstance(task._parent, Block)
    assert task._parent.action == 'block'
    assert task._parent.statically_loaded is True
    assert len(task._parent._block) == 0
    assert task._parent.when == 'bar'
    assert task._parent.task_include == task
    assert task._parent.static is True
    assert task

# Generated at 2022-06-23 07:24:47.680150
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ''' test TaskInclude preprocess_data method'''
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-23 07:24:56.752702
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-23 07:25:08.995013
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    task_data = dict(
        apply = dict(some_key = 'some_value', some_new_key = 'some_new_value')
    )
    # Test normal call with no error raised
    TaskInclude.load(task_data)

    # Test some error conditions
    # Test that a bad option raises an error if INVALID_TASK_ATTRIBUTE_FAILED
    task_data = dict(
        bad_option = 'some_value',
        apply = dict(some_key = 'some_value', some_new_key = 'some_new_value')
    )
    C.INVALID_TASK_ATTRIBUTE_FAILED = True

# Generated at 2022-06-23 07:25:18.825592
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test the method ``build_parent_block`` from class ``TaskInclude``
    '''
    from unittest import mock
    from ansible import context
    from ansible.parsing.dataloader import DataLoader

    # Change the context to avoid errors

# Generated at 2022-06-23 07:25:29.025493
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    This method tests the method load of TaskInclude.
    '''
    def init_mock_Task():
        '''
        This method creates a mock task and assigns variables to the task
        '''
        task = Task()
        task.action = 'import'
        task.name = 'import'
        task.vars = {}
        task._role = None
        task._block = None
        task._dep_chain = None
        task._parent = None
        task._task_include = None
        task._loop = None
        task._has_loop_controls = False
        task._variable_manager = None
        task._loader = None
        task._role_params = None
        task.args = {}
        task.statically_loaded = False
        task._included_file = None
        task._in

# Generated at 2022-06-23 07:25:41.584685
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    def get_loader():
        import os
        from ansible.parsing.dataloader import DataLoader
        p = os.path.join(os.path.dirname(__file__), '..', 'test_data', 'v2')
        return DataLoader(path_segments=[p])

    fname = 'test_include.yml'
    c = Play.load(fname, variable_manager=VariableManager(), loader=get_loader())

    # Check the play and all its attributes
    assert isinstance(c, Play)
    assert len(c._entries) == 1
    assert not c.handlers
    assert not c.roles

# Generated at 2022-06-23 07:25:49.984872
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader

    # args for TaskInclude
    data = {
        'include': 'foo.yaml',
        'apply': {
            'block': [],
            'name': 'Included Task',
            'tags': ['foo'],
        }
    }
    loader = DataLoader()

    # test - it shall not raise
    task = TaskInclude(loader=loader).check_options(TaskInclude.load(data), data)

    assert isinstance(task.args['apply'], dict)
    assert task.args['apply']['name'] == 'Included Task'

    # updated test: apply not allowed for action without include
    data = {
        'include': 'foo.yaml',
        'loop': '{{ vars }}'
    }

   

# Generated at 2022-06-23 07:26:02.228162
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This is a test to verify the behavior of method ``build_parent_block``
    of ``TaskInclude`` class with the use of ``frozenset`` objects
    '''
    # Create the task_include object with apply_attrs
    task_include = TaskInclude()
    task_include._parent = object()
    task_include.args = {'apply': {}}
    p_block = task_include.build_parent_block()
    # Check if the task_include.args is not empty
    assert task_include.args == {}, "task_include.args must be empty"
    # Check if the attributes 'block' and 'task_include' are not changed
    assert p_block.block == [], "block.block must be empty"

# Generated at 2022-06-23 07:26:08.156865
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class MyTaskInclude(TaskInclude):
        pass

    task = MyTaskInclude()

    # check apply attribute
    task.args = dict(apply={
        "name": "test",
        "with_items": "{{ some_list }}",
        "loop_control": "loop_var: test_var"
    })
    assert task.build_parent_block().name == "test"

    # check usual parent block
    task.args = dict()
    assert task.build_parent_block() == task