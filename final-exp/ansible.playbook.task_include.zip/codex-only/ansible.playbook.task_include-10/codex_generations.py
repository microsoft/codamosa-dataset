

# Generated at 2022-06-23 07:16:21.103932
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import __main__
    import mock
    import os

    # Set up mock objects
    parent = mock.Mock(spec=Block)
    variable_manager = mock.Mock()

    parent_vars = {'a': 1, 'b': 2, 'c': 3}

    variable_manager.set_whitelist.return_value= None
    variable_manager.get_vars.return_value=parent_vars

    parent.get_vars.return_value={}
    parent.get_name.return_value='fake_name'
    parent.get_path.return_value='fake_path'
    parent.get_dep_chain.return_value=[]
    parent.get_hosts.return_value=['foo']
    parent.get_role_params.return_value={}

# Generated at 2022-06-23 07:16:31.961093
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()

    assert task.preprocess_data(dict(action='include_role', tags=['a', 'b'])).get('tags') == ['a', 'b']
    assert task.preprocess_data(dict(action='include_role', variables={'a': 1, 'b': 2})).get('vars') == {'a': 1, 'b': 2}
    assert task.preprocess_data(dict(action='include_role', connect_timeout=10)).get('timeout') == 10
    assert task.preprocess_data(dict(action='include_role', become=True)).get('become') is True
    assert task.preprocess_data(dict(action='include_role', become_user='root')).get('become_user') == 'root'


# Generated at 2022-06-23 07:16:43.888473
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    # import jiagu
    # jiagu.init()


# Generated at 2022-06-23 07:16:52.902648
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar

    # We are using an empty dictionary for the args only because it is needed to instantiate a TaskInclude object
    data = dict()
    task_include = TaskInclude(data)


# Generated at 2022-06-23 07:17:00.607731
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task as TaskClass
    from ansible.playbook.block import Block as BlockClass
    from ansible.vars.reserved import Reserved

    ti = TaskInclude.load(
        {
            'name': 'test task',
            'include': 'test_play_include.yml',
            'apply': {
                'block': [1, 2]
            }
        }
    )

    play = Play()

    role = Role()
    role._role_path = 'roles/localhost'
    role._name = 'localhost'

    task = TaskClass()
    task._role = role

    block = BlockClass()
    block._parent = task
    block._play = play



# Generated at 2022-06-23 07:17:10.445554
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    yaml_data = dict(
        file='test.yml',
        apply=dict(
            root='{{root_dir}}',
            ignore_errors=True,
            name='No Name',
            no_log=True,
            run_once=True,
            when='ansible_architecture == "x86_64"',
            tags='test',
        )
    )

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'sudo'
   

# Generated at 2022-06-23 07:17:22.685702
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    display.verbosity = 3
    p = Play()
    r = Role()
    b = Block()
    ih = Host('hostname')
    r.hosts = {ih}
    g = Group('groupname')
    r.groups = {g}

    vm = VariableManager()

    ti = TaskInclude(block=b, role=r)
    assert ti.BASE == frozenset(('file', '_raw_params'))
    assert ti.OTHER_ARGS == frozenset(('apply',))
   

# Generated at 2022-06-23 07:17:26.214395
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Construct the parent block
    import ansible.playbook
    block_data = {}
    p_block = ansible.playbook.Block.load(block_data, task_include=None)

    # Construct TaskInclude
    task_data = { 'apply': {'block': []} }
    ti = TaskInclude(block=None, task_include=p_block)
    ti.load_data(task_data)

    # Call the method under test
    blk = ti.build_parent_block()

    # Check for equality
    assert blk == p_block

# Generated at 2022-06-23 07:17:33.959791
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = {'var': 'a', 'var1': 1}
    ti.vars['var'] = 'b'
    ti.vars['var2'] = 2

    ti._parent = Block()
    ti._parent.vars['var'] = 'c'
    ti._parent.vars['var3'] = 3

    assert ti.get_vars() == {'var2': 2, 'var': 'a', 'var1': 1, 'var3': 3}

# Generated at 2022-06-23 07:17:45.127940
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Invalid options passed to 'include' using TaskInclude
    data = dict(
        action='include',
        name='foo',
        no_log=False,
        file='bar',
        ignore_errors=True,
        invalid_option='invalid_option'
    )
    ti = TaskInclude()

    # Invalid options for include raises an AnsibleParserError
    with pytest.raises(AnsibleParserError, match='Invalid options for include: invalid_option'):
        ti.check_options(ti.load_data(data), data)

    # Invalid options for import_playbook raises an AnsibleParserError
    data['action'] = 'import_playbook'
    with pytest.raises(AnsibleParserError, match='Invalid options for import_playbook: invalid_option'):
        ti.check_options

# Generated at 2022-06-23 07:17:49.987331
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Example dict
    include_task = dict(action='include_tasks', args=dict(a=1, b=2, c=3, d=4))

    # initializing TaskInclude
    ti = TaskInclude()
    ti.load_data(include_task)

    # assert
    all_vars = ti.get_vars()
    assert all_vars == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-23 07:18:01.099488
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    block = Block()
    task_ti = TaskInclude(block=block)
    task = Task(block=block)
    task_ti.args = {'file':'test'}
    task_ti._parent = task
    task_ti.vars = {'var1':1}
    task_ti.action = 'include'
    task.action = 'task'

    task_ti2 = task_ti.copy(exclude_parent=True)
    assert task_ti.vars   == task_ti2.vars
    assert task_ti.action == task_ti2.action
    assert task_ti2._parent == None

    task_ti

# Generated at 2022-06-23 07:18:13.552960
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block

    def task_include_load(task_include_data, data_loader, variable_manager, play_context):
        ti = TaskInclude()
        task = ti.check_options(
            ti.load_data(task_include_data, variable_manager=variable_manager, loader=data_loader),
            task_include_data
        )
        return task

    task_include_data = {
        'action': 'include',
        'args': {
            'a': 'A',
            'b': 'B',
            'c': 'C'
        }
    }

    #

# Generated at 2022-06-23 07:18:21.320196
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.role.definition
    from ansible.vars.manager import VariableManager

    def task_factory(name=None, block=None, parent=None, role=None):
        ds = {'name': 'foo'}
        if name:
            ds['name'] = name
            if block:
                ds['block'] = block
            if parent:
                ds['parent'] = parent
        ti = TaskInclude(block=block, role=role)
        return ti.load_data(ds, variable_manager=VariableManager(), loader=object())

    def block_factory(parent=None):
        b = Block()
        b.parent = parent
        return b

    # Test with no parent block
    t = task_factory()
    assert [] == t.get_vars()

# Generated at 2022-06-23 07:18:25.808610
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti_copy = ti.copy()
    assert ti_copy.statically_loaded == False

    ti = TaskInclude()
    ti.statically_loaded = True
    ti_copy = ti.copy()
    assert ti_copy.statically_loaded == True

# Generated at 2022-06-23 07:18:37.557119
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.plugins.tasks.include_role import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleParserError
    import pytest
    import os
    from collections import namedtuple

    # Test lacking required option 'file'
    data = {'include': 'main.yml'}

# Generated at 2022-06-23 07:18:46.963550
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Test constructor of class TaskInclude
    '''
    # Test without parameters
    tb = TaskInclude()
    assert tb is not None
    assert tb.action == 'meta'
    assert tb._task.action == 'meta'
    assert tb.statically_loaded == False

    # Test with parameters
    tb = TaskInclude(action='notify')
    assert tb is not None
    assert tb.action == 'notify'
    assert tb._task.action == 'notify'
    assert tb.statically_loaded == False

# Generated at 2022-06-23 07:18:54.672341
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude.load(
        data={
            'action': 'include',
            'file': './static/init.yaml',
            'apply': {
                'do': 'nothing',
                'something': 'else',
            }
        },
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )
    assert isinstance(task, TaskInclude)
    assert task.action == 'include'
    assert task.args['_raw_params'] == './static/init.yaml'
    assert not task.args['apply']


# Generated at 2022-06-23 07:19:02.403251
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include_action = task_include.action
    parent_task = Task()
    parent_task.vars = {'key1': 1, 'key2': 2}
    parent_task.args = {'key3': 3, 'tags': 1, 'when': 1}
    task_include._parent = parent_task
    task_include.vars = {'key4': 4, 'key5': 5}
    task_include.args = {'key6': 6, 'tags': 1, 'when': 1}
    task_include.action = 'include'
    print(task_include.get_vars())
    task_include.action = task_include_action
    print(task_include.get_vars())

# Generated at 2022-06-23 07:19:11.032496
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with base args
    task = TaskInclude.check_options(TaskInclude(task_include=True), dict(action='include', args=dict(file='/path/to/file')))
    assert task.args['file'] == '/path/to/file'
    assert '_raw_params' in task.args
    assert task.args.get('apply') is None

    # Test with apply
    apply_attrs = dict(attribute1=1, attribute2=2)
    task = TaskInclude.check_options(TaskInclude(task_include=True), dict(action='include', args=dict(file='/path/to/file', apply=apply_attrs)))
    assert task.args['file'] == '/path/to/file'
    assert '_raw_params' in task.args

# Generated at 2022-06-23 07:19:22.827288
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude()
    new_task = task.copy()
    assert new_task == task
    assert new_task.statically_loaded == task.statically_loaded

    task.when = "Foo"
    task.tags = ["foo"]
    assert task.copy() == task

    new_task = task.copy(exclude_parent=True)
    assert new_task != task
    assert new_task._parent == None
    assert new_task.when == task.when
    assert new_task.tags == task.tags
    assert new_task.statically_loaded == task.statically_loaded

    new_task = task.copy(exclude_tasks=True)
    assert new_task != task
    assert new_task._parent == task._parent
    assert new_task.when == task.when


# Generated at 2022-06-23 07:19:26.925639
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    res = TaskInclude.load(dict(
        file='somefile',
    ))
    assert res.args['_raw_params'] == 'somefile'


# Generated at 2022-06-23 07:19:34.681854
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # class TaskInclude
    ti = TaskInclude()
    ti.statically_loaded = True
    ti.loop_control.loop_var = True
    ti.loop_control.loop_values = ["1","2"]
    ti.delegate_to = False
    ti.vars = { "name": "val"}
    ti.tags = ["tag1"]
    ti.ignore_errors = True
    ti.register = "r"
    ti.notify = [ "1", "2"]
    ti.when = "w"
    ti.action = "a"
    ti.local_action = "la"
    ti.args = {"k1": "v1", "k2": "v2"}
    ti.run_once = True
    ti.name = "n"
    ti.async_val = 10

# Generated at 2022-06-23 07:19:46.379068
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2, 'c': 3}

    parent = Block()
    parent.vars = {'a': 10, 'd': 4}
    parent._parent = None

    task_include._parent = parent

    vars = task_include.get_vars()
    # the get_vars() method should not modify the structure of the task_include object.
    assert(vars == {'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert(task_include.action == 'include')
    assert(task_include.args == {'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-23 07:19:56.706880
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.args = {'apply': {'block': {'when': ['test']}}, 'include': {'tasks': [{'name': 'test'}]}}
    ti.args['_raw_params'] = 'test'
    ti.action = 'include'
    ti.block = []
    ti.notify = {}
    ti.register = ''
    ti.tags = []
    ti.until = []
    ti.vars = {'test': 'test'}
    ti.when = []
    ti.role = {}
    ti.task_include = {}
    ti.name = 'test'
    ti._role = None
    ti._parent = None
    ti._play = {'tasks': []}
    ti._role = {'tasks': []}
    ti

# Generated at 2022-06-23 07:20:07.740586
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task_include
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.sentinel import Sentinel

    # Create PlayContext() object
    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.accelerate = 2
    play_context.network_os = 'junos'
    play_context.remote_user = 'junos'

# Generated at 2022-06-23 07:20:18.994019
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test to ensure the method TaskInclude.get_vars() returns
    the right variables and respects the action of the task
    '''
    vars = {'foo': 'bar', 'a': 'b'}
    task = TaskInclude(action="include_tasks")
    task.vars = vars
    all_vars = task.get_vars()
    assert all_vars == task.vars
    assert not vars == all_vars

    task = TaskInclude(action="include_role")
    task.vars = vars
    all_vars = task.get_vars()
    assert all_vars == task.vars
    assert not vars == all_vars

    task = TaskInclude(action="import_tasks")
    task.vars = v

# Generated at 2022-06-23 07:20:24.192831
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude as TI

    play_ds = dict(
        name='test play',
        hosts='all',
        roles=[],
        tasks=[
            dict(action='include', file='foo.yml'),
            dict(action='include', file='foo.yml', apply=dict(a='b')),
        ],
    )

    play_block = Block.load(play_ds, play=Play(), variable_manager=None, loader=None)

    task_include_ds = dict(action='include', file='foo.yml')
    task = TI.load(task_include_ds, block=play_block, variable_manager=None, loader=None)
    assert task

# Generated at 2022-06-23 07:20:34.186768
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()
    role = Role()
    parent = Block(play, task_include=None, role=role)

    task = TaskInclude(block=parent, role=role, task_include=None)
    task.action = 'include'
    task.args = {'apply': {'register': 'new_register'}, 'debug': 'msg', 'include': '{{ test_var }}'}
    task._

# Generated at 2022-06-23 07:20:37.908248
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t1 = TaskInclude()
    t1.statically_loaded = True
    t1.name = 'test_task'
    t2 = t1.copy()

    assert t2.action == 'meta'
    assert t2.statically_loaded == True
    assert t2.name == 'test_task'

# Generated at 2022-06-23 07:20:49.848494
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role import Role

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost')

    play_data = dict(
        name="TEST PLAY",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action='include', file='/home/test/test.yml', apply=dict(task='apply'))
        ]
    )


# Generated at 2022-06-23 07:20:50.887389
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    pass

# Generated at 2022-06-23 07:21:02.401429
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.block import Block

    fake_variable_manager = 'fake_variable_manager'
    fake_loader = 'fake_loader'

    # Both imported and included tasks support "when" and "tags" options
    # but they should not be listed in VALID_INCLUDE_KEYWORDS as they should
    # be handled in the parent Task() class.
    all_valid_options = TaskInclude.VALID_INCLUDE_KEYWORDS.union(Block.VALID_BLOCK_KEYWORDS).union(Task.VALID_TASK_KEYWORDS)
    data = dict((k, Sentinel) for k in all_valid_options)

    apply_attrs = dict

# Generated at 2022-06-23 07:21:14.394371
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def get_dummy_task(action='include', include_all=False, include_tasks=False, include_role=False):
        my_vars = dict(
            key1='value1',
            key2=dict(
                key3='value3',
                key4='value4',
            ),
        )
        variable_manager = VariableManager(loader=DataLoader())
        variable_manager.set_inventory(InventoryManager(loader=DataLoader()))
        variable_manager.extra_vars = my_vars
        play_context = PlayContext()

# Generated at 2022-06-23 07:21:26.933789
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(action='include', file='blah')
    ti = TaskInclude()

    # Invalid options both in action and file but file included anyway
    data['action'] = 'import_playbook'
    task = ti.load_data(data)
    task = ti.check_options(task, data)
    assert task.args['file'] == 'blah'

    # Invalid options both in action and file
    data['action'] = 'import_role'
    with pytest.raises(AnsibleParserError):
        task = ti.load_data(data)
        task = ti.check_options(task, data)

    # Invalid apply with in action and file
    data['action'] = 'import_role'
    data['apply'] = 'blah'

# Generated at 2022-06-23 07:21:36.647441
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import ansible.playbook.role.include
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    # Test if constructor of class TaskInclude works
    rt = ansible.playbook.role.include.IncludedFile()

    rb = RoleDefinition()
    t = TaskInclude.load(dict(
        action="include_role",
        name="test_task_name"
    ),
        block=Block(
            role=rb,
            role_name="test_role_name",
            task_include=rt
        )
    )
    assert t.__class__.__name__ == 'TaskInclude'
    assert t.action == "include_role"
    assert t._parent.__class__.__name__ == 'Block'
    assert t

# Generated at 2022-06-23 07:21:41.052911
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    instance = TaskInclude()
    assert(instance)

    assert(instance.BASE == frozenset(('file', '_raw_params')))
    assert(instance.OTHER_ARGS == frozenset(('apply',)))
    assert(instance.VALID_ARGS == frozenset(('apply', 'file', '_raw_params')))
    assert(instance.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control', 'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars', 'when')))



# Generated at 2022-06-23 07:21:49.154486
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Using a mock ``anisble.inventory.host.Host`` class from
    ``tests/unit/compat/mock/mock_loader_simple.py``.
    '''
    from ansible.inventory.host import Host
    # test normal load for include
    task = TaskInclude.load({'action': 'include', 'file': '/tmp/example.yml'}, host=Host())
    assert isinstance(task, TaskInclude)
    assert isinstance(task._parent, Block)
    assert task._parent._play == task._play
    assert task._parent._role == task._role
    assert task.action == 'include'
    assert task.args['_raw_params'] == '/tmp/example.yml'
    assert task.statically_loaded is False



# Generated at 2022-06-23 07:22:00.547378
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    task = TaskInclude(block=None, role=None, task_include=None)

    ds = {"action": "include"}
    assert task.preprocess_data(ds) == {"action": "include"}

    ds = {"action": "include", "debugger": "msg"}
    assert task.preprocess_data(ds) == {"action": "include", "debugger": "msg"}

    ds = {"action": "include_role"}
    assert task.preprocess_data(ds) == {"action": "include_role"}

    ds = {"action": "include_role", "debugger": "msg"}
    assert task.preprocess_data(ds) == {}

    ds = {"action": "include_role", "pre_tasks": {"debug": "msg"}}

# Generated at 2022-06-23 07:22:07.664724
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class TestTaskInclude(TaskInclude):
        _valid_actions = ('include', 'import_tasks')

    attrs = {
        'action': 'include',
        '_raw_params': 'roles/myrole.yml',
        'name': 'my role',
    }
    ti = TestTaskInclude(task_include=None)
    data = {
        'action': 'include',
        '_raw_params': 'roles/myrole.yml',
        'apply': {
            'name': 'someargs',
            'debug': 'msg=hello world',
        },
        'when': 'inventory_hostname == "somehost"',
    }
    ti.load_data(data)
    ti.post_validate(data)
    assert ti._attributes == attrs


# Generated at 2022-06-23 07:22:18.465728
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    class TestTask(TaskInclude):
        VALID_ARGS = TaskInclude.VALID_ARGS.union(frozenset(['my_attr']))

    data = dict(action='test', file='somefile', my_attr='foo')
    task = TestTask.load(data)
    assert task.action == 'test'
    assert task.args['file'] == 'somefile'

    # invalid option
    data = dict(action='test', file='somefile', my_attr='foo', my_invalid_attr='bar')
    try:
        TestTask.load(data)
    except AnsibleParserError as e:
        assert 'Invalid options for test: my_invalid_attr' in str(e)

    # since the action is not an include task, this should raise an error

# Generated at 2022-06-23 07:22:29.970139
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # Valid case
    data = dict(action='include', file='test.yml')
    result = task.check_options(task.load_data(data), data)
    assert len(result.args) == 2
    assert result.args.get('_raw_params') == 'test.yml'
    assert 'file' not in result.args

    # Invalid options should raise an error
    data = dict(action='include', file='test.yml', some_invalid_option='foo')
    with pytest.raises(AnsibleParserError):
        task.check_options(task.load_data(data), data)

    # No file should raise an error
    data = dict(action='include')
    with pytest.raises(AnsibleParserError):
        task.check

# Generated at 2022-06-23 07:22:30.590722
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    pass

# Generated at 2022-06-23 07:22:42.456697
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    # test_task_include_with_unknown_data
    data = dict(
        test = 'test'
    )

    obj = TaskInclude.load(data)

    obj2 = TaskInclude()
    obj2.statically_loaded = False
    obj2.action = 'include'
    obj2.name = 'include'
    obj2.args = dict()
    obj2.vars = dict()

    obj3 = obj.copy()

    assert obj._parent == None
    assert obj._role == None
    assert obj._task_include == None


    assert obj.BASE == frozenset({'_raw_params', 'file'})
    assert obj.OTHER_ARGS == frozenset({'apply'})

# Generated at 2022-06-23 07:22:50.844908
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti1 = TaskInclude()
    ti1.statically_loaded = True
    ti1._parent = "mocked_parent"
    ti1._play = "mocked_play"
    ti1._role = "mocked_role"
    ti1._variable_manager = "mocked_variable_manager"
    ti1._loader = "mocked_loader"

    ti2 = ti1.copy()

    assert ti1.statically_loaded == ti2.statically_loaded
    assert ti1._parent == ti2._parent
    assert ti1._play == ti2._play
    assert ti1._role == ti2._role
    assert ti1._variable_manager == ti2._variable_manager
    assert ti1._loader == ti2._loader


# Generated at 2022-06-23 07:23:00.937491
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    my_args = {'vault_password_files': ['/etc/ansible/vault_password_file']}
    ds = {'constants':C, 'my_args':my_args, 'other_args':['a',1,['b',2]]}
    pds = ti.preprocess_data(ds)
    for i in range(len(ds['other_args'])):
        assert pds['other_args'][i] != ds['other_args'][i]
        assert pds['my_args']['vault_password_files'][0] == my_args['vault_password_files'][0]
    assert pds['constants'] == C
    assert pds['my_args']['vault_password_files'][0]

# Generated at 2022-06-23 07:23:11.400642
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    ti = TaskInclude(block=block)
    ti.statically_loaded = False
    ti.action = "unittest"
    ti.any_errors_fatal = False
    ti.always_run = False
    ti.args = dict()
    ti.loop = None
    ti.local_action = False
    ti.loop_with = None
    ti._role = None
    ti.cleanup = 'never'
    ti.name = None
    ti.no_log = False
    ti.notify = None
    ti.register = None
    ti.retries = 3
    ti.role_name = None
    ti.run_once = False
    ti.tags = None
    ti.task_args = None
    ti.until = None
    ti.when = None
    ti

# Generated at 2022-06-23 07:23:20.925926
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()

    task_include_copy = task_include.copy()

    assert task_include_copy.statically_loaded == False
    assert task_include_copy.has_triggered == None
    assert task_include_copy.action == 'meta'
    assert task_include_copy.args == {}
    assert task_include_copy.deprecated_words == []
    assert task_include_copy.ignore_errors == False
    assert task_include_copy.loop == None
    assert task_include_copy.notify == []
    assert task_include_copy.register == None
    assert task_include_copy.run_once == False
    assert task_include_copy.tags == []
    assert task_include_copy.always_run == False

# Generated at 2022-06-23 07:23:25.528917
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    task = TaskInclude()
    copy = task.copy()
    assert not copy.statically_loaded

    task = TaskInclude()
    task.statically_loaded = True
    copy = task.copy()
    assert copy.statically_loaded


# Generated at 2022-06-23 07:23:34.190192
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ''' Test TaskInclude.get_vars method '''
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    b = Block()
    b.vars = dict(
        A=3, B=5, C=7
    )

    ti1 = TaskInclude(block=b)
    ti1.args = dict(
        arg1=1, arg2=2, arg3=3,
        apply={
            'free_form': "test"
        }
    )

    assert ti1.get_vars() == {'A': 3, 'arg1': 1, 'arg2': 2, 'arg3': 3, 'B': 5, 'C': 7}

    import os
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-23 07:23:44.816722
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    task_data = dict(
        action='include', file='foo.yml',
        apply=dict(block=[]),
    )
    play_context = PlayContext()
    play_context._options = dict(roles_path=Sentinel)
    play_context._var_manager = Sentinel
    play_context._loader = Sentinel
    play_obj = Play().load({}, variable_manager=play_context._var_manager, loader=play_context._loader)
    task_include = TaskInclude.load(task_data, play=play_obj, variable_manager=play_context._var_manager, loader=play_context._loader)
    assert isinstance(task_include, TaskInclude)
    assert isinstance

# Generated at 2022-06-23 07:23:48.995126
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = dict()
    ti = TaskInclude()
    ti.check_options(ti.load_data(data, False, False), data)

# Generated at 2022-06-23 07:23:59.550092
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.playbook

    loader = DataLoader()
    variable_manager = ansible.playbook.task.VariableManager()
    pb = ansible.playbook.playbook.PlayBook(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-23 07:24:01.683125
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()
    task_include.load({'include': './path/to/tasks.yml'})

# Generated at 2022-06-23 07:24:14.160404
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    my_arg_names = frozenset(task.args.keys())

    # test on 'tasks' action
    task_tasks = TaskInclude()
    task_tasks.action = 'tasks'
    try:
        task_tasks.check_options(task_tasks, {})
    except AnsibleParserError:
        assert(False)
    else:
        assert(True)

    # test on 'pre_tasks' action
    task_pre_tasks = TaskInclude()
    task_pre_tasks.action = 'pre_tasks'
    try:
        task_pre_tasks.check_options(task_pre_tasks, {})
    except AnsibleParserError:
        assert(False)
    else:
        assert(True)

   

# Generated at 2022-06-23 07:24:26.192553
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # load data with apply
    data = {"apply": {"name": "test_apply_block", "block": [{"name": "test_task_in_block"}]}}
    # test_TaskInclude(data)
    task = TaskInclude.load(data=data)
    # build parent block
    p_block = task.build_parent_block()
    # create expected p_block
    expected_p_block = Block()
    expected_p_block.role = None
    expected_p_block.always = []
    expected_p_block.any_errors_fatal = False
    expected_p_block.any_errors_fatal = False
    expected_p_block.changed_when = None
    expected_p_block.changed_when_str = None
    expected_p_block.continue_on_error

# Generated at 2022-06-23 07:24:41.039245
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    data = dict(include="test")
    assert ti.preprocess_data(data) == data
    data = dict(tags=['foo'])
    assert ti.preprocess_data(data) == data
    data = dict(include="test", bar="baz")
    with C.INVALID_TASK_ATTRIBUTE_FAILED:
        assert ti.preprocess_data(data) == dict(include="test")
    with C.INVALID_TASK_ATTRIBUTE_FAILED:
        data = dict(action="include_role", bar="baz")
        assert ti.preprocess_data(data) == dict(action="include_role")

# Generated at 2022-06-23 07:24:42.434757
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
  ti = TaskInclude()
  assert isinstance(ti, TaskInclude)
  assert isinstance(ti, Task)

# Generated at 2022-06-23 07:24:51.017200
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.sentinel import Sentinel
    def assert_preprocess_data(task_include, expected):
        if hasattr(expected, 'keys'):
            diff = set(expected.keys()).difference(task_include.VALID_INCLUDE_KEYWORDS)
            assert not diff
        else:
            assert not task_include.VALID_INCLUDE_KEYWORDS

        assert_preprocess_data.var_manager.set_inventory(Inventory(''))
        assert_preprocess_data.var_manager.get_vars(play=play, task=task_include)

# Generated at 2022-06-23 07:24:54.601813
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    target = TaskInclude()

    copied = target.copy()
    assert copied.statically_loaded == target.statically_loaded

    copied = target.copy(exclude_parent=True)
    assert copied._parent is None

    copied = target.copy(exclude_tasks=True)
    assert copied.block is None

# Generated at 2022-06-23 07:25:08.197025
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)
    task_incl = TaskInclude()
    task_incl.vars = dict()
    task_incl.action = 'include'

# Generated at 2022-06-23 07:25:18.289792
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from io import StringIO

    fake_loader = DataLoader()
    fake_inventory = None
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    yml_data = '''---
- include_tasks:
      file: file_name
      apply:
        block:
            - debug: msg=Test
      tags:
        - test'''
    include_ds = fake_loader.load(StringIO(yml_data))

    play_context = PlayContext()

# Generated at 2022-06-23 07:25:28.704605
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode

    # Test the behavior the following attributes:
    # _raw_params, apply, action and file
    # 1. _raw_params:
    #    a. no file is specified
    #    b. file is defined and set to an empty string
    #    c. file is defined and set to a non-empty string
    # 2. apply:
    #    a. set to None
    #    b. set to an empty dict
    #    c. set to a non-empty dict
    # 3. action:
    #    a. set to 'include_tasks'
    #    b. set to 'include_role'
    # 4. file:
    #    a. not set
   

# Generated at 2022-06-23 07:25:37.484245
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    raw_data = dict(
        action='include',
        file='myfile.yml',
        roles='myrole',
        tasks='mytask.yml',
        include='me.yml',
        handler='myhandler.yml',
        unknown='spam'
    )
    task = TaskInclude()
    data = task.preprocess_data(raw_data)
    assert isinstance(data, dict)
    assert 'unknown' in data
    assert data['unknown'] is Sentinel
    # Make sure 'action' is not removed
    assert 'action' in data
    assert data['action'] == 'include'


# Generated at 2022-06-23 07:25:47.245632
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler import Handler

    ti = TaskInclude()

    assert ti._parent is None
    assert ti.block is None
    assert ti.action == 'include'
    assert ti.args == dict()
    assert ti._role is None
    assert ti._loader is None
    assert ti._variable_manager is None
    assert ti._task_include is None

    ds = dict(action='include', file='/tmp/foobar.yml', apply_to='hosts', args=dict(), conditional=dict())
    ti2 = TaskInclude()
    ti2.load_data(ds)

    # FIXME: replace 'is not None' by '

# Generated at 2022-06-23 07:25:58.343886
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # We need a task that contains TaskInclude.VALID_ARGS as it will be modified
    # by check_options
    task.args = {'file': 'foo.yml', 'apply': {}, 'tags': ['tag'], 'when': 'True'}

    # Invalid options
    invalid = task.check_options(task, '')
    assert len(invalid.args.keys()) == 5

    # Invalid apply
    task.args['apply'] = 'yes'
    with pytest.raises(AnsibleParserError):
        task.check_options(task, '')

    # Invalid `action`
    task.args['apply'] = {'tags': ['tag']}
    task.action = 'import_playbook'

# Generated at 2022-06-23 07:26:08.430285
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # create a role
    role_path = C.DEFAULT_LOCAL_TMP + '/test_role_include'
    from ansible.playbook.role import Role
    r = Role.load({'name': 'test_role_include', 'path': role_path})

    # create a task to be included
    task_data = {"action": "command", "_raw_params": "echo 'hello world'", "register": "outputvar", "ignore_errors": True}
    task = Task.load(task_data, role=r)

    # create include
    include_data = {'action': 'include', 'file': 'foobar.yml', 'apply': {'tags': ['tag1'], 'when': 'tag1'}, 'tags': ['tag2'], 'when': 'tag2'}
    include = TaskIn

# Generated at 2022-06-23 07:26:09.780376
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti