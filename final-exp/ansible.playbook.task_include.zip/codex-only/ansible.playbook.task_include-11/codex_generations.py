

# Generated at 2022-06-23 07:16:19.767198
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play

    # get_vars()
    #
    # test with action='include':
    # a simple case without parent task and role
    play = Play().load({
        'name': 'test play 1',
        'hosts': 'all',
        'tasks': [
            {
                'name': 'task 1',
                'include': 'test_include_yml',
                'vars': {
                    'var_1_1': 'value 1_1',
                    'var_1_2': 'value 1_2'
                }
            }
        ]
    }, variable_manager=None, loader=None)
    task = play.get_tasks()[0]

# Generated at 2022-06-23 07:16:29.997500
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    def _test_has_valid_keys(obj, parent_action):
        for k in obj.keys():
            assert k in TaskInclude.VALID_INCLUDE_KEYWORDS or parent_action in C._ACTION_ALL_INCLUDE_ROLE_TASKS, \
                'Unexpected key "%s" found in dict %s' % (k, obj)

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude

    role = dict(
        name='test_role',
        hosts=['host'],
        gather_facts=False,
        tasks=[]
    )

    name = 'test_play'

# Generated at 2022-06-23 07:16:42.630488
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play

    block1 = Block()
    block1.vars.update({'x': 1, 'y': 2, 'z': 3})

    task1 = TaskInclude()
    task1.block = block1
    task1.args.update({'tags': [], 'ignore_errors': True, 'file': 'foo.yml'})

    # in this case 'parent' is a block
    block1.block = task1
    task1.task_include = block1
    task1.role = None
    task1.action = 'include'

    play1 = Play()
    play1.vars.update({'z': 4})
    play1.post_validate()
    play1._variable_manager.set_nonpersistent_facts(dict(z=5))

   

# Generated at 2022-06-23 07:16:50.769151
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.play_context
    import ansible.playbook.task

    context = ansible.playbook.play_context.PlayContext()
    context._set_task_vars()
    context.remote_addr = 'default'
    context.connection = 'default'
    context.port = 22

    ti = TaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 07:16:59.361307
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from unittest.mock import MagicMock

    task = TaskInclude.load({'include': 'dummy.yml'}, block=MagicMock(), role=MagicMock(), task_include=MagicMock())
    assert task.action in C._ACTION_INCLUDE_TASKS
    assert task.args == {'_raw_params': 'dummy.yml'}

    task = TaskInclude.load({'import_playbook': 'dummy.yml'}, block=MagicMock(), role=MagicMock(), task_include=MagicMock())
    assert task.action in C._ACTION_IMPORT_TASKS
    assert task.args == {'_raw_params': 'dummy.yml'}


# Generated at 2022-06-23 07:17:04.333653
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # 1. Create the first TaskInclude with the default values
    task_include1 = TaskInclude()

    # 2. Create the second TaskInclude that is copy of the first one
    task_include2 = task_include1.copy()

    # 3. Verify that the second TaskInclude has the attributes of the first one
    assert task_include1.action == task_include2.action
    assert task_include1.args == task_include2.args
    assert task_include1.always_run == task_include2.always_run
    assert task_include1.any_errors_fatal == task_include2.any_errors_fatal
    assert task_include1.block == task_include2.block
    assert task_include1.delegate_to == task_include2.delegate_to
    assert task_include1

# Generated at 2022-06-23 07:17:16.196261
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Method to test TaskInclude.get_vars() method with simple data and actual data

        1. TaskInclude.get_vars() with fake data
        2. TaskInclude.get_vars() with actual data
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    ################################################################################
    # TaskInclude.get_vars() with fake data
    ################################################################################

    fake_task_include_obj = TaskInclude()
    fake_task_include_obj.action = 'include'
    fake_task_include_obj.args = dict(foo='bar')

    assert fake_task_include_obj.get_vars() == {u'foo': u'bar'}


    #################################################################

# Generated at 2022-06-23 07:17:28.188387
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-23 07:17:39.187410
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # ansible.parsing.dataloader.DataLoader
    class DataLoader:
        def __init__(self):
            pass
    # ansible.utils.vars.VariableManager
    class VariableManager:
        def __init__(self):
            pass
    # ansible.vars.manager.AnsibleIncludeVars
    class AnsibleIncludeVars:
        def __init__(self, loader=None, variable_manager=None, included_file=None):
            pass
    # ansible.errors.AnsibleParserError
    class AnsibleParserError:
        def __init__(self, msg='', obj=None):
            pass
    # ansible.vars.manager.OptionHash

# Generated at 2022-06-23 07:17:48.969182
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.plugins.loader import fragment_loader
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play_context
    import ansible.playbook.task_include
    import ansible.playbook.task_include
    import ansible.plugins.action.copy
    from ansible.utils.vars import combine_vars

    class Play(ansible.playbook.play.Play):
        pass

    class Role(ansible.playbook.role.Role):
        pass


# Generated at 2022-06-23 07:17:57.228358
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    raw = dict(
        include = dict(
            name = '',
            tasks = [
                dict(debug = dict(msg = 'foo')),
                dict(debug = dict(msg = 'bar'))
            ]
        )
    )

    ti = TaskInclude()
    processed = ti.preprocess_data(raw)
    assert processed == dict(
        name = '',
        tasks = [
            dict(debug = dict(msg = 'foo')),
            dict(debug = dict(msg = 'bar'))
        ]
    )

# Generated at 2022-06-23 07:18:04.300765
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # create a fake task and fake args
    args = {'file': 'file', 'apply': {}, 'other_opt': 'test'}

    task = Task(action='include')
    task.args = args

    # test the method
    task_returned = task.check_options(task, args)

    # test that args contain '- include: file' and not '- include: file other_opt=test'
    assert args['_raw_params'] == 'file'
    assert 'file' not in args
    assert 'other_opt' not in args

    # test that the returned task is the same as the one passed
    assert task_returned is task

# Generated at 2022-06-23 07:18:15.272177
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    load = TaskInclude.load
    task = load({'action': 'include', 'file': 'file', 'apply': {'arg': 'val'}})
    assert task._task_include
    assert task.args == dict(_raw_params='file', apply=dict(arg='val'))

    task = load({'action': 'import_tasks', 'file': 'file', 'apply': {'arg': 'val'}})
    assert task._task_include
    assert task.args == dict(_raw_params='file', apply=dict(arg='val'))

    task = load({'action': 'include_role', 'name': 'role'}, role=True)
    assert task._task_include
    assert task.args == dict(_raw_params='role')


# Generated at 2022-06-23 07:18:27.473323
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = Task()

    task.args = {
        # Valid arguments
        '_raw_params': 'file.yml',
        'loop': 'item',
        'loop_control': {
            'loop_var': 'item',
            'label': 'my_legacy_loop'
        },
        'tags': ['foo', 'bar'],
        'when': 'item is defined'
    }

    ti.check_options(task, task.args)

# Generated at 2022-06-23 07:18:36.284058
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Plain static include:
    task = TaskInclude.load({'include': 'my_include'})
    ds = task.preprocess_data(task.args)
    assert ds == {'file': 'my_include', 'action': 'include', 'args': {'_raw_params': 'my_include'}}

    # Plain static include, positional:
    task = TaskInclude.load({'include': 'my_include'})
    ds = task.preprocess_data(task.args)
    assert ds == {'file': 'my_include', 'action': 'include', 'args': {'_raw_params': 'my_include'}}

    # Statically loaded include with various options:

# Generated at 2022-06-23 07:18:48.797565
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    block = Block()
    role = 'some_role'
    task_include = 'task_included'
    ti = TaskInclude(block, role, task_include)
    assert isinstance(ti, TaskInclude)
    assert isinstance(ti, Task)
    assert isinstance(ti, FieldAttribute)
    assert ti.BASE == frozenset(('file', '_raw_params'))
    assert ti.OTHER_ARGS == frozenset(('apply',))
    assert ti.VALID_ARGS == ti.BASE.union(ti.OTHER_ARGS)

# Generated at 2022-06-23 07:19:00.569447
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # build parent
    p_block_data = dict(
        apply=dict(
            block=dict(
                name="included tasks parent block",
                tasks=[
                    dict(
                        name="parent block task #1"
                    ),
                    dict(
                        name="parent block task #2"
                    ),
                ],
            ),
        ),
    )

    p_block = TaskInclude.load(p_block_data)
    assert p_block.args['apply']['block']['name'] == 'included tasks parent block'
    assert len(p_block.args['apply']['block']['tasks']) == 2
    assert isinstance(p_block, Block)

    # build children

# Generated at 2022-06-23 07:19:10.189055
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play, Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars import VariableManager


# Generated at 2022-06-23 07:19:15.606222
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args['a'] = 'b'
    task_include.vars['c'] = 'd'
    assert task_include.get_vars() == dict(a='b', c='d')

    task_include.action = 'anything'
    assert task_include.get_vars() == dict(c='d')

# Generated at 2022-06-23 07:19:27.617451
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.includes import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    import copy

# Generated at 2022-06-23 07:19:40.466761
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    #  create a play
    play1 = Play()
    play1.vars = {'play_var':'play_value'}

    # create a task
    task1 = Task()
    task1.vars = {'task_var':'task_value'}
    task1.action = 'include'

    task1.args = {'include_var':'include_value'}

    # add the task to the play
    play1.add_task(task1)

    # create a block
    block1 = Block()
    block1.vars = {'block_var':'block_value'}

    # add the task to the block

# Generated at 2022-06-23 07:19:51.491052
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """ This method test the preprocess_data method of TaskInclude class."""
    obj = TaskInclude()
    assert obj.preprocess_data({'import_playbook': 'test.yml', 'any_attr': 1, 'action': 'import_playbook'}) == {'any_attr': 1, 'action': 'import_playbook', 'import_playbook': 'test.yml'}
    assert obj.preprocess_data({'include_tasks': 'test.yml', 'any_attr': 1, 'action': 'include_tasks'}) == {'any_attr': 1, 'action': 'include_tasks', 'include_tasks': 'test.yml'}

# Generated at 2022-06-23 07:19:55.436373
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    ti.vars.update({'meta': {}})
    assert ti.vars['meta'] == {}
    assert ti.action == 'include'

# Generated at 2022-06-23 07:20:06.904092
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = {'debugger': [True], 'file': '../../../../../../../../../../../../../../../etc/passwd'}
    kw_data = {'action': 'include', 'ignore_errors': True, 'tags': 'untagged', 'when': 'False'}
    all_data = data.copy()
    all_data.update(kw_data)

    block = Block()
    role = None
    task_include = None
    variable_manager = None
    loader = None
    task = TaskInclude.load(all_data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    assert task.has_parent_block()
    assert task.statically_loaded is False

# Generated at 2022-06-23 07:20:18.359426
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Validate that TaskInclude() objects can be copied correctly
    '''

    fake_play = dict(
        name = 'mock play',
        hosts = 'all',
        gather_facts = 'no',
        vars = dict()
    )

    fake_loader = dict(
        get_basedir = lambda x: '/path/to/test/data',
    )

    filename = '/path/to/test/data/test.yml'
    data = dict(
        action='include',
        file='/path/to/test/data/test.yml',
        tags=['tag_a','tag_b'],
    )

    block = Block()
    block._play = fake_play
    block._role = None
    block._loader = fake_loader
    block._variable_manager = None

# Generated at 2022-06-23 07:20:31.687379
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.vault_ids = [u'342FED25-C5A5-4538-9AF3-E1FFE593A9F3']

    fake_loader = FakeLoader()

    ti = TaskInclude()
    ti.ActionModule = ActionModule
    ti.__class__ = TaskInclude
    ti._play_context = play_context
    ti._loader = fake_loader

    # no params are passed to check_options
    data = dict(action='include', args=dict())
    ti.check_options(ti.load_data(data), data)

    # action is not a valid include task

# Generated at 2022-06-23 07:20:37.174789
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    Unit test for TaskInclude method 'check_options'. This method is used by
    TaskInclude and HandlerTaskInclude so it is better to
    test it separately

    Due to the way these classes work, we cannot directly instantiate them.
    Therefore, we create a dummy class that we extend
    """
    class MyTaskInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            super(MyTaskInclude, self).__init__(*args, **kwargs)
            self.validate_options_called = False

    proxy = MyTaskInclude()

    # TaskInclude will raise an error when action is wrong
    task_include = TaskInclude()
    task_include.action = 'bad-action'

# Generated at 2022-06-23 07:20:44.676390
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Test initialization of TaskInclude object with a defined name
    include_task_01 = TaskInclude(name='task_include_01')
    assert include_task_01
    assert include_task_01.name == 'task_include_01'

    # Test initialization of TaskInclude object without a defined name
    include_task_02 = TaskInclude()
    assert include_task_02
    assert include_task_02.name == None

# Generated at 2022-06-23 07:20:54.406230
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    print("-------------test copy of TaskInclude---------------------")
    # create a simple task
    display.verbosity = 4
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    p = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'tasks': [
            {'name': 'test task', 'action': {'module': 'foo'}},
        ]
    }, variable_manager=None, loader=None)

    ti = TaskInclude()
    ti.action = 'include'
    ti.args = {'a': '1'}
    ti.vars = {'b': '2'}
    ti.statically_loaded = True
    ti._parent = p._entries[0]
    ti._block = ti

# Generated at 2022-06-23 07:21:01.783855
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Ensures TaskInclude.load returns a TaskInclude object
    '''
    import sys
    import os
    from ansible.plugins.task import action_plugins

    # Since TaskInclude.load is static we need to patch the methods that
    # are called within it to mock them or monkey patch the real methods
    # of the class it is inheriting from (Task)

    # Mocking the following method of Task because it is called many
    # times within TaskInclude.load
    def mocked_check_action(self, action):
        # Need to return the object itself to avoid nesting the mocked
        # TaskInclude.set_action method within this one
        return self

    # Monkey patch Task.load to avoid having to mock all the methods
    # of the Task class
    Task.load = TaskInclude.load


# Generated at 2022-06-23 07:21:09.200698
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    it_do_not_change_task = dict(action='include_role', args={'name': 'example'})
    task = task.check_options(
        task.load_data(it_do_not_change_task, variable_manager=None, loader=None),
        it_do_not_change_task
    )
    assert 'file' not in task.args
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == 'example'
    assert task.action == 'include_role'
    assert task.args == {'_raw_params': 'example', 'name': 'example'}

    it_changes_task = dict(action='include', args={'file': 'example.yml'})
    task = task.check_options

# Generated at 2022-06-23 07:21:17.681294
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    class TestTaskInclude(TaskInclude):

        VALID_ARGS = frozenset(('a', 'b', 'c', 'd'))
        BASE = frozenset(('a', 'b'))
        OTHER_ARGS = frozenset(('c', 'd'))

    assert TestTaskInclude.check_options(TestTaskInclude(task_include=None), {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == {
        'a': 1, 'b': 2, 'c': 3, 'd': 4, 'args': {'a': 1, 'b': 2, 'c': 3, 'd': 4}}

# Generated at 2022-06-23 07:21:28.168894
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task = TaskInclude()
    assert task is not None
    assert task.BASE == frozenset(('file', '_raw_params'))
    assert task.OTHER_ARGS == frozenset(('apply',))
    assert task.VALID_ARGS == frozenset(('apply', 'file', '_raw_params'))
    assert task.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control', 'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars', 'when'))
    assert task.block is None
    assert task.role is None
    assert task.task_include is None
    assert task.get_v

# Generated at 2022-06-23 07:21:33.020862
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include = TaskInclude()
    task_include.action = "include"
    task_include.args = { 'a': 'b' }
    task_include._parent = "myparent"
    task_include.vars = { 'c': 'd' }

    assert task_include.get_vars() == { 'a': 'b', 'c': 'd' }

    task_include.action = "import_tasks"
    assert task_include.get_vars() == { 'c': 'd' }

# Generated at 2022-06-23 07:21:44.539629
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test the method `build_parent_block` of ansible.playbook.task_include.TaskInclude.
    :return:
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    import os
    loader = DataLoader()
    play_context = PlayContext()
    play = Play.load(dict(name='Test play'), loader=loader, variable_manager=VariableManager(), play_context=play_context)

# Generated at 2022-06-23 07:21:52.623452
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Unit tests for TaskInclude's get_vars method
    '''

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader

    assert TaskInclude().get_vars() == dict()


# Generated at 2022-06-23 07:22:01.200401
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.includerole import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO
    import sys
    import yaml
    import json

    display = Display()
    display.verbosity = 4


# Generated at 2022-06-23 07:22:13.000957
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude(block=None, role=None, task_include=None)
    # case 1: when the dict key 'action' is not included in _ACTION_ALL_INCLUDE_ROLE_TASKS and the dict key 'key' is not in
    # VALID_INCLUDE_KEYWORDS, the key 'key' will be ignored with a warning
    ds = dict(
        name='test_name',
        tags='test_tags',
        key='key',
    )
    new_ds = ti.preprocess_data(ds)
    # We simply check whether the dict key exists, if it does not exist, it shows that the key 'key' was ignored
    assert 'key' not in new_ds.keys()
    # clear the dict
    new_ds.clear()

    # case 2:

# Generated at 2022-06-23 07:22:25.945279
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class ParentTask():
        def __init__(self):
            self.vars = dict()

        def get_vars(self):
            return self.vars

    # Instantiate parent task
    parent = ParentTask()

    # Instantiate TaskInclude
    obj = TaskInclude(parent)

    # Assign attributes to TaskInclude
    obj.action = 'include'
    obj.vars = dict(x=1, y=2, z=None)
    obj.args = dict(tags='tag1', when='when1', file='file1')

    # Test method get_vars
    result = obj.get_vars()
    assert result == dict(x=1, y=2, z=None, tags='tag1', when='when1', file='file1')
    assert obj.action == 'include'

# Generated at 2022-06-23 07:22:39.057358
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Validate the method get_vars of TaskInclude
    '''
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    # Case: include with no parent
    task = TaskInclude()
    task.args = {'arg1': 1}
    task.action = 'include'
    task.name = 'test_include'
    assert task.get_vars() == {'arg1': 1, 'name': 'test_include'}

    # Case: include with parent that has no vars
    t_block = Block()
    t_block.vars = {}
    t_block.action = 'block'
    t_block.name = 'test_block'
    task = Task

# Generated at 2022-06-23 07:22:51.387243
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-23 07:22:59.210008
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    "Test the TaskInclude class"
    # Create a TaskInclude object
    data = {'include': './playbooks/common/tasks/main.yml'}
    TaskInclude = TaskInclude(data)

    # Print out the TaskInclude object by calling its __repr__ method
    print('The TaskInclude object is: ' + str(TaskInclude))

    # Check if the TaskInclude object is an instance of TaskInclude
    assert isinstance(TaskInclude, TaskInclude)
    print('The TaskInclude object is an instance of TaskInclude')

# Generated at 2022-06-23 07:23:03.341712
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    c1 = TaskInclude(block=None, role=None, task_include=None)
    c1.statically_loaded = True
    c2 = c1.copy()
    assert c2.statically_loaded == True

# Generated at 2022-06-23 07:23:16.816911
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    yaml_ds = {'hosts': 'localhost'}
    play = Play.load(yaml_ds, variable_manager=VariableManager())

    yaml_ds = {'include': 'foo.yml'}
    task = TaskInclude.load(yaml_ds, play=play)

    assert task.action == 'include'
    assert task.args == {'_raw_params': 'foo.yml'}

    yaml_ds = {'include': 'foo.yml', 'tags': ['foo']}
    task = TaskInclude.load(yaml_ds, play=play)

    assert task.action == 'include'

# Generated at 2022-06-23 07:23:17.856312
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TODO
    pass

# Generated at 2022-06-23 07:23:19.196741
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    a = TaskInclude()
    assert a is not None

# Generated at 2022-06-23 07:23:30.552536
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Loader is not required for this test
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # VariableManager is not required for this test
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    # Play is not required for this test
    from ansible.playbook.play import Play
    play = Play().load(
        dict(
            name = "Ansible Play test",
            hosts = 'all',
            gather_facts = 'no',
            tasks = []
        ),
        variable_manager=variable_manager,
        loader=loader
    )

    # Role is not required for this test
    from ansible.playbook.role import Role
    role = Role()

    task_include_

# Generated at 2022-06-23 07:23:42.059703
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    This method is used to test check_options method of TaskInclude
    class. It needs to be kept in sync with the method itself to ensure
    that the test cases really test what the method is supposed to test.
    """
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.display import Display
    import sys

    class myargs(object):
        def __init__(self, d):
            self.__dict__.update(d)


# Generated at 2022-06-23 07:23:48.286999
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti2 = ti.copy()
    assert ti.__class__ == ti2.__class__
    assert '_parent' not in ti2._attributes
    assert '_tasks' not in ti2._attributes

    assert '_parent' in ti2._task_deps
    assert '_tasks' in ti2._task_deps

    ti3 = ti.copy(exclude_parent=True, exclude_tasks=True)
    assert '_parent' not in ti3._attributes
    assert '_tasks' not in ti3._attributes
    assert '_task_deps' not in ti3._attributes

# Generated at 2022-06-23 07:23:59.332244
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_data = dict(
        file='/home/test/test-include-1.yaml',
        debug_enabled=True
    )
    mock_variable_manager = MagicMock()
    mock_loader = MagicMock()

    ti = TaskInclude.load(task_data, variable_manager=mock_variable_manager, loader=mock_loader)
    assert ti.action == 'include'
    assert ti.statically_loaded is True
    assert not hasattr(ti, 'debug_enabled')
    assert ti.args['file'].startswith('/home/test/test-include-1.yaml')
    assert isinstance(ti._parent, TaskInclude)
    assert ti._role is None
    assert ti._block is None
    assert ti._play is None
    assert ti._loader == mock_

# Generated at 2022-06-23 07:24:12.765551
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop as mock_unfrackpath
    from units.mock.path import mock_open_if_exists


# Generated at 2022-06-23 07:24:25.045025
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def t_val(name):
        return FieldAttribute(name, include_role=True)

    # Try with tasks that don't fall in _ACTION_INCLUDE
    ti = TaskInclude({'include_role': t_val('include_role')}, role=False)
    # Note: we are using ti._parent for ti._parent.get_vars(). See class TaskInclude.get_vars()
    ti._parent = MagicMock()
    ti.vars = {}
    ti._parent.get_vars.return_value = {'foo': 'bar'}
    ti.args = {'name': 'my_role', 'tasks': 'tasks/main.yml'}

# Generated at 2022-06-23 07:24:41.508689
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TaskInclude is abstract, creating a TaskInclude instace for testing
    my_ti = TaskInclude()
    my_args = dict(file='/tmp/test.yml', apply=dict(ignore_errors=True))
    # create the task with a safe action to avoid loading the task from a file
    my_task = TaskInclude.load(dict(action='pause', args=my_args))
    # call method to test
    my_ti.check_options(my_task, my_args)
    for key in my_task.args.keys():
        assert key in my_task.VALID_ARGS
    # Negative test: invalid option
    invalid_args = dict(file='/tmp/test.yml', apply=dict(ignore_errors=True), unknown_opt='some value')
    incorrect_task = Task

# Generated at 2022-06-23 07:24:52.396756
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Two different scenarios, action = 'include' or action = 'import_role'
    for action in ['include', 'import_role']:
        # Create one TaskInclude instance with action = 'include'
        test_ti = TaskInclude()
        # Set action of this TaskInclude instance
        test_ti.action = action

        # gen_vars is used to store the vars from the TaskInclude instance
        gen_vars = dict()

        # Declare and set the value for self.args
        # If action = 'include', vars and parameter_key are both in self.args
        # If action = 'import_role', vars is in self.args and parameter_key is not in self.args
        test_ti.args = dict()
        if action == 'include':
            parameter_key = 'test_key'


# Generated at 2022-06-23 07:25:01.045031
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Tests the constructor of class TaskInclude

    :return: a string describing the result of the unittest
    :rtype: str
    '''
    # Create a parent Block
    p_block = Block(name="This is a test")
    p_block._play = None
    p_block._role = None
    p_block._task_include = None

    # Create a TaskInclude()
    task_inc = TaskInclude(block=p_block)
    assert task_inc._parent == p_block
    assert task_inc._role is None
    assert task_inc._task_include is None
    assert task_inc.when is None
    assert task_inc.action == 'meta'
    assert task_inc.loop == None
    assert task_inc.notify == []

# Generated at 2022-06-23 07:25:06.556458
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    error = False
    try:
        TaskInclude.load({'include': 'lol'})
    except Exception:
        error = True
    assert error

    error = False
    try:
        TaskInclude.load({'apply': 'lol'})
    except Exception:
        error = True
    assert error



# Generated at 2022-06-23 07:25:15.028686
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Test if the method creates a new block when 'apply' is specified
    apply_attrs = {"apply": "test"}
    task = TaskInclude.load(apply_attrs)
    p_block = task.build_parent_block()
    assert(p_block._parent is None)
    assert(isinstance(p_block, Block))

    # Test if the method returns self when 'apply' is not specified
    apply_attrs = {}
    task = TaskInclude.load(apply_attrs)
    p_block = task.build_parent_block()
    assert(task is p_block)

# Generated at 2022-06-23 07:25:27.594407
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    args1 = dict(
        file = "test_file",
        no_log=False,
        apply=dict(
            block=[]
        )
    )

    block1 = Block()
    block1.args = args1
    block1.action = 'include'
    block1.statically_loaded = False

    block2 = block1.copy()

    if args1 == block2.args and block1.action == block2.action and block1.statically_loaded == block2.statically_loaded:
        print("Test passed for TaskInclude.copy()")
        return 0
    else:
        print(block1.args)
        print(block2.args)
        print(block1.action)
        print(block2.action)
        print(block1.statically_loaded)

# Generated at 2022-06-23 07:25:32.414934
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    class TestTaskInclude(FieldAttribute, TaskInclude):
        ATTRIBUTES = {}

    tit = TestTaskInclude()
    tit.statically_loaded = True
    tit.action = 'myaction'
    tit.args = {'mykey': 'myvalue'}
    tit.static_data = {'mystaticdata': 'mystaticvalue'}
    tit.vars = {'myvars': 'myvarvalue'}
    tit._parent = True
    tit.tags = True
    tit.when = True
    tit.block = True
    tit.role = True
    tit.include_role_tasks = True
    tit.do_not_run = True
    tit.loop = True
    tit.loop_with = True
    tit.loop_control = True
    tit.run_once = True

# Generated at 2022-06-23 07:25:44.476645
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Mock our variable  manager and the variable manager get_vars method
    variable_manager = Mock(spec=VariableManager)
    variable_manager.get_vars.return_value = {
        'my_var_from_parent_include': 'parent_include '
    }

    # Mock our loader and the loader path_dwim method
    loader = Mock(spec=DataLoader)
    loader.path_dwim.return_value = '/path/to/include/test.yml'

    # Mock our play
    play = Mock(spec=Play)
    play.basedir = '.'

    # Create our TaskInclude to test
    task_include = TaskInclude()

    # Create the parent_task
    parent_task = Task(action='include_role', args={'name': 'test_include_role'})


# Generated at 2022-06-23 07:25:55.418950
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # input data
    task_include_action=u'include'
    task_include_playbook_path=u'/home/nibz/ansible/playbooks/include_playbook.yml'

    task_include_vars = dict()
    task_include_vars[u'name'] = u'Loaded from include_playbook.yml'
    task_include_vars[u'var_include_value'] = u'Variable defined in {{ playbook_dir }}/vars/include.yml'

    task_include_parent_vars = dict()
    task_include_parent_vars[u'var_from_playbook_value'] = u'Variable defined in {{ playbook_dir }}/vars/test.yml'

    task_include_args = dict()

# Generated at 2022-06-23 07:26:02.500078
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Setup
    block = Block()
    role = None
    task_include = None
    task = TaskInclude(block=block, role=role, task_include=task_include)
    exclude_parent = False
    exclude_tasks = False

    # Execution
    new_me = task.copy(exclude_parent=exclude_parent, exclude_tasks=exclude_tasks)

    # Assertion
    assert new_me.statically_loaded == task.statically_loaded

# Generated at 2022-06-23 07:26:10.400250
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.task_include

    task_include = ansible.playbook.task_include.TaskInclude()

    # test for TaskInclude.check_options
    # check option 'apply' for TaskInclude
    task = {'apply': 'xxx'}

    try:
        task_include.check_options(task, None)
        assert False
    except AnsibleParserError:
        assert True
    except Exception:
        assert False

    # check option 'apply' for HandlerTaskInclude
    task = {'action': 'include_role', 'apply': 'xxx'}
    try:
        task_include.check_options(task, None)
        assert False
    except AnsibleParserError:
        assert True
    except Exception:
        assert False

    # check option 'apply' for include_role
