

# Generated at 2022-06-23 07:16:20.359550
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    host_file = """
    ---
    - include: foo.yml
    """
    host_file1 = """
    ---
    - include: foo.yml
        apply:
          ignore_errors: true
    """
    host_file2 = """
    ---
    - include: foo.yml
        apply:
          something_else: true
    """
    host_file3 = """
    ---
    - include: foo.yml
        apply:
          ignore_errors: true
          something_else: true
    """

    def _assert_task_include(task_include):
        assert isinstance(task_include, TaskInclude)
        assert task_include._role is None
        assert task_include._parent is None
        assert task_include._block is None

# Generated at 2022-06-23 07:16:30.646514
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook import play
    from ansible.playbook.block import Block


# Generated at 2022-06-23 07:16:35.733839
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Create base object to use
    Base._get_action_handler = classmethod(lambda cls, action: None)
    Base._get_action_plugin = classmethod(lambda cls, action: None)
    Base._get_action_module = classmethod(lambda cls, action: None)

    # Create a Task object
    task = Task()
    block = Block()
    task.set_loader(None)
    task.set_block(block)
    task.set_play(None)
    task.set_role(None)
    task.set_task_include(None)
    task.set_action('include')

    # Create an empty task
    task_include

# Generated at 2022-06-23 07:16:46.120732
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block

    parent_block = Block()
    task_include = TaskInclude(block=parent_block)

    task_include.args = {'action': 'include', 'file': 'role1.yml'}
    task1 = task_include.check_options(task_include, None)
    assert task1.args == {'action': 'include', '_raw_params': 'role1.yml'}

    # action not in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS == 'include'
    task_include.args = {'action': 'import_playbook', 'file': 'role1.yml', 'extra': True}
    task2 = task_include.check_options(task_include, None)

# Generated at 2022-06-23 07:16:46.938304
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-23 07:16:55.605136
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    def _task_include_preprocess_data(mock_super, task_class, task_data, result):
        mock_super.preprocess_data.return_value = task_data
        task = task_class(block=None, role=None, task_include=None)
        task = task.preprocess_data(task_data)
        assert task == result, "The method 'preprocess_data' of TaskInclude does not return the expected result"

    from unittest.mock import Mock, sentinel
    mock_super = Mock()
    task_data = {'action': 'import_playbook', 'ignore_errors': False, 'args': {'file': 'hosts'}}

# Generated at 2022-06-23 07:16:56.182489
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    pass

# Generated at 2022-06-23 07:17:02.649776
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.plays import PlayBook

# Generated at 2022-06-23 07:17:05.584584
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude.load({"include": "test.yml"})
    task_include.preprocess_data({"include": "test.yml", "exclude": "fail"})

# Generated at 2022-06-23 07:17:17.106567
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    # ansible_version is a valid attribute for include but not for TaskInclude
    ds = {'action': 'include', 'ansible_version': '2.5'}
    new_ds = ti.preprocess_data(ds)
    # ansible_version is removed from ds and it is replaced with sentinel
    assert 'ansible_version' not in new_ds
    assert new_ds['ansible_version'] is Sentinel
    # include is a valid attribute for include and TaskInclude
    ds = {'action': 'include', 'include': 'some_value'}
    new_ds = ti.preprocess_data(ds)
    assert 'include' in new_ds
    assert new_ds['include'] == 'some_value'

# Generated at 2022-06-23 07:17:29.950663
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    # Setup
    play_context = PlayContext()
    play = Play()
    loader = DataLoader()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=loader,
        options=None,
        passwords=None,
        stdout_callback=None,
    )

# Generated at 2022-06-23 07:17:38.400196
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test to check that TaskInclude.preprocess_data()
    filters out invalid options for include tasks.
    '''
    # Test data
    data = dict(
        action='include',
        file='tasks/foo.yml',
        ignore_errors=True,
        invalid_option=True,
        apply=dict(
            name='include',
            block=[]),
    )

    ti = TaskInclude()
    ti.preprocess_data(data)
    # Check that invalid options are not passed to the task
    assert data['invalid_option'] is Sentinel



# Generated at 2022-06-23 07:17:39.485908
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    print('hello')

# Generated at 2022-06-23 07:17:44.566537
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded
    new_ti.statically_loaded = False
    assert not ti.statically_loaded


FieldAttribute.typed_defaults[TaskInclude] = {
    'apply': {}
}

# Generated at 2022-06-23 07:17:52.442502
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    yaml = '''
    - name: test include single task
      include: filename.yml
      apply:
        block:
          - name: include single task with apply
            debug:
              msg: included task

    - name: test include with vars
      include: filename.yml
      vars:
        foo: bar
      apply:
        block:
          - name: include with vars
            debug:
              msg: 'included task, {{ foo }}'
    '''
    block = Block.load(yaml, play=None)
    blocks = list(block._block_iterator())
    assert len(blocks) == 2, 'len should be 2 but is {}'.format(len(blocks))

    # test include single task

# Generated at 2022-06-23 07:18:02.626976
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.block

    # Create play object
    play = ansible.playbook.Play()
    play._attributes = dict(
            name='testing play',
            hosts=None,
            remote_user='root',
            gather_facts='no',
            tasks=[],
            handlers=[],
            vars_prompt=[],
            vars_files=[],
            tags=[],
            library=[],
            roles=[])

    # Create block object
    block = ansible.playbook.block.Block()
    block._play = play

    # Create task object
    task = TaskInclude()
    task._parent = block

    # Set 'statically_loaded' to True

# Generated at 2022-06-23 07:18:05.391245
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    x = TaskInclude()
    y = x.copy()
    assert y.statically_loaded == x.statically_loaded


# Generated at 2022-06-23 07:18:07.823712
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    """
    constructor of class TaskInclude UnitTest
    """
    taskInclude = TaskInclude()
    assert taskInclude.statically_loaded == False

# Generated at 2022-06-23 07:18:17.858005
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class TaskInclude_get_vars_Test(TaskInclude):
        '''
        Dummy class just to override the __init__ method
        '''
        def __init__(self, vars=None, parent=None):
            super(TaskInclude_get_vars_Test, self).__init__()
            self.vars = vars
            self._parent = parent

    # Test for 'include'
    data = {
        'include': 'test_include',
        'vars': {'a': 'b', 'c': 2},
        'args': {'c': 1, 'd': 3},
        'action': 'include',
    }
    test = TaskInclude_get_vars_Test(vars=data['vars'])
    test.load_data(data)

    assert test

# Generated at 2022-06-23 07:18:29.298438
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs

    # reads all plugins to keep track of the actions loaded
    add_all_plugin_dirs()

    ti_action1 = 'include'
    ti_action2 = 'import_tasks'
    ti_action3 = 'include_tasks'

    ti_args1 = {'file': '/tmp/included_tasks.yml', 'ignore_errors': True, 'tags': ['include_tests']}
    ti_args2 = {'file': '/tmp/included_tasks.yml', 'ignore_errors': True}
    ti_args3 = {'file': '/tmp/included_tasks.yml', 'ignore_errors': True}


# Generated at 2022-06-23 07:18:39.851383
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    from ansible.playbook.block import Block
    from ansible.utils import plugins

    import pytest
    ex = pytest.importorskip("expr")

    fake_loader = plugins.module_loader.get('fake_loader')
    fake_loader._module_replacements['include'] = {'action': 'include', 'module_args': {}}

    # Empty apply attributes
    apply_attrs = {}
    task_include = TaskInclude()
    task_include.set_loader(fake_loader)
    p_block = task_include.build_parent_block()
    assert isinstance(p_block, TaskInclude)

    # Non-empty apply attributes
    apply_attrs = {'when': '1 == 1'}

# Generated at 2022-06-23 07:18:44.335972
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    t = TaskInclude()
    assert t.get_vars() == dict()

    t = TaskInclude()
    t.vars = dict(test='test')
    t.args = dict(test='test')
    assert t.get_vars() == dict(test='test')

# Generated at 2022-06-23 07:18:52.609343
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Load data
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)
    extra_vars = load_extra_vars(loader=loader, inventory=inventory)
    variable_manager.set_extra

# Generated at 2022-06-23 07:18:57.747030
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = TaskInclude()

    # Without apply
    p_block = task.build_parent_block()
    assert p_block == task

    # With apply
    task.args['apply'] = {}
    p_block = task.build_parent_block()
    assert p_block != task
    assert isinstance(p_block, Block)


# Generated at 2022-06-23 07:19:08.161475
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    import ansible.inventory.host
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    play_ctxt = PlayContext()

# Generated at 2022-06-23 07:19:18.187715
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.unittest_loader import AnsibleLoaderTest, load_tasks_from_dataset

    class TestTaskInclude(TaskInclude, AnsibleLoaderTest):
        pass


# Generated at 2022-06-23 07:19:29.720582
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test build_parent_block with apply block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    data = {
        'action': 'include',
        'file': 'foobar.yml',
        'apply':
        {
            'block': [],
            'name': 'B',
            'loop': [1, 2, 3],
            'tags': ['foo', 'bar'],
            'when': 'ansible_distribution == "Ubuntu"',
            'listen': 'foobar',
        }
    }
    task = TaskInclude.load(data, variable_manager=variable_manager)
    p_block = task.build_parent_block()

# Generated at 2022-06-23 07:19:42.528490
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    attrs = dict(
        action='include',
        args=dict(
            debug='msg={{foo}}',
            apply=dict(
                block=dict(
                    tasks=[
                        dict(action='debug', args=dict(msg='foo')),
                        dict(action='debug', args=dict(msg='bar'))]))),
        loop='{{foo}}')

    ti = TaskInclude()
    ti.load_data(data=attrs)

    assert ti.action == 'include'
    assert ti.args == {'debug': 'msg={{foo}}', '_raw_params': '{{foo}}', '_uses_loop': True}
    assert ti.loop == attrs['loop']
    assert isinstance(ti._parent, TaskInclude)
    assert isinstance(ti._parent._parent, TaskInclude)

# Generated at 2022-06-23 07:19:52.178882
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    ds = dict(
        name='test_data',
        action='include',
        file='test_file',
        apply={'foo': 'bar'}
    )

    task = TaskInclude.load(
        ds,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader
    )

    assert task.name == 'test_data'
    assert task.action == 'include'
    assert task.args

# Generated at 2022-06-23 07:20:04.366194
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    my_data = dict(
        action = 'include_role',
        name = 'common',
        file = 'common.yml',
        loop = '{{range(2)}}',
        variables = dict(a=1, b=2, c=3)
    )

    ti = TaskInclude()
    ti.preprocess_data(my_data)

    assert my_data == dict(
        action = 'include_role',
        name = 'common',
        file = 'common.yml',
        loop = '{{range(2)}}',
        vars = dict(a=1, b=2, c=3)
    )



# Generated at 2022-06-23 07:20:06.550183
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Unit test for method copy of class TaskInclude
    '''
    task_include = TaskInclude()
    task_include.statically_loaded = True
    new_task_include = task_include.copy()

    assert new_task_include.statically_loaded == task_include.statically_loaded

# Generated at 2022-06-23 07:20:18.112721
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play

    # Building the data structure for test
    data = dict(
        action = 'include_role',
        file = 'foobar.yml',
        apply = dict(
            block = [
                dict(
                    action = 'shell',
                    args = 'do something',
                )
            ],
            loop = '{{ bar }}',
            loop_control = dict(
                label = 'baz'
            )
        )
    )

    # Building the Play and the Task directly from Play
    loader = None
    variable_manager = None
    play = Play.load('foobar.yml', loader=loader, variable_manager=variable_manager)
    task = TaskInclude.load(
        data,
        variable_manager=variable_manager,
        loader=loader,
    )

   

# Generated at 2022-06-23 07:20:31.410045
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    apply_attrs = {'name': 'test', 'loop': '_items'}

    task = TaskInclude(block=None, role=None, task_include=None)
    task._parent = Play()
    task._role = None
    task._loader = None
    task._variable_manager = None
    task.action = 'include_tasks'

    task.args = {'apply': apply_attrs}
    assert task.build_parent_block().__class__.__name__ == 'Block'
    assert task.build_parent_block().parent.__class__.__name__ == 'Play'
    assert task.build_parent_block().role == None

# Generated at 2022-06-23 07:20:35.285655
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    import ansible.playbook as Playbook

    b = Playbook.Block()
    ti = TaskInclude(block=b)
    ti.statically_loaded = True
    assert ti.statically_loaded
    copied_ti = ti.copy()
    assert copied_ti.statically_loaded

# Generated at 2022-06-23 07:20:42.351997
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_data = {'ignore_errors': True, 'debugger': True,
                 'action': 'include_tasks', 'file': 'my_tasks.yml',
                 'name': 'my_task',
                 'no_log': False, 'register': 'result1',
                 'tags': ['tag1', 'tag2'], 'timeout': 10,
                 'vars': {'var1': 'val1', 'var2': 'val2'},
                 'when': 'var1 is defined'}
    ti = TaskInclude()
    result = ti.preprocess_data(task_data)

    expected_result = {'action': 'include_tasks', 'file': 'my_tasks.yml'}
    assert(result == expected_result)



# Generated at 2022-06-23 07:20:53.025661
# Unit test for method copy of class TaskInclude

# Generated at 2022-06-23 07:20:57.842309
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # The goal is to check that the method copy returns an object of type TaskInclude
    # In order to do so, the method copy is called with both exclude_parent and exclude_tasks set to False
    task = TaskInclude()
    assert(isinstance(task.copy(False, False), TaskInclude))

# Generated at 2022-06-23 07:21:07.218404
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=None, loader=None)
    block = play.get_block_list()[0]

    ti = TaskInclude(block=block, task_include=None)
    assert len(block.block) == 0

    d

# Generated at 2022-06-23 07:21:17.011921
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.task

    # these are the tasks in play.py that have the _perform_include()
    # method which is where the task include is used in Ansible.
    C._ACTION_ALL_INCLUDE_TASKS = frozenset(('include', 'import_tasks', 'import_role', 'include_role'))

    # This is a map of roles to tasks that are used in play.py
    C._ACTION_ROLES_TASKS_MAP = {
        'include_role': 'tasks',  # RoleInclude
        'import_role': 'tasks',   # RoleInclude
    }


# Generated at 2022-06-23 07:21:28.128939
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(foo='bar')
    variable_manager.get_vars(loader=None, play=Play().load('', variable_manager=variable_manager))
    variable_manager.set_fact('test', 'test')
    play_context = PlayContext(remote_user=None)
    templar = Templar(loader=None, variables=variable_manager)

    # task without parent
    task = TaskInclude

# Generated at 2022-06-23 07:21:28.659634
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    return True



# Generated at 2022-06-23 07:21:35.354644
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # just a simple example as we can't mock-out the whole task here
    class TaskInclude(object):

        def __init__(self, apply):
            self.apply = apply

    class Block(object):

        def __init__(self, block):
            self.block = block

    parent_block = Block([1, 2, 3])
    apply_data = {'block': [4, 5]}
    ti = TaskInclude(parent_block, apply_data)
    assert ti.build_parent_block().block == [4, 5]

# Generated at 2022-06-23 07:21:40.736180
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = dict(
        name='test',
        action='include',
        file='test.yml',
    )
    ti = TaskInclude.load(data, variable_manager=None, loader=None)
    assert ti.name == 'test'
    assert ti.action == 'include'
    assert ti._attributes['file'] == 'test.yml'

# Generated at 2022-06-23 07:21:48.998267
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test the get_vars method of class TaskInclude
    '''
    # Create a playbook object which will be used to create play objects.
    # And create a play object.
    pl_obj, play_obj = create_playbook_and_play()

    # Create a task object for the role tasks
    role_task = create_role_task(play_obj)

    # Create a task object for include tasks

# Generated at 2022-06-23 07:21:58.047617
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    field = FieldAttribute(name="test_of_copy_TaskInclude")
    args = dict()
    args["test_of_copy_TaskInclude"] = field
    field.local_vars = args
    ti = TaskInclude(None, None, None)
    ti.args = args
    ti.statically_loaded = False
    new_me = ti.copy()
    assert new_me.statically_loaded == False
    assert new_me.args["test_of_copy_TaskInclude"].local_vars == args

# Generated at 2022-06-23 07:22:06.645997
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Base play with task include specifying a single task
    play_block = dict(
        hosts=['some_host'],
        tasks=[]
    )

    block_attrs = dict(
        apply=dict(
            block=dict(
                roles='some_role'
            )
        )
    )

    # Create Task include object
    task_include = TaskInclude(task_include=None, block=None, role=None)
    task_include.statically_loaded = False
    task_include.action = 'include'
    task_include.load_data(dict(some_task=block_attrs))

    # Assert that the loaded data is what is expected
    assert task_include.action == 'include'

# Generated at 2022-06-23 07:22:18.050980
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method is to test the building of parent block for included tasks
    when ``apply`` is specified
    '''
    my_task = TaskInclude()
    apply_attrs = {'always': {'when': 'always'}, 'block': []}
    my_task.args.update({'apply': apply_attrs})
    block_attrs = {'name': 'test'}
    my_block = Block.load(block_attrs, play=None, task_include=None, role=None, variable_manager=None, loader=None)
    my_block.block = [my_task]
    my_task._parent = my_block
    p_block = my_task.build_parent_block()
    assert isinstance(p_block, Block)

# Generated at 2022-06-23 07:22:29.721259
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(
        name='test_name',
        import_role=dict(name='test_import_role_name'),
        include=dict(name='test_include_name'),
        include_tasks=dict(name='test_include_tasks_name'),
        include_role=dict(name='test_include_role_name'),
        import_tasks=dict(name='test_import_tasks_name'),
        unreconized_attr='test_unreconized_attr',
    )

    for a in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        ti = TaskInclude()
        result = ti.preprocess_data(data[a])

# Generated at 2022-06-23 07:22:38.567404
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.dup_count = 0
    ti.name = 'before copy'
    ti2 = ti.copy()
    ti.name = 'after copy'

    print('Original TaskInclude is ' + ti.name)
    print('Copied TaskInclude is ' + ti2.name)
    print('Duplicate counter of ' + ti2.name + ' is ' + str(ti2.dup_count))
    assert ti2.name == 'before copy'
    assert ti2.dup_count == 0

# Generated at 2022-06-23 07:22:50.818758
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Unit test for method get_vars of class TaskInclude.
    '''
    from ansible.playbook.play_context import PlayContext

    # need to mock parent
    class MockParent(object):
        def __init__(self):
            self._play = None
            self.vars = dict()
        def get_vars(self):
            return self.vars

    parent = MockParent()
    parent.vars = dict(a='a', b='b')

    # mock play_context for include
    play_context = PlayContext()
    play_context.vars = dict(z='z')

    task_include = TaskInclude(block=parent, task_include=None)
    task_include.vars = dict(x='x', y='y')

# Generated at 2022-06-23 07:23:00.635602
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    test_class = TaskInclude()
    test_class.name = "test_class"
    test_class.when = "when test"
    test_class.async_val = 5
    test_class.poll = 5
    test_class.statically_loaded = True

    test_class_copy = test_class.copy()

    assert test_class_copy.name == "test_class"
    assert test_class_copy.when == "when test"
    assert test_class_copy.async_val == 5
    assert test_class_copy.poll == 5
    assert test_class_copy.statically_loaded == True



# Generated at 2022-06-23 07:23:05.450484
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    # Create an instance of class TaskInclude
    task_include = TaskInclude()

    # Assert the object is instance of class TaskInclude
    assert isinstance(task_include,TaskInclude)

    # Assert the _role attribute of object is None
    assert task_include._role is None



# Generated at 2022-06-23 07:23:08.742712
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.statically_loaded is False

# Generated at 2022-06-23 07:23:18.772842
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    #  Check no file with include_tasks
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    data = dict(action='include_tasks')
    ti = TaskInclude.load(data, block=Block())
    assert isinstance(ti, TaskInclude) is True
    assert isinstance(ti, Task) is True
    assert ti.action == 'include_tasks'
    assert ti.static is False

    #  Check double with include_role
    data = dict(action='include_role', name='name', file='file')

# Generated at 2022-06-23 07:23:30.430295
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import task_loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        name = 'Test include',
        apply = dict(action ='debug'),
    )
    block = dict(
        host = "all"
    )
    play = Play().load(block, loader=DataLoader(), variable_manager=VariableManager(), task_loader=task_loader)
    pb = TaskInclude.load(ds, block=block, play=play, variable_manager=VariableManager(), loader=DataLoader())
    pb.post_validate(play=play, variable_manager=VariableManager())
    pb.build

# Generated at 2022-06-23 07:23:36.348338
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    import ansible.playbook.play
    ni = TaskInclude(block=Block(), role=None, task_include=None)
    ni.statically_loaded = True
    new_task = ni.copy()
    assert(new_task.statically_loaded == True)
    assert(new_task.module_vars == None)

    # to see if parent/play/etc are carried over or not
    new_task = ni.copy(exclude_parent=True)
    assert(new_task.module_vars == None)
    assert(new_task.statically_loaded == True)
    assert(new_task._parent == None)
    assert(new_task._role == None)
    assert(new_task._play == None)
    assert(new_task._loader == None)

# Generated at 2022-06-23 07:23:45.257198
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    def test_b(ds, data, action, extra_args, apply_dict=None, parent_block=None, file=None, loop_control=None, expected_exception=None):
        if expected_exception is not None:
            with pytest.raises(expected_exception):
                TaskInclude.load(ds, action=action, extra_args=extra_args, apply_dict=apply_dict, parent_block=parent_block, file=file)
            return

        ti = TaskInclude.load(ds, action=action, extra_args=extra_args, apply_dict=apply_dict, parent_block=parent_block, file=file)
        arg_names = set(ti.args.keys())
        base_expected = set(TaskInclude.BASE)


# Generated at 2022-06-23 07:23:58.150254
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    d = {
        'name': 'test',
        'action': 'include',
        '_raw_params': 'foobar'
    }
    ti = TaskInclude(task_include=TaskInclude(), variable_manager=None, loader=None)
    ti.load_data(d, variable_manager=None, loader=None)
    ti.statically_loaded = True
    assert ti.name == 'test'
    assert ti.action == 'include'
    assert ti._parent is None
    assert ti._role is None
    assert ti._static_parent is None
    assert ti.args == {'_raw_params': 'foobar'}
    assert ti.vars == {}
    assert ti.when == {}
    assert ti.always_run is False
    assert ti.notify is []

# Generated at 2022-06-23 07:24:11.434383
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class FakeData(object):
        def __init__(self, action):
            self.action = action

    # validate that static includes do not need a file
    static_include_data = {'action': 'include'}
    static_task = TaskInclude(task_include=None)
    static_task.load_data(static_include_data, variable_manager=None, loader=None)

    # validate that bad options are caught
    task = TaskInclude(task_include=None)
    task.args = {'my_bad_option': 'value'}
    task.action = 'include_role'
    try:
        task.check_options(task, FakeData(task.action))
        assert False, "AnsibleParserError not raised"
    except AnsibleParserError:
        pass

    # validate that bad

# Generated at 2022-06-23 07:24:12.752328
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert task_include

# Generated at 2022-06-23 07:24:24.973216
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    t = Templar(loader=None, variables=dict())

    ds = dict(
        action='foo',
        file='bar',
        args=dict(
            a='b',
        )
    )

    # The static loading of 'include' tasks (located in Playbook.load) doesn't have
    # vars available. We mimic that scenario to test preprocess_data
    ti = TaskInclude(task_include=None, role=None, block=None)
    ds = ti.preprocess_data(ds)
    assert ds == dict(action='foo', args=dict(_raw_params='bar', a='b'))

    # Test whether preprocess

# Generated at 2022-06-23 07:24:41.509628
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    Unit test for method 'check_options' of class TaskInclude
    """
    # prepare 'DataLoader's to be used as parameters
    mock_loader = 'mock_loader'
    mock_vars_manager = 'mock_vars_manager'

    def prepare_data_tasks(action):
        """
        Prepare test data and task to be used in tests
        :param action: action of task to test
        :return: tuple (task to test, data used to create task)
        """
        data = {
            'action': action,
            '_raw_params': 'file_name',
            'apply': {
                'a': 'b',
            },
            'file': 'file_name',
            'invalid': 'invalid_key',
        }


# Generated at 2022-06-23 07:24:50.456378
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.module_utils._text import to_text
    import json

    # Create a TaskInclude object
    applied = dict()
    applied['is_meta'] = False
    applied['always_run'] = False
    applied['block'] = list()

    t = TaskInclude(block=None, role=None, task_include=None, apply=applied)

    # Create a Task object
    task = Task()

    # Set the action to a TaskInclude
    t.action = 'include'

    # Set the _parent of TaskInclude to Task
    t._parent = task

    # Copy the TaskInclude
    new_me = t.copy

# Generated at 2022-06-23 07:25:00.686934
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    p = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {
                'include_role': {
                    'name': 'test_role',
                    'apply': {
                        'vars': {
                            'applied_var': 1,
                        },
                    },
                },
            },
        ],
    }, variable_manager=None, loader=None)

    assert isinstance(p._entries[0], TaskInclude)
    assert isinstance(p._entries[0]._parent, Play)
    assert isinstance(p._entries[0]._parent._parent, Play)

# Generated at 2022-06-23 07:25:04.299456
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.statically_loaded = True

    new_me = task_include.copy()

    assert new_me.statically_loaded == True

# Generated at 2022-06-23 07:25:16.473427
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class MockTask(object):
        def __init__(self, vars):
            self.vars = vars
            self.args = {}
            self.get_vars = TaskInclude.get_vars

    class MockParent(object):
        def __init__(self, vars):
            self.vars = vars
            self.args = {}

    # Mock the type_validator method of FieldAttribute, to avoid AnsibleParserError
    orig_type_validator = FieldAttribute.type_validator
    FieldAttribute.type_validator = lambda self, value: value

    # Nothing to return
    ti = MockTask({})
    ti.action = 'include'
    assert {} == ti.get_vars()

    # No variables in include
    ti = MockTask({'foo': 'bar'})
    ti

# Generated at 2022-06-23 07:25:27.908969
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = dict(a=1,b=2)
    ti.vars = dict(x=1,y=2)
    try:
        ti.statically_loaded = True
    except AttributeError:
        ti.statically_loaded = Sentinel('statically_loaded')
    ti._parent = Sentinel('_parent')
    ti._role = Sentinel('_role')
    ti._variable_manager = Sentinel('_variable_manager')
    ti._loader = Sentinel('_loader')
    ti._block = Sentinel('_block')
    ti._action = 'include'
    ti._name = 'test_TaskInclude_copy'
    ti._tasks = [Sentinel('_tasks')]

# Generated at 2022-06-23 07:25:38.007231
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # pylint: disable=protected-access

    task_include = TaskInclude()
    task_include._parent = Block()
    task_include._parent.vars = {'expected_var': 'expected_value'}
    task_include.action = 'include'
    task_include.args = {'include_var': 'include_value'}

    all_vars = task_include.get_vars()
    assert all_vars['expected_var'] == 'expected_value'
    assert all_vars['include_var'] == 'include_value'

# Generated at 2022-06-23 07:25:47.544842
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class AnsibleTaskInclude(TaskInclude):
        pass

    # Test with a non-include task (super should be called)
    a = AnsibleTaskInclude({'action': 'test'}, role=None)
    a._parent = object()
    a._parent.get_vars = lambda: {'toto': 1}
    a.vars = {'tata': 2}
    vars = a.get_vars()
    assert vars == {'toto': 1, 'tata': 2}

    # Test with an include task
    a = AnsibleTaskInclude({'action': 'include', 'arg1': 11, 'arg2': 22}, role=None)
    a._parent = object()

# Generated at 2022-06-23 07:25:58.597529
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test 1: check valid 'include' keyword
    task = TaskInclude()
    data = {
        "include": "test/something.yaml",
        "apply": "a test"
    }
    task.check_options(task.load_data(data), data)
    assert task.args["_raw_params"] == data["include"]
    assert task.args["apply"] == "a test"

    # Test 2: check invalid 'include' keywords
    task = TaskInclude()
    data = {
        "include": "test/something.yaml",
        "apply": "a test",
        "invalid": "value"
    }

# Generated at 2022-06-23 07:26:08.502659
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.utils.vars
    import ansible.vars.manager
    import ansible.playbook.role

    # create a play which will include the role 'common'
    pb = ansible.playbook.play.Play()
    pb.vars={'var_name': 'var_value'}
    pb._entries = []
    pb._loader = DictDataLoader({'common': {'roles': [], 'tasks': [{'name': 'print var', 'action': 'debug', 'args': {'msg': '{{ var_name }}'}}]}})
    pb._variable_manager = ansible.utils.vars.VariableManager()
    pb