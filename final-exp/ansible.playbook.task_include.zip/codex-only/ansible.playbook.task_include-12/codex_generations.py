

# Generated at 2022-06-23 07:16:20.632154
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    play_source =  dict (
        name = "Ansible Play",
        hosts = 'local',
        gather_facts = 'no',
        tasks = [
            {"include": "file.yml", "apply": {"tags": "test"}}
        ]
    )

    loader, inventory, variable_manager = C.mocked_loader()
    variable_manager.set_inventory(inventory)
    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)
    builder = TaskInclude.load(play.tasks[0], variable_manager=variable_manager, loader=loader)
    parent_block = builder.build_parent_block()

    assert(parent_block.get_name() == "Ansible Play")
    assert(len(parent_block._block) == 0)

# Generated at 2022-06-23 07:16:21.253343
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-23 07:16:32.063632
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from units.mock.loader import DictDataLoader

    from io import StringIO

    mock_loader = DictDataLoader({'test_playbook.yml': '', 'included.yml': ''})

    def mock_find_file(self, name):
        return None

    mock_task = Task()
    mock_task._role = IncludeRole()
    mock_task._parent = Block()

# Generated at 2022-06-23 07:16:43.889246
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import plugin_loader

    import ansible.playbook

    pb = ansible.playbook.Playbook()

    loader = ansible.cli.CLI.load_file_config(["/dev/null"], [], [], playbook_path='/dev/null')
    pb.LOADER = loader
    pb.variable_manager = ansible.playbook.variable_manager.VariableManager()
    pb.basedir = '.'

    pc = PlayContext()
    pb.SETUP_CACHE['last_task_start'] = 0


# Generated at 2022-06-23 07:16:55.272460
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude(task_include=None)
    t.vars = dict(a='b')
    t.args = dict(one=1, two=2)

    # We should get a copy of the vars and args, not the actual
    # references to the vars and args
    all_vars = t.get_vars()

    assert all_vars is not t.vars
    assert all_vars is not t.args

    assert all_vars == dict(a='b', one=1, two=2)

    # Test 'include_role'
    t.vars = dict(a='b')
    t.args = dict(one=1, two=2)
    t.action = 'include_role'
    all_vars = t.get_vars()
    assert all_

# Generated at 2022-06-23 07:17:02.033027
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    import pytest
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_from_file('tests/unit/inventory'))
    host = Host(name='some_host')
    group = Group(name='some_group')
    variable_manager.set_host_variable(host, 'ansible_ssh_pass', 'somesecret')
    variable_manager.set_host_variable(host, 'ansible_ssh_user', 'root')
    variable_manager.set_host_variable

# Generated at 2022-06-23 07:17:10.964849
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.playbook import Play
    play = Play.load(dict(
        hosts='localhost',
        vars={},
        tasks=[],
    ),
        variable_manager=None,
        loader=loader,
    )
    from ansible.playbook.block import Block
    block = Block(
        play=play,
    )
    task_include = TaskInclude(block=block)
    # Test empty apply
    apply_attrs = task_include.args.pop('apply', {})
    assert apply_attrs == {}
    p_block = task_include.build_parent_block()
    assert p_block is task_include
    task_include.args['apply'] = {}
    # Test apply with

# Generated at 2022-06-23 07:17:23.360675
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Test method load of TaskInclude class.
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    def assert_play_context_vars(action, task_args, play_context_vars):
        '''
        Helper for assert_play_context_vars
        '''
        ti = TaskInclude.load(build_ti_data(action, task_args),
                              loader=DataLoader(),
                              variable_manager=VariableManager(),
                              play_context=PlayContext())

        if play_context_vars:
            assert ti.get_vars() == play_context_vars
        else:
            assert not ti.get_v

# Generated at 2022-06-23 07:17:34.496311
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lad = DataLoader()
    vam = VariableManager()
    templar = Templar(vars=vam)

    task_include = TaskInclude()
    task_include.action = 'include'

    # case 1
    task = task_include.check_options(task_include, {'include': 'abc.yml'})
    assert task.args['_raw_params'] == 'abc.yml'
    assert task.args['apply'] == {}

    # case 2

# Generated at 2022-06-23 07:17:41.658287
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    loader = DictDataLoader({
        "my_included_task.yml": """
        - name: Task that gets included
          command: do not include me
        """,
    })
    variable_manager = VariableManager()

    task = TaskInclude.load({'_raw_params': 'my_included_task.yml', 'apply': {}, 'run_once': False}, loader=loader, variable_manager=variable_manager)
    assert task.name == "Task that gets included"
    assert task.action == "command"
    assert task._role is None

    task = TaskInclude.load({'_raw_params': 'my_included_task.yml', 'apply': {}, 'when': 'False'}, loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-23 07:17:50.110975
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Instantiate task include object
    task_obj = TaskInclude()
    # Set action to 'include'
    task_obj.action = 'include'
    # Set vars dict to empty dict
    task_obj.vars = dict()
    # Set args dict to dict containing key 'testkey' with value 'testvalue'
    task_obj.args = dict()
    task_obj.args['testkey'] = 'testvalue'
    # Call get_vars method
    allvars = task_obj.get_vars()
    # Check that get_vars method returned the expected dict
    assert allvars == dict(testkey='testvalue')

    # Set action to 'include_role'
    task_obj.action = 'include_role'
    # Call get_vars method
    allvars = task_obj

# Generated at 2022-06-23 07:17:58.205366
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Test the constructor of class TaskInclude.
    '''

    # ----------
    # First test
    # ----------
    ti = TaskInclude()

    assert isinstance(ti, TaskInclude)
    assert isinstance(ti, Task)
    assert isinstance(ti, Block)

    # ----------
    # Second test
    # ----------
    ti = TaskInclude()

    assert isinstance(ti, TaskInclude)
    assert isinstance(ti, Task)
    assert isinstance(ti, Block)

# Generated at 2022-06-23 07:18:07.984567
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(
        action="include",
        file="blah.yml",
        tags=['tag'],
        when='True',
        invalid_directive='invalid_value'
    )
    task_include = TaskInclude(None, None, None)
    task_include.preprocess_data(data)
    assert not data.get('invalid_directive')
    assert 'invalid_directive' not in task_include.unknown_attributes

    # test action that does not allow wrong keywords
    data = dict(
        action="include_tasks",
        file="blah.yml",
        invalid_directive='invalid_value'
    )
    task_include = TaskInclude(None, None, None)
    task_include.preprocess_data(data)

# Generated at 2022-06-23 07:18:18.048525
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def test_get_vars_on_an_include_task(task_include):
        '''
        Tests get_vars() on an include task
        '''
        data = dict(
            action = 'include',
            args = dict(
                file = 'foobar',
                foo = 'bar',
                x = 'y',
                action = 'oops',
                tags = 'oops',
                when = 'oops',
            )
        )

        task_include.populate_valid_attrs('include')
        task_include.load_data(data, loader=None, variable_manager=None)
        all_vars = task_include.get_vars()

# Generated at 2022-06-23 07:18:25.812706
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task_include = TaskInclude()
    task_include.action = dict()
    task_include.args = dict()
    task_include.vars = dict()
    task_include.statically_loaded = True

    copy = task_include.copy()

    assert copy.action == task_include.action
    assert copy.args == task_include.args
    assert copy.vars == task_include.vars
    assert copy.statically_loaded == True



# Generated at 2022-06-23 07:18:37.553323
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import unittest
    import ansible.playbook.task_include as task_include
    class TestCase(unittest.TestCase):
        def test_validate_options(self):
            ti = task_include.TaskInclude()

            task = {
                'action': 'include_role',
                'args': {
                    'name': 'role1'
                }
            }
            # No validation for non-include tasks
            self.assertEqual(ti.check_options(task=task, data=None), task)


# Generated at 2022-06-23 07:18:49.091706
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block1 = Block(task_include=Block())
    ta1 = TaskInclude(block=block1)
    ta1.args['_raw_params'] = 'x.yml'
    ta1.statically_loaded = True
    ta1.action = 'some-action'
    ta1._role = 'some-role'
    ta1._loader = 'some-loader'
    ta1._variable_manager = 'some-variable-manager'
    ta1._parent = 'some-parent'
    ta1._role = 'some-role'
    ta1.vars = { 'k1': 'v1' }
    ta1.tags = 'some-tags'
    ta1.when = 'some-when'
    ta2 = ta1.copy()
    assert ta2.args['_raw_params'] == ta

# Generated at 2022-06-23 07:19:00.574945
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Create a dummy TaskInclude instance
    ti = TaskInclude()

    # Create a task with just one
    task = Task()
    task.action = 'include_tasks'
    task.args = {'file': 'test'}

    task = ti.check_options(task, {})

    assert '_raw_params' in task.args
    assert 'file' not in task.args

    # Now test the validation
    with pytest.raises(AnsibleParserError):
        task.args['foo'] = 'bar'
        task.action = 'import_playbook'
        ti.check_options(task, {})

    task.args.pop('foo')
    task.action = 'import_tasks'
    with pytest.raises(AnsibleParserError):
        task.args['apply']

# Generated at 2022-06-23 07:19:07.287196
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    import ansible.executor.task_result as task_result

    # CREATE TEST OBJECT SET
    ########################
    task_include = TaskInclude()
    task_include.set_loader(None)
    task_include.set_defaults(None)
    task_include.set_action('include')
    task_include.set_loop('item.name')
    task_include.set_loop_with('item')

    # CREATE TEST PLAY CONTEXT OBJECT
    ################################
    play_context = PlayContext()
    play_context.verbosity = 3
    play_context.connection = 'ssh'
    play_context.remote_addr = 'svn01'
    play_context.remote_user = 'root'
    play

# Generated at 2022-06-23 07:19:17.814371
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Test TaskInclude.copy() method
    '''
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    play_context = PlayContext()
    play_context.remote_addr = 'localhost'

# Generated at 2022-06-23 07:19:27.136047
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # create fake variables
    block = "play"
    role = "role"
    # fake task include
    task = TaskInclude(block=block, role=role)

    # block is None because 'tasks' are not involved in the test
    data = dict(file="test.yml")

    # create an instance of TaskInclude
    ti = TaskInclude.load(data, block=block, role=role, task_include=task)

    assert ti.action == 'include'
    file_dict = dict(file="test.yml")
    assert ti.task_includes == file_dict


# Generated at 2022-06-23 07:19:28.949755
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude()
    assert t

# Generated at 2022-06-23 07:19:41.786239
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    ds = {'action': 'include', 'a': 'b'}
    res = task_include.preprocess_data(ds)
    assert res == {'action': 'include', 'a': 'b', 'args': {'a': 'b'}}

    ds = {'action': 'include', 'a': 'b', 'args': {'c': 'd'}}
    res = task_include.preprocess_data(ds)
    assert res == {'action': 'include', 'a': 'b', 'args': {'c': 'd', 'a': 'b'}}

    ds = {'action': 'include', 'a': 'b', 'args': {'c': 'd'}, 'tags': 't'}
    res = task_include.preprocess_data

# Generated at 2022-06-23 07:19:43.389524
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude

# Unit test TaskInclude.load

# Generated at 2022-06-23 07:19:53.277866
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(['localhost']))

    stream = (
        "---\n"
        "- hosts: localhost\n"
        "  tasks:\n"
        "    - include_tasks: include1.yml var1=val1\n"
    )

# Generated at 2022-06-23 07:19:56.375742
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    assert True == ti.copy().statically_loaded

# Generated at 2022-06-23 07:20:03.229668
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # method get_vars test cases
    task = TaskInclude()
    ansible_playbook_path = None
    ansible_playbook_path = task.get_vars(ansible_playbook_path)
    #assert ansible_playbook_path == ansible_playbook_path
    return 0


# Generated at 2022-06-23 07:20:15.704318
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'something'
    task_include.statically_loaded = False
    task_include.args = {'a':'1', 'b':'2'}
    assert task_include.get_vars() == {'a':'1', 'b':'2'}
    task_include.args = {'a':'1', 'b':'2'}
    assert task_include.get_vars() == {'a':'1', 'b':'2'}
    task_include.args = {'a':'1', 'b':'2'}
    task_include.vars = {'c':'3', 'd':'4'}

# Generated at 2022-06-23 07:20:18.368937
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert isinstance(ti, TaskInclude)
    assert isinstance(ti, Task)
    assert isinstance(ti, Block)
    assert hasattr(ti, 'statically_loaded')

# Generated at 2022-06-23 07:20:31.686307
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockTaskInclude(TaskInclude):
        pass


# Generated at 2022-06-23 07:20:40.402345
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = None

    # Create and return 'stats' with keys and values
    def _get_stats(**kwargs):
        stats = {}
        for key, val in kwargs.items():
            stats[key] = val
        return stats

    # Test each TaskInclude.check_options() 'bad_opts' outcome
    def _test_TaskInclude_check_options(action, file, expectation):
        task = TaskInclude()
        data = {'action': action, u'file': file}
        task.load_data(data, variable_manager=variable_manager, loader=loader)
        task.action = action  # This is necessary because setting 'action' after loading data does not update 'args'
       

# Generated at 2022-06-23 07:20:51.666718
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.plugins.loader import include_role_task
    from ansible.plugins.loader import import_tasks_task
    from ansible.plugins.loader import include_tasks_task

    plugin_base = TaskInclude

    task_base = TaskInclude.load({'action': 'include_role'})

    # include_* tasks
    for action, plugin_class in (
            ('include_role', include_role_task.ActionModule),
            ('import_tasks', import_tasks_task.ActionModule),
            ('include_tasks', include_tasks_task.ActionModule)):
        task = plugin_class(task_base)
        task.action = action


# Generated at 2022-06-23 07:21:03.137906
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    my_vm=None
    my_play_context=PlayContext()
    my_play_context._play=Play()
    # Create a TaskInclude with the args 'apply' and check that a Block is created and returned
    my_taskinclude=TaskInclude()
    my_taskinclude.args={'apply':{'when':True}}
    my_taskinclude._role=None
    my_taskinclude._loader=None
    my_taskinclude._parent=None
    my_taskinclude._variable_manager=None
    my_block=my_taskinclude.build_parent_block()
    assert isinstance(my_block, Block)

    # Create a TaskInclude without the args 'apply' and check that a Block is

# Generated at 2022-06-23 07:21:10.454705
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    ti.VALID_ARGS = frozenset(('a', 'b'))
    ti.VALID_INCLUDE_KEYWORDS = frozenset(('a', 'b', 'c'))
    ds = dict(a=1, b=2, c=3)
    assert dict(a=1, b=2) == ti.check_options(ti.load_data(ds), ds).args

# Generated at 2022-06-23 07:21:21.231845
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    This unittest checks the method load of class TaskInclude. It asserts
    that the method raises AnsibleParserError when it receives an invalid
    action or when no file is specified for the action

    :return: A list of test cases to be executed
    '''
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 07:21:33.621000
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method is used to test the method TaskInclude.build_parent_block
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.utils.sentinel import Sentinel

    yaml_data = '''
    - name: include role
      include_role:
        name: nginx
    - name: include role with apply
      include_role:
        name: nginx
        apply:
          block:
            - debug:
                msg: "This task is a part of apply block"
    '''

# Generated at 2022-06-23 07:21:45.108504
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    # TODO: This only calls constructor, not really testing a lot
    task1 = TaskInclude()
    task2 = TaskInclude()
    task3 = TaskInclude()
    # Create a Block
    block1 = Block()
    block2 = Block()
    block3 = Block()
    # Assign blocks to Tasks
    task1.block = block1
    task2.block = block2
    task3.block = block3
    assert task1.block == block1
    assert task1.block == block1
    assert task1.block == task2.block
    assert not task

# Generated at 2022-06-23 07:21:57.922843
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockVariableManager(object):
        pass
    class MockLoader(object):
        pass
    # Valid data
    task_include_data = dict(action='include', args=dict(_raw_params='/fake/file'))
    task_import_data = dict(action='import_tasks', args=dict(_raw_params='/fake/file'))
    task_include_role_data = dict(action='include_role', args=dict(_raw_params='/fake/file'))
    task_import_role_data = dict(action='import_role', args=dict(_raw_params='/fake/file'))
    task_include_raw_data = dict(action='include_raw', args=dict(_raw_params='/fake/file'))

# Generated at 2022-06-23 07:22:04.161724
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Instance the class and test if it is the correct class
    ti_instance = TaskInclude()
    assert isinstance(ti_instance, TaskInclude)

    ti_instance.filter_tagged_tasks(list(['all']))
    ti_instance.filter_tagged_tasks(list(['test']))

# Generated at 2022-06-23 07:22:14.154555
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext

    t = TaskInclude()
    t.register = 'shell_out'
    t.name = 'Included task'
    t.action = 'include'
    t.include_role = 'myrole'
    t.include_tasks = 'myrole/tasks/main.yml'
    t.args = {'a': 1, 'b': 2, 'w': '{{outer_w}}'}

    t._variable_manager = PlayContext(variables={
        'a': 10,
        'b': 20,
        'outer_w': 'common_w',
    })

    all_vars = t.get_vars()
    assert all_vars['a'] == 1
    assert all_vars['b'] == 2
    assert all

# Generated at 2022-06-23 07:22:22.316566
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    # test if constructor of Role loads all attributes
    from ansible.playbook.role.include import IncludeRole

    task_include_without_args = IncludeRole.load({'include': 'file.yml'})
    assert task_include_without_args.static is False

    task_include_args = IncludeRole.load({'include': 'file.yml', 'name': 'TaskInclude'})
    assert task_include_args.name == 'TaskInclude'

# Generated at 2022-06-23 07:22:31.535396
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    data = dict(
        include='tasks/main.yml'
    )
    ti = TaskInclude.load(data)
    assert ti.args.get('_raw_params') == 'tasks/main.yml'
    assert not ti.statically_loaded


    data = dict(
        include='tasks/main.yml',
        static='yes'
    )
    ti = TaskInclude.load(data)
    assert ti.args.get('_raw_params') == 'tasks/main.yml'
    assert ti.statically_loaded


    data = dict(
        include='tasks/main.yml',
        static='no'
    )
    ti = TaskInclude.load(data)

# Generated at 2022-06-23 07:22:43.102072
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_block = TaskInclude(Block())
    data_include_playbook = dict(
        apply=dict(
            action=dict(module='test'),
        ),
    )
    data_include_role = dict(
        apply=dict(
            action=dict(module='test'),
        ),
    )
    data_include_tasks = dict(
        apply=dict(
            action=dict(module='test'),
        ),
    )
    data_import_role = dict(
        apply=dict(
            action=dict(module='test'),
        ),
    )
    data_import_tasks = dict(
        apply=dict(
            action=dict(module='test'),
        ),
    )

# Generated at 2022-06-23 07:22:53.149146
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Unit test for TaskInclude.preprocess_data
    """
    taskinclude = TaskInclude()
    # following checks that dict generated from preprocess_data contains
    # expected keys for a task/action pair
    for action in C._ACTION_ALL_INCLUDE_TASKS:
        task_dict_preprocess_data = taskinclude.preprocess_data({'action': action})
        task_dict_valid_keys = TaskInclude.VALID_INCLUDE_KEYWORDS
        assert task_dict_preprocess_data.keys() == task_dict_valid_keys



# Generated at 2022-06-23 07:23:02.126165
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.executor.task_result import TaskResult
    from ansible.vars import VariableManager
    from ansible.playbook.play_iterator import PlayIterator

    class DummyPlaybook(PlayIterator):

        def __init__(self):
            self.name = 'playbook'
            self.playbook = 'playbook'

    class DummyPlay(Block):

        def __init__(self):
            self.name = 'play'
            super(DummyPlay, self).__init__()

    class DummyTaskInclude(TaskInclude):

        def __init__(self):
            self._variable_manager = VariableManager()
            self.vars = {}
            super(DummyTaskInclude, self).__init__()

    # Test for action without 'include'
    ti = DummyTaskInclude()

# Generated at 2022-06-23 07:23:15.673677
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.role import Role
    from ansible.playbook.role.empty import EmptyRole
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    def _make_block(block, task=None):
        if task is None:
            task = Task()
        return block.copy(parent_block=task)

    def _make_role(role=None, task=None):
        if role is None:
            role = EmptyRole()
        if task is None:
            task = Task()
        return role.copy(parent_block=task)

    # Block is not None
    block = Block()
    task_include = TaskInclude(block=block)
    assert task_include.block == block
    assert task_include.action == 'meta'
    assert task

# Generated at 2022-06-23 07:23:28.063479
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    import ansible.plugins
    my_loader = ansible.plugins.loader.action_loader
    my_variable_manager = ansible.vars.VariableManager()
    my_inventory = ansible.inventory.Inventory(loader=my_loader, variable_manager=my_variable_manager)


# Generated at 2022-06-23 07:23:41.282111
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(
                include=dict(
                    apply=dict(
                        name="Ansible Block",
                        tags=['block'],
                    ),
                ),
            ),
        ],
    )

# Generated at 2022-06-23 07:23:57.622444
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play import Play as PlayObject
    from ansible.playbook.block import Block as BlockObject
    from ansible.playbook.task import Task as TaskObject

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['dummy1'])

# Generated at 2022-06-23 07:24:03.456340
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = dict(
        action='myaction',
        tags=['tag1', 'tag2'],
        args=dict(
            foo=dict(
                bar='baz',
                bat=dict(one=1, two=2),
            )
        ),
    )
    ti = TaskInclude(None, None, None)
    task = ti.load(data)
    assert task.action == 'myaction'


# Unit tests for check_options()

# Generated at 2022-06-23 07:24:14.682204
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    task = TaskInclude(block=block)
    task.args['arg1'] = 'val1'
    task.args['arg2'] = 'val2'
    task.vars['var1'] = 'val1'
    task.vars['var2'] = 'val2'
    task.action = 'include'

    block.vars = {'block_var1': 'block_val1'}
    block.tasks = [task]

    play = Play()
    play.vars = {'play_var1': 'play_val1'}
    play.block = block

    playbook = Playbook()
    playbook.vars = {'pb_var1': 'pb_val1'}
    playbook.plays = [play]

    var_manager = VariableManager()
    var_

# Generated at 2022-06-23 07:24:26.910831
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class TestTaskInclude(TaskInclude):
        '''
        Test class for TaskInclude get_vars method
        '''
        def __init__(self):
            super(TaskInclude, self).__init__()
            self.action = 'include'
            self.vars = dict(a=1)
            self.args = dict(b=2)
            self._parent = None

    task_include = TestTaskInclude()
    vars = task_include.get_vars()
    assert isinstance(vars, dict) and vars == dict(a=1, b=2)

    class TestPlay:
        '''
        Test class for TaskInclude get_vars method
        '''
        def get_vars(self):
            return dict(c=3)

    task_include._parent

# Generated at 2022-06-23 07:24:33.465782
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    It tests the method build_parent_block of the class TaskInclude
    '''

    # Defining necessary attributes that are not defined in the method initialize
    block = Block()
    role = 'role'
    apply_attrs = {}
    task_include = 'task_include'
    attrs = {'block': block, 'action': 'include', 'apply': apply_attrs}

    # Initialize TaskInclude object
    task_obj = TaskInclude(block=block, role=role, task_include=task_include)
    # Initialize apply_attrs
    apply_attrs['block'] = []
    # Defining arguments for method load
    data = {'_parent': block}
    data.update(attrs)
    # Assigning arguments and loading data

# Generated at 2022-06-23 07:24:45.208062
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import HandlerTask
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext

    variable_manager = MockVariableManager()
    loader = MockLoader()
    variable_manager._fact_cache = {'localhost': {'ansible_facts': {'f1': '1'}}}
    target_host = MockHost()
    target_host.name = 'localhost'
    blocked_host = MockHost()
    blocked_host.name = 'blocked'
    play_context = PlayContext(remote_addr=target_host.name)
    task = TaskInclude(block=None, role=None, task_include=None)
    task_custom = TaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 07:24:56.222206
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = dict(action='include', _raw_params='foo')
    task_modified = ti.check_options(task, dict(action='include', file='foo'))
    assert task_modified == dict(action='include', _raw_params='foo', ignore_errors=False, no_log=False, register=None)

    tasks = dict(action='include_role', _raw_params='foo', static=False)
    task_modified = ti.check_options(tasks, dict(action='include_role', file='foo', static=False))
    assert task_modified == dict(action='include_role', _raw_params='foo', ignore_errors=False, no_log=False, register=None, static=False)


# Generated at 2022-06-23 07:25:08.744604
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with valid args
    task_valid_args = {
        'action': 'include_tasks',
        'args': {
            '_raw_params': '/some/file/or/other',
            'apply': {
                'collect_facts': True,
            }
        }
    }
    task_valid_args_copy = task_valid_args.copy()
    task_valid_args_copy['action'] = 'include_role'
    ti = TaskInclude()

    ti.check_options(ti.load_data(task_valid_args), task_valid_args)
    ti.check_options(ti.load_data(task_valid_args_copy), task_valid_args_copy)

    # Test with invalid args

# Generated at 2022-06-23 07:25:13.506054
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Test constructor with no arguments
    ti = TaskInclude()
    assert 'block' not in ti
    assert 'role' not in ti
    assert 'task_include' not in ti
    assert ti.statically_loaded == False

# Test load method with no arguments

# Generated at 2022-06-23 07:25:16.008870
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Unit test for constructor of class TaskInclude
    '''
    ti = TaskInclude(None, task_include=None)
    assert ti is not None


# Generated at 2022-06-23 07:25:27.755697
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MyTaskInclude(TaskInclude):
        def load_data(self, data, variable_manager=None, loader=None):
            return super(MyTaskInclude, self).load_data(data, variable_manager=variable_manager, loader=loader)

    task = MyTaskInclude.load({
        'action': 'some_action',
        'my_arg': 'some_arg'
    })
    assert task.action == 'some_action'
    assert task.args == dict(_raw_params='some_arg')

    task = MyTaskInclude.load({
        'action': 'some_action',
        'file': 'some_file'
    })
    assert task.action == 'some_action'
    assert task.args == dict(_raw_params='some_file')


# Generated at 2022-06-23 07:25:31.307924
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude()
    assert t.action == 'include'
    assert t.args == {}
    assert t.vars == {}
    assert t.loop is None
    assert t.notify is None



# Generated at 2022-06-23 07:25:39.681220
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    args = {'apply': {'action': 'debug'}}
    assert TaskInclude.load(args).args == args  # __init__ calls check_options, which sets the args
    assert TaskInclude.load(args).statically_loaded is False
    assert TaskInclude.load({'not': 'valid'}, task_include=TaskInclude()).statically_loaded is False
    assert TaskInclude.load({'statically_loaded': True}, task_include=TaskInclude()).statically_loaded is True



# Generated at 2022-06-23 07:25:52.762305
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test with - include: ...
    yaml_include = '''- include: "test_task_include.yml"'''
    data = {'action': 'include', 'args': {'_raw_params': '"test_task_include.yml"'}}
    task = TaskInclude.load(data)
    assert task.args.keys() == ['_raw_params']
    assert task.action == 'include'
    assert task.args == data['args']

    # Test with - include_role: ...
    yaml_include = '''- include:
        file: "test_task_include.yml"
    '''
    data = {'action': 'include', 'args': {'file': '"test_task_include.yml"'}}
    task = TaskInclude.load(data)
   

# Generated at 2022-06-23 07:25:53.168321
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    pass

# Generated at 2022-06-23 07:26:02.408532
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    task = Task()
    task.action = 'include'
    task.args = dict(a_var='foobar', another_var=dict(a_key='a_value'))
    task.name = 'include test task'
    vm = VariableManager()
    vm.set_inventory(InventoryManager(loader=None, sources='localhost,'))
    task._variable_manager = vm

    assert task.get_vars() == dict(a_key='a_value', a_var='foobar')



# Generated at 2022-06-23 07:26:04.931849
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Unit test for class TaskInclude
    '''
    task_inc = TaskInclude()
    # pylint: disable=no-member
  

# Generated at 2022-06-23 07:26:09.793502
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Tests constructor of class TaskInclude.
    '''
    test_block = Block()
    test_role = None
    test_task_include = None

    task_include = TaskInclude(block=test_block, role=test_role, task_include=test_task_include)
    assert task_include and task_include.BASE and task_include.OTHER_ARGS and task_include.VALID_ARGS and task_include.VALID_INCLUDE_KEYWORDS