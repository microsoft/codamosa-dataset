

# Generated at 2022-06-23 07:16:18.195290
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This method tests the get_vars method of class TaskInclude
    '''
    # Initialize a mock TaskInclude object without a parent
    ti_no_parent = TaskInclude()

    # Get the vars for action include
    action_include_vars_no_parent = ti_no_parent.get_vars()
    action_include_vars_no_parent_ref = {'action': 'include'}
    assert action_include_vars_no_parent == action_include_vars_no_parent_ref

    # Get the vars for action import_playbook
    ti_no_parent.action = 'import_playbook'
    action_import_playbook_vars_no_parent = ti_no_parent.get_vars()
    action_import_playbook_vars

# Generated at 2022-06-23 07:16:28.539920
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Test that copy() sets the statically_loaded flag properly.
    '''
    static_block = Block(PlayContext(), role=None, task_include=None)
    # Set the flag to True.
    static_block.statically_loaded = True
    # Copy the block, the flag should still be True.
    static_copy = static_block.copy()
    assert static_copy.statically_loaded == True
    # Copy the block without the parent, the flag should still be True.
    static_copy_without_parent = static_block.copy(exclude_parent=True)
    assert static_copy_without_parent.statically_loaded == True
    static_task = static_block.load_data(dict(action='include_vars', args=dict(file='foo.yml')))
    # Copy the

# Generated at 2022-06-23 07:16:41.518753
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # create dummy play to load Block and Task
    play = Play()
    play.context = PlayContext(play=play)
    play.LOADER = None

    ds = dict(
        apply=dict(
            ignore_errors=True,
            when=True,
        ),
    )

    playbook_dir = "/tmp"
    def get_basedir_loader():
        return playbook_dir

    # create a task_include with parent of type Block

# Generated at 2022-06-23 07:16:53.880903
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VarManager

    # Test with a bad action
    try:
        TaskInclude.load({'action': 'bar', 'file': 'foobar.yaml'}, PlayContext(), VarManager())
        raise Exception('Expected an AnsibleParserError')
    except AnsibleParserError:
        pass

    # Test with other bad options
    try:
        TaskInclude.load({'action': 'include', 'file': 'foobar.yaml', 'foo': 123}, PlayContext(), VarManager())
        raise Exception('Expected an AnsibleParserError')
    except AnsibleParserError:
        pass

    # Test with no file

# Generated at 2022-06-23 07:16:54.701311
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    pass

# Generated at 2022-06-23 07:17:01.646016
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Returns dict with arguments that are not allowed for various types of 'include' tasks
    '''
    ti = TaskInclude()
    tests = [
        {'action': 'include', 'arg': 'no_log'},
        {'action': 'import_tasks', 'arg': 'tags'},
        {'action': 'import_role', 'arg': 'tags'},
        {'action': 'include_role', 'arg': 'tags'},
    ]

    for test in tests:
        ds = {'action': test['action'], test['arg']: 'blah'}

# Generated at 2022-06-23 07:17:07.354226
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = dict(
        name='example',
        action='debug'
    )
    data = TaskInclude.load(data)
    assert isinstance(data, TaskInclude)
    assert data.name == 'example'
    assert data.action == 'debug'
    assert not hasattr(data, 'block')
    assert not hasattr(data, 'role')
    assert not hasattr(data, 'task_include')
    assert not data.statically_loaded



# Generated at 2022-06-23 07:17:18.573244
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Clear dynamically loaded handlers
    Task.DYNAMICALLY_LOADED_HANDLERS = frozenset()

    task = TaskInclude.load(
        data={'apply': {}, 'include': {}, 'loop': '{{users}}', 'name': 'test', 'tags': ['test'], 'when': 'test'},
        block=Block(parent_block=None, role=None, task_include=None, play=None),
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert isinstance(task, TaskInclude)

# Generated at 2022-06-23 07:17:22.740992
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    block = Block()
    role = []
    task_include = []
    task = TaskInclude(block,role,task_include)
    assert task.statically_loaded == False


# Generated at 2022-06-23 07:17:34.003347
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # pylint error C0111 - missing docstring
    # pylint error R0903 - too few public methods
    # pylint:disable=C0111,R0903

    class FakeTask(object):

        def __init__(self, args):
            # pylint error E1101 - instance has no <member> member
            # pylint:disable=E1101
            self.args = args

        def get_vars(self):
            return dict(one='1', two='2')

    class FakeBlock(object):

        def __init__(self, args):
            # pylint error E1101 - instance has no <member> member
            # pylint:disable=E1101
            self.args = args
            self.vars = dict(three='3', four='4')


# Generated at 2022-06-23 07:17:35.562191
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    taskInclude = TaskInclude()
    assert taskInclude.statically_loaded == False

# Generated at 2022-06-23 07:17:46.496001
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    data = {
        'action': 'include',
        'file': 'some.yml',
        'loop': {'first': '1'},
        'apply': {'foo': 'bar'}
    }

    pc = PlayContext()
    block = Block()
    block._role = None
    block._play = None
    task = TaskInclude.load(
        data,
        block=block,
        role=None,
        task_include=None,
        variable_manager=VariableManager(loader=None),
        loader=None
    )

    assert isinstance(task, TaskInclude)
    assert task.action == 'include'

# Generated at 2022-06-23 07:17:58.056093
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Make sure we have an empty self.args
    my_TaskInclude = TaskInclude(block=None, role=None, task_include=None)
    if my_TaskInclude.args:
        raise ValueError("TaskInclude.args should be empty for this test")

    # Do not use apply_attrs
    assert my_TaskInclude.build_parent_block() is my_TaskInclude

    # Create a sample apply_attrs
    apply_attrs = {
        'name': 'sample apply_attrs',
        'tags': ['foo', 'bar'],
        'when': 'sample_when_condition',
    }

    # Add apply_attrs with a valid Action
    my_TaskInclude.args['action'] = 'include_tasks'
    my_TaskInclude.args['apply'] = apply

# Generated at 2022-06-23 07:18:07.824278
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import inspect
    import json
    import tempfile
    import os
    import shutil
    import random
    import string
    from os.path import join as pjoin

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.task_include import TaskInclude

    from ansible.utils.display import Display
    from ansible.playbook.play_iterator import PlayIterator

    display.verbosity = 4

    # Constants for the testDataGenerator
    DEFAULT_DATA

# Generated at 2022-06-23 07:18:17.702027
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti._loader = None
    ti._variable_manager = None
    ti._parent = None

    fake_block = {}
    fake_block['block'] = [{'local_action': {'module': 'debug', 'msg': 'my block'}}]
    fake_block['always'] = []
    fake_block['rescue'] = []
    fake_block['any_errors_fatal'] = False
    fake_block['continue'] = True

    ti._role = False
    ti._play = False
    ti._task_include = False
    ti.action = 'include'
    ti.args = dict()
    ti.args['apply'] = fake_block

    parent_block = ti.build_parent_block()


# Generated at 2022-06-23 07:18:23.909837
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_data = {'include': 'tasks/install.yml'}

    ti = TaskInclude()
    result = ti.preprocess_data(test_data)
    assert isinstance(result, dict)
    assert len(result) == 1
    assert result['_raw_params'] == 'tasks/install.yml'

# Generated at 2022-06-23 07:18:36.346432
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    task = TaskInclude(block=block)
    task2 = TaskInclude(block=block)
    block.add_task(task)
    block._parent = Block(play=None)

    task.add_task(task2)
    task2.args = {
        'arg1': 'val1',
        'arg2': 'val2',
        'arg3': 'val3',
        'when': 'True',
        'tags': 'test'
    }

    task.args = {
        'arg4': 'val4',
        'arg5': 'val5',
        'arg6': 'val6',
        'when': 'True',
        'tags': 'test'
    }


# Generated at 2022-06-23 07:18:48.793410
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Test 1: If a TaskInclude object has an _parent, the method copy()
    #         must create a new TaskInclude object with the same value
    #         of attribute _parent then the original object
    task_include_obj = TaskInclude(
        block=Block(
            play=Play(),
            task_include=None
        ),
        task_include=None
    )
    task_include_copy = task_include_obj.copy()

    assert task_include_obj._parent == task_include_copy._parent
    assert task_include_obj.statically_loaded == task_include_copy.statically_loaded
    assert task_include_obj.action == task_include_copy.action
    assert task_include_obj.vars == task_include_copy.vars

# Generated at 2022-06-23 07:19:00.570733
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = Task()
    task.action = 'include'

    task.args = dict(
        file='include_file',
    )
    task_include.check_options(task, '')
    assert task.args == {'_raw_params': 'include_file'}

    task.args = dict(
        file='include_file',
        debug=True,
    )
    task_include.check_options(task, '')
    assert task.args == {'_raw_params': 'include_file', 'debug': True}

    task.args = dict(
        file='include_file',
        apply=dict(
            min_days=1,
            max_days=2,
        ),
    )
    task_include.check_options(task, '')


# Generated at 2022-06-23 07:19:10.157253
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    # Successful cases

# Generated at 2022-06-23 07:19:21.511683
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    vars_dict = dict(
        var1 = 'var1',
        var2 = 'var2',
    )

    var_manager = DummyVariableManager()
    var_manager.set_host_variable(host = "hostname", vars = vars_dict)

    parent = DummyParent("hostname", var_manager)
    task = TaskInclude.load({
        "action" : "include",
        "args" : {
            "var1" : "var1",
            "var3" : "var3",
            "tags" : "tag1",
            "when" : "1 == 2"
        },
        "name" : "Include Task"
    }, parent)
    task.set_loader(None)
    task.vars = {}

    task_vars = task.get_v

# Generated at 2022-06-23 07:19:31.387942
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude.load({
        'include': 'task.yaml',
        'tags': ['include-tag'],
        'when': 'include-when',
    })

    assert task_include._role is None
    assert task_include.action in C._ACTION_INCLUDE
    assert task_include.args == {
        'file': 'task.yaml',
    }
    assert task_include.delegate_to is None
    assert task_include.name == 'task.yaml'
    assert task_include._parent is None
    assert task_include.tags == ['include-tag']
    assert task_include.when == 'include-when'



# Generated at 2022-06-23 07:19:43.727705
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    complex_data = {"import_tasks": "{{ x }}",
                    "import_tasks": "x",
                    "with_items": "{{ x }}",
                    "with_items": "x",
                    "include": "{{ x }}",
                    "include": "x"}
    test_set = [Sentinel]
    success_expected = [{'action': 'x', '_raw_params': 'x'},
                        {'action': 'x', '_raw_params': Sentinel},
                        {'action': 'x', '_raw_params': 'x'},
                        {'action': 'x', '_raw_params': Sentinel},
                        {'action': 'include', '_raw_params': 'x'},
                        {'action': 'include', '_raw_params': Sentinel}]

    test_set.extend

# Generated at 2022-06-23 07:19:52.433827
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    test_data = {'action': 'include_tasks', 'tasks': 'tasks.yml', 'other_arg': 'other_arg'}
    obj = TaskInclude()
    assert obj.preprocess_data(test_data) == {'action': 'include_tasks', 'tasks': 'tasks.yml'}
    test_data_obj = AnsibleBaseYAMLObject(test_data)
    assert obj.preprocess_data(test_data_obj) == {'action': 'include_tasks', 'tasks': 'tasks.yml'}


# Generated at 2022-06-23 07:20:05.880919
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    task_data = dict(
        action='include',
        file='somefile',
        apply=dict(
            block=[]
        )
    )

    task = TaskInclude(block=None, role=None, task_include=None)
    task.vars = dict()
    task.tags = list()

    task.args = task.load_data(task_data,variable_manager=None, loader=None)

    task.args['apply']['vars'] = dict()
    task.args['apply']['vars']['test_var'] = 'test_value'

    parent_block = task.build_parent_block()

    assert isinstance(parent_block,Block)
    assert parent_block._vars['test_var'] == 'test_value'
    assert parent_block._parent == task

# Generated at 2022-06-23 07:20:17.781197
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Method for testing options validation to use in 'load_data' of class TaskInclude
    '''
    task = TaskInclude()

    # load_data will set the action to 'include'
    task.action = 'include'
    # BASE
    task.args = {
        'file': 'foo',
    }
    task = task.check_options(task, {})
    assert 'file' not in task.args
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == 'foo'

    task.args = {
        '_raw_params': 'foo',
    }
    assert task.check_options(task, {}) == task

    # OTHER_ARGS
    task.action = 'include'

# Generated at 2022-06-23 07:20:31.088058
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    display = Display()
    block = TaskInclude()
    attrs = {
        'block': '',
        'debugger': '',
        'ignore_errors': '',
        'loop': '',
        'loop_control': {'loop_var': 'item'},
        'loop_with': ['foo'],
        'no_log': '',
        'register': '',
        'run_once': '',
        'tags': [],
        'timeout': 0,
        'vars': {},
        'when': [],
    }
    block._parent = None
    block._role = None
    block._loader = None
    block._variable_manager = None
    block.action = 'block'
    block.args = attrs

# Generated at 2022-06-23 07:20:36.900296
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.task

    play_context = dict(TEST_PLAY_CONTEXT)
    loader = DictDataLoader({"foo": """
    - include: bar
        loop: "{{ listvar }}"
    """})
    inventory = Inventory("localhost", loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load(dict(
        name="test",
        hosts="localhost",
        gather_facts=False,
        tasks=[
            dict(include="foo")
        ]
    ), variable_manager=variable_manager, loader=loader)

    pb = Playbook.load(play, variable_manager=variable_manager, loader=loader)
    pb.RUN_DATA['strategy'] = 'free'

# Generated at 2022-06-23 07:20:47.026949
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude(block=None, role=None, task_include=None)

    # Unit test with invalid parameters
    task = ti.copy(exclude_parent='False', exclude_tasks='False')
    assert(isinstance(task, TaskInclude))

    # Verify copy of statically_loaded attribute
    ti.statically_loaded = True
    task = ti.copy()
    assert(task.statically_loaded == True)

    # Verify copy of non-static attribute
    task = ti.copy()
    assert(task != ti)
    assert(isinstance(task, TaskInclude))


# Generated at 2022-06-23 07:20:59.165322
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    def task_include_assert(block, role, task_include, statically_loaded, exclude_parent, exclude_tasks):
        'Unit test for method copy of class TaskInclude'
        task = TaskInclude(block=block, role=role, task_include=task_include)
        task.statically_loaded = statically_loaded
        assert task.statically_loaded == statically_loaded
        assert task.copy(exclude_parent=exclude_parent, exclude_tasks=exclude_tasks).statically_loaded == statically_loaded

    task_include_assert(
        block=None,
        role=None,
        task_include=None,
        statically_loaded=False,
        exclude_parent=False,
        exclude_tasks=False,
    )

# Generated at 2022-06-23 07:21:01.567351
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # task = TaskInclude()
    # assert task.__class__.__name__ == 'TaskInclude'
    pass

# Generated at 2022-06-23 07:21:09.100972
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    Unit test for check_options method of class TaskInclude.
    """

    import ansible.playbook
    from ansible.cli.arguments import opt_args

    test_opt_args = opt_args.copy()
    test_opt_args.pop('inventory', None)
    test_opt_args.pop('skip_tags', None)
    test_opt_args.pop('tags', None)
    test_opt_args.pop('syntax', None)

    parser = ansible.cli.CLI.base_parser(
        constants=C,
        desc="Testing TaskInclude class",
        usage="testing",
        epilog="testing",
        options_list=list(test_opt_args.values()),
    )

    # py2/py3 helper for testing

# Generated at 2022-06-23 07:21:17.651252
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    import pytest

    class dummy_block:

        class dummy_play:
            pass

        class dummy_role:
            pass

        class dummy_task_include:
            pass

    block = dummy_block()
    block._play = block.dummy_play()
    block._role = block.dummy_role()
    block._task_include = block.dummy_task_include()

    # Test invalid args
    # Note: we need to send a new instance of dummy_block with each iteration
    # otherwise we get a ref to the old object, and the test will fail
    for k in ('one', 'two'):
        task = TaskInclude(block=dummy_block())
        task.action = 'include'

# Generated at 2022-06-23 07:21:28.167193
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role_context import RoleContext
    from ansible.vars.manager import VariableManager

    t_block1 = Block.load({})
    t_block1._role = RoleContext()

    t_task1 = TaskInclude.load({'action': 'include', 'apply': {'block': []}}, block=t_block1)
    t_task1._parent._variable_manager = VariableManager()

    t_task2 = t_task1.copy()

    assert t_task1.action == t_task2.action
    assert t_task1.name == t_task2.name
    assert t_task1.args == t_task2.args
    assert t_task1

# Generated at 2022-06-23 07:21:37.373016
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.module_utils import basic

    import ansible.plugins.action.include as include_action
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import hostvars

    # Create a ds and add to it two keys: meta and include
    ds = AnsibleBaseYAMLObject()
    ds.__ansible_module__ = AnsibleBaseYAMLObject()
    ds.__ansible_module__.__name__ = 'include'
    ds['a_meta'] = 'meta_value'
    ds['a_include'] = 'include_value'

    #

# Generated at 2022-06-23 07:21:47.807581
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    m = TaskInclude()

# Generated at 2022-06-23 07:21:59.487492
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    display.verbosity = 2
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = {'file': 'test.yml'}
    ti.tasks = [Task()]
    ti.statically_loaded = True

    ti_copy = ti.copy()

    assert ti_copy.action == 'include'
    assert ti_copy.args == {'file': 'test.yml'}
    assert len(ti_copy.tasks) == 1
    assert ti_copy.statically_loaded is True


# Test import of class TaskInclude
from ansible.playbook.handler_task_include import HandlerTaskInclude

from ansible.playbook.conditional import Conditional
from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-23 07:22:07.096837
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    dynamically_loaded = {'_role': None, '_parent': None, '_block': None, '_load_role': None,
                          'vars': {'include_tasks': 'tasks'}, 'action': 'include_tasks',
                          'args': {'_raw_params': 'tasks', 'tags': ['all']},
                          '_task': 'include_tasks', 'tags': ['all'], 'when': 'never'}

# Generated at 2022-06-23 07:22:10.406501
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Constructor can construct TaskInclude object
    assert TaskInclude() is not None

# Generated at 2022-06-23 07:22:19.075985
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.utils.sentinel import Sentinel
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    ansible_task_args = dict(file="./tasks/tasks_file", apply=dict(block=[]))
    task = TaskInclude(block=None, role=None, task_include=None)
    task.vars = dict(name=Sentinel(), bar="baz")
    task._parent = Block()
    task._parent.vars = dict(foo="bar")
    task._parent._play = Play()
    task._variable_manager = VariableManager()
    task.args = ansible_task_args
    parent_block = task.build_parent

# Generated at 2022-06-23 07:22:30.059721
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.vars.manager import VariableManager

    play_context = dict(become=False, become_method=None, become_user=None, connection=None, check=False, diff=False)
    loader = DictDataLoader({'main.yml': 'foo'})
    variable_manager = VariableManager(loader=loader)

# Generated at 2022-06-23 07:22:42.041285
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Test TaskInclude.load() method.
    '''
    import os.path
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # create a play context
    context = PlayContext()
    context.remote_addr = "localhost"
    context.connection = "local"
    context.remote_user = "root"
    context.port = 2222
    context.become = False

    # create a variable manager
    base_vars = VariableManager()

    # create a data loader
    loader = DataLoader()

    # mock a class from which we will create the task include
    role = type('Role', (), {})

    task_include = None

    # create a task

# Generated at 2022-06-23 07:22:50.776417
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class DummyClass(object):
        pass

    # Create a dummy ActionBase class for an include task
    class DummyActionBase(object):
        @staticmethod
        def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
            return DummyActionBase()

        def __init__(self, block=None, role=None, task_include=None):
            self.name = task_include.get_name()

        def copy(self, exclude_parent=False, exclude_tasks=False):
            return self

    # Create a dummy task to include
    class DummyTask(Task):
        __metaclass__ = FieldAttribute

        def __init__(self, block=None, role=None, task_include=None):
            self._block = block
           

# Generated at 2022-06-23 07:22:57.423391
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = dict(
        _raw_params='files/main.yml',
        action='include',
        task_include=True,
        apply=dict(debugger='on'),
        loop='{{ list_of_hosts }}',
    )
    ti = TaskInclude()
    if ti.check_options(ti.load_data(data), data) == None:
        raise AssertionError('Method load of class TaskInclude returns None')

# Generated at 2022-06-23 07:23:08.824259
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import copy
    import ansible.playbook.task_include
    import ansible.playbook.block

    x = '''
    - debug: var=item
      loop:
      - 1
      - 2

    - name: Display variable a
      debug: var=a
    '''

    def fake_get_vars(self):
        return {'item': 1, 'a': 'aaa'}

    saved_get_vars = ansible.playbook.task_include.TaskInclude.get_vars
    ansible.playbook.task_include.TaskInclude.get_vars = fake_get_vars

    y = copy.deepcopy(x)
    y = y.replace('- debug: var=item', '- include: fake.yml apply=loop')

    t1 = ansible.play

# Generated at 2022-06-23 07:23:19.477515
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for TaskInclude.load
    '''

    # We can't properly unit test this method because we need a 'real'
    # loader.__task_cache. So this in this test we will check more
    # that the method structure is correct

    # Create object to test
    ti = TaskInclude()
    dc = dict()

    # Check that the method return a dict
    assert isinstance(ti.load(dc), dict)

    # Check that the method raise an error if it doesn't find the
    # '_raw_params' key in the data
    try:
        ti.load(dc)
    except AnsibleParserError as e:
        assert 'No file specified for include' in to_text(e)
    except Exception as e:
        assert False, str(e)

    # Add the 'file

# Generated at 2022-06-23 07:23:30.704145
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test to validate the method build_parent_block of class TaskInclude
    We use a dummy play ansible.playbook.Play() and a dummy block ansible.playbook.block.Block()
    '''
    from ansible.playbook import Play
    import ansible.utils.vars as ans_vars
    import ansible.constants as ans_constants

    task = TaskInclude()

    # If there is not apply in the task args we are return the task
    task.args = {'not_apply': 'not_apply_value'}
    p_block = task.build_parent_block()
    assert p_block == task

    # If apply exists in the task args we are going to load a Block and return it
    task.args = {'apply': {'block': 'test'}}
   

# Generated at 2022-06-23 07:23:42.182922
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude.load(dict(action="include_tasks", file="./main.yml"))
    assert task.args['_raw_params'] == "./main.yml"
    assert task.action == "include_tasks"

    task = TaskInclude.load(dict(action="include_tasks", file="./main.yml", loop_control=dict(loop_var="item")))
    assert task.args['_raw_params'] == "./main.yml"
    assert task.action == "include_tasks"
    assert task.loop_control == dict(loop_var="item")

    task = TaskInclude.load(dict(action="import_playbook", file="./main.yml", apply=dict(ignore_errors=True)))

# Generated at 2022-06-23 07:23:49.297847
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    runner = C.action_loader.get('include', runner=None)
    action = 'include'
    ds = {'action': action}
    ti = TaskInclude.load(data=ds, action=action, runner=runner)
    assert set(ti.preprocess_data(ds).keys()) == TaskInclude.VALID_INCLUDE_KEYWORDS
    ti = TaskInclude.load(data=ds, action='include_tasks', runner=runner)
    assert set(ti.preprocess_data(ds).keys()) == TaskInclude.VALID_INCLUDE_KEYWORDS
    ti = TaskInclude.load(data=ds, action='include_role', runner=runner)
    assert set(ti.preprocess_data(ds).keys()) == TaskInclude.VALID_INCLUDE_

# Generated at 2022-06-23 07:23:59.595387
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    file_name = os.path.join(os.path.dirname(__file__), '../../test/units/modules/test_meta.py')
    data = {
        'action': 'include',
        'args': {
            'apply': {
                'vars': {
                    'file': 'test'
                }
            },
            'other_param': 'test',
            'file': file_name,
        }
    }

# Generated at 2022-06-23 07:24:04.634817
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'action'  : 'include',
          'name'    : 'task_include.yml',
          'args'    : '',
          'tags'    : ['dev','test'],
          'not_valid_attr' : 'attr1'
          }
    task_include = TaskInclude(block=None, role=None, task_include=None)

    new_ds = task_include.preprocess_data(ds)
    assert ds == new_ds

# Generated at 2022-06-23 07:24:12.152086
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    target = {'a':1, 'b':2, 'c':3}
    klass = TaskInclude()
    klass._parent = {'a':1, 'b':2, 'd':4}
    klass.action = 'include'
    klass.vars = {'b':20, 'e':5}
    klass.args = {'c':30, 'f':6}
    assert klass.get_vars() == target

# Generated at 2022-06-23 07:24:23.895049
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class TaskIncludeResult:
        def __init__(self, all_vars):
            self.all_vars = all_vars

    class TaskResult:
        def __init__(self, all_vars):
            self.all_vars = all_vars

    class BlockResult:
        def __init__(self, all_vars):
            self.all_vars = all_vars

    class ParentTaskResult:
        def __init__(self, all_vars):
            self.all_vars = all_vars

    class ParentBlockResult:
        def __init__(self, all_vars):
            self.all_vars = all_vars

    class RoleResult:
        def __init__(self, all_vars):
            self.all_vars = all_

# Generated at 2022-06-23 07:24:30.354559
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Test method copy of class TaskInclude
    '''
    # The class method copy of the class TaskInclude is tested through test_copy in the class Task
    # because all is tested in the class Task. The method copy of the class Task is superseded by the
    # same method in the class TaskInclude, so here is nothing more to test.
    # However, when the method copy of the class Task is tested, is checked also if the copy object
    # is a TaskInclude object.
    pass


# Generated at 2022-06-23 07:24:40.288317
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block1 = Block()
    block2 = Block()
    task1 = Task(block1, role=None, task_include=None)
    task2 = Task(block2, role=None, task_include=None)
    print(id(block1))
    print(id(block2))
    task1._parent = task2
    task2.args = {'apply':{'block':'[]'}}
    print(task2.args)
    print(id(task1.build_parent_block()))

test_TaskInclude_build_parent_block()

# Generated at 2022-06-23 07:24:49.674022
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    This is a pytest unit test for method 'preprocess_data' in class 'TaskInclude'.
    '''
    ti = TaskInclude()

    # This data should return the same data because 'action' is not in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    data_1 = {'action': 'include', 'bogus_var': 'bogus_value', 'file': 'some/file'}
    result_1 = ti.preprocess_data(data_1)
    assert 'bogus_var' in result_1
    assert 'bogus_value' == result_1['bogus_var']
    assert 'file' in result_1
    assert 'some/file' == result_1['file']

    # This data should return the original data as there is

# Generated at 2022-06-23 07:24:56.503746
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t = TaskInclude()
    t.static = True
    c = t.copy()
    assert c.static == True
    assert c.statically_loaded == False
    t = TaskInclude()
    t.statically_loaded = True
    c = t.copy()
    assert c.static == True
    assert c.statically_loaded == True

# Generated at 2022-06-23 07:25:00.147708
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    ti_copy = ti.copy()
    assert ti_copy.statically_loaded == True

# Generated at 2022-06-23 07:25:12.444035
# Unit test for constructor of class TaskInclude

# Generated at 2022-06-23 07:25:18.381013
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext

    block = Block()
    block.vars = {'foo': 'foo_in_block', 'bar': 'bar_in_block'}
    block.parent_block = None

    task = TaskInclude(block=block)
    task.action = 'include'
    task.args = {'baz': 'baz_in_task'}
    task.vars = {'baz': 'baz_in_task', 'hat': 'hat_in_task'}
    task.tags = ['t']
    task.when = 'w'

    p_task = TaskInclude(block=task)
    p_task.action = 'include_role'
    p_task.args = {'boo': 'boo_in_ptask'}


# Generated at 2022-06-23 07:25:26.210808
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Imports are inside the function as we don't need all of the modules loaded
    # when unit testing in general
    import ansible.playbook

    # Create a task that includes a raw_params file
    task_include = TaskInclude(None, None, None)
    task_include.action = 'include'
    task_include.args = {'file': 'my_file.yml', 'apply': {'block': []}}
    task_include.vars = {}

    # Create the task include's parent block
    parent_block = task_include.build_parent_block()

    # Create a task to be included inside the task include
    task = ansible.playbook.Task(None, None, None)
    task.action = 'command'
    task.args = {'_raw_params': 'echo "hello world"'}

# Generated at 2022-06-23 07:25:38.474851
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """Unit tests for ``ansible.playbook.task_include.TaskInclude.preprocess_data`` method"""
    from ansible.playbook.task import Task
    from ansible.utils.sentinel import Sentinel

    # Prepare a minimal task with TaskInclude and Task class for test
    include_attrs = {'action': 'include_role', 'ignore_errors': True}
    task_data = {}
    task_data.update(include_attrs)
    task_data.update({'name': 'test_task'})

    task_obj = Task.load(task_data)
    include_obj = TaskInclude.load(task_data)

    # There is no difference between TaskInclude and Task object here
    assert include_obj == task_obj

    # Replace the task object for test with a dict
    task_data

# Generated at 2022-06-23 07:25:48.077752
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    ti = TaskInclude.load({
        'include_tasks': 'foo.yml',
        'include_vars': {'x': 'y', 'a': 'b'},
        'include_role': {'name': 'bar'},
        'include_role': 'bar',
    }, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-23 07:25:50.197003
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # pylint: disable=redefined-outer-name
    my_task = TaskInclude()

    assert my_task is not None


# Generated at 2022-06-23 07:26:02.363864
# Unit test for method copy of class TaskInclude

# Generated at 2022-06-23 07:26:10.332571
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    fake_ds = {
        'action': 'include',
        'args': {
            'a': 'a',
            'tags': [],
            'when': 'some_conditional',
        },
        'vars': {
            'b': 'b',
            'when': 'some_other_conditional',
        },
    }
    fake_block = Block()
    fake_parent_block = Block()
    fake_parent_block.vars = {
        'c': 'c',
        'when': 'yet_another_conditional',
    }
    fake_block.parent = fake_parent_block
    ti = TaskInclude.load(fake_ds, block=fake_block)
