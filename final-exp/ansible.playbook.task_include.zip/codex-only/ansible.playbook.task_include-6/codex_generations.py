

# Generated at 2022-06-23 07:16:20.576048
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    d1 = dict(action='include', file='included_tasks_file.yml')
    d2 = dict(action='include', file='included_tasks_file.yml')

    task1 = TaskInclude.load(d1)
    task2 = task1.copy()

    assert task2.action == task1.action
    assert task2.file == task1.file
    assert task2.static_include == task1.static_include

    task1 = TaskInclude.load(d1, static_include=False)
    task2 = task1.copy()

    assert task2.action == task1.action
    assert task2.file == task1.file
    assert task2.static_include == task1.static_include


# Generated at 2022-06-23 07:16:28.425157
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti != None
    assert ti._attributes == {}
    assert ti.action is None
    assert ti.args == {}
    assert ti.deprecated is None
    assert ti.block is None
    assert ti.always_run is False
    assert ti.changed_when is None
    assert ti.failed_when is None
    assert ti.delegate_to is None
    assert ti.loop is None
    assert ti.loop_args == {}
    assert ti.loop_control == {}
    assert ti.loop_with is None
    assert ti.name is None
    assert ti.notify is None
    assert ti.poll is None
    assert ti.register is None
    assert ti.retries == 0
    assert ti.run_once is False
    assert ti.sudo is None

# Generated at 2022-06-23 07:16:34.177693
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude()
    #TODO: need to add test data for this function.
    exception = None
    result = None
    try:
        result = task.load()
    except Exception as ex:
        exception = ex

    assert exception is None
    assert result is not None



# Generated at 2022-06-23 07:16:38.655497
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.action == 'meta'
    assert not ti.name
    assert not ti.vars
    assert not ti.file
    assert not ti.block
    assert not ti.play
    assert not ti.role
    assert not ti.task_include

# Generated at 2022-06-23 07:16:47.973435
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # Correct data
    data = {'action': 'include', 'file': 'roles/foo/tasks/main.yml', 'debugger': None}
    task.check_options(task.load_data(data), data)

    # Bad type for apply
    data = {'action': 'include', 'file': 'roles/foo/tasks/main.yml', 'apply': 'foobar'}
    try:
        task.check_options(task.load_data(data), data)
    except AnsibleParserError as e:
        assert "Expected a dict for apply but got <type 'str'>" in str(e)

    # apply for non-include tasks

# Generated at 2022-06-23 07:16:57.872611
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Testing with action 'include'
    action = 'include'
    data = {'foo': 'bar', 'action': action}
    ti = TaskInclude()
    result = ti.preprocess_data(data)
    assert 'foo' in result
    assert 'bar' == result['foo']
    assert 'action' in result
    assert action == result['action']

    # Testing with action 'include_tasks'
    action = 'include_tasks'
    data = {'foo': 'bar', 'action': action}
    ti = TaskInclude()
    result = ti.preprocess_data(data)
    assert 'foo' not in result
    assert 'action' in result
    assert action == result['action']

    # Testing with action 'include_role'
    action = 'include_role'

# Generated at 2022-06-23 07:17:03.555259
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import become_loader, callback_loader, connection_loader, inventory_loader, lookup_loader
    from ansible.module_utils.legacy import is_executable, get_exception, get_all_subclasses
    from ansible.module_utils.common.collections import ImmutableDict
    from collections import namedtuple

    # noinspection PyUn

# Generated at 2022-06-23 07:17:05.427427
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.action == "include"
    assert not ti.statically_loaded


# Generated at 2022-06-23 07:17:17.365612
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    ds = {'action': 'include_role', 'name': 'myrole', 'tags': ['mytag']}
    p = Play.load(ds, variable_manager=None, loader=None)
    assert len(p.get_roles()) == 0

    ds = {'action': 'include_role', 'name': 'myrole', 'tags': ['mytag'], 'badattr': 'badattr'}
    try:
        p = Play.load(ds, variable_manager=None, loader=None)
        assert False
    except AnsibleParserError:
        assert True


# Generated at 2022-06-23 07:17:30.119208
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    include_ds = dict(
        include='xyz.yml',
        loop='{{ range(start, end) }}',
        include_role='xyz',
        import_role='xyz',
        role='xyz',
        include_tasks='xyz.yml',
        import_tasks='xyz.yml',
        static='xyz.yml',
        meta='xyz.yml',
        import_playbook='xyz.yml',
        title='Preprocess Test',
    )
    include = TaskInclude()
    processed_ds = include.preprocess_data(include_ds)

    for keyword in TaskInclude.VALID_INCLUDE_KEYWORDS:
        if keyword == 'title':
            assert keyword in processed_ds
        else:
            assert keyword not in processed_

# Generated at 2022-06-23 07:17:41.531775
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # test that static imports are handled correctly
    task = TaskInclude()
    data = dict()
    task = task.check_options(task, data)

    # validate 'load' invalid args
    data = dict(file='/etc/foo.yml', other='stuff')
    try:
        task.check_options(task, data)
        raise Exception('check_options should have failed for "other=stuff"')
    except AnsibleParserError:
        pass

    # validate that apply is not supported for 'include_tasks'
    data = dict(file='/etc/foo.yml', apply='stuff')
    try:
        task.check_options(task, data)
        raise Exception('check_options should have failed for "apply"')
    except AnsibleParserError:
        pass



# Generated at 2022-06-23 07:17:50.057872
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText  # noqa
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(None)

    yaml_str = '''
    - include:
      action: include
      file: ./roles/foo/tasks/main.yml
      apply: {}
      '''
    playbook = yaml.load(yaml_str)
    i = playbook[0]
    task = TaskInclude.load(i)

    assert task.action == 'include'
    assert 'file' not in task.args
    assert task.args['_raw_params'] == './roles/foo/tasks/main.yml'
    assert task.apply == {}



# Generated at 2022-06-23 07:18:01.147077
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    file_path = '/dev/null'

    # check with valid parameters, should pass
    TaskInclude.load(
        {
            'action': 'include',
            'file': file_path,
        }
    )

    # check with valid parameters and some extra arguments, should pass
    TaskInclude.load(
        {
            'action': 'include',
            'file': file_path,
            'apply': {}
        }
    )

    # check with valid parameters and additional arguments for apply, should pass
    TaskInclude.load(
        {
            'action': 'include',
            'file': file_path,
            'apply': {
                'loop': []
            }
        }
    )

    # check with valid parameters and additional arguments for loop_control, should pass

# Generated at 2022-06-23 07:18:05.441078
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Check for constructor
    # Specify task_include
    ti = TaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-23 07:18:16.108971
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import yaml
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action = dict(module = 'debug', args = dict(msg = '{{test}}')))
        ]
    )

    include_source = dict(
        include = '{{ test }}.yml',
        test = 'host_vars/localhost'
    )

    host_vars_source = dict(
        test = "ok"
    )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)
    block = play.get_children()[0]
    task = block.get_children

# Generated at 2022-06-23 07:18:27.345941
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create a dict representation of a task that does not accept all attributes
    task_data_dict = {'debugger': 'on', 'tags': 'debug'}
    # Use TaskInclude to validate a 'role' task
    TaskInclude.load(task_data_dict, action='role')
    # Use TaskInclude to validate an 'import_role' task
    TaskInclude.load(task_data_dict, action='import_role')
    # Use TaskInclude to validate an 'include_role' task
    TaskInclude.load(task_data_dict, action='include_role')
    # Use TaskInclude to validate an 'include' task
    TaskInclude.load(task_data_dict, action='include')

# Generated at 2022-06-23 07:18:38.707026
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
        Test the method TaskInclude.build_parent_block
        | GIVEN |
        |  I have a TaskInclude instance where I have specified apply with empty block
        |  and the _parent attribute is the same as the apply's block attribute
        | WHEN  |
        |  I call the method build_parent_block
        | THEN  |
        |  the method returns a Block instance with an empty list in the "block" attribute
        |  and the _parent attribute set to the same as the Block's "block" attribute
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block


# Generated at 2022-06-23 07:18:39.866295
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-23 07:18:44.235684
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()

    task = task_include.load(
        data=dict(
            name='do something',
            action='include',
            args= dict(
                file='{{file_path}}'
            )
        ),
        loader=None,
        variable_manager=None,
    )

    assert task.name == 'do something'
    assert task.action == 'include'
    assert task.args['_raw_params'] == '{{file_path}}'



# Generated at 2022-06-23 07:18:45.885519
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert(task_include) is not None

# Generated at 2022-06-23 07:18:54.030189
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    import io
    import yaml

    def _gen_task(action, data):
        text = io.StringIO()
        text.write('- ' + action + ': ')
        yaml.dump(data, text)
        data = text.getvalue()
        task = TaskInclude.load(
            data=yaml.safe_load(data),
            block=None,
            role=None,
            task_include=None,
            variable_manager=None,
            loader=None)
        return task

    def _gen_tasks(action, data):
        if isinstance(data, dict):
            return _gen_task(action, data)

# Generated at 2022-06-23 07:19:02.291508
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    def assert_data_is_valid(ti, data, task_action='action'):
        '''
        Method for testing options validation using `TaskInclude.check_options` method.
        '''
        # test case (1): valid args with `action`
        task = TaskInclude.load(data, task_include=ti)
        assert(task.action == task_action)

        # test case (2): missing 'file' option
        data1 = data.copy()
        del data1['file']
        data2 = data.copy()
        del data2['_raw_params']

# Generated at 2022-06-23 07:19:10.950738
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class MockTaskInclude(TaskInclude):
        '''
        To test method preprocess_data of class TaskInclude we need to mock
        the set of valid include keywords. This MockTaskInclude replaces
        the set with a set of three mock keywords: 'action', '_raw_params'
        and 'apply' to match against the keywords that are set in the
        tests.
        '''
        VALID_INCLUDE_KEYWORDS = frozenset(('action', '_raw_params', 'apply'))


    ds = dict(action='include', _raw_params='test.yaml')
    mti = MockTaskInclude()
    ds = mti.preprocess_data(ds)
    assert ds == dict(action='include', _raw_params='test.yaml')

    ds = dict

# Generated at 2022-06-23 07:19:19.500497
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    display = Display()
    display.verbosity = 3

    def preprocess_data(ds):
        ti = TaskInclude()
        return ti.preprocess_data(ds)

    # TaskInclude inherits from Task, therefore a lot of TaskInclude's
    # preprocess_data is a port of Task's preprocess_data. We only test
    # TaskInclude's additions here.
    #
    # For example, TaskInclude should not allow unknown attributes. In addition,
    # for an include that results in roles that can have tasks, we have to allow
    # the 'apply' attribute. In this test we additionally verify that this is
    # the only attribute that is allowed for an include resulting in roles.
    #
    # See test_Task_preprocess_data to see more tests. Those tests are also
    # relevant for TaskInclude

# Generated at 2022-06-23 07:19:30.876889
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.playbook.play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude as TI

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = ansible.playbook.play.PlayContext()

    # make a fake block to use as parent
    fake_parent_block = Block()
    fake_parent_block._play = ansible.playbook.play.Play()
    fake_parent_block._play.playbook = os.path.join(os.path.dirname(__file__), '../../../test/playbooks/include_playbook.yml')
    fake_parent_block._play

# Generated at 2022-06-23 07:19:37.745469
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    This test checks if the constructor of TaskInclude works.
    '''

    block = Block()
    role = None
    task_include = None

    ti = TaskInclude(block=block, role=role, task_include=task_include)

    assert(isinstance(ti, TaskInclude))
    assert(isinstance(ti, Task))


# Generated at 2022-06-23 07:19:39.744660
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    field_attribute = FieldAttribute() # pylint: disable=unused-variable
    task_include = TaskInclude()

# Generated at 2022-06-23 07:19:50.914914
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # make a fake task to test the preprocess_data method on
    fake_task = TaskInclude()

    # make a fake loader to load data
    fake_loader = DataLoader()

    # make a fake inventory
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager())

    # make a fake variable manager
    fake_variable_manager = VariableManager()

    # make a fake role to test the preprocess_data method on
    fake_role = None

    # make a task that uses important parameters

# Generated at 2022-06-23 07:19:52.043988
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti=TaskInclude()
    assert ti is not None

# Generated at 2022-06-23 07:20:05.691911
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.task_include import TaskInclude
    data = {
             'file': '../tasks/main.yml',
             '_raw_params': '../tasks/main.yml',
             'apply': {'block': 'fakeblock'}
            }
    p_block = {}

    ti = TaskInclude()
    ti.load_data(data)
    ti._parent = p_block
    ti.statically_loaded = True

    new_ti = ti.copy()
    print(new_ti)
    assert(new_ti.action == 'include')
    assert(new_ti.args == ti.args)
    assert(new_ti._parent == p_block)
    assert(new_ti.statically_loaded == True)

# Generated at 2022-06-23 07:20:17.736918
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.plugins.action.include_role
    import ansible.plugins.action.include_tasks


# Generated at 2022-06-23 07:20:21.112117
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Test copy a statically_loaded TaskInclude (default)
    ti = TaskInclude()
    ti_copy = ti.copy()
    assert (ti_copy.statically_loaded is True)

    # Test copy a dynamically loaded TaskInclude
    ti.statically_loaded = False
    ti_copy = ti.copy()
    assert (ti_copy.statically_loaded is False)

# Generated at 2022-06-23 07:20:33.105098
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    display.verbosity = 3

    # Create a new playbook for the test (not needed for the method copy)
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()


# Generated at 2022-06-23 07:20:39.748081
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create a dummy task include to check if the "include" key is removed from the parameters
    task_include = TaskInclude()
    ds = dict()
    ds['action'] = 'include'
    ds['name'] = 'a_task'
    ds['include'] = 'an_include'
    res = task_include.preprocess_data(ds)
    assert res['include'] is None, 'TaskInclude.preprocess_data() should not keep "include" as a task parameter'

# Generated at 2022-06-23 07:20:44.959444
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()


# Generated at 2022-06-23 07:20:54.573060
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    task_include.action = 'include'
    data = {'action': 'include',
            'file': '/tmp/include.yml',
           }
    task_include.preprocess_data(data)

    task_include.action = 'import_playbook'
    data = {'action': 'import_playbook',
            'file': '/tmp/playbook.yml',
           }
    task_include.preprocess_data(data)

    task_include.action = 'import_tasks'
    data = {'action': 'import_tasks',
            'file': '/tmp/tasks.yml',
           }
    task_include.preprocess_data(data)

    task_include.action = 'include_role'

# Generated at 2022-06-23 07:21:01.969767
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import sys
    import pytest

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    loader = None
    variable_manager = None
    role = None

    # Use a dummy action name, since it does not matter for testing options
    action = 'test_action'

    # Test with no options
    data = {'action': action}
    task = TaskInclude.load(data, role=role, task_include=Task(), variable_manager=variable_manager, loader=loader)
    assert task.check_options(task, data) == task

    # Test with empty options
    data = {'action': action, 'args': {}}

# Generated at 2022-06-23 07:21:03.453907
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    pass

# Generated at 2022-06-23 07:21:14.771728
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from unittest.case import TestCase
    from ansible.playbook.playbook_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    class TestTaskInclude(TaskInclude):
        def __init__(self, action, args):
            super(TaskInclude, self).__init__(action=action)
            self._parent = PlayContext()
            self.args = args

    # test "include" action
    ti = TestTaskInclude(action='include', args={'file': 'foo.yml', 'apply': {}})
    ti = ti.check_options(ti, data={'action': 'include'})
    assert ti.args == {'_raw_params': 'foo.yml', 'apply': {}}
    # test other

# Generated at 2022-06-23 07:21:27.196842
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # 'include' task
    task = {
        'action': 'include',
        'args': {
            'file': 'file.yml',
            'apply': {'register': 'my_include_result'},
            'debugger': False,
        },
        'delegate_to': 'localhost',
    }
    context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    ti = TaskInclude.load(task, variable_manager=variable_manager, loader=loader)
    assert ti.name == 'include'
    assert ti.args['file'] == 'file.yml'

# Generated at 2022-06-23 07:21:36.819229
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # Create a dummy task. We have to set _parent because check_for_tasks
    # expects it.
    task = TaskInclude()
    task._parent = Block(task_include=task)
    task._variable_manager = VariableManager()
    task._loader = 'Some loader'
    task._role = RoleInclude()

    # Load a dictionary that resembles a simple play from a playbook
    play_dict = dict(
        include = "somefile",
        gather_facts = True
    )
    task.load_data(play_dict, variable_manager=task._variable_manager, loader=task._loader)

    # Now create the parent block
    p

# Generated at 2022-06-23 07:21:44.173129
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # python3 requires explicit type specification
    # this is the correct way to ensure that the task_include is added correctly
    test = TaskInclude(block=Block(), role=1, task_include=2)
    assert test.block == Block()
    assert test.role == 1
    assert test.task_include == 2
    assert test.statically_loaded == False

    # this is the incorrect way of adding task_include
    test2 = TaskInclude(task_include=1, block=Block())
    assert test2.task_include == None



# Generated at 2022-06-23 07:21:46.385021
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude()
    assert t is not None

# Generated at 2022-06-23 07:21:58.661029
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # tests error checks
    ta = TaskInclude.check_options(Task(), {'action': 'include', 'args': {'file': 'file_path'}})
    assert ta.args['file'] == ta.args['_raw_params']
    assert not ta.args.get('apply')

    # tests error checks with custom action
    ta = TaskInclude.check_options(Task(), {'action': 'custom_include', 'args': {'file': 'file_path'}})
    assert ta.args['file'] == ta.args['_raw_params']
    assert not ta.args.get('apply')

    # tests if 'args' is used

# Generated at 2022-06-23 07:22:11.446443
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Create test variables
    data = {
        'file': 'foo/bar.yaml',
        'no_log': True,
        'action': 'include',
        'ignore_errors': False,
        'apply': {'tags': ['baz', 'blah']},
        'name': 'test',
        'debugger': 'foo',
        'register': 'result',
    }
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # Call TaskInclude.load()

# Generated at 2022-06-23 07:22:19.543527
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    data = dict(
        include="a_file",
        ignore_errors=True,
    )
    # - import_role
    task = TaskInclude.load(data, task_include=HandlerTaskInclude())
    assert isinstance(task, Task)
    assert task.action == 'import_role'
    assert task.args.get('file') == 'a_file'
    assert task.args.get('ignore_errors')
    assert task.args.get('apply') is None

# Generated at 2022-06-23 07:22:30.295860
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    This method checks if 'check_options' method of class TaskInclude function as expected
    """
    # Test on TaskInclude
    ti = TaskInclude()

    fake_task = Task()
    fake_task.args = {
        '_raw_params': 'fake_file_name.yml',
        'ignore_errors': True
    }
    fake_task.action = 'fake_action'
    # check existing action with fake args
    task = ti.check_options(fake_task, {})
    assert task.args['_raw_params'] == 'fake_file_name.yml'
    assert task.args['ignore_errors'] is True
    assert not task.args.get('apply')
    assert task.action == 'fake_action'
    # check non-existing action with fake args
    fake

# Generated at 2022-06-23 07:22:41.924790
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Unit test to check the constructor of class TaskInclude
    '''
    ti = TaskInclude()

    assert(ti.BASE == frozenset(('file', '_raw_params')))
    assert(ti.OTHER_ARGS == frozenset(('apply',)))
    assert(ti.VALID_ARGS == ti.BASE.union(ti.OTHER_ARGS))
    assert(ti.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                        'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                        'when')))

# Generated at 2022-06-23 07:22:50.673277
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = Task()
    task.action = 'include'
    task.args = dict(
        include_tasks='test.yml',
        tree='abc',
        branch='develop',
        depth=7,
    )
    task.vars = dict(
        foo='bar',
        baz='qux',
    )
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    task._parent = Play()
    assert task.get_vars() == dict(
        foo='bar',
        baz='qux',
        include_tasks='test.yml',
        tree='abc',
        branch='develop',
        depth=7,
    )
    task.action = 'include_tasks'

# Generated at 2022-06-23 07:23:00.840818
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role import Role
    from ansible.template import Templar

    data = dict(
        action="myaction",
        file="filevar",
    )

    # Create a test role and a test block
    r = Role()
    r._role_path = "/some/nonexisting/path"
    b = Block()
    b._role = r
    b._play = r.get_default_play()
    b._variable_manager = Templar(variables=dict())

    # Load the data into TaskInclude and get the task out of it
    ti = TaskInclude(block=b)
    task = ti.check_options(ti.load_data(data), data)

    # Assert that Task has the expected values
    assert task.name == "myaction"

# Generated at 2022-06-23 07:23:11.344062
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    module = AnsibleModule()
    module.task_include = TaskInclude
    module.task_include.VALID_ARGS = set(('file',))
    module.task_include.VALID_INCLUDE_KEYWORDS = set(())
    module.load_data = lambda x, **kw: x
    module.check_options = lambda x, y: TaskInclude.check_options(x, y)
    module.task_include.check_options.__globals__ = module.__dict__

    # Check that bad arguments to - include: are reported
    args_set = {'foo': 'bar'}
    data = {'apply': 'foo'}

# Generated at 2022-06-23 07:23:20.517927
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    # Build the structure
    test_block = Block()
    test_block.max_retries = 0
    test_block._parent = test_block
    test_block._role = test_block

    test_task = Task()
    test_task._block = test_block

    test_include = TaskInclude()
    test_include.action = 'include'
    test_include._parent = test_task
    test_include._role = test_task

    # Test true condition for constructor
    res = test_include.copy()

# Generated at 2022-06-23 07:23:28.015194
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block as block
    from ansible.playbook.task_include import TaskInclude

    # Validate bad args
    with pytest.raises(AnsibleParserError) as excinfo:
        task = TaskInclude.check_options(TaskInclude(), {'action': 'include_role',
                                                         'apply': {'x': 'y'}})
    assert "Invalid options for include_role: apply" in str(excinfo.value)



# Generated at 2022-06-23 07:23:41.281712
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_block = Block()
    role = object()
    task_include = object()

    # pylint: disable=protected-access
    ti = TaskInclude(block=task_block, role=role, task_include=task_include)

    class MockVariableManager(object):

        def __init__(self):
            self._vars = {}

        def add_extra_vars(self, ext_vars):
            self._vars.update(ext_vars)

        def get_vars(self, loader=None, play=None, include_hostvars=True):
            return self._vars

    class MockLoader(object):

        def __init__(self):
            self._host_list = {}

        def load_from_file(self, path, cache=True):
            return self._host_

# Generated at 2022-06-23 07:23:47.901649
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ''' test TaskInclude.check_options '''
    import ansible.playbook.task_include
    ti = ansible.playbook.task_include.TaskInclude()

    # test with no options to include
    task = Task()
    task.args = {}
    expected_result = task
    actual_result = ti.check_options(task, {})
    assert(expected_result is actual_result)

    # test with an unknown option
    task.args = {'action': 'include', 'unknown_opt': 'bar'}
    expected_result = task
    actual_result = ti.check_options(task, {})
    assert(expected_result is actual_result)

    # test with file
    task.args = {'action': 'include', 'file': 'foo.yml'}
    expected_result

# Generated at 2022-06-23 07:23:58.434488
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = {}
    play_context = PlayContext(variables=variable_manager)

    data = """
    - name: task with action include
      include: foo.yml
    """

    expected_result = """
    - name: task with action include
      include: foo.yml
      {meta: {hostvars: {}}}
      apply: {}
    """

# Generated at 2022-06-23 07:24:06.729116
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Unit test for method get_vars of class TaskInclude
    '''
    from ansible.playbook.included_file import IncludedFile
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.template import Templar

    p = ModuleArgsParser(dict(a=1), None, 'a')
    i = IncludedFile()
    i._parent = object()
    i.action = 'include'
    i.args = dict(a=p, b=2)
    i.vars = dict(b=3, c=4)
    i.dep_chain = []
    loader = DataLoader()
    t = Templar(loader=loader)
    i._variable_manager = FieldAttribute(parent=[t])



# Generated at 2022-06-23 07:24:17.038672
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    data = dict(
        file='/path/to/include',
        action='include',
        _ansible_no_log=False,
        apply='apply',
        invalid_attr=True,
    )

    # Load data with invalid options, i.e. 'apply'
    try:
        TaskInclude.load(
            data,
            variable_manager=None,
            loader=None,
        )
    except AnsibleParserError:
        pass
    else:
        raise Exception('TaskInclude did not raise AnsibleParserError with invalid options.')

    # Load data with invalid option, i.e. 'invalid_attr'
    ti = Task

# Generated at 2022-06-23 07:24:23.330337
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # This is a simple test used for testing a single method
    data = {
        'action': 'include',
        'foo': 'bar',
        'forks': '5'
    }
    expected = {
        'action': 'include',
        'foo': 'bar'
    }
    ti = TaskInclude()
    actual = ti.preprocess_data(data)
    assert actual == expected

# Generated at 2022-06-23 07:24:27.008002
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.base import Base

    # Create a base
    base = Base()
    base._variable_manager = None
    base._loader = None

    # Create a play
    play = Play.load({}, variable_manager=base._variable_manager, loader=base._loader)

    # Create a role
    role = Role.load({}, variable_manager=base._variable_manager, loader=base._loader)

    # Create a block
    block = Block.load({}, play=play, task_include=None, role=role, variable_manager=base._variable_manager, loader=base._loader)

    # Create a

# Generated at 2022-06-23 07:24:35.260636
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    TaskInclude._validate_action= lambda self, attr: None
    with open('/tmp/test_TaskInclude_copy','w') as fp:
        fp.write('''
- hosts: all
  tasks:
    - include: /tmp/test_TaskInclude_copy_a
''')
    play = Play().load(loader=FileLoader(), variable_manager=VariableManager(), use_handlers=False, task_blocks=[
        {
            'block': [
                {
                    'action': 'include',
                    'file': '/tmp/test_TaskInclude_copy_a',
                }
            ]
        }
    ], play_context={
        'scenario': {
            'name': 'test_TaskInclude_copy'
        },
    })
    task_include = play.tasks

# Generated at 2022-06-23 07:24:39.296835
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    test loading via the constructor of TaskInclude
    '''

    from ansible.playbook.play_context import PlayContext

    args1 = dict(file="/foo/bar")
    task1 = TaskInclude(args=args1)
    assert task1.action == 'include'

    args2 = dict(file="/foo/bar/bam")
    task2 = TaskInclude(args=args2)
    assert task2.action == 'include'
    assert task2.args['_raw_params'] == "/foo/bar/bam"

    task3 = TaskInclude()
    assert task3.action == 'meta'



# Generated at 2022-06-23 07:24:42.909600
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    ds = {'action': 'include_role', 'name': 'foo'}
    ans = task.preprocess_data(ds)
    assert ans == ds
    assert ans is not ds

# Generated at 2022-06-23 07:24:51.245480
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play

    play = Play.load({
        'name': 'test',
        'hosts': 'all',
        'tasks': [
            {'include': 'include1.yml', 'apply': {'tags': ['tag1']}},
            {'include': 'include2.yml', 'apply': {'tags': ['tag2']}},
        ]
    }, variable_manager={}, loader=None)

    play.post_validate(play._ds, play)

    # Parent of first task is the play itself
    assert play._tasks[0]._parent == play

    # Parent of the second task is the first task (first task is a block)
    assert play._tasks[1]._parent == play._tasks[0]

    # Parent of the included tasks of the

# Generated at 2022-06-23 07:24:52.428159
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    pass

# Generated at 2022-06-23 07:24:59.529515
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create trigger
    block = Block()

    # Create apply section
    apply = {}
    apply['block'] = []
    apply_block = Block.load(
        apply,
        play=block,
        task_include=None,
        role=None,
        variable_manager=None,
        loader=None,
    )

    # Create task_include
    args = {}
    args['apply'] = apply_block
    p_block = TaskInclude.build_parent_block(args, block)
    assert p_block == apply_block


# Generated at 2022-06-23 07:25:11.995590
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a task include
    task_include = TaskInclude()

    # Set the action to include
    task_include.action = 'include'

    # Create a task to add to parameter "task_include" of constructor
    task = Task()
    # Add a key-value pair to the dict of attributes "vars" of task
    task.vars['tag'] = 'tag-value'
    # Set the action to include_role
    task.action = 'include_role'
    # Set the args of task:
    #   { 'tags': 'tag-name', 'apply': {'var': 'var-value'} }
    task.args = {'tags': 'tag-name', 'apply': {'var': 'var-value'}}

    # Create a task_included to add to the list of attributes "tasks" of

# Generated at 2022-06-23 07:25:23.146438
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Test the method load of class: TaskInclude

    """

    # Test the error raised when there are unknown arguments for an 'include' task
    # where the value of the option is a dict.
    data = {'action': 'include', 'unknown_option': {'test': 'test'}}
    with pytest.raises(AnsibleParserError, message='Error not raised for unknown argument'):
        TaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    # Test the error raised when there are unknown arguments for an 'include' task
    # where the value of the option is a str.
    data = {'action': 'include', 'unknown_option': 'test'}

# Generated at 2022-06-23 07:25:30.654280
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Given
    class TestTaskInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            # Mocks
            self.VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS.union(('new_keyword',))
            super(TestTaskInclude, self).__init__(*args, **kwargs)

    # When
    ti = TestTaskInclude()
    test_value = 'test value'
    data = {'action': 'test_include', 'new_keyword': test_value}
    ds = ti.preprocess_data(data)

    # Then
    assert ds['new_keyword'] == test_value



# Generated at 2022-06-23 07:25:42.907271
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Mock Task class to simulate TaskInclude class
    class TaskMock():
        def __init__(self):
            self.action = 'test_action'
            self.args = {}

    # Test valid options
    def test_valid_options(options, action, expected_result):
        task = TaskMock()
        task.args = options
        task.action = action
        result = TaskInclude.check_options(task, options)
        assert result.args == expected_result

    test_valid_options(dict(file='test'), 'include', dict(_raw_params='test'))
    test_valid_options(dict(file='test'), 'include_tasks', dict(_raw_params='test'))

# Generated at 2022-06-23 07:25:51.389962
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    ct = TaskInclude()
    ct._parent = Sentinel()
    ct._parent.get_vars = lambda: {'x': 100}
    ct.vars = {'y': 200}
    ct.action = 'include'
    ct.args = {'x': 1, 'y': 2}
    assert ct.get_vars() == {'x': 1, 'y': 2}

    ct.action = 'include_role'
    assert ct.get_vars() == {'x': 100, 'y': 200}

# Generated at 2022-06-23 07:26:03.033896
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display.verbosity = 3
    import pytest

    preprocess_data_data = {
        'include': 'all',
        'include_vars': 'all',
        'import_tasks': 'all',
        'import_role': 'all',
        'include_role': 'all',
        'include_tasks': 'all',
    }

    # Invalid task arguments
    with pytest.raises(AnsibleParserError) as ex:
        task = TaskInclude.load(
            {
                'name': 'include_example',
                'include_tasks': 'all',
                'foo': 'bar'
            }
        )
        task.preprocess_data(task.args)
    assert 'Invalid options for include_tasks: foo' in str(ex)

    # Invalid apply attributes

# Generated at 2022-06-23 07:26:03.939516
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    assert TaskInclude()

# Generated at 2022-06-23 07:26:15.155692
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data_dicts = {
        'action': 'import_playbook',
        'file': r'../tests/test_playbooks/subdir/default.yml',
        'include': 'this',
        'tags': 'these',
        'vars': {'key': 'val'},
    }

    ti = TaskInclude()
    ti.static = True
    ds = ti.preprocess_data(data_dicts)
    assert len(ds.keys()) == 3
    assert ds.get('action') == 'import_playbook'
    assert ds.get('file') == r'../tests/test_playbooks/subdir/default.yml'
    assert ds.get('vars') == {'key': 'val'}

    ti = TaskInclude()
    ti.static = False
