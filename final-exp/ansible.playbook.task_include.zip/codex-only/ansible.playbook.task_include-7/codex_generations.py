

# Generated at 2022-06-23 07:16:19.713252
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    # Include the args of the include into the vars as
    # they are params to the included tasks
    ti.args = {'test_arg': 'test_val'}
    ti.action = 'include'

    # test copy without excluding the parent
    new_ti = ti.copy(exclude_parent=False, exclude_tasks=False)
    assert new_ti.args == {'test_arg': 'test_val'}
    assert 'test_arg' in new_ti.get_vars()
    assert 'test_val' == new_ti.get_vars()['test_arg']
    assert not new_ti.get_parents()

    # test copy with excluding the parent
    new_ti = ti.copy(exclude_parent=True, exclude_tasks=False)


# Generated at 2022-06-23 07:16:27.721016
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # define task data
    data = dict(
        include='some_file_or_statement.yml',
        apply=dict(
            free_form='some_free_form_value',
        ),
        invalid_option=True
    )
    # invalid action is not really relevant for this test, just pick one from _ACTION_* constants
    data['action'] = C._ACTION_ADDITIONAL_INCLUDE_TASKS[0]
    task_data = {'name':'default_task_name'}
    for k in task_data:
        data[k] = task_data[k]

    # init task
    task_include = TaskInclude.load(data, task_include=True)

    # check options
    assert task_include.check_options(task_include, data) == task_include


# Generated at 2022-06-23 07:16:40.226854
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Check that TaskInclude.check_options works properly in following cases:
        - call with a valid action and valid option/value pairs for that action
            (only for valid options for that action)
        - call with an invalid action and valid option/value pairs for that action
            (only for valid options for that action)
        - call with an action and invalid option/value pairs for that action
            (only for invalid options for that action)
        - call with an action and valid and invalid option/value pairs for that action
            (for both valid and invalid options for that action)
    '''
    # Define an instance of class TaskInclude
    task_include = TaskInclude()
    
    # Define a valid action
    action1 = 'include_tasks'
    # Define a valid option/value pair for action1
    option1

# Generated at 2022-06-23 07:16:52.565479
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    '''
    For the following task:
        - block:
            - debug:
              msg: "This message should be printed."
          loop: "{{ big_loop }}"
          when: my_var == 1

    The expected result is:
        - debug:
            msg: "This message should be printed."
          when: my_var == 1

    '''

    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 07:16:57.746029
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()

    kwargs = {'foo': 'bar', 'whatevs': 'the_cat'}
    ds = task.preprocess_data(kwargs)

    if set(ds.keys()) != TaskInclude.VALID_INCLUDE_KEYWORDS | {'action'}:
        raise AssertionError('Valid keys are %s and action while the preprocessed data returns %s' % (TaskInclude.VALID_INCLUDE_KEYWORDS, ds.keys()))

# Generated at 2022-06-23 07:17:03.486368
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    play_context = PlayContext()

# Generated at 2022-06-23 07:17:14.657982
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    ti.args = {'_raw_params': 'some_file'}
    assert ti.check_options(ti, {}).args.get('_raw_params') == 'some_file'
    ti.args = {'_raw_params': 'some_file', 'apply': 'something'}
    assert ti.check_options(ti, {}).args.get('_raw_params') == 'some_file'
    assert ti.check_options(ti, {}).args.get('apply') == 'something'
    ti.args = {'apply': {}}
    assert ti.check_options(ti, {}).args.get('apply') == {}
    ti.action = 'include'
    ti.args = {'apply': {}}

# Generated at 2022-06-23 07:17:27.061418
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.statically_loaded = True
    ti._role = None
    ti._block = '''
    - name: foo
      shell: echo "hello"
    '''
    ti._parent = None

    # attributes
    ti._role = None
    ti.action = 'include'
    ti.args = {'_raw_params': './roles/redis/tasks/main.yml'}
    ti.block = frozenset()
    ti.block_args = {'when': 'True'}
    ti.block_name = None
    ti.deprecated_tags = frozenset()
    ti.default_vars = []
    ti.delegate_to = None
    ti.delegate_facts = None

# Generated at 2022-06-23 07:17:32.416399
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task1 = TaskInclude.load(
        {
            'action': 'include',
            'args': {
                'apply': {
                    'when': True
                }
            }
        }
    )
    parent_block = task1.build_parent_block()
    assert isinstance(parent_block, Block)


# Generated at 2022-06-23 07:17:33.645706
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TODO
    return

# Generated at 2022-06-23 07:17:44.854055
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    task = load_task_include(variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 07:17:52.248916
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.clean import strip_internal_keys


# Generated at 2022-06-23 07:18:02.550027
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook
    ds = {'action': 'include', 'file': 'somefile.yml'}
    ti = TaskInclude()
    task = ti.load(ds)
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'somefile.yml'
    assert not task.args.get('apply')
    assert task.statically_loaded is True
    assert task.block == None

    ds = {'action': 'include', 'file': 'somefile.yml', 'apply': {'module': 'register', 'args': {'foo': 'bar'}}}
    ti = TaskInclude()
    task = ti.load(ds)
    assert task.action == 'include'

# Generated at 2022-06-23 07:18:13.855385
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test invalid options
    data = {"action": "include",
            "_raw_params": "foobar.yml",
            "unknown_option": "ok"
            }
    try:
        TaskInclude.load(data, task_include=True)
    except AnsibleParserError as e:
        assert 'Invalid options for include' in str(e)

    # Test mandatory fields are given
    data = {"action": "include"}
    try:
        TaskInclude.load(data, task_include=True)
    except AnsibleParserError as e:
        assert 'No file specified for include' in str(e)

    # Test valid options
    data = {"action": "include",
            "_raw_params": "foobar.yml",
            "apply": {"name": "foobar"}
            }
    task = Task

# Generated at 2022-06-23 07:18:21.519347
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task1 = Task()
    task2 = Task()
    task3 = Task()

    task1.action = "testaction"
    task1.name = "testname"
    task1.args = {'_raw_params':"testrawparams"}
    task1.include_tasks.append(task2)
    task1.tags.append("testtag")
    task1.when.append("testwhen")
    task2.include_tasks.append(task3)
    task3.tags.append("testtag2")

    task4 = task1.copy()
    assert task4.statically_loaded == False
    assert task4.action == "testaction"
    assert task4.name == "testname"
    assert task4.args == {'_raw_params':"testrawparams"}
    assert task4

# Generated at 2022-06-23 07:18:27.831838
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    variables = {}
    loader = None

    data = {
        'include': '{{ playbook.yml }}'
    }

    task = TaskInclude.load(data, variable_manager=variables, loader=loader)
    assert task._role is None
    assert task.action == 'include'
    assert task._parent is None
    assert not task.statically_loaded
    assert task.args == {'_raw_params': '{{ playbook.yml }}'}

# Generated at 2022-06-23 07:18:38.955188
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict(
        action='include',
        file='test.yml',
    )
    task = task.check_options(task, data)
    assert task.action == data['action']
    assert task.args == dict(_raw_params=data['file'])

    data['debugger'] = 'test'
    task = task.check_options(task, data)
    assert task.action == data['action']
    assert task.args == dict(_raw_params=data['file'])
    assert task.debugger == 'test'

    data['apply'] = {'dummy': 'value'}
    task = task.check_options(task, data)
    assert task.action == data['action']

# Generated at 2022-06-23 07:18:48.354374
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Unit test for method get_vars of class TaskInclude
    '''
    t = Task()
    t.args = {'a': 2}
    t.action = 'include_role'
    t.vars = {'a': 1}
    t.static_vars = {'a': 0}

    assert t.get_vars() == {'a': 0, 'a': 1}

    t.action = 'import_role'
    assert t.get_vars() == {'a': 0, 'a': 1}

    t.action = 'include'
    assert t.get_vars() == {'a': 2}


# Generated at 2022-06-23 07:18:55.596780
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class MockParentTask(object):
        pass

    class MockPlay(object):
        pass

    class MockBlock(object):
        pass

    class MockRole(object):
        pass

    class MockVariableManager(object):
        pass

    class MockLoader(object):
        pass

    data = dict(
        apply=dict(
            block=[]
        ),
        tags=['tag1', 'tag2'],
        vars=dict(
            name='var_name',
            value=dict(
                v1='v1',
                v2='v2'
            )
        ),
        when='1 == 2',
    )

    # Scenario 1 => action in ACTION_INCLUDE_IMPORT_TASKS

# Generated at 2022-06-23 07:18:59.089624
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # noop since it is tested in Task
    pass

# Generated at 2022-06-23 07:19:08.918032
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Test case for TaskInclude's copy method
    '''
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    # prepare VariableManager, PlayContext, DataLoader and Play
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_source = dict(
        name='TestPlay',
        hosts='localhost',
        gather_facts='no',
    )
    play = Play.load(play_source, loader=loader, variable_manager=variable_manager, loader=loader)
    # update action_loader to mock action plugin


# Generated at 2022-06-23 07:19:18.414404
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    """
    Constructor for TaskInclude class should initialize
    the members with all the given parameters.
    """
    playbook_entry = dict(
        include_role=dict(
            name='foo.bar',
            tasks_from='default'
        )
    )

    block = None
    role = "foo.bar"
    t = TaskInclude.load(playbook_entry, block=block, role=role)

    assert t._parent == block
    assert t._role == role
    assert t.name == "foo.bar"
    assert t.statically_loaded == False
    assert t.action == "include_role"
    assert t.args == dict(name='foo.bar', tasks_from='default')
    assert t.vars == dict()
    assert t.any_errors_fatal is False

# Generated at 2022-06-23 07:19:29.930416
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # NOTE: has to use task with play instead of TaskInclude for testing the preprocess_data method
    test_task = Task(name='test_task')

    # validate_conditional return True when no conditional is set or
    # the conditional is valid. So we need to set an invalid conditional
    # and check that validate_conditional returns false
    test_task.when = 'foo'
    assert not test_task.validate_conditional()

    # Set action, no_log and retries should not be valid keywords and
    # should be deleted in preprocess_data
    test_task.no_log = True
    test_task.retries = 2
    test_task.action = 'copy'
    test_task.preprocess_

# Generated at 2022-06-23 07:19:42.735478
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play

    # Every test consists of an input dictionary of key-values with the
    # expected output as the last value in the dictionary.
    # The input to the method is the first value in the dictionary
    # The expected output is the second value in the dictionary
    # The following variables are needed to test this method
    # 'task_action' - Whether the task is an action plugin or an include plugin
    # 'task_role' - Whether the task is in a role or a play.
    # 'parent_vars' - Additional variables in the parent task
    # 'task_vars' - Variables in the task under test
    # 'args' - Variables passed as args to the task under test

# Generated at 2022-06-23 07:19:43.900848
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.__class__.__name__ == 'TaskInclude'

# Generated at 2022-06-23 07:19:53.915972
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import pytest

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def create_task(task_attrs):
        task_attrs = dict(task_attrs)
        action = task_attrs.pop('action')
        loader = DataLoader()
        variable_manager = VariableManager(loader=loader)
        inventory = InventoryManager(loader=loader, sources=[])
        playbook = dict(
            hosts='all',
            gather_facts='no',
            tasks=[task_attrs]
        )

        block = Block.load(playbook, play=playbook, variable_manager=variable_manager, loader=loader, inventory=inventory)

# Generated at 2022-06-23 07:20:06.649454
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.task_include import TaskInclude

    # All options valid
    data = {'foo': 'bar'}
    options = TaskInclude.check_options({'args': data}, data)
    assert options == {'args': data}
    assert type(options['args']) is AnsibleMapping


    # No raw_params
    data = {'foo': 'bar'}
    try:
        TaskInclude.check_options({'args': data}, data)
        assert False
    except AnsibleParserError:
        pass

    # Bad args
    data = {'foo': 'bar'}

# Generated at 2022-06-23 07:20:08.607292
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This is a test method for method build_parent_block of class TaskInclude
    '''
    # FIXME: implement method test_TaskInclude_build_parent_block
    assert True

# Generated at 2022-06-23 07:20:18.194701
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Fixture no args
    task_include_src = TaskInclude()
    task_include_dst = task_include_src.copy()

    # Test no args
    task_include_dst.build_parent_block()
    assert task_include_dst.args == {}

    # Fixture with args
    task_include_src = TaskInclude()
    task_include_src.args = {'apply': {'block': []}}
    task_include_dst = task_include_src.copy()

    # Test with args
    task_include_dst.build_parent_block()
    assert task_include_dst.args == {}



# Generated at 2022-06-23 07:20:31.489089
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test to load some data and apply_attrs. Check if method build_parent_block returns
    the correct parent block.
    """
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlayContext

    playbook = '''
    - hosts: all
      tasks:
        - name: include role
          include_role:
              name: included
              apply:
                    loop: "{{ include_loop }}"
    '''

# Generated at 2022-06-23 07:20:39.705097
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Given a task include T
    T = TaskInclude()
    T.action = 'include'
    T.args = {'file': 'foo.yaml'}
    T.statically_loaded = True
    # Test if 'exclude_parent' and 'exclude_tasks' does not change the result
    # When copying T
    new_t = T.copy(exclude_parent=True, exclude_tasks=True)
    # Then the copy T' should have the same action
    assert not new_t.action == T.action
    # And the same args
    assert not new_t.args == T.args
    # And the same statically_loaded
    assert not new_t.statically_loaded == T.statically_loaded

# Generated at 2022-06-23 07:20:41.779628
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Test for checking of empty arg list
    assert TaskInclude()._validate_args() == False

# Generated at 2022-06-23 07:20:46.374186
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.verbosity = 3

    def check_options_from_dict(ti_obj, task_dict):
        task_dict_copy = task_dict.copy()
        task_dict_copy.pop('block', None)
        task_obj = Task.load(task_dict_copy, block=None, role=None, task_include=None, variable_manager=None, loader=None)
        task_obj.action = task_dict.get('action', '')
        return ti_obj.check_options(task_obj, task_dict)

    def check_options_from_str(ti_obj, task_str):
        task_str_copy = task_str.copy()
        task_str_copy.pop('block', None)

# Generated at 2022-06-23 07:20:47.151702
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    TaskInclude()

# Generated at 2022-06-23 07:20:55.945226
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    """test_TaskInclude_copy"""
    def _test_setattr_copy(attr, value):
        task = TaskInclude()
        setattr(task, attr, value)
        task_copied = task.copy()
        assert getattr(task, attr) == getattr(task_copied, attr)

    for attr in TaskInclude.__slots__:
        _test_setattr_copy(attr, 'foo')

    task = TaskInclude()
    task.set_loader(lambda: None)
    task.add_cleanup_task(lambda: None)
    task.add_cleanup_task(lambda: None)
    task.add_handler_task(lambda: None)
    task.add_handler_task(lambda: None)
    task_copied = task.copy()


# Generated at 2022-06-23 07:21:04.697282
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.action = 'test_action_1'
    ti.name = 'test_name_1'
    ti.statically_loaded = True
    ti.tags = ['test_tag_1']
    ti.when = 'test_whe_1'
    ti.args = {'test_arg_key_1': 'test_arg_value_1'}
    ti.notify = {'test_notify_key_1': ['test_notify_value_1']}
    ti.meta = {'test_meta_key_1': 'test_meta_value_1'}
    ti.local_action = 'test_local_action_1'
    ti.delegate_to = 'test_delegate_to_1'
    ti.poll = 0

# Generated at 2022-06-23 07:21:15.593608
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block

    block = Block([])
    task_include = None
    ti = TaskInclude(block, task_include)

    # Test bad options
    data = {
        'action': 'include',
        'file': 'test.yaml',
        'bad_opt': 'bad',
    }
    task = TaskInclude.load(data, block)
    with pytest.raises(AnsibleParserError) as exc:
        ti.check_options(task, data)
    assert 'Invalid options for include: bad_opt' in str(exc)

    # Test apply options
    data = {
        'action': 'include',
        'file': 'test.yaml',
        'apply': {
            'action': 'test',
        },
    }
    task = Task

# Generated at 2022-06-23 07:21:18.355322
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()

    assert(ti.statically_loaded == False)

# Generated at 2022-06-23 07:21:28.762879
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # Test that check_options() raises error on invalid options
    data = dict(action='include_tasks', invalid_option='invalid')
    with pytest.raises(AnsibleParserError):
        task.check_options(data, data)
    # Test that check_options() raises the right error message
    assert 'Invalid options for include_tasks' in str(task.check_options.__wrapped__.__code__.co_varnames)

    # Test that check_options() does not raise an error on valid options
    data = dict(action='include_tasks', file='file.yml')
    assert task.check_options(data, data) is data

    # Test that `apply` is only allowed for `include`

# Generated at 2022-06-23 07:21:35.435359
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test setup
    task_name = 'task_name'

    # Test load with static task include
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = {
        'tags': 'tag1',
        'vars': {'var1': 'value'},
    }

    # Compare
    all_vars = ti.get_vars()
    assert all_vars['var1'] == 'value'
    assert 'tags' not in all_vars
    assert 'when' not in all_vars

    # Test load with static task include and dynamic include
    ti = TaskInclude()
    ti.action = 'import_role'

# Generated at 2022-06-23 07:21:46.890542
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test TaskInclude.preprocess_data() method based on the following data structure:
    data_structure = dict(
        action='include_role',
        args=dict(
            role=dict(
                name='my-role',
            ),
            _raw_params='my-role',
        ),
    )
    '''
    from ansible.playbook.task_include import TaskInclude

    data_structure = dict(
        action='include_role',
        args=dict(
            role=dict(
                name='my-role',
            ),
            _raw_params='my-role',
        ),
    )

# Generated at 2022-06-23 07:21:58.932188
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    loader = DataLoader()
    block = Block()
    role = None

    # Invalid options for action 'include'
    task = TaskInclude(block=block, role=role)
    data = dict(
        action='include',
        ignore_errors=True,
        invalid_option=None,
    )
    try:
        task.check_options(task.load_data(data, variable_manager=variable_manager, loader=loader), data)
    except AnsibleParserError as e:
        assert 'Invalid options for include' in str(e)
        assert 'invalid_option' in str(e)

    # Invalid options for action 'import_playbook'


# Generated at 2022-06-23 07:22:04.773411
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict(when=None, name='test', no_log=True)

    fake_loader = dict(get_basedir=lambda x,y: None)
    fake_variable_manager = dict(extra_vars=dict(), host_vars=dict())
    task.load_data(data, variable_manager=fake_variable_manager, loader=fake_loader)

    task.check_options(
        task,
        data
    )



# Generated at 2022-06-23 07:22:14.485152
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'action': 'include', 'file': 'test.yml'}
    ti = TaskInclude()
    result = ti.preprocess_data(ds)
    assert(result == {'action':'include', 'file':'test.yml'})

    ds2 = {'action': 'include', 'name': 'test.yml'}
    result2 = ti.preprocess_data(ds2)
    assert(result2 == {'action':'include', 'name':'test.yml'})

    ds3 = {'action': 'include', 'file': 'test.yml', 'other': 'test'}
    result3 = ti.preprocess_data(ds3)

# Generated at 2022-06-23 07:22:27.675983
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_data = {
        'block': [
            {
                'block': [
                    {
                        'include_tasks': 'test_task.yml'
                    }
                ]
            }
        ]
    }

    data = dict(test_data)
    data['include_tasks'] = 'test_task.yml'
    task = TaskInclude.load(data)

    # Add task to the end of the block and ensure that is the case
    p_block = task.build_parent_block()
    assert p_block == task
    assert p_block._parent._parent._parent == p_block

    # Add task to the start of the block and ensure that is the case
    data['apply'] = dict()
    task = TaskInclude.load(data)
    p_block = task.build_parent

# Generated at 2022-06-23 07:22:40.498556
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    t = Task.load({
        'include': 'foo.yml'
    })

    p = Play.load({
        'hosts': 'all',
        'roles': [
            {'include': 'role.yml'}
        ],
        'tasks': [
            {'include': 'task.yml'}
        ],
        'pre_tasks': [
            {'include': 'pre.yml'},
        ],
        'post_tasks': [
            {'include': 'post.yml'}
        ],
    }, variable_manager=None, loader=None)


# Generated at 2022-06-23 07:22:52.744030
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block

    ti = TaskInclude()
    ti.action = 'include'
    ti.block = Block()
    ti.parent = Base()

    ds = dict(action='include', file='foo')
    assert 'action' in ds
    ds = ti.preprocess_data(ds)
    assert 'action' not in ds

    ds = dict(action='include_role', file='foo')
    assert 'file' in ds
    ds = ti.preprocess_data(ds)
    assert 'file' not in ds
    assert 'name' in ds

    ds = dict(action='include_role', file='foo', apply=dict())
    assert 'apply' in ds

# Generated at 2022-06-23 07:23:01.935529
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test method build_parent_block of class TaskInclude
    Test parameters:
        apply_attrs - Dictionary of arguments to 'apply' key
        expected_class - Expected class for parent_block
    Test cases:
        check TaskInclude._parent is None
        check apply_attrs is empty dict
        check apply_attrs is not empty dict
    '''
    test_cases = (
        {'apply_attrs': {}, 'expected_class': TaskInclude},
        {'apply_attrs': {'block': []}, 'expected_class': Block},
    )
    for test_case in test_cases:
        apply_attrs = test_case['apply_attrs']
        expected_class = test_case['expected_class']

        # create parent task with apply attributes
        parent_play = Fake

# Generated at 2022-06-23 07:23:15.572629
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # check_options: explicitly set options
    test_data = {
        'action': 'include',
        'file': 'filename.yml',
    }
    task._load_data(test_data, dict(), Sentinel(), Sentinel())
    task.check_options(task, test_data)
    assert task.args['file'] == 'filename.yml'
    assert task._raw_params == 'filename.yml'

    test_data = {
        'action': 'import_playbook',
        'file': 'filename.yml',
    }
    task._load_data(test_data, dict(), Sentinel(), Sentinel())
    task.check_options(task, test_data)
    assert task.args['file'] == 'filename.yml'

# Generated at 2022-06-23 07:23:28.062595
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.manager import InventoryManager

    opts = {'tags': ['tag1', 'tag2'],
            'connection': 'ssh',
            'forks': 6,
            'become': True,
            'become_method': 'sudo',
            'become_user': 'bob'
           }
    loader = None
    variable_manager = None

# Generated at 2022-06-23 07:23:41.286523
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # The goal of this unit test is to cover all the logic inside the check_options method.
    # To do this, we create several (TaskInclude) instances with different parameters.
    # Then we call the check_options method on them, and check if the method returns what we
    # expect.

    from ansible.playbook.task_include import HandlerTaskInclude
    from ansible.plugins import action_loader

    # 1. Create a TaskInclude object for the task include and check if check_options raise an error
    # if options are invalid
    ti = TaskInclude(task_include=None)

# Generated at 2022-06-23 07:23:48.845173
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    This method tests the loading of TaskInclude class,
    for several cases
    '''

    # load included task with basic attributes
    raw_task = dict(action='include', file='var_1')
    task = TaskInclude.load(raw_task)
    assert task.action == 'include'
    assert task.args['_raw_params'] == raw_task['file']

    # load included task with apply attribute
    raw_task = dict(action='include', file='var_1', apply='dict')
    task = TaskInclude.load(raw_task)
    assert task.action == 'include'
    assert task.args['_raw_params'] == raw_task['file']
    assert task.args['apply'] == raw_task['apply']

    # load included task with invalid attribute 'invalid'


# Generated at 2022-06-23 07:23:58.677765
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing.dataloader import DataLoader

    # Create a dummy task to use as a parent task
    parent_task = Task()
    parent_task._role = dict()
    parent_task.vars = dict()

    # Create the task that will be the subject of the test
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2, 'tags': 'tag'}
    task_include._parent = parent_task

    # Test the method get_vars
    assert task_include.get_vars() == dict(a=1, b=2, tags='tag')



# Generated at 2022-06-23 07:24:12.063299
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Import modules needed for these tests
    import ansible.playbook
    import ansible.playbook.attribute
    import ansible.playbook.base
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.task

    test_dict = {'action': 'include','apply': {'tags': 'preinstall,install,postinstall'}}

    test_task = TaskInclude.load(test_dict, block=None, role=None, task_include=None)
    assert test_task._parent == None
    assert test_task._role == None
    assert test_task.action == 'include'
    assert test_task.vars == {}

# Generated at 2022-06-23 07:24:23.793379
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import TaskInclude
    import pytest
    import yaml

    # Create a dictionary to mock a valid yaml play

# Generated at 2022-06-23 07:24:26.474096
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude(block=Block())
    ti.statically_loaded = True
    new_me = ti.copy()
    assert new_me.statically_loaded == True


# Generated at 2022-06-23 07:24:30.485202
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    pass


# Generated at 2022-06-23 07:24:38.686044
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Static load
    ti = TaskInclude()
    ti.load({'action': 'include', 'file': 'test.yaml'})

    # Dynamic load
    ti = TaskInclude()
    ti.load({'action': 'include_tasks', 'file': 'test.yaml'})

    ti = TaskInclude()
    ti.load({'action': 'include_role', 'file': 'test.yaml'})

# Generated at 2022-06-23 07:24:42.704882
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    """ Unit test for method copy of class TaskInclude """
    test_instance = TaskInclude()
    test_instance.statically_loaded = True

    copied_instance = test_instance.copy()

    assert test_instance.statically_loaded == copied_instance.statically_loaded

# Generated at 2022-06-23 07:24:51.173431
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Scenario 1: "include" with "args" and "apply"
    scenario1 = {
        'action': 'include',
        'args': {
            'a': 'A',
            'b': 'B',
            'apply': {
                'b': 'B1',
                'c': 'C'
            },
        }
    }
    ti = TaskInclude.load(scenario1)
    assert ti.get_vars() == {'a': 'A', 'b': 'B', 'c': 'C'}

    # Scenario 2: "import_role" with "apply"

# Generated at 2022-06-23 07:25:00.738578
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    class TaskIncludeTest(TaskInclude):

        VALID_ARGS = TaskInclude.VALID_ARGS.union(frozenset(("valid_arg",)))

    ti = TaskIncludeTest()

    def _get_task_with_args(args):
        return TaskIncludeTest.load(
            {
                "include": "includetest.yml",
                "args": args,
            },
        )

    # no args
    t = _get_task_with_args({})
    t = ti.check_options(t, data={})
    assert t.args == {"_raw_params": "includetest.yml"}

    # unknown keyword
    t = _get_task_with_args({"unknown_keyword": "value"})

# Generated at 2022-06-23 07:25:03.094485
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play  # Prevent circular import

# Generated at 2022-06-23 07:25:14.094014
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test case to check the creation of parent block
    """
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    # Creation of task object with apply key
    args = dict(apply=dict(block=[]))
    apply_block = Block(play=Play().load({'hosts': 'all', 'name': 'test', 'connection': 'local'}), task_include=None)
    parent_block = TaskInclude(block=apply_block).build_parent_block()

    # The result of build_parent_block is a Block object
    assert isinstance(parent_block, Block), "TaskInclude.build_parent_block() returns an object of type Block"

    # Creation of task object with apply key

# Generated at 2022-06-23 07:25:26.888586
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible import constants as C
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars

    pb = TaskInclude()
    pb._task = 'include'
    pb._play = PlayContext()
    pb._variable_manager = PlayContext()
    pb._loader = PlayContext()
    pb._block = Block()
    pb._role = PlayContext()
    pb.args = {'_raw_params': 'test/test_pb_include.yml', 'apply': {}}
    pb.DS = {'apply': {}}
    pb.action = 'set_fact'
    pb.vars = HostV

# Generated at 2022-06-23 07:25:38.814348
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext

    block1 = Block()
    block1._play = {'vars': {'debug': 'yes', 'login_user': 'mdehaan'},
                    'hosts': {'web': {'vars': {'group_debug': 'yes'}},
                              'db': {'vars': {}}},
                    'any_errors_fatal': 'yes',
                    'max_fail_pct': '10',
                    'gather_facts': 'no',
                    'gather_subset': ['a', 'b']}


# Generated at 2022-06-23 07:25:48.292559
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Replace Ansible display
    global display
    display = Display()

    # Create a TaskInclude() without action 'include'
    data = dict()
    data['action'] = 'include_role'
    data['vars'] = dict(one=1)
    data['args'] = dict(two=2.0)
    data['when'] = ['test1', 'test2']
    task_include = TaskInclude.load(data=data)
    # Verify get_vars
    all_vars = task_include.get_vars()
    assert len(all_vars) == 2
    assert all_vars['one'] == 1
    assert all_vars['two'] == 2.0

    # Create a TaskInclude() with action 'include'
    data['action'] = 'include'
    task_include

# Generated at 2022-06-23 07:25:59.228936
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Prepare for testing
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import State
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    v1 = VariableManager()
    v1.extra_vars = {'hosts': 'host1'}
    loader1 = DataLoader()

# Generated at 2022-06-23 07:26:08.859673
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include = TaskInclude(block=None, role=None, task_include=None)

    # Test include action
    task_include.action = 'include'
    task_include._parent = None
    task_include.vars = {}
    task_include.args = {'file': 'test_args'}

    returned_vars = task_include.get_vars()
    assert returned_vars == {'file': 'test_args'}

    # Test include_tasks action
    task_include.action = 'include_tasks'
    task_include._parent = None
    task_include.vars = {}
    task_include.args = {'file': 'test_args'}

    returned_vars = task_include.get_vars()
    assert returned_vars == {}

    #