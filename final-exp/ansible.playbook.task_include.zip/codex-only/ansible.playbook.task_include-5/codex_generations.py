

# Generated at 2022-06-23 07:16:17.532636
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # Test bad args - TaskInclude
    task = Task()
    task.action = 'include'
    task.args = {'file': 'test.yml'}
    task = ti.check_options(task, data=None)

    task.args = {'file': 'test.yml', 'apply': {}}
    task = ti.check_options(task, data=None)

    task.args = {'file': 'test.yml', 'apply': {}, 'debugger': 'on'}
    with pytest.raises(AnsibleParserError) as exc:
        task = ti.check_options(task, data=None)
    assert exc.value.message == "Invalid options for include: debugger"

    # Test bad args - HandlerTaskInclude

# Generated at 2022-06-23 07:16:27.850594
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unittest for TaskInclude method check_options
    '''
    task_include = TaskInclude()

    # Test values
    data = {
        'action': 'include_role',
        'file': 'some_path',
        'apply': {
            'block': 'some_block'
        },
        'extra': 'extra_val'
    }

    # Test 1: when action is one that allows 'apply'. Confirm the data is passed through
    task = Task()
    task.action = 'include_role'
    task.args = data
    output = task_include.check_options(task, data)
    assert task is output, \
        'TaskInclude.check_options() with action "include_role" failed. It should just return the passed task'

    # Test 2: when action is

# Generated at 2022-06-23 07:16:40.537250
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude.load({'action': 'include', 'args': {'free': 'form'}})
    assert task.get_vars() == {'free': 'form'}

    task = TaskInclude.load({'action': 'import_tasks', 'args': {'free': 'form'}})
    assert task.get_vars() == {}

    task_with_apply = TaskInclude.load(
        {
            'action': 'include',
            'args': {
                'free': 'form',
                'apply': {
                    'free': 'form',
                    'loop': ['a', 'b'],
                },
            }
        }
    )
    assert task_with_apply.get_vars() == {'free': 'form'}
    assert task_with_apply.apply

# Generated at 2022-06-23 07:16:50.789062
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = Block()
    task = TaskInclude(block=block)
    task.args = dict(apply=dict(when='some condition'))
    result = task.build_parent_block()
    assert isinstance(result, Block)
    assert result.get_dep_chain() == [block, result], 'The parent block of the task should be the Block.load result'
    assert result.when == 'some condition', 'The new Block has to have the apply:when as its when'
    assert result._dep_chain == [block, result]
    assert result.get_dep_chain() == [block, result]


# Generated at 2022-06-23 07:16:59.357940
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import yaml
    yaml_str = u"""
- include: whatever.yaml
  apply:
    block:
    - include: task.yaml
"""
    data = yaml.safe_load(yaml_str)
    task = TaskInclude.load(data)

    assert len(task._parent._block) == 1
    assert task._parent._block[0].action == 'include'
    assert task._parent._block[0].args == {'_raw_params': 'task.yaml'}


# Generated at 2022-06-23 07:17:10.369894
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    obj = AnsibleUnicode('test')
    obj.__dict__ = { 'action': 'include', '_line_number': 1, '_name': 'test'}
    ti = TaskInclude()
    ds = {'name': 'me', 'action': 'include', '_line_number': 1, '_name': 'test'}
    ds2 = {'name': 'me', 'action': 'import_playbook', '_line_number': 1, '_name': 'test'}
    ti.preprocess_data(ds)
    # If valid keyword is used, it should not raise an error
    print(ds)

# Generated at 2022-06-23 07:17:22.685871
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    mock_variable_manager = dict()
    mock_loader = dict()
    ti = TaskInclude.load(
        dict(action='include',
             file='playbook.yml'),
        variable_manager=mock_variable_manager,
        loader=mock_loader
    )
    assert ti._task_include is None
    assert ti._role == None
    assert ti._block is None
    assert ti.action == 'include'
    assert ti.file == 'playbook.yml'
    assert ti._raw_params == 'playbook.yml'
    assert ti.when is None
    assert ti.register is False
    assert ti.ignore_errors is False
    assert ti.delegate_to is None
    assert ti.notify is None
    assert ti.first_available_file is None
    assert ti.local

# Generated at 2022-06-23 07:17:33.959817
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    assert isinstance(ti, Task)
    assert isinstance(ti, TaskInclude)
    my_data = {
        'include': 'test_file.yml',
        'when': 'ansible_os_family == "Debian"'
    }
    res = ti.preprocess_data(my_data)
    assert res is not None
    assert isinstance(res, dict)
    assert 'include' in res
    assert 'when' in res
    assert 'static' not in res
    assert 'tasks' not in res
    assert 'handlers' not in res

    my_data = {
        'import_tasks': 'test_file.yml',
        'when': 'ansible_os_family == "Debian"'
    }
    res = ti.preprocess_data

# Generated at 2022-06-23 07:17:45.128645
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # import here to prevent a circular import
    from ansible.playbook.task_include import TaskInclude

    # build a TaskInclude object to test
    task = TaskInclude()
    task.action = 'include'
    task.args = {'file': 'my_file'}

    # conditions
    task_data = task.check_options(task, None)
    assert task_data.args['_raw_params'] == 'my_file'
    assert 'file' not in task_data.args

    task.args = {'file': 'my_file', 'apply': {'a': 1, 'b': 2}}
    task_data = task.check_options(task, None)
    assert task_data.args['_raw_params'] == 'my_file'

# Generated at 2022-06-23 07:17:51.770545
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    test_task = TaskInclude()
    # test valid actions
    actions = C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    # test invalid actions
    actions.append('foobarbaz')
    # test valid options
    options = TaskInclude.VALID_ARGS
    # test invalid options
    options.append('foobarbaz')

    test_data = dict()
    for action in actions:
        test_task.action = action
        for opt in options:
            test_task.args = dict()
            test_task.args[opt] = 'foobarbaz'
            test_data['action'] = action
            test_data['args'] = dict()
            test_data['args'][opt] = 'foobarbaz'


# Generated at 2022-06-23 07:18:02.474710
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play


# Generated at 2022-06-23 07:18:13.804931
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    dataset = {
        'action': 'include_role',
        'file': 'some role',
        'when': "False",
        'foobar': 'baz',
        'apply': Sentinel
    }
    block = Block(play=None)
    task = TaskInclude(block=block)
    new_dataset = task.preprocess_data(dataset)

    assert "foobar" not in new_dataset
    assert new_dataset.get('apply') is Sentinel

    block = Block(play=None)
    task = TaskInclude(block=block)
    new_dat

# Generated at 2022-06-23 07:18:19.342584
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    task_include = TaskInclude()
    import sys
    import ansible.playbook.task_include

    assert 'ansible.playbook.task_include' == sys.modules['ansible.playbook.task_include'].__name__

    assert task_include.statically_loaded == False

    ti = TaskInclude()
    ti.statically_loaded = False

    task_include2 = TaskInclude(task_include=ti)
    assert task_include2.statically_loaded == False


# Generated at 2022-06-23 07:18:30.491507
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import json
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    def _create_task(data):
        ds = json.dumps(data)
        task = Task.load(
            ds,
            block=block,
            role=role,
            task_include=task_include,
            variable_manager=variable_manager,
            loader=loader,
        )
        return task

    def _create_block(data, play=None):
        ds = json.dumps(data)

# Generated at 2022-06-23 07:18:40.688474
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    role = None
    task_include = None
    block = Block(task_include=task_include)
    task = TaskInclude(block=block, role=role, task_include=task_include)

    task.vars = dict(k1="v1", k2="v2")
    task.action = "import_tasks"

    task.args = dict(action="import_tasks")
    vars_1 = task.get_vars()

    # _parent.get_vars() has no effect when task.action is "import_tasks"
    vars_1_expect = dict(k1="v1", k2="v2", action="import_tasks")
    assert vars_1 == vars_1_expect

    task.args = dict(action="include_role")
    v

# Generated at 2022-06-23 07:18:50.814503
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    def _data():
        return dict(
            # test with all options
            action = 'include',
            args = dict(
                file = '/path/to/include/file',
                apply = dict(tags = ['test-tag'])
            ),
            name = 'test include block',
            tags = ['test-tag'],
            ignore_errors = True,
            when = 'test == "test"'
        )

    def _assert(ti):
        assert isinstance(ti, TaskInclude)
        assert ti.action == 'include'
        assert ti.statically_loaded is False
        assert ti.args['_raw_params'] == '/path/to/include/file'
        assert isinstance(ti.args['apply'], Block)
        assert ti.name == 'test include block'

# Generated at 2022-06-23 07:19:00.942619
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This test case checks the output of TaskInclude.get_vars()
    '''
    # Mocks
    class MockVariableManager(object):
        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=False):
            return dict(hostvars=dict(somevar='somevalue'))

    class MockTask(object):
        def __init__(self, vars=None):
            self.vars = vars

        def get_vars(self):
            return dict(taskvars=dict(somevar='somevalue', someothervar='someothervalue'))

    class MockTaskInclude(TaskInclude):
        def __init__(self, args=None, vars=None):
            self.args = args

# Generated at 2022-06-23 07:19:07.576793
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data = dict(action='include', file='foo.yml')
    task = task.check_options(task.load_data(data), data)
    assert 'file' not in task.args
    assert task.args['_raw_params'] == 'foo.yml'
    data = dict(action='include', _raw_params='foo.yml')
    task = task.check_options(task.load_data(data), data)
    assert 'file' not in task.args
    assert task.args['_raw_params'] == 'foo.yml'
    data = dict(action='import_playbook', file='foo.yml')
    task = task.check_options(task.load_data(data), data)

# Generated at 2022-06-23 07:19:17.152509
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    class ParentTestClass(object):
        def __init__(self):
            self.name = 'parent name'

    task = TaskInclude()
    task.statically_loaded = True
    task.args = {'1': '1'}
    task.action = 'include_role'
    task.vars = {'2': '2'}
    task._parent = ParentTestClass()

    copy_task = task.copy()

    assert task.statically_loaded == copy_task.statically_loaded
    assert task.args == copy_task.args
    assert task.action == copy_task.action
    assert task.vars == copy_task.vars
    assert task._parent != copy_task._parent

# Generated at 2022-06-23 07:19:28.753015
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    host1 = "host1.example.org"
    t_file = "some/path/file.yml"
    ds1 = {'action': 'include', 'file': t_file}

    ti = TaskInclude(task_include=None)
    ti.action = 'include'
    ti.args = {'file': t_file}
    ti.action = 'include'
    ti.statically_loaded = True
    ti.block = Block()

    ti.block.vars.update(ds1)
    ti.block.vars.update({'loop': '{{ example_list }}'})
    ti.block.loop_with = 'items'

    t = ti.copy()

# Generated at 2022-06-23 07:19:41.578848
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    attrs = dict()
    task = TaskInclude()
    for k in task.VALID_ARGS.union(task.VALID_INCLUDE_KEYWORDS):
        attrs[k] = None
    task = task.check_options(task.load_data(attrs), attrs)

    bad_opts = ['_', '__']
    for k in bad_opts:
        attrs[k] = None
    for t in C._ACTION_ALL_INCLUDE_TASKS:
        task = task.load_data(attrs, action=t)
        with testtools.ExpectedException(AnsibleParserError) as e:
            task = task.check_options(task, attrs)

# Generated at 2022-06-23 07:19:43.024758
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()



# Generated at 2022-06-23 07:19:45.291082
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    ti_new = ti.copy()
    assert ti_new.statically_loaded, 'Failed to copy the TaskInclude object'


# Generated at 2022-06-23 07:19:56.200154
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # for action `include`
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'var1': 'val1', 'var2': 'val2', 'ignore_errors':'yes'}
    task_include.vars = {}

    parent_task = Task()
    parent_task.args = {'var3': 'val3'}
    parent_task.vars = {'var4': 'val4'}

    task_include._parent = parent_task

    assert task_include.get_vars() == {'var1': 'val1', 'var2': 'val2', 'var3': 'val3', 'var4': 'val4'}

    # for action `import_tasks`
    # we test this action to make sure it doesn't

# Generated at 2022-06-23 07:20:07.493582
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude

    # test bad options
    ti = TaskInclude()
    ti.args = dict(useless_option='value', file='include_tasks/all.yml')
    data = dict(useless_option='value', file='include_tasks/all.yml')
    task = ti.check_options(ti, data)
    assert task.args['_raw_params'] == 'include_tasks/all.yml'
    assert task.args.get('useless_option') is None

    # test apply in import_tasks
    ti = TaskInclude()
    ti.args = dict(apply='value', file='include_tasks/all.yml', action='import_tasks')

# Generated at 2022-06-23 07:20:18.814769
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class TestTaskInclude(TaskInclude):
        VALID_INCLUDE_KEYWORDS = frozenset(('action', 'collection', 'name'))

    ti = TestTaskInclude()
    # Test 'include' task
    ds = ti.preprocess_data({
        'action': 'include',
        'collection': 'my.collection',
        'name': 'myTaskName',
        'invalid_kw': 'invalid_kw',
        'tags': 'tags',
        'when': 'when',
    })
    assert 'invalid_kw' not in ds
    assert 'tags' not in ds
    assert 'when' not in ds

    # Test 'include_role' task

# Generated at 2022-06-23 07:20:32.184644
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    def args_val(args):
        return [' '.join(a) for a in args.values() if a]

    # test what happens when file is missing
    ti = TaskInclude(block=None, role=None, task_include=None)
    for a in (ti.load_data({}, variable_manager=None, loader=None),
              ti.load_data({'action': 'include', 'something': 'else'}, variable_manager=None, loader=None)):
        assert a.args['_raw_params'] == ''
        assert a.args['file'] == '' and not a.args['something']

    # test with apply
    a = ti.load_data({'action': 'include', 'file': 'foo', 'apply': {'bar': 'baz'}}, variable_manager=None, loader=None)


# Generated at 2022-06-23 07:20:35.750201
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t1 = TaskInclude()
    t2 = t1.copy()
    assert t1.statically_loaded == t2.statically_loaded
    t2.statically_loaded = False
    assert t1.statically_loaded != t2.statically_loaded
    assert t1.statically_loaded

# Generated at 2022-06-23 07:20:42.752184
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    t = TaskInclude()
    t.action = 'include'
    attrs = dict(
        apply=dict(
            when=[
                'item.rc == 0',
                'item.rc == 1',
                'item.rc == 2',
                'item.rc == 3'
            ],
            with_items=[
                'foo', 'bar', 'quux'
            ]
        ),
        name='foobar'
    )
    for attr, value in attrs.items():
        t.args[attr] = value
    p_block = t.build_parent_block()
    assert 'apply' in p_block.vars, "apply should be in p_block.vars"
    assert p_block._parent is None, "p_block should be the parent block"
    assert p_block._play._

# Generated at 2022-06-23 07:20:53.331386
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Arrange
    ds = {'include': 'somewhere', 'apply': {'tags': ['a'], 'when': 'b'}}
    task = TaskInclude.load(ds)

    # Act
    p_block = task.build_parent_block()

    # Assert
    assert isinstance(p_block, Block)
    assert not isinstance(p_block, TaskInclude)
    assert task.action is p_block.block
    assert task._parent is p_block._parent
    assert task._role is p_block._role
    assert task._loader is p_block._loader
    assert task._variable_manager is p_block._variable_manager
    assert task._shared_loader_obj is p_block._shared_loader_obj
    assert task._play is p_block._play
    assert task._

# Generated at 2022-06-23 07:21:04.214354
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    play_context.update({
        'basedir': '/test',
        'role_path': 'test/test_roles/',
        'forks': 10,
        'tags': ['tag1', 'tag2'],
        'skip_tags': ['tag3', 'tag4'],
        'any_errors_fatal': True,
        'environment': dict(a=0, b=1),
    })

    # Happy path, a task include with only required parameters

# Generated at 2022-06-23 07:21:15.286951
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-23 07:21:27.653086
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.block import Block
    from ansible.utils.sentinel import Sentinel

    task_include = TaskInclude(block=Block())
    gt_example_data = AnsibleMapping(sentinel=Sentinel)
    gt_example_data.sentinel.prepend(['include', 'vars'])

    with pytest.raises(AnsibleParserError):
        task_include.check_options(Task(), gt_example_data)

    gt_example_data.sentinel.pop()
    gt_example_data.sentinel.pop()
    gt_example_data.sentinel.prepend(['include_role', 'vars'])

# Generated at 2022-06-23 07:21:34.570465
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    custom_playbook_path = './test/test_playbooks/action_include'

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    play_context = PlayContext()

    # Test with action 'include'

# Generated at 2022-06-23 07:21:39.890719
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Defining a TaskInclude class that will be used in the next tests
    class MyTaskInclude(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(MyTaskInclude, self).__init__(block=block, role=role, task_include=task_include)
            self.action = 'include'

    # Test 1: no parent block and no parameters
    # Define the TaskInclude object
    ti1 = MyTaskInclude()
    # Define the variables of the block
    ti1.vars = {'a': 'A', 'b': 'B'}
    # Define the variables available to the TaskInclude object
    ti1.args = {'c': 'C', 'd': 'D'}

    # Check the variables returned by

# Generated at 2022-06-23 07:21:49.897267
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    p = Play.load(dict(
        name = "a play",
        hosts = "all",
        gather_facts = "no",
        roles = [dict(
            name = "test_role",
            tasks = [dict(
                action = "include",
                file = "some_file"
            )],
        )],
    ))

    plugin_loader = C.DEFAULT_PLUGIN_PATH_CONFIG
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task = p.get_

# Generated at 2022-06-23 07:22:00.781908
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook
    import ansible.playbook.block

    # Create play
    play_attrs = {
        'name': 'foo',
        'hosts': 'all',
        'gather_facts': 'no'
    }
    data = dict()
    data.update(play_attrs)
    play = ansible.playbook.Play().load(data, variable_manager=None, loader=None)

    # Create first block
    block_data = dict()
    block_data['block'] = list()
    block_data['name'] = "first block"
    block = ansible.playbook.block.Block().load(block_data, play=play, task_include=None, role=None, variable_manager=None, loader=None)

    # Create first task
    task_data = dict

# Generated at 2022-06-23 07:22:07.780505
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # init
    task = TaskInclude()
    task.action = 'include_tasks'
    task.args = {}
    my_context = PlayContext()
    templar = Templar(host='host_test_TaskInclude_preprocess_data', loader=None, shared_loader_obj=None, variables=my_context,
                      fail_on_undefined=C.DEFAULT_UNDEFINED_VAR_BEHAVIOR)
    task._templar = templar
    task._role = None
    task._loader = None
    task._block = None
    task._role = None
    task._variable_manager = None

    # test case 1: empty task
    data = {}
    assert task.pre

# Generated at 2022-06-23 07:22:15.963380
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Set up
    import ansible.playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='tests/unit/test_task_include_apply/ansible_hosts')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 07:22:28.727726
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_inc = TaskInclude()
    task_inc.action = 'include'
    task_inc.args = {'a': 1, 'b': 2}
    parent_task = Task()
    parent_task.vars = {'parent': 1}
    task_inc._parent = parent_task

    vars = task_inc.get_vars()
    assert 'parent' in vars
    assert 'a' in vars

    task_inc.action = 'include_tasks'
    vars = task_inc.get_vars()
    assert 'a' not in vars

    task_inc._parent = None
    task_inc.action = 'include'
    task_inc.vars = {'my_vars': 1}
    vars = task_inc.get_vars()

# Generated at 2022-06-23 07:22:41.249015
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    import os
    import sys

    old_sys_path = list(sys.path)
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    old_cwd = os.getcwd()
    os.chdir(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
    from ansible.plugins import unit_test
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Fake data for method load
    data = dict

# Generated at 2022-06-23 07:22:53.552929
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext

    loader = ansible.playbook.playbook.Playbook.loader
    variable_manager = ansible.playbook.playbook.Playbook.variable_manager

    play_context = PlayContext()
    task_include = TaskInclude()
    # Create a block object to be used as parent object
    block = Block()

    # Test with empty apply block
    data = dict(action ='include_role', apply=dict(block=[]))
    include_task = TaskInclude.load(data=data)
    include_task._parent=block
    parent_block = include_task.build_parent_block()
    assert parent_block is not block, 'parent block is not the same as the included block'

# Generated at 2022-06-23 07:22:58.952793
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.handler import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    hti = HandlerTaskInclude()
    data = {
        'include': 'file.inc',
        'action': 'include',
        'file': 'file.inc',
        'hosts': 'host',
        'name': 'task1',
        'tags': 'tags',
        'when': 'when',
        'vars': 'vars',
        'args': 'args'
    }

    # 1) Basic validation with just file name and action include
    task = ti.load(
        data=data,
        variable_manager=None,
        loader=None
    )
    ti.check_options(task, data)

# Generated at 2022-06-23 07:23:09.950688
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # initialize
    task_include = TaskInclude()

    # test case when self._parent is empty
    option = 'test_case_no_parent'
    # expected output
    expected_result = dict()
    # test
    task_include.args.update(option)
    task_include.vars.update(option)
    result = task_include.get_vars()
    assert result == expected_result, "Test failed with option %s" %option

    # test case when self._parent is not empty
    option = 'test_case_with_parent'
    # expected output
    expected_result = dict()
    expected_result.update(option)
    # test
    task_include._parent = TaskInclude()
    task_include._parent.vars.update(option)
    result = task_include.get

# Generated at 2022-06-23 07:23:20.123021
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = ti.check_options(
        ti.load_data('- include_tasks: tasks.yml'),
        '- include_tasks: tasks.yml'
    )

    assert '_raw_params' in task.args
    assert 'file' not in task.args

    task = ti.check_options(
        ti.load_data('- import_playbook: tasks.yml'),
        '- import_playbook: tasks.yml'
    )

    assert '_raw_params' in task.args
    assert 'file' not in task.args

    ti = TaskInclude()
    task = ti.check_options(
        ti.load_data('- include: tasks.yml'),
        '- include: tasks.yml'
    )

# Generated at 2022-06-23 07:23:30.868776
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for method build_parent_block
    '''
    c = TaskInclude()
    c.args = {
        'apply': {
            'task': {
                'args': 'my_args',
                'attr': 'my_attr',
            }
        },
    }
    c.vars = 'my_vars'
    c.action = 'my_action'
    c.role = 'my_role'
    c._variable_manager = 'my_variable_manager'
    c._loader = 'my_loader'
    c._parent = 'my_parent'
    p_block = c.build_parent_block()
    assert p_block.block == []
    assert len(p_block.args) == 2

# Generated at 2022-06-23 07:23:42.306019
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task

    pb = ansible.playbook.play.Play().load({'name': 'test play'})
    pb._loader = None
    pb._basedir = 'tests/lib/ansible/playbook'
    pb._variable_manager = ansible.playbook.play.VariableManager()
    pb._tqm = None

    task = {'when': 'test', 'include': 'some_file'}
    inc = ansible.playbook.task.TaskInclude(pb, role=None, task_include=None)
    task = inc.load(task)
    apply_block = task.build_parent_block()

# Generated at 2022-06-23 07:23:57.810790
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from units.mock.path import mock_unfrackpath_noop

    mock_unfrackpath_noop()
    ti = TaskInclude(block=None, role=None, task_include=None)
    task = {'action': 'include_tasks', 'args':{'apply':{}, 'file': 'test.test'}}
    task = ti.check_options(task, task)
    assert task['args'] == {'_raw_params': 'test.test'}

    hti = HandlerTaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-23 07:24:05.371980
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Unit test for constructor of class TaskInclude
    '''
    # Constructor test without any mandatory parameters
    my_taskinclude = TaskInclude()
    assert my_taskinclude
    assert my_taskinclude._parent == None
    assert my_taskinclude._role == None
    assert len(my_taskinclude._blocks) == 0

    # Constructor test without any optional parameters
    my_taskinclude = TaskInclude(block=None, role=None, task_include=None)
    assert my_taskinclude
    assert my_taskinclude._parent == None
    assert my_taskinclude._role == None
    assert my_taskinclude._task_include == None
    assert len(my_taskinclude._blocks) == 0

# Generated at 2022-06-23 07:24:06.235038
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    pass

# Generated at 2022-06-23 07:24:08.075564
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    """
    constructor test: class TaskInclude
    """
    mod = TaskInclude()

# Generated at 2022-06-23 07:24:18.890801
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    test_instance = TaskInclude()
    copy_instance = test_instance.copy()
    assert copy_instance.statically_loaded == False
    test_instance.statically_loaded = True
    assert test_instance.action == Task.action
    assert test_instance.args == Task.args
    assert test_instance.async_val == Task.async_val
    assert test_instance.async_seconds == Task.async_seconds
    assert test_instance.become == Task.become
    assert test_instance.become_flags == Task.become_flags
    assert test_instance.become_method == Task.become_method
    assert test_instance.become_user == Task.become_user
    assert test_instance.changed_when == Task.changed_when

# Generated at 2022-06-23 07:24:29.275705
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    '''
    Test that the right options are supported for a TaskInclude.
    '''

    # Setup a new instance of a block
    block = Block()
    # Setup data for the task
    data = dict(
        apply=dict(),
        tags=['tag1'],
        when='when1',
    )

    task = TaskInclude(block=block)

    # We expect to catch the exception
    try:
        task.preprocess_data(data)
    except AnsibleParserError as e:
        pass
    else:
        assert False, "AnsibleParserError not raised."

    # Let's try to override the action of task, it should fail
    data['action'] = 'include_role'

# Generated at 2022-06-23 07:24:42.446143
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    test_block_task_include = TaskInclude(block=Block())
    assert test_block_task_include.get_vars() == dict()

    test_play_task_include = TaskInclude(play=Play())
    assert test_play_task_include.get_vars() == dict()

    test_block_task = Task(block=Block())
    assert test_block_task.get_vars() == dict()

    test_play_task = Task(play=Play())
    assert test_play_task.get_vars() == dict()

    test_role_definition_task_include = Task

# Generated at 2022-06-23 07:24:51.045739
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # pylint: disable=too-many-locals

    from ansible.playbook.attribute import FieldAttribute, FieldAttributeError
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    def _create_task(ds, role=None, block=None):
        t = TaskInclude()
        t.name = 'test task'
        if block:
            t._parent = block
            t._role = role
        t.action = 'test_action'
        t.args = dict()
        t.vars = dict()
        t.tags = list()
        t._play = Play()
        t._play.connection_info = dict()

# Generated at 2022-06-23 07:24:58.165365
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._become = True
    play_context._become_method = 'sudo'
    play_context._become_user = 'myuser'
    play_context._remote_user = 'myuser'

    fake_loader = dummy_loader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {'hostname': {'foo': 'bar'}}}
    variable_manager.options_vars = {'some_var': 'some_value'}


# Generated at 2022-06-23 07:25:09.786930
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # this code is copied from test TaskInclude.load()
    import sys
    import io
    import json
    import pprint
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars


    # Prepare args

# Generated at 2022-06-23 07:25:10.862014
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    assert TaskInclude().__class__ is TaskInclude

# Generated at 2022-06-23 07:25:15.530484
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    data = dict()
    data['action'] = 'include'
    data['file'] = "test"
    task_include = TaskInclude.load(data)
    print(task_include)
    print(task_include.args['file'])
    assert task_include.args['file'] == "test"


# Generated at 2022-06-23 07:25:22.187811
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1, 'b': 2, 'c': [1,2,3]}
    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': [1,2,3]}


# Generated at 2022-06-23 07:25:28.481374
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t = TaskInclude()
    t.args['file'] = 'foo'
    t.statically_loaded = True
    t2 = t.copy()
    assert t2.args['file'] == 'foo'
    assert t2.statically_loaded == True
    t3 = t.copy(exclude_tasks=True)
    assert t3.args['file'] == 'foo'
    assert t3.statically_loaded == True


# Generated at 2022-06-23 07:25:39.378240
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.utils.display import Display
    display = Display()

    task = Task()
    task.action = 'include'
    task.args = dict()
    task.args['apply'] = {}

    # No 'file' arg
    try:
        TaskInclude.check_options(task, None)
    except AnsibleParserError as e:
        assert e.message == 'No file specified for include'
        assert e.obj is None

    # Valid args
    task.args['file'] = 'file.yml'
    task_new = TaskInclude.check_options(task, None)
    assert task_new.args == dict(_raw_params='file.yml',
                                 apply={},
                                 when=None)

    # Invalid 'apply' arg


# Generated at 2022-06-23 07:25:52.722756
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    data = dict()

    # check_options with no arguments (error)
    try:
        ti.check_options(None, data)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('check_options should raise an AnsibleParserError exception!')

    # check_options with an empty dict task (ok)
    task = dict()
    ti.check_options(task, data)
    assert task == dict()

    # check_options with a non empty dict task (error)
    task = dict(file='test_file')
    ti.check_options(task, data)
    assert '_raw_params' in task
    assert task['_raw_params'] == 'test_file'
    assert task['file'] == 'test_file'

    # check

# Generated at 2022-06-23 07:26:03.631394
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Testing correct handling of newly introduced 'apply' arg.
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(include="foo"),
            dict(include_role="bar"),
            dict(include_tasks="foobar"),
            dict(import_playbook="foobar"),
        ]
    )


# Generated at 2022-06-23 07:26:10.672768
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager

    # Construct a Play object which is used in the constructor
    play_ds = dict(
        name="test play",
        hosts='all',
        gather_facts='no',
        connection='local',
    )
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=None)

    # Construct a Block object which is used in the constructor
    block_ds = dict(
        name="test block",
        rescue=[],
        always=[],
    )