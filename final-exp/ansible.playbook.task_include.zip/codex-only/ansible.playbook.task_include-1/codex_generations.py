

# Generated at 2022-06-23 07:16:06.029814
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    assert True

# Generated at 2022-06-23 07:16:18.143504
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude.
    '''

    v_m = {}
    k_m = {}
    t_l = {}
    r = {}
    data = {"action":"include_role", "name":"my_role", "tasks_from": "main"}
    expected = TaskInclude(role=r)
    expected.args = data
    # Simple test
    assert TaskInclude.load(data, role=r, variable_manager=v_m, loader=k_m) == expected
    # Complex test
    data["tasks_from"] = "my_tasks"
    data["collections"] = ["my_collection"]
    data["run_once"] = True
    del data["tasks_from"]
    expected.args = data

# Generated at 2022-06-23 07:16:28.494440
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = {'action': 'include', 'name': 'x'}
    task = TaskInclude.load(data)

    # asserts TaskInclude.load returned an object of class TaskInclude
    assert isinstance(task, TaskInclude)

    expected_args = {'name': 'x', '_raw_params': None}
    for k, v in expected_args.items():
        assert task.args.get(k) == v

    # Missing file
    data = {'action': 'include', 'name': 'x'}
    try:
        TaskInclude.load(data)
        assert False
    except AnsibleParserError:
        assert True

    # Bad args
    data = {'action': 'include', 'name': 'x', 'workers': 2}

# Generated at 2022-06-23 07:16:41.467572
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Create a TaskInclude instance
    myTaskInclude = TaskInclude()

    # Confirm that the TaskInclude instance has the field 'statically_loaded'
    assert hasattr(myTaskInclude, 'statically_loaded')
    # Confirm that initially 'statically_loaded' is False
    assert myTaskInclude.statically_loaded == False

    # Copy the TaskInclude instance
    myTaskInclude_copy = myTaskInclude.copy()

    # Confirm that the TaskInclude_copy instance has the field 'statically_loaded'
    assert hasattr(myTaskInclude_copy, 'statically_loaded')
    # Confirm that 'statically_loaded' of the TaskInclude_copy instance is still False
    assert myTaskInclude_copy.statically_loaded == False

    # Assign True to the field

# Generated at 2022-06-23 07:16:49.368902
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """ test TaskInclude_build_parent_block"""
    import yaml
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook import Play

    class TaskMock(TaskInclude):
        """ Mock class for Task """
        def __init__(self):
            super(TaskMock, self).__init__()

    class MockInventory(Inventory):
        def __init__(self):
            self.vars = {}
            self.hosts = {}

        def set_variable(self, host, varname, value):
            self.vars[(host, varname)] = value

    class MockVariableManger(VariableManager):
        def __init__(self):
            super(MockVariableManger, self).__init__()
            self.inventory = Mock

# Generated at 2022-06-23 07:16:58.359301
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    def _make_task(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        return TaskInclude.load(data, block=block, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    data = {'include': 'test.yml'}
    task = _make_task(data)
    assert task.action == 'include'
    assert task.args.get('file') == 'test.yml'

    data = {'include_tasks': 'test.yml'}
    task = _make_task(data)
    assert task.action == 'include_tasks'
    assert task.args.get('file') == 'test.yml'

    # validate bad args, otherwise we silently ignore
   

# Generated at 2022-06-23 07:17:10.206087
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'include': 'test_TaskInclude_preprocess_data'}
    ti = TaskInclude(None)

    assert_ds = {'include': 'test_TaskInclude_preprocess_data'}
    assert ti.preprocess_data(ds) == assert_ds

    ds = {'include': 'test_TaskInclude_preprocess_data', 'foo': 'This is', 'bar': 'an example'}
    assert_ds = {'include': 'test_TaskInclude_preprocess_data', 'foo': 'This is', 'bar': 'an example'}
    assert ti.preprocess_data(ds) == assert_ds

    ds = {'include': 'test_TaskInclude_preprocess_data', 'include_role': 'test_TaskInclude_preprocess_data2'}

# Generated at 2022-06-23 07:17:11.332957
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    pass


# Generated at 2022-06-23 07:17:23.844560
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from .role import Role
    from .play import Play
    from .task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    v = VariableManager()
    d = DataLoader()
    Role._role_paths = ['../../lib/ansible/roles/']

    inventory = Inventory(loader=d, variable_manager=v, host_list='localhost,')
    play = Play().load('../../../test/playbooks/included.yml', variable_manager=v, loader=d)
    print("play_hosts : %s" % play.hosts)
    print("play_tasks : %s" % play.tasks)

# Generated at 2022-06-23 07:17:34.964243
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class TestTaskInclude(TaskInclude):
        def __init__(self):
            super(TestTaskInclude, self).__init__()
            self._variable_manager = VariableManager()
            self._loader = 'dummy'
            self._role = Role()
            self._roles = []

# Generated at 2022-06-23 07:17:39.134450
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # setup
    data = dict(include=dict(args=dict(x='x')))
    task = TaskInclude.load(data=data)

    # test
    res = task.get_vars()
    assert 'x' in res



# Generated at 2022-06-23 07:17:48.933714
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # create and initialize TaskInclude object
    ti = TaskInclude()
    ti.action = 'include_role'
    ti.args = {'name': 'test'}
    ti.tags = ['test']
    ti.notify = ['test']

    # create TaskInclude object by calling copy method which takes 'tasks' as parameter and check if the object
    # has been properly cloned
    new_ti = ti.copy(exclude_tasks=True)
    assert ti != new_ti
    # test if the action property is properly copied
    assert ti.action == new_ti.action
    # test if the args property is properly copied
    assert ti.args == new_ti.args
    # test if the tags property is properly copied
    assert ti.tags == new_ti.tags
    # test if the notify property is properly

# Generated at 2022-06-23 07:17:55.927123
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.action = 'include_role'
    ti.args = {
        'a': 'b',
        'c': 'd'
    }

    try:
        vars = ti.get_vars()
    except Exception as e:
        print(e)
        raise

    assert vars.get('a') == 'b'
    assert vars.get('c') == 'd'


# Generated at 2022-06-23 07:17:58.156315
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude()
    assert isinstance(t.other_args, frozenset)
    assert t.statically_loaded == False

# Generated at 2022-06-23 07:18:07.984194
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test 'include' action
    task = TaskInclude.load(
        data={
            'action': 'include',
            'file': '/path/to/file',
            'simple_arg': 'simple_arg_value',
            'dict_arg': {'arg_dict_key': 'arg_dict_key_value'}
        },
        block=Block(),
        role=None,
        task_include=None,
        loader=None,
        variable_manager=None
    )

    result = task.get_vars()

    assert 'simple_arg' in result
    assert result['simple_arg'] == 'simple_arg_value'
    assert 'dict_arg' in result
    assert result['dict_arg'] == {'arg_dict_key': 'arg_dict_key_value'}

    # test

# Generated at 2022-06-23 07:18:17.972148
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display = Display()
    display.verbosity = 3
    my_task = TaskInclude()
    my_task.action = 'include'
    my_action = 'include'

    # test 1: list of tasks with an unknown key
    data = [
        {
            'set_fact': {'foo': '1'},
            'my_unknown_key': 'bar'
        },
        {'debug': 'msg={{foo}}'}
    ]

    display.display('=== Testing %s with an UNKNOWN key' % my_action)

# Generated at 2022-06-23 07:18:25.713735
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager, combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeProxy

    data = {
        'name': 'test',
        'connection': 'local',
        'hosts': 'all',
        'roles': [],
        'vars': {
            'var1': 1
        },
        'tasks': [
            {
                'include': 'include.yml',
                'var2': 2
            }
        ]
    }

    var_manager = VariableManager()
    var_manager._fact_cache = dict()

# Generated at 2022-06-23 07:18:29.012132
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded == True

# Generated at 2022-06-23 07:18:36.916438
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude()
    def check_options(task, data):
        raise AnsibleParserError("Invalid options for %s: apply" % task.action, obj=data)
    task.check_options = check_options
    data = dict(
        action="include_tasks",
        file="foo.yml",
        apply="foo"
    )
    try:
        task.load(data)
    except AnsibleParserError as e:
        assert isinstance(e.obj, dict) and e.obj == data

# Generated at 2022-06-23 07:18:48.901715
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Fake the module
    class Options(dict):
        def __init__(self, options):
            self.__dict__ = options

    class FakeModule:
        def get_option(self, key):
            return self.options[key]

    class FakeRole:
        def __init__(self, name):
            self.name = name

    class FakeData:
        def __init__(self, data):
            self.__dict__ = data

    class FakeDataBlock:
        def __init__(self, data):
            self.block = data

    class FakeBlock:
        def __init__(self, data, parent=None, role=None, task_include=None, variable_manager=None, loader=None):
            self.statically_loaded = False
            self._block = data
            self._parent = parent


# Generated at 2022-06-23 07:19:00.571458
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    try:
        from unittest import mock
    except ImportError:
        from ansible.compat.tests import mock

    from ansible.playbook.task import Task


# Generated at 2022-06-23 07:19:10.188167
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing import DataLoader

    # Prepare objects
    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()

    block_args_1 = dict(one=1, two=2, three=3)
    block_args_2 = dict(two=20, three=30, forty=40)
    block_args_3 = dict(three=300, forty=400, fivehundred=500)
    task_args_1 = dict(file='file_name')

    # Create Blocks

# Generated at 2022-06-23 07:19:21.693044
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    task_ds = dict(
        action='include_role',
        name='myrole',
        tasks_from='mytask.yml',
    )
    the_task = TaskInclude()
    the_task._variable_manager = MagicMock()
    the_task._loader = DictDataLoader({})
    the_task._role = None

    # Create a plays and set it as parent
    the_play = Play()
    the_play._variable_manager = MagicMock()
    the_play._loader = DictDataLoader({})
    the_play._tqm = MagicMock()
    the_play._tqm._data_loader = DictDataLoader

# Generated at 2022-06-23 07:19:27.461393
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    role = {}
    task_include = {}
    task = TaskInclude(block=block, role=role, task_include=task_include)
    task_copy = task.copy()
    assert task.statically_loaded == task_copy.statically_loaded

# Generated at 2022-06-23 07:19:40.467063
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import TaskExecution

    playbook = Playbook()
    playbook._loader = playbook._loader.set_basedir('../../lib/ansible/playbooks')
    playbook.load('../../lib/ansible/playbooks/_pre_tasks/test.yaml')
    play = Play().load(playbook.data[0], playbook=playbook)
    block = play.block
    task = Task().load(block.block[0], block=block, play=play)

# Generated at 2022-06-23 07:19:45.293564
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    include_task = TaskInclude(None)
    new_include_task = include_task.copy()

    assert include_task == new_include_task
    assert include_task.__dict__ == new_include_task.__dict__
    assert include_task.statically_loaded == new_include_task.statically_loaded

# Generated at 2022-06-23 07:19:53.679523
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    block = Block()
    role = None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    ti.statically_loaded = True
    ti.action = 'include_role'
    ti.args = {
        "_raw_params": "foobar",
        "tags": ["a"]
    }

    new_ti = ti.copy()
    assert new_ti.statically_loaded == ti.statically_loaded
    assert new_ti.action == ti.action
    assert new_ti.args == ti.args


# Generated at 2022-06-23 07:20:01.862992
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict(foo='bar',bar='foo')
    task_include._parent = Block()
    task_include._parent.vars = dict(bar='foo')
    task_include.vars = dict(bar='foo')
    assert task_include.get_vars() == dict(foo='bar',bar='foo')
    task_include.action = 'include_tasks'
    task_include.args = dict(foo='bar')
    task_include.vars = dict(foo='bar')
    assert task_include.get_vars() == dict(foo='bar')
    del task_include._parent
    assert task_include.get_vars() == dict(foo='bar')

# Generated at 2022-06-23 07:20:09.215849
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import os
    import sys
    import tempfile
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..','..','lib')))
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-23 07:20:19.725609
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test 1: assume file and then assume action
    result = TaskInclude.load({'file': 'my_file.yaml', 'action': ''})
    assert result.args['action'] == 'include'
    assert result.args['file'] == 'my_file.yaml'

    # Test 2: assume action and assume file
    result = TaskInclude.load({'action': 'include', 'file': 'my_file.yaml'})
    assert result.args['action'] == 'include'
    assert result.args['file'] == 'my_file.yaml'

    # Test 3: assume action and then assume file
    result = TaskInclude.load({'action': 'include', 'file': 'my_file.yaml'})
    assert result.args['action'] == 'include'

# Generated at 2022-06-23 07:20:32.682443
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test to ensure that the args of the include are loaded into the vars for
    the included tasks only for 'include' tasks
    '''
    task = TaskInclude.load({
        'action': 'include',
        'args': {
            'a': 'A',
            'include': 'some_file',
            'tags': [],
            'when': True,
        }
    })

    # Include action
    vars = task.get_vars()
    assert vars['a'] == 'A'
    assert vars['include'] == 'some_file'

    # Other actions
    action = 'include_role'

# Generated at 2022-06-23 07:20:43.569312
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    TaskInclude.register_loader()

    data = dict(
        name='test include',
        file='./tasks/main.yml'
    )

    ti = TaskInclude.load(data, None, None, None, None, None)

    assert ti.name == 'test include'
    assert ti.action == 'include'
    assert ti.args['file'] == './tasks/main.yml'
    assert ti.statically_loaded == False

    ti_copy = ti.copy()

    assert ti_copy.name == 'test include'
    assert ti_copy.action == 'include'
    assert ti_copy.args['file'] == './tasks/main.yml'
    assert ti_copy.statically_loaded == False

    ti_copy.statically_loaded = True

    assert ti

# Generated at 2022-06-23 07:20:53.882590
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test with action 'include'
    ti = TaskInclude()
    data = {'action': 'include', 'file': 'somedir/somesubdir/somefile.yaml'}
    task = ti.check_options(ti.load_data(data, variable_manager=None, loader=None), data)
    assert task.args == {'file': 'somedir/somesubdir/somefile.yaml', '_raw_params': 'somedir/somesubdir/somefile.yaml'}

    # Test with action 'include_role'
    ti = TaskInclude()
    data = {'action': 'include_role', 'file': 'somedir/somesubdir/somefile.yaml'}

# Generated at 2022-06-23 07:21:04.539455
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Unit test for method TaskInclude.get_vars
    '''
    parent_block = Block()
    parent_block.vars = {'bvar': 'bvalue'}
    ti = TaskInclude(parent_block)
    ti.action = 'include'
    ti.vars = {'tvar': 'tvalue'}
    ti.args = {'avar': 'avalue'}
    assert ti.get_vars() == {'bvar': 'bvalue', 'tvar': 'tvalue', 'avar': 'avalue'}
    ti.action = 'import_playbook'
    assert ti.get_vars() == {'bvar': 'bvalue', 'tvar': 'tvalue'}
    ti.vars = None

# Generated at 2022-06-23 07:21:15.479745
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # This is a seemingly valid include task; this task will be used in all tests:
    task_to_load_valid = dict(
        # Attributes
        action='include',
        args=dict(
            _raw_params='%Y/%m/%d',
        ),
    )

    # This is an invalid include task; attributes that don't belong to the include tasks are set:
    task_to_load_invalid = dict(
        # Attributes
        action='include',
        args=dict(
            _raw_params='%Y/%m/%d',
            # Invalid attributes
            become='False',
            remote_user='ansible',
        ),
    )

    # This is a handler task; this task will be used in some tests:

# Generated at 2022-06-23 07:21:26.334234
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    class TaskIncludeChild(TaskInclude):
        pass

    ti = TaskIncludeChild(block=None, role=None, task_include=None)
    ti.statically_loaded = True
    new_ti = ti.copy(exclude_parent=False, exclude_tasks=False)
    assert ti.statically_loaded == new_ti.statically_loaded
    assert TaskIncludeChild is new_ti.__class__

    ti.statically_loaded = False
    new_ti = ti.copy(exclude_parent=False, exclude_tasks=False)
    assert ti.statically_loaded == new_ti.statically_loaded
    assert TaskIncludeChild is new_ti.__class__

# Generated at 2022-06-23 07:21:31.728731
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    t = TaskInclude()
    t.action = 'debug'
    t.include_role = 'debug'
    t.statically_loaded = True
    c = t.copy()
    assert c.action == t.action
    assert c.include_role == t.include_role
    assert c.statically_loaded == t.statically_loaded

# Generated at 2022-06-23 07:21:44.297691
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # All valid options
    ti = TaskInclude()
    data = dict(file="my_file.yaml", apply='apply_dict')
    task = ti.check_options(ti.load_data(data), data)
    assert task.args == dict(_raw_params='my_file.yaml', apply='apply_dict')
    assert task.action == 'include'

    # Invalid options
    data = dict(file="my_file.yaml", bad_opt='bad')
    with pytest.raises(AnsibleParserError):
        task = ti.check_options(ti.load_data(data), data)

    # Invalid apply dict, but with action not in INCLUDE

# Generated at 2022-06-23 07:21:51.321132
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    ti._variable_manager = None
    ti._loader = None
    ti._parent = None
    ti._role = None
    ti.args = {'_raw_params': 'static_imports.yml', 'apply': {'block': None, 'always': None, 'name': None, 'pause': None, 'with_items': None, 'run_once': None}}
    ti.vars = None
    ti.action = 'include'
    ti.block = None
    ti._role = None
    pb = ti.build_parent_block()
    assert pb is ti



# Generated at 2022-06-23 07:21:55.160161
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    data = dict(action='include', file='foo.yml')
    task = dict(action='include', args=dict(_raw_params='foo.yml'))
    ti.check_options(task, data)

    data = dict(action='import_playbook', file='foo.yml')
    task = dict(action='import_playbook', args=dict(_raw_params='foo.yml'))
    ti.check_options(task, data)

    data = dict(action='import_tasks', file='foo.yml')
    task = dict(action='import_tasks', args=dict(_raw_params='foo.yml'))
    ti.check_options(task, data)


# Generated at 2022-06-23 07:22:01.022148
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    role_path = './test/roles/include_role_dep'
    print("get_vars: ", TaskInclude.load({'name': 'include_role_dep', 'include_role': {'name': 'include_role_dep'}}, role=role_path))
    print("get_vars: ", TaskInclude.load({'name': 'include_role_dep', 'include_role': {'name': 'include_role_dep', 'vars': {'foo': 'bar'}}}, role=role_path))

# Generated at 2022-06-23 07:22:13.001478
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task_include = TaskInclude()
    task_include.statically_loaded = False

    task = Task()
    task.statically_loaded = False

    task_include.block = task
    task_include.role = Role()
    task_include.role.get_role_path = lambda: "test"
    task_include._parent = Block()
    task_include._parent._play = Play()
    task_include._parent._play.get_vars = lambda: {"test": "dict"}
    task_include.role.get_role_path = lambda: "test"

# Generated at 2022-06-23 07:22:25.946682
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext

    # Uncomment the following 2 lines to fix the test.
    #from ansible.playbook.play import Play
    #from ansible.playbook.role import Role

    attrs = dict(apply=dict(name='test',
                            with_items=[1, 2],
                            with_dict={'key1': 'val1', 'key2': 'val2'}),
                 file='test.yml')
    task = TaskInclude(play=Play(),
                       task_include=Task(),
                       role=Role(),
                       variable_manager=PlayContext(),
                       loader=None)
    p_block = task.check_options(task.load_data(attrs), attrs).build_parent_block()

# Generated at 2022-06-23 07:22:39.058200
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import sys
    from ansible.utils.display import Display
    if sys.version_info[0] < 3:
        # In python2, mock is installed as `unittest.mock`
        # https://docs.python.org/2/library/unittest.mock.html
        from unittest.mock import Mock
    else:
        # In python3, mock is installed as `unittest.mock`
        # https://docs.python.org/3/library/unittest.mock.html
        from unittest.mock import Mock

    # A) Test for action `include`
    mock_display = Mock(spec=Display)
    mock_display.warning = lambda x: None
    # Set display to be mock_display
    display.display = mock_display

    # data
    data

# Generated at 2022-06-23 07:22:43.532497
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ds = {'action': 'include',
        'name': 'test role'}

    ti = TaskInclude(ds)
    ti.args = {'a': 'b'}
    ti.vars = {'c': 'd'}
    allvars = ti.get_vars()

    assert allvars['a'] == 'b'
    assert allvars['c'] == 'd'

    ds = {'action': 'custom',
        'name': 'test role'}

    ti = TaskInclude(ds)
    ti.args = {'a': 'b'}
    ti.vars = {'c': 'd'}
    allvars = ti.get_vars()

    assert allvars['a'] == 'b'
    assert allvars['c'] == 'd'

# Generated at 2022-06-23 07:22:56.613661
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    import ansible.constants as constants
    from ansible.utils.display import Display

    from ansible.module_utils.six import string_types
    from ansible.plugins.loader import find_plugin, action_loader

    tmp_path = '/home/user/include_action'

    task = Task()
    task.set_loader(None)
    task.action = 'import_tasks'

    data = {}

    # test with a valid file
    data['file'] = tmp_path + '/valid'
    data['_raw_params'] = tmp_path + '/valid'
    TaskInclude.check_options(task, data)

# Generated at 2022-06-23 07:23:03.291779
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PL
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task_include import TaskInclude as TI


# Generated at 2022-06-23 07:23:16.783699
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import Include

    # Set ActionBase to check all proper include/import tasks
    # More info: https://github.com/ansible/ansible/pull/69635#issuecomment-711388207
    ActionBase._ALL_PROPER_INCLUDE_IMPORT_TASKS = C._ALL_INCLUDE_TASKS

    # Note that we have to use tuples here as lists have always a reference to their elements
    ALL_INCLUDE_TASKS = ('include', 'include_role', 'import_playbook', 'import_tasks', 'include_vars')

    class FakeInclude(object):
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-23 07:23:28.816727
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    class Data:
        def __init__(self, data):
            self.data = data

    class VariableManager:
        def __init__(self):
            pass

    class Loader:
        def __init__(self):
            pass

    def test_load(data):
        task_include = TaskInclude()
        return task_include.load(data, variable_manager=VariableManager(), loader=Loader())

    import pytest
    # test no file specified
    with pytest.raises(AnsibleParserError):
        test_load(Data({}))

    # test invalid option
    with pytest.raises(AnsibleParserError):
        test_load(Data({'file': 'foo', 'invalid_option': 'bar'}))

    # test valid option and load_data
    task = test_load

# Generated at 2022-06-23 07:23:40.819761
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Base Task
    task = Task(block=None, role=None, task_include=None)
    task.vars = dict(foo='foo', bar='bar')
    all_vars = task.get_vars()
    assert all_vars == dict(foo='foo', bar='bar')

    # TaskInclude
    task = TaskInclude(block=None, role=None, task_include=None)
    task.vars = dict(foo='foo', bar='bar')
    task.args = dict(baz='baz', qux='qux')
    all_vars = task.get_vars()
    assert all_vars == dict(foo='foo', bar='bar', baz='baz', qux='qux')

# Generated at 2022-06-23 07:23:42.209976
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    c = TaskInclude()
    assert c.statically_loaded is False

# Generated at 2022-06-23 07:23:57.811141
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.vars = dict(a=1)

    assert ti.get_vars() == dict(a=1)

    ti.args = dict(b=2)
    assert ti.get_vars() == dict(a=1, b=2)

    ti.action = 'include_role'
    assert ti.get_vars() == dict(a=1)

    ti.action = 'include'
    assert ti.get_vars(  ) == dict(a=1, b=2)

    ti._parent = Sentinel()
    ti._parent.get_vars = lambda: dict(c=3)
    assert ti.get_vars() == dict(c=3, a=1, b=2)


# Generated at 2022-06-23 07:23:59.364810
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    TaskInclude.load({'file': '/path/to/include.yml', 'action': 'include'})

# Generated at 2022-06-23 07:24:07.369419
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    play_vars = dict(a=1, b=2)
    block_vars = dict(a=3, c=4)
    include_vars = dict(a=5, d=6)
    include_args = dict(n=7, z=8)
    include_action = 'include_tasks'
    block_task_vars = dict(m=9, n=10)
    block = Block.load(block_vars, play=None)
    block.block = [
        TaskInclude.load(include_vars, block=block, role=None, task_include=None),
        dict(action=include_action, args=include_args)
    ]

# Generated at 2022-06-23 07:24:17.324533
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    class my_TaskInclude_class(TaskInclude):
        pass

    class my_TaskInclude_class_with_play(TaskInclude):
        _play = 'play'

    class my_Block_class(Block):
        pass

    class my_Block_class_with_play(Block):
        _play = 'play'

    # test with ``action`` different than 'include', 'include_tasks', 'import_playbook' and 'import_role'
    ds = {'action': 'action_test', 'include': 'include_test'}
    ti = my_TaskInclude_class()
    ti.preprocess_data(ds)
    assert ds == {'action': 'action_test'}

    # test with ``action`` equal to 'include' and attrs not in ``VALID_INCLU

# Generated at 2022-06-23 07:24:28.457726
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # tasks:
    # - name: my first task
    #   include: '{{var}}'
    #   apply:
    #     block:
    #     - name: my task 2 # pylint: disable=line-too-long
    #       debug: msg="hi"

    t_include_data = {
        'apply': {
            'block': [
                {'action': 'debug', 'args': {'msg':'hi'}, 'name': 'my task 2'}
            ]
        },
        'action': 'include',
        'args': {
            '_raw_params': '{{var}}'
        },
        'name': 'my first task'
    }

    my_incl = TaskInclude.load(t_include_data, task_include=None)

    assert my_incl

# Generated at 2022-06-23 07:24:36.442216
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import os
    import tempfile

    def _check_options(self, task, data):
        TaskInclude.check_options(self, task, data)

    # Valid use case
    yaml_fragment = '''
    - include:
        file: test.yaml
        apply:
          force: yes
    '''
    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write(yaml_fragment)
    try:
        data = TaskInclude.load(
            data=dict(
                _raw_params=f.name,
            ),
            task_include=TaskInclude(),
        )
        _check_options(None, data, data)
    finally:
        os.unlink(f.name)

    # Invalid use case
    y

# Generated at 2022-06-23 07:24:46.886824
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from collections import namedtuple
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    fake_play = Play()
    fake_role = Role()
    fake_task = Task()
    fake_block = Block()

    fake_variable_manager = namedtuple('fake_variable_manager', ['get_vars'])
    fake_variable_manager.get_vars = lambda: {}
    fake_loader = namedtuple('fake_loader', ['get_basedir', 'path_dwim'])
    fake_loader.get_basedir = lambda x: '.'
    fake_loader.path_dwim

# Generated at 2022-06-23 07:24:58.661208
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This method is used to test the get_vars method of TaskInclude
    '''
    import yaml
    from ansible.parsing.vault import VaultLib

    task = TaskInclude()
    task.vars = {'t_var': 't_val'}
    task.action = 'include'
    task.args = {
        '_raw_params': 'file1',
        'arg1': 'val1'
    }
    task.add_tag('tag1')
    task.add_tag('tag2')
    result = task.get_vars()
    assert result == {'t_var': 't_val', 'arg1': 'val1', '_raw_params': 'file1'}

    task = TaskInclude()

# Generated at 2022-06-23 07:25:10.015619
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    obj = TaskInclude()

    # Test with C._ACTION_ALL_STATIC_INCLUDE_TASKS
    with pytest.raises(AnsibleParserError) as excinfo:
        obj.preprocess_data({'foo': 1, 'action': 'include', 'name': 'foo'})
    assert "Unexpected attribute (foo) in include" in str(excinfo)

    with pytest.raises(AnsibleParserError) as excinfo:
        obj.preprocess_data({'foo': [1, 2], 'action': 'import_role', 'name': 'foo'})
    assert "Unexpected attribute (foo) in import_role" in str(excinfo)


# Generated at 2022-06-23 07:25:14.506572
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass

# Auto-generate TaskInclude attribute fields
for attr, attr_cfg in Task.FIELDS.items():
    if not hasattr(TaskInclude, attr):
        setattr(TaskInclude, attr, FieldAttribute(attr_cfg))

# Generated at 2022-06-23 07:25:27.550487
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    field1 = FieldAttribute(name='field1', default='field1 default')
    field2 = FieldAttribute(name='field2', default='field2 default')
    field3 = FieldAttribute(name='field3', default='field3 default')
    field4 = FieldAttribute(name='field4', default='field4 default')
    field5 = FieldAttribute(name='field5', default='field5 default')
    field6 = FieldAttribute(name='field6', default='field6 default')
    field7 = FieldAttribute(name='field7', default='field7 default')
    field8 = FieldAttribute(name='field8', default='field8 default')
    field9 = FieldAttribute(name='field9', default='field9 default', include_role=True)

# Generated at 2022-06-23 07:25:28.924297
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # but there is no code for use
    assert True

# Generated at 2022-06-23 07:25:39.607196
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    def assert_raises(data, expection_message, task_action=''):
        exception_raised = False
        try:
            ti = TaskInclude.load(
                data,
                block=None,
                role=None,
                task_include=None,
                variable_manager=None,
                loader=None,
            )
        except AnsibleParserError as e:
            assert(sorted(expection_message.split(',')) == sorted(e.message.split(',')))
            exception_raised = True
        assert(exception_raised)


# Generated at 2022-06-23 07:25:52.763899
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    block_in_task = Block(task_include=Sentinel, role=Sentinel)
    block_in_task.vars.update({'key': 'value'})
    block_in_task._parent = Sentinel
    include_action = 'include'
    task_include = TaskInclude(block=block_in_task, task_include=Sentinel, role=Sentinel)
    task_include.action = include_action
    task_include.args.update({'include_key': 'include_value'})
    ti_vars = task_include.get_vars()
    assert ti_vars.get('key') == 'value'
    assert ti_vars.get

# Generated at 2022-06-23 07:26:03.676641
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    vars_manager = VariableManager()
    block_vars_manager = VariableManager()
    block_vars_manager._vars_cache = HostVars(play=play_context)
    hostvars = HostVars(play=play_context)
    v

# Generated at 2022-06-23 07:26:10.691686
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    ti_file = TaskInclude()
    ti_file.action = 'include'
    ti_file.args = dict(file="some_file.yaml")
    ti_file.vars = dict(ansible_file="some_file.yaml", test="dummy")

    assert ti_file.get_vars() == {'ansible_file': 'some_file.yaml', 'file': 'some_file.yaml', 'test': 'dummy'}

    ti_include = TaskInclude()
    ti_include.action = 'include'
    ti_include.args = dict(file="some_include.yaml", tags="some_tags")
    ti_include.vars = dict(ansible_include="some_include.yaml", test="dummy")

    assert ti_include.get_vars