

# Generated at 2022-06-23 07:16:17.352184
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    """
    Test for `Task.copy` method.
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    context._vars_cache = dict()
    context._queue_items = list()
    manager = VariableManager()
    manager.extra_vars = dict()
    manager.options_vars = dict()

    context._tqm = Sentinel()
    manager.set_play_context(context)

    # `include` will create a `Block` as parent block
    task_include = TaskInclude(
        dict(
            file='/path/to/file',
            action='include'
        ),
        variable_manager=manager
    )

    # Should be a `Task` because it is created by `Block`

# Generated at 2022-06-23 07:16:27.672501
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    # Test copy when there is no parent
    task = Task(play=Play().load({'name': 'test', 'hosts': 'all'}, variable_manager=None, loader=None))
    task_copy = task.copy(exclude_parent=True, exclude_tasks=False)
    assert task_copy.action == task.action
    assert task_copy.args == task.args
    assert task_copy.when == task.when
   

# Generated at 2022-06-23 07:16:40.172899
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.utils.sentinel import Sentinel
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(
                include='include_tasks_test.yml',
                apply=dict(arg1='val1', block='block_test.yml', arg2='val2'),
            )
        ]
    )
   

# Generated at 2022-06-23 07:16:48.856959
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.include_role import IncludeRole

    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "test.yml": """
        - hosts: localhost
          tasks:
            - include: test2.yml
        """,

        "test2.yml": """
        - hosts: localhost
          tasks:
            - debug:
              var: foo
        """,
    })

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    role = Role.load(None, play=None, variable_manager=variable_manager, loader=loader)
    role_include = RoleIn

# Generated at 2022-06-23 07:16:58.260901
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Usage: python -m test.test_taskinclude.test_TaskInclude_preprocess_data
    '''
    import json
    import os
    import sys

    ###########
    # imports #
    ###########

    # add `library` subdir to `sys.path`
    # this is required to import module `test.lib`
    lib_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'lib'
    )
    sys.path.append(lib_dir)

    # import a few packages/modules
    from test.lib.testutil import AnsibleParserError
    from test.lib.testutil import TEST_DATA_DIR
    from test.lib.testutil import unittest

    ##########
    # class

# Generated at 2022-06-23 07:17:03.807360
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders, get_all_plugin_paths
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    # All this is just to get the fake plugin loader
    plugin_loaders = get_all_plugin_loaders()
    fake_loader = None

# Generated at 2022-06-23 07:17:15.262136
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    context = PlayContext()
    ti = TaskInclude(context)

    # no file or _raw_params
    data_bad_1 = {'include': 'foobar.yml'}

    # file and _raw_params provided
    data_bad_2 = {'include': 'foobar.yml', 'file': 'file_data.yml', '_raw_params': 'barbaz.yml'}

    # apply used on something other than include
    data_bad_3 = {'action': 'import_tasks', 'apply': 'apply_attrs'}

    # apply is not a dict

# Generated at 2022-06-23 07:17:27.619857
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test for TaskInclude.build_parent_block
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    play_context = PlayContext()
    loader = False
    variable_manager = False
    tasks = [{"action": "shell", "args": {"chdir": "/tmp", "creates": "/tmp/test_facts.py"}, "register": "shell_out"}]

    task_include = TaskInclude()

# Generated at 2022-06-23 07:17:37.425554
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager

    pb = Playbook.load('./test/units/playbooks/test_plays/handler_include.yml', variable_manager=VariableManager(), loader=False)
    play = pb.get_plays()[0]

    task_include = TaskInclude.load({
        "include": "./files/child.yml",
    }, role=Role(), play=play)

    assert isinstance(task_include.vars, dict)
    assert task_include.name == ""
    assert task_include.action

# Generated at 2022-06-23 07:17:47.775332
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t = TaskInclude()
    d = {'action':'include', 'foobar':'xyz'}

    d1 = t.preprocess_data(d)
    assert d1 == d
    d.pop('foobar')
    d1 = t.preprocess_data(d)
    assert isinstance(d1, dict)
    assert 'foobar' not in d1
    assert d1 == d

    d1 = t.preprocess_data({'action': 'import_tasks'})
    assert d1 == {'action': 'import_tasks'}
    d1 = t.preprocess_data({'action': 'import_tasks', 'foobar': 'xyz'})
    assert isinstance(d1, dict)
    assert 'foobar' not in d1

# Generated at 2022-06-23 07:17:59.360503
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars import VariableManager
    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    import yaml

    my_vars = yaml.safe_load("""
    ---
    host1:
      ansible_host: 127.0.0.1
    """)

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(loader=DataLoader(), host_vars=my_vars))

# Generated at 2022-06-23 07:18:06.893261
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # We build a fake task called "include" with vars and args to call get_vars() on it.
    # Test that vars, args and parent vars are correctly merged and that tags and when excluded
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'x': 2, 'y': 3}
    task.args = {'tags': 'all', 'when': 3, 'A': 0, 'x': 1}

    parent = Task()
    parent.vars = {'y': 4, 'A': 1}
    parent.args = {'A': 2}

    task._parent = parent

    expected = {'x': 1, 'y': 3, 'A': 0}

    assert task.get_vars() == expected

    # Test that vars, args and parent vars

# Generated at 2022-06-23 07:18:11.440216
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    pb = TaskInclude()
    pb.args = dict(a=1)
    new_pb = pb.copy(exclude_parent=True, exclude_tasks=True)
    assert new_pb.args == dict(a=1)
    assert new_pb.statically_loaded == False

# Generated at 2022-06-23 07:18:20.210773
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # pylint: disable=bad-continuation
    assert ti.check_options(
        TaskInclude.load(dict(action='include', _raw_params='foo.yml'),
                         variable_manager=None, loader=None),
        dict(action='include')
    )
    assert ti.check_options(
        TaskInclude.load(dict(action='include', _raw_params='foo.yml', apply=dict()),
                         variable_manager=None, loader=None),
        dict(action='include')
    )


# Generated at 2022-06-23 07:18:24.276426
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    block = Block()
    role = None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)

if __name__ == '__main__':
    test_TaskInclude()

# Generated at 2022-06-23 07:18:36.777033
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils import context_objects as co

    class DummyContext:
        def __init__(self):
            self._ds = None
            self._ds_data = None
            self._ds_parsed = False
            self._ds_parsed_errors = []
            self._ds_parsed_warnings = []
            self._ds_parsed_links = {}
            self._ds_parsed_filename = ''
            self._ds_parsed_stat = None
            self._ds_parsed_mtime = 0
            self._ds_parsed_cache = None
            self._ds_parsed_exit

# Generated at 2022-06-23 07:18:48.880266
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    import sys
    import pytest

    from ansible.playbook.task_include import TaskInclude

    scope = {'action': 'include_tasks', 'args': {}}
    with pytest.raises(AnsibleParserError) as e:
        TaskInclude.preprocess_data(scope)
    assert "No file specified for include_tasks" in str(e.value)

    scope = {'action': 'import_tasks', 'args': {}}
    with pytest.raises(AnsibleParserError) as e:
        TaskInclude.preprocess_data(scope)
    assert "No file specified for import_tasks" in str(e.value)

    scope = {'action': 'not_include_tasks', 'args': {}}

# Generated at 2022-06-23 07:19:00.574013
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    test_obj = TaskInclude()

    # Test for each type of include task
    for action in C._ACTION_INCLUDE_TASKS:
        task_without_param_file = Task.load({'action': action, 'args': {'not_file': 'something'}})
        task_with_param_file = Task.load({'action': action, 'args': {'file': 'something'}})
        task_with_apply = Task.load({'action': action, 'args': {'apply': {'some': 'something'}, 'file': 'something'}})


# Generated at 2022-06-23 07:19:10.157851
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    #
    # include: test.yaml
    #
    variable_manager = "fake variable manager"
    loader = "fake loader"
    data = {
        "include": "test.yaml",
        "tags": ["tag1", "tag2"],
        "when": "ansible_os_family == 'RedHat'",
    }
    # Call method under test
    ti = TaskInclude.load(data,
                          variable_manager=variable_manager,
                          loader=loader)

    assert ti.action == 'include'
    assert ti.name == ''
    assert ti.args['_raw_params'] == "test.yaml"
    assert ti.tags == ["tag1", "tag2"]
    assert ti.when == "ansible_os_family == 'RedHat'"

    #
    # import_

# Generated at 2022-06-23 07:19:19.011508
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class TestTask(TaskInclude):
        def load_data(self, ds, variable_manager=None, loader=None):
            return self

    task = TestTask()

    # test args with known keywords
    with pytest.raises(AnsibleParserError) as exec:
        task.check_options(task.load_data({'file': 'f1', 'foo': 's1'}), {})
    assert 'Invalid options for include: foo' in str(exec.value)
    with pytest.raises(AnsibleParserError) as exec:
        task.check_options(task.load_data({'file': 'f1', 'apply': 's1'}), {})
    assert 'Expected a dict for apply but got str instead' in str(exec.value)

    # test args with unknown keywords


# Generated at 2022-06-23 07:19:30.488272
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # we don't have a TaskInclude object to test with, so we use a Task object
    obj = Task()
    # we don't have a TaskInclude object to test with, so we use a Task object
    obj.action = 'include'
    obj.args = {'param1': 'val1'}
    obj.args['_raw_params'] = 'test_file'
    obj.block = []
    obj._parent = Sentinel
    obj._role = Sentinel
    obj._play = Sentinel
    test_file = obj._loader.path_dwim('test_file1')
    test_file_content = '[{"action":"include","args":{"param1":"val1","_raw_params":"good_file"}}]'

    # test with a file that doesn`t exists
    test_file_invalid = obj._loader.path

# Generated at 2022-06-23 07:19:41.101696
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    loader = None
    variable_manager = None
    task = TaskInclude.load(
        dict(
            include="bla",
            bla="foo",
            action="include",
            name="foo",
            tags=["bar"],
        ),
        task_include=None,
        loader=loader,
        variable_manager=variable_manager
    )
    task.preprocess_data(task.args)
    assert task.args['bla'] is Sentinel
    assert task.args['action'] == 'include'
    assert task.args['name'] == 'foo'
    assert task.args['tags'] == ['bar']

# Generated at 2022-06-23 07:19:51.765860
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play = Play()
    play.context = PlayContext()
    # Good options
    good_options = {
        'action': 'include_tasks',
        'file': 'my_file',
        'apply': {
            'block': [],
            'block_errors': False,
            'always_run': [],
            'register': 'my_register',
        },
    }

    task = TaskInclude(play=play).check_options(TaskInclude.load(good_options), good_options)
    assert task is not None
    assert task.args['file'] == good_options['file']

# Generated at 2022-06-23 07:20:05.453738
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    Verify the method accepts only the valid options and the others
    """
    valid_actions = C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    invalid_actions = C._ACTION_ALL_INCLUDE_EXCLUDE_TASKS
    invalid_options = ['optVal_1', 'optVal_2']

    for valid_action in valid_actions:
        # create test data with a valid action and two invalid options
        data = dict(action=valid_action, opt1=invalid_options[0], opt2=invalid_options[1])
        ti = TaskInclude()
        task = ti.check_options(ti.load_data(data), data)

        # check that the invalid options were removed from task.args

# Generated at 2022-06-23 07:20:17.520323
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class MyTask(Task):
        _task_fields = dict(
            x = FieldAttribute(isa='string', default=None, priority=1)
        )

    # 1. test x_value and y_value are direct descendants of task
    x_value = 'xyz'
    y_value = 'zzz'
    t = MyTask()
    t.x = x_value
    t.args = {'y': y_value}
    assert t.get_vars() == dict(x=x_value, y=y_value)

    # 2. test x_value is descendant of task, y_value is descendant of role
    x_value = 'xyz'
    y_value = 'zzz'
    t = MyTask()
    t._role = MagicMock()
    t.x = x_value


# Generated at 2022-06-23 07:20:23.445804
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import sys

    display.verbosity = 3
    ti = TaskInclude()

    assert ti.preprocess_data({}) == {}, \
        "Error with empty dictionary"

    # Change this assert when attributes will be added to be tested
    assert ti.preprocess_data({'action':'include_role'}) == {'action':'include_role'}, \
        "Error with action included in VALID_INCLUDE_KEYWORDS"

    # Changing sys.argv for not having warning displayed
    old_argv = sys.argv
    sys.argv = ['ansible-playbook', '-i', '/tmp/hosts']

# Generated at 2022-06-23 07:20:24.863425
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # TODO: Coverage for this method should be added to unit tests
    pass

# Generated at 2022-06-23 07:20:27.291190
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    assert TaskInclude('abc', 'abc')

if __name__ == '__main__':
    test_TaskInclude()

# Generated at 2022-06-23 07:20:38.164182
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ''' Unit test for method get_vars of class TaskInclude '''
    import ansible.playbook.task_include
    test_include = ansible.playbook.task_include.TaskInclude.load(
        {"name": "dummy", "action": "include", "args": {"foo": "baz", "bar": 1}},
        variable_manager=None, loader=None
    )
    assert test_include.get_vars() == {"foo": "baz", "bar": 1}
    test_include.register = 'scratch'
    assert test_include.get_vars() == {"foo": "baz", "bar": 1, "register": "scratch"}
    test_include.apply = {}

# Generated at 2022-06-23 07:20:44.965532
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    class TestTaskInclude(object):
        def __init__(self, name):
            self.name = name
            self.args = dict()

    task = TestTaskInclude('test')
    task.args = dict(a=1, b=2)
    new_task = task.copy()
    assert task is not new_task
    assert task.args is new_task.args
    assert task.args == new_task.args


# Generated at 2022-06-23 07:20:56.826773
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.playbook_include import TaskIncludeSpec
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-23 07:21:06.585719
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # create a dummy play
    play = {}
    # create a dummy display
    display = Display()
    display.verbosity = 6
    play.update({'display': display})
    # create a dummy block
    block = {}
    block.update({'_role': None})
    block.update({'_play': play})
    block.update({'_variable_manager': None})
    block.update({'_loader': None})

    # Check that a block is returned when apply is not present
    include = {}
    include.update({'args': {}})
    task = TaskInclude(block=block)
    task.args = include['args']
    result = task.build_parent_block()
    assert isinstance(result, Block)

    # Check that a block is returned when apply is present with the correct attributes
   

# Generated at 2022-06-23 07:21:15.742158
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.action = 'include'
    ti.vars = {'a': 1, 'b': 2}
    ti.args = {'x': 3, 'y': 4}
    ti._parent = Task()
    ti._parent.get_vars = lambda: {'c': 5, 'd': 6}

    r = ti.get_vars()
    assert r['a'] == 1
    assert r['b'] == 2
    assert r['c'] == 5
    assert r['d'] == 6
    assert r['x'] == 3
    assert r['y'] == 4
    assert len(r) == 6


# Generated at 2022-06-23 07:21:27.737946
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Since the method get_vars() of class TaskInclude() is overridden
    and contains complex logic, a unit test is necessary in order
    to detect regressions.
    '''
    # Data for the TaskInclude object
    data = {
        'action': 'include',
        'file': './my_tasks.yml',
        'with_items': 'my_items',
        'when': 'my_when',
        'tags': 'my_tags',
    }

    # Mock the _parent attribue of the TaskInclude object
    parent_data = {
        'name': 'Play',
        'vars': {'my_vars': 'my_value'},
    }
    parent_obj = Block.load(parent_data)

    # Mock the vars attribute of the TaskIn

# Generated at 2022-06-23 07:21:28.247639
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    pass

# Generated at 2022-06-23 07:21:35.058608
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders

    # Note: to ease testing, the loader is not used here, but this causes the
    #       method _get_parent_attribute to raise an Exception in case the
    #       attribute is not found in the object.
    loader, _, _ = get_all_plugin_loaders()

# Generated at 2022-06-23 07:21:41.204924
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude('include: file_with_vars', 'include')
    task.vars = {'ansible_ssh_user': 'irelx'}
    task.args = {'file': 'file_with_vars', 'tags': ['all']}
    assert task.get_vars() == {'ansible_ssh_user': 'irelx', 'file': 'file_with_vars'}


# Generated at 2022-06-23 07:21:49.224292
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    data = {}
    block = object()
    role = object()
    task_include = object()
    variable_manager = object()
    loader = object()

    t1 = TaskInclude.load(data, block, role, task_include, variable_manager, loader)

    # Test for constructor
    assert t1.action == 'include'
    assert t1.args == {'_raw_params': None}
    assert t1._parent == block
    assert t1._role == role
    assert t1._task_include == task_include
    assert t1._variable_manager == variable_manager
    assert t1._loader == loader
    assert t1._block == None
    assert t1._dep_chain == None
    assert t1.any_errors_fatal is None
    assert t1.always_run is None
   

# Generated at 2022-06-23 07:22:00.582785
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    def test_task_inclusion_raises_error_if_options_are_invalid():
        import io
        import yaml

        #using io.StringIO will not work as load() use its own 'read()' method
        stream = io.BytesIO(b"""
        - name: run this after
          command: /usr/bin/foo
          when: (k1 == 1)
        - name: run this before
          command: /usr/bin/bar
          when: (k1 == 2)
        """)
        data = yaml.safe_load(stream)

        task = TaskInclude(task_include=None)

        for action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS:
            for not_allowed_key in TaskInclude.OTHER_ARGS:
                d

# Generated at 2022-06-23 07:22:12.887538
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.task_include import TaskInclude

    # Create a block with a single task
    data = dict(
        action=dict(
            module='ping',
            args=dict(
                data='pong',
            ),
        )
    )
    block1 = Block.load(data, play=Play().load(dict(), variable_manager=VariableManager(), loader=None), task_include=None, role=None, variable_manager=VariableManager(), loader=None)
    task = block1.block[0]

# Generated at 2022-06-23 07:22:25.946212
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test if the method ``build_parent_block`` of class ``TaskInclude`` create
    a valid block object and return the correct value type.
    '''
    # examples of definition of TaskInclude.ARGS
    # ARGS = frozenset(('action', 'file', '_raw_params', 'apply'))
    # ARGS = frozenset(('action', 'include_role', '_raw_params', 'apply', 'static', 'collections'))

    # definition of TaskInclude.VALID_INCLUDE_KEYWORDS
    # VALID_INCLUDE_KEYWORDS = frozenset(('action', 'args', 'name', 'ignore_errors', 'tags', 'when', 'loop'))

    # examples of data dict passed to construction of the object

# Generated at 2022-06-23 07:22:39.057358
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    test_play = Play().load(
        dict(
            name="Test play",
            hosts='all',
            gather_facts='no',
            roles=[],
            tasks=[
                dict(
                    block=dict(
                        tasks=[
                            dict(
                                include="some_task.yml",
                                apply=dict(
                                    block=dict(
                                        tasks=[
                                            dict(debug=dict(msg="test task"))
                                        ]
                                    )
                                )
                            )
                        ]
                    ),
                )
            ]
        ),
        variable_manager=None,
        loader=None,
    )
    task

# Generated at 2022-06-23 07:22:41.803999
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Test for the statement:
    TaskInclude()
    '''

    TaskInclude()


# Generated at 2022-06-23 07:22:54.062541
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    '''
    Check if copy is working for TaskInclude class.
    '''
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    block = Block()
    task = Task()
    task._parent = block
    task._role = None
    task._play = Play().load(dict(name="myplay", hosts=['localhost']), variable_manager=None, loader=None)

    task_include = TaskInclude()
    task_include._parent = block
    task_include._role = None
    task_include._loader = None
    task_include._variable_manager = None
    task_include._play = None
   

# Generated at 2022-06-23 07:22:55.949707
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Create test object
    task_include = TaskInclude()
    task_include.statically_loaded = True
    result = task_include.copy()

    # Verify
    assert result is not task_include
    assert result.statically_loaded == True

# Generated at 2022-06-23 07:23:03.030276
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test for action not in 'include'
    task = TaskInclude()
    task.args = {'a': 1, 'b': 2}
    task.vars = {'c': 3}

    t_vars = task.get_vars()
    assert isinstance(t_vars, dict)
    assert t_vars == {'a': 1, 'b': 2, 'c': 3}

    # test for action in 'include'
    task2 = TaskInclude()
    task2.action = 'include'
    task2.args = {'a': 1, 'b': 2}
    task2.vars = {'c': 3}

    t_vars2 = task2.get_vars()
    assert isinstance(t_vars2, dict)

# Generated at 2022-06-23 07:23:16.455958
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Create a empty object and call copy
    ti = TaskInclude()
    ti_copy = ti.copy()

    # Verify that all attributes were copied
    assert ti is not ti_copy
    assert ti.action == ti_copy.action
    assert ti.args == ti_copy.args
    assert ti.always_run == ti_copy.always_run
    assert ti.any_errors_fatal == ti_copy.any_errors_fatal
    assert ti.block == ti_copy.block
    assert ti.connection == ti_copy.connection
    assert ti.delay == ti_copy.delay
    assert ti.delegate_to == ti_copy.delegate_to
    assert ti.deprecated == ti_copy.deprecated
    assert ti.deprecated_args == ti_copy.deprecated_args
    assert ti.dep

# Generated at 2022-06-23 07:23:21.568919
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():  # pylint: disable=too-many-locals
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = inventory.get_host('localhost')
    variable_manager = VariableManager(
        loader=loader,
        inventory=inventory
    )


# Generated at 2022-06-23 07:23:31.797128
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import sys
    import pprint
    import yaml
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task

    fake_loader_class = object()
    fake_variable_manager_class = object()
    fake_inventory_class = object()

    fake_playbook = object()

    fake_play = ansible.playbook.play.Play()
    fake_play.name = 'fake_play'
    fake_play._loader = fake_loader_class
    fake_play._variable_manager = fake_variable_manager_class
    fake_play._inventory = fake_inventory_class

    fake_vars = dict(a=1, b=2, c=3)

# Generated at 2022-06-23 07:23:42.938840
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'include': 'role_name'}
    ti = TaskInclude()
    result = ti.preprocess_data(ds)
    assert result['action'] == 'include'
    assert isinstance(result['args'], dict)
    assert result['args']['_raw_params'] == 'role_name'
    assert result['args']['_uses_delegate_to'] is False
    assert result['args']['_uses_become'] is False
    assert result['args']['_uses_vars'] is False
    assert result['args']['_uses_no_log'] is False
    assert result['args']['_delegate_to'] == '127.0.0.1'
    assert result['args']['_become'] is False

# Generated at 2022-06-23 07:23:49.733824
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    host = 'somehost'
    connection = 'someconnectiontype'
    play_source =  dict(
        name = "Ansible Play",
        hosts = host,
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{what_to_debug}}'))),
            dict(action=dict(module='debug', args=dict(msg='{{what_to_debug2}}')))
        ]
    )
    play = Play.load(play_source, variable_manager=VariableManager(), loader=None)
    block = play.compile()
    task_block = block.block
    task = task_

# Generated at 2022-06-23 07:23:55.756128
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.action = 'include'
    ti_copy = ti.copy()
    assert ti_copy.action == 'include'
    assert ti_copy.statically_loaded == False
    ti.statically_loaded = True
    ti_copy = ti.copy()
    assert ti_copy.statically_loaded == True
    assert ti_copy.action == 'include'


# Generated at 2022-06-23 07:24:02.715382
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    assert(ti.build_parent_block() == ti)

    ti = TaskInclude(args={'apply': {}})
    b = ti.build_parent_block()
    assert(b._parent is None)
    assert(b.block == [])
    assert(b.args == {})

    ti = TaskInclude(args={'apply': {'block': 'foo'}})
    b = ti.build_parent_block()
    assert(b._parent is None)
    assert(b.args == {})
    assert(b.block == 'foo')

    ti = TaskInclude(args={'apply': {'block': 'foo', 'bar': False, 'baz': True, 'a': 'b', 'c': 'd'}})
    b = ti.build_parent

# Generated at 2022-06-23 07:24:14.389868
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    action = u'include'
    task_include = TaskInclude()
    task_include.action = action

    # Check vars when action is not "include"
    vars = task_include.get_vars()
    assert vars == {}, 'TaskInclude.get_vars() should return an empty dict when action is not include'

    # Check vars when action is "include"
    task_include.action = u'include'
    task_include.vars = {u'b': 1}
    task_include.args = {u'a': 2}
    vars = task_include.get_vars()
    assert vars == {u'a': 2, u'b': 1}, 'TaskInclude.get_vars() should return vars with apply args when action is include'
    task_include.args

# Generated at 2022-06-23 07:24:26.232349
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.verbosity = 3
    task = \
    {
      'action': 'include',
      'args': {
        'file': 'foobar',
        'apply': {'tags': ['all']},
      }
    }

    task = TaskInclude.check_options(TaskInclude(), task, task)
    assert 'file' not in task.args
    assert task.args['_raw_params'] == 'foobar'
    assert 'apply' in task.args
    assert task.args['apply'] == {'tags': ['all']}

    task = \
    {
      'action': 'import_playbook',
      'args': {
        'file': 'foobar',
        'apply': {'tags': ['all']},
      }
    }


# Generated at 2022-06-23 07:24:29.907316
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude({})

# Generated at 2022-06-23 07:24:36.244557
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    block = Block()
    role = Sentinel()
    task_include = Sentinel()
    t = TaskInclude(block=block, role=role, task_include=task_include)
    assert t._block == block
    assert t._role == role
    assert t._task_include == task_include


# Generated at 2022-06-23 07:24:46.846085
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # file is deprecated, _raw_params is valid, the rest not
    task = Task()
    task.action = 'include'
    task.args['file'] = '/path/to/file'
    task.args['invalid'] = 'invalid'
    task.args['ignore_errors'] = True  # valid option
    task = ti.check_options(task, {})
    assert task.args['_raw_params'] == '/path/to/file'
    assert 'file' not in task.args
    assert 'invalid' not in task.args

    # no file
    task = Task()
    task.action = 'include'
    task.args['invalid'] = 'invalid'

# Generated at 2022-06-23 07:24:56.159981
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook_executor = PlaybookExecutor(
        playbooks=['./test/ansible/playbook/test_plays/test_task_include_constructor.yml'],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords={},
    )
    playbook_executor._tqm._stdout_callback = None
    playbook_executor.run()


# Generated at 2022-06-23 07:25:08.702745
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Creates a play book
    play_content = dict(
        name = 'My Play',
        hosts = 'localhost',
        gather_facts = 'no',
        vars = {
            'var_1': 'value_1',
            'var_2': 'value_2'
        },
        tasks = [
            {
                'include': 'main.yml vars=var_1=value_3',
                'tags': ['sometag'],
                'when': 'True',
                'apply': {
                    'block': []
                }
            }
        ]
    )

    play = Play().load(
        play_content,
        variable_manager=VariableManager(),
        loader=DataLoader()
    )

    include_task = play.get_tasks()[0]

    # Execute get

# Generated at 2022-06-23 07:25:18.687174
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude()
    data = dict(
        file = 'my_included_tasks.yml',
        name = 'included_task_1',
        register = 'my_included_task',
        ignore_errors = False,
        no_log = False,
        apply = dict(
            when = 'some_condition'
        ),
        run_once = True,
    )

    task = task.load(data)
    assert task.statically_loaded
    assert task.action == 'include'
    assert task.args['name'] == 'included_task_1'
    assert task.args['register'] == 'my_included_task'
    assert task.args['ignore_errors'] == False
    assert task.args['no_log'] == False

# Generated at 2022-06-23 07:25:28.408504
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import pytest
    import ansible.playbook.task_include
    # Construct a sample task_include that we expect will be returned by the load() method
    task_include = dict(
        action='include_role',
        file='template2.j2',
        apply={
            'block': [],
            'name': 'Kamal'
        },
        name='include_role [template2.j2]'
    )
    # Run load() method and compare it with expected result
    task = ansible.playbook.task_include.TaskInclude.load(task_include)
    assert task.args.get(
        'apply') == {
            'block': [],
            'name': 'Kamal'
        }, 'Load failed'

# Generated at 2022-06-23 07:25:39.310530
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    action = 'include'
    module_name = 'debug'
    args = {'msg': 'A test message'}
    task = TaskInclude(None)
    task.action = action
    task.args = args

    # Method copy() is called on objects of class Task and its subclasses.
    # For object of subclass TaskInclude, method copy()
    # calls method copy() of superclass then adds a new attribute
    # using a new property.

    # Method copy() exists in class Task
    # Note that method copy() of superclass Task calls method copy()
    # of superclass Base. Method copy() of class Base
    # is defined in the source code of Ansible
    assert hasattr(Task, 'copy')
    assert callable(getattr(Task, 'copy'))
    # Method copy() exists in class TaskInclude


# Generated at 2022-06-23 07:25:52.680752
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    A simple test to check the method TaskInclude.check_options
    '''
    task = Task()

    # Let's test apply (applies only to some actions)
    task.action = 'include'
    task.args = {'apply': {'test': 'test'}}

    try:
        TaskInclude.check_options(task, None)
        raise AssertionError("Should have thrown an error for include action")
    except AnsibleParserError:
        pass

    task.action = 'import_tasks'
    task.args = {'apply': {'test': 'test'}}

    try:
        TaskInclude.check_options(task, None)
    except AnsibleParserError:
        raise AssertionError("Should not have thrown an error for non include action")

    # Let's test -

# Generated at 2022-06-23 07:25:57.678009
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    # Init a task with 'import_tasks' action
    task = TaskInclude.load(
        dict(
            import_tasks='../tasks/mytasks.yml',
            name='Load mytasks'
        ),
        variable_manager=variable_manager,
        loader=loader
    )
    block = task.build_parent_block()
    play_context = PlayContext()
    # Init a parent block to allow access to the variable manager
    block.set_loader(loader)
    block.set_play_context(play_context)
    # The

# Generated at 2022-06-23 07:26:07.963028
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Setup
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    task = TaskInclude(block=block, role=role, task_include=task_include)

    # Test 1
    test_data_1 = {
        'action': 'include',
        'args': {
            'file': 'foo.yml',
            'apply': {
                'bar': 'baz'
            }
        }
    }
    test_task_1 = task.check_options(task.load_data(test_data_1, variable_manager=variable_manager, loader=loader), test_data_1)
    assert task == test_task_1
    assert test_task_1.args['_raw_params'] == 'foo.yml'