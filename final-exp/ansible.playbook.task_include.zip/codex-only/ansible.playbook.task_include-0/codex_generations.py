

# Generated at 2022-06-23 07:16:20.244371
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pb = TaskInclude.load({'include': 'foo.yml', 'some_vars': 'some_value'})
    assert pb.args['_raw_params'] == 'foo.yml'
    assert pb.action == 'include'
    assert pb.vars['some_vars'] == 'some_value'
    assert pb.get_vars() == {'some_vars': 'some_value'}

    # Test for attributes being used as extra vars in case of 'include' actions

# Generated at 2022-06-23 07:16:30.539891
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test the method with task of 'action:include'
    # Check the correct case
    task = TaskInclude(block=None, role=None, task_include=None)
    data = dict(
        action = 'include',
        ignore_errors = True,
        file = 'file_A',
        apply = dict(
            something = 'task_in_block'
        )
    )
    ret_task = task.check_options(task.load_data(data), data)
    assert ret_task is not None
    assert ret_task.args['ignore_errors'] == data['ignore_errors']
    assert ret_task.args['_raw_params'] == data['file']
    assert ret_task.args['apply'] == data['apply']
    # Check the error case
    # Check the error case1: check '

# Generated at 2022-06-23 07:16:36.426201
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude(block=Block(), role=None, task_include=None)
    ti.statically_loaded = True
    ti_copy = ti.copy(exclude_parent=False, exclude_tasks=False)
    assert ti.statically_loaded == ti_copy.statically_loaded

# Generated at 2022-06-23 07:16:41.060861
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    ti = TaskInclude()
    ti_dict = dict()
    ti_dict['action'] = "import_role"

    # Check if no attribute is accepted, method returns Sentinel
    ti_dict['test_attr'] = "test_value"
    assert ti.preprocess_data(ti_dict) == Sentinel

    # Check if attributes are accepted when action is import_playbook or import_role
    ti_dict['action'] = "import_playbook"
    for k in ("tags", "vars", "name", "ignore_errors", "run_once", "loop_with", "when"):
        ti_dict[k] = "test_value"
        assert ti.preprocess_data(ti_dict) == ti_dict
        del ti_dict[k]

    # Check if attributes are not accepted when action is include
    ti

# Generated at 2022-06-23 07:16:53.602761
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Check that TaskInclude.check_options blocks non-valid args
    task = TaskInclude()
    block = Block()
    task.set_loader(None)
    task._parent = block
    task.action = 'include'

    # Here's an invalid action
    task.args['action'] = 'invalid'
    with pytest.raises(AnsibleParserError):
        task.check_options(task, None)

    # Here's non-valid args
    task.args = {
        'action': 'include',
        'file': './file',
        'no_file': './file'
    }
    task.check_options(task, None)
    assert 'no_file' in task.args

    # Here's non-valid args

# Generated at 2022-06-23 07:17:00.905422
# Unit test for method copy of class TaskInclude

# Generated at 2022-06-23 07:17:10.483339
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Create both TaskInclude and HandlerTaskInclude
    from ansible.playbook.handlertaskinclude import HandlerTaskInclude
    ti = TaskInclude()
    hti = HandlerTaskInclude()

    # Create a task and add unsupported options
    task = Task()
    task.action = 'include_role'
    task.args = {'bad_option': 'foo', 'apply': 'foo'}

    # Validate invalid options
    ti.check_options(task, [])
    hti.check_options(task, [])

    # Validate invalid apply
    task.args['apply'] = 'foo'

# Generated at 2022-06-23 07:17:22.742017
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    TaskInclude: preprocess_data
    '''
    block = Block(play=None)

    # Test valid keywords
    task = TaskInclude(block, task_include=None)
    ds1 = dict(action='include_tasks', file='f1', name='n1', tags=['t1'], ignore_errors=True)
    d1 = task.preprocess_data(ds1)
    assert d1 == ds1

    # Test invalid keywords
    ds2 = dict(action='include_tasks', file='f1', name='n1', tags=['t1'], ignore_errors=True, bad_key='b1')

# Generated at 2022-06-23 07:17:26.631472
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task


# Generated at 2022-06-23 07:17:36.840533
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Set up data(s)
    ds_with_extra_kw = {'action': 'include', 'changed_when': 'always', 'when': 'always', 'other_arg': 'other_arg'}
    ds_with_correct_kw = {'action': 'include', 'when': 'always', 'vars': {'key': 'val'}}
    ds_with_args_as_sentinel = {'action': 'include', 'when': 'always', 'other_arg': Sentinel}
    ds_with_apply_in_args = {'action': 'include_role', 'when': 'always', 'apply': {'changed_when': 'always'}}

# Generated at 2022-06-23 07:17:47.510333
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block

    display.verbosity = 3
    options = ansible.utils.cmdline.common_options('test')
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.utils.vars.VariableManager()

    fake_loader = ansible.parsing.dataloader.DataLoader()
    fake_variable_manager = ansible.utils.vars.VariableManager()


# Generated at 2022-06-23 07:17:59.046630
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Purpose: check if the options on `include` task is properly checked.
        This unit-test is quite a simple one, since it only checks
        for "bad" options and ignores extra options, so it can be
        improved.
    '''
    # build a TaskInclude object, because the method is static
    ti = TaskInclude()

    # list of validations to test

# Generated at 2022-06-23 07:18:05.024731
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class TestTaskInclude(TaskInclude):
        VALID_INCLUDE_KEYWORDS = frozenset(('name', 'action'))

    with_action = TestTaskInclude()
    data = with_action.preprocess_data(dict(action='test', name='testline', x=1))
    assert data.keys() == ['action', 'name']

    without_action = TestTaskInclude()
    data = without_action.preprocess_data(dict(name='testline', x=1))
    assert data.keys() == ['name']

# Generated at 2022-06-23 07:18:10.488990
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # In the pre-validation phase, the data brought in by the task, for example 'file'
    # can be changed to '_raw_params'. We need to validate if this change really happened.
    task = TaskInclude()
    data = {'action': 'include', 'file': 'valid_file.yml'}
    my_task = task.check_options(task.load_data(data), data)
    assert my_task.args['_raw_params'] == 'valid_file.yml'
    assert 'file' not in my_task.args

    # If a task contains invalid options, we raise an exception
    data = {'action': 'include', 'file': 'file.yml', 'invalid': 'invalid_option'}
    with pytest.raises(AnsibleParserError):
        my_

# Generated at 2022-06-23 07:18:19.599030
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os
    from ansible.plugins.loader import action_loader

    class TestTask(Task):
        def __init__(self, action=None):
            self.action = action

    # to avoid lookup of action plugins
    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../../test/units/modules/test/'))

    def get_task_class(action):
        return TestTask(action)



# Generated at 2022-06-23 07:18:30.733581
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude

    play_context = PlayContext()
    play_context.become = True


# Generated at 2022-06-23 07:18:40.872540
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    attrs = dict(
        apply=dict(
            block={}
        )
    )

    apply_attrs_expected = attrs['apply'].copy()
    del apply_attrs_expected['block']

    dummy_play = dict(
        name='dummy_play'
    )

    dummy_role = dict(
        name='dummy_role',
        _role_path='./'
    )

    dummy_variable_manager = dict(
        options=dict(
            _variable_manager=None
        )
    )

    dummy_loader = dict(
        get_basedir=lambda x: '/',
        set_basedir=lambda x: None,
    )


# Generated at 2022-06-23 07:18:50.941540
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsKey
    from ansible.vars.hostvars import HostVarsUUIDKey

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved



# Generated at 2022-06-23 07:18:56.502312
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Initialize a task include and check that the attribute statically_loaded is equal to False
    T = TaskInclude()
    assert T.statically_loaded == False

    # Copy T and check that the attribute statically_loaded is equal to False
    T_copy = T.copy()
    assert T_copy.statically_loaded == False

    # Change the value of T attribute statically_loaded and check that the attribute statically_loaded is equal to True
    T.statically_loaded = True
    assert T.statically_loaded == True

    # Copy T and check that the attribute statically_loaded is equal to True
    T_copy = T.copy()
    assert T_copy.statically_loaded == True

# Generated at 2022-06-23 07:19:01.162032
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded is True
    assert ti is not new_ti

# Generated at 2022-06-23 07:19:05.865782
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-23 07:19:13.425157
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.action = 'include_role'
    ti.vars = dict(a='a')
    ti.args = dict(a='a', b='b')
    ti.tags = []
    ti.when = 'yes'
    expected = dict(a='a', b='b')
    ti.action = 'include'
    actual = ti.get_vars()
    assert expected == actual

# Generated at 2022-06-23 07:19:25.957812
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task as BaseTask

    b_args = dict(apply=dict(where='c', when=True))
    base_block = Block.load(dict(block=[]), play=Play().load(dict(name='default', connection='local', hosts=['localhost'], gather_facts='no'), variable_manager=None, loader=None))
    t = TaskInclude.load(dict(action='test', args=b_args), block=base_block, role=None, task_include=None, variable_manager=None, loader=None)
    t_copy = t.copy()

    assert t_copy == t
    assert t_copy._parent == t._parent
    assert isinstance(t_copy, TaskInclude)

# Generated at 2022-06-23 07:19:34.258096
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    task = TaskInclude.load({
        'include': 'playbook.yml',
        'tags': ['untagged'],
        'static': 4,
    }, loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-23 07:19:46.311590
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import os
    import yaml
    from ansible.playbook.play import Play as PPlay
    from ansible.playbook.play_context import PlayContext as PPlayContext
    from ansible.parsing.dataloader import DataLoader as Dataloader
    from ansible.vars.manager import VariableManager as VManager
    from ansible.inventory.manager import InventoryManager as IManager
    from ansible.utils.vars import combine_vars

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.inventory.host import Host

    ######################################################################
    # This shows how to use TaskInclude.load
    ######################################################################
    play_source = dict

# Generated at 2022-06-23 07:19:56.636783
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    """
    Constructor: TaskInclude(block=None, role=None, task_include=None)
    """
    # tests for function load()
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a new PlayContext
    # Create a new PlayContext
    c_play_context = PlayContext(vagrant_inventory=True)

    # Create a new Play

# Generated at 2022-06-23 07:20:07.711320
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''

    def load(data):
        ti = TaskInclude()
        return ti.load(data)

    # These tests assume that Task.load is working as expected

    # Test case: no file
    data = dict(action='include')
    with pytest.raises(AnsibleParserError):
        load(data)

    # Test case: no action
    data = dict(file='test')
    with pytest.raises(AnsibleParserError):
        load(data)

    # Test case: wrong action
    # Note we assume that Task.load(data) works as expected
    data = dict(action='import_playbook', file='test')
    with pytest.raises(AnsibleParserError):
        load(data)

   

# Generated at 2022-06-23 07:20:18.957998
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include_obj = TaskInclude()

    class DummyClass:
        def __init__(self, val):
            self.val = val

    dummy_obj = DummyClass(1)
    data = {'action': 'include', 'file': 'test.yml'}
    task_include_obj.check_options(dummy_obj, data)
    assert dummy_obj.val == {
        '_raw_params': 'test.yml',
        'apply': {},
    }

    apply_attrs = {
        'block': ['mytask'],
        'when': {'test': True}
    }

    data = {
        'action': 'include',
        'file': 'test.yml',
        'apply': apply_attrs
    }
    task_include_obj.check

# Generated at 2022-06-23 07:20:24.594789
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    attr = FieldAttribute(
        name='name',
        static=False,
        default=None,
        private=False,
        priority=FieldAttribute.DEFAULT_PRIORITY,
        always_post_validate=FieldAttribute.DEFAULT_ALWAYS_POST_VALIDATE
    )
    field1 = attr.field(attribute=attr, object=None, parents=[], validate_rules={}, fail_on_undefined=False)
    field2 = attr.field(attribute=attr, object=None, parents=[], validate_rules={}, fail_on_undefined=False)
    field3 = attr.field(attribute=attr, object=None, parents=[], validate_rules={}, fail_on_undefined=False)

    task_include1 = TaskInclude()

# Generated at 2022-06-23 07:20:34.312077
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block
    import ansible.playbook.task_include
    task = ansible.playbook.task_include.TaskInclude.check_options(
            ansible.playbook.task_include.TaskInclude(
                block=ansible.playbook.block.Block()),
                dict(action='include', file='foo'))
    assert task.args['_raw_params'] == "foo"
    assert 'file' not in task.args

    task = ansible.playbook.task_include.TaskInclude.check_options(
            ansible.playbook.task_include.TaskInclude(
                block=ansible.playbook.block.Block()),
                dict(action='import_tasks', file='foo'))
    assert task.args['_raw_params'] == "foo"

# Generated at 2022-06-23 07:20:42.020959
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test scenario: apply attributes, no parent block
    apply_attrs = {'attributes_set': True}
    ti = TaskInclude()
    ti.args = {'apply': apply_attrs}
    expected_result = apply_attrs
    actual_result = ti.build_parent_block()
    assert expected_result == actual_result, 'Test scenario "apply attributes, no parent block" failed'

    # Test scenario: apply attributes, parent block
    apply_attrs = {'attributes_set': True, 'block': []}
    ti = TaskInclude()
    p_block = apply_attrs
    ti._parent = p_block
    ti.args = {'apply': apply_attrs}
    expected_result = p_block
    actual_result = ti.build_parent_block()
    assert expected

# Generated at 2022-06-23 07:20:52.487455
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    # Check valid keys
    ds = { 'action': 'import_playbook', 'file': 'test', 'tags': 'tag1' }
    assert ds == ti.preprocess_data(ds)
    # Check invalid key
    ds = { 'action': 'import_playbook', 'file': 'test', 'tags': 'tag1', 'test': 'test' }
    if C.INVALID_TASK_ATTRIBUTE_FAILED:
        try:
            ti.preprocess_data(ds)
        except AnsibleParserError as e:
            assert "is not a valid attribute" in str(e)
    else:
        assert ds == ti.preprocess_data(ds)


# Generated at 2022-06-23 07:20:59.849792
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 07:21:08.318293
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # This is the data which is going to be loaded into the task
    my_data = {
        "action": "include_tasks",
        "file": "test_file",
        "debugger": "some_value",
        "args": "value_for_args",
        "name": "my_name",
    }

    # We define the task and its action as the one that does not allow 'name' option
    my_task = TaskInclude(task_include='task_include')
    my_task._role = 'role'
    my_task.action = 'include_role'

    with pytest.raises(AnsibleParserError) as excinfo:
        my_task.check_options(my_task.load_data(my_data), my_data)


# Generated at 2022-06-23 07:21:16.311042
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    # invalid action
    ti.action = 'invalid_action'
    ti.args = {'value': 'arg_value'}
    ti.vars = {'value': 'var_value'}

    # Valid task, no change
    data = dict(action='include', value='arg_value')
    task = ti.preprocess_data(data)
    assert task.get('value') == 'arg_value'
    assert task.get('action') == 'include'

    # Remove extra args
    data = dict(action='include', value='arg_value', invalid_arg=['value'])
    task = ti.preprocess_data(data)
    assert task.get('value') == 'arg_value'
    assert task.get('action') == 'include'

# Generated at 2022-06-23 07:21:27.934670
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class MyTask(TaskInclude):
        _apply = FieldAttribute(isa='dict')

        def __init__(self):
            self._apply = UnsafeProxy({})
            super(MyTask, self).__init__()

    d = dict(
        action='include',
        file=dict(a='a', b='b'),
        apply=dict(x='x', y='y'),
        args=dict(c='c', d='d'),
        no_log=False,
        register=None,
        run_once=False,
        name='test',
    )

    t = MyTask()

# Generated at 2022-06-23 07:21:37.256815
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    play_context.remote_addr = 'localhost'
    play_context.connection = 'local'
    play_context.port = 22
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

    include_task = TaskInclude()
    include_task._role = None

# Generated at 2022-06-23 07:21:47.660736
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    ds = {'action': 'include', 'foo': 'bar'}
    pds = task.preprocess_data(ds)
    assert len(ds) == len(pds)
    assert 'foo' in pds
    ds = {'action': 'include_role', 'foo': 'bar'}
    pds = task.preprocess_data(ds)
    assert len(ds) == len(pds)
    assert 'foo' in pds
    ds = {'action': 'import_role', 'foo': 'bar'}
    pds = task.preprocess_data(ds)
    assert len(ds) == len(pds)
    assert 'foo' in pds

# Generated at 2022-06-23 07:21:57.786927
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.role.definition

    block = ansible.playbook.block.Block()
    role = ansible.playbook.role.definition.RoleDefinition()
    task_include = TaskInclude()
    ti = TaskInclude.load({'action': 'include', 'block': block, 'role': role, 'task_include': task_include}, block=block, role=role, task_include=task_include)

    assert ti.args == {'_raw_params': '', 'block': block, 'role': role, 'task_include': task_include}
    assert ti._task_include == task_include


# Generated at 2022-06-23 07:22:10.341138
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    task = TaskInclude(block=Block())
    task.action = 'include_tasks'
    task.args = {'debugger': 'on', 'name': AnsibleUnicode('the task name'), 'task': 'a simple task'}
    action = action_loader.get(task.action, task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.preprocess_data(task.args)
    assert task.args == {'name': 'the task name'}

# Generated at 2022-06-23 07:22:16.706709
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Setup
    data = {
        'action': 'include',
        'file': 'a.yml',
        'apply': {
            'b': 'c',
        },
    }
    task = TaskInclude.load(data)

    # Verify
    assert task.action == 'include'
    assert task.args == {'_raw_params': 'a.yml', 'apply': {'b': 'c'}}
    assert task.statically_loaded is False


# Generated at 2022-06-23 07:22:26.291514
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    """
    Unit test for method load of class TaskInclude
    """
    action = "include_tasks"
    raw_params = "file.yml"
    apply_dict = {"serial": "50%"}
    data = {action: raw_params, "apply": apply_dict}

    task_include = TaskInclude()
    task = task_include.load(data)
    assert task._attributes[action].value == raw_params
    assert task.args['apply'] == apply_dict
    assert task.args['_raw_params'] == raw_params

# Generated at 2022-06-23 07:22:39.793195
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = Task(block=Block(), action="include_role")
    task.args = {"foo": "bar"}

    # success
    task.action = "include_role"
    assert task == ti.check_options(task, "fake")

    # invalid options - task.action not in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    task.action = "include_tasks"
    ti_task = ti.check_options(task, "fake")
    for k in ti.VALID_ARGS:
        assert k in ti_task.args

    # _raw_params is not set
    ti_task.args['_raw_params'] = None

# Generated at 2022-06-23 07:22:48.692058
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    taskinclude = TaskInclude()
    taskinclude.action = 'include'
    taskinclude.args = {"a": 1, "b": "2"}

    p = TaskInclude()
    p.vars = {"c": 3}
    taskinclude._parent = p

    # Test for 'include' action
    all_vars = taskinclude.get_vars()
    assert all_vars["a"] == 1
    assert all_vars["b"] == "2"
    assert all_vars["c"] == 3

    # Test for other actions
    taskinclude.action = 'debug'
    all_vars = taskinclude.get_vars()
    assert "a" not in all_vars
    assert "b" not in all_vars

    taskinclude.action = ''
    all_vars = taskinclude

# Generated at 2022-06-23 07:22:55.277333
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.yaml.objects import AnsibleMapping

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    from ansible.plugins.loader import action_loader

    from ansible.utils.sentinel import Sentinel
    class FakeSentinel(Sentinel):
        def __init__(self, value):
            super(FakeSentinel, self).__init__()
            self.value = value

    play = Play().load(dict(name='test', hosts=['localhost'], gather_facts='no',
                tasks=AnsibleMapping({'include_tasks': {'name': 'include file'}})), variable_manager=None, loader=None)
    play._role = FakeSentinel('role')
    play._variable_manager = FakeSentinel('variable_manager')

# Generated at 2022-06-23 07:23:02.799585
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import action_loader

    # create inventory manager with localhost
    inventory_manager = InventoryManager(
        loader=DataLoader(),
        sources=["localhost", "127.0.0.1"],
    )
    # create variable manager to use localhost variables
    variable_

# Generated at 2022-06-23 07:23:14.462794
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti1 = TaskInclude()
    ti2 = TaskInclude()
    ti2.statically_loaded = True
    ti1.action = 'include'
    ti1._attributes = {'foo':FieldAttribute(ti1, 1, 2)}
    ti2._attributes = {'bar':FieldAttribute(ti2, 1, 2)}
    ti3 = ti1.copy()
    assert ti3.action == 'include'
    assert len(ti3._attributes) == len(ti1._attributes)

    ti4 = ti2.copy()
    assert ti4.statically_loaded
    assert len(ti4._attributes) == len(ti2._attributes)

# Generated at 2022-06-23 07:23:27.425826
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    variable_manager = VariableManager()

    variable_manager.set_nonpersistent_facts(dict(
        foo='bar',
        bar='baz',
        baz='foo',
    ))

    play_context = PlayContext(
        variable_manager=variable_manager,
        loader=None,
    )

    task = TaskInclude()

    task._parent = type('', (), {})()
    task._parent.get_vars = lambda: dict(
        foo='parent_foo',
        bar='parent_bar',
        baz='parent_baz',
    )


# Generated at 2022-06-23 07:23:30.833169
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    """ tasks: - include: file.yml
        vars:
          a: b
    """
    ti = TaskInclude.load(dict(
        include='file.yml', vars=dict(a='b')
    ))
    ti.copy()  # should work without error

# Generated at 2022-06-23 07:23:42.306460
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude

    ds_ok_action = {
        'action': 'include',
        'name': 'test',
        'file': 'test.yml',
    }

    ds_ko_action = {
        'action': 'copy',
        'name': 'test',
        'file': 'test.yml',
    }

    ds_ok_keyword = {
        'action': 'include',
        'name': 'test',
        'file': 'test.yml',
        'tags': ['test'],
    }


# Generated at 2022-06-23 07:23:57.815460
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # import:
    import ansible.playbook.play_context
    from units.mock.loader import DictDataLoader

    def create_ti(loader, variable_manager, playbook, play):
        return TaskInclude.load(
            data={'action': 'include_role', 'name': 'include_role', '_role_path': '/dev/null'},
            block=play,
            loader=loader,
            variable_manager=variable_manager,
            role=playbook.get_role_definition('include_role'),
        )

    loader = DictDataLoader({})
    variable_manager = ansible.playbook.play_context.VariableManager()
    playbook = loader.load_from_file('/dev/null')
    play = playbook.get_plays()[0]

# Generated at 2022-06-23 07:24:03.654023
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import ansible.playbook

    p = Play().load({
        'name': 'taskinclude test',
        'hosts': 'all',
        'roles': [{'role': 'test'}],
        'tasks': [{
            'include': 'test',
            'ignore_errors': True,
            'apply': {
                'module': 'include_role',
                'name': 'test',
                'tags': ['foo', 'bar'],
                'when': 'true',
            },
        }],
    }, variable_manager=ansible.playbook.variable_manager.VariableManager(), loader=ansible.playbook.loader.Loader())
    b = Block

# Generated at 2022-06-23 07:24:14.785586
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TaskInclude._load_datas() returns a TaskInclude instance whose __class__ is Task
    # so we cannot test check_options() directly.
    # Use a mock in the test for now.
    # TODO: implement a test class for TaskInclude.load() which returns an instance of TaskInclude
    from mock import Mock
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play

    task_include = TaskInclude()
    task = Mock()
    task.action = 'include'
    task.args = {
        '_raw_params': None
    }
    task.action = 'include'
    task_include.check_options(task, {})

    task.action = 'include'

# Generated at 2022-06-23 07:24:27.017795
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-23 07:24:35.288121
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class MockedLoaderClass:
        pass

    class MockedVariableManagerClass:
        pass

    class MockedTaskClass:
        def __init__(self, block=None, role=None, task_include=None):
            pass

        def load_data(self, data, variable_manager=None, loader=None):
            return data

    class MockedBlockClass:
        def __init__(self, play=None, task_include=None, role=None,
                     variable_manager=None, loader=None):
            pass

    class MockedPlayClass:
        pass

    class MockedRoleClass:
        pass

    import pytest
    # Basic test
    obj = MockedTaskClass()
    block = obj
    role = obj
    task_include = obj
    loader = MockedLoaderClass()
    variable_manager

# Generated at 2022-06-23 07:24:46.206633
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import HandlerTaskInclude
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()


# Generated at 2022-06-23 07:24:58.183348
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    This function tests the method preprocess_data of the class TaskInclude
    '''
    ds = dict(action='include', name='foo', when='always')
    ti = TaskInclude(block=None, role=None, task_include=None)
    try:
        ti.preprocess_data(ds)
    except AnsibleParserError:
        # This is the expected result, since 'name' is not valid for TaskInclude
        pass
    else:
        # If we get here it means the error was not raised, which is not expected
        assert(False)
    ds = dict(action='include', file='foo', when='always')
    ti.preprocess_data(ds)
    # If we get here it means the error was raised, which is not expected
    assert(True)

# Generated at 2022-06-23 07:25:03.167993
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Construct a TaskInclude object without an associated block
    task = TaskInclude()

    # Construct a TaskInclude object with an associated block
    task = TaskInclude(block=Block())

    assert(isinstance(task, TaskInclude))

# Generated at 2022-06-23 07:25:09.976017
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # Ensure that validate_options method is called in TaskInclude.load to prevent regressions.
    m = TaskInclude()

    def meth_validate_options():
        raise Exception('Should not be called')

    m.check_options = meth_validate_options

    try:
        # m.load_data should call m.check_options
        m.load(dict(file='/etc/passwd', action='include'))
    except Exception:
        pass
    else:
        raise AssertionError('Load should have raised exception!')

# Generated at 2022-06-23 07:25:11.049424
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    pass


# Generated at 2022-06-23 07:25:13.774540
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t1 = TaskInclude()
    assert t1.block is None
    assert t1.role is None
    assert t1.task_include is None


# Generated at 2022-06-23 07:25:22.613739
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    display = Display()

    data = {}
    data['apply'] = {'listen': 'tcp'}
    data['block'] = []
    data['block'].append({'name': 'listen tcp', 'local_action': {'module': 'firewalld', 'args': {'immediate': True, 'permanent': True, 'zone': 'public', 'port': '8822', 'protocol': 'tcp'}}})

# Generated at 2022-06-23 07:25:28.465868
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.role.include as role_include

    ti = TaskInclude()

    # No file specified
    try:
        ti.load({})
        assert False, "Should have raised AnsibleParserError: No file specified for include"
    except AnsibleParserError as e:
        assert "No file specified for include" in str(e)

    # Unknown option
    try:
        ti.load({'file': '', 'unknown_option': ''})
        assert False, "Should have raised AnsibleParserError: Invalid options for include: unknown_option"
    except AnsibleParserError as e:
        assert "Invalid options for include: unknown_option" in str(e)

    # Bad 'apply' type

# Generated at 2022-06-23 07:25:39.343096
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    variable_manager = DummyVariableManager()
    loader = DummyLoader()
    ti = TaskInclude(variable_manager=variable_manager, loader=loader)

    # action is not in C._ACTION_INCLUDE (not an include task)
    ti.action = 'include_role'
    ti._parent = DummyParent(vars={'a': 1})  # _parent.get_vars() returns {'a': 1}
    ti.vars = {'b': 2}  # task.vars = {'b': 2}
    ti.args = {'c': 3}  # task.args = {'c': 3}
    assert ti.get_vars() == {'a': 1, 'b': 2, 'c': 3}

    # action is in C._ACTION_INCLUDE (include task

# Generated at 2022-06-23 07:25:52.680177
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # create task
    task = TaskInclude.load(data={'include': 'some.yml'}, variable_manager=None, loader=None)

    # "real" tasks have a name, so this is a good way to identify a TaskInclude object
    assert task.name is None
    assert 'some.yml' == task.args['_raw_params']
    assert task.delegate_to is None
    assert task.is_handler is False
    assert task.run_once is False
    assert task.any_errors_fatal is False
    assert task.action == 'include'
    # for this test, block is None, as it is not set
    assert task.block is None

    # create task with action as list (bug 17616)

# Generated at 2022-06-23 07:26:03.596093
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.extra_vars = play_context.reduced_vars

    host_vars = variable_manager.get_vars(host=inventory.get_host('localhost'))

# Generated at 2022-06-23 07:26:10.827752
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.block

    play_context = ansible.playbook.play_context.PlayContext()
    play_context.connection = 'local'
    play = ansible.playbook.play.Play().load({}, variable_manager=None, loader=None)
    block = ansible.playbook.block.Block().load({'name': 'foo'}, play=play, variable_manager=None, loader=None)

    task_include1 = TaskInclude(block=block).load({'action': 'include', 'file': 'bar', 'ignore_errors': True}, variable_manager=None, loader=None)

    assert {'file': 'bar', 'ignore_errors': True} == task_