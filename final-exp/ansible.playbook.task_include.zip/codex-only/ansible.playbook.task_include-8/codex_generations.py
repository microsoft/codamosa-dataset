

# Generated at 2022-06-23 07:16:14.725731
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Check the calls made to parent class `Task` in `load` method
    '''
    from unittest.mock import Mock

    mock_Task = Mock(return_value=Mock(Task))
    task_include = TaskInclude()

    with Mock(Task, 'load', mock_Task):
        task_include.load('data', 'block', 'role', 'task_include', 'variable_manager', 'loader')

        mock_Task.assert_called_with('data', 'block', 'role', 'task_include', 'variable_manager', 'loader')



# Generated at 2022-06-23 07:16:25.428557
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
        # Test valid args
        task = TaskInclude()

        # Test invalid arg
        invalid_arg_val = 'invalid_value'
        for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
            ds = dict(action=action, invalid_arg=invalid_arg_val)
            task = TaskInclude()
            try:
                task = task.check_options(TaskInclude.load_data(
                    ds, variable_manager=None, loader=None), ds)
                raise AssertionError('%s should have failed with "%s" but it did not'
                                     % (action, invalid_arg_val))
            except AnsibleParserError:
                pass

        # Test invalid arg for include action
        invalid_arg_val = 'invalid_value'
        ds

# Generated at 2022-06-23 07:16:31.607850
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                                   'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                                   'when'))

# Generated at 2022-06-23 07:16:35.153519
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    data = dict(
        name="dummy",
        action="include",
        file="/tmp/task_file.yml"
    )
    task = TaskInclude.load(data)
    task.static_vars = {"dummy_key": "dummy_value"}
    task.statically_loaded = True

    new_task = task.copy()
    assert task.static_vars == new_task.static_vars
    assert task.statically_loaded == new_task.statically_loaded
    assert task.block is new_task.block

# Generated at 2022-06-23 07:16:45.809217
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    basedir = '/etc/ansible'
    variable_manager = VariableManager()
    yaml_data = """
- include_role:
    apply:
      loop:
        - "{{ DOCKER_SWARMS }}"
        - "{{ DOCKER_SWARMS | map('extract', hostvars, 'ansible_host') | list }}"
      loop_control:
        loop_var: docker_swarm
    name: docker-swarm
    when: docker_swarm not in docker_swarms
"""

# Generated at 2022-06-23 07:16:53.645026
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class MockTaskInclude(TaskInclude):
        VALID_INCLUDE_KEYWORDS = frozenset(('action', 'foo'))

    ds1 = dict(action='include_tasks', foo=Sentinel)
    new_ds1 = MockTaskInclude.preprocess_data(ds1)
    assert new_ds1 == ds1

    ds2 = dict(action='include_tasks', bar='baz')
    new_ds2 = MockTaskInclude.preprocess_data(ds2)
    assert new_ds2 == dict(action='include_tasks', foo=Sentinel)

# Generated at 2022-06-23 07:16:58.170203
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    file_name = '/foo/bar.yml'
    data = {
        'include': file_name,
        'invalid_option': 'invalid_value',
    }
    ti = TaskInclude()

    preprocessed_data = ti.preprocess_data(data)
    assert preprocessed_data == {'include': file_name, '_raw_params': file_name}, "Preprocessed data is not the same as original"

# Generated at 2022-06-23 07:17:03.784741
# Unit test for constructor of class TaskInclude

# Generated at 2022-06-23 07:17:15.187329
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.role
    # Create a simple block
    apply_attrs = {'block':[]}

# Generated at 2022-06-23 07:17:17.908773
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    a = TaskInclude(None)
    b = a.copy()

    assert a.statically_loaded == b.statically_loaded

# Generated at 2022-06-23 07:17:30.769357
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # create dummy data
    data = dict(
        _raw_params='/path/to/file',
        action='include',
        name='task_include_task',
        apply=dict(
            block=list(
                dict(
                    action='debug',
                    msg='This is the message to debug',
                )
            ),
        ),
    )
    # create dummy task
    ti = TaskInclude()
    ti.load_data(data)

    # create dummy block, play and loader

# Generated at 2022-06-23 07:17:42.480879
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MockTaskInclude(TaskInclude):
        VALID_ARGS = TaskInclude.BASE.union({'valid_arg'})

    ti = MockTaskInclude()
    data = {'action': 'include', 'file': 'anything'}
    task = MockTaskInclude.load(data)
    valid_task = ti.check_options(task, data)

    assert data['file'] == valid_task.args['_raw_params']

    data = {'action': 'include', 'file': 'anything', 'valid_arg': 'anything', 'invalid_arg': 'anything'}
    task = MockTaskInclude.load(data)
    ti.check_options(task, data)


# Generated at 2022-06-23 07:17:45.256576
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task = TaskInclude()
    assert isinstance(task, TaskInclude)
    assert isinstance(task, Task)
    assert isinstance(task, Block)
    assert task.statically_loaded is False

# Generated at 2022-06-23 07:17:47.204832
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert ti

# Test case for TaskInclude.load

# Generated at 2022-06-23 07:17:54.684329
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play

    ti = TaskInclude(play=Play())
    ti.args = {'apply': {'block': {}}}
    parent_block = ti.build_parent_block()
    assert isinstance(parent_block, Block)
    assert parent_block.parent is None


# Make sure all fields are FieldAttribute's
assert all(
    (isinstance(value, FieldAttribute) for value in TaskInclude.__dict__.values())
)

# Generated at 2022-06-23 07:18:04.123377
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.action = 'include_tasks'
    ti.statically_loaded = True
    ti.args = {'file': 'some_file'}
    ti.vars = {'var_name': 'var_value'}
    ti._parent = 'parent'
    ti._role = 'role'
    ti._loader = 'loader'
    ti._variable_manager = 'variable_manager'

    ti_copy = ti.copy()

    assert ti_copy.action == 'include_tasks'
    assert ti_copy.statically_loaded == True
    assert ti_copy.args == {'file': 'some_file'}
    assert ti_copy.vars == {'var_name': 'var_value'}
    assert ti_copy._parent == 'parent'
    assert ti

# Generated at 2022-06-23 07:18:10.913216
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    import copy

    ti = TaskInclude()
    ti.statically_loaded = True
    assert ti.statically_loaded is True
    ti_copy = copy.copy(ti)
    assert type(ti_copy) == TaskInclude
    assert ti_copy.statically_loaded is True
    ti_deepcopy = copy.deepcopy(ti)
    assert type(ti_deepcopy) == TaskInclude
    assert ti_deepcopy.statically_loaded is True

# Generated at 2022-06-23 07:18:19.876255
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block()
    loader = DataLoader()
    variable_manager = VariableManager()

    # set up a task with an include statement and make sure
    data = dict(
        apply=dict(
            test="hello"
        ),
        file="test.yml"
    )
    task = TaskInclude.load(data, block, variable_manager=variable_manager, loader=loader)
    assert task.args["apply"] == {"test": "hello"}
    assert task.args["file"] == "test.yml"

    # check that we can't set apply with the wrong task type

# Generated at 2022-06-23 07:18:21.405632
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()


# Generated at 2022-06-23 07:18:31.677873
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    ti = TaskInclude()
    ti.statically_loaded = True
    ti.action = 'include'
    ti.args = { 'file': 'test.yml' }
    ti.block = 'all'
    ti.delegate_to = 'localhost'
    ti.loop = '{{ my_var }}'
    ti.loop_with_items = ['localhost']
    ti.loop_control = { 'loop_var': 'item' }
    ti.tags = ['test', 'include']
    ti.ignore_errors = False
    ti.notify = ['test_handler']
    ti.register = 'result'
    ti.when = 'somevar'
    ti.until = ['result|success']
    ti.run_once = True
    ti.any_errors_fatal = True
    ti.no_log

# Generated at 2022-06-23 07:18:41.490947
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # We need to create a temporary loader object as well as a task in order to call 'load_data'
    class Test():
        # Class 'Test' used to test the loader object so we can call the method 'load_data'
        def __init__(self):
            self.configured = False
            self.vars = dict()

        def _is_task(self, attr):
            return True

        def set_basedir(self, basedir):
            pass

        def path_dwim(self, basedir, given):
            if '_loader_unmocked' in given:
                return given
            elif '_loader_error' in given:
                raise AnsibleError('I do not want to be mocked')
            return 'mocked'


# Generated at 2022-06-23 07:18:47.550834
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test for method TaskInclude.preprocess_data
    '''
    my_task = TaskInclude()
    my_task.action = "include"
    my_data = dict(action="include", file="b.yml", debug_var="something")
    result = my_task.preprocess_data(my_data)
    assert "debug_var" not in result


# Generated at 2022-06-23 07:18:59.297884
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude.load(dict(action='include', args=dict(apply=dict())))
    p_block = task_include.build_parent_block()
    assert p_block.get_name() == '<apply>'
    assert len(p_block.block) == 0
    assert p_block._play is None
    assert p_block._role is None
    assert p_block._dep_chain == []
    assert p_block._parent is None
    assert p_block._role is None
    assert p_block._dep_chain == []
    assert p_block._notify is None
    assert p_block._rescue is None
    assert p_block._always is None
    assert p_block._loop is None
    assert p_block._loop_with is None
    assert p_block._retries

# Generated at 2022-06-23 07:19:09.111411
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.vars.manager

    # Create fake block
    block = ansible.playbook.block.Block()
    # Create fake play
    play = ansible.playbook.play.Play()
    play._included_file = '/some/path/some_name.yml'
    block._play = play
    block._role = ansible.playbook.role.Role()
    block._parent = block
    # Create fake vars manager
    var_manager = ansible.vars.manager.VariableManager()
    var_manager.set_nonpersistent_facts({'fact': 'some_value'})
    block._variable_manager = var_manager

# Generated at 2022-06-23 07:19:16.485680
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    block = Block()
    role = object()
    task_include = object()

    t = TaskInclude(block=block, role=role, task_include=task_include)

    assert t._parent == block
    assert t._role == role
    assert t._task_include == task_include

    assert t.statically_loaded == False

# Unit tests for 'check_options' of class TaskInclude

# Generated at 2022-06-23 07:19:28.439793
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Nothing much to test here but we want to make sure that
    all exception paths are tested and that we can load a
    valid 'include' task.
    '''
    task_data = dict(
        action='include',
        file='/path/to/file.yml'
    )
    ti = TaskInclude.load(task_data, None)
    assert ti.args['_raw_params'] == '/path/to/file.yml'

    task_data['action'] = 'import_playbook'
    bad_args = ['foo', 'bar', 'baz', 'foobar']
    for arg in bad_args:
        task_data[arg] = 'foo'

# Generated at 2022-06-23 07:19:41.211359
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    data = dict(
        action="include_role",
        name="test_name",
        tasks_from="test_tasks_from",
        vars_from="test_vars_from",
        collections="test_collections",
        no_log="test_no_log",
        debugger="test_debugger",
        loop="test_loop",
        loop_control="test_loop_control",
        loop_with="test_loop_with",
        apply="test_apply",
    )
    actual_data = task_include.preprocess_data(data)

# Generated at 2022-06-23 07:19:51.995804
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a top level block with a parent block containing two child blocks
    # The child blocks contain two attributes each
    # The top level block contains one attribute
    # Create a task_include object derived from Task and pass the top level block
    ti = TaskInclude()
    ti.action = 'include'
    ti.args = dict()

    block_1 = Block()
    block_1.vars = dict()
    block_1.vars['attr_1'] = 'val1'
    block_2 = Block()
    block_2.vars = dict()
    block_2.vars['attr_2'] = 'val2'
    blk = Block()
    blk.vars = dict()
    blk.vars['attr_3'] = 'val3'

# Generated at 2022-06-23 07:20:05.653164
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    test_TaskInclude_get_vars:
    We need to test that the get_vars method implements the override behavior correctly as
    it differs from the default task behavior when dealing with 'include' statements
    This tests the simple case of an include where the args are added to the task vars
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 07:20:16.382145
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task = TaskInclude()
    # no option at all
    data = dict(action='include')
    # no file specified
    task.load(data, loader=None, variable_manager=None)
    data = dict(action='include', file='playbooks/foo.yml')
    # normal case
    task.load(data, loader=None, variable_manager=None)
    # bad opts
    data['bad_opt'] = 'some_value'
    task.load(data, loader=None, variable_manager=None)
    # invalid apply
    data = dict(action='include', apply=[])
    task.load(data, loader=None, variable_manager=None)



# Generated at 2022-06-23 07:20:21.084992
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude(block=Block())
    task.action = 'include_role'
    task.vars = dict(x=1)
    task.args = dict(y=2)
    new_task = task.copy()
    assert new_task.action == 'include_role'
    assert new_task.vars == dict(x=1)
    assert new_task.args == dict(y=2)


# Generated at 2022-06-23 07:20:33.104945
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class TestTaskInclude(TaskInclude):
        def __init__(self):
            self._parent = "parent"
            self._role = None
            self._play = "play"
            self._variable_manager = "variable_manager"
            self._loader = "loader"

    test_TaskInclude = TestTaskInclude()
    test_TaskInclude.args = {'apply': {'name': 'name', 'ignore_errors': True}}
    assert test_TaskInclude.build_parent_block().get_name() == 'name'
    assert test_TaskInclude.build_parent_block().ignore_errors is True
    assert test_TaskInclude.args == {}

    test_TaskInclude.args = {'apply': {'block': ["block"]}}
    assert test_TaskInclude.build_parent_block

# Generated at 2022-06-23 07:20:41.333154
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert task_include.action == 'include'
    assert not task_include.statically_loaded
    assert task_include.block is None
    assert task_include.role is None
    assert task_include.tags == []
    assert task_include.when == []
    assert isinstance(task_include.tags, list)
    assert isinstance(task_include.when, list)
    assert task_include.loop is None
    assert task_include.run_once is False
    assert task_include.notify == []
    assert task_include.loop_control is None
    assert task_include.ignore_errors is False
    assert task_include.no_log is False
    assert task_include.register == []
    assert task_include.free_form is False

# Generated at 2022-06-23 07:20:52.447417
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test of method TaskInclude.get_vars()
    '''
    def check_vars(task, expected_vars):
        '''
        Internal helper function: run get_vars() and build dict of vars
        check that dict of vars matches expected values
        '''
        assert isinstance(task, TaskInclude)
        vars_dict = {}
        for v in task.get_vars():
            vars_dict[v.name] = v.value
        assert vars_dict == expected_vars

    # create a task with no parent, no vars, and no args
    task = TaskInclude()
    expected_vars = {}
    check_vars(task, expected_vars)

    # create a task with no parent, vars, and args
    task = Task

# Generated at 2022-06-23 07:20:59.822031
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    import re
    from ansible.plugins.loader import action_loader
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-23 07:21:03.867307
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude(block=None)
    ti.statically_loaded = True
    tc = ti.copy()
    assert tc.statically_loaded == True
    ti.statically_loaded = False
    tc = ti.copy()
    assert tc.statically_loaded == False

# Generated at 2022-06-23 07:21:10.296717
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = dict(
        a = 1,
        b = dict(
            c = 2,
            d = dict(
                e = 3,
            ),
        ),
        f = [4],
        g = [dict(h = 5)],
        i = dict(
            j = dict(
                k = dict(
                    l = 6,
                    m = dict(
                        n = 7,
                    ),
                ),
            ),
        ),
    )

    # Test with an action that should not cause exception
    for action in C._ACTION_HANDLER_INCLUDE_IMPORT_TASKS:
        ti = TaskInclude()
        ds['action'] = action
        real_ds = ti.preprocess_data(ds)

        assert None == ti._validate_action(real_ds)
       

# Generated at 2022-06-23 07:21:18.282175
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayData
    from ansible.playbook.block import Block
    import ansible.constants as C
    import ansible.template as template
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.plugins.loader import lookup_loader

    # Define Ansible environment
    loader = DataLoader()
    inv_data = [{"hostname": "test"}]
    inv_manager = InventoryManager(loader=loader, sources=['hosts', 'hosts.yml'])
    inv_

# Generated at 2022-06-23 07:21:20.640006
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude(block=None, role='role', task_include='task_include')
    assert ti._role == 'role'



# Generated at 2022-06-23 07:21:31.401609
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    parent_block = TaskInclude.load({'action': 'include_role', 'args': {'apply': {'block': []}}})
    block = parent_block.build_parent_block()
    assert type(parent_block) == TaskInclude
    assert type(block) == Block
    assert block.parent == parent_block

    parent_block = TaskInclude.load({'action': 'include_role'})
    block = parent_block.build_parent_block()
    assert type(parent_block) == TaskInclude
    assert type(block) == TaskInclude
    assert block == parent_block


# Generated at 2022-06-23 07:21:42.267569
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    # Init class TaskInclude
    task = TaskInclude()
    # Init vars of TaskInclude
    task.statically_loaded = True
    task._block = Block
    task.role = 'role'
    task.action = 'action'
    task.args = {'key':'value'}
    # Check getter 'name' of TaskInclude
    assert(task.name == 'action')
    # Init parent block of TaskInclude
    parent = TaskInclude()
    # Check that method get_vars work correct
    task._parent = parent
    assert(task.get_vars() == {'key': 'value'})

# Generated at 2022-06-23 07:21:48.320274
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.action = 'import_tasks'
    task_include.args = {
        'dummy_arg': 'dummy_val'
    }
    assert task_include.get_vars() == dict()

    task_include.action = 'include'
    assert task_include.get_vars() == {
        'dummy_arg': 'dummy_val'
    }

# Generated at 2022-06-23 07:21:58.093942
# Unit test for constructor of class TaskInclude
def test_TaskInclude():

    task = TaskInclude()

    assert task.action == 'include'
    assert set(task.args) == set(['_raw_params']), "args were: %s" % task.args
    assert task.has_triggered_handler and task.parent_role is None \
        and task.dynamic_block is None and task.static_block is None \
        and task.block is None and task.always_run is None and task.do_not_log is None \
        and task.notify is None and task.vars is None and task.ignore_errors is None



# Generated at 2022-06-23 07:22:06.675752
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.args = {'a': 1, 'b': 2, 'c': 3}

    # test with simple dict as apply
    p_block = ti._build_parent_block()
    assert p_block is ti
    assert len(ti.args) == 3
    assert 'a' in ti.args and 'b' in ti.args and 'c' in ti.args

    # test with dict with block element
    apply_attrs = {'block': 1}
    ti.args = {'apply': apply_attrs}
    p_block = ti._build_parent_block()
    assert isinstance(p_block, Block)
    assert len(p_block.args) == 1
    assert 'block' in p_block.args

# Generated at 2022-06-23 07:22:18.082393
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    from ansible.playbook.block import Block

    t = TaskInclude()
    # t.__init__()
    t.action = 'include'
    t.args = {'tasks': '/some/path'}
    # t.copy()
    t.statically_loaded = True

    assert t.action == 'include'
    assert t.args['tasks'] == '/some/path'
    assert t.statically_loaded is True

    t2 = t.copy()

    t2.action = 'include_role'
    t2.args['tasks'] = '/some/other/path'
    t2.statically_loaded = False

    assert t.action == 'include'
    assert t.args['tasks'] == '/some/path'
    assert t.statically_loaded is True
    assert t

# Generated at 2022-06-23 07:22:29.752845
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    ti._validate_loop = lambda c: True
    task = ti.check_options({'action': 'include', 'file': 'x', 'apply': {'a': 'b'}}, 'raw data')
    assert task.args == {'apply': {'a': 'b'}, '_raw_params': 'x'}

    task = ti.check_options({'action': 'import_playbook', 'file': 'x', 'apply': {'a': 'b'}}, 'raw data')
    assert task.args == {'_raw_params': 'x'}

    task = ti.check_options({'action': 'include', 'file': 'x', 'apply': 'b'}, 'raw data')

# Generated at 2022-06-23 07:22:41.804193
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_block = Block(Block(parent_block=None, role=None), task_include=None)
    task_include = TaskInclude(block=task_block, role=None, task_include=None)

    # block_data must be a dict basing on the implementation of function preprocess_data
    block_data = dict()
    # Test case 1: action is include
    block_data['action'] = 'include_role'
    # Test case 2: action is include_role
    # block_data['action'] = 'include_role'
    # Test case 3: action is not include nor include_role
    # block_data['action'] = 'include'

    # Test case 4: ds does not contain any invalid key
    ds = dict()
    ds['debugger'] = 'off'

# Generated at 2022-06-23 07:22:45.557529
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()

    data = dict(param1=42, param2=dict(attr='attr_value'))
    new_data = task.preprocess_data(data)

    assert set(new_data.keys()) == set(data.keys())

# Generated at 2022-06-23 07:22:58.138835
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude(block=None, role=None, task_include=None)
    task_copy = task.copy(True, True)
    assert task_copy.statically_loaded == task.statically_loaded
    assert task_copy._attributes == task._attributes
    assert task_copy.action == task.action
    assert task_copy.any_errors_fatal == task.any_errors_fatal
    assert task_copy.args == task.args
    task = TaskInclude(block=True, role='role', task_include='include')
    task_copy = task.copy(True, True)
    assert task_copy.statically_loaded == task.statically_loaded
    assert task_copy._attributes == task._attributes
    assert task_copy.action == task.action
    assert task_copy

# Generated at 2022-06-23 07:23:09.261772
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Test the case when apply is not specified
    ti = TaskInclude()
    task = Task()
    task.action = 'include_role'
    task.args = dict(name='common')
    task.apply_defaults()
    t2 = ti.check_options(task, {"action": "include_role"})
    assert t2 is not None and t2.action == task.action and t2.args == dict(name='common')

    # Test the case when apply is specified
    task.args = dict(name='common', apply={"test": "test arg"})
    task.apply_defaults()
    t2 = ti.check_options(task, {"action": "include_role"})
    assert t2

# Generated at 2022-06-23 07:23:19.726818
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Given a task_include object
    task_include = TaskInclude()
    task_include.block = Block()
    task_include._loader = None
    task_include._variable_manager = None
    # And a data structure
    data = {
        'action': 'include_tasks',
        'args': {
            'file': 'relative/path/to/a/role/tasks/main.yaml'
        }
    }
    # When I load data into the task_include
    task = task_include.load(data)
    # Then action is included in the task
    assert task.action == 'include_tasks', "Action attribute not loaded for the task"
    # And args are included in the task
    assert 'file' in task.args, "Args attributes not loaded for the task"
    assert task.args

# Generated at 2022-06-23 07:23:23.497342
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert isinstance(task_include, TaskInclude)
    assert isinstance(task_include, Task)
    assert isinstance(task_include, Block)


# Generated at 2022-06-23 07:23:27.282554
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    task = TaskInclude()
    assert task._parent == None
    task._parent = "test"
    assert task._parent == "test"
    task2 = task.copy(exclude_parent=True)
    assert task2._parent == None

# Generated at 2022-06-23 07:23:34.955150
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class play:
        def __init__(self, vars):
            self.vars = vars

    class role:
        def __init__(self, vars):
            self.vars = vars

    class task:
        def __init__(self):
            self._task = Task()

    def _assert(action, all_vars, vars):
        t = TaskInclude()
        t.action = action

        t._parent = play(all_vars['_parent'])
        t._role = role(all_vars['_role'])
        t.vars = all_vars['vars']
        t._task = task()
        t.args = all_vars['args']

        assert t.get_vars() == vars

    # Basic include

# Generated at 2022-06-23 07:23:44.416599
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude

    play_context = PlayContext()

# Generated at 2022-06-23 07:23:50.349967
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # initialize a task include with "apply:" and "vars"
    the_task_include = TaskInclude.load({
        'action': 'include',
        'args': {
            'apply': {
                'vars': {
                    'x': 1,
                    'y': 10,
                },
            },
        },
    })
    # initialize a task to be contained in the task include's parent block
    the_task = Task.load(
        {
            'action': 'some_module',
            'args': {
                'a1': 'b1',
                'a2': 'b2',
            },
        },
    )
    p_block = the_task_include.build_parent_block()
    p_block.block.append(the_task)
    # check if the task's vars contain

# Generated at 2022-06-23 07:24:00.127843
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.block import Block

    passphrase = b'hunter2'
    vault = VaultLib(passphrase)
    raw2 = vault.encrypt(b'bar')
    my_block = Block()
    my_block.vault_password = passphrase
    my_block.parent = my_block

    # All good
    all_good = {
        'action': 'include_role',
        '_raw_params': b"foo.yml",
        'name': 'foo',
        'ignore_errors': False,
        'tags': ['foo'],
        'register': 'foo',
        'run_once': True,
        'when': 'bar',
    }

# Generated at 2022-06-23 07:24:07.813899
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 07:24:10.355524
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert isinstance(task_include, Task)
    assert task_include.statically_loaded is False

# Generated at 2022-06-23 07:24:22.255521
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Testing the return of method build_parent_block
    of class TaskInclude
    '''
    import unittest
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    class BlockTest(unittest.TestCase):

        def setUp(self):
            block_data = dict(
                block=dict(
                    tasks=[
                        dict(
                            include=dict(
                                action='some-action',
                                file='some-file'
                            ),
                        ),
                    ]
                ),
            )
            self.block = Block.load(block_data)


# Generated at 2022-06-23 07:24:31.647121
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Setup test fixture
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_ds = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    # Use the objects

# Generated at 2022-06-23 07:24:43.978026
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import os.path
    import ansible.utils.unsafe_proxy
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.handler

    # Setup
    test_file = "/tmp/test_file"
    setup_file(test_file)

# Generated at 2022-06-23 07:24:54.336578
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    load_me = {
        'action': 'include',
        'file': 'test.yml'
    }

    task = TaskInclude.load(load_me)
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args['ignore_errors'] == False
    assert task.args['apply'] == {}
    
    load_me = {
        'action': 'include',
        'file': 'test.yml',
        'apply': { 'loop': 'hosts'}
    }

    task = TaskInclude.load(load_me)
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'test.yml'
    assert task.args['ignore_errors'] == False

# Generated at 2022-06-23 07:25:04.737510
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    test_action = 'include_tasks'
    test_args = {'apply': {'block': []}, 'file': 'test.yml'}
    test_task = TaskInclude(action=test_action, args=test_args)
    test_task.statically_loaded = True
    new_task = test_task.copy()

    assert new_task.action == test_action
    assert new_task.args == test_args
    assert new_task.statically_loaded == True

# Generated at 2022-06-23 07:25:16.793593
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext

    def _create_included_task(args):
        # Create a task
        task_args = {'action': 'include', 'args': args}
        task_include = TaskInclude.load(task_args)

        # Create a block
        block_args = {'block': [task_include]}
        block = Block.load(block_args)

        # Create a play
        play_context = PlayContext()
        play_args = dict(
            name='Test Play',
            hosts='all'
            )

# Generated at 2022-06-23 07:25:27.987606
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()

    task_include._parent = _mock_task()
    task_include._parent._parent = _mock_play()

    # Test the default
    assert task_include.get_vars() == {'x': 'y', 'color': 'blue'}

    # Test for action include
    task_include.args = {'a': 'b'}
    task_include.action = 'include'
    assert task_include.get_vars() == {'a': 'b', 'x': 'y', 'color': 'blue'}

    # Test for action import_playbook
    task_include.args = {'a': 'b'}
    task_include.action = 'import_playbook'

# Generated at 2022-06-23 07:25:29.681452
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    print('Testing constructor of class TaskInclude...')

    ti = TaskInclude()

# Generated at 2022-06-23 07:25:41.698060
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    display.verbosity = 2  # needed for tests, as cli options aren't parsed

    ti = TaskInclude()
    ti.action = 'include_role'

    ds_static = dict(action='include_role', name='my.role', static=True)
    ds_dynamic = dict(action='include_role', name='{{ my_role }}')
    ds_static_with_invalid_arg = dict(action='include_role', name='my.role', static=True, invalid=True)
    ds_dynamic_with_invalid_arg = dict(action='include_role', name='my.role', invalid=True)

    assert sorted(ti.preprocess_data(ds_static).keys()) == sorted(list(ti.VALID_INCLUDE_KEYWORDS))

# Generated at 2022-06-23 07:25:46.489289
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager())

    attrs = {
        '_raw_params': 'somefile',
        'tags': [],
        'when': [],
    }

    data = {
        u'include': u'somefile',
        u'tags': [],
        u'when': [],
    }

    task = TaskInclude.load(data, task_include=None)
    assert task.args == attrs
    assert task.action == u'include'
    assert task.action == u'include'
    assert task.name == None

    data[u'name'] = u

# Generated at 2022-06-23 07:25:57.042672
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    p_play_context = PlayContext()
    p_variables = dict(a=1)
    p_block = Block(play=None, parent_block=None, role=None, task_include=None, use_handlers=None, always_run=None, any_errors_fatal=None, ignore_errors=None, serial=None, rescue=None, finally_=None, notify=None, environment=None, no_log=None, when=None, _role=None, vars=p_variables)
    p_block.update_vars(p_play_context)

    t_variables = dict(b=2)

# Generated at 2022-06-23 07:26:05.128004
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # set up TaskInclude object
    ti = TaskInclude()
    ti.args = {'x': 1, 'y': 2}
    ti.action = 'include'
    # test
    assert ti.get_vars() == {'x': 1, 'y': 2}
    # set up TaskInclude object
    ti = TaskInclude()
    ti.action = 'import_role'
    ti.vars = {'z': 3}
    # test
    assert ti.get_vars() == {'z': 3}