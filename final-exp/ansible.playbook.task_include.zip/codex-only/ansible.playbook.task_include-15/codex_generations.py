

# Generated at 2022-06-23 07:16:18.990354
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Method build_parent_block creates parent block when apply-type is specified
    ti = TaskInclude()

    # Set values for testing
    ti.args = {
        "apply": {
            "_lineage": [
                "tasks/main.yml"
            ],
            "when": "x == 1",
            "tags": [
                "tag1"
            ]
        }
    }

    # Method
    p_block = ti.build_parent_block()

    # Assertions
    assert p_block.has_parent() == False
    assert p_block.always_run == False
    assert p_block._lineage == None
    assert p_block.when == "x == 1"
    assert p_block.tags == ["tag1"]
    assert p_block._role == None
    assert p_

# Generated at 2022-06-23 07:16:29.436384
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # Test constructor of TaskInclude
    import ansible.playbook.play
    import ansible.inventory.host
    import ansible.inventory.group

    host = ansible.inventory.host.Host(name="test-host")
    group = ansible.inventory.group.Group(name="test-group")
    host.set_variable("foo", "bar")
    group.set_variable("foo", "baz")
    host.add_group(group)

    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{foo}}'))),
        ]
    )


# Generated at 2022-06-23 07:16:42.229967
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.play_context import PlayContext

    yaml_data = '''
    - name: test task include
      include: apache
      when: not foo
      tags:
      - foo
      - bar
    '''

    my_task = TaskInclude.load(yaml_data)

    assert( isinstance(my_task, TaskInclude) )
    assert( my_task._parent is None )
    assert( my_task._block is None )
    assert( my_task.name == 'test task include' )
    assert( my_task.tags == ['foo', 'bar'] )
    assert( my_task.when == 'not foo' )
    assert( my_task.loop == None )

# Generated at 2022-06-23 07:16:54.750688
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    BASE_CLASS_ARGS = ('block', 'role', 'task_include', '_variable_manager', 'loader')
    BASE_ATTRS = {
        '_role': None,
        '_parent': None,
        '_play': Base(),
        '_loader': DataLoader(),
        '_dep_chain': set(),
        '_variable_manager': VariableManager(host_list=[], inventory=InventoryManager('localhost')),
    }

    # Define raw data for tests

# Generated at 2022-06-23 07:17:01.941232
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude.load({'action': 'include_role', 'name': 'copy', 'apply': {'a': 'b'}})
    assert task.args.get('apply')
    try:
        task = TaskInclude.load({'action': 'include', 'name': 'copy', 'apply': {'a': 'b'}})
    except AnsibleParserError:
        pass
    else:
        assert False, "Failed to raise exception on unknown option 'apply'"


# Generated at 2022-06-23 07:17:13.012521
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_cls
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    variable_manager = InventoryManager(loader=loader, sources='')
    variable_manager.extra_vars = load_fixture('include_parent_vars.json')

    p = IncludedFile(loader.load_from_file('tests/fixtures/playbook1.yml'))


# Generated at 2022-06-23 07:17:19.549229
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    field = FieldAttribute(1, 2)

    ti = TaskInclude(block=field, role='role1', task_include='task_include1')

    assert isinstance(ti, TaskInclude)
    assert isinstance(ti.block, FieldAttribute)
    assert ti.block.private == 1
    assert ti.block.public == 2
    assert ti.role == 'role1'
    assert ti.task_include == 'task_include1'
    assert ti.statically_loaded == False


# Generated at 2022-06-23 07:17:31.778818
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    test_data_root = os.path.dirname(os.path.dirname(__file__))
    playbook_path = os.path.join(test_data_root, 'ansible', 'playbook', 'playbook_syntax_validate_include.yml')
    playbook = ansible.playbook.play.Play.load(
        playbook_path,
        variable_manager=VariableManager(),
        loader=DataLoader(),
        inventory=InventoryManager(loader=DataLoader(), sources=[]),
    )



# Generated at 2022-06-23 07:17:36.670891
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # test to make sure we don't completely lose our minds when making
    # this object, though we do need to set loader and variable_manager
    # before doing any work with it
    try:
        task=TaskInclude(None)
    except Exception as e:
        print(e)
        raise

# Generated at 2022-06-23 07:17:47.371349
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    o_ds = {
        'broken': True,
        'action': 'include_tasks',
        '_raw_params': 'statically-loaded',
        'static': True,
        'ignore_errors': True,
        'tags': ['tags-present'],
        'when': 'dynamic',
        'args': {'_raw_params': 'dynamically-loaded'},
    }
    ti = TaskInclude()
    ds = ti.preprocess_data(o_ds)

# Generated at 2022-06-23 07:17:59.046631
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    playbook = Playbook()
    t1 = TaskInclude.load({'action': 'include', 'file': 'foo'}, block=Block(), role=None, play=Play())
    t2 = t1.copy()
    assert t1.task_include == t2.task_include
    assert t1.action != t2.action
    assert t1.name != t2.name
    assert t1.tags != t2.tags
    assert t1.when != t2.when
    assert t1.loop != t2.loop
    assert t1.notify != t2.notify
    assert t1.meta != t2.meta
    assert t1.vars != t2.vars
    assert t1

# Generated at 2022-06-23 07:18:09.657524
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Cases for method check_options of class TaskInclude
    # Case 1: No file specified for include
    data = {'action': 'include',
            'name': 'include'}
    task = TaskInclude()
    try:
        task.check_options(task, data)
    except Exception as e:
        assert type(e) == AnsibleParserError
        assert str(e) == 'No file specified for include'

    # Case 2: Invalid options for include
    data = {'action': 'include',
            'name': 'include',
            'file': 'file.yml',
            'bad_option': 'bad_option'}
    task = TaskInclude()
    try:
        task.check_options(task, data)
    except Exception as e:
        assert type(e) == AnsibleParserError


# Generated at 2022-06-23 07:18:20.516900
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.utils.vars import combine_vars

    block = Block()
    role = Role()
    task = TaskInclude(block=block, role=role)

    assert block == task._parent
    assert role == task._role

    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [dict()]
    ), variable_manager=None, loader=None)
    variation = play.get_variable_manager()

    play_context = PlayContext()
    play_context._task_v

# Generated at 2022-06-23 07:18:31.257674
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for TaskInclude.check_options
    '''
    from ansible import utils
    variable_manager = utils.VariableManager()
    loader = utils.PluginLoader(
        '',
        '',
        variable_manager=variable_manager,
    )
    # Test validations for - include: ...
    for action in C._ACTION_INCLUDE:
        data = {'action': action}
        assert TaskInclude.check_options(TaskInclude(task_include=True), data).args['_raw_params'] == None
        data = {'action': action, 'file': 'test.yml'}
        assert TaskInclude.check_options(TaskInclude(task_include=True), data).args['_raw_params'] == 'test.yml'

# Generated at 2022-06-23 07:18:41.230229
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(
        include=dict(
            file="file",
        ),
    )
    ti = TaskInclude()
    ti.preprocess_data(data['include'])

    data = dict(
        include_role=dict(
            file="file",
        ),
    )
    ti = TaskInclude()
    ti.preprocess_data(data['include_role'])

    data = dict(
        include_tasks=dict(
            file="file",
        ),
    )
    ti = TaskInclude()
    ti.preprocess_data(data['include_tasks'])

    data = dict(
        import_playbook=dict(
            file="file",
        ),
    )
    ti = TaskInclude()
    ti.preprocess_data(data['import_playbook'])

# Generated at 2022-06-23 07:18:51.192435
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create a dictionary with all valid keywords
    valid_kw = TaskInclude.VALID_INCLUDE_KEYWORDS
    attributes = {x: "val_%s" % x for x in valid_kw}

    # Create a TaskInclude object to call preprocess_data
    block = Block(loader=None, role=None, play=None, task_include=None, use_handlers=False)
    task = TaskInclude(block=block)

    # Test that the dictionary is left unchanged when using a static include
    attributes['include'] = "something"
    assert(task.preprocess_data(attributes) == attributes)

    # Test that only valid keywords for static include are kept
    attributes['include'] = "something"
    attributes['one_extra_key'] = "one_extra_val"

# Generated at 2022-06-23 07:19:00.973570
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestPlay(Play):
        pass

    class TestPlay2(Play):
        pass

    class TestTaskInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            super(TestTaskInclude, self).__init__(*args, **kwargs)
            self.statically_loaded = True

    class TestBlock(Block):
        pass

    class TestBlock2(Block):
        pass

    loader = DictDataLoader

# Generated at 2022-06-23 07:19:10.223438
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Create a task include for action 'include'
    include_task = TaskInclude.load(dict(action='include', file='/test/file', foo='bar'))
    # Check params passed to the included tasks are present in the resulting dict
    assert 'foo' in include_task.get_vars()
    assert 'file' not in include_task.get_vars()

    # Create a task include for action 'include_role'
    include_role_task = TaskInclude.load(dict(action='include_role', file='/test/file', foo='bar'))
    # Check params passed to the included tasks are NOT present in the resulting dict
    assert 'foo' not in include_role_task.get_vars()
    assert 'file' not in include_role_task.get_vars()


# Generated at 2022-06-23 07:19:21.739940
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    # create a temporary file in the oldest way possible
    import tempfile
    import os
    # Get a temporary file name from the OS
    temp_file_name = tempfile.NamedTemporaryFile(delete=False).name
    temp_file = open(temp_file_name, 'w')
    temp_file.write('[]')
    temp_file.close()
    # Create a variable manager
    variable_manager = VariableManager()
    # Create play
    play = Play.load(
        temp_file_name,
        variable_manager=variable_manager,
        loader=None
    )

    ti = TaskInclude(block=play, task_include=None)
    assert isinstance(ti, TaskInclude)

# Generated at 2022-06-23 07:19:30.355544
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # arguments used by method
    ds = {'include': '', 'vars': {}}
    data = {'name': '', 'action': 'include', 'include': '', 'vars': {}}

    # mocks
    class MockTaskInclude(TaskInclude):
        def __init__(self):
            self.VALID_INCLUDE_KEYWORDS = frozenset(('include',))

    mock_task_include = MockTaskInclude()

    # tests
    assert mock_task_include.preprocess_data(ds) == data

# Generated at 2022-06-23 07:19:41.420822
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude(block=None, role=None, task_include=None)
    task.action = 'include'
    task.args = {'x': 1}
    block = Block(block=None, role=None, task_include=None)
    play = Block(block=None, role=None, task_include=None)
    block._parent = play
    task._parent = block
    block._play = play
    play._role = None
    task.vars = {'y': 1}
    all_vars = task.get_vars()
    assert all_vars['x'] == 1
    assert all_vars['y'] == 1

# Generated at 2022-06-23 07:19:52.183296
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Setup
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a context
    loader = None
    variable_manager = VariableManager()
    play_context = PlayContext()
    play = Play().load({
        "name": "foobar",
        "hosts": "all",
    }, variable_manager=variable_manager, loader=loader)
    tqm = TaskQueueManager(inventory=None, variable_manager=variable_manager, loader=loader,
                           passwords=None, stdout_callback=None, run_tree=False)

    # Create the include

# Generated at 2022-06-23 07:20:05.772817
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.vars
    import ansible.playbook.role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    test_block = Block()
    test_block.vars = {'test_block_var': 'test_block_value'}
    test_block._parent = None
    test_block._role = None
    test_block._play = None
    test_block._loader = None
    test_block._variable_manager = None

    test_task = Task()
    test_task._parent = test_block
    test_task._role = None
    test_task._play = None
    test_task._loader = None
    test_task._variable_manager = None

# Generated at 2022-06-23 07:20:10.765307
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    s = 'class TaskInclude:\n  def __init__(self, block=None, role=None, task_include=None):'
    d = str(ti.__init__)
    assert d == str(ti.__init__)

# Generated at 2022-06-23 07:20:20.889199
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    def test_error(description, data, expected_error_message):
        try:
            task = TaskInclude.load(data, task_include=Sentinel(name='task_include'))
            raise Exception('In test "{0}", expected an exception but did not get one'.format(description))
        except AnsibleParserError as e:
            assert e.message == expected_error_message

    # valid options
    task = TaskInclude.load({
        'file': 'myfile.yml',
        'debugger': 'on',
        'apply': {'a': 1, 'b': 2}
    }, task_include=Sentinel(name='task_include'))

# Generated at 2022-06-23 07:20:32.997414
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    import os
    import ansible.constants as C
    import ansible.utils.display as Display
    import ansible.playbook.task_include as TaskInclude
    import ansible.playbook.task as Task
    import ansible.playbook.block as Block
    import ansible.vars.manager as VarsManager
    from ansible.parsing.vault import VaultLib

    Display.verbosity = 4
    loader = action_loader._create_loader_for_path(os.getcwd())
    variable_manager = VarsManager(loader=loader)
    variable_manager._extra_vars = dict(remote_user='root')
    variable_manager.set_inventory(loader.inventory)


# Generated at 2022-06-23 07:20:41.273652
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task import Task

    ds = {'action': 'include', 'file': 'C:/foo', 'blah': 'blah'}
    ti = TaskInclude()
    ti.preprocess_data(ds)
    assert ti.preprocess_data(ds)['blah'] == 'blah'

    ds = {'action': 'import_tasks', 'file': 'C:/foo', 'blah': 'blah'}
    ti = TaskInclude()
    try:
        ti.preprocess_data(ds)
    except AnsibleParserError:
        assert True
    else:
        assert False

    ds = {'action': 'import_playbook', 'file': 'C:/foo', 'blah': 'blah'}
    ti = TaskInclude()

# Generated at 2022-06-23 07:20:52.448141
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    class TestTask(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(TestTask, self).__init__(block=block, role=role, task_include=task_include)

        def __eq__(self, other):
            return super(TestTask, self).__eq__(other)

        def __ne__(self, other):
            return super(TestTask, self).__ne__(other)

    class TestFieldAttribute(FieldAttribute):
        def __init__(self, field_name, dest, block, **kwargs):
            super(TestFieldAttribute, self).__init__(field_name, dest, block, **kwargs)


# Generated at 2022-06-23 07:21:03.827827
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test with a static include lookup task
    test_data_1 = {
        'action': 'include_tasks',
        'file': 'test.yml',
        'foo': 'bar'
    }
    test_task_1 = TaskInclude()
    test_task_1.load_data(test_data_1)
    test_result_1 = test_task_1.preprocess_data(test_data_1)
    assert {'action': 'include_tasks', 'file': 'test.yml'} == test_result_1, "preprocess_data fail for test_task_1"

    # Test with a dynamic (lookup) include role task

# Generated at 2022-06-23 07:21:15.052705
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    my_play = Play().load({
        'name': "myplay",
        'hosts': 'localhost',
        'gather_facts': 'no',
        'vars': {'var_play': 'play'},
        'vars_files': [],
        'roles': [],
        'tasks': [{
            'action': 'include',
            'file': 'main.yml',
            'apply': {'name': 'test'}
        }],
    }, variable_manager=None, loader=None)


# Generated at 2022-06-23 07:21:18.015367
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    ti = TaskInclude()
    assert bool(ti) is True




# Generated at 2022-06-23 07:21:21.501569
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.action = 'include'
    task.args = {'a': 'b', 'tags': 'c'}
    assert task.get_vars() == {'a': 'b'}



# Generated at 2022-06-23 07:21:30.998294
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude(block=None, role=None, task_include=None)

    # Test with option file
    ans = task.check_options(task.load_data(dict(file='test_project/test_include.yml')), {})
    assert ans.args['_raw_params'] == 'test_project/test_include.yml'

    # Test with option apply
    data = {'file': 'test_project/test_include.yml', 'apply': {'a': '1'}}
    ans = task.check_options(task.load_data(data), data)
    assert ans.args['_raw_params'] == 'test_project/test_include.yml'

    # Test with invalid option apply

# Generated at 2022-06-23 07:21:38.599561
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Validates the check_options method of class TaskInclude
    '''
    task_include = TaskInclude()
    task = Task()

    # Validates the bad args
    task.args = {'file': 'test.yml'}
    task.action = 'include'
    task_include.check_options(task, '')
    task.args = {'file': 'test.yml', 'bad_arg': 'test'}
    task.action = 'include'
    try:
        task_include.check_options(task, '')
    except AnsibleParserError as e:
        assert "Invalid options for include: bad_arg" == str(e)

    # Validates the args for include action
    task.args = {'file': 'test.yml', 'apply': 'test'}


# Generated at 2022-06-23 07:21:45.775494
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    Task = TaskInclude()
    Task.args = {'loop': 'item', 'with_items': ['one','two','three']}
    try:
        Task.build_parent_block()
    except Exception as e:
        assert(False), "build_parent_block() should not have raised exception"

    Task.args = {'apply':{'block':[]}}
    result = Task.build_parent_block()
    assert(result.block != []), "build_parent_block() failed"


# Generated at 2022-06-23 07:21:58.172978
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # test preprocess_data method of TaskInclude
    t = TaskInclude()
    assert t.preprocess_data({'foo': 42}) == {'foo': 42}
    assert t.preprocess_data({'include': 'test.yml'}) == {'include': 'test.yml'}
    assert t.preprocess_data({'include_role': 'test.yml'}) == {'include_role': 'test.yml'}
    assert t.preprocess_data({'include': 'test.yml', 'foo': 42}) == {'include': 'test.yml'}
    assert t.preprocess_data({'include': 'test.yml', 'action': 'test'}) == {'include': 'test.yml', 'action': 'test'}
    assert t.preprocess_data

# Generated at 2022-06-23 07:22:06.706477
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create a Block object that will contain tasks
    parent_block = Block()

    # Create a TaskInclude object that will be used to build the block
    root_ti = TaskInclude()
    root_ti.set_loader(None)

    # Test: case 'apply' is specified
    apply_attrs = {
        'block': [],
        'name': 'my include',
        'create': 'users',
    }
    task_include = TaskInclude.load(
        {'action': 'include', 'apply': apply_attrs},
        block=parent_block,
        role=None,
        task_include=root_ti
    )

    # Run build_parent_block method and test result
    block = task_include.build_parent_block()
    assert block != parent_block
    assert block != task

# Generated at 2022-06-23 07:22:18.082305
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    task = TaskInclude.load({
        'block': [{
            'include_tasks': {
                'name': 'test',
                'file': '/test/test.yml'
            }
        }]
    })
    assert task.action == 'include_tasks'
    assert task.args['_raw_params'] == '/test/test.yml'
    assert task.args['name'] == 'test'

    task = TaskInclude.load({
        'block': [{
            'import_tasks': {
                'name': 'test',
                'file': '/test/test.yml'
            }
        }]
    })
    assert task.action == 'import_tasks'
    assert task.args

# Generated at 2022-06-23 07:22:29.752414
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude(task_include=True)

    with pytest.raises(AnsibleParserError):
        task_include.load([{'file': 'test.yml'}])
    with pytest.raises(AnsibleParserError):
        task_include.load([{'include': 'test.yml'}])
    with pytest.raises(AnsibleParserError):
        task_include.load([{'include': 'test.yml', 'action': 'include'}])
    with pytest.raises(AnsibleParserError):
        task_include.load([{'include': 'test.yml', 'action': 'action'}])

# Generated at 2022-06-23 07:22:41.804839
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    data = {
        'name': 'include_stuff',
        'hosts': 'host1',
        'tasks': [
            {
                'debug': 'msg=Hello'
            },
            {
                'include': '../../../../unittest_custom_module/playbooks/tasks/sample_include.yml'
            }
        ]
    }
    play = Play.load(data, variable_manager=None, loader=loader)
    play._inject_facts()
    play.post_validate()
    tasks = play.get_tasks()

    task1 = tasks[0]
    task

# Generated at 2022-06-23 07:22:50.567206
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    fake_loader = object()
    task_include = TaskInclude(loader=fake_loader)
    task_include.action = 'include'
    task_include.args['tags'] = 'mytag'
    task_include.args['when'] = 'mywhen'
    task_include.args['myarg'] = 'myvar'
    myvars = task_include.get_vars()
    assert 'tags' not in myvars
    assert 'when' not in myvars
    assert 'myarg' in myvars
    assert 'myvar' == myvars['myarg']
    task_include.action = 'import_role'
    myvars = task_include.get_vars()
    assert 'myarg' not in myvars
    assert 'tags' in myvars

# Generated at 2022-06-23 07:23:00.766066
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Test TaskInclude constructor without parameters
    '''
    ti = TaskInclude()

    # Test attributes exist
    assert ti._attributes == set()
    assert ti.action == 'include'

    assert ti.block is None
    assert ti.loop is None
    assert ti.loop_with is None

    assert ti.async_val == 0
    assert ti.always_run is False
    assert ti.delegate_to is None
    assert ti.delegate_facts is False
    assert ti.ignore_errors is False
    assert ti.local_action is False
    assert ti.notify is None
    assert ti.poll is None
    assert ti.register is None
    assert ti.retries is 3
    assert ti.run_once is False
    assert ti.sudo is False
    assert ti.sudo_user

# Generated at 2022-06-23 07:23:11.343525
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def _check_vars(task, expected_vars):
        # create a context so we can raise errors
        class PlayContext(object):
            def __init__(self):
                self.task_vars = {}
            def set_task_var(self, k, v):
                self.task_vars[k] = v
            def raise_error(self, msg):
                raise Exception(msg)
            def get_task_var(self, k):
                return self.task_vars.get(k)
        play_context = PlayContext()
        all_vars = task.get_vars()
        assert all_vars == expected_vars


# Generated at 2022-06-23 07:23:20.902835
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    class MockTaskInclude(TaskInclude):
        def __init__(self, action=None, attributes=None, * args, **kwargs):
            attrs = {
                'action': FieldAttribute(fields=['action'], include_play=True, include_tasks=True, include_role=True,
                                         include_block=True),
            }
            if not attributes:
                attributes = {}
            if action:
                attributes['action'] = action
            for k,v in attrs.items():
                setattr(self._attributes, k, v)
            if attributes:
                for k,v in attributes.items():
                    setattr(self, k, v)


    expect_msg = "Cannot find included file: fake"

# Generated at 2022-06-23 07:23:22.065983
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # FIXME: create tests for load() method
    pass

# Generated at 2022-06-23 07:23:32.513972
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.playbook.play
    import ansible.playbook.playbook
    import ansible.playbook.task

    # Create a playbook object to use in our tests
    fake_loader = DummyLoader()
    pb = DummyPlaybook(loader=fake_loader)

    # Create a play object to use in our tests
    fake_variable_manager = DummyVariableManager()

# Generated at 2022-06-23 07:23:43.385030
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    # create task with include action and args

# Generated at 2022-06-23 07:23:49.908747
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    ti = TaskInclude()
    ti._loader = None
    ti._role = None
    ti._variable_manager = None
    ti._parent = None
    play = {'name': 'test_task_include_parent_block', 'hosts': 'all', 'gather_facts': 'no', 'tasks': [{'include': {'myvar': 'myval'}}]}
    ti._loader = None
    ti._play = play
    ti._play_context = PlayContext(play=play)
    ti._tqm = TaskQueueManager(loader=None, variable_manager=None, inventory=None, options=None, passwords=None)

# Generated at 2022-06-23 07:23:59.932845
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data_ = {'action': 'include', 'no_log': 'True', 'free_form': 'True'}
    ti = TaskInclude()
    assert (ti.preprocess_data(data_) == {'action': 'include', 'no_log': 'True'})
    assert (ti.preprocess_data({'action': 'import_playbook', 'include': 'True'}) == {'action': 'import_playbook', 'include': 'True'})
    assert (ti.preprocess_data({'action': 'include_role', 'no_log': 'True', 'import_playbook': 'True'}) == 
            {'action': 'include_role', 'no_log': 'True'})

# Generated at 2022-06-23 07:24:07.712336
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test a task with none of the valid options
    task_data = {'include': 'vars/main.yml'}
    task = TaskInclude(Block())
    task = task.check_options(task.load_data(task_data, variable_manager=None, loader=None), task_data)
    assert task.args == {'_raw_params': 'vars/main.yml'}

    # Test a task with some of the valid options
    task_data = {
        'include': 'vars/main.yml',
        'tags': [],
        'ignore_errors': True,
        'other': 'value'
    }
    task = TaskInclude(Block())

# Generated at 2022-06-23 07:24:18.576432
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class fake_loader:
        @staticmethod
        def load_from_file(path, class_name, args, task_vars, role=None):
            return args
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import action_loader
    loader = DataLoader()
    variable_manager = VariableManager()
    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    task_vars = {}
    vars_loader = VariableManager()
    play_context = PlayContext

# Generated at 2022-06-23 07:24:29.878411
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.playbook
    import ansible.plugins.loader

    # ANSIBLE_RETRY_FILES_ENABLED=0 ansible-playbook -i ../../inventory test_playbook/preprocess_data.yml
    loader = ansible.plugins.loader.action_loader.get('include_role')

# Generated at 2022-06-23 07:24:42.856038
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    variable_manager = DummyVM()
    loader = DummyLoader()
    p = Play().load({}, variable_manager=variable_manager, loader=loader)
    role = None
    b = Block(parent_block=None, role=role, task_include=None, play=p)

    ti = TaskInclude(parent_block=b, role=role, task_include=None)
    ti_args = {}
    ti.args = ti_args
    b.block = [ti]

    apply_block = ti.build_parent_block()
    assert apply_block == ti
    assert apply_block.block == []
    
    # Test include with apply
    ti_args = {'apply': {'block': []}}
    ti.args = ti_args
    apply_block = ti.build_parent_block()


# Generated at 2022-06-23 07:24:49.377741
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    test_data = dict(
        action = 'include',
        file = 'file/to/include',
        static = 'all',
        tags = ['tag1', 'tag2'],
        tasks = [],
    )
    task = TaskInclude.load(
        data=test_data
    )

    assert task.action == 'include'
    assert task.args["file"] == 'file/to/include'
    assert task.statically_loaded == True
    assert task.tags == ['tag1', 'tag2']
    assert len(task.tasks) == 0

# Generated at 2022-06-23 07:25:00.338087
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import TaskIncludeDefinition
    from ansible.playbook.play_context import PlayContext

    task = TaskInclude(block=None, task_include=None, role=None)
    included_data = dict(
        apply=dict(
            action='include',
            file='file_to_include.yml',
            apply=dict(
                block=dict(
                    when='success',
                    block=[]
                )
            )
        )
    )
    task.load_data(data=included_data)
    task.args['apply'].pop('block')
    task.args['block'] = []


# Generated at 2022-06-23 07:25:12.490266
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    assert not ti.check_options(ti.check_options(ti.load_data({'action': 'include', 'file': 'include_me.yml'})))
    assert not ti.check_options(ti.check_options(ti.load_data({'action': 'include_tasks', 'file': 'include_me.yml'})))
    assert not ti.check_options(ti.check_options(ti.load_data({'action': 'include_role', 'file': 'include_me.yml'})))
    assert not ti.check_options(ti.check_options(ti.load_data({'action': 'import_tasks', 'file': 'include_me.yml'})))

# Generated at 2022-06-23 07:25:13.876903
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    test_TaskInclude: constructor of class TaskInclude
    '''
    ti1 = TaskInclude()
    assert ti1 is not None

# Generated at 2022-06-23 07:25:19.189143
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook.play_context import PlayContext

    include_task = TaskInclude.load({'action': 'include'})
    include_task.vars = {'foo': 'bar'}
    include_task.args = {'apply': {}}
    include_task.statically_loaded = True

    copied_task = include_task.copy()

    assert copied_task is not include_task
    assert copied_task.action == 'include'
    assert copied_task.vars == include_task.vars
    assert copied_task.statically_loaded == include_task.statically_loaded
    assert copied_task.args == include_task.args
    assert copied_task.loop is None
    assert copied_task.role is None
    assert isinstance(copied_task._parent, PlayContext)
   

# Generated at 2022-06-23 07:25:29.267969
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    playbook = Playbook.load('', variable_manager=VariableManager(), loader=None)

    class Options:
        def __init__(self):
            self.extra_vars = dict()
            self.connection = 'local'
            self.module_path = None
            self.filename = 'test.yml'

    class Loader:
        def __init__(self):
            pass

        def get_basedir(self):
            return "."

    class PlayContext:
        def __init__(self):
            self.connection = 'local'
            self.port = None
            self.remote_addr = None
            self.remote_user = None
            self.password = None
           

# Generated at 2022-06-23 07:25:41.624609
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Test the method 'get_vars' from the class TaskInclude.
    Test with args, with include action and without include action.
    """

    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import load_plugin
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # init
    HOST = 'some_host'
    GROUP = 'some_group'

# Generated at 2022-06-23 07:25:49.986406
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    class TestInclude(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(TestInclude, self).__init__(block, role, task_include)
            # do not try to load anything
            self.action = None

    p = Play()
    p.context = PlayContext()
    p.vars_prompt = dict()
    p.vars_files = list()
    p.default_vars = dict()
    p.post_validate = lambda self: True
    p.connection = 'local'

# Generated at 2022-06-23 07:26:02.227843
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_context = {}
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play = Play.load(dict(
        name='TaskInclude test',
        hosts='localhost',
        gather_facts='no',
        roles=[]
    ), variable_manager=variable_manager, loader=loader)

    # Create parent Block

# Generated at 2022-06-23 07:26:10.298497
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play.load(dict(name='foo', hosts='localhost', gather_facts='no'), loader=loader, variable_manager=variable_manager)

    task = TaskInclude.load(dict(include='blah'), block=play, loader=loader, variable_manager=variable_manager)

    assert task.name == 'blah'
    assert task.block is play
