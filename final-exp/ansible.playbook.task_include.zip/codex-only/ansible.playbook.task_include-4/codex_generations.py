

# Generated at 2022-06-23 07:16:19.550154
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """This is a roundabout way of testing that TaskInclude.build_parent_block()
    is creating a parent Block() object when apply is specified, but it works.
    """
    import pytest
    from ansible.playbook.handler import HandlerTaskInclude

    task = TaskInclude.load({'include': 'foo', 'apply': {'tags': ['debug']}}, block=None)
    p_block = task.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.tags == ['debug']

    task = TaskInclude.load({'include_role': 'foo', 'apply': {'tags': ['debug']}}, block=None)
    p_block = task.build_parent_block()
    assert isinstance(p_block, Block)

# Generated at 2022-06-23 07:16:29.673891
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager

    task_names = ('include', 'include_tasks', 'import_playbook', 'import_tasks')
    for t_name in task_names:
        display.display('Testing %s' % t_name)
        ds = dict(
            action="include",
            args=dict(),
        )
        if t_name != 'include':
            ds['action'] = t_name

        ti = TaskInclude(task_include=None)
        try:
            ti.check_options(ti.load_data(ds), ds)
            assert False
        except AnsibleParserError:
            pass

        ds['args']['file'] = 'some_name'

        task = ti.check_

# Generated at 2022-06-23 07:16:30.982041
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    t = TaskInclude()

# Generated at 2022-06-23 07:16:32.155890
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task_include = TaskInclude()
    assert not task_include.statically_loaded



# Generated at 2022-06-23 07:16:43.974013
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    TI = TaskInclude()
    TI.args = dict(file='test.yml', other='value', other2='value')

    # With static include, no validation is done
    task = TI.check_options(TI, None)
    assert 'file' in task.args
    assert 'other2' in task.args
    assert 'other' in task.args

    # When '- include' is used, no validation is done
    TI.action = 'include'
    task = TI.check_options(TI, None)
    assert 'file' in task.args
    assert 'other2' in task.args
    assert 'other' in task.args

    # with apply
    TI.args = dict(file='test.yml', other='value', other2='value', apply=dict(name='apply'))
    task = TI

# Generated at 2022-06-23 07:16:55.272183
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    apply_attrs = {'loop': 'some_string_value'}
    task = Task()
    task.action = 'include_role'
    task.set_loader(None)
    task.args = {'apply': apply_attrs}

    # This should not raise an exception
    task = ti.check_options(task, {})

    # Invalid option 'apply'
    task.action = 'include'
    assert_raises(AnsibleParserError, ti.check_options, task, {})

    # Invalid option 'apply_attrs'
    task.args = {'apply': "some_invalid_value"}
    assert_raises(AnsibleParserError, ti.check_options, task, {})

    # Invalid option 'some_key'

# Generated at 2022-06-23 07:17:02.206255
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # Test1: Check that - include: var_name succeeds
    ds = dict(
        action = 'include',
        args=dict(
            file='var_name'
        )
    )
    task1 = TaskInclude.load(ds)
    assert task1.args['_raw_params'] == ds['args']['file']

    # Test2: Check that - include: var_name fails if file is not specified
    ds = dict(
        action = 'include',
        args=dict()
    )
    try:
        task1 = TaskInclude.load(ds)
    except Exception as e:
        assert True

    # Test3: Check that - include: var_name fails if invalid option is specified

# Generated at 2022-06-23 07:17:11.069226
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test the method TaskInclude.check_options as there is a bug
    in the framework and it doesn't validate properly the
    arguments in ``include_tasks``, ``import_tasks``,
    ``import_role`` and ``include_role``.
    .. note:: This unit test was added mainly as a "regression" check.
    :returns: None
    '''
    task = TaskInclude()

    # The following should not raise errors
    task.check_options(TaskInclude(args={'_raw_params': 'foo'}), {})
    task.check_options(TaskInclude(args={'file': 'bar'}), {})
    task.check_options(TaskInclude(args={'other_arg': 'foobar'}, action='include_tasks'), {})

# Generated at 2022-06-23 07:17:23.498111
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    include = TaskInclude.load(dict(action='include', file='/foo/bar'))
    include.statically_loaded = True
    new = include.copy()
    assert new.action == 'include'
    assert new.args['file'] == '/foo/bar'
    assert new.statically_loaded == True

    # test with exclude_parent
    new = include.copy(exclude_parent=True)
    assert new._parent == None

    # test with exclude_tasks
    new = include.copy(exclude_tasks=True)
    assert len(new._block) == 0

    # test with exclude_parent and exclude_tasks
    new = include.copy(exclude_parent=True, exclude_tasks=True)
    assert new._parent == None
    assert len(new._block) == 0


# Generated at 2022-06-23 07:17:34.606535
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import os
    import shutil
    import tempfile

    from ansible.module_utils._text import to_bytes, to_text
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def _make_data(i):
        if i == 1:
            base = dict(
                file='file1.yml',
                debugger={},
            )
            kwargs = C._ACTION_ALL_INCLUDE_TASKS

# Generated at 2022-06-23 07:17:35.305570
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-23 07:17:46.277147
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Test the load method, which is reponsible for loading from YAML data,
    and converting the data into native python objects.  It is also
    responsible for validating the data, which we also test.
    '''

    # setup config
    C.INVALID_TASK_ATTRIBUTE_FAILED = False

    data = {}
    try:
        task = TaskInclude.load(data)
        assert False, "expected exception"
    except AnsibleParserError:
        pass

    data = {"name": "test task"}
    try:
        task = TaskInclude.load(data)
        assert False, "expected exception"
    except AnsibleParserError:
        pass

    data = {"name": "test task", "include": "test.yml"}

# Generated at 2022-06-23 07:17:46.846987
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    TaskInclude()

# Generated at 2022-06-23 07:17:58.440518
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.module_utils.six import PY3

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.inventory.manager import InventoryManager

    ds = dict(
        apply=dict(
            block=dict(
                some_block_attr='a value'
            )
        ),
        file='/path/to/file'
    )

    display = Display()
    display.verbosity = 3

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources="empty_inventory")
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)


# Generated at 2022-06-23 07:18:08.395888
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Assert that check_options doesn't modify the task when it is valid.
    ti = TaskInclude()
    task_1 = Task()
    task_1.action = 'include_tasks'
    task_1.args = {}
    ti.check_options(task_1, '')
    assert task_1.args == {}

    # Assert that check_options doesn't modify the task when it is valid with valid options
    ti = TaskInclude()
    task_2 = Task()
    task_2.action = 'include_tasks'
    task_2.args = {'file':'', 'apply':{}}
    ti.check_options(task_2, '')
    assert task_2.args == {'_raw_params':'', 'apply':{}}

    # Assert that check_options raise Ans

# Generated at 2022-06-23 07:18:18.269382
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    test_block = TaskInclude()
    assert test_block._role is None
    assert test_block._parent is None
    assert test_block.statically_loaded == False
    assert test_block.BASE == frozenset(('file', '_raw_params'))
    assert test_block.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop',
                                                           'loop_control', 'loop_with', 'name', 'no_log', 'register', 'run_once',
                                                           'tags', 'timeout', 'vars', 'when'))
    assert test_block.VALID_ARGS == frozenset(('file', '_raw_params', 'apply'))
    assert test_block.OTHER

# Generated at 2022-06-23 07:18:21.072745
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    """
    Constructor for class TaskInclude
    """
    task = TaskInclude()
    assert task

# Generated at 2022-06-23 07:18:31.543128
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class FakeParent(object):
        def __init__(self, vars):
            self.vars = vars
        def get_vars(self):
            return self.vars

    class FakeRole(object):
        def __init__(self, vars):
            self.vars = vars
        def get_vars(self):
            return self.vars

    def create_task(action, vars, args=None, parent=None, role=None):
        task = TaskInclude()
        task.action = action
        task.vars = vars
        task.args = args if args is not None else {}
        task._parent = parent
        task._role = role
        return task

    # Static include

# Generated at 2022-06-23 07:18:41.389480
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block

    play_context = PlayContext()
    play_context.become = False
    play_context.become_user = None
    play_context.connection = 'local'
    play_context.remote_addr = None
    play_context.remote_user = None
    play_context.port = None
    play_context.become_method = None
    play_context.become_flags = None
    play_context.no_log = False
    play_context.check_mode = False
    play_context.timeout = 10
    play_context.only_tags = []
    play_context.skip

# Generated at 2022-06-23 07:18:47.163018
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-23 07:18:55.781130
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    make sure the task constructor works as we intended
    '''
    # minimal data needed for a TaskInclude
    raw_task_data = dict(
        action=dict(
            include=dict(
                file='some-file'
            )
        )
    )

    ti = TaskInclude()

    ti.copy()

    # test TaskInclude.load
    ti.load(raw_task_data)

    ti.preprocess_data(raw_task_data)

# Generated at 2022-06-23 07:19:08.076055
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    loader = TestLoader2()
    variable_manager = FakeVariableManager()
    variable_manager.set_nonpersistent_facts({'type': 'fake_type'})
    display = FakeDisplay()
    ti = TaskInclude()

    # For the includes and imports, the args dict is empty
    include = {'action': 'include',
               'static': 'yes'}
    import_task = {'action': 'import_tasks',
                   'static': 'yes'}
    import_role = {'action': 'import_role',
                   'static': 'yes'}

    # For the include, only the "file" options is valid
    file = {'action': 'include',
            'static': 'yes',
            'file': 'fake_file'}

    # For the other tasks, the other args are valid too
   

# Generated at 2022-06-23 07:19:11.515943
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    '''
    Make sure the TaskInclude class can be instantiated.
    '''
    ti = TaskInclude()
    display.display('TaskInclude instantiated')

# Generated at 2022-06-23 07:19:19.747330
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Verify that if the 'apply' option is specified for a task that isn't
    # of 'include' action, that we raise an error.
    task = Task.load(dict(action='import_tasks', apply=dict()))
    try:
        TaskInclude.check_options(task, dict(action='import_tasks', apply=dict()))
        assert False, "An error should have been raised because 'apply' is used for 'action' other than 'include'"
    except AnsibleParserError:
        pass

    # Verify that if the action is 'include' and that 'apply' is a dict,
    # that we don't raise an error.
    task = Task.load(dict(action='include', apply=dict()))
    TaskInclude.check_options(task, dict(action='include', apply=dict()))



# Generated at 2022-06-23 07:19:24.582580
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Set the value of INVALID_TASK_ATTRIBUTE_FAILED to true and false for testing
    original_value = C.INVALID_TASK_ATTRIBUTE_FAILED
    C.INVALID_TASK_ATTRIBUTE_FAILED = True
    C.INVALID_TASK_ATTRIBUTE_FAILED = False

    # Set up a dummy playbook
    pb = Block()
    pb.load({'hosts': 'localhost', 'tasks': []},loader=None, variable_manager=None)

    # Set up a dummy task for testing TaskInclude.preprocess_data
    task = TaskInclude(block=pb)
    task.action = 'include'
    task.args = {}

    # Test TaskInclude.preprocess_data

# Generated at 2022-06-23 07:19:34.016269
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():

    mock_loader = None
    mock_variable_manager = None
    mock_action = 'include_tasks'
    mock_file = '/home/user/file.yml'
    mock_vars = {}
    mock_block = 'parent_block'
    mock_block_vars = {'test_key': 'test_value'}
    other_args = {'tags': 'tags',
                  'when': 'when'}
    set_args = frozenset(TaskInclude.BASE.union(other_args).union(TaskInclude.OTHER_ARGS))
    mock_task_args = {'apply': 'apply', 'file': mock_file}

    # Creating a mock object for block class to assign it to parent block
    mock_block_obj = Block()
    mock_block_obj._play = mock_

# Generated at 2022-06-23 07:19:44.434565
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    example_1 = {
        "name": "An example task with static params",
        "_raw_params": "line1\nline2",
        "action": "lineinfile",
        "create": True,
    }

    task = TaskInclude.load(example_1)
    result = task.preprocess_data(example_1)

    assert isinstance(result, dict)
    assert len(result) == 4
    assert result == {
        "name": "An example task with static params",
        "_raw_params": "line1\nline2",
        "action": "lineinfile",
        "create": True
    }


# Generated at 2022-06-23 07:19:44.953880
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    assert TaskInclude()

# Generated at 2022-06-23 07:19:55.363782
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    ti = TaskInclude()
    ti_data = {
        'action': 'include',
        'file': 'test.yml',
        'tags': 'tag1,tag2',
        'when': 'condition'
    }

    new_ti_data = ti.preprocess_data(ti_data)
    assert new_ti_data['file'] == 'test.yml'
    assert new_ti_data['tags'] == 'tag1,tag2'
    assert new_ti_data['when'] == 'condition'
    assert 'action' not in new_ti_data

    hti = TaskInclude()

# Generated at 2022-06-23 07:20:02.956947
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Store original value of the flag to restore after the test
    original = C.INVALID_TASK_ATTRIBUTE_FAILED

    try:
        # Set up with invalid attribute
        C.INVALID_TASK_ATTRIBUTE_FAILED = True
        data = dict(action='include_role')
        data['foo'] = True
        task = TaskInclude.load(data)

        # The attribute 'foo' is not valid for a task include.
        # Therefore, since the flag INVALID_TASK_ATTRIBUTE_FAILED is set to True,
        # an AnsibleParserError will be raised.
        task.get_vars()

    except AnsibleParserError:
        # The test passed!
        pass

    else:
        # The test failed!
        raise

# Generated at 2022-06-23 07:20:15.556703
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {'action': 'include_role', 'name': 'an.example.role', 'foo': 'bar'}
    task = TaskInclude()
    new_ds = task.preprocess_data(ds)
    assert ds == new_ds, "'include_role' task failed preprocess_data test for no-op"

    ds = {'action': 'include_role', 'name': 'an.example.role', 'foo': 'bar'}
    # Ensure that a non-dict 'apply' attribute is properly rejected
    task = TaskInclude()
    task.args['apply'] = 123

# Generated at 2022-06-23 07:20:22.990255
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task = TaskInclude()
    assert isinstance(task, TaskInclude)
    assert task.statically_loaded
    assert task.action == 'include'
    assert task.args == {}
    assert task.delegate_to is None
    assert task.notify == []
    assert task.always_run is None
    assert task.async_val == 0
    assert task.poll is None
    assert task.changed_when == []
    assert task.failed_when == []
    assert task.environment == {}
    assert task.run_once is None
    assert task.become is None
    assert task.become_user is None
    assert task.become_method is None
    assert task.become_flags is None
    assert task.become_pass is None
    assert task.tags == []

# Generated at 2022-06-23 07:20:33.832662
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    def test_constructor():
        # Test case 1:
        # No the arguments
        # Expected result:
        # 'action' = None, 'args' = {}, 'tags' = None, 'when' = None
        # 'delegate_to' = None, 'loop_control' = None
        ti = TaskInclude()
        assert ti.action == None
        assert ti.args == {}
        assert ti.tags == None
        assert ti.when == None
        assert ti.delegate_to == None
        assert ti.loop_control == None

        # Test case 2:
        # 'action' = 'include_tasks'
        # Expected result:
        # 'action' = 'include_tasks', 'args' = {}, 'tags' = None, 'when' = None
        # 'delegate_to'

# Generated at 2022-06-23 07:20:41.760454
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = {
        'action': 'include',
        'invalid_attribute': 'foobar'
    }

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.become = None
    play_context._handle_bars = Templar(loader=loader, variables=variable_manager)
    play_iterator = PlayIterator(loader=loader, inventory=None, play=None, play_context=play_context, variable_manager=variable_manager)

    task_include = TaskIn

# Generated at 2022-06-23 07:20:52.608193
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.config.manager import ConfigManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    config_manager = ConfigManager()
    variable_manager = VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader()))
    wd = os.path.dirname(__file__)

    # Check invalid options for 'include' action

# Generated at 2022-06-23 07:20:54.991764
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    task = TaskInclude()
    assert task.action == 'include'

# Generated at 2022-06-23 07:21:05.178810
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    def assert_copied(task):
        task_copy = task.copy()
        assert(task_copy is not task)
        assert(task_copy.statically_loaded == task.statically_loaded)

    # Empty task
    task = TaskInclude()
    assert_copied(task)

    # Task with staticly loaded include
    task = TaskInclude()
    task.statically_loaded = True
    assert_copied(task)

    # Task as part of a role
    task = TaskInclude()
    role = object()
    task.role = role
    task_copy = task.copy()
    assert(task_copy.role == role)

    # Task with parent task
    task = TaskInclude()
    parent = object()
    task._parent = parent
    task_copy = task.copy()


# Generated at 2022-06-23 07:21:15.884280
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    p = TaskInclude()

    # Test data set 1: no args defined
    display.vvv('\nTest case 1')
    data = {}
    task = TaskInclude.load(data)
    assert task.get_vars() == {}

    # Test data set 2: args defined
    display.vvv('\nTest case 2')
    data = {'myarg': 'myvalue', 'myarg2': 'myvalue2'}
    task = TaskInclude.load(data)
    assert task.get_vars() == {}

    # Test data set 3: include task with args defined
    display.vvv('\nTest case 3')
    data = {'myarg': 'myvalue'}
    task = TaskInclude.load(data, task_include=p)
    p.action = 'include'


# Generated at 2022-06-23 07:21:23.980261
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    display_args = dict(
        verbosity = 2,
        color = False,
        log_only = False
    )
    display = Display(**display_args)

    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.statically_loaded = False

    new_ti = ti.copy()

    assert ti.statically_loaded == new_ti.statically_loaded

    display.display("Test copy ok", color='green')


# Generated at 2022-06-23 07:21:34.644106
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.errors import AnsibleParserError
    from ansible.playbook import Play
    import ansible.constants as C
    from ansible.plugins.loader import task_loader

    fake_loader = task_loader._find_plugins(C.DEFAULT_TASK_PATH, include_others=False)
    fake_playbook = Play().load({'hosts': 'all',
                                 'vars': {'foo': 'bar'},
                                 'tasks': [{'action': 'include',
                                            'args': {'file': '123',
                                                     'other': 'cicci'}}]})
    fake_variable_manager = fake_playbook.get_variable_manager()

    fake_action = 'include'
    fake_block = None
    fake_role = None
    fake_

# Generated at 2022-06-23 07:21:38.901267
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    # what is the output of the task

    # Create a task instance with the constructor class
    task_instance = TaskInclude()

    # Get args of the class
    task_args = task_instance.args

    # What is the task_args
    print("Task args are", task_args)


if __name__ == '__main__':
    test_TaskInclude()

# Generated at 2022-06-23 07:21:48.702235
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test build_parent_block method of class TaskInclude
    """
    task_include = TaskInclude()
    block_with_apply = {'apply': {
        'block': [{}],
        'tags': 'my_block_tags',
        'when': 'my_block_when',
        'vars': {'my_block_var': 'my_block_value'}
    }}
    block = task_include.build_parent_block()

    # Test that self is passed as return value when no apply is defined
    assert block == task_include

    # Test that a Block object is created when apply is passed
    task_include.args = dict(block_with_apply)
    result = task_include.build_parent_block()
    assert isinstance(result, Block)

    # Test that the input

# Generated at 2022-06-23 07:21:49.280306
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    pass

# Generated at 2022-06-23 07:22:00.581013
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os

    inventory_manager = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory_manager)
    variable_manager._fact_cache = {'var': 'value'}
    variable_manager.set_facts(variable_manager._fact_cache)
    variable_manager.set_variable_manager(variable_manager)

    display_args = {
        'verbosity': 3,
        'log_only': False,
        'one_line': False,
        'running_add_path': False,
    }

    display.verbosity = display_args['verbosity']


# Generated at 2022-06-23 07:22:07.689987
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    import json
    from ansible.parsing.dataloader import DataLoader

    # Since the dataloading is a complex, this is basically just a sanity check
    data = """
    - name: include test 1
      block:
        - include: '{{ test }}'
      vars:
        test: good.yml
    - name: include test 2
      block:
        - include: '{{ test }}'
        - include: '{{ test }}'
      vars:
        test: good.yml
    - name: include test 3
      block:
        - include: '{{ test }}'
        - include: '{{ test }}'
      vars:
        test: bad.yml
    """

    loader = DataLoader()
    data = json.loads(data)
    ti = TaskInclude.load

# Generated at 2022-06-23 07:22:15.916996
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)

    # Example of "include" statement with "apply" in TaskInclude
    data = {
        "include": {
            "action": "include",
            "apply": {
                "name": "first_block"
            }
        }
    }

    task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    assert (task.action == 'include')
    p_block = task.build_parent_block()


# Generated at 2022-06-23 07:22:23.643296
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = Playbook.Loader(variable_manager=variable_manager)

    task_include = loader.load_from_file('../../test/unit/module_utils/test_include_module.yml')

    assert isinstance(task_include, Task)
    assert isinstance(task_include, TaskInclude)

# Generated at 2022-06-23 07:22:32.215374
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    task = '''
            - name: "include"
              hosts: localhost
              include: 'file.yml'
              become: no
              become_method: sudo
              become_user: root
              connection: ssh
              gather_facts: yes
              no_log: False
              ignore_errors: False
              check_mode: no
              allow_world_readable_tmpfiles: False
              any_errors_fatal: False
              exclude_hosts: []
              only_hosts: []
              run_once: False
              serial: 1
            '''

# Generated at 2022-06-23 07:22:41.611206
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.play_context

    data = {u'apply': {u'handler': False,
                       u'hosts': u'all',
                       u'module_name': u'module_name'},
            u'file': u'file',
            u'name': u'name',
            u'when': u'when'}
    block = Block()
    role = None
    task_include = None
    variable_manager = ansible.playbook.play_context.VariableManager()
    loader = None
    task_include = TaskInclude.load(data, block, role, task_include, variable_manager, loader)

    assert task_include.action == u'include'

# Generated at 2022-06-23 07:22:50.387518
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for the TaskInclude method build_parent_block
    '''
    from ansible.playbook import Play, Task
    from ansible.vars import VariableManager


    # Init play
    p_block = Play().load({
        'name': 'test',
        'hosts': ['test'],
        'roles': [{
            'name': 'test',
            'hosts': ['test'],
            'tasks': [{
                'include': 'test'
            }]
        }]
    }, variable_manager=VariableManager(), loader=None)

    # Init task
    task = TaskInclude(block=p_block[0])
    task.args.update({'file': 'test', 'apply': {'when': 'test'}})


    # Test parent block without apply

# Generated at 2022-06-23 07:23:00.619511
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude.load(data={'_raw_params': "file.yml", 'action': 'include'})
    assert task.args == {'file': 'file.yml'}
    task.check_options(task, data={'_raw_params': "file.yml"})
    assert task.args == {'_raw_params': 'file.yml'}

    task = TaskInclude.load(data={'_raw_params': "file.yml", 'action': 'include', 'apply': {'become': True}})
    assert task.args == {'file': 'file.yml', 'apply': {'become': True}}

# Generated at 2022-06-23 07:23:11.283015
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create new instance of a block
    test_block = Block()
    test_block.role=None
    test_block.task_include=None
    test_block._play=None

    # Create an instance of a TaskInclude
    test_include = TaskInclude(block=test_block)
    assert isinstance(test_include, TaskInclude)
    # Add the necesary arguments for the test
    test_include.args={'apply':{}}
    test_include._parent=test_include
    test_include.add_role_to_parent()
    # Test the build_parent_block method with apply_attrs = {}
    assert isinstance(test_include, TaskInclude)

    # Create an instance of a TaskInclude
    test_include = TaskInclude(block=test_block)

# Generated at 2022-06-23 07:23:20.878260
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # we are going to test it here to avoid creating dummy plugin
    task_name = 'include'

    parser = TaskInclude(block=None, role=None, task_include=None)

    # test: check_options
    data = dict(
        apply=dict(),
        file="some file",
    )
    task = parser.load_data(data, variable_manager=None, loader=None)
    parser.check_options(task, data)

    # test: check_options / bad_opts
    data = dict(
        bad_opt=True,
        file="some file",
    )
    task = parser.load_data(data, variable_manager=None, loader=None)
    with pytest.raises(AnsibleParserError) as err:
        parser.check_options(task, data)


# Generated at 2022-06-23 07:23:25.476410
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # testTaskInclude = TaskInclude(block=None, role=None, task_include=None)
    # testTaskInclude.load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    pass

# Generated at 2022-06-23 07:23:34.142017
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    import ansible.playbook.play_context
    play_context = ansible.playbook.play_context.PlayContext()
    import ansible.executor.task_queue_manager
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
        options=None,
    )

# Generated at 2022-06-23 07:23:39.611385
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    myti = TaskInclude(block=Block())
    myti_copy = myti.copy()
    assert myti_copy.statically_loaded == False
    myti.statically_loaded = True
    myti_copy = myti.copy()
    assert myti_copy.statically_loaded == True


# Generated at 2022-06-23 07:23:47.732002
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 07:23:59.238844
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    display.verbosity = 3

    # test_TaskInclude_load_no_file_specified
    data = dict(action='include', apply=dict(block=[]))
    task = TaskInclude.load(data=data)
    assert (task.action == 'include')
    try:
        task.check_options(task=task, data=data)
        assert False, "file was not specified for include but no error was raised"
    except AnsibleParserError as e:
        assert "No file specified for include" in str(e)

    # test_TaskInclude_load_apply_not_allowed_for_include_tasks
    data = dict(action='include', apply=dict(block=[]))
    task = TaskInclude.load(data=data)

# Generated at 2022-06-23 07:24:03.350298
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    new_ti = ti.copy()
    assert new_ti.statically_loaded == True

    ti = TaskInclude()
    ti.statically_loaded = False
    new_ti = ti.copy()
    assert new_ti.statically_loaded == False


# Generated at 2022-06-23 07:24:14.607517
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_data = dict(
        name="test name",
        action="test action",
        file="test file",
        block=[]
    )

    task_block_data = dict(
        name="test name",
        action="test action",
        file="test file",
        block=[]
    )

    task = TaskInclude.load(task_data)
    assert isinstance(task, TaskInclude)
    assert isinstance(task._parent, TaskInclude)
    assert isinstance(task._parent._parent, TaskInclude)

    task = TaskInclude.load(task_block_data, task_include=task)
    assert isinstance(task, TaskInclude)
    assert isinstance(task._parent, TaskInclude)
    assert isinstance(task._parent._parent, TaskInclude)

    task_

# Generated at 2022-06-23 07:24:26.842454
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Setup test variables
    display.verbosity = 3
    data = {"action": "include_role", "name": "Apache", "ignore_errors": "yes", "when": "ansible_os_family == 'Debian'"}
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None
    display.verbosity = 3
    my_task_include = TaskInclude.load(
        data,
        block=block,
        role=role,
        task_include=task_include,
        variable_manager=variable_manager,
        loader=loader
    )

    # Setup expected variables
    task_vars = {"action": "include_role", "name": "Apache"}

# Generated at 2022-06-23 07:24:31.853135
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Creating dummy data
    data = {'include': 'test.yml', 'vars': {'a': 'b'}}
    # Creating dummy variable_manager and loader objects
    variable_manager = 'variable_manager'
    loader = 'loader'

    # Creating dummy object of class Task
    ti = TaskInclude()

    # Checking preprocess_data method of class TaskInclude
    assert(ti.preprocess_data(data) == {'include': 'test.yml', 'vars': {'a': 'b'}})

# Generated at 2022-06-23 07:24:44.181321
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager


# Generated at 2022-06-23 07:24:54.565498
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test invalid 'action'
    data = dict(
        action='include_invalid_action',
        args=dict(file='/etc/ansible/invalid_action.yml'),
    )

    try:
        TaskInclude.load(data)
        assert False, 'AnsibleParserError should be raised'
    except AnsibleParserError:
        pass

    # Test invalid 'apply' content
    data = dict(
        action='include_role',
        args=dict(
            file='/etc/ansible/apply_dict.yml',
            apply='invalid_content',
        ),
    )

    try:
        TaskInclude.load(data)
        assert False, 'AnsibleParserError should be raised'
    except AnsibleParserError:
        pass

    # Test invalid 'apply' content

# Generated at 2022-06-23 07:25:08.154013
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    my_vars = dict(
        a_var='a_var_value',
        a_dict=dict(
            a_dict_key='a_dict_value'
        )
    )

    task_vars = dict(
        another_var='another_var_value',
        another_dict=dict(
            another_dict_key='another_dict_value'
        )
    )

    # include_args will be used for 'include', 'include_tasks', 'import_tasks' and 'import_role' actions
    include_args = dict(
        a_include_arg='a_include_arg_value',
        a_include_dict=dict(
            a_include_dict_key='a_include_dict_value'
        )
    )

    # include_args_vars will be used

# Generated at 2022-06-23 07:25:18.253666
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class Blocky:
        def __init__(self, parent=None):
            self._parent = parent

        def get_vars(self):
            return {'blocky': 'blocky-value'}

    class Playy:
        def __init__(self, parent=None):
            self._parent = parent

        def get_vars(self):
            return {}

    class Roley:
        def __init__(self, parent=None):
            self._parent = parent

        def get_vars(self):
            return {}

    class Tasky(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(Tasky, self).__init__(block=block, role=role, task_include=task_include)


# Generated at 2022-06-23 07:25:19.131608
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    """
    Test the TaskInclude constructor
    """

    task = TaskInclude()
    assert task

# Generated at 2022-06-23 07:25:21.022341
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti = TaskInclude()
    ti.statically_loaded = True
    ti2 = ti.copy()
    assert ti2.statically_loaded is True

# Generated at 2022-06-23 07:25:30.145722
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class Opts(Task):
        '''
        We inherit from Task to test other methods of that class and for convenience
        '''
        _validate_deprecation = Task._validate_deprecation

        # This is needed for the '_validate_loop' method
        _loop_handler_override = FieldAttribute(isa='string', default='default')
        @property
        def loop(self):
            return self._loop

    def _assert_task_in_state(task, args, action, apply_attrs={}):
        assert args == task.args
        assert action == task.action
        assert apply_attrs == task['apply']

    # Test with an empty task
    task = TaskInclude()
    task.args['_raw_params'] = 'file'
    task.action = 'include'
    task

# Generated at 2022-06-23 07:25:33.047247
# Unit test for method copy of class TaskInclude
def test_TaskInclude_copy():
    ti1 = TaskInclude()
    ti1.statically_loaded = True
    ti2 = ti1.copy()
    assert ti1.statically_loaded == ti2.statically_loaded

# Generated at 2022-06-23 07:25:44.852721
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()
    task = task_include.load({'action': 'include', 'tags': ['example']}, loader=None, variable_manager=None)
    assert task.args == {}
    assert task.action == 'include'
    assert task.tags == ['example']

    task = task_include.load({'name': 'include', 'tags': ['example']}, loader=None, variable_manager=None)
    assert task.args == {}
    assert task.action == 'include'
    assert task.tags == ['example']

    task = task_include.load({'action': 'import_role', 'tags': ['example'], 'file': 'tasks/main.yml'}, loader=None, variable_manager=None)
    assert task._raw_params == 'tasks/main.yml'
   

# Generated at 2022-06-23 07:25:50.909135
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from units.mock.loader import DictDataLoader

    mock_loader = DictDataLoader({
        "test.yml": """
- include: test.yml
  name: foo
  tags:
  - bar
        """,
    })

    mock_variable_manager = sentinel.variable_manager
    ansible_playbook_mock = Block()
    ansible_playbook_mock._play = sentinel.play

    task_include_mock = TaskInclude(block=ansible_playbook_mock)
    task_include_mock._loader = mock_loader
    task_include_mock._variable_manager = mock_variable_manager


# Generated at 2022-06-23 07:26:02.548006
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.include import RoleInclude as tii  # noqa
    from ansible.playbook.handler.include import HandlerInclude as hii  # noqa

    # We use TaskInclude as an example to test TaskInclude and its
    # subclass HandlerInclude. Since they use the same code to validate options
    # we can cover both cases with:
    ti = TaskInclude()

    def get_task(data):
        return Task.load(
            data,
            play=None,  # not needed to test this method
            task_include=None,
            role=None,  # not needed to test this method
            loader=None,
            variable_manager=None,  # not needed to test this method
        )


# Generated at 2022-06-23 07:26:10.419802
# Unit test for constructor of class TaskInclude
def test_TaskInclude():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.vars.manager import VariableManager

    mock_loader = Mock()
    mock_variable_manager = VariableManager()
    mock_play = Play()

    mock_block = Block()
    mock_block.vars = {}
    mock_block.vars['foo'] = 'bar'

    mock_role = Role()
    mock_role._role_path = 'some/path'
    mock_role.name = 'test_role'
