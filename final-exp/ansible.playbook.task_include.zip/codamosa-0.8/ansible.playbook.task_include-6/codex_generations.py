

# Generated at 2022-06-11 11:10:52.084994
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    playbook_path = "test.yml"
    host_1 = Host(name="localhost")
    host_1.set_variable("role_var", "role_var")
    host_1.set_variable("role_var_2", "role_var_2")
    host_2 = Host(name="localhost")
    host_2

# Generated at 2022-06-11 11:11:03.205904
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Inherited class has method check_options
    assert hasattr(TaskInclude, 'check_options')

    # check_options() should raise error if invalid options found
    TaskInclude.VALID_ARGS = frozenset()
    TaskInclude.VALID_INCLUDE_KEYWORDS = frozenset()
    task_no_options = TaskInclude.load({'action': 'include'})
    try:
        task_no_options.check_options(task_no_options, {})
    except AnsibleParserError:
        assert True
    else:
        assert False

    # check_options() should raise error if 'action' is not in PROPER INCLUDE TASKS
    TaskInclude.VALID_ARGS = frozenset(('x', 'y'))
    TaskInclude.VALID

# Generated at 2022-06-11 11:11:13.496752
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import set_available_variables
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    loader = DataLoader(display)

    vars_manager = VariableManager(loader=loader)
    set_available_variables({'a': 'hi', 'b': 'bye'})

    task_args = {'action': 'include', 'file': 'fake_file'}
    ti = TaskInclude()
    ti.check_options(ti.load_data(task_args, variable_manager=vars_manager, loader=loader), task_args)


# Generated at 2022-06-11 11:11:24.690058
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import pytest

    display.verbosity = 3

    task1 = TaskInclude()
    msg = "Invalid options for `include`: x"
    with pytest.raises(AnsibleParserError, match=msg):
        task1.preprocess_data({'include': 'task.yml', 'x': 1})

    task2 = TaskInclude()
    msg = "`include_role` does not accept the `debugger` keyword"
    with pytest.raises(AnsibleParserError, match=msg):
        task2.preprocess_data({'include_role': 'task.yml', 'debugger': 1})

    task3 = TaskInclude()
    msg = "Invalid options for `import_role`: x"

# Generated at 2022-06-11 11:11:35.876915
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for different action types
    for action in C._ACTION_ALL_TASKS:
        task = TaskInclude(block=None, task_include=None)
        task.action = action
        task.args = dict(a='b')
        task._parent = None

        vars = task.get_vars()
        if task.action in C._ACTION_INCLUDE:
            assert(len(vars) == 2)
            assert(vars['a'] == 'b')
        else:
            assert(len(vars) == 1)

        # Test with parent
        parent_args = dict(c='d')
        parent_vars = dict(e='f')

        parent = TaskInclude(block=None, task_include=None)
        parent.action = 'test'

# Generated at 2022-06-11 11:11:47.319319
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = [
          { "hosts": "localhost", "tasks": [
            { "action": "include", "args": {"apply": {"when": "hostvars['localhost']['checker_property']", "block": []}, "file": "/foo/bar"}}
          ]},
          {"hosts": "other", "tasks": [
            { "include": "/foo/bar", "apply": {"when": "hostvars['localhost']['checker_property']"}}
          ]}
        ]

    variable_manager = DummyVariableManager()
    loader = DummyLoader()
    task = TaskInclude.load(block[0]['tasks'][0], block=block[0], variable_manager=variable_manager, loader=loader)
    assert task.args["file"] == "/foo/bar"

   

# Generated at 2022-06-11 11:11:55.820972
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    loader = None
    variable_manager = None
    play = Play().load(dict(
        name='test_TaskInclude',
        hosts=['localhost'],
        gather_facts='no',
        roles=[{'name': 'role'}],
        tasks=[{'include': 'no_file'}]
    ), variable_manager=variable_manager, loader=loader)

    # valid options
    data = dict(action='include', file='dummy', _raw_params='dummy', no_log='yes', run_once='yes')
    task = Task.load(data=data, block=play, role=Role())

# Generated at 2022-06-11 11:12:03.283797
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude(task_include=Sentinel())
    ti.args = {'arg1': 'hello', 'arg2': 'world'}
    result = ti.get_vars()
    assert result['arg1'] == 'hello'
    assert result['arg2'] == 'world'
    assert result['action'] == 'include'

    ti.action = 'something_else'
    result = ti.get_vars()
    assert result['arg1'] == 'hello'
    assert result['arg2'] == 'world'
    assert 'action' not in result

# Generated at 2022-06-11 11:12:14.590763
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

# Generated at 2022-06-11 11:12:24.068208
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test if the build_parent_block method returns the parent block with apply
    variables
    '''

    # Load include task with apply variables
    task_include = {
        'apply': {
            'name': 'include_task_with_apply',
            'tags': ['tag1', 'tag2'],
            'loop': '{{ none_existing_variable }}'
        }
    }

    ti = TaskInclude.load(task_include)
    parent_block = ti.build_parent_block()
    assert parent_block.name == 'include_task_with_apply'
    assert parent_block.tags == ['tag1', 'tag2']
    assert isinstance(parent_block._loop, FieldAttribute) and parent_block._loop.block_list is not None
    assert parent_block.block is None

# Generated at 2022-06-11 11:12:37.347468
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude.load(
        data={
            'action': 'include',
            'args': {
                'x': 'y',
                'z': 'a'
            }
        },
        block=Block.load({'vars': {'x': 'z'}}, task_include=None),
        task_include=None
    )
    assert t.action == 'include'
    assert t.vars == {'x': 'z'}
    assert t.args == {'x': 'y', 'z': 'a'}
    assert t.get_vars() == {'x': 'y', 'z': 'a'}

# Generated at 2022-06-11 11:12:38.011583
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    assert True

# Generated at 2022-06-11 11:12:47.442240
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task import Task

    display = Display()
    display.verbosity = 3

    # Create a dummy task to avoid errors during preprocessing
    t = Task()

    # Test with include
    ti = TaskInclude()
    ti._parent = t
    # Create a dummy data structure to test
    ds = {"action": "include", "include": "something", "bla": "blub"}
    ds_expected = {"action": "include", "include": "something", "bla": "blub"}
    ds_result = ti.preprocess_data(ds)
    assert ds_result == ds_expected

    # Test with include and 'include' as first element
    ti = TaskInclude()
    ti._parent = t
    # Create a dummy data structure to test

# Generated at 2022-06-11 11:12:57.897739
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test case: validate get_vars method
    from ansible.playbook.play_context import PlayContext

    my_play_context = PlayContext()
    my_play_context.network_os = 'ios'

    block_name = 'main'
    my_block = Block(parent_block=None, role=None,  task_include=None, play=my_play_context, use_handlers=False)
    my_block.block  = [{'hosts': 'host1', 'gather_facts': 'no', 'tasks': [{'name': 'task1', 'include': 'test.yml', 'vars': {'var1': 'val1'}}]}]

    ti = TaskInclude()
    ti.action = 'include'
    ti.block = my_block

    # Pass the block

# Generated at 2022-06-11 11:13:08.819736
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import sys
    import os
    import contextlib

    @contextlib.contextmanager
    def _cleanup():
        yield
        sys.path.pop(0)

    with _cleanup():
        sys.path.insert(0, os.path.dirname(__file__))

        data = {
            'action': 'include',
            'name': 'test',
            'tags': ['test'],
        }

        task = TaskInclude()
        data = task.preprocess_data(data)

        if len(data.keys()) != len(TaskInclude.VALID_INCLUDE_KEYWORDS):
            assert False, "Action include preprocess_data should have " + str(len(TaskInclude.VALID_INCLUDE_KEYWORDS)) + " key(s) in dictionary"

test_

# Generated at 2022-06-11 11:13:18.543035
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager
    loader = None
    block = Block()
    role = None
    task_include = None

    # 'include' action
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    data = {
        u'name': u'Task include test 1',
        u'include': u'playbooks/included.yml',
        u'apply': {
        }
    }
    task = ti.load(data, block, role, task_include, variable_manager, loader)
    assert task.action == 'include'

# Generated at 2022-06-11 11:13:29.781139
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = {'name': 'include_ds',
          'file': 'some_file',
          'some_other_key': 'some_other_value'}

    result = ti.preprocess_data(ds)
    assert not ('some_other_key' in result)
    assert result['name'] == 'include_ds'
    assert result['file'] == 'some_file'
    assert result['action'] == 'include'

    ds = {'name': 'include_ds',
          'include': 'some_file',
          'some_other_key': 'some_other_value'}

    result = ti.preprocess_data(ds)
    assert 'some_other_key' in result
    assert result['name'] == 'include_ds'

# Generated at 2022-06-11 11:13:38.251227
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-11 11:13:49.719025
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 11:13:57.928118
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a fake vars object (we're only interested in the 'tags')
    FOO_VARS = {'tags': 'bar'}

    # Create a fake Task which will be the parent of the TaskInclude to test
    # We override the get_vars class so we can check if it's being called
    class FakeTaskGetVars(Task):
        def __init__(self):
            self.called = False

        def get_vars(self):
            self.called = True
            return FOO_VARS

    # Create the TaskInclude and set its _parent to the fake parent task
    ti = TaskInclude()
    ti._parent = FakeTaskGetVars()

    # Test that the parent's get_vars is called for any action except for include

# Generated at 2022-06-11 11:14:04.018269
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This function tests the method build_parent_block of class TaskInclude.
    '''
    pass

# Generated at 2022-06-11 11:14:13.928472
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
  '''
  Checks if the method get_vars of class TaskInclude implements the
  expected behavior.
  '''
  import ansible.template
  task_include = TaskInclude()
  task_include.action = 'include'
  task_include.args = {'x': '3'}
  task_include._parent = Task()
  task_include._parent.vars = {'x': '1', 'y': '2'}
  assert task_include.get_vars() == {'x': '3', 'y': '2'}

  task_include = TaskInclude()
  task_include.action = 'some_other_action'
  task_include.args = {'x': '3'}
  task_include._parent = Task()

# Generated at 2022-06-11 11:14:23.643900
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Simple initialization for tests
    task = TaskInclude.load(dict(action="include_tasks", args=dict(file="foo.yml")))
    data = dict(action="include_tasks", args=dict(file="foo.yml"))

    # Check if an exception is raised when a non-existent option is passed to 'include_tasks' action
    task.args = dict(bad_opt="value")
    try:
        task.check_options(task, data)
    except AnsibleParserError as e:
        assert e.message == "Invalid options for include_tasks: bad_opt"
    else:
        raise AssertionError("A non-existent option passed to 'include_tasks' action should raise an exception")

    # Check if an exception is raised when an 'apply' option is passed to a non-supported

# Generated at 2022-06-11 11:14:32.794409
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for the method TaskInclude.check_options
    '''

    # Valid actions
    actions = (
        'include',
        'import_playbook',
        'import_role',
        'import_tasks',
    )

    # Invalid arguments
    invalid_args = (
        ('garbage', 'Invalid options for foo: garbage'),
        ('task', 'Invalid options for foo: task'),
        ('apply', 'Invalid options for foo: apply'),
    )

    # Valid arguments
    valid_args = (
        ('file', 'include_file.yml'),
        ('_raw_params', 'include_file.yml'),
        ('content', 'foo'),
        ('vars', {}),
    )

    # Valid arguments, but not for all tasks

# Generated at 2022-06-11 11:14:43.914136
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Initialize few vars
    name = "testTaskInclude"
    action = "include"
    file_name = 'test_file_name'
    file_name2 = 'test_file_name2'
    tags = ["tag1", "tag2"]
    when = "when1"

    var1 =  "var1"
    val1 = "val1"
    var2 =  "var2"
    val2 = "val2"
    var3 = "debugger"
    val3 = "val3"
    var4 = "no_log"
    val4 = False

    # Create a new TaskInclude
    tsk = TaskInclude()
    tsk.name = name
    tsk.action = action
    tsk.args.update({"_raw_params" : file_name})


# Generated at 2022-06-11 11:14:50.496501
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    variable_manager = Mock()
    loader = Mock()
    play = Play.load({
        'name': "Test play",
        'connection': "local",
        'hosts': 'all',
        'gather_facts': "no",
        'tasks': [{
            'name': 'test_task',
            'include': 'test_include_regular'
        }]
    }, variable_manager=variable_manager, loader=loader)
    ti = play.get_tasks()[0]

    # Check with 'apply' section
    apply_attrs = OrderedDict([('name', 'test_parent_block'), ('listen', 'to_me')])

# Generated at 2022-06-11 11:14:56.784350
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.vars['ansible_version'] = 'ansible 1.9.3'
    result = ti.get_vars()
    assert result == {'ansible_version': 'ansible 1.9.3'}, \
        "TaskInclude get_vars error: got %s, expected {'ansible_version': 'ansible 1.9.3'}" % result


# Generated at 2022-06-11 11:15:06.878721
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # create TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import module_loader

    play_context = PlayContext()
    inventory = InventoryManager(module_loader=module_loader)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    block = Block()
    task_include = TaskInclude(block=block)
    # set task_include attributes
    task_include.action = 'include'
    task_include.args = {'arg1': 1, 'arg2': 2}
    task_include.vars = {'arg1': 1, 'arg2': 2, 'arg3': 3}



# Generated at 2022-06-11 11:15:16.921739
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    assert task.get_vars() == {}, "Empty task's vars should be an empty dict"

    task = TaskInclude()
    task.args = {'foo': 1}
    assert task.get_vars() == {'foo': 1}, "Task's vars should be equal to its args"

    parent = TaskInclude()
    parent.vars = {'bar': 1}
    parent.args = {'bar': 2}

    task = TaskInclude()
    task._parent = parent
    task.vars = {'baz': 3}
    task.args = {'baz': 4}

    assert task.get_vars() == {'foo': 1}, "Task's vars should be equal to its args"

    task.action = 'include'

# Generated at 2022-06-11 11:15:26.663036
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class TaskInclude.
    We are just testing the `diff` validation here because is the most logical thing to
    test at this point.
    '''
    valid_data = {
        'action': 'include_tasks',
        'file': '../vars/main.yml'
    }

    # Valid diff set
    ti = TaskInclude()
    ti.preprocess_data(valid_data)

    # Invalid diff set
    invalid_data = {
        'action': 'include_role',
        'name': 'foobar',
        'foobar_attr': 'baz'
    }
    with pytest.raises(AnsibleParserError):
        ti.preprocess_data(invalid_data)

# Generated at 2022-06-11 11:15:40.184393
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Construct a TaskInclude object
    t = TaskInclude()
    t.action = 'include'
    t.vars = {'a': 1}
    t.args = {'_raw_params': 'a.yaml', 'b': '2'}
    # Run get_vars()
    vars = t.get_vars()
    # Check the result
    assert vars == {'a': 1, '_raw_params': 'a.yaml', 'b': '2'}



# Generated at 2022-06-11 11:15:47.403407
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data1 = {'action': 'include_role', 'name': 'test'}
    data2 = {'action': 'include_role', 'name': 'test', 'action': 'my-action'}
    data3 = {'action': 'include_role', 'name': 'test', 'action': 'my-action', 'any_key': 'any-value'}

    assert 'action' in TaskInclude.preprocess_data(data1)
    assert 'action' in TaskInclude.preprocess_data(data2)
    with pytest.raises(AnsibleParserError):
        TaskInclude.preprocess_data(data3)


# Generated at 2022-06-11 11:15:54.987721
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Given task include with 'include' as action
    task_include = TaskInclude()
    task_include.action = 'include'

    # When get_vars is called
    all_vars = task_include.get_vars()

    assert all_vars == {}, 'get_vars returned empty dictionary even though _parent, vars and args were empty'

    # Given task include with 'include' as action
    from ansible.playbook.play import Play
    play = Play().load({}, variable_manager={}, loader=None)
    task_include = TaskInclude(block=play)
    task_include.action = 'include'
    # _parent of task is initialized with the play
    assert task_include._parent == play

    # Given 'foo' is key of vars and it's value is 'bar'
   

# Generated at 2022-06-11 11:16:03.190895
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class TestTask(TaskInclude):
        def __init__(self, args):
            super(TestTask, self).__init__()
            self.args = args

    task_attrs = {'tags': ['tag1', 'tag2'], 'when': 'when1 and when2'}
    apply_attrs = {'block': [], 'become': False, 'become_user': 'joe', 'delegate_to': 'localhost', 'tags': ['tag3'], 'when': 'when3'}
    task = TestTask(task_attrs)
    task.args['apply'] = apply_attrs
    p_block = task.build_parent_block()
    assert p_block.statically_loaded is False
    assert p_block.args == apply_attrs

# Generated at 2022-06-11 11:16:11.972589
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for the method build_parent_block() of class TaskInclude.
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    def get_mock_block(name='test-block', tags=None, when=None):
        '''
        Creates a mock Block object that can be used for testing the
        build_parent_block() method.
        '''

        def mock_get_vars(self):
            '''
            Mocks the method get_vars() of class Block to return the block's
            tag and when attributes if present.
            '''
            all_vars = dict()
            if self.tags is not None:
                all_

# Generated at 2022-06-11 11:16:17.043509
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.vars = {'var1': 'foo', 'var2': 'bar'}
    task.args = {'key': 'value', 'tags': ['tag1', 'tag2'], 'when': "true"}
    assert task.get_vars() == {'var1': 'foo', 'var2': 'bar',
                               'key': 'value'}

# Generated at 2022-06-11 11:16:26.291760
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test for action 'include'.
    # Test for empty setting of 'file' and 'apply'.
    data = dict()
    data['action'] = 'include'
    data['file'] = ''
    task = TaskInclude(None, None, None)
    with pytest.raises(AnsibleParserError) as error:
        task.check_options(task.load_data(data), data)
    assert 'Invalid options for include: file' in str(error)

    # Test for 'file' and 'apply'.
    data = dict()
    data['action'] = 'include'
    data['file'] = ''
    data['apply'] = ''
    task = TaskInclude(None, None, None)

# Generated at 2022-06-11 11:16:35.270805
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    def make_play():
        play_ds = dict(
            name="foobar",
            hosts="all"
        )
        return Play().load(play_ds, variable_manager=None, loader=None)

    def make_role():
        role_ds = dict(name="foobar")
        return Role.load(role_ds, play=make_play(), variable_manager=None, loader=None)

    def make_task():
        task_ds = dict(name='task_foo', action=dict(module='debug', args=dict(msg='foo')))

# Generated at 2022-06-11 11:16:45.032565
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class FakeParentTask(object):
        def __init__(self, vars):
            self.vars = vars
        def get_vars(self):
            return self.vars
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    var_manager = FakeParentTask({'ansible_env': {'foo': 'bar'}})

    task = Task()
    task.vars = {'ansible_env': {'bar': 'foo'}}
    task.args = {'_raw_params': 'foo.yml', 'apply': {'tags': []}}

    play = Play()
    play._variable_manager = var_manager

    block = Block()
    block._play = play

# Generated at 2022-06-11 11:16:54.081664
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    t = TaskInclude()
    t.action = 'include'
    t.vars = dict(ansible_distribution='oracle')
    t.args = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    p = Play()
    p.vars = dict(ansible_os_family='solaris')

    r = Role()
    r.vars = dict(ansible_kernel='solaris')

    b = Block()
    b.vars = dict(ansible_kernel='solaris')

    t._parent = p
    p._parent = r
    r._parent = b

   

# Generated at 2022-06-11 11:17:21.138368
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # pylint: disable=protected-access,missing-docstring
    task = TaskInclude()
    ds = {'action': 'include'}
    assert task.preprocess_data(ds) == {'action': 'include'}
    ds = {'unknown_key': 'dummy', 'action': 'include'}
    assert task.preprocess_data(ds) == {'unknown_key': 'dummy', 'action': 'include'}
    ds = {'unknown_key': 'dummy', 'action': 'import_role'}
    try:
        task.preprocess_data(ds)
    except AnsibleParserError as ex:
        assert ex.message == "'unknown_key' is not a valid attribute for a TaskInclude"
    else:
        assert False

# Generated at 2022-06-11 11:17:31.040143
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # Test invalid options
    data1 = {'action': 'include_tasks', 'include': 'file', 'invalid': 'something'}
    task.check_options(task.load_data(data1, variable_manager=None, loader=None), data1)
    assert 'invalid' not in task.args

    # Test valid args assigned to matching attribute
    data2 = {'action': 'include_tasks', 'include': 'file', 'apply': {'first': 'value'}}
    task.check_options(task.load_data(data2, variable_manager=None, loader=None), data2)
    assert task.apply == {'first': 'value'}

    # Test invalid apply

# Generated at 2022-06-11 11:17:40.726190
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude:
    '''

    display.verbosity = 3

# Generated at 2022-06-11 11:17:51.877795
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import pprint
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Input
    data = {'apply': {'name': 'Test name'}, 'name': 'Test when', 'when': 'Test when'}

    # Init
    context = PlayContext()
    variable_manager = VariableManager()

    # Build
    task = TaskInclude().load(data, variable_manager=variable_manager)
    task.post_validate(context=context)
    task._validate_apply_when(context=context)
    task._load_apply_block()
    task.build_parent_block()
    
    # Assert
    assert task.args == {'name': 'Test when', 'when': 'Test when'}

# Generated at 2022-06-11 11:17:59.183469
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager
    variable_manager = VariableManager()

    # Test 1: non-static include, should not override parent's vars
    #         with the vars of the include task
    # Create a dict representing the parent task
    t = dict()
    t['vars'] = dict(
        foo='foo',
        bar='bar',
    )
    # Create a dict representing the included task
    task_include_dict = dict()
    task_include_dict['action'] = 'include'
    task_include_dict['vars'] = dict(
        foo='foo_include',
        baz='baz_include',
    )
    # Create the TaskInclude instance
    task_include = TaskInclude(variable_manager=variable_manager)
    # Put the dict into the instance
    task_

# Generated at 2022-06-11 11:18:08.820147
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # pylint: disable=missing-docstring,unsubscriptable-object,too-many-function-args
    def dummy_load_data(data, variable_manager=None, loader=None):
        task = TaskInclude()
        task.args = {'no_log': True}
        task.action = 'include'
        return task

    # path = AnsibleFileIncludeObject.load(data, variable_manager=None, loader=None)
    # task = TaskInclude.load(data, variable_manager=variable_manager, loader=loader)
    # task_include = TaskInclude()
    # task = task_include.check_options(task, data)

    display = Display()
    display.display("test_TaskInclude_check_options")

    task_include = TaskInclude()
    task_include

# Generated at 2022-06-11 11:18:18.595281
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    test_data = {'action': 'include_tasks',
                 'args': {'file': 'test'}}

    loader = unittest.mock.Mock()
    task = TaskInclude.check_options(TaskInclude.load(test_data, loader=loader), test_data)
    assert task.action == 'include_tasks', "The action name should be preserved after validation"
    assert task.args == {'_raw_params': 'test'}, "The argument 'file' should be renamed to '_raw_params'"

    test_data['args']['unknown_option'] = 'unknown'
    with pytest.raises(AnsibleParserError):
        TaskInclude.check_options(TaskInclude.load(test_data, loader=loader), test_data)


# Generated at 2022-06-11 11:18:25.022685
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    data = dict(
        action='include',
        file='playbook.yml',
        ignore_errors=False,
        loop_control=dict(loop_var='item'),
        with_items=['a', 'b'],
    )

    # should not raise an exception
    task = task_include.check_options(task_include.load_data(data), data)
    assert task
    assert task.action == 'include'
    assert task.args == dict(
        _raw_params='playbook.yml',
        apply=dict(
            loop='item',
            loop_with=['a', 'b']
        ),
        ignore_errors=False,
    )

    # should raise exception for an invalid action

# Generated at 2022-06-11 11:18:33.145234
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block

    # test_TaskInclude_check_options_no_file_raises_AnsibleParserError
    data = {'action': 'include', 'apply': {}}
    block = Block()
    role = None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    result = ti.check_options(
        ti.load_data(data, variable_manager=None, loader=None),
        data
    )
    assert False

    # test_TaskInclude_check_options_not_in_VALID_ARGS_raises_AnsibleParserError
    data = {'action': 'include', 'apply': {}, 'not_in_VALID_ARGS': True}
    block = Block

# Generated at 2022-06-11 11:18:41.314497
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # File for static include
    static_file = "ansible/test/units/modules/test_static_include.yml"

    # File for dynamic include
    dynamic_file = "ansible/test/units/modules/test_dynamic_include.yml"

    def get_vars(file):
        # Get include
        inc = TaskInclude.load(dict(include=file))
        inc.set_loader(None)

        # Add block to include
        blk = Block.load(dict(block=[]), task_include=inc)
        blk.set_loader(None)
        inc._parent = blk

        # Create task
        tsk = Task()
        blk.block.append(tsk)

        # Add vars to task

# Generated at 2022-06-11 11:19:33.755171
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class AnsibleModule:
        def __init__(self):
            self.params = None

    am = AnsibleModule()

    ti = TaskInclude(block=None, role=None, task_include=None)
    res = ti.preprocess_data({'action': 'include_tasks', 'connection': 'local', 'async': '10'})
    assert res == {'action': 'include_tasks', 'async': '10', 'connection': 'local'}

    res = ti.preprocess_data({'action': 'include_role', 'debugger': 'true', 'connection': 'local'})

# Generated at 2022-06-11 11:19:42.408439
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    a = TaskInclude()

    assert a.get_vars() == {}

    a.args['a'] = 'test'
    assert a.get_vars() == {'a': 'test'}

    # Test that 'tags' and 'when' are skipped when self.action != 'include'
    a.action = 'notinclude'
    a.args = {
        'when': 'test1',
        'tags': 'test2'
    }
    assert a.get_vars() == {'when': 'test1', 'tags': 'test2'}

    a.action = 'include'
    assert a.get_vars() == {'a': 'test'}

    # 'a' should no longer exist

# Generated at 2022-06-11 11:19:51.638777
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    ans_vars = task_include.get_vars()
    assert ans_vars == {'play': 'play1', 'play_hosts': ['127.0.0.1'], 'play_hosts_all': ['127.0.0.1']}

    task_include.args['_raw_params'] = 'foo.yaml'
    ans_vars = task_include.get_vars()
    assert ans_vars == {
        'play': 'play1',
        'play_hosts': ['127.0.0.1'],
        'play_hosts_all': ['127.0.0.1'],
        '_raw_params': 'foo.yaml'
    }


# Generated at 2022-06-11 11:19:56.639298
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    task = TaskInclude()
    assert(task.load({'include':  'hello.yml', 'tags' : 'test_tag'}) is not None)
    assert(task.action == 'include')
    assert(task.args['_raw_params'] == 'hello.yml')
    assert(task.tags == ['test_tag'])


# Generated at 2022-06-11 11:20:01.884165
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    attrs = {'block': [], 'ignore_errors': True, 'loop': 'some_item', 'loop_control': {'label': 'foo'}}
    p_block = TaskInclude.build_parent_block(attrs)

    assert p_block.ignore_errors == True
    assert p_block.loop == 'some_item'
    assert p_block.loop_control.label == 'foo'
    assert len(p_block.block) == 0



# Generated at 2022-06-11 11:20:10.796735
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit tests for the ``TaskInclude.build_parent_block()`` method
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.utils import context_objects as co

    apply_attrs = {'loop_control': {"loop_var": "item"}, 'name': "Test Parent Block"}
    # The variable manager will be auto discovered and required for the task
    variable_manager = co.VariableManager()
    # The loader will be auto discovered and required for the task
    loader = co.Loader()
    play = Play.load(dict(), loader=loader, variable_manager=variable_manager, name='TEST_PLAY')

# Generated at 2022-06-11 11:20:20.348553
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.vars import VariableManager

    vars_mgr = VariableManager()
    vars_mgr.extra_vars = {'key1': 'value1'}

    from ansible.vars import VariableManager

    # Loading with dict of dicts
    task_obj = TaskInclude.load({'_raw_params': 'test_playbook_name'}, block=None, role=None, task_include=None,
                                variable_manager=vars_mgr, loader=None)
    assert task_obj.action == 'include'
    assert task_obj.args['_raw_params'] == 'test_playbook_name'

    # Loading with dict of dicts and file option

# Generated at 2022-06-11 11:20:27.943237
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Create example data structure
    ds = {'action': 'include_tasks', 'file': 'myfile.yml', 'os_type': 'Linux'}

    # Create TaskInclude object
    ti = TaskInclude()

    # Call method to test
    ns = ti.preprocess_data(ds)

    #We expect 'os_type' to be removed from data structure
    assert 'os_type' not in ns
    assert 'os_type' not in ds



# Generated at 2022-06-11 11:20:36.017885
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders, get_loader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    class FakePlaybookFileLoader(object):
        def __init__(self, playbooks):
            self._playbooks = playbooks
            self._cache = {}

# Generated at 2022-06-11 11:20:37.189173
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    assert t.get_vars() == dict()