

# Generated at 2022-06-11 11:10:52.554868
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext()

    # The `_raw_params` option will not be included in the returned vars if
    # the action is not 'include'.
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.action = "other"
    ti.args = {"one": "1", "_raw_params": "something"}
    assert ti.get_vars() == {'one': '1'}

   

# Generated at 2022-06-11 11:11:03.852458
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action='include', args=dict(a=2, b=3, c=4), apply=dict(name='testing')),
        ]
    )



# Generated at 2022-06-11 11:11:13.885964
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext

    # Success when all args are valid
    task_data = dict(
        action='include',
        args=dict(
            file='foo.yml',
            tags=['one', 'two', 'three'],
            apply=dict(
                block=[]
            )
        )
    )
    task = TaskInclude.load(task_data)
    task = task.check_options(task, task_data)
    assert task['tags'] == ['one', 'two', 'three']
    assert task['args']['file'] == 'foo.yml'

    # Success when no args are specified
    task_data = dict(
        action='include',
        args=dict()
    )
    task = TaskInclude.load(task_data)
   

# Generated at 2022-06-11 11:11:25.298915
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager

    ti = TaskInclude()

    ti.args = {'name': 'static'}
    assert isinstance(ti.get_vars(), dict)
    assert ti.get_vars().get('name') == 'static'

    vars_manager = VariableManager()
    vars_manager.add_host_vars(HostVars(dict(name='static'), 'name'), 'name')
    ti._variable_manager = vars_manager
    ti.vars = dict(name='task_vars')

# Generated at 2022-06-11 11:11:36.344177
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Test with empty action key
    data = AnsibleBaseYAMLObject()
    data.update({'action': 'include_tasks'})
    data = TaskInclude.preprocess_data(data)
    assert (data['action'] == 'include_tasks')
    assert (data.args == {})

    # Test with extra invalid keyword
    data = AnsibleBaseYAMLObject()
    data.update({'action': 'include_tasks', 'not_a_valid_keyword': 'not_a_valid_keyword'})
    try:
        TaskInclude.preprocess_data(data)
    except AnsibleParserError:
        pass

    # Test with extra invalid keyword
    data = AnsibleBaseYAML

# Generated at 2022-06-11 11:11:47.865960
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager

    role1 = Role()
    role1._role_path = 'a/roles/example_role'
    play1 = Play().load({}, variable_manager=VariableManager(), loader=None)
    block1 = Block(play=play1, role=role1)
    task1 = Task(block=block1, role=role1)
    task1.action = 'include'

    task2 = TaskInclude.check_options(task1, {'include': 'a/roles/example_role/tasks/main.yml'})
    assert task2.action == 'include'

# Generated at 2022-06-11 11:11:56.134957
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test method TaskInclude.check_options.
    '''
    from ansible.plugins import module_loader
    from ansible.playbook.play_context import PlayContext
    import os
    import tempfile
    import json

    task = TaskInclude()

    # test with an invalid options
    data = dict(
        include='my_file.yml',
        bad_options='foo',
    )
    task.vars = dict()
    task.args = dict()
    task.action = 'include'
    task.includes = dict()
    task.tags = set()
    task.conditional = None
    task.notify = dict()
    task.handlers = dict()
    task.action_loader = module_loader._loaders['action']
    task._parent = None
    task._role

# Generated at 2022-06-11 11:12:06.373893
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test that the parent block is created correctly, ie:
      - it has the expected attributes
      - it has the expected tasks in its block when apply is specified
    """
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.vars import combine_vars

    task_include = TaskInclude()

    # We need some mocked data to fill in all the required attributes
    task_include.action = 'include'
    task_include.args = {'_raw_params': 'foo', 'key1': 'value1'}
    task_include._parent = type('FakeParent', (object,), {})()
    task_include._parent._play = type('FakePlay', (object,), {'playbook': "playbook.yaml", '_entries': []})()
    task_include._

# Generated at 2022-06-11 11:12:17.765546
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    assert TaskInclude().build_parent_block()

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    play = Play.load({'name': 'test play', 'hosts': 'local'}, variable_manager=None, loader=None)

    task_block = {
        'block': [{'action': 'debug', 'msg': 'This is block'}],
        'name': 'This is block',
    }

    task_include = {
        'action': 'include_tasks',
        'apply': task_block,
        'name': 'Include tasks',
    }

    parent_block = TaskInclude.load(task_include, play=play, task_include=None, role=None, variable_manager=None, loader=None).build_parent_block()



# Generated at 2022-06-11 11:12:27.005072
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    def make_task(action, args=None, vars=None):
        task = TaskInclude()
        task.action = action
        task.args = args or {}
        task.vars = vars or {}
        return task

    task1 = make_task('include_role', {'tags': ['tag1'], 'when': True}, {'var1': 1})
    task2 = make_task('include_tasks', {'name': 'foo', 'vars': {'var2': 2}}, {'var3': 3})

# Generated at 2022-06-11 11:12:45.596817
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    display.verbosity = 3
    task_include = TaskInclude()

    # action not in C._ACTION_INCLUDE:
    task_include.action = 'include'
    task_include.args = {'_raw_params': ['/path/to/include.yml'], 'with_items': [1,2,3]}
    task_include.vars = {'a': '123'}
    assert task_include.get_vars() == {'a': '123', '_raw_params': ['/path/to/include.yml'], 'with_items': [1,2,3]}

    # action in C._ACTION_INCLUDE:
    task_include.action = 'include'
    task_include._parent = TaskInclude()

# Generated at 2022-06-11 11:12:55.056844
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    t_obj = TaskInclude()
    t_obj._variable_manager = VariableManager()
    t_obj._loader = DataLoader()
    t_obj._parent = Base()
    t_obj._parent._play = Base()
    t_obj.action = 'include'
    t_obj._role = Base()

    # Test with only valid keywords; no changes should be made
    data = {'action': 'include',
            'arg1': 'value1',
            'arg2': 'value2'}

    t_obj.pre

# Generated at 2022-06-11 11:13:06.126674
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import ansible.constants as C
    import pytest

    t = TaskInclude()
    display = Display()

    task_test_init = Task.load({'name': 'test', 'action': 'test'})

# Generated at 2022-06-11 11:13:14.008809
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
        Tests the functionality of building a parent block for a specific task include
    '''
    import ansible.playbook.play_context as pc
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.loader import dynamic_plugin_loader

    variable_manager = pc.VariableManager()
    loader = dynamic_plugin_loader
    variable_manager.set_host_variable('testhost', {"testvar": "testval"})

    play_context = pc.PlayContext(variable_manager=variable_manager)
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_

# Generated at 2022-06-11 11:13:24.212022
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Init TaskInclude object and prepare vars
    task_include = TaskInclude({
        'include': {
            'name': 'Add user',
            'file': 'adduser.yml',
            'tag': 'test'
        }}
    )
    task_include.vars = {
        'admin_user': 'admin',
    }
    task_include.args = {
        'username': 'test'
    }

    # run method get_vars()
    result_vars = task_include.get_vars()

    # check result
    assert result_vars == {
        'username': 'test',
        'admin_user': 'admin'
    }


# Generated at 2022-06-11 11:13:25.067468
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    pass

# Generated at 2022-06-11 11:13:35.179356
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()

    # non-existing file
    data = {
        'include': '/non/existing/file',
    }
    ae = None
    try:
        task_include.load(data, loader=None)
    except AnsibleParserError as e:
        ae = e
    assert ae is not None

    # missing required arg
    data = {
        'include': 'somefile',
    }
    ae = None
    try:
        task_include.load(data, loader=None)
    except AnsibleParserError as e:
        ae = e
    assert ae is not None

    # unknown args
    data = {
        'include': 'somefile',
        'some_unknown_arg': 'some_value',
    }
    ae = None
   

# Generated at 2022-06-11 11:13:46.470957
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.playcontext import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile

    play = Play()
    play_context = PlayContext(play=play)
    inventory = InventoryManager(loader=DataLoader())

    variables = VariableManager(loader=DataLoader(), inventory=inventory)
    host = Host(name='test')

# Generated at 2022-06-11 11:13:56.083865
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class MockTask(Task):
        def __init__(self, block, name, tasks=None, when=None, tags=None, vars=None, loop=None):
            super(MockTask, self).__init__(block)

            # Mock some variables for the test
            self.name = name
            self.args = {}
            self.vars = vars
            self._parent = None

            # Make the task not static. If static, 'include' returns the parent.
            # See https://github.com/ansible/ansible/blob/devel/lib/ansible/playbook/task_include.py#L113
            self.action = 'include'
            self.statically_loaded = False

            # Precompute the result.
            self.expected_result = vars.copy()
            self.expected

# Generated at 2022-06-11 11:14:05.920779
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    #static load
    block = Block()
    block.args['vars'] = {'a': 1}
    t = TaskInclude()
    t.action = 'include'
    t.args = {'tags': ['a'], '_raw_params': 'a/main.yml'}
    t.statically_loaded = True
    t._parent = block
    vars = t.get_vars()
    assert vars == {'a': 1, 'tags': ['a'], '_raw_params': 'a/main.yml'}

    #dynamic load
    t = TaskInclude()
    t.action = 'include'
    t.args = {'tags': ['a'], '_raw_params': 'a/main.yml'}
    t.statically_loaded = False
   

# Generated at 2022-06-11 11:14:23.979489
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-11 11:14:33.409688
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # Test invalid option (no apply)
    data = dict(
        action='include_role',
        args=dict(
            apply=dict(),
            file='file.yml',
            ignore_errors=True,
        ),
    )
    task = TaskInclude.load(
        data=data,
        variable_manager=variable_manager,
        loader=loader,
    )

# Generated at 2022-06-11 11:14:44.131963
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    display = Display()
    task = TaskInclude()
    assert task.preprocess_data({'action': 'include_role', 'name': 'test', 'foo': 'bar'}) == {'action': 'include_role', 'name': 'test'}
    assert task.preprocess_data({'action': 'include_tasks', 'name': 'test', 'foo': 'bar'}) == {'action': 'include_tasks', 'name': 'test'}
    assert task.preprocess_data({'action': 'include_role', 'name': 'test', 'foo': 'bar', 'tags': []}) == {'action': 'include_role', 'name': 'test', 'tags': []}

# Generated at 2022-06-11 11:14:52.032609
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    my_play = Play().load(dict(
        name='test',
        hosts='some_hosts',
        tasks=[{
            'task1': {
                'include': 'test.yaml',
                'with_items': [1, 2],
                'debugger': 'test',
                'when': 'test',
                'apply': {
                    'name': 'test'
                }
            }
        }]
    ), variable_manager=VariableManager())
    includes = my_play.get_blocks()
    assert(len(includes) == 1)
    block = includes[0]
    assert(len(block.block) == 1)
    tasks = block.block


# Generated at 2022-06-11 11:15:02.663179
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_va = { 'xyz': 123 }
    args    = { 'ansible_by_no': 456, 'xyz': 789 }
    vars_in = { 'vain': 'variable', 'xyz': 'abc' }

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti._parent = Block()
    ti._parent.vars = vars_in
    ti._parent.args = task_va
    ti.name = 'include'
    ti.vars = vars_in
    ti.args = args

# Generated at 2022-06-11 11:15:12.645053
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # import Ansible modules for testing
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-11 11:15:17.039434
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import json
    import yaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-11 11:15:27.168712
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test TaskInclude._check_options()
    '''
    # Test a valid task
    task = TaskInclude()
    data_source = {
        'include': {
            'file': '/etc/ansible/xxx.yml',
        },
    }

    try:
        task.check_options(task.load_data(data_source), data_source)
    except Exception as e:
        raise AssertionError('TaskInclude.check_options() failed: %s' % e)

    # Test a valid task with apply
    task = TaskInclude()

# Generated at 2022-06-11 11:15:37.103752
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    task_include = TaskInclude(block=block)
    task_include.vars = dict(a='a_var')
    task_include.args = dict(b='b_var')
    task_include.action = 'include'
    task_include._parent = block
    block.vars = dict(c='c_var')
    assert task_include.get_vars() == dict(a='a_var', b='b_var', c='c_var')

    task_include.args = dict(tags='tags')
    task_include.action = 'include_role'
    task_include._parent = block
    block.vars = dict(c='c_var')
    assert task_include.get_vars() == dict(a='a_var', c='c_var')


# Generated at 2022-06-11 11:15:45.365892
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-11 11:16:03.808824
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data_dict = {"include_role": {"name": "foo.bar"}}
    ti = Task()
    result = ti.preprocess_data(data_dict)
    assert result['include_role']['action'] == 'include_role'
    assert result['include_role']['name'] == 'foo.bar'

    data_dict = {"include_role": {}, "action": "include_role", "ignore_errors": "yes"}
    result = ti.preprocess_data(data_dict)
    assert result['action'] == 'include_role'
    assert result['ignore_errors'] == 'yes'
    assert result['include_role'] == {}

    data_dict = {"import_role": {"name": "foo.bar", "tags": "debug"}}

# Generated at 2022-06-11 11:16:12.713499
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ''' ansible.playbook.task_include.TaskInclude.get_vars

    Mock class TaskInclude to test method get_vars

    The method is tested based on the following requirements:
        - In case self.action is not in C._ACTION_INCLUDE,
          the method get_vars() returns the superclass result (returned by class Task)
        - In case self.action is in C._ACTION_INCLUDE,
          the method get_vars() returns a dictionary containing:
              - self._parent.get_vars()
              - self.vars
              - self.args, except field tags and when
    '''
    from ansible.playbook.task import Task
    class TaskIncludeMock(TaskInclude):
        def __init__(self, action, args):
            self.action

# Generated at 2022-06-11 11:16:22.234064
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Test to ensure that the `args` of the include are included in `get_vars`
    when the action is 'include'.
    """

    # Test data
    args = {
        'var': 'value',
        'apply': {
            'var_1': 'value_1',
            'var_2': 'value_2'
        }
    }
    # preprocess_data is not being called so we have to set the action ourselves
    action = 'include'
    # Create a TaskInclude object
    task_obj = TaskInclude()
    # Set the attributes of the TaskInclude object
    task_obj.args = args
    task_obj.action = action

    # Call the get_vars method and compare
    assert task_obj.get_vars() == args


# Generated at 2022-06-11 11:16:31.209705
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()

    # TaskInclude.get_vars() should return ti.vars if ti.action is not
    # in C._ACTION_INCLUDE
    ti.vars = dict(a=1)
    ti.action = 'not_in_include'
    assert ti.get_vars() == dict(a=1)

    # TaskInclude.get_vars() should return dict combining ti._parent.get_vars()
    # and ti.args if it is.
    ti.vars = dict(a=1)
    ti.action = 'include'
    # Case 1: no '_parent'
    assert ti.get_vars() == dict(a=1)
    # Case 2: '_parent' has no 'get_vars' method
    class Parent():
        pass

# Generated at 2022-06-11 11:16:40.629915
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.plugins.strategy.linear import StrategyModule

    # The following is an excerpt of an ansible-playbook call with the debug module.
    # First, the yaml of the - include statement.
    task_yaml = '''
    - include: test_task_include.yml
      apply:
        load_path: ../tasks
        when: load_tasks_condition
        block:
          - test_task_include2:
    '''
    # Second, the task_include.yml is loaded and contains the following:

# Generated at 2022-06-11 11:16:50.058434
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars

    # create a valid instance of task include
    ti = TaskInclude()

    # create an empty task
    task = Task()

    # create empty data for arguments validation
    data = dict()

    # test for invalid option
    task.args = {'bad_option': 'some_value'}
    try:
        ti.check_options(task, data)
    except AnsibleParserError as err:
        assert 'Invalid options for include: bad_option' in str(err)

    # test unrecognized apply
    task.args = {'bad_option': 'some_value'}
    task.action = 'import_role'

# Generated at 2022-06-11 11:17:00.634348
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include = TaskInclude(block=None, role=None, task_include=None)

    # test: action in C._ACTION_INCLUDE
    task_include.action= 'include'
    task_include.vars = dict(task_include='task_include')
    task_include.args = dict(args='args')
    assert task_include.get_vars() == dict(task_include='task_include', args='args')

    # test: action not in C._ACTION_INCLUDE
    task_include._parent = None
    task_include.action= 'include_tasks'
    task_include.vars = dict(task_include='task_include')
    task_include.args = dict(args='args')

# Generated at 2022-06-11 11:17:04.517296
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.playbook.role.required import RoleRequirement

    # Minimally mock a parent, but just enough to execute the method under test
    parent = Play()
    parent.post_validate()
    parent._role = RoleRequirement()

    # Create our task. If we don't specify the action, it won't be included and the method under test won't execute.
    p_task = parent.add_task(block=parent._block, action='include_role')

    # Create a TaskInclude to have the method under test executed
    ti = TaskInclude(parent)
    ti.post_validate()
    ti.action = p_task.action

# Generated at 2022-06-11 11:17:13.064261
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    mock_task = type('MockTask', (object,), {})()
    setattr(mock_task, '_variable_manager', None)
    setattr(mock_task, '_loader', None)
    setattr(mock_task, '_role', None)
    setattr(mock_task, '_parent', None)
    setattr(mock_task, '_action', 'include_tasks')
    setattr(mock_task, '_pos', None)
    setattr(mock_task, '_args', {})
    setattr(mock_task, '_role', None)
    setattr(mock_task, '_play', None)
    set

# Generated at 2022-06-11 11:17:25.550950
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-11 11:17:55.616078
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Initialize the TaskInclude
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args['test1'] = 'test1'
    task_include.args['test2'] = 'test2'

    # Initialize the class parent
    block = Block()
    block.parent = None
    task_include._parent = block

    # Initialize the object parent
    parent_play = type('play', (), dict())()
    parent_play.vars = dict()
    parent_play.vars['test3'] = 'test3'
    parent_play.vars['test4'] = 'test4'
    block._play = parent_play

    # Set the vars
    task_include.vars = dict()

# Generated at 2022-06-11 11:18:01.084380
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import json
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    task_data = '''
      - name: A
        include: B
        apply:
            loop:
                - 1
                - 2
                - 3
    '''

    context = PlayContext()

# Generated at 2022-06-11 11:18:11.523902
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    preprocess_data_testdata = {
        'action': 'include',
        'invalid_attr': 'bar',
    }

    ti = TaskInclude()
    ti.preprocess_data(preprocess_data_testdata)

    assert 'invalid_attr' not in preprocess_data_testdata
    assert preprocess_data_testdata == {
        'action': 'include',
    }

    preprocess_data_testdata = {
        'action': 'include_role',
        'invalid_attr': 'bar',
    }

    ti = TaskInclude()
    ti.preprocess_data(preprocess_data_testdata)

    assert 'invalid_attr' not in preprocess_data_testdata

# Generated at 2022-06-11 11:18:19.250917
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Ensure that given the following playbook with ``apply`` specified
    # ``build_parent_block`` creates a parent block with the correct
    # attributes

    vars = dict()
    playbook = {}
    block_data = {
        'block': [],
        'apply': 'something',
        'other_attr': 'some',
        'other_attr2': 'thing',
    }
    ti = TaskInclude()
    pb = ti.build_parent_block(playbook, vars, block_data)

    assert pb is not None
    for key in ('apply', 'other_attr', 'other_attr2'):
        assert key in pb.args


# Generated at 2022-06-11 11:18:25.359279
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Tests to validate get_vars() in different scenarios
    '''
    # ############  Scenario 1: Run include as task ############
    # root block
    root_block = Block()
    root_block.role = None
    root_block.vars = dict(a='A')
    # task include
    task_include = TaskInclude(root_block)
    task_include.args = dict(b='B')
    task_include.vars = dict(c='C')
    task_include.action = 'include'
    # check results
    assert task_include.get_vars() == dict(a='A', b='B', c='C')

    # ############  Scenario 2: Run import_tasks as task ############
    # root block
    root_block = Block

# Generated at 2022-06-11 11:18:33.485894
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # first we setup a simple test playbook with a single include_role task
    # which has no parameters
    t = dict(
        block=dict(
            name="test playbook",
            tasks=[
                dict(action="include_role", args={"role": "some_role"})
            ]
        ),
        hostvars=dict()
    )

    # now we execute the task include for this task dictionary
    # which is then stored in the block
    block = Block.load(t['block'], play=None)

    # now we retrieve the first task from the block
    task = block.block[0]
    # and run get_vars for this task
    vars = task.get_vars()

    # Now the interesting part: the vars should include all variables from
    # the play context and the block, however they must

# Generated at 2022-06-11 11:18:41.716846
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    display.debug('Test TaskInclude.build_parent_block')
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    myplay_data = dict(
        name = "dummy play",
        hosts = "localhost",
        gather_facts = "no",
        tasks = [
            dict(
                include = "include_set.yml",
                apply = dict(
                    block = [
                        dict(
                            listen = "include_listen_block"
                        )
                    ]
                )
            )
        ]
    )

    v

# Generated at 2022-06-11 11:18:50.684295
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # First, create a simple task
    my_task = TaskInclude()
    my_task.args['apply'] = {'x': 1, 'y': 2}

    # Then, create a parent for the simple task
    my_block = Block.load(None, play=None, task_include=my_task, role=None, variable_manager=None, loader=None)

    # Set the parent to the simple task
    my_task._parent = my_block

    # Finally, build the parent for the task
    parent_block = my_task.build_parent_block()

    # Assert that the parent block of the parent block is the task itself
    assert my_block._parent == my_task
    # Assert that the parent task has been removed
    assert my_task.args.get('apply') is None
    # Assert

# Generated at 2022-06-11 11:19:00.016306
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.definition import RoleDefinition

    class MockParent(object):
        def __init__(self, vars_dict):
            self.vars_dict = vars_dict

        def get_vars(self):
            return self.vars_dict

        def get_block_vars(self):
            return self.vars_dict


# Generated at 2022-06-11 11:19:08.349255
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block as PLY
    ds = {'action': 'include_tasks', 'file': 'x.yml'}

    try:
        TaskInclude.load(ds, variable_manager=None)
        assert False
    except AnsibleParserError:
        pass
    else:
        assert False

    # Passing the test
    ds = {'action': 'include_tasks', 'file': 'x.yml', 'loop': 'x'}
    TaskInclude.load(ds, variable_manager=None)

    ds = {'action': 'include_tasks', 'loop': 'x'}
    task = TaskInclude.load(ds, variable_manager=None)
    assert task.args == {'_raw_params': None, 'loop': 'x'}

    d

# Generated at 2022-06-11 11:19:51.724856
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # TaskInclude.build_parent_block should return self if no apply is specified
    task = TaskInclude.load(dict(action='include', file='/not/exist'))
    assert task == task.build_parent_block()

    # TaskInclude.build_parent_block should return a new Block using the values
    # specified for apply when present
    block = Block.load(
        dict(block=[dict(action='debug', msg='debug')]),
        play=object(),
        task_include=task,
        role=object(),
        variable_manager=object(),
        loader=object(),
    )
    block.vars = dict(a=1)
    task = TaskInclude.load(dict(action='include', file='/not/exist', apply=dict(b=2)))
    assert block == task.build_

# Generated at 2022-06-11 11:20:00.433328
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude(task_include=None)
    action = 'include'
    data = dict(action=action, ignore_errors=False, name='Include role')

    # test TaskInclude._validate_tags
    task.check_options(task.load_data(data=data), data)
    assert task.args.get('_raw_params') == 'Include role'

    # test TaskInclude._validate_tags - test with include action
    task.action = 'include'
    data = dict(action=action, ignore_errors=False, tags=['web', 'nginx'], name='Include role')
    task.check_options(task.load_data(data=data), data)
    assert task.args.get('_raw_params') == 'Include role'

# Generated at 2022-06-11 11:20:09.220116
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    import ansible.inventory.group

    class DataLoaderForTest(DataLoader):
        def get_real_file(self, path):
            return path


# Generated at 2022-06-11 11:20:18.724075
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    with pytest.raises(AnsibleParserError) as excinfo:
        TaskInclude.load({'action': 'include', 'args': {'file': 'some_file.yml', 'unknown_option': 'whatever'}})
    assert 'Invalid options for include' in str(excinfo.value)

    with pytest.raises(AnsibleParserError) as excinfo:
        TaskInclude.load({'action': 'import_role', 'args': {'file': 'some_file.yml', 'unknown_option': 'whatever'}})
    assert 'Invalid options for import_role' in str(excinfo.value)


# Generated at 2022-06-11 11:20:20.981095
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # FIXME: the unit test for this method is not added because it calls
    # functions from class Task which are not implemented yet.
    pass

# Generated at 2022-06-11 11:20:31.588519
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # pylint: disable=unused-variable
    class TestTaskInclude(TaskInclude):
        VALID_ARGS = frozenset(('a', 'b', '_raw_params'))
        VALID_INCLUDE_KEYWORDS = frozenset(('a', 'no_log', 'tags'))

        def __init__(self, block=None, role=None, task_include=None):
            super(TestTaskInclude, self).__init__(block=block, role=role, task_include=task_include)

    # Define a valid task
    data1 = {
        'a': 1,
        'no_log': False,
        'tags': ['all'],
        '_raw_params': 'file1.yml'
    }

    # create a TaskInclude instance

# Generated at 2022-06-11 11:20:39.873701
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.block as ablock
    from ansible.playbook.task import Task
    data = {'when': 'success', 'async': 5, 'poll': 1, 'name': 'test_block'}
    block = ablock.Block.load(data, task_include=True, role=None, variable_manager=None, loader=None)
    ti = TaskInclude(block=block, task_include=None, role=None)
    ti._parent = Task(block=block, task_include=None, role=None)
    ti.action = 'include_tasks'
    ti.args = {'apply': {'name': 'some_name'}}
    p_block = ti.build_parent_block()