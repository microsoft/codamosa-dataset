

# Generated at 2022-06-11 11:10:47.144089
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test case when action is 'include'
    # Test case when action is not 'include'
    # Test case when action is 'include_role'
    # Test case when action is not 'include_role'
    # Test case when action is 'import_role'
    # Test case when action is not 'import_role'
    # Test case when action is 'import_tasks'
    # Test case when action is not 'import_tasks'
    # Test case when action is 'include_tasks'
    # Test case when action is not 'include_tasks'
    pass

# Generated at 2022-06-11 11:10:54.221128
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()
    task_include.load(dict(action='include_tasks', file='some_file.yml'))
    print(task_include.args)
    assert task_include.action == 'include_tasks'
    assert task_include.args['file'] == 'some_file.yml'
    assert task_include.args['_raw_params'] == 'some_file.yml'
    assert 'apply' not in task_include.args

    print("The following set of tests apply to include_role, import_role and include_tasks")
    print("--------")

    task_include.load(dict(action='include_tasks', file='some_file.yml', apply={'foo': 'bar'}))
    print(task_include.args)
    assert task_include

# Generated at 2022-06-11 11:11:06.071265
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    ti = TaskInclude()
    assert ti.load({'action': 'include', '_raw_params': 'tasks.yml'})
    assert ti.load({'action': 'import_tasks', '_raw_params': 'tasks.yml'})
    assert ti.load({'action': 'include_vars', '_raw_params': 'tasks.yml'})

    assert ti.load({'action': 'include_role', '_raw_params': 'tasks.yml'})
    assert ti.load({'action': 'include_role', '_raw_params': 'tasks.yml', 'apply': {}})

# Generated at 2022-06-11 11:11:10.154842
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = Task()
    task.action = 'action'
    task.args = {'file': 'file', 'debugger': 'debugger', 'invalid': 'invalid'}
    try:
        task = task_include.check_options(task, {})
    except AnsibleParserError as e:
        assert str(e) == "Invalid options for action: invalid options"

    task = Task()
    task.action = 'action'
    task.args = {'file': 'file', 'debugger': 'debugger', 'invalid': 'invalid'}
    task.action = 'include'

# Generated at 2022-06-11 11:11:17.242612
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti._play_context = PlayContext()
    task = {"debugger": "always", "not_allowed": "test", "action": "include_role"}

    # Test for allowed attribute
    data = ti.preprocess_data(task.copy())
    assert "debugger" in data
    assert "action" in data
    assert "not_allowed" not in data

    # Test without allowed attribute
    task.pop("debugger")
    data = ti.preprocess_data(task.copy())
    assert "debugger" not in data
    assert "action" in data



# Generated at 2022-06-11 11:11:24.451820
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a new TaskInclude instance
    ti = TaskInclude()

    # Set some attributes
    ti.action = 'include'
    ti.args = {'_raw_params': 'sample-playbook.yml'}
    ti.vars = {'var1': 'val1'}

    # Check if method get_vars returns correct variables
    assert ti.get_vars() == {'var1': 'val1', '_raw_params': 'sample-playbook.yml'}

# Generated at 2022-06-11 11:11:34.417328
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude(
        block=None,
        role=None,
        task_include=None,
        _parent=Block(
            play=None,
            role=None,
            task_include=None,
            block=None,
            name='test_parent_block',
            vars={'test_parent_block': True},
        )
    )
    task.vars = {'test_task': True}
    task.args = {'test_args': True}
    task.action = 'test_action'

    assert task.get_vars() == {
        'test_parent_block': True,
        'test_task': True,
        'test_args': True,
    }

# Generated at 2022-06-11 11:11:45.300163
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    from ansible.vars.manager import VariableManager
    import ansible.inventory
    from ansible.executor.playbook_executor import PlaybookExecutor

    # To create a 'include' task that calls the method build_parent_block
    # we create a task of class 'TaskInclude' with a block that has a 'apply'
    # attribute and we call the method. After, we verify if a block is created
    # and we check if the attribute 'apply' is removed from the task object.
    parent = ansible.playbook.Play()
    p_block = ansible.playbook.Block(parent)
    task = ansible.playbook.TaskInclude(block=p_block)
    apply_attrs = {'apply': {'name': 'test'}}

# Generated at 2022-06-11 11:11:54.996877
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test the pre-processing of data
    '''
    ti = TaskInclude()
    ds = {'action': 'include'}
    ds = ti.preprocess_data(ds)
    assert ds == {}

    # Ensure that 'include' as it could be a filename
    ds = {'action': 'include', 'include': 'foobar.yml'}
    ds = ti.preprocess_data(ds)
    assert ds == {'include': 'foobar.yml', 'action': 'include'}

    # Ensure all the following action types include 'file' as a valid task attribute
    ds = {'action': 'include_role', 'file': '/path/to/role'}
    ds = ti.preprocess_data(ds)

# Generated at 2022-06-11 11:12:05.348868
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # instantiate objects without calling the constructor
    task_include = type('TaskInclude', (TaskInclude,), {})

    # setup
    task = type('Task', (object,), {'action': 'include'})
    task.args = {'_raw_params': 'some_file.yml', 'some_unknown_param': 'some_value'}
    data = {'action': 'include', 'some_unknown_param': 'some_value'}

    with pytest.raises(AnsibleParserError) as execinfo:
        task_include.check_options(task, data)
    assert 'Invalid options for include: some_unknown_param' in str(execinfo.value)

    # setup
    task.action = 'import_playbook'
    task.args = {'apply': 'something'}
   

# Generated at 2022-06-11 11:12:18.492402
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    assert task.preprocess_data({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # check that 'include' is not an invalid attribute
    assert task.preprocess_data({'a': 1, 'include': 2}) == {'a': 1, 'include': 2}  # noqa: F821

    # invalid attributes
    with pytest.raises(AnsibleParserError) as exc:
        task.preprocess_data({'a': 1, 'b': 2, 'p': 3})
    assert "is not a valid attribute for a TaskInclude" in str(exc.value)

# Generated at 2022-06-11 11:12:27.812840
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from unit.mock.loader import DictDataLoader
    from unit.mock.vars import VariableManager

    tc = TaskInclude()
    data_loader = DictDataLoader({'test': dict(action='include', file='roles/a/tasks/main.yml'),
                                  'test_bad_arg': dict(action='import_playbook', foo='bar'),
                                  'test_apply': dict(action='import_role', file='roles/a', apply=['foo']),
                                  'test_apply_bad_dict': dict(action='import_role', file='roles/a', apply='foo')
                                  })
    variables = VariableManager()
    data = data_loader.load_from_file('test')

    # test

# Generated at 2022-06-11 11:12:38.995364
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    context = Templar(loader=loader)
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


    # Create a task with action 'include_tasks'
    include_task_data = {
        'name': 'test include_tasks',
        'action': 'include_tasks',
        'file': 'include_tasks.yml',
    }

    include_task = TaskInclude.load(include_task_data, variable_manager=variable_manager, loader=loader)
    assert include_task

# Generated at 2022-06-11 11:12:48.032901
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for action include
    args = {'tag': 'tag', 'when': 'when'}
    task_include_action_include = TaskInclude.load(data={'action': 'include', 'args': args}, variable_manager={}, loader={})
    assert task_include_action_include.action == 'include'
    assert task_include_action_include.get_vars() == args
    # Test if the parent is not None
    args = {'tag': 'tag', 'when': 'when'}
    task_include_action_include = TaskInclude.load(data={'action': 'include', 'args': args}, variable_manager={'k': 'v'}, loader={'k': 'v'})
    task_include_action_include._parent = Task()

# Generated at 2022-06-11 11:12:58.591187
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test the method ``build_parent_block`` of the class ``TaskInclude``.
    '''
    import ansible.playbook.play

    abstract_task = TaskInclude()
    abstract_task._parent = ansible.playbook.play.Play()
    abstract_task._variable_manager = None
    abstract_task._loader = None
    abstract_task.args = {'apply': {'tags': ['a_tag']}}
    abstract_task.statically_loaded = False

    # check if the method returns a Block instance
    p_block = abstract_task.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.block is None
    assert p_block.block_type == 'meta'
    assert p_block.parent is abstract_task
    assert p

# Generated at 2022-06-11 11:13:09.356013
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test for method get_vars of class TaskInclude

    # task_include_myself
    task_include_myself = TaskInclude.load({'action': 'include', 'file': 'test.yml'})

    # task_include_parent is a parent of task_include_myself
    task_include_parent = TaskInclude.load({'action': 'include', 'file': 'test.yml'})
    task_include_parent.block = []
    task_include_myself._parent = task_include_parent

    # task_myself is included in task_include_myself

# Generated at 2022-06-11 11:13:19.793685
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import HandlerTaskInclude

    # Yes we are testing for task and handler here, but TaskInclude and HandlerTaskInclude
    # share the same behavior for check_options as long as it is used only with action='include'
    for cls in (TaskInclude, HandlerTaskInclude):
        # Testing valid arguments
        data = {
            "include": "valid",
            "action": "include",
            "file": "test1.yml",
            "_raw_params": "test1.yml",
            "args": {},
        }
        task = cls(action='include').check_options(cls.load_data(data, variable_manager=None, loader=None), data)
        assert task._parent is None
        assert task.action == 'include'

# Generated at 2022-06-11 11:13:30.715715
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # Test a task without any args
    task_no_args = Task()
    task.check_options(task_no_args, {})
    # Test a task with only the valid args
    task_no_bad_args = Task(action='include', args={'_raw_params': '...'})
    task.check_options(task_no_bad_args, {})
    # Test a task with an invalid arg
    task_bad_arg = Task(action='include', args={'_raw_params': '...', 'file': '...'})
    try:
        task.check_options(task_bad_arg, {})
        assert False, 'Should have thrown an error but did not'
    except AnsibleParserError:
        pass
    # Test a task with valid args and an invalid

# Generated at 2022-06-11 11:13:37.724523
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a fake task
    class FakeTask:
        def __init__(self):
            self.vars = dict()

    # Create the TaskInclude object we are testing
    task_include = TaskInclude()
    task_include._parent = FakeTask()
    task_include._parent.vars = dict(var1="value1_parent")
    task_include.vars = dict(var2="value2_child")
    task_include.args = dict(var3="value3_args")

    # Test it
    vars = task_include.get_vars()
    assert isinstance(vars, dict), 'get_vars() must return a dict'

# Generated at 2022-06-11 11:13:48.064287
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = TaskInclude(block=None, role=None, task_include=None)
    task.action = 'include'
    task.args.update({'apply': {'block': 'block_0'}})
    p_block = task.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.block == 'block_0'
    assert p_block._parent == task

    task.action = 'include_role'
    del task.args['apply']
    p_block = task.build_parent_block()
    assert isinstance(p_block, TaskInclude)
    assert p_block == task
    assert p_block._parent is None

# Generated at 2022-06-11 11:14:04.285679
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    display.WARNINGS = False

    # Empty dict
    data = dict()
    TaskInclude.load(data)

    # Empty dict
    data = dict(
        include=dict(file=None)
    )
    TaskInclude.load(data)

    class MockTask:
        def __init__(self):
            self.action = 'include'
            self.args = dict()
            self.block = []
            self.notify = []
            self.tasks = []
            self.rescue = []
            self.always = []
            self.loop = []
            self._uuid = 'uuid'
            self.vars = dict()
            self.when = dict()
            self.when_filename = None
            self.when_file = None
            self.when_stat = None
            self.when

# Generated at 2022-06-11 11:14:12.332346
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    t = TaskInclude()
    t._task_include = None
    t._action = 'include'
    t._parent = Play()
    t.vars = {'foo': 'bar'}
    t.args = {'this': 'that'}

    v = VariableManager(vars_cache={})
    v.set_host_variable('127.0.0.1', 'localhost', 'hello', 'world')
    t._variable_manage

# Generated at 2022-06-11 11:14:22.079074
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This test verifies the connection between the task and its parent block.
    '''
    import pytest
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DummyLoader()
    variable_manager = VariableManager()

    task_include = TaskInclude.load(
        dict(
            apply=dict(
                block=[]
            )
        ),
        variable_manager=variable_manager,
        loader=loader,
    )

    play = Play.load(dict(
        name='test',
        hosts=['all'],
        roles=[]
    ), variable_manager, loader)

# Generated at 2022-06-11 11:14:30.877474
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # Test with all possible 'include' arguments
    data = dict(
        action='include',
        file='some_file',
        name='some name',
        tags='tag one,tag two',
        when='some condition',
    )
    task = TaskInclude.load(data)
    assert task.action == data['action']
    assert task.args['_raw_params'] == data['file']
    assert task.name == data['name']
    assert task.tags == ['tag one', 'tag two']
    assert task.when == data['when']

    # Test with case use of 'file' argument
    data = dict(
        action='include',
        FILE='some_file',
    )
    task = TaskInclude.load(data)
    assert task.args['_raw_params'] == data['FILE']



# Generated at 2022-06-11 11:14:42.039080
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    class TaskIncludeTest(TaskInclude):
        VALID_ARGS = frozenset(('var1', 'var2', 'var3', 'var4'))
        VALID_INCLUDE_KEYWORDS = frozenset(('var1', 'var2', 'var3', 'var4'))

    def run_check_options(data):
        task = TaskIncludeTest(None, None)
        return task.check_options(task.load_data(data, None, None), data)

    data = {'var1': 'value1'}
    assert run_check_options(data).args == {'var1': 'value1'}

    data = {'var1': 'value1', 'var2': 'value2'}

# Generated at 2022-06-11 11:14:49.656931
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    # dicts that do not contain the key 'action'
    assert task.preprocess_data({}) == {}
    assert task.preprocess_data({'foo': True}) == {'foo': True}
    assert task.preprocess_data({'foo': True, 'action': 'foo'}) == {'foo': True, 'action': 'foo'}
    # dicts that contain the key 'action', but with invalid actions
    assert task.preprocess_data({'action': 'foo'}) == {'action': 'foo'}
    assert task.preprocess_data({'action': 'static', 'foo': True}) == {'action': 'static', 'foo': True}

# Generated at 2022-06-11 11:14:50.953239
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    assert False, "TODO: test_TaskInclude_load"

# Generated at 2022-06-11 11:15:01.556911
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    def test_task_include_preprocess_data_action_include(action):
        test_ds = {
            'name': 'test_file.yml',
            'apply': {},
        }
        test_ds[action] = 'test_file.yml'
        ds = TaskInclude.preprocess_data(test_ds, False)
        assert len(ds) == 2
        assert ds.get(action) == 'test_file.yml'
        assert ds.get('name') == 'test_file.yml'

    for action in C._ACTION_INCLUDE_TASKS:
        test_task_include_preprocess_data_action_include(action)


# Generated at 2022-06-11 11:15:03.874699
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Object to test
    obj = TaskInclude()

    # Test with an empty dictionary.
    obj.load({})
    assert obj._parent is None

# Generated at 2022-06-11 11:15:07.648546
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.load_data({'action': 'include', 'vars': {'x': 'y'}, 'args': {'z': 1}})
    assert ti.get_vars() == {'x': 'y', 'z': 1}

# Generated at 2022-06-11 11:15:20.186455
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = TaskInclude.load({
        "include": "abc.yml",
        "apply":{
            "remote_user": "bob",
            "sudo": "yes"
        }
    })
    parent_block = task.build_parent_block()
    assert isinstance(parent_block, Block)
    assert parent_block.remote_user == "bob"
    assert parent_block.sudo == "yes"
    assert parent_block.block == []

# Generated at 2022-06-11 11:15:30.462007
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # when: action is a type of include
    # then: validates 'apply' attribute
    # and: does not validate bad args
    task_dict = {'action': 'include', 'apply': 'foo'}
    task = TaskInclude.check_options(TaskInclude(), task_dict)
    assert isinstance(task.args.get('apply'), dict)

    task_dict = {'action': 'include', 'bad_opt': 'foo'}
    task = TaskInclude.check_options(TaskInclude(), task_dict)
    assert len(task.args) == 1
    assert 'bad_opt' in task.args

    # when: action is not a type of include
    # then: does not validate 'apply' attribute
    # and

# Generated at 2022-06-11 11:15:39.595081
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    Unit test for method check_options of class TaskInclude.
    It is not named 'test_validate_options' on purpose to
    prevent confusion with '_validate_*" methods.
    """
    task = TaskInclude()
    data = dict(
        action='import_role',
        file='role1',
        ignore_errors=True,
        abc='xyz',
        apply={}
    )
    with pytest.raises(AnsibleParserError) as e:
        task.check_options(task.load_data(data), data)
    assert 'Invalid options for import_role: abc' in e.value.message
    assert 'Unexpectedly found apply for action import_role' in e.value.message


# Generated at 2022-06-11 11:15:47.476295
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class MyTask(TaskInclude):
        def __init__(self, _parent=None, **kwargs):
            self._parent = _parent
            super(MyTask, self).__init__(**kwargs)

    parent_block = Block(sentinel.parent_play)
    parent_block._vars_cache = {'a': '1', 'b': '2'}
    parent_block.vars = {'c': '3'}
    my_task = MyTask(action='include_tasks', args={'a': '4'}, parent=parent_block)
    assert my_task.get_vars() == {'a': '1', 'b': '2', 'c': '3', 'a': '4'}

# Generated at 2022-06-11 11:15:55.020399
# Unit test for method load of class TaskInclude

# Generated at 2022-06-11 11:16:03.189800
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    sample_one = {
        "action": "include",
        "args": {
            "apply": {},
            "file": "some/path"
        }
    }
    sample_two = {
        "action": "include",
        "args": {
            "apply": {},
            "file": "some/path",
            "other_arg": "some_value"
        }
    }
    sample_three = {
        "action": "include_role",
        "args": {
            "apply": {},
            "file": "some/path",
            "other_arg": "some_value"
        }
    }

# Generated at 2022-06-11 11:16:11.974190
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    task = Task()
    task.action = 'include'
    task_include = TaskInclude()

    # Assign good args
    task.args = {
        'file': 'file',
        '_raw_params': '_raw_params',
        'apply': {},
    }
    task_include.check_options(task, {})
    assert task._raw_params == 'file'
    assert task.args['file'] is None
    assert task.args['_raw_params'] == '_raw_params'
    assert 'apply' in task.args
    assert task.args['apply'] == {}

    # No file specified
    task.args = {}

# Generated at 2022-06-11 11:16:21.477978
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Three different cases to unit test.
    #
    # Use an example of "include" task followed by regular task
    # containing vars.
    #
    # In case of include, Task.get_vars() should return vars
    # only of current task(include), and not of regular task.
    #
    # In case of regular task, Task.get_vars() should return vars
    # of all the tasks.
    #
    # In case of regular task, but inside a block, only vars of
    # current task should be considered.

    from ansible.playbook import Play, Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play as PlayDS
    from ansible.playbook.block import Block as BlockDS

# Generated at 2022-06-11 11:16:30.603835
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    task = Task()
    play = Play().load({'name': 'test_play', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=VariableManager(), loader=None)
    # assert normal tasks do not raise errors

# Generated at 2022-06-11 11:16:39.937594
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = Block()
    role = object()
    vars = FieldAttribute(
        field_names=('vars',),
        include_role=True,
        include_task=True
    )
    attrs = FieldAttribute(
        field_names=('attrs',),
        include_role=False,
        include_task=True,
    )
    args = FieldAttribute(
        field_names=('args',),
        include_role=True,
        include_task=True
    )

    task_include = TaskInclude(block=block, role=role)
    args(task_include, {'apply': {'name': 'foo', 'vars': {'myvar': 'myvalue'}}})
    assert task_include.args['apply']['name'] == 'foo'

# Generated at 2022-06-11 11:17:04.234825
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    task, data = task_include.check_options(
        task_include.load_data({'include': 'myfile.yml'}, variable_manager=None, loader=None),
        {'include': 'myfile.yml'}
    )
    assert task.args['_raw_params'] == 'myfile.yml'

    task, data = task_include.check_options(
        task_include.load_data({'include_role': 'myfile.yml'}, variable_manager=None, loader=None),
        {'include_role': 'myfile.yml'}
    )
    assert task.args['_raw_params'] == 'myfile.yml'


# Generated at 2022-06-11 11:17:11.143336
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''Test for TaskInclude.build_parent_block() method'''
    # Since we can only verify that the returned parent block
    # is the same as the current object, we only test for
    # cases that return the current object.
    # The tests for the cases that return a new block are
    # in test_Block_load.

    # This will happen if no 'apply' is specified
    apply_attrs = None
    block = TaskInclude()
    block._parent = None
    assert block.build_parent_block() == block, 'No parent block is returned'

    # This will happen if 'apply' is specified, but is not a dict
    apply_attrs = 1
    block = TaskInclude()
    block._parent = None
    assert block.build_parent_block() == block, 'No parent block is returned'

# Generated at 2022-06-11 11:17:23.543718
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Not you cannot validate the task before adding it to the play.
    # You can validate the task after adding it to the play.

    # create the task without fail_on_undefined_errors
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory_from_list([{'hosts': ['testhost'], 'vars': {'foo': 'bar'}}]))
    context = PlayContext()

    task_data = dict(
        action='include',
        file='/test/test.yml',
        _raw_params='/test/test.yml',
    )

# Generated at 2022-06-11 11:17:32.781328
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.templating import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    data = '''
      - include: package.yml

      - include: {{ pkg_file }}
        no_log: false
        when: some_var

      - include: ./dir/roles/download/tasks/main.yml
        loop: "{{iterable}}"
        loop_control:
          loop_var: "{{item.name}}"
          label: "{{item.label | default(item.name, true)}}"

    '''
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager

# Generated at 2022-06-11 11:17:43.071420
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    class Task(TaskInclude):
        fields = {
            'action': FieldAttribute(isa='string'),
            'args': FieldAttribute(isa='dict', default=dict()),
            'apply': FieldAttribute(isa='dict'),
        }

    class Block(object):
        fields = {
            '_play': FieldAttribute(),
            '_role': FieldAttribute(),
            '_variable_manager': FieldAttribute(),
            '_loader': FieldAttribute(),
        }

    class ParentBlock(Block):
        fields = {
            'apply': FieldAttribute(isa='dict', default=dict())
        }


# Generated at 2022-06-11 11:17:53.838490
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test preprocess_data method of class TaskInclude. This will cover
    the call to super.preprocess_data method of TaskInclude and also
    the case where we do not have any keys in the task other than `action`
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    task_include = TaskInclude(block=Block(), task_include=Task())
    # test preprocess_data call to super.preprocess_data
    ds = dict(action='include', file='somefile.yml')
    assert task_include.preprocess_data(ds) == ds
    # test preprocess_data call with an empty dict
    ds = dict()
    assert task_include.preprocess_data(ds) == ds

# Generated at 2022-06-11 11:18:00.690814
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    t = TaskInclude('bla')
    assert t.load({"action": "include", "file": "./test_tasks/bla.yml"}, None)
    assert t.load({"action": "include", "file": "./test_tasks/bla.yml", "register": "bla"}, None)
    assert t.load({"action": "include", "file": "./test_tasks/bla.yml", "no_log": "True"}, None)
    assert t.load({"action": "include", "file": "./test_tasks/bla.yml", "ignore_errors": "True"}, None)

# Generated at 2022-06-11 11:18:11.145991
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    from ansible.playbook.task_include import TaskInclude

    class ParentTask(object):
        block  = None
        role   = None
        _role  = None
        action = 'include'

    # pylint: disable=too-many-arguments
    def load_data(task, data, parent_block=None, role=None, apply_attrs=None, task_include=None):
        # pylint: enable=too-many-arguments
        # pylint: disable=attribute-defined-outside-init
        task.parent = parent_block
        task.action = task._attributes.get('action', 'include')

# Generated at 2022-06-11 11:18:20.104755
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Unit tests for method check_options of class TaskInclude
    from ansible.playbook.task_include import TaskInclude

    class MockTaskInclude(TaskInclude):
        """
        Mock class that extends TaskInclude to make it easy to test method check_options
        """
        def __init__(self):
            super(MockTaskInclude, self).__init__()
            self.args = dict()

    # Test that a 'file' parameter is changed to '_raw_params'
    task = MockTaskInclude()
    task.action = 'include'
    task.args = dict(file='/tmp/foo')

    task = task.check_options(task, task.args)
    assert 'file' not in task.args
    assert task.args['_raw_params'] == '/tmp/foo'

   

# Generated at 2022-06-11 11:18:27.693041
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals

    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 11:19:13.664540
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class TestTaskInclude(TaskInclude):
        ACTION = 'action'
        VALID_INCLUDE_KEYWORDS = tuple()

    task = TestTaskInclude()

    # test with bad options and check that we raise
    with pytest.raises(AnsibleParserError):
        task.check_options({'action': task.ACTION, 'args': {'bad': 'option'}}, {'action': task.ACTION, 'args': {'bad': 'option'}})

    # test with apply outside of include
    with pytest.raises(AnsibleParserError):
        task.check_options({'action': task.ACTION, 'args': {'apply': 'non-dict'}}, {'action': task.ACTION, 'args': {'apply': 'non-dict'}})

    # test with apply as

# Generated at 2022-06-11 11:19:23.355359
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.connection import Connection
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_data = {
        "all": {
            "hosts": [
                "test_host1",
                "test_host2",
            ]
        }
    }

    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=inv_data))

# Generated at 2022-06-11 11:19:32.009762
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.group import Group
    from ansible.playbook.batch import Batch
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    # We don't use TaskInclude directly,
    # but its subclass HandlerTaskInclude instead.
    # TaskInclude is not used directly, but its subclass
    # HandlerTaskInclude is used in the tests.
    task = HandlerTaskInclude()

    # Test valid attributes

# Generated at 2022-06-11 11:19:38.086575
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    Unit test for method check_options of class TaskInclude
    """
    # try to create a task include without any options, should fail
    task = TaskInclude()
    # take some valid options
    data = dict(action='include', file='foo.yml')
    # add some invalid options
    data['foo'] = 'bar'
    data['baz'] = 42
    # try to check them (this will raise an exception)
    task.check_options(task.load_data(data), data)


# Generated at 2022-06-11 11:19:46.942176
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    try:
        # Test when apply is specified without attributes
        TaskInclude.load(dict(action='include', apply=dict()))
    except Exception as e:
        assert type(e) == AnsibleParserError and 'apply' in e.message
    else:
        raise AssertionError

    try:
        # Test when apply is specified with valid attributes
        TaskInclude.load(dict(action='include', apply=dict(x=1)))
    except Exception as e:
        assert type(e) == AnsibleParserError and 'apply' in e.message
    else:
        raise AssertionError


# Generated at 2022-06-11 11:19:56.146120
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    playbook_path = "/tmp/test_playbook.yml"
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=playbook_path)
    play_context = PlayContext()

# Generated at 2022-06-11 11:20:04.813720
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class Ti(TaskInclude):
        VALID_ARGS = frozenset(['foo', 'bar'])
        VALID_INCLUDE_KEYWORDS = frozenset(['foo', 'bar', 'include'])

    task = Ti()
    task.action = 'include'
    task.args = {'foo': 'foo', 'bar': True}
    assert task.check_options(task, {}) == task

    task.args = {'foo': 'foo', 'bar': True, 'baz': 'baz'}
    try:
        task.check_options(task, {})
    except AnsibleParserError as e:
        assert 'Invalid options for include: baz' in str(e)

    task.action = 'include_role'

# Generated at 2022-06-11 11:20:13.725052
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing import DataLoader
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    pc = PlayContext()
    task = TaskInclude()
    task.action = 'include'
    # When the action is 'include', the method get_vars of the TaskInclude class
    # returns the dict of vars and args
    # The vars and args are added to the include_vars dict
    # In this example, we add the vars of the parent block, the args of the
    # TaskInclude object and the args of the block of included tasks to the
    # dict include_vars.
    bl = Block()
    bl.vars = {'test': 'test'}
    bl._parent = task
    task.args = {'test2': 'test2'}

# Generated at 2022-06-11 11:20:23.944092
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Test the method check_options of the class TaskInclude.
    '''
    # initialize
    block = Block.load(
        dict(
            tasks=[
                dict(
                    action='include',
                    args=dict(
                        apply=dict(
                            a=1,
                            b=[2, 3],
                        ),
                        file='t.yml',
                    )
                )
            ],
            vars=dict(
                c=4,
            )
        )
    )
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # create the object
    ti = TaskInclude(block=block, role=role, task_include=task_include)

    # create the task to check

# Generated at 2022-06-11 11:20:31.494274
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    tsb_action = '''- include_tasks: test_task_block.yml
      apply:
        block:
          - debug:
              msg: hello world'''

    test_TaskInclude = TaskInclude.load(tsb_action, play=None, task_include=None, block=None, role=None)
    p_block = test_TaskInclude.build_parent_block()
    assert p_block.block[0].action == 'debug'
    assert p_block.block[0].args['msg'] == 'hello world'
