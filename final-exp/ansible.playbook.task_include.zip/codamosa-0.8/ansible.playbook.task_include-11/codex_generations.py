

# Generated at 2022-06-11 11:10:53.134945
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    t = TaskInclude()
    ds = {
        'action': 'include_tasks',
        'file': 'test.yaml',
        'ignore_errors': True,
        'apply': {},
        'unknown': 'this should raise an error',
    }

    t.preprocess_data(ds)

    assert ds['_raw_params'] == 'test.yaml'
    assert ds['apply'] == {}
    assert 'unknown' not in ds

    ds = {
        'action': 'include',
        'file': 'test.yaml',
        'ignore_errors': True,
        'apply': {},
        'other': 'other',
    }

    t.preprocess_data

# Generated at 2022-06-11 11:11:04.763587
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task1 = TaskInclude()
    task1_vars = task1.get_vars()
    assert task1_vars == {}

    task2 = TaskInclude(action="include")
    task2_vars_1 = task2.get_vars()
    task2.args = dict({'a': 1, 'b': 2})
    task2_vars_2 = task2.get_vars()
    assert task2_vars_1 == {}
    assert task2_vars_2 == dict({'a': 1, 'b': 2})

    task3 = TaskInclude(action="import_role")
    task3.vars = dict({'a': 1, 'b': 2})
    task3.args = dict({'a': 3, 'c': 4})

# Generated at 2022-06-11 11:11:14.315854
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This method tests the build_parent_block method of class TaskInclude
    We test two cases:
        - when apply attributes are specified
        - when they are not
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    data = {"action": "include_tasks", "apply": {
        "block": {},
        "collections": "",
        "debugger": "",
        "tags": [],
        "when": "",
    }}
    play = Play().load(data, variable_manager=None, loader=None)
    assert isinstance(TaskInclude.load(data, play=play).build_parent_block(), Block)

# Generated at 2022-06-11 11:11:25.950306
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # test valid options
    valid_options = ('name', 'tags', 'ignore_errors', 'register', 'run_once', 'when', 'include', 'vars', 'loop', 'timeout', 'loop_with', 'debugger')
    test_data = dict((key, 'test') for key in valid_options)
    # include action takes any valid option
    test_data['action'] = 'include'
    # test invalid options
    test_data['invalid_option'] = '123'
    # Expected result: no exception is raised
    TaskInclude.load(test_data)

    # Test for 'include_tasks' action
    test_data['action'] = 'include_tasks'
    # The only valid option for 'include_tasks' is 'name'
    for key in valid_options:
        del test_

# Generated at 2022-06-11 11:11:36.823060
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Allowed use cases are:
        - name + include_tasks/include_role
        - name + import_playbook + include_tasks/include_role
        - name + include_tasks/include_role + apply
        - name + import_playbook + include_tasks/include_role + apply
        - include_tasks/include_role
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.utils.data import DataLoader

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

    # We need to bypass the initial check of ans

# Generated at 2022-06-11 11:11:48.316360
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task_include_data_file = dict(action='test', args=dict(_raw_params='test'))
    task_invalid_options = dict(action='test', args=dict(_raw_params='test', debug='true'))
    task_not_loaded = ti.load(task_invalid_options)
    task_loaded = ti.load(task_include_data_file)

    ti.check_options(task_loaded, task_include_data_file)
    try:
        ti.check_options(task_not_loaded, task_invalid_options)
        assert(False)
    except AnsibleParserError:
        assert(True)

    task_invalid_apply = dict(action='include', args=dict(_raw_params='test', apply='true'))

# Generated at 2022-06-11 11:11:56.378573
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include._action = 'include_tasks'
    task_include.vars = {
        'a': 1,
        'b': 2,
    }
    task_include.args = {
        'a': 10,
        'c': 3,
        'tags': None,
        'when': None
    }
    assert task_include.get_vars() == {'a': 10, 'b': 2, 'c': 3}

    task_include._action = 'include_role'
    task_include.vars = {
        'a': 1,
        'b': 2,
    }
    task_include.args = {
        'a': 10,
        'c': 3,
        'tags': None,
        'when': None
    }
   

# Generated at 2022-06-11 11:12:03.528941
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Check that it returns a Block instance when 'apply' is specified
    ti = TaskInclude()

    ti.args = {'apply': {"name": "myapply"}}
    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)

    # Check that it returns an instance of the class with 'apply' is not specified
    ti.args = {'not_apply': {"name": "myapply"}}
    p_block = ti.build_parent_block()
    assert isinstance(p_block, TaskInclude)

# Generated at 2022-06-11 11:12:14.029135
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    r = Role()
    r.get_vars = lambda: {'r_vars': 1}

    s = TaskInclude(role=r)
    s.action = 'include'
    s.vars = {'s_vars': 2}
    s.args = {'s_args': 3}

    assert s.get_vars() == {'r_vars': 1, 's_vars': 2, 's_args': 3}

    s.action = 'include_tasks'
    assert s.get_vars() == {'r_vars': 1, 's_vars': 2}

# Generated at 2022-06-11 11:12:23.482174
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    block1 = Block()
    block1.vars = { 'module_a_var': 'module_a_var_value' }
    block1.args = { 'module_a_arg': 'module_a_arg_value' }
    block2 = Block()
    block2.vars = { 'module_b_var': 'module_b_var_value' }
    block2.args = { 'module_b_arg': 'module_b_arg_value' }
    block2.block  = [ block1 ]
    block2.action = 'include'

    task_include = TaskInclude()
    task_include.vars

# Generated at 2022-06-11 11:12:43.023971
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude.load(dict(name='include1', action='include', args=dict(file='1.yml')))
    assert task_include.get_vars() == dict()

    block = Block.load(dict(rescue=[], always=[], name='include1'))
    task_include.set_load_path(['role', 'include'])
    task_include.set_loader(sentinel.loader)
    task_include.set_parent(block)

    assert task_include.get_vars() == dict(file='1.yml')

# Generated at 2022-06-11 11:12:46.984825
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    _test_TaskInclude_preprocess_data(action="include")
    _test_TaskInclude_preprocess_data(action="include_role")
    _test_TaskInclude_preprocess_data(action="import_playbook")
    _test_TaskInclude_preprocess_data(action="import_role")


# Generated at 2022-06-11 11:12:57.240892
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    task1 = TaskInclude(action='include')
    task2 = TaskInclude(action='include_tasks')
    task3 = TaskInclude(action='import_playbook')

    # Test task1: action is 'include'
    task1.args = {'x': 'foo'}
    assert task1.get_vars() == {'x': 'foo'}

    # Test task2: action is 'include_tasks'
    task2.args = {'x': 'foo'}
    assert task2.get_vars() == {'x': 'foo'}

    # Test task3: action is 'import_playbook'
    task3.args = {'x': 'foo'}
    assert task3.get_vars() == {'x': 'foo'}

    '''

# Generated at 2022-06-11 11:13:08.098217
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import BaseIncludeResolver

    c = PlayContext()
    p = Play().load({'name': 'test_play', 'hosts': 'localhost', 'gather_facts': 'no'}, variable_manager=None, loader=None)

    task1 = TaskInclude(block='my_block', role=None, task_include=None)

    task1.args = {
        'apply': {
            'name': 'my_block',
        }
    }
    task1._parent = p

    task1_block = task1.build_parent_block()
    assert task1_block._parent


# Generated at 2022-06-11 11:13:14.901364
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Imports not needed at runtime
    import ansible.playbook.block
    import ansible.playbook.task

    # Create a `task_include`
    ti = TaskInclude()

    # Create and assign a `Block` object to attribute `_parent` of `ti`
    ti._parent = ansible.playbook.task.Task()

    # The `args` dictionary of `ti` is populated
    ti.args = {
        'action': 'include_role',
        'apply': {
            'block': [],
            'block_args': {
                'define_vars': {
                    'some_var': 'some value'
                }
            }
        },
        'some_arg': 'some value'
    }

    # The `build_parent_block` method of `ti` is called
    p

# Generated at 2022-06-11 11:13:26.740615
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    import collections
    import pytest
    from ansible.utils.display import Display
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    display_mock = Display()

    def _check_options(action, args, expected_action=None, expected_args=None):
        task_include = TaskInclude()

        task_include.action = action
        task_include.args = args

        task = task_include.check_options(task_include, None)

        assert task.action == (expected_action or action)
        assert task.args == (expected_args if expected_args else args)

    # valid options
    _check_options('include', {'file': 'some_file.yml'})

# Generated at 2022-06-11 11:13:33.770813
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = Block()
    task_include = TaskInclude(block=block)
    task_include.args = dict()

    p_block = task_include.build_parent_block()
    assert p_block.__class__ == Block
    assert p_block.__dict__ == block.__dict__

    task_include.args = dict(apply=dict())

    p_block = task_include.build_parent_block()
    assert p_block.__class__ == Block
    assert p_block.__dict__ != block.__dict__

# Generated at 2022-06-11 11:13:43.790033
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TaskInclude
    # File
    # Apply
    task = TaskInclude()
    data = {'action': 'include', 'file': 'tasks/main.yaml'}
    task.check_options(task, data)

    data = {'action': 'include', 'file': 'tasks/main.yaml', 'apply': {'foo': 'bar'}}
    task.check_options(task, data)

    data = {'action': 'include', 'apply': {'foo': 'bar'}}
    try:
        task.check_options(task, data)
        assert False
    except AnsibleParserError:
        pass

    # Invalid option
    data = {'action': 'include', 'file': 'tasks/main.yaml', 'invalid_option': 'invalid_value'}
   

# Generated at 2022-06-11 11:13:54.874186
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """
    Unit test for method preprocess_data of class TaskInclude
    """
    def test_no_error(action, data, extra_attrs={}, **kwargs):
        task = TaskInclude.load(data, **kwargs)
        task.action = action
        task = task.preprocess_data(task.copy(exclude_parent=True, exclude_tasks=True)._task)
        assert 'apply' not in task
        assert 'no_log' not in task
        assert task._role is None
        assert task._finalize_me is True
        assert task.action == action
        assert task.statically_loaded is False
        assert isinstance(task.tags, set)
        assert isinstance(task.when, list)
        assert isinstance(task.vars, dict)

# Generated at 2022-06-11 11:14:04.625557
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    class MockVariableManager:
        def get_vars(self, loader=None, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True, use_cache=True):
            return {'mock_var': 'mock_value'}

    class MockLoader:
        pass

    task_include = TaskInclude()
    task = task_include.load(
        {
            'include': 'mock_file',
            'include_with_var': '{{ mock_var }}',
            'extra_attrs': 'attrs_value'
        },
        variable_manager=MockVariableManager(),
        loader=MockLoader()
    )

    assert(task.args['_raw_params'] == 'mock_file')

# Generated at 2022-06-11 11:14:24.791977
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    Block.CONSTANT_ATTRIBUTES = frozenset(('block', 'block_id', 'always', 'changed_when', 'ignore_errors', 'failed_when', 'delegate_to', 'register', 'run_once', 'when', 'retries', 'delay'))
    block = Block()
    name = FieldAttribute(parent=block)
    name.initialize(FieldAttribute.FIELD_TYPES[0], 'include')
    block.action = name
    args = FieldAttribute(parent=block)
    args.initialize(FieldAttribute.FIELD_TYPES[0], {'a1': 'a2'})
    block.args = args
    vars_ = FieldAttribute(parent=block)

# Generated at 2022-06-11 11:14:34.596344
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play_context
    import ansible.playbook.block
    import ansible.playbook.role

    apply_attrs = {'name': 'blah', 'handler': True}
    ti = TaskInclude()
    ti.args['apply'] = apply_attrs
    res = ti.build_parent_block()
    assert res == ti
    ti.args['apply'] = True
    p_block = res = ti.build_parent_block()
    assert isinstance(p_block, ansible.playbook.block.Block)
    assert p_block.block == []
    assert p_block.name == 'blah'
    assert p_block.handler
    assert p_block.task_include == ti
    assert p_block.play == ti.play
    assert p_block.role

# Generated at 2022-06-11 11:14:45.086715
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test get_vars, this will also test get_vars as defined in Task
    '''
    # let's create a TaskInclude instance
    my_task = TaskInclude()

    # add some data for vars, parent and args
    my_task.vars = {'this': 'vars'}
    my_task._parent = type('MockContainer', (object,), {'get_vars': lambda s: {'this': 'parent vars'}})()
    my_task.args = {'this': 'args'}

    # test for action include
    my_task.action = 'include'
    all_vars = my_task.get_vars()
    assert all_vars == {'this': 'args'}

    # test for action import_role
    my_task

# Generated at 2022-06-11 11:14:54.811018
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    assert TaskInclude.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                                            'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                                            'when'))

    ia = TaskInclude()
    assert ia.preprocess_data({'action': 'include_role', 'tags': ['foo', 'bar']}) == {'action': 'include_role', 'tags': ['foo', 'bar']}

# Generated at 2022-06-11 11:15:05.028618
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # the preprocess_data method should return a dictionary with the same keys than the original dictionary
    # and should not add extra keys to the dictionary
    data = {'action': 'include', 'file': 'something', 'key': 'value'}
    t = TaskInclude()
    result = t.preprocess_data(data)
    assert 'action' in result and 'file' in result and 'key' in result and len(result.keys()) == 3

    # the preprocess_data method should return a dictionary with the same keys than the original dictionary
    # and should not modify any of the keys that have a "real" value (i.e. not Sentinel)
   

# Generated at 2022-06-11 11:15:14.968725
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext

    myvars = dict(
        a='b',
        c='d',
        e='f',
        union=dict(
            a='j',
            b='k',
        )
    )

    play_context = PlayContext()
    play_context.variable_manager = ansible.playbook.VariableManager()
    play_context.variable_manager.extra_vars = myvars

    # test with action=include, which is the only case where we do some different logic
    inc = TaskInclude()
    inc.args['_raw_params'] = 'test.yml'
    inc.action = 'include'
    inc.set_loader(None)
    inc._play = None
    inc._variable_manager = play

# Generated at 2022-06-11 11:15:25.120937
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # *args is a list of tasks to be placed in the parent block
    def _test(tasks, action, **kwargs):
        t = TaskInclude.load({
            'name': 'test',
            'action': action,
            'block': tasks,
            'apply': kwargs
        })
        p_block = t.build_parent_block()
        assert p_block.block == tasks, 'Failed to build parent block for %s' % action

    for action in ('include_tasks', 'include_role',):
        _test(['task1', 'task2'], action)

    # Test with apply filter(s)

# Generated at 2022-06-11 11:15:35.426229
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.playbook_include import TaskIncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.utils import plugin_docs

    # Create a fake loader to be able to pass a fake inventory
    class FakeLoader:
        def __init__(self, inventory=None):
            self.inventory = inventory
    fake_loader = FakeLoader()

    # We need a fake variable_manager
    from ansible.vars import VariableManager
    fake_variable_manager = VariableManager()

    # We need a fake datasource
    class FakeDataSource:
        def __init__(self):
            self.path = '/dev/null'
    fake_ds

# Generated at 2022-06-11 11:15:43.703634
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pb = TaskInclude(block=None, role=None, task_include=None)
    # Example 1: apply is defined
    apply_attrs   = {'attrs': 'attrs', 'block': 'block'}
    args          = {'apply': apply_attrs}
    file_name     = 'file_name'
    test_ti_1     = TaskInclude(block=None, role=None, task_include=None)
    test_ti_1.args = args
    test_ti_1.args['_raw_params'] = file_name
    # Execute method
    build_parent_block_1 = test_ti_1.build_parent_block()
    # Assertion: method build_parent_block should return a Block
    assert isinstance(build_parent_block_1, Block)

# Generated at 2022-06-11 11:15:47.009078
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude(block=None, role=None, task_include=None)
    with pytest.raises(AnsibleParserError):
        task_include.args = {'apply': 'test'}
        task_include.build_parent_block()

# Generated at 2022-06-11 11:16:09.741670
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """Test parsing of 'action: include_role' statement - TaskInclude.get_vars() method.

    Cases:
    - include_role: action, arguments
    - include_tasks: action, arguments
    - include_vars: action, arguments
    """
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Initialize parameters
    loader = DataLoader()
    variable_manager = VariableManager()
    display.verbosity = 3


# Generated at 2022-06-11 11:16:18.874558
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import mock
    from ansible.playbook.play_context import PlayContext

    # load_data() will call the method build_parent_block() if 'apply' is specified in the attributes,
    # and the result will be returned by load_data()
    # This mock defines what build_parent_block() will return in case of 'apply' not specified
    # and in case of 'apply' specified
    mock_parent = mock.MagicMock()
    mock_parent.get_vars.return_value = dict()
    mock_parent._play = mock.MagicMock()
    mock_parent._play._variable_manager = mock.MagicMock()
    mock_parent._variable_manager = mock_parent._play._variable_manager
    mock_parent._role = mock.MagicMock()
    mock_parent._loader = mock.MagicM

# Generated at 2022-06-11 11:16:28.284887
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This function tests TaskInclude class method get_vars()
    '''
    import ansible.playbook.task_include

    # Create a task to include
    task_include = TaskInclude()
    # Create a parent task
    task_parent = TaskInclude()

    ###################################################
    # Case 1: 'include' task with apply and _parent
    ###################################################
    # Assign the parent to the task
    task_include._parent = task_parent
    # Assign an apply property to the task
    task_include.args = {"apply": "anything"}
    # Assert that task_include has the following vars
    assert task_include.get_vars() == {'apply': 'anything'} 

    ###################################################
    # Case 2: 'include' task with apply and no parent

# Generated at 2022-06-11 11:16:37.015924
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role

    class FakeRole(ansible.playbook.role.Role):
        def __init__(self):
            super(FakeRole, self).__init__()
            self._role_vars = dict()
            self._role_vars['task_vars'] = dict()
            self._role_vars['task_vars']['rolevars'] = dict()
            self._role_vars['task_vars']['rolevars']['key1'] = 'value1'
            self._role_vars['task_vars']['rolevars']['key2'] = 'value2'

# Generated at 2022-06-11 11:16:46.830697
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    class Mock(object):
        def __init__(self):
            pass

        def get_vars(self):
            return {}

    data = {
        "apply": {
            "name": "test",
            "block": [
                {
                    "include_role": {
                        "block": [
                            {
                                "debug": "msg=test"
                            }
                        ]
                    }
                }
            ]
        }
    }

    p = Mock()
    p._play = Mock()
    p._play.hostvars = {}
    p.get_vars = lambda: {}
    p.vars = {}

# Generated at 2022-06-11 11:16:56.736683
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # Validation of valid options
    data = {'action': 'include_tasks', 'file': 'some_file.yml', 'apply': {}, 'tags': ['tag1', 'tag2'],
            'ignore_errors': True}
    task.check_options(task.load_data(data), data)

    # Validation of invalid options
    data = {'action': 'include_tasks', 'file': 'some_file.yml', 'some_invalid_option': 'some_value'}

# Generated at 2022-06-11 11:17:07.130111
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    assert ti.preprocess_data({'include': ''}) == {'include': ''}
    assert ti.preprocess_data({'include': None}) == {'include': None}
    assert ti.preprocess_data({'include': 1}) == {'include': 1}
    assert ti.preprocess_data({'include': {}}) == {'include': {}}
    assert ti.preprocess_data({'include': 'foobar.yml'}) == {'include': 'foobar.yml'}
    assert ti.preprocess_data({'include': 'foobar.yml', 'other_opt': 'other'}) == {'include': 'foobar.yml'}
    assert ti.preprocess_data({'include': 'foobar.yml', 'tags': 'other'})

# Generated at 2022-06-11 11:17:18.203859
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    p = Play().load({
        'name': 'test play',
        'hosts': ['localhost'],
        'gather_facts': 'no',
        'tasks': [{
            'include_tasks': {
                'file': 'task_file.yml',
            },
        }],
    }, variable_manager=VariableManager(), loader=DictDataLoader())

    block_no_apply = p.get_blocks()[0].get_blocks()[0]


# Generated at 2022-06-11 11:17:29.225673
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This test checks whether the build_parent_block method of class
    TaskInclude returns the right value.
    '''
    # stubs
    play = {}
    role = {}
    variable_manager = {}
    loader = {}
    _self = TaskInclude(block={})

    # test 1: no apply attribute
    expected = _self
    actual = _self.build_parent_block()
    assert actual is expected, "expected %r but got %r for test 1" % (expected, actual)

    # test 2 apply attribute
    _self.args = {
        'apply': {
            'block': [],
        },
    }

# Generated at 2022-06-11 11:17:36.886252
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test for method get_vars of class TaskInclude
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import VariableResolver
    from ansible.vars.hostvars import HostVars

    p = Play.load(dict(
        name = "a play with a task include",
        hosts = 'myhosts',
        gather_facts = 'no',
        roles = ['web'],
        tasks = [ dict(include='other.yml', n='a'), dict(include='my.yml', z='c')],
    ))
    #

# Generated at 2022-06-11 11:17:56.405107
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # Common to all TaskInclude classes
    assert ti.VALID_INCLUDE_KEYWORDS == frozenset(('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control',
                                                   'loop_with', 'name', 'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars',
                                                   'when'))

    # 'file' to '_raw_params' renaming
    task = ti.check_options(
        ti.load_data(dict(file='foo.yml', name='name', other_arg='foo')),
        dict(file='foo.yml', name='name', other_arg='foo')
    )


# Generated at 2022-06-11 11:18:05.676606
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude as ti
    from ansible.playbook.task import Task

    apply_attrs = {'debugger': {'connect': True, 'port': 4444}}
    data = {
        'action': 'include_role',
        'file': 'include_role_file.yml',
        'apply': apply_attrs
    }

    task = ti.load(data, loader=None)
    assert isinstance(task, Task)
    assert 'file' not in task.args
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == 'include_role_file.yml'
    assert 'apply' not in task.args
    assert task.block.apply == apply_attrs


# Generated at 2022-06-11 11:18:15.853629
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    yaml_data = '''
    - action: include a=1 b=2
      args:
        apply:
          block: []
          when: 1
          rescue: []
          always: []
    '''

    play_context = {}
    loader = None

    pb = Play().load(yaml_data, play_context, loader=loader)
    ti = pb.get_blocks()[0].block[0]

    assert isinstance(ti, TaskInclude)
    assert isinstance(ti.args['apply'], dict)

    p_block = ti.build_parent_block()

    assert isinstance(p_block, Block)
   

# Generated at 2022-06-11 11:18:23.472073
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test the get_vars method.
    '''

    # Include action that requires no variables
    no_var_action = 'pause'
    task_incl_name_no_var_action = 'pause'
    task_incl_no_var_action = TaskInclude(name=task_incl_name_no_var_action, action=no_var_action)

    assert task_incl_no_var_action.get_vars() == dict()

    # Include action that requires variables
    var_action = 'include'
    task_incl_name_var_action = 'include'
    task_incl_var_action = TaskInclude(name=task_incl_name_var_action, action=var_action)

    # Parent block that includes variables
    parent_block_name

# Generated at 2022-06-11 11:18:31.421993
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.role, ansible.playbook.play
    p = ansible.playbook.play.Play()
    r = ansible.playbook.role.Role()
    task = TaskInclude.load(dict(action='include', file='test'), role=r, block=None)
    # file is set because it's a base option
    assert task.args.get('file') == 'test'
    task = TaskInclude.load(dict(action='include', file='test', apply={}), role=r, block=None)
    assert task.args.get('apply') == {}
    task = TaskInclude.load(dict(action='include', file='test', apply='test'), role=r, block=None)
    assert isinstance(task.args.get('apply'), dict)
    # Invalid values for

# Generated at 2022-06-11 11:18:39.009955
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # load data to test
    data = {
        'action': 'include',
        'args': {
            'apply': {
                'block': [],
                'name': 'apply',
                'when': ['bool_val'],
            },
            'file': 'my_file.yml',
        },
    }

    task = TaskInclude.load(data)
    parent_block = task.build_parent_block()

    # assert() statements
    assert len(parent_block._parent._block) == 1
    assert isinstance(parent_block._parent._block[0], Block)
    assert len(parent_block._parent._block[0].block) == 0
    assert parent_block._parent._block[0].name == 'apply'

# Generated at 2022-06-11 11:18:40.078888
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pass


# Generated at 2022-06-11 11:18:49.115418
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    taskinclude = TaskInclude()
    taskinclude._parent = Block()
    taskinclude._parent.vars = dict()
    taskinclude.vars = dict()
    taskinclude.args = dict()

    # Normal behavior of get_vars
    assert taskinclude.get_vars() == dict()

    # Normal behavior of get_vars
    taskinclude._parent.vars = dict(a=3)
    assert taskinclude.get_vars() == dict(a=3)

    # Normal behavior of get_vars
    taskinclude.vars = dict(b=5)
    assert taskinclude.get_vars() == dict(a=3, b=5)

    # Normal behavior of get_vars
    taskinclude.args = dict(c=8)

# Generated at 2022-06-11 11:18:53.482908
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Arrange
    task_include = TaskInclude()
    task_include.args = {
        '_raw_params': 'some_file',
        'apply': {}
    }
    task = None
    data = None

    # Act
    task = task_include.check_options(task_include, data)

    # Assert
    assert task == task_include

# Generated at 2022-06-11 11:19:02.669652
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import action_loader

    mock_play = Play().load({'name': 'test', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=None, loader=None)

    t_attr = FieldAttribute(display=True)
    block = Block()
    block.block  = [Task()]
    block.role = RoleDefinition()
    block.action = 'block'
    block.block = [Task()]
    p_block = block.copy()
    p_block.role = RoleDefinition()
    task = TaskInclude(block=p_block)
    task.action = 'include'

# Generated at 2022-06-11 11:19:31.912633
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import sys
    import StringIO

    class Options:
        def __init__(self):
            self.tags = None
            self.action = None

    from ansible.playbook.task_include import TaskInclude as TI
    from ansible.playbook.task import Task

    # Test an empty TaskInclude
    options = Options()
    options.action = 'include'
    ti = TI(task_include=options)
    if ti.check_options(ti, {}) != ti:
        raise AssertionError("'check_options' did not return the same TaskInclude")

    # Test TaskInclude with a bad argument
    options = Options()
    options.action = 'include'
    options.args = {"foo": "bar"}
    ti = TI(task_include=options)

# Generated at 2022-06-11 11:19:40.521055
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import pytest

    class MockLoader:
        def get_basedir(self, *args, **kwargs):
            return '.'


    file_name = 'test_TaskInclude_check_options.yml'

# Generated at 2022-06-11 11:19:49.789624
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block

    # Invalid options for action 'include'
    block = Block()
    block.apply_implementation()

    task = TaskInclude(block=block)
    task.action = 'include'
    task.args = {'file': '/etc/motd', 'foo': 'bar'}
    task.args['_raw_params'] = task.args.pop('file', None)

    try:
        task.check_options(task, None)
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('AnsibleParserError was not raised')

    # Invalid options for action 'import_playbook'
    block = Block()
    block.apply_implementation()

    task = TaskInclude(block=block)

# Generated at 2022-06-11 11:19:58.882487
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a dummy model, with parent, to get the get_vars() method to run
    _result = TaskInclude.load(
        {
            'block': [{
                'module': 'foo'
            }],
            'include': 'some-file.yml'
        },
        Block(
            task=TaskInclude(
                block=Block(),
                role=None,
                task_include=None
            ),
            play=None,
            task_include=None,
            role=None,
            variable_manager=None,
            loader=None,
        ),
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )

    # Make the call we are testing
    result = _result.get_vars()

    # Check the result

# Generated at 2022-06-11 11:20:07.286978
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    The method TaskInclude.build_parent_block returns a block based on the apply
    attributes specified.
    '''
    apply_attrs = {'ignore_errors': True}
    task = TaskInclude()
    parent_block = task.build_parent_block()
    assert isinstance(parent_block, Block)
    assert 'ignore_errors' not in task.args


    task = TaskInclude()
    task.args = {'apply': apply_attrs}
    parent_block = task.build_parent_block()
    assert isinstance(parent_block, Block)
    assert parent_block.ignore_errors is True
    assert 'apply' not in task.args
    assert parent_block.block == []
    assert parent_block.task_include == task
    assert parent_block.task_level

# Generated at 2022-06-11 11:20:16.718930
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude.load(dict(
        action='include_role',
        args=dict(
            name='test_role',
            tasks_from='test'
        ),
    ))
    assert ti.get_vars() == dict()

    ti = TaskInclude.load(dict(
        action='import_tasks',
        args=dict(
            name='test_role',
        ),
    ))
    assert ti.get_vars() == dict()

    ti = TaskInclude.load(dict(
        action='include',
        args=dict(
            name='test_role',
        ),
    ))
    assert ti.get_vars() == dict()


# Generated at 2022-06-11 11:20:17.655089
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # TODO
    pass

# Generated at 2022-06-11 11:20:28.848904
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role.definition import TaskDefinition
    from ansible.utils.vars import combine_vars

    # Test with different actions

# Generated at 2022-06-11 11:20:36.728324
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    import ansible.utils.vars as ansible_vars

    # We make sure the module can be imported
    loader = 'ansible.parsing.dataloader.DataLoader'
    try:
        __import__(loader)
    except:
        print('ERROR: Unable to import ansible.parsing.dataloader.DataLoader. This test is skipped.')
        return

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # This is the list of all possible args for include,
    # with their default value