

# Generated at 2022-06-11 11:10:51.333796
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.verbosity = 3

    # TODO: Instead of creating a quick and dirty 'data' dict, we should use a
    # separate test JSON file to make it clear where the data comes from.

    # TaskInclude 'include'
    data = dict(args=dict(name='include'))
    task = TaskInclude()
    # Check if '_raw_params' is added to args when 'file' is missing
    task.check_options(task, data)
    assert task.args.get('_raw_params') is None

    # Check if '_raw_params' is added to args when 'file' is present
    data['args']['file'] = '/some/path'
    task.check_options(task, data)
    assert task.args.get('_raw_params') == '/some/path'

    #

# Generated at 2022-06-11 11:10:55.215003
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    f = FieldAttribute(TaskInclude())
    f.post_validate(ds={'action': 'include_role', 'foo': 'bar'}, var_manager=None, loader=None)
    assert f.action == 'include_role'
    assert f.foo == Sentinel



# Generated at 2022-06-11 11:11:07.021408
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # Arrange - create two data set dictionaries, one is missing file
    # key in the args, the other is missing action key. Also, we add
    # extra options. Finally, create a mock display object that will
    # be used to check if messages were displayed or not.

    data = dict(
        action='include',
        args=dict(
            file='/path/to/task',
            debug='True',
        ),
    )
    data_fail_no_file = dict(
        action='include',
        args=dict(
            debug='True',
        ),
    )
    data_fail_no_action = dict(
        args=dict(
            file='/path/to/task',
            debug='True',
        ),
    )

    # Mock Display

# Generated at 2022-06-11 11:11:15.380204
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task

    ti = TaskInclude()
    task_with_no_data = Task()
    task_with_raw_params = Task(args={'_raw_params': 'spam'})
    task_with_no_file = Task(args={'spam': 'eggs'})
    task_with_file = Task(args={'file': 'spam'})
    task_with_bad_args = Task(args={'spam': 'eggs', 'file': 'spam'})
    task_with_bad_args_2 = Task(args={'spam': 'eggs', 'bacon': 'spam'})
    task_with_bad_args_3 = Task(args={'file': 'spam', 'bacon': 'spam'})
    task_with

# Generated at 2022-06-11 11:11:25.832931
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Declare test data
    data = {
        "action": "include",
        "file": "file.yml",
        "apply": {
            "block": [],
            "rescue": [],
            "always": [],
            "ignore_errors": False
        }
    }

    # Create object loader and load object data
    loader = TestDataLoader()
    obj = TaskInclude.load(data=data, loader=loader)

    # Test build_parent_block
    p_block = obj.build_parent_block()
    assert p_block.block_type == "apply"
    assert p_block.parent == obj
    assert obj.args["apply"] == {}


# Generated at 2022-06-11 11:11:36.724277
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display = Display()
    import ansible.constants as C
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    block = Block(play=None, parent=None)
    role = None
    task_include = None

    ti = TaskInclude(block=block, role=role, task_include=task_include)

    # Tests with no include action
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    task = Task(block=ti, role=role, task_include=ti)
    task.action = 'another action'

# Generated at 2022-06-11 11:11:48.265974
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test invalid options
    task = TaskInclude.load({
        'action': 'include',
        'my_opt': 'my_value',
    })

    try:
        task.check_options(task, {
            'action': 'include',
            'my_opt': 'my_value',
        })
    except AnsibleParserError as e:
        assert e.message == "Invalid options for include: my_opt"
    else:
        raise AssertionError("AnsibleParserError not raised")

    # Test invalid options for static include
    task = TaskInclude.load({
        'include_tasks': 'my_task_file',
    })


# Generated at 2022-06-11 11:11:56.351505
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    my_task = {
        'action': 'include_role',
        'file': 'some/file',
        'apply': {'name': 'my_block'},
        'other_option': 'should be dropped'
    }
    # check that options are checked properly
    ti.check_options(my_task, my_task)  # should do nothing
    assert my_task.get('other_option') is None  # should be dropped
    assert my_task.get('apply') == {'name': 'my_block'}
    assert my_task.get('file', None) == 'some/file'
    assert my_task.get('_raw_params') == 'some/file'

    # check that an error is thrown with an invalid option

# Generated at 2022-06-11 11:12:06.613997
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # GIVEN
    # WHEN
    ti = TaskInclude()

    # THEN
    assert ti.preprocess_data({'action': 'include_role'}) == {'action': 'include_role'}
    assert ti.preprocess_data({'action': 'include_role', 'name': 'test', 'debugger': 'test'}) == {'action': 'include_role',
                                                                                                  'name': 'test'}
    assert ti.preprocess_data({'action': 'include_role', 'name': 'test', 'when': 'test', 'debugger': 'test'}) == {'action': 'include_role',
                                                                                                                 'name': 'test',
                                                                                                                 'when': 'test'}

# Generated at 2022-06-11 11:12:17.967198
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    obj = TaskInclude()
    assert obj.action == 'include'
    assert obj.args == {}
    assert obj.preprocess_data(dict(action='include', args=dict())) == dict(action='include', args=dict(), file=None, _raw_params=None)

    assert obj.preprocess_data(dict(action='include', args=dict(file='test1.yml'))) == dict(action='include', args=dict(), file='test1.yml', _raw_params='test1.yml')


# Generated at 2022-06-11 11:12:32.202666
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_vars = dict(foo="bar")
    def test_get_vars(action):
        # create a task with action and task_vars
        task = TaskInclude()
        task.action = action
        task.vars = task_vars

        # create a parent for the task and assign args and vars
        parent = Block()
        parent.args = dict(arg1="arg1value", arg2="arg2value")
        parent.vars = dict(parent_var1="pvar1")

        # assign the parent to the task and test get_vars
        task._parent = parent

        all_vars = task.get_vars()
        if action not in C._ACTION_INCLUDE:
            assert all_vars == dict(parent_var1="pvar1")

# Generated at 2022-06-11 11:12:40.594693
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    pb = TaskInclude()

    pb.args = {
        'apply': {
            'with_items': [1,2,3]
        }
    }
    pb._parent = Play()

    p_block = pb.build_parent_block()

    assert isinstance(p_block, Block)
    assert p_block.block is not None
    assert p_block.block == []

    assert pb.args == {}



# Generated at 2022-06-11 11:12:48.912646
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host = Host(name='localhost')
    variable_manager = VariableManager()
    variable_manager.set_inventory(host.get_inventory())
    p_block = Block()
    parent_block_vars = {'my_var': 'my_value'}
    p_block.vars = parent_block_vars
    task_include = TaskInclude(block=p_block)

    # get_vars of task_include should not include the parent block vars when action is not an include
    task_include.action = 'include_role'

# Generated at 2022-06-11 11:12:59.496421
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Ansible methods cannot import AnsibleIncludeResolver
    because it uses methods of AnsibleIncludeResolver too.
    So this method is created to test the get_vars method of TaskInclude
    '''

    # examples of vars from the playbook
    playbook_vars = dict()
    playbook_vars["db_backup_destination_dir"] = "backup_db"
    playbook_vars["db_backup_database_name"] = "dummy_db"

    # examples of vars from the static include
    static_vars = dict()
    static_vars["db_backup_include_dir"] = "db_backup_dir"

    # examples of vars from the dynamic include
    dynamic_vars = dict()
    dynamic_vars["a"] = "Hello"


# Generated at 2022-06-11 11:13:09.996002
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Test TaskInclude.load without role
    task = TaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-11 11:13:20.654800
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ti._task_name = 'include'

    # Note: the obj argument is used only to set the correct error message
    obj = {'key': 'value'}

    # throw error if a bad option is passed
    ds = {'action': 'include', 'file': 'test.yml', 'foobar': 'foobar'}
    try:
        ti.preprocess_data(ds)
        assert False, "'foobar' is not a valid option for include"
    except AnsibleError as e:
        pass

    # throw error if a bad option is passed
    ds = {'action': 'import_tasks', 'file': 'test.yml', 'foobar': 'foobar'}

# Generated at 2022-06-11 11:13:31.503890
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible import errors
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.parsing.convert_bool import boolean

    variable_manager = VariableManager()
    loader = None
    variable_manager.extra_vars = dict(a=1, b=2)
    variable_manager.vars_cache = dict(a=1, b=2, c=1)
    play_context = PlayContext()
    play_context.check_mode = False
    play_context.verbosity = 0

# Generated at 2022-06-11 11:13:34.325717
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    my_task_include = TaskInclude()
    p_block = my_task_include.build_parent_block()
    assert p_block == my_task_include
    
    # TODO: implement more test cases

# Generated at 2022-06-11 11:13:44.659472
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Importing AnsibleModule stuff
    from ansible.module_utils.basic import AnsibleModule

    # Create a sample AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            include = dict(required=True),
            action = dict(required=True, choices=C._ACTION_ALL_INCLUDE_ROLE_TASKS),
        )
    )

    # Creating a task with the AnsibleModule above
    my_task = TaskInclude(
        block=None,
        role=None,
        task_include=None,
    )

    # Create a data dict that is used by the task_include to generate a task
    # Note: since we are not going to include any file here, the
    # property 'statically_loaded' will be set to False

# Generated at 2022-06-11 11:13:55.342755
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Function to test the method check_options of class TaskInclude
    '''
    # Create a TaskInclude object
    ti = TaskInclude()

    # Create a task with valid options
    task_data = dict(action="include_tasks", file="file1.yml")
    task = Task()
    task.args = task_data

    res_task = ti.check_options(task, task_data)

    # Check the result
    assert res_task is not None
    assert res_task.args["_raw_params"] == "file1.yml"

    # Create a task with invalid options
    task_data = dict(action="import_tasks", file="file1.yml", invalid_opt = "my_invalid_opt")
    task = Task()
    task.args = task_

# Generated at 2022-06-11 11:14:13.770843
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # Simple sanity check
    assert task.check_options(task.load_data({'include': 'vars.yml'}), {})

    # Invalid options
    try:
        task.check_options(task.load_data({'include': 'vars.yml', 'invalid': 'options'}), {})
        assert False, 'This should not happen'
    except AnsibleParserError as err:
        assert 'Invalid options for include' in str(err)
        assert 'invalid' in str(err)

# Unit tests for class TaskInclude
# TODO: include tests for preprocess_data. Most of the changes from that method were
# moved to get_vars() so it's not easy to unit test them. We could add a bunch of
# use cases to the tests, but it

# Generated at 2022-06-11 11:14:23.478644
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext

    # Since PlayContext need loader, we need a loader. The task needs a variable manager.
    # The variable manager needs a loader. The loader needs a config.
    loader = DictDataLoader({'somefile.yaml': "{ foo: 'bar' }"})
    vm = VariableManager(loader=loader)
    play_context = PlayContext(variable_manager=vm)

    data = {
        'action': 'add_host',
        'apply': {
            'name': 'Add hosts to group',
            'hosts': '{{ groups.new_hosts }}'
        },
    }

    ti = TaskInclude.load(data)
    ti.action = 'add_host'

# Generated at 2022-06-11 11:14:27.938783
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    ti = TaskInclude()
    ti._role = None
    ti._variable_manager = VariableManager()
    ti._loader = None

    data = {'action': 'include', 'vars': {'var1': 'test_var_value'}, 'test_key': 'test_value'}
    task = ti.check_options(ti.load_data(data, variable_manager=ti._variable_manager, loader=ti._loader), data)

# Generated at 2022-06-11 11:14:37.278086
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class Abc(object):
        def __init__(self):
            self.name = 'Abc'
            self.parent_block = None
            self.ds = {'name': 'myplay', 'hosts': 'host1,host2'}

    from ansible.playbook.play import Play

    class MockClass(object):
        _variable_manager = None
        _loader = None
        _play = Play().load(dict(name='myplay', hosts='host1,host2'), variable_manager=None, loader=None)

    ti = TaskInclude(MockClass())
    ti.preprocess_data({'include': {'name': 'some_include', 'apply': {'foo': 'somevar'}}})



# Generated at 2022-06-11 11:14:40.727571
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = _test_task_attributes(ti, TaskInclude.load)
    task2 = ti.check_options(task, {})
    assert task2 is not None

# Generated at 2022-06-11 11:14:49.119914
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.vars
    import ansible.lookup.file
    import ansible.template
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleParserError

    display = Display()
    display.verbosity = 4

    # Create a host in the inventory
    loader = DataLoader()

# Generated at 2022-06-11 11:14:59.694689
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-11 11:15:09.911670
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class FakeTask(object):
        action = 'include'
        args = {}
    include_task = TaskInclude()
    task = FakeTask()
    # a '_raw_params' is required
    try:
        include_task.check_options(task, None)
        assert False
    except AnsibleParserError:
        assert True
    task.args = {'_raw_params':'test.yml'}
    # 'apply' is not allowed if action is not in C._ACTION_INCLUDE_TASKS
    task.action = 'import_role'
    task.args['apply'] = {}
    try:
        include_task.check_options(task, None)
        assert False
    except AnsibleParserError:
        assert True
    # 'apply' is allowed only if is a dict
    task

# Generated at 2022-06-11 11:15:18.319541
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(action='include_tasks', file='foo.yml', apply=dict())
    task = TaskInclude.check_options(TaskInclude(), Task(), data)
    assert task.args['file'] == 'foo.yml'
    assert isinstance(task.args['apply'], dict)

    data = dict(action='import_playbook', file='foo.yml', apply=dict())
    try:
        TaskInclude.check_options(TaskInclude(), Task(), data)
        assert False
    except AnsibleParserError as e:
        assert str(e) == 'Invalid options for import_playbook: apply'
    except:
        assert False



# Generated at 2022-06-11 11:15:28.513858
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-11 11:15:47.789283
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # Check options with invalid attribues, then check that the exception is raised
    data = {'action': 'include_role', 'args': {'vars': {'x': 1}, 'undefined_attribue': 'invalid value'}}
    task = {'block': None, 'action': 'include_role', 'args': {'vars': {'x': 1}}}
    ti.check_options(task, data)
    assert False

    # Check options with valid attribues, then check that no exception is raised
    data = {'action': 'include_role', 'args': {'vars': {'x': 1}, 'tags': ['invalid value']}}

# Generated at 2022-06-11 11:15:55.356061
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test 1: simple case
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict()
    task_include.args['apply'] = dict()
    task_include.args['apply']['block'] = []
    parent_block_1 = task_include.build_parent_block()
    assert(parent_block_1 is not None)
    assert(isinstance(parent_block_1, Block))

    # Test 2: no block is present
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict()
    parent_block_2 = task_include.build_parent_block()
    assert(parent_block_2 is not None)

# Generated at 2022-06-11 11:16:03.615713
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'test', 'utils'))
    from runtests import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    # Create a task and set its attributes
    task = TaskInclude()
    block_args = {'block': []}
    role = AnsibleExitJson()._ansible_get_changed_objects()[0].get_dep_attrs()
    task._parent = AnsibleExitJson()._ansible_get_changed_objects()[0]
    task._variable_manager = AnsibleExitJson()._ansible_get_changed_objects()[0]
    task._loader = AnsibleExitJson

# Generated at 2022-06-11 11:16:12.409294
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    myti = TaskInclude()

    # Cannot test without parent since it will return nothing
    # Test with parent
    myti2 = TaskInclude()
    myti2.vars = dict(my="my")
    myti2.args = dict(my="my", my1="my1")
    myti.vars = dict(my="my")
    myti.args = dict(my="my", my1="my1")
    myti.action = "include"
    myti._parent = myti2
    myti.statically_loaded = True
    assert myti.get_vars() == dict(my1="my1", my="my", my="my")

    # Test with parent and no sentinel
    myti = TaskInclude()
    myti.vars = dict(my="my")
    my

# Generated at 2022-06-11 11:16:13.281067
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TODO
    pass

# Generated at 2022-06-11 11:16:20.623540
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    display.visibility = 'none'

    ti = TaskInclude()
    ti._role = 'parent'
    ti._parent = 'test parent'

    p_block = ti.build_parent_block()
    assert p_block == ti

    # test with apply:
    attrs = {'block': 'test block'}
    ti = TaskInclude()
    ti._role = 'parent'
    ti._parent = 'test parent'
    ti.args['apply'] = attrs
    p_block = ti.build_parent_block()
    assert p_block.block == attrs['block']

# Generated at 2022-06-11 11:16:29.793924
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.verbosity = 3
    import ansible.playbook.task_include

    my_args = dict()
    my_data = dict()

    # Test 1: no args, include action
    my_data['action'] = 'include'
    ansible.playbook.task_include.TaskInclude.check_options(my_args, my_data)

    # Test 2: no args, import action
    my_data['action'] = 'import_tasks'
    ansible.playbook.task_include.TaskInclude.check_options(my_args, my_data)

    # Test 3: valid args, include action
    my_args = {'file': 'xyz.yml', 'tags': ['tag1', 'tag2'], 'apply': dict(import_playbook='abc.yml')}
    my

# Generated at 2022-06-11 11:16:39.089532
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import six

    loader = DataLoader()
    inventory = InventoryManager(
        loader=loader,
        sources=[
            "localhost ansible_connection=local ansible_python_interpreter='/usr/bin/env python'",
        ],
    )


# Generated at 2022-06-11 11:16:48.585237
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from .task import Task

    task_raw = {'tasks': [], 'name': 'included task', 'action': 'include', 'args': {'a': {'b': {'c': 1}}}}
    task_raw2 = {'tasks': [], 'name': 'included task', 'action': 'include_role', 'args': {'a': {'b': {'c': 1}}}}
    task_raw3 = {'tasks': [], 'name': 'included task', 'action': 'import_tasks', 'args': {'a': {'b': {'c': 1}}}}
    task_raw4 = {'tasks': [], 'name': 'included task', 'action': 'include_tasks', 'args': {'a': {'b': {'c': 1}}}}

   

# Generated at 2022-06-11 11:16:53.278672
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    t.action = 'include'
    t.args = {'a': 1, 'b': 2}
    t.vars = {'b': 3, 'c': 4}
    all_vars = t.get_vars()

    assert all_vars['a'] == 1
    assert all_vars['b'] == 3
    assert all_vars['c'] == 4

# Generated at 2022-06-11 11:17:03.477629
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = TaskInclude.load(dict(
        file='/dev/null',
        apply=dict(
            block=[]
        )
    ))

    assert isinstance(task, TaskInclude)
    assert len(task._parent.block) == 0
    assert len(task.block) == 0

# Generated at 2022-06-11 11:17:10.819830
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test cases for TaskInclude.check_options
    '''
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    def _rule_check(task, data, action=None, error=None, warn=None, add_apply=False, extra_fields=()):
        '''
        Helper to check TaskInclude.check_options and HandlerTaskInclude.check_options rules
        '''

        if action:
            task.args.update({'action': action})
        task_copy = task.copy()
        if add_apply:
            task.args['apply'] = {'block': [], 'ignore_errors': 'yes'}

        if error:
            with pytest.raises(error):
                task.check_options(task, data)

# Generated at 2022-06-11 11:17:23.204432
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Test args options validation
    display = Display()

    # 'args' is not a valid option
    test_data = {
        'action': 'include',
        'args': 'some_string'
    }

    ti = TaskInclude()
    task = Task()
    task.vars = {}
    task.action = 'include'
    task.args = test_data.get('args')

    try:
        ti.check_options(task, test_data)
    except AnsibleParserError as e:
        assert e.message == 'Invalid options for include: args'
        assert e.obj == test_data
    else:
        assert False

    # 'args' is a valid option for dynamic includes
    test_data = {
        'action': 'include',
        'args': {'x': 1}
    }

# Generated at 2022-06-11 11:17:32.535725
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class MockApplyTask(TaskInclude):
        '''
        This is a mock class of TaskInclude so that we don't have to load
        the actual class from the Ansible tree.
        '''
        def __init__(self, args):
            super(MockApplyTask, self).__init__()
            self.args = args


    class MockPlay(object):
        '''
        This is a mock class of Play so that we don't have to load
        the actual class from the Ansible tree to test the method.
        '''
        def __init__(self):
            pass

        def set_loader(self, loader):
            self._loader = loader


# Generated at 2022-06-11 11:17:42.730504
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    _test_play = {
        'name': 'name',
        'hosts': 'all',
        'gather_facts': 'yes',
        'vars': {},
        'roles': [],
        'tasks': [{
            'roles': [],
            'vars': {},
            'include': 'include_file',
            'apply': {'run_once': 'true'},
        }]
    }

    test_play = Play().load(_test_play, variable_manager=None, loader=None)

    test_include = TaskInclude(block=test_play, role=None, task_include=None)


# Generated at 2022-06-11 11:17:53.561169
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude.load({
        'action': 'include_tasks',
        'file': 'myfile',
        'no_log': True
    }, loader=None)
    assert task.args.get('_raw_params') == 'myfile'
    assert task.args.get('no_log') is True

    task = TaskInclude.load({
        'action': 'import_tasks',
        'file': 'myfile',
        'no_log': True
    }, loader=None)
    assert task.args.get('no_log') is True

    task = TaskInclude.load({
        'action': 'include_role',
        'name': 'myrole',
        'no_log': True
    }, loader=None)
    assert task.args.get('no_log') is True

   

# Generated at 2022-06-11 11:18:00.072317
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude instance
    task = TaskInclude(block=None, role=None, task_include=None)

    # Set a parent for the instance
    parent_task = Task()
    parent_task.vars = {'parent_variable': 'parent'}
    parent_block = Block()
    parent_block._parent = parent_task
    task._parent = parent_block

    # Set some variables
    task.vars = {'task_variable': 'task'}
    task.args = {'include_variable': 'include'}
    task.action = 'include'

    # Assert that the get_vars() method returns the expected dictionary

# Generated at 2022-06-11 11:18:10.451521
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # test load method
    task_args = {
        'action': 'include',
        'file': '/test/test.yml',
        'some_other_arg': 'some_other_value',
        'apply': {
            'when': 'aaa == bbb',
            'loop_control': {
                'loop_var': 'loop_var_value'
            }
        },
        'ignore_errors': True
    }
    display = Display()
    display.verbosity = 3

    task_include = TaskInclude()

    task = task_include.load(task_args)

    assert task.action == 'include'
    assert task.args.get('_raw_params') == '/test/test.yml'
    assert task.args.get('ignore_errors') == True
    assert task.args.get

# Generated at 2022-06-11 11:18:17.341717
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """This is a basic test for TaskInclude preprocessor"""
    ti = TaskInclude()
    # set up some values for the SENTINEL class
    Sentinel.__init__(Sentinel, "SENTINEL")
    task_data = {
        'action': "include",
        'module': "shell",
        'args': {'arg1': "value1"},
        'not_an_attribute': Sentinel
    }
    assert(isinstance(task_data, dict))
    # we expect no exceptions to be raised
    ti.preprocess_data(task_data)

# Generated at 2022-06-11 11:18:24.248302
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # init some data structures
    display = Display()
    display.verbosity = 3
    display.debug = True
    display.deprecate = True

    # init needed data for test
    data = {'name': 'include_role: name=apache', 'action': 'include_role'}
    args = {'name': 'apache', 'apply': {}, '_raw_params': 'name=apache'}
    apply_attrs = {'block': []}
    vars_ = {'foo': 'bar'}
    all_vars = {'foo': 'bar', 'name': 'apache', 'apply': {}}
    attrs = {'_variable_manager': None, '_parent': None, '_role': None, '_loader': None, '_play': None}
    attrs.update(vars_)

# Generated at 2022-06-11 11:19:06.039248
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task1 = Task()
    task1.block = [
        dict(action='include_tasks',
             file='foo.yml',
             ignore_errors=True),
        dict(action='include_tasks',
             file='bar.yml',
             apply=dict(block=[]))
    ]
    task2 = Task()
    task2.block = task1.block[0]
    task2.args = dict(
        file='foo.yml',
        ignore_errors=True
    )
    block3 = task1.block[1]
    block3.pop('block')
    task3 = Task()
    task3.block = block3
    task3.args = dict(
        file='bar.yml',
        apply=dict(block=[]),
        ignore_errors=True
    )

# Generated at 2022-06-11 11:19:15.077190
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    assert task_include.preprocess_data(
        {'action': 'include_tasks', 'args': {'free_form': 'bla'}}
    ) == {
        'action': 'include_tasks',
        'args': {'free_form': 'bla'},
    }

    assert task_include.preprocess_data(
        {'action': 'import_tasks', 'args': {'free_form': 'bla'}}
    ) == {
        'action': 'import_tasks',
        'args': {'free_form': 'bla'},
    }


# Generated at 2022-06-11 11:19:24.730279
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test for method build_parent_block of class TaskInclude
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a fake block and parent block

# Generated at 2022-06-11 11:19:33.532849
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.role.definition import RoleDefinition  # noqa
    from ansible.playbook.play_context import PlayContext  # noqa
    from ansible.playbook.play import Play  # noqa
    from ansible.vars.manager import VariableManager  # noqa
    from ansible.parsing.dataloader import DataLoader  # noqa

    data = {
        'apply': {},
        'include': 'foo.yml',
    }
    block = Block.load(
        data,
        PlayContext(),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        play=Play(),
    )

    parent_block = block.block[0].build_parent_block()
    assert isinstance(parent_block, Block)


# Generated at 2022-06-11 11:19:42.206895
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import plugin_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition


# Generated at 2022-06-11 11:19:51.301428
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-11 11:20:00.048451
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    import ansible.playbook.block as i_block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-11 11:20:08.777514
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.errors as errors
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    # Setup of TaskInclude
    display = Display()
    display.verbosity = 3
    display.deprecated_warnings = False

    task_include = TaskInclude(block=Block(), role=IncludedFile())
    task_include._role = RoleInclude()
    task_include.action = 'import_playbook'
    task_include.args = {'apply': {'block': []}}
    task_include._parent = Block()

    # Setup of Block
    block = Block()


# Generated at 2022-06-11 11:20:18.116279
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test method get_vars of class TaskInclude
    '''
    t1 = TaskInclude()
    t1.action = 'include'
    t1.vars.update({'var1':'value1','var2':'value2'})
    t1.args.update({'arg1':'v1','arg2':'v2'})
    t1.vars.update({'arg1':'vv1','arg2':''})  # test that vars will override args

    assert t1.get_vars() == {'var1':'value1','var2':'value2','arg1':'vv1','arg2':'v2'}

    t2 = TaskInclude()
    t2.action = 'import_playbook'

# Generated at 2022-06-11 11:20:29.210847
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole

    # Test for action: include
    ti_args={'_raw_params':'abc.yml', 'x':'11', 'y':'22', 'z':'33'}
    ti = TaskInclude(block=None, role=None, task_include=None, args=ti_args)
    all_vars=ti.get_vars()
    assert all_vars == {'x': '11', 'y': '22', 'z': '33'}

    # Test for action: include_role
    ir_args={'name': 'dummy_role', 'x':'11', 'y':'22', 'z':'33'}