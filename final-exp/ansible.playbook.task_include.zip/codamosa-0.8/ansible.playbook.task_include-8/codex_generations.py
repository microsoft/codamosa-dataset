

# Generated at 2022-06-11 11:10:44.013826
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    test_data = {'action': 'my_include', 'foo': 1, 'bar': 2}
    class DummyIncludeTask(TaskInclude):
        VALID_INCLUDE_KEYWORDS = frozenset(('action', 'foo', 'bar'))

    assert DummyIncludeTask.preprocess_data(test_data) == test_data



# Generated at 2022-06-11 11:10:50.718345
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.role.include
    import ansible.playbook.play.include

    task_include = TaskInclude()

    # Invalid options for TaskInclude
    with pytest.raises(AnsibleParserError):
        task_include.load({'include': 'bad.yaml'})
    with pytest.raises(AnsibleParserError):
        task_include.load({'include': 'role.yaml', 'not_valid': None})

    # Valid options for TaskInclude
    task = task_include.load({'include': 'role.yaml'})
    assert task.args['file'] == 'role.yaml'

    task = task_include.load({'include': 'play.yaml'})
    assert task.args['file'] == 'play.yaml'
    assert task

# Generated at 2022-06-11 11:11:01.442865
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # create play context
    mock_loader, inventory, variable_manager = MockLoader(), MockInventory(), VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context._vars_per_host = {}

    # create block
    task_ds = dict(
        action='raw',
        _raw_params='Hello from Include task',
        no_log=True,
        connection='network_cli',
        tags=['include_tag'],
        when=dict(platform='junos'),
        debugger='junos'
    )


# Generated at 2022-06-11 11:11:12.407484
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 11:11:18.594280
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class MockPlay(object):
        pass

    class MockInclude(TaskInclude):
        _parent = None
        args = {'tasks' : 'httpd', 'other_args' : 'value'}
        vars = dict()
        action = 'include'
    t = MockInclude()

    vars = t.get_vars()
    assert vars.get('tasks') == 'httpd'
    assert vars.get('other_args') == 'value'

# Generated at 2022-06-11 11:11:21.487471
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    block.vars = {'ansible_connection': 'local'}
    task = TaskInclude(block=block, task_include=None)
    assert task.get_vars() == {}

# Generated at 2022-06-11 11:11:33.366911
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Test valid data for C._ACTION_INCLUDE_TASKS
    for action in C._ACTION_INCLUDE_TASKS:
        task = TaskInclude(block=None, task_include=None)
        data = {'action': action, '_raw_params': 'foo'}
        task.check_options(task, data)
        assert data['_raw_params'] == 'foo'

    # Test valid data for C._ACTION_IMPORT_TASKS
    for action in C._ACTION_IMPORT_TASKS:
        task = TaskInclude(block=None, task_include=None)
        data = {'action': action, '_raw_params': 'foo'}
        task.check_options(task, data)
        assert data['_raw_params'] == 'foo'

   

# Generated at 2022-06-11 11:11:42.439112
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    my_arg_names = 'file apply tags when'.split()
    task_data = dict(
        file='some_file',
        apply=dict(
            add_host=dict(
                groups=dict(
                    skcp=dict(hosts='1.2.3.4')
                )
            )
        )
    )
    task_data.update([(k, obj) for k, obj in task_data.items()])

    ti = TaskInclude()
    ti.check_options(task_data, task_data)
    assert '_raw_params' in task_data
    assert task_data['_raw_params'] == task_data['file']

# Generated at 2022-06-11 11:11:53.148724
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-11 11:12:03.573503
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block as block
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    with pytest.raises(AnsibleParserError) as err:
        TaskInclude.check_options(Task(), {})
    assert "No file specified for include" in str(err.value)

    with pytest.raises(AnsibleParserError) as err:
        TaskInclude.check_options(Task(), {'file': 'some_file.yml'})
    assert "Invalid options for include: " in str(err.value)

    task = Task()
    task.action = 'import_playbook'
    with pytest.raises(AnsibleParserError) as err:
        Task

# Generated at 2022-06-11 11:12:19.012035
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()

    task_include.vars = {'x': '1', 'y': '2'}
    task_include.args = {'a': '3', 'b': '4'}
    task_include.action = 'include'
    assert task_include.get_vars() == {'x': '1', 'y': '2', 'a': '3', 'b': '4'}, 'task_include get_vars when include'

    task_include.action = 'import_role'
    assert task_include.get_vars() == {'x': '1', 'y': '2', 'a': '3', 'b': '4'}, 'task_include get_vars when import_role'

    task_include.action = 'include_role'
    assert task_include

# Generated at 2022-06-11 11:12:23.846241
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test when 'apply' is specified
    task = TaskInclude()
    task.args = {'apply': {'block': []}}
    task._parent = 'test_parent'
    task._variable_manager = 'test_variable_manager'
    task._loader = 'test_loader'
    task._play = 'test_play'
    task._role = 'test_role'
    p_block = task.build_parent_block()
    assert p_block._parent == task._parent, 'Parent of block is not correct'
    assert p_block._variable_manager == task._variable_manager, 'Variable manager of block is not correct'
    assert p_block._loader == task._loader, 'Loader of block is not correct'
    assert p_block._play == task._play, 'Play of block is not correct'
    assert p

# Generated at 2022-06-11 11:12:33.871067
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import unittest
    import ansible.playbook.play
    import ansible.playbook.playbook
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.playbook.role
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    import ansible.vars.manager
    import ansible.vars.hostvars

    class TaskIncludeTest(unittest.TestCase):
        def test_build_parent_block(self):
            #create a dummy role for testing
            role = ansible.playbook.role.Role()
            role._role_name = 'geerlingguy.java'

# Generated at 2022-06-11 11:12:44.818464
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = dict(
        action='include',
        file='some_file.yml',
        vars=dict(
            first='John',
            last='Doe',
        ),
        with_dict=dict(
            host1='192.168.1.1',
            host2='192.168.1.2',
        ),
        with_list=[
            'host3',
            'host4',
        ],
        _hosts='host1:192.168.1.1,host2:192.168.1.2'
    )
    ti = TaskInclude()
    preprocessed_data = ti.preprocess_data(data)
    assert preprocessed_data == data


# Generated at 2022-06-11 11:12:53.880014
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This test verifies that method TaskInclude.get_vars() handles the action
    attribute correctly: if action is 'include' the args are include in the
    returned variables if the action is not 'include' the args are not
    included.
    '''
    import ansible.parsing.yaml.objects
    class MockVariableManager(object):
        def get_vars(self, loader, play=None, task=None, host=None, all_vars=None):
            pass

    class MockBlock(object):
        class _play(object):
            pass
        def __init__(self, *args, **kwargs):
            self.args = kwargs
            self.vars = {'test': 'success'}
            self._parent = None
            self._play = MockBlock._play()


# Generated at 2022-06-11 11:13:04.918563
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Success cases
    # WARNING: we cannot use the usual mocker/unittest.mock's patch here because
    # the TaskInclude class has to be loaded before the patching can be applied.
    # This is because of how python works.
    # See unittest.mock.patch documentation for further information.
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        for arg in TaskInclude.VALID_ARGS:
            if action not in C._ACTION_INCLUDE_TASKS and arg == 'apply':
                continue
            task = TaskInclude()
            data = {'action': action, arg: 'foo'}
            transformed_task = task.check_options(task.load_data(data), data)
            assert transformed_task.args.get(arg)

# Generated at 2022-06-11 11:13:13.383932
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Provide test data and expected output for method get_vars of class TaskInclude
    '''
    # Test data
    test_block = Block()
    test_block.vars = { 'var1': 'value1' }
    test_block.post_validate()

    test_task_include = TaskInclude()
    test_task_include._parent = test_block
    test_task_include.action = 'include'
    test_task_include.args = { 'some': 'value' }
    test_task_include.post_validate()

    # Expected output
    expected = { 'some': 'value', 'var1': 'value1' }
    # Execute method to be tested
    actual = test_task_include.get_vars()
    # Compare actual versus expected output

# Generated at 2022-06-11 11:13:25.011238
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ad = {}
    task = TaskInclude()

    assert task.check_options(task, ad) == task

    ad = {'file': '', '_raw_params': '', 'action': 'include', 'when': 'a'}
    ti = TaskInclude()
    ti = ti.check_options(ti, ad)

    # The method is expected to return a modified task
    assert ad != ti.args == {'_raw_params': '', 'when': 'a'}

    # Invalid actions
    for action in ('import_tasks', 'include_role', 'include_tasks'):
        ad = {'file': '', '_raw_params': '', 'action': action, 'apply': {}}
        ti = TaskInclude()
        with pytest.raises(AnsibleParserError):
            ti

# Generated at 2022-06-11 11:13:35.139706
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    # Create play
    play_ds = dict(name="test_play", hosts=["host1"])
    play = Play.load(play_ds, variable_manager=VariableManager(), loader=None)

    # Create role
    role_ds = dict(name="test_role")
    role_def = RoleDefinition.load(role_ds, play=play, variable_manager=play.get_variable_manager(), loader=play._loader)
    templar = Templar(loader=play._loader, variables=play.get_variable_manager())
    role = role

# Generated at 2022-06-11 11:13:46.416052
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Unit test to check if the method get_vars of class TaskInclude
    returns the expected result
    '''

    class FakeTask1(Task):
        '''
        Class FakeTask1 used in the unit test that mimics a Task class sibling of a TaskInclude
        '''

        def get_vars(self):
            res = {"a": 1, "b": 2}
            return res

    class FakeRole(Role):

        def get_role_params(self):
            res = dict(
                param1="value1",
                param2="value2",
                param3="value3",
            )
            return res

    # test:
    # - no apply, no include
    # - no apply, include
    # - apply, no include
    # - apply, include

    # test: no apply

# Generated at 2022-06-11 11:13:57.725000
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play = Play().load({'name': 'TEST PLAY'}, variable_manager={}, loader=None)
    block = Block().load(
        {'name': 'TEST BLOCK', 'block': [
            {'name': 'TEST TASK INCLUDE', 'action': 'include', 'apply': {'block': [], 'name': 'TEST APPLY BLOCK'}}
        ]},
        play=play,
        task_include=None,
        role=None,
        variable_manager={},
        loader=None,
    )

    # Getting the parent block of the task include
    p_block = block.block[0].build_parent_block()

# Generated at 2022-06-11 11:14:07.696178
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude

    # Include task with a base task
    play_data = dict(
        name="Test play",
        hosts="myhosts",
        roles=[{
            'name': 'Base role',
            'tasks': [
                {'include': 'myinclude.yml', 'action': 'include', 'args': {'name': 'no', 'debug': 'yes'}}
            ]
        }],
    )
    play = Play.load(play_data, variable_manager=None, loader=None)
    role = RoleInclude.load(play._entries[0], play=play)

# Generated at 2022-06-11 11:14:17.410174
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.load_data(dict(args=dict(a=1, b=2, c=3)))
    variables = ti.get_vars()
    assert set(variables.keys()) == set(['a', 'b', 'c'])

    ti.args['tags'] = 'x'
    ti.args['when'] = True
    ti.action = 'include_role'
    variables = ti.get_vars()
    assert set(variables.keys()) == set(['a', 'b', 'c', 'tags', 'when'])

    ti.action = 'include'
    variables = ti.get_vars()
    assert set(variables.keys()) == set(['a', 'b', 'c', 'tags', 'when'])

# Generated at 2022-06-11 11:14:26.364907
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar

    # A PlayContext not None is required by the __init__ method of the Play class
    pc = PlayContext()

    # A Play is required to create a Block(see the let self._play = play in the Block's __init__ method)
    play = Play().load({}, variable_manager=None, loader=None)

    # The 'include' task

# Generated at 2022-06-11 11:14:36.352940
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude(block=None, role=None, task_include=None)
    task_include._parent = Task()
    parent_vars = {'a': 1, 'b': 2}
    task_include._parent.vars = dict(a=0, b=0)
    task_include.vars = dict(a=1, b=1)
    task_include.args = dict(a=2, b=2)
    assert task_include.get_vars() == dict(a=2, b=2)

    task_include.action = 'import_role'
    assert task_include.get_vars() == dict(a=2, b=2)

    task_include.action = 'include'

# Generated at 2022-06-11 11:14:46.576108
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    host_vars = {'hostvars': 'True'}
    play_vars = {'playvars': 'True'}
    task_vars = {'taskvars': 'True'}
    include_vars = {'includevars': 'True', 'loop': 'hostvars'}
    include_args = {'file': './include.yml'}

    loader = DictDataLoader({'include.yml': """
---
- name: include test
  debug: var=includevars
"""})

    class TestBlock():
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self): return self.vars

    class TestParentBlock(Block):
        def __init__(self, block):
            self._parent

# Generated at 2022-06-11 11:14:56.931015
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # When 'action' is not in C._ACTION_INCLUDE
    action = "include_tasks"
    block = Block(task_include=TaskInclude())
    # Construct a TaskInclude object with 'action'
    obj = TaskInclude(block=block, args=dict(action=action))
    # Assert it is an instance of TaskInclude
    assert isinstance(obj, TaskInclude)
    # Assert method get_vars of obj is the same as of the super class Task
    assert obj.get_vars() == Task.get_vars(obj)
    # If 'action' is in C._ACTION_INCLUDE
    action = "include"
    # Construct a TaskInclude object with 'action'
    obj = TaskInclude(block=block, args=dict(action=action))
   

# Generated at 2022-06-11 11:15:07.027361
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.play
    import ansible.playbook.task

    # No args
    data = {'action': 'include'}
    task = TaskInclude.load(data)
    assert task.args['file'] == None

    # Bad args
    data = {'action': 'include', 'name': 'Hello'}
    task = TaskInclude.load(data)
    assert task.args['name'] == None

    # Valid args
    data = {'action': 'include', 'tags': 'Hello'}
    task = TaskInclude.load(data)
    assert task.args['tags'] == 'Hello'

    # Valid args with whitelisting
    data = {'action': 'include', 'no_log': True}
    task = TaskInclude.load(data)
    assert task.no_

# Generated at 2022-06-11 11:15:17.097509
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import json
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    tasks = json.load(open("test/unit/test_task_include.json", "r"))
    task = tasks[0]

    apply_attrs = task["apply"]
    block = Block.load(apply_attrs, play=Play.load(dict()), task_include=TaskInclude(dict()), role=None, variable_manager=None, loader=None)
    parent_block = task["parent_block"]

    assert block.block is None
    assert block.rescue is None
    assert block.always is None

# Generated at 2022-06-11 11:15:25.620347
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    t = TaskInclude()
    t.args = dict()
    assert t.build_parent_block() == t

    t.args = dict(apply=dict())
    assert len(t.build_parent_block().block) == 0

    t.args = dict(apply=dict(block=[dict(task=dict(action=dict(module='debug', args=dict(msg='a block'))))]))
    assert t.build_parent_block().block[0]['task']['action']['module'] == 'debug'
    assert t.build_parent_block().block[0]['task']['action']['args']['msg'] == 'a block'

# Generated at 2022-06-11 11:15:40.530976
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude.load(dict(action = 'include', args = dict(x = 'a', b = 'c', tags = 'a', when = 'a')))
    assert task.get_vars() == {'x':'a', 'b':'c'}

    task = TaskInclude.load(dict(action = 'include_role', args = dict(x = 'a', b = 'c', tags = 'a', when = 'a')))
    assert task.get_vars() == {'x':'a', 'b':'c'}

    task = TaskInclude.load(dict(action = 'import_tasks', args = dict(x = 'a', b = 'c', tags = 'a', when = 'a')))

# Generated at 2022-06-11 11:15:48.988323
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Unit test for TaskInclude.build_parent_block()
    """
    print("Starting Unit Test for TaskInclude.build_parent_block()")
    ti = TaskInclude()
    ti.args = {'apply': {
                'block': [],
                'when': '',
                'name': ''}}
    ti._parent = {'_play': {
                        '_variable_manager': '',
                        '_loader': ''}}

    p_block = ti.build_parent_block()

    # Changing to use assertIsNotNone as assertNotEqual does not seem to be working
    # assertNotEqual(ti._parent._play._variable_manager, '', "Unit Test Failed: TaskInclude.build_parent_block(), p_block._parent._play._variable_manager did not match")
    # assertNot

# Generated at 2022-06-11 11:15:56.558755
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ti_dict = {
        'block': [
            {'name': 'include task'},
            {'name': 'not included'}
            ],
        'when': 'some condition'
    }

    p_play = Play().load({
        'name': 'include',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            ti_dict
            ]
    })

    # Loading the play automatically sets the _parent field

# Generated at 2022-06-11 11:16:02.164065
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''Unit test for method build_parent_block of class TaskInclude'''
    task = TaskInclude()
    mock_play = 'something'

    # Case 1: apply not specified
    task._parent = mock_play
    assert task is task.build_parent_block()

    # Case 2: apply specified
    mock_block = 'something else'
    task._parent = mock_play
    task.args = {'apply': {'block': mock_block}}
    assert mock_block is task.build_parent_block().block

# Generated at 2022-06-11 11:16:11.096241
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.vars.manager import VariableManager

    class DummyLoader:
        pass

    class DummyVariableManager:
        pass

    class DummyBlock:
        pass

    loader = DummyLoader()
    variable_manager = DummyVariableManager()
    block = DummyBlock()
    block.vars = {}

    assert TaskInclude.load(
        {'action': 'include', 'foo': 'bar'}, block=block, variable_manager=variable_manager, loader=loader
    ).args == {'_raw_params': 'bar'}


# Generated at 2022-06-11 11:16:20.405107
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    data = AnsibleBaseYAMLObject()
    data.value = AnsibleUnsafeText('include')
    data.args = dict()
    data.args['file'] = AnsibleUnsafeText('abc')
    data.tags = AnsibleSequence([AnsibleUnsafeText('foo_tag')])

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.extra_vars['hostvars'] = dict()


# Generated at 2022-06-11 11:16:29.589374
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # create fake apply options
    apply_attrs = {'debugger': [], 'name': 'sample include',
        'block': [{'action': 'include', 'args': {'file': 'sample.yml'}}],
        'force_handlers': False}

    # create fake parent block
    p_block = {'play': {'hosts': 'all', 'name': 'fake_play'}}

    # create fake task include
    task_include = {'_attributes': {'apply': apply_attrs, 'file': 'sample.yml',
                    'block': 'PseudoBlock'}, '_role': None,
                    '_parent': p_block, 'action': 'include'}

    # create TaskInclude object
    ti = TaskInclude()

    # call method to test
    new_parent

# Generated at 2022-06-11 11:16:38.867432
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    obj = TaskInclude()

    action = 'include_role'
    args = {'name': 'role', 'tasks_from': 'example'}
    task = Task()
    task.action = action
    task.args = args

    # Load 'args' and check if they are loaded correctly
    obj.check_options(task, {'action': action, 'args': args})
    assert isinstance(task.args['_raw_params'] , FieldAttribute)
    assert task.args['_raw_params'] == 'role'

    # Check if a dict is provided for apply
    args = {'apply': 'something'}
    task = Task()
   

# Generated at 2022-06-11 11:16:48.378932
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from copy import copy
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    play = Play.load(dict(name='Test Play', hosts=['127.0.0.1'], gather_facts='no'), ansible_vars={})
    play.load()

    # No apply, return self
    task = TaskInclude.load(dict(include='/path/to/include'))
    assert task.build_parent_block() is task

    # With apply, create a new parent block
    task = TaskInclude.load(dict(include='/path/to/include', apply=dict(become=True)))
    parent_block = task.build_parent_block()

# Generated at 2022-06-11 11:16:52.755710
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    
    # Test for an "include"
    #
    # include: test.yml v5=55 v6=66
    #
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = dict()
    task_include.args['v5'] = '55'
    task_include.args['v6'] = '66'
    all_vars = task_include.get_vars()
    assert len(all_vars) == 2
    assert all_vars['v5'] == '55'
    assert all_vars['v6'] == '66'
    
    # Test for an "include_role"
    #
    # include_role: name=test-role
    #
    task_include = TaskInclude()

# Generated at 2022-06-11 11:17:10.962705
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    from ansible.utils.sentinel import Sentinel
    from ansible.template import Templar
    from ansible import context

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)

    # set up context
    play_

# Generated at 2022-06-11 11:17:23.350348
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    t._variable_manager = MagicMock()
    t._parent = MagicMock()
    t.vars = dict(
        foo='foo',
        bar='bar',
    )

    # no action case
    assert t.get_vars() == {'foo': 'foo', 'bar': 'bar'}

    # no apply, no parent
    t.action = 'include'
    t._parent = None
    assert t.get_vars() == {'foo': 'foo', 'bar': 'bar', 'ignore_errors': False, '_raw_params': None, 'tags': [], 'when': None}

    # with apply and with parent
    t.action = 'include_role'

# Generated at 2022-06-11 11:17:28.017744
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    my_data = {
        "include": "some_file.yml",
        "name": "Some task that includes another one",
    }
    task = TaskInclude(block=None, role=None, task_include=None)
    task.check_options(task.load_data(my_data), my_data)

# Generated at 2022-06-11 11:17:35.226086
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = {'include': 'foo', 'tags': None, 'do_not_exist': None, 'ignore_errors': False, 'register': 'result'}
    new_ds = ti.preprocess_data(ds)
    assert ds != new_ds
    assert 'include' not in new_ds
    assert 'tags' not in new_ds
    assert new_ds['do_not_exist'] is Sentinel
    assert new_ds['ignore_errors'] is False
    assert new_ds['register'] == 'result'
    assert 'include' in ds
    assert 'tags' in ds

    ds = {'include_role': 'foo', 'tags': None, 'do_not_exist': None, 'ignore_errors': False, 'register': 'result'}
    new_ds

# Generated at 2022-06-11 11:17:45.797238
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.args = {
        'a': 1,
        'tags': ['tag1', 'tag2'],
        'when': 'always',
        'b': 2,
        'other': 'should be ignored'
    }
    task.vars = {'c': 3}
    p = Block()
    p.vars = {'c': 3, 'd': 4}
    task._parent = p
    task.action = 'include'
    result = task.get_vars()
    assert result == {'a': 1, 'c': 3, 'd': 4, 'b': 2}

    task.action = 'include_role'
    result = task.get_vars()

# Generated at 2022-06-11 11:17:55.954589
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.display(u'TEST: TaskInclude - method check_options')
    for task_action in C._ACTION_ALL_INCLUDE_IMPORT_TASKS:
        task_args = dict(
            file='test0',
            name='test1',
            register='test2',
            loop='test3',
            ignore_errors='test4',
            timeout='test5',
            with_dict='test6',
            with_list='test7',
            with_items='test8',
            with_together='test9',
            loop_control='test10',
            when='test11',
            tags='test12',
            args='test13',
            vars='test14',
            debugger='test15',
        )
        task_args.pop('name')

# Generated at 2022-06-11 11:18:01.225509
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    class FakeTask(Task):
        pass

    task_include = TaskInclude()
    task_include_parent = TaskInclude()
    task_include.vars = {'a': 'b'}
    task_include.args = {'c': 'd'}
    task_include._parent = task_include_parent
    task_include_parent.vars = {'e': 'f'}

    assert task_include.get_vars() == {'a': 'b', 'c': 'd'}

    task = FakeTask()
    task_include = TaskInclude()
    task_include.vars = {'a': 'b'}
    task_include.args = {'c': 'd'}
    task_include.action = 'include_role'
    task_include._parent = task


# Generated at 2022-06-11 11:18:10.040890
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_attrs = {'block': [], 'always': [], 'rescue': [], 'any_errors_fatal': False}
    p_block = TaskInclude.build_parent_block(apply_attrs)
    assert p_block.tags == ['tag1', 'tag2']  # tags set in the apply attributes
    assert p_block.block == []              # block set in the apply attributes
    assert p_block.always == []             # always set in the apply attributes
    assert p_block.rescue == []             # rescue set in the apply attributes
    assert p_block.any_errors_fatal == False # any_errors_fatal set in the apply attributes

# Generated at 2022-06-11 11:18:17.341393
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing import DataLoader

    loader = DataLoader()
    task_include = TaskInclude(loader=loader)
    task_include.action = 'include'
    task_include.args = {'apply': {'block': 'x', 'name': 'y'}, 'debug': 'msg=hello'}
    p_block = task_include.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.args == {'name': 'y', 'block': []}
    assert task_include.args == {'debug': 'msg=hello'}



# Generated at 2022-06-11 11:18:21.759412
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Set up environment
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils.parsing.convert_bool import boolean

    class Options(object):
        def __init__(self):
            self.pprint = False
            self.syntax = False
            self.inventory = './test/unit/utils/test.ini'
            self.extra_vars = []

# Generated at 2022-06-11 11:19:01.211975
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # We first create a dummy task, which inherits from TaskInclude.
    # Many methods are not implemented in this dummy task, but this is
    # sufficient for our tests.
    class dummy_task(TaskInclude):
        def load_data(self, ds):
            return ds
        def validate_data(self):
            pass

    # This is the data structure that we want to pre-process.
    original = {
        'when': True,
        'include': 'static_include.yml',
    }

    # We create an instance of the dummy task and we pre-process the data.
    ti = dummy_task()
    ti._block = ti
    ti._loader = 'dummy loader'
    result = ti.preprocess_data(original)

    # The result should be a clone of the original data, but the

# Generated at 2022-06-11 11:19:05.330665
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude.load({'apply': 'debugger'},
                          block=None,
                          role=None,
                          task_include=None)
    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)
    assert isinstance(p_block, Task)
    assert isinstance(p_block, TaskInclude)
    assert not p_block.statically_loaded
    assert not p_block.action
    assert not p_block.any_errors_fatal
    assert not p_block.always_run

    assert p_block.block is None
    assert not p_block.loop
    assert not p_block.loop_args
    assert not p_block.loop_with
    assert not p_block.loop_control
    assert not p_block.block

# Generated at 2022-06-11 11:19:14.339760
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mock_block = Block()
    mock_role = Role()
    mock_vars_manager = VariableManager()
    mock_loader = DataLoader()

    # test case 1: no 'file' specified and valid action - expect AnsibleParserError
    data1 = {}
    action1 = 'include'
    task1 = TaskInclude(block=mock_block, role=mock_role)

# Generated at 2022-06-11 11:19:23.964322
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class TaskInclude
    '''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block


# Generated at 2022-06-11 11:19:32.702823
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    my_play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {
                'include': 'playbook-1.1',
                'apply': {
                    'tags': ['config'],
                    'task_tries': 2,
                    'task_start_retries': 2,
                    'task_retry_delay': 2,
                    'block': [
                        {
                            'include': 'playbook-2.1',
                            'apply': {
                                'ignore_errors': True,
                            },
                        },
                    ],
                },
            },
        ],
    })

# Generated at 2022-06-11 11:19:41.447783
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Create parent block with vars
    parent_data = {
        'block': [],
        'vars': {
            'var1': 1,
            'var2': 2
        },
        'name': 'Test'
    }
    parent_block = Block.load(
        parent_data,
        play=None,
        task_include=None,
        role=None,
        variable_manager=None,
        loader=None,
    )

    # Create a task include with args
    data = {
        'file': 'include.yml'
    }
    include_action = 'include'

# Generated at 2022-06-11 11:19:50.499709
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # A new TaskInclude object for testing
    ti = TaskInclude()

    # The task loaded with the options and the data
    task = {}
    data = {}

    # There are no options specified
    assert ti.check_options(task, data) == task

    # Options with no value
    task = {'_raw_params': None, 'debugger': None}
    data = task.copy()
    try:
        assert ti.check_options(task, data) == task, "File must be specified"
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('Accepted invalid data with no file given')

    # Valid options for include
    task = {'_raw_params': 'test.yml'}
    data = task.copy()
    task['action'] = 'include'


# Generated at 2022-06-11 11:19:59.522643
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import Play
    from ansible.plugins.loader import action_loader

    play = Play().load({
        'name': 'test',
        'hosts': 'localhost',
        'gather_facts': False,
        'tasks': [
            {'action': 'include', 'file': 'include_me.yml'},
            {'include_tasks': 'include_me.yml'},
            {'include_role': 'my_role'},
        ]
    }, variable_manager=None, loader=None)

    block = play.get_block_list()[0]
    task = block.block[0]
    task._role = None
    task.action = 'include'
    task.args = {'file': 'include_me.yml'}
    task.check_

# Generated at 2022-06-11 11:20:08.090475
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj


    data = dict(
        name="test",
        action="include_role",
        apply=dict(
            serial=1,
            ignore_errors=False,
        )
    )
    loader, inventory, variable_manager = Mock(), Mock(), Mock()

    # Test include_role with apply
    role = Mock()
    role.name = "my_role"
    role.get_vars.return_value.copy.return_value = dict(vars=dict())
    role.get_tasks.return_value = dict(
        tasks=[
            dict(
                name="task1",
                action="debug",
                args=dict(msg="hello"),
            )
        ]
    )
    role.get

# Generated at 2022-06-11 11:20:17.359224
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    # Test TaskInclude, include_role
    data = {
        'include_role': {
            'name': 'test',
        },
    }
    ansible_action, task = Task._load_action_plugin(data)
    ti = TaskInclude(task_include=task)
    task = ti.check_options(task, data)

    assert not task.args.get('apply')
    assert task.args.get('_raw_params') == 'test'
    assert task.action == 'include_role'

    # Test HandlerTaskInclude, include_