

# Generated at 2022-06-11 11:10:49.598694
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    data = dict(file='foo.yml')
    task = Task.load({'include': data})
    assert task.action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    # no static action
    task = ti.check_options(task, data)
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == 'foo.yml'
    assert 'file' not in task.args
    # with static action
    data['static'] = True
    task = Task.load({'include': data})
    assert task.action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    task = ti.check_options(task, data)
    assert 'static' in task

# Generated at 2022-06-11 11:10:55.853165
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    t = TaskInclude()
    assert t.build_parent_block() == t, 'build_parent_block returned the wrong result'
    t.args['apply'] = {'name': 'parent block'}
    p_block = t.build_parent_block()
    assert isinstance(p_block, Block), 'build_parent_block should return a block'
    assert p_block.name == 'parent block', 'build_parent_block should return the requested block'


# Generated at 2022-06-11 11:11:03.412912
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti_obj = TaskInclude()
    ti_obj.action = 'include'
    play_obj = TaskInclude()
    play_obj.action = 'include'
    play_obj._role = "role_name"
    p_block = ti_obj.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.action == 'include'
    assert p_block._parent == play_obj
    assert p_block._role == "role_name"



# Generated at 2022-06-11 11:11:13.635547
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from . import fixtures

    assert Task.check_options(Task(task_include=TaskInclude()), {}) is None

    with fixtures.fixture() as data:
        data['action'] = 'include'
        data['apply']  = 'something'

        with fixtures.assertRaises(AnsibleParserError, "Invalid options for include: apply"):
            TaskInclude.check_options(
                TaskInclude.load_data(data, variable_manager=fixtures.VariableManager(), loader=fixtures.DictDataLoader()),
                data
            )

        data['apply']  = { 'something': 'something' }

# Generated at 2022-06-11 11:11:24.994855
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Test the method get_vars for the case where the action is not include or import_role or include_role
    t = Task()
    t.action = 'shell'
    t.args = {'x':1, 'y':2}
    assert(t.get_vars() == {'x':1, 'y':2})

    # Test the method get_vars for the case where the action is import_role or include_role
    t = Task()
    t.action = 'import_role'
    t.args = {'x':1, 'y':2}
    assert(t.get_vars() == {'x':1, 'y':2})

    # Test the method get_vars for the case where the action is include and there is no parent
    t = Task()

# Generated at 2022-06-11 11:11:36.144057
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    task = TaskInclude()
    # 1) action is not in the list of proper include tasks
    data = dict(action='become', args=dict(file='become_test.yml'))
    x = task.preprocess_data(data)

    # 2) action is in the list of proper include tasks
    play_context = PlayContext()
    data = dict(action='include', args=dict(file='include_test.yml', debug=True, tags='include'))
    x = task.preprocess_data(data)

    # 3) action is in the list of proper import tasks
    play_context = PlayContext()

# Generated at 2022-06-11 11:11:47.598632
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    orig_get_vars = Task.get_vars

# Generated at 2022-06-11 11:11:55.966723
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play_context as pc
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=VariableManager(),
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    play_context = pc.PlayContext()

    # Test with no apply specified
    static_task = TaskInclude.load({
        'action': 'include_role',
        'name': 'test',
    })
    static_task._play = Sentinel
    static_task._role = Sentinel
    static_task._variable_manager = VariableManager()
    static_task._loader = Sentinel

# Generated at 2022-06-11 11:12:06.195978
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = dict({ 'action': 'include', 'args': dict({'file': 'file.yml', '_raw_params': 'file.yml'})})
    # Asserts the args (file, _raw_params) which are used internally are considered valid
    task_include.check_options(task, dict({ 'action': 'include', 'args': dict({'file': 'file.yml', '_raw_params': 'file.yml'})}))
    task_include.check_options(task, dict({ 'action': 'include_role', 'args': dict({'file': 'file.yml', '_raw_params': 'file.yml'})}))
    # Asserts a valid option for action 'import_playbook' is considered valid
    task_apply = dict

# Generated at 2022-06-11 11:12:17.559494
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    def _create_include(action, **kwargs):
        data = dict(action=action, **kwargs)
        return TaskInclude.load(data, variable_manager=None, loader=None)
    # get_vars should be unified with the one of class Task() when action != 'include'
    include = _create_include('include', file='foo.yaml', include_role=dict(name='foo'))
    import ansible.playbook
    assert include.get_vars() == ansible.playbook.Task().get_vars()
    # get_vars return vars from parent block and params for apply when action == 'include'
    include = _create_include('include', file='foo.yaml', apply=dict(foo=1), bar=2)

# Generated at 2022-06-11 11:12:36.671294
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    loader = DataLoader()

    inventory_manager = InventoryManager(loader=loader, sources=['localhost'])

    play_context = PlayContext()


# Generated at 2022-06-11 11:12:40.809542
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.collection_search import CollectionSearch
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.resolver import VariableManagerTombstone
    from ansible.plugins.loader import get_all_plugin_loaders, get_collection_loader


# Generated at 2022-06-11 11:12:49.018801
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    ds = {
        'include': 'somefile',
        'action': 'include',
        'action2': 'include2',
        'tags': ['tag1', 'tag2']
    }
    new_ds = ti.preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert set(new_ds.keys()) == set(ds.keys()) - {'action2'}

    ds = {
        'include': 'somefile',
        'action': 'import_role',
        'action2': 'include2',
        'tags': ['tag1', 'tag2']
    }
    new_ds = ti.preprocess_data(ds)
    assert isinstance(new_ds, dict)
    assert set(new_ds.keys()) == set

# Generated at 2022-06-11 11:12:59.731397
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import os
    import tempfile

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    import ansible.constants as C

    current_dir = os.path.dirname(os.path.realpath(__file__))
    parent_dir = os.path.dirname(current_dir)
    plugin_dir = os.path.join(parent_dir, 'lib', 'ansible', 'plugins', 'action')

    if plugin_dir not in C.DEFAULT_ACTION_PLUGIN_PATH:
        C.DEFAULT_ACTION_PLUGIN_PATH.insert(0, plugin_dir)

    (fd, fname) = tempfile.mkstemp()

# Generated at 2022-06-11 11:13:10.117799
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Assumptions:
    # - the data being loaded is valid, so we don't care about all possible variations
    # - the block is only created if apply is specified, the else case is not tested
    # - the self.args.pop('apply', {}) will not alter the original task
    # - the role and parent play are not relevant for this test
    # - the loader is not relevant for this test
    # - the variable manager is not relevant for this test

    # This is the same data as in test_load_role_task_data
    data = {
        'block': [
            {
                'apply': {
                    'block': [],
                    'name': 'Included task'
                },
                'name': 'Included task'
            }
        ]
    }

    # This is the same data as in test_load_

# Generated at 2022-06-11 11:13:20.793145
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()
    variable_manager = VariableManager()

    task_class = TaskInclude()

# Generated at 2022-06-11 11:13:31.599671
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Example of applying TaskInclude on a "fake" Block
    '''
    class FakeBlock:
        def __init__(self, value=None):
            self.value = value

    class FakeTaskInclude(TaskInclude):
        _parent = FakeBlock(value=True)

    ti = FakeTaskInclude(block=[])
    # Apply on the block:
    ti.args['apply'] = {'block': []}
    parent_block = ti.build_parent_block()
    assert isinstance(parent_block, Block)
    assert parent_block._parent.value == True
    # Without apply on the block:
    ti.args.pop('apply')
    parent_block = ti.build_parent_block()
    assert isinstance(parent_block, TaskInclude)
    assert parent_block._parent

# Generated at 2022-06-11 11:13:39.109783
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # These are the allowed options
    task.args = {
        'file': 'foo.yml',
        'apply': {'key': 'value'},
    }
    # No exceptions expected.
    task.check_options(task, None)

    # These are the disallowed options
    options = ['foo', 'bar']
    for option in options:
        task.args = {
            'file': 'foo.yml',
            option: 'baz',   # Should not be here!
        }
        # AnsibleParserError: Invalid options for include_tasks: bar
        try:
            task.check_options(task, None)
        except AnsibleParserError:
            pass
        else:
            raise Exception("Should have thrown exception for option %s" % option)

    # Dis

# Generated at 2022-06-11 11:13:50.662367
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    def make_data(action, exclude_keywords, **kwargs):
        data = {
            'action': action,
            'register': 'var',
            'loop': '{{ items }}',
            'loop_control': {
                'name': 'item'
            },
            'loop_with': 'items',
        }
        data.update(kwargs)

        return {k: v for k, v in data.items() if k not in exclude_keywords}

    def run_TaskInclude_preprocess_data(action, valid_keywords, **kwargs):
        ti = TaskInclude()
        exclude_keywords = C.TASK_INCLUDE_ATTRIBUTES - set(valid_keywords)
        data = make_data(action, exclude_keywords, **kwargs)
        d

# Generated at 2022-06-11 11:13:58.313884
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    class FakeParent(object):
        _play = 'foo'

    class FakeRole(object):
        pass

    class FakeVariableManager(object):
        pass

    class FakeLoader(object):
        pass

    block1 = {'block': []}
    ti = TaskInclude(block=FakeParent(), role=FakeRole(), task_include=None)
    ti._loader = FakeLoader()
    ti._variable_manager = FakeVariableManager()
    pb1 = ti.build_parent_block()
    assert isinstance(pb1, Block)
    assert pb1.block == []

    block2 = {'block': ['t1', 't2', 't3']}
    ti = TaskInclude(block=FakeParent(), role=FakeRole(), task_include=None)
    ti.args['apply'] = block2
   

# Generated at 2022-06-11 11:14:16.391556
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():  # pylint: disable=R0915
    ''' Unit test for method load of class TaskInclude '''
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    context = PlayContext()
    variable_manager = VariableManager()

    # test for no file specified
    ti = TaskInclude()
    ti.action = 'include'
    task_data = dict(action='include')
    task_data2 = dict(action='include', file='')
    with pytest.raises(AnsibleParserError) as excinfo:
        ti.load(task_data, variable_manager=variable_manager, loader=loader)
    assert "No file specified for include"

# Generated at 2022-06-11 11:14:25.488838
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    block = Block()
    block._play = Play()
    block._play.context = PlayContext()
    block._task_include = Task()
    block.vars = { "a": 3 }
    block._task_include.vars = { "var1": "hello" }
    loader = DataLoader()

# Generated at 2022-06-11 11:14:31.313136
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from units.mock.loader import DictDataLoader

    tasks = [dict(action='include', file='site.yml'),
             dict(action='include_role', name='foobar')]
    block = Block()
    block.append(TaskInclude.load(tasks[0], block=block))
    block.append(TaskInclude.load(tasks[1], block=block))

    # Check if it produces any errors
    for task in block:
        task.preprocess_data(task.serialize())

# Generated at 2022-06-11 11:14:36.397602
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    data = dict(
        action='include',
        include='my_file.yml',
    )

    display.verbosity = 4
    task = Task.load(data)
    task = TaskInclude.load(data)

    # expect no error
    # if we get here, the test passed
    assert True == True


# Generated at 2022-06-11 11:14:46.613968
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti.action = 'include'

# Generated at 2022-06-11 11:14:56.462957
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # create dummy block and register as parent
    parent_block = Block()
    parent_block.vars = {"parent_block_var1": "parent_block_value1"}
    parent_block.register_var_provider(parent_block)

    # create dummy task_include
    task_include = TaskInclude()
    task_include._parent = parent_block
    task_include.vars = {"task_include_var1": "task_include_value1"}

    # verify outcome of method get_vars for task_include
    expected_vars = {"parent_block_var1": "parent_block_value1",
                     "task_include_var1": "task_include_value1"}
    assert task_include.get_vars() == expected_vars

# Generated at 2022-06-11 11:15:01.791093
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create a task with valid an invalid attributes
    task = TaskInclude()
    ds = {'name': 'Test', 'action': 'include', 'invalid_attribute': 'Invalid'}

    # Try to preprocess the data
    result = task.preprocess_data(ds)

    # Check that the invalid attribute has been removed
    assert 'invalid_attribute' not in result



# Generated at 2022-06-11 11:15:11.905341
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    # Init the TaskInclude with valid attributes and set the file
    task_include_data = dict(
        action='include',
        file='test.yml',
    )
    # Test that we can load the data
    ti = TaskInclude.load(task_include_data)
    # The file should be set
    assert ti.args['_raw_params'] == 'test.yml'
    # We should not find an invalid key for the action
    assert set(ti.args.keys()).difference(ti.VALID_ARGS) == set()

    # Init the TaskInclude without valid attributes
    task_include_data = dict(
        action='include',
    )
    # Test that this will raise an error

# Generated at 2022-06-11 11:15:16.516137
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    # Create TaskInclude and TaskIncludeHandler object for testing
    task_include = TaskInclude()
    task_handler_include = TaskInclude()

    # Modify the object dynamically for testing, so that it can be used as role/include task
    task_include.action = 'role'
    task_handler_include.action = 'include'

    # Create data to pass as argument to the preprocess_data method
    data = dict(name='test_role', ignore_errors=True)
    data_invalid = dict(name='test_role', some_random_invalid_attr=True)

    # When ignore_errors is present in the data, and the action is role

# Generated at 2022-06-11 11:15:26.617368
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Example of 'data' dict to pass to TaskInclude
    data = dict(action="include",
                file="file_path",
                other="bad_option",
                apply=dict(block=[]))
    task = TaskInclude()

    # Check with a task where it has been defined that 'apply' is NOT a valid option
    task.VALID_ARGS = TaskInclude.BASE
    task.check_options(task, data)
    assert "other" in task.args
    assert "file" not in task.args
    assert "_raw_params" in task.args

    # Check with a task where it has been defined that 'apply' is a valid option
    task.VALID_ARGS = TaskInclude.VALID_ARGS
    task.check_options(task, data)
    assert task.args.get

# Generated at 2022-06-11 11:15:42.238506
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude(block=None, task_include=True)
    attrs = {
            'foo': 'bar',
            'baz': 'booze'
    }
    task.args = attrs.copy()
    task.action = 'include'

    # 'include' tasks is special, as their attributes are used for the vars
    assert task.get_vars() == attrs

    # 'include_role' does not include the args, but it does the vars
    task.action = 'include_role'
    assert task.get_vars() == task.vars

    # other tasks, like 'include_tasks' do not include args
    task.action = 'include_tasks'
    assert task.get_vars() == {}

# Generated at 2022-06-11 11:15:50.560918
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-11 11:15:58.190248
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit testing of TaskInclude.check_options
    '''
    # instantiate class instances
    task_include_obj = TaskInclude()
    task_obj = Task()

    # initialize instance variables
    task_obj.action = 'include'
    data = {'a': 'a', 'b': 'b', 'c': 'c'}

    # test check_options method where 'file' key is present
    task_obj.args = {'file': 'file', 'a': 'a', 'b': 'b', 'c': 'c'}
    task_obj = task_include_obj.check_options(task_obj, data)
    assert task_obj.args['_raw_params'] == 'file'

    # test check_options method where 'file' key is not present
    task_obj.args

# Generated at 2022-06-11 11:16:06.567092
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    playbook = Playbook()
    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, inventory=None)

# Generated at 2022-06-11 11:16:15.777294
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    global TaskInclude
    with open('test/units/plugins/tasks/include_play.yaml', 'r') as f:
        raw_task_include = f.read()
        task_include_data = yaml.safe_load(raw_task_include)
    task_include_data['_line'] = 'test/units/plugins/tasks/include_play.yaml:4'
    loader, inventory, variable_manager = AnsibleHelpers().get_loader_inventory_variable_manager_objects()
    task_include = TaskInclude.load(
        task_include_data,
        variable_manager=variable_manager,
        loader=loader
    )
    parent = task_include.build_parent_block()
    assert parent.get_name() == 'included_task'
    assert parent._role.get

# Generated at 2022-06-11 11:16:24.978637
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Placed in a separate module as it references ansible.playbook.play and ansible.playbook.block

    # TODO: refactor/remove as (1) redundant with TaskInclude.load and (2) tests should not be in the same file as the module they're testing
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import os

    # Prepare data needed to test the method
    container_data = dict(
        name='test',
        hosts='all',
        gather_facts='no',
        vars=dict(
            a=dict(b=1)
        )
    )
    play_data = dict(
        name='test',
        roles=[],
        vars=dict(
            a=dict(c=2)
        )
    )
    block

# Generated at 2022-06-11 11:16:33.510266
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.args = dict(include_foo='bar')
    task.action = 'include'
    assert task.get_vars() == dict(include_foo='bar')

    task = TaskInclude()
    task.action = 'include_role'
    assert task.get_vars() == dict()

    task = TaskInclude()
    task.action = 'import_role'
    assert task.get_vars() == dict()

    task = TaskInclude()
    _parent = Task()
    _parent.vars = dict(parent_foo='bar')
    task._parent = _parent
    task.action = 'import_role'
    assert task.get_vars() == dict(parent_foo='bar')

# Generated at 2022-06-11 11:16:43.050354
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import mock

    class MicroMock(mock.Mock):
        __getitem__ = mock.Mock(return_value=Sentinel)
        __getattr__ = mock.Mock(return_value=Sentinel)

    tasks = ['include', 'import_role', 'import_playbook', 'include_role', 'include_tasks']
    for t in tasks:
        # no file specified
        m = MicroMock(action=t)
        m.args = dict(file=None)
        with pytest.raises(AnsibleParserError):
            TaskInclude.check_options(m, 'data')

        # valid args
        m = MicroMock(action=t)
        m.args = dict(file='file')

# Generated at 2022-06-11 11:16:52.107316
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    ti._role = 'dummy_role'
    ti._parent = lambda: None
    ti._parent._play = 'dummy_play'
    # The private _loader of the mock object is actually a dict, hence the 'copy()'
    # Note that a param 'block' is required to be passed in order to be able to make a copy of the task's block
    ti._variable_manager = lambda: None
    ti._variable_manager.__dict__ = dict(vars={}, _fact_cache={}, get_vars=lambda: {}, template_host='dummy')
    ti._loader = lambda: None
    ti._loader.__dict__ = dict(vars={}).copy()
    p_block = ti.build_parent_block()

    assert p_block.block == []

# Generated at 2022-06-11 11:17:03.269948
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Verify get_vars works correctly when the action is 'include'
    # Create a task include
    import ansible.playbook.role_include as role_include
    import ansible.playbook.task_include as task_include

# Generated at 2022-06-11 11:17:20.220640
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    def assert_no_side_effect(ds):
        ds_copy = ds.copy()
        ti = TaskInclude()
        ti.preprocess_data(ds)
        assert ds == ds_copy

    ds = dict(action='include_role', name='bar')
    assert_no_side_effect(ds)

    ds['bad'] = 42
    ds_copy = ds.copy()
    ti = TaskInclude()
    with pytest.raises(AnsibleParserError):
        ti.preprocess_data(ds)
    assert ds == ds_copy

# Generated at 2022-06-11 11:17:30.438690
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Creating a fake TaskInclude instance
    class FakeBlock:
        class FakePlay:
            class FakeRole:
                class FakeLoader:
                    pass

                def get_vars(self):
                    return dict(key="role_vars")

            def get_vars(self):
                return dict(key="play_vars")

        class FakeVariableManager:
            pass

        def get_vars(self):
            return dict(key="block_vars")

    class FakeRole:
        def get_vars(self):
            return dict(key="role_vars")

    ti = TaskInclude(block=FakeBlock())
    ti.args = dict(key="args")
    ti.action = "some task other than 'include'"
    ti.vars = dict(key="task_vars")
    ti._

# Generated at 2022-06-11 11:17:39.713666
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude

    assert TaskInclude._validate_args({'bad_arg': '_ignored_'}) == {}

    assert TaskInclude.check_options(TaskInclude(Block()), {'action': 'include_role', 'apply': {}, 'args': {}})

    try:
        TaskInclude.check_options(TaskInclude(Block()), {'action': 'include', 'apply': [], 'args': {}})
    except AnsibleParserError as e:
        assert e.message == 'Expected a dict for apply but got <class \'list\'> instead'


# Generated at 2022-06-11 11:17:49.405110
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test case to check the method of TaskInclude
    :return:
    """
    test_attr = FieldAttribute(default=None, field_type='dict')
    test_attr.name = 'apply'
    test_attr.set_data('apply', dict(block=[]))
    test_attr.set_data('block', '')
    test_attr._parent = None
    import ansible.playbook.play_context
    ctx = ansible.playbook.play_context.PlayContext()
    task = TaskInclude(play=ctx)
    p_block = task.build_parent_block()
    assert p_block == task


# Generated at 2022-06-11 11:17:57.882460
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-11 11:17:59.267764
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # TODO
    pass

# Generated at 2022-06-11 11:18:08.998476
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import os
    import sys
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.play_context
    import ansible.playbook.block

    # Mock play object as _parent property
    class mock_play():
        hosts = 'all'
        tasks = []

        def __init__(self, name=None):
            self.vars = {}
            self.name = name if name is not None else 'mock play'
            self.play_context = ansible.playbook.play_context.PlayContext()

        def get_vars(self):
            return {'foo': 'mock play'}

    # Mock block object as _parent property
    class mock_block():
        hosts = 'all'
        tasks = []


# Generated at 2022-06-11 11:18:18.739827
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options of class TaskInclude
    :return:
    '''
    ti = TaskInclude()
    def validate_data(task_data, action):
        '''
        Method to apply check_options to task_data and validate the output.
        TaskInclude.load and HandlerTaskInclude.load call this method
        :param task_data:
        :param action:
        :return:
        '''
        task = TaskInclude.load(task_data, block=None, role=None, task_include=None, variable_manager=None, loader=None)
        if action in C._ACTION_INCLUDE_TASKS:
            assert task.args.get('apply')
        else:
            assert not task.args.get('apply')

    # no params
    task

# Generated at 2022-06-11 11:18:25.085747
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    assert TaskInclude.check_options.__doc__ is not None
    assert TaskInclude.check_options.__doc__ == TaskInclude.check_options.func_doc

    task = TaskInclude()
    assert task.check_options(task, {}).action == 'include'

    task = TaskInclude.load({'include': 'foo'})
    assert task.check_options(task, {}).args['_raw_params'] == 'foo'

    task = TaskInclude.load({'include': 'foo', 'when': 'bar'})
    assert task.check_options(task, {}).args['_raw_params'] == 'foo'

    with pytest.raises(AnsibleParserError):
        task = TaskInclude.load({'import_playbook': 'foo', 'apply': 'bar'})
       

# Generated at 2022-06-11 11:18:29.217852
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # # Create task object
    # task = TaskInclude()
    #
    # # Check if variable 'value1' exists in task variable
    # assert('value1' in task.get_vars())
    #
    # # Check the value of variable 'value1' in task variable
    # assert(task.get_vars()['value1'] == '10')
    # pass
    pass

# Generated at 2022-06-11 11:18:48.967919
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude

    module_data = AnsibleUnicode('include_tasks')
    task_data = AnsibleUnicode('include_tasks')
    task_include_args = dict(_raw_params=AnsibleUnicode('/etc/playbooks/playbook.yaml'))
    block_args = dict()

    task_include = TaskInclude(block=Block.load(block_args, play=None, task_include=None, role=None),
                               role=None,
                               task_include={'action': module_data, 'args': task_include_args})


# Generated at 2022-06-11 11:18:57.898679
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class FakeVars(object):
        def __init__(self, ds):
            self.vars = ds
    class FakeRole(object):
        def __init__(self, ds):
            self.vars = ds

    task_include_data = {'apply': {'load_path': 'test'}, 'my_test': 'test'}
    task_include = TaskInclude(task_include=FakeVars(task_include_data))

    task_include.check_options(task_include, task_include_data)
    assert task_include.args.get('load_path') is None  # Must be None because apply is not supported for ``include_role``
    assert task_include.args.get('my_test') is None  # Must be None because ``my_test`` is not valid option



# Generated at 2022-06-11 11:19:06.772560
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    print('testing TaskInclude.get_vars()...')

    # Using local import as the file is in tests/units/parsing/
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()

    # load play 1

# Generated at 2022-06-11 11:19:16.052773
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Test no parent block
    data = dict(
        apply = dict(
            block = [],
        ),
    )
    p_block = TaskInclude.load(data, loader=None).build_parent_block()
    assert p_block._parent is None

    # Test parent block exists
    block_data = dict(
        block = [],
    )
    block = Block.load(
        block_data,
        play=None,
        task_include=None,
        role=None,
        variable_manager=None,
        loader=None,
    )
    data = dict(
        apply = dict(
            block = [],
        ),
    )
    p_block = TaskInclude.load(data, block=block, loader=None).build_parent_block()
    assert p_block._parent

# Generated at 2022-06-11 11:19:25.519251
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    # Scenario 1: task does not have apply attribute
    p = Play().load({'name': 'play0', 'hosts': 'all'})
    b = Block()
    b._play = p
    t = TaskInclude()
    t._parent = b
    t.action = 'include'
    t.args = {'file': 123}
    assert t.build_parent_block() is t, "method build_parent_block must return self because the task does not have apply attribute"

    # Scenario 2: task has an apply attribute
    apply_attrs = {'block': []}
    t.args['apply'] = apply_attrs
    p_

# Generated at 2022-06-11 11:19:28.554490
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args = dict(var1='value1')
    task_include.action = 'include'
    assert task_include.get_vars() == dict(var1='value1')

# Generated at 2022-06-11 11:19:37.360727
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    def _create_example_task_include(data):
        return TaskInclude(block=None, role=None, task_include=None).load_data(data, variable_manager=None, loader=None)

    # 'include' must have valid options
    assert _create_example_task_include({'include': 'foobar.yml', 'run_once': True})
    assert _create_example_task_include({'include': 'foobar.yml', 'ignore_errors': True})
    assert _create_example_task_include({'include': 'foobar.yml', 'loop': ['one', 'two']})
    assert _create_example_task_include({'include': 'foobar.yml', 'loop_with': 'fuz'})

# Generated at 2022-06-11 11:19:46.027169
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.role.include import IncludeRole

    # Test preprocess_data
    for ds in ({'name': {'action': 'include_role', 'tasks': 'tasks', 'vars': 'vars'}},
               {'name': {'action': 'import_role', 'tasks': 'tasks', 'vars': 'vars'}},
               {'name': {'action': 'include_tasks', 'file': 'file', 'vars': 'vars'}},
               {'name': {'action': 'import_tasks', 'file': 'file', 'vars': 'vars'}}):
        ti = TaskInclude()
        ti.preprocess_data(ds)
        assert not ti.args
        assert ds['name']

    # Test load with no raw params

# Generated at 2022-06-11 11:19:55.361893
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test that get_vars returns the correct variables with the 'include' action
    '''
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    display.verbosity = 0

    p = Play().load({
        'name': 'aplay',
        'hosts': 'all',
        'gather_facts': 'no',
        'roles': [],
        'tasks': [
            {'name': 'task-1', 'include': 'task-2', 'vars': {'var1': 'value1', 'var2': 'value2'}},
            {'name': 'task-2', 'vars': {'var3': 'value3', 'var4': 'value4'}}
        ]
    }, variable_manager=None, loader=None)

# Generated at 2022-06-11 11:20:03.622532
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    # indentation needed for YAML parsing
    yml_play = """---
- hosts: localhost
  tasks:
    - include: included.yml
"""
    play = Play.load(yml_play, variable_manager=play_context.variable_manager, loader=play_context.loader)
    task = play.get_tasks()[0]

    assert task.get_vars().get('hosts') == 'localhost'
    assert task.get_vars().get('tasks') == None
    assert task.get_vars().get('include') == 'included.yml'



# Generated at 2022-06-11 11:20:31.060982
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    data = dict(
        action = 'include_role',
        role_name = 'redhat.yum',
        unvalidated_option = 'test',
    )
    processed_data = task.preprocess_data(data)
    assert(processed_data['unvalidated_option'] == Sentinel)

    data = dict(
        action = 'include_tasks',
        file = 'tasks/main.yml',
        unvalidated_option = 'test',
    )
    processed_data = task.preprocess_data(data)
    assert(processed_data['unvalidated_option'] == Sentinel)

# Generated at 2022-06-11 11:20:39.391219
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO

    data1 = """
    - hosts: localhost
      connection: local
      gather_facts: false
      tasks:
        - name: include a file
          action: include
          args:
              file: "{{ my_file }}"
              ignore_errors: True
          vars:
              my_var: 'a string'

    """
