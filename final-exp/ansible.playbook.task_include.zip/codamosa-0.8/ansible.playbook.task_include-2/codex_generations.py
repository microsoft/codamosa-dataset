

# Generated at 2022-06-11 11:10:49.266880
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude(block=Block.load({'tasks': [{}]}))
    task._parent = TaskInclude(block=Block.load({'vars': {'foo': 'bar'}}))

    task.vars = {'baz': 'qux'}
    task.args = {'hey': 'there'}

    assert task.action not in C._ACTION_INCLUDE and task.get_vars() == {'baz': 'qux'}
    task.action = 'include'
    assert task.get_vars() == {'foo': 'bar', 'baz': 'qux', 'hey': 'there'}

# Generated at 2022-06-11 11:10:59.531513
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Wipe these clean on every load
    if hasattr(TaskInclude, '_include_cache'):
        del TaskInclude._include_cache

    # Below we test the case where a 'task' is used as an 'include' by checking
    # if the 'ignore_errors' kwarg is properly assigned

# Generated at 2022-06-11 11:11:11.139715
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    t = TaskInclude.load(
        dict(
            action='include_tasks',
            file='test.yml',
            apply=dict(
                block=dict(
                    when=False,
                    ignore_errors=True,
                )
            ),
            run_once=True,
        ),
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None,
    )
    assert t.args['file'].vars == {'file': 'test.yml'}
    assert t.args['apply'].vars == {'block': {}}
    assert t.args['run_once'].vars == {'run_once': True}
    assert isinstance(t.args['apply'], Block)

# Generated at 2022-06-11 11:11:16.889518
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class TestTaskInclude(TaskInclude):
        def __init__(self, action, keyword, test_field_name, test_field_type, test_field_default, task_include=None):
            super(TaskInclude, self).__init__(task_include=task_include)
            self.args = {
                'action': action,
                '_raw_params': keyword,
                '__test_field_name__': test_field_name,
                '__test_field_type__': test_field_type,
                '__test_field_default__': test_field_default,
            }

# Generated at 2022-06-11 11:11:28.341394
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-11 11:11:39.127983
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    task = TaskInclude()
    result = task.check_options(
        dict(action='include', args=dict(include_role=dict(name='my_role', apply=dict(foo=1)))),
        dict(action='include', include_role=dict(name='my_role', apply=dict(foo=1)))
    )
    assert result == dict(action='include', args=dict(include_role=dict(name='my_role', apply=dict(foo=1))))


# Generated at 2022-06-11 11:11:46.493138
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = Block()

    task = TaskInclude(block=block)
    task.role = None
    task._parent = block

    # Test when apply is not specified
    pb = task.build_parent_block()
    assert pb == block

    # Test when apply is specified
    task.args['apply'] = {'when': True}
    pb2 = task.build_parent_block()
    assert pb2 != block
    assert pb2._parent == block

# Generated at 2022-06-11 11:11:51.536307
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    task = Task.load({'foo': 'bar'})
    assert task.check_options({}, {}) == {}
    with pytest.raises(AnsibleParserError):
        task.check_options({'_raw_params': True}, {})
    with pytest.raises(AnsibleParserError):
        task.check_options({'file': True}, {})

    task = Task.load({'apply': {'foo': 'bar'}})
    assert task.check_options({'apply': 'foo'}, {}) == {'apply': 'foo'}
    task = Task.load({'localhost': {'foo': 'bar'}})
    assert task.check_options({'localhost': 'foo'}, {}) == {'localhost': 'foo'}

   

# Generated at 2022-06-11 11:12:01.432779
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    This method tests the check_options method of class TaskInclude
    '''

# Generated at 2022-06-11 11:12:12.509630
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test no change if no invalid keyword is present
    ds = {'name': 'test', 'include': 'test1'}
    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert ds == {'name': 'test', 'include': 'test1'}

    # Test exception is raised if invalid keyword is present
    ds = {'name': 'test', 'froiz': 'test2'}
    ti = TaskInclude()
    try:
        ds = ti.preprocess_data(ds)
    except AnsibleParserError:
        pass
    else:
        assert False

    # Test with 'include'
    ds = {'name': 'test', 'include': 'test1', 'froiz': 'test2'}
    ti = TaskInclude()


# Generated at 2022-06-11 11:12:25.801219
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    module = type('module', (), dict(ANSIBLE_MODULE_ARGS={'param1': '1', 'param2': '2'}))()
    module.params = module.ANSIBLE_MODULE_ARGS
    module.fail_json = lambda x: None

    mock_task = TaskInclude(block=None, role=None, task_include=None,
                            _role_params={'param1': '1'}, action='include', _parent=ModuleExecutor(module))
    mock_task.args = { 'foo': 'bar'}
    assert mock_task.action in C._ACTION_ALL_INCLUDE_ROLE_TASKS
    assert mock_task.get_vars() == {'foo': 'bar', 'param1': '1', 'param2': '2'}

    module = type

# Generated at 2022-06-11 11:12:36.614932
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block_vars = TaskInclude(dict(vars=dict(a=1, b=2)))
    assert block_vars.get_vars() == dict(a=1, b=2)

    block_apply = TaskInclude(dict(vars=dict(a=1, b=2), args=dict(c=3, d=4), apply=dict(e=5, f=6)))
    assert block_apply.get_vars() == dict(a=1, b=2, c=3, d=4, e=5, f=6)

    block_tags = TaskInclude(dict(vars=dict(a=1, b=2), args=dict(c=3, d=4), apply=dict(e=5, f=6), tags=["x", "y", "z"]))


# Generated at 2022-06-11 11:12:46.195955
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # creation of TaskInclude with action import_tasks
    ti = TaskInclude()
    ti.action = 'import_tasks'
    ti.args = {'file': 'test.yml'}
    # creation of dictionary of data to be executed by method preprocess_data
    ds = {'name': 'import test', 'tags': 'test', 'file': 'test.yml', 'action': 'import_tasks'}
    # execution of method preprocess_data
    result = ti.preprocess_data(ds)
    # test of dictionaries
    assert result == {'action': 'import_tasks', 'args': {'file': 'test.yml'}, 'file': 'test.yml',
                      'name': 'import test', 'tags': 'test'}

# Generated at 2022-06-11 11:12:51.990114
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ds = dict()
    ds.update({'action': 'include'})

    # ds['task_include'] is set by the TaskInclude.load() method
    t = TaskInclude.load(ds)

    assert t.get_vars() == {}

    t.args = {
        '_raw_params': 'include.yml',
        'foo': 'bar',
    }

    assert t.get_vars() == {'foo': 'bar'}

# Generated at 2022-06-11 11:13:02.950713
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    ti = TaskInclude()
    ti.vars = dict(A='B')
    ti.action = 'include'
    # create parent task, which includes vars from parent block
    ti.args = dict(C='D')
    pl = Play.load({'name': '1', 'hosts': ['s1']}, variable_manager=None, loader=None)
    pl._tasks = [ti]
    ti._play = pl
    ti._parent = ti  # task is it's own parent, to demonstrate block inheritance
    ti._role = None
    inv = Inventory(loader=None, variable_manager=None, host_list=[])
    ti._variable_manager = inv

# Generated at 2022-06-11 11:13:09.966140
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = dict(action='include', file='foo.yml')

    ti = TaskInclude()
    ds = ti.preprocess_data(ds)
    assert 'include' == ds['action']
    assert 'foo.yml' == ds['file']

    ds = dict(action='include', file='foo.yml', bar='baz')
    with pytest.raises(AnsibleParserError):
        ti = TaskInclude()
        ti.preprocess_data(ds)


# Generated at 2022-06-11 11:13:20.605846
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.group_task import GroupTask
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    class TestTaskInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            super(TestTaskInclude, self).__

# Generated at 2022-06-11 11:13:29.780572
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    obj_parent = TaskInclude()

    obj_task = TaskInclude(
        block=obj_parent,
        vars={'name': 'value'},
        args={'var': 'value'},
        action='include'
    )

    assert obj_task.get_vars() == {'var': 'value', 'name': 'value'}

    obj_task = TaskInclude(
        block=obj_parent,
        vars={'name': 'value'},
        args={'var': 'value'},
        action='include_role'
    )

    assert obj_task.get_vars() == {'name': 'value'}

# Generated at 2022-06-11 11:13:38.250979
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test the get_vars method of class TaskInclude

    # make a mock task
    mytask = TaskInclude()
    mytask.action = 'include'
    mytask.args['x'] = '1'
    mytask.vars['y'] = '2'
    mytask.block = [
        Task(),
        Task(),
    ]
    mytask.block[0].args['a'] = '3'
    mytask.block[0].vars['b'] = '4'
    mytask.block[1].args['c'] = '5'
    mytask.block[1].vars['d'] = '6'

    # call get_vars
    vars = mytask.get_vars()

    # test the result

# Generated at 2022-06-11 11:13:49.719024
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import ansible.utils.context_objects as context_objects
    # Create a valid context
    context_objects.settings = C
    context_objects.CLIARGS = lambda: None
    con = PlayContext()
    con._play = lambda: None
    con._play._variable_manager =  VariableManager(con)
    con._play._variable_manager._inventory = InventoryManager(con)
    con._task = lambda: None
    con._task._block = lambda: None
    con._task._block._role = lambda: None
    con._task._block._role._path = "./"
    con._task._task_

# Generated at 2022-06-11 11:13:59.633193
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Test with empty apply dict
    ti = TaskInclude()
    ti.args = dict()
    ti._loader = None
    ti._variable_manager = None

    pb = ti.build_parent_block()
    assert isinstance(pb, TaskInclude)

    # Test with apply dict
    ti = TaskInclude()
    ti.args = dict(apply={})
    ti._loader = None
    ti._variable_manager = None

    pb = ti.build_parent_block()
    assert isinstance(pb, Block)

# Generated at 2022-06-11 11:14:09.888151
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_attrs = dict(
        name = 'example loop',
        loop = '{{ example }}',
    )
    ansible_var_manager = {}
    ansible_loader = {}
    ansible_play = {'hosts': 'localhost'}
    ansible_role = {}
    task_include = TaskInclude.load(
        apply_attrs,
        play=ansible_play,
        role=ansible_role,
        variable_manager=ansible_var_manager,
        loader=ansible_loader,
    )
    # Validate attributes
    assert task_include.action == 'include'
    assert task_include.name == 'example loop'
    assert task_include.loop == '{{ example }}'
    assert task_include.has_parent() == False
    # Run the method being tested


# Generated at 2022-06-11 11:14:19.763186
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play

    TaskInclude.BASE = frozenset(('_raw_params', 'apply'))
    TaskInclude.OTHER_ARGS = frozenset(())
    TaskInclude.VALID_ARGS = TaskInclude.BASE.union(TaskInclude.OTHER_ARGS)
    TaskInclude.VALID_INCLUDE_KEYWORDS = frozenset(
        ('action', 'args', 'collections', 'debugger', 'ignore_errors', 'loop', 'loop_control', 'loop_with', 'name',
         'no_log', 'register', 'run_once', 'tags', 'timeout', 'vars', 'when'))


# Generated at 2022-06-11 11:14:28.248221
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    ds = {'action': 'include', 'name': 'include test task', 'a': 'foo', 'b': 'bar'}
    new_ds = task_include.preprocess_data(ds)

    assert ds == new_ds

    ds = {'action': 'import_role', 'name': 'include test task'}
    new_ds = task_include.preprocess_data(ds)

    assert ds == new_ds

    ds = {'action': 'import_role', 'name': 'include test task', 'not_allowed': 'foo'}
    try:
        task_include.preprocess_data(ds)
        assert False
    except AnsibleParserError:
        pass



# Generated at 2022-06-11 11:14:34.498110
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()

    test_cases = (
        (dict(apply=dict(ignore_errors=True)), dict(apply=dict(ignore_errors=True))),
        (dict(apply={}, ignore_errors=True), dict(apply={}, ignore_errors=True)),
    )

    for ds, expected_ds in test_cases:
        actual_ds = task_include.preprocess_data(ds)
        assert expected_ds == actual_ds

# Generated at 2022-06-11 11:14:45.046371
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.extra_vars = {"hostvars": {"host1": {"var1": "host1", "var2": "host1"}}, "group_names": ["group1"]}

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, all_vars=variable_manager, play_context=play_context)

    class Play:
        def __init__(self):
            self.name = "Name"
            self.hosts = ["all"]
            self.hosts

# Generated at 2022-06-11 11:14:49.946955
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    some_dict = {
        'action': 'include_role',
        'name': 'some_role',
        'invalid_key': 'some_value',
    }
    some_dict_expected = {
        'action': 'include_role',
        'name': 'some_role',
    }
    some_dict_result = TaskInclude.preprocess_data(some_dict)

    assert some_dict_result == some_dict_expected

# Generated at 2022-06-11 11:15:00.431067
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.play
    import ansible.vars.manager
    # Inherit the parent task __init__ instead of the TaskInclude class
    # __init__ so that the parent class __init__ gets tested (which might
    # be important in case it changes)
    task = ansible.playbook.block.Block.__init__(
        ansible.playbook.block.Block(),
        role=ansible.playbook.role.Role(),
        task_include=TaskInclude(),
        play=ansible.playbook.play.Play()
    )

    # init with empty args
    task.args = dict()
    assert task.get_vars() == dict()

    # 'include' action and empty args

# Generated at 2022-06-11 11:15:10.575175
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    task_include = TaskInclude()
    task = task_include.load({ 'file' : 'foo.yml' }, block=None, role=None, task_include=None, variable_manager=None, loader=None)

    assert isinstance(task, TaskInclude)
    assert task._role is None
    assert task._parent is None
    assert task._block is None
    assert task.action == 'include'
    assert task.name == 'include'
    assert task.args.keys() == {'_raw_params', 'file'}
    assert task.args['file'] == 'foo.yml'
    assert task.args['_raw_params'] == 'foo.yml'
    assert task._loader is None
    assert task._variable_manager is None
    assert task._task_include is None

# Generated at 2022-06-11 11:15:20.633855
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class Test(TaskInclude):
        FILE = FieldAttribute(isa='path')
        APPLY = FieldAttribute(isa='dict')

        def __init__(self):
            super(Test, self).__init__()
            self.args = dict()

    for t in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        task = Test()

        good_args = dict(
            file='file',
            apply=dict(
                aaa=1,
            ),
            bbb=1,
        )
        task.args = dict(
            file='file',
            bbb=1,
        )
        task.action = t
        task.check_options(task, good_args)
        assert 'apply' in task.args


# Generated at 2022-06-11 11:15:32.726875
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {
        'tags': ['a', 'b'],
        'when': 'c',
        'include': 'd',
    }
    task_include.action = 'role'

    task_include.preprocess_data(task_include.args)
    assert len(task_include.args) == 1
    assert not task_include.args.get('tags')
    assert not task_include.args.get('when')
    assert task_include.args.get('include') == 'd'

# Generated at 2022-06-11 11:15:41.301207
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    add_all_plugin_dirs()

    class Host(object):
        def __init__(self, name):
            self.name = name

    # Mock objects
    class Connection(object):
        @staticmethod
        def connect(self, paramiko=False):
            return paramiko


# Generated at 2022-06-11 11:15:49.693459
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task1 = Task()
    task1.action = 'include_role'
    task2 = task_include.check_options(task1, None)
    assert task1.args == {}
    assert task2.args['_raw_params'] == '{{ role_name }}'

    task1 = Task()
    task1.action = 'include_role'
    task1.args = {'file': '{{ role_name }}'}
    task2 = task_include.check_options(task1, None)
    assert task2.args['_raw_params'] == '{{ role_name }}'

    task1 = Task()
    task1.action = 'include'
    task1.args = {'file': '{{ role_name }}'}
    task2 = task_include.check

# Generated at 2022-06-11 11:15:57.324961
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # Here we create a task and we test that check_options method does not raise any error
    task = TaskInclude(action='include_vars')
    task.args['file'] = 'filename'
    ret = task.check_options(task, data=None)
    assert ret == task

    # Here we create a task and we test that check_options method raises an error because
    # we specify that the task will be of type 'import_tasks' and we provide it with
    # an invalid parameter, `apply`.
    task = TaskInclude(action='import_tasks')
    task.args['file'] = 'filename'
    task.args['apply'] = 'invalid'
    try:
        task.check_options(task, data=None)
        assert False
    except AnsibleParserError:
        pass

    # Here

# Generated at 2022-06-11 11:16:01.414684
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Init of a new taskinclude instance
    ti = TaskInclude()
    ti.action = 'include_tasks'
    ti.args = {'tags': ['always'], 'when': 'True'}
    # Check that the method returns the expected result
    assert(ti.get_vars() == {'tags': ['always'], 'when': 'True'})

# Generated at 2022-06-11 11:16:10.236483
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # create a parent task
    p_task = TaskInclude()

    # create a task with 'include' action
    test_include_vars = {'name': 'test_name', 'tags': ['tag1', 'tag2'], 'when': ['true']}
    test_include_args = {'action': 'include', 'args': {'name': 'test_name', 'tags': ['tag1', 'tag2'], 'when': ['true']}}
    task = TaskInclude(task_include=p_task, args=test_include_args)
    task.vars = test_include_vars

    # get the actual vars
    actual_vars = task.get_vars()

    # get the expected vars
    expected_vars = dict()

# Generated at 2022-06-11 11:16:19.301370
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    # Create some data mock to use in this tests
    task_data = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4',
    }

    # Call the method 'preprocess_data' from class TaskInclude passing the task_data as parameter
    # This should return the same task_data ie: no change was done to it
    new_task_data = ti.preprocess_data(task_data)

    # Assert that there was no changes in the task_data
    assert new_task_data == task_data

    # Let's add some invalid keys to the task_data to be sure the method 'preprocess_data'
    # remove them from task_data

# Generated at 2022-06-11 11:16:28.800963
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    '''
    Unit test for method load of class TaskInclude
    '''
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class MockInclude(TaskInclude):
        '''
        Mocked class for unit test
        '''
        def load_data(self, ds, variable_manager=None, loader=None):
            return ds

    my_block = MockInclude()
    my_block.check_options(my_block.load_data({'action': 'include_role', 'file': 'foo', 'apply': {'derp': 'burp'}}))
    my_block.statically_loaded = True
    my_block.args = {'file': 'foo', '_raw_params': 'bar', 'baz': 'qux'}

# Generated at 2022-06-11 11:16:32.674354
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.args = dict(foo='bar')
    ti.action = 'include'
    result = ti.get_vars()
    assert result['foo'] == 'bar'
    ti.action = 'import_tasks'
    result = ti.get_vars()
    assert 'foo' not in result

# Generated at 2022-06-11 11:16:42.375676
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
  '''
  Test method TaskInclude.build_parent_block
  '''
  import ast

  from ansible.playbook.play import Play
  from ansible.playbook.role.definition import RoleDefinition
  from ansible.playbook.task_include import TaskInclude
  from ansible.template import Templar
  from ansible.vars import VariableManager
  from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 11:16:54.672725
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.clean import module_args_to_strings

    task_data = dict(
        apply=dict(
            a=1,
            b=2,
        ),
        file='role1',
        tags=['tag1', 'tag2'],
        when=True,
    )

    t = TaskInclude()
    assert t.preprocess_data(task_data) == dict(
        apply=dict(
            a=1,
            b=2,
        ),
        file='role1',
    )

    task_data['tags'] = ['tag1', 'tag2']

# Generated at 2022-06-11 11:17:05.689467
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_include = TaskInclude()
    task_include.args = {
        'apply': {
            'block': [],
            'debugger': None,
            'ignore_errors': False,
            'loops': None,
            'loop_control': None,
            'loop_with': None,
            'name': None,
            'register': None,
            'run_once': False,
            'tags': None,
            'timeout': None,
            'vars': {},
            'when': None,
        },
    }
    task_include._parent = 'mock_parent'
    task_include._role = 'mock_role'
    task_include._variable_manager = 'mock_variable_manager'
    task_include._loader = 'mock_loader'

    # In this case,

# Generated at 2022-06-11 11:17:15.933076
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    def do_test(action, expected, check_parent=True):
        if check_parent:
            data = dict(action=action, parent_args=dict(n=1, m=2))
        else:
            data = dict(action=action, n=1, m=2)
        task = TaskInclude.load(data)
        assert task.get_vars() == expected

    yield do_test, C._ACTION_INCLUDE, {'n': 1, 'm': 2}
    yield do_test, C._ACTION_INCLUDE_ROLE, {'n': 1, 'm': 2}
    yield do_test, C._ACTION_INCLUDE_TASKS, {'n': 1, 'm': 2}
    yield do_test, C._ACTION_IMPORT_TASKS,

# Generated at 2022-06-11 11:17:27.885419
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Imports
    import ansible.playbook.task_include

    # Setup
    ds = dict(
        name='test name',
        action='debug',
        debugger='test debugger',
        loop_with='test loop_with',
        loop_control='test loop_control',
        loop='test loop',
        when='test when',
        tags='test tags',
        args='test args',
        timeout='test timeout',
        vars='test vars',
        no_log='test no_log',
        register='test register',
        run_once='test run_once',
        apply='test apply',
        collections='test collections',
        ignore_errors='test ignore_errors',
        file='test/file.yml'
    )

# Generated at 2022-06-11 11:17:35.154330
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    mock_loader = 'foo'

    # Create task without parent and without arguments
    data = dict()
    data['include'] = None
    data['action'] = 'include'
    data['name'] = 'test_playbook_name'
    block = TaskInclude.load(data, loader=mock_loader)
    assert (block.get_vars() == dict())

    # Create task with dummy parent and without arguments
    data = dict()
    data['include'] = None
    data['action'] = 'include'
    data['name'] = 'test_playbook_name'
    parent = Block()
    parent.vars = dict(var1='val1', var2='val2')
    block = TaskInclude

# Generated at 2022-06-11 11:17:45.754479
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 11:17:55.970435
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.repository import collection_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    cl = AnsibleCollectionLoader()
    cl.set_collection_paths(['./test/data/collections/ansible_collections/my_namespace/my_collection'])
    cl.resolve_collections(['my_namespace.my_collection'])

    my_collection = collection_loader._load_collections(cl, ['my_namespace.my_collection'])[0]

    # Create a dummy variable_manager
    variable_manager = FieldAttribute()
    variable_manager.defaults = {'inventory_dir': '.', 'inventory_file': 'foo'}
    variable_manager.vars_cache = {}

    # Create a dummy loader
    loader = FieldAttribute()
    loader

# Generated at 2022-06-11 11:18:03.563985
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    get_vars(self) method should return an empty dict
    when action is anything except 'include'.
    '''
    # create a task-include obj instance and assert action is not 'include'
    ti = TaskInclude()
    assert ti.action != 'include'

    # create vars to be referenced in the indicated tasks
    vars = dict(key='value')

    # create and add included tasks
    included_tasks = [Task()]
    ti.block = included_tasks

    # set vars
    ti.vars = vars
    ti.args = vars

    # Check the returned vars are not considered
    assert ti.get_vars() == dict()



# Generated at 2022-06-11 11:18:14.057848
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Make sure TaskInclude.get_vars works properly
    # This function is not static, we cannot call it directly
    # We also cannot call TaskInclude.__init__() because it is not
    # a static class and its __init__() calls functions that
    # require a class instance.

    # Required to create the parent blocks
    fake_parent = Block()
    fake_parent.vars = {'var1': 'value1'}

    # Test data
    data = {'vars': {'var2': 'value2'}, 'args': {'var3': 'value3'}}

    # Test TaskInclude.get_vars()
    ti = TaskInclude()
    ti.load_data(data)

    # If no parent is specified, vars are self.vars + self.args
    # Only '

# Generated at 2022-06-11 11:18:22.339262
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options of class TaskInclude
    '''

    # Test with empty task
    task_incl = TaskInclude()
    task = {}
    new_task = task_incl.check_options(task, {})
    assert new_task is task

    # Test with apply option
    task = {'apply': {'tags': [], 'when': False}}
    with pytest.raises(AnsibleParserError):
        task_incl.check_options(task, {})

    # Test with options not existing in TaskInclude
    task = {'test': {'tags': [], 'when': False}}
    with pytest.raises(AnsibleParserError):
        task_incl.check_options(task, {})

    # Test with empty apply option
    task

# Generated at 2022-06-11 11:18:51.663232
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # The options tested are only for action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS
    test_play = Play().load({
        'name': 'test play',
        'hosts': ['all'],
        'gather_facts': 'no',
        'tasks': [
            dict(action=dict(include='foo.yml')),
            dict(action=dict(import_role='bar', name='baz'))
        ]
    }, variable_manager=None, loader=None)

    test_play._included_file_for_host = dict()

# Generated at 2022-06-11 11:19:00.854592
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.task import Task

    # test for action in C._ACTION_INCLUDE
    for action in C._ACTION_INCLUDE:
        task = TaskInclude()
        task.action = action

        # define parent task
        parent_task = Task()
        parent_task._play = Sentinel()
        parent_task.vars = {'foo': 'bar'}
        parent_task.args = {'bar': 'foo'}
        task._parent = parent_task

        # define include task
        task._role = None
        task._variable_manager = None
        task._loader = None
        task.vars = {'baz': 'qux'}

# Generated at 2022-06-11 11:19:09.313103
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.resolve import VariableManager

    yaml_data = {
        'hosts': 'all',
        'tasks': [
            {
                'name': 'include test',
                'include': {'file': 'some_file.yml'}
            }
        ]
    }
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'my_var': 'foobar'}
    display = Display()
    display.verbosity = 3
    loader = DataLoader()

    pc = PlayContext(verbosity=3)
    play = Play().load(yaml_data, variable_manager=variable_manager, loader=loader)
    new_task = play.get_tasks()[0]

# Generated at 2022-06-11 11:19:19.233319
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext

    task = TaskInclude(block=None, task_include=None, role=None, loader=None, variable_manager=None, templar=None)
    task.action = 'include'
    task.args = {'a': 1, 'tags': 'all'}

    # Setup context to assign to _parent
    pc = PlayContext()
    pc._vars = {'f': 1}
    task._parent = pc

    all_vars = task.get_vars()
    assert all_vars == {'a': 1, 'f': 1}, all_vars

    task.action = 'include_tasks'

    all_vars = task.get_vars()

# Generated at 2022-06-11 11:19:23.197780
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.args = { 'foo': 'bar' }
    task._parent = Task()
    task._parent.vars = { 'color': 'red' }
    assert task.get_vars() == {'foo': 'bar', 'color': 'red'}

# Generated at 2022-06-11 11:19:31.732632
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-11 11:19:40.370811
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    The block resulting from build_parent_block should have a block attribute which is a list.
    '''
    import json
    import os
    import tempfile
    from ansible.utils.sentinel import Sentinel

    # Create fixtures
    data_file = tempfile.NamedTemporaryFile(delete=False)
    data = {
        'action': 'include_tasks',
        'args': {
            'apply': {
                'loop': '{{ list_of_dicts }}',
                'loop_control': {
                    'label': "{{ item.mylabel }}",
                },
                'name': "{{ item.mylabel }}",
            }
        }
    }
    json.dump(data, data_file)
    data_file.close()
    data_file_name = data_file.name

# Generated at 2022-06-11 11:19:46.192764
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    data = dict(apply = dict(x = dict()), action = 'include_tasks', import_playbook = '/usr/local/foo.yml')
    with Display().no_output():
        data_preprocessed = task.preprocess_data(data)
    # tested dict has only valid keywords and invalid keywords are removed
    assert(set(data.keys())).difference(task.VALID_INCLUDE_KEYWORDS) == set()


# Generated at 2022-06-11 11:19:55.513921
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Unit test for method build_parent_block of class TaskInclude
    """
    # Testing normal usage
    ds = {'action': 'include_tasks', 'apply': {'name': 'test_task'}}
    ti = TaskInclude(block=None, role=None, task_include=None)
    ti = ti.load(ds, variable_manager=None, loader=None)
    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.block == []

    # Testing normal usage
    ds = {'action': 'include_tasks', 'apply': {'name': 'test_task'}}
    ti = TaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-11 11:20:04.162884
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    # Initialize required for loading

    ds = dict(
        ignore_errors=True,
        file='myinclude.yaml',
        action='include',
        apply=dict(
            block=[]
        )
    )
    task = TaskInclude.load(data=ds, block=None, role=None, task_include=None)
    assert task.args['ignore_errors'] is True
    assert task.args['_raw_params'] == 'myinclude.yaml'
    assert task.action == 'include'


# Generated at 2022-06-11 11:20:34.404719
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.playbook.task import HandlerTask
    from ansible.template import Templar

    # We choose a handler task so play is set properly during load
    t = HandlerTask.load(dict(action=dict(module='foo', args=dict(x=1))), None, None, None)
    # The fake play is necessary for the variable manager to work
    t._play = Play()
    t._play._options = dict(extra_vars={})
    t._play._variable_manager = Templar(t._play._loader, t._play._options)
    t.build_parent_block()

    assert isinstance(t._parent, Block)
    assert t._parent.block is not None
    assert t._parent.block == []
    assert t._parent.vars == dict()
   

# Generated at 2022-06-11 11:20:42.832491
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    ti.args = {'apply': {'block': []}}
    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block._parent is None
    assert not p_block._task
    assert not p_block._role
    assert not p_block._play
    assert p_block._loader is None
    assert p_block._variable_manager is None
    # No sentinel in the args
    assert 'apply' not in p_block.args
    # Only ``block`` in the args
    assert p_block.args == {'block': []}

    ti = TaskInclude()
    ti.args = {'apply': {'block': [{'name': 'test', 'debug': {'var': 'test'}}]}}
