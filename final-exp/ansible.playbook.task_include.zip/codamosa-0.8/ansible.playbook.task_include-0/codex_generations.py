

# Generated at 2022-06-11 11:10:49.718691
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    task_include = TaskInclude()
    task_include.action = 'include_role'

    task_include.args = {'role': 'test_role'}

    vars_manager = VariableManager()
    dataloader = DataLoader()

    host_result = TaskResult(host=None, task=task_include)

    ret_vars = task_include.get_vars()

    assert ret_vars.get('role') == 'test_role'


# Generated at 2022-06-11 11:11:00.462762
# Unit test for method build_parent_block of class TaskInclude

# Generated at 2022-06-11 11:11:11.700089
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Set up an ansible.vars.manager.VariableManager
    vm = VariableManager()
    vm.set_inventory(None)


# Generated at 2022-06-11 11:11:12.446677
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # TODO: implement this
    assert True

# Generated at 2022-06-11 11:11:22.562372
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Hack! Manually create a TaskInclude object
    task = TaskInclude()

    # Test invalid options
    data = {'action': 'include_role', 'foobar': 'foobar'}
    try:
        task.check_options(TaskInclude.load(data), data)
    except AnsibleParserError:
        pass
    else:
        assert False, "ParserException not raised for invalid options"

    # Test invalid options for include (apply only allowed)
    data = {'action': 'include', 'foobar': 'foobar'}
    try:
        task.check_options(TaskInclude.load(data), data)
    except AnsibleParserError:
        pass
    else:
        assert False, "ParserException not raised for invalid options"

    # Test invalid options for include with apply

# Generated at 2022-06-11 11:11:34.417500
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # OK, use the same common dictionary for all test cases.
    # This allow to detect any problem if the order of iteration of the dict is changed.
    # If a problem is detected, the order of the dict must be explicit instead of arbitrary.
    # When you add a new value in the dict, you must
    # - set the value to Sentinel if you don't want the test case to check the value
    # - give a different value for each test case, to make the test case explicit
    # When you add a new test case, you must initialize the dict with the value as previously.
    # If a test case need a value that is not in the dict, you must add it.
    # Note: Using dict comprehension and dict(my_dict, **new_dict) is not working,
    # because it is changing the order of the entries.
    test_dict = {}


# Generated at 2022-06-11 11:11:45.299359
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import os
    import pytest

    data1 = {
        'action': 'include_role',
        'file': 'testfile',
        'apply': 'foo',
        'name': 'test_include_role',
        'tags': 'tag1',
        'ignore_errors': True,
    }
    data2 = {
        'action': 'include_role',
        'file': 'testfile',
        'name': 'test_include_role',
        'tags': 'tag1',
        'badkey': 'badvalue',
    }
    variable_manager = VariableManager()
    loader

# Generated at 2022-06-11 11:11:49.853894
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    result = task.preprocess_data({})
    assert isinstance(result, dict)
    assert len(result) == 0

    # Action: block: - include_tasks:
    result = task.preprocess_data({'debugger': 'true', 'loop': 'true', 'loop_with': 'my_var'})
    assert isinstance(result, dict)
    assert len(result) == 0

    # Action: block: - include:
    result = task.preprocess_data({'debugger': 'true'})
    assert isinstance(result, dict)
    assert 'debugger' in result
    assert result.get('debugger') is True

    # Action: block: - include_role:
    result = task.preprocess_data({'debugger': 'true'})

# Generated at 2022-06-11 11:11:58.358222
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # create a play
    play = Play().load({'name': 'testplay1'}, variable_manager={}, loader=None)

    # create a block and set the parent to the play
    block1 = Block()
    block1._parent = play

    # add a task to the block
    task1 = Task()
    task1.action = 'setup'
    block1._parent = None
    task1._parent = block1
    block1.block = [task1]

    # verify task does not have parent
    assert task1._parent is None

    # verify the task action is setup
    assert task1.action == 'setup'

    # create task include
    task2 = TaskInclude()
    task2.action = 'include'
    task2._parent = block1
    task2._role = None
    block1.block

# Generated at 2022-06-11 11:12:09.192945
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import os

    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.role.include

    test_path = os.path.join(os.path.dirname(__file__), 'test_data')
    test_path = os.path.join(test_path, 'TaskInclude.load' + os.path.extsep + 'json')
    test_data = ansible.utils.jsonify.load_jsonfile(test_path)

    options = test_data['options']
    play = ansible.playbook.PlayBook.load(None, variable_manager=None, loader=None)
    role = ansible.playbook.RoleInclude.load(None, play=play, variable_manager=None, loader=None)
    task = ansible.playbook.task

# Generated at 2022-06-11 11:12:22.714918
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Create a task with apply to trigger the failure
    ds = {
        'action': 'include_role',
        'apply': '',
    }
    ti = TaskInclude()
    try:
        ti.preprocess_data(ds)
    except AnsibleParserError as e:
        assert 'apply' in str(e)
    else:
        assert False, "the task should have failed!"

    # Create a task with an unknown key to trigger the failure
    ds = {
        'action': 'include_role',
        'apply': '',
        'unknown': 'whatever',
    }
    try:
        ti.preprocess_data(ds)
    except AnsibleParserError as e:
        assert 'unknown' in str(e)
    else:
        assert False, "the task should have failed!"

   

# Generated at 2022-06-11 11:12:32.703357
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # create a task that contains an include task, the include task doesn't contain any keywords
    # shouldn't raise an exception
    data = dict(
        action='include_tasks',
        name='test_include',
        file='test_included_play',
        tags=['test_include'],
    )
    display.verbosity = 3
    task = TaskInclude.load(data)

    # create a task that contains an include task and a valid keyword, shouldn't raise an exception
    data = dict(
        action='include_tasks',
        name='test_include',
        file='test_included_play',
        register='some_var',
        tags=['test_include'],
    )
    task = TaskInclude.load(data)

    # create a task that contains an include task and a valid keyword and an

# Generated at 2022-06-11 11:12:43.762799
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Allowed options
    input_data = {'file': "abcd", 'apply': {'b': 'y'}, 'tags': ['tag1', 'tag2']}
    ti = TaskInclude()
    task = ti.load(input_data)
    ti.check_options(task, input_data)

    # Invalid/Ignored options
    input_data2 = {'file': "abcd", 'apply': {'b': 'y'}, 'tags': ['tag1', 'tag2'], 'action': 'include_tasks'}
    # Should pass
    ti.check_options(task, input_data2)

    # Invalid/Ignored options

# Generated at 2022-06-11 11:12:50.487623
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    test_task = Task()
    test_task._variable_manager = {}
    test_task.vars = dict(var1='val1', var2='val2')
    test_task.args = dict(arg1='arg1', arg2='arg2')
    test_block = Block()
    test_block._parent = test_task
    test_block._variable_manager = {}
    test_block._play = Play()
    test_block._play._context = PlayContext()

# Generated at 2022-06-11 11:13:01.493327
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play

    t = Play().load(
        dict(
            hosts='localhost',
            tasks=[
                dict(
                    include=dict(
                        action='include',
                        args=dict(
                            file='/tmp/foo',
                        ),
                        other_option='other_value',
                    ),
                ),
            ],
        ),
        variable_manager=None,
        loader=None,
    )
    t = t.task_blocks[0].block[0]
    assert t.action == 'include'
    assert t.args['file'] == '/tmp/foo'
    assert 'other_option' not in t.args


# Generated at 2022-06-11 11:13:11.322657
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    var_manager = DummyVarsModule()
    t = TaskInclude.load(dict(name='test', file='test'), variable_manager=var_manager)
    t.preprocess_data(dict(action='include'))
    t.preprocess_data(dict(action='import_tasks'))
    t.preprocess_data(dict(action='include', tags='test'))
    t.preprocess_data(dict(action='import_tasks', no_log=True))
    t.preprocess_data(dict(action='import_role', ignore_errors=True))
    t.preprocess_data(dict(action='import_playbook'))

    # This is invalid as it is not TaskInclude.VALID_INCLUDE_KEYWORDS

# Generated at 2022-06-11 11:13:22.236367
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    my_display = Display()
    setattr(my_display, '_suppress_warnings', True)

    task_data = dict(
        _raw_params='/etc/ansible/roles/utils/tasks/main.yaml',
        file='/etc/ansible/roles/utils/tasks/main.yaml',
        action='include',
    )

    play_context = PlayContext()
    #

# Generated at 2022-06-11 11:13:30.717748
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # create a task-include object
    class FauxParent:
        pass
    task_include = TaskInclude(action='include', role=None)
    task_include._parent = FauxParent()
    task_include._parent.get_vars = lambda: {'a': 1}
    task_include.vars = {'b': 2}
    task_include.args = {'c': 3}

    # expected vars are the merge of parent vars, attrs and args
    assert task_include.get_vars() == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 11:13:38.689705
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    #
    # Example 1
    #
    data = {
        'action': 'include_tasks',
        'args': {
            'file': 'myfile.yml',
            'a_bad_key': 'wrong_value',
            'apply': {
                'a_key': 'good_value',
            },
        }
    }

    task = TaskInclude.load(
        data=data,
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )

    ti = TaskInclude(block=None, role=None, task_include=None)
    task_new = ti.check_options(task, data)

    assert task is task_new

# Generated at 2022-06-11 11:13:50.238464
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    example_data = dict(action='include', file='some_include.yml', tags=['include_tags'], apply=dict(a=1, b=2))
    example_data_with_wrong_attr = dict(action='include', file='some_include.yml', tags=['include_tags'], some_wrong_attr='some_value')
    example_data_with_no_apply = dict(action='include', what='some_value', file='some_include.yml', tags=['include_tags'])
    example_data_with_wrong_apply = dict(action='include', file='some_include.yml', tags=['include_tags'], apply=['wrong', 'wrong'])

# Generated at 2022-06-11 11:13:59.395274
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    display.verbosity = 0
    ds = dict(
        apply=dict(
            block=[]
        ),
        file='my_file.yml'
    )
    ti = TaskInclude()
    ti.load_data(ds, variable_manager=None, loader=None)

    p_block = ti.build_parent_block()
    assert ti.action == 'include_tasks'
    assert isinstance(p_block, Block)
    assert p_block.block == []

# Generated at 2022-06-11 11:14:09.679562
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Creating test objects
    task = TaskInclude()
    # Testing a dict for action=include
    dict_action_include = dict(
        action='include',
        file='foo.yml',
        other_param=1,
        other_param2=2,
        other_param3=3,
        other_param4=4,
        extra_param=True,
    )
    # Testing a dict for action=import_tasks
    dict_action_import = dict(
        action='import_tasks',
        file='foo.yml',
        other_param=1,
        other_param2=2,
        other_param3=3,
        other_param4=4,
        extra_param=True,
    )
    # Testing a dict for action=include_role
    dict_action_

# Generated at 2022-06-11 11:14:19.596648
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Valid data
    data = {
        'action': 'include',
        'file': '/path/to/foo.yml',
        'tags': ['tag_1'],
        'ignore_errors': True,
        'apply': {
            'debugger': 'test_debugger',
            'loop_with': 'test_loop_with',
            'loop': 'test_loop',
            'name': 'test_name',
        }
    }
    task_include = TaskInclude()
    task = task_include.check_options(task_include.load_data(data), data)

    assert task.action == 'include'
    assert 'file' not in task.args
    assert task.args['_raw_params'] == data['file']

    assert task.args['tags'] == data['tags']

# Generated at 2022-06-11 11:14:21.199163
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task = TaskInclude()
    assert isinstance(task.build_parent_block(), TaskInclude)

# Generated at 2022-06-11 11:14:30.003060
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import unittest
    import ansible.constants as C

    class FakeParent(object):
        def __init__(self):
            pass
        def get_vars(self):
            return dict(x=1, y=2)

    class FakeTaskInclude(TaskInclude):
        def __init__(self):
            self._parent = FakeParent()
            self.args = dict(apply={'x': 3, 'tags': 'abc', 'when': "x=13"})

    class TestTaskInclude(unittest.TestCase):

        def test_TaskInclude_build_parent_block_no_apply(self):
            task = FakeTaskInclude()
            task.args = {}

            result = task.build_parent_block()

            self.assertEqual(result, task)


# Generated at 2022-06-11 11:14:40.815886
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Tests the following scenarios:
    1. With and without apply
    2. With and without parent_block in apply
    '''
    class MockBlock(object):
        def __init__(self, parent=None):
            self._parent = parent

    class MockRole(object):
        def __init__(self):
            self._task_blocks = []

    block = MockBlock()
    role = MockRole()
    task_include = TaskInclude()
    task_include._parent = block
    task_include._role = role

    # Case 1: include without apply
    task_include.args = {}

    parent_block = task_include.build_parent_block()
    assert isinstance(parent_block, TaskInclude)
    assert parent_block is task_include

    # Case 2: include with apply but no

# Generated at 2022-06-11 11:14:49.120493
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars.manager import VariableManager

    def get_task(vars):
        task_include = TaskInclude.load({'action': 'include', 'args': {'a': 12, 'b': 34}})
        task_include._variable_manager = VariableManager()
        task_include._variable_manager._fact_cache = vars
        return task_include

    my_vars = dict(x=1, y=2)
    ti_obj = get_task(my_vars)
    assert ti_obj.get_vars() == dict(x=1, y=2, a=12, b=34)

    my_vars = dict(x=1, y=2, a=10, b=20)
    ti_obj = get_task(my_vars)
    assert ti_obj

# Generated at 2022-06-11 11:14:59.695984
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.module_utils._text import to_native
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.sentinel import Sentinel
    from ansible.vars.manager import VariableManager

    loader = get_all_plugin_loaders()[0]


# Generated at 2022-06-11 11:15:09.913311
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task_data = dict(
        action="include",
        args=dict(
            file="tasks/main.yml",
        )
    )
    task = Task.load(task_data)

    bad_opts = ['bad_option']
    task.args.update(dict.fromkeys(bad_opts, True))
    assert sorted(task.args.keys()) == sorted(TaskInclude.VALID_ARGS.union(bad_opts))
    assert not task.args['apply']

    try:
        task = ti.check_options(task, task_data)
    except:
        display.display("task[args]: %s" % task.args)
        raise

    assert sorted(task.args.keys()) == sorted(TaskInclude.VALID_ARGS)

# Generated at 2022-06-11 11:15:14.880446
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    #check regular options
    data = {'action': 'include', '_raw_params': 'somefile.yml'}
    task.check_options(task.load_data(data), data)

    #check options with apply
    data = {'action': 'import_role', '_raw_params': 'somefile.yml', 'apply': {}}
    task.check_options(task.load_data(data), data)

    #check options with apply and some other argument
    data = {'action': 'import_role', '_raw_params': 'somefile.yml', 'apply': {}, 'other_arg': 1}
    task.check_options(task.load_data(data), data)

    #check options with apply and some other invalid argument

# Generated at 2022-06-11 11:15:29.035562
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import pytest
    import yaml
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import action_loader

    # Instantiate data loader, inventory, variable and loader manager objects
    data_loader = DataLoader()
    inventory = InventoryManager(data_loader, sources=None)
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)
    loader = None

    # Create play object to initialize loader attributes

# Generated at 2022-06-11 11:15:38.546316
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import sys, os
    sys.path.append("..")
    os.chdir("..")
    from test_utils import AnsiblePlaybookContext, AnsibleTaskTest
    def get_play_context():
        return PlayContext(play=Play().load({'name': 'unit_testing'}, variable_manager=AnsiblePlaybookContext.load(None).variable_manager, loader=AnsiblePlaybookContext.load(None).loader), variable_manager=AnsiblePlaybookContext.load(None).variable_manager, loader=AnsiblePlaybookContext.load(None).loader)

# Generated at 2022-06-11 11:15:46.659146
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Here is three example of test
    ds1 = {
        "include": {}
    }
    ti1 = TaskInclude.load(ds1)
    assert isinstance(ti1.get_vars(), dict)

    # Second example
    ds2 = {
        "include": {
            "action": "import_tasks"
        }
    }
    ti2 = TaskInclude.load(ds2)
    assert isinstance(ti2.get_vars(), dict)

    # third example
    ds3 = {
        "include": {
            "action": "include"
        }
    }
    ti3 = TaskInclude.load(ds3)
    assert isinstance(ti3.get_vars(), dict)

# Generated at 2022-06-11 11:15:54.402582
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Test for action 'import_tasks'
    ti = TaskInclude()
    ti._parent = Block()
    ti._parent.vars = dict()
    ti._parent.vars['parent_var'] = 'parent_value'
    ti.vars = dict()
    ti.vars['task_include_var'] = 'task_include_value'
    ti.args = dict()
    ti.args['task_include_args'] = 'task_include_args_value'
    ti.action = 'import_tasks'
    assert len(ti.get_vars()) == 3
    assert ti.get_vars()['parent_var'] == 'parent_value'
    assert ti.get_vars()['task_include_var'] == 'task_include_value'
    assert ti.get_vars()

# Generated at 2022-06-11 11:16:02.388003
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Import here to workaround a circular import, since AnsibleAction is imported in task_include.py
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    pc = PlayContext()
    p = Play().load({}, variable_manager=None, loader=None)

    ds = {
        'include': {
            'file': '../../tasks/main.yml',
            'apply': { 'ignore_errors': True },
        },
        'block': []
    }

    ti = TaskInclude.load(ds, parent=Base(), variable_manager=None, loader=None)
    pb = ti.build_parent_block()
    assert pb.get_name() == 'block'

# Generated at 2022-06-11 11:16:11.334737
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    import ansible.plugins.loader
    import ansible.plugins.task

    class FakeVariableManager():
        def __init__(self):
            self.extra_vars = {}

    loader = ansible.plugins.loader.PluginLoader()
    variable_manager = FakeVariableManager()
    action_loader = ansible.plugins.loader.ActionModuleLoader(loader, variable_manager)

    action_plugin = action_loader.get('include_role')
    block = ansible.playbook.Block()
    block.role = "fake_role"

    task = TaskInclude(block=block, role=block.role)
    task._loader = loader
    task._variable_manager = variable_manager
    task._action = action_plugin
    task._parent = block

# Generated at 2022-06-11 11:16:16.388004
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    t = TaskInclude()
    ds = dict(action='include_tasks', file='test.yml', apply={'test': '123'})
    task = t.check_options(t.load_data(ds), ds)
    assert {'action': 'include_tasks', 'file': 'test.yml', 'apply': {'test': '123'}} == task.args

# Generated at 2022-06-11 11:16:25.673329
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import vars_loader
    import ansible.constants as C
    import os
    import json

    C.HOST_KEY_CHECKING = False
    current_dir = os.path.dirname(__file__)


# Generated at 2022-06-11 11:16:33.348894
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class MockParent(object):
        def get_vars(self):
            return dict(a=12, b='foo')

    ti = TaskInclude()
    ti._parent = MockParent()
    ti.vars = dict(c=12, d='bar')
    ti.args = dict(a=13, b='baz')
    assert ti.get_vars() == dict(a=13, b='baz', c=12, d='bar')

    ti.action = "include_role"
    assert ti.get_vars() == dict(include_role_a=13, include_role_b='baz', c=12, d='bar')

# Generated at 2022-06-11 11:16:42.922895
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import sys
    import json
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Create a stub of the loader to avoid having to mock it all
    class LoaderStub:
        def __init__(self):
            pass

        def get_basedir(self, *args, **kwargs):
            return 'dummy-basedir'

        def load_from_file(self, *args, **kwargs):
            return AnsibleBaseYAMLObject('dummy')

        def path_dwim(self, *args, **kwargs):
            return 'dummy-dwim'

    # Simulate what happens in the baseclass Task
    class TaskStub(Task):
        def __init__(self, **kwargs):
            self._play = Sent

# Generated at 2022-06-11 11:17:00.427966
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    class MockBlock:
        def __init__(self, loop_data='test'):
            self.loop = loop_data

        def get_vars(self):
            return {'item': self.loop}

        def get_loop_items(self):
            return {'item': [self.loop]}


    class MockPlay:
        def __init__(self, loop_data='test'):
            self.playbooks = []
            self.block = MockBlock(loop_data)
            self.variable_manager = VariableManager()
            self.loader = DataLoader()

# Generated at 2022-06-11 11:17:09.293714
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    # create a play and find its vars
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        roles=[]
    )

    task_ds = dict(
        name="Test Task",
        action='debug',
        args=dict(
            msg='hello'
        )
    )

    play = Play.load(play_ds)
    p_vars = play.get_vars()

    # role is needed to construct the TaskInclude, will be replaced in it anyway

# Generated at 2022-06-11 11:17:21.372342
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import copy
    import sys
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    class Options(object):
        verbosity = 0

    # Setup play, task, and TaskInclude instances with args to test mimic an include task
    play_ds = dict(
        name="my_play",
        hosts="all",
        gather_facts="no",
        tasks=[]
    )
    play = Play.load(play_ds, variable_manager=VariableManager(), loader=DataLoader())
    task_ds = dict(
        include="my_task",
        action="include",
        args=dict()
    )
    task = Task

# Generated at 2022-06-11 11:17:23.302837
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    assert type(task.get_vars) == dict


# Generated at 2022-06-11 11:17:32.561629
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    """
    Test with apply and without apply
    """
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play as Play_
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from collections import namedtuple

    Block = namedtuple('Block', ['parent'])
    Role = namedtuple('Role', ['_role_name'])

    # With apply
    host = 'localhost'

# Generated at 2022-06-11 11:17:42.775464
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # invalid action
    with pytest.raises(AnsibleError) as e:
        task.check_options(task, {})

    task.action = 'include'
    task.args = {'file': 'file'}
    task.check_options(task, {})

    task.action = 'include_role'
    task.args = {'file': 'file'}
    task.check_options(task, {})

    task.action = 'include'
    task.args = {'file': 'file', 'apply': 'value'}
    with pytest.raises(AnsibleError) as e:
        task.check_options(task, {})

    task.action = 'import_role'

# Generated at 2022-06-11 11:17:53.633427
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import PlayBook
    from ansible.playbook.play import Play

    display.verbosity = 3

    loader = DataLoader()
    play = Play.load(
        dict(
            name="foobar",
            hosts=["all"],
            roles=['rolename'],
        ),
        variable_manager=VariableManager(),
        loader=loader,
    )
    assert play.name == "foobar"
    assert play.hosts == ["all"]

    pb = PlayBook(
        playbook=None,
        loader=loader,
    )

    pb.set_variable_manager(VariableManager())
    pb.set_loader(loader)
    pb.set

# Generated at 2022-06-11 11:18:00.250387
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Note: method preprocess_data is used in method load for TaskInclude
    #       and HandlerTaskInclude so we only test it on TaskInclude
    ti = TaskInclude()
    ti.BASE = frozenset(('file', '_raw_params'))
    ti.OTHER_ARGS = frozenset(('apply',))
    ti.VALID_ARGS = ti.BASE.union(ti.OTHER_ARGS)

    ds = dict()
    # Change nothing
    assert ti.preprocess_data(ds) == dict()

    ds = dict(action='include_tasks')
    assert ti.preprocess_data(ds) == dict(action='include_tasks')
    ds = dict(action='include_tasks', file='test')
    assert ti.preprocess_data(ds)

# Generated at 2022-06-11 11:18:10.677574
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play


# Generated at 2022-06-11 11:18:19.700707
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create a TaskInclude instance
    ti = TaskInclude()

    # Create an instance of FieldAttribute and assign it to the 'apply' argument
    # of the TaskInclude instance
    apply_attrs = FieldAttribute(name='apply', include_role=None)
    ti.args['apply'] = apply_attrs

    # Assign a Block instance to the Block attribute of the FieldAttribute
    # instance
    apply_attrs['block'] = Block()

    # Call build_parent_block method and assign the result to the variable
    # p_block.
    p_block = ti.build_parent_block()

    # Assert that p_block is not the same object as the 'ti' variable.
    assert p_block is not ti
    # Assert that p_block is of class Block.

# Generated at 2022-06-11 11:18:47.453423
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Task
    task_kwargs = {'action': 'include', 'args': {'apply': {}}}
    my_task = TaskInclude.load(data=task_kwargs, variable_manager={}, loader={})
    expected_attrs = {'apply': {}}
    assert my_task.args == expected_attrs

    task_kwargs = {'action': 'include', 'args': {'apply': "blah"}}
    try:
        TaskInclude.load(data=task_kwargs, variable_manager={}, loader={})
    except AnsibleParserError as epe:
        assert str(epe) == 'Expected a dict for apply but got <class \'str\'> instead'


# Generated at 2022-06-11 11:18:56.434810
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook
    from ansible.vars.manager import VariableManager

    # load_data and _load_vars is tested in test_TaskInclude_load_data and test_TaskInclude_load_vars
    # We test the invalid options in test_TaskInclude_check_options

    task_ds = dict(
        include_tasks="test_include_tasks.yml",
        apply=None,
        no_log=False,
        register="test_include_tasks_register",
    )

# Generated at 2022-06-11 11:19:05.356216
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    TaskInclude.VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS.union(
        ('foo', 'bar',)
    )

    ti_class = TaskInclude
    ti = TaskInclude()
    ti._parent = object()
    ti.vars = dict(a=1, b=2)
    ti.args = dict(c=3, d=4)
    ti.action = 'include'
    ti._parent.get_vars = lambda: dict(e=5, f=6)

    # test method of class
    assert ti_class.get_vars() == dict(c=3, d=4)

    # test method of instance

# Generated at 2022-06-11 11:19:14.393785
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    class FakeTask(TaskInclude):
        _validate_loop_delay = Sentinel
        _validate_loop_until = Sentinel
        _validate_loop_failed_when = Sentinel
        _validate_loop_with_items = Sentinel

        def __init__(self, block=None, role=None, task_include=None):
            super(FakeTask, self).__init__(block=block, role=role, task_include=task_include)
            self.called = []

        def validate_options(self, task, data):
            return super(FakeTask, self).check_options(task, data)

        def validate_args(self):
            pass

        def _validate_loop_delay(self, value):
            self.called.append(type(self)._validate_loop_delay)

# Generated at 2022-06-11 11:19:24.002748
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test data
    task_data = [{'apply': {'block': [{'ignore_errors': 'yes'}, {'debug': 'msg={{ item }}'}]}, 'when': '{{ inventory_hostname }} in groups.db_servers',
                  'include': ['/opt/ansible/files/mysql/tasks/db_backup.yml'], 'loop': '{{ db_servers }}'}]
    task_data[0]['apply']['block'][1]['with_items'] = '{{ databases }}'
    task_data[0]['apply']['block'][1]['loop_control'] = {'loop_var': 'item'}

    # Init the objects
    blk1 = Block(sentinel.play, task_data)
    role = sentinel.role


# Generated at 2022-06-11 11:19:32.745609
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    ti = TaskInclude(block=Block())

    ti.args = {'apply':{'test':'test'}, '_raw_params': '/tmp/1', 'file': '1'}

    # Mock object of class Play

# Generated at 2022-06-11 11:19:41.437737
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.vars.manager

    my_vars = {'foo': 1, 'bar': 2}
    my_args = {'bam': 10, 'bom': 20}

    # create task and set some attributes
    my_task = TaskInclude()
    my_task.vars.update(my_vars)
    my_task.args.update(my_args)

    # An action that is not in C._ACTION_INCLUDE will get get_vars from super
    my_task.action = 'setup'
    assert my_task.get_vars() == my_vars

    # change the action to include and test the modified behavior of get_vars
    my_task.action = 'include'

    # when the parent of my_task is not valid, the get_vars should be the

# Generated at 2022-06-11 11:19:50.499828
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.parsing.yaml.objects
    task = TaskInclude()
    assert isinstance(task.check_options(task.load_data({'include': 'some.yml'}), {}), TaskInclude)
    assert isinstance(task.check_options(task.load_data({'action': 'include', 'include': 'some.yml'}), {}), TaskInclude)
    assert isinstance(task.check_options(task.load_data({'include': 'some.yml', 'tags': ['a']}), {}), TaskInclude)
    assert isinstance(task.check_options(task.load_data({'include': 'some.yml', 'tags': 'a'}), {}), TaskInclude)

# Generated at 2022-06-11 11:19:59.535053
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel
    from ansible.template import Templar
    import ansible.constants as C
    import os
    import yaml

    # setup environment
    class FakeLoader:

        def get_basedir(self):
            return "/path/to/playbook"

    class FakeVarMgr:

        def __init__(self):
            self._vars = {}


# Generated at 2022-06-11 11:20:08.139557
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """Test TaskInclude.get_vars  (include action)
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    # test get_vars for include
    # ------
    play_context = PlayContext()
    play_context.vars['var1'] = 'play_context1'
    play_context.vars['var2'] = 'play_context2'
    play_context.vars['var3'] = 'play_context3'

    play_context.extra_vars['extra_var1'] = 'extra_var1'
    play_context.extra_vars['extra_var2'] = 'extra_var2'

# Generated at 2022-06-11 11:20:36.146372
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    This method checks whether 'check_options' method
    raises AnsibleParserError on invalid options
    """
    from ansible.errors import AnsibleParserError
    from ansible.playbook.attribute import Attribute

    task_include = TaskInclude()
    task_data = {'_lineage': [], 'action': 'include'}
    task = task_include.load_data(task_data)
    task = task_include.check_options(task, task_data)
    assert task == task_include.load_data(task_data)

    # Validates the option 'apply' when action is not 'include'
    task_data = {'_lineage': [], 'action': 'block', 'apply': {}}
    task = task_include.load_data(task_data)

# Generated at 2022-06-11 11:20:44.996639
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test get_vars() with including tasks
    ti = TaskInclude()
    ti.action = 'include'
    ti.inline = dict(tasks=[dict(action='debug', msg='Tasks included')])
    ti.block = [Task.load(dict(action='debug', msg='Inline tasks'), ti)]
    ti.args = dict(a=1, b='two')
    assert ti.get_vars() == dict(a=1, b='two')

    # test get_vars() with other included tasks
    ti = TaskInclude()
    ti.action = 'include-tasks'
    ti.block = [Task.load(dict(action='debug', msg='Included tasks'), ti)]
    ti.args = dict(a=1, b='two')