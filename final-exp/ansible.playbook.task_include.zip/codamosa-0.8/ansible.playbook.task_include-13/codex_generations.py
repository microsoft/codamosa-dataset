

# Generated at 2022-06-11 11:10:44.176210
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_data = dict(
        action='include',
        name='include_me',
        xx='yy',
    )
    task = TaskInclude()
    task.load_data(test_data)

    vars = task.get_vars()
    assert not isinstance(vars, FieldAttribute)
    assert vars == dict(xx='yy')


# Generated at 2022-06-11 11:10:52.583482
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = DataLoader()

    ti = TaskInclude()
    ti._variable_manager = VariableManager()
    ti._loader = loader
    ti.set_loader(loader)

    playbook_file = 'tests/fixtures/playbooks/tasks-include/playbook.yml'

# Generated at 2022-06-11 11:11:03.852866
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)

    display.verbosity = 3
    pc = PlayContext()
    t = TaskInclude(task_include=None, block=None, role=None)

# Generated at 2022-06-11 11:11:13.878026
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    task_include = TaskInclude()
    task_include._parent = None
    task_include.vars = {}
    task_include.args = {'t_a': 'hello', 't_b': 'world', 't_c': 'test_include'}
    task_include.action = 'include'

    ans_task_include = TaskInclude()
    ans_task_include._parent = None
    ans_task_include.vars = {}
    ans_task_include.args = {'t_a': 'hello', 't_b': 'world', 't_c': 'test_include'}
    ans_task_include.action = 'include'

    exist_task_include = TaskInclude()
    exist_task_include._parent = None
    exist_task_include.vars = {}
    exist

# Generated at 2022-06-11 11:11:25.298449
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    assert TaskInclude.preprocess_data({'include': 'test.yml'}) == {'action': 'include', 'file': 'test.yml'}
    assert TaskInclude.preprocess_data({'include_tasks': 'test.yml'}) == {'action': 'include_tasks', 'file': 'test.yml'}
    assert TaskInclude.preprocess_data({'include_role': 'test.yml'}) == {'action': 'include_role', 'file': 'test.yml'}
    assert TaskInclude.preprocess_data({'include_role': 'test.yml', 'vars': {'a': 'b'}}) == {'action': 'include_role', 'file': 'test.yml', 'vars': {'a': 'b'}}


#

# Generated at 2022-06-11 11:11:36.344572
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # pytest is looking for 'test_' prefixed names for auto-detecting tests
    dummy_parent = None
    task = TaskInclude(block=dummy_parent)

    data = {}
    try:
        task.check_options(task.load_data(data), data)
    except Exception as ex:
        assert ex.__class__.__name__ == "AnsibleParserError" and "No file specified for include" in str(ex)
    else:
        assert False, "should have raised"

    data = {"file": "dummy.yml"}
    task.check_options(task.load_data(data), data)

    data = {"file": "dummy.yml", "apply": {"p": "v"}}

# Generated at 2022-06-11 11:11:47.009476
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = dict(action='include_role', file='f1', args=dict(a=2, b=3), other='hello')
    ti.preprocess_data(ds)
    assert ds == dict(action='include_role', args=dict(a=2, b=3, _raw_params='f1'), other='hello')
    ds = dict(action='include_role', file='f1', args=dict(a=2, b=3), other='hello', post_var='var')
    ti.preprocess_data(ds)
    assert ds == dict(action='include_role', args=dict(a=2, b=3, _raw_params='f1'), post_var='var')

# Generated at 2022-06-11 11:11:52.508082
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    context.vars_validate_convert_bare = False
    context.vars_convert_bare = False
    vm = VariableManager(loader=None, inventory=None)

    def data_fixture(action='include', args=None, **kwargs):
        if args is None:
            args = {}
        data = dict(action=action, args=args)
        data.update(kwargs)
        return data

    data = data_fixture(file='tasks/main.yml')

# Generated at 2022-06-11 11:12:02.721985
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    def _create_task(action, args, vars={}, implicit_vars={}, parent_task=None):
        pb_data = {'action': action, 'args': args, 'register': '', 'vars': vars, 'loop': ''}
        task = TaskInclude.load(pb_data, task_include=parent_task)
        task._variable_manager = variable_manager
        for key, value in implicit_vars.items():
            setattr(task, key, value)
        return task

    play_context = PlayContext()
    play_context.remote_addr = 'testhost'
    play_context.hostvars

# Generated at 2022-06-11 11:12:13.976449
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.module_utils.six import string_types
    from ansible.plugins.loader import action_loader

    task_include = TaskInclude()

    # Check for action in C._ACTION_INCLUDE_TASKS
    ds = {'tasks': 'tasks/main.yml', 'action': 'include'}
    result = task_include.preprocess_data(ds)
    assert result == ds

    # Check for action in C._ACTION_INCLUDE_ROLE_TASKS
    ds = {'role': 'role/common', 'action': 'include_role'}
    result = task_include.preprocess_data(ds)
    assert result == ds

    # Check for action in C._ACTION_IMPORT_TASKS

# Generated at 2022-06-11 11:12:26.962752
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    task_include module - get_vars method
    '''

    from ansible.playbook.play import Play

    from ansible.utils.dump import dump
    from ansible.utils.state import collect_role_vars

    pb = Play().load({
        'name': 'testgetvars',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'include': 'included_file'},
            {'include': 'included_file', 'apply': {'tags': 't1'}},
            {'include': 'included_file', 'apply': {'ignore_errors': True}}
        ]
    },variable_manager=dict(), loader=dict())

    play_vars = pb.get_vars()
   

# Generated at 2022-06-11 11:12:38.057657
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    class TmpBlock1(object):
        def __init__(self):
            self.static_vars = {}
            self.vars_prompt = {}
            self.vars = {}
            self.vars_files = []
            self.post_validate_vars = {}
            self.role = None
            self.role_params = {}
            self.default_vars = {}
            self.prompt = {}
            self.context = PlayContext()
            self.post_validate_vars = {}
            self._play = None

        def get_vars(self):
            return {}

        def all_vars(self):
            return {}


# Generated at 2022-06-11 11:12:47.479474
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.role import Role

    class FakeBlock:
        def __init__(self):
            self._play = 'play'
            self._loader = 'loader'
            self._variable_manager = 'var_mgr'
            self._role = 'role'

    class FakeTaskInclude:
        def __init__(self):
            self._variable_manager = 'var_mgr'
            self._loader = 'loader'
            self._role = 'role'
            self._parent = FakeBlock()

    class FakeTask:
        def __init__(self):
            self._parent = FakeBlock()

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Inherited Block
    # Args of Task
    # Dict apply
    ti = FakeTaskIn

# Generated at 2022-06-11 11:12:57.938976
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Create a TaskInclude object with action 'include'
    task_include = TaskInclude(block=None, role=None, task_include=None)
    task_include.action = 'include'
    # Add vars to TaskInclude object
    task_include.vars = dict(a=1, b=2)
    # Add args to TaskInclude object
    task_include.args = dict(c=3, d=4)
    # Create parent Block object for TaskInclude object
    parent_block = Block()
    parent_block.vars = dict(e=5, f=6)
    task_include.block = parent_block
    # Get _vars for TaskInclude object
    all_vars = task_include.get_vars()
    # Check presence of vars in _vars

# Generated at 2022-06-11 11:13:08.819340
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-11 11:13:15.154987
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # pylint: disable=too-many-locals,too-many-statements,too-many-branches,too-many-nested-blocks
    # pylint: disable=protected-access
    import os
    import copy
    import yaml

    CWD = os.getcwd()
    ROLE_PATH = os.path.join(CWD, 'test_role', 'tasks', 'main.yaml')
    BLOCK_PATH = os.path.join(CWD, 'test_block.yaml')
    BLOCK_PATH_TMPL = os.path.join(CWD, 'test_block_tmpl.yaml')

    for task in ('import_role', 'include_role', 'import_playbook', 'include'):
        file_path = None

# Generated at 2022-06-11 11:13:26.894507
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    inventory.set_play_context(play_context)

    task = TaskInclude.load(dict(action='include', file='tasks.yml'), variable_manager=variable_manager, loader=loader)

    assert task.action == 'include'
    assert task._attributes.get('file') is None
    assert task.args == dict(_raw_params='tasks.yml')



# Generated at 2022-06-11 11:13:36.462818
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    play = {
        'name': 'test',
        'hosts': ['local'],
        'gather_facts': 'no',
        'tasks': [
            {
                'name': 'include test',
                'include': 'somefile.yml',
                'apply': {
                   'name': 'test',
                   'block': [],
                },
            },
        ],
    }

    role = {
        'name': 'test',
        'tasks': [],
        'defaults': [],
    }


# Generated at 2022-06-11 11:13:37.006562
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    pass

# Generated at 2022-06-11 11:13:37.783248
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    pass  # TODO

# Generated at 2022-06-11 11:13:52.999545
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup.include as include_lookup
    from ansible.plugins.loader import validate_options

    from ansible.playbook.block import Block

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # We don't import them here to keep them hidden in regular use
    from ansible.vars.manager import VariableManager
    from ansible.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # These fail without the 'validate_options' wrapper
    # A task

# Generated at 2022-06-11 11:13:54.568941
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test of method get_vars of class TaskInclude
    '''
    # TODO

    return

# Generated at 2022-06-11 11:14:03.943110
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    role = Role.load({
        'name': 'foo',
        'tasks': [
            { 'include_role': {
                'name': 'bar',
                'tasks_from': 'main.yml'
            }},
            { 'include': {
                'file': 'main.yml',
                'apply': {
                    'when': 'os_is_linux',
                    'tags': 'kernel'
                }
            }}
        ]
    })


# Generated at 2022-06-11 11:14:05.649701
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    instance = TaskInclude()
    assert instance.build_parent_block() == instance

# Generated at 2022-06-11 11:14:15.617622
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    t = TaskInclude()
    t.args = {'one':1, 'two':2}
    t.action = 'include'
    t._parent = Object()
    t._parent.get_vars = lambda: {'p_one': 10, 'p_two': 20}
    t.vars = {'v_one': 100, 'v_two': 200}
    assert t.get_vars() == {'p_one': 10, 'p_two': 20, 'v_one': 100, 'v_two': 200, 'one': 1, 'two': 2}

    t = TaskInclude()
    t.args = {'one':1, 'two':2}
    t.action = 'not_include'
    t._parent = Object()

# Generated at 2022-06-11 11:14:24.718831
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-11 11:14:34.548104
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    assert TaskInclude.preprocess_data({'action': 'include_tasks', 'include': 'filename'}) == {}
    assert TaskInclude.preprocess_data({'action': 'import_tasks', 'include': 'filename'}) == {}
    assert TaskInclude.preprocess_data({'action': 'include_role', 'include': 'filename'}) == {}
    assert TaskInclude.preprocess_data({'action': 'import_role', 'include': 'filename'}) == {}
    assert TaskInclude.preprocess_data({'action': 'include_playbook', 'include': 'filename'}) == {'action': 'include_playbook', 'include': 'filename'}
    assert TaskInclude.preprocess_data({'action': 'include_tasks', 'include': 'value'}) == {}
    assert TaskInclude

# Generated at 2022-06-11 11:14:45.047204
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    For scenario 1, if apply_attrs are not present in task, then the
    task is returned as parent block and the args should not be popped.
    For scenario 2, if apply_attrs are present in task, then a block is
    created and returned as parent block and the apply_attrs should be
    popped.
    '''
    # Scenario 1
    attrs = {'apply': {}}
    task_include = TaskInclude(None)
    task_include.args = attrs
    p_block = task_include.build_parent_block()
    assert (p_block == task_include) and (attrs.get('apply') == {})

    # Scenario 2
    attrs = {'apply': {'name': 'bla'}}
    task_include = TaskInclude(None)
   

# Generated at 2022-06-11 11:14:54.762211
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    play_source = dict(
        name = 'test play',
        hosts = 'all',
        gather_facts = 'no',
        roles = [],
        tasks = [
            dict(include = 'tasks.yml', vars = dict(a = 'A')),
        ],
    )

# Generated at 2022-06-11 11:15:00.478188
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible import playbook
    from ansible.playbook.play import Play

    task = TaskInclude()
    data = { "action": "include", "name": "test", "file": "test.yaml" }
    play = Play.load(data, variable_manager=playbook.VariableManager(), loader=playbook.Loader())
    res = TaskInclude.check_options(task, data)
    assert res is not None

# Generated at 2022-06-11 11:15:17.186746
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    pm = FakePlaybookModule()
    t1 = TaskInclude.load(dict(
        name='include role',
        include='../some/other/role',
    ), variable_manager=pm.variable_manager, loader=pm.loader)

    p_tc1 = Block(play=Play().load(dict(
        name='test',
        hosts='all',
        tasks=[
            dict(
                include='name of role to include',
            ),
        ],
    ), loader=pm.loader, variable_manager=pm.variable_manager))


# Generated at 2022-06-11 11:15:17.808205
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
  pass

# Generated at 2022-06-11 11:15:27.985842
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    task_attrs = {
        'action': 'include',
        'apply': {
            'block': [],
            'block_type': 'rescue',
            'ignore_errors': True
        },
        '_raw_params': 'my.yml',
        '__ansible_module__': 'include',
        '__ansible_arguments__': 'my.yml',
        '__ansible_action__': 'include',
        '_ansible_verbose_always': False,
        '_ansible_version': (2, 8, 0),
    }

    task = TaskInclude.load(task_attrs)

# Generated at 2022-06-11 11:15:37.753225
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.vars.manager import _get_fact_cache_dir
    from unit.test_loader import DictDataLoader
    from unit.compat import mock

    loader = DictDataLoader({
        '/etc/ansible/roles/role1/tasks/main.yml': """
        - debug: msg='{{ item }}'
          with_items: "{{ listvar }}"
        """,
    }).loaders

    test_var_manager = VariableManager()
    test_var_manager.extra_vars = {'listvar': ['a', 'b', 'c']}
    test_var_manager.set_fact_cache(_get_fact_cache_dir(play=False))

    #

# Generated at 2022-06-11 11:15:46.183936
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import inclusion_loader, vars_loader

    task_include_data = {
        'action': 'include',
        'args': {
            'apply': {
                'serial': 1,
                'register': 'var_register'
            }
        },
        '_raw_params': []
    }
    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    module_loader = DataLoader()
    module_

# Generated at 2022-06-11 11:15:53.978862
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():

    import pytest
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.errors import AnsibleParserError

    # Test action 'include'
    block = Block()
    data = {'file': 'main.yml', 'apply': {}}
    task_include = TaskInclude(block, task_include=None)
    task = task_include.load(data, block)
    assert task.action == 'include'
    assert task.args == {'_raw_params': 'main.yml', 'apply': {}}
    assert task._parent == block
    assert task._role == None
    assert task.statically_loaded == False

    data = {'action': 'include', 'file': 'main.yml', 'apply': {}}
    task

# Generated at 2022-06-11 11:16:01.933308
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook.task_include

    # Case where arguments are provided
    task = ansible.playbook.task_include.TaskInclude(task_include = "../tests/test_data/test_include_task.yml")
    try:
        task.check_options(task.load_data(task.load_file()), task.load_file())
        assert(False)
    except AnsibleParserError:
        assert(True)

    task = ansible.playbook.task_include.TaskInclude(task_include = "../tests/test_data/test_include_task.yml")
    task.check_options(task.load_data(task.load_file()), task.load_file())

    # Case where no arguments are provided
    task = ansible.playbook.task_include.Task

# Generated at 2022-06-11 11:16:10.854858
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Testcase for get_vars method of class TaskInclude.
    """
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    test = ansible.playbook.Play()
    test2 = ansible.playbook.Task()
    test2._parent = test
    test3 = ansible.playbook.Task()
    test3._parent = test2
    test4 = ansible.playbook.Block()
    test4._parent = test3
    test5 = ansible.playbook.Task()
    test5._parent = test4



# Generated at 2022-06-11 11:16:20.041506
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Initialize TaskInclude object
    args = dict()
    ti = TaskInclude()

    # Ensure that method get_vars is the same as the method inherited from Task class
    assert ti.get_vars() == Task().get_vars()

    # Change action of TaskInclude object
    ti.action = 'include'

    # Ensure that method get_vars returns a dict
    assert isinstance(ti.get_vars(), dict)

    # Change _parent attribute and ensure that method get_vars returns a dict
    ti._parent = True
    assert isinstance(ti.get_vars(), dict)

    # Change vars attribute and ensure that method get_vars returns a dict
    ti.vars = 'abc'
    assert isinstance(ti.get_vars(), dict)

    # Change args attribute and ensure that

# Generated at 2022-06-11 11:16:29.342454
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.play
    import ansible.playbook.task

    t = TaskInclude()
    t.args = {'foo': 'bar'}
    t.action = 'include_role'

    assert t.get_vars() == {'foo': 'bar'}

    t = TaskInclude()
    t.args = {'files': '/etc/hosts'}
    t.action = 'include_role'

    assert t.get_vars() == {'files': '/etc/hosts'}

    t = TaskInclude()
    t.args = {'tags': ['baz'], 'when': 'foo'}
    t.action = 'include_role'

    assert t.get_vars() == {}

    t = TaskInclude()

# Generated at 2022-06-11 11:16:52.973175
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    attr_dict = {
        'action' : 'include',
        '_raw_params' : 'static_include_1.yml',
        'arg1' : 'val1',
        'arg2' : 'val2',
    }
    task_include_obj = TaskInclude()
    task_include_obj.vars = { 'var1' : 'var1'}
    attr_obj = FieldAttribute(task_include_obj, attr_dict, FieldAttribute.SET)
    assert task_include_obj.get_vars() == { 'arg1': 'val1', 'arg2': 'val2', 'var1': 'var1'}

# Generated at 2022-06-11 11:17:04.285579
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    task = TaskInclude.load({'include': 'example.yml'}, Block())
    assert len(task.args) == 1
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == 'example.yml'

    task = TaskInclude.load({'include': {'action': 'include', 'file': 'example.yml'}}, Block())
    assert len(task.args) == 1
    assert '_raw_params' in task.args
    assert task.args['_raw_params'] == 'example.yml'


# Generated at 2022-06-11 11:17:11.165322
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task_include = TaskInclude()
    assert set(task_include.args.keys()) == frozenset(['file'])

    # Test file
    task = TaskInclude.load({'include': 'vars.yml'})
    assert set(task.args.keys()) == frozenset(['file'])
    task = TaskInclude.load({'include': 'vars.yml', 'tags': ['tag1']})
    assert set(task.args.keys()) == frozenset(['file', 'tags'])

    # Test include_role
    task = TaskInclude.load({'include_role': {'name': 'my_role'}})
    assert set(task.args.keys()) == frozens

# Generated at 2022-06-11 11:17:19.481336
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    opts = ['not_valid', 'file=foo', 'ignore_errors']
    data = dict(
        action='include_tasks',
        args=dict(enumerate(opts)),
    )

    ti = TaskInclude()
    task = ti.check_options(
        ti.load_data(data), data
    )

    assert task.args['file'] == 'foo'
    assert task.args['ignore_errors'] is True
    assert task.args['not_valid'] is None

# Generated at 2022-06-11 11:17:29.988837
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = dict(
        file='/path/to/playbook.yml',
        static='y',
        apply=dict(
            block=dict(
                rescue=dict(
                    other='bar'
                ),
                when='foo',
            )
        ),
        debug='msg="I have a reason"'
    )

    task = TaskInclude.load(
        data,
        loader=None,
        variable_manager=None
    )
    task = task.check_options(task, data)

    # Assert Base
    assert 'file' in task.args
    assert 'file' not in data

    # Assert Other Args
    assert 'apply' in task.args
    assert 'apply' not in data

    # Assert bad args
    assert 'static' not in task.args
    assert 'debug'

# Generated at 2022-06-11 11:17:38.572849
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    """
    Run tests on method 'check_options' of class TaskInclude
    """
    import pytest

    class ArgsMock(object):
        """ Class to mock the args attribute of TaskInclude """

        def __init__(self, **kwargs):
            """ Set the attribute args to the dict kwargs """
            self.args = kwargs

    # Test invalid options
    # --------------------
    data = dict()  # data argument is not used
    with pytest.raises(AnsibleParserError) as execinfo:
        TaskInclude.check_options(ArgsMock(invalid_option=True), data)
    assert 'Invalid options for include: invalid_option' in str(execinfo)

# Generated at 2022-06-11 11:17:50.026079
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def _compare_taskincl(data, expected):
        task_include=TaskInclude()
        task_include.vars = {}
        task_include.args = {}
        task_include.action = data['action']
        task_include.block = None
        task_include.register = None
        task_include.role = None
        task_include.task_include = None
        task_include.tags = []

        # Set an empty vars dict for templar
        variable_manager = VariableManager()
        play_context = PlayContext()

# Generated at 2022-06-11 11:17:58.250362
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    assert t.get_vars() == {}

    t.vars = {'a': 1}
    assert t.get_vars() == {'a': 1}

    t._parent = Task()
    t._parent.vars = {'b': 2}
    assert t.get_vars() == {'a': 1, 'b': 2}

    t.args = {'c': 3}
    assert t.get_vars() == {'a': 1, 'b': 2, 'c': 3}

    t.action = 'include'
    assert t.get_vars() == {'a': 1, 'b': 2, 'c': 3, 'tags': None, 'when': None}
    t.args = {'tags': [], 'when': 'True'}


# Generated at 2022-06-11 11:18:03.467666
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    include_file = 'foobar.yml'
    extra_vars  = dict(a=1, b="foo")
    include_task = TaskInclude()
    include_task.args['file'] = include_file
    include_task.vars = extra_vars
    vars = include_task.get_vars()

    assert vars == dict(file=include_file, a=1, b="foo")



# Generated at 2022-06-11 11:18:13.973612
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    According to the documentation, arguments like 'action', 'args', 'no_log', etc will be used by the
    'include_tasks' task and can't be used directly on 'include'. They are documented as arguments for
    the 'include' task, but this is for backwards compatibility only.
    '''
    from ansible.playbook.conditional import Conditional

    from ansible.playbook.play_context import PlayContext

    from ansible.parsing.dataloader import DataLoader

    # we'll also need a validator
    from ansible.playbook.block import validate_block

    loader = DataLoader()

    # setup a fake task, just to setup the play context
    task = Task()
    task.set_loader(loader)

    play_context = PlayContext()
    task._play_context = play

# Generated at 2022-06-11 11:19:01.036103
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import sys
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 3

    class Options:
        def __init__(self, verbosity=None):
            super(Options, self).__init__()
            self.connection = 'local'
            self.module_path = ''

# Generated at 2022-06-11 11:19:09.495342
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # 1. test for action: include
    # 1.1 test for vars from include, vars from task and vars from args
    # expected result: return all vars except tags and when

# Generated at 2022-06-11 11:19:19.432177
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # define a simple playbook
    playbook = '''---
- hosts: 127.0.0.1
  gather_facts: false

  tasks:
    - include: "{{ play_dir }}/playbook.yml"
      vars:
        foo: 1
        bar: 2
'''
    import os
    import tempfile
    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create the playbook inside the temporary directory
    playbook_filename = os.path.join(tmpdir, 'playbook.yml')

# Generated at 2022-06-11 11:19:28.392020
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    class FakeVariableManager:
        pass

    class FakeLoader:
        pass

    class FakePlay:
        name = "fake"
        variable_manager = FakeVariableManager()
        loader = FakeLoader()
        context = PlayContext()

    class FakeTask:
        _role = None
        _block = None
        _parent = None
        _variable_manager = FakeVariableManager()
        _loader = FakeLoader()
        _play = FakePlay()

        def __init__(self, data, parent=None, role=None, block=None, task_include=None):
            self._parent = parent
            self._play = FakePlay()
            self._role = role
           

# Generated at 2022-06-11 11:19:37.161896
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.mod_args import ModuleArgsParser

    block_vars_list = dict(
        block_var1='block_var1_val',
        block_var2='block_var2_val',
    )
    block_args_list = dict(
        block_arg1='block_arg1_val',
        block_arg2='block_arg2_val',
    )
    include_args_list = dict(
        include_arg1='include_arg1_val',
        include_arg2='include_arg2_val',
    )

# Generated at 2022-06-11 11:19:45.776845
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class FakePlay(object):
        def __init__(self):
            self.vars = dict()

    class FakeBlock(object):
        def __init__(self):
            self._parent = FakePlay()

    class FakeTaskInclude(TaskInclude):
        def __init__(self, action):
            self._parent = FakeBlock()
            self.args = dict()
            self.action = action

    # Test for action include
    ti = FakeTaskInclude('include')
    ti.vars = dict()
    ti.args['a'] = 1
    ti.args['b'] = 2
    ti.args['tags'] = 3
    ti.args['when'] = 4
    assert ti.get_vars() == {'a': 1, 'b': 2}

    # Test for action import_tasks
   

# Generated at 2022-06-11 11:19:55.134805
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import os
    import mock
    import ansible.playbook.block
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # create a mock PlayContext object, as it needs to exist
    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    play_context = PlayContext()

    # create a task, which is the object we want to test
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    fake_play

# Generated at 2022-06-11 11:20:03.787977
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-11 11:20:12.652128
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_loader

    loader = get_loader()
    play = Play().load({
        'name': 'includetest',
        'hosts': 'all',
        'tasks': [{
            'name': 'foo',
            'include': {
                'name': 'bar',
                'apply': {
                    'block': 'baz',
                    'vars': {'qux': 'quux'}
                },
                'vars': {'foo': 'bar'}
            }
        }]
    }, loader=loader)
    fake_role = Role()

    task = play.get_tasks()

# Generated at 2022-06-11 11:20:22.802298
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a context to create a Variable Manager
    play_context = PlayContext()
    play_context._hosts = [ "myhost" ]
    play_context._vars = HostVars(loader=None, inventory=None)
    play_context._unsafe = True
    play_context._options = {}
    play_context._options['no_log'] = False
    play_context._options['verbosity'] = 0

    # Create a variable manager
    variable_manager = VariableManager(loader=None, inventory=None, play_context=play_context)
    variable_manager