

# Generated at 2022-06-11 11:10:49.352496
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    import ansible.constants as C
    import ansible.plugins
    import yaml

    C.DEFAULT_DEBUG = False
    C.DEFAULT_TRANSPORT = 'local'
    C.DEFAULT_REMOTE_USER = 'username'
    C.DEFAULT_REMOTE_PASS = 'password'
    C.DEFAULT_PRIVATE_KEY_FILE = '/path/to/file'
    C.DEFAULT_SUDO_USER = 'username'
    C.DEFAULT_SUDO_PASS = 'password'
    C.ANSIBLE_TRANSPORT = 'local'

# Generated at 2022-06-11 11:10:59.677277
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block
    ti = TaskInclude()

    task = Task(name='This is the task name')
    task.action = 'include'
    task.args = {'array_of_tasks':[{'debug':'msg=value'}]}
    t2 = ti.check_options(task, data=[1,2,3])

    assert t2.action == 'include'
    assert t2.args == {'array_of_tasks':[{'debug':'msg=value'}]}

    task = Task(name='This is the task name')
    task.action = 'include_role'
    task.args = {'array_of_tasks':[{'debug':'msg=value'}]}

# Generated at 2022-06-11 11:11:11.238712
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # test if the warning below is raised
    if C.INVALID_TASK_ATTRIBUTE_FAILED:
        # Failing for this one since it is not a valid option for task_include or handler_task_include
        try:
            TaskInclude.preprocess_data({
                'action': 'include_tasks',
                'debugger': 'no_log',
                'file': 'somefile.yml'
            })
            assert False
        except AnsibleParserError:
            assert True
    else:
        TaskInclude.preprocess_data({
            'action': 'include_tasks',
            'debugger': 'no_log',
            'file': 'somefile.yml'
        })

    # test if no warning is raised

# Generated at 2022-06-11 11:11:20.661166
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Sanity check on TaskInclude.build_parent_block.
    This method is used to create the parent block for the included tasks when 'apply' is specified.
    '''
    tasks = [
        {
            'include': '{{var_for_include}}',
            'apply': {'vars': {'var_for_apply': 'var_for_parent_block'}},
        },
    ]
    task_test = TaskInclude.load(
        tasks[0],
        block=None,
        role=None,
        task_include=None,
        variable_manager=None,
        loader=None
    )
    assert task_test
    assert task_test.args["apply"]["vars"]["var_for_apply"] == "var_for_parent_block"

    block

# Generated at 2022-06-11 11:11:32.425621
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test expected output of TaskInclude.get_vars
    '''
    test_block = Block(task_include=None, role=None, play=None, parent_block=None)
    test_block.vars = {'b_var': 'b_val'}
    test_block._parent = type('TestParentBlock', (), {'get_vars': lambda self: {'p_var': 'p_val'}})()
    test_block._parent.get_vars.__annotations__ = {'return': dict}

    test_ti = TaskInclude(task_include=None, role=None, block=test_block)
    test_ti.action = 'include'
    test_ti.vars = {'t_var': 't_val'}

# Generated at 2022-06-11 11:11:38.852244
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.action = 'include'
    task.vars = {'v': 1}
    task.args = {'a': 2}
    task._parent = type('DummyParent', (), {'get_vars': lambda: {'d': 3}})()

    get_vars = task.get_vars()
    assert get_vars == {'a': 2, 'v': 1, 'd': 3}, get_vars

# Generated at 2022-06-11 11:11:41.213535
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    assert task.get_vars() == {}, 'get_vars() returns an empty dict'

# Generated at 2022-06-11 11:11:52.244198
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ds = {'action': 'include', 'name': 'task name', 'tags': ['tag1'], 'invalid_attr': 'foo', 'apply': {}}
    ti.preprocess_data(ds)
    # Note that there is no 'invalid_attr' in the resulting dict
    assert set(ds.keys()) == set(['action', 'name', 'tags', 'apply'])

    ds = {'action': 'include_role', 'name': 'task name', 'tags': ['tag1'], 'invalid_attr': 'foo', 'apply': {}}
    ti.preprocess_data(ds)
    # Note that 'invalid_attr' is still in the dict as the action is not in C._ACTION_INCLUDE

# Generated at 2022-06-11 11:12:02.373157
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    assert ti.preprocess_data({}) == {}

    assert ti.preprocess_data({'action': 'include_tasks'}) == {}
    # This should not raise an exception as condition is False
    ti.preprocess_data({'action': 'include_tasks', 'hello': 'world'})

    ti.preprocess_data({'action': 'import_tasks'}) == {}
    # This should not raise an exception as condition is False
    ti.preprocess_data({'action': 'import_tasks', 'hello': 'world'})

    ti.preprocess_data({'action': 'include_role'}) == {}
    # This should not raise an exception as condition is False
    ti.preprocess_data({'action': 'include_role', 'hello': 'world'})

    ti

# Generated at 2022-06-11 11:12:13.664280
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude

    # create a data structure with 'include' keyword
    data = dict(
        action='include_tasks',
        file='/abs/path',
        include='/abs/path',
        tags=[],
        when=[],
        apply={},
    )
    # there should be no 'include' after TaskInclude.preprocess_data
    assert 'include' not in TaskInclude.preprocess_data(data)

    # create a data structure with 'include' keyword - action is import_role
    data = dict(
        action='import_role',
        include='/abs/path',
        tags=[],
        when=[],
        apply={},
    )
    # there should be 'include'

# Generated at 2022-06-11 11:12:28.570555
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    me = TaskInclude(block=None, role=None, task_include=None)
    _config = {'color': 'green'}
    _role   = Sentinel()
    me._parent = Sentinel()

    # -- test apply
    me._parent._play = Sentinel()
    me._variable_manager = Sentinel()
    me._loader = Sentinel()

    apply_attrs = {'local_action': 'test',
                   'vars': {'color': 'red'},
                   'block': [],
                  }
    me.args = {'apply': apply_attrs}
    new_block = {'block': Block(play=Sentinel(), task_include=me, role=_role,
                                variable_manager=Sentinel(), loader=Sentinel())}
    apply_attrs.update(new_block)

    res

# Generated at 2022-06-11 11:12:39.900560
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.action = 'include'

    # -------------------------------------------------------------------------
    # Action not in C._ACTION_INCLUDE,
    #   should produce result from parent Task() class
    # -------------------------------------------------------------------------
    ti.action = 'not_include'
    ti.vars = {'a': 'a'}
    ti.args = {'b': 'b'}
    parent_vars = {'c': 'c'}
    def get_parent_vars():
        return parent_vars
    ti._parent.get_vars = get_parent_vars
    all_vars = ti.get_vars()
    assert all_vars == {'a': 'a', 'c': 'c'}
    assert ti.vars == {'a': 'a'}

# Generated at 2022-06-11 11:12:48.499518
# Unit test for method get_vars of class TaskInclude

# Generated at 2022-06-11 11:12:59.061405
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    data = {'action': 'include'}

    # validates the bad args
    # this should raise
    try:
        task = TaskInclude.load(data)
        assert False
    except AnsibleParserError as e:
        assert 'No file specified' in str(e)

    # validates bad args
    data['file'] = 'not_here.yml'
    data['bad_key'] = 'bad_value'
    try:
        task = TaskInclude.load(data)
        assert False
    except AnsibleParserError as e:
        assert 'Invalid' in str(e)

    # not raise because it is an action that does not apply such validation
    data['action'] = 'meta'
    task = TaskInclude.load(data)

    # validates apply arg

# Generated at 2022-06-11 11:13:02.745759
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.utils.vars import merge_hash
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from six import iteritems

    t = TaskInclude(block=None, role=None, task_include=None)
    t.action = 'include_role'

# Generated at 2022-06-11 11:13:12.167151
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.basedefs import Loader

    class DummyVariableManager(object):
        @staticmethod
        def add_host_vars(host):
            return {}

        @staticmethod
        def get_vars(loader, path, play=None, host=None, task=None, include_hostvars=False, include_delegate_to=False):
            return {}

    class DummyPlayContext(PlayContext):
        def __init__(self):
            self._vars = {}
            self.remote_addr = 'localhost'

        def get_vars(self):
            return {}


# Generated at 2022-06-11 11:13:23.203850
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create an instance of TaskInclude
    filename = 'test_include_playbook.yaml'
    task_include = TaskInclude()
    # Create an empty dictionary
    args = {}
    # Assign the value of apply_attrs to args
    args['apply'] = {}
    # Assign the value of Block to block
    args['block'] = []
    # Assign the value of args to TaskInclude._args
    task_include._args = args
    # Assign the TaskInclude to TaskInclude._parent
    task_include._parent = task_include
    # Assign the filename to TaskInclude._role
    task_include._role = filename
    # Call the method build_parent_block of TaskInclude
    # to create a parent block of an included task
    parent_block = task_include.build_parent

# Generated at 2022-06-11 11:13:33.815783
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext

    ti = TaskInclude()
    ti.args['_raw_params'] = 'anything'

    try:
        ti.check_options(ti, None)
    except AnsibleParserError as e:
        assert False, "AnsibleParserError raised unexpectedly when 'apply' option is not provided"

    ti.args['apply'] = 'anything'

    try:
        ti.check_options(ti, None)
    except AnsibleParserError as e:
        assert 'Invalid options for include: apply' == str(e), \
            "AnsibleParserError raised unexpectedly when 'apply' option is provided"

    ti.action = 'anything not in C._ACTION_INCLUDE_TASKS'

# Generated at 2022-06-11 11:13:43.843969
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task_content = dict(
        action='include',
        args=dict(
            apply = dict(
                block = dict(
                    # add_host is used as a selector so it's important
                    # that the method under test does not add the block
                    # selector definitions to the included tasks
                    add_host=dict(
                        name='myhost',
                        groups='mygroup',
                        address='192.168.20.1'
                    )
                )
            )
        )
    )
    task = TaskInclude.load(
        task_content,
        task_include=None,
        loader=None,
        variable_manager=None
    )
    parent_block = task.build_parent_block()
    assert isinstance(parent_block, Block)
    assert parent_block.block == [task]

# Generated at 2022-06-11 11:13:54.912264
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # PATH
    task_data = {
        'action': 'include',
        'path': '/home/ansible/playbooks',
    }
    task = TaskInclude.load(task_data)
    assert task.args.get('_raw_params') == '/home/ansible/playbooks'

    # STATIC, no 'file'. If there is no 'file' and no '_raw_params', '_raw_params' is set to None
    task_data['static'] = True
    task = TaskInclude.load(task_data)
    assert task.args.get('_raw_params') == None

    # STATIC, with 'file'. '_raw_params' is set to the value of 'file'
    task_data['file'] = '/home/ansible/playbooks/foo.yaml'
    task

# Generated at 2022-06-11 11:14:08.686235
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # test for no file here
    task = Task()
    task.action = 'include_role'
    data = dict(action='include_role')
    try:
        ti.check_options(task, data)
        assert False
    except AnsibleParserError:
        pass

    # test for 'apply' for 'include_role'
    task = Task()
    task.action = 'include_role'
    task.args = dict(file='foo.yml', apply=dict())
    data = dict(action='include_role', file='foo.yml', apply=dict())
    try:
        ti.check_options(task, data)
        assert False
    except AnsibleParserError:
        pass

    # test for invalid options for 'include_role'
    task = Task()


# Generated at 2022-06-11 11:14:18.820828
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = {'name': 'include-play', 'hosts': 'localhost', 'gather_facts': 'no', 'vars': {},
            'tasks': [{'action': 'include', 'args': {'file': 'myfile.yml', '_raw_params': 'myfile.yml'}},
                      {'action': 'include_role', 'args': {'file': 'myfile.yml', '_raw_params': 'myfile.yml'}}]}

    loader = AnsibleLoader(None, variable_manager={}, loader=None)

# Generated at 2022-06-11 11:14:26.212337
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # without args
    class Task(TaskInclude):
        def __init__(self):
            self.action = 'include'
            self.vars = dict(A=1)
            self.args = dict()

    t = Task()
    assert t.get_vars() == dict(A=1)

    # with args
    class Task(TaskInclude):
        def __init__(self):
            self.action = 'include'
            self.vars = dict(A=1)
            self.args = dict(B=2)

    t = Task()
    assert t.get_vars() == dict(A=1, B=2)

# Generated at 2022-06-11 11:14:36.218674
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    tasks_data = [
        {
            'action': 'include',
            'file': 'some/path.yml',
            'apply': {'action': 'something'},
            'tags': ['tag1', 'tag2'],
            'when': True,
        },
        {
            'action': 'import_tasks',
            'file': 'some/path.yml',
        },
        {
            'action': 'include_role',
            'name': 'some_role',
            'ignore_errors': True,
        },
    ]
    display.verbosity = 3


# Generated at 2022-06-11 11:14:46.463655
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block as block

    # File is mandatory for include and import_tasks
    for action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS:
        from ansible.parsing.yaml.objects import AnsibleUnicode
        display.warning("*** START TEST for action: %s ***" % action)
        ti = TaskInclude(block=None, role=None, task_include=None)


# Generated at 2022-06-11 11:14:56.741816
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    assert TaskInclude.check_options({'action': 'include_vars', 'file': 'test'}, {}) == {'action': 'include_vars', 'file': 'test'}
    try:
        TaskInclude.check_options({'action': 'include_role', 'file': 'test', 'bad_option': 1}, {})
        assert False
    except AnsibleParserError:
        pass
    try:
        TaskInclude.check_options({'action': 'include_role', 'file': 'test', 'apply': 1}, {})
        assert False
    except AnsibleParserError:
        pass

# Generated at 2022-06-11 11:15:06.829089
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Given
    data = {'action': 'include', 'name': 'test.yml'}
    include = TaskInclude()

    # When
    res = include.preprocess_data(data)

    # Then
    assert 'action' in res
    assert 'name' not in res
    assert '_raw_params' in res
    assert res['action'] == 'include'
    assert res['_raw_params'] == 'test.yml'

    # Given
    data = {'action': 'import_playbook', 'name': 'test.yml', 'ignore_errors': False}
    include = TaskInclude()

    # When
    res = include.preprocess_data(data)

    # Then
    assert 'action' in res
    assert 'name' not in res

# Generated at 2022-06-11 11:15:16.927685
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import os
    import tempfile
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.sentinel import Sentinel
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import get_all_plugin_loaders

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'],)
    loader.set_basedir(os.path.join(os.getcwd(), "test/units/module_loader/action_plugins"))
    all_plugins = get_all_plugin_loaders()


# Generated at 2022-06-11 11:15:27.047564
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.task_include
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import TaskHandler

    TaskInclude = ansible.playbook.task_include.TaskInclude

    # This test just validates a few cases but doesn't cover all options
    # and their combinations.

    # TaskInclude
    data = {'action': 'include_tasks', 'file': 'foo'}
    task = TaskInclude(block=None, role=None, task_include=None)
    task.check_options(task=task.load_data(data), data=data)
    assert task.args == {'file': 'foo'}
    assert task.static is True


# Generated at 2022-06-11 11:15:35.988323
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    test_task = TaskInclude()
    test_task.args = {'apply': {
        'block': [],
        'name': 'test action'
        }
    }

    p_block = test_task.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.name == 'test action'
    assert p_block.parent == test_task
    assert sorted(p_block.args.keys()) == ['args', 'block']

    test_task.args = {'apply': {
        'name': 'test action'
        }
    }

    p_block = test_task.build_parent_block()
    assert p_block == test_task

# Generated at 2022-06-11 11:15:52.375272
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class TaskIncluBlock(Block):
        pass
    class TaskIncluParent(TaskIncluBlock):
        pass
    class TaskIncluPlay(TaskIncluParent):
        pass

    class TaskIncluRole(TaskIncluParent):
        pass

    class TaskIncluParentBlock(TaskIncluParent):
        pass

    class TaskIncluIncl(TaskInclude):
        pass

    task_include_obj = TaskIncluIncl()
    task_include_obj._parent = TaskIncluParent()
    task_include_obj._parent._parent = TaskIncluPlay()
    task_include_obj.vars = {
        'key_1': 'value_1',
        'key_2': 'value_2'
    }

# Generated at 2022-06-11 11:16:00.065901
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    # test the case of apply, no parent
    data_for_test = {
        'action': 'include_tasks',
        'args': {
            'apply': {
                'loop': '{{ items }}',
                'debugger': 'on',
                'action': 'debug',
                'msg': '{{ item }}',
                'args': {
                    'test': '{{ item }}',
                    'register': 'output'
                }
            }
        }
    }


# Generated at 2022-06-11 11:16:00.945670
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # FIXME: implement
    pass

# Generated at 2022-06-11 11:16:09.740582
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    vars_test_data = dict(
        dummy_value=dict(),
        vars=dict(),
        args=dict(
            foo=True,
            bar=dict(
                baz='qux',
            ),
        ),
        action=Sentinel,
        task_include=None,
    )


# Generated at 2022-06-11 11:16:18.874449
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Scenario 1
    tasks = [{"include_tasks": "../common/tasks1.yml", "args": {"x": "a"}}, {"include_tasks": "../common/tasks2.yml", "args": {"y": "b"}}]
    assert TaskInclude.load(tasks[0], loader=None).get_vars() == {"x": "a"}
    assert TaskInclude.load(tasks[1], loader=None).get_vars() == {"y": "b"}

    # Scenario 2

# Generated at 2022-06-11 11:16:27.540214
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    block = dict(apply={'block': {'b': 2}})
    task = TaskInclude(block=block, loader=loader, variable_manager=variable_manager)
    assert isinstance(task.args.get('apply', {}).get('block'), dict)
    assert 'block' not in task._parent.args
    p_block = task.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block._parent == task
    assert 'block' in p_block._parent.args
    assert isinstance(p_block._parent.args['block'], list)
    assert 'block' not in task.args

# Generated at 2022-06-11 11:16:36.354513
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Prepare a task instance
    class ExampleTaskInclude(TaskInclude):
        @classmethod
        def load(cls, data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
            ti = cls(block=block, role=role, task_include=task_include)

            # Assign some attributes as they would be after loading
            ti.action = 'include'
            ti.args = dict(file='/path/to/file.yml', a=1, b=2, c=3)
            ti._parent = None

            return ti

    # Get the instance
    task = ExampleTaskInclude.load({})

    # Test the method
    assert(task.get_vars() == dict(a=1, b=2, c=3))

# Generated at 2022-06-11 11:16:44.410572
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    import yaml

    yaml_str = """
- include:
    action: foobar
    invalid_action_key: value
    name: Play name
    tasks:
      - debug: msg="foo"
"""
    yaml_data = yaml.load(yaml_str)

    TaskInclude.preprocess_data(yaml_data[0])

    assert yaml_data[0]['invalid_action_key'] is Sentinel, "We should not have found 'invalid_action_key'"
    assert 'invalid_action_key' not in yaml_data[0], "We should not have found 'invalid_action_key'"

# Generated at 2022-06-11 11:16:53.540909
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    display = Display()
    options = dict(
        connection='local',
        module_path=['/to/mymodules'],
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
    )

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # test no change
    ti = TaskInclude()
    task = Task()
    task.action = 'include'

# Generated at 2022-06-11 11:17:04.926520
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Test when value of 'apply' is not a dict
    try:
        ti = TaskInclude()
        ti.check_options(
            Task.load({'include': 'some_value', 'apply': 'some_value'}),
            {'include': 'some_value', 'apply': 'some_value'}
        )
    except AnsibleParserError as e:
        assert 'Expected a dict for apply but got str instead' in str(e)

    # Test when 'apply' is used for the wrong task type

# Generated at 2022-06-11 11:17:28.639917
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible import utils

    # in order to test check_options we'll create a dummy task and include
    # objects with fake data
    display = Display()
    variable_manager = utils.plugins. vars_loader.VariableManager()
    loader = utils.plugins.loader.PluginLoader(None, variable_manager=variable_manager)
    task = Task()
    task_include = TaskInclude(block=None, role=None, task_include=None)

    # 1. test valid keywords and options
    # 1.1 include
    task.action = 'include'
    task.args = dict(file='tasks.yaml', apply=dict(x=1))
    task = task_include.check_options(task, {})

# Generated at 2022-06-11 11:17:35.313074
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This method is used to test the proper functioning of the get_vars method
    of the TaskInclude class.
    '''
    from ansible import playbook

    # Example of include
    ti_include = TaskInclude()
    ti_include.action = 'include'
    ti_include.vars = {'this_is': 'a_test'}
    ti_include.args = {'ignore_errors': True, 'no_log': False}

    # Example of include_role
    ti_include_role = TaskInclude()
    ti_include_role.action = 'include_role'
    ti_include_role.vars = {'this_is': 'a_test'}
    ti_include_role.args = {'ignore_errors': True, 'no_log': False}

    # Example

# Generated at 2022-06-11 11:17:39.351403
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block, role = None, None
    task_include = None
    ti = TaskInclude(block=block, role=role, task_include=task_include)
    assert ti.get_vars() == {}, 'test TaskInclude.get_vars() failed'

# Generated at 2022-06-11 11:17:50.690723
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.become import Become
    from ansible.playbook.play import Play
    from ansible.playbook.become_options import BecomeOptions
    # setup test
    become_loader = BecomeOptions(dict(password='password'))
    play_vars = dict()
    play_vars['var1'] = 'value1'
    play_vars['var2'] = 'value2'
    play_vars['var3'] = 'value3'
    play_module_args = dict()
    play_module_args['var4'] = 'value4'
    play_module_args['var5'] = 'value5'
    play_module_args['var6'] = 'value6'
    play_module_args['when'] = 'when'

# Generated at 2022-06-11 11:17:58.593637
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    block = Block()

    class Options:
        pass

    opts = Options()
    opts.tags = None
    opts.action = 'include'
    opts.args = Options()
    opts.args._raw_params = 'test'
    opts.args._file = 'test' # noqa
    opts.args.apply = None  # noqa
    opts.args._action = 'include'
    opts.args.ignore_errors = None
    opts.args.loop = None
    opts.args.loop_control = None
    opts.args.loop_with = None
    opts.args.name = None
    opts.args.no_log = None
    opts.args.register = None
    opts.args.when = None
    opts.args.debugger

# Generated at 2022-06-11 11:18:08.015475
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create the dataloader and pass through the valid_block_structure
    loader = DataLoader()
    data = {
        'apply': {'ignore_errors': True},
    }

    # Create a new play context
    context = PlayContext()

    # Create a new play and set options
    play = Play()
    play.hosts = ['localhost']
    play.name = 'Build a parent block'
    play.post_validate = lambda x,y: True

# Generated at 2022-06-11 11:18:18.072899
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class TestTaskInclude(TaskInclude):
        def __init__(self):
            super(TestTaskInclude, self).__init__()

        def get_action_tasks(self, action=None, only_tags=None, skip_tags=None, exclude_parent=False, exclude_tasks=False):
            return []

        def add_block(self, block):
            pass

        def load_data(self, data, variable_manager=None, loader=None):
            pass

    # Set up needed fixtures
    task = Task()

    # Test check_options with empty args
    t = TestTaskInclude()
    t.args = {}
    assert t.check_options(task, {}) is task

    # Test check_options with all valid args
    t = TestTaskInclude()

# Generated at 2022-06-11 11:18:24.695336
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test for TaskInclude.get_vars()
    '''

    # Initialize data
    data = dict(
        action='include',
        file='test.yml',
        extra_param='extra_value',
    )

    # Test with 'action' = 'include'
    task = TaskInclude.load(data)
    vars = task.get_vars()

    # Asserts
    assert 'file' not in vars
    assert 'extra_param' in vars
    assert vars['extra_param'] == 'extra_value'

    # Test with 'action' = 'import_tasks'
    data['action'] = 'import_tasks'
    task = TaskInclude.load(data)
    vars = task.get_vars()

    # Asserts
   

# Generated at 2022-06-11 11:18:30.276362
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    display = Display()

    data = dict(
        action = 'include',
        args   = dict(
            _raw_params  = 'foo.yml',
            bar          = 'baz'
        ),
        vars   = dict(
            varia = 'blah'
        ),
        when   = 'inventory_hostname == this_host',
        tags   = ['only_me'],
    )

    task = TaskInclude.load(data)
    task.validate()

    assert data == task.get_vars()



# Generated at 2022-06-11 11:18:38.207614
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # This method is used to create the parent block for the included tasks
    # when ``apply`` is specified
    # Example:
    # - include: test.yml
    #   apply:
    #     for_each: "{{ (item1, item2) }}"
    #     when:     item2 > 2
    #     loop_control:
    #         label: "loop1: {{ item1 }}"

    # Check TaskInclude.build_parent_block returns Block for for_each or for_items
    apply_attrs = {'for_items': [], 'block': [], 'when': 'item2 > 2', 'loop_control': {'label': 'loop1: {{ item1 }}'}}
    ti = TaskInclude()
    ti._loader = None
    ti._role = None

# Generated at 2022-06-11 11:19:23.152490
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    task = Task.load({'action': 'include', 'file': 'test.yml'})
    assert ti.check_options(task, None).args == {'_raw_params': 'test.yml'}
    assert ti.check_options(task, None).file == 'test.yml'
    assert ti.check_options(task, None).action == 'include'

    task = Task.load({'action': 'import_role', 'name': 'testrole', 'apply': 'someval'})
    assert ti.check_options(task, None).args == {'apply': 'someval', 'name': 'testrole'}
    assert ti.check_options(task, None).name == 'testrole'

# Generated at 2022-06-11 11:19:28.801749
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # make sure static/dynamic include tasks can't use apply
    for task_action in C._ACTION_ALL_INCLUDE_TASKS:
        task = TaskInclude(None)
        ti = task.load(dict(action=task_action, apply={}))
        try:
            ti.check_options(ti, ti._ds)
        except AnsibleParserError as e:
            if ti.action not in C._ACTION_INCLUDE_TASKS:
                assert 'apply' in str(e)

# Generated at 2022-06-11 11:19:35.508917
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = Block()
    block.vars = {'a': 1, 'b': 2}
    block.block = []
    task_include = TaskInclude(block=block)
    task_include.args = {'apply': {'c': 3, 'd': 4}}
    p_block = task_include.build_parent_block()
    expected_p_block_vars = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert p_block.vars == expected_p_block_vars
    assert task_include.args == {}

# Generated at 2022-06-11 11:19:41.529823
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Testing with apply specified
    block_attrs = {'apply': {}, 'block': []}
    block = TaskInclude._build_parent_block(block_attrs)
    assert block.attributes == dict(block=[])
    assert isinstance(block, Block)

    # Testing without apply specified
    block_attrs = {'block': []}
    block = TaskInclude._build_parent_block(block_attrs)
    assert block.attributes == dict(block=[])
    assert isinstance(block, Block)


# Generated at 2022-06-11 11:19:50.577207
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # test invalid action
    test_input = {"args": {"path": "/test"}, "action": "test_action"}
    test_output = {"args": {"path": "/test"}, "action": "test_action"}
    test_output_ti = {"args": {"path": "/test"}, "action": "test_action"}
    ti.check_options(test_input, test_output)  # this should not raise any exception
    assert test_input == test_output_ti  # this should not change anything

    # test valid actions for the check_options validation
    for test_action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS:
        test_input = {"args": {"path": "/test"}, "action": test_action}

# Generated at 2022-06-11 11:19:51.222164
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    assert True

# Generated at 2022-06-11 11:20:00.035988
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude({'action': 'include'})
    t.args = {'x': 1, 'y': 2}
    assert t.get_vars() == {'x': 1, 'y': 2}

    t.vars = {'z': 3}
    assert t.get_vars() == {'x': 1, 'y': 2, 'z': 3}

    # Try again with a different action
    t = TaskInclude({'action': 'include_role'})
    t.args = {'x': 1, 'y': 2}
    assert t.get_vars() == {'x': 1, 'y': 2}

    t.vars = {'z': 3}
    assert t.get_vars() == {'x': 1, 'y': 2, 'z': 3}



# Generated at 2022-06-11 11:20:08.817426
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import inspect
    from ansible.cli import CLI
    import ansible.constants as C

    parser = CLI.base_parser(
        usage='%prog [options] [playbook.yml] [playbook2 ...]',
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        diff_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.",
    )
    (options, args) = parser.parse_args()
    # NOTE:

# Generated at 2022-06-11 11:20:18.116742
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block_vars = {'b': 'b'}
    parent_vars = {'p': 'p'}
    parent_block = Block(block_vars=block_vars)
    parent_block.set_parent(Block(block_vars=parent_vars))
    task = TaskInclude(action='include_role', args={'role': 'foobar'})
    task.set_loader(DictDataLoader({}))
    task.set_play_context(PlayContext())
    task.set_parent(parent_block)
    assert task.get_vars() == {'b': 'b', 'p': 'p'}
    task.set_action('include')

# Generated at 2022-06-11 11:20:29.211308
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    task = TaskInclude(play_context)

    # Test arg 'file'
    data = {'file': 'a'}
    task.preprocess_data(data)
    assert data['_raw_params'] == 'a'
    assert 'action' in data

    # Test arg 'file'
    data['file'] = 'a'
    task.preprocess_data(data)
    assert data['_raw_params'] == 'a'
    assert 'action' in data

    # Test arg '_raw_params'
    data['_raw_params'] = 'a'
    task.preprocess_data(data)
    assert data['_raw_params'] == 'a'
    assert 'action' in data

    #