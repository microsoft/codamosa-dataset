

# Generated at 2022-06-11 11:10:50.740957
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    my_dict = dict(statically_loaded=True)
    m = AnsibleMapping(my_dict)
    ti = TaskInclude()
    ti.statically_loaded = True
    ti.preprocess_data(m)

    # pass through static include objects
    assert 'statically_loaded' in m

    my_dict = dict(no_log=True, ignore_errors=True, name='foo')
    m = AnsibleMapping(my_dict)
    ti = TaskInclude()
    ti.preprocess_data(m)

    # exclude known non-task attributes for include and include_role
    assert 'no_log' not in m

# Generated at 2022-06-11 11:11:01.442627
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence

    ti = TaskInclude()
    ti.static_loader = None
    ti._parent = object()

    data = dict(
        action='include_role',
        name='dummy',
        no_log='False',
        pre_tasks=AnsibleSequence([
            dict(action='debug', msg='debug message', register='v_msg'),
            dict(action='debug', var='a', register='v_a')
        ]),
        loop='items',
        loop_control=dict(loop_var='item'),
    )

# Generated at 2022-06-11 11:11:12.407266
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # We create a TaskInclude object
    task = TaskInclude()

    # This is the default value of any attribute
    result = None

    # We set the default task name
    task.name = "include"

    # We set the action name
    task.action = "include"

    # In this case the get_vars method must return empty list
    assert task.get_vars() == result

    # We set the action name
    task.action = "include_role"

    # We set the task args
    task.args = {'a': 1, 'b': 2, 'c': 3}
    result = {'a': 1, 'b': 2, 'c': 3}

    # Since action is not 'include' we are going to get vars from parent task
    assert task.get_vars() == result

   

# Generated at 2022-06-11 11:11:22.518606
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import json
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Testing validation of bad args
    data = json.loads('''{
        "action"     : "include",
        "args"       : {
            "_raw_params" : "foo.yml",
            "invalid_opt" : "bar"
        }
    }''')

    try:
        TaskInclude._validate_args(data['args'], data)
        raise AssertionError('AnsibleParserError not thrown')
    except AnsibleParserError as e:
        assert str(e) == 'Invalid options for include: invalid_opt'

    # Testing validation of 'apply' for wrong tasks

# Generated at 2022-06-11 11:11:34.369359
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    def _test_check_options(task, data, expected_error):
        try:
            task.check_options(task, data)
        except AnsibleParserError as e:
            assert e.message == expected_error
            return True
        except Exception as e:
            raise Exception(e)
        return False


    def _error_message_none_param_file(action, data):
        return 'No file specified for %s' % action

    def _error_message_bad_arg(arg_name, action, data):
        return 'Invalid options for %s: %s' % (action, arg_name)

    def _error_message_bad_arg_apply(action, data):
        return 'Invalid options for %s: apply' % action


# Generated at 2022-06-11 11:11:45.299747
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.role

    class TestTaskInclude(TaskInclude):
        pass

    class TestRole(ansible.playbook.role.Role):
        pass

    from ansible.playbook.play import Play

    class TestPlay(Play):
        pass

    from ansible.playbook.block import Block

    class TestBlock(Block):
        pass

    from ansible.playbook.task import Task

    class TestTask(Task):
        pass

    Block._datastructure_registry.update({
        'block': TestBlock,
        'role': TestRole,
        'play': TestPlay,
        'task': TestTask,
        'include': TestTaskInclude,
    })


# Generated at 2022-06-11 11:11:55.029490
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    #from ansible.playbook.task import Task
    #from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()
    playbook = Play.load({'name': 'TEST'}, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 11:12:05.347143
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude

    class TestTaskInclude(unittest.TestCase):

        def setUp(self):
            self._test_dir = tempfile.mkdtemp()
            self._playbook_path = os.path.join(self._test_dir, 'test.yml')

# Generated at 2022-06-11 11:12:16.665315
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Run method from class TaskInclude
    class TestTaskInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            self.apply = kwargs.get('apply')
            self.parent = kwargs.get('_parent')
            self.role = kwargs.get('_role')
            self._variable_manager = kwargs.get('_variable_manager')
            self._loader = kwargs.get('_loader')
            self._play = kwargs.get('_play')
        def build_parent_block(self):
            return super(TaskInclude, self).build_parent_block(self)

    # Test with apply attribute

# Generated at 2022-06-11 11:12:26.025625
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    module_name = 'test_TaskInclude_build_parent_block'
    module_path = 'lib/ansible/modules/%s' % module_name
    from ansible.parsing.yaml.objects import AnsibleMapping

    data = AnsibleMapping(apply=dict(name=module_name))
    task = TaskInclude.load(data)
    task._loader = DictDataLoader({module_path: '---\n'})
    task_include_load()

    task._parent._play = DummyPlay()

    parent_block = task.build_parent_block()
    assert isinstance(parent_block, Block)
    assert parent_block.args == {'name': module_name}
    assert parent_block.block == []
    assert isinstance(parent_block._play, DummyPlay)

# Generated at 2022-06-11 11:12:41.806579
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook import Play, Playbook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C


# Generated at 2022-06-11 11:12:49.541124
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.plugins.action.include as IncludeActionModule
    from ansible.playbook.play_context import PlayContext

    # Basics of a PlayContext
    play_context = PlayContext()

    # For the test, we will create a task with a parent
    task_include = TaskInclude()
    task_include.action = 'include'
    task_include._loader = None

    var_manager = None
    task_include.set_loader(var_manager)

    role = None
    task_include._role = role

    # Basics of a task
    display = Display()
    task_include.action = 'include'
    task_include.args = dict()
    task_include.args['tags'] = []
    task_include.args['when'] = 'yes'
    task_include._parent = None
    task_

# Generated at 2022-06-11 11:13:00.362138
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import ansible.constants as C

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_inventory(variable_manager.loader.inventory)
    templar = Templar(loader=variable_manager.loader, shared_loader_obj=variable_manager, variables=variable_manager)

    # Example of data without 'when'
    data = {
        'include': 'include_simple.yml',
    }
    task_include = TaskInclude.load(data)
    assert task_include.action == 'include'
   

# Generated at 2022-06-11 11:13:10.599083
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.block

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 11:13:21.238658
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-11 11:13:32.131429
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    # test optional args
    t = task.check_options({'args': {'a': 'b'}}, None)
    assert t.args['a'] == 'b'
    t = task.check_options({'tags': 'foo'}, None)
    assert t.tags == 'foo'
    t = task.check_options({'when': 'true'}, None)
    assert t.when == 'true'
    t = task.check_options({'apply': {'a': 'b'}}, None)
    assert t.apply['a'] == 'b' and t.args['apply'] == {'a': 'b'}
    # invalid args
    task_include = TaskInclude()
    e = None

# Generated at 2022-06-11 11:13:39.329013
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    # remove 'file' and '_raw_params' from the list of valid keywords
    test_VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS - {'file', '_raw_params'}
    # add 'file' to the set of valid keywords
    TaskInclude.VALID_INCLUDE_KEYWORDS = TaskInclude.VALID_INCLUDE_KEYWORDS | {'file'}
    # task dictionary with valid keywords
    data1 = {"action": "include_tasks", "args": {"file": "some_file.yml"}}
    # task dictionary with invalid keyword

# Generated at 2022-06-11 11:13:44.710421
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_attributes = {'apply': {'loop': '{{users}}', 'vars': {'name': '{{item}}'}}}
    apply_attributes['block'] = []

    task = TaskInclude.load(apply_attributes)
    p_block = task.build_parent_block()
    assert isinstance(p_block, Block)
    assert task.args == {}

# Generated at 2022-06-11 11:13:55.369129
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # To test the function TaskInclude.load we need a TaskInclude object
    # The TaskInclude object is created by calling TaskInclude.load itself
    # So here we define a class TaskInclude which dynamically creates a class
    # with a TaskInclude object which calls the TaskInclude.load
    class FakeParent(object):
        pass

    class FakeTaskInclude(TaskInclude):
        def __init__(self):
            pass

        @staticmethod
        def load(data, block=None, role=None, task_include=None, variable_manager=None, loader=None):
            # Fake variable_manager and loader
            variable_manager = None
            loader = None


# Generated at 2022-06-11 11:14:05.257586
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play

    from ansible.playbook.play import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    import ansible.constants as C

    # Create a mock play
    pc = PlayContext()
    p = Play().load({'name': 'mock-play'}, variable_manager=pc.variable_manager, loader=pc.loader)

    # Create a mock block
    apply_attrs = {'block': []}
    task_include = TaskInclude(block=None, role=None, task_include=None)

# Generated at 2022-06-11 11:14:24.491623
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import sys
    import ansible.playbook.play
    import ansible.playbook.play_context

    context = ansible.playbook.play_context.PlayContext()

    # Clean up namespace
    for k in sys.modules.copy():
        if k.startswith('ansible.playbook.play'):
            del sys.modules[k]

    # Create the play via the factory method

# Generated at 2022-06-11 11:14:31.794912
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    parent_block = Block()
    parent_block.vars = dict(parent_var='parent_var')
    ti = TaskInclude(block=parent_block)
    ti.action = 'include'
    ti.args = dict(task_include_arg='task_include_arg')
    ti.vars = dict(task_include_var='task_include_var')

    expected_vars = dict(parent_var='parent_var', task_include_arg='task_include_arg', task_include_var='task_include_var')
    actual_vars = ti.get_vars()

    assert expected_vars == actual_vars

# Generated at 2022-06-11 11:14:43.104471
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test for no parent block
    apply_attrs = {}
    apply_attrs['block'] = [{'action': 'test', '_raw_params': 'action', '_line_number': '1'}]
    apply_attrs['when'] = "ansible_os_family == 'RedHat'"
    ti1 = TaskInclude()
    parent_task = ti1.build_parent_block()
    assert apply_attrs['block'] == parent_task._block

    # test for parent block
    apply_attrs = {}
    apply_attrs['block'] = [{'action': 'test', '_raw_params': 'action', '_line_number': '1'}]
    apply_attrs['when'] = "ansible_os_family == 'RedHat'"
    ti2 = TaskInclude()

# Generated at 2022-06-11 11:14:50.146778
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    def get_parent_blocks(task):
        if isinstance(task, Block):
            return [task, *get_parent_blocks(task._parent)]
        return []

    import json
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 11:15:00.712142
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test with an include with no tasks and no parent
    include_no_tasks_no_parent = TaskInclude()
    vars_include_no_tasks_no_parent = include_no_tasks_no_parent.get_vars()
    assert vars_include_no_tasks_no_parent == {}

    # Test with an include with no tasks, but with a parent
    task_include_no_tasks = TaskInclude()
    task_include_no_tasks.args['test_key'] = 'test_value'
    task_parent_no_tasks = Task(task_include=task_include_no_tasks)
    task_parent_no_tasks.vars['test_key2'] = 'test_value2'
    task_include_no_tasks._parent = task_

# Generated at 2022-06-11 11:15:07.751939
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    apply_task = TaskInclude()
    assert apply_task.build_parent_block().get_name() == 'TaskInclude'

    apply_attrs = {'block': [], 'debug': True}
    apply_task = TaskInclude(
        args={'apply': apply_attrs},
        action='include',
        _parent=Block(),
        _loader=Loader(),
        _variable_manager=VariableManager(Loader()),
    )
    assert apply_task.build_parent_block().get_name() == 'TaskInclude'

# Generated at 2022-06-11 11:15:17.756587
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    TaskInclude.VALID_INCLUDE_KEYWORDS.add('my_var')
    TaskInclude.VALID_ARGS.add('my_var')
    display.verbosity = 0
    task1 = TaskInclude()
    task1.action = 'import_tasks'
    task1.args = dict(my_var='value')
    task2 = TaskInclude()
    task2.action = 'include'
    task2.args = dict(my_var='value')
    if task1.get_vars() != dict(my_var='value'):
        raise Exception("failed to get vars from block")
    if task2.get_vars() != dict(my_var='value'):
        raise Exception("failed to get vars from block")



# Generated at 2022-06-11 11:15:27.937162
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test task with valid data
    task = TaskInclude()

    task.action = 'include_tasks'

    test_data = dict(
        name='dummy name',
        file='dummy file',
        ignore_errors=True,
        loop='item',
        loop_with='data',
    )
    task.preprocess_data(test_data)

    task.action = 'import_playbook'
    test_data = dict(
        name='dummy name',
        file='dummy file',
        ignore_errors=True,
        loop='item',
        loop_with='data',
    )
    task.preprocess_data(test_data)

    # Test task with invalid data and INVALID_TASK_ATTRIBUTE_FAILED=False

# Generated at 2022-06-11 11:15:37.717848
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    import ansible.playbook.role
    import ansible.inventory

    host = ansible.inventory.host.Host(name='testhost')
    group = ansible.inventory.group.Group(name='testGroup')
    group.add_host(host)
    inventory = ansible.inventory.Inventory(host_list=[host])
    task = ansible.playbook.TaskInclude.load({"include": "tests/units/utils/mock_tasks.yml", "apply": {"action": "shell", "name": "run simple command", "command": "echo foo"}})
    group.add_task(task)

# Generated at 2022-06-11 11:15:46.183934
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Using clone of Ansible parser, we check the preprocess_data method for TaskInclude class
    '''

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 11:16:17.835732
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block = Block(play=None, task_include=None, role=None, variable_manager=None, loader=None)
    ti = TaskInclude(block=block, role=None, task_include=None)

    # No apply, returns the block of the TaskInclude
    p_block = ti.build_parent_block()
    assert block == p_block

    # Build a play and the parent block, to be used in the below tests
    p = Play().load(dict(name="dummy_play"), None, None, None, None)
    p.post_validate()
    pb = Block(play=p, task_include=ti, role=None, variable_manager=None, loader=None)

    # Add the block to the TaskInclude and create a new parent block
    ti._parent = pb
    p_

# Generated at 2022-06-11 11:16:25.264678
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Test for include
    ti = TaskInclude()
    ti.action = 'include'
    ti.vars = {'a': 1, 'b': 2}
    ti.args = {'c': 3, 'd': 4}

    ti_vars = ti.get_vars()

    assert set(ti_vars.keys()) == set(['a', 'b', 'c', 'd'])

    # Test for import_tasks
    ti.action = 'import_tasks'
    ti_vars = ti.get_vars()

    assert set(ti_vars.keys()) == set(['a', 'b'])

# Generated at 2022-06-11 11:16:34.395675
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    class TestParent(object):

        def __init__(self, vars, loader):
            self.vars = vars
            self._loader = loader
            self._role = None
            self._variable_manager = None

        def get_vars(self):
            return self.vars

    class TestTaskInclude(TaskInclude):

        def __init__(self, args, parent, vars, loader):
            super(TestTaskInclude, self).__init__()
            self._parent = parent
            self._loader = loader
            self.args = args
            self.vars = vars
            self._role = None
            self._variable_manager = None

    vars = dict(test='test')
    loader = None


# Generated at 2022-06-11 11:16:44.009249
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    This method tests check_options() of TaskInclude class
    '''
    task = TaskInclude()
    data_include = dict(
        action='include',
        file='relative/path',
        name='included_name',
        debug=True,
        apply=dict(
            block=dict(
                rescue=dict(
                    block=[]
                )
            )
        )
    )
    data_import_playbook = dict(
        action='import_playbook',
        file='relative/path',
        name='included_name',
        debug=True,
        apply=dict(
            block=dict(
                rescue=dict(
                    block=[]
                )
            )
        )
    )

# Generated at 2022-06-11 11:16:53.148500
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    def get_block(name):
        return Block.load({'name': name, 'block': []}, task_include=None)

    # Test with 'apply' specified
    ti = TaskInclude()
    ti.args = {'apply': {'name': 'b1'}}
    ti._parent = get_block('p1')
    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.name == 'b1'
    assert p_block._parent == ti._parent

    # Test without 'apply' specified
    ti = TaskInclude()
    ti.args = {'x': 'y'}
    ti._parent = get_block('p2')
    p_block = ti.build_parent_block()
    assert p_block == ti

# Generated at 2022-06-11 11:17:02.383586
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    mytask = TaskInclude()
    mytask.action = 'include'
    mytask._parent = 'block1'
    mytask._role = 'role1'
    mytask._variable_manager = 'variable_manager1'
    mytask._loader = 'loader1'
    apply_attrs = {}
    apply_attrs['block'] = [1, 2, 3]
    mytask.args = {'apply': apply_attrs}
    assert mytask.build_parent_block().args['block'] == [1, 2, 3]
    mytask.args = {}
    assert mytask.build_parent_block() == mytask

# Generated at 2022-06-11 11:17:10.261432
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    the_play = Play()
    the_play.hosts = 'somehost'
    the_play.name = 'someplay'
    the_play.connection = 'someconnection'
    the_play.gather_facts = 'somegather'
    the_play.any_errors_fatal = 'someerror'
    the_play.max_fail_percentage = 'somemax'
    the_play.serial = 'someserial'
    the_play.port = 'someport'

    the_block = Block(parent_block=the_play)

# Generated at 2022-06-11 11:17:22.524189
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude.check_options
    task = dict(name='test', action='include_tasks', file='/foo/bar', apply=dict(a=1))

    # check whitespace
    with pytest.raises(AnsibleParserError):
        ti(task, dict(name='  ', action='include_tasks', file='/foo/bar'))

    # check duplicate params
    with pytest.raises(AnsibleParserError):
        ti(task, dict(name='  ', action='include_tasks', file='/foo/bar', file='/other/bar'))

    # check invalid params

# Generated at 2022-06-11 11:17:31.999237
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    The get_vars method should return the parent vars plus the include args for
    the include action.
    '''

    # No parent and no vars
    ti = TaskInclude(None)
    assert (ti.get_vars() == {})

    # One arg and one var
    ti = TaskInclude(None)
    ti.args = {'file' : "some/path"}
    ti.vars = {'var' : "value"}
    assert (ti.get_vars() == {'file' : 'some/path', 'var' : 'value'})

    # Test the parent overrides case
    p_block = Block(None)
    p_block.vars = {'var' : "value2"}
    ti.vars = {'var' : "value"}
    ti

# Generated at 2022-06-11 11:17:41.987061
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t = TaskInclude()

    # Check that apply option is not valid for `import_role` and `import_tasks`
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        if action == 'include':
            continue

        try:
            t.preprocess_data({'action': action, 'apply': None})
            raise AssertionError('Check apply option is not valid for %s FAILED!' % action)
        except AnsibleParserError:
            assert True, 'Check apply option is not valid for %s PASSED!' % action

    # Check that file option is mandatory

# Generated at 2022-06-11 11:18:21.789564
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.block import Block

    block = Block()
    task = TaskInclude(block=block)
    task.action = 'include'
    task.args = {'_raw_params': 'xyz.yml'}
    assert task.get_vars() == {}


# Generated at 2022-06-11 11:18:29.640186
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    class MockLoader():
        def __init__(self):
            self.path_exists_calls = {}
            self.path_exists_calls['hello.yml'] = True
            self.path_exists_calls['directory/hello.yml'] = True
            self.path_exists_calls['/absolute/path/to/hello.yml'] = True
            self.path_exists_calls['/other_file'] = False

            self.path_exists_results = {}

        def path_exists(self, path):
            self.path_exists_results[path] = path
            return self.path_ex

# Generated at 2022-06-11 11:18:37.723914
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    ti.action = "include"
    ds = {'tags': 'never'}
    new_ds = ti.preprocess_data(ds)
    assert ds is new_ds
    assert ds['tags'] == 'never'
    # statically loaded include statement
    ti.statically_loaded = True
    new_ds = ti.preprocess_data(ds)
    ds['tags'] = 'never'
    assert ds is not new_ds
    assert ds['tags'] == 'never'
    # action as include_role
    ti.action = "include_role"
    new_ds = ti.preprocess_data(ds)
    assert ds is new_ds
    # include_role with statically loaded
    ti.statically_loaded = True
    new_ds = ti

# Generated at 2022-06-11 11:18:42.422779
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args = dict(foo='bar', baz='blah')
    task_include.vars = dict(bling='blang')
    task_include._parent = Task()
    task_include._parent.vars = dict(dog='cat')
    assert task_include.get_vars() == dict(bling='blang', foo='bar', baz='blah')

# Generated at 2022-06-11 11:18:51.493939
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    module_args = {}
    module_args['file'] = './test/unit/test_plays/playbook_1/playbook.yml'
    task_include = TaskInclude(task_include=None)
    task_include.args = module_args
    task_include.action = 'include'
    vars = task_include.get_vars()
    assert 'file' in vars
    assert vars['file'] == './test/unit/test_plays/playbook_1/playbook.yml'
    assert 'tags' not in vars
    assert 'when' not in vars

    # test on static include
    static_include = TaskInclude(task_include=None)
    static_include.args = module_args
    static_include.action = 'include_role'
    static_include

# Generated at 2022-06-11 11:19:00.671386
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    # Example static file
    static_task = {'hosts': 'localhost', 'include_tasks': 'tasks.yml'}

    ti = TaskInclude()
    ti.preprocess_data(static_task)

    # Static file is not loaded
    assert 'include_tasks' in static_task

    # Example not static file
    not_static_task = {'hosts': 'localhost', 'include_tasks': {'file': 'tasks.yml'}}

    ti = TaskInclude()
    ti.preprocess_data(not_static_task)

    # Not static file is loaded
    assert 'include_tasks' not in not_static_task
    assert 'file' in not_static_task

    # Example role

# Generated at 2022-06-11 11:19:09.128587
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()
    # create a dict with all valid attributes
    valid_data = {'action': 'include',
                  'filename': 'somefile.yml',
                  'apply': {'find': {'age': 1}}}
    result = task.preprocess_data(ds=valid_data)
    # 'apply' attribute should be split into dict and assigned to property 'apply'
    assert 'apply' in task.args
    # 'filename' should be assigned to property 'file'
    assert 'file' in task.args
    # 'action' should be assigned to property 'action'
    assert 'action' in task.args
    # 'filename' should not be present any more
    assert 'filename' not in result
    # 'action' should not be present any more
    assert 'action' not in result
    # 'apply'

# Generated at 2022-06-11 11:19:19.032611
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    class TestTaskInclude(TaskInclude):
        _valid_actions = frozenset(('include',))

    # preprocess_data should be able to handle a list with only one element
    # It should add the element to each key of the list
    ds = [{'role': ['foo', 'bar']}]
    pds = TestTaskInclude.preprocess_data(ds)
    assert len(pds) == 1
    assert pds[0]['role'][0] == 'foo'
    assert pds[0]['role'][1] == 'bar'

    # preprocess_data should be able to handle a list with multiple elements
    # It should add the elements in the order of the list
    ds = [{'role': ['foo']}, {'role': 'bar'}]
    pds = Test

# Generated at 2022-06-11 11:19:21.734788
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # build_parent_block can't be tested by a unit test. It is attached to an object.
    # If it runs correctly it is tested indirectly in test_TaskInclude_copy
    assert True


# Generated at 2022-06-11 11:19:30.565199
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import ansible.playbook.task_include as task_include
    import ansible.playbook.task as task
    import ansible.playbook.block as block
    # Set action to include, vars to {'a': 1} and
    # kwargs to {'_raw_params': 'foo', 'b': 'file'}
    # Expect that:
    # - 'b' and '_raw_params' are in args
    # - 'a' is in vars with value 1
    ds = {'action': 'include', 'vars': {'a': 1}, '_raw_params': 'foo', 'b': 'file'}
    ti = task_include.TaskInclude(block.Block(task.Task()))
    ds = ti.preprocess_data(ds)

# Generated at 2022-06-11 11:20:22.667737
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    TaskInclude.BASE = frozenset(('x', 'y'))
    TaskInclude.OTHER_ARGS = frozenset(('a', 'b'))
    TaskInclude.VALID_ARGS = TaskInclude.BASE.union(TaskInclude.OTHER_ARGS)
    TaskInclude.VALID_INCLUDE_KEYWORDS = frozenset(('a', 'b', 'x', 'y'))

    ##################################################################################
    # Test for include action
    data = dict(action='include', x='a', y='b', a='a1', b='b1', c='c1')
    ti = TaskInclude()
    ti = ti.load(data)

# Generated at 2022-06-11 11:20:32.639961
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    # Test method get_vars of class TaskInclude and test case 1
    ds1 = dict(tags=['test_case_1'], action='include_tasks', file='test1.yml', myvar='just a var')
    task1 = TaskInclude.load(ds1)
    expected_vars1 = dict(myvar='just a var')
    assert task1.get_vars() == expected_vars1

    # Test method get_vars of class TaskInclude and test case 2
    ts2 = Block(play=None)
    ds2 = dict(tags=['test_case_2'], action='include', file='test2.yml', myvar='just a var')
    task2 = TaskInclude.load(ds2, block=ts2)
    expected_vars2 = dict