

# Generated at 2022-06-11 11:10:49.519085
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext

    from io import StringIO
    import sys

    play_context = PlayContext()
    loader = DictDataLoader({
        "/etc/ansible/roles/role1/tasks/foo.yml": """
        ---
        - hosts: all
          become: true
          tasks:
          - shell: echo 'hello world!'
        """,
        "/etc/ansible/roles/role1/tasks/bar.yml": """
        ---
        - hosts: all
          become: false
          tasks:
          - shell: echo 'hello world!'
        """
    })
    variable_manager = VariableManager()

    # Valid args

    # '- include: ...'

# Generated at 2022-06-11 11:11:00.108848
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.vars = {'var1': 'val1'}

    ti.args = {'_raw_params': 'param1',
               'var2': 'val2',
               'tags': ['tag1', 'tag2'],
               'when': 'when1'}

    all_vars = ti.get_vars()
    assert all_vars['var1'] == 'val1'
    assert 'var1' in all_vars
    assert all_vars['_raw_params'] == 'param1'
    assert '_raw_params' in all_vars
    assert all_vars['var2'] == 'val2'
    assert 'var2' in all_vars
    assert 'tags' not in all_vars
    assert 'when' not in all_

# Generated at 2022-06-11 11:11:11.489190
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import HandlerTaskInclude as HTI

    class MockParent(object):
        """Simple mock class used for testing"""
        def __init__(self, my_value):
            self.my_value = my_value

        def get_vars(self):
            return {'my_parent_value': self.my_value}

    def test_task_include_check_options_without_apply(task_action, kwargs):
        ti = TaskInclude()
        task = ti.load({
            'action': task_action,
            'args': kwargs
        })
        task = ti.check_options(task, None)

        assert task.args == {'_raw_params': 'file_value'}


# Generated at 2022-06-11 11:11:21.132650
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    def create_temp_task(action, **kwargs):
        """
        Return a created temporary task with no checks.
        """
        task = Task(block=None, role=None, task_include=None)
        task.name = 'Test Task'
        task.action = action
        task.args = kwargs

        return task

    # Create a temporary TaskInclude object that creates a temporary Task object
    # with the given action. Though for the action, ``include`` should be avoided
    # as it requires the static loading of a file.
    ti_task_factory = lambda action: TaskInclude(block=None, role=None, task_include=create_temp_task(action=action, file=None))
    ti_task_include_factory = lambda action: ti_task_factory(action='include')

    #

# Generated at 2022-06-11 11:11:31.653514
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    params = dict(
        action=Sentinel,
        args={'apply': dict(block=[])},
        _parent=Sentinel,
        _role=Sentinel,
        _variable_manager=Sentinel,
        _loader=Sentinel,
        vars={},
    )
    task = TaskInclude(**params)

    # Check that it creates a Block as we expect
    p_block = task.build_parent_block()
    assert isinstance(p_block, Block)

    # Check that it returns the task itself in case there is no apply
    task.args.pop('apply')
    p_block = task.build_parent_block()
    assert p_block is task

# Generated at 2022-06-11 11:11:42.449278
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.vars = {'a': 1, 'b': 2}
    task.action = 'include'
    task.args = {'c': 3, 'd': 4}
    task._parent = object()
    task._parent.get_vars = lambda: {'e': 5, 'f': 6}
    task._role = object()
    task._role.get_vars = lambda: {'g': 7, 'h': 8}
    task._loader = lambda x: yaml.safe_load(x)
    vars = task.get_vars()
    assert vars == {'e': 5, 'f': 6, 'a': 1, 'b': 2, 'c': 3, 'd': 4, 'g': 7, 'h': 8}


# Generated at 2022-06-11 11:11:53.148541
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task_fields = TaskInclude.fields

    # Construct a dict representing a task data structure for include
    ds = {
        'name': 'Test Task',
        'action': 'include',
        'args': {
            'file': 'test_file.yml',
        }
    }

    # Run the preprocess_data on the data structure
    ti = TaskInclude()
    ti.load_data(ds)

    # Check that the action was replaced by the symbol for static
    assert ds['action'] == Sentinel.static

    # Construct the same data structure but with a dynamic reference
    ds['args']['file'] = {'foo': 'bar'}

    # Run the preprocess_data on the data structure
    ti.load_data(ds)

    # Check that the action was replaced by the symbol for dynamic


# Generated at 2022-06-11 11:12:03.573808
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    data = {'action': 'include', 'name': 'inc'}
    task = TaskInclude.load(data)
    assert task.args['name'] == 'inc'
    assert task.build_parent_block() is task
    # test apply attrs
    data['args'] = {'apply': {'name': 'parent'}}
    task = TaskInclude.load(data)
    assert task.args['name'] == 'inc'
    assert task.build_parent_block().args['name'] == 'parent'

    # test apply attrs with args
    data['args']['apply']['args'] = {'k': 'v'}
    task = TaskInclude.load(data)
    assert task.args['name'] == 'inc'

# Generated at 2022-06-11 11:12:14.848015
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # To test a method of class using a class attribute
    # for example C._ACTION_INCLUDE, we need to mock the class attribute
    # to be able to test it.
    # But the attribute itself is not a class attribute.
    # This is the reason why we created the class attribute C._ACTION_INCLUDE_ROLE_TASKS
    # which contains the same value as C._ACTION_INCLUDE.
    parameterized_role_name = 'test_include'
    task_name = 'include role'
    C._ACTION_INCLUDE_ROLE_TASKS = (
        'include_role',
    )
    role = MagicMock()
    role.get_vars.return_value = {
        'parameterized_role_name': parameterized_role_name,
    }


# Generated at 2022-06-11 11:12:24.356501
# Unit test for method preprocess_data of class TaskInclude

# Generated at 2022-06-11 11:12:33.336924
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    assert TaskInclude.load({
        "include": "{{ lookup('file', files) }}",
        "apply": {
            "name": "somename"
        }
    }).build_parent_block().name == 'apply'


    assert TaskInclude.load({
        "include": "{{ lookup('file', files) }}",
    }).build_parent_block().action == 'include'

# Generated at 2022-06-11 11:12:44.343375
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    my_task = TaskInclude()

    # ------------------------------
    # No file, this will raise an error
    # ------------------------------
    test_data = {'when': "False"}
    try:
        my_task.check_options(my_task.load_data(test_data, variable_manager={}, loader={}), test_data)
    except AnsibleParserError as e:
        assert str(e) == 'No file specified for include'
    else:
        assert False, 'AnsibleParserError not raised'

    # ------------------------------
    # Invalid options will raise an error
    # ------------------------------
    test_data = {'when': "False", 'file': 'test.yml', 'invalid_option': "test"}

# Generated at 2022-06-11 11:12:53.125876
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude as TI
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-11 11:13:04.059126
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Ensure check_options works properly
    '''

    # Test 'import_tasks'
    t = TaskInclude()
    data = {'import_tasks': 'test.yml'}
    task_obj = t.Task._load_data(data, variable_manager=None, loader=None)
    t.check_options(task_obj, data=data)
    assert task_obj.action == 'import_tasks'
    assert task_obj.args == {'_raw_params': 'test.yml'}
    assert task_obj.args.get('apply') is None

    # Test 'import_tasks' with invalid args
    data = {'import_tasks': 'test.yml', 'b': 1, 'c': 2}
    task_obj = t.Task._load_data

# Generated at 2022-06-11 11:13:12.870760
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # This unit test is a little bit complicated to write because we use
    # real objects generated when using Ansible Playbooks.
    # To simplify the test, we use injected mock objects to provide them
    module_loader_mock = None
    inventory_mock = None
    task1 = TaskInclude()
    task1.args = {'apply': []}
    task1._parent = Task()
    task1._parent.block  = []
    task1._play = Play()
    task1._play._loader = module_loader_mock
    task1._play._variable_manager = VariableManager(loader=None, inventory=inventory_mock)
    task1._play._tasks = []
    task1._play._included_file_tasks = []
    task1._play._handlers = []
    task1._play._in

# Generated at 2022-06-11 11:13:24.168044
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    ti.check_options(ti.load_data({u'action': u'include'}), {u'action': u'include'})
    ti.check_options(ti.load_data({u'action': u'include_tasks'}), {u'action': u'include_tasks'})
    ti.check_options(ti.load_data({u'action': u'include_role'}), {u'action': u'include_role'})

    ti.check_options(ti.load_data({u'action': u'include_vars'}), {u'action': u'include_vars'})
    ti.check_options(ti.load_data({u'action': u'import_playbook'}), {u'action': u'import_playbook'})

# Generated at 2022-06-11 11:13:34.617867
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars import VariableManager

    ti = TaskInclude()
    # We need to mock the attributes of the class to have the same attributes of a task during execution
    # So we can use the same methods that are used in production such as build_parent_block
    ti.action = 'include'
    ti._parent = Play()
    ti._loader = None
    ti._variable_manager = VariableManager()
    ti._templar = Templar(loader=None, variables=ti._variable_manager)
    ti._task = None
    ti._block = None


# Generated at 2022-06-11 11:13:45.030438
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    class _TaskInclude(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(_TaskInclude, self).__init__(block=block, role=role, task_include=task_include)
            self._parent = None
            self._role = None
            self._variable_manager = None
            self._loader = None
            self.vars = None
            self.args = None

    class _Block(Block):
        def __init__(self, play=None, task_include=None, role=None):
            super(_Block, self).__init__(play=play, task_include=task_include, role=role)
            self._parent = None
            self._play = None
            self._role = None
            self._variable_manager = None


# Generated at 2022-06-11 11:13:55.518934
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # empty block
    block = {'block': []}
    # undefined keyword
    data = {'undef': 'foo', 'block': block}
    with pytest.raises(AnsibleParserError):
        task = TaskInclude.load(data)

    # invalid options for include
    data = {'apply': {}, 'block': block}
    with pytest.raises(AnsibleParserError):
        task = TaskInclude.load(data)

    # valid options for include
    data = {'file': 'foo', 'block': block}
    task = TaskInclude.load(data)
    assert 'file' not in task.args
    assert '_raw_params' in task.args

    # not a valid option for import_role

# Generated at 2022-06-11 11:14:05.446035
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class FakeBlock:

        def get_vars(self):
            return {"fake_block_var": "fake_block_value"}

    class FakeTask:

        def __init__(self, parent=None):
            self._parent = parent

        def get_vars(self):
            return {"fake_task_var": "fake_task_value"}

    class FakeParentTask:

        def get_vars(self):
            return {"fake_parent_var": "fake_parent_value"}

    # Test with include-like action
    task = TaskInclude()
    task._parent = FakeParentTask()
    task_vars = {"fake_task_include_var": "fake_task_include_value", "tags": "tag_value", "when": "task_when_value"}
    task.vars = task_v

# Generated at 2022-06-11 11:14:19.170531
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude

    play_context = PlayContext()
    playbook = Playbook()
    playbook.set_playbook_basedir("./tests")
    play = Play()
    play._play_context = play_context
    play._loader = playbook._loader
    play._variable_manager = playbook._variable_manager
    play.vars = {}
    play._block = Block()
    task = TaskInclude()
    task._parent = play
    task._role = None
    task._loader = playbook._loader
    task._variable_manager = playbook._variable_manager


# Generated at 2022-06-11 11:14:28.007452
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader

    role = Role()
    role._role_name = 'test'
    role._role_path = '/tmp/fake_role'
    assert role._role_name == 'test'
    assert role._role_path == '/tmp/fake_role'
    assert role.get_vars() == {}
    assert role.get_default_vars() == {}

    play_context = PlayContext()
    play_context.basedir = '/tmp'
    play_context.remote_addr = '127.0.0.1'
    play_context.password = 'pass1'

# Generated at 2022-06-11 11:14:38.312848
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # Arrange
    apply_attrs = {
        'name': 'created_by_parent_block',
        'block': [],
        'ignore_errors': 'yes',
        'connection': 'local',
        'any_errors_fatal': 'yes',
        'any_unreachable_fatal': 'yes',
        'serial': 0,
        'delegate_to': '',
        'run_once': 'yes'
    }
    task = TaskInclude()
    task.args = {'apply': apply_attrs}

    # Act
    block = task.build_parent_block()

    # Assert
    assert isinstance(block, Block)
    assert len(block.block) == 0
    assert block.name == apply_attrs['name']
    assert block.ignore_errors == apply_

# Generated at 2022-06-11 11:14:40.351160
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    assert ti.get_vars() == dict()


# Generated at 2022-06-11 11:14:48.889960
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.plugins.loader import find_loader_plugin
    from ansible.inventory.manager import InventoryManager

    # Setup an InventoryManager to pass to TaskInclude
    inventory = InventoryManager()
    inventory.add_host(Host('host'))
    inventory.add_host(Host('host2'))
    inventory.add_group('group1')
    inventory.add_group('group2')

    # TODO: add more tests, especially for blocks with loops
    # For example, add a test of a play with a block with a with_items loop
    # and a block within that block which is the parent block of the included tasks

    # Create a Play

# Generated at 2022-06-11 11:14:59.443104
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-11 11:15:05.619745
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Data to test with
    ds = {'action': 'include', 'args': {'foo': 2, 'bar': 7}}
    result = {'action': 'include', 'args': {'foo': 2, 'bar': 7}}
    # Create object to be tested
    task_include = TaskInclude()
    # Call the mehtod
    data = task_include.preprocess_data(ds)
    # Assert that data has been correctly included
    assert data == result

# Generated at 2022-06-11 11:15:15.708358
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    # Test preprocess_data method of class TaskInclude
    task_include = TaskInclude()
    data = {'action': 'include', 'args': 'file'}
    assert task_include.preprocess_data(data) == {'args': 'file', 'action': 'include'}
    data = {'action': 'include', 'apply': 'attrs'}
    assert task_include.preprocess_data(data) == {'apply': 'attrs', 'action': 'include'}
    data = {'action': 'include', 'args': 'file', 'extra': 'extra'}
    with pytest.raises(AnsibleParserError) as exc:
        task_include.preprocess_data(data)
    assert "is not a valid attribute for a TaskInclude" in str(exc.value)
    data

# Generated at 2022-06-11 11:15:25.817958
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    class MetaTaskInclude(TaskInclude):
        pass

    data = { 'action': 'include', 'file': 'dummy.yaml' }
    task = MetaTaskInclude.load_data(data)

    # load_data does copy.deepcopy, so we need to manually set
    # the action in the new object
    task.action = 'include'
    assert task.args['_raw_params'] == 'dummy.yaml'

    # Load includes task that can take apply option
    for action in C._ACTION_INCLUDE_TASKS:
        task.action = action
        task = MetaTaskInclude.load_data(data)
        task.action = action
        task = MetaTaskInclude.check_options(task, data)
        assert task.action == action

# Generated at 2022-06-11 11:15:35.909954
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import unittest2 as unittest

    class TestTaskInclude(unittest.TestCase):
        def test_check_options_without_action(self):
            task = TaskInclude()
            # no task.action so it should raise an exception
            with self.assertRaises(AnsibleParserError):
                task.check_options(task, {})

        def test_check_options_with_action(self):
            for action in C._ACTION_INCLUDE_TASKS:
                task = TaskInclude()
                task.action = action

                # the action will be in task.action, so we should not get an exception

# Generated at 2022-06-11 11:15:48.198026
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    pbex = PlaybookExecutor(playbook=["test_playbook_TaskInclude_build_parent_block.yml"])
    pbex._tqm._variable_manager = VariableManager()
    pbex._variable_manager = VariableManager()
    pbex._tqm.set_loader(pbex._loader)
    pbex.run()
    assert pbex._tqm._playbooks[0]._included_files[0]._parent._role == None
    assert pbex._tqm._playbooks[0]._included

# Generated at 2022-06-11 11:15:55.763718
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # This method is not really unit tested because it is hard to track all the possible task action,
    # options and type of arguments and there are many combinations. This test is only to check
    # that no issues are found with some sample cases.
    class MockInclude(TaskInclude):
        def __init__(self, *args, **kwargs):
            super(MockInclude, self).__init__(*args, **kwargs)

            self.args = {}
            self.action = self.__class__.__name__.lower()


# Generated at 2022-06-11 11:16:01.406966
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    task1 = TaskInclude()
    task2 = TaskInclude()
    task3 = TaskInclude()
    task1._parent = task2
    task2._parent = task3
    task1.args = {'apply': {'become': 'True'}}
    p_block = task1.build_parent_block()
    assert p_block.has_block()
    assert p_block.get_name() is not None
    assert p_block.get_name() == 'block'
    assert p_block.task_include is task1

# Generated at 2022-06-11 11:16:10.236832
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    TaskInclude.load = TaskInclude.load
    TaskInclude.check_options = TaskInclude.check_options
    ti = TaskInclude()
    data = {
        'action': 'include',
        'apply': {
            'tags': 'woot',
            'loop': '{{ my_list }}'
        },
        'file': 'my_file.yml',
        'name': 'my include',
        'loop_control': {'loop_var': 'my_var'},
        'collections': [
            'my.collection',
            'other.collection'
        ]
    }
    task = ti.load(data)
    assert task.action == 'include'

# Generated at 2022-06-11 11:16:19.300386
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Load data from yaml file (use the same directory where this file is located)
    data = load_fixture(os.path.join(os.path.dirname(__file__), 'fixtures', 'test_TaskInclude_get_vars.yaml'))
    # Create task include
    ti = TaskInclude(data)
    # Check vars returned by get_vars
    vars_expected = {'name': 'Anisble', 'action': 'include', 'version': 2}
    vars_returned = ti.get_vars()
    assert vars_expected == vars_returned
    # Create task
    task = Task(data)
    # Check vars returned by get_vars

# Generated at 2022-06-11 11:16:28.803743
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Unit test for method check_options of class TaskInclude
    '''
    class FakeTaskInclude(TaskInclude):
        def __init__(self):
            self.args = dict()
            self.action = None

    display_args = dict()

    # Invalid options gets an exception raised:
    ti = FakeTaskInclude()
    ti.args = {'bad_option': 'value'}
    ti.action = 'include_role'
    try:
        ti.check_options(ti, None)
        pytest.fail('An exception should have been raised')
    except AnsibleParserError as e:
        assert "Invalid options for include_role: bad_option" in str(e)

    # Not so for other actions, though:
    ti.action = 'import_tasks'

# Generated at 2022-06-11 11:16:37.784533
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # The goal here is to test that load method actually calls check_options
    # The problem is that the call to check_options read the attributes of
    # task which are passed by reference. This makes the test more complicated
    # as we need to pass the 'task' argument which is the result of load_data
    # On top of that we need to call check_options *after* load_data and so
    # we can't use the arguments passed to load which are 'self', 'data',
    # etc.

    # So we need to fake a task attribute, with a dict and a frozenset
    # as it is done in check_options
    class Task(object):
        def __init__(self):
            self.action = 'include'
            self.args = {'_raw_params': 'foo', 'bar': 1}
            self.args

# Generated at 2022-06-11 11:16:47.225409
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude

    # Case: - include_tasks
    my_arg_names = frozenset(('file', 'tags', 'do it', 'apply'))
    task = TaskInclude()
    task = task.check_options(task, {'action':'include_tasks', 'file':'foo'})
    assert task.action == 'include_tasks'
    assert task.args['_raw_params'] == 'foo'
    assert task.vars == {}
    assert task.args == {'_raw_params': 'foo', 'apply': {}}

    # Case: - include_role
    my_arg_names = frozenset(('file', 'tags', 'do it', 'apply'))
    task = TaskInclude()
    task = task.check_

# Generated at 2022-06-11 11:16:57.334397
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager

    playbook = ansible.playbook.Play()
    playbook._entries = [ansible.playbook.task.Task()]

    block = Block(
        parent=playbook,
        role=None,
        task_include=None,
        always_run=False,
        until=False,
        retries=0,
        rescue=[],
        any_errors_fatal=False,
        changed_when=False,
        failed_when=False,
        run_once=False,
        delegate_to=False
    )

    task = TaskInclude(block=block)    

# Generated at 2022-06-11 11:17:07.431072
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # Should throw no error upon valid args
    assert ti.check_options(
        ti.load_data(
            dict(file='/test/test.yml', apply=dict(a=1), b=2),
        )
    )

    # Should throw error upon invalid args
    try:
        ti.check_options(
            ti.load_data(
                dict(file='/test/test.yml', apply=dict(a=1), b=2, c=3),
            )
        )
    except AnsibleParserError as e:
        assert 'Invalid options for include: c' in str(e)
    else:
        assert 'Expected AnsibleParserError when invalid args passed'

    # Should not throw an error when task.action not in C._ACTION_ALL_PROPER_

# Generated at 2022-06-11 11:17:26.309247
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play

    my_play_source =  dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = 'no',
        tasks = [
            dict(action=dict(include="foo.yml", foo="ok")),
            dict(action=dict(include_role="common")),
            dict(action=dict(import_playbook="bar.yml", baz="nok")),
            dict(action=dict(import_tasks="baz.yml", qux="nok")),
            dict(action=dict(import_tasks="baz.yml", foo="ok")),
        ]
    )
    pb = Play.load(my_play_source, variable_manager=None, loader=None)

# Generated at 2022-06-11 11:17:34.278012
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()

    # Test for action import_role
    output = task.preprocess_data({'action': 'include_role',
                                   'name': 'Example',
                                   'ignore_errors': True,
                                   'tags': ['example']})
    assert output['ignore_errors']
    assert 'tags' not in output

    # Test for action include
    output = task.preprocess_data({'action': 'include',
                                   'ignore_errors': True,
                                   'tags': ['example']})
    assert output['ignore_errors']
    assert 'tags' not in output

    # Test for action include_tasks

# Generated at 2022-06-11 11:17:39.958017
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ds = {
        "include": "some.yml",
        "apply": {
            "tags": ["sometag"],
            "when": ["somewhen"]
        }
    }
    block = TaskInclude.load(ds)
    try:
        block.build_parent_block()
    except:
        assert False, "TaskInclude.build_parent_block() failed"



# Generated at 2022-06-11 11:17:51.335224
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader

    from ansible.vars.manager import VariableManager
    from ansible.vars import  HostVars

    play_context = PlayContext()
    play_context._set_task_and_variable_override(
        task_overrides={},
        play_vars={},
        play_context_vars={},
    )
    play_context.update_vars(dict(
        ansible_connection='local',
        ansible_python_interpreter='python',
    ))


# Generated at 2022-06-11 11:17:58.869398
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    t = TaskInclude()

    assert t.preprocess_data({}) == {}

    ds = {'action': 'include_tasks',
          'other_key': "value"}
    assert t.preprocess_data(ds) == {'action': 'include_tasks',
                                     'other_key': "value"}

    ds = {'action': 'import_tasks',
          'other_key': "value"}
    assert t.preprocess_data(ds) == {'action': 'import_tasks',
                                     'other_key': "value"}

    ds = {'action': 'include_role',
          'other_key': "value"}
    assert t.preprocess_data(ds) == {'action': 'include_role',
                                     'other_key': "value"}

    ds

# Generated at 2022-06-11 11:18:07.602848
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.plugins.loader import include_tasks_loader

    task = TaskInclude.load({
        'name': 'test',
        'include_tasks': 'some_file.yml',
        'tags': ['t1', 't2'],
        'when': {
            'var': 'value'
        },
        'vars': {
            'var1': 'value1',
            'var2': 'value2',
        }
    }, loader=include_tasks_loader)
    assert task.get_vars() == {'var1': 'value1', 'var2': 'value2', 'name': 'test', 'include_tasks': 'some_file.yml'}


# Generated at 2022-06-11 11:18:17.710925
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    from ansible.playbook import block
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    data = {'include': 'some_file', 'ignore_errors': True, 'garbage': 'garbage'}
    task_include = TaskInclude.load(data, block.Block(loader=loader))
    # task_include.args {} is OK since 'ignore_errors' is an action, not an include keyword
    assert task_include.args['ignore_errors'] is True
    # 'garbage' is removed
    assert 'garbage' not in data
    data = {'when': 'foo'}
    task_include = TaskInclude.load(data, block.Block(loader=loader))
    # task_include.args {} is OK since 'when' is an action, not an include

# Generated at 2022-06-11 11:18:24.476836
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.loader import action_loader

    for action_name in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        action_path = action_loader._get_action_class_name(action_name)
        action = action_loader.get(action_name, class_only=True)
        action_docs = read_docstring(action, style=action_loader._get_docstring_style(), verbose=False)
        task_include = TaskInclude(block=None, role=None, task_include=None)
        task_data = dict()
        task_data['action'] = action_name
        task_data['local_action'] = 'local_' + action_name
        task_data['args']

# Generated at 2022-06-11 11:18:32.593654
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task1 = TaskInclude()
    task1.action = 'include'
    task1.args = {'arg1':1, 'arg2':2}
    task1.vars = {'vars1':1, 'vars2':2}
    task1._parent = Task()
    task1._parent.get_vars = lambda: {'parent':1, 'parent2':2}
    assert task1.get_vars() == {'arg1':1, 'arg2':2, 'vars1':1, 'vars2':2, 'parent':1, 'parent2':2}

    task2 = TaskInclude()
    task2.action = 'include_tasks'
    task2.args = {'arg1':1, 'arg2':2}

# Generated at 2022-06-11 11:18:40.664674
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import os
    import tempfile

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext(loader=loader, options={}, variable_manager=variable_manager)

    block = Block()
    play = Play().load({}, loader=loader, variable_manager=variable_manager, play_context=play_context)
    block._play = play

    test_result = None
    test_name = None

# Generated at 2022-06-11 11:18:58.057375
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # test empty argument
    task = Task()
    task.args = dict()
    task.action = "include"
    TaskInclude.check_options(task, None)

    # test [in]valid option for include actions
    task.args = dict(apply=dict(), file="test")
    task.action = "include"
    TaskInclude.check_options(task, None)
    task.args = dict(apply="notadict", file="test")
    with pytest.raises(AnsibleParserError):
        TaskInclude.check_options(task, None)

    task.args = dict(apply=dict(), file="test")
    task.action = "include_tasks"
    TaskInclude.check_options(task, None)

# Generated at 2022-06-11 11:19:06.924980
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()

    # No task, no data
    task = ti.check_options(None, None)
    assert task is None

    task = Task()
    task.action = 'include'
    task.args = {'file': '/path/to/file'}
    task.vars = {}
    task.block = 0
    task.always_run = 0
    task.delegate_to = None
    task.run_once = 0
    task.notify = []
    task.first_available_file = None
    task.register = None
    task.ignore_errors = 0
    task.serial = 0

    # No data
    task_2 = ti.check_options(task, None)
    assert task == task_2

    # With data

# Generated at 2022-06-11 11:19:16.220451
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.task_include
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    import ansible.playbook.role_include

    #-----------------------------------------------------------------------
    # Test include_role 'include_vars'
    #-----------------------------------------------------------------------
    vars = dict(a=1, b=2)
    ti = ansible.playbook.task_include.TaskInclude(action='include_role', name='test', vars=vars)
    assert ti.get_vars() == vars

    #-----------------------------------------------------------------------
    # Test include_role 'include_tasks'
    #-----------------------------------------------------------------------
    # Test 1: empty vars
    ti = ans

# Generated at 2022-06-11 11:19:25.641068
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_class
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude as TaskInclude_class
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # make a RoleInclude
    role_include = RoleInclude()

    # create a role and a play
    role = Role()
    play = Play()
    play._role = role

    # Set the parent for the RoleInclude
    role_include.set_parent(play)

    # Create the task which has vars
    task = TaskInclude_class()

# Generated at 2022-06-11 11:19:34.557420
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    TaskInclude.load(
        {
            'action': 'include_tasks',
            'file': 'foo.yml',
            # 'tags': 'debug',
            # 'when': 'false',
        },
    )

    with pytest.raises(AnsibleParserError) as error:
        TaskInclude.load(
            {
                'action': 'include_tasks',
                # 'file': 'foo.yml',
                'tags': 'debug',
                'when': 'false',
            },
        )

        assert 'No file specified for include_tasks' in str(error)

    # if this raise an exception, it will be raise again in the calling function

# Generated at 2022-06-11 11:19:39.036649
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader

    p = Play().load({'name': 'test',
                     'hosts': 'all',
                     'tasks': [ {'include': 'role1'} ]
                     }, variable_manager=None, loader=DataLoader())

    for t in p.get_tasks():
        assert t._parent == p

# Generated at 2022-06-11 11:19:48.021477
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import pytest

    # [task_include, variables, error_msg, assertion]

# Generated at 2022-06-11 11:19:57.202868
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    task_include = TaskInclude(block=None, role=None, task_include=None)
    task_include._parent = Play()
    task_include._parent._play_context = PlayContext()
    task_include._parent._role = None
    task_include.action = 'include'
    task_include.args = {'apply': {}, 'foo': 'bar'}
    task_include.vars = {'foo1': 'bar1'}
    task_include._role = None

    parent_block = task_include.build_parent_block()

    assert type(parent_block) == Block
    assert parent_block == task_include
    assert task_include

# Generated at 2022-06-11 11:20:05.767228
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task as ParentTask
    from ansible.playbook.block import Block as ParentBlock
    from ansible.playbook.handler import Handler
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor

# Generated at 2022-06-11 11:20:14.251756
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    play = Play.load({"name": "test_taskinclude", "hosts": "localhost"}, variable_manager=variable_manager, loader=loader)
    testTask = TaskInclude(dict(apply=dict(name='test'), args=dict(task_attr='value')), play=play)
    parentBlock = testTask.build_parent_block()
    assert parentBlock.name == 'test'
    assert parentBlock.block[0].args['task_attr'] == 'value'

# Generated at 2022-06-11 11:20:38.453724
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a dummy context