

# Generated at 2022-06-11 11:10:48.037310
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible
    from ansible.utils.sentinel import Sentinel
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.role.definition import RoleDefinition

    # Construct some objects
    variable_manager = VariableManager()
    hosts = ['localhost']
    inventory = Inventory(hosts)
    loader = ansible.loader.Loader()
    display = Display()
    options = None

    #
    # Generate play for test
    #

    # Generate a play for testing the method 'build_parent_block'.
    # The test play includes four tasks:
    # - set_fact: var1

# Generated at 2022-06-11 11:10:54.703754
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    def assert_block_equals(block, attrs):
        block_attrs = block.get_vars()
        for attr in attrs:
            if attrs[attr] != block_attrs[attr]:
                raise AssertionError('block attribute %s not equal to %s' % (attr, attrs[attr]))

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.plugins.dynamic_inventory import InventoryModule

    context = PlayContext()
    context.remote_addr = 'localhost'


# Generated at 2022-06-11 11:11:06.545275
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    t = TaskInclude()

    # Method should raise AnsibleParserError if include does not have file
    def preprocess_data_test_1():
        t.preprocess_data({'action':'include'})
    import pytest
    pytest.raises(AnsibleParserError, preprocess_data_test_1)

    # Method should raise AnsibleParserError if include_tasks does not have file
    def preprocess_data_test_2():
        t.preprocess_data({'action':'include_tasks'})
    pytest.raises(AnsibleParserError, preprocess_data_test_2)

    # Method should raise AnsibleParserError if include_role does not have file

# Generated at 2022-06-11 11:11:15.155975
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayClass
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import TaskInclude
    from ansible.template import Templar

    variable_manager = DummyVars()
    play = Play()
    play._play = PlayClass(play=play,
                           play_hosts=set(['127.0.0.1']),
                           play_basedir='/some/path',
                           variable_manager=variable_manager)

    block = Block()
    block._play = play

    role = IncludeRole()
    role._role_name = 'some-role'
    role._block = block

# Generated at 2022-06-11 11:11:22.068949
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    class FakeParent:
        def __init__(self, *args, **kwargs):
            pass

    task_meta = {
        'action': 'include',
        '_parent': FakeParent(a='a'),
        'args': {
            'apply': {
                'block': 'block',
            }
        }
    }

    ti = TaskInclude(**task_meta)
    p_block = ti.build_parent_block()

    assert isinstance(p_block, Block)


# Generated at 2022-06-11 11:11:27.044833
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    args = dict(a=1, b=2)
    task = TaskInclude(block=block, args=args)
    vars_ = task.get_vars()
    assert vars_ == dict(a=1, b=2)

# Generated at 2022-06-11 11:11:34.167078
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ti = TaskInclude()
    ti.action = 'include'
    ti.vars = {'x': 1, 'y': 2}
    ti.args = {'_raw_params': './foo'}
    ti._parent = Block()
    ti._parent.get_vars = lambda: {'x': 10, 'z': 30}
    assert ti.get_vars() == {'x': 1, 'y': 2, 'z': 30, '_raw_params': './foo'}

# Generated at 2022-06-11 11:11:45.031836
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Test that Invalid TaskInclude attributes are properly detected
    '''
    my_task = TaskInclude()
    ds = dict(action='include_tasks', foo='bar')

    # Test with INVALID_TASK_ATTRIBUTE_FAILED=False, ie. display a warning
    C.INVALID_TASK_ATTRIBUTE_FAILED = False
    result = my_task.preprocess_data(ds)
    assert len(result) == 1
    assert 'foo' not in result
    assert 'action' in result

    # Now test with INVALID_TASK_ATTRIBUTE_FAILED=True, ie. failed
    C.INVALID_TASK_ATTRIBUTE_FAILED = True
    def my_func():
        result

# Generated at 2022-06-11 11:11:54.829400
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.file_include import FileInclude
    from ansible.template import Templar

    play_context = PlayContext()
    loader = MockLoader()
    play = Play().load({'name': 'test_play', 'hosts': 'all'}, loader=loader, variable_manager=MockVariableManager())

# Generated at 2022-06-11 11:12:05.151688
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    """Unit test for TaskInclude preprocess_data."""
    class AnsibleOptions:
        pass
    ansible_options = AnsibleOptions()
    ansible_options.__dict__['INVALID_TASK_ATTRIBUTE_FAILED'] = False

    task = TaskInclude()
    task._role = ""
    task._loader = C.DEFAULT_LOADER()
    task._variable_manager = C.VariableManager()
    task.no_log = False
    task.block = ''
    task.when = ['1']
    task.args = {}
    task.action = 'include'

    # We are only validating the invalid attributes are removed
    # so we have to add something that is invalid first.
    # We know 'no_log' is not used in include tasks so we can use that as an example

# Generated at 2022-06-11 11:12:19.669156
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    task_ds = dict(
        name="Include task",
        block=None,
        role=None,
        task_include=None,
        include=dict(
            args=dict(
                _raw_params="file.yml",
                apply=dict(
                    environment=[
                        dict(
                            name="test",
                            value="value"
                        )
                    ],
                    tags=["test-tag"],
                    when="test-when"
                )
            )
        )
    )

# Generated at 2022-06-11 11:12:24.579950
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    test_data = {
        'var_a': '',
        'var_b': Sentinel,
        'var_c': '',
        'var_d': '',
        'var_e': '',
        'var_f': '',
        'var_g': '',
        'var_h': '',
    }

    # 'action' is the bare minimum needed to trigger validation
    # For 'include_role' and 'import_role' we will get an additional check
    assert set(ti.preprocess_data(test_data).keys()) == set(['var_a', 'var_c', 'var_d', 'var_e', 'var_f', 'var_g', 'var_h'])

    test_data['action'] = 'import_role'
    assert set

# Generated at 2022-06-11 11:12:34.652194
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager

    task_ds_1 = dict(
        action='include',
        include='foo.yml',
        apply='',
        block=dict(
            name='foo',
            block=[
                dict(action='debug', msg='first debug')
            ]
        )
    )


# Generated at 2022-06-11 11:12:45.434729
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    '''
    Unit test for method preprocess_data of class TaskInclude
    '''
    def test(data, changed_data, expected_changed_data, expected_exception):
        task_include = TaskInclude()
        task_include.action = 'static_include_role'

        if expected_exception:
            try:
                processed_data = task_include.preprocess_data(data)
                assert False
            except AnsibleParserError:
                assert True
        else:
            processed_data = task_include.preprocess_data(data)
            assert processed_data == expected_changed_data


# Generated at 2022-06-11 11:12:54.809679
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()
    task = task_include.check_options(Task.load({'name': 'test_task_include', 'action': 'include', 'args': {'file': 'not_a_real_file'}}))
    assert task.name == 'test_task_include'
    assert task.action == 'include'
    assert task.args['_raw_params'] == 'not_a_real_file'
    assert task.args['_raw_params'] == task.args.get('file'), 'Check if file was moved to _raw_params'
    assert 'file' not in task.args, 'Check that file does not exist in args'

    # Test for invalid arg for include-like tasks

# Generated at 2022-06-11 11:13:05.866030
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # prepare data
    task_include = TaskInclude()
    block = Block()
    task_include._parent = block
    task_include._role = None
    task_include._variable_manager = None
    task_include._loader = None
    task_include.args = {'apply': {'other': 'test_value'}}

    # execute test method
    p_block = task_include.build_parent_block()

    # verify result:
    assert(isinstance(p_block, Block))
    assert(p_block._parent is block)
    assert(p_block._role is None)
    assert(p_block._variable_manager is None)
    assert(p_block._loader == None)
    assert(p_block.args == {})
    assert(p_block.block == [])

# Unit

# Generated at 2022-06-11 11:13:13.857520
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    a = Block()
    a.vars['a_var'] = 'a_val'
    b = Task()
    b.vars['b_var'] = 'b_val'
    c = TaskInclude()
    c.vars['c_var'] = 'c_val'
    c.args['c_arg'] = 'c_val'
    c.action = 'include'
    c.parent = b
    b.parent = a
    assert c.get_vars() == {
        'a_var' : 'a_val',
        'b_var' : 'b_val',
        'c_var' : 'c_val',
        'c_arg' : 'c_val',
    }

# Generated at 2022-06-11 11:13:25.486924
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars, HostVarsVars
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create a dictionary of the data structure to use to create a task
    ds = dict(
        file = 'some_file.yml',
        apply = dict(
            block = [
                dict(
                    task = dict(
                        action = 'my_action',
                    ),
                ),
            ],
        ),
        some_other_attribute = 'some_other_value',
    )

    # Create a TaskInclude object with the ds
    task = TaskInclude.load(ds)
    # Create

# Generated at 2022-06-11 11:13:29.160274
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    options = PlayContext()
    options.verbosity = 3
    options.become = True
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.remote_user = 'root'
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, host_list=['127.0.0.1'])
    inventory.add_group('group1')

# Generated at 2022-06-11 11:13:37.894067
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    TaskInclude.check_options({'action': 'include_role', 'args': {'apply': 42}})
    TaskInclude.check_options({'action': 'include_role', 'args': {'file': 'tasks/main.yml', 'noop': True}})
    TaskInclude.check_options({'action': 'include_role', 'args': {'tags': 'setup'}})
    TaskInclude.check_options({'action': 'include_role', 'args': {'file': 'tasks/main.yml', 'apply': None}})
    TaskInclude.check_options({'action': 'include_role', 'args': {'apply': {'loop_with': 'bogus'}, 'file': 'tasks/main.yml'}})

# Generated at 2022-06-11 11:13:53.471568
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.included_file import IncludedFile
    tf = IncludedFile('./test.yml')
    ti = TaskInclude(task_include=tf)
    data = dict(action='include', test='hello')
    res = ti.preprocess_data(data)
    assert res.get('action') == 'include'
    assert res.get('test') is None
    data = dict(action='import_tasks', test='hello')
    res = ti.preprocess_data(data)
    assert res.get('action') == 'import_tasks'
    assert res.get('test') == 'hello'
    data = dict(action='include', test='hello')
    res = ti.preprocess_data(data)
    assert res.get('action') == 'include'
    assert res.get

# Generated at 2022-06-11 11:14:02.810061
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    my_task = TaskInclude()
    data = dict(
        action='include',
        file='/some/file',
    )
    result = my_task.preprocess_data(data)
    assert not result.get('meta')
    assert result.get('file') is None
    assert result.get('_raw_params') == '/some/file'

    data = dict(
        action='import_role',
        role='blah',
        file='/some/file',
    )
    result = my_task.preprocess_data(data)
    assert result.get('file') is None
    assert result.get('_raw_params') == '/some/file'
    assert result.get('role') is None


# Generated at 2022-06-11 11:14:12.863554
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # init required objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-11 11:14:22.610971
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook.play_context
    parent_context = ansible.playbook.play_context.PlayContext()

    task = TaskInclude(role=None, task_include=None, block=None)
    task.vars = {'host': 'host'}
    task._parent = parent_context
    parent_context.vars = {'role': 'role'}
    assert task.get_vars() == {'host': 'host', 'role': 'role'}, task.get_vars()

    task = TaskInclude(role=None, task_include=None, block=None)
    task.vars = dict()
    task._parent = parent_context
    parent_context.vars = {'role': 'role'}

# Generated at 2022-06-11 11:14:24.472128
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # pylint: disable=unused-argument
    def apply_factory(args, variable_manager=None, loader=None):
        task = TaskInclude()

# Generated at 2022-06-11 11:14:34.213085
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import yaml

    class TaskInclude(TaskInclude):
        # We use a dummy play class for unit tests
        class _play:
            class _play_ds:
                def __init__(self):
                    self.host_groups = {}

                def _get_task_vars(self, obj):
                   return obj.vars

            # We need the _ds attribute to be instanciated to avoid
            # exception if the module is imported
            _ds = _play_ds()

        _parent = _play()
        # We need the _ds attribute to be instanciated to avoid
        # exception if the module is imported
        _ds    = _play()._ds

    t1 = TaskInclude()
    t1.action = 'include'

# Generated at 2022-06-11 11:14:41.321972
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {'action': 'include_role', 'name': 'foo'}
    task = TaskInclude()
    result = task.preprocess_data(data)
    assert result == data

    data = {'action': 'include_role', 'name': 'foo', 'bad': 'bar', 'another': 'baz'}
    task = TaskInclude()
    result = task.preprocess_data(data)
    assert result == {'action': 'include_role', 'name': 'foo'}

# Generated at 2022-06-11 11:14:49.348859
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.included_file import IncludedFile
    from ansible.parsing.dataloader import DataLoader

    class ParentTask:
        def __init__(self):
            self.vars = {
                'var1': 'foo',
            }

        def get_vars(self):
            return self.vars

    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager()
    included_file = IncludedFile(loader, variable_manager, display)
    parent_task = ParentTask()
    parent_block = Block(play=PlayContext(), role=None, task_include=included_file)
    parent_task._parent = parent_block

    # Test a include task that is not 'include'
   

# Generated at 2022-06-11 11:14:51.576263
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    obj = {}
    ti = TaskInclude()
    ti.preprocess_data(obj)
    assert obj == {}


# Generated at 2022-06-11 11:15:02.148144
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():

    import sys
    import os
    import yaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    v_file = './host_vars/hosts'
    # Getting Vars from host_vars/hosts
    content = open(v_file).read()
    y = yaml.load(content)
    host_vars = y['vms_test']['vars']

    # Setting up play context
    play_context = PlayContext()

# Generated at 2022-06-11 11:15:15.575900
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    task = TaskInclude()
    # Should call display.warning
    task.check_options({'_raw_params': 'no-such-file.yaml', 'debugger': 'foo'}, data={})

    # Should raise AnsibleParserError
    task_data = {'_raw_params': 'no-such-file.yaml', 'debugger': 'foo'}
    task_data['action'] = 'include_role'
    try:
        task.check_options(task_data, data={})
        assert False, 'Should raise AnsibleParserError'
    except AnsibleParserError as e:
        pass

    # Should raise AnsibleParserError
    task_data = {'_raw_params': 'no-such-file.yaml', 'debugger': 'foo'}

# Generated at 2022-06-11 11:15:25.669359
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # test when action not in ('include', 'import_tasks')
    class TestTaskIncludeA(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None, action="action1"):
            super(TestTaskIncludeA, self).__init__(block=block, role=role, task_include=task_include)
            self.action = action

    ti = TestTaskIncludeA()
    ti._parent = Block()
    ti._parent.vars = {'parent_var': 1}
    ti.vars = {'task_var': 2}
    ti.args = {'task_arg': 3}
    assert not ti._role
    assert not ti._play
    # all variables are present in returned dict.

# Generated at 2022-06-11 11:15:35.791412
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_mock = TaskInclude()

    # regular task vars
    task_mock.vars.update({'var':'val'})

    # included task, specific vars
    task_mock.action = 'include'
    task_mock.args.update({'file': 'template'})
    task_mock.args.update({'my_include': 'my_var'})

    # parent task vars, do not include here though
    if False:
        task_mock._parent = TaskInclude({'add_host': 'localhost'})

    vars = task_mock.get_vars()

    assert vars['var'] == 'val', 'TaskInclude get_vars : plain var should be included'

# Generated at 2022-06-11 11:15:44.082796
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.module_utils.six import string_types

    ti = TaskInclude()
    # Test that we accept valid keywords
    valid_kwds = dict(
        action='invalid',
        args='invalid',
        collections='invalid',
        debugger='invalid',
        ignore_errors='invalid',
        loop='invalid',
        loop_control='invalid',
        loop_with='invalid',
        name='invalid',
        no_log='invalid',
        register='invalid',
        run_once='invalid',
        tags='invalid',
        timeout='invalid',
        vars='invalid',
        when='invalid'
    )
    ds = ti.preprocess_data(valid_kwds)
    assert isinstance(ds, dict)

# Generated at 2022-06-11 11:15:52.374913
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Mock the Play and PlayContext to avoid side-effects
    class PlayContextMock(PlayContext):
        def __init__(self, *args, **kwargs):
            pass


    class PlayMock(object):
        def __init__(self, *args, **kwargs):
            pass

    # Place the same action as in test_TaskInclude_load
    action_loader._actions['include'] = MockActionModule()
    action_loader._aliases['include'] = 'include'

    # Create and load the TaskInclude
    task_incl = TaskInclude()

# Generated at 2022-06-11 11:16:00.066636
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    v_manager = VariableManager()
    loader = DataLoader()
    play = Play().load({}, loader=loader, variable_manager=v_manager)

    def _load_data(task, data):
        return task.load_data(
            data,
            loader=loader,
            variable_manager=v_manager,
        )

    def _assert_valid(action, data):
        task = TaskInclude(block=Block(parent=play))
        task = _load_data(task, data)

# Generated at 2022-06-11 11:16:03.265973
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Arrange
    task_include = TaskInclude()
    task_include.args['a'] = "b"

    # Act
    vars = task_include.get_vars()

    # Assert
    assert vars['a'] == 'b'

# Generated at 2022-06-11 11:16:12.052636
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleParserError
    from ansible.utils.vars import combine_vars

    # The items we will use in the tests
    task_valid_data = dict(
        action='include',
        file='/etc/ansible/included_tasks.yml',
        apply=dict(
            action='copy',
            src='/etc/ansible/included_tasks.yml',
            dest='/etc/ansible/copied_task.yml',
        ),
    )

# Generated at 2022-06-11 11:16:21.566185
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    the_host = 'localhost'
    the_loader = DataLoader()

    the_inventory = InventoryManager(
        loader=the_loader,
        sources=the_host
    )
    the_variable_manager = VariableManager(
        loader=the_loader,
        inventory=the_inventory
    )

    ti = TaskInclude()
    ti.action = 'include'

    ti.args = {
        'first_include': 'somevalue'
    }

    ti.filename = 'some_file'
    ti.role

# Generated at 2022-06-11 11:16:30.642777
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Creates a simple test case for method check_options of class TaskInclude.
    '''
    from ansible.playbook.handler import HandlerTaskInclude
    import os

    import pytest
    from ansible.errors import AnsibleParserError
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import merge_hash

    fix_path = os.path.dirname(__file__)
    loader = AnsibleCollectionLoader()
    blocks = loader.load_from_file(os.path.join(fix_path, 'data/tasks/include_action_test.yml'))

    display = Display()
    display.verbosity = 3



# Generated at 2022-06-11 11:16:46.948789
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():

    # 'include_plus' is include things and some other things
    include_plus_data = dict(
        action='include_plus',
        file='abc.yml',
        other_key='other_value',
    )
    include_plus_task = Task.load(include_plus_data, dict(name='dummy_name'))
    assert isinstance(include_plus_task, TaskInclude)
    # expect key 'file' to be poped out and be added to '_raw_params'
    TaskInclude.check_options(include_plus_task, include_plus_data)
    assert 'file' not in include_plus_task.args
    assert 'abc.yml' == include_plus_task.args['_raw_params']

# Generated at 2022-06-11 11:16:56.827689
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    play_data = {}
    play = Play.load(play_data, variable_manager=None, loader=None)

    play_data['tasks'] = [{'action': 'shell', 'args': {'chdir': '/tmp'}, 'include': 'other.yml'}]
    block_data = {'block': []}
    block = Block.load(block_data, play=play, task_include=None, role=None, loader=None, variable_manager=None)

    task_data = {'action': 'include', 'args': {'file': 'other.yml'}}

# Generated at 2022-06-11 11:17:07.169047
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbooks.play_context import PlayContext

    class MockModel(object):
        def __init__(self):
            pass

    class MyTaskInclude(TaskInclude):
        VALID_ARGS = TaskInclude.VALID_ARGS.union(['foobar'])

        def __init__(self, block=None, role=None, task_include=None):
            super(MyTaskInclude, self).__init__(block=block, role=role, task_include=task_include)
            self.statically_loaded = False

    play_context = PlayContext()
    loader = MockModel()
    variable_manager = MockModel()

    # test_TaskInclude_check_options_no_file_specified
   

# Generated at 2022-06-11 11:17:18.203858
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play = Play().load({
        'name': 'include task test',
        'hosts': 'all',
        'gather_facts': False,
        'tasks': [
            {
                'name': 'normal task',
                'include': 'included_file.yml'
            }
        ]
    }, variable_manager=VariableManager(), loader=DataLoader())

    # The task has no apply attribute so it should return itself
    task = play.get_task_by_name('normal task')
    assert isinstance(task.build_parent_block(), TaskInclude)

    # The task has an apply

# Generated at 2022-06-11 11:17:29.225064
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    ti = TaskInclude()
    self = ti # hack to have the same interface as a TaskInclude instance
    self._parent = Sentinel('_parent')
    self._role = Sentinel('_role')
    self._variable_manager = Sentinel('_variable_manager')
    self._loader = Sentinel('_loader')
    self.args = {'apply': {'name': 'block_name'}}

    p_block = ti.build_parent_block()
    assert isinstance(p_block, Block)
    assert p_block.name == 'block_name'
    assert p_block.parent == self._parent
    assert p_block.play == self._parent._play
    assert p_block.role == self._role
    assert p_block.variable_manager == self._variable_manager
    assert p_block.loader == self._loader

# Generated at 2022-06-11 11:17:36.364087
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    role = type('role', (object,), {})
    play = type('play', (object,), {})
    variable_manager = type('variable_manager', (object,), {})
    loader = type('loader', (object,), {})
    parent = type('parent', (object,), {})
    
    parent._loader = loader
    parent._variable_manager = variable_manager
    parent._play = play
    
    task_include = TaskInclude(parent=parent, role=role)
    apply_attrs = {
        'block': []
    }
    task_include.args['apply'] = apply_attrs
    p_block = task_include.build_parent_block()
 
    assert isinstance(p_block, Block)


# Generated at 2022-06-11 11:17:47.310089
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    vars = dict(
        t1=dict(
            name="task 1",
            tags="tag1",
            ignore_errors="no"
        ),
        t2=dict(
            name="task 2",
            tags="tag2",
            ignore_errors="no"
        )
    )

    task = dict(
        name="include",
        apply=dict(
            ignore_errors="yes",
            tasks=[vars['t1'], vars['t2']]
        )
    )

    # setup
    ti = TaskInclude.load(task)
    assert ti.name == "include"
    assert ti.action == "include"
    assert len(ti._block._block) == 2
    assert ti._block._block[0].name == "task 1"

# Generated at 2022-06-11 11:17:56.841542
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Use pipe as delimiter to be compatible with Windows
    task_data = "include_tasks: file=${items} | with_items: *sat_tasks.yml"
    task = TaskInclude.load(task_data)
    assert task_data == task.args.get('_raw_params')

    task_data = "include_role: name={{ item }} | with_items: *sat_roles"
    task = TaskInclude.load(task_data)
    assert task_data == task.args.get('_raw_params')

    task_data = "import_playbook: x.yml"
    task = TaskInclude.load(task_data)
    assert task_data == task.args.get('_raw_params')

if __name__ == '__main__':
    test_

# Generated at 2022-06-11 11:18:06.376252
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test method get_vars of class TaskInclude to see that args of the
    include are included in the vars ONLY for 'include' action
    '''
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role.include

    # Create a test play

# Generated at 2022-06-11 11:18:15.724329
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    fake_block = {
        "block": [],
        "attributes": {
            "loop_control": {
                "loop_var": "item"
            }
        }
    }

    parent_block = TaskInclude.load(
        {"action": "include_role", "args": {"loop": [{"item": "a"}], "apply": fake_block}},
        task_include=None,
        loader=loader,
    )

    assert isinstance(parent_block, Block)
    assert parent_block.loop_control.loop_var == "item"
    assert len(parent_block._block) == 0

# Generated at 2022-06-11 11:18:45.049469
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # check for valid "action" options
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        data = dict(action=action, file='some_playbook.yaml')
        try:
            task.check_options(task.load(data), data)
        except Exception as e:
            raise AssertionError(
                'Unexpected error for option \'action: %s\':\n%s' % (action, e)
            )

    # check for invalid "action" options
    for action in C._ACTION_ALL_INCLUDE_ROLE_TASKS:
        invalid_data = dict(action='invalid_action', file='some_playbook.yaml')

# Generated at 2022-06-11 11:18:53.753202
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_args = {'var1': 'val1', 'var2': 'val2'}
    test_name = 'Test include'
    test_task = TaskInclude(Sentinel(), Sentinel(), Sentinel())
    test_task.name = test_name
    test_task.vars = dict()
    test_task.args = test_args
    # test_task._parent = Sentinel()

    # test TaskInclude.get_vars with action not in include
    test_vars = test_task.get_vars()
    assert test_name == test_vars['item']
    assert test_vars == test_task.vars

    # test TaskInclude.get_vars with action in include but without parent
    test_task.action = 'include'
    test_vars = test_task.get_v

# Generated at 2022-06-11 11:19:00.292603
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude(block = None, task_include = None, role = None)
    t.action = 'include'
    t.args = {'_raw_params': 'a.yml', 'b': 2}
    t.vars = {'a': 1}

    expected = {'a': 1, '_raw_params': 'a.yml', 'b': 2}
    actual = t.get_vars()

    assert expected == actual,\
        "Expected {0} but got {1}".format(expected, actual)

# Generated at 2022-06-11 11:19:06.433328
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    # set mock role
    role = {
        'name': 'test_role',
        'tasks':[]
    }
    # set mock task include
    task = {
        'action': 'include',
        'args': {
            'apply': {},
            'file': 'test_include.yml',
            'tags': []
        }
    }

    # create TaskInclude object
    ti_object = TaskInclude()
    p_block = ti_object.build_parent_block(task, role)

    # assert not None
    assert p_block is not None

# Generated at 2022-06-11 11:19:15.614424
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # setting action to 'include' because we are testing valid options
    # on 'include' task only
    task.action = 'include'

    # testing valid options with action as 'include'

# Generated at 2022-06-11 11:19:25.138479
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # prepare the test case classes
    class MyTask(TaskInclude):
        def __init__(self, block=None, role=None, task_include=None):
            super(MyTask, self).__init__(block=block, role=role, task_include=task_include)
            self.statically_loaded = False


# Generated at 2022-06-11 11:19:29.441819
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude()

    data = dict(action='include', ignore_errors=True)
    task = dict(action='include', args=dict(ignore_errors=True))

    task = task_include.check_options(task, data)

    assert task == dict(action='include', args=dict(ignore_errors=True, _raw_params=None))



# Generated at 2022-06-11 11:19:38.202645
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    import ansible.constants as C
    play_context = PlayContext()
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = "127.0.0.1",
        gather_facts = "no",
        tasks = [
            dict(block=dict(
                tasks=[
                    dict(include_role=dict(
                        name="rolename",
                        apply=dict(),
                    ))
                ]
            ))
        ]
    ), variable_manager=None, loader=None)
    play.load()
    t_blocks = play._tasks
   

# Generated at 2022-06-11 11:19:42.857715
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    data = {
        'action': 'include',
        'file': 'dummy_file',
        'bad_key': 'dummy_key'
    }

    data_result = {
        'action': 'include',
        '_raw_params': 'dummy_file'
    }

    assert data_result == ti.preprocess_data(data)


# Generated at 2022-06-11 11:19:52.114539
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''Unit test for method TaskInclude.check_options'''
    t = TaskInclude()
    task = t.check_options({'action': 'include', 'file': 'blah.yml', 'bad_option': 'val'}, {'action': 'include', 'file': 'blah.yml', 'bad_option': 'val'})
    assert set(task.args.keys()) == {'_raw_params', 'bad_option'}
    assert task.args['_raw_params'] == 'blah.yml'
    assert task.args['bad_option'] == 'val'


# Generated at 2022-06-11 11:20:34.962999
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.plays import Play
    from ansible.playbook.play import PlayContext

    class TestTask(TaskInclude):
        def __init__(self, block, apply=None):
            super(TestTask, self).__init__(block=block)
            self.args = {}
            if apply:
                self.args['apply'] = apply
            self.action = 'include'

    # Include task
    task = TestTask(block=Sentinel(play=Play().load(dict(_hosts='all', gather_facts='no', vars={'var1': 'value1'}))))
    task.check_options(task, {})

    # Include task with apply