

# Generated at 2022-06-11 11:10:50.847786
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    task = Task()
    task.args = {'file': 'file_for_task'}
    task.action = 'include_role'
    task_include = TaskInclude()
    result = task_include.check_options(task, None)
    assert result is task
    assert task.args['file'] is None
    assert task.args.get('_raw_params') == 'file_for_task'
    task.action = 'import_role'
    result = task_include.check_options(task, None)
    assert result is task
    assert task.args['file'] is None

# Generated at 2022-06-11 11:11:01.547536
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()
    assert {'action': 'include_tasks', 'file': 'test.yml'} == ti.preprocess_data({'action': 'include_tasks', 'file': 'test.yml'})
    assert {'action': 'include_tasks', 'file': 'test.yml', 'test_attr': 1} == ti.preprocess_data({'action': 'include_tasks', 'file': 'test.yml', 'test_attr': 1})
    assert {'action': 'import_tasks', 'file': 'test.yml', 'test_attr': 1} == ti.preprocess_data({'action': 'import_tasks', 'file': 'test.yml', 'test_attr': 1})

# Generated at 2022-06-11 11:11:11.488132
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    import ansible.utils.unsafe_proxy as unsafe_proxy
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = dict(
        include=dict(
            stuff=AnsibleUnicode(unsafe_proxy.SafeText('foobar'))
        )
    )
    data['include']['when'] = data['include']['stuff']

    ti = TaskInclude()
    ti_data = ti.preprocess_data(data)
    assert ti_data['when'] is not None
    assert ti_data['when'] is not data['include']['when']
    assert ti_data['when'] == data['include']['when']

# Generated at 2022-06-11 11:11:12.750871
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    data = {}
    ti = TaskInclude()
    ti.preprocess_data(data)


# Generated at 2022-06-11 11:11:23.147141
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    task = TaskInclude()

    # Test raw_params
    assert task.preprocess_data({'_raw_params': 'test'})['_raw_params'] == 'test'
    assert task.preprocess_data({'_raw_params': 'test'}).get('file') is None

    # Test file
    assert task.preprocess_data({'file': 'test'})['_raw_params'] == 'test'
    assert task.preprocess_data({'file': 'test'}).get('file') is None

    # Test apply
    assert isinstance(task.preprocess_data({'apply': {'test': 'test'}}).get('apply'), dict)
    assert task.preprocess_data({'apply': 'test'})['_raw_params'] == 'test'

    # Test valid_include_key

# Generated at 2022-06-11 11:11:34.862572
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collections import is_sequence

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.verbosity = 3

    loader = DataLoader()
    inventories = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventories)
    play_context = PlayContext

# Generated at 2022-06-11 11:11:46.437668
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task import Task
    from ansible.playbook.task import TaskInclude

    def test_cases(cases):
        for c in cases:
            task = c['task']
            data = c['data']
            expected = c['expected']

            task = TaskInclude.check_options(task, data)
            for prop in task.args:
                assert getattr(task, prop) == expected[prop]

    # task_include that is not import_tasks or include_tasks won't have their options validated
    task = Task()
    task.action = 'setup'
    task.args = dict(_raw_params='foobar', apply='yes')
    data = dict(_raw_params='foobar', apply='yes')
    expected = dict(_raw_params='foobar', apply='yes')
   

# Generated at 2022-06-11 11:11:55.309586
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar

    play_context = PlayContext()
    play_context._vars_plugins = []

    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.accelerate = 0
    play_context._use_acceleration = True
    play_context.accelerate_ipv6 = False
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become

# Generated at 2022-06-11 11:12:05.562627
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    templar = Templar(loader=DataLoader())

    playbook = Play.load(dict(name='test', hosts=['localhost'], gather_facts='no',
                              roles=["testrole"]),
                              variable_manager=VariableManager(), loader=DataLoader())
    host = InventoryManager(loader=DataLoader()).get_hosts(pattern="localhost")[0]

# Generated at 2022-06-11 11:12:16.873144
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    class fake_task(object):
        def __init__(self, data):
            self.action = 'include'
            self.args = data['args']

    class fake_obj(object):
        def __init__(self, data):
            self.object = data


# Generated at 2022-06-11 11:12:32.118308
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    role = Role.load({'name': 'FakeRole', 'tasks': [{'action': 'include_tasks', 'file': 'tasks/debug.yml'}]},
                      variable_manager=VariableManager(), loader=DictDataLoader({}))


# Generated at 2022-06-11 11:12:43.162872
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor import task_queue_manager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_status import TaskStatus
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.utils.vars import combine_vars

    # Imports for Ansible 2.8
    from ansible.playbook.play import Play

# Generated at 2022-06-11 11:12:50.227072
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context._plugin_blacklist.append('action')

    task = TaskInclude()
    # no action
    data_no_action = {'invalid_option': 'whatever'}
    task_no_action = task.check_options(task.load_data(data_no_action), data_no_action)
    assert 'invalid_option' not in task_no_action.args
    # with action = include
    data_action_include = {'action': 'include', 'file': 'whatever'}
    task_action_include = task.check_options(task.load_data(data_action_include), data_action_include)
    assert 'file' not in task_action_include.args

# Generated at 2022-06-11 11:13:01.187681
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    ti_object_1 = TaskInclude()
    ti_object_2 = TaskInclude()
    ti_object_3 = TaskInclude()
    ti_object_3.action = 'include_tasks'
    ti_object_4 = TaskInclude()
    ti_object_4.action = 'include_tasks'
    ti_object_5 = TaskInclude()
    ti_object_5.action = 'include_role'
    ti_object_6 = TaskInclude()
    ti_object_6.action = 'import_playbook'

# Generated at 2022-06-11 11:13:11.095737
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    block = Block()
    task = TaskInclude(block=block)
    task.vars = dict(a=4, b=5)
    task.action = "include"
    task._parent = Block()
    task._parent.vars = dict(a=1, b=2)
    task.args = dict(c=6, d=7)
    # Method get_vars should combine vars from parent, TaskInclude and args
    assert task.get_vars() == dict(a=4, b=5, c=6, d=7)

    block = Block()
    task = TaskInclude(block=block)
    task.vars = dict(a=4, b=5)
    task.action = "import_tasks"
    task._parent = Block()

# Generated at 2022-06-11 11:13:21.825956
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.block
    import ansible.playbook.task
    from collections import namedtuple

    # Mocks
    class Mock_AnsibleParserError(Exception):
        pass

    class Mock_Task(ansible.playbook.task.Task):
        def __init__(self):
            super(Mock_Task, self).__init__()
            self.args = namedtuple('args', 'keys')
            self.args.keys = ()
            self.action = ''

    class Mock_TaskInclude():
        def __init__(self):
            self.VALID_ARGS = ()
            self.VALID_INCLUDE_KEYWORDS = ()

    # Init
    task_include = Mock_TaskInclude()
    task = Mock_Task()
    data = object()

    #

# Generated at 2022-06-11 11:13:32.660403
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile

    display = Display()
    loader = DataLoader()

# Generated at 2022-06-11 11:13:42.739571
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    context = PlayContext()
    block = Block()
    block._role = None
    block._play = None
    block._variable_manager = None
    block._loader = None
    task = TaskInclude(block)
    task._parent = block
    task._loader = None
    task._variable_manager = None
    task._role = None
    task.args = {
        'apply': {
            'name': 'test_parent_block',
            'delegate_to': 'foo',
            'tags': ['tag1', 'tag2'],
            'register': 'result',
        },
    }
    parent_block = task.build_parent_block()
    assert isinstance(parent_block, Block)

# Generated at 2022-06-11 11:13:54.060624
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    class TestRole(Role):
        pass
    class TestPlay(Play):
        pass
    task = TaskInclude.load({
        'action': 'include',
        'file': 'foo.yml',
        'apply': {
            'do-something': {
                'with_items': [1, 2, 3],
            }
        }
    }, block=None, role=None, task_include=None)
    assert isinstance(task._parent, Block)
    assert task._parent._role == None
    assert task._parent._play == None
    assert task._parent._blocks == [task]

    # Include + apply + role

# Generated at 2022-06-11 11:14:03.434471
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task_include = TaskInclude()
    task_include.args = {'a': 'a', 'b': 'b', 'c': 'c'}
    task_include._parent = Task()
    task_include._parent.get_vars = lambda: {'p': 'p'}

    # test include
    task_include.action = 'include'
    all_vars = task_include.get_vars()
    assert all_vars['a'] == 'a'
    assert all_vars['b'] == 'b'
    assert all_vars['c'] == 'c'
    assert all_vars['p'] == 'p'
    assert 'tags' not in all_vars
    assert 'when' not in all_vars
    assert 'vars' not in all_vars

    # test

# Generated at 2022-06-11 11:14:18.926972
# Unit test for method check_options of class TaskInclude

# Generated at 2022-06-11 11:14:27.766830
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    This unit test tests method build_parent_block of class TaskInclude
    '''
    import ansible
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    # args is used in method check_options
    args = {
        '_raw_params': 'file',
        'apply': {
            'block': [],
            'name': 'block_name',
            'when': 'when_clause',
            'other': 'other_clause'
        }
    }

    # add_task is used as an attribute in the returned Block object

# Generated at 2022-06-11 11:14:37.808678
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from copy import copy
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    var_manager = VariableManager()
    var_manager.set_inventory(None)

    TASK_INCLUDE_1 = {
        'apply': None,
        'file': 'some_file',
        'vars': {'var1': 'value1'},
        'action': 'include'
    }

# Generated at 2022-06-11 11:14:47.567561
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    TaskInclude.VALID_INCLUDE_KEYWORDS = Task.VALID_ATTRIBUTES.union(TaskInclude.VALID_INCLUDE_KEYWORDS)

    # 1
    apply_attrs = {'block': []}
    task_include = TaskInclude.load({'include': 'tasks/main.yml', 'apply': apply_attrs}, block=None, role=None, task_include=None)
    parent_block = task_include.build_parent_block()
    assert isinstance(parent_block, Block)

    # 2
    task_include = TaskInclude.load({'include': 'tasks/main.yml'}, block=None, role=None, task_include=None)
    parent_block = task_include.build_parent_block()

# Generated at 2022-06-11 11:14:58.029568
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude()

    ds = {
        'action': 'include_role',
        'name': 'some_name',
        'apply': {},
        'another_attr': 'pass',
    }
    # Test that preprocess_data doesn't modify original data structure
    original_ds = ds.copy()
    ti.preprocess_data(ds)
    assert original_ds == ds

    # Test valid attributes
    ds = {
        'action': 'include_role',
        'name': 'some_name',
        'apply': {},
        'another_attr': 'pass',
        'tags': 'some_tag',
        'when': 'some_condition',
    }
    new_ds = ti.preprocess_data(ds.copy())
    assert new_ds == ds

   

# Generated at 2022-06-11 11:15:03.875431
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    TaskInclude_obj = TaskInclude()
    TaskInclude_obj.set_loader(None)
    TaskInclude_obj.args = {'a': 1}
    TaskInclude_obj.action = 'include_role'

    res = TaskInclude_obj.get_vars()
    assert res['a'] == 1
    assert 'action' not in res
    assert 'role' not in res
    assert 'tags' not in res

# Generated at 2022-06-11 11:15:12.977646
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    data_valid_args = {
        'file': '/path/to/file',
        'apply': {
            'action': 'start',
        }
    }
    task = task.check_options(task.load_data(data_valid_args))
    assert hasattr(task, 'args') and task.args
    assert 'file' in task.args

    data_invalid_args = {
        'file': '/path/to/file',
        'apply': 'bad value'
    }
    try:
        task = task.check_options(task.load_data(data_invalid_args))
    except AnsibleParserError as e:
        assert 'Expected a dict for apply' in str(e)

# Generated at 2022-06-11 11:15:23.031204
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    """
    Test TaskInclude.get_vars
    """
    fake_loader = DictDataLoader({
        "vars.yml": """
        foo: 'foo'
        foo_extra: 'foo_extra'
        """,
        "include_vars.yml": """
        bar: 'bar'
        bar_extra: 'bar_extra'
        """,
    })
    fake_variable_manager = VariableManager(loader=fake_loader)
    fake_block = Block()

# Generated at 2022-06-11 11:15:33.505563
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    I don't know how to test protected methods in a class.
    So, I'll add dummy protected methods for testing
    '''
    class MockTaskInclude(TaskInclude):
        def _check_valid_options(self, ds):
            return self.check_options(self.load_data(ds), ds)
    task = MockTaskInclude()
    # file missing
    data = {'action': 'include', 'args': {'a': 'b'}}
    result = False
    try:
        task._check_valid_options(data)
    except:
        result = True
    assert result

    # file only
    data = {'action': 'include', 'args': {'file': 'blah'}}
    result = task._check_valid_options(data)
    assert result.args

# Generated at 2022-06-11 11:15:42.159904
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ds = {
        'action': 'include',
        'file': '/tmp/foobar',
    }
    ti = TaskInclude()
    ds = ti.preprocess_data(ds) # preprocess_data is supposed to mutate ds
    assert ds == {
        'action': 'include',
        'file': '/tmp/foobar',
        '_raw_params': '/tmp/foobar',
    }

    ds = {
        'action': 'import_tasks',
        'file': '/tmp/foobar',
    }
    ti = TaskInclude()
    ds = ti.preprocess_data(ds) # preprocess_data is supposed to mutate ds

# Generated at 2022-06-11 11:15:53.303269
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude

    assert TaskInclude.check_options(TaskInclude(), {'action': 'include', 'file': 'somefile'}) is not None

    assert TaskInclude.check_options(TaskInclude(), {'action': 'import_role', 'name': 'somefile'}) is not None

    assert TaskInclude.check_options(TaskInclude(), {'action': 'include', 'apply': 'somefile'}) is not None



# Generated at 2022-06-11 11:16:01.174403
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.include import TaskInclude
    from ansible.vars.manager import VariableManager

    test_play = Play().load({
        'name': 'task include test',
        'hosts': ['some_host'],
        'roles': [
            {
                'name': 'some_role',
                'include': {
                    'name': 'some_role',
                    'apply': {
                        'hosts': 'some_host',
                        'tags': ['some_tag']
                    }
                }
            }
        ]
    }, variable_manager=VariableManager(), loader=None)

    # Test using an IncludeRole
    ir

# Generated at 2022-06-11 11:16:09.980413
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import sys
    import os
    import tempfile
    import textwrap

    try:
        from unittest import mock
    except ImportError:
        # Python 2 import
        import mock

    path = os.path.join(tempfile.mkdtemp(), 'test_check_options.yaml')
    with open(path, 'w') as f:
        f.write(textwrap.dedent('''
        # Python 3 import
        from unittest import mock

        - name: test
          include: test.yaml
        '''))

    # First we need to import the original modules to be sure that
    # the mocked ones will be used later
    from ansible.parsing import loader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 11:16:19.070971
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # validates bad options. This test checks the method check_options()
    # of TaskInclude class.
    base_attrs = {'action': 'include', 'args': {}}

# Generated at 2022-06-11 11:16:28.492069
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.block import Block

    d = dict(
        include = 'my_include',
        include_tasks = 'my_include_tasks',
        import_role = 'my_import_role',
        import_tasks = 'my_import_tasks',
    )

    for k in list(d):
        ti = TaskInclude()
        b = Block(task_include=ti)
        ti._parent = b

        new_ti = ti.preprocess_data({k: d[k], 'loop': 'my_loop'})
        assert new_ti[k] == d[k]
        assert 'loop' not in new_ti

    # test empty
    ti = TaskInclude()
    b = Block(task_include=ti)
    ti._parent = b

    assert ti.pre

# Generated at 2022-06-11 11:16:37.483889
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    ti = TaskInclude()
    assert 'args' not in ti.check_options(
        TaskInclude.load(dict(file='file.yaml', action='include_role')),
        dict(file='file.yaml', action='include_role')
    ).args
    assert 'args' in ti.check_options(
        TaskInclude.load(dict(file='file.yaml', action='include_role', args=True)),
        dict(file='file.yaml', action='include_role', args=True)
    ).args
    assert 'args' in ti.check_options(
        TaskInclude.load(dict(file='file.yaml', action='include_role', args=dict())),
        dict(file='file.yaml', action='include_role', args=dict())
    ).args




# Generated at 2022-06-11 11:16:46.988352
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    fixture = dict(
        file='some/include',
        apply=dict(
            some_block_attribute=1,
            another_block_attribute='some_string_value'
        )
    )

    task = TaskInclude.load(fixture)

    assert task.args.get('file') == 'some/include'
    assert task.args.get('_raw_params') == 'some/include'
    assert isinstance(task.args.get('apply'), dict)
    assert task.args['apply'].get('some_block_attribute') == 1
    assert task.args['apply'].get('another_block_attribute') == 'some_string_value'
    assert isinstance(task.block, Block)
    assert isinstance(task, Task)
    assert isinstance(task, TaskInclude)

# Generated at 2022-06-11 11:16:56.917706
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.block import Block

    task_include = TaskInclude()
    task = TaskInclude.load({"action": "include_tasks", "_raw_params": "dummy_file.yml", "apply": {"block": []}}, block=None, role=None, task_include=None)

    expected_task_attributes = {'action': "include_tasks", "_raw_params": "dummy_file.yml", "apply": {"block": []}, 'tags': set(), 'when': []}
    expected_task_args = {'file': None, '_raw_params': 'dummy_file.yml', 'apply': {'block': []}}
    expected_block_args = {'block': []}

# Generated at 2022-06-11 11:17:07.167877
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    test_parent_vars = {'a': 'aa', 'b': 'bb'}
    test_task_vars = {'task_a': 'task_aa', 'task_b': 'task_bb'}

    # test action include
    test_task = TaskInclude()
    test_task._parent = TestParent(test_parent_vars)
    test_task.vars = test_task_vars
    test_task.args = {'_raw_params': 'test_file', 'apply': 'test_apply'}
    test_task_args = test_task.args
    test_task_args['a'] = 'aa'
    test_task_args['b'] = 'bb'
    test_task_args['task_a'] = 'task_aa'

# Generated at 2022-06-11 11:17:18.203843
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible import context
    from ansible.vars.manager import VariableManager

    context._init_global_context(play_context=PlayContext())
    ti = TaskInclude()
    ti._role = object()
    setattr(ti._role, 'get_default_vars', lambda: {'a': 0})
    ti._play = object()
    ti._play.get_variable_manager = lambda: VariableManager()
    ti.vars = { 'b': 1 }
    ti.args = { 'c': 2 }
    ti.action = 'include'
    assert ti.get_vars() == {'a': 0, 'b': 1, 'c': 2}
    ti.action = 'include_role'
    assert ti.get_vars()

# Generated at 2022-06-11 11:17:30.766954
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t_include = TaskInclude()
    t_include.args = {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'}
    t_include.action = 'include'

    # Empty parent task
    assert t_include.get_vars() == {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'}

    # parent task with 'tags' and 'when'
    t_include._parent = Task()
    t_include._parent.vars = {'tags': 'some tags', 'when': 'some condition'}


# Generated at 2022-06-11 11:17:40.298046
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.variable import Variable
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.splitter import parse_kv

    # Build a fake include task
    block = Block()
    block.vars = dict(foo='bar')
    task_include = TaskInclude()
    task_include.set_parent(block)
    task_include.args = dict()

    # Build a fake play that extract host and group vars
    play_context = Play

# Generated at 2022-06-11 11:17:51.585368
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test load with file
    data = dict(
        action="debug",
        file="foo.yaml",
    )
    task = TaskInclude.load(data)
    assert task._attributes['action'] == "debug"
    assert task.args['_raw_params'] == "foo.yaml"

    # Test load with content
    data = dict(
        action="debug",
        content="foo: bar",
    )
    task = TaskInclude.load(data)
    assert task._attributes['action'] == "debug"
    assert task.args['_raw_params'] == "foo: bar"

    # Test load with apply

# Generated at 2022-06-11 11:17:59.016138
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # In this example the the var "foo" of the include gets used by the include but
    # not by the include_tasks
    host_vars = {'foo': 'bar', 'baz': 'bra'}
    play = dict(
        host_vars=host_vars,
        tasks=[
            dict(
                action='include',
                file='test.yml',
                foo='bar'
            ),
            dict(
                action='include_tasks',
                file='tasks.yml',
                foo='bar'
            )
        ]
    )
    block = Block.load(play, task_include=None)
    block.post_validate(play=play)
    include = block.block
    assert include.args['foo'] == 'bar'

# Generated at 2022-06-11 11:18:08.660554
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.handlers.task_include import HandlerTaskInclude
    # Init
    ti = TaskInclude()
    hti = HandlerTaskInclude()
    # Test loading of task include
    data = dict(
        file='foo',
        include='bar',
        name='baz',
    )
    ti.load(data)
    # Test loading of handler task include
    data['notify'] = 'baz'
    hti.load(data)
    # Test bad args
    with pytest.raises(AnsibleParserError) as e:
        ti.check_options(dict(action='include_tasks', args=dict(file="foo", bar="baz")), data)
    assert 'Invalid options for include_tasks' in e.value.message
    # Test apply not dict
   

# Generated at 2022-06-11 11:18:18.518390
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.utils.vars import combine_vars

    # setup

# Generated at 2022-06-11 11:18:24.978517
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    def _variable_manager_constructor(loader):
        variable_manager = VariableManager()

# Generated at 2022-06-11 11:18:33.076895
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude, HandlerTaskInclude

    def _assert_load(task, data):
        t = TaskInclude.load(data, task_include=task, role=None)
        assert isinstance(t, TaskInclude)
        assert t.action == 'include'
        assert t.args['_raw_params'] == 'foo.yaml'
        assert t.args['ignore_errors'] is False


# Generated at 2022-06-11 11:18:41.241951
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    import copy
    import sys

    display.verbosity = 3
    display.deprecated_warning = False

    class Fake_action:
        def __init__(self):
            self.name = None
        def __contains__(self, item):
            return False
    class Fake_class():
        def __init__(self):
            self.action = Fake_action()
            self.statically_loaded = False

    a = Fake_class()
    a.preprocess_data = TaskInclude.preprocess_data.__func__
    ds = {'a': '1', 'b': '2'}
    a.action.name = 'include'
    a_copy = copy.deepcopy(a)
    a.preprocess_data(ds)
    assert a_copy.__dict__ == a.__dict__

# Generated at 2022-06-11 11:18:49.204254
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # Initialize some test data
    load = dict(
        action='include',
        file='file.yml',
        _raw_params='file.yml',
        other_option='bla'
    )

    # Run get_vars
    ti = TaskInclude()
    ti.load_data(load, variable_manager=None, loader=None)
    vars = ti.get_vars()

    # Initialize expected result
    expected_vars = {
        'file':'file.yml',
        'other_option':'bla',
        '_raw_params': 'file.yml'
    }

    # Assert result
    assert vars == expected_vars

# Generated at 2022-06-11 11:19:33.211321
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Test method build_parent_block of class TaskInclude for two cases:
    1. apply_attrs is empty
        return self
    2. apply_attrs is not empty
        create parent block and return it
    '''
    from ansible.playbook.block import Block
    ti = TaskInclude()
    ti.set_loader(None)
    ti.set_variable_manager(None)
    ti.set_parent('parent')
    ti.set_play('play')
    ti.set_role('role')
    apply_attrs = {'name': 'test', 'apply': {}}
    ti.args.update(apply_attrs)
    assert ti.apply_attrs == {}
    assert ti.build_parent_block() is ti

# Generated at 2022-06-11 11:19:39.075466
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    import ansible.playbook.role
    task_include_inst = TaskInclude()
    task_inst = task_include_inst.check_options(
        task_include_inst.load_data(
            {'action': 'include_role', 'name': 'test', 'apply': {'tags': ['test']}}),
        {'action': 'include_role', 'name': 'test', 'apply': {'tags': ['test']}}
    )

    assert task_inst.args['apply']['tags'] == ['test']

# Generated at 2022-06-11 11:19:48.062214
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    class FakeLoader:
        def __init__(self):
            self.get_basedir = lambda x: ''
    class FakeVariableManager:
        def __init__(self):
            self.extra_vars = dict()
            self.options = dict()
            self.defaults = dict()
    class FakePlay:
        def __init__(self):
            self.name = 'fake'
            self.role = None
            self.connection = None
            self.vars = {}
            self.extra_vars = {}
            self.get_variable_manager = lambda: x
    class FakeRole:
        def __init__(self):
            self.vars = {}
            self.get_variable_manager = lambda: x
    my_loader = FakeLoader()
    my_play = FakePlay()
    my_role

# Generated at 2022-06-11 11:19:57.242741
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    This method tests that method get_vars of class TaskInclude
    returns expected vars
    TODO: replace this unit test with pytest, currently it
    is the only way I found to test ansible code easily
    '''

    task_include = TaskInclude()
    task_include.action = 'include'
    task_include.args = {'a': 1}
    if task_include.get_vars() != {'a': 1}:
        raise AssertionError('test_get_vars failed, '
                             'it should not return parent vars')

    task_include.action = 'import_playbook'
    task_include.args = {'a': 1}

# Generated at 2022-06-11 11:20:05.806005
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class DummyTask(TaskInclude):
        def __init__(self, **kwargs):
            super(DummyTask, self).__init__()
        def get_vars(self):
            return super(DummyTask, self).get_vars()

    # action is not include
    task = DummyTask()
    task.args = {"a": 1}
    task._parent = TaskInclude()
    task._parent.vars = {"b": 2}
    assert task.get_vars() == {"a": 1, "b": 2}

    # parent.block is destroyed
    task = DummyTask()
    task.args = {"a": 1}
    task.action = "static_include"
    task._parent = TaskInclude()
    task._parent.action = "include"

# Generated at 2022-06-11 11:20:15.015381
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role_include import RoleInclude
    from ansible.plugins import module_loader
    from ansible.vars import VariableManager

    play1 = Play()
    role1 = IncludeRole()
    block1 = Block()
    task1 = TaskInclude()
    block1._parent = play1
    block1._role = role1
    task1._parent = block1
    task1._role = role1
    role1.name = "test_role"
    role1._parent = role1

    play1._variable_manager = VariableManager()
    play1._variable_manager

# Generated at 2022-06-11 11:20:25.707493
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display = Display()
    display.display('ignored', color='yellow')

    task_include = TaskInclude()
    # test with valid options
    options = dict(
        action=Sentinel(),
        args=Sentinel(),
        collections=Sentinel(),
        debugger=Sentinel(),
        debug_strategy=Sentinel(),
        ignore_errors=Sentinel(),
        loop=Sentinel(),
        loop_control=Sentinel(),
        loop_with=Sentinel(),
        name=Sentinel(),
        no_log=Sentinel(),
        register=Sentinel(),
        run_once=Sentinel(),
        tags=Sentinel(),
        timeout=Sentinel(),
        vars=Sentinel(),
        when=Sentinel(),
    )

# Generated at 2022-06-11 11:20:34.589230
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import os
    import copy
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar

    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager


    context = PlayContext()
    context._set_vars_files_result = {'test_host': {'test_host': 'test_host'}}
    context.set_vars_result = {'test_host': {'test_host': 'test_host'}}
    context.current_host = 'test_host'
    context.remote_addr = 'test_host'
    context.hostvars = {'test_host': {'test_host': 'test_host'}}