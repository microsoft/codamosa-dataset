

# Generated at 2022-06-11 11:10:52.115125
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    
    ds = {'a': 1, 'when': 'b'}
    play = Play.load(ds, variable_manager=None, loader=None)
    b = Block(parent_block=play)
    task = TaskInclude.load(ds, block=b)
    task.preprocess_data(ds)

    assert ds == {'a': 1, 'when': 'b'}

    ds = {'a': 1, 'when': 'b', 'role': 'c'}
    play = Play.load(ds, variable_manager=None, loader=None)
    b = Block(parent_block=play)
    task = RoleIn

# Generated at 2022-06-11 11:11:03.262519
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    hostvars = HostVars(loader=loader, variable_manager=inventory._variable_manager, hostname='127.0.0.1')
    host = Host(name='127.0.0.1')
    host.set_

# Generated at 2022-06-11 11:11:13.531212
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
  t = TaskInclude()
  t.args = {'arg1' : 'value1', 'arg2' : 'value2'}
  t.vars = {'var1' : 'value1', 'var2' : 'value2'}
  t.action = 'include'
  assert t.get_vars() == {'arg1' : 'value1', 'arg2' : 'value2', 'var1' : 'value1', 'var2' : 'value2'}
  t.action = 'import_role'
  assert t.get_vars() == {'arg1' : 'value1', 'arg2' : 'value2'}
  t._parent = TaskInclude()
  t._parent.vars = {'var1' : 'value1', 'var2' : 'value2'}

# Generated at 2022-06-11 11:11:20.437275
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    block_vars = {'block': None}
    p_block = TaskInclude.load({'action': 'include',
                                'apply': block_vars},
                               block=None, role=None,
                               task_include=None).build_parent_block()
    assert isinstance(p_block, TaskInclude)
    assert isinstance(p_block._block, Block)
    assert block_vars['block'] == p_block._block._attributes['block'], "Block not created"

# Generated at 2022-06-11 11:11:32.172014
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    class MockRole():
        def __init__(self, role=None):
            self.name = role

    class MockPlay():
        def __init__(self, name=None, hosts=None, roles=[]):
            self.name = name
            self.hosts = hosts
            self.roles = roles


# Generated at 2022-06-11 11:11:37.801273
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    ti = TaskInclude(block=None, role=None, task_include=None)
    ds = {'action': 'include_tasks', 'name': 'name', 'foo': 'bar'}
    ds = ti.preprocess_data(ds)
    assert ds == {'action': 'include_tasks', 'name': 'name'}
    assert 'foo' not in ds

# Generated at 2022-06-11 11:11:49.316834
# Unit test for method load of class TaskInclude

# Generated at 2022-06-11 11:11:56.856960
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role

    # Setup play
    play_ds = dict(name='setup')
    play_ds['tags'] = ['setup']
    play_ds['connection'] = 'local'
    play_ds['gather_facts'] = 'no'

    play_obj = ansible.playbook.play.Play.load(play_ds)

    # Setup tasks
    task_include_ds = dict(action='include_tasks')
    task_include_ds['file'] = '../../library/actual/conftest'

    task_include = ansible.playbook.task.TaskInclude.load(task_include_ds)
    task_include._play = play_obj
    task_include._play._parent = None

# Generated at 2022-06-11 11:12:07.184254
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import sys, os
    import json

    # Get the path of the ansible-playbook script
    ansible_playbook_path = sys.argv[0]
    ansible_playbook_path = os.path.realpath(ansible_playbook_path)
    ansible_playbook_path = os.path.dirname(ansible_playbook_path)

    # Get the path of the testing playbook
    test_playbook_path = os.path.join(ansible_playbook_path, "..", "test", "static", "test_include_vars.yml")

    # Get the path of the python-yaml package (for yaml.dump)

# Generated at 2022-06-11 11:12:18.536983
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import get_all_plugin_loaders, find_plugin

    loader = DataLoader()
    variable_manager = VariableManager()

    ti = TaskInclude()
    ti._variable_manager = variable_manager
    ti._loader = loader

    # test build_parent_block() with None apply
    ti.args = dict(apply=None)
    assert ti.action in ["include_tasks", "include_role", "import_role"]
    result = ti.build

# Generated at 2022-06-11 11:12:32.753397
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import collections
    import sys
    import inspect
    import ansible.playbook.task_include

    test_cases = collections.namedtuple('task_include_get_vars_test_cases', ('fact_vars', 'parent_vars', 'task_vars', 'action', 'expect'))


# Generated at 2022-06-11 11:12:43.844137
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()

# Generated at 2022-06-11 11:12:47.134605
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    ds = {'action': 'include', 'args': {'var_inc': 'inc'}}
    TaskInclude.load(ds)
    all_vars = TaskInclude.load(ds).get_vars()
    assert all_vars == {'var_inc': 'inc'}, 'incorrect vars for TaskInclude: %s' % all_vars

# Generated at 2022-06-11 11:12:57.482985
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    import ansible.playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, lookup_loader

    vault_pass = 'secret'
    vault_id = 'vaultID'
    vault_file = '/tmp/vault_pass.txt'
    with open(vault_file, 'w') as f:
        f.write(vault_pass)

    vault_hash = VaultLib(vault_id, vault_file, vault_pass).encrypt('mypass')

# Generated at 2022-06-11 11:13:08.344548
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import C
    # pylint: disable=protected-access

    # Test case: Invalid task attribute
    task_include = TaskInclude()
    data_dict = {'action': 'include_role', 'foo': 'bar'}
    data_dict_expected = data_dict.copy()
    data_dict_expected.update({'INVALID_ATTRIBUTE_FAILED': True})
    task_include.preprocess_data(data_dict)
    assert data_dict == data_dict_expected

    # Test case: Invalid task attribute, but ignore_errors is set
    task_include = TaskInclude()

# Generated at 2022-06-11 11:13:16.624824
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # Prepare the test data
    #
    # The keys of dictionary 'options' are the names of arguments,
    # and the values are the values of the arguments;
    # The key of the dictionary 'data' is 'options', the value of which is the
    # dictionary 'options'.
    apply_dict = {u'y': u'1'}
    options = {u'_raw_params': u'tests/test_include.yml', u'apply': apply_dict}
    options_with_unknown = {u'_raw_params': u'tests/test_include.yml', u'apply': apply_dict, u'unknown': None}

    # Create a TaskInclude object 'ti'
    ti = TaskInclude()

    # Test the 'check_options' method
    #
    # With known arguments and 'action' being

# Generated at 2022-06-11 11:13:28.428395
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.block import Block
    from ansible.playbook.task.include import TaskInclude
    from ansible.plugins.loader import action_loader

    task_include_file = TaskInclude()

    action_loader.get('include')._load_attr_module('include')
    task = action_loader.get('include')()
    task.action = 'include'

    task.args = {}
    task.args['name'] = 'Name'
    # Should not raise an Exception
    task = task_include_file.check_options(task, 'include')

    task.args = {}
    task.args['name'] = 'Name'
    task.args['bad-opt'] = 'opt-value'
    # Should raise an Exception

# Generated at 2022-06-11 11:13:32.330163
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    t = TaskInclude()
    t.action = 'include'
    t.args = {'a': 'A', 'b': 'B'}

    v = t.get_vars()

    assert v['a'] == 'A'
    assert v['b'] == 'B'

# Generated at 2022-06-11 11:13:39.429049
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from AnsibleModule import AnsibleModule
    from ansible.playbook.play import Play
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.display import Display
    from ansible.plugins.loader import variable_manager

    ti = TaskInclude()
    ti._role = None
    ti._loader = Sentinel()
    var_mgr = variable_manager()
    var_mgr.extra_vars = {"test_var_1": "test_value_parent", "test_var_2": "test_value_parent"}
    var_mgr.options_vars = {"test_var_3": "test_value_parent"}
    var_mgr.host_vars = {"test_host_1": {"test_var_4": "test_value_1"}}

# Generated at 2022-06-11 11:13:51.182181
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # no apply attributes
    task=TaskInclude(block=None, role=None, task_include=None)
    task.action='include'
    task.args={'a': 'a', 'b': 'b', 'c': 'c'}
    task.tags=['t1', 't2']
    task.when='t3'
    task.block=None
    task._role=None
    task._play=None
    task._variable_manager=None
    task._loader=None
    task.statically_loaded = False
    task.action='include'
    block1=Block(block=None, role=None, task_include=None)
    block1._parent=None

# Generated at 2022-06-11 11:14:08.236487
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.helpers
    import ansible.playbook.conditional
    from ansible.utils.vars import combine_vars

    pb = ansible.playbook.Playbook()
    play_ds = dict(
        name="test_playbook_name",
        hosts="localhost",
        gather_facts=False,
        become=False,
        roles=[],
        vars={},
        tasks=[],
    )
    play = ansible.playbook.Play().load(
        play_ds,
        variable_manager=pb._variable_manager,
        loader=pb._loader,
    )

# Generated at 2022-06-11 11:14:18.316332
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    my_play = Play().load({
        'name': 'foobar',
        'hosts': 'all',
    })


# Generated at 2022-06-11 11:14:27.239156
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import pytest

    # Variables
    vars1 = {
        'a': True,
        'b': 'test_value_b'
    }

# Generated at 2022-06-11 11:14:37.229891
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    Validate method check_options of class TaskInclude
    '''
    from ansible.playbook.task_include import TaskInclude

    # Check that options are validated correctly
    good_data = {
        'apply': {},
        'file': 'test.yml',
    }

    # Check that invalid options are flagged correctly
    bad_opt_data = {
        'foo': 'bar',
        'file': 'test.yml',
    }

    # Check that missing file option is flagged correctly
    no_file_data = {
        'apply': {},
    }

    # Check that apply option is validated correctly
    bad_apply_type_data = {
        'apply': [],
        'file': 'test.yml',
    }

    # Check that 'action' and 'args' options

# Generated at 2022-06-11 11:14:47.272995
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager._fact_cache = dict(foo='bar')
    variable_manager.options_vars = dict()

# Generated at 2022-06-11 11:14:56.462984
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_host_variable('hostname', {'my_var': 'my_value'})
    variable_manager.set_host_variable('hostname', {'foo': 'bar'})

    task = TaskInclude.load(
        dict(
            file = 'include-tasks.yml',
            vars = {'var1': 'value1'},
        ),
        variable_manager=variable_manager,
        loader=None
    )

    assert task.get_vars() == dict(my_var='my_value', var1='value1', file='include-tasks.yml')



# Generated at 2022-06-11 11:15:06.579068
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    '''
    This method tests check_options method, which is
    used by load and load_data methods, for proper
    error raising and validation.
    '''
    import ansible.playbook.block
    import ansible.playbook.task
    # Base class for task include - Task
    task = ansible.playbook.task.Task(block=ansible.playbook.block.Block())

    action = 'include'

    # Load should not raise error with default args
    task = TaskInclude.check_options(task, {'action': action})

    # Validate valid args
    invalid_opts = ('foo', 'bar')
    task = TaskInclude.check_options(task, {'action': action, 'args': dict(zip(invalid_opts, range(2)))})

# Generated at 2022-06-11 11:15:16.286276
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # test with no apply
    block = Block()
    task_include = TaskInclude()
    task_include.block = block

    task_include.args = {}

    p_block = task_include.build_parent_block()
    assert p_block == block

    # test with apply
    block = Block()
    task_include = TaskInclude()
    task_include.block = block

    apply_attrs = {'block': []}
    task_include.args = {'apply': apply_attrs}

    p_block = task_include.build_parent_block()
    assert p_block.block == apply_attrs['block']
    assert p_block.args == apply_attrs
    assert p_block.block == task_include.block

# Generated at 2022-06-11 11:15:26.371558
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()

    # basic test - check valid options
    data = dict(action='include_tasks', apply='test_value', _raw_params='test_file')
    task.check_options(task.load_data(data, variable_manager=None, loader=None), data)
    assert isinstance(task.args['apply'], dict)
    assert task.args['apply']['block'] == []

    # options of '_raw_params' and 'file' should be the same
    task.args['_raw_params'] = 'test_file'
    task.args.pop('file', None)
    task.check_options(task, data)
    assert task.args['_raw_params'] == task.args['file']

    # make sure 'apply' option is the only one possible with the action '

# Generated at 2022-06-11 11:15:36.472996
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import HandlerTaskInclude

    play = Play.load(dict(
        name="test",
        hosts=["all"],
    ), variable_manager=None, loader=None)
    role1 = RoleDefinition.load(dict(
        name="role1",
        include_role=dict(),
        include_tasks=dict(),
        include_vars=dict(),
    ), play=play, variable_manager=None, loader=None)

# Generated at 2022-06-11 11:15:53.782244
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    p = Play().load({
        'name': 'test',
        'hosts': 'all',
        'roles': [
            {'include': 'role1'},
        ]
    }, variable_manager=PlayContext().set_options(), loader=False)

    i = InventoryManager(loader=False).load_inventory([
        {'hosts': ['1']},
    ])

    r = p.get_roles()[0]
    r._role_params = None
    t = r.get_tasks()[0]
    t.load_args(include='task1.yml', foo='bar')
    t.block = Block()
    t

# Generated at 2022-06-11 11:16:01.707582
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.handlertask import HandlerTaskInclude
    # Valid calls
    for task_class in (TaskInclude, HandlerTaskInclude):
        task_class.check_options(TaskInclude.load({
            'action': 'include',
            'file': 'foo.yaml',
        }), {})
        task_class.check_options(TaskInclude.load({
            'action': 'import_tasks',
            'file': 'foo.yaml',
        }), {})
        task_class.check_options(TaskInclude.load({
            'action': 'import_playbook',
            'file': 'foo.yaml',
        }), {})

# Generated at 2022-06-11 11:16:10.564903
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import TaskVars, ModuleVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 11:16:19.693509
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.plugins.loader import connection_loader

    my_task = TaskInclude()
    my_task._role = None
    my_task._loader = None
    my_task.action = 'include_tasks'
    my_task._parent = Block()
    my_task._parent._play = Play()
    my_task._parent._play.connection = 'local'
    my_task._parent._play.name = 'none'
    my_task._parent._play._basedir = 'none'
    my_task._parent._play._DS = {}
    my_task._parent._play.vars = {}
    my_task._parent._play.v

# Generated at 2022-06-11 11:16:29.092897
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block()
    # Define loader and variable manager to satisfy some checks in load method
    loader = DataLoader()
    variable_manager = VariableManager()
    # Define task include data
    data = {'action': 'include', 'args': {'file': 'include.yml'}}
    task_include = TaskInclude.load(data=data, block=block, variable_manager=variable_manager, loader=loader)

    assert task_include.args['file'] == 'include.yml', \
        "Error loading 'file' from task include data"

# Generated at 2022-06-11 11:16:38.133233
# Unit test for method preprocess_data of class TaskInclude
def test_TaskInclude_preprocess_data():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    r_playbook = Playbook()
    r_play = Play().load(
        {'name': 'r_play'},
        r_playbook,
        loader=loader,
    )
    r_play._tqm = None
    r_play._variable_manager = VariableManager()
    r_play._variable_manager._fact_cache = dict()
    r_block = Block()
    r_block._play = r_play
    r_block.vars = dict()
    r_

# Generated at 2022-06-11 11:16:47.712605
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    def assertBlock(block_attrs, apply_attrs):
        block_attrs['block'] = []
        block_attrs.pop('apply', None)
        apply_attrs.pop('block', None)
        p_block = TaskInclude.load({
            'action': 'include',
            'args': apply_attrs,
        }, None, None, None, None, None).build_parent_block()
        assert p_block._attributes == block_attrs

    for apply_attrs in [{}, {'block':None}]:
        assertBlock(apply_attrs, apply_attrs)


# Generated at 2022-06-11 11:16:57.689457
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''Unit test for method get_vars of class TaskInclude'''
    def get_vars(task, parent_task=None, parent_block=None, role=None):
        '''Helper method to test TaskInclude.get_vars()'''
        task.block = parent_block
        task._parent = parent_task
        task._role = role
        return task.get_vars()

    file_name = '/etc/settings/main.yml'
    task = TaskInclude()
    # test for action not in C._ACTION_INCLUDE
    task.action = 'include_role'
    task.vars = {
        'name': 'bob',
        'age': 30,
    }
    task.args = dict()


# Generated at 2022-06-11 11:17:07.689586
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    from ansible.playbook.task_include import HandlerTaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    task_vars = dict()
    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=C.ansible_version_info(gitinfo=False))
    fake_play = Play.load({
        'name': 'test',
        'hosts': 'localhost'
    }, variable_manager=variable_manager, loader=loader)

    # TaskInclude

# Generated at 2022-06-11 11:17:19.063677
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task = TaskInclude()
    good_options = {
        'file': 'another_task.yml'
    }
    task.check_options(task, good_options)

    with_apply = {
        'file': 'another_task.yml',
        'apply': 'foo'
    }
    with pytest.raises(AnsibleParserError):
        task.check_options(task, with_apply)
    with_apply['apply'] = {'foo': 'bar'}
    task.check_options(task, with_apply)

    bad_options = {
        'foo': 'bar',
        'file': 'another_task.yml'
    }
    with pytest.raises(AnsibleParserError):
        task.check_options(task, bad_options)

# Generated at 2022-06-11 11:17:46.245911
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    '''
    Test for TaskInclude() method get_vars, given a parameter
    '''
    task = TaskInclude()
    assert task.get_vars() == {}
    all_vars_dict = {'var1': {'key1': 'value1', 'key2': 'value2'}, 'var2': 'value3', 'var3': {'key3': 'value3', 'key4': 'value4'}}
    task.vars = all_vars_dict
    assert task.get_vars() == all_vars_dict

    task.action = 'include'

# Generated at 2022-06-11 11:17:56.229216
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    # this class exists only to make the data loadable without raises (https://github.com/ansible/ansible/issues/19263)
    class TestTaskInclude(Task):
        action = 'include'
    task = TestTaskInclude(block=None, role=None, task_include=None)
    # test valid options
    data = {'file': 'test_file'}
    new_task = task.check_options(task.load_data(data), data)
    assert new_task.args['_raw_params'] == 'test_file'
    data = {'file': 'test_file', 'other_opt': 'other_val'}
    # test fallback

# Generated at 2022-06-11 11:18:05.359836
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    play_data = {
        'name': 'test',
        'hosts': "localhost",
        'tasks': [
            {'include': {'file': 'nonexistent.yml'}}
        ]
    }
    play_tasks = play_data['tasks']
    play = Play().load(
        play_data,
        variable_manager=None,
        loader=None
    )

    for task_data in play_tasks:
        for key, value in task_data.items():
            task = TaskInclude.load(value, task_include=task_data)
    p_task = play.get_vars()
    result = 'file' == p_task.keys()[0]
    assert result



# Generated at 2022-06-11 11:18:08.264218
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    '''
    Unit test for method build_parent_block of class TaskInclude
    '''
    task = TaskInclude()
    result = task.build_parent_block()
    assert result is not None

# Generated at 2022-06-11 11:18:14.630434
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    mock_object = TaskInclude()
    mock_object.action = 'include'
    def mock_get_vars():
        return {'a': 1}
    mock_object.get_vars = mock_get_vars

    value = mock_object.get_vars()
    assert value == {'a': 1}

    mock_object.action = 'include_role'
    value = mock_object.get_vars()
    assert value == {'a': 1}

# Generated at 2022-06-11 11:18:22.711470
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    variable_manager = VariableManager()
    loader = DataLoader()
    display.verbosity = 3

    ti_task_include = TaskInclude(block=None, role=None, task_include=None)
    ti_task_include.action = 'include'
    ti_task_include.args = dict(dest="{{dest}}", src="{{src}}")
    ti_task_include.vars = dict(dest="/etc/hosts", src="/etc/hosts.bak")
    ti_task_include._loader = loader
    ti_task_include._variable_manager = variable_manager
    retval = ti_task_include.get_vars()
    print(retval)
    assert retval == {'dest': '/etc/hosts', 'src': '/etc/hosts.bak'}

    ti_task

# Generated at 2022-06-11 11:18:29.940846
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    c = PlayContext()
    p = Play().load({'name': 'foo', 'hosts': 'all',
                     'gather_facts': 'no',
                     'tasks': [{'name': 'bar', 'include': 'other', 'hosts': 'meh'}]},
                    variable_manager=None, loader=None)

    p._prepare_context(c)
    t = p.get_tasks()[0]

    assert t.get_vars() == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost',
                            'group_names': [], 'groups': {}}

# Generated at 2022-06-11 11:18:38.023936
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    display.verbosity = 3

    variable_manager = VariableManager()
    loader = DataLoader()

    datastream = [
      dict(
        include='some_file.yml',
        with_items='some_items.yml',
        with_dict='some_dict.yml',
      )
    ]

    pb = Play().load(datastream, variable_manager=variable_manager, loader=loader)
    play_context = PlayContext(play=pb)
    task = pb.tasks[0]

    tt = Templar(loader=loader, variables=variable_manager)

    # Test include task

# Generated at 2022-06-11 11:18:47.082148
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    mytask = TaskInclude(block=None, role=None, task_include=None)
    assert isinstance(mytask, TaskInclude)

    task_dict = {'action': 'include_role', 'args': {'_raw_params': 'role_to_include', 'apply': {}}}
    task = TaskInclude.check_options(mytask, task_dict)
    assert isinstance(task, TaskInclude)
    assert task.args['_raw_params'] == 'role_to_include'
    assert task.args.get('apply', {}) == {}

    task_dict = {'action': 'include_role', 'args': {'_raw_params': 'role_to_include', 'apply': 'apply_dict'}}
    task = TaskInclude.check_options(mytask, task_dict)


# Generated at 2022-06-11 11:18:56.065429
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    display.verbosity = 3

    task = TaskInclude()

    test_cases = [
        # test data, expected result, expected exception
        (dict(a=1, b=2, c=3, _raw_params="hello.yml"), True, False),
        (dict(a=1, b=2, c=3, _raw_params="hello.yml", apply=dict(a=1), v=1), True, False),
        (dict(a=1, b=2, c=3, _raw_params="hello.yml", apply=dict(a=1), v=1, z=1), True, True),
        (dict(a=1, b=2, c=3, _raw_params="hello.yml", apply=1), True, True),
    ]


# Generated at 2022-06-11 11:19:47.116885
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    from ansible.vars.manager import VariableManager

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader

    from units.mock.loader import DictDataLoader

    from ansible.utils.vars import combine_vars

    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 11:19:54.358626
# Unit test for method check_options of class TaskInclude
def test_TaskInclude_check_options():
    task_include = TaskInclude.load(
        dict(action='include',
             args=dict(file='my_include',
                       apply=dict(when='condition_a'))),
        None, None, None, None, None
    )
    # Checks that apply was applied as property of TaskInclude
    assert 'apply' in task_include.__dict__
    # Checks that file was transfered to _raw_params
    assert task_include.args.get('_raw_params') == 'my_include'
    # Checks that apply was poped from args
    assert 'apply' not in task_include.args

# Generated at 2022-06-11 11:20:00.469659
# Unit test for method build_parent_block of class TaskInclude
def test_TaskInclude_build_parent_block():
    # Create a Block and Task so that Task include has something to work with
    block = Block()
    task = Task()
    block.add_task(task)
    # Create TaskInclude object with a parent block
    task_include = TaskInclude(block=block)
    # Set apply dict as an include argument
    args = dict(apply={})
    task_include.args = args
    # Ensure that parent block has the same arguments as apply
    assert task_include.build_parent_block().args == args
    # Ensure that TaskInclude has no more arguments
    assert not task_include.args

# Generated at 2022-06-11 11:20:08.176576
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    task = TaskInclude()
    task.args = {"some_arg": "some_value"}
    assert task.get_vars() == {}

    task.action = "include"
    assert task.get_vars() == {"some_arg": "some_value"}

    block = Block()
    block.vars = {"some_var": "some_value"}
    task._parent = block
    assert task.get_vars() == {"some_var": "some_value", "some_arg": "some_value"}

    task.vars = {"some_var": "some value"}
    assert task.get_vars() == {"some_var": "some value", "some_arg": "some_value"}

# Generated at 2022-06-11 11:20:17.453069
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    # ACTIONS = [INCLUDE, IMPORT_TASKS]
    # this test will fail if we exclude 'include' from ACTIONS in TaskInclude.get_vars
    ACTIONS = C._ACTION_ALL_INCLUDE_IMPORT_TASKS

    # create test tasks with file as attr, ansible-playbook
    # requires that this attribute exists so check that our task
    # will not break when used by ansible-playbook
    tasks = [TaskInclude(action=a, file='file') for a in ACTIONS]
    tasks[0].args['_raw_params'] = 'raw_params'
    tasks[0].vars = {'vars': 'vars'}
    tasks[0].args['args'] = {'args': 'args'}
    assert len(tasks) == len(ACTIONS)

# Generated at 2022-06-11 11:20:28.644165
# Unit test for method load of class TaskInclude
def test_TaskInclude_load():
    # Test TaskInclude when 'file' is specified
    module_path = '/test/module'
    file = 'tasks/test_task.yml'
    params = {
        'action': 'include',
        'file': file
    }
    load_data = Task.load_data(params)
    task = TaskInclude.load(load_data)
    assert task.action == 'include'
    assert task.args.get('_raw_params') == module_path + '/' + file

    # Test TaskInclude when '_raw_params' is specified
    module_path = '/test/module'
    _raw_params = module_path + '/tasks/test_task.yml'
    params = {
        'action': 'include',
        '_raw_params': _raw_params
    }


# Generated at 2022-06-11 11:20:36.562369
# Unit test for method get_vars of class TaskInclude
def test_TaskInclude_get_vars():
    import ansible.playbook
    from ansible.template import Templar

    p = ansible.playbook.Play()
    play_vars = ansible.playbook.Play.load(dict(
        name="test",
        hosts="all",
        gather_facts="no",
        vars=dict(
            a=42,
            b="hello world",
        ),
    ))

    ti = TaskInclude(block=p, role=None, task_include=None)
    ti.vars = dict(
        x="hello",
        y=dict(
            a=1,
            b=2,
        ),
    )

    ti.args = dict(
        x="world",
        y=dict(
            c=3,
            d=4,
        ),
    )

    # testing action 'include