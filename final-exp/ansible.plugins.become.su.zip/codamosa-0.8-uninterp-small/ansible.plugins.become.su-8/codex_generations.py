

# Generated at 2022-06-25 08:15:31.288069
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    b_output = 'Password:'
    res_1 = become_module_1.check_password_prompt( b_output)
    assert res_1 is True, 'Test for method check_password_prompt of class BecomeModule, expected result is True, actual result is ' + str(res_1)

    become_module_2 = BecomeModule()
    b_output = 'password'
    res_2 = become_module_2.check_password_prompt( b_output)
    assert res_2 is False, 'Test for method check_password_prompt of class BecomeModule, expected result is False, actual result is ' + str(res_2)

    become_module_3 = BecomeModule()
    b_output = '密码：'
    res_3 = become

# Generated at 2022-06-25 08:15:41.620678
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()

    # Testing cases
    #
    # Success:
    #   * with default values
    #   * with custom beome_exe, become_flags
    #   * with custom become_exe, become_flags, become_user
    #   * with custom become_exe, become_flags, become_user, success_cmd
    #
    # Failure:
    #   * no arguments
    #   * cmd is None

    # Test case with default values
    cmd = "ls -l /"
    shell = "/bin/bash"
    become_module.build_become_command(cmd, shell)
    exe = "/bin/su"
    flags = ""
    user = "root"
    success_cmd = "/bin/bash -c ls -l /"


# Generated at 2022-06-25 08:15:47.889895
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    assert become_module_1.check_password_prompt(b"") == False
    assert become_module_1.check_password_prompt(b"Password:") == True



# Generated at 2022-06-25 08:15:55.925420
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    PROMPT_L10N = [ 'Password', 'Parool', 'Pasahitza' ]
    become_module_1.set_options(dict(prompt_l10n=PROMPT_L10N))
    PWD_PROMPT = 'Enter password: '
    CANNOT_EXECUTE = 'su: incorrect password'
    FOO_PASSWD = 'foobar'

    # case 0
    PWD_RESPONSE = '''
[%s@foo ~]$ %s%s
su: incorrect password
[%s@foo ~]$ ''' % (get_current_user(), PWD_PROMPT, FOO_PASSWD, get_current_user())

# Generated at 2022-06-25 08:16:00.137924
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():

    become_module_0 = BecomeModule()

    for l in become_module_0.get_option('prompt_l10n') or become_module_0.SU_PROMPT_LOCALIZATIONS:
        prompt = '%s:' % l
        assert become_module_0.check_password_prompt(prompt)

# Generated at 2022-06-25 08:16:02.482824
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_3 = BecomeModule()
    b_output = 'assword:'
    assert become_module_3.check_password_prompt(b_output) == True



# Generated at 2022-06-25 08:16:06.941180
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    assert become_module_1.check_password_prompt(b'We trust you have received the usual lecture from the local System'
                                                 b'\nAdministrator. It usually boils down to these three things:'
                                                 b'\n\n    #1) Respect the privacy of others.'
                                                 b'\n    #2) Think before you type.'
                                                 b'\n    #3) With great power comes great responsibility.'
                                                 b'\n\n[sudo] password for mohit:')



# Generated at 2022-06-25 08:16:17.668419
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()

    # Test 0: output contains valid prompt
    b_prompt_string = b"Password:"
    b_output = b"Password: "
    b_result = become_module_0.check_password_prompt(b_output)
    assert b_result

    # Test 1: output contains valid prompt with a leading word
    b_prompt_string = b"Password:"
    b_output = b"gordon's Password: "
    b_result = become_module_0.check_password_prompt(b_output)
    assert b_result

    # Test 2: output contains valid prompt with a trailing unicode character
    b_prompt_string = b"Password:"

# Generated at 2022-06-25 08:16:21.130928
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = become_module_0
    assert become_module_1.build_become_command('/bin/sh -c test_case_return_1', 'test_case_shell')
    return


# Generated at 2022-06-25 08:16:30.455448
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import os
    import platform
    import textwrap
    import pytest
    from ansible.collections.ansible.builtin import AnsibleModule
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError

    # Create the AnsibleModule instance

# Generated at 2022-06-25 08:16:36.015352
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    # Add your testing code here
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_check_password_prompt(list_0)


# Generated at 2022-06-25 08:16:39.446702
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = ['\x1b[01;31mroot\x1b[0m@desk-11:/tmp/ansible-test\x1b[01;34m$\x1b[0m ']
    become_module_0 = BecomeModule()
    var_0 = become_check_password_prompt(list_0)
    assert True == var_0


# Generated at 2022-06-25 08:16:41.866339
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_check_password_prompt(list_0)


# Generated at 2022-06-25 08:16:52.807554
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    #
    # test default value of prompt_l10n
    #
    var_0 = become_module_0.SU_PROMPT_LOCALIZATIONS
    var_0 = become_module_0.get_option('prompt_l10n')
    #
    # test with empty value of prompt_l10n
    #
    become_module_0.set_option('prompt_l10n', [])
    var_0 = become_module_0.get_option('prompt_l10n')
    var_0 = become_check_password_prompt(var_0)
    #
    # test with non empty value of prompt_l10n
    #

# Generated at 2022-06-25 08:17:01.500380
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test for method build_become_command(cmd, shell).
    # Test the standard use case for the build_become_command() method.
    assert AnsibleModule.build_become_command('test', 'shell') == 'su -c test'
    assert AnsibleModule.build_become_command('test', '') == 'su -c test'
    assert AnsibleModule.build_become_command('', 'shell') == 'su -c shell'
    assert AnsibleModule.build_become_command('', '') == 'su'

    # Test that the user and flags options work correctly.
    assert AnsibleModule.build_become_command('test', 'shell') == 'su -c test'
    assert AnsibleModule.build_become_command('test', '') == 'su -c test'

# Generated at 2022-06-25 08:17:03.302450
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    # default case
    print("default case")
    assert check_password_prompt([]) == True
    assert check_password_prompt("abc") == True


# Generated at 2022-06-25 08:17:06.163787
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.check_password_prompt(list_0)

# Generated at 2022-06-25 08:17:09.170628
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    print("Test check_password_prompt")
    instance_BecomeModule = BecomeModule()
    b_output = "password: "
    result = instance_BecomeModule.check_password_prompt(b_output)
    assert result == True

if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_check_password_prompt()

# Generated at 2022-06-25 08:17:15.767124
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # This test will fail if there is a bug in build_become_command
    # that causes the method to crash.
    try:
        become_module_0.build_become_command('cmd', 'shell')
    except:
        assert False



# Generated at 2022-06-25 08:17:25.050122
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    print("\nTesting BecomeModule.check_password_prompt ...")
    test_cases = [
        {
            'name': 'Localised password prompt exists',
            'b_output': u'''dave's Password:''',
            'localised_prompts': [u'Password', u'パスワード'],
            'result': True

        },
        {
            'name': 'Localised password prompt does not exist',
            'b_output': u'''Bad login:''',
            'localised_prompts': [u'Password', u'パスワード'],
            'result': False

        }
    ]

    for test_case in test_cases:
        print("\nRunning test case %s ..." % test_case['name'])

# Generated at 2022-06-25 08:17:31.270809
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(list_0, shell)

# Generated at 2022-06-25 08:17:33.395233
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.build_become_command()
    var_1 = become_module_1.prompt


# Generated at 2022-06-25 08:17:37.367263
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'ls'
    shell = 'shell'
    expected_result = 'su  -c /bin/sh -c \'ls\''
    actual_result = become_module.build_become_command(cmd, shell)
    assert actual_result == expected_result


# Generated at 2022-06-25 08:17:39.674833
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    # Setup
    data = list()

    become_module_0 = BecomeModule()

    # Test
    var_0 = become_check_password_prompt(data)

    assert var_0 == False

# Generated at 2022-06-25 08:17:44.491693
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module = BecomeModule()
    b_output = "Password: "
    b = become_module.check_password_prompt(b_output)
    assert True == b


# Generated at 2022-06-25 08:17:48.769403
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    list_0 = ['A' for var_0 in range(0, 10)]
    var_0 = become_module_0.check_password_prompt(list_0)

if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_check_password_prompt()

# Generated at 2022-06-25 08:17:55.108308
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = become_module_0.build_become_command('sudo -H -S -n true', 'sh')
    str_1 = become_module_0.build_become_command('sudo -H -S -n id -u', 'sh')
    str_2 = become_module_0.build_become_command('sudo -H -S -n id -a', 'sh')
    str_3 = become_module_0.build_become_command('sudo -H -S -n id -Z', 'sh')
    str_4 = become_module_0.build_become_command('sudo -H -S -n id -G', 'sh')

# Generated at 2022-06-25 08:17:57.177590
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.check_password_prompt(list_0)


# Generated at 2022-06-25 08:17:59.011313
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    # Local variables
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = check_password_prompt(list_0)
    # Testing
    assert var_0 is True

# Generated at 2022-06-25 08:18:03.733465
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:18:17.063112
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    list_0 = []
    var_0 = become_module_0.check_password_prompt(list_0)


# Generated at 2022-06-25 08:18:20.194493
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    list_0 = ["foo"]
    become_module_0 = BecomeModule()
    var_0 = become_module_build_become_command(list_0)


# Generated at 2022-06-25 08:18:31.133169
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
    become_module_0 = BecomeModule()
   

# Generated at 2022-06-25 08:18:39.934186
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # FIXME: test for get_option('become_exe')
    # FIXME: test for get_option('become_flags')
    # FIXME: test for get_option('become_user')
    # FIXME: test for _build_success_command(cmd, shell)
    # FIXME: test for shlex_quote()
    # FIXME: test for shlex_quote(success_cmd)


# Generated at 2022-06-25 08:18:41.692404
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.check_password_prompt(list_0)


# Generated at 2022-06-25 08:18:47.401467
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    #### This test makes sure that the method will return the correct output by comparing it with known sample output.
    output = build_become_command('cmd', 'shell')

    #### The following variables are known and available for testing:
    #### become_module.name = 'su'
    #### become_module.prompt = True
    #### become_module.get_option('become_exe') = 'su'
    #### become_module.get_option('become_flags') = ''
    #### become_module.get_option('become_user') = 'root'
    #### become_module._build_success_command('cmd', 'shell') = 'cmd'
    expected = ''
    assert output == expected


# Generated at 2022-06-25 08:18:51.374488
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command('test_string', 'test_string')
    assert var_0 == 'test_string'


# Generated at 2022-06-25 08:18:57.699356
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = []
    become_module_0 = BecomeModule()
    # test case for call check_password_prompt()
    var_0 = become_module_0.check_password_prompt(list_0)
    # test case for call check_password_prompt()
    var_0 = become_module_0.check_password_prompt(list_0)



# Generated at 2022-06-25 08:19:04.384665
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    var_0 = BecomeModule()
    var_1 = ['Password']
    var_0.set_option('prompt_l10n', var_1)
    var_2 = ['Authentication failure']
    var_0.set_option('fail', var_2)
    var_3 = b'Password : '
    var_4 = var_0.check_password_prompt(var_3)


# Generated at 2022-06-25 08:19:06.938634
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    mock_cmd = 'cmd'
    mock_shell = 'shell'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(mock_cmd, mock_shell)
    print(var_0)


# Generated at 2022-06-25 08:19:17.298090
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = None
    shell_0 = None
    return_value_0 = become_module_0.build_become_command(cmd_0, shell_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:19:27.213813
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Definitions
    cmd_0 = []
    shell_0 = False
    become_exe_0 = "root"
    become_flags_0 = "su"
    become_user_0 = ""
    success_cmd_0 = "su"
    exe_0 = "su"
    flags_0 = ""
    user_0 = ""
    # Call method build_become_command with args
    become_module_0 = BecomeModule()
    value_0 = become_module_0.build_become_command(cmd_0, shell_0)
    # Assertions
    assert value_0 == success_cmd_0, "Return value from build_become_command with args should be %s, but is %s" % (success_cmd_0, value_0)


# Generated at 2022-06-25 08:19:32.780612
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(list_0)

# Generated at 2022-06-25 08:19:35.053587
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 'ls'
    shell = '/bin/sh'
    become_module_1 = BecomeModule()
    var_1 = become_module_1.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:19:40.622585
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
	list_0 = []
	become_module_0 = BecomeModule()
	var_0 = become_module_0.build_become_command(list_0)

test_case_0()

# Generated at 2022-06-25 08:19:46.021650
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = get_option('become_exe')
    str_0 = get_option('become_flags')
    str_0 = get_option('become_user')
    str_0 = build_become_command('su', 1)

if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:19:52.686169
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo 'Hello World'"
    shell = "dest_shell"
    dest_cmd = "dest_cmd"
    become_module_0.build_become_command(cmd, shell)
    # If a certain path exists

# Generated at 2022-06-25 08:19:54.817773
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.check_password_prompt(list_0)



# Generated at 2022-06-25 08:19:59.943497
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.check_password_prompt(list_0)
    var_1 = become_module_0.check_password_prompt(list_0)


# Generated at 2022-06-25 08:20:06.068667
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_check_password_prompt(list_0)
    assert var_0 == False


# Generated at 2022-06-25 08:20:23.908130
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.get_option('prompt_l10n') == []


# Generated at 2022-06-25 08:20:25.603465
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command()
    print(var_0)

# Generated at 2022-06-25 08:20:28.741914
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = []
    shell = []
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(cmd, shell)
    print(var_0)


# Generated at 2022-06-25 08:20:31.482721
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.build_become_command("cmd", "shell")

# Generated at 2022-06-25 08:20:34.308500
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = "ls"
    shell = "/bin/sh"
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(cmd, shell)


# Generated at 2022-06-25 08:20:38.700506
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_exe_0 = 'sudo'
    become_user_0 = '0'
    cmd_0 = 'su'
    shell_0 = 'bash'
    become_module_0 = BecomeModule()
    become_module_0.set_options
    var_0 = become_module_0.build_become_command(cmd_0, shell_0)


# Generated at 2022-06-25 08:20:43.897620
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Create an object of class BecomeModule with default arguments
    become_module_0 = BecomeModule()

    # Create an object of class BecomeModule with default arguments
    become_module_1 = BecomeModule()

    # Create an object of class BecomeModule with default arguments
    become_module_2 = BecomeModule()

    # Create an object of class BecomeModule with default arguments
    become_module_3 = BecomeModule()

    # Create an object of class BecomeModule with default arguments
    become_module_4 = BecomeModule()

    # Create an object of class BecomeModule with default arguments
    become_module_5 = BecomeModule()

    # Create an object of class BecomeModule with default arguments
    become_module_6 = BecomeModule()

    # Create an object of class BecomeModule with default arguments
    become_module_7 = BecomeModule()

    # Create an object of class

# Generated at 2022-06-25 08:20:46.343039
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command('cmd', 'shell')


# Generated at 2022-06-25 08:20:57.657404
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    print("Testing method 'build_become_command'")
    # Declare str for testing purposes
    str1 = ""
    str2 = ""
    str3 = ""
    str4 = ""
    str5 = ""
    # Declare arrays for testing purposes
    array1 = [str1, str2, str3]
    array2 = [str1, str2, str3, str4, str5]
    array3 = [str1, str2, str3, str4]
    array4 = [str1, str2, str3, str4, str5]
    array5 = [str1, str2, str3, str4]
    # Declare BecomeModule object
    become_module_obj = BecomeModule()
    # Declare become_flags
    become_flags = ""
    # Declare become_user
   

# Generated at 2022-06-25 08:20:59.939822
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()


# Generated at 2022-06-25 08:21:31.957664
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = become_module_0.build_become_command()
    assert str_0 is not None


# Generated at 2022-06-25 08:21:39.045945
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Intialize a BecomeModule object and create a temporary test file with the arguments
    become_module_0 = BecomeModule()
    open_file_0 = tempfile.TemporaryFile()
    try:
        # Make a temporary file to write the arguments
        open_file_0.write(b'--extra-vars\nansible_connection\n')
        open_file_0.seek(0)
        # Call build_become_command() with the file arguments
        become_module_0.build_become_command(open_file_0, 'shell')
    finally:
        open_file_0.close()


# Generated at 2022-06-25 08:21:47.411671
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    option_0_list = ['ansible_become', 'ansible_become_method', 'ansible_become_user']
    option_1_list = ['ansible_become', 'ansible_become_method', 'ansible_become_user']
    option_2_list = ['ansible_become', 'ansible_become_method', 'ansible_become_user']
    option_3_list = ['ansible_become', 'ansible_become_method', 'ansible_become_user']
    option_4_list = ['ansible_become', 'ansible_become_method', 'ansible_become_user']

# Generated at 2022-06-25 08:21:56.365116
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd_0 = []
    shell_0 = "sh"
    become_module_0 = BecomeModule()
    print(become_module_0.build_become_command(cmd_0, shell_0))

if __name__ == "__main__":
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:22:01.738772
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    string_0 = 'cmd'
    string_1 = 'shell'
    var_0 = become_module_0.build_become_command(string_0, string_1)
    var_1 = become_module_0.prompt

# Generated at 2022-06-25 08:22:05.682801
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    string_0 = "sudo -b cd /; env TEST_VAR='some value' /some/path"
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(string_0, string_0)


# Generated at 2022-06-25 08:22:08.693278
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # bc is an object of class BecomeModule
    bc = BecomeModule()
    # chk is a string object
    cmd = "ls"
    shell = "bash"
    chk = bc.build_become_command(cmd, shell)
    assert chk == chk


# Generated at 2022-06-25 08:22:16.715260
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    dict_0 = dict()
    dict_0['become_exe'] = ''
    dict_0['become_flags'] = ' -f'
    dict_0['become_user'] = 'test_user'
    dict_0['prompt_l10n'] = ['Password']
    become_module_0 = BecomeModule()
    become_module_0.set_options(dict_0)
    string_0 = 'ls -l'
    string_1 = become_module_0.build_become_command(string_0, '')
    assert string_1 == 'su -f test_user -c ls -l', string_1

# Generated at 2022-06-25 08:22:19.388446
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = "ls"
    shell = "/bin/bash"
    become_module_0 = BecomeModule()
    result_0 = become_module_0.build_become_command(cmd, shell)
    print(result_0)


# Generated at 2022-06-25 08:22:23.800082
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 'command_0'
    shell = 'shell_0'
    become_module_0 = BecomeModule()
    var_0 = become_module_build_become_command(cmd, shell)

test_case_0()

# Generated at 2022-06-25 08:23:31.602501
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = build_become_command(list_0, list_0)

# Generated at 2022-06-25 08:23:36.781338
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # case 0
    list_0 = ['', 'bash -c']
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(list_0[0], list_0[1])


# Generated at 2022-06-25 08:23:45.107361
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "cmd"
    shell = "shell"
    result = become_module.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:23:51.229849
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    list_0 = []
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(list_0, list_0)


# Generated at 2022-06-25 08:23:54.500315
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'command'
    shell = 'shell'
    var = become_module.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:24:04.770967
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_class_0 = BecomeModule()
    # Build command to execute
    # Build command to execute
    # Build command to execute
    # Build command to execute
    test_class_0.get_option = get_option_0
    test_class_0.name = 'su'
    test_class_0.get_option("become_exe")
    build_become_command("su ","su ","su ","su ")



# Generated at 2022-06-25 08:24:08.665655
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    list_0 = []
    become_module_0 = BecomeModule()
    become_module_build_become_command(list_0)


# Generated at 2022-06-25 08:24:13.054658
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    string_0 = 'echo ansible'
    string_1 = 'python'
    become_module_0 = BecomeModule()
    string_2 = become_module_0._build_become_command(string_0, string_1)

# Generated at 2022-06-25 08:24:15.210298
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(cmd='Command_0', shell='Shell_0')

# Generated at 2022-06-25 08:24:20.238018
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(None, None)