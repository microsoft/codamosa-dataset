

# Generated at 2022-06-25 08:15:32.667542
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import shlex_quote

    # Method build_become_command of class BecomeModule
    #
    # Values for parameter cmd:
    test_cmd_0 = 'date'
    test_cmd_1 = 'ls'
    test_cmd_2 = 'ps'
    test_cmd_3 = 'true'
    test_cmd_4 = 'false'
    test_cmd_5 = 'uptime'
    test_cmd_6 = 'grep'
    test_cmd_7 = 'cat'
    test_cmd_8 = 'grep -i alaska'
    test_cmd_9 = 'sed s/alaska/alask/'

    # Values for parameter shell:

# Generated at 2022-06-25 08:15:38.640498
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.connection = None
    cmd = 'cmd'
    shell = 'shell'
    ret = become_module_0.build_become_command(cmd, shell)
    assert ret == "su -c '%s'" % shlex_quote(cmd)



# Generated at 2022-06-25 08:15:47.697807
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:15:55.787533
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    b_output_0 = "this is a string"
    assert not become_module_0.check_password_prompt(b_output_0)

    b_output_1 = "this is a string: "
    assert become_module_0.check_password_prompt(b_output_1)

    b_output_2 = "this is a string: "
    assert become_module_0.check_password_prompt(b_output_2)

    b_output_3 = "this is a string： "
    assert become_module_0.check_password_prompt(b_output_3)

    for prompt in become_module_0.SU_PROMPT_LOCALIZATIONS:
        b_output_4 = prompt
        assert become_module_0

# Generated at 2022-06-25 08:15:58.341518
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    password = 'test-value'

# Generated at 2022-06-25 08:16:04.413557
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule(become_flags='-f')
    assert become_module_1._build_success_command('pwd', None) == 'pwd'
    assert become_module_1._build_success_command('$SHELL -c "pwd"', None) == '$SHELL -c "pwd"'


# Generated at 2022-06-25 08:16:07.537488
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'passwd'
    shell = 'sh'
    become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:16:20.641684
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    bs = []
    my_module = become_module_0

    # test case 1
    # password prompt
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
    bs.append(to_bytes(u"Password: "))
   

# Generated at 2022-06-25 08:16:25.678043
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    become_module_1.prompt = True
    b_output_1 = 'Password:'.encode()
    b_output_2 = 'パスワード:'.encode()
    b_output_3 = 'Diвoλo:'.encode()
    assert become_module_1.check_password_prompt(b_output_1)
    assert become_module_1.check_password_prompt(b_output_2)
    assert become_module_1.check_password_prompt(b_output_3)

# Generated at 2022-06-25 08:16:34.630985
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():

    become_module_1 = BecomeModule()
    output_1 = to_bytes(u'any command with Password: ')
    expected_1 = True
    actual_1 = become_module_1.check_password_prompt(output_1)
    assert actual_1 == expected_1

    become_module_2 = BecomeModule()
    output_2 = to_bytes(u'any command with PASSWORD: ')
    expected_2 = True
    actual_2 = become_module_2.check_password_prompt(output_2)
    assert actual_2 == expected_2

    become_module_3 = BecomeModule()
    output_3 = to_bytes(u'any command with password: ')
    expected_3 = True

# Generated at 2022-06-25 08:16:42.139071
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    # GIVEN
    become_module = BecomeModule()

    # WHEN
    b_output = to_bytes("\nPassword:")
    check = become_module.check_password_prompt(b_output)

    # THEN
    assert check == True


# Generated at 2022-06-25 08:16:46.377233
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    assert become_module_1.check_password_prompt(b'Password:')


# Generated at 2022-06-25 08:16:55.268463
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ''
    shell = ''
    become_module_0._build_success_command = lambda x, y: 'ls'
    assert become_module_0.build_become_command(cmd, shell) == 'su -c ls'
    cmd = 'ls'
    assert become_module_0.build_become_command(cmd, shell) == 'su -c ls'
    cmd = 'ls'
    assert become_module_0.build_become_command(cmd, shell) == 'su -c ls'
    cmd = 'ls -l'
    assert become_module_0.build_become_command(cmd, shell) == 'su -c ls -l'
    cmd = '''ls -l 'abc' "def"'''
    assert become_module_

# Generated at 2022-06-25 08:16:59.309486
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    b_output = to_bytes('password')
    assert become_module_0.check_password_prompt(b_output) == True
    b_output = to_bytes('another password')
    assert become_module_0.check_password_prompt(b_output) == False


# Generated at 2022-06-25 08:17:08.595834
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():

    become_module_1 = BecomeModule()
    assert become_module_1.check_password_prompt('Password: ') is True
    assert become_module_1.check_password_prompt('My password: ') is True
    assert become_module_1.check_password_prompt('My password:') is True
    assert become_module_1.check_password_prompt('My password：') is True
    assert become_module_1.check_password_prompt('Password') is False
    assert become_module_1.check_password_prompt('My password') is False


# Generated at 2022-06-25 08:17:10.843910
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert isinstance(become_module_0, BecomeModule)


# Generated at 2022-06-25 08:17:15.967583
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    b_output_0 = become_module_0.check_password_prompt(b"password: ")


# Generated at 2022-06-25 08:17:24.722155
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    assert become_module_0.check_password_prompt(b'Password') == True
    assert become_module_0.check_password_prompt(b'Password:') == True

# Generated at 2022-06-25 08:17:34.194063
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command("ls", False) == "su -c 'ls'"
    assert become_module.build_become_command("ls", True) == "su -c 'ls'"
    assert become_module.build_become_command("", False) == ""
    assert become_module.build_become_command("", True) == ""

    become_module = BecomeModule()
    become_module.set_option("become_exe", "sue")
    become_module.set_option("become_user", "root")
    become_module.set_option("become_flags", "")
    assert become_module.build_become_command("ls", False) == "sue root -c 'ls'"
    assert become_module.build_bec

# Generated at 2022-06-25 08:17:36.993644
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()

    # Test with a known string
    b_output="PASSWORD: "
    result = become_module_0.check_password_prompt(b_output)
    assert result == True


# Generated at 2022-06-25 08:17:52.081737
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
   become_module_0 = BecomeModule()
   become_module_0.set_options(privilege_escalation=dict(become_password='Ansible',
                                                         become_user='admin',
                                                         become_exe='su',
                                                         become_flags='-c',
                                                         become_pass='Ansible'),
                               su_become_plugin=dict(password='Ansible',
                                                     user='admin',
                                                     executable='su',
                                                     flags='-c'))

   output_0 = "Password: "
   assert become_module_0.check_password_prompt(output_0) is True, "check_password_prompt should return True"


# Generated at 2022-06-25 08:17:58.400300
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_cases = [
        ({'become_user': 'root', 'prompt_l10n': ['Password']}, "su - root -c 'echo BECOME-SUCCESS-fhkciemxjc'"),
        ({'become_user': 'root', 'prompt_l10n': ['Password'], 'become_exe': 'sudo'}, "sudo - root -c 'echo BECOME-SUCCESS-fhkciemxjc'"),
        ({'become_user': 'root', 'prompt_l10n': ['Password'], 'become_exe': 'su', 'become_flags': '-f'}, "su -f root -c 'echo BECOME-SUCCESS-fhkciemxjc'"),
    ]


# Generated at 2022-06-25 08:18:04.615876
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_args = {'become_exe': 'su', 'become_flags': '-c', 'become_user': 'root'}
    assert become_module_1.build_become_command(None, None, **become_args) == 'su -c root'
    assert become_module_1.build_become_command('/bin/cat /foo/bar', None, **become_args) == 'su -c root -c /bin/cat /foo/bar'
    become_args = {'become_exe': 'sudo', 'become_flags': '-k -H -u root', 'become_user': None}

# Generated at 2022-06-25 08:18:07.960133
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command("", True) == ""


# Generated at 2022-06-25 08:18:11.180306
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert BecomeModule().build_become_command("/bin/bash", "/bin/sh") == "su - root -c '/bin/bash'"
    assert BecomeModule(dict(become_exe = "sudo", become_flags = "-l", become_user = "ansible")).build_become_command("/bin/bash", "/bin/sh") == "sudo -l ansible -c '/bin/bash'"


# Generated at 2022-06-25 08:18:23.497821
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('ls', 'sh') == 'su root -c "sh -c \'ls\'"'

if __name__ == '__main__':
    #
    # Run unit tests
    #
    test_case_0()
    test_func_name = locals()['test_' + os.path.splitext(os.path.basename(__file__))[0]]
    for test_func_name in dir():
        if test_func_name.startswith('test_') and callable(locals()[test_func_name]):
            print('Running', test_func_name)
            locals()[test_func_name]()
    print('Done')

# Generated at 2022-06-25 08:18:26.264556
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    
    # set up parameters
    cmd = None

    assert become_module_0.build_become_command(cmd, shell) == None, \
        'Expected None, but got %s' % become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:18:34.727143
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.set_options({'become_user': 'test_become_user'})
    assert become_module.build_become_command('') == 'su  test_become_user -c \'\''
    assert become_module.build_become_command('echo') == 'su  test_become_user -c \'echo\''


# Generated at 2022-06-25 08:18:41.943279
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    become_module_0.prompt = None

    (b_output) = (b'aaaaaaaaa')
    __ret = become_module_0.check_password_prompt(b_output)
    assert __ret == False, "Failed to test_BecomeModule_check_password_prompt"

# Generated at 2022-06-25 08:18:46.141641
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    print("Unit test for method check_password_prompt of class BecomeModule")
    filename = "tests/files/fixtures/su_prompt.txt"
    f = open(filename, "r")
    stdout = f.read()
    become_module = BecomeModule()
    b_password_prompt = become_module.check_password_prompt(stdout)
    assert b_password_prompt == True
    print("Unit test for method check_password_prompt of class BecomeModule passed")


# Generated at 2022-06-25 08:19:09.978359
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    b_output1 = b'Password: '
    result1 = become_module_1.check_password_prompt(b_output1)
    assert result1

    b_output2 = b'contrasenya: '
    result2 = become_module_1.check_password_prompt(b_output2)
    assert result2

    b_output3 = b'contrasenya: '
    result3 = become_module_1.check_password_prompt(b_output3)
    assert result3


# Generated at 2022-06-25 08:19:16.989619
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_obj = BecomeModule()
    assert become_module_obj.check_password_prompt(b'Retype new UNIX password:') == True
    assert become_module_obj.check_password_prompt(b'Password:') == True
    assert become_module_obj.check_password_prompt(b'Su password:') == True
    assert become_module_obj.check_password_prompt(b'New password:') == True
    assert become_module_obj.check_password_prompt(b'Password: ') == False
    assert become_module_obj.check_password_prompt(b'Password') == False
    assert become_module_obj.check_password_prompt(b'') == False

# Generated at 2022-06-25 08:19:18.185295
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()


# Generated at 2022-06-25 08:19:27.691034
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """
    test:
    1. That the command 'su' is correctly built.
    2. That the command 'su -c' is correctly built.
    3. That the command 'su -c' with custom options is correctly built.
    4. That the command 'su -c' with custom options, user and executable is correctly built.
    5. That an empty command returns an empty string.
    """

    become_module_1 = BecomeModule()
    become_module_1.notify_on_become = False
    expected_command_1 = 'su -c id'

    become_module_2 = BecomeModule()
    become_module_2.get_option = lambda x: '-'
    become_module_2.notify_on_become = False
    expected_command_2 = 'su - -c id'

    become

# Generated at 2022-06-25 08:19:33.469944
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('test_cmd', 'test_shell') == 'su  -c \'test_shell -c \'"\'"\'test_cmd\'"\'"\'\''

# Generated at 2022-06-25 08:19:41.077526
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "test"
    shell = ""
    output = become_module_0.build_become_command(cmd, shell)
    assert output == "su root -c 'test'"


# Generated at 2022-06-25 08:19:45.096422
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module = BecomeModule()
    b_output = "su -c hello world Password: "
    result = become_module.check_password_prompt(b_output)
    assert result == True

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:19:49.265492
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    assert become_module_0.check_password_prompt(b'') == False


# Generated at 2022-06-25 08:19:55.109001
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    # Change globals to test values
    global SU_PROMPT_LOCALIZATIONS
    SU_PROMPT_LOCALIZATIONS = [
        'Password'
    ]
    become_module_0 = BecomeModule()

    # Test
    # This is the expected output from su
    b_output = to_bytes('Password: ')
    result = become_module_0.check_password_prompt(b_output)
    assert result == True



# Generated at 2022-06-25 08:20:00.349354
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()

    # Test case 1
    b_output = b"Password:"
    result = become_module_1.check_password_prompt(b_output)
    assert result == True, "Failed to verify the method check_password_prompt with TestCase #1"


# Generated at 2022-06-25 08:20:43.908346
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    b_output = (b'Password: ')
    is_prompt_exists = become_module_0.check_password_prompt(b_output)
    assert is_prompt_exists, "Failure in test_BecomeModule_check_password_prompt"


# Generated at 2022-06-25 08:20:47.980483
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'SU_CMD'
    shell = 'SU_SHELL'

    # case 0
    expected_0 = 'su -l root -c SU_CMD'
    actual_0 = become_module_0.build_become_command(cmd, shell)
    assert expected_0 == actual_0


# Generated at 2022-06-25 08:20:58.906221
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('/usr/bin/whoami', '/bin/sh') == 'su root -c \'/bin/sh -c \'"\'"\'/usr/bin/whoami\'"\'"\'\''
    assert become_module_1.build_become_command('/usr/bin/whoami', '/bin/bash') == 'su root -c \'/bin/bash -c \'"\'"\'/usr/bin/whoami\'"\'"\'\''
    assert become_module_1.build_become_command('/usr/bin/whoami', '/bin/ksh') == 'su root -c \'/bin/ksh -c \'"\'"\'/usr/bin/whoami\'"\'"\'\''
    assert become_module

# Generated at 2022-06-25 08:21:03.801492
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = '/bin/sh'
    assert become_module_0.build_become_command(cmd, shell) == 'su  root -c \'ls\''


# Generated at 2022-06-25 08:21:06.075115
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('echo $HOME', '/bin/bash -c') == 'su -c /bin/bash -c echo\ $HOME'

# Generated at 2022-06-25 08:21:09.038406
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.set_options(direct={'become_exe':'su', 'become_flags':'', 'become_user':'foo'})
    assert become_module_1.build_become_command('bar', 'baz') == "su  foo -c 'bar'"


# Generated at 2022-06-25 08:21:14.984248
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  become_module = BecomeModule()
  cmd = 'ls'
  shell = '/bin/bash'
  # Test case 1
  expected = 'su -c ls'
  actual = become_module.build_become_command(cmd, shell)
  assert expected == actual


# Generated at 2022-06-25 08:21:26.025247
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module = BecomeModule()
    prompt_string = b'Password: '
    output = b'Password: ' 
    actual_result = become_module.check_password_prompt(output)
    expected_result = True
    assert expected_result == actual_result
    output_1 = b'Password:'
    actual_result_1 = become_module.check_password_prompt(output_1)
    expected_result = False
    assert expected_result == actual_result_1 
    output_2 = b'password: '
    actual_result_2 = become_module.check_password_prompt(output_2)
    expected_result = False
    assert expected_result == actual_result_2    
    output_3 = b'Pasword: '
    actual_result_3 = become_module.check_

# Generated at 2022-06-25 08:21:37.034057
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():

    become_module_0 = BecomeModule()

# Generated at 2022-06-25 08:21:43.301979
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils.common.text.converters import (
        to_text,
    )

    become_module_0 = BecomeModule()
    if become_module_0.CHECK_BECOME_SUCCESS != to_text(b'\r\n'):
        raise Exception('Failed')
    if become_module_0.BECOME_ERROR_STRINGS != []:
        raise Exception('Failed')
    cmd = ['echo', 'Hello']
    shell = 'shell'
    ans_built_cmd = shlex_quote("su -c ") + shlex_quote("'echo Hello'")

# Generated at 2022-06-25 08:23:09.236287
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    become_module_1.options['prompt_l10n'] = [b'Password']
    assert become_module_1.check_password_prompt(b'Password: ')

    become_module_2 = BecomeModule()
    become_module_2.options['prompt_l10n'] = [b'Password']
    assert not become_module_2.check_password_prompt(b'Some other prompt: ')

    become_module_3 = BecomeModule()
    become_module_3.options['prompt_l10n'] = []
    assert become_module_3.check_password_prompt(b'Password: ')

    become_module_4 = BecomeModule()

# Generated at 2022-06-25 08:23:15.236815
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module = BecomeModule()
    become_module.set_options(dict(prompt_l10n=[u'Password', u'パスワード']))

    assert become_module.check_password_prompt(to_bytes('Password:'))
    assert become_module.check_password_prompt(to_bytes('パスワード:'))
    assert become_module.check_password_prompt(to_bytes('パスワード：'))
    assert become_module.check_password_prompt(to_bytes('Password: '))
    assert become_module.check_password_prompt(to_bytes('password:'))
    assert become_module.check_password_prompt(to_bytes('パスワード: '))

# Generated at 2022-06-25 08:23:25.248447
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module = BecomeModule()
    assert False == become_module.check_password_prompt(b'')
    assert True == become_module.check_password_prompt(b'passworD:')
    assert True == become_module.check_password_prompt(b'passworD: ')
    assert True == become_module.check_password_prompt(b'passworD:  ')

# Generated at 2022-06-25 08:23:31.667032
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    output = 'Password: '
    assert(become_module_1.check_password_prompt(output) == True)
    output = 'Password : '
    assert(become_module_1.check_password_prompt(output) == True)
    output = 'Password：'
    assert(become_module_1.check_password_prompt(output) == True)
    output = 'Password： '
    assert(become_module_1.check_password_prompt(output) == True)
    output = 'Password : '
    assert(become_module_1.check_password_prompt(output) == True)
    output = 'Password'
    assert(become_module_1.check_password_prompt(output) == False)

# Generated at 2022-06-25 08:23:37.667017
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ''
    shell = ''
    assert become_module_0.build_become_command(cmd, shell) == cmd
    cmd = 'test_cmd'
    shell = ''
    test_case = "su  root -c 'test_cmd'"
    assert become_module_0.build_become_command(cmd, shell) == test_case



# Generated at 2022-06-25 08:23:43.847846
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "command to run"
    shell = "shell to execute command on"
    try:
        result = become_module_1.build_become_command(cmd, shell)
        assert result is not None
        assert isinstance(result, str)
    except Exception as e:
        print("Exception thrown in test_BecomeModule_build_become_command: " + str(e))
        assert False
    finally:
        become_module_1 = None


# Generated at 2022-06-25 08:23:49.656519
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 08:23:56.834180
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()

    # Test with invalid password prompt
    b_output = to_bytes(u'Invalid password')
    assert not become_module_0.check_password_prompt(b_output)

    # Test with valid password prompt
    b_output = to_bytes(u'Password')
    assert become_module_0.check_password_prompt(b_output)

    # Test with valid password prompt containing space around colon
    b_output = to_bytes(u'Password :')
    assert become_module_0.check_password_prompt(b_output)

    # Test with valid password prompt containing space around colon
    b_output = to_bytes(u'Password :')
    assert become_module_0.check_password_prompt(b_output)

    # Test with valid password prompt containing

# Generated at 2022-06-25 08:24:05.322147
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = ''
    exe = become_module_1.get_option('become_exe') or become_module_1.name
    flags = become_module_1.get_option('become_flags') or ''
    user = become_module_1.get_option('become_user') or ''
    expected_cmd = "%s %s %s" % (exe, flags, user)
    assert become_module_1.build_become_command(cmd, shell=None) == expected_cmd

# Generated at 2022-06-25 08:24:09.013295
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    output = b"Password: "
    assert become_module_0.check_password_prompt(output) == True
