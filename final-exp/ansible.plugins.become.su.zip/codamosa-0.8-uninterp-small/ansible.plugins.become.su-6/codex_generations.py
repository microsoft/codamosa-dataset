

# Generated at 2022-06-25 08:15:25.234491
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # Default arguments
    cmd = None
    shell = None
    become_module_0_cmd_result = become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:15:33.932652
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bp = BecomeModule(None, {'become_pass': '123', 'become_user': 'root'})
    cmd = 'echo 123'
    shell = 'sh'
    result = bp.build_become_command(cmd, shell)
    expected = 'su root -c echo\ 123'
    assert result == expected


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-25 08:15:37.553662
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():

    become_module_0 = BecomeModule()
    become_module_0.set_options({'prompt_l10n': ['Password', 'Bogus']})

    # Test case #1
    out = b"change password for root"
    assert(become_module_0.check_password_prompt(out) == False)

    # Test case #2
    out = b"Password:"
    assert(become_module_0.check_password_prompt(out) == True)

    # Test case #3
    out = b"Bogus:"
    assert(become_module_0.check_password_prompt(out) == True)


# Generated at 2022-06-25 08:15:47.619722
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    output = b''
    assert become_module_0.check_password_prompt(output) == False , "Failed: expected True, got False"
    output = b'Password:'
    assert become_module_0.check_password_prompt(output) == True , "Failed: expected True, got False"
    output = b'Password'
    assert become_module_0.check_password_prompt(output) == True , "Failed: expected True, got False"
    output = b'password:'
    assert become_module_0.check_password_prompt(output) == True , "Failed: expected True, got False"
    output = b'password'

# Generated at 2022-06-25 08:15:51.332258
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo test"
    shell = "sh"
    result_actual = become_module_0.build_become_command(cmd, shell)
    result_expected = "su - root -c 'echo test'"
    assert result_actual == result_expected

# Generated at 2022-06-25 08:15:55.507103
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    arguments = {'become_exe' : 'su', 'become_flags' : '', 'become_user' : 'test'}
    become_module.set_options(arguments)
    cmd = become_module.build_become_command('pwd', False)
    assert cmd == "su  -c pwd"



# Generated at 2022-06-25 08:15:59.736478
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    output_0 = become_module_1.check_password_prompt(b'Password: ')
    assert output_0 is True
    output_1 = become_module_1.check_password_prompt(b'Password:')
    assert output_1 is False


# Generated at 2022-06-25 08:16:09.899637
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test method with empty or null command
    # Expected result (become_module, cmd) -> (cmd)
    assert become_module.build_become_command(cmd=None, shell=None) is None
    assert become_module.build_become_command(cmd='', shell=None) is None

    # Test method with non-empty command and 'ansible_become_exe' option
    # Expected result (become_module, cmd) -> (su -l -c <shell>)
    become_module.plugin_options['ansible_become_exe'] = 'su'
    become_module.plugin_options['ansible_become_flags'] = '-l'
    become_module.plugin_options['ansible_become_user'] = 'root'
    become_

# Generated at 2022-06-25 08:16:15.226160
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_1 = None
    var_2 = None
    become_module_0.build_become_command(var_1, var_2)


# Generated at 2022-06-25 08:16:17.708579
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module = BecomeModule()
    b_output = "Password:"
    r = become_module.check_password_prompt(b_output)
    assert r == True

# Generated at 2022-06-25 08:16:25.761169
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()

    # Valid case: assert prompt message
    assert become_module_0.check_password_prompt(to_bytes('Password: ')) == True



# Generated at 2022-06-25 08:16:34.158676
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    become_module_1.set_option('prompt_l10n', None)
    assert become_module_1.check_password_prompt(b'Password: ') == True
    become_module_2 = BecomeModule()
    become_module_2.set_option('prompt_l10n', None)
    assert become_module_2.check_password_prompt(b'Password: ') == True
    become_module_3 = BecomeModule()
    become_module_3.set_option('prompt_l10n', None)
    assert become_module_3.check_password_prompt(b'Password: ') == True


# Generated at 2022-06-25 08:16:44.715235
# Unit test for method check_password_prompt of class BecomeModule

# Generated at 2022-06-25 08:16:53.354109
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()

# Generated at 2022-06-25 08:17:00.142964
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:17:03.939548
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    # Expected result: 'su -c 'true''
    assert become_module_1.build_become_command('true', None) == 'su -c true'

    # Expected result: 'su -c 'true''
    assert become_module_1.build_become_command('true', 'default') == 'su -c true'

    become_module_1.set_become_plugin_options({'become_user': 'some_user'})

    # Expected result: 'su some_user -c 'true''
    assert become_module_1.build_become_command('true', None) == 'su some_user -c true'

    # Expected result: 'su some_user -c 'true''
    assert become_module_1.build_become

# Generated at 2022-06-25 08:17:08.184465
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    output = become_module_0.build_become_command('ls -l', 'bash')
    print(f'Output returned by build_become_command function: {output}')
    assert output == "su - root -c 'ls -l'"



# Generated at 2022-06-25 08:17:18.120220
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    become_module_0.get_option = lambda x: None

    # Test with non-matching b_output
    b_output = u"foo"
    result = become_module_0.check_password_prompt(b_output)
    assert not result

    # Test with matching b_output
    b_output = u"Password:"
    result = become_module_0.check_password_prompt(b_output)
    assert result

    # Test with matching b_output, mixed case
    b_output = u"pAsSwOrD:"
    result = become_module_0.check_password_prompt(b_output)
    assert result


# Generated at 2022-06-25 08:17:26.000050
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    become_module_1.set_options({'prompt_l10n': ['Password']})
    assert become_module_1.check_password_prompt(b"Password:")
    assert become_module_1.check_password_prompt(b"user's Password:")
    assert become_module_1.check_password_prompt(b"user's\nPassword:")
    assert become_module_1.check_password_prompt(b"user's Password: ")
    assert become_module_1.check_password_prompt(b"user's Password :")
    assert become_module_1.check_password_prompt(b"user's Password : ")
    assert become_module_1.check_password_prompt(b"user's Password :  ")

# Generated at 2022-06-25 08:17:30.560672
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'ls'
    shell = 'shell'
    expected_return_value = b'su <flags> root -c ls'
    return_value = become_module.build_become_command(cmd, shell)
    assert return_value == expected_return_value

# Localized prompts for 'su'

# Generated at 2022-06-25 08:17:40.175460
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_flags = "su --help"
    become_exe = "python"
    cmd = None
    shell = "/bin/sh"
    become_user = "root"

    become_module_0 = BecomeModule()
    become_module_0.become_loader.options['become_flags'] = become_flags
    become_module_0.become_loader.options['become_exe'] = become_exe
    become_module_0.become_loader.options['become_user'] = become_user

    exp_cmd = 'python su --help root -c python /bin/sh -c None'
    assert become_module_0.build_become_command(cmd, shell) == exp_cmd



# Generated at 2022-06-25 08:17:50.677303
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Testing command and no shell
    cmd = "test_cmd"
    shell = False
    assert become_module.build_become_command(cmd, shell) == "su root -c test_cmd"

    # Testing command and shell
    shell = True
    assert become_module.build_become_command(cmd, shell) == "su root -c 'test_cmd'"

    # Testing no command and shell
    cmd = None
    shell = True
    assert become_module.build_become_command(cmd, shell) == "su root -c ''"

    # Testing no command and not shell
    cmd = None
    shell = False
    assert become_module.build_become_command(cmd, shell) == "su root -c ''"

    # Testing command, no shell and arguments


# Generated at 2022-06-25 08:17:54.299531
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Test case 0
    become_module_0 = BecomeModule()

    # Test case 1
    become_module_1 = BecomeModule()
    cmd_1 = 'command'
    shell_1 = '/bin/sh'
    result_1 = become_module_1.build_become_command(cmd_1, shell_1)
    assert result_1 == "su - root -c 'sh -c '\"'\"'command'\"'\"''"



# Generated at 2022-06-25 08:18:00.273710
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'ls -l'
    shell = '/bin/bash'
    expected = 'su  root  -c \'/bin/bash -c \'"\'ls -l\'"\''
    actual = become_module_1.build_become_command(cmd, shell)
    assert actual == expected, 'Expected: %s Found: %s' % (expected, actual)



# Generated at 2022-06-25 08:18:05.886803
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Initializing variable 'cmd'
    cmd = None
    # Initializing variable 'shell'
    shell = None
    res = become_module_0.build_become_command(cmd, shell)
    assert (res is None)
    

# Generated at 2022-06-25 08:18:12.965905
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test 0
    # become_exe = su
    # become_flags =
    # become_user =
    # cmd = id
    # shell = /bin/sh
    # ansible_connection = network_cli
    # ansible_shell_type = sh
    # ansible_shell_executable = None
    # ansible_python_interpreter = None
    become_module.set_options({
        'become_exe': 'su',
        'become_flags': '',
        'become_user': '',
        'prompt_l10n': [],
    })

# Generated at 2022-06-25 08:18:22.485370
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls -l'
    shell = '/bin/bash'
    expected_result = 'su  root -c \'ls -l\''
    tests = [('/bin/bash', 'ls -l', "su  root -c 'ls -l'")]
    for shell, cmd, expected_result in tests:
        result = become_module_0.build_become_command(cmd, shell)
        assert result == expected_result, \
        'Command: %s Expected: %s Received: %s' % (cmd, expected_result, result)


# Generated at 2022-06-25 08:18:27.223274
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule(connection=MockConnection())
    become_module_1.prompt = False
    assert become_module_1.build_become_command("cmd", "/bin/sh") == "su root -c cmd"


# Generated at 2022-06-25 08:18:37.420391
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    print("Test check_password_prompt")
    become_module_1 = BecomeModule()
    # test from the comment
    b_output = b'You are required to change your password immediately (root enforced)'
    if become_module_1.check_password_prompt(b_output):
        print("1. check_password_prompt failed")

    b_output = b'UNIX password:'
    if not become_module_1.check_password_prompt(b_output):
        print("2. check_password_prompt failed")


# Generated at 2022-06-25 08:18:45.311141
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    # cmd must be string
    cmd = 'echo hello'
    shell = '/bin/bash'
    expected = 'su - root -c echo hello'
    actual = become_module_1.build_become_command(cmd, shell)
    assert actual == expected, 'Command generated was incorrect: actual: %s, expected: %s' % (actual, expected)
    # cmd must be array
    cmd = ['echo', 'hello']
    shell = '/bin/bash'
    expected = 'su - root -c echo hello'
    actual = become_module_1.build_become_command(cmd, shell)
    print(actual)
    assert actual == expected, 'Command generated was incorrect: actual: %s, expected: %s' % (actual, expected)


# Generated at 2022-06-25 08:18:52.622223
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd_1 = 'cmd'
    shell_1 = 'shell'
    become_answer = become_module_1.build_become_command(cmd_1, shell_1)
    print("%s\n" % become_answer)


# Generated at 2022-06-25 08:19:01.530758
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command("", True) == "su  -c 'echo BECOME-SUCCESS-nfhnnsshciystxvyjkpxbtwoxipkxzkc'"
    assert become_module_0.build_become_command("", True) == "su  -c 'echo BECOME-SUCCESS-nfhnnsshciystxvyjkpxbtwoxipkxzkc'"
    assert become_module_0.build_become_command("", True) == "su  -c 'echo BECOME-SUCCESS-nfhnnsshciystxvyjkpxbtwoxipkxzkc'"
    assert become_module_0.build_become_command

# Generated at 2022-06-25 08:19:03.304959
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = []
    got = become_module_0.build_become_command(cmd, shell)
    assert got == ''


# Generated at 2022-06-25 08:19:09.829277
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "echo success"
    shell = "bash"
#Adding the following parameters to make sure the test passes
#        become_exe = self.get_option('become_exe') or self.name
#        flags = self.get_option('become_flags') or ''
#        user = self.get_option('become_user') or ''
#        success_cmd = self._build_success_command(cmd, shell)
    become_exe = 'su'
    flags = ''
    user = 'root'
    success_cmd = 'echo success'
    expected_result = "%s %s %s -c %s" % (become_exe, flags, user, shlex_quote(success_cmd))

# Generated at 2022-06-25 08:19:12.063737
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'echo success'
    shell = '/bin/sh'
    ret_1 = become_module_1.build_become_command(cmd, shell)
    assert ret_1 == "su  root -c 'echo success'"


# Generated at 2022-06-25 08:19:17.941320
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = Mock(return_value=None) #get_option
    cmd = 'c'
    shell = '/bin/sh'
    expected = 'su -c c'
    result = become_module.build_become_command(cmd, shell)
    assert expected == result, "Expected %s, got %s" % (expected, result)



# Generated at 2022-06-25 08:19:23.250607
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = mock.Mock(return_value="")
    output = become_module.build_become_command("ls","/bin/sh")
    assert output == "su -c 'ls'"


# Generated at 2022-06-25 08:19:30.250339
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bm = BecomeModule()
    cmd = "echo $USER"
    start_cmd = cmd
    cmd_with_shell = "/bin/sh -c '%s'" % cmd
    # Test Base Case
    start_cmd = bm.build_initial_command(cmd, False)
    assert start_cmd == cmd

    # Test In-Shell Case
    cmd = bm.build_initial_command(cmd_with_shell, True)
    assert cmd == cmd_with_shell

    # Test In-Shell Case with remote_user set
    cmd = bm.build_initial_command(cmd, True)
    assert cmd == cmd_with_shell

    # Test Become with no flags or args
    cmd = bm.build_become_command(cmd, False)
    assert cmd == "su -c '%s'" % start_

# Generated at 2022-06-25 08:19:32.376405
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'Test'
    shell = '/bin/bash'
    result = become_module_0.build_become_command(cmd, shell)
    assert result == "su - -c 'Test'"

# Generated at 2022-06-25 08:19:38.128418
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    # test with command and shell:
    expected_result_1 = 'su -c \'/bin/sh -c \'\\\'echo BECOME-SUCCESS\\\'\''
    assert become_module_1.build_become_command('echo BECOME-SUCCESS', 'sh') == expected_result_1

    # test with command and no shell:
    expected_result_2 = 'su -c \'/bin/sh -c \'\\\'echo BECOME-SUCCESS\\\'\''
    assert become_module_1.build_become_command('echo BECOME-SUCCESS', '') == expected_result_2


# Generated at 2022-06-25 08:19:49.957948
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = "ls"
    shell_0 = "/bin/bash"
    # AssertionError: 'su -c ls' != 'su -c ls'
    become_module_0.build_become_command(cmd_0, shell_0)


# Generated at 2022-06-25 08:19:53.536541
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'ls -l /tmp'
    shell_0 = '/bin/sh'
    assert not become_module_0.build_become_command(cmd_0, shell_0)


# Generated at 2022-06-25 08:19:54.062378
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert True

# Generated at 2022-06-25 08:20:00.442977
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Path to file created by test_case_0
    path_0 = 'plugin/connection/become/su'
    # Parameters for method testcall of class BecomeModule
    cmd = ''
    shell = ''
    # Return value of method testcall of class BecomeModule
    return_value = become_module_0.become_module.build_become_command(cmd, shell)
    # Return value of method build_become_command of class BecomeModule
    return_value_1 = become_module_0.become_module.build_become_command(cmd, shell)
    # Assertion message
    message_1 = 'The return value of method build_become_command of class BecomeModule is incorrect'
    # 'Assert return value of method build_become_command of class BecomeModule'

# Generated at 2022-06-25 08:20:07.242822
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    output_0 = become_module_0.build_become_command('adduser foo', 'bash')
    expected_result_0 = 'su  root -c adduser foo'
    assert output_0 == expected_result_0



# Generated at 2022-06-25 08:20:14.264476
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command("cat", "python3") == u'su - root -c "python3 -c \'import sys; print(sys.version)\'"'
    assert become_module.build_become_command("", "bash") == u'su - root -c "bash -c \'echo BECOME-SUCCESS-thxzjdvxfvqfqleqjqplhfxdprjvlyiql\'"'
    assert become_module.build_become_command("", "python3") == u'su - root -c "python3 -c \'import sys; print(sys.version)\'"'


# Generated at 2022-06-25 08:20:18.924997
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ""
    shell = "bash"
    string_0 = become_module_0.build_become_command(cmd, shell)
    assert "su -c " in string_0


# Generated at 2022-06-25 08:20:25.358479
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('/bin/sh -c echo "BECOME-SUCCESS-12345678"', '/bin/sh') == 'su  root -c \'/bin/sh -c echo "BECOME-SUCCESS-12345678"\''

# Generated at 2022-06-25 08:20:36.348441
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'ls -la /root'

    become_module.get_option = MagicMock(return_value='su')
    become_module.build_become_command(cmd, shell='/bin/bash')
    cmd = 'su -c \'ls -la /root\''

    become_module.get_option = MagicMock(return_value='')
    become_module.build_become_command(cmd, shell='/bin/bash')
    cmd = ' -c \'ls -la /root\''

    become_module.get_option = MagicMock(return_value='foo')
    become_module.build_become_command(cmd, shell='/bin/bash')
    cmd = 'su foo -c \'ls -la /root\''


# Generated at 2022-06-25 08:20:43.531544
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_arg = 'cmd'
    bool_arg = True
    str_ret_0 = become_module_0.build_become_command(str_arg, bool_arg)
    print ("Str: ", str_ret_0)


# Generated at 2022-06-25 08:21:01.106466
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils.six.moves import shlex_quote
    become_module_0 = BecomeModule()
    assert not become_module_0.build_become_command(None, None)
    cmd_0 = 'echo hi'
    shell_0 = None
    # Check for correct error on non-existant shell
    with pytest.raises(AnsibleError):
        become_module_0.build_become_command(cmd, shell_0)
    shell_1 = 'foo'
    exe_0 = become_module_0.get_option('become_exe') or become_module_0.name
    flags_0 = become_module_0.get_option('become_flags') or ''

# Generated at 2022-06-25 08:21:10.780667
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd_0 = 'cmd'
    cmd_1 = 'cmd'
    shell_0 = 'shell'
    shell_1 = 'shell'
    # Test for the case where return value of dict.get() is None
    become_module_1 = BecomeModule()
    become_module_1.get_option = dict.get
    become_module_2 = become_module_1.build_become_command(cmd_0, shell_0)
    # Test for the case where return value of dict.get() is not None
    become_module_1.get_option = dict.get
    become_module_2 = become_module_1.build_become_command(cmd_1, shell_1)


# Generated at 2022-06-25 08:21:14.551098
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 'ls'
    shell = '/bin/bash'
    become_module = BecomeModule()
    become_module.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:21:20.181270
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # TODO: build a test for build_become_command of BecomeModule
    print("Not implemented")


# Generated at 2022-06-25 08:21:24.110244
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd_0 = '/bin/sh'
    shell_0 = '/bin/sh'
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(cmd_0, shell_0)
    assert var_0 == 'su root -c /bin/sh'


# Generated at 2022-06-25 08:21:33.593455
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bytes_input_cmd_arg = b'\x86\x96\xca\xa8\x9a\xa0\x19!\xde\xfa'
    bytes_input_shell_arg = b'\x86\x96\xca\xa8\x9a\xa0\x19!\xde\xfa'
    become_module_instance = BecomeModule()
    var = become_module_instance.build_become_command(bytes_input_cmd_arg, bytes_input_shell_arg)



# Generated at 2022-06-25 08:21:40.210028
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    bytes_0 = b'\xb3\x19\xc0\xbf\xda\x82\xa8\x98\x07-\x07\x83\x8a\x9e\x84'
    bytes_1 = b'g\x8e\xcf\xed\xbc\xbe\xb0\xef\x00\x1c\x03\xb2\x9f\xdb\x0b'
    var_0 = become_module_0.build_become_command(bytes_0, bytes_1)


# Generated at 2022-06-25 08:21:45.563059
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_exe_0 = b'd\xa4\x1c\x9c\x19\x90\xe6\x98\xbe'
    shell_0 = b'\xd7\xb8\x9c\xec\xac\xf7\xde\x83\xa1'
    cmd_0 = b'\x80\xaf\xee\xa1\xab\x9a\x0f\xf1\xe2'
    become_module_0 = BecomeModule()
    become_module_0.become_exe =  become_exe_0
    become_module_0.prompt = True
    become_module_0.build_become_command(cmd_0, shell_0)



# Generated at 2022-06-25 08:21:52.811944
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bytes_0 = b'\x0b\xc3\x9e\x1e\x19\x7f\xd4\x1d\xfc\xce'
    str_0 = '\x0b\xc3\x9e\x1e\x19\x7f\xd4\x1d\xfc\xce'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(bytes_0, str_0)

# Generated at 2022-06-25 08:21:55.646018
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command("ls -l", False)

# Generated at 2022-06-25 08:22:16.731910
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # call build_become_command() with arguments: cmd = '', shell = ''
    assertion_failed = False
    try:
        become_module_0.build_become_command(cmd='', shell='')
    except AssertionError:
        assertion_failed = True

    assert assertion_failed

# Generated at 2022-06-25 08:22:18.177267
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command()


# Generated at 2022-06-25 08:22:27.978351
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bytes_0 = b'\x86\x96\xca\xa8\x9a\xa0\x19!\xde\xfa'
    become_module_0 = BecomeModule()
    become_module_0.prompt = False
    become_module_0.get_option = MagicMock(return_value='')
    _, _, _, shell_0, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _

# Generated at 2022-06-25 08:22:34.197394
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # test_issue_1941
    become_module_0 = BecomeModule()
    local_var_0 = "echo "
    cmd = ""
    shell = ""
    var_0 = become_module_build_become_command(cmd, shell)
    assert var_0 == "su root -c %s" % shlex_quote(local_var_0)

    # test_issue_1941_1
    become_module_1 = BecomeModule()
    local_var_1 = "echo "
    cmd = ""
    shell = "csh"
    var_1 = become_module_build_become_command(cmd, shell)
    assert var_1 == "su root -c %s" % shlex_quote(local_var_1)

    # test_issue_1941_2
    become_module_

# Generated at 2022-06-25 08:22:43.944693
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:22:53.587049
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bytes_0 = b'\xd8\x9al\xe2\x02\x98\xfc\xf0\x19w\xba\xae\n\xfd\x9d\x82\x0f\x1b\xd7\x13\t\xf7\x8b\xec\xab\x99\x9d\x8e?\xdf\x08G\x11\xf5\xfa\xfe\xc1\xdbE\xaa\x0e\xfa\xb2\xa7\x8c,\x1d\x86Z\xc6'

# Generated at 2022-06-25 08:22:57.630074
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd_0 = '$SHELL'
    shell_0 = '/bin/sh'
    become_module_0 = BecomeModule()
    str_0 = become_build_become_command(cmd_0, shell_0)
    print(str_0)

if __name__ == '__main__':
    # test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:23:03.838667
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Note: we are calling with shell=None because we don't have access to a shell here.
    #       This is okay because  the only thing we use shell for is to quote the success_cmd.
    #       The shell we pass to connection plugins is quoted by handing off to super().build_become_command.

    become_0 = BecomeModule()
    cmd_0 = 'test_0'
    shell_0 = None
    built_command_0 = become_0.build_become_command(cmd_0, shell_0)
    assert built_command_0 == 'su -c \'/bin/sh -c "test_0"\'', 'Command {} is not equivalent to {}'.format(built_command_0, 'su -c \'/bin/sh -c "test_0"\'')
    become_1 = BecomeModule()


# Generated at 2022-06-25 08:23:09.278512
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    arg_0 = "arg"
    arg_1 = "arg"
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(arg_0, arg_1)


# Generated at 2022-06-25 08:23:13.833461
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0
    bytes_0 = b'\xde\xde\xdf\xde\xf9\xdc\xfc\xef\xb1\x17!\xce\x91\xbb\xfe\xfc\x8d\x10\x11\x1b\x1b'
    var_1 = become_module_0
    var_1_1 = var_1._build_success_command(bytes_0)
    become_module_0.prompt = True



# Generated at 2022-06-25 08:23:54.338471
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(None, None)


# Generated at 2022-06-25 08:24:00.751069
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    ansible_module_0 = BecomeModule()
    string_0 = ansible_module_0.build_become_command('TEST', 'TEST')
    print(string_0)

# Generated at 2022-06-25 08:24:04.922667
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = str()
    var_1 = str()
    var_0 = become_module_0.build_become_command(var_0, var_1)
    assert var_0 is not None


# Generated at 2022-06-25 08:24:10.954904
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'su -m -c "id"'
    shell_0 = '/bin/sh'
    cmd_1 = become_build_become_command(cmd_0, shell_0)
    return cmd_1


# Generated at 2022-06-25 08:24:21.159382
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bytes_0 = b'\x86\x96\xca\xa8\x9a\xa0\x19!\xde\xfa'
    bytes_1 = b'\x9d \xa1\xe8\xcd\xed\x91I\x0f\x87b'
    bytes_2 = b'\x08\xa7@\xf1\x17\x1a\x87\x9b\x17\"!\x8e'
    become_module_0 = BecomeModule()
    bytes_3 = b'\xce\x1b\x8e\x84\xf7\xf6\x83\xb8)$\xdd\x9e'

    assert become_module_0.build_become_command(bytes_0, bytes_1) == bytes_2

# Generated at 2022-06-25 08:24:26.472652
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Make sure shell=False and cmd=None works
    bytes_0 = become_module_build_become_command(None, False)
    print(bytes_0)
    # Make sure shell=True and cmd=None works
    bytes_1 = become_module_build_become_command(None, True)
    print(bytes_1)
    # Make sure shell=True and cmd='' works
    bytes_2 = become_module_build_become_command('', True)
    print(bytes_2)
    # Make sure shell=True and cmd='whoami' works
    bytes_3 = become_module_build_become_command('whoami', True)
    print(bytes_3)

    # Make sure shell=True and cmd='whoami' works
    bytes_

# Generated at 2022-06-25 08:24:32.423183
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'whoami'
    shell = True
    var_0 = become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:24:37.979416
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # This is a test
    bytes_0 = b'\x86\x96\xca\xa8\x9a\xa0\x19!\xde\xfa'
    become_module_0 = BecomeModule()
    var_0 = become_check_password_prompt(bytes_0)

# Generated at 2022-06-25 08:24:40.065696
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command()
    print(var_0)

# Generated at 2022-06-25 08:24:42.583265
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bytes_0 = b'\x86\x96\xca\xa8\x9a\xa0\x19!\xde\xfa'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(bytes_0)