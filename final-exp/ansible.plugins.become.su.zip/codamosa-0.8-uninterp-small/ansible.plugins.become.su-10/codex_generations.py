

# Generated at 2022-06-25 08:15:29.386021
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # unit test for build_become_command
    # test case 0
    # cmd = "ls -lah"
    # shell = "/bin/sh"
    # expected_results = "su -c 'ls -lah'"
    # actual_results = become_module_0.build_become_command(cmd, shell)
    # assert actual_results == expected_results
    # test case 1
    cmd = "id"
    shell = "/bin/sh"
    expected_results = "su -c 'id'"
    actual_results = become_module_0.build_become_command(cmd, shell)
    assert actual_results == expected_results

test_case_0()

# Generated at 2022-06-25 08:15:34.000911
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    assert become_module_1.check_password_prompt('Password: ')
    assert become_module_1.check_password_prompt('パスワード： ')
    assert become_module_1.check_password_prompt('Пароль: ')
    # assert not become_module_1.check_password_prompt('what')


# Generated at 2022-06-25 08:15:36.908325
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()

    # Checking return value of check_password_prompt with 'b'''
    str_1 = b''
    bool_1 = become_module_1.check_password_prompt(str_1)
    assert bool_1 == False


# Generated at 2022-06-25 08:15:42.595870
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test args
    become_module_1 = BecomeModule()
    cmd = "/usr/bin/whoami"
    shell = "/bin/bash"

    # Test expected value
    expected_value = "/usr/bin/whoami"
    assert become_module_1.build_become_command(cmd, shell) == expected_value

# Generated at 2022-06-25 08:15:52.565343
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    become_module_1.prompt = True
    become_module_1.prompt_l10n = ['пароль']

# Generated at 2022-06-25 08:15:57.090529
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 'date'
    shell = 'sh'
    become_module_0 = BecomeModule()
    become_module_0._shell = 'sh'
    become_module_0.get_option = mock_get_option
    assert become_module_0.build_become_command(cmd, shell) == "su root -c sh -c 'date'"


# Generated at 2022-06-25 08:16:03.356821
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo 1"
    shell = "echo 1"
    result = become_module_0.build_become_command(cmd, shell)
    assert(result == "su -- -c 'echo 1'")


# Generated at 2022-06-25 08:16:08.639903
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    become_module_1.prompt_l10n = ['I/m in an american, english speaking environment']
    assert become_module_1.check_password_prompt("I don't see any of that prompts") is False
    assert become_module_1.check_password_prompt("This is the Password prompt") is True

# Generated at 2022-06-25 08:16:11.360046
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    b_output = to_bytes('Password: ')
    become_module_0 = BecomeModule()
    result = become_module_0.check_password_prompt(b_output=b_output)
    assert result == True



# Generated at 2022-06-25 08:16:21.093506
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    b_output = to_bytes(u'Senha: ')
    assert become_module_1.check_password_prompt(b_output)

    b_output = to_bytes(u'Password: ')
    assert become_module_1.check_password_prompt(b_output)

    b_output = to_bytes(u'Пароль: ')
    assert become_module_1.check_password_prompt(b_output)

    b_output = to_bytes(u'Mật khẩu: ')
    assert become_module_1.check_password_prompt(b_output)

    b_output = to_bytes(u'לקוח סיסמה: ')
   

# Generated at 2022-06-25 08:16:27.180925
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module = BecomeModule()
    b_output = to_bytes('Password:')
    assert become_module.check_password_prompt(b_output) is True

# Generated at 2022-06-25 08:16:28.599306
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()

    assert become_module_1.check_password_prompt(u'Password:') == True


# Generated at 2022-06-25 08:16:33.560848
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    success_cmd_0 = 'sudo -K && sudo -k && sudo -H -S -p "[sudo via ansible, key=uvqlxlvxgzzkveidkeewzbawbzgdyxyc] password: " -u someuser /bin/sh -c '
    success_cmd_1 = '"'
    success_cmd = success_cmd_0 + success_cmd_1 + 'cd "/home/ansible/ansible/test/integration/become_test_dir" && chmod -R 755 etc' + success_cmd_1
    result = become_module_0.check_password_prompt(to_bytes(success_cmd, errors='surrogate_or_strict'))
    assert result == True

# Generated at 2022-06-25 08:16:39.707583
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    become_module_0.prompt = True
    become_module_0.get_option = lambda x: ['Password']
    b_output = 'Password:'.encode('utf-8')
    expected_output = become_module_0.check_password_prompt(b_output)
    assert expected_output, "Return value should be True."


# Generated at 2022-06-25 08:16:45.134003
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "ls"
    shell = "/bin/bash"
    assert become_module_0.build_become_command(cmd, shell) == "su - root -c 'source /etc/profile; /bin/bash -c \"ls\"'"


# Generated at 2022-06-25 08:16:49.465254
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_1 = BecomeModule()
    become_module_1.prompt = True
    b_output = to_bytes('Password:')
    result = become_module_1.check_password_prompt(b_output)
    assert(result == True)


# Generated at 2022-06-25 08:16:52.814636
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    cmd = "id"
    shell = "/bin/sh"
    expected_result = "su  -c id"
    result = become_module_1.build_become_command(cmd, shell)

    assert result == expected_result


# Generated at 2022-06-25 08:17:01.498921
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():

    become_module_0 = BecomeModule()
    test_output = to_bytes('Password')
    assert become_module_0.check_password_prompt(test_output)

    test_output = to_bytes('Password:')
    assert become_module_0.check_password_prompt(test_output)

    test_output = to_bytes('Password：')
    assert become_module_0.check_password_prompt(test_output)

    test_output = to_bytes('Password :')
    assert become_module_0.check_password_prompt(test_output)

    test_output = to_bytes('Password：')
    assert become_module_0.check_password_prompt(test_output)

    test_output = to_bytes('Password\n')
    assert become_module_

# Generated at 2022-06-25 08:17:11.770531
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    become_module_0.set_options(become_pass=None, become_user=None, become_exe=None, become_flags=None, prompt_l10n=[])
    assert become_module_0.check_password_prompt(b'') == False
    assert become_module_0.check_password_prompt(b'\x1b[1;32m') == False
    assert become_module_0.check_password_prompt(b'\x1b[1;32mBECOME password: \x1b[0m') == True
    become_module_0.set_options(become_pass=None, become_user=None, become_exe=None, become_flags=None, prompt_l10n=['password'])
    assert become_

# Generated at 2022-06-25 08:17:21.376711
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # test case #0
    become_module_0 = BecomeModule()

    cmd = None
    shell = None
    ret = become_module_0.build_become_command(cmd, shell)
    assert ret == None

    # test case #1
    become_module_1 = BecomeModule()

    cmd = "echo"
    shell = None
    ret = become_module_1.build_become_command(cmd, shell)
    assert ret == "su -c echo"

    # test case #2
    become_module_2 = BecomeModule()

    cmd = "echo"
    shell = "/bin/bash"
    ret = become_module_2.build_become_command(cmd, shell)
    assert ret == "su -c echo"

    # test case #3
    become_module_3 = BecomeModule

# Generated at 2022-06-25 08:17:38.918576
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    become_module_0.set_options(direct={u'prompt_l10n': u'Password'})

    # Prompted for password
    assert become_module_0.check_password_prompt(b'Password : ')
    assert become_module_0.check_password_prompt(b'Password: ')

# Generated at 2022-06-25 08:17:42.083873
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():

    become_module_0 = BecomeModule()

    # From [test_case_0, test_case_0]
    b_output = to_bytes(u'')

    if become_module_0.check_password_prompt(b_output):
        # From [test_case_0, test_case_1]
        pass


# Generated at 2022-06-25 08:17:47.785053
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo "hello"'
    shell = '/bin/sh'
    returned_value = become_module_0.build_become_command(cmd=cmd, shell=shell)
    assert returned_value == 'su - root -c \'/bin/sh -c "sudo -H -S -n -u root /bin/sh -c \\\\"echo \\\\"\\\\\\"hello\\\\\\"\\\\\\"\\\\""\''

# Generated at 2022-06-25 08:17:58.248542
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    prompt_patterns = [
        # English
        "Password",
        # Romanian
        "Parolă",
        # German
        "Passwort",
        # Hungarian
        "Jelszó",
        # Thai
        "รหัสผ่าน",
        # Chinese (simplified)
        "密码",
        # Chinese (traditional)
        "密碼",
        # Catalan
        "Contrasenya",
    ]

    become_module_1 = BecomeModule()
    become_module_1.set_option('prompt_l10n', prompt_patterns)
    b_output = to_bytes("Password:")
    assert become_module_1.check_password_prompt(b_output)
    b_output = to

# Generated at 2022-06-25 08:18:07.818513
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with long command string
    become_module_build_become_command_test_0_user = "user"
    become_module_build_become_command_test_0_password = "password"
    become_module_build_become_command_test_0_cmd = "/bin/echo 'hello there'"
    become_module_build_become_command_test_0_shell = "/bin/bash"
    become_module_build_become_command_test_0_exe = "su"
    become_module_build_become_command_test_0_flags = ""
    become_module_build_become_command_test_0_become_user = become_module_build_become_command_test_0_user
    become_module_build_become_command_test_0_

# Generated at 2022-06-25 08:18:13.430721
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ['/bin/bash -l -c "whoami"']
    shell = True
    actual_result = become_module_0.build_become_command(cmd,shell)
    expected_result = 'su  root -c \'/bin/bash -l -c "whoami"\''
    assert actual_result == expected_result

    cmd = ['/bin/bash -l -c "whoami"']
    shell = False
    actual_result = become_module_0.build_become_command(cmd,shell)
    expected_result = 'su  root -c \'/bin/bash -l -c "whoami"\''
    assert actual_result == expected_result

# test for successfull switch user

# Generated at 2022-06-25 08:18:18.337852
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_2 = BecomeModule()
    cmd = ''
    shell = ''
    result = "su -c "
    assert(result == become_module_2.build_become_command(cmd, shell))


# Generated at 2022-06-25 08:18:21.808738
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'whoami'
    shell = '/bin/sh'
    become_command_0 = become_module.build_become_command(cmd, shell)
    assert become_command_0 == 'su  - root -c whoami'

# Generated at 2022-06-25 08:18:31.248628
# Unit test for method check_password_prompt of class BecomeModule
def test_BecomeModule_check_password_prompt():
    become_module_0 = BecomeModule()
    become_module_0.prompt = True
    become_module_0.name = 'sudo'
    become_module_0.fail = ['Authentication failure']

    assert become_module_0.check_password_prompt(b'xxsudo:') == True
    assert become_module_0.check_password_prompt(b'xxsudo: ') == True
    assert become_module_0.check_password_prompt(b'xxsudo: xx') == True

    assert become_module_0.check_password_prompt(b'xxsudO:') == True
    assert become_module_0.check_password_prompt(b'xxsudO: ') == True

# Generated at 2022-06-25 08:18:37.966987
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'ls'
    shell = ''
    cmd_expected = 'su  root -c \'ls\''
    cmd_actual = become_module_1.build_become_command(cmd, shell)
    assert cmd_expected == cmd_actual


# Generated at 2022-06-25 08:19:01.449697
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Testing empty command
    assert become_module.build_become_command(cmd='', shell=None) == ''

    # Testing with real command
    cmd = 'ls /tmp'
    assert become_module.build_become_command(cmd=cmd, shell=None) == 'su   -c \'ls /tmp\''

    # Testing with executable option
    become_module.options['become_exe'] = 'sudo'
    assert become_module.build_become_command(cmd=cmd, shell=None) == 'sudo   -c \'ls /tmp\''

    # Testing with flags option and user option
    become_module.options['become_flags'] = '-p'
    become_module.options['become_user'] = 'admin'
    assert become_module.build_

# Generated at 2022-06-25 08:19:10.840932
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()

    cmd = ''
    shell = ''
    actual_result = become_module.build_become_command(cmd, shell)
    expected_result = ''
    assert actual_result == expected_result

    cmd = 'ls -l'
    shell = ''
    actual_result = become_module.build_become_command(cmd, shell)
    expected_result = 'su -s /bin/sh test_user -c "ls -l"'
    assert actual_result == expected_result

    cmd = 'ls -l'
    shell = None
    actual_result = become_module.build_become_command(cmd, shell)
    expected_result = 'su -s /bin/sh test_user -c "ls -l"'
    assert actual_result == expected_result


# Generated at 2022-06-25 08:19:13.571563
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'ls -l'
    shell = ''

    result = become_module.build_become_command(cmd, shell)

    assert result == "su root -c  ls -l"


# Generated at 2022-06-25 08:19:16.344069
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = 'sh'
    become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:19:25.078365
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """Unit test for build_become_command

    :return: None
    """
    become_module = BecomeModule()
    # Test case with options
    assert 'su -c echo "hello"' == become_module.build_become_command('echo "hello"', None)

    # Test case with shell
    assert 'su -c /bin/sh -c echo "hello"' == become_module.build_become_command('echo "hello"', '/bin/sh')

if __name__ == '__main__':
    # test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:19:29.629313
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # Bug: https://github.com/ansible/ansible/issues/46112
    # Test case verifies that Build's succeed even though no become_pass is set
    cmd = ''
    shell = ''
    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'su -c ""'
    # Test case verifies that function doesn't break when cmd is present
    cmd = 'echo test'
    shell = ''
    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'su -c "echo test"'

    # Test case verifies that function doesn't break when cmd & shell are present
    cmd = 'echo test'
    shell = 'testshell'

# Generated at 2022-06-25 08:19:34.410979
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    cmd = [ 'ls', '-l' ]
    shell = '/bin/bash'
    become_exe = 'su'
    become_flags = '-m'
    become_user = 'abc'
    success_cmd = 'ls -l'
    expected = "%s %s %s -c %s" % (become_exe, become_flags, become_user, shlex_quote(success_cmd))

    result = become_module.build_become_command(cmd, shell)

    assert result == expected

# test for method check_password_prompt of class BecomeModule

# Generated at 2022-06-25 08:19:46.563837
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ["cmd"]
    shell_true = True
    shell_false = False

    become_module_0.build_become_command(cmd, shell_true)
    assert 'su root -c cmd' == become_module_0.build_become_command(cmd, shell_true)
    assert 'su root -c cmd' == become_module_0.build_become_command(cmd, shell_false)

    become_module_0.become_pass = "passwd"
    become_module_0.build_become_command(cmd, shell_true)
    assert 'su root -c cmd' == become_module_0.build_become_command(cmd, shell_true)
    assert 'su root -c cmd' == become_module_0.build_

# Generated at 2022-06-25 08:19:52.975031
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    # Test 1
    cmd = "ls"
    shell = "/bin/sh"
    assert become_module.build_become_command(cmd, shell) == "su  root -c /bin/sh -c 'ls'"

    # Test 2
    cmd = "ls"
    shell = "/bin/sh"
    assert become_module.build_become_command(cmd, shell) == "su  root -c /bin/sh -c 'ls'"

    # Test 3
    cmd = "ls"
    shell = None
    assert become_module.build_become_command(cmd, shell) == "su  root -c /bin/sh -c 'ls'"

    # Test 4
    cmd = "ls"
    shell = "/bin/sh"
    assert become_module.build_

# Generated at 2022-06-25 08:19:55.759837
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'ls -la'
    shell = None
    assert become_module_1.build_become_command(cmd, shell) == 'su - root -c ls -la'


# Generated at 2022-06-25 08:20:09.686994
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_obj = BecomeModule()
    cmd = 'touch ttt'
    expected_result = 'su root -c touch ttt'
    '''
    Assertion Error.
    Expected result: 'su root -c touch ttt'
    Actual result: 'su  -c touch ttt'
    '''
    actual_result = become_module_obj.build_become_command(cmd, False)
    assert expected_result == actual_result


# Generated at 2022-06-25 08:20:14.252090
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "true"
    shell = "cmd"
    become_command = become_module_0.build_become_command(cmd, shell)
    assert become_command == 'su  -c true', "become_command: %s" % become_command


# Generated at 2022-06-25 08:20:22.492299
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # Run method build_become_command of class BecomeModule with arg "ls -l" and
    # shell=True
    ret_1 = become_module_0.build_become_command("ls -l", True)
    assert ret_1 == "su  root -c 'ls -l'"

    # Run method build_become_command of class BecomeModule with arg "ls -l" and
    # shell=False
    ret_2 = become_module_0.build_become_command("ls -l", False)
    assert ret_2 == "su  root -c 'ls -l'"

    # Run method build_become_command of class BecomeModule with arg "" and
    # shell=True

# Generated at 2022-06-25 08:20:27.535139
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import shlex_quote
    become_module_0 = BecomeModule()
    become_module_0.prompt = True
    become_module_0.get_option = lambda x: None
    # Since we can't expect the shell type this is hard to test
    #become_module_0.build_become_command(cmd, shell)
    #assert cmd == "su -c 'whoami'"
    #assert shell == "/bin/sh"

    #become_module_0.get_option = lambda x: x == 'become_exe' and 'test_become_exe' or None

# Generated at 2022-06-25 08:20:28.145715
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert True


# Generated at 2022-06-25 08:20:37.989022
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case = [
        {
            # cmd is not None
            "cmd": None,
            "expect_result": None,
        },
        {
            # cmd is not None
            "cmd": "whoami",
            "expect_result": "su -c whoami",
        },
    ]

    become_module_0 = BecomeModule()
    for case in test_case:
        cmd = case["cmd"]
        expect_result = case["expect_result"]
        result = become_module_0.build_become_command(cmd, shell=False)
        if result != expect_result:
            raise AssertionError("%s != %s" % (result, expect_result))



# Generated at 2022-06-25 08:20:43.462791
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "ls"
    shell = "/bin/sh"

    # Test with default values
    become_module_1.success_method = "su"
    become_module_1.prompt_method = "su"
    become_module_1.prompt = True
    become_module_1.build_become_command(cmd, shell)
    assert become_module_1.prompt == True
    assert become_module_1.success_cmd == "ls"
    assert become_module_1.become_cmd == "su root -c \"ls\""

    # Test with custom values
    become_module_1.success_method = "su"
    become_module_1.prompt_method = "su"
    become_module_1.prompt = False
   

# Generated at 2022-06-25 08:20:49.876902
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'pwd'
    shell_0 = 'sh'
    assert become_module_0.build_become_command(cmd_0, shell_0) == "su  root -c 'pwd'"
    cmd_1 = ''
    shell_1 = 'csh'
    assert become_module_0.build_become_command(cmd_1, shell_1) == ''
    cmd_2 = 'sudo echo "Hello, world!"'
    shell_2 = 'sh'

# Generated at 2022-06-25 08:20:55.073930
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda option, default=None: default
    become_module_1.get_option.__self__ = become_module_1
    assert become_module_1.build_become_command(cmd='whoami', shell='csh') == "su -c 'whoami'"


# Generated at 2022-06-25 08:21:04.171262
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.prompt = True
    # Builds become command
    # Expected: 'su '
    cmd = ''
    shell = None
    assert become_module_0.build_become_command(cmd, shell) == 'su '


# Generated at 2022-06-25 08:21:13.756094
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command('', str())


# Generated at 2022-06-25 08:21:15.723923
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '=d60?'
    str_1 = 'e'
    become_module_0 = BecomeModule()
    return_val = become_module_0.build_become_command(str_0, str_1)
    return return_val


# Generated at 2022-06-25 08:21:21.519631
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = 'JeSoz^9V,$:o&4y\\_fD'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(str_0, '')


# Generated at 2022-06-25 08:21:30.359417
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # check in case a differnt become_exe is set
    become_module_0.set_options({'become_exe': 'sudo'})
    # match the '-S' flag we pass
    flags_str = '-S'
    become_module_0.set_options({'become_flags': flags_str})
    cmd = 'cat /tmp/foo'
    result = become_module_0.build_become_command(cmd, shell=False)
    cmd_intended = 'sudo -S -c cat /tmp/foo'
    assert result == cmd_intended, "build_become_command gives %s; expected %s" % (result, cmd_intended)


# Generated at 2022-06-25 08:21:33.438109
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command()

# Generated at 2022-06-25 08:21:38.278096
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = 'm'
    str_1 = '?'
    var_0 = become_module_0.build_become_command(str_0, str_1)
    var_1 = 'su -c m'
    assert var_0 == var_1



# Generated at 2022-06-25 08:21:43.942403
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = 'hP<S[-g(5x5h -p*'
    str_1 = 'oB@]|'
    var_0 = become_build_become_command(str_0, str_1)


# Generated at 2022-06-25 08:21:47.098156
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command()


# Generated at 2022-06-25 08:21:56.884216
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '$bkK)fR9X,(:Myi8.K(.%c'
    str_1 = '@8Wk^M;{9.9Mb'
    str_2 = 'V'
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(str_0, str_1, str_2)
    return var_0

# Generated at 2022-06-25 08:22:02.699078
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_2 = BecomeModule()
    cmd_2 = ''
    shell_2 = ''
    var_2 = become_module_2.build_become_command(cmd_2, shell_2)
    pass


# Generated at 2022-06-25 08:22:25.266529
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    var_1 = '|'
    become_module_0 = BecomeModule(var_1)
    str_0 = 'D9>s`|d`@hUJ:6'
    var_2 = ''
    var_3 = become_module_0.build_become_command(str_0, var_2)


# Generated at 2022-06-25 08:22:30.479807
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = 'XZQPJH8R#@bh'
    become_module_0 = BecomeModule()
    str_1 = 'kPZ9'
    var_0 = become_build_become_command(str_0, str_1)


# Generated at 2022-06-25 08:22:38.019186
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = 'UlzBI0&;_q8?!"oT%QI}'
    str_1 = 'y>ct{2r|+UH#9U'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(str_0, str_1)
    assert var_0 == 'su -c \'y>ct{2r|+UH#9U\''

# Generated at 2022-06-25 08:22:41.142396
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    command = ['ps']
    shell = '/bin/sh'
    become_module_0 = BecomeModule()
    command_0 = become_module_0.build_become_command(command, shell)
    print(str(command_0))


# Generated at 2022-06-25 08:22:42.029910
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command()

# Generated at 2022-06-25 08:22:44.559404
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '9^AJ})aQ@v%>/f'
    str_1 = ')'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(str_1, str_0)


# Generated at 2022-06-25 08:22:51.562487
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'IH'
    shell_0 = 'kv,x}'
    var_0 = become_module_0.build_become_command(cmd_0, shell_0)
    # assert var_0 == "/bin/su -l adm -c /bin/sh -c IH --login"

if __name__ == '__main__':
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:22:59.273394
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd_0 = "su - root"
    shell_0 = "/bin/sh"
    become_module_0 = BecomeModule()
    # Call the method
    str_0 = become_module_0.build_become_command(cmd_0, shell_0)
    cmd_1 = "su - root"
    shell_1 = "/bin/sh"
    become_module_1 = BecomeModule()
    # Call the method
    str_1 = become_module_1.build_become_command(cmd_1, shell_1)
    cmd_2 = "su - root"
    shell_2 = "/bin/sh"
    become_module_2 = BecomeModule()
    # Call the method
    str_2 = become_module_2.build_become_command(cmd_2, shell_2)



# Generated at 2022-06-25 08:23:00.462731
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Note: must be tested via unit tests as otherwise we cannot test
    # the behavior of dynamic ansible options.
    assert False


# Generated at 2022-06-25 08:23:07.117769
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '&_sC?d0'
    become_module_0 = BecomeModule()
    var_0 = become_module_0
    str_1 = '!Kl'
    str_2 = 'Xi4'
    var_1 = become_module_0.build_become_command(str_1, str_2)

if __name__ == '__main__':
        test_case_0()
        test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:23:47.737596
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Command
    cmd = 'ls'

    # Shell
    shell = '/bin/sh'

    self = BecomeModule()
    # Expected
    expected = 'su root -c ls'
    self.prompt = True
    # Result
    result = self.build_become_command(cmd, shell)
    assert result == expected


# Generated at 2022-06-25 08:23:58.178968
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    method_args = {'cmd': None,
                   'shell': None,
                   '_orig_become_exe': None,
                   '_orig_become_flags': None,
                   '_orig_become_user': None,
                   '_orig_become_prompt': None,
                   '_orig_prompt': True,
                   '_shell_type': None}
    method_result = {'rc': None,
                     'stdout': None,
                     'stderr': None,
                     'start_time': None,
                     'end_time': None,
                     'delta': None,
                     'cmd': None,
                     'prompt': True}
    return become_module_0.build_become_command(**method_args), method_result

# Generated at 2022-06-25 08:24:03.624152
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = 'xWb)8<w7vlE-{}'
    str_1 = '/D'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(str_0, str_1)


# Generated at 2022-06-25 08:24:12.824801
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '@Rb0xvf0<&?~a-5'
    print(len(str_0))
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(str_0, str_0)
    print(var_0)

test_case_0()
test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:24:16.925765
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Setup
    cmd = ""
    shell = None
    become_module_0 = BecomeModule()

    # Invocation
    retval = become_module_0.build_become_command(cmd, shell)

    # Verification
    assert type(retval) == str, "Return value of build_become_command method is not a str"



# Generated at 2022-06-25 08:24:20.982840
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '9'
    str_1 = 'B'
    become_module_0 = BecomeModule()
    str_2 = become_module_build_become_command(str_0, str_1)


# Generated at 2022-06-25 08:24:27.304866
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    string_0 = 'jEo6Q9XOz3'
    string_1 = 'Dl6U,:6U>}S'
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(string_0, string_1)
    print(var_0)
    print(string_0)
    print(string_1)
    print(become_module_0)

# Generated at 2022-06-25 08:24:29.286739
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = 'sN|#3qI T(>eCi/'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(str_0)


# Generated at 2022-06-25 08:24:36.719873
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_parameters = []

    test_parameters.append({"cmd": "", "shell": False})

    test_parameters.append({"cmd": ",yKjSaOEWIw$-k.HjKZ", "shell": True})

    test_parameters.append({"cmd": "p!m@$w#g&xJIl{na", "shell": True})

    test_parameters.append({"cmd": "E/4qw3qGz", "shell": False})

    test_parameters.append({"cmd": "DjKc$*0W^1*pB+x#0z>rv9XfajDd", "shell": False})


# Generated at 2022-06-25 08:24:46.749383
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  i = 0
  # success_cmd = ''
  cmd = 'cmd'
  shell = 'shell'
  become_module_0 = BecomeModule()
  # [0]:
  # success_cmd = 'shell -c cmd'
  i += 1
  var_0 = become_module_0.build_become_command(cmd, shell)
  if var_0 != 'su -c shell -c cmd':
    raise Exception("Test case failed at: test_BecomeModule_build_become_command_case_#" + str(i))
    return

  # [1]:
  # success_cmd = 'shell -c cmd'
  i += 1
  become_module_0.prompt = False
  var_0 = become_module_0.build_become_command(cmd, shell)