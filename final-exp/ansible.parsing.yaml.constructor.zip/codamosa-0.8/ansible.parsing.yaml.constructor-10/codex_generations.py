

# Generated at 2022-06-11 09:15:14.023803
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var
    import ansible.constants as C
    C.HOST_KEY_CHECKING = False

    yaml_str = '''

- key1:
    - item1
- key2:
    - item2
    - item3
- key3:
    - item4
    - item5
'''
    print("yaml_str:\n%s\n" % yaml_str)

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    print("data:%s\n" % dir(data))
    print("data:%s\n" % data)

# Generated at 2022-06-11 09:15:20.500883
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    class test_node:
        def __init__(self, value):
            self.value = value
            self.start_mark = "test"

    output = ansible_constructor.construct_yaml_str(test_node('test'))
    assert output == u'test'
    assert isinstance(output, AnsibleUnicode)
    assert output.ansible_pos is None



# Generated at 2022-06-11 09:15:29.818113
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    stream = '''
- alpha
- beta
- gamma
'''
    s = AnsibleLoader(None, stream).get_single_data()
    assert isinstance(s, AnsibleSequence)
    assert len(s) == 3
    assert s.has_ansible_types()

    stream = '''
- 1
- 2
- 3
'''
    s = AnsibleLoader(None, stream).get_single_data()
    assert isinstance(s, AnsibleSequence)
    assert len(s) == 3
    assert not s.has_ansible_types()

    stream = '''
- 1
- 2
- 3
'''

# Generated at 2022-06-11 09:15:31.397751
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    pass


# Generated at 2022-06-11 09:15:40.615948
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    from yaml import load, dump
    contructor = AnsibleConstructor()
    str1 = u"\n- letsencrypt_certificate:\n"
    str2 = "    - domains: [domain.tld, www.domain.tld]\n"
    str3 = "      email: test@domain.tld\n"
    str4 = "    - domains: [domain.tld, www.domain.tld]\n"
    str5 = "      email: test@domain.tld\n"
    contains = str1 + str2 + str3 + str4 + str5
    yaml_str = contructor.construct_yaml_str(contains)
    assert isinstance(yaml_str, AnsibleUnicode)

# Generated at 2022-06-11 09:15:50.148178
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.host import Host
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-11 09:16:00.203537
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor(vault_secrets=['secret_key'])

# Generated at 2022-06-11 09:16:10.683432
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    data = """
    - value01
    - value02
    - value03
    """
    # Monkeypatch stdin/stdout/stderr
    saved_stdin = sys.stdin
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    sys.stdin = to_bytes(data)
    sys.stdout = io.open(os.devnull, 'wb')
    sys.stderr = io.open(os.devnull, 'wb')

    # Perform the test
    import yaml
    list_result = yaml.load(data, Loader=AnsibleConstructor)
    print(list_result)

    # Revert the monkeypatching
    sys.stdin = saved_stdin
    sys.stdout = saved_stdout

# Generated at 2022-06-11 09:16:20.266034
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constr = AnsibleConstructor()
    value_node = u'value_node'
    key_node = u'key_node'
    node = MappingNode(u'tag:yaml.org,2002:map', [key_node, value_node], start_mark=None, end_mark=None, flow_style=None)
    deep = False
    with mock.patch('ansible.parsing.yaml.objects.AnsibleMapping', autospec=True) as mock_mapping:
        res = constr.construct_mapping(node, deep)
        res.update.assert_called_once_with(value_node)
        mock_mapping.assert_called_once_with()
        assert res == mock_mapping

        # Exception case
        res.update.side_effect = Exception

# Generated at 2022-06-11 09:16:31.739547
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys

    def _print(line, **kwargs):
        # noinspection PyProtectedMember
        print(line.encode(sys.stdout.encoding, 'replace').decode(sys.stdout.encoding), **kwargs)

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars

    loader = AnsibleCollectionLoader()

    # test empty dict
    node = AnsibleBaseYAMLObject(loader=loader)
    mapping = AnsibleConstructor().construct_m

# Generated at 2022-06-11 09:16:45.099380
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    def construct_yaml_str(node):
        return node.tag.split('!', 1)[1]

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleConstructor, self).__init__(*args, **kwargs)
            self.add_constructor(u'tag:yaml.org,2002:str', construct_yaml_str)

    def test_default_unicode_yaml_str_constructor():
        test_yaml_str = 'default unicode string with no tag'

# Generated at 2022-06-11 09:16:55.440149
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test AnsibleConstructor.construct_yaml_str(node) with node is unicode
    node = {'test':'test'}
    node = to_bytes(node)
    node = u'[{0}]'.format(node)
    ansible_constructor = AnsibleConstructor()
    data = ansible_constructor.construct_yaml_str(node)
    assert data == '[{0}]'
    # Test AnsibleConstructor.construct_yaml_str(node) with node is bytes
    node = {'test':'test'}
    node = to_bytes(node)
    node = u'{0}'.format(node)
    data = ansible_constructor.construct_yaml_str(node)
    assert data == {'test':'test'}


# Generated at 2022-06-11 09:17:04.705817
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class MockVaultLib(VaultLib):
        def __init__(self):
            self.secrets = []
        def decrypt(self, ciphertext):
            return 'value'

    constructor = AnsibleConstructor()
    constructor._vaults['default'] = MockVaultLib()
    with open('test/unit/parsing/yaml/constructor_test.yml', 'r') as f:
        data = yaml.load(f, Loader=AnsibleConstructor)
        assert isinstance(data['vault'], AnsibleUnsafeText)
        assert data['vault'] == 'value'

# Generated at 2022-06-11 09:17:08.142408
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import objects
    input_data = {'x': objects.AnsibleUnsafeText('${foo}')}
    output_data = {'x': '${foo}'}
    assert AnsibleConstructor().construct_yaml_unsafe(input_data) == output_data

# Generated at 2022-06-11 09:17:10.826821
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    test_AnsibleConstructor = AnsibleConstructor()
    class testclass:
        pass
    test = testclass()
    test.id = "str"
    result = test_AnsibleConstructor.construct_yaml_unsafe(test)
    assert(result == "str")

# Generated at 2022-06-11 09:17:17.723721
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    s = u"""- 1
    - 2
    - 3"""
    yaml_obj = yaml.load(s, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, list)
    assert len(yaml_obj) == 3
    assert yaml_obj[0] == 1
    assert yaml_obj[1] == 2
    assert yaml_obj[2] == 3

# Generated at 2022-06-11 09:17:27.993745
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test case with duplicate keys
    test_case1 = """
        key1: value1
        key2: value2
        key1: value3
        """
    parsed_data = AnsibleConstructor(C.DEFAULT_VAULT_ID_MATCH).construct_yaml_map(yaml.compose(test_case1))
    assert parsed_data.get('key1') == 'value3'

    # Test case with duplicate keys
    # Ignore duplicate keys
    test_case2 = {
        'key1': 'value1',
        'key2': 'value2',
        'key1': 'value3'
    }
    parsed_data = AnsibleConstructor(C.DEFAULT_VAULT_ID_MATCH).construct_mapping(yaml.compose(test_case2))
    assert parsed_data

# Generated at 2022-06-11 09:17:34.153326
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    vault_secret = 'test'
    file_name = 'test'
    data = "test1, test2, test3"
    constructor = AnsibleConstructor(file_name=file_name, vault_secrets=[vault_secret])
    # Mapping from a tag to a python type.
    with constructor.node_yaml_type(u'tag:yaml.org,2002:seq'):
        assert constructor.construct_yaml_seq(data) == ['test1', 'test2', 'test3']


# Generated at 2022-06-11 09:17:46.441441
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    vault = VaultLib(secrets=[u"supersecret"])

    class Node(object):
        def __init__(self, start_mark):
            self.start_mark = start_mark

    # As a convenience we wrap the vault constructor, but this makes it hard to test.  So:
    class UnsafeAnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        def __new__(cls, *args, **kwargs):
            return AnsibleUnsafeText.__new__(cls, *args, **kwargs)

    # A base64-encoded "hello world" string encrypted with vault

# Generated at 2022-06-11 09:17:54.477343
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_block = '''
---
- name: A
  a: 1
  b: 2
- name: B
  b: 1 # DUPLICATE
  b: 2 # DUPLICATE
  c: 3
- name: C
  c: 1
  d: 2
- name: D
  d: 1 # DUPLICATE
  e: 2
  d: 3 # DUPLICATE
- name: E
  d: 1 # DUPLICATE
  e: 2
  e: 3 # DUPLICATE
'''
    items = []
    display = Display()
    for version in range(3):
        # TODO: Why are we iterating over versions?
        d = AnsibleConstructor(file_name='test').get_single_data(yaml_block, vault_secrets=['ansible'])
       

# Generated at 2022-06-11 09:18:13.310487
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test if YAML data with duplicate dict keys raise a warning
    with warnings.catch_warnings(record=True) as warn:
        data = yaml.load('''
                        data: "some test data"
                        data: "test data"
                    ''', AnsibleConstructor)
        assert len(warn) == 1
        assert issubclass(warn[-1].category, UserWarning)
        assert "duplicate dict key" in str(warn[0].message)

# Generated at 2022-06-11 09:18:18.344714
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = 'key1: value1\n' \
           'key2: value2\n' \
           'key1: value3\n'
    from io import StringIO
    yaml_stream = StringIO(data)
    yaml_mapping = AnsibleConstructor().get_single_data(yaml_stream)
    assert yaml_mapping['key1'] == 'value3'



# Generated at 2022-06-11 09:18:28.350381
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.composer import Composer
    from yaml.scanner import Scanner

    yaml_str = b'''---
test_str: !<tag:yaml.org,2002:str> "test str"
test_dict:
    key1: !<tag:yaml.org,2002:str> "test str"
    key2: !<tag:yaml.org,2002:str> "test str"
'''
    s_obj = Scanner()
    c_obj = Composer(s_obj, AnsibleConstructor())
    node = c_obj.get_node()
    AnsibleConstructor.construct_yaml_str(node, c_obj)

# Generated at 2022-06-11 09:18:37.484244
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import pdb
    from yaml import load
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_list = "[1, 2, 3]"

    # pdb.set_trace()
    # construct_yaml_seq is a generator, so it needs to be called like this:
    for yaml_list in AnsibleConstructor().construct_yaml_seq(load(yaml_list, Loader=AnsibleLoader)):
        pass

    assert isinstance(yaml_list, AnsibleSequence)
    assert isinstance(yaml_list[0], AnsibleUnicode)
    assert isinstance(yaml_list[1], AnsibleUnicode)
    assert isinstance(yaml_list[2], AnsibleUnicode)

# Generated at 2022-06-11 09:18:43.468360
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class YamlConstructor(AnsibleConstructor):
        def __init__(self):
            AnsibleConstructor.__init__(self)
            self.yaml = None

        def construct_yaml_map(self, node):
            self.yaml = super(YamlConstructor, self).construct_yaml_map(node)

    yaml = """
        foo: bar
        baz:
          qux: quux
    """
    yaml_constructor = YamlConstructor()

    try:
        yaml_constructor.construct_yaml_map(yaml)
    except Exception as e:
        raise e

    assert next(yaml_constructor.yaml).ansible_pos == ('<string>', 1, 1)



# Generated at 2022-06-11 09:18:57.048561
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    test_seq = [1, 2, 3, 'foo']
    test_map = {'a': 1, 'b': 2, 'c': 3}

    import os
    import tempfile
    (fd, temp_file) = tempfile.mkstemp()
    fp = os.fdopen(fd, 'w')
    fp.write(u'{0}\n{1}\n'.format(test_seq, test_map))
    fp.close()

    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml import load

    with open(temp_file, 'rb') as f:
        ans_yaml = load(f, Loader=AnsibleLoader)

# Generated at 2022-06-11 09:19:00.405528
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ac = AnsibleConstructor()

    seq_node = {"a": 1, "b": 2, "c": 3}
    ans_seq = ac.construct_yaml_seq(seq_node)

    assert(ans_seq.__class__ == AnsibleSequence)


# Generated at 2022-06-11 09:19:07.882267
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    this_path = os.path.dirname(os.path.realpath(__file__))
    display.verbosity = 4  # Ensure the test runs in quiet mode
    ansible_constructor = AnsibleConstructor(vault_secrets=['test'])
    with open('%s/vault_test_file.yml' % this_path, 'r') as f:
        test_yaml = yaml.load(f, Loader=AnsibleConstructor)
    assert test_yaml['key'] == 'value'

# Generated at 2022-06-11 09:19:17.879922
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_src = """
foo : bar1
foo : bar2
"""
    # ansible_pos contains file name, line, column
    ansible_pos = (None, 1, 3)
    expected_result = {'foo': u'bar2'}
    expected_result.ansible_pos = ansible_pos
    for item in ['warn', 'error', 'ignore']:
        C.DUPLICATE_YAML_DICT_KEY = item
        data = AnsibleConstructor().construct_yaml_map(yaml.parse(yaml_src))
        assert data == expected_result
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    data = AnsibleConstructor().construct_yaml_map(yaml.parse(yaml_src))
    assert data == expected

# Generated at 2022-06-11 09:19:27.719729
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    assert isinstance(True, type(ansible_constructor.construct_yaml_unsafe(True)))
    assert isinstance(False, type(ansible_constructor.construct_yaml_unsafe(False)))
    assert isinstance("string type", type(ansible_constructor.construct_yaml_unsafe("string type")))
    assert isinstance(1, type(ansible_constructor.construct_yaml_unsafe(1)))
    assert isinstance(1.0, type(ansible_constructor.construct_yaml_unsafe(1.0)))
    assert isinstance({}, type(ansible_constructor.construct_yaml_unsafe({})))
    assert isinstance([], type(ansible_constructor.construct_yaml_unsafe([])))

# Generated at 2022-06-11 09:19:46.497326
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create data to be used for testing the function construct_vault_encrypted_unicode of class AnsibleConstructor
    class AnsibleVaultEncryptedUnicode():
        ansible_pos = ''

    class ConstructorError():
        context = None
        context_mark = None
        problem = ''
        problem_mark = ''
        note = None

    class ValueNode():
        start_mark = ''

    class AnsibleSafeLoader():
        def __init__(self, vault_secrets=None):
            self.vault_secrets = vault_secrets or []

    class VaultLib():
        def __init__(self, secrets=None):
            self.secrets = secrets or []

    class Vault():
        ansible_pos = ''
        vault = ''


# Generated at 2022-06-11 09:19:54.002130
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    invalid_map = '''
    - alpha: one
      bravo: two
    - charlie: three
      delta: four
    '''
    invalid_map_exception = (
        u'While constructing a mapping from {1}, line {2}, column {3}, found a duplicate dict key ({0}).'
        u' Using last defined value only.'
    )

    # test for duplicate dict key error
    try:
        AnsibleConstructor.construct_yaml_map(invalid_map)
    except ConstructorError as e:
        assert to_unicode(e.problem).startswith(invalid_map_exception)
    else:
        assert False, 'the construct_yaml_map method did not raise an exception'

    # test for non-duplicate dict keys

# Generated at 2022-06-11 09:20:03.352854
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.hashing import secure_hash
    from ansible.utils.unsafe_proxy import wrap_var

    # Construct an AnsibleConstructor object
    ac = AnsibleConstructor(file_name='testfile')

    # Construct a VaultLib object
    vault_secret = 'unittest'
    vault_hash = secure_hash(vault_secret)
    vault = VaultLib(vault_hash)
    ac._vaults['default'] = vault

    # Construct a node object

# Generated at 2022-06-11 09:20:09.757392
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    secrets = ['foo']
    constructor = AnsibleConstructor(vault_secrets=secrets)
    node = AnsibleVaultEncryptedUnicode('!vault-encrypted $ANSIBLE_VAULT;1.1;AES256;foo\n61636465666768696a6b6c6d6e6f70', vault_secrets=secrets)
    ret = constructor.construct_vault_encrypted_unicode(node)
    assert ret == u'abcdefghijklmnop'

# Generated at 2022-06-11 09:20:13.358586
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    plaintext_data = 'plaintext_data'
    vault = VaultLib(secrets=['password'])
    b_ciphertext_data = vault.encrypt(plaintext_data)
    ret = AnsibleVaultEncryptedUnicode(b_ciphertext_data)
    ret.vault = vault

# Generated at 2022-06-11 09:20:15.480591
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    try:
        constructor.construct_mapping(1)
        assert False
    except ConstructorError:
        assert True


# Generated at 2022-06-11 09:20:19.058738
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # test with None
    res = AnsibleConstructor.construct_vault_encrypted_unicode(None)
    assert res == None

    # test with empty string
    res = AnsibleConstructor.construct_vault_encrypted_unicode('')
    assert res == ''


# Generated at 2022-06-11 09:20:24.067436
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    yaml_string = r'''
# This is a simple YAML list.
- 1.0
- 2
- 3
'''
    data = list(yaml.load_all(yaml_string, Loader=AnsibleConstructor))
    assert data == [1.0, 2, 3]



# Generated at 2022-06-11 09:20:26.735227
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ctor = AnsibleConstructor()
    value = ctor.construct_yaml_map(MappingNode())
    assert value is not None


# Generated at 2022-06-11 09:20:31.831414
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    class MockYamlNode:
        id = 'object'

    class MockUnsafeConstructor:
        def construct_object(self, node):
            return node.value

    yaml_constructor = AnsibleConstructor()
    yaml_constructor.construct_object = MockUnsafeConstructor().construct_object
    assert yaml_constructor.construct_yaml_unsafe(MockYamlNode('test')) == 'test'

# Generated at 2022-06-11 09:20:47.932609
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # simple test string
    test_dict = {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5'}
    assert all([isinstance(k, AnsibleUnicode) and isinstance(v, AnsibleUnicode) for k,v in test_dict.items()]) is True

    # create an instance of AnsibleConstructor, use it to parse the test_dict string
    test_loader = AnsibleLoader(None, None)
    test_constructor = test_loader.constructor

# Generated at 2022-06-11 09:20:51.996626
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    c = AnsibleConstructor(file_name=None, vault_secrets=None)
    m = c.construct_yaml_map(None)

    assert isinstance(m, AnsibleMapping)
    assert isinstance(m, dict)


# Generated at 2022-06-11 09:20:55.434760
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    construct = AnsibleConstructor()
    node = construct.construct_scalar("foo")
    result = construct.construct_yaml_str(node)
    assert result.__class__.__name__ == 'AnsibleUnicode'
    assert result == 'foo'



# Generated at 2022-06-11 09:21:04.776495
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = '!vault $ANSIBLE_VAULT;1.2;AES256;example\n36643035393437326234363735353237313933633430346462343733373830353364663737363365\n34303633653934653530346538666462373530346162366165363966303536333536656133313961\n31363039383266356437623731623336613866626631306133353564653532376436393539616134\n6365353036616336623264356639636431306632663930376437333464\n'
    vault_secrets = [ 'example' ]
    vault_secrets.reverse()

# Generated at 2022-06-11 09:21:16.123638
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    class MockBaseConstructor:
        def __init__(self):
            self._vaults = {}
            self._vaults['default'] = VaultLib(secrets=[])

        def construct_scalar(self, node):
            return str(node)

    class MockNode:
        def __init__(self, start_mark):
            self.start_mark = start_mark

    yaml_info = {'start_mark': MockNode(start_mark=u'<string>')}

    # Create a node.
    node = MockNode(**yaml_info)

    # Create an AnsibleConstructor object.
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults = MockBaseConstructor()._vaults

    # Test construct_vault_encrypted_unicode method.
    ret

# Generated at 2022-06-11 09:21:21.043479
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # pylint: disable=protected-access
    constructor = AnsibleConstructor()
    constructor.construct_yaml_map = lambda node: {}
    constructor.construct_scalar = lambda node: "abc"
    ret = constructor.construct_yaml_str()
    assert ret == 'abc'
    assert type(ret) == AnsibleUnicode
    assert ret.ansible_pos == ('<string>', 0, 0)

# Generated at 2022-06-11 09:21:24.009665
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    C = AnsibleConstructor
    assert '!unsafe 42' == yaml.dump(C.construct_yaml_unsafe(yaml.parser.Parser().get_single_node(b'!unsafe 42')))

# Generated at 2022-06-11 09:21:33.487109
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml import nodes

    # Test with encrypted data
    test_yaml = '!vault | \n          $ANSIBLE_VAULT;1.1;AES256\n          39333166323935336534633937633462623463666365396466323361666230306535333130663138\n          39323433356564616335363033663966663466633836343231646463633035643933663031350a34\n          61343165646536633565393638643465656436343432646231666336306631333035613464333133\n          6564633536316338343132616464336362333139393932373763306435656564383365646634650a'

# Generated at 2022-06-11 09:21:42.218431
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    class AnsibleConstructorTest(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            self._ansible_file_name = file_name
            super(AnsibleConstructorTest, self).__init__()
            self._vaults = {}
            self.vault_secrets = vault_secrets or []
            self._vaults['default'] = VaultLib(secrets = self.vault_secrets)

    class Node:
        start_mark = "Node"
    vault_secrets = ["truc"]
    node = Node()
    # make a node with a content matching a vault encrypted data
    node.value = "truc" * 8 * 16
    yaml_constructor = AnsibleConstructorTest(None, vault_secrets)
   

# Generated at 2022-06-11 09:21:52.119537
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class StrAnsibleMapping(AnsibleMapping):
        def __str__(self):
            return AnsibleDumper().dump(self, Dumper=AnsibleDumper, default_flow_style=False, indent=2)

    yaml_text = """
    first_map:
        key_1: value_1
        key_2: value_2
    second_map:
        key_3: value_3
        key_4: value_4
    """

    constructor = AnsibleConstructor()
    data = constructor.construct_yaml_map(constructor.construct_document(yaml_text))

# Generated at 2022-06-11 09:22:07.123522
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with a mapping that expect to work
    test_mapping_1 = dict(key1='value1', key2='value2')
    yaml_node_1 = AnsibleConstructor.construct_yaml_map(None, test_mapping_1)

    # Test with a mapping that is expected to fail
    test_mapping_2 = dict(key1='value1', key1='value2')
    with pytest.raises(exceptions.ConstructorError):
        AnsibleConstructor.construct_yaml_map(None, test_mapping_2)


# Generated at 2022-06-11 09:22:13.114542
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = u'''
        a: &a
            1: one
            2: two
        b:
            <<: *a
            3: three
        c:
            4: four
            a: test
            b:
                5: five
                6: six
            c:
                - 7
                - 8
        d:
            a: test
            b: test
    '''
    print(yaml.load(data, AnsibleConstructor))



# Generated at 2022-06-11 09:22:26.453056
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = """
- key1: value1
- key1: value2
- key2: value3
- key2: value4
- key2: value5
    """
    class MockNode(object):
        def __init__(self, value=None):
            self.value = value

    node_list = []
    for key, value in [('key1', 'value1'), ('key1', 'value2'), ('key2', 'value3'), ('key2', 'value4'), ('key2', 'value5')]:
        key_node = MockNode(value=key)
        value_node = MockNode(value=value)
        node = MockNode(value=[key_node, value_node])
        node_list.append(node)


# Generated at 2022-06-11 09:22:29.590764
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import sys
    if sys.version_info[0] == 3:
        yaml_unsafe_text = AnsibleUnsafeText(u'\u2713')
    else:
        yaml_unsafe_text = AnsibleUnsafeText(u'\xe2\x9c\x93')

    node = AnsibleConstructor.construct_yaml_unsafe(None, yaml_unsafe_text)
    assert node.ansible_text == yaml_unsafe_text

# Generated at 2022-06-11 09:22:36.645204
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    x = """
    ---
    {}
    """
    y = """
    ---
    name: test
    """
    z = """
    ---
    name: test
    name: test2
    """
    a = """
    ---
    name: test
    name: test2
    name: test3
    """
    assert (isinstance(AnsibleConstructor().construct_yaml_map(yaml.compose(yaml.compose(yaml.parse(x)))), AnsibleMapping))
    assert (isinstance(AnsibleConstructor().construct_yaml_map(yaml.compose(yaml.compose(yaml.parse(y)))), AnsibleMapping))

# Generated at 2022-06-11 09:22:49.807277
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    from ansible.parsing.yaml.objects import (
        AnsibleMapping,
        AnsibleSequence,
        AnsibleUnicode)


# Generated at 2022-06-11 09:22:58.397174
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys

    data = {
        'bool': False,
        'int': 42,
        'float': 3.14,
        'str': 'foo',
        'unicode': u'bar',
        'list': [],
        'dict': dict()
    }

    def register_constructor(tag, foo):
        def f(self, node):
            return data[tag]
        AnsibleConstructor.add_constructor(tag, f)

    for tag, obj in data.items():
        register_constructor(tag, obj)

    ac = AnsibleConstructor()
    for tag, obj in data.items():
        if sys.version_info[0] == 2:
            # python2
            node = safe_load(u'!%s' % tag)

# Generated at 2022-06-11 09:23:01.414281
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    c = AnsibleConstructor()
    class MockNode:
        pass

    node = MockNode()
    node.id = 'str'
    assert(c.construct_yaml_unsafe(node) == '')

# Generated at 2022-06-11 09:23:12.928458
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml import objects
    from yaml.nodes import MappingNode
    from yaml.nodes import ScalarNode
    from yaml import tokens

    safe_constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:23:21.223277
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.dataloader import DataLoader

    from io import StringIO

    yaml_data = StringIO("""
    foo: 1
    bar: 2
    foo: 3
    """)

    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data == dict(foo=3, bar=2)

    yaml_data = StringIO("""
    foo: 1
    bar: 2
    foo: 3
    """)

    loader = DataLoader()
    data = loader.load(yaml_data, file_name='foo.yaml')
    assert data == dict(foo=3, bar=2)

# Generated at 2022-06-11 09:23:47.627730
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Simple test with construct_yaml_str from AnsibleConstructor class
    filename = 'test.yml'
    vault_secrets = [{'password': 'ansible'}]
    v = AnsibleConstructor(file_name=filename, vault_secrets=vault_secrets)
    from yaml.composer import Composer, CompositionError
    from yaml.scanner import Scanner
    from yaml.reader import Reader
    from yaml.parser import Parser
    from io import StringIO
    stream = StringIO(u'test')
    reader = Reader(stream)
    reader.name = 'test.yml'
    parser = Parser(reader)
    composer = Composer(parser)
    composed_data = composer.get_single_data()

# Generated at 2022-06-11 09:23:59.800902
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    import hmac
    import hashlib
    import struct

    def _derive_key(salt, secret):
        '''
        Derive a 256 bit key from the provided secret (unicode) and salt (binary).

        This method was ported from Ansible's implementation of the same
        function:
        https://github.com/ansible/ansible-modules-core/blob/ae69c4fd4d26bb4fbe5b0cf5cbeb39a5b5d5e9ca/crypto/lib/ansible/module_utils/crypto.py#L63
        '''
        salt_key = secret.encode("utf-8") + salt

# Generated at 2022-06-11 09:24:04.280834
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    print("AnsibleConstructor_construct_yaml_str")
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str('"some text"')
    print("AnsibleConstructor_construct_yaml_str passed")

# Generated at 2022-06-11 09:24:06.999668
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_text = """
- 1
- 3
- 2
"""
    yaml_obj = yaml.load(yaml_text, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, list)
    assert yaml_obj == [1, 3, 2]

# Generated at 2022-06-11 09:24:08.048444
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # This test needs to be fixed for python3
    pass

# Generated at 2022-06-11 09:24:16.634310
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    class TEST_AnsibleConstructor(AnsibleConstructor):
        """ This class is used for unit test purpose only """
        def _node_position_info(self, node):
            return None

    secret = "THIS_IS_SECRET"
    vault_password_file = "./ansible_constructor_password_file"
    open(vault_password_file, "w").write(secret)


# Generated at 2022-06-11 09:24:24.082621
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:24:29.144016
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleMapping
    data = AnsibleMapping()
    data.update({'a': 1, 'b': 2, 'c': 3})
    _ansible = AnsibleConstructor()
    assert _ansible.construct_yaml_seq(data) == [1, 2, 3]



# Generated at 2022-06-11 09:24:36.271387
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import __builtin__
    if not hasattr(__builtin__, '__builtins__'):
        __builtin__.__builtins__ = __builtins__
    # Monkeypatch yaml.Scanner so that yaml.load doesn't open a file
    # named "!unsafe" in the current directory
    yaml_Scanner = type(yaml.Scanner)
    yaml_safe_load = yaml.load
    def load(stream, **kwargs):
        save_open = __builtin__.open
        def open(name, mode='r'):
            return save_open(os.devnull, mode)
        __builtin__.open = open

# Generated at 2022-06-11 09:24:45.736526
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Set up the object and call the method
    node = u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3535366266333239306266623634656637333031613961326133623763653435616232376237313\n          26163310a3135663632313461333261613536363733356662336536373962663531386265373965\n          3236640a33633132633739386231656233323432653664633032626163313234636362396331346\n          53966353761623164353138326632623166353063386637633165663534363933\n        '
    ansibleconst = AnsibleConstruct