

# Generated at 2022-06-11 09:15:10.898023
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from yaml.events import ScalarEvent

    assert AnsibleConstructor.construct_yaml_str(ScalarNode(None, None, ScalarEvent(None, None, value=u'abc'), None, None)) == u'abc'


# Generated at 2022-06-11 09:15:21.645114
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Given
    my_dict = {
        u'k1': u'v1',
        u'k2': u'v2',
        u'k3': u'v3',
        u'k4': {
            u'k4-1': u'v4-1',
            u'k4-2': u'v4-2'
        }
    }

    # When
    ac = AnsibleConstructor()
    new_dict = ac.construct_mapping(my_dict)

    # Then
    assert new_dict[u'k1'] == u'v1'
    assert new_dict[u'k2'] == u'v2'
    assert new_dict[u'k3'] == u'v3'


# Generated at 2022-06-11 09:15:25.735543
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    text_string = "a string"
    text_node = AnsibleUnsafeText(text_string)
    ansible_constructor = AnsibleConstructor()
    result = ansible_constructor.construct_yaml_unsafe(text_node)
    assert result.value == text_string

# Generated at 2022-06-11 09:15:33.886755
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    class TestClass:
        pass

    # Test if not dict, list, int, bool or string (none of the other special constructors)
    test_input = TestClass()
    result = AnsibleConstructor.construct_yaml_unsafe(test_input)
    assert result == wrap_var(test_input)

    # Test dict
    test_input = dict(test_key=1)
    result = AnsibleConstructor.construct_yaml_unsafe(test_input)
    assert result == wrap_var(test_input)

    # Test list
    test_input = [1, 2, 3]
    result = AnsibleConstructor.construct_yaml_unsafe(test_input)
    assert result == wrap_var(test_input)

    # Test int
    test_input = 1
    result = AnsibleConstruct

# Generated at 2022-06-11 09:15:42.820790
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Test for bools, integers, float and list
    node = u'tag:yaml.org,2002:map'
    a = AnsibleConstructor()
    data = AnsibleMapping()
    expected = AnsibleMapping()
    expected['test1'] = True
    expected['test2'] = 8
    expected['test3'] = 9.0
    expected['test4'] = AnsibleSequence([10,11,12])
    expected['test5'] = wrap_var(13)
    expected.ansible_pos = ('<string>', 1, 1)
    data.update(expected)
    value = a.construct_yaml_map(node)

# Generated at 2022-06-11 09:15:50.759348
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import subprocess
    import tempfile

    def shell(cmd):
        return subprocess.check_output(cmd, shell=True)

    with tempfile.NamedTemporaryFile() as tmp:
        tmp.write("test")
        tmp.flush()

        vault_pwd = "test"

        _x = shell("ansible-vault encrypt {0} --ask-vault-pass".format(tmp.name))

        with open(tmp.name) as f:
            yamlobj = yaml.load(f, Loader=AnsibleConstructor)

        assert isinstance(yamlobj, unicode)


# Generated at 2022-06-11 09:15:55.128105
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ans_constr = AnsibleConstructor()
    seq = '''
      - 1
      - 2
      - 3
    '''
    result = ans_constr.construct_yaml_seq(seq)
    assert result == AnsibleSequence([1, 2, 3])

# Generated at 2022-06-11 09:16:04.456168
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

    def test(input_str, expected):
        from ansible import constants as C
        from ansible.parsing.vault import VaultLib
        from ansible.parsing.yaml import objects
        from ansible.parsing.yaml.loader import AnsibleLoader
        from ansible.parsing.yaml.dumper import AnsibleDumper
        from ansible.vars.unsafe_proxy import wrap_var

        # load the input string
        loader = AnsibleLoader(input_str)
        data = loader.get_single_data()

        # dump the data back into a string
        dumper = AnsibleDumper()

# Generated at 2022-06-11 09:16:10.325109
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = AnsibleConstructor()
    test_string = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3135305236316533656662623534366437323861323936666531343262323533376563376532303437\n          "
    assert node.construct_vault_encrypted_unicode(test_string)

# Generated at 2022-06-11 09:16:20.095512
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:16:38.011119
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import io
    import yaml
    from yaml.representer import Representer
    from ansible.parsing.yaml.objects import AnsibleUnicode
    
    # Populate the data structure that we want to dump to YAML
    data = dict()
    data['key'] = AnsibleUnicode('value')
    
    # Overwrite sys.stdout, so that we can capture it, and examine the YAML dumped
    # to it. 
    captured_stdout = io.StringIO()
    sys.stdout = captured_stdout

    yaml.add_representer(AnsibleUnicode, Representer.represent_unicode)
    yaml.dump(data, sys.stdout, Dumper=Representer, default_flow_style=False, default_style='"')


# Generated at 2022-06-11 09:16:42.359104
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_constructor = AnsibleConstructor()
    node = MappingNode(tag='tag:yaml.org,2002:map',
                       value=[],
                       start_mark=None,
                       end_mark=None,
                       flow_style=None)
    result = yaml_constructor.construct_mapping(node)
    assert result == {}

# Generated at 2022-06-11 09:16:52.516226
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_string = """
            one: two
            three: four
            five: six
            five: seven
        """
    try:
        data = yaml.load(yaml_string, AnsibleConstructor)
    except ConstructorError as e:
        pass
    else:
        assert False, "duplicate key during construction did not raise an exception"
    display.verbosity = 4
    try:
        data = yaml.load(yaml_string, AnsibleConstructor)
    except ConstructorError as e:
        pass
    else:
        assert False, "duplicate key during construction did not raise an exception"
    display.verbosity = 0
    data = yaml.load(yaml_string, AnsibleConstructor)

# Generated at 2022-06-11 09:17:02.673321
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    m1 = {'key1': 'value', 'key2': 'value'}
    m2 = {'key1': 'value', 'key2': 'value2'}
    m3 = {'key1': 'value2', 'key2': 'value'}

    # Unit test for the case that duplicate keys are allowed
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), node=None, deep=False) == {}
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), m1, deep=False) == m1
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), m2, deep=False) == m2

# Generated at 2022-06-11 09:17:10.682720
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleMapping
    test_data = {'a': 1, 'b': 2, 'c': 3}
    ac = AnsibleConstructor()
    safe_mapping = ac.construct_yaml_map(node="TEST")
    safe_mapping.update(test_data)
    assert(isinstance(safe_mapping, AnsibleMapping))
    assert(safe_mapping['a'] == 1)
    assert(safe_mapping['b'] == 2)
    assert(safe_mapping['c'] == 3)
    assert(safe_mapping.ansible_pos == ('<string>', 1, 0))


# Generated at 2022-06-11 09:17:22.926859
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with a mapping having duplicate keys
    class FakeNode(object):
        def __init__(self, value):
            self.value = value

    class FakeMark(object):
        def __init__(self, line, column):
            self.line = line
            self.column = column
            self.name = '<string>'

    fake_node = FakeNode((
        (FakeNode('name'), FakeNode('user')),
        (FakeNode('name'), FakeNode('ansible')),
        (FakeNode('password'), FakeNode('password')),
        (FakeNode('uid'), FakeNode(1000)),
        (FakeNode('comment'), FakeNode('ansible')),
        (FakeNode('home'), FakeNode('/home/ansible')),
        (FakeNode('shell'), FakeNode('/bin/true')),
    ))

# Generated at 2022-06-11 09:17:28.222006
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml import load
    from yaml.nodes import MappingNode
    node = MappingNode(None, None, None, None)
    data = AnsibleConstructor.construct_yaml_map(node)
    assert isinstance(data, AnsibleMapping), 'Result of method construct_yaml_map is not an instance of AnsibleMapping'



# Generated at 2022-06-11 09:17:33.802276
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = dict(k1=1,k2=2,k3=4)
    yaml_data = b"k1: 1\nk2: 2\nk3: 4"
    yaml_object = AnsibleLoader(yaml_data, vault_secrets=[], file_name='main.yml').get_single_data()
    assert yaml_object == data



# Generated at 2022-06-11 09:17:36.705671
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    foo = AnsibleConstructor(file_name='test_file')._node_position_info('foobar')
    assert foo == (u'test_file', 0, 7)

# Generated at 2022-06-11 09:17:48.847474
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import io
    import sys
    import yaml
    if not sys.version_info[0] < 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    data = dict(
        one=dict(two=dict(three=3))
    )


# Generated at 2022-06-11 09:18:03.807511
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = ['mypassword']
    class MockNode():
        start_mark = None
        def __init__(self, text):
            self.text = text
    # Mock node with encrypted u'abc\x01\x01\x01\x01\x01'

# Generated at 2022-06-11 09:18:11.890972
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Given
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[(u'foo', u'bar'), (u'bar', u'baz'), (u'foo', u'baz')],
                       start_mark=None, end_mark=None, flow_style=None)
    deep = False

    # When
    ansible_constructor = AnsibleConstructor()
    ret = ansible_constructor.construct_mapping(node=node, deep=deep)

    # Then
    assert ret == AnsibleMapping({'foo': 'baz', 'bar': 'baz'})
    assert ret.ansible_pos == (None, 1, 1)

# Generated at 2022-06-11 09:18:22.076999
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:18:28.493767
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test = AnsibleConstructor()

    mapping = {
        'a': 'b',
        'c': 'd',
        'e': 'f'
    }

    mapping_node = MappingNode(None, None, True, mapping.items())

    class_method = getattr(test, 'construct_mapping')
    result = class_method(mapping_node)

    assert result == mapping

# Generated at 2022-06-11 09:18:38.180456
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from .vendored import yaml

    ac = AnsibleConstructor()
    yaml_str = "Hello World '\n"
    ret = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert(ret == 'Hello World \'')

    ret = yaml.load('--- !unsafe \'Hello World \'', Loader=AnsibleConstructor)
    assert(ret == 'Hello World \'')

    # Test for default str constructor inside !unsafe
    ret = yaml.load('--- !unsafe [\'Hello World \']', Loader=AnsibleConstructor)
    assert(ret == ['Hello World '])

    # Test for AnsibleConstructor string constructor inside !unsafe

# Generated at 2022-06-11 09:18:40.353067
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert AnsibleConstructor.construct_yaml_seq(AnsibleConstructor(), None) == 'foo'


# Generated at 2022-06-11 09:18:53.763857
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.unsafe_proxy import wrap_var

    data = """
---
- name: test_playbook_data
  connection: local
  hosts: all
  gather_facts: no
  tasks:
    - name: test
      debug: msg="{{ item }}"
      with_items:
        - one
        - two
        - three
"""
    play_context = PlayContext()
   

# Generated at 2022-06-11 09:19:03.057793
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Default duplicate key handling is C.DUPLICATE_YAML_DICT_KEY
    """
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.display import Display

    # we don't want to display the deprecation warnings
    display = Display()
    display._deprecation_warnings = frozenset()

    # test YAML string to be parsed as valid mapping and invalid mapping
    valid_yaml_str = u'---\na: aa\nb: bb\n'
    invalid_yaml_str = u'---\na: aa\na: aaa\n'

    # this is the expected

# Generated at 2022-06-11 09:19:12.957139
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    vault_secret = VaultSecret('abc')
    vault_secrets = [vault_secret]
    yaml_str = "a: 1\nb: !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  623133653339373736656235663534346338633965343933346135613332393262326565643066\n  34623862393361326262313432386162396338326530336332626264666566660a\n"

# Generated at 2022-06-11 09:19:22.350896
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest as ut
    import tempfile


# Generated at 2022-06-11 09:19:29.992116
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass



# Generated at 2022-06-11 09:19:40.987088
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():    # pylint: disable=too-many-locals,unused-argument
    # pylint: disable=too-many-locals
    import os
    import unittest

    # Setup a test environment
    tmpdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + os.path.sep + 'tmp'
    if not os.path.isdir(tmpdir):
        os.mkdir(tmpdir)
    tmpfile = os.path.join(tmpdir, 'test_yaml.yml')

    # Temp file to test the creation of a mapping

# Generated at 2022-06-11 09:19:50.382363
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # Setup the expected value
    expected_value = {'a': 'b'}

    # Setup the node to be used by the test method
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

# Generated at 2022-06-11 09:19:56.074827
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:20:02.749268
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = """
    - { foo: {bar: baz}, foobar: !unsafe "{{ testvar }}" }
    """
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    # check that the unsafe flag has been set
    assert data[0]['foobar'].unsafe
    # and we have the correct data
    assert '{{ testvar }}' == data[0]['foobar'].value

# Generated at 2022-06-11 09:20:10.624697
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    data = '''
    - {a: b, c: "d"}
    - {a: !unsafe "{{b}}"}
    '''
    yaml.add_representer(AnsibleUnicode, lambda dumper, data: dumper.represent_scalar(u'tag:yaml.org,2002:str', u'%s' % data.data))

    results = yaml.load(data, Loader=yaml.Loader)
    assert isinstance(results[0]['c'], AnsibleUnicode)
    assert isinstance(results[1]['a'], AnsibleUnicode)

# Generated at 2022-06-11 09:20:11.130846
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    pass

# Generated at 2022-06-11 09:20:18.244355
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Test that ansible_pos is added to the returned AnsibleMapping.
    """
    constructor = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    node.start_mark.line = 1
    node.start_mark.column = 5
    node.end_mark.line = 2
    node.end_mark.column = 4
    for data in constructor.construct_yaml_map(node):
        assert data.ansible_pos == (None, 1, 6)
        assert data.ansible_line_number == 1
        assert data.ansible_column_number == 6



# Generated at 2022-06-11 09:20:24.910585
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    '''Return an instance of class UnsafeClass'''
    constructor = AnsibleConstructor()
    unsafe_node = {'id': 'unsafe'}
    # For example: !unsafe
    result = constructor.construct_yaml_unsafe(unsafe_node)
    assert isinstance(result, dict)
    assert '__ansible_unsafe__' in result
    assert result['__ansible_unsafe__'] is True
    assert '__ansible_untrusted__' not in result

# Generated at 2022-06-11 09:20:28.531356
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    a = AnsibleConstructor()
    data = a.construct_yaml_seq(MappingNode('tag:yaml.org,2002:map', []))

    assert isinstance(data, GeneratorType)
    assert isinstance(next(data), AnsibleSequence)



# Generated at 2022-06-11 09:20:44.935293
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import sys
    assert sys.version_info >= (2,7)
    assert sys.version_info < (3,0)
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))) + "/lib/ansible")
    from ansible.parsing.yaml.loader import AnsibleLoader
    vault_secrets = ['foo']
    a = AnsibleConstructor(None, vault_secrets)
    # old style vault

# Generated at 2022-06-11 09:20:49.543350
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    y = '''
test:
  some: value
'''
    import yaml

    a = yaml.load(y, Loader=AnsibleConstructor)
    assert a['test']['some'] == 'value'

    try:
        yaml.load("{test: wrong}", Loader=AnsibleConstructor)
    except Exception as e:
        assert isinstance(e, yaml.constructor.ConstructorError)



# Generated at 2022-06-11 09:20:59.062189
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import sys
    from io import StringIO

    class ProgressStream(StringIO):
        def __init__(self, name='<fake stdin>'):
            self.name = name
            self._bytes_read = 0
            self._pct_done = 0
            StringIO.__init__(self)
        def read(self, bytes):
            self._bytes_read += bytes
            self._pct_done = 100 * self._bytes_read / len(self.getvalue())
            return StringIO.read(self, bytes)

    test_input = ProgressStream()
    test_output = sys.stdout
    sys.stdin = test_input
    sys.stdout = test_output

# Generated at 2022-06-11 09:21:08.347116
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['$ANSIBLE_VAULT;1.1;AES256\n35313932363138383136346430623966646535323464346362653436653733373536643133346566\n30633033323662316532383165613532653139613531653135313632353162366433653731343833\n36356664343835643935373261396363663339663932343430333537666333373939666539616466\n33626239363961333438653635393665373730643430653837666631346630383766303132616366\n3332306563636130356633\n']

# Generated at 2022-06-11 09:21:09.153395
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    a = AnsibleConstructor()

# Generated at 2022-06-11 09:21:20.393864
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import unittest
    import yaml
    class Test(unittest.TestCase):
        def _test(self, node_value, value, deep=False):
            node = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map', value = node_value)
            c = AnsibleConstructor(file_name="test_file_name")
            self.assertEqual(c.construct_mapping(node, deep), value)
            self.assertEqual(c.construct_mapping(node, deep).ansible_pos[0], "test_file_name")
            self.assertEqual(c.construct_mapping(node, deep).ansible_pos[1], 1)

# Generated at 2022-06-11 09:21:29.861342
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    class _yaml_ScalarNode():
        def __init__(self, start_mark, end_mark, style):
            self.start_mark = start_mark
            self.end_mark = end_mark
            self.style = style
    yaml_ScalarNode = _yaml_ScalarNode

    class _yaml_Mark():
        def __init__(self, name, index, line, column, buffer, pointer):
            self.name = name
            self.index = index
            self.line = line
            self.column = column
            self.buffer = buffer
            self.pointer = pointer
    yaml_Mark = _yaml_Mark


# Generated at 2022-06-11 09:21:30.745336
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    instance = AnsibleConstructor()
    assert instance

# Generated at 2022-06-11 09:21:35.850504
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    map = {'a':1,'b':2}
    constructor = AnsibleConstructor()
    ansible_map = constructor.construct_yaml_map(map)
    assert isinstance(ansible_map, AnsibleMapping)
    assert ansible_map['a']==1
    assert ansible_map['b']==2


# Generated at 2022-06-11 09:21:44.344345
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # define a dict
    a = dict()
    # Set some keys on dictionary
    a["somename"] = "somenamevalue"
    a["nested_dict_key"] = dict()
    a["nested_dict_key"]["key_a"] = "value_a"
    a["nested_dict_key"]["key_b"] = "value_b"
    a["list_key"] = [5000, "foo", "bar", "baz", "boo", "moo", 6000]
    a["builtin_list_key"] = list()
    a["builtin_list_key"].append(a["somename"])
    a["nested_list_key"] = list()
    a["nested_list_key"].append(a["list_key"])
    a

# Generated at 2022-06-11 09:22:04.761168
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq(): # noqa
    import yaml
    f = yaml.load(u"---\n- 1\n- 2\n- 3\n", Loader=AnsibleConstructor)
    assert isinstance(f, list)
    assert f == [1, 2, 3]

# Generated at 2022-06-11 09:22:09.522929
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Define the node
    node = MappingNode(None, None, True, None, None)

    # Create an instance of AnsibleConstructor
    ansible_constructor = AnsibleConstructor()

    # Create an instance of AnsibleSequence
    ansible_sequence = ansible_constructor.construct_yaml_seq(node)

    # Check if the instance is of class AnsibleSequence
    assert type(ansible_sequence) == AnsibleSequence

# Generated at 2022-06-11 09:22:22.085351
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    import yaml
    vault = VaultLib(secrets=['$ANSIBLE_VAULT;1.1;AES256\n4444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444\n4444444444444444444444444444444444444444444444444444444444444444\n'])

# Generated at 2022-06-11 09:22:32.973268
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    This test module is used on Travis CI and AppVeyor.
    """
    from ansible.parsing.yaml.dumper import AnsibleDumper

    source_list = [
        [dict(key1="value1", key2="value2"), dict(key1="value1", key2="value2")],
        [dict(key1="value1", key2="value1"), 2],
        [dict(key1="value1", key2="value2"), "duplicate key (key1)"],
        [dict(key1="value1", key2="value2"), "duplicate key (key1)"],
        [dict(key1="value1", key2="value2"), "duplicate key (key1)"],
    ]


# Generated at 2022-06-11 09:22:39.514305
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    yaml_str = """
#!ansible
---
    - hosts: localhost
      vars:
          foo: !unsafe "{{ '{' }}1+1{'}' }}"
      tasks:
        - debug: var=foo
    """
    yaml_ansible_constructor = AnsibleConstructor()
    data = yaml.load(yaml_str, Loader=yaml.Loader)
    assert isinstance(data[0]['vars']['foo'], wrap_var)
    assert data[0]['vars']['foo'] == wrap_var("{{ 1+1 }}")

# Generated at 2022-06-11 09:22:51.897446
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # AnsibleConstructor is a subclass of SafeConstructor
    # Note: It is not possible to construct a SafeConstructor directly
    # (see https://github.com/yaml/pyyaml/pull/228)
    # SafeConstructor uses __new__ and not __init__
    # So we need to use super(AnsibleConstructor, self).__new__() instead of super(AnsibleConstructor, self).__init__()
    # See https://stackoverflow.com/questions/4481954/python-trying-to-understand-new-and-init
    assert isinstance(super(AnsibleConstructor, AnsibleConstructor()).__new__(AnsibleConstructor), SafeConstructor)
    # Test parameters
    vault_secrets = ['secret1', 'secret2']
    # There is no check

# Generated at 2022-06-11 09:22:59.517854
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:23:04.867510
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    node = type('node', (object,), {'id': 'object'})
    value = type('value', (object,), {'construct_object': 'value_construct_object'})
    constructor = AnsibleConstructor()
    ret = constructor.construct_yaml_unsafe(node)
    value.assert_called_once_with('value_construct_object')

# Generated at 2022-06-11 09:23:11.611927
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    _node='YWJjMTIz'
    _AnsibleConstructor=AnsibleConstructor()
    _ret=_AnsibleConstructor.construct_vault_encrypted_unicode(_node)
    assert _ret.vault.secrets[0] == 'abc123'
    assert _ret.vault.secrets[1] == 'abc123'
    assert _ret.vault.secrets[2] == 'abc123'


# Generated at 2022-06-11 09:23:21.481441
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # create an AnsibleConstructor with a vault secret
    vault_secret="test_secret"
    ac = AnsibleConstructor(vault_secrets=[vault_secret])

    # create a node with the string "!vault | " and the ciphertext
    # (the ciphertext is the output of 'ansible-vault encrypt_string --vault-id default test_string --stdin-name test_string')

# Generated at 2022-06-11 09:24:24.663915
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ret = AnsibleConstructor.construct_yaml_seq(None, None)

# Generated at 2022-06-11 09:24:30.282994
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO   # python3
    import yaml               # type: ignore
    data = u'hello world'
    s = StringIO(u'{0}'.format(data))
    ansible_str = yaml.load(s, Loader=AnsibleConstructor)
    assert isinstance(ansible_str, AnsibleUnicode)
    assert ansible_str == data

# Generated at 2022-06-11 09:24:37.170293
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import traceback
    import pdb
    import doctest
    import os
    import shutil

    if not os.path.exists("test/unit/parsing/yaml/fixtures/"):
        os.makedirs("test/unit/parsing/yaml/fixtures/")

    fh = open("test/unit/parsing/yaml/fixtures/AnsibleConstructor_construct_mapping.rst", "w")

# Generated at 2022-06-11 09:24:46.729059
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = u'a_unicode_string'

    # Test 1: No PyYAML (library) loaded.
    try:
        # Using the construct_yaml_str method of the class AnsibleConstructor
        # the function will raise an AttributeError due to the fact that the
        # function will fail to find the method construct_scalar.
        AnsibleConstructor.construct_yaml_str(node)
    except AttributeError as err:
        assert to_bytes(str(err)) == to_bytes('module \'yaml\' has no attribute \'constructor\'')

    # Test 2: PyYAML is loaded.
    from yaml import load, dump
    from yaml.constructor import SafeConstructor

    # Create the object to test by using the dump function of the PyYAML module,
    # and load

# Generated at 2022-06-11 09:24:54.404819
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    def test_case(data, expected_output, tags='', expect_warnings=False):
        try:
            data = yaml.load(data, AnsibleConstructor)
            assert data == expected_output, "expected=%s found=%s" % (expected_output, data)
            if expect_warnings:
                assert display.messages[0][0] == 'warning'
                display.clean()
        except ConstructorError as err:
            # We expect failure, so ignore the error
            pass
        except AssertionError:
            print("%s failed: %s" % (tags, err))
            raise


# Generated at 2022-06-11 09:25:05.680407
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_obj = AnsibleConstructor(file_name='test/file_name.yaml', vault_secrets=['secret1', 'secret2'])
    try:
        test_obj.construct_vault_encrypted_unicode(node=None)
    except Exception as e:
        assert isinstance(e, ConstructorError)
        assert to_native(e) == "found !vault but no vault password provided"

    try:
        test_obj.construct_vault_encrypted_unicode(node=123)
    except Exception as e:
        assert isinstance(e, ConstructorError)
        assert to_native(e) == "found !vault but no vault password provided"
