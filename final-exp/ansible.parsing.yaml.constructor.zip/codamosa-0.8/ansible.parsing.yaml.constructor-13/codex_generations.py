

# Generated at 2022-06-11 09:15:08.605096
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os

    file_name = os.path.join(os.path.dirname(__file__), 'yaml_test', 'map.yml')
    with open(file_name, 'r') as f:
        data = yaml.load(f, Loader=AnsibleConstructor)
        assert data is not None


# Generated at 2022-06-11 09:15:19.085887
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Unit test to test if the warning/error handling
    # in AnsibleConstructor.construct_mapping works
    from io import StringIO
    from tempfile import NamedTemporaryFile
    from yaml import FullLoader

    # the line number where the previous token has ended (plus empty lines)
    # Add one so that the first line is line 1 rather than line 0
    column = 1
    line = 1

    datasource = 'test_file.yaml'
    position = (datasource, line, column)

    # Create a temporary file to test this method
    with NamedTemporaryFile(mode='w+t') as temp_file:
        temp_file.write('a: 1\n')
        temp_file.write('b: 2\n')
        temp_file.write('a: 3\n')

# Generated at 2022-06-11 09:15:28.117589
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    '''
    The method construct_mapping of class AnsibleConstructor
    '''
    n = MappingNode(None, [(None, 10), (None, 20), (None, 30)], False, None, None, None)
    ansible_constructor = AnsibleConstructor()

    try:
        ansible_constructor.construct_mapping(n, True)
    except ConstructorError as e:
        print(e)
        assert e.problem == "expected a mapping node, but found %s" % n.id
        assert e.problem_mark == n.start_mark

    n = MappingNode(None, [(None, 10), (None, 20), (None, 30)], False, None, None, None)

    m = ansible_constructor.construct_mapping(n, True)


# Generated at 2022-06-11 09:15:35.011813
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    #
    # Cannot use standard unit test class here because unittest prohibits
    # use of yield in test methods (construct_yaml_seq() uses yield)
    #

    #
    # 1) construct_yaml_seq() - simple test of tuple created with 'YAML' keyword
    #
    # Format of input YAML to be loaded (converted to string)
    yaml_str = "{a: 1, b: 2, c: 3}"
    # Create an instance of the YAML constructor class
    constructor = AnsibleConstructor()
    # Invoke the constructor to build the Python object
    # Note that this would normally be invoked as:
    # constructor.construct_yaml_map(node)
    # but load()

# Generated at 2022-06-11 09:15:43.974521
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    import yaml
    data = '''
---
key1: value1
key2: value2
key3:
  - value3_1
  - value3_2
key4:
  key4_1: value4_1
  key4_2: value4_2
    '''
    constructor = AnsibleConstructor()
    yaml_obj = yaml.load(data, Loader=yaml.loader.BaseLoader)

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleVaultEncryptedUnicode
    assert isinstance(yaml_obj, dict)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj.ansible_pos == ('<string>', 1, 1)
   

# Generated at 2022-06-11 09:15:49.225516
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_doc = """
a:
  b: 1
  c: 2
"""
    yaml_obj = yaml.load(yaml_doc, Loader=AnsibleConstructor)
    assert yaml_obj == {'a': {'b': 1, 'c': 2}}

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 09:15:54.968821
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[(0, 0)], flow_style=False)
    ansible_constructor = AnsibleConstructor(file_name='test')
    mapping = ansible_constructor.construct_mapping(node)
    assert isinstance(mapping, AnsibleMapping)


# Generated at 2022-06-11 09:16:04.183823
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys
    from unittest import TestCase

    output = StringIO()
    stream = StringIO(u'{"one": "two"}')
    data = AnsibleConstructor().get_single_data(stream)
    yield_data = next(data)
    data = yield_data[0]
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 1
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # test get_single_data
    output = StringIO()
    stream = StringIO(u'{"one": "two"}')
    data = AnsibleConstructor().get_single_data(stream)

# Generated at 2022-06-11 09:16:09.740313
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Just check that !vault is declared
    assert AnsibleConstructor.yaml_constructors[u'!vault'] == AnsibleConstructor.construct_vault_encrypted_unicode
    assert AnsibleConstructor.yaml_constructors[u'!vault-encrypted'] == AnsibleConstructor.construct_vault_encrypted_unicode



# Generated at 2022-06-11 09:16:19.652377
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    def construct_yaml_map(self, node):
        data = AnsibleMapping()
        yield data
        value = self.construct_mapping(node)
        data.update(value)
        data.ansible_pos = self._node_position_info(node)

    setattr(AnsibleConstructor, 'construct_yaml_map', construct_yaml_map)

    def construct_mapping(self, node, deep=False):
        if not isinstance(node, MappingNode):
            raise ConstructorError(None, None,
                                   "expected a mapping node, but found %s" % node.id,
                                   node.start_mark)
        self.flatten_mapping(node)
        mapping = AnsibleMapping()
        for key_node, value_node in node.value:
            key

# Generated at 2022-06-11 09:16:35.688568
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    c = AnsibleConstructor()
    u1 = c.construct_yaml_unsafe(MappingNode(tag=u'!unsafe',
                                             value=[],
                                             start_mark=None,
                                             end_mark=None))
    u2 = c.construct_python_object(MappingNode(tag=u'!unsafe',
                                               value=[],
                                               start_mark=None,
                                               end_mark=None))
    assert isinstance(u1, AnsibleUnsafeText)
    assert isinstance(u2, AnsibleUnsafeText)
    assert repr(u1) == repr(u2)

# Generated at 2022-06-11 09:16:44.634870
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.module_utils._text import to_text
    # Test case 1
    # Note: This test case uses a flat dictionary
    node1 = """!!python/object/apply:ansible.parsing.yaml.objects.AnsibleMapping
- - !!python/unicode 'first_key'
  - !!python/unicode 'first_value'
- - !!python/unicode 'second_key'
  - !!python/unicode 'second_value'
"""
    data1 = {
        u'first_key': u'first_value',
        u'second_key': u'second_value'
    }
    constructor = AnsibleConstructor()
    value1 = constructor.construct_yaml_map(node1)
    assert value1 == data1

    # Test case 2
    # Note

# Generated at 2022-06-11 09:16:55.009125
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Arrange
    import StringIO
    import yaml
    import base64

    # Create an string with valid encrypted data
    plaintext_data = "Secret data"
    vault_secrets = ['SecretPassword']
    vault = VaultLib(secrets=vault_secrets)
    encryptor = vault.encryptor
    encrypted_data = encryptor.encrypt(plaintext_data)
    b_encrypted_data = base64.b64encode(encrypted_data)
    s_encrypted_data = b_encrypted_data.decode('ascii')

    # Add '!vault' tag and construct a node from our data
    s_data = "!vault |\n" + s_encrypted_data
    yaml_stream = StringIO.StringIO(s_data)

# Generated at 2022-06-11 09:17:04.667325
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    import io
    import yaml
    import unittest

    class TestVaultLib(VaultLib):
        def __init__(self, password=None):
            self.password = password
            self.password_used = None
        def load(self, password):
            self.password_used = password
            return self.password
        
        def encrypt(self, password, plaintext):
            return plaintext, False

    class VaultEncryptedValue:
        def __eq__(self, other):
            return self.ciphertext_data == other.ciphertext_data

    class AnsibleConstructorTests(unittest.TestCase):
        def setUp(self):
            self.md = AnsibleConstructor('filename.yaml')
            
        def tearDown(self):
            pass

# Generated at 2022-06-11 09:17:06.180765
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert AnsibleConstructor.construct_yaml_str(node=None).__class__ == AnsibleUnicode

# Generated at 2022-06-11 09:17:12.775899
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:17:21.590816
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor(file_name='test_file')

    node = None
    actual = constructor.construct_yaml_str(node)
    assert actual == u''

    from yaml.nodes import ScalarNode
    node = ScalarNode('tag:yaml.org,2002:str', u'string', None, None, None)

    actual = constructor.construct_yaml_str(node)
    assert actual == u'string'
    assert actual.ansible_pos == ('test_file', 1, 1)

# Generated at 2022-06-11 09:17:30.320267
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    # ciphertext data
    b_ciphertext_data = b"\xbf\x8e\x92\x97\xfd\x89\xfc\x99\xd5\x9e\xe8\x13[\x83\x06\xf7\x8f\x90\x0eu\x99\xfc"
    b_ciphertext_data_base64 = base64.b64encode(b_ciphertext_data)

    # the ciphertext data encoded as a YAML string
    s_ciphertext_data_yaml = b_ciphertext_data_base64.decode('ascii')

    # secrets

# Generated at 2022-06-11 09:17:39.292701
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = """
    - group_by:
        - id
        - name
    - group_by:
        - id
        - name
    """
    ace = AnsibleConstructor()
    # pylint: disable=unused-variable
    # Pylint thinks that the generator that AnsibleConstructor.construct_yaml_seq
    # returns is unused. However, it is used and needs to be iterated over.
    for data in ace.construct_yaml_seq(yaml_data):
        pass
    assert isinstance(data, AnsibleSequence)
    assert data[0]['group_by'][0] == 'id'
    assert data[0]['group_by'][1] == 'name'

# Generated at 2022-06-11 09:17:47.365902
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_file_path = "my_vault_file"
    test_vault_password = "1234"
    test_state_data = "VaultEncryptedUnicode object"
    ansible_constructor = AnsibleConstructor(test_file_path, [test_vault_password])
    test_node = AnsibleUnicode(test_state_data)
    ansible_constructor.construct_vault_encrypted_unicode(test_node)

# Generated at 2022-06-11 09:17:54.121711
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    u'''Test method construct_yaml_seq of the class AnsibleConstructor'''
    m = AnsibleConstructor()
    assert False, 'TODO'

# Generated at 2022-06-11 09:18:03.155670
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()
    assert isinstance(constructor.construct_yaml_str(''), AnsibleUnicode)
    assert constructor.construct_yaml_str('') == AnsibleUnicode('')
    assert isinstance(constructor.construct_yaml_str(u'42'), AnsibleUnicode)
    assert constructor.construct_yaml_str(u'42') == AnsibleUnicode(u'42')
    assert isinstance(constructor.construct_yaml_str(u'foo'), AnsibleUnicode)
    assert constructor.construct_yaml_str(u'foo') == AnsibleUnicode(u'foo')
    assert isinstance(constructor.construct_yaml_str(u'BAR'), AnsibleUnicode)
    assert constructor.construct_yaml_str

# Generated at 2022-06-11 09:18:12.233840
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import ansible.parsing.yaml.data
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib

    context = PlayContext()


    def test_func(doc):
        construct = AnsibleConstructor(vault_secrets=['mysecret'])
        construct.vault_secrets = ['mysecret']
        yaml_data = ansible.parsing.yaml.data.AnsibleParser(vault_secrets=['mysecret'], vault_password_file='/dev/null')
        ret = yaml_data.load(doc, vault_secrets=['mysecret'], vault_password_file='/dev/null')
        return ret



# Generated at 2022-06-11 09:18:22.758167
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64

    vault_secrets = [b'5ebe2294ecd0e0f08eab7690d2a6ee69']
    vault_secrets_wrong = [b'5ebe2294ecd0e0f08eab7690d2a6ee68']

    # We are using a specific hash as 'secret' that is included in the fixture test_AnsibleConstructor_construct_vault_encrypted_unicode.yml
    # With this hash we can decrypt the fixture file
    # This hash is not used in other tests

    # data is the fixture data, the vaulted data

# Generated at 2022-06-11 09:18:32.766907
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import wrap_var

    class TestClass(object):
        pass

    # These strings should be parsed as AnsibleUnsafeText/AnsibleUnsafeBytes
    # and not as unicode or str in py3 resp. str or bytes in py2
    unsafe_tst_str = "!unsafe 'test1'"
    unsafe_tst_bytes = u"!unsafe b'test2'".encode('utf-8')

    # First check if they are parsed as AnsibleUnsafeText/AnsibleUnsafeBytes
    data = y

# Generated at 2022-06-11 09:18:38.921153
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    # test with DUPLICATE_YAML_DICT_KEY = 'ignore'
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    data = yaml.load("""
        a: 1
        a: 2
""", AnsibleConstructor)
    assert data == {'a': 2}
    assert data.ansible_pos == ('<unicode string>', 2, 3)

# Generated at 2022-06-11 09:18:52.850132
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    '''
    Runs a unit test for AnsibleConstructor's construct_mapping method
    '''

    from yaml.nodes import MappingNode
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.scanner import Scanner
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''\
a: 
  b: 1
  c: 2
  d: 3
'''


# Generated at 2022-06-11 09:18:57.375259
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_str = """\
    - first
    - second
    """
    yaml_obj = [u'first', u'second']
    assert yaml_obj == yaml.load(yaml_str, Loader=AnsibleConstructor)

# Generated at 2022-06-11 09:19:00.701177
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode()
    node.value = {'a':1,'b':2}
    assert(AnsibleConstructor().construct_yaml_map(node) == {'a':1,'b':2})


# Generated at 2022-06-11 09:19:09.809481
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # FIXME: the below 2 lines need to be removed once the fixture style of
    # tests has been converted to pytest throughout the testsuite, currently
    # this is required for the ansible-test sanity checks to pass
    from ansible.module_utils import basic
    basic.sys = sys

    c = AnsibleConstructor()

    # test basic usage
    result = c.construct_yaml_seq(None)
    assert isinstance(result, list)

    # test 'yield data'
    iterator = c.construct_yaml_seq(None)
    data = next(iterator)
    assert isinstance(data, AnsibleSequence)
    assert isinstance(iterator, list)

# Generated at 2022-06-11 09:19:22.042164
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    c = AnsibleConstructor()
    l = c.construct_yaml_seq("nodename")
    assert isinstance(l, AnsibleSequence)

# Generated at 2022-06-11 09:19:33.422060
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import textwrap
    import yaml

# Generated at 2022-06-11 09:19:42.024415
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_data = '''
    key:  # comment
      - item1
      - item2
    key2: value2
    key3:
      key: value
    '''
    import yaml
    node = yaml.compose(test_data)
    mapping = AnsibleConstructor.construct_mapping(AnsibleConstructor(), node)
    # MappingNode has list of 2-tuples
    assert len(mapping) == 3
    assert mapping['key'] == ['item1', 'item2']
    assert mapping['key2'] == 'value2'
    assert mapping['key3']['key'] == 'value'
    assert mapping.ansible_pos == (None, 1, 1)

# Generated at 2022-06-11 09:19:51.225749
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.module_utils._text import to_bytes

    def _check_ansible_pos(data, expected_ansible_pos):
        return not hasattr(data, 'ansible_pos') or data.ansible_pos == expected_ansible_pos


# Generated at 2022-06-11 09:19:56.704666
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    a = '''
 - one
 - two
 - three
    '''
    data = yaml.safe_load(a)
    assert data == [u'one', u'two', u'three']
    data = yaml.load(a, Loader=AnsibleLoader)
    assert data == [u'one', u'two', u'three']



# Generated at 2022-06-11 09:20:00.513281
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    constructor = AnsibleConstructor()
    data = dict(a=dict(b=1, c=2))
    node = AnsibleConstructor.construct_yaml_map(constructor, data)
    assert isinstance(node, AnsibleMapping)
    assert node == data

# Generated at 2022-06-11 09:20:06.904300
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    config_data = b'''
a: 
  b: 1
  c: 2
  d: 3
'''
    config_data_dict = dict({'a': {'b': 1, 'c': 2, 'd': 3}})
    from ansible.parsing.yaml.loader import AnsibleLoader

    config_obj = AnsibleLoader(config_data, file_name='test_AnsibleConstructor_construct_yaml_map').get_single_data()
    assert config_data_dict == config_obj



# Generated at 2022-06-11 09:20:15.520767
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Testing for Case 1 #
    # Case 1:
    # The contents of the variable 'input_data' is set as following
    # input_data = "- {a: 1, b: 2, c: 3}" When the contents of the variable 'input_data' is
    # passed to AnsibleConstructor.construct_yaml_seq, it should return corresponing
    # AnsibleSequence object.
    input_data = '''- {a: 1, b: 2, c: 3}
                    - {a: 1, b: 2, c: 3}'''
    ansible_seq = AnsibleConstructor.construct_yaml_seq(input_data)
    assert isinstance(ansible_seq, AnsibleSequence)
    assert len(ansible_seq) == 2

# Generated at 2022-06-11 09:20:25.301998
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestLoader(DataLoader):
        def __init__(self):
            pass

    loader = TestLoader()
    testobj = AnsibleConstructor(loader)

    emptystrnode = 'tag:yaml.org,2002:str'
    emptystr = testobj.construct_yaml_str(emptystrnode)
    assert(isinstance(emptystr, AnsibleUnicode))
    assert(emptystr == '')
    assert(emptystr.ansible_pos == ('<string>', 1, 0))

    nonemptystrnode = 'tag:yaml.org,2002:str'

# Generated at 2022-06-11 09:20:33.984786
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_secrets = [VaultSecret('foo'), VaultSecret('bar')]
    vault_secrets.extend(sys.argv[1:])
    ac = AnsibleConstructor(file_name="test_data/test_vault.yml", vault_secrets=vault_secrets)

# Generated at 2022-06-11 09:21:01.195834
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    keys = ["key1", "key2", "key3", "key4", "key5"]
    values = ["value1", "value2", "value3", "value4", "value5"]
    #duplicate_keys = ["key1", "key2", "key2", "key4", "key4"]
    duplicate_keys = ["key1", "key2", "key1", "key4", "key4"]

    test_obj = AnsibleConstructor()
    test_obj.display = Display()
    expected_result = dict(zip(keys, values))
    test_obj.display.verbosity = 2

    # Test case 1: No duplicate keys
    generated_result = test_obj.construct_mapping(mapping=dict(zip(keys, values)))
    assert expected_result == generated_result

# Generated at 2022-06-11 09:21:11.360955
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    '''
    Test AnsibleConstructor.construct_mapping by passing different values
    of node.
    '''

    yaml = '''
        a: 1
        b: 2
        c: 3
    '''

    # Verify that constructor does not fail for valid
    # YAML sequence.
    result = AnsibleConstructor(file_name='test_file_name').construct_mapping(
        YAML().load(yaml)[0]
    )

    # Verify that the result is correct by comparing it
    # with expected result.
    assert result == {u'a': 1, u'b': 2, u'c': 3}
    assert result.ansible_pos == ('test_file_name', 1, 0)

    # Verify that constructor fails for invalid YAML
    # sequence.

# Generated at 2022-06-11 09:21:21.400596
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Variables we expect to find in the vault
    expected_vault_id = 'default'
    expected_vault_secret = 'vaultsecret'
    # The variable we encrypt
    variable_name = 'encrypted_variable'
    variable_value = 'The variable value'

# Generated at 2022-06-11 09:21:30.911437
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import unittest
    import yaml

    class TestAnsibleConstructor(unittest.TestCase):

        def test_construct_mapping(self):
            sample_dict1 = {'key1': 'value1', 'key2': 'value2'}
            sample_dict2 = {'key1': 'value1', 'key2': 'value2', 'key1': 'value3'}
            sample_dict3 = {'key1': 'value1', 'key2': 'value2', 'key1': (1,2,3)}
            sample_dict4 = {'key1': 'value1', 'key2': 'value2', 'key1': (1,2,3), 'key3': (1,2,3)}


# Generated at 2022-06-11 09:21:34.915065
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_dict = {
        'foo': 'bar',
        'fie': {
            'fum': 'fee',
            'foe': 'fum',
        },
        'baz': 'qux',
    }
    test_map = AnsibleConstructor.construct_mapping(test_dict)
    assert test_dict == test_map

# Generated at 2022-06-11 09:21:41.289471
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    import ansible.parsing.yaml.objects

    node = MappingNode(u'tag:yaml.org,2002:map', [], [])
    node.start_mark = "blah"
    node.end_mark = "blah"
    ac = AnsibleConstructor()
    thing = ac.construct_yaml_map(node)

    assert isinstance(thing, ansible.parsing.yaml.objects.AnsibleMapping)
    assert thing.ansible_pos == ("<string>", 1, 1)



# Generated at 2022-06-11 09:21:42.406796
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # FIXME: test construct_yaml_unsafe function
    pass



# Generated at 2022-06-11 09:21:48.513843
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = {'normal_key': 'normal_value'}
    deep_data = AnsibleMapping({'deep_key': 'deep_value'})
    data['deep_key'] = deep_data
    node = MappingNode()
    node.value = (('normal_key', 'normal_value'), ('deep_key', 'deep_value'))
    mapping = AnsibleConstructor().construct_mapping(node, deep=True)
    assert mapping == data


# Generated at 2022-06-11 09:21:58.185893
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    from yaml import load
    from yaml.scanner import ScannerError

    # mixed
    data = b"""
str1: foo
str2: bar
str3: baz
"""
    y = load(StringIO(to_native(data)), Loader=AnsibleConstructor)
    assert y['str1'] == 'foo'
    assert y['str2'] == 'bar'
    assert y['str3'] == 'baz'
    # single
    data = b"""
str: foo
"""
    y = load(StringIO(to_native(data)), Loader=AnsibleConstructor)
    assert y['str'] == 'foo'
    # empty
    data = b"""
str:
"""

# Generated at 2022-06-11 09:22:01.505968
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=[])
    vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(None)
    assert vault_encrypted_unicode is not None

# Generated at 2022-06-11 09:22:50.333299
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test calling construct_vault_encrypted_unicode without a vault password
    node = "!vault |\n\n          $ANSIBLE_VAULT;1.1;AES256\n\n          63313965336635333864316439336631646231346430346631643239633164326461323564373537\n\n          643836376230373633313662396561366338633762636437616336343731393733\n\n          386433346564366638646565313462393663326239393965623133353539303166\n\n          64323761616665366630363862333066666132656336\n\n          "
    assert AnsibleConstructor._testable_construct_v

# Generated at 2022-06-11 09:22:56.301510
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    """Method construct_vault_encrypted_unicode of class AnsibleConstructor should return plaintext in case vault_secrets set
    """
    plaintext = 'test'
    vault_secrets = ['test']
    vault_encrypted_unicode = AnsibleConstructor(None, vault_secrets)
    value = vault_encrypted_unicode.construct_vault_encrypted_unicode(plaintext)
    assert value == vault_encrypted_unicode._vaults['default'].decrypt(plaintext)



# Generated at 2022-06-11 09:23:05.767029
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # This test code was copied from this code:
    #   http://stackoverflow.com/questions/39821865/using-unittest-to-test-method-that-relies-on-user-input
    # which was the first result of this search (for the string "unittest mock input")
    #   http://www.google.com/search?q=unittest+mock+input
    import mock
    import io
    import sys
    import yaml

    mock_stdin = io.StringIO()
    mock_stdin.write('1')
    mock_stdin.seek(0)

    mock_stdout = io.StringIO()


# Generated at 2022-06-11 09:23:16.499034
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    file_name = 'test.yaml'
    vault_secrets = ['test_secret']
    text = "{'a': 'test', 'b': 'test:test'}"
    data = AnsibleMapping()
    data[u'a'] = u'test'
    data[u'b'] = u'test:test'
    yaml_data = context_sensitive_string(text)
    mapping_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=yaml_data, start_mark=None, end_mark=None)
    ansible_constructor = AnsibleConstructor(file_name, vault_secrets)
    result = ansible_constructor.construct_yaml_map(mapping_node)

# Generated at 2022-06-11 09:23:22.157343
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    _data = '''
- [apples, oranges]
- {'apples': 1, 'oranges': 2, 'pears': 3}
'''

    _data_seq = [
        AnsibleSequence([u'apples', u'oranges']),
        AnsibleMapping({u'apples': 1, u'oranges': 2, u'pears': 3})
    ]

    assert AnsibleConstructor.construct_yaml_seq(yaml.compose(_data)) == _data_seq

# Generated at 2022-06-11 09:23:25.578513
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test that the correct object is returned when trying to parse a dict
    ac = AnsibleConstructor(file_name='<string>')
    result = ac.construct_yaml_map(MappingNode(None, [], [], None, None))
    assert(isinstance(result, AnsibleMapping))

# Generated at 2022-06-11 09:23:34.430159
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    yaml_str = '''
    a: 1
    b: 2
    c: hi
    d: {a: 1, b: 2}
    e:
     - 1
     - 2
     - 3
    f: !unsafe '<script>alert("hacked")</script>'
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data[u'a'] == 1
    assert data[u'b'] == 2
    assert data[u'c'] == u'hi'
    assert len(data[u'd']) == 2
    assert isinstance(data[u'd'], AnsibleMapping)
    assert data[u'd'][u'a'] == 1


# Generated at 2022-06-11 09:23:43.226425
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode, AnsibleSequence, AnsibleVaultEncryptedUnicode
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    data0 = '''
    a: 1
    b:
      c: 2
      d: 2
    e:
      - 2
      - 2
    '''
    data1 = '''
    a: 1
    b:
      c: 2
      d: 2
    e:
      - 2
      - 2
    b:
      c: 3
      d: 4
    '''

# Generated at 2022-06-11 09:23:54.387897
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    data = b'$ANSIBLE_VAULT;1.1;AES256\n61333632333766373461303465393733653332363731386232626330356236313963353138353063310a6362393561653138393730646337636138366264616365343835383832316237316538366364630a656635326336383364393537383465303932373163306636346364633332313434383961316262\n'
    vault_secrets = ['password']
    vault_lib = VaultLib(secrets=vault_secrets)
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    constructor._vaults['default'] = vault_lib
    node = Ans

# Generated at 2022-06-11 09:24:05.428018
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None)
    constructor = AnsibleConstructor()

    node = loader.get_single_data('!unsafe 1')
    assert not hasattr(node, 'safe_for_untrusted_multiline_input')
    subset = loader.construct_yaml_subset(node, deep=True)
    assert hasattr(subset, 'safe_for_untrusted_multiline_input')
    assert subset.safe_for_untrusted_multiline_input

    node = loader.get_single_data('!unsafe "1"')
    assert not hasattr(node, 'safe_for_untrusted_multiline_input')