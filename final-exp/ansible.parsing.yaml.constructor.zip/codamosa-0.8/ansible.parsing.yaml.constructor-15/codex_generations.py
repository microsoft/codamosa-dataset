

# Generated at 2022-06-11 09:15:10.570187
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
        Test AnsibleConstructor class, method construct_yaml_map
    """
    # This tests a method that is used as a callback to yaml.loader,
    # it cannot be tested under current setup, TestLoader cannot handle
    # that method, TestLoader is the base class of TestYamlInclude.
    # To test this functionality we must use a different strategy,
    # for example a functional test located in lib/ansible/test/yaml_include/
    pass

# Generated at 2022-06-11 09:15:21.298139
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import tempfile
    import shutil
    import yaml
    from ansible.module_utils.six import PY2, text_type
    from ansible.module_utils._text import to_text

    # On Python 2, 2**64 == 2**64, on Python 3, 2**64 == 2**64 % 2**64.
    # For this test to work on both Python 2 and Python 3, we need to use
    # 2**64 % 2**64.
    big_int_py2 = 2**64
    big_int_py3 = 2**64 % 2**64
    big_int_for_test = big_int_py3 if PY2 else big_int_py2

    def _dict_representer(dumper, data):
        return dumper.represent_dict(data.items())

   

# Generated at 2022-06-11 09:15:30.620087
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    testData = {'foo': 1, 'bar': 2, 'this is a duplicate': 3, 'this is another duplicate': 4}

    C.DUPLICATE_YAML_DICT_KEY = 'error'
    try:
        AnsibleConstructor().construct_mapping(testData)
    except ConstructorError as err:
        assert(str(err) ==
               u"while constructing a mapping from {'foo': 1, 'bar': 2, 'this is another duplicate': 4, 'this is a duplicate': 3}, line 1, column 0:found a duplicate dict key ('this is a duplicate')")
    C.DUPLICATE_YAML_DICT_KEY = 'warn'

# Generated at 2022-06-11 09:15:40.150812
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # GIVEN an AnsibleConstructor with no secrets
    ac = AnsibleConstructor()

    # WHEN constructing a vault node
    node = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          333132333435363738393132333435363738393132333435363738393132333435\n          3637383931323334353637383931323334353637383931323334353637383931\n          3738332\n"

    # THEN an error occurs
    try:
        ac.construct_vault_encrypted_unicode(node)
        assert False, "No secret provided, should fail"
    except ConstructorError as e:
        assert True, "No secret provided, failed as expected"
        print(e)

# Generated at 2022-06-11 09:15:48.372564
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
  vault_secrets = ['abc']
  ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
  ciphertext = ansible_constructor.construct_vault_encrypted_unicode(node=None)
  assert ciphertext.vault is not None
  assert len(ciphertext.vault.secrets) == 1
  assert ciphertext.vault.secrets[0] == 'abc'

  ciphertext = ansible_constructor.construct_vault_encrypted_unicode(node=None)
  assert ciphertext.vault is not None
  assert len(ciphertext.vault.secrets) == 2
  assert ciphertext.vault.secrets[1] == 'abc'

# Generated at 2022-06-11 09:15:59.063712
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    """
    This unit test tests the method construct_vault_encrypted_unicode of class AnsibleConstructor.
    """
    import os
    import string
    import random
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    # create a VaultLib object
    secret = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(20))
    vault_pass_file = tempfile.NamedTemporaryFile(delete=True)
    vault_pass_file.write(to_bytes(secret))
    vault_pass_file.flush()
    vault = VaultLib(vault_pass_file.name)
    vault_pass_file.close()

   

# Generated at 2022-06-11 09:16:09.428805
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    '''
    Ensure that construct_yaml_map correctly converts a PyYaml MappingNode to
    an AnsibleMapping.
    '''
    from yaml.nodes import MappingNode
    from yaml.constructor import ConstructorError
    from copy import deepcopy

    # The data (dict) we will pass to the constructor
    data = {
        b'foo': b'bar',
        b'baz': b'qux',
    }

    # The node we will pass to the method.  We need to use a copy so that the
    # modifications to the node don't "leak" into other tests.
    node = deepcopy(MappingNode(None, None, data, None, None))

    # The object we expect to get back
    expect = AnsibleMapping(data)

    # The node should be modified

# Generated at 2022-06-11 09:16:09.980807
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-11 09:16:19.886978
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import os
    import lib.ansible_internal_yaml.constructor as constructor
    import lib.ansible_internal_yaml.composer as composer
    my_dict = {'a': {'b': {'c': [1, 2, 3, 4]}}}
    yaml_data = """
a:
  b:
    c: [1, 2, 3, 4]
        """
    if sys.version_info < (3, 0):
        from StringIO import StringIO
    else:
        from io import StringIO
    yaml_file = StringIO(yaml_data)
    my_constructor = constructor.AnsibleConstructor()

# Generated at 2022-06-11 09:16:24.901682
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    mappingnode = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    assert mappingnode.id == 'mapping'
    assert mappingnode.tag == 'tag:yaml.org,2002:map'
    assert constructor.construct_mapping(mappingnode) == AnsibleMapping()

# Generated at 2022-06-11 09:16:40.586661
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    # Create a mock VaultLib class with a decrypt method that simply returns the
    # ciphertext
    class VaultLibDecrypt(VaultLib):
        def decrypt(self, ciphertext):
            return ciphertext

    # Create an AnsibleConstructor with a VaultLibDecrypt instance
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults['default'] = VaultLibDecrypt(None)

    # Create a node that points to a vault-encrypted document
    from yaml.nodes import ScalarNode
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer

    node_value = u'\u2234foo\u2234'

# Generated at 2022-06-11 09:16:46.671156
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_str = '''
        - name: test
          inventory: "{{ inventory_file | basename }}"
        - name: test2
          inventory: "{{ inventory_file | basename }}"
        - name: test3
          inventory: "{{ inventory_file | basename }}"
    '''
    ac = AnsibleConstructor(file_name='test')

    data = yaml.compose_all(yaml.parse(yaml_str), ac)

    assert isinstance(data, list)
    assert isinstance(data[0], AnsibleMapping)
    assert isinstance(data[1], AnsibleMapping)
    assert isinstance(data[2], AnsibleMapping)

# Generated at 2022-06-11 09:16:57.006405
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class TestConstructor(AnsibleConstructor):
        def __init__(self):
            self._test_data_is_empty = False
            self._test_data = dict()
            self._test_data['construct_mapping_return'] = dict()
            super(TestConstructor, self).__init__()

        def construct_mapping(self, node, deep=False):
            result = dict()
            for key_node, value_node in node.value:
                result[key_node.value] = value_node.value
                if self._test_data['construct_mapping_return']:
                    return self._test_data['construct_mapping_return']
            self._test_data['construct_mapping'] = result
            return result

    import yaml
    data = dict()

    # Test #0


# Generated at 2022-06-11 09:17:06.458826
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    secret = '$ecret'

# Generated at 2022-06-11 09:17:12.915701
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    import yaml

    try:
        # Check if yaml.CSafeLoader is defined and use it if so.
        yaml.CSafeLoader
        yaml_loader = yaml.CSafeLoader
    except AttributeError:
        yaml_loader = yaml.SafeLoader

    class AnsibleConstructorTest(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            raise Exception("construct_yaml_unsafe must not be called")

        def construct_unsafe(self, node):
            return self.construct_yaml_unsafe(node)


# Generated at 2022-06-11 09:17:24.935835
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import os
    import sys

    # create a yaml loader
    loader = AnsibleConstructor(file_name=None, vault_secrets=None)

    # define a test node
    class TestNode:
        def __init__(self, start_mark, end_mark, value=None):
            self.start_mark = start_mark
            self.end_mark = end_mark
            self.value = value

    # create a test start mark
    class TestMark:
        def __init__(self, name, line, column):
            self.name = name
            self.line = line
            self.column = column

    # define a test value
    class TestValue:
        def __init__(self, ansible_pos, value=[]):
            self.ansible_pos = ansible_pos
            self.value

# Generated at 2022-06-11 09:17:32.050500
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from yaml.constructor import ConstructorError

    class TestAnsibleConstructor(unittest.TestCase):
        # Test case for method construct_mapping

        def test_no_duplicate(self):
            ac = AnsibleConstructor()

            # Test with a mapping without duplicate keys
            h_mapping = {'key1': 'value1', 'key2': 'value2'}
            mapping = ac.construct_mapping(MappingNode(None, [], u'tag:yaml.org,2002:map'), deep=True)
            mapping.update(h_mapping)
            self.assertEqual(h_mapping, mapping)

           

# Generated at 2022-06-11 09:17:42.662119
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    # ConstructorError
    node = object()
    try:
        assert ansible_constructor.construct_yaml_str(node) == node
    except ConstructorError:
        assert True
    else:
        assert False
    node = AnsibleMapping()
    try:
        assert ansible_constructor.construct_yaml_str(node)
    except ConstructorError:
        assert True
    else:
        assert False
    # Try to perform the test
    node = AnsibleMapping()
    node.start_mark = object()
    node.start_mark.name = ''
    assert ansible_constructor.construct_yaml_str(node).ansible_pos == ('<string>', 1, 1)

# Generated at 2022-06-11 09:17:52.764344
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class Sample(object):
        pass
    sample = Sample()
    sample.test = 'hello'

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    MAPPING_YAML_EXAMPLE = u"""
a:
  key1: value1
  key2: value2
b: {c: value3, d: value4}
e:
  - item1
  - item2
"""
    if not PY2:
        MAPPING_YAML_EXAMPLE = MAPPING_YAML_EXAMPLE.encode('utf-8')
    s = StringIO(MAPPING_YAML_EXAMPLE)

    import yaml
    representation = yaml.load(s)

    # object of

# Generated at 2022-06-11 09:18:01.158257
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Check if AnsibleConstructor.construct_yaml_seq is handling each element of the list
    :return:
    """
    _ansible_file_name = 'sample.yml'
    _vault_secrets = '123'
    ansible_constructor = AnsibleConstructor(_ansible_file_name, _vault_secrets)

    import yaml
    from yaml.scanner import ScannerError
    from yaml.parser import ParserError

    # Testseq checks that if element has key "key" then same element has key "key_value"

# Generated at 2022-06-11 09:18:13.636917
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Initialization of AnsibleConstructor class
    ansible_constructor = AnsibleConstructor()

    # Value of class AnsibleSequence
    ansible_seq = AnsibleSequence()

    # Extra attribute ansible_pos
    ansible_seq.ansible_pos = None

    value = [1, 2, 3]

    # Node object of class yaml.nodes.MappingNode with
    # value of ansible_seq
    node = MappingNode(None, value, None, None, False)

    # Assert method construct_yaml_seq
    assert ansible_constructor.construct_yaml_seq(node) is not None



# Generated at 2022-06-11 09:18:22.451571
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    yamlstr = '''
- hosts: localhost
  tasks:
    - name: foo
      debug: msg=foo
      debug: msg=bar

    - name: bar
      debug: msg=baz'''

    print('the below should not be printed')

    try:
        yaml.load(yamlstr, AnsibleConstructor)
    except ConstructorError as e:
        print('exception: ' + str(e))
    else:
        raise Exception('expected a constructor error')

    print('the above should not be printed')


if __name__ == '__main__':
    test_AnsibleConstructor_construct_mapping()

# Generated at 2022-06-11 09:18:32.541079
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.composer import Composer
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import io
    import sys
    import unittest
    
    class AnsibleConstructorTestCase(unittest.TestCase):
        
        def setUp(self):
            self.constructor = AnsibleConstructor()
            # Create a node with type str
            class FakeComposer(Composer):
                def __init__(self):
                    self.document = "document"
                def get_node(self):
                    class FakeNode(object):
                        id = 'str'
                        tag = u'!str'
                        start

# Generated at 2022-06-11 09:18:41.610838
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_text

    context = dict(variable_start_string="[[",
                   variable_end_string="]]",
                   loader=DataLoader())

    s = u'[[unsafe_var1]]'
    unsafe_var1 = AnsibleVaultEncryptedUnicode(b'vault-test1')
    unsafe_var1.vault = context['loader']._vault_secrets[0].vault
    assert to_text(unsafe_var1) == to_text(unsafe_var1.vault.decrypt(unsafe_var1))

# Generated at 2022-06-11 09:18:55.491397
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Tests for the case where duplicated key raises an error
    amc = AnsibleConstructor()
    amc._ansible_file_name = 'fake_filename'
    node_start_mark = type('node_start_mark', (object,), {})()
    node_end_mark = type('node_end_mark', (object,), {})()
    node_start_mark.line = 10
    node_start_mark.column = 20
    node_start_mark.name = 'fake_filename'
    node_end_mark.line = 10
    node_end_mark.column = 20
    node_start_mark.name = 'fake_filename'
    key_node = type('key_node', (object,), {})()

# Generated at 2022-06-11 09:19:03.107588
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ''' testing method construct_yaml_seq of class AnsibleConstructor '''
    # testing with default value
    a = AnsibleConstructor()
    d = {'a': 1, 'b': 2}
    data = AnsibleSequence()
    data.extend([1, 2])
    data.ansible_pos = None
    yaml_data = AnsibleConstructor.construct_yaml_seq(a, d)
    assert yaml_data.__next__() == data
    data = AnsibleSequence()
    data.ansible_pos = None
    assert yaml_data == data


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 09:19:04.582029
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print(AnsibleConstructor.construct_yaml_map)

# Generated at 2022-06-11 09:19:14.946916
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    import yaml
    from ansible.parsing.vault import VaultLib

    my_list = ['foo', 'bar', 'baz']
    my_list_yaml = yaml.dump(my_list, default_flow_style=False)
    seq_node = yaml.compose(my_list_yaml)
    assert isinstance(seq_node, yaml.nodes.SequenceNode)

    vault_secret = 'myvaultsecret'

    # load into AnsibleMapping, using Constructor and vault_secrets
    ac = AnsibleConstructor(file_name='/test/test.yml', vault_secrets=[vault_secret])
    val = ac.construct_yaml_seq(seq_node).next()
    assert isinstance(val, list)

# Generated at 2022-06-11 09:19:18.526777
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = u'tag:yaml.org,2002:str'
    value = u'foo'
    string = u'{0} {1}'.format(node, value)
    aconstructor = AnsibleConstructor()
    assert aconstructor.construct_yaml_str(value) == string

# Generated at 2022-06-11 09:19:28.443614
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:19:39.792812
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Setup
    node = MappingNode(None, None, None)
    yaml_data = dict(key="val")
    ansible_constructor = AnsibleConstructor()

    # Execute
    ansible_map = ansible_constructor.construct_yaml_map(node)
    ansible_map.update(yaml_data)

    # Assert
    assert ansible_map is not None
    assert ansible_map['key'] == 'val'
    assert isinstance(ansible_map, dict)



# Generated at 2022-06-11 09:19:47.291666
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create an instance of AnsibleConstructor
    ansible_constructor = AnsibleConstructor()

    # Create a node containing a vault-encrypted string
    node_str = "test vault string"
    node = MappingNode(None)
    node.value = [(AnsibleUnicode("test_vault_string_key"), AnsibleUnicode(node_str))]

    # Decrypt the node
    decrypted_node = ansible_constructor.construct_vault_encrypted_unicode(node)
    assert decrypted_node.vault is not None
    assert decrypted_node.decrypted

# Generated at 2022-06-11 09:19:50.493562
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_str = """[ 1, 2, 3 ]"""

    import yaml
    ansible_constructor = AnsibleConstructor()
    data = yaml.load(yaml_str, Loader=yaml.Loader)

    assert isinstance(data, AnsibleSequence)

# Generated at 2022-06-11 09:19:53.862794
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    val = '''
        foo: !unsafe [1, 2, 3]
    '''
    result = AnsibleLoader(val).get_single_data()
    assert result == {'foo': [1, 2, 3]}



# Generated at 2022-06-11 09:19:57.319041
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()

    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

    assert constructor.construct_mapping(node) == AnsibleMapping()

# Generated at 2022-06-11 09:20:06.669361
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode, ScalarNode
    from yaml.composer import Composer
    class DummyComposer(Composer):
        def get_node(self):
            return SequenceNode(tag=u'tag:yaml.org,2002:seq', value=[],
                start_mark=None, end_mark=None, flow_style=False)
    constructor = AnsibleConstructor()
    constructor.composer = DummyComposer(constructor.composer.parser)
    seq = next(constructor.construct_yaml_seq(constructor.composer.get_node()))
    assert isinstance(seq, AnsibleSequence), "Must be instance of AnsibleSequence"
    seq.extend([AnsibleUnicode('foo')])

# Generated at 2022-06-11 09:20:15.673574
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    from ansible.parsing.vault import VaultEditor
    import yaml
    from ansible.module_utils._text import to_bytes
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 09:20:18.584251
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from collections import OrderedDict
    mapping = AnsibleConstructor.construct_mapping(None, deep=False)
    assert not isinstance(mapping, OrderedDict)
    assert isinstance(mapping, AnsibleMapping)

# Generated at 2022-06-11 09:20:23.394397
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = '''
        a: b
        c: d
        a: e
    '''
    d = AnsibleConstructor().construct_mapping(node)
    assert d['a'] == b
    assert d['c'] == d
    assert d.ansible_pos == ('<unicode string>', 0, 0)

# Generated at 2022-06-11 09:20:27.875182
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert AnsibleConstructor().construct_yaml_str('123') == AnsibleUnicode('123')
    assert AnsibleConstructor().construct_yaml_str(u'123') == AnsibleUnicode(u'123')
    assert AnsibleConstructor().construct_yaml_str(b'123') == AnsibleUnicode(b'123')

# Generated at 2022-06-11 09:20:39.824832
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.parsing.yaml.loader as loader
    from pprint import pprint
    from ansible.module_utils._text import to_text

    text = u"""\
%YAML 1.2
---
a:
  b: c
d:
  e:
    - f
    - g
    - h
  i: j
  k:
    l: m
    n: "o"
    p: [q, r, s]
    t:
      - u: v
      - w: x
      - y: z"""
    my_dict = loader.load(text, AnsibleConstructor)
    assert 'a' in my_dict
    assert 'b' in my_dict['a']
    assert my_dict['a']['b'] == 'c'

# Generated at 2022-06-11 09:20:47.337687
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import sys
    import ansible.parsing.vault
    vault_password = os.getenv("ANSIBLE_VAULT_PASSWORD")
    if vault_password is None:
        print("ANSIBLE_VAULT_PASSWORD environment variable not defined")
        sys.exit(-1)
    vault_secrets = [{'vault_password_file': vault_password}]
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-11 09:20:56.569999
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

# Generated at 2022-06-11 09:21:04.492865
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.vars import AnsibleUnsafe
    import sys
    py_version = sys.version_info
    if py_version[0] <= 2:
        import os
        import subprocess
        import tempfile
        import yaml
        a = AnsibleConstructor()
        unsafe_string = "!unsafe {0}".format(os.path.normpath(tempfile.gettempdir()))
        obj = yaml.load(unsafe_string, Loader=a)
        assert isinstance(obj, AnsibleUnsafe)
        assert subprocess.call(['ls', obj], close_fds=True) == 0
    else:
        return

# Generated at 2022-06-11 09:21:15.832758
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import six
    import unittest
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.old_stdout = sys.stdout
            self.buffer = io.StringIO()
            sys.stdout = self.buffer

        def tearDown(self):
            sys.stdout = self.old_stdout

    class TestAnsibleConstructorIgnore(TestCase):
        def runTest(self):
            yaml_str = '''
                foo: bar
                foo: baz
            '''
            yaml_obj = yaml.load(yaml_str, Loader=AnsibleLoader)

# Generated at 2022-06-11 09:21:20.515734
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()

    value_node = object()
    mocked_construct_scalar = object()
    with mock.patch.object(AnsibleConstructor, 'construct_scalar', return_value=mocked_construct_scalar):
        value = constructor.construct_yaml_str(value_node)
    assert value == mocked_construct_scalar


# Generated at 2022-06-11 09:21:29.993423
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-11 09:21:31.600376
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    result = AnsibleConstructor().construct_yaml_str(None)
    assert result == to_bytes(u''), result

# Generated at 2022-06-11 09:21:40.506392
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml = """
        - hosts: localhost
          connection: local
          tasks:
            - name: test
              debug:
                msg: "test"
                test: "test"
    """

# Generated at 2022-06-11 09:21:44.832842
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_obj = AnsibleConstructor()
    test_obj = ansible_constructor_obj.construct_yaml_str('test')
    # test should be assigned the unicode representation of the input it was assigned to
    assert test_obj == u'test'
    # test type should be of type AnsibleUnicode
    assert isinstance(test_obj, AnsibleUnicode)

# Generated at 2022-06-11 09:22:00.992844
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
        foo: bar
        bam: !unsafe 'false'
        num: 42
        constant: 1kb
        '''
    result = AnsibleLoader(data).get_single_data()
    assert isinstance(result, AnsibleMapping)
    assert result['foo'] == 'bar'
    assert result['bam'] == 'false'
    assert result['num'] == 42
    assert result['constant'] == 1024


# Generated at 2022-06-11 09:22:07.860137
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    expected = ['name', 'age']
    yaml_data = """
        - name
        - age
    """
    yaml_data = to_bytes(dedent(yaml_data), errors='surrogate_or_strict')
    constructor = AnsibleConstructor(file_name='fname')
    assert list(constructor.construct_yaml_seq(constructor.construct_yaml_sequence(yaml_data))) == expected
    assert list(constructor.construct_yaml_seq(constructor.construct_yaml_sequence(yaml_data)))[0].ansible_pos == ('fname', 2, 3)

# Generated at 2022-06-11 09:22:19.518027
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    assertion_error_message = "wrong password"
    assert_error_message = "should have thrown assertion error"
    constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:22:24.210190
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ac = AnsibleConstructor()
    seq = ac.construct_yaml_seq({'value': 'test'})
    assert isinstance(seq, AnsibleSequence)
    assert to_bytes(seq) == b'test'


# Generated at 2022-06-11 09:22:31.819274
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    from yaml.constructor import ConstructorError
    from yaml.nodes import MappingNode

    mock_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

    ac = AnsibleConstructor()

    assert ac.construct_yaml_map(mock_node) == AnsibleMapping({})



# Generated at 2022-06-11 09:22:36.585672
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys, StringIO
    sio = StringIO.StringIO()
    old_stdout = sys.stdout
    sys.stdout = sio
    a = AnsibleConstructor()
    node = a.construct_yaml_map(node={'foo': 'bar', 'baz': 'qux', 'foo': 'baz'})
    sys.stdout = old_stdout
    io = sio.getvalue()
    assert 'found a duplicate dict key' in io
    for key in node.keys():
        assert key in ('foo', 'baz')



# Generated at 2022-06-11 09:22:49.732238
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleMapping

    class MockNode:
        def __init__(self, value):
            self.value = value

    class MockConstructor:
        def __init__(self, node):
            self.node = node
            self.construct_mapping_called = False

        def construct_mapping(self, node, deep=False):
            self.construct_mapping_called = True
            assert node is self.node
            return {'key': 'value'}

    class MockArgv:
        def __init__(self):
            self.debug = False

    class MockC:
        class DUPLICATE_YAML_DICT_KEY:
            pass

    constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:22:58.364152
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['vault_secret']
    yaml_data = u'''
    ---
    !vault |
        $ANSIBLE_VAULT;1.1;AES256
        6435376433373064303132353433383039356133353165363033343136656261343332643166623965
        6565306664316336326563613163363063383134396334666330656661303633
        ...
    '''
    yaml.add_multi_constructor(u'!vault', None, AnsibleConstructor)
    data = yaml.load(yaml_data)
    assert data.data == u'$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-11 09:23:01.743360
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = u"""- one
- two
- three
"""
    value = AnsibleConstructor().construct_yaml_seq(yaml_data)
    assert value == [u'one', u'two', u'three']



# Generated at 2022-06-11 09:23:13.274732
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import ansible.parsing.yaml.dumper
    class AnsibleDumper(ansible.parsing.yaml.dumper.AnsibleDumper):
        pass
    # mock yaml.nodes.MappingNode
    mocked_MappingNode = AnsibleDumper.mock.create_autospec(ansible.parsing.yaml.nodes.MappingNode)
    # mock yaml.nodes.Node
    mocked_Node = AnsibleDumper.mock.create_autospec(ansible.parsing.yaml.nodes.Node)
    # mock ansible.parsing.vault.VaultLib
    mocked_VaultLib = AnsibleDumper.mock.create_autospec(ansible.parsing.vault.VaultLib)
    # mock

# Generated at 2022-06-11 09:23:30.998261
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    pass

# Generated at 2022-06-11 09:23:33.201299
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert "AnsibleConstructor" == AnsibleConstructor.__name__
    assert "construct_yaml_map" == AnsibleConstructor.construct_yaml_map.__name__

# Generated at 2022-06-11 09:23:39.446563
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import os
    import yaml
    from ansible.module_utils.six.moves import StringIO

    io = StringIO()

    io.write(u"- 1\n")
    io.write(u"- 2\n")
  
    io.seek(0)

    c = AnsibleConstructor()
    for data in c.construct_yaml_seq(yaml.reader.Reader(io).read()):
        pass

    assert isinstance(data, AnsibleSequence)
    assert data[0] == 1
    assert data[1] == 2

# Generated at 2022-06-11 09:23:48.946421
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['vault_secret_secret']

# Generated at 2022-06-11 09:23:53.449367
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    a = AnsibleConstructor()
    data = a.construct_yaml_seq('test')
    assert type(data) is list
    data = data[0]
    assert type(data) is AnsibleSequence
    assert data.ansible_pos == (None, None, None)

# Generated at 2022-06-11 09:24:03.307727
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # test dictionary with non-string keys (not supported)
    import yaml
    node = yaml.nodes.MappingNode(u'!map')
    node.value = [
        yaml.nodes.MappingNode(u'tag:yaml.org,2002:str'),
        yaml.nodes.ScalarNode(u'str', u'foo', (10, 1), (10, 1), 'quoted'),
    ]
    c = AnsibleConstructor()
    try:
        c.construct_mapping(node)
        assert False
    except yaml.constructor.ConstructorError:
        assert True

# Generated at 2022-06-11 09:24:11.699506
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import pytest_twisted
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import combine_vars
    from ansible.utils.vars import combine_hash

    from ansible.plugins.vars.vault_cli import AnsibleVaultCLIError
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import yaml

    instance = AnsibleConstructor()


# Generated at 2022-06-11 09:24:19.774486
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class node(object):
        def __init__(self, value=None, start_mark=None):
            self.value = value
            self.start_mark = start_mark

    class node1(object):
        def __init__(self, value=None, start_mark=None):
            self.value = value
            self.start_mark = start_mark

    class node2(object):
        def __init__(self, value=None, start_mark=None):
            self.value = value
            self.start_mark = start_mark

    class node3(object):
        def __init__(self, value=None, start_mark=None):
            self.value = value
            self.start_mark = start_mark


# Generated at 2022-06-11 09:24:28.039315
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:24:30.384949
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    actual = AnsibleConstructor().construct_yaml_seq(None)
    assert type(actual) == type(AnsibleSequence())

# Generated at 2022-06-11 09:24:48.328631
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    pass
    #TODO


# Generated at 2022-06-11 09:24:50.201671
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = AnsibleConstructor()
    data = 'Test ansible string'
    node = yaml_str.construct_yaml_str(data)
    assert data == node

# Generated at 2022-06-11 09:24:58.482052
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml = """
- name: Test of construct_yaml_map
  hosts: all
  tasks:
    - name: test_duplicate_dict_keys
      debug:
        msg: "Hello World"
    - name: test_duplicate_dict_keys
      debug:
        msg: "Hello Ansible"
"""
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader