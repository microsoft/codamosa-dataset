

# Generated at 2022-06-11 09:15:10.195248
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    C.DUPLICATE_YAML_DICT_KEY = 'error'
    yaml_constructor = AnsibleConstructor()
    test_dict = dict(test_key='test_value', test_key2=2)
    yaml_map = yaml_constructor.construct_yaml_map(test_dict)
    # .pop() is just a helper to assert the test_key value
    assert yaml_map.pop('test_key') == 'test_value'

# Generated at 2022-06-11 09:15:12.935522
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor()
    b = AnsibleMapping()
    b[1] = 1
    b[2] = 2
    assert a.construct_yaml_map(b) == b


# Generated at 2022-06-11 09:15:20.740109
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    yaml_str = to_bytes('''
        a:
          - aa
        b:
          - bb
    ''')
    cons = AnsibleConstructor()
    data = list(yaml.load_all(yaml_str, Loader=cons.loader))[0]

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data.ansible_pos, tuple)
    assert data['a'] == ['aa']
    assert data['b'] == ['bb']


# Generated at 2022-06-11 09:15:23.961763
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ansible_constructor = AnsibleConstructor()
    node = None
    result = ansible_constructor.construct_yaml_str(node)
    assert isinstance(result, AnsibleUnicode)

# Generated at 2022-06-11 09:15:32.650574
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, None)

    # Passing sequence of dictionaries
    data = '''
- dict:
    foo: bar
- dict:
    bar: baz
'''
    constructed_data = loader._constructor.construct_yaml_seq(data)
    assert hasattr(constructed_data[0], 'ansible_pos')
    assert [dict(foo='bar'), dict(bar='baz')] == list(constructed_data)

    # Passing sequence of sequences (list of lists)
    data = '''
-
  - foo
  - bar
-
  - bar
  - baz
'''
    constructed_data = loader._constructor.construct_yaml_seq(data)

# Generated at 2022-06-11 09:15:41.783943
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from io import StringIO

    value = u'[Foo]\nbar=baz\n'

# Generated at 2022-06-11 09:15:51.406279
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3, string_types
    from ansible.module_utils.six.moves import cStringIO

    data = """
    ansible:
      - safe:
          - 1
          - 2
      - unsafe:
          - 1
          - 2
      - unsafe:
          - 1
          - 2
      - safe:
          - 1
          - 2
    """

    def unsafe_string_callback(self):
        return 'unsafe'

    # We need a custom loader because AnsibleLoader.get_single_data()
    # always calls SafeLoader(stream) which will call add_implicit_resolver
    # and re-define the tag.

# Generated at 2022-06-11 09:16:01.733113
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.data import parse
    from ansible.parsing.dataloader import DataLoader

    # TODO: use Dataloader.set_vault_secrets() when we have proper unit tests
    vault_secrets = []

    yaml_data = """
        ---
        foo: bar
    """

    # NOTE: the native line separator is only needed on Windows, where Python
    #       by default uses '\r\n' as a line separator, instead of '\n', which
    #       is the native line separator on Linux, OSX and all other Unix-like
    #       systems.
    #       See https://docs.python.org/2/tutorial/inputoutput.html#reading

# Generated at 2022-06-11 09:16:12.337288
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ac = AnsibleConstructor()
    v = VaultLib()
    # test with wrong password
    v_data = v.encrypt(to_bytes('mysecret', encoding='utf-8'))
    v_split = v_data.split(b'$ANSIBLE_VAULT;', 1)
    v_split[1] = to_bytes('1.1;AES256;abcdef\n', encoding='utf-8')
    v_data = b'$ANSIBLE_VAULT;'.join(v_split)
    result = ac.construct_vault_encrypted_unicode({'value': v_data})
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault.secrets == []
    assert isinstance(result.data, bytes)
    assert result == v_data


# Generated at 2022-06-11 09:16:20.784553
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secret = 'whatever'
    vault_secrets = [vault_secret] # this would normally be from a cli argument, config file, environment variable, etc.
    test_string = "!vault |\n    line 1\n    line 2\n    line 3\n"
    test_bytes = to_bytes(test_string)
    new_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    s = new_constructor.construct_yaml(test_bytes)
    assert (type(s) is AnsibleVaultEncryptedUnicode)
    assert (s.value == test_string)
    assert (s.vault.secrets == [vault_secret])



# Generated at 2022-06-11 09:16:37.893693
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # Set up parameters
    node = None

    # Invoke object method
    test_obj = AnsibleConstructor()
    test_obj.construct_yaml_map(node)

    # Check called function to see if they are overwritten or not
    #
    # function name: construct_yaml_map
    #
    # patch_object(AnsibleConstructor, 'construct_yaml_map', autospec=True)
    # patch_construct_yaml_map = patch.object(
    #     AnsibleConstructor, 'construct_yaml_map', autospec=True)
    # patch_construct_yaml_map.start()
    # mock_construct_yaml_map = patch_construct_yaml_map.start()
    #

    #
    # function name: construct_mapping
    #
    #

# Generated at 2022-06-11 09:16:43.646230
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    class MockConstructor(AnsibleConstructor):
        def construct_object(self, node):
            return node.start_mark.index

    node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:int', value='42')
    node.start_mark = yaml.Mark(u'file.yml', index=57)
    constructor = MockConstructor()
    assert constructor.construct_yaml_unsafe(node) == 57



# Generated at 2022-06-11 09:16:51.800296
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml

    sample_text = '''
key1: value1
key2: value2
'''
    with open('/tmp/salt', 'w') as f:
        f.write(sample_text)

    with open('/tmp/salt') as f:
        x = yaml.load(f, AnsibleConstructor)
        assert isinstance(x, AnsibleMapping) is True
        assert x.get('key1') == 'value1'
        assert x.get('key2') == 'value2'
        assert x.ansible_pos == ('/tmp/salt', 1, 0)


# Generated at 2022-06-11 09:17:01.878948
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class TestYAMLObject(AnsibleBaseYAMLObject):
        pass

    yaml_obj = TestYAMLObject()
    yaml_obj._yaml_node_anchor = 'anchor'
    yaml_obj._yaml_node_tag = 'tag'
    yaml_obj.yaml_set_anchor('anchor')

    class DummyConstructor(AnsibleConstructor):
        def __init__(self):
            super(DummyConstructor, self).__init__()
            self._yaml_objects = {'anchor': yaml_obj}


# Generated at 2022-06-11 09:17:05.865568
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.dataloader import DataLoader
    from six import StringIO
    loader = DataLoader()
    src = StringIO(u"foo: bar\nfoo: baz\n")
    yml_data = loader.load_from_file(src)
    assert yml_data == {u"foo": u"baz"}

# Generated at 2022-06-11 09:17:10.619331
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = '''
      foo: bar
      baz: qux
    '''
    data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(data, dict)
    assert isinstance(list(data.keys())[0], AnsibleUnicode)
    assert isinstance(list(data.values())[0], AnsibleUnicode)

# Generated at 2022-06-11 09:17:22.876048
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import StringIO
    from yaml import safe_load

    # this is a copy of the test_construct_mapping_duplicate_key test from yaml.constructor
    # with the following changes:
    # 1. use AnsibleConstructor instead of SafeConstructor
    # 2. add print 'stdout', 'stderr' to output the sys.stdout and sys.stderr

    node = MappingNode(None, None,
        [('key', 'value')] * 2,
        (None, None), None)
    error = False
    try:
        output = safe_load(StringIO.StringIO(open(__file__).read()))
    except ConstructorError as exc:
        print(exc)
        error = True
    print('stdout', sys.stdout)

# Generated at 2022-06-11 09:17:30.913909
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = MappingNode(u'tag:yaml.org,2002:python/unicode', [(u'!vault', '$ANSIBLE_VAULT;1.1;AES256\r\nmGNhbWVudG8gYWRtaW5pc3RyYWRvciA9IG5pc3RcbmN1c3RvbWVyID0gdmFsaWRhdG9yXG5maXJzdCA9IHN1cGVyZGVzcGlyb1xubGFzdCA9IHN1cGVyZGVzcGlyb1xuZW1haWwgPSBzdXBlcmRlc3Bpcm9AZGVzcGlyby5jb20=\r\n')], None, None, None)
    vault_sec

# Generated at 2022-06-11 09:17:36.802237
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from io import StringIO
    testing_yaml_doc = '''
    # Comment
    - foo
    - bar
    '''

    ansible_constructor = AnsibleConstructor(file_name='foo.yaml')

    foo_doc = list(yaml.load_all(StringIO(testing_yaml_doc), Loader=AnsibleConstructor))

    assert len(foo_doc) == 1
    assert foo_doc[0] == ['foo', 'bar']

# Generated at 2022-06-11 09:17:48.969346
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml

    data = {
        'raw_string': '!unsafe "This is a string"',
        'raw_num': '!unsafe 33',
        'raw_list': '!unsafe ["a", 33, {"a": "b"}]',
        'raw_dict': '!unsafe { "a": "b" }',
    }

    _loader = yaml.Loader(data)
    _loader.anchors = {}
    _loader.add_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)
    _loader.add_implicit_resolver(u'!unsafe', re.compile(u''), None)

    data_loaded = yaml.load(data, Loader=_loader)
    for k in data_loaded:
        assert data_

# Generated at 2022-06-11 09:18:04.035465
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_str = StringIO("""
        a: 1
        b: 2
        c: 3
    """)
    constructor = AnsibleConstructor(file_name='<test_data>')
    mappings = yaml.load(yaml_str, Loader=constructor)
    assert isinstance(mappings, AnsibleMapping)
    assert mappings.ansible_pos == ('<test_data>', 1, 0)
    assert len(mappings) == 3
    assert mappings['a'] == 1
    assert mappings['b'] == 2
    assert mappings['c'] == 3


# Generated at 2022-06-11 09:18:13.475468
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Setup test data
    anchor = 'id-47'
    seq = [1, 2, 3]
    node = yaml.nodes.SequenceNode(tag=u'tag:yaml.org,2002:seq',
                                   value=seq,
                                   start_mark=yaml.error.Mark(u'<memory>', 1, 2, 0, '*'),
                                   end_mark=yaml.error.Mark(u'<memory>', 1, 5, 3, '*'),
                                   flow_style=False)
    node.__setattr__('anchors', {anchor: node})
    # Setup mocks
    ac = AnsibleConstructor()
    ac.construct_sequence = lambda n: n.value

    # Exercise
    seq_obj = ac.construct_yaml_seq(node).__next__

# Generated at 2022-06-11 09:18:20.348189
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # No exception is expected
    vault = VaultLib(secrets=["1234", "5678"])
    vault.update("foobar")

    b_ciphertext = vault.encrypt(b'test')
    b_ciphertext_data = b'!vault |\n' + b_ciphertext.data + b'\n'
    AnsibleConstructor.construct_vault_encrypted_unicode(None,b_ciphertext_data)

# Loader that uses our custom constructor to generate Ansible objects
from yaml.loader import SafeLoader



# Generated at 2022-06-11 09:18:31.453130
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    data = ansible_vault.dump({'message': 'hello world', 'greeting': 'something'})
    vault_secrets = ['unittest_secret']
    d = VaultLib(secrets=vault_secrets)
    encrypted_data = d._encrypt_data(data)
    ciphertext_data = '$ANSIBLE_VAULT;1.1;AES256\n%s\n' % encrypted_data

    constructor = AnsibleConstructor()
    constructor.vault_secrets = vault_secrets
    constructor._vaults['default'] = VaultLib(secrets=vault_secrets)
    ret = constructor.construct_vault_encrypted_unicode('%s\n' % ciphertext_data)

# Generated at 2022-06-11 09:18:35.434737
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ans_cons = AnsibleConstructor('file-location')
    test_yaml = '''\
---
one:
  two: 2
  three: 3
one_again: 3
'''
    ans_cons.construct_yaml_map(test_yaml)

# Generated at 2022-06-11 09:18:36.636733
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert AnsibleConstructor.construct_yaml_map(
        None) is None

# Generated at 2022-06-11 09:18:43.361602
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # create data for constructor
    node = None
    vault_secrets = ['/tmp/foo']

    # create constructor
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=vault_secrets)

    # create and encrypt a piece of data
    b_plaintext = to_bytes('my secret unencrypted data')
    vault = VaultLib(secrets=vault_secrets)
    b_ciphertext = vault.encrypt(b_plaintext)

    # create an AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-11 09:18:57.031462
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class MockNode(object):
        def __init__(self, value):
            self.value = value

    class MockConstructor(AnsibleConstructor):
        def __init__(self):
            self.construct_sequence_return = u'construct_sequence_return value'

        def construct_sequence(self, node):
            return self.construct_sequence_return

    obj = MockConstructor()
    data = MockNode([1, 2, 3])
    result = obj.construct_yaml_seq(data)
    assert(result.ansible_pos == (None, 0, 0))
    assert(result[0] == u'construct_sequence_return value')

    result = obj.construct_yaml_seq(data)
    assert(result.ansible_pos == (None, 0, 0))

# Generated at 2022-06-11 09:19:01.592196
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    data = '---\nfoo: 123'
    c = AnsibleConstructor()
    # We don't care much about the result of load here, but the fact that it
    # does not raise an exception.
    try:
        c.load(data)
    except Exception as e:
        print("load() raised unexpected excpetion: {}".format(e))
        assert False

# Generated at 2022-06-11 09:19:11.500587
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    # test valid encrypted data

# Generated at 2022-06-11 09:19:25.904299
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    a = AnsibleConstructor()
    vault_password = "mypassword"
    vault_secrets = [ vault_password ]
    vault_data = AnsibleVaultEncryptedUnicode.encrypt('mydata', vault_password)
    vault_data_yaml = '!vault |\n          %s' % (vault_data,)
    node = a.compose_document(a.compose_node(None, vault_data_yaml))
    assert isinstance(a.construct_yaml_unsafe(node), AnsibleVaultEncryptedUnicode)
    assert isinstance(a.construct_vault_encrypted_unicode(node), AnsibleVaultEncryptedUnicode)
    a = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-11 09:19:36.464412
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    valid_cases = [
        '[]',
        '[1, 2]',
        '[1, 2, 3]',
        "['a', 'b', 'c']",
        "['a', 'b', 'c', 'd']",
        "['a', 'b', 'c', 'd', 'e']",
        "[1, 2, 'a', 'b']",
        "[1, 2, 'a', 'b', 'c']",
        "[1, 2, 'a', 'b', 'c', 'd']",
    ]


# Generated at 2022-06-11 09:19:39.302098
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    construct_encrypted_unicode = AnsibleConstructor().construct_vault_encrypted_unicode

    assert construct_encrypted_unicode(MappingNode(None, None, True, None, None)) == None

# Generated at 2022-06-11 09:19:48.901905
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.constants as C

    C.DUPLICATE_YAML_DICT_KEY = 'warn'

    import yaml
    yaml_str = """
    first: key1
    second: key2
    third: key3
    second: key4
    """
    data = yaml.load(yaml_str, Loader=yaml.Loader)
    assert data['first'] == 'key1'
    assert data['second'] == 'key4'
    assert data['third'] == 'key3'


    C.DUPLICATE_YAML_DICT_KEY = 'error'

    import yaml
    yaml_str = """
    first: key1
    second: key2
    third: key3
    second: key4
    """

# Generated at 2022-06-11 09:19:56.339833
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    li = list()
    li.append("a")
    li.append("b")
    li.append("c")

    dict = dict()
    dict[1] = 1
    dict["2"] = 2
    dict["3"] = (1, 2, 3)
    dict["4"] = li
    dict["5"] = dict

    # get yaml stream
    stream = yaml.dump(dict)
    yaml_parser = yaml.BaseLoader(stream)
    node = yaml_parser.get_single_node()

    ac = AnsibleConstructor()
    data = ac.construct_yaml_map(node)

    assert data is not None
    assert data['1'] == 1
    assert data['2'] == 2
    assert data['3'] == (1, 2, 3)


# Generated at 2022-06-11 09:20:05.761917
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yml = '''
a:
  b:
    c: string
    d: _undefined
    e: _undefined
    f: _undefined
    g: _undefined
  b1:
    c: string
    d: _undefined
  b2:
    c: string
    d: _undefined
    e: _undefined
  b3:
    c: string
    d: _undefined
    e: _undefined
    f: _undefined
b:
  c: _undefined
  d: _undefined
  e: _undefined
'''

    import re
    import json
    from ansible.parsing.yaml.objects import AnsibleMapping
    import ansible.parsing.yaml.loader as yaml

# Generated at 2022-06-11 09:20:15.055663
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:20:24.722541
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import unittest
    from mock import Mock
    from units.module_utils.yaml_loader import AnsibleLoader

    class TestAnsibleConstructor_construct_yaml_seq(unittest.TestCase):

        def setUp(self):
            self.data = '''
                          - a
                          - b
                          '''

        def test_data_type(self):
            loader = AnsibleLoader(self.data)
            result = loader.get_single_data()
            if sys.version_info[0] >= 3:
                self.assertIsInstance(result, list)
            else:
                self.assertIsInstance(result, AnsibleSequence)

        def test_values(self):
            loader = AnsibleLoader(self.data)
            result = loader.get_single_data

# Generated at 2022-06-11 09:20:33.619493
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    import tempfile

    true = True
    false = False

    # Test the constructor
    data = {'a': 1, 'b': 2, 'c': 3}

    tmp_fd, tmp_filename = tempfile.mkstemp()
    os.write(tmp_fd, b'---\na: 1\nb: 2\nc: 3\n')
    os.close(tmp_fd)

    data_loader = AnsibleLoader(
        data,
        file_name=tmp_filename)
    data_loader.constructor = AnsibleConstructor
    data_loader.add_constructor(u'tag:yaml.org,2002:map', AnsibleConstructor.construct_yaml_map)
    tmp_data = data_loader

# Generated at 2022-06-11 09:20:41.376896
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Note that this "unit test" has a fair amount of overhead.
    file_name = 'sample_vault_file_for_testing_constructor.yml'

# Generated at 2022-06-11 09:21:00.425180
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import shutil
    import tempfile
    import yaml

    # suppress deprecation warning raised by the following call to yaml.safe_load
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    def create_tempfile_yaml_vault_encrypted_document(data):
        tmpdir = tempfile.mkdtemp(prefix='ansible_test_')
        filename = os.path.join(tmpdir, 'testfile_yaml_vault_encrypted.yaml')
        with open(filename, "w") as f:
            f.write(data)
        return filename

    def test_load_vault_yaml_document_from_file(document):
        vault_password = "vaultpass"
        vault_secrets = [vault_password, ]


# Generated at 2022-06-11 09:21:08.836055
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    yaml.undefined = lambda: None
    class TestClass(yaml.YAMLObject):
        yaml_tag = ''
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    assert isinstance(yaml.load("""
        TestClass:
            name: Test_First
            type: Test_Second
            age: Test_Third
    """, Loader=AnsibleConstructor), TestClass)

    assert isinstance(yaml.load("""
        TestClass:
            name: Test_First
            type: Test_Second
            age: Test_Third
            name: Test_Finish
    """, Loader=AnsibleConstructor), TestClass)

# Generated at 2022-06-11 09:21:13.250563
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class_instance = AnsibleConstructor()
    try:
        assert class_instance.construct_yaml_seq('node')
    except NotImplementedError:
        print('NotImplementedError')


# Generated at 2022-06-11 09:21:17.851983
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_instance = AnsibleConstructor()
    assert ansible_instance.construct_yaml_map(MappingNode('MappingNode', [], [])) == {}
    assert ansible_instance.construct_yaml_map(MappingNode('MappingNode', [], [[1, 2]])) == {1: 2}


# Generated at 2022-06-11 09:21:22.460200
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    text = "hi there"
    yaml_data = AnsibleConstructor().construct_yaml_str(yaml.nodes.ScalarNode('tag:yaml.org,2002:str', text))
    assert isinstance(yaml_data, AnsibleUnicode)
    assert yaml_data == text

# Generated at 2022-06-11 09:21:26.392470
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # unit test for AnsibleConstructor.construct_yaml_map
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    assert isinstance(yaml.load(u'test: value', Loader=AnsibleConstructor), AnsibleMapping)



# Generated at 2022-06-11 09:21:35.662946
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Start by creating a dummy node, since we just need a node,
    # and all the attributes of AnsibleConstructor class are protected
    # and can't be accessed from out side
    node = object()
    ac = AnsibleConstructor(vault_secrets=['secret'])

    # Test 1. This is a normal test case.
    ansible_dict = {"k1": "v1", "k2": {"k3": "v3"}}
    node.value = [
        (ac.construct_object(["k1"], deep=True), ac.construct_object("v1", deep=True)),
        (ac.construct_object(["k2"], deep=True), ac.construct_object({"k3": "v3"}, deep=True))
    ]

    ansible_constructor = ac.construct_yaml_map

# Generated at 2022-06-11 09:21:44.235897
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault = VaultLib(secrets=['11223344'])
    ciphertext = vault.encrypt('password')
    plain_input = '!vault |\n' + ciphertext
    plain_input = to_bytes(plain_input)
    plain_node = yaml.load(plain_input)
    plain_text = plain_node.value
    ansible = AnsibleConstructor()
    ansible_node = ansible.construct_vault_encrypted_unicode(plain_node)
    ansible_text = ansible_node.value
    print(ansible_node)
    print(ansible_text)
    assert plain_text == ansible_text

if __name__ == '__main__':
    import yaml
    test_AnsibleConstructor_construct_vault_encrypted_unicode()

# Generated at 2022-06-11 09:21:54.375675
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    import tempfile
    import shutil
    try:
        import ansible.parsing.vault
    except ImportError:
        print("failed=1")
        print("msg=ansible.parsing.vault could not be imported")
        sys.exit(1)
    # end try

    try:
        import ansible.parsing.yaml.loader
    except ImportError:
        print("failed=1")
        print("msg=ansible.parsing.yaml.loader could not be imported")
        sys.exit(1)
    # end try

    try:
        import ansible.parsing.yaml.objects
    except ImportError:
        print("failed=1")

# Generated at 2022-06-11 09:22:03.487439
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_mapping = AnsibleMapping()
    test_mapping['first_key'] = 'first_value'
    test_mapping['second_key'] = 'second_value'
    test_mapping.ansible_pos = ('test', 1, 2)

    test_node = MappingNode(tag='tag:yaml.org,2002:map', value=[])
    test_node.value.append((ScalarNode(tag='tag:yaml.org,2002:str', value='second_key'),
                            ScalarNode(tag='tag:yaml.org,2002:str', value='second_value')))

# Generated at 2022-06-11 09:22:26.451968
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Check that unicode value is returned when ansible-safe string is passed
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str("This is good")



# Generated at 2022-06-11 09:22:28.138065
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # test that AnsibleUnicode is returned
    ansible_constructor = AnsibleConstructor()
    result = ansible_constructor.construct_yaml_str('string')
    assert isinstance(result, AnsibleUnicode)
    assert result == 'string'



# Generated at 2022-06-11 09:22:33.663477
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    '''testing construct_yaml_map method of class AnsibleConstructor'''

    # Arrange
    file_name = 'test.yaml'
    yaml='''\
x: "bar"
y:
- 1
- 2
'''
    # Act:
    test_construct_yaml_map = AnsibleConstructor(file_name).construct_yaml_map(yaml)

    # Assert
    assert test_construct_yaml_map is not None


# Generated at 2022-06-11 09:22:37.711499
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """ test_AnsibleConstructor_construct_yaml_seq() """
    from yaml import nodes
    import warnings
    import sys

    def warn(*args, **kwargs):
        pass

    warnings.warn = warn
    sys.stderr = open(os.devnull, 'w')
    sys.stdout = open(os.devnull, 'w')

    # Test 1

# Generated at 2022-06-11 09:22:50.715204
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import unittest
    import yaml
    from ansible.utils.unsafe_proxy import wrap_var
    class MyClass(object):
        def __init__(self, x=None, y=None):
            self.x = x
            self.y = y
        @property
        def unsafe(self):
            return True
        def __eq__(self, other):
            return (isinstance(other, MyClass)
                    and self.x == other.x
                    and self.y == other.y
                    and self.unsafe == getattr(other, 'unsafe', False))
        def __hash__(self):
            return hash(self.x) ^ hash(self.y)

# Generated at 2022-06-11 09:22:54.045066
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Pass a mapping node and make sure we get a AnsibleMapping back.
    mappingNode = MappingNode(None, None, [])
    mapping = AnsibleConstructor().construct_yaml_map(mappingNode)
    assert isinstance(mapping, AnsibleMapping)

    # Check if a non-mapping node raises the correct exception.
    badNode = MappingNode(None, None, None)
    raised = False
    try:
        AnsibleConstructor().construct_yaml_map(badNode)
    except ConstructorError:
        raised = True
    assert raised



# Generated at 2022-06-11 09:23:00.406483
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    TODO:
        Need to add unit test to test_vars_plugins.py
        - it would run every time and we are testing the constructor here
    """
    import os
    from ansible.compat.tests import unittest
    from ansible.vars.plugins.yaml import get_yaml_loader

    # Get the filename for the test file
    test_filename = os.path.join(os.path.dirname(__file__), 'vars_plugins', 'test_constructor', 'test_yaml_constructor.yaml')


# Generated at 2022-06-11 09:23:11.711209
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    from ansible.parsing.vault import VaultLib

    vault_secrets = [ 'This is a vault password' ]
    vault_decoder = VaultLib(secrets=vault_secrets)
    expected = 'This is a test'
    ciphertext = vault_decoder.encrypt(expected)
    ciphertext = base64.b64encode(ciphertext)

    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    node = object()
    node.start_mark = object()
    node.start_mark.line = 1
    node.start_mark.column = 2
    node.start_mark.name = 'ansible_test'
    node.value = 'ciphertext'

# Generated at 2022-06-11 09:23:21.585805
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            self._ansible_file_name = file_name
            super(TestAnsibleConstructor, self).__init__()
            self._vaults = {}
            self.vault_secrets = vault_secrets or []
            self._vaults['default'] = VaultLib(secrets=self.vault_secrets)


    # Based on the test data provided in vault.py
    import os

# Generated at 2022-06-11 09:23:30.812618
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    from io import StringIO
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.resolver import Resolver

    # Redirect stderr to StringIO object
    stderr = sys.stderr
    sys.stderr = StringIO()

    # Create map node
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

    # Instantiate AnsibleConstructor class
    ansible_constructor = AnsibleConstructor()

    # Add key-value pairs to map node

# Generated at 2022-06-11 09:24:17.149809
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Unit tests for AnsibleConstructor.construct_mapping method
    """
    import os
    import sys
    import unittest
    import yaml

    COUNT_DUP_KEY_WARNING = '"localhost": While constructing a mapping from {0}, line 2, column 1, found a duplicate dict key ({0}). Using last defined value only.'

    if sys.version_info[0] > 2:
        import io
        StringIO = io.StringIO
    else:
        import StringIO
        StringIO = StringIO.StringIO

    class AnsibleConstructorTest(unittest.TestCase):
        def setUp(self):
            self.vault_secrets = [{'vault_password': 'ansible'}]


# Generated at 2022-06-11 09:24:24.012786
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = b"""
        data:
            key1: value1
            key1: value2
            key3:
                - value3_1
                - value3_2
                - value3_3
            key4:
                key4_1: 4_1
                key4_2: 4_2
    """
    load_data = yaml.load(data, Loader=AnsibleConstructor)

    assert load_data["data"] == {u'key1': u'value2', u'key3': [u'value3_1', u'value3_2', u'value3_3'], u'key4': {u'key4_2': u'4_2', u'key4_1': u'4_1'}}

# Generated at 2022-06-11 09:24:26.045678
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    d = AnsibleUnsafeDict({'foo': 'bar'})
    assert AnsibleConstructor(file_name='foo.yml').construct_yaml_unsafe(d) is d

# Generated at 2022-06-11 09:24:32.904598
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    # given
    data = '''
        foo: 1
        bar:
         - 1
         - 2
        baz:
          1: 2
          3: 4
        qux:
         - 1: 2
           3: 4
    '''
    # when
    result = yaml.load(
        data,
        Loader=AnsibleConstructor)
    # then
    assert result == {'bar': [1, 2], 'foo': 1, 'qux': [{1: 2, 3: 4}], 'baz': {1: 2, 3: 4}}

# Generated at 2022-06-11 09:24:37.017118
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
  '''
  Tests that ansible.parsing.yaml.constructor.AnsibleConstructor.construct_vault_encrypted_unicode()
  throws an exception while trying to decrypt an encrypted YAML string without a vault secret
  '''
  ansible_constructor = AnsibleConstructor(None, [])
  with pytest.raises(ConstructorError):
    ansible_constructor.construct_vault_encrypted_unicode(None)

# Generated at 2022-06-11 09:24:46.488967
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:24:54.207253
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-11 09:25:05.431543
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # arrange
    node = []