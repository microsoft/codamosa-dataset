

# Generated at 2022-06-11 09:15:11.999167
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # This only tests the path of code that does not raise an exception.
    ac = AnsibleConstructor()
    node = MappingNode(None, None, None)
    ansible_mapping = ac.construct_yaml_map(node)
    ansible_mapping.send(None)
    assert isinstance(ansible_mapping.send(None), AnsibleMapping)



# Generated at 2022-06-11 09:15:16.503557
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a_constructor = AnsibleConstructor()
    yaml_mapping = MappingNode(u'tag:yaml.org,2002:map', [], [])
    mapping = a_constructor.construct_mapping(yaml_mapping)
    assert isinstance(mapping, AnsibleMapping)

# Generated at 2022-06-11 09:15:26.160502
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    import yaml


# Generated at 2022-06-11 09:15:34.186305
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:15:37.096767
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    ac = AnsibleConstructor()

    a = AnsibleUnsafeText(u"abcdef")
    assert ac.construct_yaml_unsafe(a) is a

# Generated at 2022-06-11 09:15:40.027522
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    # TODO : Implement tests
    # assertEqual(expected, ansible_constructor.construct_mapping(*args, **kwargs))
    pass # or raise SkipTest

# Generated at 2022-06-11 09:15:49.288948
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # This is a test of constructing an AnsibleMapping via the
    # construct_yaml_map method of AnsibleConstructor.  We use
    # a YAML document as an input as follows:
    #
    # a: this is a
    # b: this is b
    # c: this is c
    #
    # We then construct three nodes representing these mappings
    # and pass them to construct_yaml_map.
    #
    # When the method returns, we should end up with a data structure
    # of the form {'a': 'this is a', 'b': 'this is b', 'c': 'this is c'}

    from yaml.nodes import ScalarNode, MappingNode


# Generated at 2022-06-11 09:15:59.569980
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    example_yaml = '''
---
one:
- 1
- 2
- 3
two: 2
three:
  one:
    four: 2
    five: 3
  two: 5
'''

    ansible_map = AnsibleMapping()

    temp_map = AnsibleMapping()
    temp_map[AnsibleUnicode('one')] = [1,2,3]
    temp_map[AnsibleUnicode('two')] = 2

    temp_map2 = AnsibleMapping()

# Generated at 2022-06-11 09:16:09.584774
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # setup vault secrets
    secrets = [ 'secret1', 'secret2' ]
    vault = VaultLib(secrets=secrets)
    # encrypt with first secret
    b_ciphertext = vault.encrypt('pass1')
    # add some whitespace
    ciphertext = u' ' + b_ciphertext + u' '
    # init yaml node
    node = MappingNode(None, [], [], None, None)
    # load constructor
    const = AnsibleConstructor()
    # set vault secrets
    const.vault_secrets = secrets
    # set default vault
    const._vaults['default'] = vault
    # decrypt
    ret = const.construct_vault_encrypted_unicode(node, ciphertext)
    assert ret == u' pass1 '

# Generated at 2022-06-11 09:16:19.478627
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    class TestConstructor(AnsibleConstructor):
        def _node_position_info(self, node):
            return (node.start_mark.name, node.start_mark.line, node.start_mark.column + 1)

    value = '''
    a: 1
    b:
      c: 3
      d: 4
    '''
    yaml_data = TestConstructor()

    data = yaml_data.construct_yaml_map(yaml_data.construct_yaml_str(value))
    assert data.ansible_pos == (None, 1, 1)
    assert isinstance(data, AnsibleMapping)
    assert isinstance(list(data.keys())[0], AnsibleUnicode)
    assert list(data.keys())[0] == u'a'

# Generated at 2022-06-11 09:16:36.344794
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secret = 'ansible'
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = [vault_secret]

    plaintext = AnsibleUnicode('plaintext')
    ciphertext = ansible_constructor._vaults['default'].encrypt(plaintext.encode('utf-8'))

    plaintext_node = {u'tag': u'!vault', u'value': ciphertext}
    plaintext_constructor = ansible_constructor.construct_vault_encrypted_unicode(plaintext_node)
    assert plaintext_constructor.vault_secret == vault_secret
    assert plaintext_constructor.vault.decrypt(plaintext_constructor).decode('utf-8') == plaintext


# Generated at 2022-06-11 09:16:43.034979
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    node.start_mark = object()

    mapping = c.construct_mapping(node)

    assert isinstance(mapping, dict)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping.ansible_pos == (None, None, None)


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-11 09:16:52.912460
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.vars.unsafe_proxy import wrap_var

    data = u"---\n- '{{ ansible_tmpdir }}'\n- '{{ ansible_tmpdir }}'\n"
    result = AnsibleSequence(['/tmp/foo', '/tmp/bar'])
    ret = yaml.load(data, Loader=AnsibleConstructor)

    assert ret == result
    assert wrap_var(ret) != result
    assert wrap_var(ret).vars == result
    assert wrap_var(ret).vars == wrap_var(result)
    assert wrap_var(ret).vars.ansible_pos == ret.ansible

# Generated at 2022-06-11 09:17:03.033051
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    #
    #  Make each element in sequence be a dictionary.
    #
    input_string = '''---
- name: test1
  age: 10
- name: test2
  age: 20
  alias:
    - alias1
    - alias2
'''
    # We check the first element only; the logic is the same for second
    #
    #  The original value of element.ansible_pos is
    #    ("<unicode string>", 1, 1)
    #
    #  The line number of each token is given by the attribute
    #   start_mark.line
    #  The column number of each token is given by the attribute
    #   start_mark.column
    #
    #  When the key 'age' is found, the value of start_mark.line
    #    is 3
   

# Generated at 2022-06-11 09:17:09.107221
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.utils.unsafe_proxy import wrap_var

    for string_to_parse, value_expected in [
        ('{test: !unsafe "test"}', {'test': wrap_var('test')}),
        ('test: !unsafe "test"', {'test': wrap_var('test')}),
        ('test: !unsafe 9', {'test': wrap_var(9)}),
    ]:
        data = yaml.load(string_to_parse, AnsibleConstructor)
        assert data == value_expected

# Generated at 2022-06-11 09:17:19.975275
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """Ensure that the correct warning is emitted when a !unsafe tag is used.
    The following tests verify that we get the correct warning message
    when the !unsafe tag is used and that we correctly wrap the returned
    object in the WrappedUnsafeClass.

    """
    import sys

    def get_mock_stderr(monkeypatch):
        # get a handle on the io stream for stderr
        mock_stderr = io.StringIO()
        # replace sys.stderr with the mock stream
        monkeypatch.setattr(sys, 'stderr', mock_stderr)
        return mock_stderr


# Generated at 2022-06-11 09:17:29.513123
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.plugins.loader import vars_loader
    from ansible.parsing.vault import VaultSecret

    from ansible.parsing.yaml import objects

    class MockVaultSecret(VaultSecret):

        def __init__(self, *args, **kwargs):
            super(MockVaultSecret, self).__init__(*args, **kwargs)

            self._mock_decrypted_data = self.decrypt_data(self.ciphertext_data)

        def decrypt_data(self, data):
            return b'DECRYPTED-DATA'

        @property
        def decrypted_data(self):
            return self._mock_decrypted_data


# Generated at 2022-06-11 09:17:39.020467
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['test_secret_1', 'test_secret_2']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)


# Generated at 2022-06-11 09:17:50.039058
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # The data to test construct_yaml_map with
    data = {}

    # instantiate the class AnsibleConstructor
    ansible_constructor = AnsibleConstructor()

    # call the method construct_yaml_map with data
    result = ansible_constructor.construct_yaml_map(data)

    # assert that the result was an AnsibleMapping
    assert isinstance(result, AnsibleMapping)

    # assert that the result was a callable
    assert callable(result)

    # call the result
    result = result()

    # assert that the result was an AnsibleMapping
    assert isinstance(result, AnsibleMapping)

    # assert that the result was empty
    assert len(result) == 0

# Generated at 2022-06-11 09:17:50.703676
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
  pass

# Generated at 2022-06-11 09:17:56.631558
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    node = constructor.construct_mapping(
        None,
        deep=True
    )

    assert isinstance(node, AnsibleMapping)

# Generated at 2022-06-11 09:18:05.659562
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner

    class DummyChecker(object):
        @staticmethod
        def check_node(node):
            pass

    # Set-up YAML parser
    reader = Reader('')
    reader.check_printable = DummyChecker()
    scanner = Scanner(reader)
    parser = Parser(scanner)
    composer = Composer(parser)

    # Generate node
    node = composer.compose_document()
    node.tag = u'!yaml-seq'
    node.start_mark = 0
    node.end_mark = 0
    node.value = []

    # Invoke method

# Generated at 2022-06-11 09:18:15.678611
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    map_node = MappingNode(node_id='test', value=[
        ('a', 'a'),
        ('b', 'b'),
        ('a', 'aa'),
        ('a', 'aaa'),
        ('b', 'bb'),
        ('a', 'aaaa'),
    ])
    obj = AnsibleConstructor()
    mapping = obj.construct_mapping(map_node, deep=True)

    if C.DUPLICATE_YAML_DICT_KEY == 'error':
        assert mapping == {'a': 'aaaa', 'b': 'bb'}
    elif C.DUPLICATE_YAML_DICT_KEY == 'warn':
        assert mapping == {'a': 'aaaa', 'b': 'bb'}

# Generated at 2022-06-11 09:18:19.965510
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = u'{msg1: "Good morning!", msg2: "How do you do?", msg3: "See you later."}'
    plain_constructor = SafeConstructor(data)
    plain_constructor.construct_yaml_map()
    ansible_constructor = AnsibleConstructor(data)
    ansible_constructor.construct_yaml_map()

# Generated at 2022-06-11 09:18:31.141051
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    from io import StringIO
    from yaml import load, dump

    data = StringIO("""
    - 1
    - 2
    - 3
    """
    )
    yaml_list = load(data, Loader=AnsibleConstructor)
    assert yaml_list._ansible_pos == (None, 2, 0)
    assert yaml_list[0]._ansible_pos == (None, 3, 2)
    assert yaml_list[1]._ansible_pos == (None, 4, 2)
    assert yaml_list[2]._ansible_pos == (None, 5, 2)
    assert dump(yaml_list) == '\n- 1\n- 2\n- 3\n'


# Generated at 2022-06-11 09:18:40.580773
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # set up
    yaml_text = '''
    - name: localhost
      hosts: localhost
      gather_facts: no
      tasks:
        - name: 'Task that loads variables'
          set_fact:
            hostvars_nested: !vars
              var1: value1
              var2: value2

    '''
    yaml_text_bytes = to_bytes(yaml_text, errors='surrogate_or_strict')

    # invoke
    # In Ansible 2.9 and earlier (before yaml.Loader was removed) use yaml_text_bytes here
    yaml_object = yaml.load(yaml_text)

    # verify
    assert len(yaml_object) == 1
    tasks = yaml_object[0].get('tasks')
    assert tasks


# Generated at 2022-06-11 09:18:48.963059
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_seq = {'a': 1, 'b': 'foo', 'c': ['a', 'b']}
    display.debug(u'Testing AnsibleConstructor.construct_yaml_seq:\n%s' % test_seq)
    d = AnsibleConstructor().construct_yaml_seq(test_seq)
    assert(d.ansible_pos == (None, 1, 0))
    assert(len(d) == 3)



# Generated at 2022-06-11 09:19:00.776129
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with a string without a newline character
    assert 'foo' == AnsibleConstructor.construct_yaml_str(None, 'foo')
    # Test with a string with a newline character
    assert 'foo\nbar' == AnsibleConstructor.construct_yaml_str(None, 'foo\nbar')
    # Test with a string with only a newline character
    assert '\n' == AnsibleConstructor.construct_yaml_str(None, '\n')
    # Test with a string with a carriage return character
    assert 'foo\rbar' == AnsibleConstructor.construct_yaml_str(None, 'foo\rbar')
    # Test with a string containing only a carriage return character
    assert '\r' == AnsibleConstructor.construct_yaml_str(None, '\r')



# Generated at 2022-06-11 09:19:07.420151
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    input_yaml = b"""
    a: 1
    b: 2
    c: 3
    """
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_map(yaml.compose(input_yaml))
    assert isinstance(result, dict)
    assert len(result) == 3
    assert result[b'a'] == 1
    assert result[b'b'] == 2
    assert result[b'c'] == 3



# Generated at 2022-06-11 09:19:17.460057
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml

    #!vault |
    #          $ANSIBLE_VAULT;1.1;AES256
    #          3039303165313132313663326266613631393238613166323738376432616333616565396466666361383533
    #          61383530333231386365373330356562353130376363386266343630396635333266633761370a363633653933
    #          3136366231633739656663386563336535336361663435666431313663663232646439316662376162326539
    #          326563346330333865636138613661326536663735326532650a373537393036643734

# Generated at 2022-06-11 09:19:31.816568
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib

    # test conditions
    # ---------------
    vault_secret = '$ANSIBLE_VAULT;1.1;AES256'
    vault_ciphertext = '''$ANSIBLE_VAULT;1.1;AES256\n35373965383730666666666534653235613530343565663763613662373365343039353633383437\n3536633463616335333430343165396437613138383363666337366166656262626266376131633665\n643565303565303964663164306439663861343539\n'''
    vault_plaintext = 'foo'
    vault_

# Generated at 2022-06-11 09:19:39.751380
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    file_name = 'filename_unit_test'
    ac = AnsibleConstructor(file_name=file_name)
    node = MappingNode(tag=u'tag:yaml.org,2002:python/dict', value=[], start_mark=True)
    actual = ac.construct_mapping(node, deep=False)
    assert isinstance(actual, AnsibleMapping)
    assert actual.ansible_pos[0] == file_name
    assert actual.ansible_pos[1] == 1
    assert actual.ansible_pos[2] == 1


# Generated at 2022-06-11 09:19:49.336809
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    from yaml.reader import Reader, ReaderError
    from yaml.scanner import Scanner, ScannerError
    from StringIO import StringIO
    import sys

    # a sequence with a string and a dictionary
    data = "\n- a: b\n- 1"
    stream = StringIO(data)
    reader = Reader(stream)
    try:
        tokens = reader.tokenize()
    except ReaderError as exc:
        sys.exit(exc)
    scanner = Scanner()
    try:
        tokens = scanner.scan_tokens(tokens)
    except ScannerError as exc:
        sys.exit(exc)
    con = AnsibleConstructor(file_name=None)

# Generated at 2022-06-11 09:19:55.557772
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['s3cr3t']
    constructor = AnsibleConstructor(None, vault_secrets=vault_secrets)
    yaml_str = u"!vault |\n\t$ANSIBLE_VAULT;1.1;AES256\n6332353964653733313134383236636539663265333166303738666237636239316236386132343\n63363034646537646236616233396366346566630a62653463393664663932373133383336343531\n34333066303135646665383066353964663563396235316335623436643531613764353665646638\n\n"

# Generated at 2022-06-11 09:20:03.558516
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Construct a yaml map
    yaml_map = u'foo: bar\n' \
               u'abcd: 123\n' \
               u'another: foo\n'
    # Load a mapping
    ret = list(yaml.load_all(to_bytes(yaml_map), Loader=AnsibleConstructor))[0]
    assert(len(ret) == 3)
    # Should warn about duplicate dict keys
    msg = u"While constructing a mapping from <string>, line 1, column 1, found a duplicate dict key (foo). " \
          u"Using last defined value only."
    display.display.warning.assert_called_with(msg)


# Generated at 2022-06-11 09:20:13.069483
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    yaml_data = u'["foo", "bar", "baz"]'

    import yaml

    # Use the constructor we are testing
    AnsibleConstructor = AnsibleConstructor()
    AnsibleConstructor.add_constructor(u'tag:yaml.org,2002:seq',
                                       AnsibleConstructor.construct_yaml_seq)
    data = yaml.load(yaml_data, Loader=yaml.Loader)

    assert isinstance(data, AnsibleSequence)
    assert isinstance(data[0], AnsibleUnicode)
    assert data[0] == "foo"
    assert data[1] == "bar"
    assert data[2] == "baz"
    assert data.ansible_pos == (None, 1, 1)

# Generated at 2022-06-11 09:20:21.375095
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()

    # positive tests
    node1 = MappingNode(u'tag:yaml.org,2002:map', [])
    assert constructor.construct_mapping(node1) == AnsibleMapping()
    assert constructor.construct_mapping(node1).ansible_pos is None
    assert type(constructor.construct_mapping(node1).ansible_pos) is tuple

    node2 = MappingNode(u'tag:yaml.org,2002:map', [])
    node2.start_mark = {'index': 4, 'line': 2, 'column': 3}
    assert constructor.construct_mapping(node2).ansible_pos == ('<unicode string>', 2, 4)
    assert type(constructor.construct_mapping(node2).ansible_pos) is tuple

# Generated at 2022-06-11 09:20:31.796905
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import pytest

    class TestNode(object):
        def __init__(self, value, line, column, name):
            self.start_mark = TestMark(value, line, column, name)

    class TestMark(object):
        def __init__(self, value, line, column, name):
            self.value = value
            self.line = line
            self.column = column
            self.name = name

    # class object

# Generated at 2022-06-11 09:20:39.449515
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.compat.tests import unittest
    from ansible.parsing.yaml.dumper import AnsibleDumper

    import sys
    import yaml

    class TestAnsibleConstructorUnsafe(unittest.TestCase):

        def yaml_to_unsafe(self, yaml_data, expected_data):
            ac = AnsibleConstructor()
            # are we on a version that supports SafeLoader?
            if yaml.__with_libyaml__:
                if yaml.version_info >= (5, 1):
                    ac.add_multi_constructor(None, ac.construct_yaml_unsafe)

            data = yaml.load(yaml_data, Loader=yaml.SafeLoader)
            self.assertEqual(data, expected_data)

            data = y

# Generated at 2022-06-11 09:20:47.037318
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from sys import exc_info
    from traceback import extract_tb
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    ac = AnsibleConstructor()

    # Test that construct_yaml_map constructs an AnsibleMapping
    yaml_map = """
        key: value
    """

    ret = ac.construct_yaml_map(ac.construct_yaml_map(yaml_map))
    instanceof_ret = isinstance(ret, AnsibleBaseYAMLObject)
    if not instanceof_ret:
        tb = extract_tb(exc_info()[2])
        filename, line, func, text = tb[-1]
        print('An error occurred on line {} in statement {}'.format(line, text))

# Generated at 2022-06-11 09:20:57.930850
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert AnsibleConstructor().construct_yaml_str(MappingNode(u'tag:yaml.org,2002:str', u'test', (1, 1), (1, 1))) == u'test'

# Generated at 2022-06-11 09:21:07.204584
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """Tests AnsibleConstructor.construct_yaml_map()"""

    # Fixing random seed, so that tests are deterministic.
    # import random
    # random.seed(1)
    input_value = dict()
    input_value['key1'] = 'value1'
    input_value['key2'] = 'value2'
    # construct_yaml_map() accepts a yaml.nodes.MappingNode and returns a dict
    # yaml.load() returns the object represented by the given node
    # yaml.compose() returns a node representing the object, which is then
    # passed to yaml.load()
    output_value = AnsibleConstructor().construct_yaml_map(yaml.compose(input_value))
    expected_value = dict()

# Generated at 2022-06-11 09:21:15.317392
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.scanner import Scanner

    class MyLoader(AnsibleConstructor, Composer, Parser, Scanner):
        pass
    loader = MyLoader()
    node = loader.compose_document(loader.scan_directives('!seq abc'))
    data = loader.construct_document(node)
    assert isinstance(data, list)
    assert data[0] == 'abc'

# Generated at 2022-06-11 09:21:20.026799
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    from ansible.parsing.yaml.objects import AnsibleMapping

    data = dict(a=1, b=dict(c=3, d=4))

    data = AnsibleMapping(data)

    assert data.a == 1
    assert data.b.c == 3
    assert data.ansible_pos == (u'<unicode str>', 1, 1)


# Generated at 2022-06-11 09:21:29.429574
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    data = AnsibleLoader(None, context).load("""
    foo: bar
    foo: baz
    bar: foo
    foo: 1
    baz:
      - 1
      - 2
      - 3
      - 4
      #
      # And something else
      #
      - 5
      - 6
      - 7
      - 8
    """)

    # Duplicate key foo is present.
    assert data['foo'] == '1'
    # There are 2 spaces before yaml entries "bar" and "foo"
    assert data.ansible_pos['line'] == 1

    # Duplicate key baz is not present, only first entry is available


# Generated at 2022-06-11 09:21:37.607026
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    if sys.version_info >= (3, 0):
        value = 'foo'
        ret = AnsibleUnicode(value)
        value2 = 'bar'
        ret2 = AnsibleUnicode(value2)
        assert value == ret
        assert value != ret2
    else:
        value = u'foo'
        ret = AnsibleUnicode(value)
        value2 = u'bar'
        ret2 = AnsibleUnicode(value2)
        assert value == ret
        assert value != ret2
    # Test that it is unicode:
    assert isinstance(ret, unicode)
    assert not isinstance(ret, str)
    assert isinstance(ret, AnsibleUnicode)

# Generated at 2022-06-11 09:21:46.400524
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from io import StringIO
    import ansible.parsing.yaml.loader
    from ansible.module_utils.six import PY3

    if PY3:
        string_type = str
        data = u'!unsafe "test"'
    else:
        string_type = basestring
        data = u'!unsafe u"test"'

    stream = StringIO(data)
    constructor = AnsibleConstructor(file_name=stream)
    load = getattr(ansible.parsing.yaml.loader, 'FullLoader')
    result = constructor.get_single_data(stream, load)
    assert result == "test"
    assert isinstance(result, string_type) is True



# Generated at 2022-06-11 09:21:53.074651
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    yaml_string = '''\
key: value
key: value'''


# Generated at 2022-06-11 09:21:56.684198
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = AnsibleMapping()
    yield data
    value = self.construct_mapping(node)
    data.update(value)
    data.ansible_pos = self._node_position_info(node)

test_AnsibleConstructor_construct_yaml_map()

# Generated at 2022-06-11 09:22:05.196789
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - one
    - two
    - three
    '''
    try:
        data = AnsibleLoader(data, '<string>').get_single_data()
    except:
        data = None

    assert isinstance(data, AnsibleSequence)
    assert data[0] == AnsibleUnicode('one')
    assert data[1] == AnsibleUnicode('two')
    assert data[2] == AnsibleUnicode('three')



# Generated at 2022-06-11 09:22:25.924388
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None, flow_style=False)
    obj = AnsibleConstructor()
    with pytest.raises(ConstructorError):
        obj.construct_yaml_map(node)

# Generated at 2022-06-11 09:22:29.462003
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    obj = object()
    ansible_constructor = AnsibleConstructor()
    ret = ansible_constructor.construct_yaml_unsafe(obj)
    assert ret == wrap_var(obj)



# Generated at 2022-06-11 09:22:36.584608
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # This is a test.
    # This is the second line of the test.
    # This is the third line of the test.
    # This is the last line of the test.
    data = """
---
# This is a test.
# This is the second line of the test.
# This is the third line of the test.
# This is the last line of the test.
dummy_mapping:
  key1: value1
  key2: value2
  key3: value3
  key4: value4
  key5: value5
"""

    from ansible.parsing.yaml.loader import AnsibleLoader
    results = AnsibleLoader(data).get_single_data()

# Generated at 2022-06-11 09:22:46.319434
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence

    filename = 'vinayagam'
    vault_secrets = ['vinay']

    # checking whether result of construct_yaml_seq is instance of AnsibleSequence
    ans_con = AnsibleConstructor(filename, vault_secrets)

    value = AnsibleSequence()
    # Add value 1
    value.append([1, 2, 3])
    yield_value = value
    result = ans_con.construct_yaml_seq(yield_value)
    assert isinstance(result, AnsibleSequence) is True

# Generated at 2022-06-11 09:22:56.612458
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing import vault

    class DummyVault(vault.VaultLib):
        def __init__(self, *args, **kwargs):
            pass

        def load(self, data):
            return data

    # construction of mapping with duplicate keys
    with vault.VaultManager(vault_secrets=['secret'], vault_classes=[DummyVault]):
        data = '''
        key1: value1
        key2: value2
        key3: value3
        key4: value4
        key4: value5
        '''
        node = yaml.compose(data)
        constructor = AnsibleConstructor(vault_secrets=['secret'])
        result = constructor.construct_yaml_map(node.value[0])
        assert result.ansible_pos

# Generated at 2022-06-11 09:23:06.551334
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """Testing a seq of ints"""
    yaml_code = """
- 1
- 2
- 2
- 5
"""
    constructor_obj = AnsibleConstructor()

    data = yaml.load(yaml_code, Loader=AnsibleLoader)
    # isinstance() function is used to test a object whether it is instance of class.
    # In the following assert statement, it verifies the return value of yaml.load()
    # is an instance of AnsibleSequence. The return value of yaml.load() is a list
    # of ints, and that list of ints is an instance of AnsibleSequence.
    assert isinstance(data, AnsibleSequence)
    assert data[0] == 1
    assert data[1] == 2
    assert data[2] == 2

# Generated at 2022-06-11 09:23:11.710946
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    s = StringIO('''
    - 1
    - 2
    - 3
    ''')

    l = AnsibleLoader(s)
    res = l.get_single_data()

    assert res == [1, 2, 3]

# Generated at 2022-06-11 09:23:20.671788
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from yaml.nodes import SequenceNode
    from io import StringIO
    node = SequenceNode(tag="tag:yaml.org,2002:seq", value=[], start_mark=None, end_mark=None)
    ansibleConstructor = AnsibleConstructor()
    ansibleConstructor.construct_yaml_seq(node)
    assert(isinstance(ansibleConstructor, AnsibleConstructor))
    assert(isinstance(node, SequenceNode))
    assert(isinstance(ansibleConstructor.construct_yaml_seq(node), AnsibleSequence))
    assert(isinstance(StringIO(), StringIO))


# Generated at 2022-06-11 09:23:22.931504
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-11 09:23:29.785496
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['123456']
    ansible_constructor = AnsibleConstructor(None, vault_secrets)
    vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode('ABC!DEF')
    assert(vault_encrypted_unicode.vault is not None)
    assert(vault_encrypted_unicode.data == 'ABC!DEF'.encode('utf-8'))
    assert(vault_encrypted_unicode.vault.decrypt(vault_encrypted_unicode.data) == '123456')


# Generated at 2022-06-11 09:24:05.326377
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    try:
        from ansible.parsing.yaml.objects import AnsibleUnsafeText
    except:
        return

    value = AnsibleUnsafeText(u'test')
    assert value == u'test'
    assert value.__class__ == AnsibleUnsafeText

# Generated at 2022-06-11 09:24:10.200187
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    imported_module = __import__('ansible.parsing.yaml.loader', fromlist=['AnsibleConstructor'])
    constructor = imported_module.AnsibleConstructor(file_name='xyz.yaml')
    #mock_node = <yaml.nodes.MappingNode object at 0x7f7a1cb72e90>
    with patch.object(imported_module, 'MappingNode') as mock_MappingNode:
        mock_MappingNode.return_value = mock_MappingNode
        #mock_mapping = <ansible.parsing.yaml.objects.AnsibleMapping object at 0x7f7a1cb72ed0>

# Generated at 2022-06-11 09:24:18.349285
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Unit test to verify that the '!unsafe' tag is used properly by class AnsibleConstructor
    result_dict = {"name": "test", "test_list": [3, 4, 5],
                   "test_dict": {"a": "b", "c": "d"},
                   "test_var": "ansible_variable",
                   "test_unsafe": "!unsafe\n&"}
    result_dict_valid = {"name": "test", "test_list": [3, 4, 5],
                         "test_dict": {"a": "b", "c": "d"},
                         "test_var": "ansible_variable",
                         "test_unsafe": "&"}
    import yaml
    result = yaml.dump(result_dict, default_flow_style=False, Dumper=AnsibleDumper)

# Generated at 2022-06-11 09:24:22.138869
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert AnsibleConstructor().construct_mapping(
        MappingNode('test_mapping', [
            (ScalarNode('test_key', 'test_key'), ScalarNode('test_value', 'test_value'))
        ], anchor=None, tag=u'tag:yaml.org,2002:map')
    ) == {'test_key': 'test_value'}

# Generated at 2022-06-11 09:24:31.064656
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Make sure we are testing the class
    myConstructor = AnsibleConstructor()

    # Get the test objects
    testObjects = getTestObjects()

    # test_construct_mapping_duplicate_keys_same_line
    # Test mapping with duplicate keys on the same line
    map = myConstructor.construct_mapping(testObjects['duplicate_keys_same_line'], deep=False)
    assert map is not None
    assert map['key1'] == 'value2'
    assert map.ansible_pos == (None, 1, 0)

    # test_construct_mapping_duplicate_keys_multiple_lines
    # Test mapping with duplicate keys on the same line

# Generated at 2022-06-11 09:24:37.968906
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    class _SafeConstructorMock(SafeConstructor):
        def construct_scalar(self, node):
            return node.value

    safe_constructor = _SafeConstructorMock()

    constructor = AnsibleConstructor()

    # -- test basic case

    node = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', u'test', yaml.nodes.MappingNode(), 0, 0, None)
    construct_value = constructor.construct_yaml_str(node)

    assert isinstance(construct_value, AnsibleUnicode)
    safe_construct_value = safe_constructor.construct_yaml_str(node)

    assert construct_value == safe_construct_value

    # -- test that ansible_pos is added


# Generated at 2022-06-11 09:24:44.200886
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Create a YAML mapping node
    node = MappingNode(None, None, True, None)
    node.value = [[1, 2], [3, 4]]

    # Create a AnsibleConstructor object
    constructor = AnsibleConstructor()

    # Call the method
    result = constructor.construct_mapping(node)

    # Check the result
    assert result == {1: 2, 3: 4}

# Generated at 2022-06-11 09:24:51.988050
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test the constructor when given a tag:yaml.org,2002:map
    # This should always return a dict type object with
    # the position information included
    test_input = dict(a=1, b=2)
    test_input_node = yaml.compose(test_input)
    test_input_node.tag = u'tag:yaml.org,2002:map'
    ac = AnsibleConstructor()
    test_output = ac.construct_yaml_map(test_input_node)
    assert type(test_output) == dict
    assert test_output['a'] == 1
    assert test_output['b'] == 2
    assert test_output.ansible_pos == ('<unicode string>', 1, 0)

    # Test when given a tag:yaml.org,2002:python/dict

# Generated at 2022-06-11 09:25:00.789455
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from yaml.nodes import ScalarNode
    from yaml.nodes import MappingNode
    from yaml.nodes import SequenceNode
    import types
    import mock

    def mock_get_value(*args, **kwargs):
        return True

    temp = AnsibleConstructor
    with mock.patch.object(temp, 'get_value', mock_get_value) as mock_get_value:
        ac = AnsibleConstructor()

        # Case 1: value_node is not instance of AnsibleBaseYAMLObject
        key_node = ScalarNode("test_key")
        value_node = ScalarNode("test_value")

# Generated at 2022-06-11 09:25:10.743736
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    c = AnsibleConstructor()
    node = object()
    node.start_mark = object()
    node.start_mark.column = 0
    node.start_mark.line = 0
    node.start_mark.name = 'test_file'
    c.vault_secrets = []