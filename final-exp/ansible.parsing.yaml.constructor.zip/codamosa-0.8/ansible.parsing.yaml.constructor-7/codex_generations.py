

# Generated at 2022-06-11 09:15:14.570477
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class FooYAMLObject(AnsibleBaseYAMLObject):
        pass
    class BarYAMLObject(AnsibleBaseYAMLObject):
        pass
    class BazYAMLObject(AnsibleBaseYAMLObject):
        pass
    class FooBarYAMLObject(AnsibleBaseYAMLObject):
        pass
    class FooBarBazYAMLObject(AnsibleBaseYAMLObject):
        pass

    import sys
    import yaml
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    loader = yaml.Loader


# Generated at 2022-06-11 09:15:19.352916
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class MyAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            return self.construct_scalar(node)
    c = MyAnsibleConstructor()
    s = c.construct_yaml_str('')
    assert s == None

# Generated at 2022-06-11 09:15:28.779340
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():  # pylint: disable=too-many-statements
    # pylint: disable=no-member
    # pylint: disable=attribute-defined-outside-init

    import ansible.parsing.yaml.objects
    import copy
    import sys

    from collections import MutableMapping

    import yaml

    # Constructor of this testing class will be used by Loader
    class YamlLoader(yaml.SafeLoader):

        def __init__(self, file_name = None, vault_secrets = None):

            # Call constructor of parent class
            yaml.SafeLoader.__init__(self)

            # Set up dictionaries for YAML tags
            self.add_constructor(u'tag:yaml.org,2002:map', YamlLoader.construct_yaml_map)
            self.add

# Generated at 2022-06-11 09:15:39.304535
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ac = AnsibleConstructor()

    # Test the base case with nothing fancy
    str = """
---
a: 1
b: 2
c: 3
"""
    expected = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    results = AnsibleModule._load_params(str)
    assert results == expected

    # Test complicated case with submaps
    str = """
---
a: 1
b:
    c: 1
    d: 2
e:
    1: val1
    2: val2
"""

# Generated at 2022-06-11 09:15:47.049749
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from yaml import load, dump
    yaml_str = u'foo: bar\n'

    # load the data
    data = load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)

    # change the data
    data[u'foo'] = u'baz'
    assert data[u'foo'] is u'baz'

    # dump the data
    re_data = dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert re_data == u'foo: baz\n'



# Generated at 2022-06-11 09:15:57.960775
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.vault import VaultLib

    # Test 'ignore' with construct_mapping.
    # construct_mapping line number is 36.
    # construct_object line number is 47.
    # construct_scalar line number is 54.
    # clone line number is 57.
    # construct_yaml_str line number is 64.
    config_data = """
        - hosts: localhost
          remote_user: root
          gather_facts: no
          tasks:
          - shell: "echo Hello"
            register: tmp
          - shell: "echo {{item}}"
            with_items:
              - "{{tmp.stdout}}"
              - "{{tmp.stdout}}"
            register: tmp2
    """
    config_data = to_bytes(config_data)
    vault_password

# Generated at 2022-06-11 09:16:08.305351
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    # dummy vaul secret as constructor needs it
    vault_secret = {"key": "value"}
    ac = AnsibleConstructor("", vault_secrets=[vault_secret])
    # dummy test data, should be overwritten by test data
    data = yaml.load('''
        ---
        foo: bar
        baz:
          - [abc]
          - [def]
          - [ghi]
          - [xyz]
          - 1
          - 2
        test: 3
        test2: 4
    ''', Loader=yaml.Loader)
    assert data == {"foo": "bar", "baz": [['abc'], ['def'], ['ghi'], ['xyz'], 1, 2], "test": 3, "test2": 4}

    # read in test data


# Generated at 2022-06-11 09:16:10.815177
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor()
    assert isinstance(a.construct_yaml_map(MappingNode()), type(AnsibleMapping()))


# Generated at 2022-06-11 09:16:20.340223
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib

    value = u"$ANSIBLE_VAULT;1.1;AES256\n32653439643033353136613231663763623464383137323431616439653533643362396164313733\nd9b9e6723e1ff73f6e63d6e8cdca8f11aa2e2e32acd63437f277d66e6f5c916b\n5e5d2f5b6e5e70faf1d9a9125c5ffae1f88a98c8a80a593652d48e361a07acbc\n"
    node = yaml.compose(value)
    node.start_

# Generated at 2022-06-11 09:16:23.755551
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yamlstr = ''' - a: 1 \n   b: 2 \n - 'key': 'value' '''

    obj = yaml.load(yamlstr, AnsibleConstructor)
    assert obj[1]['key'] == 'value'

# Generated at 2022-06-11 09:16:40.793030
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import YAML
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var

    vault_secrets = [b'foo']
    vault = VaultLib(secrets=vault_secrets)
    ciphertext = vault.encrypt('foobar')
    b_yaml = wrap_var(ciphertext).to_bytes()
    yaml_obj = YAML(typ='safe').load(b_yaml)
    assert isinstance(yaml_obj, AnsibleVaultEncryptedUnicode)

    b_yaml = wrap_var(ciphertext).to_bytes().replace

# Generated at 2022-06-11 09:16:42.622924
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    c = AnsibleConstructor()
    result = c.construct_yaml_map(dict())
    assert isinstance(result, dict)



# Generated at 2022-06-11 09:16:48.150990
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_dict = {'key1': 'value1', 'key2': 'value2'}

    assert isinstance(yaml_dict, dict)
    ac = AnsibleConstructor()
    assert isinstance(ac, AnsibleConstructor)

    ansible_map = ac.construct_yaml_map(yaml_dict)
    assert isinstance(ansible_map, AnsibleMapping)
    assert ansible_map.ansible_pos is None



# Generated at 2022-06-11 09:16:56.771023
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    node = '!unsafe "something_bad"'
    ansible_constructor = AnsibleConstructor()
    import ansible.parsing.yaml.loader
    unsafe_obj = ansible_constructor.construct_yaml_unsafe(
        ansible.parsing.yaml.loader.AnsibleLoader(node,
                                                  ansible_constructor=ansible_constructor).get_single_data())

    assert unsafe_obj == 'something_bad'
    assert isinstance(unsafe_obj, ansible.parsing.unsafe_proxy.AnsibleUnsafeText)

# This test is for the class constructor

# Generated at 2022-06-11 09:17:06.221848
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    # given
    file_content = '''
list:
- foo
- bar
- baz
dict:
  foo: bar
  baz: qux
dict2:
  foo: bar
  foo: baz
string: "abc"
'''
    # when
    data = yaml.load(file_content, Loader=AnsibleConstructor)
    # then
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos[0] is None
    assert data.ansible_pos[1] == 1
    assert data.ansible_pos[2] == 1
    assert isinstance(data['list'], list)

# Generated at 2022-06-11 09:17:12.796988
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # In the following, we try to construct a yaml.nodes.SequenceNode object
    # manually, since it is impossible to load a .yaml file in a unit test.
    from yaml.nodes import SequenceNode
    from yaml.composer import Composer

    # The following are copied from the source code of PyYAML 5.1. This is
    # unfortunate, but I could not find a better way.
    class Constructor(SafeConstructor):
        pass

    class Parser(object):
        def __init__(self, stream):
            self.stream = stream
            self.loader = Composer(Constructor)
            self._next_event()

        def _next_event(self):
            self.event = self.stream.read()

    # The following are also copied from the source code of PyYAML

# Generated at 2022-06-11 09:17:24.896764
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Note: We don't need to test every type of node for this method, because
    # SafeConstructor already tests those in its unit tests.  We just need to
    # make sure that our overridden !unsafe tag is handled the way we want it
    # to.
    #
    # The below checks that !unsafe tags cause variables to be marked as unsafe
    # (naturally)
    #
    # See: http://stackoverflow.com/a/9652397/89334

    from ansible.parsing.yaml import objects
    import random

    # First check that the basics work (overriding the !unsafe tag to make sure
    # that we wrap the variable as an AnsibleUnsafe variable)
    simple_strings = ['foo', 'bar', 'baz', 'foobar', 'foo-bar']

# Generated at 2022-06-11 09:17:32.027909
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['123']

    # Generate two different encrypted strings based on two different vault secrets
    encrypted_string_vault1 = AnsibleConstructor(vault_secrets=vault_secrets).construct_vault_encrypted_unicode(u'$ANSIBLE_VAULT;1.1;AES256;vaultname\n123456\n')
    encrypted_string_vault2 = AnsibleConstructor(vault_secrets=['456']).construct_vault_encrypted_unicode(u'$ANSIBLE_VAULT;1.1;AES256;vaultname\n123456\n')
    # If the encrypted string is constructed with the same vault secret, the decrypted string should be the same
    assert encrypted_string_vault1.decrypt() == encrypted_string_vault1.decrypt()

# Generated at 2022-06-11 09:17:41.272945
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = """\
---
  ? key1
  : 1
  ? key2
  : 2
"""
    yaml = YAML(typ='safe')
    yaml.constructor.add_constructor(
        u'tag:yaml.org,2002:map',
        yaml.constructor.construct_yaml_map)
    ansible_map = yaml.load(data)
    assert isinstance(ansible_map, dict)
    assert len(ansible_map) == 2
    for key, value in ansible_map.items():
        assert key[0] in ('key1', 'key2')
        assert value in (1, 2)


# Generated at 2022-06-11 09:17:52.172890
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import AnsibleLoader
    default_loader = AnsibleLoader
    def test_constructor(loader, suffix, node):
        """
        The test constructor used in testing the vault functionality. It will
        decrypt any vault-encrypted string and return to AnsibleLoader.
        """
        if suffix is not None:
            return loader.construct_yaml_str(node)
        return AnsibleConstructor.construct_vault_encrypted_unicode(loader, node)

    vault_loader = AnsibleLoader(None, default_constructor=test_constructor, secret='test')

# Generated at 2022-06-11 09:18:07.206813
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    from yaml.nodes import ScalarNode

    # Test whether wrapped objects are returned as expected.
    exp = datetime.datetime(2000, 1, 2, 3, 4, 5)
    act = AnsibleConstructor().construct_yaml_unsafe(ScalarNode(u'!unsafe', exp, 1, 2, 3, 4, 5))
    assert act == exp
    assert act.__class__ == wrap_var(exp).__class__

    # Test whether wrapped objects are returned as expected.
    exp = datetime.date(2000, 1, 2)
    act = AnsibleConstructor().construct_yaml_unsafe(ScalarNode(u'!unsafe', exp, 1, 2, 3, 4, 5))
    assert act == exp
    assert act.__class__ == wrap_var

# Generated at 2022-06-11 09:18:12.029151
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test default case
    yaml_str = '''
key1: value1
key2: value2
'''
    yaml_ansible_constructor = AnsibleConstructor('<string>')
    yaml_data = yaml.load(yaml_str, Loader=yaml.SafeLoader)
    assert yaml_data['key1'] == 'value1'


# Generated at 2022-06-11 09:18:22.526901
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    yaml_str = '''
#!vault |
$ANSIBLE_VAULT;1.1;AES256
3039356665363866386662353161393233353262646262386163343232386565303937313266623264
66643865333934316364643039383533623063630a3762383764636334316662346161396634376539
6236646364303635333430666232376163373930663534646632333761363165613332313433626135
653633340a35376363396538626633626632316662333733613761360a
    '''


# Generated at 2022-06-11 09:18:32.575131
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # If the line '---' is not the first line of the test file,
    # 'ansible_pos' will not be (1, 1, 1) which is the expected value
    # in the test.

    # Test the case that input is unicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    test_yaml = '''
    ---
    a: !vault |
        $ANSIBLE_VAULT;1.1;AES256
        30626263366130326165666465356530326362323533653336636138313431326264323137343666
        66303564666132626330653834383331323431613631316563656638396361613065356630666137
        3936000000
    '''

# Generated at 2022-06-11 09:18:41.640409
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    base = SafeConstructor
    #  Basic case
    node = object()
    node.start_mark = object()
    node.start_mark.line = 1
    node.start_mark.column = 2
    node.start_mark.name = 'name'
    node.end_mark = object()
    node.end_mark.line = 2
    node.end_mark.column = 3
    node.end_mark.name = 'name'
    node.tag = u'tag:yaml.org,2002:str'
    x = AnsibleConstructor(file_name='name')
    x.construct_scalar = lambda node: 'abc'
    y = x.construct_yaml_str(node)
    assert y.start_mark.line == 1
    assert y.start_mark.column == 2
   

# Generated at 2022-06-11 09:18:55.490632
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Given a constructed node:
    node = MappingNode(None, None, True, [
        (ScalarNode(None, None, None, None, False, '!yaml!unicode!string', False), None),
        (ScalarNode(None, None, None, None, False, '!yaml!unicode!string', False), None),
    ])
    # When constructing a mapping from the node:
    obj = AnsibleConstructor().construct_mapping(node, True)
    # Then the result should be a mapping:
    assert isinstance(obj, AnsibleMapping)

    # When constructing a mapping from a node with 2 different keys:

# Generated at 2022-06-11 09:19:03.653312
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var_recursive
    from ansible.parsing.vault import VaultEditor


# Generated at 2022-06-11 09:19:13.712468
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    example_dict_0 = dict()
    example_dict_1 = dict()
    example_dict_1["key_0"] = example_dict_0
    example_dict_2 = dict()
    example_dict_3 = dict()
    example_dict_3["key_1"] = example_dict_2
    example_list = [example_dict_1, example_dict_3]
    example_dict_1["key_1"] = example_list
    example_dict_3["key_0"] = example_list

    example_seq = AnsibleConstructor().construct_yaml_seq(MappingNode(u'tag:yaml.org,2002:map', [], [], False))

    example_seq.append(example_dict_1)
    example_seq.append(example_dict_3)


# Generated at 2022-06-11 09:19:22.892645
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:19:33.990947
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    node = {}

# Generated at 2022-06-11 09:19:49.491757
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = '''
        name: "test_string"
    '''
    loader = AnsibleLoader(StringIO(data), file_name="test_file")
    ansible_map = AnsibleMapping()
    ansible_map.ansible_pos = ('test_file', 1, 1)
    assert loader.get_single_data() == ansible_map



# Generated at 2022-06-11 09:19:54.950346
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()
    node = object()
    node.start_mark = object()
    node.start_mark.line = 2
    node.start_mark.column = 1
    node.start_mark.name = 'testfile'
    node.end_mark = object()
    node.end_mark.line = 2
    node.end_mark.column = 3
    node.end_mark.name = 'testfile'
    s = constructor.construct_yaml_str(node)
    assert isinstance(s, AnsibleUnicode)
    assert s.ansible_pos == (u'testfile', 2, 1)


# Generated at 2022-06-11 09:19:58.982415
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    yaml_string = u'''\
key: "value"
'''
    yaml_object = AnsibleConstructor().get_single_data(StringIO(yaml_string))
    assert isinstance(yaml_object[u'key'], AnsibleUnicode)



# Generated at 2022-06-11 09:20:05.941162
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    #Example yaml
    yaml = '''
        a: 1
        b: 2
        c: 3
        a: 4
    '''

    # expected result
    # AnsibleMapping([("a", 4), ("b", 2), ("c", 3)])
    default_constructor = getattr(yaml, 'BaseConstructor', None)
    yaml.BaseConstructor = AnsibleConstructor
    x = yaml.load(yaml)
    yaml.BaseConstructor = default_constructor
    assert x == AnsibleMapping([("a", 4), ("b", 2), ("c", 3)])

# Generated at 2022-06-11 09:20:08.997737
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    # Test constructor
    ansible_constructor = AnsibleConstructor()

    # Test context and assertions
    value = ansible_constructor.construct_yaml_unsafe(MappingNode())
    assert value is None

# Generated at 2022-06-11 09:20:12.921551
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    nd = AnsibleConstructor.construct_yaml_map(None)
    call_count, instance, args, kwargs = AnsibleConstructor.construct_mapping.call_args
    assert instance == nd
    assert args == tuple()
    assert kwargs == {'deep': False}


# Generated at 2022-06-11 09:20:18.014451
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Data to be tested
    testData = {"attr": {"key": "value"}}

    # Construct the ansible constructor
    ac = AnsibleConstructor()

    # Construct the yaml mapping node
    yaml_tag = u'tag:yaml.org,2002:python/dict'
    node = MappingNode(yaml_tag, None, None, None)

    output = ac.construct_yaml_unsafe(node)
    assert output == testData

# Generated at 2022-06-11 09:20:26.734932
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # This test requires a local file assuming a vault password of 'vault'
    testfile = './test/constructor_vault_encrypted_unicode.yml'
    with open(testfile) as fp:
        test_data = yaml.load(fp, Loader=AnsibleConstructor)
        result = test_data[u'test_key'].data
        expected_result = b"test_string\n"
        assert result == expected_result
        assert result.decode('utf-8') == "test_string\n"

# Generated at 2022-06-11 09:20:35.069392
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:20:37.485265
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_mapping(node)
    return True

# Generated at 2022-06-11 09:20:56.191943
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert AnsibleConstructor.construct_yaml_seq('node') == 'node'


# Generated at 2022-06-11 09:21:03.100027
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import objects
    example_yaml = '''\
---
- !unsafe "{{ foo }}"
'''
    expected = [objects.AnsibleUnsafeText('{{ foo }}')]
    loader = AnsibleConstructor()
    result = list(loader.construct_yaml_unsafe(loader.construct_document(example_yaml)))
    assert result == expected


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-11 09:21:13.582664
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = '''
            a: 1
            b: 2
            c: 3
        '''
    yaml_res = AnsibleConstructor().construct_mapping(
        AnsibleConstructor().construct_yaml_map(
            AnsibleConstructor().construct_yaml_unsafe(
                AnsibleConstructor().construct_document(yaml_str))))
    assert yaml_res.ansible_pos == ('<unicode>', 1, 0)
    assert yaml_res['a'].ansible_pos == ('<unicode>', 2, 4)
    assert yaml_res['b'].ansible_pos == ('<unicode>', 3, 4)
    assert yaml_res['c'].ansible_pos == ('<unicode>', 4, 4)

# Generated at 2022-06-11 09:21:22.731592
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [ 'secret1', 'secret2' ]
    ac = AnsibleConstructor(vault_secrets=vault_secrets)

    # test when secrets is None
    ac._vaults['default'].secrets = None
    value = 'AES256:1:Oc7rR8Pzf+BwNxjKl4/4XQ=='
    node = 'tag:yaml.org,2002:str'
    result = ac.construct_vault_encrypted_unicode(value, node)
    assert result[0] == 0  # The constructor function raises an exception which we catch in the wrapper. See tests/units/test_plugins/test_lookup.py for an example.

    # secrets is valid
    ac._vaults['default'].secrets = vault_secrets
    value

# Generated at 2022-06-11 09:21:32.224675
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    yaml_data = u'{a: {b: {c: [10, 13, 33]}}}'
    yaml_dict = yaml.load(yaml_data)
    assert yaml_dict.a.b.c[0] == 10
    assert yaml_dict.a.ansible_pos == ('<unicode string>', 1, 0)
    assert type(yaml_dict.a.b.c) == AnsibleSequence
    assert yaml_dict.a.b.c.ansible_pos == ('<unicode string>', 1, 12)
    assert type(yaml_dict.a) == AnsibleMapping
    assert yaml_dict.a.b.ansible_pos == ('<unicode string>', 1, 7)


# Generated at 2022-06-11 09:21:36.039624
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    self = AnsibleConstructor() # For testing without subclassing, you have to create an instance
    node = MappingNode(tag='tag:yaml.org,2002:str', value='abc')
    result = self.construct_vault_encrypted_unicode(node)
    assert result == 'abc'

# Generated at 2022-06-11 09:21:43.806479
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    test_map = MappingNode(tag=u'tag:yaml.org,2002:map', value=[
        (AnsibleUnicode(u'key_1'), AnsibleUnicode(u'value_1')),
        (AnsibleUnicode(u'key_2'), AnsibleUnicode(u'value_2'))
    ])

    ansible_map = ansible_constructor.construct_mapping(test_map)

    assert isinstance(ansible_map, AnsibleMapping)
    assert ansible_map['key_1'] == u'value_1'
    assert ansible_map['key_2'] == u'value_2'

# Generated at 2022-06-11 09:21:53.924942
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class MockConstructor(AnsibleConstructor):

        # noinspection PyMethodOverriding
        def construct_yaml_str(self, node):
            return node.value

    dumper = AnsibleDumper()
    constructor = MockConstructor()


# Generated at 2022-06-11 09:22:03.173244
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.module_utils.common._collections_compat import Mapping

    from io import BytesIO
    from yaml import load, dump

    secret_key = 'mysecret'
    vault_password = 'MyVaultPassword'
    secrets = [vault_password]


# Generated at 2022-06-11 09:22:08.551517
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    # Some test data
    data1 = """
    - 'Ansible'
    - 'AWX'
    - 'Tower'
    """

    yaml1 = """
    - 'Ansible'
    - 'AWX'
    - 'Tower'
    """

    # Parse the test data
    obj1 = yaml.load(data1, AnsibleConstructor)

    # Ensure that the array does not contain the dict
    assert obj1 == yaml.load(yaml1)

# Generated at 2022-06-11 09:22:54.435320
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os
    import sys
    import unittest
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Back up the datastructures in CONSTRUCTOR_NODES, so we can restore them later
    old_constructor_nodes = dict(AnsibleConstructor.CONSTRUCTOR_NODES)

    # Copy the constructor nodes from the base YAML constructor so that we can make our own dict
    # object which does not call super().construct_yaml_map(), which will call the AnsibleConstructor.
    class ConstructMapping(yaml.constructor.Constructor):
        __slots__ = ()

        def construct_yaml_map(self, node):
            data = yaml.nodes.MappingNode(None, None)
            yield data
            value = self.construct_

# Generated at 2022-06-11 09:23:01.169219
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib


    vault_password = "vault test"
    vault_secrets = [vault_password]
    # Initialize VaultLib object with vault_secret
    vault = VaultLib(secrets=vault_secrets)

    # Variable value to be encrypted
    value = "mysecret"
    # Encrypt the variable value
    b_ciphertext = vault.encrypt(value)

    # The first line of the output from VaultLib.encrypt
    tag = "!vault |"
    # The YAML string to be parsed
    yaml_str = "{0}\n  {1}".format(tag, b_ciphertext)
    # Load the YAML string
    yaml

# Generated at 2022-06-11 09:23:12.491153
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ac = AnsibleConstructor()

    class TestNode:
        def __init__(self, id):
            self.id = id

    class TestMappingNode(TestNode):
        def __init__(self, id):
            TestNode.__init__(self, id)

        def __getitem__(self, name):
            if name == 'data':
                return {'foo': 'bar'}

    class TestSequenceNode(TestNode):
        def __init__(self, id):
            TestNode.__init__(self, id)

        def __getitem__(self, name):
            if name == 'data':
                return ['foo', {'bar': 'baz'}]

    class TestStringNode(TestNode):
        def __init__(self, id, data):
            TestNode.__init

# Generated at 2022-06-11 09:23:16.459684
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from sys import version_info
    from io import StringIO

    if version_info[0] == 2:
        from ansible.compat.tests import unittest
        from ansible.compat.tests.mock import patch
    else:
        import unittest
        from unittest.mock import patch

    import yaml

    class TestAnsibleConstructor_construct_yaml_str(unittest.TestCase):

        def setUp(self):
            self.test_data = {
                'test1': 'test1',
                'test2': 'test2'
            }

        def tearDown(self):
            pass


# Generated at 2022-06-11 09:23:22.797092
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    node = MappingNode(
        tag='tag:yaml.org,2002:map',
        value=[],
        start_mark=None,
        end_mark=None
    )

    data = AnsibleMapping()
    data.update({u'a': AnsibleMapping()})

    test_constructor = AnsibleConstructor()
    data_wrapped_var = test_constructor.construct_yaml_unsafe(node)
    data_wrapped_var.a['foo'] = 'bar'

    assert data_wrapped_var.a == AnsibleMapping({u'foo': u'bar'})

# Generated at 2022-06-11 09:23:25.769924
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = """
foo: bar
bar: baz
"""
    yaml_obj = {'foo': 'bar', 'bar': 'baz'}
    AnsibleConstructor._test(yaml_str, yaml_obj)

# Generated at 2022-06-11 09:23:34.565585
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os
    import tempfile
    import yaml

    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file_name = test_file.name
    test_data = u"""
foo:
  bar: 1
quot: "{{ variable }}"
foo2:
  bar: 1
  bar: 1
  bar: 1
  bar: 1
  bar: 1
  bar: 1
  bar: 1
  bar: 1
  bar: 1
  bar: 1
"""
    test_file.write(test_data.encode('utf-8'))
    test_file.close()

    # Set test to 'ignore' so we don't actually throw the error.  This test
    # is primarily to ensure the warning or error is thrown.
    C.DUPLICATE_Y

# Generated at 2022-06-11 09:23:40.279157
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = 'test_AnsibleConstructor_construct_yaml_str'
    for Loader in [yaml.SafeLoader, yaml.Loader, yaml.CLoader]:
        yaml_obj = yaml.load(yaml_str, Loader=Loader)
        assert isinstance(yaml_obj, AnsibleUnicode)
        assert yaml_obj == yaml_str

# Generated at 2022-06-11 09:23:46.053518
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    constructor = AnsibleConstructor()

    # Test with Unicode
    data_unicode = u'Test'
    node = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', data_unicode)
    result = constructor.construct_yaml_str(node)

    assert isinstance(result, AnsibleUnicode)
    assert isinstance(result, AnsibleUnicode)
    assert result.ansible_pos == (None, None, None)



# Generated at 2022-06-11 09:23:58.907666
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from shutil import copyfileobj
    # test empty list
    s = to_bytes("")
    stream = StringIO(s.decode("utf-8"))
    l = AnsibleLoader(stream, None)
    yaml_data = l.get_single_data()
    d = AnsibleDumper()
    stream1 = StringIO()
    copyfileobj(stream, stream1)
    assert yaml_data == []
    assert stream1.getvalue() == ''
    # test empty yaml
    s = to_bytes("---\n---\n")
    stream = StringIO(s.decode("utf-8"))
   