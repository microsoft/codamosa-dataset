

# Generated at 2022-06-11 09:15:16.089466
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = """---
- one: 1
- two: 2
- three: 3
"""
    # construct yaml_data
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(yaml_data)
    # Because this is a MappingNode, we expect a dict with the first key of 'one'
    assert isinstance(ansible_constructor.construct_yaml_map(yaml_data), dict)
    assert 'one' in ansible_constructor.construct_yaml_map(yaml_data)

    # construct yaml_data
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq(yaml_data)
    # Because this is a SequenceNode, we expect a list with the first value

# Generated at 2022-06-11 09:15:25.813744
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = {
        'color': 'red',
        'color': 'yellow'
    }

    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=None)

    for k in data:
        v = data[k]
        key_node = SafeConstructor.construct_scalar(node, tag=u'tag:yaml.org,2002:str', value=k)
        value_node = SafeConstructor.construct_scalar(node, tag=u'tag:yaml.org,2002:str', value=v)
        node.value.append((key_node, value_node))

    data_result = AnsibleConstructor.construct_mapping(AnsibleConstructor(), node)

    assert data_result == {'color': 'yellow'}

# Generated at 2022-06-11 09:15:32.618822
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
	constructor = AnsibleConstructor()
	# test normal yaml seq
	yaml_js = [0, 1, 2]
	yaml_node = yaml.nodes.SequenceNode(tag='tag:yaml.org,2002:seq', value=yaml_js, flow_style=False)
	assert list(constructor.construct_yaml_seq(yaml_node)) == yaml_js
	# test ansible seq
	ansible_js = AnsibleSequence([0, 1, 2])
	# ansible seq tests is in test_vault.py


# Generated at 2022-06-11 09:15:36.208311
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(u'tag:yaml.org,2002:map', [],
                       start_mark=None, end_mark=None)
    value = AnsibleConstructor(file_name='test').construct_yaml_map(node)
    assert dict == type(value)



# Generated at 2022-06-11 09:15:45.403159
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import sys
    import os

    sys.path.append(os.path.dirname(__file__) + '/../../lib/')
    from ansible.parsing.vault import VaultLib

    test_constructor = AnsibleConstructor()

    # no vault_secrets
    node_no_vault_secrets = yaml.nodes.MappingNode('tag:yaml.org,2002:map', [], [])
    node_no_vault_secrets.start_mark = yaml.nodes.Mark('test_file', 0, 0, 0, None, None)
    node_no_vault_secrets.value = [yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'test test', None, None, None)]
    node_

# Generated at 2022-06-11 09:15:50.880185
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    data = """
    a: 1
    b: 2
    c: 3
    """
    node = yaml.compose(data)
    mapping = AnsibleConstructor().construct_mapping(node)

    assert dict(mapping) == dict(a=1, b=2, c=3)
    assert mapping['a'].ansible_pos == ('', 1, 4)


# Generated at 2022-06-11 09:16:01.095310
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    module_name = 'test_AnsibleConstructor_construct_mapping'
    display.display("Running %s" % module_name, color='cyan')

    """
    This is a unit test for method construct_mapping of class AnsibleConstructor
    that checks the correctness of YAML mapping nodes processing. In particular,
    it tests correct behavior of the following cases:

    - non-mapping node is passed as a parameter
    - a hashable key is passed as a parameter
    - a not hashable key is passed as a parameter
    - a duplicate key is passed as a parameter
    - a non-mapping node is passed as a parameter
    """

    # non-mapping node is passed as a parameter
    non_mapping_node = AnsibleUnicode("teststring")


# Generated at 2022-06-11 09:16:04.118154
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    constructor = AnsibleConstructor()
    value = constructor.construct_yaml_str(1)

    assert isinstance(value, AnsibleUnicode)

# Generated at 2022-06-11 09:16:10.011918
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    instance = AnsibleConstructor()
    node = {
        'id': 'testid',
        'start_mark': {
            'line': 1,
            'column': 0,
            'name': 'testname'
        },
        }
    actual = instance.construct_yaml_str(node)
    assert actual.ansible_pos == ('testname', 2, 1)

# Generated at 2022-06-11 09:16:15.209673
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    arg = '''
- - hosts:
      - a
      - b
    tasks:
      - name: task1
    vars:
      a: 5
      b: 10
    roles:
      - role1
'''
    adapter = AnsibleConstructor()
    obj = adapter.construct_yaml_seq(arg)
    assert(isinstance(obj, list))

# Generated at 2022-06-11 09:16:32.066796
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import wrap_var
    # Method added for testing purposes to instantiate the class and
    # invoke the method under test.
    display.verbosity = False
    data = '''
    foo: 
      bar: baz
    '''
    file_contents = StringIO(data)
    ac = AnsibleConstructor(file_name='file1', vault_secrets=['password'])
    ansible_dict = ac._construct_mapping(ac.construct_yaml_map(ac.construct_yaml_str(data)))
    assert isinstance(ansible_dict, AnsibleMapping)

# Generated at 2022-06-11 09:16:42.515225
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # skipping in Travis CI as it runs in a container without python-crypto
    if os.environ.get("TRAVIS", None):
        return

    # Setup test data
    node = yaml.nodes.MappingNode(tag=u'!vault')
    node.value = []

# Generated at 2022-06-11 09:16:52.609405
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # pylint: disable=unused-argument,unused-variable
    def construct_scalar(node):
        return node

    def _node_position_info(node):
        return "dummy"

    # create an instance to test on
    obj = AnsibleConstructor(file_name=None, vault_secrets=None)

    # setup the test data
    # ciphertext_v1_format
    node = "AAAAAAAAAAAADTXpkvOyhYOmnsjft8eQ2DGCv_NynC2hkHBd8N3qD7vA5y0g5"

    # execute the call statement to be tested
    # pylint: disable=protected-access
    ret = obj.construct_vault_encrypted_unicode(node)

    # verify the results

# Generated at 2022-06-11 09:17:02.752989
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    '''Unit tests for AnsibleConstructor method construct_vault_encrypted_unicode'''
    vault_password = 'ansible'
    vault_secrets = dict(vault_secrets=[vault_password])
    test_constructor = AnsibleConstructor()
    test_constructor.vault_secrets = vault_secrets

# Generated at 2022-06-11 09:17:03.594422
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass



# Generated at 2022-06-11 09:17:11.296255
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os
    import copy
    import yaml
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml import SeedLoader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml import objects
    from ansible.vars.unsafe_proxy import wrap_var
    import ansible.constants as C

    old_C_DUPLICATE_YAML_DICT_KEY = copy.deepcopy(C.DUPLICATE_YAML_DICT_KEY)

    def construct_unsafe_mapping_node(key, value):
        mapping = SeedLoader.construct_mapping(key)
        mapping.update(value)
        mapping = wrap_var(mapping)
        return mapping

    yaml

# Generated at 2022-06-11 09:17:23.465753
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # We are testing that AnsibleConstructor.construct_yaml_seq
    # will raise a ConstructorError if any item in its sequence
    # is an AnsibleVaultEncryptedUnicode object. This is because
    # dictionaries are not allowed to contain these types.

    import yaml


# Generated at 2022-06-11 09:17:25.101823
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert AnsibleConstructor.construct_mapping(None, deep=False) == {}


# Generated at 2022-06-11 09:17:27.608234
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    
    import yaml
    data = yaml.load("""\
- one
- two
- three
""", Loader=yaml.Loader)
    assert(isinstance(data, list))

# Generated at 2022-06-11 09:17:33.287741
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import json
    data = [
        1,
        'A',
        {'a': 1, 'b': 2},
        [1, 2, 3]
    ]
    expect_data_1 = {
        "expect_1": data[0],
        "expect_2": data[1],
        "expect_3": data[2],
        "expect_4": data[3]
    }
    expect_data_2 = [
        data[0],
        data[1],
        data[2],
        data[3]
    ]

# Generated at 2022-06-11 09:17:44.769707
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():  # this method is called 'test_AnsibleConstructor_construct_yaml_str'
    yaml_obj = AnsibleConstructor()
    yaml_obj.construct_yaml_str(u"foo")
    # return_value is the value returned by the called method.
    return_value = None
    assert return_value == None


# Generated at 2022-06-11 09:17:53.579072
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    from ansible.module_utils._text import to_bytes

    class FakeFileName():
        name = u'fake_filename'

    class FakeNode():
        start_mark = FakeFileName()

    class FakeSafeconstructor():
        def construct_scalar(self, node):
            return u'fake_value'

    constructor = AnsibleConstructor()
    constructor.construct_scalar = FakeSafeconstructor().construct_scalar
    node = FakeNode()
    result = constructor.construct_yaml_str(node)
    assert isinstance(result, AnsibleUnicode)
    assert result.ansible_pos == (u'fake_filename', 1, 1)
    assert to_native(result) == u'fake_value'

    # Default behaviour

# Generated at 2022-06-11 09:18:02.400321
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.errors import AnsibleVaultError, AnsibleParserError
    from ansible.parsing.yaml.loader import AnsibleLoader

    class AnsibleConstructorTest(AnsibleConstructor):
        def __init__(self, vault_secrets):
            super(AnsibleConstructorTest, self).__init__(vault_secrets=vault_secrets)

    from crypt.encrypt import EncryptedUnicode

    test_vault_secrets = ['test_vault_secret']
    test_constructor = AnsibleConstructorTest(vault_secrets=test_vault_secrets)
    test_loader = AnsibleLoader(constructor=test_constructor)


# Generated at 2022-06-11 09:18:11.436872
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    # Setup
    node = yaml.MappingNode(u'tag:yaml.org,2002:map', [], start_mark=None, end_mark=None)

# Generated at 2022-06-11 09:18:17.575315
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_case = {
        'data': [1, 2, 3],
        'constructor_name': 'tag:yaml.org,2002:seq',
        'expected_value': [1, 2, 3]
    }

    constructor = AnsibleConstructor()
    value = constructor.construct_yaml_seq(test_case['data'])
    for i in value:
        assert i.__dict__ == test_case['expected_value'].__dict__

# Generated at 2022-06-11 09:18:28.915833
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    from yaml import Loader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    def construct_yaml_seq(self, node):
        return 'test successful'

    # This is the original method that we will replace
    constructor_method = Loader.add_constructor
    # This is our replacement
    Loader.add_constructor = construct_yaml_seq

    with open('./test_data/construct_yaml_seq_test.yml') as f:
        yaml_data = f.read()
        print('Test successful if it does not throw an exception')
        try:
            sys.modules['yaml'].__dict__['yaml'].load(yaml_data, Loader=Loader)
        except Exception as e:
            raise AssertionError

# Generated at 2022-06-11 09:18:38.609034
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    construct = AnsibleConstructor()
    mapping_node = MappingNode('something',[])

    # Test with an empty mapping
    data = construct.construct_yaml_map(mapping_node)
    assert isinstance(data, AnsibleMapping)
    assert dict(data) == {}

    # Test with a full mapping
    mapping_node = MappingNode('something',[])
    mapping_node.value = [('foo','bar')]
    data = construct.construct_yaml_map(mapping_node)
    assert isinstance(data, AnsibleMapping)
    assert dict(data) == {'foo': 'bar'}

    # Test with a duplicate key
    mapping_node = MappingNode('something',[])
    mapping_node.value = [('foo','bar'), ('foo', 'baz')]


# Generated at 2022-06-11 09:18:40.288826
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    Constructor = AnsibleConstructor()
    r = Constructor(file_name="temp.yaml", vault_secrets='123')

# Generated at 2022-06-11 09:18:50.782661
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()

    node = MappingNode(u'tag:yaml.org,2002:map',[
        [
            'key1',
            'value1'
        ],
        [
            'key2',
            'value2'
        ]
    ], None, None, None)
    data = ansible_constructor.construct_yaml_map(node)
    assert data.ansible_pos[0] is None
    assert data.ansible_pos[1] == 1
    assert data.ansible_pos[2] == 1


# Generated at 2022-06-11 09:18:56.966437
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode

    node = MappingNode(u'tag:yaml.org,2002:map', [])
    result = AnsibleConstructor().construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)
    assert result.ansible_pos == (None, 1, 1)



# Generated at 2022-06-11 09:19:15.070410
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    # Test for the case that the mapping contains a duplicate key
    # try different settings for constant DUPLICATE_YAML_DICT_KEY
    from ansible.parsing.loader import DataLoader

# Generated at 2022-06-11 09:19:18.597405
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    # Create a node instance
    node = None
    # Create the expected output
    expected = AnsibleUnicode(u'unicode')
    # Test that the output matches the expected output
    assert ac.construct_yaml_str(node) == expected

# Generated at 2022-06-11 09:19:26.421903
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Generate the class AnsibleConstructor.
    ansible_construct = AnsibleConstructor()

    # Generate a node as a mapping node.
    node = MappingNode(u'tag:yaml.org,2002:map', [])

    # Construct the yaml map.
    ansible_mapping = ansible_construct.construct_yaml_map(node)

    # Test if the node was correctly constructed.
    assert isinstance(ansible_mapping, AnsibleMapping)
    assert not ansible_mapping
    assert ansible_mapping.ansible_pos is None



# Generated at 2022-06-11 09:19:28.677128
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    node = 'test'

    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-11 09:19:32.769340
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    mapping = MappingNode( 'tag:yaml.org,2002:map', [],
        [ (ScalarNode('tag:yaml.org,2002:str', 'a'), ScalarNode('tag:yaml.org,2002:int', '1')),
          (ScalarNode('tag:yaml.org,2002:str', 'b'), ScalarNode('tag:yaml.org,2002:int', '2')),
          (ScalarNode('tag:yaml.org,2002:str', 'first'), ScalarNode('tag:yaml.org,2002:int', '1')),
          (ScalarNode('tag:yaml.org,2002:str', 'second'), ScalarNode('tag:yaml.org,2002:int', '2')) ])


# Generated at 2022-06-11 09:19:42.677677
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Brief: construct_yaml_str method of class AnsibleConstructor is supposed to return a unicode value
    #        for any possible value of node and self.construct_scalar.
    import sys
    obj = AnsibleConstructor()
    # If a unicode node is passed then the value returned will be of same type: unicode
    assert(isinstance(obj.construct_yaml_str(u'foo'), unicode))
    # If a str node is passed and unicode(str) fails, then a unicode node will be returned
    # The error can be simulated by passing non-utf8 encoded node below.
    class Node:
        def __init__(self):
            self.start_mark = u''

# Generated at 2022-06-11 09:19:49.568410
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    display.display(u'in test_AnsibleConstructor_construct_yaml_seq')
    from yaml.nodes import ScalarNode
    from yaml.composer import Composer
    from yaml.scanner import Scanner
    from yaml.parser import Parser

    COMPOSER = Composer(Parser(Scanner()), AnsibleConstructor())
    seq = COMPOSER.compose_node(ScalarNode(None, None, (1, 1), (1, 1)))
    assert seq[0] == [1]



# Generated at 2022-06-11 09:19:55.698208
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import doctest
    try:
        # python3
        import unittest.mock as mock
    except ImportError:
        # python21
        import mock
    m = mock.mock_open()
    m.return_value.__iter__ = lambda self: iter(self.readline, '')
    m.return_value.readline = '| ansible_loop_var=foo ansible_facts=bar'.encode('utf-8')
    with mock.patch('ansible.parsing.yaml.loader.open', m, create=True):
        (fails, tests) = doctest.testmod(
            ansible.parsing.yaml.loader,
            optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS
        )
       

# Generated at 2022-06-11 09:20:03.394000
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class MyAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            return "abc"

    class TestObj(object):
        yaml_tag = u'tag:yaml.org,2002:str'
        def __init__(self):
            super(TestObj, self).__init__()
        def __str__(self):
            return "123"
        def __unicode__(self):
            return u"123"

    obj = TestObj()
    val = MyAnsibleConstructor().construct_yaml_str(obj)
    assert val == u"abc"


# Generated at 2022-06-11 09:20:12.921733
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constr = AnsibleConstructor()
    yaml_doc = '''
---
a: 1
b: 1
c: 3
d: 4
'''
    node = yaml.compose(yaml_doc)
    mapping = constr.construct_mapping(node)
    assert mapping == {"a": 1, "b": 1, "c": 3, "d": 4}

    if sys.version_info[:2] == (2, 6):
        # we don't run this test on >=2.7 as the sort order is different - need to investigate
        # but this is acceptable, as the duplicate key is only printed for a warning.
        yaml_doc = '''
---
a: 1
b: 2
a: 3
'''
        node = yaml.compose(yaml_doc)

# Generated at 2022-06-11 09:20:36.488837
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    testyaml = '''
        - hosts:
          - localhost
          - localhost
          - localhost
          tasks:
          - debug:
              msg: "{{ item }}"
            with_items:
              - abc
              - def
              - def
              - def
        - hosts:
          - localhost
          tasks:
          - shell: /bin/false
        - hosts:
          - localhost
          tasks:
          - shell: /bin/false
        '''
    import yaml

    c = AnsibleConstructor()
    yaml.add_multi_constructor(u'!unsafe', c.construct_yaml_unsafe)

    yaml.add_constructor(u'!unsafe', c.construct_yaml_unsafe)

# Generated at 2022-06-11 09:20:41.446307
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import ansible.parsing.yaml.constructor

    v = '''
    key1: test1
    key2: test2
    key3: test3
    key1: a new value
    '''
    import yaml
    c = AnsibleConstructor.construct_yaml_map(yaml.compose(v))
    assert c['key1'] == 'a new value'
    assert c['key2'] == 'test2'
    assert c['key3'] == 'test3'

# Generated at 2022-06-11 09:20:49.167271
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import warnings

    if sys.version_info[0] == 2:
        if sys.version_info[1] < 7:
            warnings.filterwarnings('ignore', 'dict key order is not guaranteed', UserWarning, 'yaml')
    from yaml import load, dump

    class C:
        pass
    c = C()
    c.a = 5
    c.b = 6

    class D:
        pass
    d = D()
    d.__dict__['c'] = c

    yaml_str = dump({'a': c, 'b': d})
    data = load(yaml_str, Loader=AnsibleConstructor)

    assert data.get('a').a == 5
    assert data.get('a').b == 6

# Generated at 2022-06-11 09:20:54.794384
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    node = Mock()
    node.start_mark = Mock()
    node.start_mark.column = 5
    node.start_mark.line = 1
    node.start_mark.name = 'stack'
    setattr(node, 'id', 'string')
    value = ansible_constructor.construct_scalar(node)
    assert value == node.value
    assert isinstance(value, AnsibleUnicode)

# Generated at 2022-06-11 09:21:01.087921
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Setup
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = [b'password']
    vault = VaultLib(secrets=ansible_constructor.vault_secrets)
    node = AnsibleVaultEncryptedUnicode(vault.encrypt(b'test'))

    # Test
    ansible_constructor.construct_vault_encrypted_unicode(node)

    # Assert
    assert node.vault == vault

# Generated at 2022-06-11 09:21:04.575474
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ac = AnsibleConstructor()
    s = "{{ lookup('env','HOME') }}"
    n = ANSIBALLZ_MOCK_SENTINEL()
    assert ac.construct_yaml_unsafe(n)._unsafe_proxy.obj == s

# Generated at 2022-06-11 09:21:15.915695
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    When iterating over a dict, the __call__ method of the iterator object is
    called to get the next item from the object. This is done by calling the
    __getitem__ method of the iterator object. If there is an __iter__ method
    on the object, then the value of that method will be returned.
    """
    class Node(object):
        def __init__(self):
            self.start_mark = 0
    class FakeYaml(object):
        @staticmethod
        def load(obj):
            return obj
    # Test with a unicode string
    node = Node()
    fake_yaml = FakeYaml()
    value = AnsibleConstructor(fake_yaml).construct_yaml_str(node)
    # Test that AnsibleUnicode is returned

# Generated at 2022-06-11 09:21:24.716125
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:21:25.424044
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert(True)

# Generated at 2022-06-11 09:21:34.750490
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys, os
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    cwd = os.getcwd()
    if cwd.endswith('test/units/parsing/yaml'):
        yml_file = os.path.abspath('data/construct_mapping_test.yml')
    else:
        yml_file = os.path.abspath('test/units/parsing/yaml/data/construct_mapping_test.yml')

    with open(yml_file) as f:
        yml_data = f.read()

    assert yml_data.count('foo') == 6
    assert yml_data.count('bar') == 3


# Generated at 2022-06-11 09:22:14.628246
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    This function is used to test the AnsibleConstructor.__init__
    method when given a not existing file as argument.
    """
    # Testing construct_yaml_seq
    seq = ['a', 'b', 'c']
    file_name = 'test_file.yml'

    # create an AnsibleConstructor object
    acon = AnsibleConstructor(file_name)

    # create a mapping node for the sequence
    mnode = MappingNode(u'tag:yaml.org,2002:seq', seq)

    # call construct_yaml_seq with the mapping node as argument
    return_seq = acon.construct_yaml_seq(mnode)
    # assert that the return sequence is an AnsibleSequence instance
    assert isinstance(return_seq, AnsibleSequence)

    # assert that

# Generated at 2022-06-11 09:22:27.849210
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    invalid_key1 = {'A': 'a', 'B': 'b', '3': 'c'}
    invalid_key2 = {'A': 'a', 'B': 'b', (1,2): 'c'}
    valid_key = {'A': 'a', 'B': 'b', 'C': 'c'}

    c = AnsibleConstructor()

    # bad key
    try:
        c.construct_mapping({'a': 'b', 'c': 3}, invalid_key1)
    except ConstructorError as e:
        assert e.problem == "found unacceptable key (must not start with '0-9')"
    else:
        raise Exception('Bad key not detected by construct_mapping method')

    # bad key

# Generated at 2022-06-11 09:22:35.660538
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    debug = False
    import os
    import sys
    import yaml
    my_test_vault_secret = 'test'

    # Setup
    vault_test_file = 'VaultTestFile.yml'
    my_vault_secrets = [my_test_vault_secret,]
    my_data = '{Hello: World}'
    my_enc_text = 'AES256EncryptedString'
    my_enc_text_in_file = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          %s\n' % my_enc_text

    # Vault test file should not already exist

# Generated at 2022-06-11 09:22:36.086936
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-11 09:22:38.139374
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert(isinstance(AnsibleConstructor.construct_mapping(None, deep=False), AnsibleMapping))

# Generated at 2022-06-11 09:22:43.717996
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_text = """
        A: 1
        B: 2
        C: 3
        """
    res = yaml.load(yaml_text, Loader=AnsibleConstructor)
    assert AnsibleMapping == type(res)
    assert res['A'] == '1'
    assert res['B'] == '2'
    assert res['C'] == '3'

# Generated at 2022-06-11 09:22:55.462511
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:23:01.157406
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    dummy = AnsibleConstructor()
    # In order to test this construct_yaml_seq method it must be called
    # within a with statement. However, in order to test this the
    # context manager must be mocked out.
    # The create_constructor allows this.
    with dummy.create_constructor() as yaml:
        # Create a YAML test string
        test_data = "\n- a\n- b\n- c\n"
        # Load the YAML into a Python structure
        result = yaml.load(test_data)
        # Ensure it is an AnsibleSequence object
        assert isinstance(result, AnsibleSequence)
        # Check that the values are as expected
        assert result[0] == u'a'
        assert result[1] == u'b'

# Generated at 2022-06-11 09:23:12.490786
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import load
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    sample_enc_string = 'ANVzNXh4O1NzNFZ4NXJyVEJ1TDJLdWxvd0pZcTNZY29FblZsTzZsWFpTek9LZjRL\r\nQT0=\r\n'
    secrets = VaultLib().decrypt(sample_enc_string)
    constructed_obj = load(sample_enc_string, Loader=AnsibleLoader, vault_secrets=secrets)
    constructed_obj_plaintext = constructed_obj.decode()

# Generated at 2022-06-11 09:23:22.098990
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from yaml.nodes import SequenceNode
    from yaml.constructor import ConstructorError
    from ansible.parsing.yaml.loader import AnsibleLoader
    import tempfile
    import os

    data_file = tempfile.mktemp(suffix=".yml")

# Generated at 2022-06-11 09:24:29.917978
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.parsing.yaml.dumper
    yaml.add_representer(str, ansible.parsing.yaml.dumper.AnsibleDumper.represent_str)

    x = '''
a: b
c: d
e: f
g: h
i: a
'''
    y = """
a: 'b'
c: 'd'
e: 'f'
g: 'h'
i: 'a'
"""
    z = yaml.dump(yaml.load(y, Loader=AnsibleConstructor))

    assert(x == z)


# Generated at 2022-06-11 09:24:32.673825
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    fake_node = 'fake_node'
    fake_data = 'fake_data'
    constructed_yaml_seq = AnsibleConstructor.construct_yaml_seq(fake_node)
    constructed_yaml_seq.send(None)
    assert constructed_yaml_seq.send(fake_data) == fake_data

# Generated at 2022-06-11 09:24:35.024784
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    con = AnsibleConstructor()
    node = yaml.nodes.MappingNode(tag='tag:yaml.org,2002:map', value=[])
    assert type(con.construct_yaml_map(node).next()) == AnsibleMapping

# Generated at 2022-06-11 09:24:37.437694
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    ac = AnsibleConstructor(file_name=None, vault_secrets=None)
    ac.construct_mapping(node, deep=False)

# Generated at 2022-06-11 09:24:47.062297
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import sys
    import unittest
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-11 09:24:55.129487
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    vault_password = 'my_secret'
    vault_secrets = [vault_password]

    # construct_vault_encrypted_unicode() should decrypt the vaule and return the decrypted value.

# Generated at 2022-06-11 09:25:06.374354
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag={'tag': 'tag:yaml.org,2002:python/dict'}, value=[])
    my_obj = AnsibleConstructor(_file_name='my_file_name')
    assert 'ansible_pos' in my_obj.construct_mapping(node)

    node = MappingNode(tag={'tag': 'tag:yaml.org,2002:dict'}, value=[])
    my_obj = AnsibleConstructor(_file_name='my_file_name')
    assert 'ansible_pos' in my_obj.construct_mapping(node)

    node = MappingNode(tag={'tag': 'tag:yaml.org,2002:map'}, value=[])
    my_obj = AnsibleConstructor(_file_name='my_file_name')