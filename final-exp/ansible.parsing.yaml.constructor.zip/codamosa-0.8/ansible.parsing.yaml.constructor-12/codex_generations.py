

# Generated at 2022-06-11 09:15:17.783097
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys

# Generated at 2022-06-11 09:15:24.928006
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    c = AnsibleConstructor()
    assert c.construct_yaml_unsafe(AnsibleUnsafeText('foo')) == AnsibleUnsafe('foo')
    assert c.construct_yaml_unsafe(AnsibleUnsafeText(b'foo')) == AnsibleUnsafe('foo')
    assert c.construct_yaml_unsafe(VaultLib({'vault_id': None}, 'foo')) == AnsibleUnsafe('foo')

# Generated at 2022-06-11 09:15:33.152864
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor()
    vault = VaultLib(secrets=['test'])
    encrypted_string = vault.encrypt('test1')
    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', encrypted_string, anchor=None, tag=None)
    ansible_vault_encrypted_unicode = constructor.construct_vault_encrypted_unicode(node)
    try:
        assert ansible_vault_encrypted_unicode.vault == vault
        assert ansible_vault_encrypted_unicode.__str__() == 'test1'
    except AssertionError as e:
        raise e
    else:
        print("Test AnsibleConstructor.construct_vault_encrypted_unicode PASSED")

# Generated at 2022-06-11 09:15:42.276360
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['test secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-11 09:15:43.778858
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ''' test_AnsibleConstructor_construct_yaml_map '''

    assert True

# Generated at 2022-06-11 09:15:54.603832
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils._text import to_text
    # PyYAML will encode strings as ASCII, but when re-loaded,
    # in Python 2, it will be re-loaded as unicode. In Python 3,
    # the native string type is unicode, and there is no ASCII type.
    # But we want to be able to write programmatically generated
    # playbooks that include unicode characters and have them
    # be re-loadable by PyYAML.
    # In either Python 2 or Python 3, if the string is encoded as
    # unicode (or utf-8), then PyYAML will reload it as unicode.
    # But if the string is encoded as ASCII, then in Python 2
    # PyYAML will reload it as a unicode string, but in Python 3
    # PyYAML will reload

# Generated at 2022-06-11 09:16:03.784995
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-11 09:16:05.066904
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert False, "Test not implemented"

# Generated at 2022-06-11 09:16:15.582813
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    used in:
        test/units/parsing/test_yaml.py
    """
    # Without a secret
    constructor = AnsibleConstructor()
    nodes = [{'key1': 'value1'}, {'key2': 'value2'}]
    try:
        mapping = constructor.construct_mapping(nodes)
        assert len(mapping) == 2
        assert mapping['key2'] == 'value2'
    except ConstructorError:
        pass
    # With a vault secret
    constructor = AnsibleConstructor(vault_secrets=['secret'])
    nodes = [{'key1': 'value1'}, {'key2': 'value2'}]

# Generated at 2022-06-11 09:16:22.049296
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # GIVEN
    import yaml, os
    filename = os.path.join(os.path.dirname(__file__), 'data', 'test.yml')
    yaml_data = open(filename, 'r').read()
    yaml_data = yaml.safe_load(yaml_data)

    # WHEN
    # THEN
    assert yaml_data['a'] == AnsibleSequence([1, 2, 3])
    assert yaml_data['a'].ansible_pos == ('test.yml', 17, 1)


# Generated at 2022-06-11 09:16:40.056900
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from io import BytesIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    text = b"key1: somevalue\nkey2: another value"

    loader = AnsibleLoader(BytesIO(text), 'example.yml')
    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert list(data.keys()) == ['key1', 'key2']
    assert data['key1'] == 'somevalue'

# Generated at 2022-06-11 09:16:46.293088
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = {'a': 'b', 'c': 'd'}
    stream = StringIO()

    AnsibleDumper(stream, default_flow_style=False).dump(data)
    output = stream.getvalue()
    assert 'a: b\n' in output
    assert 'c: d\n' in output

    stream = StringIO(output)
    data = AnsibleConstructor(file_name='test.yaml', vault_secrets=[]).get_single_data(stream)
    assert isinstance(data, AnsibleMapping)
    assert 'a' in data
    assert 'b' == data['a']



# Generated at 2022-06-11 09:16:51.381456
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    constructor = AnsibleConstructor(file_name=None)
    node = SequenceNode(tag='TAG:yaml.org,2002:seq', value=[], start_mark=None, end_mark=None, flow_style=False)
    assert constructor.construct_yaml_seq(node) is not None

# Generated at 2022-06-11 09:17:01.458444
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_yaml = '''
- - item
  - item2
- - key: value
    key2: value2
  - key: value
    key2: value2
- - key: value
    key2: value2
'''

    import yaml

    # test default default_flow_style=False
    test_yaml_list = yaml.load(test_yaml, Loader=AnsibleConstructor)

    assert isinstance(test_yaml_list, AnsibleSequence)
    assert test_yaml_list[0][0] == 'item'
    assert test_yaml_list[0][1] == 'item2'

    assert isinstance(test_yaml_list[1], AnsibleSequence)

# Generated at 2022-06-11 09:17:09.866067
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    global display
    display.verbosity = 4
    # output = sys.stdout
    # output.encoding = 'UTF-8'
    # output = io.StringIO()
    # display = Display(verbosity=4, output=output)
    file_name = 'tests/test_data/test_yaml_key_duplicates.yml'
    vault_secrets=[]
    with open(file_name) as fh_:
        data = fh_.read()
        loader = AnsibleConstructor(file_name, vault_secrets=vault_secrets)
        d = loader.get_single_data(data)
        assert (C.DUPLICATE_YAML_DICT_KEY == 'error')
        assert (d['first'] == '1')

# Generated at 2022-06-11 09:17:21.492163
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
---
- foo
- bar
"""
    yaml_data = yaml.load(data, Loader=AnsibleLoader)

    assert type(yaml_data) == AnsibleSequence
    assert type(yaml_data[0]) == AnsibleUnicode
    assert yaml_data[0] == 'foo'
    assert type(yaml_data[1]) == AnsibleUnicode
    assert yaml_data[1] == 'bar'

   

# Generated at 2022-06-11 09:17:30.257452
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """This test ensures that AnsibleConstructor.construct_mapping()
    complains as expected when duplicate keys are found.
    """
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    from yaml.nodes import MappingNode

    class TestConstructMapping(unittest.TestCase):
        """ This tests the behaviour of AnsibleConstructor.construct_mapping() """
        def test_construct_duplicate_key(self):
            """ This tests that ansible complains as expected when a mapping has duplicate keys """
            k1 = ('tag:yaml.org,2002:str', 'key1')
            v1 = ('tag:yaml.org,2002:str', 'value1')

# Generated at 2022-06-11 09:17:39.919677
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml
    test_sequence = "[ 1, 2, 3 ]"

# Generated at 2022-06-11 09:17:51.408611
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_file = open('../../../test/unit/parsing/yaml/constructor/fixtures/construct_yaml_map.yaml')
    yaml_data = yaml_file.read()
    yaml_file.close()
    ac = AnsibleConstructor()
    data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3
    assert data['d'] == 4
    assert data['e'] == 5
    assert data['f'] == 6
    assert data['g'] == 7
    assert data['h'] == 8
    assert data['i'] == 9
    assert data['j'] == 10
    assert data['k'] == 11

# Generated at 2022-06-11 09:17:56.106220
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml.nodes import ScalarNode
    base_node = ScalarNode(tag=u'tag:yaml.org,2002:int', value='1')
    data = []
    c = AnsibleConstructor()
    #an empty list
    node = c.construct_yaml_seq(data)
    assert len(node) == 0
    #now with nodes
    for i in range(2):
        data.append(base_node)
        c.construct_yaml_seq(data)
    assert len(node) == 2


# Generated at 2022-06-11 09:18:12.365301
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import unittest
    from unittest import TestCase


# Generated at 2022-06-11 09:18:21.132366
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    data = """
        a: 1
        b: 2
        c: 3
    """
    loader = DataLoader()
    loader.set_vault_secrets(['testsecret'])
    ansible_loader = AnsibleLoader(loader, None)
    parsed = ansible_loader.load(data)

    assert isinstance(parsed, AnsibleMapping)
    assert parsed['a'] == 1
    assert parsed['b'] == 2
    assert parsed['c'] == 3
    assert parsed.ansible_pos == (None, 1, 1)


# Generated at 2022-06-11 09:18:31.912958
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping

    ac = AnsibleConstructor()

    # test on non MappingNode
    try:
        ac.construct_mapping('test')
    except ConstructorError:
        pass
    else:
        pytest.fail('When construct mapping with non MappingNode, should throw ConstructorError!')

    # test on MappingNode with duplicate dict key
    try:
        ac.construct_mapping(MappingNode(tag=u'tag:yaml.org,2002:map',
                                         value=[('duplicate_key', u'test')],
                                         start_mark=None,
                                         end_mark=None,
                                         flow_style=None))
    except ConstructorError:
        pass
    else:
        pytest

# Generated at 2022-06-11 09:18:40.452960
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml import Loader, load
    from ansible.utils.unsafe_proxy import UnsafeText

    yaml_data = '''
    1
    '''
    yaml_data_result = UnsafeText(yaml_data)
    assert yaml_data_result.ansible_safemode == True
    yaml_data_result = load(yaml_data, Loader=Loader)
    assert yaml_data_result.ansible_safemode == True
    yaml_data = '''
    !unsafe 1
    '''
    yaml_data_result = load(yaml_data, Loader=Loader)
    assert yaml_data_result.ansible_safemode == False

# Generated at 2022-06-11 09:18:54.031786
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.module_utils.six import StringIO

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    stream = ('---\n'
              '- host1\n'
              '- host2\n')

    stream_str = ''.join(stream)
    stream_str_utf8 = stream_str.encode('utf-8')

    ansible_constructor = AnsibleConstructor()
    ansible_loader = AnsibleLoader(stream_str_utf8, ansible_constructor)

    data = list(ansible_loader.get_single_data())

    assert len(data) == 1
    assert isinstance(data[0], AnsibleSequence)

# Generated at 2022-06-11 09:18:59.826395
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    Makes sure that construct_yaml_str() will return a unicode string
    """
    import yaml
    print(dir(yaml))
    yaml_str = 'key: hello'
    yaml_data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert type(yaml_data['key']) == AnsibleUnicode

# Generated at 2022-06-11 09:19:10.617526
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test the error message when value of dict is not an object
    generated_error_message = None
    try:
        node = AnsibleConstructor.construct_yaml_map(1)
        assert node is None
    except Exception as err:
        generated_error_message = str(err)

    expected_error_message = "expected a mapping node, but found 1"
    assert generated_error_message == expected_error_message, \
        '''Failed to assert if generated_error_message == expected_error_message
        generated_error_message: {0}
        expected_error_message: {1}
        '''.format(generated_error_message, expected_error_message)

    # Test if AnsibleMapping works
    node = dict(key_1="value_1", key_2="value_2")

# Generated at 2022-06-11 09:19:20.412520
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    class FakeYAML(object):
        def __init__(self, test_case, file_name, vault_secrets):
            self.test_case = test_case
            self.file_name = file_name
            self.vault_secrets = vault_secrets

        def load(self, string):
            self.test_case.assertIn('a: 1', string)
            self.test_case.assertIn('b:', string)
            self.test_case.assertEqual(string[:4], '--- ')
            return super(FakeYAML, self).load(string)

    # prepare test case
    import unittest
    classTest = unittest.TestCase('__init__')

    # prepare input

# Generated at 2022-06-11 09:19:30.511014
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    construct_yaml_map = AnsibleConstructor.construct_yaml_map
    construct_mapping = AnsibleConstructor.construct_mapping
    constructor = AnsibleConstructor()

    class Test:
        def __str__(self):
            return 'test'

    test = Test()

    mapping = construct_yaml_map(constructor, MappingNode(None, None, True, [u'test_key_1'], [test]))
    assert isinstance(mapping, AnsibleMapping) and mapping == {'test_key_1': u'test'}
    mapping = construct_mapping(constructor, MappingNode(None, None, True, [u'test_key_1'], [test]), True)

# Generated at 2022-06-11 09:19:41.229985
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader

    stream = StringIO("""
- when: test
  tags:
    - test_tag
  user: test_user
  vars:
    test_var: test_value
""")
    loader = AnsibleLoader(stream, file_name='test.yml')
    data = loader.get_single_data()

    assert data[0]['tags'] == ["test_tag"]
    assert data[0]['user'] == 'test_user'
    assert data[0]['vars'] == {'test_var': 'test_value'}
    assert data[0]['when'] == 'test'


# Generated at 2022-06-11 09:20:01.011204
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test init
    import sys
    orig_stdout = sys.stdout
    print("orig_stdout", orig_stdout)
    import io
    sys.stdout = io.StringIO()
    try:
        ac = AnsibleConstructor()
    finally:
        out = sys.stdout.getvalue()
        sys.stdout.close()
        sys.stdout = orig_stdout
        print(out)
    # Test construct_yaml_str
    print('Test construct_yaml_str')
    import sys
    import yaml
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    a = AnsibleBaseYAMLObject()
    a.tag = u'tag:yaml.org,2002:str'
    a

# Generated at 2022-06-11 09:20:03.435381
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    try:
        AnsibleConstructor.construct_mapping("node")
    except ConstructorError as e:
        assert("expected a mapping node" in str(e))

# Generated at 2022-06-11 09:20:12.960116
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

    # construct_vault_encrypted_unicode:
    #   - if vault.secrets is None, raise ConstructorError
    constructor._vaults = {'default': VaultLib(secrets=None)}
    value = u'$ANSIBLE_VAULT;1.1;AES256\n...'
    b_ciphertext_data = to_bytes(value)
    with pytest.raises(ConstructorError) as excinfo:
        constructor.construct_vault_encrypted_unicode(value)

# Generated at 2022-06-11 09:20:19.361725
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = u'''
    a: 1
    b:
      c: 3
      d: 4
    '''
    yaml = AnsibleConstructor(file_name=u'test_file.yaml')
    yaml_obj = list(yaml.construct_yaml(yaml.compose_node(yaml_str, None)))
    assert yaml_obj[0][u'a'] == 1
    assert yaml_obj[0][u'b'][u'c'] == 3
    assert yaml_obj[0][u'b'][u'd'] == 4


# Generated at 2022-06-11 09:20:29.460819
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:20:35.957457
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    AnsibleConstructor.construct_yaml_seq() Test
    """

    # Test with 'test1' as data
    data = 'test1'
    node = MappingNode(None, None, None, None)
    ansibleConstructor = safe_load(data)
    ansibleConstructor.construct_yaml_seq(node)

    # Test with 'test2' as data
    data = 'test2'
    node = MappingNode(None, None, None, None)
    ansibleConstructor = safe_load(data)
    ansibleConstructor.construct_yaml_seq(node)


# Generated at 2022-06-11 09:20:41.548606
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper

    content = '''
- name: value1
- name: value2
- name: value3
- name: value4
  test: value
'''

    assert isinstance(yaml.load(content, Loader=yaml.Loader), list)
    assert isinstance(yaml.load(content, Loader=AnsibleConstructor), list)
    assert isinstance(yaml.load(content, Loader=AnsibleDumper), list)


# Generated at 2022-06-11 09:20:49.268021
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ac = AnsibleConstructor()
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    import yaml
    # create a test node
    node = yaml.compose(stream=None, version=None, tags=None, node=None,
        indent=None, width=None, allow_unicode=None, line_break=None,
        encoding=None, explicit_start=None, explicit_end=None, version_string=None,
        tags_implicit=None, prefix=None, resolver=None, scanner=None,
        compositions=None)
    node.tag = u'tag:yaml.org,2002:seq'
    node.start_mark=yaml.Mark(index=0, column=0, line=0, buffer=0, pointer=0)
    node.end

# Generated at 2022-06-11 09:20:58.731023
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults = {'default': VaultLib(secrets='')}
    # Test valid yaml value

# Generated at 2022-06-11 09:21:03.019135
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    json_str_map = yaml.load("---\n- foo\n- bar: !!str foo", Loader=AnsibleConstructor)
    assert json_str_map[1]['bar'] == u'foo'
    assert type(json_str_map[1]['bar']) == AnsibleUnicode

# Generated at 2022-06-11 09:21:22.285135
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    import tempfile

    class TestCase(unittest.TestCase):
        def _test(self, vault_secrets, ciphertext, expected):
            ac = AnsibleConstructor(file_name=None, vault_secrets=vault_secrets)
            vault = ac._vaults['default']

            # Set a temporary path to the vault file since we are not using ansible.cfg
            vault.file_name = tempfile.mktemp()

            # Get a vault encrypted string node
            node = ac.construct_yaml_str(ac.construct_scalar(ciphertext))

            # Assertion
            self.assertEqual(ac.construct_vault_encrypted_unicode(node), expected)


# Generated at 2022-06-11 09:21:31.767188
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    # This test uses an example ciphertext string.
    # Note: The example has been taken from the vault documentation
    # https://docs.ansible.com/ansible/latest/user_guide/vault.html#vault-data-file-format

# Generated at 2022-06-11 09:21:33.024140
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ac = AnsibleConstructor()
    assert ac.construct_yaml_seq("node")

# Generated at 2022-06-11 09:21:35.702984
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = AnsibleConstructor.construct_yaml_seq('!!python/tuple [1,2,3]')
    assert isinstance(node, AnsibleConstructor.construct_yaml_seq)


# Generated at 2022-06-11 09:21:44.235351
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Test an empty dictionary
    mynode = yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', [])
    test_instance = AnsibleConstructor()
    test_instance.construct_yaml_unsafe(mynode)

    # Test a dictionary with a single entry
    mynode = yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', [],
                                    flow_style=True)
    test_instance = AnsibleConstructor()
    mynode.value.append([yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', u'one'),
                          yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', u'two')])

# Generated at 2022-06-11 09:21:49.392610
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    constructor = AnsibleConstructor(file_name=None, vault_secrets=None)
    mapping_node = MappingNode('tag:yaml.org,2002:map', [])
    constructed_map = constructor.construct_yaml_map(mapping_node)
    assert isinstance(constructed_map, AnsibleMapping)
    assert constructed_map == {}



# Generated at 2022-06-11 09:21:54.926422
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = MappingNode(tag="tag:yaml.org,2002:str", value=[], start_mark=None, end_mark=None, flow_style=None)
    vault_encrypted_constructor = AnsibleConstructor.construct_vault_encrypted_unicode
    assert isinstance(vault_encrypted_constructor(node), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-11 09:22:03.836675
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class MockNode(object):
        def __init__(self, start_mark):
            self.start_mark = start_mark

    class MockMark(object):
        def __init__(self, line, column, name):
            self.line = line
            self.column = column
            self.name = name

    # test case 1:
    # try to construct a AnsibleMapping from an empty map
    node = MockNode(MockMark(1, 1, 'foo.yml'))
    data = AnsibleConstructor().construct_yaml_map(node)
    expected_data = AnsibleMapping()
    assert data == expected_data

    # test case 2:
    # try to construct a AnsibleMapping from a normal map with duplicate key

# Generated at 2022-06-11 09:22:08.270705
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    s = u'HELLO\u00a9'
    ansi = AnsibleConstructor()
    assert ansi.construct_yaml_str(s).encode('utf-8') == s.encode('utf-8')
    assert ansi.construct_yaml_str(s).__class__ == u''.__class__

# Unit test method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-11 09:22:18.024906
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.vault as vault
    v = vault.VaultLib(secrets=['test'])
    yaml_text = "!unsafe '{\"a\":{\"b\":\"c\"},\"changed\":false}'"
    assert isinstance(AnsibleConstructor(vault_secrets=['test']).construct_yaml_unsafe(v.load(yaml_text)), dict)
    try:
        AnsibleConstructor().construct_yaml_unsafe(v.load(yaml_text))
    except ValueError as e:
        assert "The !unsafe feature requires a vault password to be provided" in to_native(e)

# Generated at 2022-06-11 09:22:42.973115
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = """
    {
        foo:'foo',
        foo:'bar',
        baz:'baz',
    }
    """
    expected = {u'foo': 'bar', u'baz': u'baz'}
    actual = AnsibleConstructor.construct_yaml_map(yaml_str)
    assert expected == actual

# Generated at 2022-06-11 09:22:54.952859
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class MockNode(object):
        pass
    node = MockNode()
    node.start_mark = None
    node.value = [
        (MockNode(), MockNode())
    ]
    node.value[0][0].value = 'a'
    node.value[0][1].value = 'b'
    node.value.append((MockNode(), MockNode()))
    node.value[1][0].value = 'c'
    node.value[1][1].value = 'd'
    node.value.append((MockNode(), MockNode()))
    node.value[2][0].value = 'a'
    node.value[2][1].value = 'e'
    c = AnsibleConstructor()

# Generated at 2022-06-11 09:23:00.908708
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    # Python 2 to 3 unicode handling
    if sys.version_info[0] == 3:
        unicode_type = str
    else:
        unicode_type = unicode

    # Create a mock object of class AnsibleConstructor
    c = AnsibleConstructor()
    # Create a mock object of class ScalarNode
    s = MockClass()
    # Set the return value of method construct_unicode of class SafeConstructor to value
    c.construct_unicode = Mock(return_value='value')

    # Call method construct_yaml_str of class AnsibleConstructor
    r = c.construct_yaml_str(s)

    # Assert return value is of type AnsibleUnicode
    assert isinstance(r, AnsibleUnicode)
    # Assert return value contains the correct value


# Generated at 2022-06-11 09:23:12.206862
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Testing stub
    yaml_stream = """
            foo:
                name: "bar"
                age: 2
                choices:
                    - one
                    - two
            baz:
                - another
                - thing
                - thing 2
                - key:
                    nested: item
    """

    # Prepare test data
    expected_value = AnsibleMapping(ansible_pos=('<string>', 2, 0))

    # Do the test
    ansible_constructor = AnsibleConstructor(file_name='<string>')
    ret = ansible_constructor.construct_mapping(yaml_stream)

    # Make sure the returned type is what we expect
    assert isinstance(ret, AnsibleMapping)

    # Make sure the returned value is what we expect
    assert ret == expected_value

# Generated at 2022-06-11 09:23:21.916478
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    class Data:
        pass

    data = Data()
    data.data = [1, 2, 3]
    data.data.ansible_pos = 8, 1, 1
    data_yaml = yaml.dump(data, Dumper=yaml.SafeDumper, default_flow_style=False)

    AnsibleConstructor.add_constructor(
        u'tag:yaml.org,2002:python.Data',
        lambda loader, node: loader.construct_yaml_seq(node)
    )

    data_out = yaml.load(data_yaml, Loader=yaml.Loader)

    assert data_out.data.ansible_pos == (8, 1, 1)
    assert data_out.data.__class__ == AnsibleSequence

# Generated at 2022-06-11 09:23:25.961968
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    some_data = dict(some_list=[1, 2, 3], some_string="foo")
    data1 = some_data['some_list']
    data2 = "foo"

    assert(AnsibleConstructor.construct_yaml_seq(some_data) == data1)
    assert(AnsibleConstructor.construct_yaml_seq(data2) == data2)

# Generated at 2022-06-11 09:23:34.702408
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    # Test a simple dict
    s = "key1: value1\n" \
        "key2: value2\n"
    data = AnsibleLoader(s,
                         file_name=u"<string>",
                         vault_secrets=[],
                         loader=AnsibleConstructor).get_single_data()
    res = AnsibleMapping(ansible_pos=(u'<string>', 1, 0),
                         key1=wrap_var("value1"),
                         key2=wrap_var("value2"))
    assert res == data

    # Test a dict with subdicts

# Generated at 2022-06-11 09:23:41.664061
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    yaml_s = """
- 1
- 2
- 3
"""

    x = yaml.load(yaml_s, Loader=AnsibleConstructor)
    assert isinstance(x[0], AnsibleUnicode)
    assert isinstance(x[1], AnsibleUnicode)
    assert isinstance(x[2], AnsibleUnicode)
    assert x[0] == '1'
    assert x[1] == '2'
    assert x[2] == '3'

test_AnsibleConstructor_construct_yaml_seq()

# Generated at 2022-06-11 09:23:42.818666
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    construct_yaml_map(AnsibleConstructor())


# Generated at 2022-06-11 09:23:43.349296
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-11 09:24:32.189266
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = AnsibleConstructor().construct_yaml_str('!!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          33323633393138363532663665323231383662613336326162323931633832346230623662313833\n          64363638316430616133633235383331393161373737396339633832396434396631666534396265\n          633739336338383665333836303931362D35622D346539622D626330382D32393639356338333836\n          39366561373966\n          ')
    assert isinstance(node, AnsibleVaultEncryptedUnicode)
    assert node.vault == VaultLib()

# Generated at 2022-06-11 09:24:34.769079
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ac = AnsibleConstructor()
    ret = list(ac.construct_yaml_seq("helloworld\n"))
    assert isinstance(ret[0], AnsibleSequence)
    assert ret[0].ansible_pos == (None, 1, 0)

# Generated at 2022-06-11 09:24:43.571664
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import pytest
    with pytest.raises(ConstructorError) as cm:
        AnsibleConstructor().construct_mapping(MappingNode(None, None, None, None, None, True))
    assert str(cm.value).startswith('expected a mapping node')

    with pytest.raises(ConstructorError) as cm:
        AnsibleConstructor().construct_mapping(MappingNode(None, None, None, None, None, False))
    assert str(cm.value).startswith('expected a mapping node')

    with pytest.raises(TypeError) as cm:
        AnsibleConstructor().construct_mapping('not a MappingNode')
    assert str(cm.value).startswith('expected a mapping node')

# Generated at 2022-06-11 09:24:51.406650
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_secrets = ['test1234']
    test_value = '$ANSIBLE_VAULT;1.1;AES256\n36346535343564363565643639356437653133343161366332323663316338643535626263353539\n3438376635643337646263666136313236376439666564383538333865313237623063333539663865\n3630346665333661623162\n'
    test_node = AnsibleVaultEncryptedUnicode(test_value)
    test_constructor = AnsibleConstructor(vault_secrets=test_secrets)
    test_constructor.construct_vault_encrypted_unicode(test_node)

test_Ansible

# Generated at 2022-06-11 09:24:55.130261
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    def dummy_yaml_constructor(self, node):
        return self.construct_vault_encrypted_unicode(node)

    ansible_constructor = dummy_yaml_constructor(None, None)
    assert ansible_constructor.construct_vault_encrypted_unicode == AnsibleConstructor.construct_vault_encrypted_unicode

# Generated at 2022-06-11 09:24:58.006420
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    obj = AnsibleConstructor()
    yaml_seq =  (
        '- 123\n'
        '- 456\n'
        '- 789\n'
        )
    obj.construct_yaml_seq(yaml_seq)

# Generated at 2022-06-11 09:25:04.415924
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    vault_secrets = {}
    yaml_str = "{a: 1, b: !unsafe ['foo', 'bar', 'baz']}"
    yaml_data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert yaml_data == {
        'a': 1,
        'b': ['foo', 'bar', 'baz']
    }