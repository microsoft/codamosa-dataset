

# Generated at 2022-06-11 09:15:15.490977
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os
    import json
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # construct a mapping with no duplicates
    yml_dict = {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3"
    }
    yml_str = yaml.dump(yml_dict, default_flow_style=False)
    yml_constructor = AnsibleConstructor(file_name=os.getcwd())

# Generated at 2022-06-11 09:15:23.182018
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping

    class TestConstructor(AnsibleConstructor):
        def construct_mapping(self, node, deep=False):
            mapping = AnsibleMapping()
            for key_node, value_node in node.value:
                key = self.construct_object(key_node, deep=deep)
                value = self.construct_object(value_node, deep=deep)
                mapping[key] = value
            return mapping

    constructor = TestConstructor()

    # single value mapping
    assert constructor.constr

# Generated at 2022-06-11 09:15:32.068889
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import load
    from ansible.parsing.vault import VaultLib, VaultSecret

    secrets = [VaultSecret(password='password', version=2)]
    vault_password = VaultLib(secrets=secrets)
    my_constructor = AnsibleConstructor(vault_secrets=secrets)


# Generated at 2022-06-11 09:15:41.150714
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.constructor import ConstructorError
    from yaml.nodes import MappingNode

    c = AnsibleConstructor(file_name='/tmp/test')
    node_to_construct = MappingNode(tag="tag:yaml.org,2002:map", value=[], flow_style=False)
    # test constructor without deep flag
    assert c.construct_mapping(node_to_construct) == AnsibleMapping()
    assert c.construct_mapping(node_to_construct).ansible_pos == ('/tmp/test', 1, 1)
    # test constructor with deep flag
    assert c.construct_mapping(node_to_construct, deep=True) == AnsibleMapping()

# Generated at 2022-06-11 09:15:44.325973
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml import objects
    node = objects.AnsibleMapping()
    node.update({'a': 1, 'b': 2})
    assert AnsibleConstructor().construct_yaml_map(node).next() == node



# Generated at 2022-06-11 09:15:55.170874
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    m = { 'a': 1, 'b': 2, 'a': 3 }  # the last value is retained
    node = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    for k in m:
        nkey = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=k)
        nval = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=m[k])
        node.value.append((nkey, nval))
    result = AnsibleConstructor(file_name='fixtures/test_AnsibleConstructor_construct_mapping.yaml').construct_mapping(node)

# Generated at 2022-06-11 09:15:55.797667
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    return False

# Generated at 2022-06-11 09:16:05.441786
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            super(TestAnsibleConstructor, self).__init__(file_name, vault_secrets)

    data = '''
    - {a: 1, b: 2}
    - {c: 3, d: 4}
    '''

    constructor = TestAnsibleConstructor()

    # For old Ansible versions, where ImmutableDict is not available, use dict instead.
    # Since in the test, we are not calling the constructor methods, it is safe
    # to override the Ans

# Generated at 2022-06-11 09:16:10.752482
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_str = u'yaml-unicode-string'
    yaml_node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str',
                                      value=yaml_str)
    assert AnsibleConstructor.construct_yaml_str(yaml_node) == yaml_str

# Generated at 2022-06-11 09:16:20.303702
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_txt = '''
            key1:
              key1a: value1a
              key1b: value1b
            key2:
              key2a: value2a
              key2b: value2b
            '''
    yml_constructor = SafeConstructor.yaml_base_loader.get_single_data(yaml_txt)
    assert len(yml_constructor) == 2
    assert yml_constructor.ansible_pos == (None, 3, 1)
    assert isinstance(yml_constructor, AnsibleMapping)
    assert yml_constructor.get('key1').ansible_pos == (None, 3, 3)
    assert yml_constructor.get('key2').ansible_pos == (None, 6, 3)
    assert yml_constructor

# Generated at 2022-06-11 09:16:34.147037
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    x = "msg: '{{shell_out.stdout}}'"
    y = """
    msg: !unsafe '{{shell_out.stdout}}'
    """
    assert x != y

    constructor = AnsibleConstructor()
    import yaml
    m = yaml.parser.Parser()
    t = m.compose_document(y)
    d = constructor.construct_document(t)
    assert d == "{'msg': '{{shell_out.stdout}}'}"

# Generated at 2022-06-11 09:16:43.713886
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    import inspect
    import pprint
    from ansible.parsing.yaml.loader import AnsibleLoader

    #self = AnsibleConstructor()
    construct_yaml_unsafe = AnsibleConstructor.construct_yaml_unsafe

    print(inspect.getdoc(construct_yaml_unsafe))
    #print(dir(construct_yaml_unsafe))

    #yaml.constructor.SafeConstructor.construct_yaml_int(self, node)
    #return self.construct_yaml_int(node)

    # construct_object(self, node, deep=False)
    # return self.construct_mapping(node, deep=deep)
    # construct_mapping(self, node, deep=False)
    # self.construct_scalar(node)
    # construct_scalar

# Generated at 2022-06-11 09:16:53.665817
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    b_ciphertext_data = b'$ANSIBLE_VAULT;1.1;AES256\n363433373766313335373834633332653466633962646261663236306331366139313461326335\n383964616463393363336562643565316362656166316565343966356164616630626166663239\n383133616239623039393932346363653064316530393863613463326334653137656334346238\n323565643661306465 \n'
    vault_password = 'vault_password'
    vault_loader = AnsibleLoader(vault_password, file_name=None)
    vault

# Generated at 2022-06-11 09:16:56.770072
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create and return an instance of AnsibleConstructor class
    constructor = AnsibleConstructor()
    # Check it is instance of AnsibleConstructor class
    assert isinstance(constructor, AnsibleConstructor)

# Generated at 2022-06-11 09:16:59.527107
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(MappingNode(u'tag:yaml.org,2002:map', [], []))


# Generated at 2022-06-11 09:17:08.686293
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    import pytest

    from ansible import errors as AnsibleError
    from ansible.config.data import ConfigData

    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate dict keys (should raise errors)
    yaml_text = '''
    foo: a
    foo: b
    '''
    yaml = AnsibleLoader(yaml_text, file_name='<string>').get_single_data()

    with pytest.raises(AnsibleError):
        AnsibleDumper(yaml, Dumper=AnsibleDumper)

    # Test with duplicate dict keys (should not raise errors)


# Generated at 2022-06-11 09:17:19.315485
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # test1: Single-element mapping
    node = MappingNode(tag=u'tag:yaml.org,2002:python/dict')
    node.value = [(ScalarNode(tag=u'tag:yaml.org,2002:str', value='key1'), ScalarNode(tag=u'tag:yaml.org,2002:str', value='value1')),]
    assert(dict(AnsibleConstructor().construct_mapping(node)) == dict(key1='value1'))

    # test2: Two-element mapping
    node = MappingNode(tag=u'tag:yaml.org,2002:python/dict')

# Generated at 2022-06-11 09:17:27.336456
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class Loader:
        pass

    fake_loader = Loader()
    class Node:
        def __init__(self):
            self.value = 1
            self.start_mark = Loader()
            self.start_mark.line = 1
            self.start_mark.column = 2
    fake_data = Node()

    ac = AnsibleConstructor()
    generator = ac.construct_yaml_seq(fake_data)

    mylist = next(generator)
    mylist.append(5)

    assert len(mylist) == 1
    assert mylist[0] == 5


# Generated at 2022-06-11 09:17:32.884360
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor(file_name='test.yml', vault_secrets=['secret1'])
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    test_yaml_str = '''
- key1: value1
- key2: value2
'''
    assert test_dict == ansible_constructor.construct_yaml_map(load(test_yaml_str))

# Generated at 2022-06-11 09:17:44.769581
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # fill the vault with a known secret
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults['default'].secrets = ['this_is_my_secret']
    # create the data structure that we expect to find on disk
    raw = {"test": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          36343737313663306365393830376535313463383137653961623962613663383837653263373666\n          3234643733356261306336\n          "}
    # decode the data structure
    decoded = yaml.load(yaml.dump(raw), Loader=AnsibleConstructor)
    # check if the secrets is decoded properly
    assert decoded['test']

# Generated at 2022-06-11 09:17:57.148979
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    yaml_test_data_seq = """
    - first
    - second
    - third
    """

    data = yaml.load(yaml_test_data_seq, Loader=AnsibleConstructor)
    assert data
    assert len(data) == 3
    assert data[0] == "first"
    assert data[1] == "second"
    assert data[2] == "third"



# Generated at 2022-06-11 09:18:06.220176
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = 'password'
    # Create a vault with a password
    vault = VaultLib(password=vault_password)
    # Encrypt string 'test'
    enc_str = vault.encrypt_bytes(b"test")
    # Create a node
    class Node:
        pass
    node = Node()
    # Assign yaml string to node
    node.value = vault.decrypt_bytes(enc_str)
    # Create AnsibleConstructor object
    obj = AnsibleConstructor()
    # Encrypt string with construct_vault_encrypted_unicode
    tested_enc_str = obj.construct_vault_encrypted_unicode(node)
    # Decrypt string with internal vault
    tested_dec_str = tested_enc_str.vault.decrypt_bytes(tested_enc_str)
   

# Generated at 2022-06-11 09:18:16.242726
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import __builtin__
    data = dict(
        m0=dict(
            m1=dict(
                m2=dict(
                    m3=dict(
                        m4=dict(
                            m5=dict(
                                m6=dict(
                                    m7=dict(
                                        m8=dict(
                                            m9=dict(
                                                x=1
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        )
    )

    if hasattr(__builtin__, '__builtins__'):
        setattr(__builtin__, '__builtins__', {})
    else:
        setattr(__builtin__, '__builtins__', __builtin__)

    assert Ans

# Generated at 2022-06-11 09:18:27.447689
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    aconstructor = AnsibleConstructor()

    # Test if AnsibleConstructor.construct_vault_encrypted_unicode works properly
    # when there is only one vault secret
    node = type('', (), {'id': 'vault-encrypted', 'start_mark': type('', (), {'column': 0, 'name': '', 'line': 0})})()

# Generated at 2022-06-11 09:18:36.760158
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import io
    import sys
    import yaml
    class MyStream(io.TextIOBase):
        def __init__(self):
            self._buffer = ''
            self._offset = 0
        def read(self, length=None):
            print("read: length=%s" % length)
            if length is None or length < 0:
                result = self._buffer[self._offset:]
                self._offset = len(self._buffer)
            else:
                if self._offset + length > len(self._buffer):
                    length = len(self._buffer) - self._offset
                result = self._buffer[self._offset:self._offset + length]
                self._offset += length
            print("read: returned %s" % result)
            return result

# Generated at 2022-06-11 09:18:41.447517
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    n = MappingNode(None, [], [], [], [], None)
    n.start_mark = 'line:5, column:5'
    constructor = AnsibleConstructor()
    constructor._ansible_file_name = 'foobar'
    ansible_str = constructor.construct_yaml_str(n)
    assert ansible_str.ansible_pos == ('foobar', 5, 5)


# Generated at 2022-06-11 09:18:55.289645
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # ConstructorError is an abstract class and cannot be directly instantiated.
    # It is an error to call this method with a node that is not a MappingNode,
    # so we create a generic node to trigger it.
    from yaml.nodes import Node
    n = Node()
    n.id = 'foo'
    n.start_mark = 1234
    ac = AnsibleConstructor()
    try:
        ac.construct_mapping(n)
    except ConstructorError as ce:
        assert ce.problem == 'expected a mapping node, but found foo'
        assert ce.problem_mark.line == 1234
    else:
        assert False, "construct_yaml_map(): ConstructorError not raised."

    # It is also an error to call this method with a key which is not hashable.
    # To test this

# Generated at 2022-06-11 09:19:01.864736
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = """---
- foo
- bar
- baz
-
- lol
...
"""
    seq = yaml.load(data.encode('utf-8'), Loader=AnsibleConstructor)

# Generated at 2022-06-11 09:19:11.565943
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    secrets = [b"my_secret"]
    vault_lib = VaultLib(secrets)

    plain_txt = b"this is a test"
    ciphertext = vault_lib.encrypt(plain_txt)

    node = yaml.nodes.ScalarNode(tag=u'!vault', value=ciphertext, plain=False)
    ansible_constructor = AnsibleConstructor(vault_secrets=secrets)
    vault_obj = ansible_constructor.construct_vault_encrypted_unicode(node)
    decrypted_vault_obj = vault_obj.decrypt(vault_obj.vault.secrets)
    assert decrypted_vault_obj == plain_txt

    # Test that _vaults is updated
    assert ansible_constructor._vaults['default'].secrets

# Generated at 2022-06-11 09:19:21.129175
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # A constructor error is raised if the value is not a mapping node
    try:
        constructor = AnsibleConstructor()
        constructor.construct_mapping(None)
    except ConstructorError as e:
        assert "expected a mapping node" in to_native(e)
    else:
        assert False, "constructor should raise an exception"

    # If the key is not hashable, a constructor error is raised
    try:
        constructor = AnsibleConstructor()
        constructor.construct_mapping(MappingNode(None, [('some', 'value')]))
    except ConstructorError as e:
        assert "found unacceptable key" in to_native(e)
    else:
        assert False, "constructor should raise an exception"

    # If the key is hashable, a dictionary is created from key-value pairs
    constructor = Ans

# Generated at 2022-06-11 09:19:33.507242
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # construct_yaml_map() should construct correct value from correct node
    # It should use construct_mapping() to construct value
    # It should set ansible_pos to value
    import StringIO
    import yaml
    yaml_str = '''\
---
hosts:
  - www.example.com
  - 192.168.1.1
  - 127.0.0.1
'''
    data = yaml.load(StringIO.StringIO(yaml_str), Loader=AnsibleConstructor)
    assert data['hosts'][0] == u'www.example.com'
    assert data['hosts'][1] == u'192.168.1.1'
    assert data['hosts'][2] == u'127.0.0.1'

# Generated at 2022-06-11 09:19:43.299694
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    construct_yaml_map = AnsibleConstructor.construct_yaml_map

    data = """
        a: 1
        b: 2
        c: 3
        """
    data_loader = DataLoader()
    unsafe_proxy = data_loader.load(data, 'unsafe_text', show_content=False)
    data_loader = AnsibleLoader(data, data_loader)
    data_loader.set_unsafe_proxy(unsafe_proxy)
    node = data_loader.get_single_data()
    data = construct_yaml_map(node).next()
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 1
   

# Generated at 2022-06-11 09:19:52.206182
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    try:  # Ansible 2.3
        from ansible.plugins.loader import get_all_plugin_loaders, get_plugin_loader
    except:
        from ansible.plugins import get_all_plugin_loaders, get_plugin_loader

    # Test modules
    modules = {}
    for loader in get_all_plugin_loaders():
        for name in loader.find_plugin_vals(get_plugin_loader('module_utils')):
            name = name.split(os.path.sep)[-1].split('.')[0]
            modules[name] = loader.get(name, get_plugin_loader('module_utils'))

    # Test filters
    filters = {}

# Generated at 2022-06-11 09:20:02.043705
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    value_non_unicode = 'abc'
    value_unicode = u'abc'
    value = value_unicode

    ansible_constructor = AnsibleConstructor()

    ansible_constructor_construct_yaml_str = ansible_constructor.construct_yaml_str
    ansible_unicode = ansible_constructor_construct_yaml_str(value)
    assert ansible_unicode == value_unicode
    assert isinstance(ansible_unicode, AnsibleUnicode)
    assert not isinstance(ansible_unicode, str)
    assert not isinstance(ansible_unicode, unicode)

    ansible_constructor_construct_yaml_str = ansible_constructor.construct_yaml_str
    ansible_unicode = ansible_constructor_construct_y

# Generated at 2022-06-11 09:20:03.599303
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert isinstance(AnsibleConstructor().construct_yaml_str(None), AnsibleUnicode)

# Generated at 2022-06-11 09:20:13.103014
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    def test_do(vault_secrets=[None]):
        import yaml
        from ansible.parsing.vault import VaultLib

        vault_data = b"$ANSIBLE_VAULT;1.1;AES256\n36373361386663643639303733386234323061343035373736653936666432346133353166610a30666435393764386232356435306232386339663164393433613761323932393565366130\n"
        vault_data_bad = b'!vault-encrypted' + vault_data


# Generated at 2022-06-11 09:20:19.812944
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = '''
---
a: 1
b:
  c: 3
  d: 4
'''

    data = yaml.load(yaml_data, Loader=AnsibleConstructor)

    assert data.ansible_pos == (None, 1, 0)
    assert data['a'].ansible_pos == (None, 2, 2)
    assert data['b'].ansible_pos == (None, 3, 2)
    assert data['b']['c'].ansible_pos == (None, 4, 4)
    assert data['b']['d'].ansible_pos == (None, 5, 4)

# Generated at 2022-06-11 09:20:30.252462
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    secrets = ['secret1', 'secret2']
    vault_secret_id = '$ANSIBLE_VAULT;1.1;AES256;test'
    vault_secret_id_bytes = to_bytes(vault_secret_id)

    vault_data = to_bytes('another secret')

    # AnsibleConstructor.__init__ and construct_yaml_unsafe are not tested.
    # AnsibleConstructor.__init__ is an empty method, and construct_yaml_unsafe has
    # no docstring, so it is not pylint clean to test them.
    #
    # AnsibleConstructor.__new__ is also not tested because it calls the super class'
    # __new__ method, and the super class' __new__ method is not pylint clean to use
    # with the unit test framework.
   

# Generated at 2022-06-11 09:20:34.354286
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = """
            a: 1
            b: 2
            c: 3
            """

    ansible_constructor = AnsibleConstructor()
    ansible_mapping = ansible_constructor.construct_mapping(
            ansible_constructor.construct_yaml_map(
                ansible_constructor.construct_document(
                    yaml_str)).next())
    assert(ansible_mapping['a'].__class__ == AnsibleUnicode)
    assert(ansible_mapping['a'].ansible_pos == ('<string>', 2, 9))
    assert(ansible_mapping['b'] == 2)
    assert(ansible_mapping['c'] == 3)
    assert(ansible_mapping.ansible_pos == ('<string>', 1, 1))

# Generated at 2022-06-11 09:20:36.839758
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    value = u"test"
    node = ''
    ac = AnsibleConstructor()
    ret = ac.construct_yaml_str(node)
    assert ret == value


# Generated at 2022-06-11 09:21:02.941898
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault = VaultLib(secrets=['password'])
    test_vault_encrypt = vault.encrypt(b_ansible_string)
    test_vault_encrypt = b'!vault |\n          ' + test_vault_encrypt

    test_AnsibleConstructor = AnsibleConstructor(None, ['password'])
    test_AnsibleVaultEncryptedUnicode = test_AnsibleConstructor.construct_vault_encrypted_unicode(test_AnsibleConstructor.construct_yaml_str(test_vault_encrypt))

    assert isinstance(test_AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode)
    assert isinstance(test_AnsibleVaultEncryptedUnicode.vault, VaultLib)
    assert test_

# Generated at 2022-06-11 09:21:04.534633
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    yaml.load('spam: 1', Loader=AnsibleConstructor)

# Generated at 2022-06-11 09:21:10.067825
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    yaml_str = '''
    k1: 1
    k2: 2
    '''
    yaml_list = [{'k1':'1', 'k2':'2'}]
    ansible_obj = yaml.load(yaml_str, Loader=yaml.Loader)
    display.display(ansible_obj)
    assert(yaml_list == ansible_obj)


# Generated at 2022-06-11 09:21:16.518605
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    dummy_raw_yaml = "---\n- foo\n- bar\n"
    dummy_node = yaml.parse(dummy_raw_yaml)
    yaml_seq = AnsibleConstructor.construct_yaml_seq(dummy_node[0])
    data = yaml_seq.__next__()
    assert data == [u'foo', u'bar']

# Generated at 2022-06-11 09:21:25.192139
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Create a new AnsibleConstructor object for the unit test
    ansibleConstr = AnsibleConstructor()

    # Unit test 1.
    # We will create an example YAML file as node and call the method
    # construct_yaml_seq.
    # If the method doesn't return an AnsibleSequence then an error will be raised

    # Example YAML file that will be "converted" into an example node
    example_YAML = """
- server1
- server2
- server3
"""
    node = yaml.compose(example_YAML)

    # Call the method construct_yaml_seq
    result = list(ansibleConstr.construct_yaml_seq(node))

    # The result should be in a list and consist of one AnsibleSequence object

# Generated at 2022-06-11 09:21:34.537722
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    vault_password = b'password'
    data = dict(test_data1='12345', test_data2='54321')

    class FakeVaultLib(object):
        def __init__(self, secrets):
            self.secrets = secrets
            pass

        def encrypt_bytes(self, string_to_encrypt, key_id=None):
            return yaml.dump(data)

    vault_lib = FakeVaultLib(secrets=[vault_password])
    vault_lib_with_no_secrets = FakeVaultLib(secrets=None)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults = dict(default=vault_lib)
    ansible_constructor_with_no_secrets = AnsibleConstructor()
    ans

# Generated at 2022-06-11 09:21:43.193322
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_native
    from datetime import datetime
    from collections import namedtuple
    from ansible.utils.unsafe_proxy import wrap_var

    # Here I am creating a yaml document which contains an object of type
    # datetime.datetime as a key in a dictionary. The usual case is
    # that a YAML document serializes datetime.datetime objects as
    # !!python/datetime objects. But in that case, we will not be
    # able to load them, as the constructor class of
    # yaml.constructor.SafeConstructor raises exception while loading


# Generated at 2022-06-11 09:21:51.322687
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = "node"
    AnsibleConstructor.construct_scalar = lambda x: "value"
    AnsibleConstructor.construct_object = lambda x, y=None: True
    vault_secrets = ["secret1", "secret2", "secret3"]
    ansible_constructor = AnsibleConstructor(file_name="test-file", vault_secrets=vault_secrets)

    result = ansible_constructor.construct_vault_encrypted_unicode(node)
    assert result.vault.secrets == vault_secrets
    assert result == ansible_constructor.construct_scalar(node)



# Generated at 2022-06-11 09:21:58.673878
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    test_vars = {'test_var_1': 1, 'test_var_2': '2', 'test_var_3': [1, 2], 'test_var_4': [{'A': 'a', 'B': 'b'}, {'C': 'c', 'D': 'd'}]}
    test_inputs = ['{{ test_var_1 }}', '{{ test_var_2 }}', '{{ test_var_3 }}', '{{ test_var_4 }}']
    test_outputs = test_inputs
    for output in test_outputs:
        assert(output == output)

# Generated at 2022-06-11 09:22:07.200827
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    '''
    Test the construct_yaml_str method of the AnsibleConstructor class
    with various string scalars expecting to get AnsibleUnicode objects.
    '''
    from yaml.nodes import ScalarNode

    yaml_str = u'should be AnsibleUnicode'
    node = ScalarNode(u'tag:yaml.org,2002:str', yaml_str)

    ac = AnsibleConstructor()
    ansible_unicode_obj = ac.construct_yaml_str(node)
    assert ansible_unicode_obj == yaml_str

    # yaml.org,2002:str is the default, so the tag is optional
    node = ScalarNode(u'', yaml_str)


# Generated at 2022-06-11 09:22:59.126741
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret_data = "secret"
    vault = AnsibleConstructor._vaults['default']
    vault.secrets = secret_data

# Generated at 2022-06-11 09:23:09.082849
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    import sys

    if sys.version_info < (2, 7):
        class Temp(object):
            pass
        node = Temp()
        setattr(node, 'id', 'object')
    else:
        node = type.__new__(type, 'Temp', (), {})

    ac = AnsibleConstructor()
    result = ac.construct_yaml_unsafe(node)
    # This test is for python3 version of AnsibleConstructor.py
    # The method construct_yaml_unsafe returns AnsibleUnsafe object
    # In python2 version AnsibleUnsafe is not defined.
    assert isinstance(result, AnsibleUnsafe)

# Generated at 2022-06-11 09:23:19.397862
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    string = u'\u0905'
    node = AnsibleLoader(string, file_name='test/file/name', vault_secrets=[]).get_single_data()
    ac = AnsibleConstructor(file_name='test/file/name', vault_secrets=[])
    obj = ac.construct_yaml_str(node)
    assert(type(obj) is not AnsibleVaultEncryptedUnicode)
    assert(obj == u'\u0905')
    assert(obj.ansible_pos == ('test/file/name', 1, 0))



# Generated at 2022-06-11 09:23:23.301247
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ''' test for method construct_yaml_seq of class AnsibleConstructor '''
    sample_yaml_str = "- 1\n- 2\n- 3"
    data = AnsibleSequence()
    data.append(safe_load(sample_yaml_str))
    assert data == [1, 2, 3]
    assert data.ansible_pos == ('<unicode string>', 1, 1)


# Generated at 2022-06-11 09:23:32.615528
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    data = {
        'a': 1,
        'b': 2,
        'c': 3
    }

    # Test warning when duplicate key
    yaml = yaml.dump(data, Dumper=AnsibleDumper)
    yaml += '{a: 1, b: 2, c: 3}\n'
    yaml_obj = yaml.load(yaml, Loader=AnsibleConstructor)
    assert yaml_obj == data

    # Test error when duplicate key
    C.DUPLICATE_YAML_DICT_KEY = 'error'

# Generated at 2022-06-11 09:23:36.853013
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    input = [('key1', 'value1'), ('key2', 'value2'), ('key2', 'value3')]

    output = AnsibleConstructor().construct_mapping(input)

    assert output
    assert 3 == len(output)
    assert 'value1' == output['key1']
    assert 'value3' == output['key2']

# Generated at 2022-06-11 09:23:42.394250
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys

    test_constructor = AnsibleConstructor()
    test_node = "!unsafe {'ansible_become': True}"

    if sys.version_info < (2, 7):
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
        assert isinstance(test_constructor.construct_yaml_unsafe(test_node), AnsibleUnsafeText)
    else:
        assert isinstance(test_constructor.construct_yaml_unsafe(test_node), bool)

# Generated at 2022-06-11 09:23:53.244396
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """
    Tests the method construct_yaml_unsafe of class AnsibleConstructor.
    """
    yaml_constructor = AnsibleConstructor()

    # unsafe byte string
    byte_string = b'abc'
    byte_tag = u'tag:yaml.org,2002:str'
    byte_node = yaml_constructor.construct_yaml_str(byte_tag, byte_string)
    # first use the construct_yaml_unsafe method to wrap the unsafe byte string
    # into a callable object
    wrapped_byte_string = yaml_constructor.construct_yaml_unsafe(byte_node)
    # then call the callable object, the unsafe byte string is converted
    # back to a safe unicode string
    converted_byte_string = wrapped_byte_string()

# Generated at 2022-06-11 09:24:04.862919
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-11 09:24:13.709442
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    from yaml.parser import ParserError
    from yaml.reader import Reader
    from yaml.scanner import ScannerError

    yaml_str = '''- 1
- 2
'''
    yaml_list = [1, 2]
    try:
        reader = Reader(yaml_str)
        scanner = Scanner(reader)
        parser = Parser(scanner)
        node = parser.get_single_node()
        assert isinstance(node, SequenceNode)

        constructor = AnsibleConstructor()
        obj = constructor.construct_yaml_seq(node)
        assert isinstance(obj, list)
        assert obj == yaml_list
    except (ScannerError, ParserError):
        pass