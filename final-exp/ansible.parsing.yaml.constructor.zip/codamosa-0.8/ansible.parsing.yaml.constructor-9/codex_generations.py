

# Generated at 2022-06-11 09:15:08.066573
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor()
    # simple string
    node = {
        "start_mark": 42,
        "end_mark": 1337
    }
    assert constructor.construct_vault_encrypted_unicode(node) == '42, 1337'

# Generated at 2022-06-11 09:15:16.412020
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    constructor = AnsibleConstructor()
    class FakeNode:
        start_mark = None
    node = FakeNode()
    data = AnsibleMapping()
    data.ansible_pos = (
        '/home/foo/bar.yml',
        2,
        3
    )
    s = """
    {
        "foo": "bar",
        "hex": "0x1"
    }
    """
    data.update(constructor.construct_yaml_map(node, deep=False))
    data['hex'] = '0x1'
    assert data == {'foo': 'bar', 'hex': '0x1'}


# Generated at 2022-06-11 09:15:21.899570
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """ Test the construct_yaml_seq method of the AnsibleConstructor """
    testdata = u"""
- 1
- 2
- 3
- 4
- 5
"""

    data = yaml.load(testdata, Loader=AnsibleConstructor)
    assert 4 in data
    assert isinstance(data, AnsibleSequence)



# Generated at 2022-06-11 09:15:31.034975
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing import vault
    import ansible.parsing.vault
    import ansible.parsing.yaml.loader
    v = vault.VaultLib(secrets=[b"blah_blah_blah_blah"])

# Generated at 2022-06-11 09:15:35.330472
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    text = "foo: true\nbar: false"
    mapping = ansible_safe_load(text)
    assert mapping['foo'] is True
    assert mapping['bar'] is False

test_AnsibleConstructor_construct_yaml_map.unittest = ['.ansible', '.ansible_pos']


# Generated at 2022-06-11 09:15:38.916253
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    ansible_constructor = AnsibleConstructor()
    node = '[{a:duplicate_key}, {a:duplicate_key}]'
    assert ansible_constructor.construct_yaml_map(node) == 'mapping-duplicate-key'

# Generated at 2022-06-11 09:15:47.692192
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    '''
    Verify that the construct_yaml_unsafe method of AnsibleConstructor class
    returns the same object when retrieving it from a AnsibleMapping.
    See issue #1410

    The problem was that the object was wrapped with an AnsibleUnsafeText wrapper.
    '''
    yaml_data = to_bytes(u"---\n{unsafe_value: !unsafe 'myvalue'}")
    c = AnsibleConstructor(file_name='<string>')
    obj = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert obj.get('unsafe_value') == 'myvalue'

    if sys.version_info[0] >= 3:
        assert not isinstance(obj.get('unsafe_value'), unicode)

# Generated at 2022-06-11 09:15:58.595785
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    test_data_path = os.path.join(os.path.dirname(__file__), 'unit', 'parsing', 'yaml', 'v2_chained_data.yml')
    vault_secrets = ['topsecret1']
    with open(test_data_path, 'rb') as f:
        value = f.read()
    constructor = AnsibleConstructor(test_data_path, vault_secrets)
    node = object()
    node.start_mark = object()
    node.start_mark.column = 0
    node.start_mark.line = 0
    node.start_mark.name = test_data_path
    ansible_vault_encrypted_unicode = constructor.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-11 09:16:07.239858
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_str = '''
        foo: bar
        baz: 
            - x
            - y
    '''
    file_name = 'test_AnsibleConstructor'
    yaml_data = yaml.load(test_str, Loader=AnsibleConstructor)
    assert yaml_data['foo'] == u'bar'
    assert yaml_data['baz'][0] == u'x'
    assert yaml_data['baz'][1] == u'y'
    yaml_data_2 = yaml.load(test_str, Loader=AnsibleConstructor)
    assert yaml_data == yaml_data_2

# Generated at 2022-06-11 09:16:17.224637
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    text = "l1:\n  - item1\n  - item2\n  - item3\n"
    loader = yaml.Loader(text)
    data = loader.get_data()
    assert isinstance(data, dict)
    assert data == {u'l1': [u'item1', u'item2', u'item3']}

    # Check that ansible_pos was set on the AnsibleSequence object
    assert isinstance(data[u'l1'], AnsibleSequence)
    assert data[u'l1'].ansible_pos == (u'<unicode string>', 1, 1)

    # Check that ansible_pos was set on the AnsibleUnicode objects within the sequence

# Generated at 2022-06-11 09:16:34.930469
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import unittest

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # create a temporary file, and write the unencrypted string to it
    (tmp_fd, tmp_file_name) = tempfile.mkstemp(dir=os.getcwd())
    os.write(tmp_fd, b'This is a test')
    os.close(tmp_fd)

    # encrypt the temporary file
    vault_password = 'test1234'
    vault = VaultLib(vault_password)
    enc_file = vault.encrypt_file(tmp_file_name)

    # create an AnsibleConstructor object and use it to read the vault-encrypted file
    ac = AnsibleConstructor()
    ac.vault_secrets.append

# Generated at 2022-06-11 09:16:44.154840
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    try:
        from yaml.nodes import MappingNode
    except ImportError:
        from yaml import MappingNode

    try:
        from collections import OrderedDict
    except ImportError:
        from ansible.utils.ordereddict import OrderedDict

    def create_node(values):
        node = MappingNode(tag=u'tag:yaml.org,2002:map', value=values,
                           flow_style=False)
        return node

    def create_value(key, value):
        return (key, value)

    def create_key(key):
        # arbitrary value chosen to not conflict with the values
        # used when type(key) == scalarint, scalarfloat, scalarbool
        node = scalar

# Generated at 2022-06-11 09:16:54.198571
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-11 09:17:02.713062
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class args:
        vault_password_file = 'unused'

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    c = AnsibleConstructor(vault_secrets=[b'foo'])

    input = dict(s=dict(s1=u'v1', s2=u'v2'))
    d = AnsibleDumper(default_flow_style=True)
    s = d.encode(input)

    output = AnsibleLoader(args, vault_secrets=[b'foo']).get_single_data()
    assert output == input



# Generated at 2022-06-11 09:17:10.712176
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing import vault
    import sys
    import os
    fd, path = os.path.split(os.path.realpath(__file__))
    test_data_path = os.path.join(fd, 'test_data')
    sys.path.insert(0, test_data_path)

    from test_data.vault_data import VAULT_DATA_SECRET_1_V1, VAULT_DATA_SECRET_2_V1, VAULT_DATA_UNENCRYPTED_V1, \
        VAULT_DATA_DECRYPT_ERROR, VAULT_DATA_SECRET_1_V2, VAULT_DATA_SECRET_2_V2, VAULT_DATA_UNENCRYPTED_V2


# Generated at 2022-06-11 09:17:16.353015
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    test_constructor = AnsibleConstructor()
    node = 'tag:yaml.org,2002:str'
    value = 'some text'
    obj = AnsibleUnicode(value)

    actual_result = test_constructor.construct_yaml_unsafe(node, value)
    assert actual_result.__eq__(obj)



# Generated at 2022-06-11 09:17:25.994640
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    if sys.version_info[0] >= 3:
        from unittest import mock
    else:
        try:
            import mock
        except ImportError:
            pass

    def mock_display_warning(msg):
        assert msg.startswith('You should not see this warning in an old vaulted file.  Vault IDs')
    with mock.patch.object(display, 'warning', side_effect=mock_display_warning) as mock_display_warning:
        ac = AnsibleConstructor()
        assert isinstance(ac.construct_vault_encrypted_unicode(None), AnsibleVaultEncryptedUnicode)
    assert mock_display_warning.called

# Generated at 2022-06-11 09:17:33.763932
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:17:43.266984
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    text = """
    - a
    - b
    """
    data = yaml.load(text, Loader=AnsibleLoader)
    assert type(data) == list
    assert data[0] == 'a'
    assert data[1] == 'b'

    text = """
    - a
      b
    """
    data = yaml.load(text, Loader=AnsibleLoader)
    assert type(data) == list
    assert data[0] == 'a\n  b'



# Generated at 2022-06-11 09:17:49.423216
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    d = """
    a: 1
    b: 2
    c: 3
    d: 4
    e: 5
    """
    data = AnsibleLoader(d).get_single_data()
    assert data == {u'a': 1, u'c': 3, u'b': 2, u'e': 5, u'd': 4}

# Generated at 2022-06-11 09:17:56.711104
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass # TODO

# Generated at 2022-06-11 09:18:05.731402
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import binascii
    ansible_constructor = AnsibleConstructor()

    # Test with valid dict
    yaml_str = "ansible"
    node = "tag:yaml.org,2002:str"
    ret = ansible_constructor.construct_yaml_str(yaml_str, node)
    assert ret == "ansible"

    yaml_str = "ansible"
    node = "tag:yaml.org,2002:python/unicode"
    ret = ansible_constructor.construct_yaml_str(yaml_str, node)
    assert ret == "ansible"

    # Test with non-valid tag
    yaml_str = "ansible"
    node = "tag:yaml.org,2002:str"
    ret = ansible_constructor.construct_yaml

# Generated at 2022-06-11 09:18:15.754293
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    test_data_dir = os.path.dirname(os.path.realpath(__file__))
    workspace = os.path.join(test_data_dir, 'workspace')
    os.makedirs(workspace, exist_ok=True)
    expect_file = os.path.join(workspace, 'expect_construct_yaml_map')
    if os.path.exists(expect_file):
        os.remove(expect_file)
    loader = AnsibleLoader(None, None, None)

# Generated at 2022-06-11 09:18:16.296520
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-11 09:18:17.776588
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # TODO: create a test YAML file and load it using this
    #       constructor.
    pass

# Generated at 2022-06-11 09:18:29.108510
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    import unittest
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultEditor
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.utils.unsafe_proxy import ANSIBLE_VAULT_IDENTIFIER

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self.test_loader = None
            self.test_dumper = None

        def tearDown(self):
            pass


# Generated at 2022-06-11 09:18:35.727249
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    data = '''
foo:
  one
  two
bar:
  three
  four
'''
    construct_mapping = yaml.Loader(data).construct_mapping
    node = yaml.compose(data)
    mapping = construct_mapping(node)
    assert type(mapping) == dict
    assert mapping['foo'] == ['one', 'two']
    assert mapping['bar'] == ['three', 'four']
    assert set(mapping.keys()) == set('foo bar'.split())



# Generated at 2022-06-11 09:18:42.916996
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.nodes import AnsibleMappingNode

    # Test 1: test for normal yaml unicode
    node = AnsibleMappingNode(u'tag:yaml.org,2002:str', 'string', None, None, None)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_scalar = MockConstructScalar(u'yaml unicode')
    result = ansible_constructor.construct_yaml_str(node)
    assert isinstance(result, AnsibleUnicode)
    assert result._text == u'yaml unicode'

    # Test 2: test for normal yaml str
    node = AnsibleMappingNode(u'tag:yaml.org,2002:str', 'string', None, None, None)
    ans

# Generated at 2022-06-11 09:18:56.778228
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Answer object
    class TestJsonifierDict(AnsibleBaseYAMLObject):
        pass

    class TestJsonifierDictNode(MappingNode):

        def __init__(self, tag, value, start_mark=None, end_mark=None, flow_style=None):
            super(MappingNode, self).__init__(tag, value, start_mark, end_mark, flow_style)
            self.yaml_data = TestJsonifierDict()

    # Input object

# Generated at 2022-06-11 09:19:04.114761
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class FakeNode:
        def __init__(self, start_mark):
            self.start_mark = start_mark

        def __str__(self):
            return 'FakeNode()'

    class FakeNodeMark:
        def __init__(self, line, column):
            self.line = line
            self.column = column

        def __str__(self):
            return 'FakeNodeMark()'


# Generated at 2022-06-11 09:19:17.159172
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = '''
a:
  b: 1
  c: 2
'''
    yaml_map = dict(a=dict(b=1, c=2))
    assert isinstance(yaml_str, str)
    assert isinstance(yaml_map, dict)

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == yaml_map


# Generated at 2022-06-11 09:19:22.349882
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    def check(value_in, value_out):
        data = value_in
        ansible_constructor = AnsibleConstructor(file_name='test')
        ansible_constructor.construct_yaml_map(data)
        data = value_out

    # list of tuples (value_in, value_out)
    cases = [
        ([], [])
    ]

    for case in cases:
        check(case[0], case[1])

# Generated at 2022-06-11 09:19:28.074038
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = """
        foo: bar
        baz:
          - qux
          - quz
    """
    ac = AnsibleConstructor()
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert data == {'foo': 'bar', 'baz': ['qux', 'quz']}
    assert type(data['foo']) is AnsibleUnicode

# Generated at 2022-06-11 09:19:33.799302
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_input = u'foo: bar\nbreak: baz'
    yaml_output = AnsibleConstructor().construct_yaml_map(SafeConstructor().construct_yaml_map(yaml_input))
    assert yaml_output[u'foo'] == u'bar'
    assert yaml_output[u'break'] == u'baz'

# Generated at 2022-06-11 09:19:39.914709
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    constructor = AnsibleConstructor()
    value = constructor.construct_yaml_unsafe(None)
    assert value.is_safe
    value = constructor.construct_yaml_unsafe(datetime.datetime.now())
    assert not value.is_safe
    # This is not a Python object, so we can't evaluate it
    value = constructor.construct_yaml_unsafe(u'!config')
    assert not value.is_safe



# Generated at 2022-06-11 09:19:44.979716
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # create constructor
    ac = AnsibleConstructor()

    # test that no exception is raised if a value is passed in
    assert ac.construct_vault_encrypted_unicode('test') == 'test'

    # test that if no value is passed in, an exception is raised
    try:
        ac.construct_vault_encrypted_unicode(None)
    except AssertionError:
        pass

# Generated at 2022-06-11 09:19:53.303511
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """ Unit test for method construct_mapping of class AnsibleConstructor. """
    import yaml
    ac = AnsibleConstructor()
    test_dict = AnsibleMapping()
    test_dict["key1"] = "value1"
    test_dict["key2"] = "value2"
    test_dict["key3"] = "value3"
    test_dict["a"] = "a"
    test_dict["b"] = "b"
    test_dict["c"] = "c"
    test_dict["a"] = "aa"
    test_dict["b"] = "bb"
    test_dict["c"] = "cc"
    test_dict["a"] = "aaaa"
    test_dict["b"] = "bbbb"
    test_dict["c"] = "cccc"
    test_

# Generated at 2022-06-11 09:19:53.828849
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-11 09:20:03.145804
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    test_value = u'test message'
    vault_secrets = [ u'secret1', u'secret2' ]
    vault = VaultLib(secrets = vault_secrets)
    encrypted_value = vault.encrypt(test_value)
    test_data = { 'sansible_vault': encrypted_value }
    ansible_constructor = AnsibleConstructor(file_name = None, vault_secrets = vault_secrets)
    result = ansible_constructor.construct_vault_encrypted_unicode('unknown node object')
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 09:20:06.094167
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    s = AnsibleConstructor()
    seq1 = s.construct_yaml_seq([1, 2, 3])
    seq2 = s.construct_yaml_seq([1, 2, 3])
    assert repr(seq1) == repr(seq2)

# Generated at 2022-06-11 09:20:22.328970
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create temporary file
    tmp_fd, tmp_path = tempfile.mkstemp(prefix='ansible-tower-openstack-yaml-unittest-')
    os.close(tmp_fd)
    os.remove(tmp_path)
    # Write to the temp file
    tmp_fd = open(tmp_path, 'w')

# Generated at 2022-06-11 09:20:27.275372
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None, flow_style=False)
    ac = AnsibleConstructor()
    for i in ac.construct_yaml_map(node):
        assert isinstance(i, AnsibleMapping)



# Generated at 2022-06-11 09:20:28.204093
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass



# Generated at 2022-06-11 09:20:36.414229
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import os

    curpath = os.path.dirname(os.path.realpath(__file__))
    dumper = AnsibleDumper()

    # Test with string
    obj = ['test']
    obj_dump = dumper.represent_data(obj)
    obj_ansible = AnsibleConstructor.construct_yaml_seq(obj_dump).next()
    assert obj == obj_ansible

    # Test with dict
    obj = [{'test':{'test1':'test2'}}]
    obj_dump = dumper.represent_data(obj)
    obj_ansible = AnsibleConstructor.construct_yaml_seq(obj_dump).next()
    assert obj == obj_ansible

   

# Generated at 2022-06-11 09:20:44.192463
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib

    # Constructor is called with one argument so its instance attribute
    # vault_secrets needs to be set to avoid calling VaultLib with no arguments
    # and the call of VaultLib to raise an exception.
    test_constructor = AnsibleConstructor(vault_secrets=[])
    test_constructor._vaults["default"] = VaultLib(secrets=test_constructor.vault_secrets)

    # The safe constructor raises an exception if the object is not a node.
    test_object = object
    try:
        test_constructor.construct_yaml_unsafe(test_object)
        assert False, "test_AnsibleConstructor_construct_yaml_unsafe failed."
    except AttributeError:
        pass

    # In case the object is a

# Generated at 2022-06-11 09:20:47.626328
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:str', value=u'hello', start_mark=None, end_mark=None)
    assert ac.construct_yaml_str(node).__class__ is AnsibleUnicode
    assert ac.construct_yaml_str(node) == u'hello'

# Generated at 2022-06-11 09:20:55.591621
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    key_value = {'a': 'A', 'b': 'B'}
    key_node = 'a'
    value_node = 'A'

    ansible_constructor = AnsibleConstructor()
    yaml_map = '{"a": "A", "b": "B"}'
    node = yaml.compose(yaml_map)

    a_mapping = ansible_constructor.construct_yaml_map(node)

    assert isinstance(a_mapping, AnsibleMapping)
    assert a_mapping == key_value
    assert not deepdiff.DeepDiff(a_mapping, key_value)



# Generated at 2022-06-11 09:21:01.714334
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os, tempfile
    temp = tempfile.NamedTemporaryFile(delete=False, mode='w')
    temp_name = temp.name
    temp.write('{"a":"b", "a": "c"}')
    temp.close()
    with open(temp_name, 'r') as yaml_file:
        test_constructor = AnsibleConstructor()
        test_constructor.construct_yaml_map(yaml_file)
        os.remove(temp_name)



# Generated at 2022-06-11 09:21:08.023898
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    this_module = sys.modules[__name__]
    class_AnsibleConstructor = getattr(this_module, 'AnsibleConstructor')
    construct_yaml_map_method = getattr(class_AnsibleConstructor, 'construct_yaml_map')
    node = None
    construct_yaml_map_result = construct_yaml_map_method(node)
    assert construct_yaml_map_result is None
    assert callable(construct_yaml_map_result)


# Generated at 2022-06-11 09:21:19.285344
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.plugin_docs import read_docstring
    add_all_plugin_dirs()

    datastring = b'''
    - !unsafe
      - !!python/tuple [1, 2]
    '''
    try:
        constructed_data = yaml.load(datastring, Loader=AnsibleConstructor)
    except yaml.error.YAMLError:
        constructed_data = None
    expected_data = [[wrap_var((1, 2))]]
    assert constructed_data == expected_data



# Generated at 2022-06-11 09:21:29.525806
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    input_data = [1, 2, 3, 'data']

    result = AnsibleConstructor.construct_yaml_seq(input_data)

    assert result == [1, 2, 3, 'data']

# test for method construct_mapping  of class AnsibleConstructor

# Generated at 2022-06-11 09:21:38.321184
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class MockConstructor():
        def __init__(self):
            self.vault_secrets = ['vault_secret']
            self.vaults = {}

    mock_constructor = MockConstructor()

# Generated at 2022-06-11 09:21:47.702747
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    lines = [
        '- anaconda',
        ' - bnconda',
        '- cnconda',
        ' - dnconda',
        ' ']
    lines = [to_bytes(x, encoding=None) for x in lines]
    data = to_bytes('\n'.join(lines), encoding=None)

    # Uncomment this to see the data used for the test
#     print('\n'.join(lines))

    yaml = AnsibleConstructor(file_name="test_construct_yaml_seq_file")

    result = yaml.construct_yaml_seq(yaml.compose_all(data))


# Generated at 2022-06-11 09:21:57.438037
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = u'secret'
    vault = VaultLib(secrets=[vault_password])
    secret = u'password: foo'
    b_ciphertext_data = vault.encrypt(to_bytes(secret))
    node = u'!vault-encrypted |\n%s' % vault.delimiters[0] + to_native(b_ciphertext_data) + vault.delimiters[1] + u'\n...'
    data = yaml.load(node, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert not isinstance(data, AnsibleUnicode)
    assert isinstance(data.vault, VaultLib)
    assert data.vault == vault
    assert data == b_ciphertext

# Generated at 2022-06-11 09:22:06.132405
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:22:16.595971
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    text = u'a: 1\nb: 2\n'
    data = yaml.load(text)
    assert isinstance(data, dict)
    assert isinstance(data['a'], int)
    assert isinstance(data['b'], int)

    text = u'a: 1\nb: 2\nd: c\n'
    data = yaml.load(text)
    assert isinstance(data, dict)
    assert isinstance(data['a'], int)
    assert isinstance(data['b'], int)
    assert isinstance(data['d'], AnsibleUnicode)

    text = u'a: 1\nb: 2\nc: \'c\'\n'
    data = yaml

# Generated at 2022-06-11 09:22:29.670627
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.config.data import load_yaml_config_file

    # we need to avoid self.construct_yaml_map, which constructs an
    # AnsibleMapping instance and not a normal dict
    # AnsibleConstructor._construct_mapping is the private method
    # which is used by construct_yaml_map

    # test the case where we have an empty list
    test_empty_list = AnsibleConstructor._construct_mapping({})
    assert isinstance(test_empty_list, AnsibleMapping)
    assert test_empty_list == {}
    test_empty_list_with_keys = AnsibleConstructor._construct_mapping({'lookup_plugin': 'dig', 'set_fact': 'ansible_user'})
    assert 'lookup_plugin' in test_empty_list_with_keys


# Generated at 2022-06-11 09:22:34.669875
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = u'''
    a: 1
    b: 2
    c: 3
    '''
    expected_result = {u'a': 1, u'b': 2, u'c': 3}
    result = AnsibleConstructor(file_name=u'<string>').construct_mapping(yaml.compose(yaml_str))
    assert result == expected_result


yaml.add_multi_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)

# Generated at 2022-06-11 09:22:45.316035
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test = dict()

    for order in ['key-application-order', 'key-item-order', 'key-order-changed']:
        for dupe in ['duplicates', 'no-duplicates']:
            for data_structure in ['dict', 'OrderedDict']:
                for construct in ['dict-order-preserved', 'dict-order-randomized']:
                    if dupe == 'duplicates':
                        testdata = {'v11': {'name': 'test11', 'value': 'v11'},
                                    'v12': {'name': 'test12', 'value': 'v12'},
                                    'v21': {'name': 'test21', 'value': 'v21'},
                                    'v22': {'name': 'test22', 'value': 'v22'}}
                   

# Generated at 2022-06-11 09:22:50.377526
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = AnsibleSequence()
    data.extend([1,2])
    data.ansible_pos = ("1", 2, 3)
    assert(data.ansible_pos == ("1", 2, 3))
    assert(list(data) == [1,2])

# Generated at 2022-06-11 09:23:11.513244
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import ansible.units.bytes.decrypt
    import ansible.units.bytes.encrypt

    # Init a vault lib instance with a specified password
    secret = "mypassword"
    vault = VaultLib(secrets=[secret])
    vault.update({"my_secret": "This is my secret text"})
    vault_variable = vault.dump()

    # Init an AnsibleConstructor instance with the password
    ac = AnsibleConstructor(vault_secrets=[secret])

    # Node is the value from the AnsibleVaultEncryptedUnicode.data
    node = {'tag': 'tag:yaml.org,2002:python/bytes', 'value': vault_variable}

    # The output is an AnsibleVaultEncryptedUnicode object.
    result = ac.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-11 09:23:21.445923
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ["1234567890qwertyuio", ]
    ansibleconstructor = AnsibleConstructor(vault_secrets=vault_secrets)
    node1 = '!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          65306433396630636537303536346164376335363532376438336664336134626235653762363138\n          31666433613836386538376161643633643736613331323461353831333238316236633036316530\n          32373361623635333133376234376461363837333636633362373231653339366461643862616365\n          3734666366333564\n          '


# Generated at 2022-06-11 09:23:30.177019
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    data = '''
---
- !vault |
          $ANSIBLE_VAULT;1.1;AES256
          35383761613232636563323661396331343639376132333736336633366530386130393637613339
          34663738393035383337666233643333633638353033353661303231666337613666666262373265
          6163636463386330366565313735323635313230383933313431316562613065
    w: x
- !unsafe '''

    data_loaded = yaml.load(data, Loader=AnsibleConstructor)
    data_loaded[1].should.be.equal(True)

# Generated at 2022-06-11 09:23:38.744579
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import ansible

    # Wrap ansible.constants.DEFAULT_VAULT_PASSWORD_FILE in a getter to allow mocking of the user home directory
    import ansible.constants

    # ansible.constants is a module, so changing the value of its DEFAULT_VAULT_PASSWORD_FILE won't persist
    # if we do this in a unit test, due to the way python handles imports, so we wrap it in a method instead
    def get_default_vault_password_file():
        return ansible.constants.DEFAULT_VAULT_PASSWORD_FILE

    # Wrap ansible.constants.DEFAULT_VAULT_ID_MATCH in a getter to allow mocking of the user home directory

# Generated at 2022-06-11 09:23:47.772432
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.vars import BaseVarsPlugin
    # For some reason we can't directly use class AnsibleConstructor above.  The string !unsafe is
    # not added to yaml.SafeContructor.yaml_constructors.  So we have to create a subclass of AnsibleConstructor
    # and add !unsafe to yaml_constructors.
    class SubAnsibleConstructor(AnsibleConstructor):
        yaml_constructors = AnsibleConstructor.yaml_constructors.copy()
        yaml_constructors.update({u'!unsafe': AnsibleConstructor.construct_yaml_unsafe})


# Generated at 2022-06-11 09:23:52.548888
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    if sys.version_info[0] < 3:
        assert AnsibleConstructor.construct_yaml_str("node") == "node"
    else:
        assert AnsibleConstructor.construct_yaml_str("node") == u"node"

# Generated at 2022-06-11 09:23:56.584395
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # str_var is a yaml representation of a string
    str_var = u'hello, world'
    y = AnsibleConstructor.construct_yaml_str(None, str_var)
    assert y.data == str_var



# Generated at 2022-06-11 09:24:06.553359
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import unittest
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class AnsibleConstructorAnsibleConstructor_construct_yaml_seq(unittest.TestCase):
        def test_AnsibleConstructor_construct_yaml_seq_list(self):
            expected = [
                {
                    "name": "John",
                    "age": 27,
                    "sex": 'Male',
                    "country": "USA"
                }
            ]
            data = """
                    - name: John
                      age: 27
                      sex: Male
                      country: USA
                    """
            yaml_obj = yaml.load(data, Loader=AnsibleConstructor)

# Generated at 2022-06-11 09:24:09.490310
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    test_node = {}
    assert ansible_constructor.construct_mapping(test_node) == {}

# Generated at 2022-06-11 09:24:17.714150
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping

    file_name = "test_yaml_constructor.yml"
    data = """
foo: bar
baz:
- "one"
- 2
- 3
bam:
  fuu: bar
  baz:
  - "one"
  - 2
  - 3
"""
    x = AnsibleMapping(ansible_pos=(file_name, 3, 1))
    x["foo"] = "bar"
    x["baz"] = AnsibleSequence([
        "one",
        2,
        3
    ], ansible_pos=(file_name, 6, 3))

# Generated at 2022-06-11 09:24:46.815072
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.lib.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Here i want to generate a AnsibleVaultEncryptedUnicode object instead of AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:24:54.500483
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from units.mock.loader import DictDataLoader
    from ansible.parsing.yaml.loader import AnsibleLoader

    # "import os" runs when the module is imported, not when these tests are run
    # (since unit tests are run from the command line), so we do it manually
    # here so that the os module has the correct values for these tests
    import os
    import sys
    os_path = os.path
    sys_executable = sys.executable

    mock_data = """
    - host: localhost
      tasks:
        - name: winshell
          win_shell: "{{ cmd }}"
    """

    yaml_data = """
    - host: localhost
      tasks:
        - name: winshell
          win_shell: !unsafe cmd
    """

    # Test where we return

# Generated at 2022-06-11 09:25:04.595346
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import unittest
    import yaml

    class TestAnsibleConstructor(unittest.TestCase):

        def test_seq_constructor_return_type(self):
            # Use the test data from issue #21839 as a test case
            input_text = u"""[ some,
   test,
   data,
   here]
"""
            constructor = AnsibleConstructor()
            data = yaml.load(input_text, Loader=yaml.BaseLoader)
            self.assertIsInstance(data, AnsibleSequence)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestAnsibleConstructor)
    unittest.TextTestRunner(verbosity=2).run(suite)
