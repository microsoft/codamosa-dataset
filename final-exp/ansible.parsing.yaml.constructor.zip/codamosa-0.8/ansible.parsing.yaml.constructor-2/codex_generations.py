

# Generated at 2022-06-11 09:15:17.575014
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml import _load_unsafe_yaml

    text = '''
foo: bar
baz:
  - a: 1
    b: 2
    c: 3
  - d: 4
    e: 5
    f: 6
'''

    doc = _load_unsafe_yaml(text)

    assert isinstance(doc, AnsibleMapping)
    assert isinstance(doc['foo'], AnsibleUnicode)
    assert isinstance(doc['baz'], AnsibleSequence)

    outer = doc['baz']
    assert isinstance(outer, AnsibleSequence)

    for x in outer:
        assert isinstance(x, AnsibleMapping)
        assert isinstance(x['a'], AnsibleUnicode)

# Generated at 2022-06-11 09:15:22.235635
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    mapping = u'{a: 1, b: 2, c: 3}'
    ansible_mapping = AnsibleConstructor().construct_yaml_map(mapping)
    assert type(ansible_mapping) == AnsibleMapping
    assert ansible_mapping == dict(a=1, b=2, c=3)



# Generated at 2022-06-11 09:15:26.580909
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    f = 'construct_yaml_str'
    s = 'hello world'
    w = AnsibleConstructor()
    r = w.construct_yaml_str(s)
    e = AnsibleUnicode(s)
    assert r == e, '%s: Expected %s == %s, got %s != %s' % (f, s, e, r, e)


# Generated at 2022-06-11 09:15:34.420215
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class DummyConstructor(SafeConstructor):
        def construct_scalar(self, node):
            return 'construct_scalar return value'

    class DummyNode(object):
        def __init__(self):
            self.start_mark = AttrDict(name='start_mark name', line=1, column=2)
            self.id = 'id'

    dummy_node = DummyNode()
    dummy_constructor = DummyConstructor()
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_scalar = dummy_constructor.construct_scalar

    ansible_str = ansible_constructor.construct_yaml_str(dummy_node)
    assert 'construct_scalar return value' == ansible_str


# Generated at 2022-06-11 09:15:38.578918
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    yaml_string = """
- [host1, host2]
- - group1
  - group2
    """

    obj = yaml.load(yaml_string, Loader=AnsibleConstructor)
    #obj[0] is a list
    assert obj[0][0] == 'host1'

# Generated at 2022-06-11 09:15:47.420232
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 09:15:50.880396
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ac = AnsibleConstructor(None, [])
    node = MappingNode(u'', [], [], True, None, None, None)
    list(ac.construct_yaml_map(node))

# Generated at 2022-06-11 09:16:01.096230
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret

    class MockVaultLib(object):
        def encrypt(self, data, raw=False):
            return data

        def decrypt(self, data, vault_version=0):
            return data

        def is_encrypted(self, data):
            return False

        def is_encrypted_with_secret(self, data, secret):
            return False

    vault_password = b'password'
    vault_secrets = [VaultSecret(vault_password)]
    vault_lib = MockVaultLib()


# Generated at 2022-06-11 09:16:11.865461
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Prepare the yaml data
    # the vault secret for vault id 'default' is 'asdfasfd'

# Generated at 2022-06-11 09:16:21.114945
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class AnsibleConstructorTest(AnsibleConstructor):
        def __init__(self):
            super(AnsibleConstructorTest, self).__init__()
            self.construct_scalar = self.test_construct_scalar


# Generated at 2022-06-11 09:16:38.187288
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    from ansible.constants import mk_boolean

    my_constructor = AnsibleConstructor()
    assert my_constructor.construct_yaml_unsafe(u'foo') == u'foo'
    assert my_constructor.construct_yaml_unsafe(42) == 42
    assert my_constructor.construct_yaml_unsafe(['foo', 'bar']) == ['foo', 'bar']
    assert my_constructor.construct_yaml_unsafe({'foo': 'bar', 'baz': ['qux', 'corge']}) == {'foo': 'bar', 'baz': ['qux', 'corge']}

# Generated at 2022-06-11 09:16:39.799244
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # a = utils.AnsibleConstructor()
    assert False


# Generated at 2022-06-11 09:16:43.982266
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Arrange
    # noinspection PyTypeChecker
    constructor = AnsibleConstructor(file_name='/etc/file')
    node = 'YWJj'
    node.start_mark = 'node_start'

    # Act
    result = constructor.construct_vault_encrypted_unicode(node)

    # Assert
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 09:16:54.004271
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:17:03.995849
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    secrets = ["ansible"]
    nodes = []

# Generated at 2022-06-11 09:17:11.534315
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import json
    import unittest

    class AnsibleConstructorConstructMappingTest(unittest.TestCase):
        def test_warn_duplicate_yaml_dict_key(self):
            from io import StringIO
            from ansible.utils.display import Display
            from ansible.parsing.yaml.loader import AnsibleLoader

            display = Display()
            text = u'{"a":1,"a":2}'

            buf = StringIO()
            save_stdout = sys.stdout
            sys.stdout = buf


# Generated at 2022-06-11 09:17:23.743400
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    display.verbosity = 3
    assert display.verbosity > 2, "Unit tests require verbose mode."
    aconstructor = AnsibleConstructor()
    data = aconstructor.construct_yaml_unsafe(None)
    assert data is None, "None was expected as data"
    data = aconstructor.construct_yaml_unsafe("")
    assert isinstance(data, UnsafeProxy),\
            "UnsafeProxy was expected as data but got %s" % type(data)
    assert data.value == "", "Empty string was expected as data"
    data = aconstructor.construct_yaml_unsafe("test")

# Generated at 2022-06-11 09:17:31.405948
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    assert AnsibleConstructor.construct_yaml_unsafe(None).unwrap() is None
    assert AnsibleConstructor.construct_yaml_unsafe(0).unwrap() == 0
    assert AnsibleConstructor.construct_yaml_unsafe(False).unwrap() is False
    assert AnsibleConstructor.construct_yaml_unsafe("foo").unwrap() == "foo"
    assert AnsibleConstructor.construct_yaml_unsafe("!foo").unwrap().unwrap() == "!foo"
    assert AnsibleConstructor.construct_yaml_unsafe("!foo").unwrap().unwrap() == "!foo"
    assert AnsibleConstructor.construct_yaml_unsafe("!foo").unwrap().unwrap() == "!foo"

# Generated at 2022-06-11 09:17:38.977918
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    mock_node = MagicMock()
    mock_node.start_mark.line = 1
    mock_node.start_mark.column = 2
    mock_node.start_mark.name = 'test.yml'

    mock_node.value = [
        (Mock(id='key_node'), Mock(id='value_node'))
    ]

    construct_mapping = AnsibleConstructor.construct_mapping
    value = construct_mapping(AnsibleConstructor, mock_node, deep=False)

    assert value.ansible_pos == ('test.yml', 2, 3)

# Generated at 2022-06-11 09:17:50.668331
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # This test should test the following code
    # def construct_yaml_map(self, node):
    #     data = AnsibleMapping()
    #     yield data
    #     value = self.construct_mapping(node)
    #     data.update(value)
    #     data.ansible_pos = self._node_position_info(node)

    # Use the module utils loader function to create an object to test
    from ansible.parsing import ds as pds
    ds = pds.DataLoader()

    datalist = [
        '''
        ---
        - hosts:
          - 127.0.0.1
        ''',
    ]

    for data in datalist:
        test_data = ds.load(data)
        assert type(test_data) is AnsibleMapping

# Generated at 2022-06-11 09:18:09.805271
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Unit tests for method construct_yaml_map of class AnsibleConstructor.
    #
    # Args:
    #     file_name=None: The file name or datasource of the data.
    #     vault_secrets=None: The vault secrets to use.
    # Returns:
    #     The constructed object.
    # Raises:
    #     ConstructorError: If constructor error is raised
    try:
        obj = AnsibleConstructor()
        node = MappingNode()
        result = obj.construct_yaml_map(node)
        assert True
    except ConstructorError as e:
        assert False



# Generated at 2022-06-11 09:18:19.391639
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()
    constructor.add_constructor(u'!unsafe', constructor.construct_yaml_unsafe)
    constructor.add_constructor(u'!vault', constructor.construct_vault_encrypted_unicode)
    constructor.add_constructor(u'!vault-encrypted', constructor.construct_vault_encrypted_unicode)
    data = """
    a: [
      {
         b: !unsafe 1
      }
    ]
    """
    d = yaml.load(data, Loader=AnsibleConstructor)
    assert d == {'a': [{'b': 1}]}

    data = """
    a: [
      {
         b: !unsafe "1"
      }
    ]
    """

# Generated at 2022-06-11 09:18:30.751856
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os
    import textwrap
    import sys
    import tempfile
    import pytest
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedFile

    (fd, fn) = tempfile.mkstemp()


# Generated at 2022-06-11 09:18:39.414029
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # test cases should cover the different characteristics of the ciphertext
    # ciphertext may be padded or not padded
    # ciphertext may have embedded new lines or not
    # ciphertext may have yaml comments at the end or not
    # ciphertext may be hexlified or not
    # ciphertext may have a vault_id, if vault_id is equal to default, it should be ignored
    # if vault_id is not equal to default, it should be processed
    # expects to be able to decrypt the ciphertext from ansible-vault
    # expects to be able to generate the same ciphertext from ansible-vault
    # expects to be able to decrypt the ciphertext from ansible-vault with a vault_id
    pass

# Generated at 2022-06-11 09:18:53.300245
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import copy
    # Test construction
    value = ""
    b_ciphertext_data = to_bytes(value)
    # could pass in a key id here to choose the vault to associate with
    # TODO/FIXME: plugin vault selector
    vault = VaultLib(secrets=None)
    if vault.secrets is None:
        raise ConstructorError(context=None, context_mark=None,
                               problem="found !vault but no vault password provided",
                               problem_mark=None,
                               note=None)
    ret = AnsibleVaultEncryptedUnicode(b_ciphertext_data)
    ret.vault = vault
    ret.ansible_pos = None
    node = copy.deepcopy('ret')

# Generated at 2022-06-11 09:19:02.789972
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # testing to see if the dictionary returned by this method is equivalent to a python dictionary
    import yaml
    from .datatype import AnsibleUnsafeText

    ansible_yaml_dictionary = """
    key: value
    key2: 5
    key3: {'dict': 'yes!'}
    key4:
      - one
      - two
      - three
    """
    yaml_dictionary = """
    key: value
    key2: 5
    key3: {'dict': 'yes!'}
    key4:
      - one
      - two
      - three
    """

    # ensure equivalent yaml documents are loaded as equivalent python dictionaries
    assert (yaml.safe_load(ansible_yaml_dictionary) == yaml.safe_load(yaml_dictionary))

    # ensure the

# Generated at 2022-06-11 09:19:04.583424
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    c = AnsibleConstructor()
    assert c.construct_yaml_seq('dummy') == None


# Generated at 2022-06-11 09:19:09.331805
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    seq_sample1 = yaml.nodes.SequenceNode(tag = u'tag:yaml.org,2002:seq', value = [], flow_style = False)
    ac = AnsibleConstructor()
    res = ac.construct_yaml_seq(node = seq_sample1)
    assert type(res) == AnsibleSequence


# Generated at 2022-06-11 09:19:19.053552
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Will create a 1-vault instance and load 'welcome1' password
    ac = AnsibleConstructor(file_name=None, vault_secrets=['welcome1'])

# Generated at 2022-06-11 09:19:29.063428
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import os
    import StringIO
    # Set up some objects we'll need
    test_seq = [1,2,3]
    test_yaml_str = '---\n- 1\n- 2\n- 3\n'
    test_yaml_file_path = './test_AnsibleConstructor_construct_yaml_seq'
    test_yaml_file = open(test_yaml_file_path, 'w+')
    test_yaml_file.write(test_yaml_str)
    test_yaml_file.seek(0)
    test_safe_constructor = SafeConstructor(test_yaml_file_path)
    test_ansible_constructor = AnsibleConstructor(test_yaml_file_path)

    # Inject the test_safe

# Generated at 2022-06-11 09:19:52.664946
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml import objects

    # test empty string
    yaml_str = objects.AnsibleUnicode()
    yaml_str.ansible_pos = ""
    a = AnsibleConstructor()
    assert a.construct_yaml_str(yaml_str) == u''

    # test unicode
    assert a.construct_yaml_str(u'hell\xf8\u20ac') == u'hell\ufffd\u20ac'

    # test AnsibleUnicode type
    yaml_str = AnsibleUnicode('hell\xf8\u20ac')
    yaml_str.ansible_pos = ""

# Generated at 2022-06-11 09:20:02.459437
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test the content of seq
    loader = AnsibleLoader(stream="""
        - A
        - B
        - C
    """, file_name='<string>', vault_secrets=[])
    construct = loader.get_single_data()
    assert construct == AnsibleSequence(['A', 'B', 'C'])

    # Test the content of seq with new lines
    loader = AnsibleLoader(stream="""
        - A
        - B
        - 
          - E
          - F
        - C
    """, file_name='<string>', vault_secrets=[])
    construct = loader.get_single_data()
    assert construct == Ans

# Generated at 2022-06-11 09:20:04.038942
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_const = AnsibleConstructor()
    ansible_const.construct_yaml_seq()



# Generated at 2022-06-11 09:20:10.855229
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    import yaml

    test_yaml = u'''
      - name: foo
        description: |
          Test description
    '''
    data = yaml.load(test_yaml, Loader=AnsibleConstructor)
    assert data[0]['description'].__class__ == AnsibleUnicode

    data = yaml.load(test_yaml, Loader=yaml.SafeLoader)
    assert data[0]['description'].__class__ == str


# Generated at 2022-06-11 09:20:19.296558
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        def setUp(self):
            import yaml
            self.yaml = yaml
            self.str = 'string'
            self.node = self.yaml.nodes.ScalarNode('tag:yaml.org,2002:str', self.str)
            self.ac = AnsibleConstructor()

        def tearDown(self):
            self.yaml.SafeLoader.add_constructor(u'tag:yaml.org,2002:str', self.yaml.SafeConstructor.construct_yaml_str)


# Generated at 2022-06-11 09:20:20.750936
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    foo = {'foo': 'bar'}
    assert(foo == wrap_var(foo))



# Generated at 2022-06-11 09:20:31.231942
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os

    class TestAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return '<unsafe>%s</unsafe>' % self.construct_scalar(node)

    # This is a test case where the object is expected to be encrypted when
    # it's read it from the YAML file.
    input_data = """---
# comments!
a: "{{x}}"
# another comment
b: '{{y}}'
...
"""
    input_file = 'test_AnsibleConstructor_construct_yaml_unsafe_input.yml'
    with open(input_file, 'w') as f:
        f.write(input_data)



# Generated at 2022-06-11 09:20:34.017619
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class UnitTestAnsibleConstructor(AnsibleConstructor):
        def construct_python_str(self, node):
            return 'test'

    assert UnitTestAnsibleConstructor().construct_yaml_str('node') == AnsibleUnicode('test')

# Generated at 2022-06-11 09:20:40.100809
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    data = u"""
foo: The first text entry
bar: The second text entry
foo: The third text entry
"""
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, dict)
    assert isinstance(yaml_obj[u'foo'], AnsibleUnsafeText)
    assert yaml_obj[u'foo'] == u'The third text entry'
    assert yaml_obj[u'bar'] == u'The second text entry'

# Generated at 2022-06-11 09:20:45.716032
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    config = """
        - mystring: 'example'
        - myunicode: ëxample
    """
    assert isinstance(yaml.safe_load(config)['mystring'], str)
    assert isinstance(yaml.load(config, Loader=AnsibleConstructor)['mystring'], AnsibleUnicode)
    assert isinstance(yaml.load(config, Loader=AnsibleConstructor)['myunicode'], AnsibleUnicode)

# Generated at 2022-06-11 09:21:17.071240
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass



# Generated at 2022-06-11 09:21:25.967322
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile

    from ansible.parsing.yaml.loader import AnsibleLoader

    # Need a temporary filename to write vault password
    temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    temp_file.write('testing')
    temp_file.close()

    # Create a vault string with the password, then try to decrypt it
    vault_password = 'testing'
    test_string = 'hello world'

    vault = VaultLib()
    ciphertext = vault.encrypt(to_bytes(test_string))
    ciphertext_str = u'!vault |\n  $ANSIBLE_VAULT;1.1;AES256;' + ciphertext.decode('utf-8')


# Generated at 2022-06-11 09:21:28.598781
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ret = AnsibleConstructor().construct_yaml_str('foo')
    assert isinstance(ret, AnsibleUnicode)
    assert ret == 'foo'

# Generated at 2022-06-11 09:21:37.488734
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile

    # Set up an environment where the test construct_vault_encrypted_unicode
    # will run. Since we don't want to mess with any existing configuration
    # we save the old environment and restore it afer the test run.
    old_dir = os.path.dirname(__file__)
    old_vault_password_file = os.environ.get(C.VAULT_PASSWORD_FILE_ENV_VAR, None)

    temp_dir = tempfile.mkdtemp()
    vault_password_file = os.path.join(temp_dir, "vault.txt")
    with open(vault_password_file, "w") as f:
        f.write("secret")

# Generated at 2022-06-11 09:21:46.259053
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    data = """
---
key1: value1
key2: value2
key2: value3
...
"""
    parser = AnsibleConstructor()
    parsed_data = yaml.load(data, Loader=yaml.Loader)
    assert parsed_data['key2'] == 'value3'
    data = """
---
key1: value1
key2: value2
key2: value3
...
"""
    C.DUPLICATE_YAML_DICT_KEY = 'error'
    try:
        parsed_data = yaml.load(data, Loader=yaml.Loader)
        assert False, 'Yaml data dictionary should not contain duplicate keys'
    except yaml.constructor.ConstructorError:
        pass

    C.DUPLICATE_YAML_D

# Generated at 2022-06-11 09:21:56.460911
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    print("Testing method construct_yaml_seq of class AnsibleConstructor")
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import io
    import os
    import tempfile
    ac = AnsibleConstructor()
    test_yaml = u'[1, 2, 3, 4, 5]\n'
    stream = io.StringIO(test_yaml)
    test_file = stream.fileno()
    fd1, t_file = tempfile.mkstemp(suffix='.rolo')
    os.write(fd1, stream.encode("utf-8"))
    os.close(fd1)
    test_data = ac.construct_yaml_seq(ac.construct_yaml_stream(t_file))
    res = []

# Generated at 2022-06-11 09:21:58.875682
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    mapping = {"test": "value"}
    assert mapping == AnsibleConstructor.construct_yaml_map(MappingNode(u'tag:yaml.org,2002:map', mapping))

# Generated at 2022-06-11 09:22:04.208781
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    print('\nTEST: construct_mapping()')
    import yaml
    yaml_str = '''
        a: 1
        b: 2
        d: 9
        c: 3
        a: 4
    '''
    print('YAML string: %s' % yaml_str)
    obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    print('Result: %s' % obj)



# Generated at 2022-06-11 09:22:08.631300
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    sn = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'hello world')
    v = ac.construct_yaml_str(sn)
    assert isinstance(v, AnsibleUnicode)
    assert v == 'hello world'
    assert v.ansible_pos == (None, 0, 0)


# Generated at 2022-06-11 09:22:18.706167
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # set constants.DEFAULT_VAULT_PASSWORD_FILE to directory containing Vault password file,
    # and constants.DEFAULT_VAULT_PASSWORD_FILE the name of Vault password file
    vault_password = u'$ANSIBLE_VAULT;1.1;AES256\na"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    node = SafeConstructor.construct_yaml_str(None, vault_password)
    vault = AnsibleConstructor._vaults['default']
    encrypted = AnsibleConstructor.construct_vault_encrypted_unicode(None, node)
    decrypted = vault.decrypt(encrypted)

# Generated at 2022-06-11 09:23:27.904561
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    value = AnsibleConstructor().construct_mapping(node)
    assert isinstance(value, dict)


# Generated at 2022-06-11 09:23:36.853829
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.compat.tests import unittest

    ansible_constructor = AnsibleConstructor()

    class TestMappingNode(MappingNode):
        def __init__(self, line, column, value):
            MappingNode.__init__(self, u'tag:yaml.org,2002:map', value,
                                 start_mark=None, end_mark=None, flow_style=None)
            self.start_mark = type('Mark', (object,), {'column': column, 'line': line, 'name': None})
            self.end_mark = self.start_mark

    class TestConstructorError(ConstructorError):
        def __init__(self, problem, problem_mark):
            self.problem = problem
            self.problem_mark = problem_mark


# Generated at 2022-06-11 09:23:44.672110
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Verify that the wrap_var() and AnsibleUnsafeText are applied when
    # the tag !unsafe is present and when the string returned from
    # self.construct_scalar() is a plain unicode() object.
    ac = AnsibleConstructor(u'')
    ac.construct_scalar = MagicMock(name='construct_scalar', return_value=u'bar')
    ansible_unsafe_text = ac.construct_yaml_unsafe(Mock())
    ac.construct_scalar.assert_called_once_with(Mock())
    assert not isinstance(ansible_unsafe_text, unicode)
    assert type(ansible_unsafe_text)  is str


# Generated at 2022-06-11 09:23:56.784585
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    test_cases = [
        {
            "name": "empty",
            "data": "",
        },
        {
            "name": "string one",
            "data": "string",
        },
        {
            "name": "string two",
            "data": "string two",
        },
        {
            "name": "string with special chars",
            "data": "string \t\f\n\r\v",
        },
        {
            "name": "string with utf8 char",
            "data": u"string with utf8 char ë",
        },
    ]

    for test_case in test_cases:
        data = yaml.load(test_case['data'], Loader=AnsibleConstructor)

# Generated at 2022-06-11 09:24:01.761896
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    x = '''
- 1
- 2
- 3
'''
    y = yaml.load(x, Loader=AnsibleConstructor)
    assert(isinstance(y, AnsibleSequence))
    assert(y[2] == 3)



# Generated at 2022-06-11 09:24:06.781162
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    tc_test_data = [("test_const", "test_variable")]
    for i, tf in (tc_test_data):
        cf = AnsibleConstructor()
        print("Executing test for " + str(tf))
        result = cf.construct_mapping(tf)
        print("Result: " + str(result))
        assert isinstance(result, dict)

# Generated at 2022-06-11 09:24:15.755793
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    class TestException(Exception):
        pass

    node = yaml.nodes.MappingNode([], [])

    data = {
        u'key1': u'value1',
        u'key2': u'value2',
        u'key3': u'value3',
    }

    def construct_object(self, node, deep=False):
        if node.id == u'yaml.org,2002:str':
            node.value = data.popitem()
            key_node = node
            value_node = node
            return key_node, value_node
        else:
            raise TestException(u'Unexpected node: %s' % node)

    node.construct_object = construct_object

    ac = AnsibleConstructor()
    m = ac.construct_mapping(node)

# Generated at 2022-06-11 09:24:20.781170
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """
    assert that for a python/unicode node, construct_yaml_unsafe does wrap the value with wrap_var
    """
    data = to_bytes(u'foo\nbar\nbaz')

    class test_node:
        pass

    node = test_node()
    node.id = 'python/unicode'

    constructor = AnsibleConstructor.construct_yaml_unsafe
    value = constructor(node, data)

    assert value is not data
    assert value == data

# Generated at 2022-06-11 09:24:29.764749
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import json


# Generated at 2022-06-11 09:24:36.748913
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.resolver import Resolver

    yaml_str = '''
        - first
        - second
        - third
    '''

    parser = Parser(yaml_str)
    resolver = Resolver()
    composer = Composer(parser, resolver)
    node = composer.get_node()
    base_node_items = node.items[:]
    ac = AnsibleConstructor()

    seq_node = ac.construct_yaml_seq(node)

    assert isinstance(seq_node, list)
    assert len(seq_node) == 1
    assert isinstance(seq_node[0], AnsibleSequence)

    ansible_seq = seq_node[0]