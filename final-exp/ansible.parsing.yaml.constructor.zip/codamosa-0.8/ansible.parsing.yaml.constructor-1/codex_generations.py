

# Generated at 2022-06-11 09:15:12.815519
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    file_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + "/test/ansible_constructor.yml"
    yaml_data = open(file_path).read()
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    print(data)
# test_AnsibleConstructor_construct_mapping()


# Generated at 2022-06-11 09:15:23.336635
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test for correct behavior when duplicate keys are found
    for duplicate_yaml_dict_key in set(C.DUPLICATE_YAML_DICT_KEY_ALLOWED_VALUES):
        C.DUPLICATE_YAML_DICT_KEY = duplicate_yaml_dict_key
        yaml_str = "foo: bar\nfoo: baz\n"
        AnsibleConstructor._yaml = None

# Generated at 2022-06-11 09:15:24.775195
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    source = AnsibleConstructor()
    result = source.construct_yaml_str(None)
    assert result is None

# Generated at 2022-06-11 09:15:33.265599
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:15:42.469468
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [b'pass']
    test_value = u'$ANSIBLE_VAULT;1.1;AES256\n34356333623530366538663365346238626437383733653039386463666433623130383935313037\n37633034373866623037663637326637613861316262633066626632343565393533386438653661\n653734363338656632386536\n'
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    ans_value = constructor.construct_vault_encrypted_unicode(test_value)
    assert test_value == ans_value.vault.decrypt(ans_value)



# Generated at 2022-06-11 09:15:49.873414
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode

    dummy_variable = AnsibleUnicode("dummy")
    dummy_variable.vault = VaultLib()
    dummy_variable.ansible_pos = ("dummy", 1, 1)
    dummy_variable.ansible_line = "dummy"

    dummy_node = "dummy"
    dummy_constructor = AnsibleConstructor()

    assert dummy_constructor.construct_yaml_str(dummy_node) == dummy_variable



# Generated at 2022-06-11 09:16:00.062037
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    if sys.version_info[0] > 2:
        # On Python 3, we expect unicode objects
        node = u'10'
        result = AnsibleConstructor(file_name='<string>').construct_yaml_unsafe(node)
        assert result == AnsibleUnsafeText(u'10')

        node = u'1.1'
        result = AnsibleConstructor(file_name='<string>').construct_yaml_unsafe(node)
        assert result == AnsibleUnsafeText(u'1.1')

        node = u'false'
        result = AnsibleConstructor(file_name='<string>').construct_yaml_unsafe(node)

# Generated at 2022-06-11 09:16:10.479609
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import six
    import copy
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    obj = AnsibleUnsafeText(u'hello world!')
    assert obj == u'hello world!'
    assert obj != 'hello world!'
    assert isinstance(obj, six.text_type)
    assert not isinstance(obj, six.binary_type)

    copy_obj = copy.deepcopy(obj)
    assert copy_obj == u'hello world!'
    assert copy_obj != 'hello world!'
    assert isinstance(copy_obj, six.text_type)
    assert not isinstance(copy_obj, six.binary_type)

    data = {
        u'text': obj,
    }

    dump

# Generated at 2022-06-11 09:16:20.155038
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # test construct_yaml_map function
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var

    # create a node object
    import yaml
    node = yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', None)

    # create a data object which will be used to construct the map object
    data = AnsibleMapping()

    # create a list of tuple (key_node, value_node)

# Generated at 2022-06-11 09:16:24.901486
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    test_data = u'key1: value1'

    node = yaml.compose(test_data)
    mapping = AnsibleConstructor.construct_yaml_map(
        AnsibleConstructor(),
        node)
    value1 = mapping.get('key1')
    assert isinstance(value1, AnsibleUnicode)

# Generated at 2022-06-11 09:16:41.167061
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # Set to True to see debug messages
    debug = False

    # Initialize a vault instance
    secret_filename = "test/vault-secret.txt"
    vault = VaultLib(secrets=secret_filename)

    # Construct encrypted data
    plaintext = "this is the plaintext"
    _raw_bytes = vault.encrypt(plaintext)

    # Create a yaml node
    class FakeYamlNode(object):
        def __init__(self, data):
            self.data = data

    fake_yaml_node = FakeYamlNode(_raw_bytes)

    # Class for testing

# Generated at 2022-06-11 09:16:44.846895
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    unsafe = AnsibleUnsafeText(u'ansible -i inventory -a "/bin/echo hello" all')
    assert unsafe['__unsafe__'].__class__.__name__ == 'AnsibleUnsafeText'
    assert unsafe['__unsafe__'] == 'ansible -i inventory -a "/bin/echo hello" all'

# Generated at 2022-06-11 09:16:50.856871
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Setup
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
            flow_style=True)
    node.start_mark = None
    node.end_mark = None
    ac = AnsibleConstructor(file_name='fake/path')
    # Test
    assert ac.construct_yaml_unsafe(node) is node
    # Teardown - None



# Generated at 2022-06-11 09:17:01.068210
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import os
    import tempfile

    # Test whether the constructor does what is expected for yaml.load
    try:
        fd, tmp_path = tempfile.mkstemp(text=True)
        with os.fdopen(fd, 'w') as f:
            f.write(u'My string\n')
        with open(tmp_path, 'r') as f:
            test_yaml_str = AnsibleConstructor(file_name=tmp_path).get_single_data(f)
            assert test_yaml_str == u'My string\n'
            assert isinstance(test_yaml_str, AnsibleUnicode)
    finally:
        os.remove(tmp_path)

    # Test whether the constructor does what is expected for yaml.safe_load

# Generated at 2022-06-11 09:17:09.582924
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.utils.unsafe_proxy import UnsafeProxy

    # this tests the construction from empty string
    data = yaml.load('''
    ---
    foo:
      bar: 1
      baz: world
    ''', Loader=AnsibleConstructor)
    assert data['foo']['bar'] == 1
    assert data['foo']['baz'] == 'world'

    # this tests the construction of strings in a dict
    data = yaml.load('''
    ---
    foo: "bar"
    ''', Loader=AnsibleConstructor)
    assert data['foo'] == u'bar'
    assert isinstance(data['foo'], AnsibleUnicode)

    # this tests the construction of multiple strings in a dict

# Generated at 2022-06-11 09:17:20.958157
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    data = {'foo': 'bar', 'bar': 'baz', 'baz': 'foo'}

    safe_dump = yaml.dump(data, Dumper=yaml.SafeDumper)
    unsafe_dump = yaml.dump(data, Dumper=yaml.UnsafeDumper)
    res = yaml.load(safe_dump, Loader=AnsibleLoader)
    assert(isinstance(res, dict))
    res = yaml.load(unsafe_dump, Loader=AnsibleLoader)
    assert(isinstance(res, AnsibleMapping))



# Generated at 2022-06-11 09:17:29.957368
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from collections import namedtuple
    from io import StringIO
    from yaml import Loader
    from ansible.module_utils.six import string_types

    test_data = u'foo: bar\n'
    expected_result = {u'foo': u'bar'}
    # Test function AnsibleConstructor.construct_yaml_str  with:
    #   - strings are converted to unicode objects
    #   - the position in the YAML file (line, column, name) is stored in the
    #     AnsibleUnicode object
    #
    # The test is done by subclassing SafeLoader to replace the standard
    # string constructor with AnsibleConstructor.construct_yaml_str
    #
    # Note that this unit test is not

# Generated at 2022-06-11 09:17:34.691267
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    test_string = """
- name: Test
  hello: world
  foo: bar
  baz: buzz
"""

    ansible_constructor = AnsibleConstructor()
    result = yaml.load(test_string, Loader=AnsibleConstructor)

    assert result[0] == {'name': 'Test', 'hello': 'world', 'foo': 'bar', 'baz': 'buzz'}


# Generated at 2022-06-11 09:17:47.101412
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from sys import version_info
    if version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO

# Generated at 2022-06-11 09:17:54.738505
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ac = AnsibleConstructor()
    assert hasattr(ac, '_ansible_file_name')
    assert ac._ansible_file_name is None
    assert hasattr(ac, '_vaults')
    assert isinstance(ac._vaults, dict)
    assert 'default' in ac._vaults
    assert isinstance(ac._vaults['default'], VaultLib)
    assert hasattr(ac, 'vault_secrets')
    assert isinstance(ac.vault_secrets, list)

    assert hasattr(ac, 'construct_mapping')
    assert callable(ac.construct_mapping)
    from yaml.nodes import MappingNode
    from six import string_types
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-11 09:18:07.132178
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_yaml = """
a: 1
b: 2
a: 3
"""
    yaml.load(test_yaml, Loader=AnsibleConstructor)

    test_yaml = """
a: 1
b: 2
a: 3
"""
    yaml.load(test_yaml, Loader=AnsibleConstructor)

    test_yaml = """
a: 1
b: 2
a: 3
"""
    try:
        yaml.load(test_yaml, Loader=AnsibleConstructor)
    except ConstructorError as e:
        pass
    else:
        assert False

# Generated at 2022-06-11 09:18:17.131683
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import ansible.parsing.yaml.dumper
    node = """
a:
  b: 1
  c: 2
  d: 3
  e:
    f: 4
    g: 5
    h: 6
"""
    data = AnsibleLoader(node, file_name="").get_single_data()
    ansible_pos_list = []
    assert len(data) == 1
    for item in data:
        assert len(item) == 5
        assert item['a'] == {u'b': 1, u'c': 2, u'd': 3, u'e': {u'f': 4, u'g': 5, u'h': 6}}

# Generated at 2022-06-11 09:18:28.453065
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    display = Display()
    display.verbosity = 0
    from ansible.parsing.yaml.objects import AnsibleMapping

    to_test = u'''{
        "a": {
            "b": {
                "c": !unsafe "{{ vault_secret | to_json }}"
            }
        }
    }
    '''
    v = VaultLib([])
    ansible_constructor = AnsibleConstructor()
    result = yaml.load(to_test, Loader=AnsibleConstructor)

    assert isinstance(result, AnsibleMapping)
    a = result.get(u'a')
    assert isinstance(a, AnsibleMapping)
    b = a.get(u'b')
    assert isinstance

# Generated at 2022-06-11 09:18:38.172667
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = "foo: bar\n"
    map_yaml = list(yaml.load_all(data, Loader=AnsibleConstructor))
    assert map_yaml[0].ansible_pos == ("<string>", 1, 0)

    data = "foo: bar\n  baz: quux\n"
    map_yaml = list(yaml.load_all(data, Loader=AnsibleConstructor))
    assert map_yaml[0].ansible_pos == ("<string>", 1, 0)

    data = "- bar\n  - baz\n  - quux\n"
    map_yaml = list(yaml.load_all(data, Loader=AnsibleConstructor))

# Generated at 2022-06-11 09:18:41.610339
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    input_data = '''
    - one
    - two
    - three
    '''
    yaml_obj = yaml.load(input_data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, list)
    assert yaml_obj == ['one', 'two', 'three']



# Generated at 2022-06-11 09:18:50.782474
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = '''
list1:
    - value1
    - value2
list2:
    - value3
    - value4
'''
    # Create an instance of AnsibleConstructor
    obj = AnsibleConstructor()
    # Create an instance of AnsibleMapping
    data = obj.construct_yaml_map( yaml_data )
    assert data[ 'list1' ][1] == 'value2'
    assert data[ 'list2' ][0] == 'value3'

# Generated at 2022-06-11 09:18:57.793174
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    stream = u'{var1: val1, var2: val2, var3: val3}'
    yamlnode = yaml.compose(stream)
    mapper = AnsibleConstructor()
    data = mapper.construct_mapping(yamlnode)
    if not isinstance(data, dict) or len(data) != 3:
        raise AssertionError('Failed to parse yaml input')



# Generated at 2022-06-11 09:19:02.980942
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
  from ansible.parsing.vault import VaultLib
  from ansible.utils.unsafe_proxy import wrap_var

  vault_secrets = ['pass']
  construct = AnsibleConstructor(None, vault_secrets)

  node = wrap_var(['a'])

  ansible_seq = construct.construct_yaml_seq(node)
  assert isinstance(ansible_seq, AnsibleSequence)
  assert ansible_seq == wrap_var(['a'])


# Generated at 2022-06-11 09:19:06.813621
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    import yaml

    ret = yaml.load('''---
foo: "bar"
''', Loader=AnsibleConstructor)
    assert ret == {'foo': u'bar'}
    assert isinstance(ret['foo'], AnsibleUnicode)



# Generated at 2022-06-11 09:19:16.954416
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():                          # pylint: disable=C0103
    import sys
    import yaml
    from ansible.parsing import vault
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Don't use the real vault secret because it contains the key itself,
    # which we don't want to accidentally leak into the test output
    vault_secret = VaultSecret(vault.get_file_vault_secret('.vault_password.txt'))
    vault_secrets = [vault_secret]
    vault_lib

# Generated at 2022-06-11 09:19:37.495933
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    from ansible.parsing.yaml.loader import AnsibleLoader

    # AnsibleConstructor.construct_yaml_seq() is tested by AnsibleConstructorTestCase.test_construct_yaml_seq
    # through AnsibleLoader.get_single_data.
    # If this test fails, you may also want to check AnsibleLoader.get_single_data.

    # test when there is no node.value
    node = object()
    node.value = None
    node.start_mark = object()
    node.start_mark.column = 0
    node.start_mark.line = 0
    node.start_mark.name = 'ansible'
    node.id = 'seq'

    sut = AnsibleConstructor('ansible')

# Generated at 2022-06-11 09:19:46.664454
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Construct a YAML sequence.

    The constructor is called to create a sequence.
    Each element of the sequence is further processed
    by calling the construct_object method.
    The sequence is returned to the caller wrapped in a
    AnsibleSequence object.

    """
    test_sequence = [ 'foo', 'bar' ]
    test_data = """
    - foo
    - bar
    """
    test_sequence.ansible_pos = ( '<string>', 1, 5 )

    ac = AnsibleConstructor()

    node = yaml.compose(test_data)
    data = ac.construct_yaml_seq(node)

    for key, value in data:
        assert value == test_sequence


# Generated at 2022-06-11 09:19:47.215197
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert False

# Generated at 2022-06-11 09:19:51.333965
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    constructor = AnsibleConstructor()
    data = AnsibleMapping()
    result = constructor.construct_yaml_map(yaml.MappingNode(u'tag:yaml.org,2002:map', []))
    assert result == data
    assert result.ansible_pos == ('<unicode string>', 1, 1)


# Generated at 2022-06-11 09:20:00.805971
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test duplicate key in case of key error
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    node.value = [node.value[0], node.value[0]]
    construct = AnsibleConstructor()
    try:
        construct.construct_mapping(node, deep=False)
        assert False
    except ConstructorError:
        assert True

    # Test duplicate key in case of ignore
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    node.value = [node.value[0], node.value[0]]
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    construct = AnsibleConstructor()

# Generated at 2022-06-11 09:20:10.509743
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    import ansible.parsing.yaml.loader

    # Test that a value is correctly decrypted
    vault_secrets = VaultSecret([u'ansible'])
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-11 09:20:18.907553
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    """
    A test to ensure that we properly handle the situation when we have multiple password sources
    """

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO


# Generated at 2022-06-11 09:20:19.408718
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
  pass

# Generated at 2022-06-11 09:20:29.620802
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping

    a_str_str_map = AnsibleMapping({'foo': 'bar'})
    a_str_str_map.ansible_pos = ('file.yml', 1, 2)

    a_str_unicode_map = AnsibleMapping({'foo': AnsibleUnicode(value=u'bar')})
    a_str_unicode_map.ansible_pos = ('file.yml', 1, 2)

    a_unicode_str_map = AnsibleMapping({AnsibleUnicode(value=u'bar'): 'foo'})
    a_unicode_str_map.ansible_pos = ('file.yml', 1, 2)

    a_unicode_unicode_map = AnsibleMapping

# Generated at 2022-06-11 09:20:37.712794
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    '''Unit test for method construct_yaml_str of class AnsibleConstructor'''

    print(__name__ + '.' + test_AnsibleConstructor_construct_yaml_str.__name__)

    # Create an instance of AnsibleConstructor
    ansible_constructor = AnsibleConstructor()

    # Create a sequence of test cases
    test_cases = [
        dict(
            input='string one',
            expected=AnsibleUnicode('string one'),
        ),
    ]

    # Iterate over the test cases
    for test_case in test_cases:

        # Unpack the input and expected values from the test cases
        input = test_case['input']
        expected = test_case['expected']

        # Call the method

# Generated at 2022-06-11 09:21:06.964182
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    import StringIO

    class TestAnsibleConstructor(AnsibleConstructor):
        def construct_mapping(self, node, deep=False):
            return 42

    test_yaml_snippet = StringIO.StringIO("""\
a: 1
b: 2
c: 3
d: 4
e: 5
""")


# Generated at 2022-06-11 09:21:18.233671
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = """
test:
  foo: bar
  baz: qux
  1: 2
  3: 4
  5.5: 6.6
  a: 7
  b: 8
  c:
    - 1
    - 2
  d:
    - 3
    - 4
"""
    import sys
    import io
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping, AnsibleSequence

    # capture all the output by redirect to devnull
    fnull = open(os.devnull, 'w')
    savestdout = sys.stdout
    sys.stdout = fnull

    # Let's use ansible.utils.unsafe_proxy.ansible_safe_yaml_load and.ansible_safe_yaml_dump
   

# Generated at 2022-06-11 09:21:21.082635
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_str = '{a: 1, b: 2}'
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str(yaml.compose(yaml_str))

# Generated at 2022-06-11 09:21:30.630734
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-11 09:21:35.371072
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    constructor = AnsibleConstructor()
    value = """
test:
    key1: value1
    key2: value2
    key3: value3
"""
    node = AnsibleConstructor.construct_yaml_map(constructor, value)
    assert node == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}



# Generated at 2022-06-11 09:21:43.883739
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            self._ansible_file_name = file_name
            super(AnsibleConstructor, self).__init__()

        def construct_yaml_str(self, node):
            return AnsibleUnicode(self.construct_scalar(node))

        def construct_vault_encrypted_unicode(self, node):
            return AnsibleVaultEncryptedUnicode(self.construct_scalar(node))

    import yaml

    str_in = u"a normal string"
    bytes_in = to_bytes(str_in)

# Generated at 2022-06-11 09:21:50.462963
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = u'{ key1: "test-value", key2: { key3: value3 } }'
    ansible_constructor = AnsibleConstructor()
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data['key1'], basestring)
    assert data['key1'] == 'test-value'
    assert isinstance(data['key2'], dict)
    assert data['key2']['key3'] == 'value3'

# Generated at 2022-06-11 09:21:59.918827
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import tempfile

    # Identify temporary file where to store vault_passwd
    vault_passwd_f = tempfile.NamedTemporaryFile(delete=False)

    # Write password in vault_passwd
    vault_passwd_f.write(b'123')
    vault_passwd_f.close()

    # Create vault_passwd_f path list
    vault_secrets = ['@' + vault_passwd_f.name]

    # Create AnsibleConstructor
    AnsibleConstructor_obj = AnsibleConstructor(
        vault_secrets=vault_secrets)

    # Declare the yaml dictionary

# Generated at 2022-06-11 09:22:00.454836
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    pass

# Generated at 2022-06-11 09:22:09.019258
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """Basic test for method construct_yaml_seq of class AnsibleConstructor.
       Just make sure that it does not raise an exception.
    """

    # Sample data to pass to _test_AnsibleConstructor_construct_yaml_seq
    test_data_1 = '''
- 0
- 1
'''

    test_data_2 = '''
- apple
- - 0
  - 1
- !!str orange
- !!str pear
- !!str guava
'''

    def _test_AnsibleConstructor_construct_yaml_seq(yaml_data):
        import yaml
        # Create a yaml document out of the given yaml data and load it
        yaml_doc = yaml.Document(yaml_data, None)
        # Create an AnsibleConstructor object
        ac = Ansible

# Generated at 2022-06-11 09:22:35.965704
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import io, sys

    my_console = sys.stdout
    sys.stdout = io.StringIO()

    # Testing construct_mapping.  This isn't a testing of the top level, so
    # we have to create all of the stuff that is in the constructor as well as
    # all the other yaml classes.  I was hoping for a better way to do this...
    node = MappingNode(None, None, None, None)

    class FakeNode(object):
        def __init__(self, id, start_mark, value):
            self.id = id
            self.start_mark = start_mark
            self.value = value


# Generated at 2022-06-11 09:22:48.756085
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml import nodes
    import sys

    a = AnsibleConstructor()

    # Test duplicate key from yaml.constructor.SafeConstructor
    node = nodes.MappingNode(None, None, None, None)
    node.value = [(nodes.ScalarNode('tag:yaml.org,2002:str', 'a'), 'a'),
                  (nodes.ScalarNode('tag:yaml.org,2002:str', 'a'), 'b'),
                  (nodes.ScalarNode('tag:yaml.org,2002:str', 'c'), 'c')]
    sys.modules['ansible.parsing.dataloader'].C.DUPLICATE_YAML_DICT_KEY = 'ignore'

# Generated at 2022-06-11 09:22:57.816747
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = """
name: first dict
key: value
dict_list:
- {key_1: value_1}
- {key_2: value_2}
nested_dict_list:
- {name: first dict, key: value}
- {name: second dict, key: value}
nested_dict: {name: nested dict, key: value}
nested_dict_as_value: {name: nested dict, key: value}
    """
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)

    assert data['name'] == 'first dict'
    assert data['key'] == 'value'
    assert data['dict_list'][0]['key_1'] == 'value_1'

# Generated at 2022-06-11 09:23:08.335784
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode

    def _safe_constructor(self, node):
        return self.construct_yaml_str(node)

    class _AnsibleConstructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            return _safe_constructor(self, node)

    for value in u'foo', u'bar', u'1', u'yes', u'no', u'on', u'off':
        node = ScalarNode(tag=u'tag:yaml.org,2002:str', value=value)
        instance = _AnsibleConstructor()
        result = instance.construct_object(node)
        assert isinstance(result, AnsibleUnicode)
        assert result == value


# Generated at 2022-06-11 09:23:09.044885
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-11 09:23:19.734664
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """Testing the correct behavior of method construct_yaml_unsafe of class AnsibleConstructor
    """
    import string
    import random
    import re

    # Setting up a test object of class AnsibleConstructor
    test_object = AnsibleConstructor()

    # Testing the correct behavior when !unsafe tag is used
    # Generating a random string to test
    random_string = "".join(random.choice(string.ascii_uppercase) for _ in range(100))
    # Checking if the string has been wrapped
    assert isinstance(test_object.construct_yaml_unsafe(random_string), wrap_var), \
        "String {0} not wrapped by unsafe_proxy".format(random_string)

    # Testing the correct behavior when !unsafe tag has not been used
    # Generating a random string to test

# Generated at 2022-06-11 09:23:22.007752
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    cons = AnsibleConstructor()
    data = {'an_unsafe_value': '!unsafe va\nl'}
    assert cons.construct_yaml_map(data) == data



# Generated at 2022-06-11 09:23:25.770788
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # key1: 1
    # key2: 2
    test_dict = {
        'key1': 1,
        'key2': 2,
    }
    a_constructor = AnsibleConstructor()
    results = a_constructor.construct_yaml_map(test_dict)
    assert results == test_dict


# Generated at 2022-06-11 09:23:28.327920
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['vault_password']
    node = AnsibleConstructor(vault_secrets=vault_secrets).construct_yaml_str(node)


# Generated at 2022-06-11 09:23:32.067259
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    obj = AnsibleConstructor(file_name=__file__)
    ret = obj.construct_yaml_map(node)
    assert isinstance(ret, AnsibleMapping)
    assert len(ret) == 0

# Generated at 2022-06-11 09:24:18.001783
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = '''
        a: b
        b: 1
        c:
          - A
          - B
        d: {a: b, c: d}
        e:
          a: b
          c: d
          e:
             f: g
    '''
    expected = {'a': 'b', 'b': '1', 'c': ['A', 'B'], 'd': {'a': 'b', 'c': 'd'}, 'e': {'a': 'b', 'c': 'd', 'e': {'f': 'g'}}}
    parsed = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(parsed, dict)
    assert parsed == expected

# Generated at 2022-06-11 09:24:25.366224
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    constructor = AnsibleConstructor()
    def test_construct(value, expected_result=None, expected_error=None, expected_warning=None):
        if expected_error:
            expected_warning = None
        node = ""
        # make the tests more readable
        if hasattr(value, '__name__'):
            node = value.__name__
        else:
            node = str(value)

        # create a new mapping
        mapping_node = MappingNode(u'tag:yaml.org,2002:map', value, start_mark=None, end_mark=None, flow_style=None)
        # call the method to test
        try:
            result = constructor.construct_yaml_map(mapping_node).next()
        except ConstructorError as e:
            result = str(e)
            #

# Generated at 2022-06-11 09:24:33.962104
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Arrange
    stream = "---\n- foo: FOO\n  bar: BAR\n\n- foo: FOO2\n  bar: BAR2"
    node = yaml.parse(stream)
    from ansible.parsing.yaml.objects import AnsibleSequence
    AnsibleConstructor.add_constructor(
        u'tag:yaml.org,2002:seq',
        AnsibleConstructor.construct_yaml_seq)

    # Act
    data = AnsibleConstructor.construct_yaml_seq(node)

    # Assert
    assert isinstance(data, AnsibleSequence)
    stuffs = data

    for stuff in stuffs:
        assert isinstance(stuff, dict)

    assert stuffs[0]['foo'] == 'FOO'

# Generated at 2022-06-11 09:24:41.924993
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    stream = '''
        - name: foo
          acme:
            foo: "1"
          bar:
            baz: "2"
      '''
    results = list(AnsibleLoader(stream, file_name='/foo/bar').get_single_data())
    assert type(results[0]['acme']['foo']) == type(results[0]['bar']['baz']) == AnsibleUnicode
    assert 'ansible_pos' in results[0]['acme']['foo']
    assert 'ansible_pos' in results[0]['bar']['baz']

# Generated at 2022-06-11 09:24:45.668019
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test if the method returns unicode object
    ansible_constructor = AnsibleConstructor()
    ans_str = ansible_constructor.construct_yaml_str(node=None)
    assert hasattr(ans_str, 'ansible_pos')
    assert isinstance(ans_str, AnsibleUnicode)

# Generated at 2022-06-11 09:24:51.768521
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_value = 'value'

    class InitDummy(AnsibleConstructor):
        def __init__(self, *args, **kwargs):
            self.output = None
            super(InitDummy, self).__init__(args, kwargs)

        def construct_yaml_str(self, node):
            self.output = super(InitDummy, self).construct_yaml_str(node)
            return self.output

    ac = InitDummy()
    ac.construct_yaml_str(node=yaml_value)
    assert isinstance(ac.output, AnsibleUnicode)

# Generated at 2022-06-11 09:25:00.510502
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import yaml
    from ansible.parsing.yaml import objects
    from ansible.parsing.vault import VaultLib

    c = AnsibleConstructor(file_name='/path/to/testfile.yml')

    vault_secret = os.urandom(32)
    vault_passwords = {'default': vault_secret}

    c_vault_lib = VaultLib(vault_passwords)
    data = 'file_content'
    enc_vault_str = c_vault_lib.encrypt(data)

    # test with no vault secret
    node = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', '!vault |\n  ' + enc_vault_str)

# Generated at 2022-06-11 09:25:10.569173
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_secrets = [ 'test' ]
    #vault_secrets = None  # -> VaultLib(secrets=None)
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    #ansible_vault_encrypted_unicode = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          30373335393634636665393737386138343739366334353034376637363834636439386566626539\