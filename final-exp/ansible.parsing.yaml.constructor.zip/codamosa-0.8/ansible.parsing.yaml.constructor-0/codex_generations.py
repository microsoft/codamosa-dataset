

# Generated at 2022-06-11 09:15:16.133115
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:15:22.610032
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor(file_name='/test/ansible_constructor')
    mapping_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], deep=True)
    mapping = ansible_constructor.construct_mapping(mapping_node)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping.ansible_pos == ('/test/ansible_constructor', 1, 1)

# Generated at 2022-06-11 09:15:31.627206
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml import objects

    # http://stackoverflow.com/a/24519338
    class MockNode(object):
        def __init__(self, val_node, key_node, start_mark, end_mark):
            self.value = (val_node, key_node)
            self.start_mark = start_mark
            self.end_mark = end_mark

    # http://stackoverflow.com/a/24519338
    class MockMark(object):
        def __init__(self, name, line, column):
            self.name = name
            self.line  = line
            self.column = column

    # Given
    # a node of yaml.nodes.MappingNode
    val_node = "value"
    key_node = "key"
   

# Generated at 2022-06-11 09:15:32.460908
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass


# Generated at 2022-06-11 09:15:41.586479
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-11 09:15:46.355628
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert AnsibleConstructor().construct_mapping(MappingNode('tag:yaml.org,2002:map', [])) == AnsibleMapping()
    assert AnsibleConstructor().construct_mapping(MappingNode('tag:yaml.org,2002:map', [('key', 'value')])) == AnsibleMapping([(AnsibleUnicode('key'), AnsibleUnicode('value'))])

# Generated at 2022-06-11 09:15:57.197482
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [ b'$ANSIBLE_VAULT;1.1;AES256', b'5c5d93eb8d76f24a4f4a4e4d954ca56a9c9b09d2c2c1e91a2f3c3b3b3d3d3a' ]
    class node:
        def __init__(self):
            self.start_mark = None

    obj = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-11 09:16:07.100407
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    secret = 'test_secret'
    vault = VaultLib(secrets=[secret])

# Generated at 2022-06-11 09:16:17.146125
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import _VaultSecret
    from ansible import context
    import os

    path = os.path.dirname(os.path.realpath(__file__))
    test_file_path = os.path.join(path, "./test_data/vault/vault_encrypted_data_test.yml")

    def fake_load_vault_secrets(loader, vault_secrets):
        vault

# Generated at 2022-06-11 09:16:25.982911
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    class MockNode(object):

        def __init__(self, id=None, start_mark=None):
            self.id = id
            self.start_mark = start_mark

    expected_output = AnsibleSequence()
    expected_output.ansible_pos = ('<string>', 1, 1)

    output = AnsibleConstructor('<string>').construct_yaml_seq(MockNode(id='seq'))
    if isinstance(output, yaml.nodes.ScalarNode):
        assert output.tag
    else:
        output = next(output)
        assert output == expected_output

# Generated at 2022-06-11 09:16:41.488410
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Case 1. The following construct_yaml_map() should return an AnsibleMapping object with one key-value pair.
    node = MappingNode(
        "tag:yaml.org,2002:map",
        [
            (
                ScalarNode("tag:yaml.org,2002:str", "node1"),
                ScalarNode("tag:yaml.org,2002:str", "val1")
            )
        ]
    )
    result = AnsibleConstructor.construct_yaml_map(node)

    assert isinstance(result, AnsibleMapping)
    assert len(result) == 1
    assert result['node1'] == 'val1'

    # Case 2. The following construct_yaml_map() should return an AnsibleMapping object with two key-value pairs.

# Generated at 2022-06-11 09:16:47.062415
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # simple test to ensure we can overload yaml.constructor.Constructor
    # with our own and make it work (ensures the basic ansible constructors
    # and representers are loaded)

    class MyAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            value = self.construct_scalar(node)
            # in this test, we return the scalar prefixed with 'foo'
            return u'foo' + value

    # Replicate the format that PyYAML expects fo the constructors argument.
    # (see https://github.com/yaml/pyyaml/blob/master/lib3/yaml/constructor.py#L

# Generated at 2022-06-11 09:16:57.528654
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    construct_yaml_unsafe = AnsibleConstructor.construct_yaml_unsafe

    # an example object representing the following yaml structure
    # [x, y, z]
    #  x:
    #    y: z
    # if we can anticipate the internal structure of a yaml node and
    # assign it to a mock, we can use this method in our unit tests
    x = [1, 2, 3]
    x_node = {'id':'seq', 'value':[{'id':'int', 'value':1}, {'id':'int', 'value':2}, {'id':'int', 'value':3}], 'start_mark':1, 'end_mark':2}
    x_yaml_node = [x_node]

    # test construct_yaml_unsafe with a sequence
   

# Generated at 2022-06-11 09:17:06.816671
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os.path
    import tempfile
    import ansible.parsing.vault as vaultlib

    # create and read back a vault encrypted file
    (vault_fd, vault_filename) = tempfile.mkstemp()
    vault_file = open(vault_filename, 'wb')
    vault_pass = 'this_is_a_test_vault_pass'

    # Write some unencrypted data

# Generated at 2022-06-11 09:17:11.481761
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    yaml_str = "--- !unsafe '[1,2,3]'"
    yaml_obj = AnsibleLoader(yaml_str).get_single_data()
    print(yaml_obj)
    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert str(yaml_obj) == "[1,2,3]"


# Generated at 2022-06-11 09:17:23.705920
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
                       flow_style=False, start_mark=None, end_mark=None)
    empty_dict = AnsibleConstructor().construct_mapping(node)
    assert empty_dict == {}

    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
                       flow_style=False, start_mark=None, end_mark=None)
    node.value = [
        (ScalarNode(u'foo'), ScalarNode(u'bar')),
        (ScalarNode(u'baz'), ScalarNode(u'qux'))
    ]
    # primitive test for AnsibleMapping
    mapping = AnsibleConstructor().construct_mapping(node)
   

# Generated at 2022-06-11 09:17:31.381309
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml import objects
    input_yaml = '''
        d1:
          d2:
            d3:
              d4: value
        a:
          b:
            - b1
            - b2
        c:
          d: 1
          e: 2
          f: 3
        '''
    data = AnsibleLoader(input_yaml).get_single_data()

    assert data['d1']['d2']['d3']['d4'] == 'value'
    assert data['a']['b'][0] == 'b1'
    assert data['a']['b'][1] == 'b2'
    assert data['c']['d'] == 1

# Generated at 2022-06-11 09:17:33.279321
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    '''Unit test for method construct_yaml_map of class AnsibleConstructor.'''
    # TODO: Test code here
    pass


# Generated at 2022-06-11 09:17:36.458007
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = AnsibleConstructor.construct_yaml_seq(0)
    assert node.ansible_pos == None
    assert isinstance(node, list)
    assert len(node) == 0

# Generated at 2022-06-11 09:17:48.723325
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    '''
    Test for method construct_yaml_seq of class AnsibleConstructor.
    '''

    from ansible.parsing.yaml.loader import AnsibleLoader
    filename = 'testdata/yaml/test_construct_yaml_seq.yml'
    with open(filename, 'r') as f:
        data = f.read()
    loader = AnsibleLoader(data, file_name=filename)
    node = loader.get_single_data()
    ac = AnsibleConstructor(file_name=filename)
    assert node.tag == u'tag:yaml.org,2002:seq'

    res = ac.construct_yaml_seq(node)
    assert res != None
    assert len(res) == 3
    assert res[0] == 'a'

# Generated at 2022-06-11 09:17:54.688341
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    seq = AnsibleConstructor.construct_yaml_seq()
    assert isinstance(seq, AnsibleConstructor.construct_yaml_seq())

# Generated at 2022-06-11 09:18:03.646247
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml import nodes
    import base64
    from ansible.parsing.vault import VaultLib

    vault_secret = 'qwerty'
    vault_secrets = [vault_secret]
    ansible_constructor = AnsibleConstructor(file_name='<string>', vault_secrets=vault_secrets)

    # create a VaultLib object for encrypting the plaintext in vault-encrypted string
    vault = VaultLib(secrets=vault_secrets)

    plaintext = base64.b64encode('hello')
    ciphertext = vault.encrypt(plaintext)
    ciphertext_base64 = base64.b64encode(ciphertext)

# Generated at 2022-06-11 09:18:12.800588
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.data import DataLoader
    import os
    import glob

    path_data = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'yaml')
    filenames = [x for x in glob.glob(os.path.join(path_data, '*.yml')) if 'new_style' not in x]

    loader = DataLoader()
    for filename in filenames:
        with open(filename, 'rb') as f:
            print('testing %s' % filename)
            data = loader._constructor.construct_yaml_seq(loader.compose_document(f.read()))
            loaded_data = list(data)

# Generated at 2022-06-11 09:18:23.515349
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:18:29.373253
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    stub_node = MyYamlMappiingNode()
    data = ansible_constructor.construct_yaml_seq(stub_node)
    data.__next__()
    # when
    result = data.ansible_pos

    # then
    expected = ("<unicode string>", 1, 1)
    assert result == expected



# Generated at 2022-06-11 09:18:31.487442
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # construct_yaml_seq(node) should return a generator
    assert(isinstance(AnsibleConstructor.construct_yaml_seq('node'), types.GeneratorType))

# Generated at 2022-06-11 09:18:40.852973
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import ansible.parsing.vault
    import ansible.parsing.yaml.loader

    class TestAnsibleConstructor(AnsibleConstructor):

        def __init__(self, file_name=None, vault_secrets=None):
            super(TestAnsibleConstructor, self).__init__(file_name, vault_secrets)

        def construct_vault_encrypted_unicode(self, node):
            # We need to re-implement this method to make the test work, since the
            # method AnsibleConstructor.construct_vault_encrypted_unicode
            # uses the class VaultLib and method VaultLib.decrypt, which
            # would fail without initializing the class VaultLib

            value = self.construct_scalar(node)
            b_ciphertext_data = to_

# Generated at 2022-06-11 09:18:54.622093
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """
    If a yaml value is marked with !unsafe, then it should be wrapped in a
    representation of it's raw string representation
    """
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from collections import namedtuple

    class FakeVaultSecret(object):
        def __init__(self, data=''):
            self.data = data

    vault_secret = FakeVaultSecret('abc')
    test_vault = VaultLib(secrets=[vault_secret])
    test_vault.encrypt('test')

    test_value = '"test"'

    # Load the unsafe value and assert that it's not wrapped in an
    # AnsibleUnsafeText object

# Generated at 2022-06-11 09:19:03.346137
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [{'secret': 'key1'}]
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)


# Generated at 2022-06-11 09:19:13.306945
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ac = AnsibleConstructor()
    test_node = 'test_node'
    test_vault = VaultLib()
    test_vault_secrets = ['123', '456', '789']
    test_vault.secrets = test_vault_secrets
    ac._vaults['default'] = test_vault
    # Test an encrypted string
    test_value = test_vault.encrypt(u'This is a test')
    test_ret = ac.construct_vault_encrypted_unicode(test_node, test_value)

# Generated at 2022-06-11 09:19:33.459471
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    # This test is inspired by this issue: https://github.com/ansible/ansible/issues/15627
    # This issue seems to be caused by internally, pyyaml uses the ascii codec.
    # When he parses the yaml file, he uses the default_flow_style=False, this
    # causes in the output the special chars be escaped to utf-8.
    # As a result, the output of yaml.dump will be utf-8 bytes and the input
    # of yaml.load will be utf-8 bytes. This will cause pyyaml use the utf-8
    # codec to parse the file.
    # At the same time, when yaml.load uses the utf-8 codec, it may get str
    # objects which are valid unicode strings that have a bad utf-8

# Generated at 2022-06-11 09:19:38.103895
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    ac = AnsibleConstructor()
    yaml_str = '!unsafe 1'
    data = ac.construct_yaml_unsafe(yaml_str)
    assert isinstance(data, AnsibleUnsafeText)



# Generated at 2022-06-11 09:19:41.188414
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    actual_output = ac.construct_yaml_str(u'foo')
    expected_output = AnsibleUnicode(u'foo')
    assert actual_output == expected_output


# Generated at 2022-06-11 09:19:50.577912
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['my_secret']
    constr = AnsibleConstructor(vault_secrets=vault_secrets)
    context_mark = None
    problem = None
    problem_mark = None
    note = None
    value = "!vault |\n"
    value += "          $ANSIBLE_VAULT;1.1;AES256\n"
    value += "          32303134616239353431623636656434353736633863313662373136613631326334316134346130\n"
    value += "          39346430376531366431643966653665356262623838326334630a65643235343335633263636339\n"

# Generated at 2022-06-11 09:19:59.219131
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_encrypted_unicode = AnsibleConstructor(vault_secrets=['secret'])
    secret_text = u'hello world'
    # Generate ciphertext with AnsibleVaultEncryptedUnicode
    secret = AnsibleVaultEncryptedUnicode(secret_text.encode('utf8'))
    ciphertext = secret.encode()
    # Create a new node and pass it to the constructor
    node = yaml.nodes.ScalarNode(yaml.nodes.Tag(u'!vault'), ciphertext, 'anchor', None, None)
    secret2 = vault_encrypted_unicode.construct_vault_encrypted_unicode(node)
    plaintext = secret2.decode()
    assert plaintext == secret_text

# Generated at 2022-06-11 09:20:03.716387
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    result = [1, 2, 3]
    constructor = AnsibleConstructor()
    yaml_str = u'[1, 2, 3]'
    yaml_node = constructor.construct_yaml_str(yaml_str)
    assert yaml_node == u'[1, 2, 3]'
    assert yaml_node == result



# Generated at 2022-06-11 09:20:07.551844
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = """
foo: bar
baz: qux
"""
    data = AnsibleMapping()
    data.ansible_pos = (None, 1, 1)
    assert(AnsibleConstructor().construct_yaml_map(node) == data)

# Generated at 2022-06-11 09:20:09.682394
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import load
    # ensures that create new object of AnsibleConstructor
    AnsibleConstructor().construct_yaml_seq([])

# Generated at 2022-06-11 09:20:12.044864
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    constructor = AnsibleConstructor()
    list_1 = constructor.construct_yaml_seq("")
    assert(isinstance(list_1, AnsibleSequence))


# Generated at 2022-06-11 09:20:20.228545
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib(['password'])
    ciphertext = vault.encrypt(b'foo')
    data = {'a': b'foo', 'b': u'bar', 'c': ciphertext}
    as_yaml = yaml.dump(data)
    result = yaml.load(as_yaml, Loader=AnsibleConstructor)

    # NOTE: yaml.dump(data, default_flow_style=False) returns the exact same
    # YAML, but the yaml.load() call takes nearly twice as long. The
    # stream-like return value of yaml.dump() is not used.

    assert isinstance

# Generated at 2022-06-11 09:20:44.934881
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a = AnsibleConstructor()
    start_mark = None
    end_mark = None
    value = [MappingNode(tag=u'tag:yaml.org,2002:map',
                         value=[],
                         start_mark=start_mark,
                         end_mark=end_mark,
                         flow_style=None)]
    node = MappingNode(tag=u'tag:yaml.org,2002:map',
                       value=value,
                       start_mark=start_mark,
                       end_mark=end_mark,
                       flow_style=None)
    assert a.construct_mapping(node) == {}

# Generated at 2022-06-11 09:20:48.106376
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    mapping_node = MappingNode(tag=u'tag:yaml.org,2002:str', value=[], start_mark=None, end_mark=None)
    ret = ansible_constructor.construct_mapping(mapping_node)
    assert isinstance(ret, AnsibleMapping)

# Generated at 2022-06-11 09:20:56.846378
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import unittest
    from yaml.nodes import ScalarNode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class Test(unittest.TestCase):
        def test_construct_yaml_unsafe(self):
            data = b'foo'
            node = ScalarNode('tag:yaml.org,2002:str', data, start_mark=None, end_mark=None)
            a = AnsibleConstructor()
            result = a.construct_yaml_unsafe(node)
            self.assertIsInstance(result, AnsibleUnsafeText)
            self.assertEqual(result, 'foo')

    t = Test()
    t.test_construct_yaml_unsafe()

# Generated at 2022-06-11 09:21:04.083466
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test data
    data = """# Test yaml file
a: 1
a: 2
"""
    # Build data tree
    from ansible.parsing.yaml import objects
    ansible_data = objects.AnsibleMapping()
    ansible_data['a'] = 1
    ansible_data['a'] = 2
    return_data = AnsibleConstructor().construct_mapping(data)
    assert return_data == ansible_data, "Returned data '%s' is not the same as expected data '%s'" % (
        return_data, ansible_data)

# Generated at 2022-06-11 09:21:11.180247
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from ansible.parsing.dataloader import DataLoader
    source = "a: b\nc: d\n"
    result = [{"a": "b"}, {"a": "b", "c": "d"}]
    loader = DataLoader()
    data = loader.load(source)
    assert data == result[1]


# Generated at 2022-06-11 09:21:18.358670
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    const = AnsibleConstructor()
    seq = [3,4,5]
    yield_func = const.construct_yaml_seq(None)
    ansible_seq = yield_func.send(None)
    for item in seq:
        ansible_seq.append(item)
    assert ansible_seq == seq
    yield_func = const.construct_yaml_seq(None)
    ansible_seq = yield_func.send(None)
    assert ansible_seq.ansible_pos is None

# Generated at 2022-06-11 09:21:27.361720
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys, os
    import unittest
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnicode

    # Create a file with some content
    fd, fname = tempfile.mkstemp()

# Generated at 2022-06-11 09:21:36.648540
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor()

    # Test one
    class Node():
        start_mark = 'start_mark'

    s_value = "!vault |\n" \
              "          $ANSIBLE_VAULT;1.1;AES256\n" \
              "          6438376431393233346165633239626263313161363131646434396438656362626166623433363064\n" \
              "          6530313061646631633862336564646361303336313834623063323632663661393666333837663735\n" \
              "          62356263393064636632323637363931316662356537666130336537356538\n"

    b_ciphertext

# Generated at 2022-06-11 09:21:37.174168
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert True

# Generated at 2022-06-11 09:21:45.848911
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
# Instantiate a VaultLib object with no vault password
    vault = VaultLib(secrets=None)
# Instantiate an AnsibleConstructor object with the VaultLib object 'vault'
    ansible_constructor = AnsibleConstructor(vault_secrets=vault)
    try:
# Try to use the constructed object to handle a vault encrypted object
        ansible_constructor.construct_vault_encrypted_unicode(None)
# Python2.7 and 3.4 do not raise an exception here, but 3.6 does
# Python2.7 and 3.4 fail later when they try to look up the constructed
# object's 'vault' attribute
        assert False
    except ConstructorError as e:
        assert isinstance(e, ConstructorError)
        assert 'found !vault but no vault password provided' in e.problem

# Generated at 2022-06-11 09:22:31.182274
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from yaml.representer import SafeRepresenter
    from ansible.parsing.yaml import _AnsibleLoader

    # This code comes mainly from http://pyyaml.org/ticket/28
    class LenientRepresenter(SafeRepresenter):
        def represent_list(self, data):
            node = SafeRepresenter.represent_list(self, data)
            node.flow_style = False
            return node

    # First we create a loader, which processes the YAML into a Python data structure.
    # Then we create a dumper, which gives us back the serialization of the data structure.
    # We monkey-patch the dumper to give us a LenientRepresenter, which will flow the sequence rather than block it.
    # Note that we ask for 'default_flow_style=False' in the dumper,

# Generated at 2022-06-11 09:22:34.959573
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from copy import copy
    import textwrap

    doc = textwrap.dedent("""
        ---
        a: 1
        b: 2
        a: 3
        c: 4
        c: 5
        a: 7
        """)

    kv = {}
    for mode in ('warn', 'error', 'ignore', 'none'):
        for DuplicateYamlDictKey in ('warn', 'error', 'ignore', 'none'):
            kv[mode, DuplicateYamlDictKey] = []
            C.DUPLICATE_YAML_DICT_KEY = DuplicateYamlDictKey
            for line, expected in enumerate([7, 3, 5]):
                data = copy(doc)
                data = data.splitlines()
                data[line] = '# ' + data

# Generated at 2022-06-11 09:22:38.937239
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    vault_secrets = [u'secret']
    cons = AnsibleConstructor(vault_secrets=vault_secrets)
    vault = VaultLib(secrets=vault_secrets)
    vault.encrypt(u'hello')
    ciphertext = vault.encrypt(u'hello')
    ciphertext_data = ciphertext.replace(u'$ANSIBLE_VAULT;1.1;AES256',u'!vault-encrypted')
    ciphertext_data = ciphertext_data.encode("utf-8")
    # print("test_AnsibleConstructor_

# Generated at 2022-06-11 09:22:50.216100
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader

    base_constructor = AnsibleConstructor()
    cur_dict = {'a': 'b', 'b': 'c', 'c': 'd'}
    dumped_dict = base_constructor.represent_mapping('tag:yaml.org,2002:map', cur_dict, flow_style=False)
    node = AnsibleLoader(dumped_dict).get_single_node()

    constructor = AnsibleConstructor()
    new_mapping = constructor.construct_mapping(node)

    assert new_mapping == cur_dict
    assert new_mapping.ansible_pos == ('<string>', 1, 1)

# Generated at 2022-06-11 09:22:54.592286
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    class TestClass():
        def __init__(self, key, value):
            self.key = key
            self.value = value
        def __eq__ (self, other):
            if isinstance(other, self.__class__):
                return self.__dict__ == other.__dict__
            return False
    a = TestClass(1,2)
    b = TestClass(1,5)
    c = TestClass(2,2)
    d = TestClass(2,5)
    flow_style_data = [a,b,c,d]
    inline_data = [{a:a}, {b:b}, {c:c}, {d:d}]
    # Use AnsibleConstructor to parse flow style data
    for d in flow_style_data:
        lines = yaml

# Generated at 2022-06-11 09:23:01.455600
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_data = '''
    a: a
    b: b
    c: c
    d: d
    '''
    # testing with error, warning and ignore for duplicate dict key
    C.DUPLICATE_YAML_DICT_KEY = 'error'
    with pytest.raises(ConstructorError):
        yaml.load(test_data, Loader=AnsibleConstructor)
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    yaml.load(test_data, Loader=AnsibleConstructor)
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    yaml.load(test_data, Loader=AnsibleConstructor)

# Generated at 2022-06-11 09:23:12.985013
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    if sys.hexversion >= 0x03000000:
        from io import StringIO
    else:
        from StringIO import StringIO
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    yaml_str = "---\n- name: test\n  hosts: localhost\n  roles\n  - common\n  - web\n  become: yes\n...\n"
    yaml_stream = StringIO(unicode(yaml_str))

    try:
        ansible_constructor = AnsibleConstructor()
        ansible_constructor.construct_yaml_seq(yaml_stream)
    except ConstructorError as e:
        print("e.args: {0}\n".format(e.args))

# Generated at 2022-06-11 09:23:18.374911
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.parsing.yaml.objects

    assert isinstance(AnsibleConstructor.construct_mapping(mapping_node_mock), ansible.parsing.yaml.objects.AnsibleMapping)
    assert 'ansible_pos' in AnsibleConstructor.construct_mapping(mapping_node_mock)



# Generated at 2022-06-11 09:23:23.648977
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    import tempfile

    try:
        tmp = tempfile.NamedTemporaryFile(mode='w+')
        tmp.write(u'foo: !!python/unicode "bar"\n')
        tmp.flush()
        input_stream = open(tmp.name)
    except:
        raise
    # yaml parser
    kv = yaml.load(input_stream, AnsibleConstructor)
    # assert isinstance(kv['foo'], AnsibleUnicode)
    assert kv['foo'].ansible_pos == (u'<unicode string>', 0, 5)

# Generated at 2022-06-11 09:23:32.953837
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
  import collections

  class AnsibleConstructor(SafeConstructor):
    def __init__(self, file_name=None, vault_secrets=None):
        self._ansible_file_name = file_name
        super(AnsibleConstructor, self).__init__()
        self._vaults = {}
        self.vault_secrets = vault_secrets or []
        self._vaults['default'] = VaultLib(secrets=self.vault_secrets)

    def construct_yaml_map(self, node):
      data = AnsibleMapping()
      yield data
      data.update(self.construct_mapping(node))
      data.ansible_pos = self._node_position_info(node)
