

# Generated at 2022-06-11 09:15:11.464252
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()

    def construct_object(self, node):
        return object

    constructor.construct_object = construct_object.__get__(constructor, AnsibleConstructor)

    # arbitrary value
    arbitrary_value = object

    # arbitrary node
    arbitrary_node = object

    # arbitrary data
    arbitrary_data = constructor.construct_object(arbitrary_node)

    try:
        result = constructor.construct_yaml_unsafe(arbitrary_node)

        assert result is arbitrary_data
    except AssertionError:
        print(result)



# Generated at 2022-06-11 09:15:17.249614
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    example = """
- first
- second
- third
    """
    ac = AnsibleConstructor()
    seq = ac.construct_yaml_seq(ac.compose(example))

    assert (list(seq) == [u'first', u'second', u'third'])
    assert (next(seq) == [u'first', u'second', u'third'])

# Generated at 2022-06-11 09:15:24.352527
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    unsafe_text = AnsibleUnsafeText("{{ foo }}")
    unsafe_text_class_name = unsafe_text.__class__.__name__
    a = AnsibleConstructor()

    actual_output = a.construct_yaml_unsafe(unsafe_text)
    expected_output = AnsibleUnsafeText("{{ foo }}")

    assert actual_output.__class__.__name__ == unsafe_text_class_name
    assert actual_output == expected_output


# Generated at 2022-06-11 09:15:31.456151
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Tests the case where there are duplicate keys.
    # In the example below, bar appears twice and YAML
    # allows the second value to be used, overwriting
    # the first value.
    # For example, if C.DUPLICATE_YAML_DICT_KEY == warn,
    # then this code would display a warning since it presents
    # a possible bug in the yaml file.
    my_yaml = '''
foo:
  bar: one
  bar: two
'''
    print(AnsibleConstructor().construct_yaml_map(my_yaml))

# Generated at 2022-06-11 09:15:40.598245
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test empty string
    data = b'!vault |\n       $ANSIBLE_VAULT'
    doc = AnsibleLoader(data, vault_secrets='password').get_single_data()
    assert doc.vault_id is None
    assert doc.vault.secrets == ['password']
    assert doc.data == b''

    # Test full string

# Generated at 2022-06-11 09:15:50.087671
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    ansible_loader = AnsibleLoader(stream=u'foo: !unsafe { bar: baz }', file_name=u'foo.txt')
    assert isinstance(ansible_loader.get_single_data(), dict)
    ansible_loader = AnsibleLoader(stream=u'foo: !unsafe { bar: | baz }', file_name=u'foo.txt')
    assert isinstance(ansible_loader.get_single_data(), dict)
    ansible_loader = AnsibleLoader(stream=u'foo: !unsafe { bar: baz }', file_name=u'foo.txt')
    assert isinstance(ansible_loader.get_single_data(), dict)

# Generated at 2022-06-11 09:16:00.204343
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_lib = VaultLib(secrets=['vault_pass'])
    secret_data = u'vault_password'
    plaintext_data = u'test_variable'

    # test if ciphertext data is encrypted and can be decrypted
    ciphertext_data = vault_lib.encrypt(plaintext_data)
    vault_encrypted_data = u'!vault |\n  %s' % ciphertext_data
    ansible_constructor = AnsibleConstructor(vault_secrets=['vault_pass'])
    ansible_constructor._vaults['default'] = vault_lib



# Generated at 2022-06-11 09:16:06.444223
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    '''
    AnsibleConstructor: construct_vault_encrypted_unicode
    '''
    _test_AnsibleConstructor_construct_vault_encrypted_unicode(
        '$ANSIBLE_VAULT;1.1;AES256',
        'ansible-vault view group_vars/all',
        'ansible-vault view group_vars/all',
        '$ANSIBLE_VAULT;1.1;AES256'
        )


# Generated at 2022-06-11 09:16:09.309365
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    obj = AnsibleConstructor()
    assert obj.construct_yaml_map({'foo': 'bar'}) == {'foo': 'bar'}


# Generated at 2022-06-11 09:16:14.446857
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    actual = {"test_key": ["test_value"]}
    expected = {"test_key": AnsibleSequence(["test_value"])}
    assert(expected == AnsibleConstructor("").construct_yaml_seq(None).__next__())
    assert(expected["test_key"].ansible_pos[0] == "<string>")



# Generated at 2022-06-11 09:16:31.863059
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    display.display("Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor")
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_pass = "1234"
    vault = VaultLib([vault_pass])
    plaintext = "hello"
    ciphertext = vault.encrypt(plaintext)
    expected_node = AnsibleVaultEncryptedUnicode(ciphertext)
    expected_node.vault = vault
    constructor = AnsibleConstructor(vault_secrets=[vault_pass])
    yaml_node = yaml.nodes.ScalarNode(tag=u'!vault-encrypted', value=ciphertext, anchor=None, style=None)
    result_node = constructor.construct_

# Generated at 2022-06-11 09:16:42.398069
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils._text import to_text

    assert isinstance(yaml.load("{a: 1}", Loader=yaml.Loader), AnsibleMapping)
    assert isinstance(yaml.load("{a: 1, b: 2}", Loader=yaml.Loader), AnsibleMapping)

    assert isinstance(yaml.load("""
    a: 1
    b: 2
    """, Loader=yaml.Loader), AnsibleMapping)

    with pytest.raises(yaml.constructor.ConstructorError):
        yaml.load("{a: 1, a: 2}", Loader=yaml.Loader)


# Generated at 2022-06-11 09:16:47.114508
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    yaml = AnsibleConstructor(file_name=None, vault_secrets=None)

    data = yaml.construct_yaml_map(node)
    assert isinstance(data, AnsibleMapping)



# Generated at 2022-06-11 09:16:57.568987
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:17:06.857118
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode

# Generated at 2022-06-11 09:17:13.093580
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import tempfile
    # Create test data
    ciphertext = b'sdfsdfsdfsdf'
    # Create test class
    ac = AnsibleConstructor()
    # Create test node
    class Node():
        pass
    node = Node
    node.id = 'vault'
    node.start_mark = Node()
    node.start_mark.name = 'test'
    node.start_mark.line = '1'
    node.start_mark.column = '1'
    node.value = ciphertext
    # Test
    vault_result = ac.construct_vault_encrypted_unicode(node)
    assert isinstance(vault_result, AnsibleVaultEncryptedUnicode)
    assert vault_result.data == ciphertext
    assert vault_result.vault.secrets is None

# Generated at 2022-06-11 09:17:25.015025
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = MappingNode(None, None, None, None)
    node.start_mark = 'foo'
    node.end_mark = 'bar'
    node.line = 2
    node.column = 3
    node.value = 'foo'

    for vault_version in [1, 2]:
        vault_secret = VaultLib.new_secret()
        vault = VaultLib(vault_secret)
        vault_text = vault.encrypt(b'secret')
        vault.secrets = [vault_secret]

        # test if we can decrypt a vanilla message
        b_ciphertext_data = vault.encrypt(b'plaintext')
        ret = AnsibleVaultEncryptedUnicode(b_ciphertext_data)
        ret.vault = vault


# Generated at 2022-06-11 09:17:30.885386
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    obj = dict(
        test1='value1',
        test2='value2',
        test3=10,
        test4='value4',
        test5=12,
    )

    data = """
    ---
    test1: value1 #assigned to test1
    test2: value2 #assigned to test2
    test3: !unsafe value3 #assigned to test3
    test4: !unsafe 10 #assigned to test4
    """

    y = yaml.load(data, Loader=AnsibleConstructor)
    y['test5'] = 12

    assert obj == y

# Generated at 2022-06-11 09:17:36.132983
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = AnsibleMapping()
    node = MappingNode()
    data.update(node.value)

    node.ansible_pos = AnsibleConstructor._node_position_info(node)
    actual = AnsibleConstructor.construct_yaml_map(node)
    assert next(actual) == data
    assert next(actual) == node.value
    assert next(actual).ansible_pos == node.ansible_pos



# Generated at 2022-06-11 09:17:48.515683
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

# Generated at 2022-06-11 09:17:59.663712
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = """
- key1:
    value1:
        value2: [1, 2, 3]
    key2: value3
""".splitlines()

    yaml_data = list(yaml.load_all(data, Loader=AnsibleConstructor))[0]

    assert yaml_data[0].key1.value1.value2[1] == 2

# Generated at 2022-06-11 09:18:02.669953
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    yaml_data = yaml.load(u'foo: !unsafe "bar"', Loader=AnsibleConstructor)

    assert yaml_data.get(u'foo') == u'bar'

# Generated at 2022-06-11 09:18:11.657612
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.compat.tests import unittest

    class TestAnsibleConstructor_construct_yaml_seq(unittest.TestCase):

        values = [['a', 'b', 'c', 'd', 'e'],
                  ('a', 'b', 'c', 'd', 'e'),
                  set([0, 1, 2, 3, 4]),
                  {'a': 'b', 'c': 'd'},
                  {'a': 'b', 'c': 'd', 'e': 'f'}]

        def test_AnsibleConstructor_construct_yaml_seq(self):
            for value in self.values:
                yaml_data = yaml.dump(value)


# Generated at 2022-06-11 09:18:18.405263
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from fractions import Fraction

    constructor = AnsibleConstructor()

    test_fragments = [
        b'!unsafe 123',
        b'!unsafe "foo bar"',
    ]
    for test_fragment in test_fragments:
        result = constructor.construct_yaml(test_fragment)
        assert isinstance(result, AnsibleUnsafeText)
        assert isinstance(result.as_raw(), Fraction)

# Generated at 2022-06-11 09:18:22.077042
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    map_node = ansible_constructor.construct_yaml_map("a: 1")
    map_node = list(map_node)
    assert map_node[0]["a"] == 1

# Generated at 2022-06-11 09:18:27.739318
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    class FakeNode:
        id = 'foo'
    fake_node = FakeNode()
    my_class = AnsibleConstructor()
    my_class.construct_foo = lambda x: x
    result = my_class.construct_yaml_unsafe(fake_node)
    expected = wrap_var(fake_node)
    assert result == expected

# Generated at 2022-06-11 09:18:33.409545
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    d = {'a': [1, 2, 3], 'b': ['a', 'b', 'c']}
    data = AnsibleLoader(d, None).get_single_data()
    assert data == d
    #import pytest
    #with pytest.raises(Exception) as exc:
    #    AnsibleConstructor.construct_yaml_seq()
    #assert 'no arguments' in str(exc.value)

# Generated at 2022-06-11 09:18:41.997118
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = {'key': ['value1', 'value2']}
    serialized = AnsibleDumper(Dumper=AnsibleDumper).dump(data)
    assert serialized == '{key: [value1, value2]}\n'
    deserialized = AnsibleLoader(stream=serialized).get_single_data()
    assert deserialized == data
    assert isinstance(deserialized, AnsibleMapping)
    assert isinstance(deserialized['key'], AnsibleSequence)
    assert isinstance(deserialized['key'][0], AnsibleUnicode)

# Generated at 2022-06-11 09:18:55.751231
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # test yaml.dump()'s representation of the class to test
    # this is done to test if the behaviour of AnsibleConstructor
    # and AnsibleConstructor.construct_yaml_unsafe has changed
    test_data = AnsibleUnsafeText("foo")
    import yaml
    assert yaml.dump(test_data) == "!!python/object/new:ansible.parsing.yaml.objects.AnsibleUnsafeText {_text: foo}\n"

    # test that AnsibleConstructor.construct_yaml_unsafe()
    # returns an object with the same class
    assert type(AnsibleConstructor().construct_yaml_unsafe(test_data)) is AnsibleUnsafeText

    # test that the

# Generated at 2022-06-11 09:19:04.980143
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Arrange
    node = MappingNode(tag=u'tag:yaml.org,2002:map',
                            value=[(key, value)
                                      for key, value in [
                                          (u'name',
                                              u'Test_name'),
                                         (u'age',
                                              u'Test_age'),
                                         (u'profession',
                                              u'Test_profession')
                                         ]
                                    ],
                            anchor=None,
                            start_mark=None,
                            end_mark=None,
                            mapping_type=None)

    my_test_object = AnsibleConstructor()

    # Act
    actual = my_test_object.construct_yaml_map(node)

    # Assert

# Generated at 2022-06-11 09:19:22.435637
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    class FakeNode(object):
        id = None
        start_mark = None

        def __init__(self, fake_id):
            self.id = fake_id

    constr = AnsibleConstructor()

    assert constr.construct_yaml_unsafe(FakeNode('int')) == AnsibleUnsafe(1)
    assert constr.construct_yaml_unsafe(FakeNode('float')) == AnsibleUnsafe(1.1)
    assert constr.construct_yaml_unsafe(FakeNode('str')) == AnsibleUnsafe('str')
    assert constr.construct_yaml_unsafe(FakeNode('list')) == AnsibleUnsafe([1])

# Generated at 2022-06-11 09:19:33.686378
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:19:42.720822
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    data = '''
active_id: 1
app:
  admin_id: 1
  includes:
    - "//config/app.php"
  name: Application
  path: /Users/cst/Sites/workbench/app
  url: http://app.localhost
  user_id: 1
description:
  en: |-
    Project Framework

    Framework for Laravel 4 development.
framework:
  admin_id: 1
  name: Foundation
  path: /Users/cst/Sites/workbench/foundation
key: foundation
'''
    value = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(value['framework'], AnsibleMapping)

# Generated at 2022-06-11 09:19:51.718629
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os.path
    from ansible.compat.tests.mock import patch
    from ansible.parsing.yaml import load

    # Path to the yaml file we're going to mock.
    file_name = os.path.join(os.path.dirname(sys.modules[__name__].__file__), 'data', 'construct_mapping_data.yml')

    import yaml

    def mock_open_file_read(*args, **kwargs):
        """Function for mocking open(file_name, 'r') with our yaml data"""
        if args[0] == file_name:
            return to_bytes(yaml.dump({'first_key': 'first_value', 'second_key': 'second_value'}))

# Generated at 2022-06-11 09:19:56.339989
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    x = yaml.load('''
foo:
- 1
- 2
''', Loader=AnsibleConstructor)
    assert x['foo'][0] == 1
    assert x['foo'][1] == 2
    assert isinstance(x['foo'], AnsibleSequence)
    assert type(x['foo']) is not list



# Generated at 2022-06-11 09:20:05.762767
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Create a vault with a password
    vault = VaultLib(['pass'])

    # Create a ciphertext
    ciphertext = vault.encrypt(b'test')

    # Create the node
    class Node:
        pass

    node = Node()
    node.start_mark = Node()
    node.start_mark.line = 1
    node.start_mark.column = 0

    # Construct the encrypted unicode
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults['default'] = vault
    ansible_constructor.vault_secrets = ['pass']
    encrypted_unicode = ansible_constructor.construct_

# Generated at 2022-06-11 09:20:15.094425
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class FakeNode:
        def __init__(self, val=None, start_mark=None):
            self.value = val
            self.start_mark = start_mark

        def __getitem__(self, key):
            return self.value[key]


    ac = AnsibleConstructor(file_name=None, vault_secrets=[])
    d = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
    }

    dup_node_2 = FakeNode(val=('key1', FakeNode(val='value3', start_mark=None)), start_mark=None)

# Generated at 2022-06-11 09:20:24.769341
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    # Constructor test
    yaml_data = '''
    - b:
        c: 1
        d: 2
      e:
      - foo
      - bar
      f:
      - baz
    '''
    constructor = AnsibleConstructor()

# Generated at 2022-06-11 09:20:32.504305
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import copy
    enc_key = '$ANSIBLE_VAULT;1.1;AES256\ntookie\ntookie\n'
    cipher = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\ntookie\ntookie\n'
    node = SafeConstructor.construct_yaml_scalar(AnsibleConstructor, cipher)
    vault_cipher = AnsibleConstructor.construct_vault_encrypted_unicode(AnsibleConstructor, node)
    assert enc_key == vault_cipher
    assert copy.deepcopy(2) == vault_cipher.vault.decrypt(enc_key)

# Generated at 2022-06-11 09:20:40.255838
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    vault_pass = 'passw0rd'
    vault_obj = VaultLib(secrets=[vault_pass])
    vault_encrypted_string = vault_obj.encrypt('testing')
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets.append(vault_pass)
    ansible_constructor._vaults['default'] = vault_obj

    # Use AnsibleConstructor to construct a vault-encrypted string and verify it's type is AnsibleVaultEncryptedUnicode
    # and that it decodes back to 'testing'

# Generated at 2022-06-11 09:21:15.526483
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:21:24.342330
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-11 09:21:33.776588
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['toto']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    constructor.vault_secrets = vault_secrets

# Generated at 2022-06-11 09:21:42.483029
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-11 09:21:52.447173
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible import module_utils
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

    import sys
    import types

    yaml_str = u'---\n!unsafe False\n'
    m = module_utils.basic.AnsibleModule(argument_spec={})
    ac = AnsibleConstructor(file_name=u'<yaml>')

    # Python 2/3 compatible
    if sys.version_info[0] < 3:
        assert u'bool' == types.UnicodeType(m.from_yaml(yaml_str)).__name__
    else:
        assert u'bool' == type(m.from_yaml(yaml_str)).__name__

    # Python 2/3 compatible

# Generated at 2022-06-11 09:21:56.461080
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    input_data = '''
foo: bar
'''
    loader = AnsibleLoader(input_data)
    data = loader.get_single_data()
    assert isinstance(data['foo'], AnsibleUnicode)

# Generated at 2022-06-11 09:21:57.436577
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from io import StringIO
    impo

# Generated at 2022-06-11 09:22:06.133124
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class AnsibleConstructor_construct_mapping_ConstructorError(ConstructorError):
        pass

    class AnsibleConstructor_construct_mapping_ConstructorError_context(ConstructorError):
        pass

    class AnsibleConstructor_construct_mapping_MappingNode(MappingNode):
        pass

    class AnsibleConstructor_construct_mapping_AnsibleMapping(AnsibleMapping):
        pass

    def test_AnsibleConstructor_construct_mapping_mock_construct_object(node):
        return node

    # Do not override SafeConstructor.mapping_tag

    if 'mapping_tag' in globals():
        del globals()['mapping_tag']
    if 'construct_object' in globals():
        del globals()['construct_object']


# Generated at 2022-06-11 09:22:16.663330
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class MyConstructor(AnsibleConstructor):

        @staticmethod
        def _get_data():
            """
            This method returns a list of tuples, each tuple contains:
            - the name of the item
            - a dict of the input to construct_yaml_map
            - a dict representing the expected output of construct_yaml_map
            """
            data = []

            my_dict = {}
            data.append(('my_dict', my_dict, {}))

            my_dict = {'a': 'b'}
            data.append(('my_dict', my_dict, {'a': 'b'}))

            my_dict = {'a': 'b', 'c': 'd', 'e': None}

# Generated at 2022-06-11 09:22:26.312084
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    file_name = 'test_AnsibleConstructor_file'
    ansible_constructor = AnsibleConstructor(file_name)

    value = []
    node = MappingNode(u"tag:yaml.org,2002:map", value, start_mark=None, end_mark=None, flow_style=False)
    ansible_constructor.flatten_mapping(node)
    data = AnsibleSequence()
    assert data == ansible_constructor._AnsibleConstructor__construct_yaml_seq(node)



# Generated at 2022-06-11 09:23:09.212533
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.dumper import Dumper
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer

    file_name=''
    vault_secrets=[]
    constr = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    buf = 'test_buf'
    reader = Reader(buf)
    scanner = Scanner(reader)
    parser = Parser(scanner)
    composer = Composer(parser, resolver)
    dumper = Dumper()
    value = 'test_value'
    node = 'test_node'
    constr.construct_scalar = Mock(return_value=value)
    constr.construct_vault_

# Generated at 2022-06-11 09:23:19.850114
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_case1 = {
        'x': {'y': 1, 'z': 3},
        'a': 2,
        'b': 3,
        'c': [{'x': 4}]
    }

    test_case2 = {
        'a': 1,
        'a': 2
    }

    test_case3 = {
        'a': 1,
        'a': 2,
        'b': {'c': 3},
        'b': {'d': 4}
    }

    ac = AnsibleConstructor()
    if not isinstance(ac.construct_mapping(test_case1), AnsibleMapping):
        raise AssertionError("Failed to Assert AnsibleConstructor.construct_mapping")


# Generated at 2022-06-11 09:23:20.931747
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # TODO: add here some unit tests for method construct_yaml_map of class AnsibleConstructor
    pass


# Generated at 2022-06-11 09:23:29.711439
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-11 09:23:33.482082
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    arg = AnsibleUnicode('test')
    ansible_const = AnsibleConstructor()

    assert ansible_const.construct_yaml_str(arg) is arg
    assert ansible_const.construct_yaml_str('test') == arg

# Generated at 2022-06-11 09:23:37.803683
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert AnsibleConstructor is not object
    assert AnsibleConstructor is not None
    assert callable(AnsibleConstructor)
    assert AnsibleConstructor.construct_yaml_map is not object
    assert AnsibleConstructor.construct_yaml_map is not None
    assert callable(AnsibleConstructor.construct_yaml_map)



# Generated at 2022-06-11 09:23:46.054323
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test for duplicate keys in input data
    node = MappingNode(tag=u'tag:yaml.org,2002:map',
                       value=[(u'aa', 'bb'), (u'aa', 'cc')],
                       start_mark=object(),
                       end_mark=object())
    ac = AnsibleConstructor()
    with ac._vaults['default']:
        # Test with no error
        ac.vault_secrets = ['secret0']
        assert ac.construct_yaml_map(node).next() == {u'aa': 'cc'}
        assert ac.construct_yaml_map(node).next() == {u'aa': 'cc'}
        # Test with error
        ac.vault_secrets = None

# Generated at 2022-06-11 09:23:52.287562
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None)
    data = '[1, 2, 3, 4]'
    seq = loader.get_single_data(data)
    assert isinstance(seq, AnsibleSequence)
    assert isinstance(seq[0], int)


# Generated at 2022-06-11 09:23:53.073007
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    pass

# Generated at 2022-06-11 09:24:04.640265
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # test with no vault passwords and no vault passwords on command line
    display.verbosity = 0
    a = AnsibleConstructor(vault_secrets=[])
    v = a.construct_vault_encrypted_unicode(object)
    assert v is not None
    assert type(v) == AnsibleVaultEncryptedUnicode

    # test with no vault passwords and vault password on command line
    display.verbosity = 0
    a = AnsibleConstructor(vault_secrets=[])
    v = a.construct_vault_encrypted_unicode(object)
    assert v is not None
    assert type(v) == AnsibleVaultEncryptedUnicode

    # test with vault password and vault password on command line
    display.verbosity = 0