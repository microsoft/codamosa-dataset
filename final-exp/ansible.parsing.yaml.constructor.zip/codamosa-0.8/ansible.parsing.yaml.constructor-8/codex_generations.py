

# Generated at 2022-06-11 09:15:11.266821
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    c = AnsibleConstructor()

    test_data = [
        ('hello', 'hello'),
        ('h\ne\n\tl\nl\no', 'h\ne\n\tl\nl\no'),
    ]

    for data, expected in test_data:
        value = c.construct_yaml_str(data)
        assert expected == value

# Generated at 2022-06-11 09:15:22.069040
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.parsing.yaml.loader
    yaml_str = '''
a:
  b:
    - one
    - two
    - three
  c: four
  d:
   - five
   - six
  f:
    - g: seven
      h: eight
      i:
       - nine
       - ten
    - j: eleven
      k: twelve
      l: thirteen
'''
    data = ansible.parsing.yaml.loader.load(yaml_str)
    assert len(data.keys()) == 1, 'length of parsed data != 1'
    assert data['a']['b'][1] == 'two', 'value of parse data != "two"'

# Generated at 2022-06-11 09:15:31.190102
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping

    node = MappingNode(u'tag:yaml.org,2002:map', [], [], None, None)
    node.start_mark = object()
    node.end_mark = object()
    node.value = [
            [MappingNode(u'tag:yaml.org,2002:str', ['foo']),
                MappingNode(u'tag:yaml.org,2002:str', ['bar'])],
            [MappingNode(u'tag:yaml.org,2002:str', ['baz']),
                MappingNode(u'tag:yaml.org,2002:str', ['bob'])]
    ]

    cons = AnsibleConstructor()

    ansible_map = cons.construct_yaml_map

# Generated at 2022-06-11 09:15:40.518472
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text
    # pass the test
    sample_dict = {'key1':'value1', 'key2':'value2'}
    text = b'''key1: value1
key2: value2
'''
    loader = AnsibleLoader(text, 'construct_yaml_map.yaml')
    data = loader.get_single_data()
    
    assert data == sample_dict
    assert isinstance(data, dict)

    # failed the test
    sample_dict = {'key1':'value1', 'key1':'value2'}
    text = b'''key1: value1
key1: value2
'''

# Generated at 2022-06-11 09:15:45.159356
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    '''
    Testcase for method construct_yaml_seq of class AnsibleConstructor.
    '''
    data = [
        'a',
        'b',
        10,
    ]
    AnsibleConstructor.yaml_vault_secrets = None
    ans_const = AnsibleConstructor()
    ans_const.construct_yaml_seq(data)


# Generated at 2022-06-11 09:15:55.871251
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test case parameters:
    # AnsibleConstructor.construct_yaml_str is the object under test.
    # str_node_str is a string representation of the input node for construct_yaml_str method. It is converted to a node
    # object by parse_yaml_str.

    # Test case 1: Test when the input is node object with tag yaml.org,2002:str
    node_str = '''!<tag:yaml.org,2002:str> some_value'''
    ret = AnsibleConstructor.construct_yaml_str(AnsibleConstructor.parse_yaml_str(node_str))
    assert isinstance(ret, AnsibleUnicode)
    assert ret == 'some_value'

    # Test case 2: Test when the input is object with tag yaml.org,2002:python

# Generated at 2022-06-11 09:15:58.595952
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()
    node = {'id': u'bool', 'value': True}
    value = constructor.construct_yaml_unsafe(node)
    assert value is True

# Generated at 2022-06-11 09:15:59.452719
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass



# Generated at 2022-06-11 09:16:03.369127
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    ansible_constructor = AnsibleConstructor()

    node = "yaml.org/str"
    value = ansible_constructor.construct_yaml_str(node)
    assert isinstance(value, AnsibleUnicode)
    assert value == "yaml.org/str"



# Generated at 2022-06-11 09:16:11.629471
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import datetime
    test_yaml_input = {'key_a': 'value_a',
                       'key_b': 'value_b',
                       'key_a': 'value_a_changed',
                       'key_c': datetime.datetime(2018, 1, 4, 5, 0, 0)}
    constructor = AnsibleConstructor()
    mapping_node_instance = constructor.construct_yaml_map(MappingNode())
    mapping = constructor.construct_mapping(mapping_node_instance)
    assert mapping == test_yaml_input


# Generated at 2022-06-11 09:16:28.365558
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = """
---
- test1
- test2
- test3
- test4
"""

    from ansible.parsing.yaml import AnsibleLoader
    yaml_data = AnsibleLoader(data).get_single_data()
    assert yaml_data[0] == 'test1'
    assert yaml_data[1] == 'test2'
    assert yaml_data[2] == 'test3'
    assert yaml_data[3] == 'test4'

# Generated at 2022-06-11 09:16:37.138259
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import nodes

    node = nodes.ScalarNode(tag='tag:yaml.org,2002:str', value='value', start_mark='mark', end_mark='mark')
    a = AnsibleConstructor()
    assert isinstance(a.construct_yaml_str(node), str)

    node = nodes.ScalarNode(tag='tag:yaml.org,2002:python/unicode', value='value', start_mark='mark', end_mark='mark')
    a = AnsibleConstructor()
    assert isinstance(a.construct_yaml_str(node), str)

# Generated at 2022-06-11 09:16:45.218417
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    def assert_equal_unwrapped(tag, value):
        assert_equal(value, unwrapped)

    import unittest
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils import context_objects as co
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import text_type, assert_equal
    from io import StringIO

    out = StringIO()

    class TestModuleCLI(object):
        def __init__(self):
            self.verbosity = 0
            self.no_log = True

    display = Display()
    display.verbosity = 3

    co.GlobalCLIArgs = TestModuleCLI()


# Generated at 2022-06-11 09:16:52.033214
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # test_constructor = AnsibleConstructor()
    # test_node = yaml.nodes.MappingNode()
    # result = test_constructor.construct_yaml_map(test_node)
    # assert result.ansible_pos is not None
    # assert result.ansible_pos[0] is None
    # assert result.ansible_pos[1] is None
    # assert result.ansible_pos[2] is None
    # assert result == {}
    raise Exception('Unimplemented test')

# Generated at 2022-06-11 09:16:55.057334
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    a = AnsibleConstructor()
    assert a.construct_yaml_unsafe('test') == wrap_var('test')
    assert a.construct_yaml_unsafe(123) == wrap_var(123)

# Generated at 2022-06-11 09:17:04.077855
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class DummyNode(AnsibleBaseYAMLObject):
        def __init__(self, value):
            self.value = value

    node1 = DummyNode("foo")
    node2 = DummyNode("")

    ac = AnsibleConstructor()

    assert ac.construct_yaml_str(node1) == u'foo'
    assert isinstance(ac.construct_yaml_str(node1), AnsibleUnicode)
    assert ac.construct_yaml_str(node2) == u''
    assert isinstance(ac.construct_yaml_str(node2), AnsibleUnicode)



# Generated at 2022-06-11 09:17:10.943413
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    input_text = '''
{key_1: value_1, key_2: value_2}
    '''
    input_text = textwrap.dedent(input_text)
    yaml_node = yaml.compose(input_text)
    node = next(yaml_node.value)
    assert isinstance(node, yaml.nodes.MappingNode)
    data = next(AnsibleConstructor.construct_yaml_map(yaml_node))
    assert 'key_1' in data
    assert data['key_1'] == 'value_1'
    assert 'key_2' in data
    assert data['key_2'] == 'value_2'


# Generated at 2022-06-11 09:17:19.744729
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    yaml_text = "!unsafe '{\"_python_object\": \"datetime.datetime(2017, 2, 10, 14, 0, 15, 874716)\"}'"
    obj = yaml.load(yaml_text, Loader=AnsibleLoader)
    assert(isinstance(obj, AnsibleUnsafeText))
    assert(obj == u"{u'_python_object': u'datetime.datetime(2017, 2, 10, 14, 0, 15, 874716)'}")


# Generated at 2022-06-11 09:17:22.412199
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # TODO: Fix test_AnsibleConstructor_construct_yaml_seq
    pass

# Generated at 2022-06-11 09:17:30.663138
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Given
    test_input = (
        (dict(key1="value1", key2="value2"), dict(key1="value3")),
        (dict(key1="value1", key2="value2"), dict(key2="value3")),
        (dict(key1="value1", key2="value2"), dict(key1="value3", key2="value3")),
    )
    test_expect = (
        dict(key1="value3"),
        dict(key1="value1", key2="value3"),
        dict(key1="value3", key2="value3"),
    )

# Generated at 2022-06-11 09:17:44.547125
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = """
    - 1
    - 2
    - 3
    """
    answer = [1, 2, 3]

# Generated at 2022-06-11 09:17:53.459097
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import json

    class AnsibleConstructorForTest(AnsibleConstructor):
        def __init__(self):
            super(AnsibleConstructorForTest, self).__init__()
            self.ansible_types = []

        def construct_yaml_unsafe(self, node):
            self.ansible_types.append('string' if node.value == 'a' else type(node.value))
            return super(AnsibleConstructorForTest, self).construct_yaml_unsafe(node)

        def construct_json_unsafe(self, node):
            self.ansible_types.append('json')
            return super(AnsibleConstructorForTest, self).construct_yaml_unsafe(node)

    test_con = AnsibleConstructorForTest()


# Generated at 2022-06-11 09:18:02.244795
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    # Note:The 'construct_yaml_map' method of class AnsibleConstructor
    # is intended to be overridden by the 'AnsibleConstructor' class.  This
    # method is used to provide a replacement for 'construct_yaml_map' when
    # running the unit test. It is not necessary to have this method in the
    # class when using 'AnsibleConstructor' in an application.
    def construct_yaml_map(self, node):
        data = AnsibleMapping()
        yield data
        value = self.construct_mapping(node)
        data.update(value)
        data.ansible_pos = self._node_position_info(node)
        # The following line is used to print the value of the variable 'data'
        # this is to assist while writing unit tests.


# Generated at 2022-06-11 09:18:08.891374
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import io
    from io import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    dumper = AnsibleDumper()
    loader = AnsibleLoader(stream=StringIO(u'test: foo'))
    loader.get_single_data()
    test_node = loader.compose_document()
    test_map = AnsibleConstructor(file_name='<string>').construct_mapping(test_node)
    assert test_map == {u'test': u'foo'}

# Generated at 2022-06-11 09:18:18.692613
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml = """
        a: &a !!python/unicode "I am not a string"
        b: &b !!python/unicode "{{ *a }}"
      """

    # Initialize the constructor with the yaml
    ac = AnsibleConstructor(file_name=None, vault_secrets=None)
    ac.safe_constructors['!unsafe'] = ac.construct_yaml_unsafe

    # Load the yaml
    data = yaml_load(yaml, Loader=yaml.Loader, Constructor=ac)

    # Print the data
    print(data)
    # {'a': 'I am not a string', 'b': 'I am not a string'}


if __name__ == '__main__':
    test_AnsibleConstructor_construct_yaml_unsafe()

# Generated at 2022-06-11 09:18:30.092234
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    doc = u'''
---
a:
  b: 1
  b: 2
'''

    def test_construct_mapping(key_value):
        data = AnsibleMapping()
        data.update(key_value)
        return data

    def validate(result):
        if result.get('a', {}).get('b') != 2:
            raise Exception("Failed")

    # test_construct_mapping
    loader = AnsibleLoader(doc, None)
    mapping = test_construct_mapping(loader.get_single_data())
    validate(mapping)

    # construct_mapping
    loader = AnsibleLoader(doc, None)
    mapping = AnsibleConstructor.construct_mapping(loader)

# Generated at 2022-06-11 09:18:39.722030
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    yaml_data = """
- key: 1
- key: 2
- key: 3
"""

    def assert_correct_position(yaml_data):
        data = yaml.load(yaml_data, Loader=AnsibleConstructor)
        assert isinstance(data, list)
        first_node_position = data[0].ansible_pos
        assert first_node_position[0] == '<string>'
        assert first_node_position[1] == 1
        assert first_node_position[2] == 1
        second_node_position = data[1].ansible_pos
        assert second_node_position[0] == '<string>'
        assert second_node_position[1] == 2
        assert second_node_position[2] == 1
        third_node

# Generated at 2022-06-11 09:18:51.698349
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor(file_name='test-file')
    tm = 'tag:yaml.org,2002:map'
    # tm = {'tag': 'yaml.org,2002:map', 'anchor': None, 'implicit': True, 'value': None, 'style': None}
    tm = MappingNode(tm, [], [], None)
    res = None
    for r in a.construct_yaml_map(tm):
        res = r
    assert isinstance(res, AnsibleMapping)
    assert res == {}
    assert len(res) == 0
    assert res.ansible_pos == ('test-file', 1, 1)


# Generated at 2022-06-11 09:19:02.188084
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    import sys
    from io import StringIO

    from ansible.parsing.yaml import AnsibleLoader
    from ansible.parsing.yaml.loader import AnsibleLoaderInterpolated

    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Load
    src = StringIO(u'{a: 1, b: 2}')

    # Test
    loader = AnsibleLoader(src, '<string>')
    obj   = loader.get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert isinstance(obj['a'], AnsibleUnicode)
    assert obj['a'] == '1'
    assert isinstance(obj['b'], AnsibleUnicode)
    assert obj['b'] == '2'

    # Load

# Generated at 2022-06-11 09:19:11.941095
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['default-test-value']

    # An AnsibleConstructor object is created, or no vault_secrets are set
    assert AnsibleConstructor(vault_secrets=None)._vaults['default'].secrets is None
    assert AnsibleConstructor(vault_secrets=[])._vaults['default'].secrets is None
    assert AnsibleConstructor()._vaults['default'].secrets is None

    # vault_secrets is set to an empty list
    node = MappingNode(None, None, False, None)
    node.start_mark = 'start_mark'
    assert AnsibleConstructor(vault_secrets=[]).construct_vault_encrypted_unicode(node=node) == ''

    # vault_secrets is set to a non-empty list

# Generated at 2022-06-11 09:19:43.723105
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    yaml_unsafe_str = '''
---
    - {a: {'!unsafe': "{{ '{' }}" }}
    - {a: {'!unsafe': "{'{'}" }}
    - {a: {'!yaml-unsafe': "{{ '{' }}" }}
    - {a: {'!yaml-unsafe': "{'{'}" }}
    - {a: {'!yaml-safe': "{{ '{' }}" }}
    - {a: {'!yaml-safe': "{'{'}" }}
'''

    data = yaml.load(yaml_unsafe_str, Loader=AnsibleConstructor)
    assert data[0]['a'] == {'!unsafe': u"{{ '{' }}"}

# Generated at 2022-06-11 09:19:52.443372
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    my_map = {'one': 1, 'two': 'dos', 'three': [1, 2, 3]}

    # Dump the YAML
    stream = yaml.dump(my_map, Dumper=AnsibleDumper, default_flow_style=False, allow_unicode=True)

    # Load the YAML into a native Python data structure
    data = yaml.load(stream, Loader=AnsibleConstructor)

    assert data['two'] == u'dos'

    assert type(data['two']) == AnsibleUnicode
    assert data['two'] == u'dos'
    assert data['two'] == 'dos'

    assert type(data['three'][0]) == AnsibleUn

# Generated at 2022-06-11 09:19:57.610151
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_node = "a"
    test_constructor = AnsibleConstructor
    # TODO: figure out why we're getting this error: test_constructor.construct_yaml_map() expected an instance of
    # TODO: 'yaml.MappingNode', got 'str'
    # test_constructor.construct_yaml_map(test_node)

# Generated at 2022-06-11 09:20:06.861951
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    stream = StringIO("""
    foo:
      - alpha
      - beta
      - gamma

    bar:
      - one
      - two
      - three
    """)

    data = yaml.load(stream, Loader=AnsibleLoader)

    assert isinstance(data['foo'], AnsibleSequence)
    assert isinstance(data['bar'], AnsibleSequence)

    value = AnsibleSequence([AnsibleUnicode("alpha"),
                             AnsibleUnicode("beta"),
                             AnsibleUnicode("gamma")])
    assert data['foo'] == value

    value = AnsibleSequence

# Generated at 2022-06-11 09:20:08.285525
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass   # implemented in test_loader.py



# Generated at 2022-06-11 09:20:16.058665
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import textwrap
    import yaml

    data = textwrap.dedent("""\
        foo: bar
        bar:
          baz: foo
          foo: baz
        duplicate:
          baz: foo
          foo: baz
          foo: baz""")

    with warnings.catch_warnings(record=True) as warn_list:
        warnings.simplefilter("always")

        data = yaml.load(data, Loader=yaml.Loader)

        assert data == {'bar': {'foo': 'baz', 'baz': 'foo'}, 'foo': 'bar', 'duplicate': {'baz': 'foo', 'foo': 'baz'}}, data



# Generated at 2022-06-11 09:20:26.114901
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    # Create Vault password
    vault_pass = 'ansible'
    vault_pass_bytes = to_bytes(vault_pass, encoding='utf-8', errors='surrogate_or_strict')

    # Create VaultEditor with given password
    vault = VaultEditor(vault_pass_bytes)
    secret = vault.encrypt('ansible')
    node_scalar = AnsibleDumper().represent_scalar(u'!vault', u'$ANSIBLE_VAULT;1.3;AES256;myuser\n%s\n' % secret)

    # Create Vault password

# Generated at 2022-06-11 09:20:30.337038
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor()
    sample = {'1': 1, '2': 2, '3': 3}
    dup_key = {'1': 1, '1': 1}
    mapping_node = c.construct_yaml_map(sample)
    mapping_node_dup = c.construct_yaml_map(dup_key)

# Generated at 2022-06-11 09:20:34.424748
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml import AnsibleLoader
    import yaml

    def test(data, expected_results):
        constructor = AnsibleConstructor()
        # we need to use the safe loader here as otherwise we won't get AnsibleMappings back
        loader = AnsibleLoader(constructor)

        src = '''\
        - hosts: all
          tasks:
          - name: test
            shell: echo hi
          {0}
        '''.format(data)

        results: AnsibleMapping = loader.load(src)

        assert isinstance(results, list)
        assert len(results) == 1

        results = results.pop()
        assert isinstance(results, AnsibleMapping)
        assert len(results) == 2
        assert 'hosts' in results

# Generated at 2022-06-11 09:20:42.224517
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import io

    # Test case 1
    # Test the case when the value passed in is of type unicode
    output = io.StringIO()
    sys.stdout = output

    test_data = 'hi'
    c = AnsibleConstructor()
    c.construct_yaml_str(test_data)

    sys.stdout = sys.__stdout__
    assert output.getvalue() == 'hi'

    # Test case 2
    # Test the case when the value passed in is of type str
    output = io.StringIO()
    sys.stdout = output

    test_data = 'hi'
    c = AnsibleConstructor()
    c.construct_yaml_str(test_data)

    sys.stdout = sys.__stdout__

# Generated at 2022-06-11 09:22:01.212867
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.utils.unsafe_proxy import wrap_var

    class TestCase(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        # test for method construct_vault_encrypted_unicode of class AnsibleConstructor
        def test_construct_vault_encrypted_unicode_safetext(self):
            from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 09:22:09.797415
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from yaml.nodes import ScalarNode, MappingNode

    expected_output = b'\x93\x9d\xaa\xbb\x1b\xad\xe8k\xcd\xfd\xc9[\x9a\xbd\x16\x00\xb3\x00n\x04\xb3\x00\xae'

    b_mock_password = b'Myp@ssw0Rd'
    vault_lib = VaultLib(b_mock_password)
    vault_obj = vault_lib.encrypt(b'hello world')

    # This is the object that will be created by AnsibleConstructor
    assert vault

# Generated at 2022-06-11 09:22:22.555728
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Calling construct_yaml_unsafe raises exception if input does not have
    # any id property
    constructor = AnsibleConstructor()
    node = MappingNode(u'tag:yaml.org,2002:map', [], None, None, None)
    try:
        constructor.construct_yaml_unsafe(node)
    except ConstructorError as e:
        assert to_native(e.problem) == "expected 'object' constructor, but was: <class 'yaml.nodes.MappingNode'>"

    # Calling construct_yaml_unsafe returns the value if input has id
    # property and it is 'object'
    node.id = 'object'
    output = constructor.construct_yaml_unsafe(node)
    assert isinstance(output, AnsibleMapping) and output == {}

    # Calling construct

# Generated at 2022-06-11 09:22:30.902075
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    try:
        from unittest import mock
    except ImportError:
        import mock

    def construct_vault_encrypted_unicode(self, node):
        from yaml.constructor import ConstructorError
        raise ConstructorError()

    AnsibleConstructor.construct_vault_encrypted_unicode = construct_vault_encrypted_unicode

    with pytest.raises(ConstructorError):
        ac = AnsibleConstructor()
        node = mock.MagicMock()
        ac.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-11 09:22:38.333252
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()
    constructor._ansible_file_name = 'fake_file_name'
    # regular node
    node = dict()
    node['start_mark'] = dict()
    node['start_mark']['line'] = 1
    node['start_mark']['column'] = 2
    node['start_mark']['name'] = 'fake_datasource_name'
    node['id'] = 'fake_id'
    # construct_yaml_unsafe() calls construct_<id>, which will fail if we don't overwrite it
    setattr(constructor, 'construct_%s' % node['id'], lambda x: 'fake_value')
    ansible_dict = constructor.construct_yaml_unsafe(node)

# Generated at 2022-06-11 09:22:50.175589
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml import MappingNode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['1']
    vault_secrets.append(VaultLib(secrets=vault_secrets))
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

    ansible_mapping = AnsibleMapping()
    ansible_mapping['one'] = 'one'
    ansible_mapping['two'] = 'two'

    mapping = constructor.construct_mapping(ansible_mapping)

    assert mapping['one'] == 'one'
    assert mapping['two'] == 'two'

# Generated at 2022-06-11 09:22:58.611189
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['TEST-PASSWORD']
    c = AnsibleConstructor(vault_secrets=vault_secrets)
    c.add_constructor(u'!vault', c.construct_vault_encrypted_unicode)

# Generated at 2022-06-11 09:23:05.468930
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml

    yaml_obj = """
    ansible_become_password: !unsafe "{{ example_variable }}"
    """
    yaml_data = yaml.load(yaml_obj, Loader=AnsibleConstructor)
    assert isinstance(yaml_data['ansible_become_password'], AnsibleUnsafeText)

# Generated at 2022-06-11 09:23:15.473673
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultEditor

    secrets = [ "test" ]
    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=secrets)
    dumper = AnsibleDumper()

    source = dict(password='ansible')
    ciphertext = VaultEditor(secrets=secrets).encrypt(source)
    ciphertext = dumper.represent_scalar(u'!vault', character="!") + ciphertext

    data = yaml.load(ciphertext, Loader=loader)

    assert u"ansible" == data['password']

# Generated at 2022-06-11 09:23:21.551055
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = type("node", (object,), {
        "id": "tag:yaml.org,2002:str",
        "start_mark": type("start_mark", (object,), {
            "column": 42,
            "line": 666
        })
    })
    ret = AnsibleConstructor("/tmp/blah").construct_yaml_str(node)
    assert ret.ansible_pos == ("/tmp/blah", 666, 42)

# Generated at 2022-06-11 09:24:40.209499
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml = """
    a: test
    b: test
    """
    data = yaml.load(yaml)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 'test'
    assert data['b'] == 'test'


# Generated at 2022-06-11 09:24:49.199663
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with no constructor arguments
    c = AnsibleConstructor()
    node = yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:int', value='3200')
    ret = c.construct_yaml_str(node)
    assert type(ret) == AnsibleUnicode
    assert not isinstance(ret, AnsibleVaultEncryptedUnicode)
    assert ret == u'3200'

    # Test with file_name and vault_secrets constructor arguments
    filename = '/foo/bar/baz.yml'
    vault_secret = 'myvaultsecret'
    c = AnsibleConstructor(filename, vault_secret)
    # Test with a vault encrypted string node
    node = yaml.nodes.ScalarNode(tag='!vault', value='3200')

# Generated at 2022-06-11 09:24:55.330938
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_constructor = AnsibleConstructor()

    # test with non-mapping node
    node = {}

# Generated at 2022-06-11 09:25:06.787360
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    mock_stream = None
    with open('test/yaml/duplicate_keys', 'rb') as f:
        mock_stream = f.read()
    stream_mock_data = yaml.load(mock_stream, Loader=AnsibleLoader)

    for run in ['ignore', 'warn', 'error']:
        C.DUPLICATE_YAML_DICT_KEY = run

        # run the test
        yaml_out = yaml.load(mock_stream, Loader=AnsibleLoader)

        assert len(yaml_out) == len(stream_mock_data)
        # deepcopy here to avoid the yaml stream data being changed by yaml
        yaml_data = stream