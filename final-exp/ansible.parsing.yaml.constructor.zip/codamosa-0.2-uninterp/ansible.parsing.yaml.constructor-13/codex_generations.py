

# Generated at 2022-06-17 06:33:31.202145
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple mapping
    data = '''
        a: 1
        b: 2
        c: 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    mapping = loader.get_single_data()
    assert isinstance(mapping, AnsibleMapping)

# Generated at 2022-06-17 06:33:43.252093
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_str = '''
        a: 1
        b:
          - 2
          - 3
        c: 4
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['a'], AnsibleUnicode)

# Generated at 2022-06-17 06:33:51.418255
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the constructor returns an AnsibleUnicode object
    # when a string is constructed
    yaml_str = u'foo: bar'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[u'foo'], AnsibleUnicode)

    # Test that the constructor returns an AnsibleUnicode object
    # when a string is constructed
    yaml_str = u'foo: bar'
    data = AnsibleLoader(yaml_str).get_single_data()

# Generated at 2022-06-17 06:34:01.261344
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file

# Generated at 2022-06-17 06:34:12.087438
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test for AnsibleSequence
    data = AnsibleSequence()
    data.append(AnsibleUnicode('test'))
    data.append(AnsibleUnicode('test2'))

# Generated at 2022-06-17 06:34:19.805892
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test for empty list
    data = []
    data_loaded = AnsibleLoader(data).get_single_data()
    assert isinstance(data_loaded, AnsibleSequence)
    assert data_loaded == []

# Generated at 2022-06-17 06:34:28.320420
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with vault_secrets = None
    vault_secrets = None
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:34:39.694362
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the constructor correctly wraps the value in an AnsibleUnsafeText object
    yaml_str = "!unsafe 'foo'"
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'foo'

    # Test that the dumper correctly unwraps the value from an AnsibleUnsafeText object
    yaml_str = AnsibleDumper().dump(data)
    assert yaml_str == "'foo'\n"

    # Test that the constructor correctly wraps the value in an AnsibleUn

# Generated at 2022-06-17 06:34:50.368656
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleSequence
    data = AnsibleSequence()
    data.append(1)
    data.append(2)
    data.append(3)
    data.append(4)
    data.append(5)
    data.append(6)
    data.append(7)

# Generated at 2022-06-17 06:35:02.140431
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for construct_yaml_map

# Generated at 2022-06-17 06:35:17.466102
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = """
    a: 1
    b: 2
    c: 3
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert obj == {'a': 1, 'b': 2, 'c': 3}

    stream = StringIO()
    dumper = AnsibleDumper(stream)
    dumper.represent_dict(obj)
    assert stream.getvalue() == data

# Generated at 2022-06-17 06:35:24.626161
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - 1
    - 2
    - 3
    '''

    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]

# Generated at 2022-06-17 06:35:36.039977
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    data_mapping = AnsibleMapping()
    data_mapping['foo'] = 'bar'
    data_mapping['baz'] = [1, 2, 3]

    data_mapping_loaded = AnsibleLoader(data).get_single_data()

    assert data_mapping == data_mapping_loaded

    data_mapping_dumped = AnsibleDumper().dump(data_mapping, Dumper=AnsibleDumper)

   

# Generated at 2022-06-17 06:35:47.789525
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB


# Generated at 2022-06-17 06:35:59.988741
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test for construct_yaml_seq
    data = """
    - 1
    - 2
    - 3
    """
    loader = AnsibleLoader(data, file_name='<string>')

# Generated at 2022-06-17 06:36:08.749099
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
- !unsafe "{{ foo }}"
- !unsafe "{{ bar }}"
- !unsafe "{{ baz }}"
'''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[0], AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeText)
    assert isinstance(data[2], AnsibleUnsafeText)

    assert data[0] == '{{ foo }}'
    assert data[1] == '{{ bar }}'

# Generated at 2022-06-17 06:36:17.305947
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test case 1: no duplicate dict key
    data = '''
    a: 1
    b: 2
    c: 3
    '''
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj == {'a': 1, 'b': 2, 'c': 3}
    assert AnsibleDumper().dump(yaml_obj) == data

    # Test case 2: duplicate dict key

# Generated at 2022-06-17 06:36:28.942281
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.nodes import AnsibleMappingNode
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.nodes import AnsibleUnicodeNode
    from ansible.parsing.yaml.nodes import AnsibleVaultEncryptedUnicodeNode
    from ansible.parsing.yaml.nodes import AnsibleUnsafeNode

    # Test with a simple mapping
   

# Generated at 2022-06-17 06:36:33.907582
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    from ansible.parsing.vault import VaultLib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the vault password file
    vault_password_file = os.path.join(tmpdir, 'vault_password_file')
    with open(vault_password_file, 'w') as f:
        f.write('ansible')

    # Create the vault file
    vault_file = os.path.join(tmpdir, 'vault_file')

# Generated at 2022-06-17 06:36:42.397062
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple dictionary
    data = {'a': 1, 'b': 2, 'c': 3}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.add_constructor(u'tag:yaml.org,2002:map', AnsibleConstructor.construct_yaml_map)
    ansible_constructor.add_constructor

# Generated at 2022-06-17 06:36:55.438852
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['test_secret']
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'test_plaintext'
    ciphertext = vault.encrypt(plaintext)
    yaml_data = '!vault |\n  ' + ciphertext

    loader = AnsibleLoader(yaml_data, vault_secrets=vault_secrets)
    data = loader.get_single_data()

    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault == vault
    assert data.vault.dec

# Generated at 2022-06-17 06:37:06.673698
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['secret']
    ac = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:37:13.178587
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    yaml_str = '''
    - !unsafe |
        {
            "key": "value"
        }
    '''

    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert data[0] == AnsibleUnsafeText('{\n    "key": "value"\n}\n')

# Generated at 2022-06-17 06:37:26.935044
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY set to 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'

# Generated at 2022-06-17 06:37:37.544863
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['test_secret']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:37:48.346850
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a valid vault encrypted string
    vault_secrets = ['secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_data = ciphertext.encode('utf-8')
    ciphertext_data_str = ciphertext_data.decode('utf-8')

# Generated at 2022-06-17 06:37:59.333496
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-17 06:38:05.115373
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text

    # Test 1: Test that AnsibleConstructor.construct_mapping() returns an AnsibleMapping object
    #         when given a MappingNode object
    #
    # Given
    #   - a MappingNode object
    # When
    #   - AnsibleConstructor.construct_mapping() is called
    # Then
    #   - Ansible

# Generated at 2022-06-17 06:38:15.275747
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    yaml_str = '''
---
a: 1
b: 2
'''
    stream = StringIO(yaml_str)
    loader = AnsibleLoader(stream, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2}
    assert data.ansible_pos == ('<string>', 1, 0)
    stream = StringIO()
    dumper = AnsibleDumper(stream)

# Generated at 2022-06-17 06:38:27.533027
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test for duplicate keys
    yaml_str = u'''
a: 1
a: 2
'''
    yaml_str_dup_key = u'''
a: 1
a: 2
'''
    yaml_str_dup_key_ignore = u'''
a: 2
'''

    # Test for duplicate keys
    yaml_str_dup_key_error = u'''
a: 1
a: 2
'''

# Generated at 2022-06-17 06:38:44.050385
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    data = """
        foo: bar
        baz:
          - 1
          - 2
          - 3
        qux:
          - a
          - b
          - c
        quux:
          - a
          - b
          - c
        """

    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()

    dumper = AnsibleDumper()

# Generated at 2022-06-17 06:38:56.437515
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = '!unsafe "test"'
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert yaml_obj == 'test'
    assert AnsibleDumper().dump(yaml_obj) == data

    # Test with a dict
    data = '!unsafe {test: test}'
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, AnsibleMapping)
    assert y

# Generated at 2022-06-17 06:39:06.989232
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-17 06:39:15.220691
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    test_yaml = '''
- !unsafe "{{ foo }}"
- !unsafe "{{ bar }}"
'''
    data = yaml.load(test_yaml, Loader=AnsibleLoader)
    assert data == [AnsibleUnsafeText('{{ foo }}'), AnsibleUnsafeText('{{ bar }}')]
    assert yaml.dump(data, Dumper=AnsibleDumper) == test_yaml

# Generated at 2022-06-17 06:39:28.247440
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-17 06:39:37.541119
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write some YAML to the temporary file
    with open(path, 'w') as f:
        f.write("""
---
- hosts: localhost
  tasks:
    - name: test
      shell: echo "{{ test }}"
      register: result
    - debug: var=result.stdout_lines
""")

    # Load the YAML into a data structure
    with open(path, 'r') as stream:
        data = yaml.load(stream, Loader=AnsibleConstructor)

    # Remove the temporary file
    os.remove(path)

    # Test the data structure

# Generated at 2022-06-17 06:39:45.857428
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = "foo: bar\n"
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert data['foo'] == u'bar'
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

# Generated at 2022-06-17 06:39:51.519214
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'a': 'b', 'c': 'd'}
    yaml = AnsibleDumper().dump(data)
    assert yaml == '{a: b, c: d}\n'

    data = AnsibleLoader(yaml).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 'b', 'c': 'd'}

    data = {'a': 'b', 'c': 'd', 'a': 'e'}
    yaml = AnsibleDumper().dump(data)

# Generated at 2022-06-17 06:40:02.437935
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import yaml

    # Test with python 2.x
    if sys.version_info[0] < 3:
        test_string = u'\u00e9'
        test_string_utf8 = test_string.encode('utf-8')
        test_string_unicode = unicode(test_string_utf8, 'utf-8')
        test_string_yaml = u'!!python/unicode ' + test_string_utf8.decode('utf-8')
        test_string_yaml_utf8 = test_string_yaml.encode('utf-8')
        test_string_yaml_unicode = unicode(test_string_yaml_utf8, 'utf-8')

        # Test with python 2.x and unicode string
        test_string_yaml_

# Generated at 2022-06-17 06:40:11.535970
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for duplicate dict keys
    data = '''
    foo: bar
    foo: baz
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['foo'] == 'baz'

    # Test for duplicate dict keys
    data = '''
    foo: bar
    foo: baz
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance

# Generated at 2022-06-17 06:40:28.814634
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
   

# Generated at 2022-06-17 06:40:40.484538
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import random
    import string
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

    # Create a random string
    random_string = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))

    # Write the random string to the temporary file
    tmpfile.write(random_string)

    # Close the temporary file
    tmpfile.close()

    # Create a vault password file
    vault_password_file = os.path.join(tmpdir, 'vault_password_file')

    # Create a random vault password

# Generated at 2022-06-17 06:40:53.258071
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test with a list
    data = [1, 2, 3]
    data_yaml = yaml.dump(data, Dumper=AnsibleDumper)
    data_yaml_loaded = yaml.load(data_yaml, Loader=AnsibleLoader)
    assert isinstance(data_yaml_loaded, AnsibleSequence)
    assert data_yaml_loaded == data

    # Test with a tuple
    data = (1, 2, 3)
    data_yaml = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-17 06:41:02.656065
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleSequence

# Generated at 2022-06-17 06:41:12.274960
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    # test with a simple dict
    yaml_str = '''
    a: 1
    b: 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 1
    assert data['b'] == 2

    # test with a dict with duplicate keys
    yaml_str = '''
    a: 1
    b: 2
    a: 3
    '''

# Generated at 2022-06-17 06:41:25.688136
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    data = {'foo': 'bar', 'baz': 'qux'}
    dumper = AnsibleDumper()
    yaml_data = dumper.dump(data)
    loader = AnsibleLoader(None, vault_secrets=['secret'])
    ansible_data = loader.get_single_data(yaml_data)
    assert isinstance(ansible_data, AnsibleMapping)
    assert ansible_data == data
    assert ans

# Generated at 2022-06-17 06:41:36.230849
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_str = '''
        a: 1
        b:
          - 2
          - 3
        c:
          d: 4
          e: 5
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 3
    assert isinstance(data['a'], AnsibleUnicode)
   

# Generated at 2022-06-17 06:41:48.333482
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleSequence
    yaml_str = '''
- 1
- 2
- 3
'''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]
    assert AnsibleD

# Generated at 2022-06-17 06:41:56.899040
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = '''
    a: 1
    b: 2
    '''
    yaml_str_duplicate_key = '''
    a: 1
    b: 2
    a: 3
    '''
    yaml_str_duplicate_key_ignore = '''
    a: 1
    b: 2
    a: 3
    '''
    yaml_str_duplicate_key_warn = '''
    a: 1
    b: 2
    a: 3
    '''
    yaml_str_duplicate_key_error = '''
    a: 1
    b: 2
    a: 3
    '''

# Generated at 2022-06-17 06:42:09.149352
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the class AnsibleConstructor returns an AnsibleUnicode object
    # when the method construct_yaml_str is called.
    yaml_str = 'foo: bar'
    yaml_data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(yaml_data, OrderedDict)
    assert isinstance(yaml_data['foo'], AnsibleUnicode)


# Generated at 2022-06-17 06:42:27.748927
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml

    # Test for AnsibleUnsafeText
    data = AnsibleUnsafeText('!unsafe')
    data.ansible_pos = ('file', 1, 1)

# Generated at 2022-06-17 06:42:37.477556
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import yaml

    # Test case 1
    yaml_str = '''
    - 1
    - 2
    - 3
    '''
    yaml_data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert yaml_data == [1, 2, 3]

    # Test case 2
    yaml_str = '''
    - 1
    - 2
    - 3
    '''
    yaml_data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert yaml_data == [1, 2, 3]

    # Test case 3
    yaml_str = '''
    - 1
    - 2
    - 3
    '''

# Generated at 2022-06-17 06:42:49.294797
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test that AnsibleMapping is returned
    data = '''
    a: 1
    b: 2
    '''
    loader = AnsibleLoader(data, file_name='test_AnsibleConstructor_construct_yaml_map')
    assert isinstance(loader.get_single_data(), AnsibleMapping)

    # test that AnsibleMapping is returned
    data = '''
    a: 1
    b: 2
    '''
   

# Generated at 2022-06-17 06:43:00.894485
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
   

# Generated at 2022-06-17 06:43:12.128335
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = ['vault_secret']
    vault = VaultLib(secrets=vault_secrets)
    vault_data = vault.encrypt(b'vault_data')
    vault_data = vault_data.decode('utf-8')
    vault_data = AnsibleVaultEncryptedUnicode(vault_data)
    vault_data.vault = vault

# Generated at 2022-06-17 06:43:19.709215
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_str = '''
- 1
- 2
- 3
'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]