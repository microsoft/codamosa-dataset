

# Generated at 2022-06-17 06:33:30.447917
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import yaml
    import sys

    class MyConstructor(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return AnsibleUnsafeText("unsafe")

    class MyLoader(yaml.SafeLoader):
        def __init__(self, stream):
            super(MyLoader, self).__init__(stream)
            self.add_constructor(u'!unsafe', MyConstructor.construct_yaml_unsafe)

    yaml_str = u"!unsafe"
    data = yaml.load(yaml_str, Loader=MyLoader)
    assert isinstance(data, AnsibleUnsafeText)
    assert data == "unsafe"

# Generated at 2022-06-17 06:33:42.708553
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:33:51.100995
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256SIV
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20Poly1305AEAD
    from ansible.parsing.vault import Vault

# Generated at 2022-06-17 06:34:01.146676
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
   

# Generated at 2022-06-17 06:34:12.001110
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar', 'baz': 'qux'}
    unsafe_data = {'foo': 'bar', 'baz': 'qux', 'unsafe': '!unsafe'}
    unsafe_text = '!unsafe'

    # Test that the constructor works
    yaml_data = AnsibleDumper().dump(unsafe_data)
    assert yaml_data == '{foo: bar, baz: qux, unsafe: !unsafe}\n'

    # Test that the loader works
    assert AnsibleLoader(yaml_data).get_single_data

# Generated at 2022-06-17 06:34:20.566945
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    yaml_data = '''
    foo: bar
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data['foo'] == 'bar'
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test with a duplicate key
    yaml_data = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data['foo'] == 'baz'
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test with a duplicate key and ignore
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'

# Generated at 2022-06-17 06:34:28.596175
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor(unittest.TestCase):

        def test_construct_yaml_map(self):
            data = '''
            a: 1
            b: 2
            '''
            loader = AnsibleLoader(data, file_name='<string>')
            data = loader.get_single_data()
            self.assertIsInstance(data, AnsibleMapping)
            self

# Generated at 2022-06-17 06:34:39.972225
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write vault password to the file
    with open(fname, 'w') as f:
        f.write('myvaultpassword')

    # Create a vault encrypted string
    s = '$ANSIBLE_VAULT;1.1;AES256\n'
    s += '6332623163386331623232333863316232323338633162323233386331623232333863316232323338\n'

# Generated at 2022-06-17 06:34:50.543383
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.nodes import ScalarNode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256CFB

# Generated at 2022-06-17 06:35:02.244418
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(u'tag:yaml.org,2002:map', [], [], [], None, None)
    node.value = [
        (ScalarNode(u'tag:yaml.org,2002:str', u'key1', (1, 0), (1, 4), None),
         ScalarNode(u'tag:yaml.org,2002:str', u'value1', (1, 5), (1, 11), None)),
        (ScalarNode(u'tag:yaml.org,2002:str', u'key2', (2, 0), (2, 4), None),
         ScalarNode(u'tag:yaml.org,2002:str', u'value2', (2, 5), (2, 11), None))
    ]
    node

# Generated at 2022-06-17 06:35:17.020209
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 06:35:26.298360
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with a string that contains a unicode character
    node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'\u00e9')
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str(node)
    assert isinstance(ansible_constructor.construct_yaml_str(node), AnsibleUnicode)

    # Test with a string that contains a unicode character
    node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:python/unicode', value=u'\u00e9')
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str(node)

# Generated at 2022-06-17 06:35:37.029725
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_text
    import yaml
    import os
    import sys

    # Create a vault object

# Generated at 2022-06-17 06:35:48.132723
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write vault password to the file
    with open(path, 'w') as f:
        f.write('secret')

    # Write vault encrypted data to the file
    with open(path, 'a') as f:
        f.write('\n---\n')
        f.write('!vault |\n')
        f.write('          $ANSIBLE_VAULT;1.1;AES256\n')

# Generated at 2022-06-17 06:35:55.784986
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test construct_yaml_seq

# Generated at 2022-06-17 06:36:05.428268
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test with a simple map
    test_yaml_str = u"{a: 1, b: 2}"
    test_yaml_str_expected = u"{a: 1, b: 2}\n"
    test_yaml_str_expected_repr = u"{'a': 1, 'b': 2}"
    test_yaml_str_expected_repr_with_ansible_pos = u"{'a': 1, 'b': 2} (test_file.yml:1,1)"
    test_yaml_

# Generated at 2022-06-17 06:36:15.371470
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test with a string
    data = '!unsafe "hello"'
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleUnsafeText)

    # Test with a list
    data = '!unsafe [1, 2, 3]'
    loader = AnsibleLoader(data, file_name='<string>')

# Generated at 2022-06-17 06:36:27.913425
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import yaml

    # Create a file-like string to read the YAML from
    yaml_str = u"""
    a: 1
    b: 2
    c: 3
    """
    yaml_fp = io.StringIO(yaml_str)

    # Create a YAML loader and load the YAML
    yaml_loader = yaml.Loader(yaml_fp)
    yaml_loader.compose_document()

    # Get the first document
    yaml_doc = yaml_loader.get_single_node()

    # Create an AnsibleConstructor and use it to construct the mapping
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = ansible_constructor.construct_mapping(yaml_doc)

    # Check that

# Generated at 2022-06-17 06:36:37.606859
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test with a simple mapping
    data = '''
    a: 1
    b: 2
    c: 3
    '''
    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert obj.ansible_pos == ('<string>', 1, 0)
    assert obj == {'a': 1, 'b': 2, 'c': 3}

    # Test with a mapping

# Generated at 2022-06-17 06:36:47.441027
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Create a vault object
    vault_secrets = ['my_secret_password']
    vault = VaultLib(vault_secrets)

    # Create a vault encrypted string
    plaintext_data = 'my_secret_data'
    b_plaintext_data = to_bytes(plaintext_data)
    b_ciphertext_data = vault.encrypt(b_plaintext_data)
    ciphertext_data = to_native(b_ciphertext_data)

    #

# Generated at 2022-06-17 06:37:14.144792
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test construct_yaml_map
    data = '''
    a: 1
    b: 2
    c: 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    obj = loader.get_single_data()

# Generated at 2022-06-17 06:37:27.360069
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    data = """
    foo:
      bar:
        baz: 1
    """

    yaml_data = yaml.load(data, Loader=AnsibleLoader)

    assert isinstance(yaml_data, AnsibleMapping)
    assert isinstance(yaml_data['foo'], AnsibleMapping)
    assert isinstance(yaml_data['foo']['bar'], AnsibleMapping)
    assert isinstance(yaml_data['foo']['bar']['baz'], int)

# Generated at 2022-06-17 06:37:38.052938
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

# Generated at 2022-06-17 06:37:49.210899
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault encrypted string
    vault_secrets = ['test_password']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:37:59.921382
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var

    # Test the constructor
    data = '''
    a: 1
    b:
      c: 3
      d: 4
    '''

# Generated at 2022-06-17 06:38:10.584630
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    yaml_str = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data[0], AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeText)

    yaml_str = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-17 06:38:18.578736
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test with duplicate dict keys
    yaml_str = """
    a: 1
    b: 2
    a: 3
    """
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 3
    assert data['b'] == 2

    # test with duplicate dict keys and unsafe
    yaml_str = """
    a: 1
    b: 2
    a: !unsafe 3
    """


# Generated at 2022-06-17 06:38:26.750827
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Create a vault object
    vault_secrets = ['vault_secret']
    vault = VaultLib(secrets=vault_secrets)

    # Create a vault encrypted string

# Generated at 2022-06-17 06:38:39.728220
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    data_str = yaml.dump(data, Dumper=AnsibleDumper)
    data_str = data_str.replace('bar', '!unsafe bar')
    data_str = data_str.replace('qux', '!unsafe qux')
    data_str = data_str.replace('corge', '!unsafe corge')
    data_loaded = yaml.load(data_str, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:38:49.779135
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from sys import version_info

    # Python 2.x
    if version_info[0] < 3:
        from io import BytesIO as StringIO

    # Create a YAML string
    yaml_str = """
    a: 1
    b: 2
    c: 3
    """

    # Create a YAML string with duplicate keys
    yaml_str_duplicate_keys = """
    a: 1
    b: 2
    c: 3
    a: 4
    """

    # Create a YAML string with duplicate keys and ignore

# Generated at 2022-06-17 06:39:09.539117
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    yaml_str = "foo"
    yaml_obj = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert isinstance(yaml_obj, AnsibleUnicode)
    assert yaml_obj == "foo"
    assert yaml_str == AnsibleDumper(default_flow_style=False).dump(yaml_obj)

    # Test with a unicode string
    yaml_str = u"foo"

# Generated at 2022-06-17 06:39:17.735892
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
a: 1
b: 2
'''
    yaml_obj = AnsibleLoader(data, file_name='test_AnsibleConstructor_construct_yaml_map').get_single_data()
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj == {'a': 1, 'b': 2}
    assert yaml_obj.ansible_pos == ('test_AnsibleConstructor_construct_yaml_map', 1, 0)


# Generated at 2022-06-17 06:39:24.389993
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test that the method construct_yaml_seq of class AnsibleConstructor
    # returns an AnsibleSequence object.
    #
    # The AnsibleSequence object is a subclass of the Python list object.
    #
    # The AnsibleSequence object has an attribute ansible_pos which is a tuple
    # containing the following values:
    #   - datasource: the name of the file from which the data was read
    #   - line: the line number where the previous token has ended (plus empty lines)
    #   -

# Generated at 2022-06-17 06:39:32.144640
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text

    yaml_str = u"---\n- !unsafe '{{ ansible_managed }}'"
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data[0], AnsibleUnsafeText)
    assert data[0] == u"{{ ansible_managed }}"
    assert to_text(data[0]) == u"{{ ansible_managed }}"

# Generated at 2022-06-17 06:39:39.275538
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-17 06:39:48.548708
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdin
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretAWS
    from ansible.parsing.vault import VaultSecretAzure
    from ansible.parsing.vault import VaultSecretGCP
    from ansible.parsing.vault import VaultSecretHashivault
    from ansible.parsing.vault import VaultSecretK8s
    from ansible.parsing.vault import VaultSecret

# Generated at 2022-06-17 06:40:00.206619
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256Tag
    from ansible.parsing.vault import VaultAES256CBCHMACSha256TagV2
    from ansible.parsing.vault import VaultAES256CBCHMACSh

# Generated at 2022-06-17 06:40:09.672573
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleSequence
    data = '''
    - foo
    - bar
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    dumper = AnsibleDumper()
    result = loader.get_single_data()
    assert isinstance(result, AnsibleSequence)
    assert result == ['foo', 'bar']

# Generated at 2022-06-17 06:40:15.705989
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor(unittest.TestCase):

        def test_construct_yaml_unsafe(self):
            yaml_str = u'!unsafe "{{ foo }}"'
            data = AnsibleLoader(yaml_str).get_single_data()
            self.assertIsInstance(data, AnsibleUnsafeText)
            self.assertEqual(data, u'{{ foo }}')
            self

# Generated at 2022-06-17 06:40:27.781836
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
        foo:
            bar: 1
            baz: 2
        foo:
            bar: 3
            baz: 4
        '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar'] == 3
    assert data['foo']['baz'] == 4


# Generated at 2022-06-17 06:40:57.466796
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = """
    foo: bar
    baz:
      - one
      - two
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    obj = loader.get_single_data()

    assert isinstance(obj, AnsibleMapping)
    assert obj.ansible_pos == ('<string>', 1, 0)
    assert obj['foo'].ansible_pos == ('<string>', 2, 4)

# Generated at 2022-06-17 06:41:01.824371
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = yaml.load('''
---
- a
- b
- c
''', Loader=AnsibleConstructor)
    assert data == ['a', 'b', 'c']
    assert isinstance(data, AnsibleSequence)
    assert data.ansible_pos == ('<unicode string>', 1, 0)



# Generated at 2022-06-17 06:41:09.109257
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import yaml

    class MyConstructor(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return 'unsafe'

    class MyRepresenter(yaml.representer.SafeRepresenter):
        def represent_unsafe(self, data):
            return self.represent_scalar(u'!unsafe', u'unsafe')

    MyConstructor.add_constructor(u'!unsafe', MyConstructor.construct_yaml_unsafe)
    MyRepresenter.add_representer(Unsafe, MyRepresenter.represent_unsafe)

    class Unsafe(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return 'unsafe'

    data = Unsafe('unsafe')


# Generated at 2022-06-17 06:41:16.088377
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    import sys
    import os
    import tempfile
    import subprocess
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Write data to the temporary file
    os.write(fd, b"---\n- !unsafe '{\"foo\": \"bar\"}'\n")
    os.close(fd)

    # Create a temporary python file
    fd, tmppyfile = tempfile.mkstemp(dir=tmpdir, suffix='.py')

    # Write data to the temporary python file
    os.write(fd, b"#!/usr/bin/env python\nimport yaml\n")

# Generated at 2022-06-17 06:41:21.847323
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_password = 'vault_password'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-17 06:41:33.015736
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    # Test with a string
    test_string = u'This is a test string'
    test_string_node = AnsibleLoader(test_string, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(test_string_node, AnsibleUnicode)
    assert test_string_node == test_string
    assert AnsibleDumper(default_style=None, default_flow_style=False).represent_data(test_string_node) == test_string



# Generated at 2022-06-17 06:41:44.813725
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib

    # Create a vault object
    vault = VaultLib(secrets=['password'])

    # Create a string to encrypt
    plaintext = 'This is a test'

    # Encrypt the string
    ciphertext = vault.encrypt(plaintext)

    # Create a yaml node
    node = yaml.nodes.ScalarNode(tag=u'!vault', value=ciphertext)

    # Create an AnsibleConstructor object
    ansible_constructor = AnsibleConstructor()

    # Call the method construct_vault_encrypted_unicode
    ansible_vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(node)

    # Check that the returned object is an instance of Ansible

# Generated at 2022-06-17 06:41:54.227082
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:42:05.636221
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test for class AnsibleUnsafeText
    yaml_str = "!unsafe 'test'"
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'test'
    assert AnsibleDumper().dump(data) == yaml_str

    # Test for class AnsibleMapping

# Generated at 2022-06-17 06:42:15.291568
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for duplicate dict keys
    yaml_str = '''
    foo:
      bar: baz
      bar: baz
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 1
    assert data['foo']['bar'] == 'baz'

    # Test for duplicate dict keys with different values
    yaml_str = '''
    foo:
      bar: baz
      bar: baz2
    '''

# Generated at 2022-06-17 06:43:03.144501
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    import yaml

    # Test for AnsibleUnsafeText
    yaml_str = '!unsafe "{{ foo }}"'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleUnsafeText)
    assert data == '{{ foo }}'
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

    #

# Generated at 2022-06-17 06:43:14.526973
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    # Test with a string
    test_string = 'test string'
    test_string_yaml = 'test string\n'
    test_string_yaml_unicode = u'test string\n'
    test_string_yaml_unicode_with_tag = u'tag:yaml.org,2002:str\ntest string\n'
    test_string_yaml_unicode_with_tag_and_quotes = u'tag:yaml.org,2002:str\n"test string"\n'
    test_string_y

# Generated at 2022-06-17 06:43:24.606402
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - 1
    - 2
    - 3
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]
    assert yaml.dump(yaml_obj, Dumper=AnsibleDumper) == data

