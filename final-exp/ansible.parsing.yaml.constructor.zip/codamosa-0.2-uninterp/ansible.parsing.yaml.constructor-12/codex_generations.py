

# Generated at 2022-06-17 06:33:26.411079
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for construct_yaml_map
    # Test for construct_yaml_map with AnsibleMapping
   

# Generated at 2022-06-17 06:33:33.547460
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test case 1
    # Test case with duplicate dict keys
    # This test case is to check if the method construct_mapping of class AnsibleConstructor
    # raises an exception when duplicate dict keys are found
    # The exception is raised when the value of DUPLICATE_YAML_DICT_KEY is 'error'
    # The exception is not raised when the value of DUPLICATE_YAML_DICT_KEY is 'warn' or 'ignore'
    # The exception is raised when the value of DUPLICATE_YAML_DICT_KEY is not 'error', 'warn' or 'ignore'
    # The exception is raised when the value of DUPLICATE_YAML_DICT_KEY is None


# Generated at 2022-06-17 06:33:45.349111
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with a string
    node = u'tag:yaml.org,2002:str'
    value = 'test'
    ret = AnsibleConstructor.construct_yaml_str(node, value)
    assert isinstance(ret, AnsibleUnicode)
    assert ret == value

    # Test with a unicode
    node = u'tag:yaml.org,2002:str'
    value = u'test'
    ret = AnsibleConstructor.construct_yaml_str(node, value)
    assert isinstance(ret, AnsibleUnicode)
    assert ret == value

    # Test with a number
    node = u'tag:yaml.org,2002:str'
    value = 1
    ret = AnsibleConstructor.construct_yaml_str(node, value)

# Generated at 2022-06-17 06:33:52.641086
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for Python 2

# Generated at 2022-06-17 06:34:01.689891
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    yaml_str = '''
    foo: !unsafe "{{ foo }}"
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data['foo'], AnsibleUnsafeText)
    assert data['foo'] == '{{ foo }}'
    assert AnsibleDumper().dump(data) == yaml_str

    # Test with a list
    yaml_str = '''
    foo: !unsafe
      - "{{ foo }}"
    '''

# Generated at 2022-06-17 06:34:09.775272
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - 1
    - 2
    - 3
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]
    assert AnsibleDumper().dump(data) == yaml_str

# Generated at 2022-06-17 06:34:14.191191
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = '''
    a: 1
    b: 2
    '''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['a'] == 1
    assert yaml_obj['b'] == 2


# Generated at 2022-06-17 06:34:22.118433
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import yaml

    # Test with a simple dict
    data = {'a': 1, 'b': 2}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-17 06:34:28.477913
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with vault-encrypted string
    vault_password = 'test'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_str = ciphertext.decode('utf-8')
    yaml_str = '!vault |\n  ' + ciphertext_str
    data = yaml.load(yaml_str, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:34:39.769953
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Create a string with a YAML mapping
    yaml_str = '''
---
key1: value1
key2: value2
'''

    # Load the YAML string
    yaml_obj = AnsibleLoader(yaml_str).get_single_data()

    # Check that the YAML string was loaded as an AnsibleMapping
    assert isinstance(yaml_obj, AnsibleMapping)

    # Check that the YAML string was loaded correctly
    assert yaml_obj['key1'] == 'value1'

# Generated at 2022-06-17 06:34:57.211993
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a list
    data = [1, 2, 3]
    yaml_str = AnsibleDumper().dump(data)
    data_loaded = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data_loaded, AnsibleSequence)
    assert data == data_loaded

    # Test with a tuple
    data = (1, 2, 3)
    yaml_str = AnsibleDumper().dump(data)
    data_loaded = AnsibleLoader(yaml_str).get_single_data()

# Generated at 2022-06-17 06:35:07.688236
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = '!unsafe "string"'
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleUnsafeText)

    # Test with a number
    data = '!unsafe 42'
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleUnsafeText)

    # Test with a list
    data = '!unsafe [1, 2, 3]'

# Generated at 2022-06-17 06:35:17.772039
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test case 1
    data = '''
    - 1
    - 2
    - 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')

# Generated at 2022-06-17 06:35:24.763473
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib

    # Create a vault password file
    vault_password_file = '/tmp/ansible_vault_password_file'
    with open(vault_password_file, 'w') as f:
        f.write('my_vault_password')

    # Create a vault secret
    vault_secrets = [{'vault_password_file': vault_password_file}]

    # Create a vault encrypted string
    vault = VaultLib(secrets=vault_secrets)
    vault_encrypted_string = vault.encrypt('my_secret_string')

    # Create a yaml string
    yaml_string = '!vault |\n' + vault_encrypted_string

    # Create an AnsibleConstructor

# Generated at 2022-06-17 06:35:34.771608
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - 1
    - 2
    - 3
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]
    assert yaml.dump(yaml_obj, Dumper=AnsibleDumper) == data

# Generated at 2022-06-17 06:35:41.098594
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import wrap_var

    data = """
    foo: bar
    baz:
      - 1
      - 2
      - 3
    """

    loader = AnsibleLoader(data, file_name='<string>')
    result = loader.get_single_data()

    assert isinstance(result, AnsibleMapping)
    assert result['foo'] == 'bar'
    assert isinstance(result['baz'], list)
    assert result['baz'] == [1, 2, 3]

    data = """
    foo: bar
    foo: baz
    """


# Generated at 2022-06-17 06:35:50.554626
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
        a: 1
        b: 2
        c: 3
    '''
    data = AnsibleLoader(data).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos == (None, 1, 0)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert AnsibleDumper().dump(data) == data

    data = '''
        a: 1
        b: 2
        c: 3
        a: 4
    '''
    data = AnsibleLoader

# Generated at 2022-06-17 06:35:57.638719
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['secret1', 'secret2']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    node = MappingNode(tag=u'tag:yaml.org,2002:str', value=[], start_mark=None, end_mark=None)

# Generated at 2022-06-17 06:36:06.921032
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault-encrypted string
    vault_secrets = ['secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:36:16.665774
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import base64
    import binascii
    import json

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    (fd, filename) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create temporary vault password file
    (fd, vault_password_file) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create temporary vault password file
    (fd, vault_password_file_2) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create temporary vault password file

# Generated at 2022-06-17 06:36:32.233005
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import textwrap
    import base64

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the YAML

# Generated at 2022-06-17 06:36:41.273683
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test construct_yaml_seq
    data = '''
    - 1
    - 2
    - 3
    '''

# Generated at 2022-06-17 06:36:52.290129
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:37:04.813209
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.emitter import AnsibleEmitter
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode, AnsibleMappingNode
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.parser import AnsibleParser
    from ansible.parsing.yaml.composer import AnsibleComposer

# Generated at 2022-06-17 06:37:14.773244
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-17 06:37:27.525490
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test case 1:
    #   - dict with duplicate keys
    #   - duplicate_dict_key = 'warn'
    #   - expected: warning message
    #   - expected: last defined value is used
    #   - expected: no exception
    yaml_str = '''
        a: 1
        b: 2
        a: 3
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 3
    assert data['b'] == 2

    # Test case 2:
    #   - dict with duplicate keys


# Generated at 2022-06-17 06:37:38.174867
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    yaml_str = u'''
    foo:
      bar:
        baz:
          - 1
          - 2
          - 3
      bar:
        baz:
          - 4
          - 5
          - 6
    '''

    yaml_str_expected = u'''
    foo:
      bar:
        baz:
          - 4
          - 5
          - 6
    '''


# Generated at 2022-06-17 06:37:49.365964
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a temporary file
    (fd, fname) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')

    # Write some data to the temporary file
    f.write("""
    foo: !unsafe !!python/object/apply:os.system ["echo bar"]
    """)
    f.close()

    # Read the data from the temporary file
    data = yaml.safe_load(open(fname))

    # Remove the temporary file
    os.remove(fname)

    # Remove the temporary directory
    os

# Generated at 2022-06-17 06:38:00.037610
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as objects
    import ansible.parsing.yaml.loader as loader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)

    # Create the YAML

# Generated at 2022-06-17 06:38:10.732695
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple dict
    data = {'a': 1, 'b': 2}
    yaml_str = AnsibleDumper().dump(data)
    yaml_str = yaml_str.replace('\n', '')
    yaml_str = yaml_str.replace('-', '')
    yaml_str = yaml_str.replace(' ', '')
    yaml_str = yaml_str

# Generated at 2022-06-17 06:38:29.018997
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test case 1:
    # Test case for duplicate dict key with 'warn'
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    data = """
    foo: bar
    foo: baz
    """
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data['foo'] == 'baz'

    # Test case 2:
    # Test case for duplicate dict key with 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'

# Generated at 2022-06-17 06:38:36.975141
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create a test object
    test_obj = AnsibleConstructor()

    # Create a test node
    test_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

    # Call the method
    result = test_obj.construct_yaml_map(test_node)

    # Check the result
    assert isinstance(result, AnsibleMapping)



# Generated at 2022-06-17 06:38:45.362791
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import PY3

    # Test with a string
    data = AnsibleLoader('').get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'foo'
    assert AnsibleDumper().represent_data(data) == 'foo\n...\n'

    # Test with a list
    data = AnsibleLoader('[foo, bar]').get_single_data()
    assert isinstance(data, list)
    assert len(data) == 2
    assert data[0] == 'foo'
   

# Generated at 2022-06-17 06:38:56.881118
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
    foo: bar
    baz:
      - one
      - two
      - three
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['baz'], list)
    assert isinstance(data['baz'][0], AnsibleUnicode)
    assert isinstance(data['baz'][1], AnsibleUnicode)

# Generated at 2022-06-17 06:39:07.374027
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    data = """
    foo: bar
    baz: qux
    """
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['foo'] == 'bar'
    assert yaml_obj['baz'] == 'qux'

    data = """
    foo: bar
    foo: qux
    """
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['foo'] == 'qux'


# Generated at 2022-06-17 06:39:16.409762
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    import decimal
    import fractions
    import uuid

    from ansible.parsing.yaml.objects import AnsibleUnsafe

    # Test that the following types are wrapped in AnsibleUnsafe
    for unsafe_type in (datetime.datetime, datetime.date, datetime.time,
                        decimal.Decimal, fractions.Fraction, uuid.UUID):
        assert isinstance(AnsibleConstructor.construct_yaml_unsafe(None, unsafe_type), AnsibleUnsafe)

    # Test that the following types are not wrapped in AnsibleUnsafe
    for safe_type in (str, int, float, list, dict, tuple, set, frozenset):
        assert not isinstance(AnsibleConstructor.construct_yaml_unsafe(None, safe_type), AnsibleUnsafe)

# Generated at 2022-06-17 06:39:28.599250
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import yaml

    vault_secrets = [VaultSecret('vault_password', 'vault_password')]
    loader = AnsibleLoader(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:39:37.766925
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a list
    data = [1, 2, 3]
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    ansible_data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(ansible_data, AnsibleSequence)
    assert ansible_data == data

    # Test with a tuple
    data = (1, 2, 3)
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    ansible_data

# Generated at 2022-06-17 06:39:47.638574
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = [VaultSecret('password')]

# Generated at 2022-06-17 06:39:59.301146
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test with a simple mapping
    data = '''
    a: 1
    b: 2
    '''
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data == {'a': 1, 'b': 2}

    # Test with a mapping with duplicate keys

# Generated at 2022-06-17 06:40:28.451001
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple list
    data = """
    - foo
    - bar
    """
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader.get_single_data() == ['foo', 'bar']

    # Test with a list of dictionaries
    data = """
    - foo: bar
    - baz: qux
    """
    loader = AnsibleLoader(data, file_name='<string>')

# Generated at 2022-06-17 06:40:36.457779
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
---
- hosts: localhost
  tasks:
    - debug:
        msg: "{{ 'test' }}"
'''
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

# Generated at 2022-06-17 06:40:44.501272
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = 'test'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == data

    # Test with a unicode string
    data = u'test'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == data

    # Test with a unicode string

# Generated at 2022-06-17 06:40:56.236789
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)
    vault_text = vault.encrypt('test')
    vault_text_with_newline = vault_text + '\n'

    # Test with newline at the end of the vault text
    node = yaml.nodes.ScalarNode(tag=u'!vault', value=vault_text_with_newline, start_mark=None, end_mark=None, style=None)

# Generated at 2022-06-17 06:41:04.958000
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a valid vault encrypted string
    vault_password = 'vault_password'
    vault_secrets = [vault_password]

# Generated at 2022-06-17 06:41:09.356270
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = [1, 2, 3]
    stream = StringIO()
    AnsibleDumper(stream, default_flow_style=False).dump(data)
    stream.seek(0)
    data2 = AnsibleLoader(stream).get_single_data()
    assert isinstance(data2, AnsibleSequence)
    assert data == data2

# Generated at 2022-06-17 06:41:16.187461
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test for AnsibleSequence
    data = AnsibleSequence()
    data.append(1)
    data.append(2)
    data.append(3)
    data.append(4)
    data.append(5)
   

# Generated at 2022-06-17 06:41:21.930965
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['secret1']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    node = MappingNode(None, None, None, None)
    node.start_mark = 'test_mark'
    node.value = 'test_value'
    ansible_vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(node)
    assert ansible_vault_encrypted_unicode.vault.secrets == vault_secrets
    assert ansible_vault_encrypted_unicode.ansible_pos == ('<string>', 1, 1)
    assert ansible_vault_encrypted_unicode.vault.secrets == vault_secrets

# Generated at 2022-06-17 06:41:33.016328
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - 1
    - 2
    - 3
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test that the position information is preserved
    new_data = AnsibleDumper().represent_data(data)
    assert new_data == data

    # Test that the position information is preserved
    new_data = Ansible

# Generated at 2022-06-17 06:41:44.814205
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'baz'}
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test for duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''

# Generated at 2022-06-17 06:42:29.148525
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:42:38.629342
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml

    # Test the constructor

# Generated at 2022-06-17 06:42:49.757598
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a simple string
    test_string = "This is a test string"
    test_string_yaml = yaml.dump(test_string, Dumper=AnsibleDumper)
    test_string_yaml_loaded = yaml.load(test_string_yaml, Loader=AnsibleLoader)
    assert isinstance(test_string_yaml_loaded, AnsibleUnicode)
    assert test_string_yaml_loaded == test_string

    # Test with a

# Generated at 2022-06-17 06:43:01.395101
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIntegrity
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB

# Generated at 2022-06-17 06:43:07.065080
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = [b'vault_secret']
    vault = VaultLib(secrets=vault_secrets)
    loader = AnsibleLoader(vault_secrets=vault_secrets)
    loader.vault = vault

    # Test with a simple string
    string = "simple string"
    data = loader.get_single_data(string)
    assert isinstance(data, AnsibleUnicode)
    assert data == string

    # Test with a string containing a vault encrypted string

# Generated at 2022-06-17 06:43:17.941492
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.constructor import SafeConstructor