

# Generated at 2022-06-17 06:33:28.109204
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple list
    data = """
    - 1
    - 2
    - 3
    """
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]

    # Test with a list of lists
    data = """
    - 1
    - 2
    - 3
    -
      - 4
      - 5
      - 6
    """

# Generated at 2022-06-17 06:33:39.750987
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['secret1', 'secret2']
    vault_password_files = ['/tmp/vault_password1', '/tmp/vault_password2']
    vault = VaultLib(secrets=vault_secrets, password_files=vault_password_files)
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)

    # Test with vault secrets

# Generated at 2022-06-17 06:33:49.711602
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with !vault tag

# Generated at 2022-06-17 06:33:54.123460
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test unicode string
    data = u'foo: bar'
    loader = AnsibleLoader(data, file_name='<string>')
    result = loader.get_single_data()
    assert isinstance(result, AnsibleMapping)
    assert isinstance(result[u'foo'], AnsibleUnicode)


# Generated at 2022-06-17 06:34:02.597460
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a vault password file
    vault_pass_file = os.path.join(tmpdir, 'vault_pass.txt')
    with open(vault_pass_file, 'w') as f:
        f.write('ansible')

    # Create a vault encrypted file
    vault_file = os.path.join(tmpdir, 'vault_file.yml')
    vault = VaultLib(vault_pass_file)
    vault.encrypt_string('secret')

# Generated at 2022-06-17 06:34:13.143260
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple list
    data = '''
    - 1
    - 2
    - 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader.get_single_data() == [1, 2, 3]

    # Test with a list of lists
    data = '''
    - [1, 2, 3]
    - [4, 5, 6]
    - [7, 8, 9]
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance

# Generated at 2022-06-17 06:34:18.131870
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = u"foo: bar"
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'

# Generated at 2022-06-17 06:34:25.421475
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    s = '''
    foo: !unsafe |
      {
        "bar": "baz"
      }
    '''
    data = yaml.load(s, Loader=AnsibleConstructor)
    assert isinstance(data['foo'], AnsibleUnsafeText)
    assert data['foo'] == '''
      {
        "bar": "baz"
      }
    '''

# Generated at 2022-06-17 06:34:37.222619
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate dict keys
    yaml_str = '''
    a: 1
    b: 2
    a: 3
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 3, 'b': 2}
    assert AnsibleDumper(data).get_data() == yaml_str

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY == 'error'
    C.DUPLICATE_YAML

# Generated at 2022-06-17 06:34:41.964814
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create a vault object
    vault_secrets = ['test_secret']
    vault = VaultLib(secrets=vault_secrets)

    # Create a node object
    node = object()

    # Create a constructor object
    constructor = AnsibleConstructor()

    # Create a vault encrypted unicode object
    vault_encrypted_unicode = constructor.construct_vault_encrypted_unicode(node)

    # Check that the vault encrypted unicode object has the correct vault
    assert vault_encrypted_unicode.vault == vault

# Generated at 2022-06-17 06:34:58.976734
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = '''
        foo: bar
        baz:
            - one
            - two
        '''

    # test that the data is loaded as an AnsibleMapping
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)

# Generated at 2022-06-17 06:35:09.244772
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping
    # object.
    yaml_str = '''
    foo: bar
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping
    # object with the correct data.
    yaml_str = '''
    foo: bar
    baz: qux
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:35:18.836171
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test case 1
    data = '''
    - 1
    - 2
    - 3
    '''
    yaml_obj = AnsibleLoader(data).get_single_data()
   

# Generated at 2022-06-17 06:35:25.592100
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault_password = 'test'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_yaml = '!vault |\n          ' + '\n          '.join(ciphertext.splitlines(True))
    ciphertext_yaml_bytes = to_bytes(ciphertext_yaml)

# Generated at 2022-06-17 06:35:34.688469
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'key1': 'value1', 'key2': 'value2'}
    yaml_str = AnsibleDumper().dump(data)
    yaml_obj = AnsibleLoader(yaml_str).get_single_data()

    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj == data


# Generated at 2022-06-17 06:35:41.078738
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    data = AnsibleSequence()
    data.append(1)
    data.append(2)
    data.append(3)
    data.ansible_pos = ('test_file', 1, 1)

    yaml_data = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    new_data = yaml.load(yaml_data, Loader=AnsibleLoader)

    assert new_data == data
    assert new_data.ansible_pos == data.ansible_pos

# Generated at 2022-06-17 06:35:50.520452
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    import sys

    # Create a string with a yaml document that has an unsafe string
    # and a safe string

# Generated at 2022-06-17 06:36:00.733085
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
   

# Generated at 2022-06-17 06:36:09.130150
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.vault import VaultSecret
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var

    # Create a vault secret
    vault_secret = VaultSecret('test_secret')

    # Create a vault
    vault = VaultLib(secrets=[vault_secret])

    # Create a vault encrypted string
    vault_encrypted_string = vault.encrypt('test_string')

    # Create a vault encrypted string with a vault id
    vault_

# Generated at 2022-06-17 06:36:17.497316
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    data_mapping = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data_mapping, dict)
    assert isinstance(data_mapping['foo'], AnsibleUnicode)
    assert isinstance(data_mapping['baz'], list)
    assert isinstance(data_mapping['baz'][0], int)

    data_mapping['foo'] = 'baz'

# Generated at 2022-06-17 06:36:33.098145
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''

    loader = AnsibleLoader(data, file_name='<test_AnsibleConstructor_construct_yaml_unsafe>')
    data = loader.get_single_data()

    assert data[0] == AnsibleUnsafeText('{{ foo }}')
    assert data[1] == AnsibleUnsafeText('{{ bar }}')

    dumper = AnsibleDumper()
    output = dumper.dump(data, default_flow_style=False)



# Generated at 2022-06-17 06:36:40.758591
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - one
    - two
    - three
    """

    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get_single_data()
    assert isinstance(seq, AnsibleSequence)
    assert seq == ['one', 'two', 'three']

    dumper = AnsibleDumper()
    dumped_data = dumper.dump(seq)
    assert dumped_data == data

# Generated at 2022-06-17 06:36:51.882867
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    import stat
    import subprocess
    import time
    import json
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary vault password file
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, "w") as f:
        f.write("vault_password")

    # Create a temporary vault file
    vault_file = os.path.join(tmpdir, "vault_file")
    with open(vault_file, "w") as f:
        f.write("vault_password")

    # Create a temporary file

# Generated at 2022-06-17 06:37:04.350528
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a simple sequence
    yaml_data = '''
    - 1
    - 2
    - 3
    '''


# Generated at 2022-06-17 06:37:14.411258
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS

# Generated at 2022-06-17 06:37:21.071061
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.utils.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.utils.unsafe_proxy import Ans

# Generated at 2022-06-17 06:37:30.429236
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import ansible.parsing.vault as vault

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    vault_file = os.path.join(tmpdir, 'vault_file')

# Generated at 2022-06-17 06:37:40.124180
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret']
    vault_password_files = []
    vault_ids = []
    loader = AnsibleLoader(vault_secrets=vault_secrets, vault_password_files=vault_password_files, vault_ids=vault_ids)

    # Test case 1:
    #   - !vault |
    #     $ANSIBLE_VAULT;1.1;AES256
    #     63316462363132396163346362323863313

# Generated at 2022-06-17 06:37:52.449298
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault-encrypted string
    vault_secrets = ['vault_secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:38:01.628524
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'key1', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'value1', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:38:17.342882
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:38:28.258430
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple list
    data = '''
    - one
    - two
    - three
    '''
    data_obj = AnsibleSequence([AnsibleUnicode('one'), AnsibleUnicode('two'), AnsibleUnicode('three')])

# Generated at 2022-06-17 06:38:40.673637
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with vault password
    vault_secrets = ['test_password']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    node = AnsibleConstructor.construct_yaml_str(constructor, node=None)

# Generated at 2022-06-17 06:38:46.914801
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a duplicate dict key
    data = '''
    foo:
      bar: 1
      bar: 2
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    loader.vault_secrets = ['vaultpassword']

# Generated at 2022-06-17 06:38:55.738954
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = [1, 2, 3]
    yaml_data = AnsibleDumper().dump(data)
    loaded_data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(loaded_data, AnsibleSequence)
    assert loaded_data == data

# Generated at 2022-06-17 06:39:06.760499
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test for duplicate keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    yaml_str_expected = '''foo: baz
'''
    yaml_str_expected_warn = '''foo: bar
'''
    yaml_str_expected_error = '''foo: bar
'''

    # Test for duplicate keys
    yaml_str2 = '''
    foo: bar
    foo: baz
    '''

# Generated at 2022-06-17 06:39:15.746023
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test with a duplicate key
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test with a duplicate key and ignore
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test with a duplicate key and warn
    C.DUPLIC

# Generated at 2022-06-17 06:39:28.289950
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256Tag
    from ansible.parsing.vault import VaultAES256CBCHMACSha256TagV2
    from ansible.parsing.vault import VaultAES256CBCHMACSh

# Generated at 2022-06-17 06:39:34.621580
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = '''
    - 1
    - 2
    - 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader.get_single_data() == [1, 2, 3]

# Generated at 2022-06-17 06:39:46.230302
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    with open(temp_path, 'w') as f:
        f.write('---\n')
        f.write('- !unsafe "{{ lookup(\'pipe\', \'echo "Hello World"\') }}"\n')

    # Read the data from the temporary file
    with open(temp_path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleConstructor)

    # Remove the temporary file
    os.remove(temp_path)

    # Test the data
    assert data == [u'Hello World']

# Generated at 2022-06-17 06:40:04.293065
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the method construct_yaml_str of class AnsibleConstructor
    # always returns an AnsibleUnicode object.
    #
    # The method construct_yaml_str is called by the method construct_object
    # of class SafeConstructor.
    #
    # The method construct_object is called by the method construct_mapping
    # of class SafeConstructor.
    #
    # The method construct_mapping is called by the method construct_yaml_map
    # of class AnsibleConstructor.
    #
    # The method construct_yaml_map is called by

# Generated at 2022-06-17 06:40:13.022564
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - foo
    - bar
    """

    loader = AnsibleLoader(data, None, None)
    seq = loader.get_single_data()

    assert isinstance(seq, Sequence)
    assert isinstance(seq, AnsibleSequence)
    assert seq[0] == 'foo'
    assert seq[1] == 'bar'

    dumper = AnsibleDumper()

# Generated at 2022-06-17 06:40:24.467580
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = [1, 2, 3]
    yaml_data = AnsibleDumper().dump(data)
    yaml_data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(yaml_data, AnsibleSequence)
    assert yaml_data == data

# Generated at 2022-06-17 06:40:35.078691
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'] == [1, 2, 3]

    # Test that the data is preserved after dumping and loading
    data2 = AnsibleLoader(AnsibleDumper(data).get_data()).get_single_data()

# Generated at 2022-06-17 06:40:43.296207
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create a vault with a password
    vault = VaultLib(secrets=['password'])
    # Encrypt a string
    ciphertext = vault.encrypt('secret')
    # Create a node with the encrypted string
    node = MappingNode(u'tag:yaml.org,2002:str', ciphertext, None, None, None)
    # Create an AnsibleConstructor object
    ac = AnsibleConstructor(vault_secrets=['password'])
    # Decrypt the string
    decrypted = ac.construct_vault_encrypted_unicode(node)
    # Check that the decrypted string is the same as the original string
    assert decrypted == 'secret'

# Generated at 2022-06-17 06:40:55.461961
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple list
    data = '''
    - 1
    - 2
    - 3
    '''
    obj = AnsibleLoader(data).get_single_data()
    assert isinstance(obj, AnsibleSequence)
    assert obj == [1, 2, 3]
    assert obj.ansible_pos == ('<unicode string>', 1, 0)
    assert AnsibleDumper().dump(obj) == data

    # Test with a list of lists

# Generated at 2022-06-17 06:41:01.028000
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_str = '''
        a: 1
        b: 2
        c: 3
    '''
    yaml_obj = AnsibleMapping({'a': 1, 'b': 2, 'c': 3})
    assert AnsibleConstructor.construct_yaml_map(None, yaml.compose(yaml_str)) == yaml_obj



# Generated at 2022-06-17 06:41:08.543132
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeDict
    from ansible.utils.unsafe_proxy import AnsibleUnsafeList
    from ansible.utils.unsafe_proxy import Ansible

# Generated at 2022-06-17 06:41:15.752579
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # test for AnsibleUnsafeText
    data = AnsibleUnsafeText(u'!unsafe 123')
    yaml_data = AnsibleDumper().dump(data)
    assert yaml_data == u'!unsafe 123\n'
    data2 = AnsibleLoader(None, None).load(yaml_data)
    assert data2 == data

    # test for AnsibleMapping
    data = AnsibleMapping()
    data[u'foo'] = u'bar'

# Generated at 2022-06-17 06:41:25.570085
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - foo
    - bar
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    dumper = AnsibleDumper()
    seq = loader.get_single_data()
    assert isinstance(seq, AnsibleSequence)
    assert seq == ['foo', 'bar']
    assert dumper.dump(seq) == data

# Generated at 2022-06-17 06:41:50.864215
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-17 06:42:02.281734
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for method construct_yaml_seq of class AnsibleConstructor
    # Test with a list of strings

# Generated at 2022-06-17 06:42:12.981390
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test 1
    # Test with a simple sequence
    data = '''
    - 1
    - 2
    - 3
    '''

# Generated at 2022-06-17 06:42:20.642364
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_str = '''
- 1
- 2
- 3
'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]

# Generated at 2022-06-17 06:42:29.697481
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import base64
    import binascii
    import json

    # Test data
    vault_password = 'vault_password'
    vault_password_file = 'vault_password_file'
    vault_password_file_content = 'vault_password_file_content'
    vault_password_file_content_b64 = base64.b64encode(vault_password_file_content.encode('utf-8')).decode('utf-8')
    vault_password_file_content_b64_encoded = binascii.b2a_qp(vault_password_file_content_b64.encode('utf-8')).decode('utf-8')
    vault_password_file_content_b64

# Generated at 2022-06-17 06:42:39.121075
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import string_types

# Generated at 2022-06-17 06:42:50.033771
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:43:01.638234
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml

    # Test with a simple dict
    data = {'a': 1, 'b': 2}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    yaml_data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data == data

    # Test with a dict containing a dict

# Generated at 2022-06-17 06:43:12.358332
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for issue #22961
    # https://github.com/ansible/ansible/issues/22961
    #
    # This test is to ensure that the construct_yaml_str method of the
    # AnsibleConstructor class returns an AnsibleUnicode object.
    #
    # The AnsibleUnicode object is a subclass of the Python unicode class.
    #
    # The AnsibleUnicode class is used to ensure that the __unicode__ method
    # is called when the object is coerced to a string.
    #
    # The __unicode__ method

# Generated at 2022-06-17 06:43:24.672486
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test construct_yaml_seq
    yaml_str = '''
    - 1
    - 2
    - 3
    '''