

# Generated at 2022-06-17 06:33:23.760825
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - 1
    - 2
    - 3
    """
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleSequence)
    assert yaml_data == [1, 2, 3]

# Generated at 2022-06-17 06:33:29.289907
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    a: 1
    b: 2
    c: 3
    d: 4
    """

    loader = AnsibleLoader(data, file_name='<string>')
    mapping = loader.get_single_data()

    assert isinstance(mapping, AnsibleMapping)
    assert mapping['a'] == 1
    assert mapping['b'] == 2
    assert mapping['c'] == 3
    assert mapping['d'] == 4

# Generated at 2022-06-17 06:33:41.089566
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:33:49.346230
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - 1
    - 2
    - 3
    '''

    loader = AnsibleLoader(data, file_name='<string>')
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleSequence)
    assert obj == [1, 2, 3]

    dumper = AnsibleDumper()
    output = dumper.dump(obj)
    assert output == data



# Generated at 2022-06-17 06:33:55.096205
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a vault password file
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, "w") as f:
        f.write("vault_password")

    # Create a vault encrypted file
    vault_encrypted_file = os.path.join(tmpdir, "vault_encrypted_file")

# Generated at 2022-06-17 06:34:03.123051
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write a YAML file with vault encrypted data

# Generated at 2022-06-17 06:34:05.340286
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_str = u'foo: bar'
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, dict)
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'


# Generated at 2022-06-17 06:34:14.309024
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - 1
    - 2
    - 3
    """
    data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 3
    assert data[0] == 1
    assert data[1] == 2
    assert data[2] == 3
    assert yaml.dump(data, Dumper=AnsibleDumper) == data



# Generated at 2022-06-17 06:34:23.248695
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    yaml_str = '''
    foo: !unsafe "{{ lookup('env', 'HOME') }}"
    '''

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data['foo'] == AnsibleUnsafeText('{{ lookup(\'env\', \'HOME\') }}')

# Generated at 2022-06-17 06:34:29.506599
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    a: 1
    b: 2
    c: 3
    """
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data == {'a': 1, 'b': 2, 'c': 3}

    data = """
    a: 1
    b: 2
    c: 3
    a: 4
    """
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data

# Generated at 2022-06-17 06:34:43.441380
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import stat
    import time
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary vault password file
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, "w") as f:
        f.write("vault_password")

    # Create a temporary vault file
    vault_file = os.path.join(tmpdir, "vault_file")
    with open(vault_file, "w") as f:
        f.write("vault_password")

    # Create a temporary file

# Generated at 2022-06-17 06:34:54.640415
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = u'!unsafe "test"'
    ansible_constructor = AnsibleConstructor()
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert yaml_obj == u"test"
    assert yaml.dump(yaml_obj, Dumper=AnsibleDumper) == data

    # Test with a dict
    data = u'!unsafe {test: test2}'
    ansible_constructor

# Generated at 2022-06-17 06:35:05.541919
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the file
    with open(path, 'w') as f:
        f.write('---\n')
        f.write('foo: !unsafe "bar"\n')
        f.write('baz: !unsafe "qux"\n')

    # Read the data back in
    with open(path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleConstructor)

    # Remove the temporary file
    os.remove(path)

    # Test the data
    assert data['foo'] == 'bar'

# Generated at 2022-06-17 06:35:13.393792
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = u'foo: bar'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

# Generated at 2022-06-17 06:35:25.560497
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault_secret = VaultSecret('vault_password')
    vault_lib = VaultLib(secrets=[vault_secret])
    vault_lib.secrets = [vault_secret]
    vault_lib.secrets[0]._password = 'vault_password'
    vault_lib.secrets[0]._password_file = None
    vault_lib.secrets[0]._prompt = None
    vault_lib.secrets[0]._new_password = None
    vault_lib.sec

# Generated at 2022-06-17 06:35:36.623359
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:35:48.132499
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a vault password
    vault_secrets = ['vault_password']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:35:55.784250
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml

    # Test the case of a simple map

# Generated at 2022-06-17 06:36:01.667774
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a mapping node
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    ac = AnsibleConstructor()
    result = ac.construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)

    # Test with a non-mapping node
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    ac = AnsibleConstructor()
    result = ac.construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)

    # Test with a non-mapping node

# Generated at 2022-06-17 06:36:09.833987
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_yaml = AnsibleDumper().dump(test_dict)
    test_constructor = AnsibleConstructor()

# Generated at 2022-06-17 06:36:27.992001
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)
    vault.update('test')
    ciphertext = vault.encrypt(b'test')
    ciphertext = ciphertext.decode('utf-8')
    ciphertext = '!vault |\n          ' + ciphertext.replace('\n', '\n          ')
    yaml_data = yaml.load(ciphertext, Loader=AnsibleConstructor)
    assert isinstance(yaml_data, AnsibleVaultEncryptedUnicode)
    assert yaml_data.vault == vault
    assert yaml_

# Generated at 2022-06-17 06:36:32.823830
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for duplicate keys
    yaml_str = '''
    key1: value1
    key2: value2
    key1: value3
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 2
    assert data['key1'] == 'value3'
    assert data['key2'] == 'value2'

    # Test for duplicate keys with vault
   

# Generated at 2022-06-17 06:36:41.628110
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$ecret'
    vault_secrets = [ vault_password ]
    vault = VaultLib(vault_secrets)

    # Test with a simple sequence
    data = [ 'a', 'b', 'c' ]
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    yaml_data = vault.encrypt(yaml_data)

# Generated at 2022-06-17 06:36:52.526418
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20

# Generated at 2022-06-17 06:37:05.078249
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      bar:
        baz: 1
    '''

    obj = AnsibleLoader(data).get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert obj == {'foo': {'bar': {'baz': 1}}}

    # Test that the ansible_pos attribute is set correctly
    assert obj.ansible_pos == ('<string>', 2, 3)
    assert obj['foo'].ansible_pos == ('<string>', 3, 5)
    assert obj['foo']['bar'].ansible_

# Generated at 2022-06-17 06:37:14.949838
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # create a vault password file
    vault_password_file = temp_path + '.vault_pass'
    with open(vault_password_file, 'w') as f:
        f.write('ansible')

    # create a vault encrypted file
    vault_file = temp_path + '.vault'

# Generated at 2022-06-17 06:37:25.176665
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo: bar
    bar: baz
    baz: foo
    """
    data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['bar'] == 'baz'
    assert data['baz'] == 'foo'

# Generated at 2022-06-17 06:37:35.185950
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-17 06:37:42.513500
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import ansible.constants as C

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary vault password file
    fd, vault_password_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary vault password file
    fd, vault_password_file2 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary vault password file
    fd, vault_password_file3 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary

# Generated at 2022-06-17 06:37:54.816542
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import yaml

    yaml_str = '''
---
- hosts: localhost
  tasks:
    - name: test
      debug:
        msg: "{{ 'foo' }}"
'''

    stream = StringIO(yaml_str)
    data = yaml.load(stream, Loader=AnsibleLoader)
    assert isinstance(data[0]['tasks'][0]['debug']['msg'], AnsibleUnicode)

# Generated at 2022-06-17 06:38:15.652973
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
- 1
- 2
- 3
'''
    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get_single_data()

    assert isinstance(seq, AnsibleSequence)
    assert seq == [1, 2, 3]

    dumper = AnsibleDumper()
    dumped_data = dumper.dump(seq)

    assert dumped_data == data

# Generated at 2022-06-17 06:38:27.672106
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = """
    foo: bar
    baz:
      - one
      - two
    """
    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['baz'], list)
    assert isinstance(data['baz'][0], AnsibleUnicode)

# Generated at 2022-06-17 06:38:40.212798
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_yaml = '''
a: 1
b: 2
'''
    test_yaml_bytes = to_bytes(test_yaml)
    test_yaml_unicode = to_native(test_yaml_bytes)
    test_

# Generated at 2022-06-17 06:38:50.687184
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test data

# Generated at 2022-06-17 06:38:58.420768
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = AnsibleUnicode('foo')
    data.ansible_pos = ('test', 1, 1)

    yaml = AnsibleDumper().dump(data)
    assert yaml == 'foo\n'

    data2 = AnsibleLoader(None, None).get_single_data(yaml)
    assert data2 == data
    assert data2.ansible_pos == data.ansible_pos

# Generated at 2022-06-17 06:39:08.624821
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test with a string containing a unicode character
    yaml_str = u'foo\u20acbar'
    yaml_str_bytes = yaml_str.encode('utf-8')
    yaml_str_unicode = yaml_str.decode('utf-8')

    # Test with a string containing a unicode character
    yaml_str_unicode_obj = AnsibleUnicode(yaml_str_unicode)
    assert yaml_str_unicode_obj == yaml_str_unicode

    # Test with a string containing a unicode character
    yaml_str_bytes_obj = AnsibleUnicode(yaml_str_bytes)
    assert yaml_str_bytes_

# Generated at 2022-06-17 06:39:17.457894
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Test construct_mapping with a simple mapping
    yaml_data = """
    foo: bar
    """

# Generated at 2022-06-17 06:39:29.148993
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with duplicate dict keys
    yaml_str = '''
    a: 1
    a: 2
    '''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert yaml_obj == {'a': 2}

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY set to 'warn'
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    yaml_str = '''
    a: 1
    a: 2
    '''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert yaml_obj == {'a': 2}

    # Test with duplicate dict keys and C.DUPLICATE_

# Generated at 2022-06-17 06:39:29.759104
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-17 06:39:38.563320
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-17 06:40:08.126603
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault_lib = VaultLib(secrets=vault_secrets)
    plaintext = 'my plaintext'
    ciphertext = vault_lib.encrypt(plaintext)
    yaml_data = '!vault |\n' + ciphertext
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault == vault_lib
    assert data.decrypt(vault_secrets) == plaintext

# Generated at 2022-06-17 06:40:14.996817
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault secret
    vault_secrets = ['test']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:40:21.078685
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner

    class TestReader(Reader):
        def __init__(self, input):
            Reader.__init__(self, input)

        def peek(self, index=0):
            # Override peek to return a string instead of an integer
            return Reader.peek(self, index)

    class TestScanner(Scanner):
        def __init__(self, stream):
            Scanner.__init__(self, stream)

        def fetch_more_tokens(self):
            # Override fetch_more_tokens to return a string instead of an integer
            return Scanner.fetch_more_

# Generated at 2022-06-17 06:40:29.477577
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple string
    data = 'test'
    yaml_str = AnsibleDumper().dump(data)
    data_loaded = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data_loaded, AnsibleUnicode)
    assert data_loaded == data

    # Test with a string containing a newline
    data = 'test\n'
    yaml_str = AnsibleDumper().dump(data)
    data_loaded = AnsibleLoader(yaml_str).get_single_data()

# Generated at 2022-06-17 06:40:40.744295
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    '''

    yaml_str_duplicate_key = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''

    yaml_str_duplicate_key_error = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''


# Generated at 2022-06-17 06:40:53.311569
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test case 1:
    #   - !vault |
    #     $ANSIBLE_VAULT;1.1;AES256
    #     6332633362366131623332323762316232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323

# Generated at 2022-06-17 06:41:00.634185
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    # test for duplicate dict keys
    data = """
    foo:
      bar: 1
      bar: 2
    """
    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar'] == 2

    # test for duplicate dict keys

# Generated at 2022-06-17 06:41:10.405544
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test with duplicate keys and C.DUPLICATE_YAML_DICT_KEY set to 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'

# Generated at 2022-06-17 06:41:24.919012
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-17 06:41:35.685519
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES

# Generated at 2022-06-17 06:42:02.825170
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import base64
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Create a vault object
    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)

    # Create a vault encrypted string
    plaintext_string = 'test'
    ciphertext_bytes = vault.encrypt(plaintext_string)
    ciphertext_string = base64.b64encode(ciphertext_bytes)

    # Create

# Generated at 2022-06-17 06:42:13.110960
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test for duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'baz'}

    # Test for duplicate dict keys with different types
    yaml_str = '''
    foo: bar
    foo: 123
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 123}

    # Test for duplicate dict keys with different types
   

# Generated at 2022-06-17 06:42:25.778731
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for method construct_yaml_seq of class AnsibleConstructor
    # Test for AnsibleSequence

# Generated at 2022-06-17 06:42:35.555832
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars

# Generated at 2022-06-17 06:42:42.988174
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with duplicate dict keys
    yaml_str = '''
    a: 1
    a: 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 2

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY = 'warn'
    yaml_str = '''
    a: 1
    a: 2
    '''
    C.DUPLICATE_YAML_DICT_KEY = 'warn'

# Generated at 2022-06-17 06:42:51.465419
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a vault password file
    vault_password_file = temp_path + '.vault_pass'
    with open(vault_password_file, 'w') as f:
        f.write('ansible')

    # Create a vault encrypted file
    vault_file = temp_path + '.vault'
    vault = VaultLib(vault_password_file)
    vault_data = vault.encrypt('ansible')

# Generated at 2022-06-17 06:43:02.999906
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys
    import yaml

    # Create a string with a yaml document
    yaml_str = u"""
    a: 1
    b: 2
    c: 3
    """

    # Load the string
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleLoader)

    # Dump the object
    yaml_out = StringIO()
    yaml.dump(yaml_obj, stream=yaml_out, Dumper=AnsibleDumper, default_flow_style=False)

    # Compare the

# Generated at 2022-06-17 06:43:14.368071
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = """
    - one
    - two
    - three
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    the_list = loader.get_single_data()

    assert isinstance(the_list, AnsibleSequence)
    assert len(the_list) == 3
    assert the_list[0] == 'one'
    assert the_list[1] == 'two'
    assert the_list[2] == 'three'

    # Now test the dumper
   