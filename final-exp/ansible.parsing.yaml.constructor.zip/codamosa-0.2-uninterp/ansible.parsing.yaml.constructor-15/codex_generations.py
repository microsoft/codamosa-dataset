

# Generated at 2022-06-17 06:33:25.270113
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for duplicate dict keys
    yaml_str = '''
    foo:
      bar: 1
      bar: 2
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar'] == 2
    assert AnsibleDumper().dump(data) == yaml_str

    # Test for duplicate dict keys
    yaml_str = '''
    foo:
      bar: 1
      bar: 2
    '''

# Generated at 2022-06-17 06:33:37.405546
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdin
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretAWS
    from ansible.parsing.vault import VaultSecretGCP
    from ansible.parsing.vault import VaultSecretAzure
    from ansible.parsing.vault import VaultSecretHashivault
    from ansible.parsing.vault import Vault

# Generated at 2022-06-17 06:33:47.911072
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(u'tag:yaml.org,2002:map', [], [], None, None, None)
    node.value = [
        (ScalarNode(u'tag:yaml.org,2002:str', u'foo', None, None, None),
         ScalarNode(u'tag:yaml.org,2002:str', u'bar', None, None, None)),
        (ScalarNode(u'tag:yaml.org,2002:str', u'baz', None, None, None),
         ScalarNode(u'tag:yaml.org,2002:str', u'qux', None, None, None))
    ]
    node.start_mark = Mark(u'', 0, 0, None, None, None)
    node.end_

# Generated at 2022-06-17 06:33:54.216956
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - foo
    - bar
    """
    loader = AnsibleLoader(data, file_name='<string>')
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleSequence)
    assert obj == ['foo', 'bar']
    assert obj.ansible_pos == ('<string>', 1, 1)

    data = """
    - foo
    - bar
    - baz:
        - qux
        - quux
    """
    loader = AnsibleLoader(data, file_name='<string>')
    obj = loader.get_single_data()

# Generated at 2022-06-17 06:34:02.650250
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'secret'
    vault_secrets = [vault_password]

# Generated at 2022-06-17 06:34:11.829021
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    yaml_data = '!vault |\n  %s' % ciphertext
    data = AnsibleLoader(yaml_data, vault_secrets=vault_secrets).get_single_data()
    assert data.vault.secrets == vault_secrets
    assert data.vault.decrypt(data) == plaintext

# Generated at 2022-06-17 06:34:20.324986
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import base64
    import binascii
    import json
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary vault password file
    fd, vault_password_file = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary vault password file
    fd, vault_password_file2 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary vault password file
    fd, vault_password_file3 = tempfile.mkstem

# Generated at 2022-06-17 06:34:28.514371
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    import yaml

    data = {'foo': 'bar', 'baz': 'qux'}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    yaml_data = yaml_data.replace('bar', '!unsafe bar')
    yaml_data = yaml_data.replace('qux', '!unsafe qux')
    yaml_data = yaml_

# Generated at 2022-06-17 06:34:39.770307
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml

    class TestAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            return AnsibleUnicode(self.construct_scalar(node))

    test_data = {
        'test_1': 'test_1',
        'test_2': 'test_2',
    }

    test_yaml = yaml.dump(test_data, default_flow_style=False)
    test_yaml_unicode = to_bytes(test_yaml)

    test_yaml_stream = yaml.load(test_yaml_unicode, Loader=TestAnsibleConstructor)

    assert isinstance(test_yaml_stream, dict)
   

# Generated at 2022-06-17 06:34:45.575796
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_str = '''
- 1
- 2
- 3
'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]



# Generated at 2022-06-17 06:35:06.366147
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = """
---
- hosts: localhost
  tasks:
    - name: test
      debug:
        msg: "{{ item }}"
      with_items:
        - 1
        - 2
        - 3
"""
    yaml_data = to_bytes(dedent(yaml_data), errors='surrogate_or_strict')
    yaml_obj = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert yaml_obj[0]['tasks'][0]['with_items'][0] == 1
    assert yaml_obj[0]['tasks'][0]['with_items'][1] == 2
    assert yaml_obj[0]['tasks'][0]['with_items'][2] == 3

# Unit

# Generated at 2022-06-17 06:35:12.398352
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import yaml

    yaml_str = '!unsafe "{{ foo }}"'
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert yaml_obj.ansible_unsafe == '{{ foo }}'

# Generated at 2022-06-17 06:35:25.230934
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = dict(
        a=1,
        b=2,
        c=dict(
            d=3,
            e=4,
            f=dict(
                g=5,
                h=6,
            )
        )
    )

    stream = StringIO()
    AnsibleDumper(stream, default_flow_style=False).dump(data)

    stream.seek(0)
    data2 = AnsibleLoader(stream).get_single_data()

    assert isinstance(data2, AnsibleMapping)
    assert data == data

# Generated at 2022-06-17 06:35:34.730708
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = 'test'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == data

    data = 'test'
    node = AnsibleDumper(data, default_flow_style=False).represent_data(data)
    assert node.value == data

# Generated at 2022-06-17 06:35:41.077668
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple map
    data = '''
    key1: value1
    key2: value2
    '''
    data_mapping = AnsibleMapping()
    data_mapping['key1'] = 'value1'
    data_mapping['key2'] = 'value2'
    data_mapping.ansible_pos = ('<string>', 1, 0)
    data_mapping_loaded = AnsibleLoader(data, file_name='<string>').get_single_data()
    assert data_mapping == data_mapping_loaded

    # Test with

# Generated at 2022-06-17 06:35:50.556282
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foo', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'bar', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:35:57.639077
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    a: 1
    b: 2
    c: 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3
    assert data.ansible_pos == ('<string>', 1, 0)

    dumper = AnsibleDumper()
    data = dumper.represent_data(data)

# Generated at 2022-06-17 06:36:02.850746
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    yaml.add_representer(AnsibleUnicode, AnsibleRepresenter.represent_unicode)
    yaml.add_constructor(u'tag:yaml.org,2002:str', AnsibleConstructor.construct_yaml_str)

# Generated at 2022-06-17 06:36:12.971205
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for empty dict
    data = AnsibleMapping()
    data.ansible_pos = ('test', 1, 1)
    yaml_data = AnsibleDumper(default_flow_style=False).dump(data)
    assert yaml_data == '{}\n'

    # Test for dict with one element
    data = AnsibleMapping()
    data.ansible_pos = ('test', 1, 1)
    data['key'] = 'value'
    yaml_data

# Generated at 2022-06-17 06:36:18.883080
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test that AnsibleConstructor.construct_yaml_str returns an AnsibleUnicode object
    # when given a string
    yaml_str = 'test string'
    ansible_constructor = AnsibleConstructor()
    ansible_unicode = ansible_constructor.construct_yaml_str(yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=yaml_str))
    assert isinstance(ansible_unicode, AnsibleUnicode)
    assert ansible_unicode == yaml_str

    # Test that AnsibleConstructor.construct_yaml_str returns an AnsibleUnicode object
    # when given a unicode string
   

# Generated at 2022-06-17 06:36:35.605894
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    loader = AnsibleLoader(data, file_name='<string>')
    result = loader.get_single_data()

    assert isinstance(result['foo'], AnsibleUnicode)
    assert isinstance(result['baz'][0], AnsibleUnicode)

# Generated at 2022-06-17 06:36:44.653010
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    yaml_str = """
        a: 1
        b: 2
        c: 3
    """

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    yaml_str = """
        a: 1
        b: 2
        c: 3
        a: 4
    """


# Generated at 2022-06-17 06:36:54.210585
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a simple dictionary
    data = {'a': 1, 'b': 2}
    yaml_data = AnsibleDumper().dump(data)
    yaml_data = to_bytes(yaml_data)
    result = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(result, AnsibleMapping)


# Generated at 2022-06-17 06:37:04.303346
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = [1, 2, 3]
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    assert yaml_data == '- 1\n- 2\n- 3\n'

    yaml_data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleSequence)
    assert yaml_data == data


# Generated at 2022-06-17 06:37:14.376398
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = 'string'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == data

    # Test with a unicode string
    data = u'unicode string'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == data

    # Test with a number
    data = 42


# Generated at 2022-06-17 06:37:25.341616
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    yaml_str = '''
---
- !unsafe |
  {
    "changed": false,
    "ping": "pong"
  }
'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data[0], AnsibleUnsafeText)
    assert data[0].value == '''
  {
    "changed": false,
    "ping": "pong"
  }
'''

# Generated at 2022-06-17 06:37:35.431356
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secret = VaultSecret('test_password')
    vault_secrets = [vault_secret]
    vault = VaultLib(secrets=vault_secrets)
    data = vault.encrypt('test_data')
    yaml_data = '!vault |\n' + data
    loader = AnsibleLoader(yaml_data, vault_secrets=vault_secrets)
    data = loader.get_single_data()

# Generated at 2022-06-17 06:37:42.640336
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_yaml = 'a: 1\nb: 2\n'
    test_stream = StringIO(test_yaml)
    test_loader = AnsibleLoader(test_stream, file_name='<test_stream>')
    test_constructor = AnsibleConstructor(file_name='<test_stream>')

# Generated at 2022-06-17 06:37:54.905503
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.utils.unsafe_proxy import wrap_var

    vault_password = 'secret'
    vault_secrets = [vault_password]

# Generated at 2022-06-17 06:38:02.711254
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    yaml_str = '''
    foo:
      bar: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': {'bar': 'baz'}}

    yaml_str = '''
    foo:
      bar: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data

# Generated at 2022-06-17 06:38:26.251490
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret']
    vault = VaultLib(vault_secrets)
    vault_secrets = ['vault_secret']
    vault = VaultLib(vault_secrets)
    ciphertext = vault.encrypt(b'foo')
    ciphertext = vault.encrypt(b'foo')
    ciphertext = vault.encrypt(b'foo')
    ciphertext = vault.encrypt(b'foo')
    ciphertext = vault.encrypt(b'foo')

# Generated at 2022-06-17 06:38:37.346930
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - a
    - b
    - c
    """

    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get_single_data()
    assert isinstance(seq, AnsibleSequence)
    assert seq == ['a', 'b', 'c']

    dumper = AnsibleDumper()
    output = dumper.dump(seq)
    assert output == data


# Generated at 2022-06-17 06:38:45.570880
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test with a valid yaml file
    yaml_str = """
    a: 1
    b: 2
    """
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 1
    assert data['b'] == 2

    # Test with a yaml file with duplicate keys
    yaml_str = """
    a: 1
    b: 2
    a: 3
    """
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 3

# Generated at 2022-06-17 06:38:57.012268
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)


# Generated at 2022-06-17 06:39:07.458174
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeTextProxy

    yaml_str = '''
    - !unsafe "{{ lookup('file', '/etc/passwd') }}"
    - !unsafe "{{ lookup('file', '/etc/passwd') }}"
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[0], AnsibleUnsafeTextProxy)
    assert isinstance(data[0]._obj, AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeTextProxy)

# Generated at 2022-06-17 06:39:16.035743
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid encrypted string
    vault_secrets = ['test_password']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(None)
    assert vault_encrypted_unicode.vault.secrets == vault_secrets

    # Test with an invalid encrypted string
    vault_secrets = ['invalid_password']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    try:
        ansible_constructor.construct_vault_encrypted_unicode(None)
        assert False
    except ConstructorError:
        assert True

# Generated at 2022-06-17 06:39:28.393631
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import base64
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write vault-encrypted data to the file
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_data = 'hello world'
    vault_encrypted_data = vault.encrypt(vault_data)
    with open(path, 'w') as f:
        f.write(vault_encrypted_data)

    # Read vault-encrypted data from the file

# Generated at 2022-06-17 06:39:37.610543
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.error import AnsibleParserError
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdout
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretEnv
    from ansible.parsing.vault import VaultSecretAWS

# Generated at 2022-06-17 06:39:47.496090
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml

    yaml_str = '''
- 1
- 2
- 3
'''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 3
    assert isinstance(data[0], int)
    assert isinstance(data[1], int)

# Generated at 2022-06-17 06:39:59.296308
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text

    # Test with a mapping that has duplicate keys

# Generated at 2022-06-17 06:40:16.008153
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault secret
    vault_secrets = [b'$ANSIBLE_VAULT;1.1;AES256\n3630643566656433666564376638646566376465373664373537643739646436356564363865\n3630643566656433666564376638646566376465373664373537643739646436356564363865\n']
    ac = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:40:27.336857
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = """
    a: 1
    b: 2
    c: 3
    """

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    # test round-trip
    assert yaml_str == AnsibleDumper(data, default_flow_style=False).get_single_data()



# Generated at 2022-06-17 06:40:39.345627
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test case 1:
    # Test if the method construct_mapping of class AnsibleConstructor
    # can handle the case when the input node is not a MappingNode
    #

# Generated at 2022-06-17 06:40:52.547312
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml

    # test construct_yaml_map
    data = {'a': 1, 'b': 2}

# Generated at 2022-06-17 06:41:02.115022
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for method construct_yaml_seq of class AnsibleConstructor
    #
    # Given a yaml node, this method should return a AnsibleSequence object
    # containing the data from the node

# Generated at 2022-06-17 06:41:09.308400
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test for AnsibleUnsafeText
    data = AnsibleUnsafeText(u'!unsafe 123')
    data.ansible_pos = (u'<unicode string>', 1, 0)
    assert AnsibleDumper().represent_data(data) == u'!unsafe 123\n...\n'

# Generated at 2022-06-17 06:41:16.162533
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test case 1
    # Test with a simple yaml file
    # Test with a simple yaml file

# Generated at 2022-06-17 06:41:21.911711
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    yaml_str = '''
a:
  b: 1
  c: 2
'''

    data = AnsibleLoader(StringIO(yaml_str)).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['a']['b'] == 1
    assert data['a']['c'] == 2

    yaml_str = '''
a:
  b: 1
  c: 2
  d:
    e: 3
    f: 4
'''


# Generated at 2022-06-17 06:41:33.015913
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    import sys
    import yaml

    # Test for python 2.6

# Generated at 2022-06-17 06:41:44.813402
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 06:42:13.794231
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar', 'baz': 'qux'}
    yaml_str = AnsibleDumper(None, width=1000).dump(data)
    yaml_str = yaml_str.replace('bar', '!unsafe bar')
    yaml_str = yaml_str.replace('qux', '!unsafe qux')
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data['foo'], AnsibleUnsafeText)
    assert isinstance(data['baz'], AnsibleUnsafeText)

# Generated at 2022-06-17 06:42:26.001780
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import yaml

    # Test case 1: duplicate dict key
    # Expected result: raise ConstructorError
    test_case_1 = '''
    a: 1
    a: 2
    '''
    try:
        yaml.load(test_case_1, Loader=AnsibleConstructor)
    except ConstructorError as e:
        pass
    else:
        assert False, 'Test case 1 failed'

    # Test case 2: duplicate dict key with ignore
    # Expected result: no error
    test_case_2 = '''
    a: 1
    a: 2
    '''
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'

# Generated at 2022-06-17 06:42:35.765910
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:42:43.146323
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.utils.unsafe_proxy import wrap_var
    import os
    import sys
    import yaml

    # Create a vault secret
    vault_secret = VaultSecret('secret')

    # Create a vault
    vault = VaultLib([vault_secret])

    # Create a vault encrypted

# Generated at 2022-06-17 06:42:49.258846
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - one
    - two
    - three
    """

    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader.get_single_data() == ['one', 'two', 'three']

# Generated at 2022-06-17 06:43:00.894940
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    yaml_str = """
    - foo: bar
    - baz: qux
    """

    data = AnsibleLoader(StringIO(yaml_str)).get_single_data()
    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['baz'], AnsibleUnicode)

    yaml_str = AnsibleDumper().dump(data, Dumper=AnsibleDumper)
    data = AnsibleLoader(StringIO(yaml_str)).get_single_data()

# Generated at 2022-06-17 06:43:12.127861
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test with a list of strings
    node = yaml.nodes.SequenceNode(tag=u'tag:yaml.org,2002:seq', value=[
        yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foo'),
        yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'bar'),
        yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'baz')
    ])
    data = AnsibleConstructor.construct_yaml_seq(AnsibleConstructor(), node)
    assert isinstance(data, AnsibleSequence)
    assert isinstance(data[0], AnsibleUnicode)
