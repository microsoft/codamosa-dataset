

# Generated at 2022-06-17 06:33:25.466769
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = '''
        - foo: bar
        - baz:
            - one
            - two
        - qux:
            - three
            - four
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['baz'][0], AnsibleUnicode)
    assert isinstance(data[2]['qux'][1], AnsibleUnicode)

# Generated at 2022-06-17 06:33:37.608697
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:33:48.110684
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for a simple map
    data = '''
    a: 1
    b: 2
    '''
    data_map = AnsibleMapping()
    data_map['a'] = 1

# Generated at 2022-06-17 06:33:54.350736
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for the case when the value is a string
    yaml_str = '''
    key: !unsafe "value"
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, dict)
    assert isinstance(data['key'], AnsibleUnsafeText)
    assert data['key'] == 'value'
    assert AnsibleDumper().dump(data) == yaml_str

    # Test for the case when the value is a list

# Generated at 2022-06-17 06:34:02.727708
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-17 06:34:13.264391
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
   

# Generated at 2022-06-17 06:34:21.139246
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultA

# Generated at 2022-06-17 06:34:28.786641
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    foo:
      bar: 1
      bar: 2
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': {'bar': 2}}

    yaml_str = '''
    foo:
      bar: 1
      bar: 2
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:34:39.972086
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test with a simple string
    test_string = 'test string'
    test_string_yaml = 'test string\n...\n'
    test_string_yaml_unicode = u'test string\n...\n'
    test_string_yaml_bytes = b'test string\n...\n'
    test_string_yaml_unicode_bytes = b'test string\n...\n'

    # Test with a string with a newline
    test_string_newline = 'test\nstring'
   

# Generated at 2022-06-17 06:34:50.543124
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode

    # Test with a list
    test_list = [1, 2, 3]
    test_list_node = AnsibleSequenceNode(tag=u'tag:yaml.org,2002:seq', value=test_list)
    test_list_node.ansible_pos = (u'<string>', 1, 1)
    test

# Generated at 2022-06-17 06:35:06.537715
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:35:13.264778
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test that duplicate keys are handled correctly
    test_yaml = '''
    foo: bar
    foo: baz
    '''
    test_data = yaml.load(test_yaml, Loader=AnsibleConstructor)
    assert isinstance(test_data, AnsibleMapping)
    assert test_data['foo'] == 'baz'

# Generated at 2022-06-17 06:35:25.514112
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = '''
    a: 1
    b: 2
    c: 3
    d: 4
    e: 5
    '''

    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert obj == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

    stream = StringIO()

# Generated at 2022-06-17 06:35:36.577547
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Test for duplicate dict key
    test_data = '''
    a: 1
    a: 2
    '''
    test_data_dup_key = '''
    a: 1
    a: 2
    '''
    test_data_dup_key_ignore = '''
    a: 2
    '''
    test_data_dup_key_error = '''
    a: 1
    a: 2
    '''

# Generated at 2022-06-17 06:35:48.132265
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = '''
- 1
- 2
- 3
'''
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]
    assert yaml.dump(yaml_obj, Dumper=AnsibleDumper) == data


# Generated at 2022-06-17 06:35:59.946797
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping
    # and that the AnsibleMapping has the correct ansible_pos attribute
    data = """
    foo: bar
    """
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj.ansible_pos == ('<unicode string>', 1, 0)

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping


# Generated at 2022-06-17 06:36:07.306358
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
- 1
- 2
- 3
'''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

# Generated at 2022-06-17 06:36:16.695882
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import shutil
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the YAML file
    yaml_file = os.path.join(tmpdir, 'test.yml')
    with open(yaml_file, 'w') as yaml_fh:
        yaml_fh.write("""\
---
- hosts: localhost
  tasks:
    - name: test
      shell: !unsafe "{{ lookup('pipe', 'echo hello') }}"
""")

    # Create a temporary module location
    module_dir = os.path.join(tmpdir, 'library')

# Generated at 2022-06-17 06:36:28.599342
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)
    vault_data = vault.encrypt('test')
    vault_data = vault_data.strip()


# Generated at 2022-06-17 06:36:33.573758
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for duplicate keys
    yaml_str = '''
    a: 1
    b: 2
    a: 3
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 2
    assert data['a'] == 3
    assert data['b'] == 2

    # Test for duplicate keys with different types
    yaml_str = '''
    a: 1
    b: 2
    a: 3
    a: "3"
    '''

# Generated at 2022-06-17 06:36:45.006824
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    node = MappingNode(u'tag:yaml.org,2002:map', [], None, None, None)
    node.value = [
        (ScalarNode(u'tag:yaml.org,2002:str', u'foo', None, None, None),
         ScalarNode(u'tag:yaml.org,2002:str', u'bar', None, None, None)),
        (ScalarNode(u'tag:yaml.org,2002:str', u'baz', None, None, None),
         ScalarNode(u'tag:yaml.org,2002:str', u'qux', None, None, None))
    ]
    node.start_mark = Mark(u'', 0, 0, None, None, None)

# Generated at 2022-06-17 06:36:53.527284
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = AnsibleUnicode('test')
    data.ansible_pos = ('test', 1, 1)

    # Test that the data is correctly serialized
    serialized = AnsibleDumper().represent_data(data)
    assert serialized == 'test\n...\n'

    # Test that the data is correctly deserialized
    deserialized = AnsibleLoader(None, None).construct_yaml_str(serialized)
    assert deserialized == data

# Generated at 2022-06-17 06:37:05.212371
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test with a simple dict
    data = {'a': 'b'}
    yaml_str = AnsibleDumper().dump(data)
    data_loaded = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data_loaded, AnsibleMapping)
    assert data_loaded == data

    # Test with a dict containing a dict

# Generated at 2022-06-17 06:37:11.881533
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = '''
        - foo: bar
        - baz: qux
    '''

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)

    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['baz'], AnsibleUnicode)

# Generated at 2022-06-17 06:37:26.390346
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple sequence
    data = '''
    - 1
    - 2
    - 3
    '''
    data_expected = AnsibleSequence([1, 2, 3])
    data_expected.ansible_pos = ('<unicode string>', 1, 0)

# Generated at 2022-06-17 06:37:33.354346
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    yaml_str = u'!unsafe "{{ foo }}"'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleUnsafeText)
    assert data == u'{{ foo }}'

# Generated at 2022-06-17 06:37:41.650585
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    from yaml.parser import Parser
    from yaml.scanner import Scanner

    yaml_str = '''
    foo:
      bar: 1
      bar: 2
    '''

    yaml_str_2 = '''
    foo:
      bar: 1
      bar: 2
      baz: 3
    '''

    yaml_str_3 = '''
    foo:
      bar: 1
      bar: 2
      baz: 3
      baz: 4
    '''


# Generated at 2022-06-17 06:37:53.530810
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    data = '''
    - 1
    - 2
    - 3
    '''

    loader = AnsibleLoader(data, file_name='<string>')
    result = loader.get_single_data()

    assert isinstance(result, AnsibleSequence)
    assert result == [1, 2, 3]

    dumper = AnsibleDumper()
    result = dumper.represent_data(result)

    assert isinstance(result, yaml.nodes.SequenceNode)
    assert result.tag == u'tag:yaml.org,2002:seq'

# Generated at 2022-06-17 06:38:02.199453
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for duplicate keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 1
    assert data['foo'] == 'baz'

    # Test for duplicate keys with different types
    yaml_str = '''
    foo: bar
    foo: 123
    '''

# Generated at 2022-06-17 06:38:13.376785
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_str = """
    foo: bar
    baz:
      - qux
      - quux
    """

    yaml_str_duplicate_keys = """
    foo: bar
    foo: baz
    """

    yaml_str_duplicate_keys_nested = """
    foo: bar
    baz:
      - qux
      - quux
    foo: baz
    """


# Generated at 2022-06-17 06:38:28.912580
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple sequence
    data = '''
    - foo
    - bar
    - baz
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get_single_data()
    assert isinstance(seq, AnsibleSequence)

# Generated at 2022-06-17 06:38:41.196614
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # test construct_mapping
    data = """
        a: 1
        b: 2
        c: 3
        d: 4
    """
    data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    # test construct

# Generated at 2022-06-17 06:38:52.892553
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test with a simple mapping
    data = {'a': 1, 'b': 2, 'c': 3}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    yaml_data = yaml_data.replace('{', '?', 1)
    yaml_data = yaml_data.replace('}', ':', 1)
    yaml_data = yaml_data.replace('\n', '', 1)
    yaml_data = yaml_data.replace('\n', '', 1)
    y

# Generated at 2022-06-17 06:39:00.133255
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    yaml_data = '!vault |\n  ' + ciphertext
    data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault == vault
    assert data.decrypt() == plain

# Generated at 2022-06-17 06:39:09.931103
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test with a simple mapping
    data = '''
    key1: value1
    key2: value2
    '''
    mapping = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping['key1'] == 'value1'
    assert mapping['key2'] == 'value2'

    # Test with a duplicate key
    data = '''
    key1: value1
    key1: value2
    '''
    mapping = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping['key1'] == 'value2'

    # Test with

# Generated at 2022-06-17 06:39:15.746389
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
- 1
- 2
- 3
'''
    loader = AnsibleLoader(data, file_name='<string>')
    result = loader.get_single_data()
    assert isinstance(result, AnsibleSequence)
    assert result == [1, 2, 3]


# Generated at 2022-06-17 06:39:28.288975
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foo', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'bar', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:39:37.579944
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test with a mapping with duplicate keys
    data = """
    key1: value1
    key2: value2
    key1: value3
    """
    yaml_data = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data == {'key1': 'value3', 'key2': 'value2'}

    # Test with a mapping with duplicate keys and C.DUPLICATE_YAML_DICT_KEY == 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'

# Generated at 2022-06-17 06:39:47.459704
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = '''
- 1
- 2
- 3
'''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]
    assert data.ansible_pos == ('<unicode string>', 1, 0)


# Generated at 2022-06-17 06:39:59.295257
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault secret
    vault_secrets = ['test_secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    node = MappingNode(tag=u'tag:yaml.org,2002:str', value=[], start_mark=None, end_mark=None)

# Generated at 2022-06-17 06:40:15.680724
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml
    import sys
    import os
    import tempfile
    import shutil
    import copy

    #

# Generated at 2022-06-17 06:40:20.996433
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    a: 1
    b: 2
    c: 3
    '''
    data = AnsibleLoader(data).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert data.ansible_pos == ('<unicode string>', 1, 0)
    assert AnsibleDumper().dump(data) == data



# Generated at 2022-06-17 06:40:26.382378
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = """
        foo: bar
        baz:
          - one
          - two
          - three
        """
    yaml_obj = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert yaml_obj['foo'] == 'bar'
    assert yaml_obj['baz'] == ['one', 'two', 'three']

# Generated at 2022-06-17 06:40:35.121384
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = u'foo: bar'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

# Generated at 2022-06-17 06:40:44.289161
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with duplicate dict keys
    yaml_str = '''
    key1: value1
    key2: value2
    key1: value3
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['key1'] == 'value3'
    assert data['key2'] == 'value2'

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY = 'warn'

# Generated at 2022-06-17 06:40:56.151359
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    # Test with a string
    test_string = 'test string'
    test_string_yaml = 'test string\n'
    test_string_yaml_unicode = u'test string\n'
    test_string_yaml_unicode_ansible = AnsibleUnicode(u'test string')
    test_string_yaml_unicode_ansible.ansible_pos = ('<unicode string>', 1, 1)

    # Test with a unicode string
    test_unic

# Generated at 2022-06-17 06:41:04.882906
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    # Test with a simple dict

# Generated at 2022-06-17 06:41:13.430179
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test for duplicate keys
    data = '''
    a: 1
    a: 2
    '''
    loader = AnsibleLoader(data)
    mapping = loader.get_single_data()
    assert isinstance(mapping, AnsibleMapping)
    assert mapping == {'a': 2}

    # Test for duplicate keys with different types
    data = '''
    a: 1
    a: 2
    a: 3
    '''
    loader = AnsibleLoader(data)
    mapping = loader.get_single_data()

# Generated at 2022-06-17 06:41:26.110712
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    a: 1
    b: 2
    c: 3
    """

    # test that the data is loaded as an AnsibleMapping
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)

    # test that the data is dumped as an AnsibleMapping
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    yaml_data_dumped

# Generated at 2022-06-17 06:41:36.469175
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    a: 1
    b: 2
    c: 3
    '''

    data_mapping = AnsibleMapping()
    data_mapping['a'] = 1
    data_mapping['b'] = 2
    data_mapping['c'] = 3

    data_mapping.ansible_pos = ('<string>', 1, 0)

    loader = AnsibleLoader(data, file_name='<string>')
    data_mapping_loaded = loader.get_single_data()

    assert data_mapping == data_mapping_loaded

    d

# Generated at 2022-06-17 06:42:05.794726
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - foo
    - bar
    - baz
    """

    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj[0] == 'foo'
    assert yaml_obj[1] == 'bar'
    assert yaml_obj[2] == 'baz'

    # Test round-trip
    yaml_data = yaml.dump(yaml_obj, Dumper=AnsibleDumper)
    y

# Generated at 2022-06-17 06:42:15.374533
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.vault import VaultLib

    vault_secrets = [b'vault_secret']
    vault = VaultLib(secrets=vault_secrets)
    ciphertext = vault.encrypt(b'plaintext')
    ciphertext_str = ciphertext.decode('utf-8')
    yaml_str = u'---\n- !vault |\n  ' + ciphertext_str + u'\n- !vault-encrypted |\n  ' + ciphertext_str
    yaml_str_bytes = yaml_str.encode('utf-8')

# Generated at 2022-06-17 06:42:24.651062
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = '''
    - foo: bar
    - baz: qux
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['baz'], AnsibleUnicode)

# Generated at 2022-06-17 06:42:35.167510
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = '!unsafe "test"'
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert yaml_obj == 'test'
    assert AnsibleDumper().dump(yaml_obj) == data

    # Test with a number
    data = '!unsafe 123'
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert yaml_obj

# Generated at 2022-06-17 06:42:47.146688
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test with a simple mapping
    yaml_data = u'{a: 1, b: 2}'
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data == {u'a': 1, u'b': 2}

    # Test with a duplicate key
    yaml_data = u'{a: 1, a: 2}'
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data == {u'a': 2}

    # Test with a duplicate key and a warning
    C.DUPLICATE_

# Generated at 2022-06-17 06:42:59.267275
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo:
      bar: 1
      baz: 2
    """

    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data == {'foo': {'bar': 1, 'baz': 2}}

    data = """
    foo:
      bar: 1
      baz: 2
      bar: 3
    """

    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data

# Generated at 2022-06-17 06:43:05.887775
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import os
    import yaml
    import tempfile
    import shutil
    import unittest

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'test.yml')
            self.temp_file_name = 'test.yml'
            self.temp_file_content = '''
            ---
            a: 1
            b: 2
            c: 3
            '''
            with open(self.temp_file, 'w') as f:
                f.write(self.temp_file_content)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)



# Generated at 2022-06-17 06:43:16.725730
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence