

# Generated at 2022-06-17 06:33:27.377059
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode

    # test_AnsibleConstructor_construct_yaml_seq_1
    data = """
    - 1
    - 2
    - 3
    """
    loader = AnsibleLoader(data, None, AnsibleConstructor)
    seq = loader.get_single_data()

# Generated at 2022-06-17 06:33:38.975364
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[0], AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeText)
    assert data[0] == "{{ foo }}"
    assert data[1] == "{{ bar }}"

    yaml_str_out = AnsibleDumper(data, default_flow_style=False).get_single_data()

# Generated at 2022-06-17 06:33:49.159680
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    # Test with a valid vault encrypted string
    vault_secrets = ['test']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_constructor.add_constructor(u'!vault', ansible_constructor.construct_vault_encrypted_unicode)
    ansible_constructor.add_constructor(u'!vault-encrypted', ansible_constructor.construct_vault_encrypted_unicode)
    ansible_constructor.add_constructor(u'!unsafe', ansible_constructor.construct_yaml_unsafe)
    ansible_constructor.add_constructor(u'tag:yaml.org,2002:str', ansible_constructor.construct_yaml_str)
    ansible_construct

# Generated at 2022-06-17 06:34:00.820351
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from yaml import load, dump

    # Test for empty list
    data = []
    stream = StringIO()
    AnsibleDumper(stream, default_flow_style=False).dump(data)
    data2 = load(stream.getvalue(), Loader=AnsibleLoader)
    assert isinstance(data2, AnsibleSequence)
    assert data == data2

    # Test for list with one element
    data = [1]
    stream = StringIO()
    AnsibleDumper(stream, default_flow_style=False).dump(data)
   

# Generated at 2022-06-17 06:34:11.698022
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafe

# Generated at 2022-06-17 06:34:19.525068
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = "test"
    yaml_data = AnsibleDumper().dump(data)
    assert isinstance(yaml_data, AnsibleUnicode)
    assert yaml_data == data

    # Test with a unicode string
    data = u"test"
    yaml_data = AnsibleDumper().dump(data)
    assert isinstance(yaml_data, AnsibleUnicode)
    assert yaml_data == data

    # Test with a unicode string
    data = u"test"
    yaml_data = AnsibleD

# Generated at 2022-06-17 06:34:25.983605
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml

    vault_secrets = ['secret1', 'secret2']
    vault_password_file = 'test/unit/parsing/yaml/vault_password_file.txt'
    vault_password_file_bad = 'test/unit/parsing/yaml/vault_password_file_bad.txt'

    # Test with vault_password_file
    loader = AnsibleLoader(None, vault_password_file=vault_password_file)
    data = loader.get_single_data()

# Generated at 2022-06-17 06:34:37.958050
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['test_secret']
    vault = VaultLib(secrets=vault_secrets)
    vault_data = vault.encrypt('test_data')
    vault_data_yaml = yaml.dump(vault_data, default_flow_style=False)
    vault_data_yaml = vault_data_yaml.replace('\n', '\n    ')
    vault_data_yaml = '\n    '.join(vault_data_yaml.splitlines())
    vault_data_yaml = '!vault |\n    ' + vault_data_yaml
    vault_data_y

# Generated at 2022-06-17 06:34:44.083667
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp()
    os.close(fd)

    # Write the YAML

# Generated at 2022-06-17 06:34:55.226279
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that AnsibleConstructor.construct_mapping returns an AnsibleMapping
    # object
    yaml_str = '''
    foo: bar
    baz: qux
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)

    # Test that AnsibleConstructor.construct_mapping returns an AnsibleMapping
    # object when the yaml_str contains a duplicate key

# Generated at 2022-06-17 06:35:12.398886
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret']
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-17 06:35:25.230925
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    yaml_str = '!vault |\n  %s' % ciphertext
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault == vault
    assert data.vault.secrets == vault_secrets
    assert data.vault.decrypt

# Generated at 2022-06-17 06:35:36.403438
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import sys
    import os
    import tempfile
    import shutil
    import base64
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the vault password file
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, "w") as f:
        f.write("vault_password\n")

    # Create the vault

# Generated at 2022-06-17 06:35:47.969349
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    a: 1
    b: 2
    """

    data_mapping = AnsibleMapping()
    data_mapping['a'] = 1
    data_mapping['b'] = 2

    data_mapping.ansible_pos = ('<string>', 1, 0)

    loader = AnsibleLoader(data, file_name='<string>')
    data_mapping_loaded = loader.get_single_data()

    assert data_mapping == data_mapping_loaded

    dumper = AnsibleDumper()
    data_dumped = dumper.dump

# Generated at 2022-06-17 06:35:55.648387
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test for method construct_vault_encrypted_unicode(self, node)
    # of class AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:36:01.570239
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import yaml

    # Create a sequence
    seq = AnsibleSequence()
    seq.append(1)
    seq.append(2)
    seq.append(3)

    # Dump the sequence to a string
    data = yaml.dump(seq, Dumper=AnsibleDumper)

    # Load the string back into a sequence
    seq2 = yaml.load(data, Loader=AnsibleLoader)

    # Test that the loaded sequence is the same as the original
    assert seq == seq2

    # Test that the loaded sequence is an instance of Ansible

# Generated at 2022-06-17 06:36:09.770008
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    yaml_str = '!unsafe "test"'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'test'
    assert yaml_str == AnsibleDumper(default_flow_style=False).dump(data)

    # Test with a number
    yaml_str = '!unsafe 123'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
   

# Generated at 2022-06-17 06:36:17.694262
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate keys
    test_data = """
    foo: bar
    foo: baz
    """
    test_data_expected = {'foo': 'baz'}
    test_data_expected_duplicate_key_warning = 'While constructing a mapping from <string>, line 3, column 5, found a duplicate dict key (foo). Using last defined value only.'
    test_data_expected_duplicate_key_error = 'While constructing a mapping from <string>, line 3, column 5, found a duplicate dict key (foo). Using last defined value only.'

    #

# Generated at 2022-06-17 06:36:26.868209
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = u"foo: bar"
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data['foo'], AnsibleUnicode)
    assert data['foo'] == u'bar'
    assert AnsibleDumper().dump(data) == yaml_str

# Generated at 2022-06-17 06:36:36.640967
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib

    # test with a simple map
    data = '''
    a: 1
    b: 2
    '''
    stream = StringIO(data)
    loader = AnsibleLoader(stream, '<string>')
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert obj['a'] == 1
    assert obj['b'] == 2

    # test with a map containing a map


# Generated at 2022-06-17 06:36:53.327800
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    data = '''
    - !unsafe |
        #!/bin/sh
        echo "hello world"
    '''

    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()

    assert isinstance(data[0], AnsibleUnsafeText)
    assert data[0] == '#!/bin/sh\necho "hello world"'

    # Verify that the !unsafe tag is preserved when dumping the data
    dumped_data = yaml.dump(data, Dumper=yaml.SafeDumper)
    assert dumped_data == data

# Generated at 2022-06-17 06:37:02.877722
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    data = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''
    loader = AnsibleLoader(data, None)
    yaml_data = yaml.load(data, Loader=loader)
    assert yaml_data[0] == AnsibleUnsafeText('{{ foo }}')
    assert yaml_data[1] == AnsibleUnsafeText('{{ bar }}')

# Generated at 2022-06-17 06:37:13.220532
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_secrets = ['test_secret']
    vault_password = 'test_secret'
    vault_lib = VaultLib(secrets=vault_secrets)
    vault_text = vault_lib.encrypt(vault_password, 'test_text')
    vault_text_yaml = '!vault |\n' + vault_text
    vault_text_yaml_bytes = to_bytes(vault_text_yaml)
    vault_text_yaml_unicode = to_native(vault_text_yaml_bytes)

# Generated at 2022-06-17 06:37:20.144760
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.utils.display import Display

# Generated at 2022-06-17 06:37:25.948935
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a duplicate key
    yaml_text = '''
    foo: bar
    foo: baz
    '''
    data = AnsibleLoader(yaml_text).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'baz'}

    # Test with a duplicate key and a warning
    yaml_text = '''
    foo: bar
    foo: baz
    '''
    C.DUPLICATE_YAML_DICT_KEY = 'warn'

# Generated at 2022-06-17 06:37:36.316429
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar', 'baz': 'qux'}
    yaml_data = AnsibleDumper().dump(data)
    yaml_data = yaml_data.replace('bar', '!unsafe bar')
    yaml_data = yaml_data.replace('qux', '!unsafe qux')

    loader = AnsibleLoader(None, None)
    data = loader.load(yaml_data)

    assert isinstance(data['foo'], AnsibleUnsafeText)
    assert isinstance(data['baz'], AnsibleUnsafeText)

# Generated at 2022-06-17 06:37:43.270951
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = '''
        a: 1
        b: 2
        c: 3
    '''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['a'] == 1
    assert yaml_obj['b'] == 2
    assert yaml_obj['c'] == 3
    assert yaml_obj.ansible_pos == (None, 1, 0)


# Generated at 2022-06-17 06:37:55.389241
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    - !unsafe "{{ baz }}"
    '''

    # Load the data
    loader = AnsibleLoader(data, None)
    results = loader.get_single_data()

    # Dump the data
    dumper = AnsibleDumper()
    dumped_data = dumper.dump(results, Dumper=AnsibleDumper)

    # Load the dumped data
    loader = AnsibleLoader(dumped_data, None)
    results = loader.get

# Generated at 2022-06-17 06:38:02.996450
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-17 06:38:14.290754
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test with a string
    test_str = 'test string'
    test_str_node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=test_str)
    test_str_ret = AnsibleConstructor().construct_yaml_str(test_str_node)
    assert isinstance(test_str_ret, AnsibleUnicode)
    assert test_str_ret == test_str

    # Test with a unicode string
    test_unicode_str = u'test unicode string'

# Generated at 2022-06-17 06:38:28.623874
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple mapping
    data = {'a': 1, 'b': 2, 'c': 3}
    yaml_str = AnsibleDumper().dump(data)
    ansible_obj = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(ansible_obj, AnsibleMapping)
    assert ansible_obj == data

    # Test with a mapping that has duplicate keys
    data = {'a': 1, 'b': 2, 'c': 3, 'a': 4}
    yaml_str = AnsibleDumper().dump(data)

# Generated at 2022-06-17 06:38:40.996654
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import os
    import tempfile
    import yaml

    # Create a temporary file to store the vault password
    (fd, vault_password_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to store the vault encrypted data
    (fd, vault_encrypted_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a vault password
    vault_password = 'ansible'

    # Create a vault secret
    vault_secret = VaultSecret(vault_password)

    # Create a vault
    vault = VaultLib([vault_secret])

    #

# Generated at 2022-06-17 06:38:52.583954
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    plaintext = 'my secret string'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_with_header = '$ANSIBLE_VAULT;1.1;AES256\n%s\n' % ciphertext

# Generated at 2022-06-17 06:38:59.625295
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write the yaml string to the temporary file
    with open(path, 'w') as f:
        f.write("""
        foo:
            bar: baz
            bar: qux
        """)

    # Read the yaml file
    with open(path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleConstructor)

    # Remove the temporary file
    os.remove(path)

    # Assert that the data is correct
    assert data == {'foo': {'bar': 'qux'}}

# Generated at 2022-06-17 06:39:09.734697
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import ansible.parsing.vault as vault
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a vault password file
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, "w") as f:
        f.write("vault_password")

    # Create a vault encrypted file
    vault_encrypted_file = os.path.join(tmpdir, "vault_encrypted_file")

# Generated at 2022-06-17 06:39:17.758528
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with empty mapping
    data = AnsibleMapping()
    assert data == AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()

    # Test with one element
    data = AnsibleMapping()
    data['key1'] = 'value1'
    assert data == AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()

    # Test with two elements
    data = AnsibleMapping()
    data['key1'] = 'value1'
    data['key2'] = 'value2'


# Generated at 2022-06-17 06:39:24.418369
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:39:30.193558
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import tempfile
    import yaml

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(mode='w+t', delete=False)
    tmpfile.write('{a: 1, b: 2, c: 3, a: 4}')
    tmpfile.close()

    # Load the file
    with open(tmpfile.name, 'r') as stream:
        data = yaml.load(stream, Loader=AnsibleConstructor)

    # Remove the temporary file
    os.unlink(tmpfile.name)

    # Test the data
    assert data == {'a': 4, 'b': 2, 'c': 3}

    # Test the position information
    assert data.ansible_pos == (tmpfile.name, 1, 1)

# Generated at 2022-06-17 06:39:38.755598
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write vault-encrypted data to the file
    vault_password = 'secret'
    vault = VaultLib([VaultSecret(vault_password)])

# Generated at 2022-06-17 06:39:48.183317
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    a: 1
    b: 2
    c: 3
    '''
    data = AnsibleLoader(data).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3

    data = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''
    data = AnsibleLoader(data).get_single_data()
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:40:01.094775
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret']
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-17 06:40:07.975183
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = [VaultSecret('vault-password', 'vault-password')]
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    vault = VaultLib(secrets=vault_secrets)
    vault_text = vault.encrypt('test')

# Generated at 2022-06-17 06:40:15.648903
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test with a string
    node = 'test'
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_str(node), AnsibleUnicode)

    # Test with a unicode string
    node = u'test'
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_str(node), AnsibleUnicode)

    # Test with a unicode string
    node = u'test'
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_str(node), AnsibleUnicode)

    # Test with a unicode string
    node = u'test'
    ac = AnsibleConstructor()

# Generated at 2022-06-17 06:40:27.750728
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret1', 'vault_secret2']
    vault = VaultLib(secrets=vault_secrets)
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    loader.vault = vault

    data = loader.load('''
    ---
    foo:
      bar:
        baz:
          - 1
          - 2
          - 3
        qux:
          - 4
          - 5
          - 6
    ''')


# Generated at 2022-06-17 06:40:39.825619
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test with a simple sequence
    data = AnsibleSequence()
    data.append(AnsibleUnicode('foo'))
    data.append(AnsibleUnicode('bar'))
    data.append(AnsibleUnicode('baz'))
    data.ansible_pos = ('test', 1, 1)
    yaml = AnsibleDumper().dump(data)
    data2 = AnsibleLoader

# Generated at 2022-06-17 06:40:52.690439
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, 'w') as tmp:
        tmp.write("""
---
vault_password_file: %s
        """ % path)

    # Create a vault password file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, 'w') as tmp:
        tmp.write("""
ansible
        """)

    # Create a vault file
    fd, path = tempfile.mkstemp(dir=tmpdir)

# Generated at 2022-06-17 06:41:02.278081
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    ---
    - !unsafe "{{ lookup('pipe', 'echo foo') }}"
    - !unsafe "{{ lookup('pipe', 'echo bar') }}"
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[0], AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeText)
    assert data[0].value == '{{ lookup(\'pipe\', \'echo foo\') }}'

# Generated at 2022-06-17 06:41:12.122434
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode

    yaml_str = '''
        foo:
            bar:
                baz: 1
                baz: 2
                baz: 3
            bar:
                baz: 4
                baz: 5
                baz: 6
        foo:
            bar:
                baz: 7
                baz: 8
                baz: 9
    '''
    yaml_dict = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(yaml_dict, AnsibleMapping)
    assert isinstance(yaml_dict['foo'], AnsibleMapping)

# Generated at 2022-06-17 06:41:25.636110
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a list of strings
    data = ['a', 'b', 'c']
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.add_constructor(u'tag:yaml.org,2002:seq', ansible_constructor.construct_yaml_seq)
    ansible_constructor.add_constructor(u'tag:yaml.org,2002:str', ansible_constructor.construct_yaml_str)
   

# Generated at 2022-06-17 06:41:36.200928
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultAES128CBC


# Generated at 2022-06-17 06:41:52.198196
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    data = '''
    a: 1
    b: 2
    '''

    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 1
    assert data['b'] == 2

    # test that the position info is set correctly
    assert data.ansible_pos == ('<string>', 1, 0)

    # test that the position info is set correctly when the data is read
    # from a file
    data = yaml.load(open(__file__))

# Generated at 2022-06-17 06:42:00.085245
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with duplicate dict keys
    test_data = """
    - hosts: localhost
      vars:
        foo: bar
        foo: baz
    """

# Generated at 2022-06-17 06:42:11.344914
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-17 06:42:25.398017
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

    # Create the YAML

# Generated at 2022-06-17 06:42:35.256489
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys
    import yaml

    # Test with a simple map
    yaml_str = """
a: 1
b: 2
c: 3
"""
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test with a map containing a map

# Generated at 2022-06-17 06:42:47.259818
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.resolver import AnsibleResolver

    # Test for duplicate dict keys
    yaml_str = '''
    foo:
      bar: 1
      bar: 2
    '''
    yaml_obj = AnsibleMapping(dict(foo=dict(bar=2)))
    yaml_obj.ansible_pos = ('<string>', 2, 3)
    yaml_

# Generated at 2022-06-17 06:42:54.127989
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test for duplicate dict key
    data = """
    foo: bar
    foo: baz
    """
    try:
        yaml.load(data, Loader=AnsibleConstructor)
    except ConstructorError as e:
        assert e.problem == "while constructing a mapping\n" \
                            "found a duplicate dict key (foo)\n" \
                            "in \"<unicode string>\", line 2, column 4"
        assert e.problem_mark.line == 2
        assert e.problem_mark.column == 4
        assert e.context_mark.line == 2
        assert e.context_mark.column == 4
    else:
        assert False, "Expected ConstructorError"

    # Test for

# Generated at 2022-06-17 06:43:03.702154
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    # Test with a simple list
    data = u'''
    - 1
    - 2
    - 3
    '''
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleSequence)
    assert yaml_data == [1, 2, 3]

    # Test with a list of dicts

# Generated at 2022-06-17 06:43:10.819710
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import yaml

    yaml_str = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)

    assert isinstance(data[0], AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeText)