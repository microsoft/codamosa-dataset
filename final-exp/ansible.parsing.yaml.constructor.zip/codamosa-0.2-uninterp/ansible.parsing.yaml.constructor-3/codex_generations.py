

# Generated at 2022-06-17 06:33:28.030470
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-17 06:33:39.660570
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Test the method construct_yaml_map of class AnsibleConstructor
    """
    # Test with a simple dict
    yaml_data = '''
    foo: bar
    '''
    yaml_obj = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['foo'] == 'bar'
    assert yaml_obj.ansible_pos == ('<unicode string>', 1, 0)

    # Test with a dict with a duplicate key
    yaml_data = '''
    foo: bar
    foo: baz
    '''
    yaml_obj = yaml.load(yaml_data, Loader=AnsibleConstructor)

# Generated at 2022-06-17 06:33:49.639885
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import wrap_var
    from ansible.utils.unsafe_proxy import wrap_var

    # Test construct_yaml_str
    # Test with a string
    test_string = "test string"
    test_

# Generated at 2022-06-17 06:33:54.007950
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for duplicate keys
    yaml_str = u'''
    foo:
      bar: 1
      bar: 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar'] == 2

    # Test for duplicate keys
    yaml_str = u'''
    foo:
      bar: 1
      bar: 2
      bar: 3
    '''

# Generated at 2022-06-17 06:34:02.105567
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    yaml_data = yaml.load(ciphertext, Loader=AnsibleConstructor)
    assert isinstance(yaml_data, AnsibleVaultEncryptedUnicode)
    assert yaml_data.vault == vault
    assert yaml_data.decrypt() == plaintext

# Generated at 2022-06-17 06:34:12.722432
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    data = '''
        a: b
        c: d
    '''
    node = yaml.compose(data)
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)
    assert result == {'a': 'b', 'c': 'd'}

    # Test with a mapping with duplicate keys
    data = '''
        a: b
        c: d
        a: e
    '''
    node = yaml.compose(data)
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)
    assert result == {'a': 'e', 'c': 'd'}



# Generated at 2022-06-17 06:34:20.703335
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    # Test that AnsibleConstructor.construct_yaml_unsafe returns an AnsibleUnsafeText
    # object when given a string.
    data = '!unsafe "This is a string"'
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleUnsafeText)

    # Test that AnsibleConstructor.construct_yaml_unsafe returns an AnsibleUnsafeText
    # object when given a list.

# Generated at 2022-06-17 06:34:28.645200
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    test_string = 'test'
    test_string_yaml = 'test\n...\n'
    test_string_yaml_unicode = u'test\n...\n'
    test_string_yaml_unicode_expected = u'test'
    test_string_yaml_unicode_expected_type = AnsibleUnicode
    test_string_yaml_unicode_expected_pos = ('<unicode>', 1, 1)
    test_string_yaml_unicode_expected_pos_type = tuple

    test_

# Generated at 2022-06-17 06:34:39.875002
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple list
    data = '''
    - 1
    - 2
    - 3
    '''
    data_expected = AnsibleSequence([1, 2, 3])
    data_expected.ansible_pos = (None, 2, 2)
    data_loaded = AnsibleLoader(data).get_single

# Generated at 2022-06-17 06:34:49.757119
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    data = 'test'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == data

    # Test the dumper
    data = 'test'
    node = AnsibleDumper(data, default_flow_style=False).represent_data(data)
    assert isinstance(node, AnsibleUnicode)
    assert node == data

# Generated at 2022-06-17 06:35:06.789558
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:35:17.020133
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for duplicate dict keys
    # Note: this test is not exhaustive, but it does test the following:
    #   - duplicate keys in a top-level dict
    #   - duplicate keys in a nested dict
    #   - duplicate keys in a dict that is a value of a dict
    #   - duplicate keys in a dict that is a value of a list
    #   - duplicate keys in a dict that is a value of a list that is a value of a dict
    #   - duplicate keys in a dict that is a value of a list that is a value of a list
    #   - duplicate keys in a dict that is a value of a list that is a value of a list that is

# Generated at 2022-06-17 06:35:24.203752
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test with a simple list
    data = [1, 2, 3]
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    loader = AnsibleLoader(yaml_data, file_name='<string>')
    ansible_data = loader.get_single_data()
    assert isinstance(ansible_data, AnsibleSequence)
    assert ansible_data == data

    # Test with a list of lists
    data = [[1, 2], [3, 4]]

# Generated at 2022-06-17 06:35:35.764681
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert AnsibleDumper().dump(data) == yaml_str

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''

# Generated at 2022-06-17 06:35:47.636650
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    for key, value in test_dict.items():
        test_node.value.append((key, value))
    test_constructor = AnsibleConstructor()
    test_constructor.construct_yaml_map(test_node)
    assert test_constructor.construct_yaml_map(test_node) == test_dict

    # Test with a dict with duplicate keys
    test_dict = {'a': 1, 'b': 2, 'a': 3}
    test_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])

# Generated at 2022-06-17 06:35:59.814556
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleConstructor.construct_yaml_seq
    # Create a AnsibleConstructor object
    ac

# Generated at 2022-06-17 06:36:08.600162
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - a
    - b
    - c
    '''

    data_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(data_obj, list)
    assert len(data_obj) == 3
    assert isinstance(data_obj[0], AnsibleUnicode)
    assert isinstance(data_obj[1], AnsibleUnicode)
    assert isinstance(data_obj[2], AnsibleUnicode)
    assert data_obj[0] == 'a'

# Generated at 2022-06-17 06:36:17.206935
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple sequence
    data = '''
- a
- b
- c
'''
    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get_single_data()
    assert isinstance(seq, AnsibleSequence)

# Generated at 2022-06-17 06:36:28.944599
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'key1', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'value1', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:36:33.908702
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS

# Generated at 2022-06-17 06:36:51.569962
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    yaml_data = '''
        foo: bar
        baz: qux
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'] == 'qux'
    assert data.ansible_pos == ('<string>', 1, 1)

    # Test with a dict that has duplicate keys
    yaml_data = '''
        foo: bar
        baz: qux
        foo: quux
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:37:04.028548
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Create a vault object with a password
    vault_password = 'test_password'
    vault = VaultLib(vault_password)

    # Encrypt a string with the vault
    plaintext_data = 'test_string'
    b_ciphertext_data = vault.encrypt(plaintext_data)

    # Create a yaml string with the encrypted string
    yaml_string = '!vault |\n' + b_ciphertext_data.decode('utf-8')

    # Load the yaml string with AnsibleLoader

# Generated at 2022-06-17 06:37:14.146259
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create a temporary file
    fd, test_file = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    with open(test_file, 'w') as f:
        f.write("""
---
# This is a test file
# It contains a list of strings
- !unsafe "{{ lookup('pipe', 'echo hello') }}"
- !unsafe "{{ lookup('pipe', 'echo world') }}"
""")

    # Load the data from the temporary file

# Generated at 2022-06-17 06:37:20.835881
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import wrap_var

    # Test with a simple string
    vault_password = 'secret'
    vault = VaultLib

# Generated at 2022-06-17 06:37:29.421832
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test construct_mapping with duplicate keys
    # test construct_mapping with duplicate keys
    data = """
    foo: 1
    foo: 2
    """
    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:37:39.713379
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test that AnsibleConstructor.construct_yaml_seq() returns an AnsibleSequence object
    # and that the object contains the expected data.
    #
    # Note: AnsibleConstructor.construct_yaml_seq() is called by the yaml.constructor.SafeConstructor.construct_yaml_seq()
   

# Generated at 2022-06-17 06:37:52.017011
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.module_utils.six import string_types

# Generated at 2022-06-17 06:38:01.328708
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate keys
    yaml_str = """
    a: 1
    b: 2
    a: 3
    """
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 3, 'b': 2}

    # Test with duplicate keys and C.DUPLICATE_YAML_DICT_KEY set to 'warn'
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    data = y

# Generated at 2022-06-17 06:38:12.381773
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20

# Generated at 2022-06-17 06:38:26.443633
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Create a vault object
    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)

    # Create a vault encrypted string
    plaintext = 'This is a plaintext string'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_data = ciphertext.encode

# Generated at 2022-06-17 06:38:44.335477
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
    a: 1
    b: 2
    c: 3
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    yaml_str = """
    a: 1
    b: 2
    c: 3
    a: 4
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:38:56.483151
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = AnsibleUnsafeText(u'!unsafe foo')
    yaml_data = AnsibleDumper().dump(data)
    assert yaml_data == u'!unsafe foo\n'
    data2 = AnsibleLoader(None, None).get_single_data(yaml_data)
    assert data2 == data

    # Test with a list
    data = AnsibleUnsafeText(u'!unsafe [foo, bar]')
    yaml_data = AnsibleDumper().dump(data)

# Generated at 2022-06-17 06:39:07.034792
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test 1:
    # Test with a simple dict
    # Expected result:
    #   - The dict is returned as an AnsibleMapping object
    #   - The keys and values are AnsibleUnicode objects
    #   - The values are not encrypted
   

# Generated at 2022-06-17 06:39:16.093266
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = """
    a: 1
    b: 2
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    obj = loader.get_single_data()

    assert isinstance(obj, AnsibleMapping)
    assert obj['a'] == 1
    assert obj['b'] == 2

    stream = StringIO()
    dumper = AnsibleDumper(stream)
    dumper.represent_mapping('tag:yaml.org,2002:map', obj.items())

    assert stream

# Generated at 2022-06-17 06:39:22.678688
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-17 06:39:28.958155
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = """
    a: 1
    b: 2
    c: 3
    """
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

    yaml_str = """
    a: 1
    b: 2
    c: 3
    a: 4
    """


# Generated at 2022-06-17 06:39:38.123762
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test for duplicate dict keys
    yaml_str = u"""
    foo: bar
    foo: baz
    """
    yaml_str_duplicate_dict_key = u"""
    foo: bar
    foo: baz
    """
    yaml_str_duplicate_dict_key_ignore = u"""
    foo: baz
    """
    yaml_str_duplicate_dict_key_error = u"""
    foo: bar
    foo: baz
    """

    # Test for duplicate dict keys


# Generated at 2022-06-17 06:39:47.744333
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'baz'}

    # Test for duplicate dict keys with different types
    yaml_str = '''
    foo: bar
    foo: 123
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:39:59.340855
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple string
    data = 'simple string'
    yaml_str = AnsibleDumper().dump(data)
    assert isinstance(yaml_str, str)
    loaded_data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(loaded_data, AnsibleUnicode)
    assert loaded_data == data

    # Test with a string containing a single quote
    data = "string with 'single quote'"
    yaml_str = AnsibleDumper().dump(data)
    assert isinstance(yaml_str, str)


# Generated at 2022-06-17 06:40:08.839663
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    test_str = 'test string'
    node = AnsibleLoader(test_str).get_single_data()
    assert isinstance(AnsibleConstructor().construct_yaml_str(node), AnsibleUnicode)

    # Test with a unicode string
    test_str = u'test string'
    node = AnsibleLoader(test_str).get_single_data()
    assert isinstance(AnsibleConstructor().construct_yaml_str(node), AnsibleUnicode)

    # Test with a number

# Generated at 2022-06-17 06:40:52.600051
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test construct_yaml_str
    test_str = "test_str"
    test_str_node = AnsibleLoader(test_str).get_single_data()
    assert isinstance(test_str_node, AnsibleUnicode)
    assert test

# Generated at 2022-06-17 06:41:02.196782
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with a duplicate dict key
    yaml_str = u'{a: 1, a: 2}'
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(yaml_str)
    # Test with a duplicate dict key and C.DUPLICATE_YAML_DICT_KEY == 'error'
    yaml_str = u'{a: 1, a: 2}'
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(yaml_str)
    # Test with a duplicate dict key and C.DUPLICATE_YAML_DICT_KEY == 'ignore'
    yaml_str = u'{a: 1, a: 2}'
    ansible_constructor = Ansible

# Generated at 2022-06-17 06:41:09.361540
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    # Test with a string that is not unicode
    test_string = 'test'
    test_string_node = AnsibleLoader(test_string, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(test_string_node, AnsibleUnicode)

    # Test with a string that is unicode
    test_unicode = u'test'

# Generated at 2022-06-17 06:41:23.863522
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    data = """
    foo: !unsafe "{{ lookup('pipe', 'echo hello') }}"
    """

    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()

    assert isinstance(data['foo'], AnsibleUnsafeText)
    assert data['foo']._text == "{{ lookup('pipe', 'echo hello') }}"

    # test that the !unsafe tag is preserved when dumping the data
    dumped_data = yaml.dump(data, Dumper=yaml.SafeDumper)
    assert dumped_data == data

# Generated at 2022-06-17 06:41:34.473319
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data[0], AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeText)

    dumped_data = yaml.dump(data, Dumper=AnsibleDumper)
    assert dumped_data == yaml_str

# Generated at 2022-06-17 06:41:46.415782
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test the AnsibleConstructor.construct_yaml_unsafe method
    # by loading and dumping the following YAML document:
    #
    # ---
    # - !unsafe "{{ lookup('pipe', 'echo hello') }}"
    # - !unsafe "{{ lookup('pipe', 'echo world') }}"
    #
    # and verifying that the dumped document is identical to the original.


# Generated at 2022-06-17 06:41:55.422992
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = """
        a:
          b: 1
          c: 2
        d:
          e: 3
          f: 4
    """
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert yaml_obj == {'a': {'b': 1, 'c': 2}, 'd': {'e': 3, 'f': 4}}
    assert yaml_obj.ansible_pos == ('<unicode string>', 1, 1)
    assert yaml_obj['a'].ansible_pos == ('<unicode string>', 2, 3)
    assert yaml_obj['a']['b'].ansible_pos == ('<unicode string>', 3, 5)
    assert yaml_obj['a']['c'].ans

# Generated at 2022-06-17 06:42:02.531296
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test for construct_yaml_map
    test_data = '''
    a: 1
    b: 2
    c: 3
    '''
    test_data_obj = AnsibleM

# Generated at 2022-06-17 06:42:10.815931
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'] == [1, 2, 3]

# Generated at 2022-06-17 06:42:19.262923
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test construct_yaml_map
    data = """
        a: 1
        b:
          c: 3
          d: 4
    """

# Generated at 2022-06-17 06:43:02.939531
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    test_string = "test string"
    test_string_yaml = "test string\n"

# Generated at 2022-06-17 06:43:07.913316
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256Cipher
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACCipher
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCCipher
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHM

# Generated at 2022-06-17 06:43:18.488420
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    import ansible.parsing.yaml.objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    test_string = 'test string'
    test_string_yaml = '!unsafe %s' % test_string
    test_string_yaml_loaded = yaml.load(test_string_yaml, Loader=AnsibleLoader)
    assert test_string_yaml_loaded == test_string
    assert isinstance(test_string_yaml_loaded, ansible.parsing.yaml.objects.AnsibleUnsafeText)
    assert yaml.dump(test_string_yaml_loaded, Dumper=AnsibleDumper)