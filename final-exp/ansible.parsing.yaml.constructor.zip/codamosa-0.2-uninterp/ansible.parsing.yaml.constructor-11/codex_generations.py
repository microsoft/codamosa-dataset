

# Generated at 2022-06-17 06:33:26.585151
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import ansible.parsing.vault as vault

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Write data to the temporary file
    os.write(fd, b'$ANSIBLE_VAULT;1.1;AES256\n')
    os.write(fd, b'63326233616238633762323661613331326132333132323132323132323132323\n')

# Generated at 2022-06-17 06:33:38.369407
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.nodes import MappingNode

# Generated at 2022-06-17 06:33:48.654941
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = """
    foo:
      bar: baz
      baz: foo
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar'] == 'baz'
    assert data['foo']['baz'] == 'foo'

    yaml_str = """
    foo:
      bar: baz
      bar: foo
    """


# Generated at 2022-06-17 06:34:00.749747
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode

    vault_secrets = ['test_secret']
    vault_password_file = None
    vault_id = 'test_vault'
    vault_id_2 = 'test_vault_2'

# Generated at 2022-06-17 06:34:11.653138
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write some data to the file

# Generated at 2022-06-17 06:34:19.493734
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with vault password
    vault_secrets = ['secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:34:28.205128
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)
    vault.update(vault_secrets)

    # Test with valid vault encrypted data

# Generated at 2022-06-17 06:34:39.578805
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeDict
    from ansible.utils.unsafe_proxy import AnsibleUnsafeList
    from ansible.utils.unsafe_proxy import AnsibleUnsafeNone
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 06:34:50.282549
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes, to_text

    # Test that the method construct_yaml_str of class AnsibleConstructor
    # returns an object of class AnsibleUnicode
    data = 'foo: bar'
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    # Test that the method construct_yaml_str of class AnsibleConstructor
    # returns an object of class AnsibleUnicode

# Generated at 2022-06-17 06:35:02.045290
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test case 1:
    #   - input:
    #       - node:
    #           - value:
    #               - key_node:
    #                   - value: key1
    #               - value_node:
    #                   - value: value1
    #               - key_node:
    #                   - value: key2
    #               - value_node:
    #                   - value: value2
    #   - expected output:
    #       - AnsibleMapping:
    #           - key1: value1
    #           - key2: value2

# Generated at 2022-06-17 06:35:17.385421
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_data = ciphertext.encode('utf-8')

    # test construct_vault_encrypted_unicode
    yaml_str = '!vault |\n' + ciphertext
    loader = AnsibleLoader(yaml_str, vault_secrets=vault_secrets)
    data

# Generated at 2022-06-17 06:35:24.597902
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_data = '''
    - foo
    - bar
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 2
    assert data[0] == 'foo'
    assert data[1] == 'bar'



# Generated at 2022-06-17 06:35:36.039823
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with duplicate keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert yaml_obj == {'foo': 'baz'}

    # Test with duplicate keys and C.DUPLICATE_YAML_DICT_KEY == 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    try:
        yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    except ConstructorError:
        pass

# Generated at 2022-06-17 06:35:46.451419
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    foo: bar
    baz:
      - one
      - two
    """

    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['foo'] == 'bar'
    assert yaml_obj['baz'] == ['one', 'two']
    assert yaml_obj.ansible_pos == ('<unicode string>', 1, 0)

# Generated at 2022-06-17 06:35:54.434101
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-17 06:36:04.424502
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY = 'warn'
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance

# Generated at 2022-06-17 06:36:14.449471
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.utils.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.utils.unsafe_proxy import Ans

# Generated at 2022-06-17 06:36:27.438348
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

# Generated at 2022-06-17 06:36:37.187114
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as yaml_object
    import ansible.parsing.yaml.loader as yaml_loader
    import ansible.parsing.yaml.dumper as yaml_dumper

    # Create a vault object
    vault_password = 'vault_password'
    vault_secrets = [vault_password]
    vault_obj = VaultLib(secrets=vault_secrets)

    # Create a vault encrypted string
    vault_str = 'vault_string'
    vault_encrypted_str = vault_obj.encrypt(vault_str)

    # Create a yaml node

# Generated at 2022-06-17 06:36:46.963201
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from ansible.utils.unsafe_proxy import wrap_var

    yaml_str = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    data = AnsibleLoader(StringIO(yaml_str)).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'] == [1, 2, 3]
    assert data.ansible_pos == ('<unicode string>', 1, 0)

   

# Generated at 2022-06-17 06:37:05.167828
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    yaml_str = """
    a: 1
    b: 2
    c: 3
    """

    yaml_str_duplicate_key = """
    a: 1
    b: 2
    c: 3
    a: 4
    """

    yaml_str_duplicate_key_error = """
    a: 1
    b: 2
    c: 3
    a: 4
    """


# Generated at 2022-06-17 06:37:15.019980
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    import tempfile
    import shutil
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary vault password file
    vault_password_file = os.path.join(tmpdir, 'vault_password_file')
    with open(vault_password_file, 'w') as f:
        f.write('ansible')

# Generated at 2022-06-17 06:37:25.547007
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with empty string
    node = AnsibleConstructor.construct_vault_encrypted_unicode('')
    assert node.data == ''
    assert node.vault.secrets == []
    assert node.ansible_pos == ('<string>', 1, 1)

    # Test with non-empty string
    node = AnsibleConstructor.construct_vault_encrypted_unicode('test')
    assert node.data == 'test'
    assert node.vault.secrets == []
    assert node.ansible_pos == ('<string>', 1, 1)

# Generated at 2022-06-17 06:37:35.726429
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping
    # object, and that the object has the correct position information
    test_data = '''
    foo: bar
    baz: qux
    '''
    loader = AnsibleLoader(test_data, file_name='test_file.yml')
    data = loader.get_single_data()

# Generated at 2022-06-17 06:37:42.739606
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple list
    data = '''
    - 1
    - 2
    - 3
    '''
    data_obj = AnsibleSequence([1, 2, 3])

# Generated at 2022-06-17 06:37:54.949229
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    # Test for duplicate keys
    # Test for 'ignore'
    yaml_str = to_bytes("""
    a: 1
    a: 2
    """)
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, Mapping)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 2}

    # Test for 'warn'

# Generated at 2022-06-17 06:37:58.342313
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    vault_secrets = [VaultSecret('secret', 'password')]
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'secret'

# Generated at 2022-06-17 06:38:04.654849
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
   

# Generated at 2022-06-17 06:38:14.872593
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import yaml
    from ansible.parsing.vault import VaultLib

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a vault password file
    vault_password_file = temp_path + '.vault_password'
    with open(vault_password_file, 'w') as f:
        f.write('secret')

    # Create a vault encrypted file
    vault_encrypted_file = temp_path + '.vault_encrypted'
    vault = VaultLib(vault_password_file)
    vault.encrypt_string('secret')
    with open(vault_encrypted_file, 'w') as f:
        f.write(vault.encrypted_data)

    # Read the vault

# Generated at 2022-06-17 06:38:27.372355
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test for duplicate dict keys
    yaml_str = '''
    foo:
      bar: baz
      bar: baz
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar'] == 'baz'
    assert len(data['foo']) == 1
    assert len(data)

# Generated at 2022-06-17 06:38:44.108102
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test for AnsibleConstructor.construct_yaml_seq
    # AnsibleConstructor.construct_yaml_seq(node)
    # AnsibleConstructor.construct_yaml_

# Generated at 2022-06-17 06:38:56.438345
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256Tag
    from ansible.parsing.vault import VaultAES256CBCHMACSha256TagV2
    from ansible.parsing.vault import VaultAES256CBCHMACSh

# Generated at 2022-06-17 06:39:06.987602
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:39:16.031069
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    yaml_str = '''
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)

    assert isinstance(data[0], AnsibleUnsafeText)
    assert isinstance(data[1], AnsibleUnsafeText)

    yaml_str2 = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_str == yaml_str2

# Generated at 2022-06-17 06:39:28.392762
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = [b'vault_secret']
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    loader.vault_secrets = vault_secrets
    loader.vault = VaultLib(secrets=vault_secrets)

    # test construct_yaml_map
    data = AnsibleMapping()
    data.ansible_pos = ('<string>', 1, 1)
    data.update({'a': 'b'})
    data.update({'c': 'd'})

# Generated at 2022-06-17 06:39:37.610371
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file

# Generated at 2022-06-17 06:39:45.941079
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import yaml

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor_construct_yaml_str(unittest.TestCase):
        def test_construct_yaml_str(self):
            yaml_str = '''
            - foo
            - bar
            '''
            data = yaml.load(yaml_str, Loader=AnsibleConstructor)
            self.assertEqual(data, [u'foo', u'bar'])

    unittest.main()

# Generated at 2022-06-17 06:39:51.559452
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode

# Generated at 2022-06-17 06:40:02.479089
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with vault password
    vault_secrets = ['my_secret']
    vault_password = 'my_secret'

# Generated at 2022-06-17 06:40:11.573925
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml

    # Test with a string
    yaml_str = "test"
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str(yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=yaml_str))
    assert isinstance(ansible_constructor.construct_yaml_str(yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=yaml_str)), AnsibleUnicode)

    # Test with a unicode string
    yaml_str = u"test"
    ansible_constructor = AnsibleConstructor()
    ansible_construct

# Generated at 2022-06-17 06:40:28.790132
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB

# Generated at 2022-06-17 06:40:40.484819
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.utils.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.utils.unsafe_proxy import Ans

# Generated at 2022-06-17 06:40:53.310268
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Create a string with a YAML map
    yaml_str = u'{a: 1, b: 2, c: 3}\n'

    # Create a string buffer
    buf = StringIO()

    # Save the original stdout
    stdout = sys.stdout

    # Redirect stdout to the string buffer
    sys.stdout = buf

    # Load the YAML string
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()

    # Dump the data
    Ans

# Generated at 2022-06-17 06:41:02.685787
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode

    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)
    vault.update(vault_secrets)

# Generated at 2022-06-17 06:41:12.305493
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 06:41:15.855079
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = u'foo: bar'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'



# Generated at 2022-06-17 06:41:26.795156
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test that the constructor is called
    class TestConstructor(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return 'test'

    # Test that the constructor is called
    class TestConstructor2(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return AnsibleUnsafeText('test')

    # Test that the constructor is called
    class TestConstructor3(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return AnsibleUnsafe

# Generated at 2022-06-17 06:41:32.873153
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = "foo: bar"
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data['foo'], AnsibleUnicode)

# Generated at 2022-06-17 06:41:44.813500
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # test for duplicate dict key
    test_data = '''
    a: 1
    a: 2
    '''
    test_data_dup_key = '''
    a: 1
    a: 2
    '''
    test_data_dup_key_

# Generated at 2022-06-17 06:41:51.074094
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the unsafe text is properly wrapped
    data = AnsibleLoader('').get_single_data()
    assert isinstance(data, AnsibleUnsafeText)

    # Test that the unsafe text is properly unwrapped
    assert AnsibleDumper(None, default_flow_style=False).represent_data(data) == '!unsafe ""\n'

# Generated at 2022-06-17 06:42:09.348296
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple dict
    data = {'a': 'b'}
    yaml_data = AnsibleDumper().dump(data)
    yaml_data = yaml_data.replace('\n', '')
    assert yaml_data == '{a: b}'
    loaded_data = AnsibleLoader(yaml_data).get_single_data()

# Generated at 2022-06-17 06:42:16.741309
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    data = {'a': [1, 2, 3]}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    yaml_data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(yaml_data['a'], AnsibleSequence)
    assert yaml_data['a'] == [1, 2, 3]

# Generated at 2022-06-17 06:42:28.203668
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.constructor = AnsibleConstructor()

        def test_construct_mapping_duplicate_key(self):
            # Test that duplicate keys are detected
            yaml_str = '''
            a: 1
            a: 2
            '''
            with self.assertRaises(ConstructorError) as cm:
                self.constructor.construct_yaml(yaml_str)
            self.assertIn('found a duplicate dict key', str(cm.exception))


# Generated at 2022-06-17 06:42:37.911726
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import base64
    import binascii

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write vault encrypted data to the file
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_data = 'This is a secret message'
    with open(path, 'wb') as f:
        f.write(vault.encrypt(vault_data))

    # Read the file
    with open(path, 'rb') as f:
        data = f.read()

    # Decode the vault encrypted data
    vault

# Generated at 2022-06-17 06:42:49.423329
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((u'key1', u'value1'))
    node.value.append((u'key2', u'value2'))
    node.value.append((u'key3', u'value3'))
    node.value.append((u'key4', u'value4'))
    node.value.append((u'key5', u'value5'))
    node.value.append((u'key6', u'value6'))
    node.value.append((u'key7', u'value7'))
    node.value.append((u'key8', u'value8'))
   

# Generated at 2022-06-17 06:43:01.041577
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar'}
    data_str = 'foo: bar'
    data_unsafe = '!unsafe foo'
    data_unsafe_str = '!unsafe "foo"'
    data_unsafe_str_2 = '!unsafe \'foo\''
    data_unsafe_str_3 = '!unsafe "foo bar"'
    data_unsafe_str_4 = '!unsafe \'foo bar\''
    data_unsafe_str_5 = '!unsafe "foo bar baz"'

# Generated at 2022-06-17 06:43:12.245763
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from yaml import load, dump

    # Test with a simple string
    yaml_str = u'foo'
    data = load(StringIO(yaml_str), Loader=AnsibleLoader)
    assert isinstance(data, AnsibleUnicode)
    assert data == u'foo'

    # Test with a string containing a newline
    yaml_str = u'foo\nbar'
    data = load(StringIO(yaml_str), Loader=AnsibleLoader)
    assert isinstance(data, AnsibleUnicode)
