

# Generated at 2022-06-17 06:33:29.137323
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import base64
    import binascii
    import json
    import time
    import random
    import string
    import hashlib
    import hmac
    import struct
    import getpass
    import pwd
    import grp
    import stat
    import platform
    import re
    import datetime
    import traceback
    import ansible.constants as C
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-17 06:33:40.809366
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import ansible.parsing.yaml.loader
    import ansible.parsing.vault
    import ansible.parsing.vault.VaultLib
    import ansible.parsing.vault.VaultEditor
    import ansible.parsing.vault.VaultSecret

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)

    # create the vault password file
    vault_password_file = os.path.join(tmpdir, ".vault_pass.txt")

# Generated at 2022-06-17 06:33:50.292190
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from yaml import load, dump
    from yaml.constructor import ConstructorError
    from yaml.nodes import MappingNode
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-17 06:34:00.924428
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar'}
    data_as_yaml = AnsibleDumper().dump(data)
    data_as_yaml = data_as_yaml.replace('bar', '!unsafe bar')
    data_as_yaml = data_as_yaml.replace('foo', '!unsafe foo')
    data_as_yaml = data_as_yaml.replace('{', '!unsafe {')
    data_as_yaml = data_as_yaml.replace('}', '!unsafe }')
    data_as_yaml

# Generated at 2022-06-17 06:34:11.827822
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dictionary
    yaml_data = '''
        a: 1
        b: 2
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data == {'a': 1, 'b': 2}

    # Test with a dictionary with duplicate keys
    yaml_data = '''
        a: 1
        b: 2
        a: 3
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data == {'a': 3, 'b': 2}

    # Test with a dictionary with duplicate keys and C.DUPLICATE_YAML_DICT_KEY set to 'warn'
    C.DUPLICATE_YAML_DICT_KEY = 'warn'


# Generated at 2022-06-17 06:34:20.352484
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Create a string with a duplicate key
    yaml_str = '''
    foo:
      bar: 1
      bar: 2
    '''

    # Load the string with AnsibleLoader
    loader = AnsibleLoader(StringIO(yaml_str), file_name='<string>')
    data = loader.get_single_data()

    # Dump the data with AnsibleDumper
    stream = StringIO()
    dumper = AnsibleDumper(stream, default_flow_style=False)
    dumper.open()
    d

# Generated at 2022-06-17 06:34:25.964722
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_data = """
    foo: bar
    baz:
      - qux
      - quux
    """

    yaml_obj = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj == {'foo': 'bar', 'baz': ['qux', 'quux']}

# Generated at 2022-06-17 06:34:35.920267
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - foo
    - bar
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert data == ['foo', 'bar']
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

# Generated at 2022-06-17 06:34:43.177912
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    # test with a string
    data = 'this is a string'
    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    value = loader.get_single_data()
    assert isinstance(value, AnsibleUnicode)
    assert value == data

    # test with a unicode string
    data = u'this is a unicode string'
    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    value = loader.get_single_

# Generated at 2022-06-17 06:34:54.412164
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import unittest
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.stream = io.StringIO()
            self.handler = logging.StreamHandler(self.stream)
            self.handler.setLevel(logging.DEBUG)
            self.logger = logging.getLogger('ansible.parsing.yaml.loader')
            self.logger.addHandler(self.handler)
            self.logger.setLevel(logging.DEBUG)

        def tearDown(self):
            self.logger.removeHandler(self.handler)


# Generated at 2022-06-17 06:35:12.034799
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Create a vault object
    vault = VaultLib([])

    # Create a string with vault encrypted data

# Generated at 2022-06-17 06:35:25.106444
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = '!unsafe "string"'
    loader = AnsibleLoader(data, None)
    assert isinstance(loader.get_single_data(), AnsibleUnsafeText)

    # Test with a list
    data = '!unsafe [1, 2, 3]'
    loader = AnsibleLoader(data, None)
    assert isinstance(loader.get_single_data(), AnsibleUnsafeText)

    # Test with a dict
    data = '!unsafe {a: 1, b: 2, c: 3}'

# Generated at 2022-06-17 06:35:36.333434
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:35:41.359785
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    if sys.version_info[0] < 3:
        assert isinstance(AnsibleConstructor().construct_yaml_str(None), unicode)
    else:
        assert isinstance(AnsibleConstructor().construct_yaml_str(None), str)

# Generated at 2022-06-17 06:35:50.753035
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    # Test with duplicate dict keys
    yaml_str = """
    foo: bar
    foo: baz
    """
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == {'foo': 'baz'}

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY set to 'warn'
    yaml_str = """
    foo: bar
    foo: baz
    """
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == {'foo': 'baz'}

    # Test with duplicate dict keys and C.DUPLICATE_YAML

# Generated at 2022-06-17 06:36:00.901856
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test case 1: duplicate dict keys
    yaml_str = '''
    a: 1
    b: 2
    a: 3
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 3, 'b': 2}

    # Test case 2: duplicate dict keys with 'ignore'
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    data = AnsibleLoader(yaml_str).get_single_data()

# Generated at 2022-06-17 06:36:09.259599
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
    a: 1
    b: 2
    c: 3
    d: 4
    e: 5
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

    yaml_str = """
    a: 1
    b: 2
    c: 3
    d: 4
    e: 5
    a: 6
    """


# Generated at 2022-06-17 06:36:17.565697
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping
    # object.
    data = AnsibleLoader(None, None).get_single_data("""
        foo: bar
        baz: quux
    """)
    assert isinstance(data, AnsibleMapping)

    # Test that AnsibleDumper.represent_yaml_map returns a MappingNode
    # object.
    data = AnsibleMapping()
    data['foo'] = 'bar'
    data

# Generated at 2022-06-17 06:36:28.436306
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = """
- 1
- 2
- 3
"""

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 3
    assert data[0] == 1
    assert data[1] == 2
    assert data[2] == 3

    # Test round trip
    assert yaml_str == AnsibleDumper(data, default_flow_style=False).get_single_data()

# Generated at 2022-06-17 06:36:33.394206
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test that AnsibleConstructor.construct_mapping() works as expected
    # when the yaml contains duplicate keys.
    #
    # The test is done by comparing the result of the method
    # AnsibleConstructor.construct_mapping() with the expected result.
    #
    # The expected result is obtained by using the method
    # SafeConstructor.construct_mapping() of the class yaml.constructor.SafeConstructor
    # which is the parent class of AnsibleConstructor.
    #
    # The test is done for the following values of the configuration option
    # DUPLICATE_YAML_DICT_KEY:
    #
    #  

# Generated at 2022-06-17 06:36:51.744827
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.nodes import AnsibleMappingNode

    # Test with a string
    test_string = 'test string'
    test_string_node = AnsibleMappingNode(tag=u'tag:yaml.org,2002:str', value=test_string)
    test_string_node.start_mark = object()
    test_string_node.end_mark = object()
    test_string_node.style = 'test style'
    test_string_node.anchor = 'test anchor'

# Generated at 2022-06-17 06:37:04.268737
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test the basic functionality of construct_yaml_seq
    data = yaml.load("""
    - foo
    - bar
    """, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert data == ['foo', 'bar']
    assert data.ansible

# Generated at 2022-06-17 06:37:14.339513
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that AnsibleConstructor.construct_yaml_unsafe returns an AnsibleUnsafeText object
    # when given a string
    test_string = u'!unsafe test string'
    test_string_node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=test_string)
    test_string_object = AnsibleConstructor.construct_yaml_unsafe(test_string_node)
    assert isinstance(test_string_object, AnsibleUnsafeText)
    assert test_string

# Generated at 2022-06-17 06:37:21.015552
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import yaml

    # Test with a simple sequence
    test_data = '''
    - foo
    - bar
    - baz
    '''
    test_data_expected = AnsibleSequence(['foo', 'bar', 'baz'])
    test

# Generated at 2022-06-17 06:37:30.254182
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.utils.unsafe_proxy import wrap_var

    vault_password = 'vault_password'
    vault_secrets = [ vault_password ]
    vault_id = 'default'

# Generated at 2022-06-17 06:37:39.981751
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = ['test_secret']
    vault = VaultLib(secrets=vault_secrets)
    vault_text = vault.encrypt('test_text')
    vault_text_yaml = yaml.dump(vault_text, Dumper=AnsibleDumper)
    vault_text_yaml = vault_text_yaml.replace('!!python/unicode', '!vault')

# Generated at 2022-06-17 06:37:51.174290
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - one
    - two
    - three
    '''

    data_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data_obj, AnsibleSequence)
    assert data_obj == ['one', 'two', 'three']

    data_yaml = yaml.dump(data_obj, Dumper=AnsibleDumper)
    assert data_yaml == data

# Generated at 2022-06-17 06:38:00.785323
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-17 06:38:11.667577
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret']
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    yaml_data = """
    foo: bar
    baz:
      - one
      - two
    """
    data = yaml.load(yaml_data, Loader=loader)
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['baz'], AnsibleSequence)

# Generated at 2022-06-17 06:38:26.089157
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import range

    display = Display()


# Generated at 2022-06-17 06:38:43.842145
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import stat

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary vault password file
    vault_password_file = os.path.join(tmpdir, 'vault_password_file')
    with open(vault_password_file, 'w') as f:
        f.write('ansible')

    # Create temporary vault file
    vault_file = os.path.join(tmpdir, 'vault_file')
    with open(vault_file, 'w') as f:
        f.write('$ANSIBLE_VAULT;1.1;AES256\n')

# Generated at 2022-06-17 06:38:56.437513
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test for duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['foo'] == 'baz'

    # Test for duplicate dict keys with different types
    yaml_str = '''
    foo: bar
    foo: 123
    '''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)

# Generated at 2022-06-17 06:39:01.645209
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleUnsafeText
    yaml_data = '!unsafe "{{ foo }}"'
    data = AnsibleLoader(yaml_data).get_single_data()

# Generated at 2022-06-17 06:39:10.607926
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar', 'baz': 'qux'}
    yaml_str = '---\nfoo: bar\nbaz: qux\n'

    # test round trip
    ansible_loader = AnsibleLoader(yaml_str)
    ansible_loader.vault_secrets = []
    data_loaded = ansible_loader.get_single_data()
    assert data_loaded == data

    ansible_dumper = AnsibleDumper()
    yaml_str_dumped = ansible_dumper.dump(data_loaded)

# Generated at 2022-06-17 06:39:18.095353
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = '''
        - foo: bar
        - baz:
            - 1
            - 2
        - qux:
            - a: 1
            - b: 2
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['baz'], list)
    assert isinstance(data[2]['qux'], list)
    assert isinstance(data[2]['qux'][0], dict)
    assert isinstance(data[2]['qux'][1], dict)

# Generated at 2022-06-17 06:39:29.544748
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib

    vault_secrets = [b'vault_secret']
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    loader.add_constructor(u'tag:yaml.org,2002:map', AnsibleConstructor.construct_yaml_map)
    loader.add_constructor(u'tag:yaml.org,2002:python/dict', AnsibleConstructor.construct_yaml_map)
    loader.add_constructor(u'tag:yaml.org,2002:str', AnsibleConstructor.construct_yaml_str)
    loader.add_constructor

# Generated at 2022-06-17 06:39:38.434847
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.vault import VaultLib as VaultLibUtils
    import os
    import tempfile

    # create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # create a vault password file
    vault_password_file = temp_path + ".vaultpass"
    with open(vault_password_file, 'w') as f:
        f.write("vaultpassword")



# Generated at 2022-06-17 06:39:47.164721
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - 1
    - 2
    - 3
    '''
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]
    assert yaml_obj.ansible_pos == ('<unicode string>', 1, 0)
    assert AnsibleDumper().dump(yaml_obj) == data

# Generated at 2022-06-17 06:39:59.159543
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)
    vault_text = vault.encrypt(b'plaintext')
    vault_text_str = vault_text.decode('utf-8')
    vault_text_str_yaml = '!vault |\n  ' + vault_text_str.replace('\n', '\n  ')
    vault_text_str_yaml_bytes = vault_text_str_yaml.encode('utf-8')

    # Test with a string

# Generated at 2022-06-17 06:40:08.666275
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    # Test with a simple sequence
    data = AnsibleSequence(['a', 'b', 'c'])
    data.ansible_pos = ('test_file', 1, 1)
    stream = StringIO()
    AnsibleDumper(stream, default_flow_style=False).dump(data)
    stream.seek(0)
    data2 = AnsibleLoader(stream).get_single_data()
    assert data == data2

    # Test with a sequence of sequences

# Generated at 2022-06-17 06:40:28.002503
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdin
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretAWS
    from ansible.parsing.vault import VaultSecretGPG
    from ansible.parsing.vault import VaultSecretKeyring
    from ansible.parsing.vault import VaultSecretKMS
    from ansible.parsing.vault import VaultSecretAzureKeyVault
    from ansible.parsing.vault import Vault

# Generated at 2022-06-17 06:40:40.121781
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.display import Display
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 06:40:49.007680
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - 1
    - 2
    - 3
    """

    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]

# Generated at 2022-06-17 06:40:59.252948
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_password = 'vault_password'
    vault_secrets = [ vault_password ]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext)
    yaml_data = yaml.dump({'ciphertext': ciphertext}, Dumper=AnsibleDumper, default_flow_style=False)

# Generated at 2022-06-17 06:41:05.845075
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
- 1
- 2
- 3
'''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str


# Generated at 2022-06-17 06:41:13.911995
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    import base64
    from ansible.parsing.vault import VaultLib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary vault password file
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, 'w') as f:
        f.write("vault_password\n")

    # Create a temporary vault file
    vault_file = os.path.join(tmpdir, "vault_file")
    with open(vault_file, 'w') as f:
        f.write("$ANSIBLE_VAULT;1.1;AES256\n")
        f.write

# Generated at 2022-06-17 06:41:26.249417
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = "vault_password"
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext_data = "plaintext_data"
    ciphertext_data = vault.encrypt(plaintext_data)
    ciphertext_data_yaml = "!vault |\n  " + ciphertext_data.replace("\n", "\n  ")
    yaml_data = yaml.load(ciphertext_data_yaml, Loader=AnsibleConstructor)

# Generated at 2022-06-17 06:41:36.526777
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdout
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretAsk
    from ansible.parsing.vault import VaultSecretAskNew
    from ansible.parsing.vault import VaultSecretAskNewConfirm
    from ansible.parsing.vault import VaultSecretAskNewConfirmOnce
    from ansible.parsing.vault import VaultSecretAskNewConfirmOncePrompt

# Generated at 2022-06-17 06:41:48.429360
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    # Test with a regular string
    data = 'string'
    node = AnsibleLoader(data, file_name='<string>').get_single_data()
    assert isinstance(AnsibleConstructor(file_name='<string>').construct_yaml_str(node), AnsibleUnicode)

    # Test with a unicode string
    data = u'unicode'
    node = AnsibleLoader(data, file_name='<string>').get_single_data()

# Generated at 2022-06-17 06:41:58.695822
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test the constructor
    yaml_str = '''
    a: 1
    b: 2
    c: 3
    '''
    yaml_str_dup = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''
    yaml_str_dup_warn = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''

# Generated at 2022-06-17 06:42:14.978106
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    # Test with no duplicate keys
    yaml_str = '''
    a: 1
    b: 2
    c: 3
    '''
    data = AnsibleLoader(yaml_str, vault_secrets=[VaultLib.DEFAULT_VAULT_ID]).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    # Test with duplicate keys
    yaml_str = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''
   

# Generated at 2022-06-17 06:42:25.037298
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    a: 1
    b: 2
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2}
    assert AnsibleDumper().dump(data) == yaml_str



# Generated at 2022-06-17 06:42:35.212907
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_yaml = '!vault |\n  ' + ciphertext.replace('\n', '\n  ')
    ciphertext_yaml_bytes = to_bytes(ciphertext_yaml)
    ciphertext_yaml_bytes_stream = yaml.compat.BytesIO(ciphertext_yaml_bytes)

# Generated at 2022-06-17 06:42:47.186884
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    a: 1
    b: 2
    c: 3
    '''
    data_expected = '''{a: 1, b: 2, c: 3}'''

    data_mapping = AnsibleMapping()
    data_mapping['a'] = 1
    data_mapping['b'] = 2
    data_mapping['c'] = 3

    data_mapping_expected = AnsibleMapping()
    data_mapping_expected['a'] = 1
    data_mapping_expected['b'] = 2

# Generated at 2022-06-17 06:42:59.266573
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.utils.unsafe_proxy import wrap_var

    yaml_str = '''
- 1
- 2
- 3
'''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert data[0] == 1
    assert data[1] == 2
    assert data[2] == 3
    assert yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-17 06:43:10.657912
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)

    # Test with a simple map
    data = {'a': 1, 'b': 2}
    yaml_data = AnsibleDumper().dump(data)
    loader = AnsibleLoader(vault_secrets=vault_secrets)
    ansible

# Generated at 2022-06-17 06:43:19.827273
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader