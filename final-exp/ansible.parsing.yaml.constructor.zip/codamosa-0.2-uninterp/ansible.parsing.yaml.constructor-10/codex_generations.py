

# Generated at 2022-06-17 06:33:28.121710
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    yaml_str = '''
a: 1
b: 2
c: 3
'''
    stream = StringIO(yaml_str)
    data = AnsibleLoader(stream).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert AnsibleDumper().dump(data) == yaml_str


# Generated at 2022-06-17 06:33:39.750799
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - 1
    - 2
    - 3
    """

    # Create a sequence
    sequence = AnsibleSequence()
    sequence.append(1)
    sequence.append(2)
    sequence.append(3)

    # Create a loader
    loader = AnsibleLoader(data, file_name='<string>')

    # Create a dumper
    dumper = AnsibleDumper()

    # Load the data
    loaded_data = loader.get_single_data()

    # Dump the data

# Generated at 2022-06-17 06:33:49.712072
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
a: 1
b: 2
c: 3
"""
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    yaml_str = """
a: 1
b: 2
c: 3
a: 4
"""
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:33:54.106049
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

# Generated at 2022-06-17 06:34:02.598287
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h', 'i': 'j', 'k': 'l', 'm': 'n', 'o': 'p', 'q': 'r', 's': 't', 'u': 'v', 'w': 'x', 'y': 'z'}

    # Create a yaml string from the data
    yaml_string = yaml.dump(data, Dumper=AnsibleDumper)

    # Load the yaml string into a AnsibleMapping
    ansible_m

# Generated at 2022-06-17 06:34:13.143443
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_data = '''
    - foo: bar
    - foo: baz
    '''

    test_data_unicode = u'''
    - foo: bar
    - foo: baz
    '''

    data = yaml.load(test_data, Loader=AnsibleLoader)
    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['foo'], AnsibleUnicode)

    data = yaml.load(test_data_unicode, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:34:21.013607
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test for duplicate keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 1
    assert data['foo'] == 'baz'

    # Test for duplicate keys with different types
    yaml_str = '''
    foo: bar
    foo: 123
    '''
    data = Ansible

# Generated at 2022-06-17 06:34:28.740353
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a simple mapping
    data = '''
    a: b
    c: d
    '''
    data_mapping = AnsibleMapping()
    data_mapping['a'] = AnsibleUnicode('b')
    data_mapping['c'] = AnsibleUnicode('d')
    data_

# Generated at 2022-06-17 06:34:39.941178
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)
    vault_text = vault.encrypt('test')
    vault_text = vault_text.replace('\n', '\r\n')
    vault_text = vault_text.replace('\r\r\n', '\r\n')
    data = {'test': vault_text}

# Generated at 2022-06-17 06:34:50.545183
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['vault_secret']
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-17 06:35:07.464240
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 06:35:17.581213
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar', 'baz': 'qux'}
    yaml_data = AnsibleDumper().dump(data)
    yaml_data = yaml_data.replace('bar', '!unsafe bar')
    yaml_data = yaml_data.replace('qux', '!unsafe qux')
    yaml_data = yaml_data.replace('{', '!unsafe {')
    yaml_data = yaml_data.replace('}', '!unsafe }')

# Generated at 2022-06-17 06:35:24.611212
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test for empty list
    data = AnsibleSequence()
    data.ansible_pos = ('test', 1, 1)
    assert AnsibleDumper(None, None, None).represent_data(data) == '[]\n'

    # Test for a list

# Generated at 2022-06-17 06:35:36.045676
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.nodes import MappingNode

# Generated at 2022-06-17 06:35:47.789114
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write the YAML to the file
    with open(fname, 'w') as f:
        f.write('---\n')
        f.write('foo: !vault |\n')
        f.write('          $ANSIBLE_VAULT;1.1;AES256\n')

# Generated at 2022-06-17 06:35:55.505121
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Create a vault
    vault_secrets = ['vault_secret']
    vault = VaultLib(secrets=vault_secrets)

    # Create a loader

# Generated at 2022-06-17 06:36:05.388060
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test for !unsafe
    yaml_str = u'!unsafe 123'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == u'123'


# Generated at 2022-06-17 06:36:12.337674
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import yaml

    # We need to use the same constructor for both the load and the load_all
    # calls, so we create a subclass of AnsibleConstructor that overrides the
    # construct_yaml_map method to return a list instead of a generator.
    class TestConstructor(AnsibleConstructor):
        def construct_yaml_map(self, node):
            return list(super(TestConstructor, self).construct_yaml_map(node))

    # We need to use the same loader for both the load and the load_all calls,
    # so we create a subclass of yaml.Loader that overrides the construct_mapping
    # method to use our TestConstructor.

# Generated at 2022-06-17 06:36:20.883044
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    yaml_str = '''
    - !unsafe "{{ foo }}"
    '''

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data[0] == AnsibleUnsafeText('{{ foo }}')

# Generated at 2022-06-17 06:36:31.245053
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml
    import os
    import sys

    # Create a vault object
    vault_sec

# Generated at 2022-06-17 06:36:45.076688
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-17 06:36:54.360145
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-17 06:37:01.034028
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = '''
    - 1
    - 2
    - 3
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]



# Generated at 2022-06-17 06:37:07.378586
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    node.start_mark = object()
    node.end_mark = object()
    ac = AnsibleConstructor()
    data = ac.construct_yaml_map(node)
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos == (None, 1, 1)


# Generated at 2022-06-17 06:37:16.178875
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 06:37:28.089084
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import tempfile
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write some YAML to the temporary file
    with open(path, 'w') as f:
        f.write("""
---
- hosts: localhost
  tasks:
    - name: test
      shell: echo "{{ '!unsafe' | to_nice_yaml }}"
""")

    # Read the YAML from the temporary file
    with open(path, 'r') as stream:
        data = yaml.load(stream, AnsibleConstructor)

    # Delete the temporary file
    os.remove(path)

    #

# Generated at 2022-06-17 06:37:38.647704
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test case 1
    data = '''
    a: 1
    b: 2
    c: 3
    '''
    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    # Test case 2

# Generated at 2022-06-17 06:37:49.988989
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate keys
    test_data = """
    key1: value1
    key2: value2
    key1: value3
    """
    test_data_duplicate_keys = yaml.load(test_data, Loader=AnsibleLoader)
    assert isinstance(test_data_duplicate_keys, AnsibleMapping)
    assert test_data_duplicate_keys == {'key1': 'value3', 'key2': 'value2'}

    # Test with no duplicate keys

# Generated at 2022-06-17 06:38:00.511562
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
   

# Generated at 2022-06-17 06:38:11.303331
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - foo: bar
    - baz: qux
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['baz'], AnsibleUnicode)

    yaml_str = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-17 06:38:28.179923
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert AnsibleDumper().dump(data) == yaml_str



# Generated at 2022-06-17 06:38:40.632646
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTagNoIV

# Generated at 2022-06-17 06:38:46.893208
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import base64
    import binascii
    import json
    import sys
    import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.vault_password_file = os.path.join(self.temp_dir, 'vault_password_file')
            self.vault_password = 'vault_password'
            self.vault_password_file_content = self.vault_password
            with open(self.vault_password_file, 'w') as f:
                f.write(self.vault_password_file_content)

            self.vault_password_file_content_

# Generated at 2022-06-17 06:38:57.908278
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    # Test with a string
    test_string = u'This is a test string'
    test_string_yaml = u'tag:yaml.org,2002:str\nThis is a test string\n'
    test_string_yaml_bytes = to_bytes(test_string_yaml)
    test_string_yaml_bytes_len = len(test_string_yaml_bytes)
    test_string_yaml_bytes_pos = 0
    test_string_yaml_bytes

# Generated at 2022-06-17 06:39:08.211941
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    class MyConstructor(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return 'unsafe'

    class MyRepresenter(yaml.representer.SafeRepresenter):
        def represent_yaml_unsafe(self, data):
            return self.represent_scalar(u'!unsafe', data)

    MyConstructor.add_constructor(u'!unsafe', MyConstructor.construct_yaml_unsafe)
    MyRepresenter.add_representer(AnsibleUnsafeText, MyRepresenter.represent_yaml_unsafe)


# Generated at 2022-06-17 06:39:17.112537
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - foo: bar
      bam: baz
    - foo: baz
      bam: bar
    """

    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get_single_data()

    assert isinstance(seq, AnsibleSequence)
    assert len(seq) == 2
    assert isinstance(seq[0], AnsibleMapping)
    assert isinstance(seq[1], AnsibleMapping)
    assert seq[0]['foo'] == 'bar'

# Generated at 2022-06-17 06:39:28.942757
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml.nodes import ScalarNode
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.scanner import Scanner

    # Create a ScalarNode
    node = ScalarNode(u'tag:yaml.org,2002:str', u'foo', (1, 1), (1, 4))

    # Create a Parser
    stream = u'foo'
    loader = AnsibleLoader(stream, None)
    scanner = Scanner(stream, loader)
    parser = Parser(scanner, loader)

    # Create a Composer
    composer = Composer(parser, loader)

    # Create an Ans

# Generated at 2022-06-17 06:39:38.091675
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.nodes import MappingNode

# Generated at 2022-06-17 06:39:47.744430
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys
    import yaml

    # Test 1: Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping object
    #         when given a yaml.nodes.MappingNode object
    # Given
    test_data = """
    ---
    key1: value1
    key2: value2
    """
    test_stream = StringIO(test_data)
    test_loader = AnsibleLoader(test_stream, file_name='<string>')
    test_node = test_loader.get_single_data()

   

# Generated at 2022-06-17 06:39:59.340152
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    class AnsibleConstructor(yaml.SafeConstructor):
        def construct_yaml_seq(self, node):
            data = AnsibleSequence()
            yield data
            data.extend(self.construct_sequence(node))
            data.ansible_pos = self._node_position_info(node)

    def construct_yaml_str(self, node):
        # Override the default string handling function
        # to always return unicode objects
        value = self.construct_scalar(node)
        return AnsibleUnicode(value)

    AnsibleConstructor.add_constructor(
        u'tag:yaml.org,2002:str',
        construct_yaml_str)

   

# Generated at 2022-06-17 06:40:07.002698
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    yaml_str = '''
    - 1
    - 2
    - 3
    '''

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]

# Generated at 2022-06-17 06:40:11.104432
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = """
    a: 1
    b: 2
    """
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == {'a': 1, 'b': 2}
    assert data.ansible_pos == ('<string>', 1, 0)


# Generated at 2022-06-17 06:40:25.333780
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = AnsibleSequence([1, 2, 3])
    data.ansible_pos = ('test', 1, 1)

    yaml = AnsibleDumper().dump(data, Dumper=AnsibleDumper)
    assert yaml == '- 1\n- 2\n- 3\n'

    data2 = AnsibleLoader(None, None).load(yaml)
    assert data2 == data
    assert data2.ansible_pos == data.ansible_pos



# Generated at 2022-06-17 06:40:37.358967
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test for duplicate dict keys
    test_data = '''
    foo: bar
    foo: baz
    '''
    test_data_stream = StringIO(test_data)
    test_data_stream.name = '<string>'
    sys.stdin = test_data_stream
    loader = AnsibleLoader(None, None)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {u'foo': u'baz'}
    dumper = Ans

# Generated at 2022-06-17 06:40:44.992067
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 06:40:56.362571
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret1', 'vault_secret2']
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-17 06:41:04.449187
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    d: 4
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

# Generated at 2022-06-17 06:41:10.085969
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secret = 'test_secret'
    vault_secrets = [vault_secret]
    vault_password_file = None
    vault_ids = ['test_vault_id']
    vault_id = vault_ids[0]
    vault_id_file = None


# Generated at 2022-06-17 06:41:24.711514
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_data = """
    a: 1
    b: 2
    c: 3
    """

    data = yaml.load(test_data, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3
    assert data.ansible_pos == ('<string>', 1, 0)

    test_data = """
    a: 1
    b: 2
    c: 3
    a: 4
    """

    data = yaml.load(test_data, Loader=AnsibleLoader)
   

# Generated at 2022-06-17 06:41:35.616672
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault encrypted string
    vault_secrets = ['test_secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:41:53.058389
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-17 06:42:00.619918
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256CFB1
   

# Generated at 2022-06-17 06:42:11.461168
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    yaml_str = '''
    - 1
    - 2
    - 3
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

# Generated at 2022-06-17 06:42:25.461023
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test 1:
    # Test if the method construct_yaml_seq of class AnsibleConstructor
    # returns an AnsibleSequence object.
    data = '''
    - foo
    - bar
    '''
    data_loaded = AnsibleLoader(data).get_single_data()
    assert isinstance(data_loaded, AnsibleSequence)

    # Test 2:
    # Test if the method construct_yaml_seq of class AnsibleConstructor
    # returns an AnsibleSequence object with the correct data.

# Generated at 2022-06-17 06:42:35.256131
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Test with a simple mapping
    data = '''
    a: 1
    b: 2
    c: 3
    '''
    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    # Test with a nested mapping

# Generated at 2022-06-17 06:42:47.259689
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for empty list
    data = []
    yaml_str = AnsibleDumper().dump(data)
    data2 = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data2, AnsibleSequence)
    assert len(data2) == 0

    # Test for list with one

# Generated at 2022-06-17 06:42:59.308329
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    a: 1
    b:
      c: 3
      d: 4
    '''

    data_mapping = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data_mapping, AnsibleMapping)
    assert data_mapping == {'a': 1, 'b': {'c': 3, 'd': 4}}

    data_mapping = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data_mapping, AnsibleMapping)
    assert data_

# Generated at 2022-06-17 06:43:05.909456
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    data = """
    foo: !unsafe "{{ foo }}"
    bar: !unsafe "{{ bar }}"
    """

    loader = AnsibleLoader(data)
    loader.construct_mapping(loader.get_single_data())
    assert isinstance(loader.get_single_data(), AnsibleMapping)

# Generated at 2022-06-17 06:43:17.137719
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Write a YAML file with a vault encrypted string
    with os.fdopen(fd, 'w') as f:
        f.write('---\n')