

# Generated at 2022-06-17 06:33:27.498747
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes, to_text

    data = """
    a: 1
    b: 2
    c: 3
    """
    data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    data = """
    a: 1
    b: 2
    c: 3
    a: 4
    """

# Generated at 2022-06-17 06:33:39.088488
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create a vault object
    vault = VaultLib(secrets=['secret'])

    # Create a yaml string

# Generated at 2022-06-17 06:33:49.234479
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-17 06:33:55.024633
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml

    # Test for duplicate dict keys
    yaml_data = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test for duplicate dict keys with !vault

# Generated at 2022-06-17 06:34:03.075897
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

# Generated at 2022-06-17 06:34:13.857507
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)
    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)
    vault_secrets = ['secret1', 'secret2']

# Generated at 2022-06-17 06:34:21.797206
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with duplicate keys
    yaml_str = '''
    foo: 1
    foo: 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {u'foo': 2}

    # Test with no duplicate keys
    yaml_str = '''
    foo: 1
    bar: 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:34:28.190530
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import io
    import yaml

    # Test with a duplicate key
    test_yaml = '''
    foo: bar
    foo: baz
    '''
    test_stream = io.StringIO(test_yaml)
    test_stream.name = '<string>'
    test_constructor = AnsibleConstructor(file_name=test_stream.name)
    test_loader = yaml.Loader(test_stream, test_constructor)
    test_loader.get_single_data()

    # Test with a duplicate key and the ignore option
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    test_yaml = '''
    foo: bar
    foo: baz
    '''

# Generated at 2022-06-17 06:34:39.579367
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    from ansible.parsing.vault import VaultLib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    vault_password_file = os.path.join(tmpdir, "vault_password.txt")
    vault_file = os.path.join(tmpdir, "vault_file.yml")

    # Create a vault password file
    vault_password = "vault_password"
    with open(vault_password_file, 'w') as f:
        f.write(vault_password)

    # Create a vault file
    vault_data = "vault_data"

# Generated at 2022-06-17 06:34:50.282555
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    test_string = 'test string'
    test_string_yaml = '!unsafe "%s"' % test_string
    test_string_unsafe = AnsibleUnsafeText(test_string)
    test_string_unsafe_yaml = AnsibleDumper().dump(test_string_unsafe)
    assert test_string_yaml == test_string_unsafe_yaml
    assert test_string_unsafe == AnsibleLoader(test_string_yaml).get_single_data()

    # Test with a number
    test_number = 42

# Generated at 2022-06-17 06:35:01.609683
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    vault_password = 'vault_password'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-17 06:35:06.664082
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_str = '''
    - 1
    - 2
    - 3
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]

# Generated at 2022-06-17 06:35:16.892558
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create a vault secret
    vault_secret = VaultSecret('password')

    # Create a vault
    vault = VaultLib([vault_secret])

    # Create a constructor
    constructor = AnsibleConstructor(vault_secrets=[vault_secret])

    # Create a loader
    loader = AnsibleLoader(constructor)

    # Create a vault encrypted string
    vault_encrypted_string = vault.encrypt('test')

    # Load the vault encrypted string
    vault_encrypted_string_loaded = loader.load(vault_encrypted_string)

    # Check that the vault encrypted string loaded is an AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:35:26.263804
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:35:36.998275
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['secret']
    vault_password_file = None
    vault_identity_list = None
    vault_identity_only = False
    vault_version = 1
    vault_prompt = False
    vault_filename = None
    vault_encoding = 'utf-8'
    vault_errors = 'strict'
    vault_keep_newline = False

# Generated at 2022-06-17 06:35:48.134174
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test case 1:
    #   - dict with duplicate keys
    #   - DUPLICATE_YAML_DICT_KEY = 'warn'
    #   - expect: warning message
    #   - expect: last defined value only
    #   - expect: AnsibleMapping
    test_case_1 = """
    ---
    foo: bar
    foo: baz
    """
    old_duplicate_yaml_dict_key = C.DUPLICATE_YAML_DICT_KEY
    C.DUPLICATE_YAML_D

# Generated at 2022-06-17 06:35:55.783817
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-17 06:36:05.428275
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a duplicate key
    test_data = """
    foo: bar
    foo: baz
    """
    loader = AnsibleLoader(yaml.load(test_data, Loader=AnsibleConstructor), vault_secrets=[])
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test with a duplicate key and C.DUPLICATE_YAML_DICT_KEY = 'error'
    C.DUPLICATE_YAM

# Generated at 2022-06-17 06:36:15.402474
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secrets = ['secret1', 'secret2']
    vault_password_file = 'test/unit/parsing/vault/test_vault.txt'
    vault_password_files = [vault_password_file]
    vault = VaultLib(vault_password_files=vault_password_files)
    vault_data = vault.encrypt('test')
    # Test the constructor

# Generated at 2022-06-17 06:36:20.502367
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test for AnsibleConstructor.construct_yaml_seq
    #
    # Test for AnsibleConstructor.construct_yaml_seq with a simple sequence
    #
    # Test for AnsibleConstructor.construct_yaml_seq with a simple sequence
    #
    # Test for AnsibleConstructor.construct_y

# Generated at 2022-06-17 06:36:38.144822
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys
    if sys.version_info < (3, 0):
        from io import BytesIO as StringIO
    yaml_str = '''
        a: 1
        b: 2
        c: 3
    '''
    yaml_str_duplicate_key = '''
        a: 1
        b: 2
        c: 3
        a: 4
    '''

# Generated at 2022-06-17 06:36:44.588319
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = """
    foo: bar
    baz:
      - one
      - two
    """

    loader = AnsibleLoader(StringIO(data), file_name='<string>')
    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'] == ['one', 'two']

    dumper = AnsibleDumper()
    output = dumper.dump(data)

    assert output == data

# Generated at 2022-06-17 06:36:54.222418
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var

    # Test that the method construct_yaml_unsafe of class AnsibleConstructor
    # returns an AnsibleUnsafeText object when the input is a string
    # and that the object has the attribute ansible_pos
    #
    # The input is a string
    #
    # The expected result is an AnsibleUnsafeText object with the attribute
    # ansible_pos
    #
    # The test is successful if the result is an AnsibleUnsafeText object
   

# Generated at 2022-06-17 06:37:01.919574
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner

    class FakeNode(object):
        def __init__(self, value):
            self.value = value
            self.start_mark = None

    class FakeConstructor(object):
        def construct_object(self, node, deep=False):
            return node.value

    class FakeLoader(object):
        def __init__(self, node):
            self.composer = Composer(node, FakeConstructor())

        def get_single_node(self):
            return self.composer.get_single_node()


# Generated at 2022-06-17 06:37:08.836625
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = """
    - foo
    - bar
    """
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert loader.get_single_data() == ['foo', 'bar']



# Generated at 2022-06-17 06:37:17.056758
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = 'test'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == 'test'
    assert AnsibleDumper(default_flow_style=False).dump(node) == "test\n...\n"

    # Test with a unicode string
    data = u'test'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()

# Generated at 2022-06-17 06:37:28.410088
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_password = 'secret'
    vault_secrets = [vault_password]

# Generated at 2022-06-17 06:37:38.915606
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test that a string is returned as an AnsibleUnsafeText object
    yaml_str = '!unsafe "test string"'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'test string'

    # Test that a list is returned as an AnsibleUnsafeText object
    yaml_str = '!unsafe [1, 2, 3]'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:37:45.928249
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = '''
        key1: value1
        key2: value2
        key3: value3
    '''
    yaml_obj = AnsibleConstructor().construct_yaml_map(yaml.compose(yaml_str))
    assert yaml_obj['key1'] == 'value1'
    assert yaml_obj['key2'] == 'value2'
    assert yaml_obj['key3'] == 'value3'


# Generated at 2022-06-17 06:37:57.500996
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    yaml_str = '!unsafe "hello world"'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'hello world'
    assert AnsibleDumper().dump(data) == yaml_str

    # Test with a number
    yaml_str = '!unsafe 42'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 42
   

# Generated at 2022-06-17 06:38:15.652052
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import yaml


# Generated at 2022-06-17 06:38:27.644503
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secret = VaultLib(secrets=['secret'])

# Generated at 2022-06-17 06:38:40.170742
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-17 06:38:50.554309
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a sequence of strings
    data = """
    - one
    - two
    - three
    """
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == ['one', 'two', 'three']
    assert yaml.dump(yaml_obj, Dumper=AnsibleDumper) == data

    # Test with a sequence of mappings

# Generated at 2022-06-17 06:38:59.388906
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:39:09.500521
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a simple dict
    yaml_str = '''
    foo: bar
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'bar'}

    # Test with a dict containing a vault encrypted string
    vault_sec

# Generated at 2022-06-17 06:39:17.735868
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    yaml_str = """
    foo:
      bar: 1
      baz: 2
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': {'bar': 1, 'baz': 2}}

    yaml_str = yaml.dump(data, Dumper=AnsibleDumper)
    assert yaml_str == """\
foo:
  bar: 1
  baz: 2
"""

# Generated at 2022-06-17 06:39:22.234474
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    test_data = {'a': 1, 'b': 2, 'c': 3}
    test_yaml = '''
a: 1
b: 2
c: 3
'''
    test_yaml_duplicate_key = '''
a: 1
b: 2
c: 3
a: 4
'''

    # test_yaml_duplicate_key should be ignored
    test_data_duplicate_key = {'a': 1, 'b': 2, 'c': 3}

    # test_yaml_duplicate_key should be ignored
    test

# Generated at 2022-06-17 06:39:32.362685
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the method construct_yaml_str of class AnsibleConstructor
    # returns a AnsibleUnicode object.
    yaml_str = 'foo'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnicode)

    # Test that the method construct_yaml_str of class AnsibleConstructor
    # returns a AnsibleUnicode object with the correct value.
    yaml_str = 'foo'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert data

# Generated at 2022-06-17 06:39:44.124670
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeTextProxy
    import yaml

    # Test that a string is wrapped in an AnsibleUnsafeTextProxy
    data = u'!unsafe "hello world"'
    loader = AnsibleLoader(data, file_name='<string>')
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleUnsafeTextProxy)
    assert obj == u'hello world'
    assert obj.ansible_pos == ('<string>', 1, 1)

    # Test that a string is wrapped in an AnsibleUn

# Generated at 2022-06-17 06:40:03.182159
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # test for duplicate dict keys
    data = """
    foo: bar
    foo: baz
    """
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleMapping)

    # test for duplicate dict keys with deep=True
    data = """
    foo:
      - bar
      - baz
    """
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleMapping)

    # test for duplicate dict keys with deep=True

# Generated at 2022-06-17 06:40:12.141993
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var

    # test with a list
    yaml_str = '''
    - 1
    - 2
    - 3
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleSequence)
    assert data == [1, 2, 3]

    # test with a list of dicts

# Generated at 2022-06-17 06:40:26.574449
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdin
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretRepository
    from ansible.parsing.vault import VaultSecretRepositoryPrompt
    from ansible.parsing.vault import VaultSecretRepositoryFile
    from ansible.parsing.vault import VaultSecretRepositoryStdin
    from ansible.parsing.vault import VaultSecretRepositoryPrompt

# Generated at 2022-06-17 06:40:38.437632
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    class TestAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            return AnsibleUnicode('test')

    class TestAnsibleDumper(AnsibleDumper):
        pass

    class TestAnsibleRepresenter(AnsibleRepresenter):
        pass

    TestAnsibleDumper.add_representer(AnsibleUnicode, TestAnsibleRepresenter.represent_unicode)


# Generated at 2022-06-17 06:40:45.488446
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    import yaml

    # Test with a string
    test_string = "test string"
    test_string_bytes = to_bytes(test_string)
    vault_password = "vault_password"
    vault_secrets = [vault_password]

# Generated at 2022-06-17 06:40:50.493897
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    yaml_str = u'foo: bar'
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'



# Generated at 2022-06-17 06:41:00.483496
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = '''
        foo:
          - bar
          - baz
        bar:
          - baz
          - foo
        baz:
          - foo
          - bar
        '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], list)
    assert isinstance(data['bar'], list)
    assert isinstance(data['baz'], list)


# Generated at 2022-06-17 06:41:08.136855
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for issue #22894
    yaml_str = u'foo: bar\n'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data['foo'], AnsibleUnicode)

    # Test for issue #24051
    yaml_str = u'foo: bar\n'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert data['foo'] == u'bar'

    # Test for issue #24051

# Generated at 2022-06-17 06:41:15.465079
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # test construct_yaml_seq
    # test AnsibleSequence
    # test AnsibleLoader
    # test AnsibleDumper
    # test AnsibleUnicode
    # test AnsibleVaultEncryptedUnicode
    # test VaultLib

    # test construct_yaml_seq
    # test AnsibleSequence
    # test Ans

# Generated at 2022-06-17 06:41:26.690816
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple dict
    data = {'a': 1, 'b': 2, 'c': 3}
    yaml_str = AnsibleDumper(None, default_flow_style=False).dump(data)
    yaml_str = to_bytes(yaml_str)
    data2 = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data2, AnsibleMapping)

# Generated at 2022-06-17 06:41:46.168664
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    vault_secrets = [VaultSecret(VaultAES256CBC(VaultAES256()), b'foo')]
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    loader.vault_secrets = vault_secrets
    loader.vaults['default'] = VaultLib(secrets=vault_secrets)
    loader.v

# Generated at 2022-06-17 06:41:55.193530
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test for empty list
    data = AnsibleSequence()
    data.ansible_pos = ('test', 1, 1)
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_data == '[]\n'

    # Test for list with one element
    data = AnsibleSequence()
    data.append('test')
    data.ansible_pos = ('test', 1, 1)
   

# Generated at 2022-06-17 06:42:02.346859
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    data = """
    foo: bar
    baz:
      - one
      - two
    """

    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'] == ['one', 'two']

    # Test that duplicate keys are detected
    data = """
    foo: bar
    foo: baz
    """

    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()

    assert isinstance

# Generated at 2022-06-17 06:42:13.047343
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

# Generated at 2022-06-17 06:42:20.531310
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
        foo: bar
        baz:
            - one
            - two
        quux:
            - three
            - four
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 3
    assert data['foo'] == 'bar'
    assert data['baz'] == ['one', 'two']
    assert data['quux'] == ['three', 'four']

    # Test that we can dump the data back out to YAML


# Generated at 2022-06-17 06:42:29.646194
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    # Test 1:
    # Test that AnsibleConstructor.construct_yaml_map()
    # returns an AnsibleMapping object.
    test_data = '''
    key1: value1
    key2: value2
    '''
    loader = AnsibleLoader(test_data, vault_secrets=['secret'])
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)

    # Test 2:
    # Test that AnsibleConstructor.construct_yaml_map

# Generated at 2022-06-17 06:42:39.047944
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with empty dict
    data = {}
    yaml_str = AnsibleDumper().dump(data)
    yaml_str = yaml_str.replace('\n', '')
    assert yaml_str == '{}'
    data_loaded = AnsibleLoader(yaml_str).get_single_data()

# Generated at 2022-06-17 06:42:49.966752
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys

    # Create a string with a YAML mapping
    yaml_str = u'{foo: bar, baz: qux}'

    # Create a string buffer
    buf = StringIO()

    # Save the original stdout
    stdout = sys.stdout

    # Redirect stdout to the buffer
    sys.stdout = buf

    # Load the YAML string
    data = AnsibleLoader(yaml_str).get_single_data()

    # Dump the data to stdout
    AnsibleDumper().dump(data)



# Generated at 2022-06-17 06:43:01.004309
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    import sys
    import os
    import tempfile
    import subprocess
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary python file
    fd, tmppyfile = tempfile.mkstemp(dir=tmpdir, suffix='.py')
    os.close(fd)

    # Write the python file

# Generated at 2022-06-17 06:43:12.245450
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    vault_secrets = ['test']
    vault_password_file = 'test'
    vault_password = 'test'
    vault_identity = 'test'
    vault_identity_file = 'test'
    vault_identity_file_type = 'test'
    vault_identity_file_encoding = 'test'
    vault_identity_file_encoding_errors = 'test'
