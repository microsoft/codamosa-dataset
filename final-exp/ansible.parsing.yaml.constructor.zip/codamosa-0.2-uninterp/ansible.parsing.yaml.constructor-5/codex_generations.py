

# Generated at 2022-06-17 06:33:26.411441
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test for vault_secrets = None
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.vault_secrets is None
    try:
        ansible_constructor.construct_vault_encrypted_unicode(None)
        assert False
    except ConstructorError:
        assert True

    # Test for vault_secrets = []
    ansible_constructor = AnsibleConstructor(vault_secrets=[])
    assert ansible_constructor.vault_secrets == []
    try:
        ansible_constructor.construct_vault_encrypted_unicode(None)
        assert False
    except ConstructorError:
        assert True

    # Test for vault_secrets = ['password']

# Generated at 2022-06-17 06:33:38.213764
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['test']
    vault = VaultLib(secrets=vault_secrets)
    vault_text = vault.encrypt('test')
    vault_text_bytes = to_bytes(vault_text)
    vault_text_unicode = AnsibleVaultEncryptedUnicode(vault_text_bytes)


# Generated at 2022-06-17 06:33:48.575639
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_password = 'secret'
    vault_secrets = [ vault_password ]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    node = AnsibleVaultEncryptedUnicode(ciphertext)
    node.vault = vault
    node.ansible_pos = ('test', 1, 1)
    yaml = AnsibleDumper(None, default_flow_style=False).represent_

# Generated at 2022-06-17 06:34:00.709749
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple sequence
    data = '''
    - 1
    - 2
    - 3
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]

    # Test with a sequence of sequences
    data = '''
    -
      - 1
      - 2
      - 3
    -
      - 4
      - 5
      - 6
    '''
    yaml_obj

# Generated at 2022-06-17 06:34:07.122348
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = u'foo: bar'
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert isinstance(data['foo'], AnsibleUnicode)
    assert data['foo'] == u'bar'

# Generated at 2022-06-17 06:34:16.443313
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import yaml

    class MyConstructor(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            return self.construct_object(node)

    class MyDumper(yaml.SafeDumper):
        pass

    MyDumper.add_representer(
        yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
        lambda dumper, data: dumper.represent_dict(data.items()))

    MyDumper.add_representer(
        yaml.resolver.BaseResolver.DEFAULT_SEQUENCE_TAG,
        lambda dumper, data: dumper.represent_list(data))


# Generated at 2022-06-17 06:34:24.096675
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - 1
    - 2
    - 3
    """

    seq = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(seq, AnsibleSequence)
    assert seq == [1, 2, 3]



# Generated at 2022-06-17 06:34:29.961695
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3}
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str


# Generated at 2022-06-17 06:34:40.345878
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a string
    data = 'string'
    yaml_data = AnsibleDumper(None, None,
                              default_flow_style=False,
                              representer=AnsibleRepresenter).represent_data(data)


# Generated at 2022-06-17 06:34:50.991812
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['vault_secret']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:35:07.598931
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleSequence

# Generated at 2022-06-17 06:35:17.696389
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from sys import version_info

    if version_info[0] < 3:
        from io import BytesIO as StringIO

    # Test for duplicate keys
    yaml_str = u"""
    foo: bar
    foo: baz
    """
    yaml_str_dup_key = u"""
    foo: bar
    foo: baz
    """
    yaml_str_dup_key_warn = u"""
    foo: bar
    foo: baz
    """

# Generated at 2022-06-17 06:35:24.704156
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple mapping
    node = MappingNode(u'tag:yaml.org,2002:map', [], [], None, None)
    node.value = [
        (ScalarNode(u'tag:yaml.org,2002:str', u'key1', None, None),
         ScalarNode(u'tag:yaml.org,2002:str', u'value1', None, None)),
        (ScalarNode(u'tag:yaml.org,2002:str', u'key2', None, None),
         ScalarNode(u'tag:yaml.org,2002:str', u'value2', None, None))
    ]
    node.start_mark = Mark(u'', 0, 0, None, None, None)

# Generated at 2022-06-17 06:35:36.115923
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Create a vault object
    vault_secrets = ['vaultsecret1', 'vaultsecret2']
    vault = VaultLib(secrets=vault_secrets)

    # Create a test string

# Generated at 2022-06-17 06:35:47.826903
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    from ansible.parsing.vault import VaultLib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, "w") as f:
        f.write("vault_password")

    # Create a vault encrypted file in the temporary directory
    vault_file = os.path.join(tmpdir, "vault_file")

# Generated at 2022-06-17 06:35:55.564543
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import yaml

    # Test with a simple map
    test_data = '''
    key1: value1
    key2: value2
    '''
    test_data_expected = {'key1': 'value1', 'key2': 'value2'}
    test_data_expected_pos = ('<unicode string>', 1, 1)

# Generated at 2022-06-17 06:36:05.388093
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = """
    a: 1
    b: 2
    c: 3
    """

    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    mapping = loader.get_single_data()
    assert isinstance(mapping, AnsibleMapping)
    assert mapping == {'a': 1, 'b': 2, 'c': 3}

    stream = StringIO()
    dumper = AnsibleDumper(stream)
    dumper.represent_dict(mapping)
    assert stream.getvalue()

# Generated at 2022-06-17 06:36:15.371909
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp()
    os.close(fd)

    # Create a vault password file
    vault_password_file = temp_file_path + '.vault'
    with open(vault_password_file, 'w') as f:
        f.write('vault_password')

    # Create a vault encrypted file
    vault_encrypted_file = temp_file_path + '.yml'
    with open(vault_encrypted_file, 'w') as f:
        f.write('!vault |\n')
        f.write('          $ANSIBLE_VAULT;1.1;AES256\n')

# Generated at 2022-06-17 06:36:27.913484
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml


# Generated at 2022-06-17 06:36:37.682683
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test with a simple sequence
    data = '''
    - 1
    - 2
    - 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()
    assert isinstance(data, list)
    assert len(data) == 3
    assert data[0] == 1
    assert data[1] == 2

# Generated at 2022-06-17 06:36:53.472914
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml

    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_yaml = yaml.dump(test_dict, Dumper=AnsibleDumper)
    test_loader = AnsibleLoader(test_yaml, vault_secrets=[])
    test_loader.vaults['default'] = VaultLib(secrets=[])

# Generated at 2022-06-17 06:37:01.093629
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - 1
    - 2
    - 3
    """

    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]

# Generated at 2022-06-17 06:37:11.881736
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple sequence
    data = '''
- 1
- 2
- 3
'''
    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleSequence)
   

# Generated at 2022-06-17 06:37:26.390056
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that AnsibleConstructor.construct_yaml_unsafe returns an AnsibleUnsafeText object
    # when given a string
    data = '!unsafe "test"'
    loader = AnsibleLoader(data, None)
    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleUnsafeText)
    assert obj == 'test'

    # Test that AnsibleConstructor.construct_yaml_unsafe returns an AnsibleUnsafeText object
    # when given an integer
    data = '!unsafe 42'

# Generated at 2022-06-17 06:37:36.850682
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    if sys.version_info < (2, 7):
        # Python 2.6 doesn't have assertIsInstance
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        def test_construct_yaml_unsafe(self):
            yaml_str = u'!unsafe "{{ foo }}"'
            data = AnsibleLoader(yaml_str).get_single_data()
            self.assertIsInstance(data, AnsibleUnsafeText)
            self.assertEqual(data, u'{{ foo }}')

    unittest.main()

# Generated at 2022-06-17 06:37:47.357132
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test for empty sequence
    data = AnsibleSequence()
    data.ansible_pos = ('test', 1, 1)
    assert AnsibleDumper().represent_data(data) == '[]\n'

    # Test for sequence with one element

# Generated at 2022-06-17 06:37:58.543996
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple mapping
    test_data = '''
    a: 1
    b: 2
    c: 3
    '''
    test_data_expected = {'a': 1, 'b': 2, 'c': 3}
    test_data_expected_pos = ('<unicode string>', 1, 1)
    test_data_expected_pos_a = ('<unicode string>', 2, 3)


# Generated at 2022-06-17 06:38:04.739329
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml

    data = """
    - foo: bar
      baz:
        - one
        - two
    - foo: baz
      baz:
        - three
        - four
    """

    loader = AnsibleLoader(data, file_name='<string>')
    data = loader.get_single_data()

    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert isinstance(data[0]['baz'], list)
    assert isinstance(data[1], dict)
    assert isinstance(data[1]['baz'], list)


# Generated at 2022-06-17 06:38:15.037796
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write some data to the file
    with open(fname, 'w') as f:
        f.write('---\n')
        f.write('foo: !vault |\n')
        f.write('          $ANSIBLE_VAULT;1.1;AES256\n')

# Generated at 2022-06-17 06:38:27.401252
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)

    # Write some data to the file

# Generated at 2022-06-17 06:38:47.411594
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # Test with a string
    yaml_str = "!unsafe 'test'"
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'test'

    # Test with a number
    yaml_str = "!unsafe 123"
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert isinstance(data, int)
    assert data == 123

    # Test with a list
    yaml_str = "!unsafe [1, 2, 3]"

# Generated at 2022-06-17 06:38:58.227151
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-17 06:39:08.462371
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    yaml_data = '''
        foo: bar
        baz: qux
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'bar', 'baz': 'qux'}

    # Test with a dict containing a list
    yaml_data = '''
        foo: bar
        baz:
          - qux
          - quux
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'bar', 'baz': ['qux', 'quux']}

    # Test with a

# Generated at 2022-06-17 06:39:17.327712
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = 'string'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
    assert isinstance(node, AnsibleUnicode)
    assert node == 'string'
    assert AnsibleDumper(default_flow_style=False).dump(node) == 'string\n...\n'

    # Test with a unicode string
    data = u'unicode string'
    node = AnsibleLoader(data, yaml_constructor=AnsibleConstructor).get_single_data()
   

# Generated at 2022-06-17 06:39:29.057164
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    # Create a vault object
    vault_secrets = ['secret']
    vault = VaultLib(secrets=vault_secrets)

    # Create a vault encrypted string

# Generated at 2022-06-17 06:39:38.213821
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    d: 4
    e: 5
    '''

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 5
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3
    assert data['d'] == 4
    assert data['e'] == 5


# Generated at 2022-06-17 06:39:47.811435
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        def setUp(self):
            self.constructor = AnsibleConstructor()

        def test_construct_mapping_duplicate_key_warn(self):
            # Test that a warning is displayed when a duplicate key is found
            # and DUPLICATE_YAML_DICT_KEY is set to 'warn'
            C.DUPLICATE_YAML_DICT_KEY = 'warn'
            # Capture stdout
            stdout = sys.stdout
            sys.stdout = io.StringIO()

# Generated at 2022-06-17 06:39:56.255461
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
    foo: bar
    baz:
      - one
      - two
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'] == ['one', 'two']

# Generated at 2022-06-17 06:40:05.974972
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple dict
    data = {'key1': 'value1', 'key2': 'value2'}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    yaml_data = yaml_data.replace('\n', '')
    yaml_data = yaml_data.replace('\'', '')
    yaml_data = yaml_data.replace('"', '\'')
    yaml_data = yaml_data.replace('{', '{ ')
    yaml_data = y

# Generated at 2022-06-17 06:40:14.222560
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB

# Generated at 2022-06-17 06:40:44.169507
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault_lib = VaultLib(vault_secrets)
    plaintext = 'secret'
    ciphertext = vault_lib.encrypt(plaintext)
    yaml_data = '!vault |\n' + ciphertext
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_loader = AnsibleLoader(yaml_data, ansible_constructor)

# Generated at 2022-06-17 06:40:56.067095
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a valid vault encrypted string

# Generated at 2022-06-17 06:41:04.805224
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write some data to the file
    with open(path, 'w') as f:
        f.write("""
---
foo:
  bar: 1
  baz: 2
foo:
  bar: 3
  baz: 4
""")

    # Read the data from the file
    with open(path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleConstructor)

    # Remove the temporary directory

# Generated at 2022-06-17 06:41:13.358588
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import base64

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create the YAML

# Generated at 2022-06-17 06:41:26.110651
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foo', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'bar', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:41:36.438856
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml
    import os

    # Create a vault
    vault_password = 'test'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)

    # Create a string to encrypt
    string_to_encrypt = 'test'

    # Encrypt the string
    encrypted_string = vault.encrypt(string_to_encrypt)

    # Create a Y

# Generated at 2022-06-17 06:41:45.648134
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    data = {'key': 'value'}
    stream = StringIO()
    AnsibleDumper(stream, default_flow_style=False).dump(data)
    stream.seek(0)
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

# Generated at 2022-06-17 06:41:53.861074
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = u"foo: bar\n"
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'

    # Test that the data is preserved when dumped back to YAML
    assert yaml_str == AnsibleDumper(data, default_flow_style=False).get_single_data()

# Generated at 2022-06-17 06:42:05.515916
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create a vault secret
    vault_secret = VaultSecret('secret')

    # Create a vault object
    vault = VaultLib(secrets=[vault_secret])

    # Create a vault encrypted string
    vault_encrypted_string = vault.encrypt('test')

    # Create a yaml string
    yaml_string = '!vault |\n' + vault_encrypted_string

    # Create a AnsibleConstructor object
    ansible_constructor = AnsibleConstructor(vault_secrets=[vault_secret])

    # Create a AnsibleLoader object
    ansible_loader = AnsibleLoader(ansible_constructor)

# Generated at 2022-06-17 06:42:13.952170
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Test with a simple string
    node = 'test'
    ac = AnsibleConstructor()
    result = ac.construct_yaml_unsafe(node)
    assert result == 'test'

    # Test with a list
    node = ['test1', 'test2']
    ac = AnsibleConstructor()
    result = ac.construct_yaml_unsafe(node)
    assert result == ['test1', 'test2']

    # Test with a dict
    node = {'test1': 'test2'}
    ac = AnsibleConstructor()
    result = ac.construct_yaml_unsafe(node)
    assert result == {'test1': 'test2'}

# Generated at 2022-06-17 06:42:51.351068
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, fname = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write a YAML file with a vault encrypted string

# Generated at 2022-06-17 06:43:02.909311
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    vault_password_file = os.path.join(tmpdir, "vault_password_file")
    with open(vault_password_file, "w") as f:
        f.write("vaultpassword")

    # Create a vault encrypted file
    vault_file = os.path.join(tmpdir, "vault_file")

# Generated at 2022-06-17 06:43:14.330307
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['test_secret']
    vault = VaultLib(secrets=vault_secrets)
    ciphertext_data = vault.encrypt('test_data')
    ciphertext_data = to_bytes(ciphertext_data)
    ciphertext_data = to_native(ciphertext_data)
    ciphertext_data = u'!vault |\n          ' + ciphertext_data
    ciphertext_data = to_bytes(ciphertext_data)
    ciphertext_data = to_native(ciphertext_data)
    ciphertext_data = ciphertext