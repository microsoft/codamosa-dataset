

# Generated at 2022-06-17 06:33:27.851724
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys
    import yaml

    # Test for method construct_yaml_seq of class AnsibleConstructor
    #
    # Test for the case where the sequence is empty
    #
    # Expected result:
    #     An AnsibleSequence object with no elements
    #
    # Test for the case where the sequence has one element
    #
    # Expected result:
    #     An AnsibleSequence object with one element
    #
    # Test for the case where the sequence has multiple elements
    #
    # Expected result:
    #     An Ans

# Generated at 2022-06-17 06:33:39.466400
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test 1:
    # Test that AnsibleConstructor.construct_yaml_

# Generated at 2022-06-17 06:33:49.456468
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the AnsibleConstructor.construct_yaml_str method returns an AnsibleUnicode object
    # when given a string
    yaml_str = 'test'
    node = AnsibleLoader(yaml_str, vault_secrets=['secret']).get_single_data()
    assert isinstance(AnsibleConstructor(vault_secrets=['secret']).construct_yaml_str(node), AnsibleUnicode)

    # Test that the AnsibleConstructor.construct_yaml_str method returns

# Generated at 2022-06-17 06:34:00.854690
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for duplicate dict keys
    # Test for 'ignore'
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test for 'warn'
    yaml_str = '''
    foo: bar
    foo: baz
    '''

# Generated at 2022-06-17 06:34:11.741447
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with duplicate keys
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((u'key1', u'value1'))
    node.value.append((u'key2', u'value2'))
    node.value.append((u'key1', u'value3'))
    node.value.append((u'key3', u'value4'))
    node.value.append((u'key4', u'value5'))
    node.value.append((u'key1', u'value6'))
    node.value.append((u'key5', u'value7'))
    node.value.append((u'key1', u'value8'))
    node

# Generated at 2022-06-17 06:34:18.215068
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    data = '''
    ---
    - !unsafe "{{ foo }}"
    - !unsafe "{{ bar }}"
    '''

    loader = AnsibleLoader(data, file_name='<string>')
    assert isinstance(loader.get_single_data(), list)
    assert isinstance(loader.get_single_data()[0], AnsibleUnsafeText)
    assert isinstance(loader.get_single_data()[1], AnsibleUnsafeText)

# Generated at 2022-06-17 06:34:27.700409
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test with C.DUPLICATE_YAML_DICT_KEY = 'warn'
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    yaml_str = '''
    key1: value1
    key2: value2
    key1: value3
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['key1'] == 'value3'
    assert data['key2'] == 'value2'

    # Test with C.DUPLICATE_YAML_DICT

# Generated at 2022-06-17 06:34:39.379580
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test construct_yaml_map
    yaml_str = '''
    a: 1
    b: 2
    '''
    data = AnsibleLoader(yaml_str).get_single

# Generated at 2022-06-17 06:34:47.602204
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test the constructor
    yaml_str = u'foo: bar'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[u'foo'], AnsibleUnicode)

    # Test the dumper
    assert yaml_str == AnsibleDumper(data).get_data()

# Generated at 2022-06-17 06:34:58.642704
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault = VaultLib(vault_secrets)
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    ciphertext_yaml = '!vault |\n  ' + ciphertext
    ciphertext_yaml_bytes = to_bytes(ciphertext_yaml)

# Generated at 2022-06-17 06:35:14.687371
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test that we get an AnsibleMapping object back
    data = """
    foo: bar
    """
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)

    # Test that duplicate keys raise an error
    data = """
    foo: bar
    foo: baz
    """
    try:
        yaml.load(data, Loader=AnsibleConstructor)
    except ConstructorError as e:
        assert 'found a duplicate dict key' in to_native(e)
    else:
        assert False, "Expected a ConstructorError"

    # Test that duplicate keys raise a warning

# Generated at 2022-06-17 06:35:25.772246
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test with a simple dict
    data = {'a': 1, 'b': 2}
    yaml_data = yaml.dump(data, Dumper=AnsibleDumper)
    yaml_data = yaml_data.replace('\n', '')
    assert yaml_data == '{a: 1, b: 2}'
    yaml_data = yaml.load(yaml_data, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:35:36.712282
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import pytest
    import yaml

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Write some data to the temporary file
    with open(temp_path, 'w') as f:
        f.write("""
        foo:
          bar:
            baz: 1
        """)

    # Create a yaml object
    yaml_obj = yaml.load(open(temp_path, 'r'), Loader=AnsibleConstructor)

    # Assert that the yaml object is a dict
    assert isinstance(yaml_obj, dict)

    # Assert that the yaml object has the expected keys
    assert 'foo' in yaml_obj

    # Assert that the yaml object has the

# Generated at 2022-06-17 06:35:45.850101
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = '''
        - foo: bar
        - foo: baz
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)

    assert isinstance(data[0]['foo'], AnsibleUnicode)
    assert isinstance(data[1]['foo'], AnsibleUnicode)



# Generated at 2022-06-17 06:35:53.946927
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import yaml

    # Create a AnsibleConstructor object
    ac = AnsibleConstructor()

    # Create a yaml.nodes.MappingNode object
    yaml_node = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map', value=[])

    # Create a AnsibleMapping object
    ansible_mapping = ac.construct_yaml_map(yaml_node)

    # Create a AnsibleSequence object
    ansible_sequence = ac.construct_yaml_seq(yaml_node)

    # Create a yaml.nodes.SequenceNode object
    yaml_node = yaml.nodes.SequenceNode(tag=u'tag:yaml.org,2002:seq', value=[])

    # Create a AnsibleSequence

# Generated at 2022-06-17 06:36:03.891470
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': 'baz'}
    assert yaml.dump(data, Dumper=AnsibleDumper) == yaml_str

    # Test with duplicate dict keys
    yaml_str = '''
    foo: bar
    foo: baz
    '''


# Generated at 2022-06-17 06:36:11.368514
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    # Test with duplicate keys
    test_yaml = u"""
    foo: bar
    foo: baz
    """
    test_stream = StringIO(test_yaml)
    test_loader = AnsibleLoader(test_stream, file_name='<string>')
    test_data = test_loader.get_single_data()
    assert isinstance(test_data, AnsibleMapping)
    assert test_data == {u'foo': u'baz'}

    # Test with duplicate keys and C.DUPLICATE_YAML_DICT

# Generated at 2022-06-17 06:36:21.778217
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - one
    - two
    - three
    """

    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleSequence)
    assert yaml_data == ['one', 'two', 'three']

# Generated at 2022-06-17 06:36:31.760059
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with a string
    node = 'foo'
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_str(node), AnsibleUnicode)
    assert ac.construct_yaml_str(node) == 'foo'

    # Test with a number
    node = 1
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_str(node), AnsibleUnicode)
    assert ac.construct_yaml_str(node) == '1'

    # Test with a boolean
    node = True
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_str(node), AnsibleUnicode)
    assert ac.construct_yaml_str(node) == 'True'

    # Test with a list

# Generated at 2022-06-17 06:36:40.948838
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    # Test with a string
    test_string = '!unsafe "abc"'
    data = yaml.load(test_string, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleUnsafeText)
    assert data == 'abc'
    assert yaml.dump(data, Dumper=AnsibleDumper) == test_string

    # Test with a number
    test_string = '!unsafe 123'
    data = yaml.load(test_string, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:37:03.306345
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping
    # object with the correct data.
    yaml_data = '''
    foo: bar
    baz:
      - one
      - two
      - three
    '''
    data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert isinstance(data['baz'], list)

# Generated at 2022-06-17 06:37:13.580667
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    # Test for duplicate dict keys
    # Test for 'ignore'
    data = """
    foo: bar
    foo: baz
    """
    stream = io.StringIO(data)
    loader = AnsibleLoader(stream, file_name='<string>')
    loader.vault_secrets = []
    try:
        loader.get_single_data()
    except ConstructorError as e:
        assert False, 'Unexpected ConstructorError: %s' % e
    assert loader.data == {'foo': 'baz'}

    # Test

# Generated at 2022-06-17 06:37:27.077242
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    d: 4
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    yaml_str = '''
    a: 1
    b: 2
    c: 3
    d: 4
    a: 5
    '''

    data = yaml

# Generated at 2022-06-17 06:37:37.715891
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test with a simple string
    test_string = 'test string'
    test_string_yaml = yaml.dump(test_string)
    test_string_yaml_loaded = yaml.load(test_string_yaml, Loader=AnsibleConstructor)
    assert isinstance(test_string_yaml_loaded, AnsibleUnicode)
    assert test_string_yaml_loaded == test_string

    # Test with a unicode string
    test_string = u'\u00e9'
    test_string_yaml = yaml.dump(test_string)

# Generated at 2022-06-17 06:37:48.668761
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple mapping
    data = '''
    a: 1
    b: 2
    c: 3
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    mapping = loader.get_single_data()
    assert isinstance(mapping, AnsibleMapping)
    assert mapping == {'a': 1, 'b': 2, 'c': 3}

    # Test with a duplicate key
    data = '''
    a: 1
    b: 2
    c: 3
    a: 4
    '''
    loader = AnsibleLoader

# Generated at 2022-06-17 06:37:59.572384
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a simple list
    data = [1, 2, 3]
    yaml_str = AnsibleDumper().dump(data)
    data2 = AnsibleLoader(yaml_str).get_single_data()
    assert data == data2

    # Test with a list of strings
    data = [u'a', u'b', u'c']
    yaml_str = AnsibleDumper().dump(data)
    data2 = AnsibleLoader(yaml_str).get_single_data()
    assert data == data2

    # Test with a list of unicode strings

# Generated at 2022-06-17 06:38:05.240020
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'foo': 'bar', 'baz': 'qux'}
    yaml_data = AnsibleDumper().dump(data)
    yaml_data = yaml_data.replace('bar', '!unsafe bar')
    yaml_data = yaml_data.replace('qux', '!unsafe qux')
    yaml_data = yaml_data.replace('\'bar\'', '\'!unsafe bar\'')
    yaml_data = yaml_data.replace('\'qux\'', '\'!unsafe qux\'')
    yaml

# Generated at 2022-06-17 06:38:15.387205
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'key1', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'value1', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:38:27.551165
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    - a
    - b
    - c
    '''

    data_obj = AnsibleSequence(['a', 'b', 'c'])
    data_obj.ansible_pos = ('<string>', 1, 0)

    loader = AnsibleLoader(data, file_name='<string>')
    data_obj_loaded = loader.get_single_data()

    assert data_obj == data_obj_loaded

    dumper = AnsibleDumper()
    data_dumped = dumper.represent_data(data_obj)

    assert data == data

# Generated at 2022-06-17 06:38:40.083900
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test that AnsibleConstructor.construct_yaml_map returns an AnsibleMapping
    # object and that it has the correct ansible_pos attribute
    yaml_data = """
    foo: bar
    """
    data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos == ('<unicode string>', 1, 1)

    # Test that AnsibleConstructor.construct_yaml_map returns an Ans

# Generated at 2022-06-17 06:39:13.044070
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:39:27.227968
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with duplicate dict keys
    yaml_str = '''
---
a: 1
b: 2
a: 3
'''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 2
    assert data['a'] == 3
    assert data['b'] == 2

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY = 'warn'
    C.DUPLICATE_YAML_D

# Generated at 2022-06-17 06:39:36.556418
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    # Test for duplicate dict key
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test for duplicate dict key with different values
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = AnsibleLoader

# Generated at 2022-06-17 06:39:46.728756
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    a: 1
    b: 2
    c: 3
    """

    loader = AnsibleLoader(data, file_name='<string>')
    ansible_mapping = loader.get_single_data()

    assert isinstance(ansible_mapping, AnsibleMapping)
    assert ansible_mapping['a'] == 1
    assert ansible_mapping['b'] == 2
    assert ansible_mapping['c'] == 3

    data = """
    a: 1
    b: 2
    c: 3
    a: 4
    """

    loader = AnsibleLoader(data, file_name='<string>')
    ansible

# Generated at 2022-06-17 06:39:59.066008
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.display import Display
    from ansible.parsing.yaml.dumper import AnsibleD

# Generated at 2022-06-17 06:40:08.574366
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    vault_file = os.path.join(tmpdir, "vault.yml")
    with open(vault_file, "w") as f:
        f.write("""
---
vault_password_file: vault.txt
""")

    # Create a file in the temporary directory
    vault_password_file = os.path.join(tmpdir, "vault.txt")
    with open(vault_password_file, "w") as f:
        f.write("""
vault_password
""")

    # Create a file in the temporary directory

# Generated at 2022-06-17 06:40:14.221721
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - 1
    - 2
    - 3
    """

    obj = AnsibleLoader(data).get_single_data()
    assert isinstance(obj, AnsibleSequence)
    assert obj == [1, 2, 3]

    assert data == AnsibleDumper(default_flow_style=False).dump(obj)

# Generated at 2022-06-17 06:40:27.478612
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-17 06:40:39.513741
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    # test for construct_yaml_unsafe
    # test for construct_yaml_unsafe
    # test for construct_yaml_unsafe
    # test for construct_yaml_unsafe
    # test for construct_yaml_unsafe
    # test for construct_yaml_unsafe
   

# Generated at 2022-06-17 06:40:48.725843
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
        foo:
            bar: 1
            baz: 2
        """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'foo': {'bar': 1, 'baz': 2}}

# Generated at 2022-06-17 06:41:37.351903
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import yaml
    yaml_str = u"foo: bar\n"
    yaml_str_io = StringIO(yaml_str)
    data = yaml.load(yaml_str_io, Loader=AnsibleLoader)
    assert isinstance(data[u'foo'], AnsibleUnicode)
    assert data[u'foo'] == u'bar'
    yaml_str_io = StringIO()

# Generated at 2022-06-17 06:41:48.756812
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-17 06:41:59.128182
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    # test with a simple string
    data = """
    - foo
    - bar
    """
    loader = AnsibleLoader(data, None)
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert len(loader.get_single_data()) == 2
    assert isinstance(loader.get_single_data()[0], AnsibleUnicode)
    assert isinstance(loader.get_single_data()[1], AnsibleUnicode)
    assert loader.get_single_data()[0] == 'foo'

# Generated at 2022-06-17 06:42:10.655281
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml_seq
    # Test for AnsibleConstructor.construct_yaml

# Generated at 2022-06-17 06:42:18.497550
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    a: 1
    b: 2
    c: 3
    '''

    data_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(data_obj, AnsibleMapping)
    assert data_obj['a'] == 1
    assert data_obj['b'] == 2
    assert data_obj['c'] == 3

    data_str = AnsibleDumper().dump(data_obj)
    assert data_str == data

# Generated at 2022-06-17 06:42:27.928183
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - foo
    - bar
    """

    loader = AnsibleLoader(data, file_name='<string>')
    obj = loader.get_single_data()

    assert isinstance(obj, AnsibleSequence)
    assert len(obj) == 2

    dumper = AnsibleDumper()
    data = dumper.dump(obj)

    assert data == '- foo\n- bar\n'

# Generated at 2022-06-17 06:42:37.636822
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from yaml.nodes import MappingNode
    from yaml.constructor import ConstructorError
    from ansible.module_utils._text import to_bytes
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for construct_mapping method of class AnsibleConstructor
    # Test for construct_mapping method of class AnsibleConstructor
    # Test for construct_mapping method of class AnsibleConstructor
    # Test for construct_mapping method of class AnsibleConstructor
    # Test for construct_mapping method of class AnsibleConstructor
    # Test for construct_mapping method of class AnsibleConstructor
    # Test for construct_mapping method of class AnsibleConstructor
    # Test for construct_mapping method of class Ansible

# Generated at 2022-06-17 06:42:49.328340
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdout
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretPromptStdin
    from ansible.parsing.vault import VaultSecretPromptStdinStdout
    from ansible.parsing.vault import VaultSecretPromptStdinStdoutFile
    from ansible.parsing.vault import VaultSecretPromptStdinFile
    from ansible.parsing.vault import VaultSecretPrompt

# Generated at 2022-06-17 06:43:00.932023
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test for duplicate dict keys
    test_data = '''
    foo:
      bar: baz
      bar: baz2
    '''
    test_data_result = AnsibleMapping()
    test_data_result['foo'] = AnsibleMapping()
    test_data_result['foo']['bar'] = AnsibleUnicode('baz2')
    test_data_result['foo'].ansible

# Generated at 2022-06-17 06:43:12.167354
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple dict
    data = {'a': 1, 'b': 2}
    yaml_data = AnsibleDumper().dump(data)
    loader = AnsibleLoader(yaml_data)