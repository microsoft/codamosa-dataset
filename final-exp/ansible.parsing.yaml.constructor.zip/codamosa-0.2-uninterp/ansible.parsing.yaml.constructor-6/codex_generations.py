

# Generated at 2022-06-17 06:33:29.318607
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    vault_secrets = ['vault_secret']
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)

    # Test construct_yaml_seq
    data = loader.get_single_data("""
    - 1
    - 2
    - 3
    """)
    assert isinstance(data, list)
    assert len(data) == 3
    assert data[0] == 1
    assert data[1] == 2
    assert data[2] == 3

    # Test construct_yaml

# Generated at 2022-06-17 06:33:41.135519
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a duplicate key
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'baz'

    # Test with a duplicate key and a warning
    yaml_str = '''
    foo: bar
    foo: baz
    '''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-17 06:33:50.480241
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import sys

    # Create a dict with a unicode string
    data = dict(a=u'foo')

    # Dump the dict to a yaml string
    yaml_str = AnsibleDumper().dump(data)

    # Load the yaml string to a AnsibleMapping
    data2 = AnsibleLoader(yaml_str).get

# Generated at 2022-06-17 06:34:00.923903
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
    a: 1
    b: 2
    c: 3
    d: 4
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    yaml_str = """
    a: 1
    b: 2
    c: 3
    d: 4
    a: 5
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:34:07.768303
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    - 1
    - 2
    - 3
    """
    yaml_obj = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2, 3]

# Generated at 2022-06-17 06:34:16.878498
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Test with a mapping
    data = '''
    a: 1
    b: 2
    c: 3
    '''
    data_mapping = AnsibleMapping()
    data_mapping['a'] = AnsibleUnicode('1')
    data_mapping['b'] = AnsibleUnicode('2')
    data_mapping['c'] = AnsibleUnicode('3')
    data_mapping

# Generated at 2022-06-17 06:34:27.156498
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import yaml

    # Test for AnsibleConstructor.construct_yaml_seq
    #
    # Ansible

# Generated at 2022-06-17 06:34:39.254963
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'a': 'b', 'c': 'd'}
    data_str = AnsibleDumper(None, default_flow_style=False).dump(data)
    data_str = data_str.replace('b', '!unsafe b')
    data_str = data_str.replace('d', '!unsafe d')
    data_str = data_str.replace('\n', '')
    data_str = data_str.replace(' ', '')
    data_str = data_str.replace(':', ': ')
    data_str = data_str

# Generated at 2022-06-17 06:34:50.053181
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # create a vault secret
    vault_secret = VaultSecret(password='password')

    # create a vault
    vault = VaultLib(secrets=[vault_secret])

    # create a vault encrypted string
    vault_encrypted_string = vault.encrypt('test')

    # create a vault encrypted string node

# Generated at 2022-06-17 06:35:00.124321
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - 1
    - 2
    - 3
    """

    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get_single_data()
    assert isinstance(seq, AnsibleSequence)
    assert seq == [1, 2, 3]

    dumper = AnsibleDumper()
    dumped_data = dumper.dump(seq)
    assert data == dumped_data



# Generated at 2022-06-17 06:35:11.570691
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = '''
- 1
- 2
- 3
'''
    yaml_data = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(yaml_data, AnsibleSequence)
    assert yaml_data == [1, 2, 3]



# Generated at 2022-06-17 06:35:23.366686
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = [1, 2, 3]
    yaml = AnsibleDumper().dump(data)
    assert isinstance(yaml, AnsibleUnicode)

    data2 = AnsibleLoader(yaml).get_single_data()
    assert isinstance(data2, AnsibleSequence)
    assert data == data2



# Generated at 2022-06-17 06:35:35.385800
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import os
    import tempfile
    import shutil
    import sys
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Create the YAML

# Generated at 2022-06-17 06:35:45.093128
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = '''
    foo:
      bar:
        baz: 1
    foo:
      bar:
        baz: 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar']['baz'] == 2

# Generated at 2022-06-17 06:35:52.594330
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-17 06:35:58.534375
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    - foo
    - bar
    '''
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleSequence)
    assert yaml_data == ['foo', 'bar']


# Generated at 2022-06-17 06:36:07.580829
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test case 1:
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #   - key: value
    #

# Generated at 2022-06-17 06:36:16.694735
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    yaml_str = u'''
- foo
- bar
'''
    yaml_str_unicode = u'''
- foo
- bar
'''

    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert isinstance(data[0], AnsibleUnicode)
    assert isinstance(data[1], AnsibleUnicode)

    data = AnsibleLoader(yaml_str_unicode, file_name='<string>').get_single_data()
    assert isinstance

# Generated at 2022-06-17 06:36:28.603531
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test construct_yaml_seq
    data = '''
        - 1
        - 2
        - 3
        - 4
        - 5
        - 6
        - 7
        - 8
        - 9
        - 10
    '''
    loader = AnsibleLoader(data, file_name='<string>')
   

# Generated at 2022-06-17 06:36:33.574300
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    # Test with a string that contains a unicode character
    test_str = u'\u00e9'
    if PY3:
        test_str = test_str.encode('utf-8')
    test_str = to_bytes(test_str)
    data = AnsibleLoader(test_str).get_single_data()
    assert isinstance(data, AnsibleUnicode)
    assert to_text(test_str) == data

    # Test with a string that contains a unicode character
    test_str

# Generated at 2022-06-17 06:36:51.535527
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for duplicate dict keys
    test_yaml = '''
    foo:
      bar:
        baz: 1
      bar:
        baz: 2
    '''
    data = yaml.load(test_yaml, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo']['bar']['baz'] == 2

    # Test for duplicate dict keys with different values
    test_yaml = '''
    foo:
      bar:
        baz: 1
      bar:
        baz: 2
      bar:
        baz: 3
    '''
   

# Generated at 2022-06-17 06:37:03.981014
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-17 06:37:14.105500
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with a simple dict
    data = {'a': 1, 'b': 2}
    yaml_str = AnsibleDumper().dump(data)

# Generated at 2022-06-17 06:37:27.325006
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test that the constructor returns an AnsibleUnsafeText object
    # when the tag is !unsafe
    yaml_str = u'!unsafe "unsafe string"'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleUnsafeText)
    assert data == u'unsafe string'

    # Test that the constructor returns an AnsibleUnsafeText object
    # when the tag is !unsafe
    yaml_str = u'!unsafe "unsafe string"'
    data = AnsibleLoader(yaml_str).get

# Generated at 2022-06-17 06:37:38.011823
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

# Generated at 2022-06-17 06:37:49.124767
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = '!unsafe "hello"'
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert yaml_obj == 'hello'
    assert AnsibleDumper().dump(yaml_obj) == data

    # Test with a list
    data = '!unsafe [1, 2, 3]'
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert isinstance(yaml_obj, list)
    assert yaml_

# Generated at 2022-06-17 06:37:57.867099
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with a mapping node
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    mapping = AnsibleConstructor().construct_mapping(node)
    assert isinstance(mapping, AnsibleMapping)

    # Test with a non-mapping node
    node = MappingNode(tag=u'tag:yaml.org,2002:str', value=[])
    try:
        AnsibleConstructor().construct_mapping(node)
    except ConstructorError:
        pass
    else:
        assert False, "construct_mapping did not raise ConstructorError"

# Generated at 2022-06-17 06:38:04.404813
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from io import StringIO

    data = '''
    foo: bar
    baz:
      - 1
      - 2
      - 3
    '''

    stream = StringIO(data)
    loader = AnsibleLoader(stream, 'test_AnsibleConstructor_construct_yaml_str')
    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleUnicode)

# Generated at 2022-06-17 06:38:13.223454
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    yaml_str = """
    foo: bar
    baz:
      - one
      - two
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)
    assert data['foo'] == 'bar'
    assert data['baz'][0] == 'one'
    assert data['baz'][1] == 'two'



# Generated at 2022-06-17 06:38:26.925886
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types

# Generated at 2022-06-17 06:38:42.101458
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with duplicate dict keys
    yaml_data = """
    foo: bar
    foo: baz
    """
    yaml_obj = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert yaml_obj == {'foo': 'baz'}

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT_KEY == 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'
    yaml_data = """
    foo: bar
    foo: baz
    """
    with pytest.raises(ConstructorError):
        yaml.load(yaml_data, Loader=AnsibleConstructor)

    # Test with duplicate dict keys and C.DUPLICATE_YAML_DICT

# Generated at 2022-06-17 06:38:47.558501
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    yaml_str = "foo: bar\n"
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert data['foo'] == u'bar'

# Generated at 2022-06-17 06:38:58.312395
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml

    # Test with a simple mapping
    data = """
    foo: bar
    """
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data['foo'] == 'bar'

    # Test with a mapping that has a duplicate key
    data = """
    foo: bar
    foo: baz
    """
    yaml_data = yaml.load(data, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:39:05.652726
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    foo:
      bar:
        baz: qux
    '''
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(yaml_data, AnsibleMapping)
    assert yaml_data['foo']['bar']['baz'] == 'qux'

# Generated at 2022-06-17 06:39:13.309222
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

# Generated at 2022-06-17 06:39:27.379691
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdin
    from ansible.parsing.vault import VaultSecretFile
    from ansible.parsing.vault import VaultSecretPrompt
    from ansible.parsing.vault import VaultSecretAWS
    from ansible.parsing.vault import VaultSecretGPG
    from ansible.parsing.vault import VaultSecretKMS
    from ansible.parsing.vault import VaultSecretAzureKeyVault
    from ansible.parsing.vault import VaultSecretHashivault

# Generated at 2022-06-17 06:39:36.705087
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test that the !unsafe tag works
    yaml_str = u'!unsafe "{{ foo }}"'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleUnsafeText)
    assert data == u'{{ foo }}'

    # test that the !unsafe tag works with a dict
    yaml_str = u'foo: !unsafe "{{ foo }}"'
    data = yaml.load(yaml_str, Loader=AnsibleLoader)

# Generated at 2022-06-17 06:39:46.769067
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:39:58.652204
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = '''
    foo:
      bar:
        baz:
          - 1
          - 2
          - 3
    '''

    loader = AnsibleLoader(data, file_name='<string>')
    dumper = AnsibleDumper()

    obj = loader.get_single_data()
    assert isinstance(obj, AnsibleMapping)
    assert obj['foo']['bar']['baz'] == [1, 2, 3]

    data2 = dumper.dump(obj)
    assert data == data2

# Generated at 2022-06-17 06:40:08.215948
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a valid vault-encrypted string
    vault_secrets = ['secret']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-17 06:40:20.298215
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'key1', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'value1', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:40:29.275945
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple map
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    node.value.append((ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foo', start_mark=None, end_mark=None),
                       ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'bar', start_mark=None, end_mark=None)))

# Generated at 2022-06-17 06:40:40.597917
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    test_str = u'foo'
    test_str_bytes = b'foo'
    test_str_unicode = u'foo'

    # Test that a byte string is converted to unicode
    test_str_bytes_node = AnsibleLoader(test_str_bytes).get_single_data()
    assert isinstance(AnsibleConstructor().construct_yaml_str(test_str_bytes_node), AnsibleUnicode)

    # Test that a unicode string is converted to unicode

# Generated at 2022-06-17 06:40:53.312501
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # test for construct_yaml_seq
    yaml_data = '''
    - one
    - two
    - three
    '''

# Generated at 2022-06-17 06:41:00.634660
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Write data to the temporary file
    with open(tmpfile, 'w') as f:
        f.write("""
        foo: bar
        baz: qux
        foo: quux
        """)

    # Read the file with AnsibleConstructor
    with open(tmpfile) as f:
        data = yaml.load(f, Loader=AnsibleConstructor)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Test the data
    assert data

# Generated at 2022-06-17 06:41:08.267335
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test with a string
    data = '!unsafe "foo"'
    expected = AnsibleUnsafeText('foo')
    actual = yaml.load(data, Loader=AnsibleLoader)
    assert expected == actual

    # Test with a list
    data = '!unsafe [1, 2, 3]'
    expected = [1, 2, 3]
    actual = yaml.load(data, Loader=AnsibleLoader)
    assert expected == actual

    # Test with a dict
    data = '!unsafe {foo: bar}'
    expected

# Generated at 2022-06-17 06:41:15.549955
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES

# Generated at 2022-06-17 06:41:26.745467
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test 1:
    # Test the construct_yaml_seq method of class AnsibleConstructor
    # with a sequence of strings
    data = '''
    - foo
    - bar
    - baz
    '''
    loader = AnsibleLoader(data, file_name='<string>')
    seq = loader.get

# Generated at 2022-06-17 06:41:36.718579
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    yaml_data = '''
        a: 1
        b: 2
        c: 3
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data == {'a': 1, 'b': 2, 'c': 3}

    # Test with a dict with duplicate keys
    yaml_data = '''
        a: 1
        b: 2
        c: 3
        a: 4
    '''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data == {'a': 4, 'b': 2, 'c': 3}

    # Test with a dict with duplicate keys and a warning

# Generated at 2022-06-17 06:41:48.418735
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        def test_construct_yaml_unsafe(self):
            data = """
            foo: !unsafe |
                {
                    "bar": "baz"
                }
            """
            loader = AnsibleLoader(data, None, vault_secrets=['test'])
            data = loader.get_single_data()
            self.assertIsInstance

# Generated at 2022-06-17 06:42:11.992472
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    - 1
    - 2
    - 3
    """
    data_loaded = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(data_loaded, AnsibleSequence)
    assert data_loaded == [1, 2, 3]
    data_dumped = yaml.dump(data_loaded, Dumper=AnsibleDumper)
    assert data_dumped == data

# Generated at 2022-06-17 06:42:25.578203
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test with a list of strings
    test_list = ['a', 'b', 'c']
    test_list_yaml = AnsibleDumper().encode(test_list)
    test_list_yaml_obj = AnsibleLoader(None, None).get_single_data(test_list_yaml)
    assert isinstance(test_list_yaml_obj, AnsibleSequence)
    assert test_list_yaml_obj == test_list

    # Test with a list of integers
    test_

# Generated at 2022-06-17 06:42:35.384913
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'secret'
    vault_secrets = [vault_password]
    vault = VaultLib(secrets=vault_secrets)
    plaintext = 'hello'
    ciphertext = vault.encrypt(plaintext)
    node = yaml.nodes.ScalarNode(tag='!vault', value=ciphertext)
    ac = AnsibleConstructor(vault_secrets=vault_secrets)
    result = ac.construct_vault_encrypted_unicode(node)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == vault
    assert result

# Generated at 2022-06-17 06:42:47.398991
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test with a simple list
    test_data = """
    - foo
    - bar
    """
    loader = AnsibleLoader(test_data, None)
    data = loader.get_single_data()
    assert isinstance(data, list)
    assert len(data) == 2
    assert data[0] == 'foo'
    assert data[1] == 'bar'

    # Test with a list of lists
    test_data = """
    - foo
    - bar
    -
      - baz
      - qux
    """

# Generated at 2022-06-17 06:42:53.082881
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    yaml_str = '''
        a: 1
        b: 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == {'a': 1, 'b': 2}
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test with a dict with duplicate keys
    yaml_str = '''
        a: 1
        b: 2
        a: 3
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == {'a': 3, 'b': 2}
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # Test with a dict with duplicate keys and

# Generated at 2022-06-17 06:43:03.291992
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
    a: 1
    b: 2
    c: 3
    d: 4
    """

    # Test with a duplicate key
    data_duplicate = """
    a: 1
    b: 2
    c: 3
    d: 4
    a: 5
    """

    # Test with a duplicate key and a different value
    data_duplicate_diff_value = """
    a: 1
    b: 2
    c: 3
    d: 4
    a: 5
    """

    # Test with a duplicate key and a different value

# Generated at 2022-06-17 06:43:14.634608
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes