

# Generated at 2022-06-20 23:40:33.121642
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader

    def compare_dict_key(result, expected_key, expected_value):
        assert(expected_key in result)
        assert(isinstance(result[expected_key], objects.AnsibleUnicode))
        assert(expected_value == result[expected_key].data)

    data = """
foo: bar
bar: baz
"""
    expected = {'foo': 'bar', 'bar': 'baz'}
    loader = AnsibleLoader(data, file_name="dummy", vault_secrets=[])
    result = loader.get_single_data()

    for key, value in expected.items():
        compare_dict_key(result, key, value)


# Generated at 2022-06-20 23:40:35.990696
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    import yaml
    y = """
        a:
           b: 1
        """

    data = yaml.load(y, Loader=AnsibleConstructor)
    assert data['a']['b'] == 1

# Generated at 2022-06-20 23:40:48.796233
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.vault import VaultLib
    import yaml
    import inspect
    import os

    plugin_loader = AnsibleLoader(None, file_name='/tmp/dummy')

    assert isinstance(plugin_loader.constructor.construct_yaml_seq(None), AnsibleSequence)

    # Test that we are using the right YAML version
    assert os.path.dirname(inspect.getfile(yaml)) in plugin_loader.constructor.yaml_impl.get_module_paths()

    # Test that the vault secrets are properly passed to the vault object
    secrets = ['foo', 'bar']
    plugin

# Generated at 2022-06-20 23:40:57.656377
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.parser import ParserError
    import os

    # Test AnsibleConstructor.construct_yaml_str
    safe_constructor = AnsibleConstructor()
    yaml_str = to_bytes("""
        ---
        - bar
        - foo
    """)
    try:
        yaml_data = safe_constructor.get_single_data(yaml_str)
    except ParserError as e:
        assert False, 'failed to parse: %s' % (e)
    assert isinstance(yaml_data, list)
    assert isinstance(yaml_data[0], AnsibleUnicode)

    # Test AnsibleConstructor.construct_yaml_str with an AnsibleSequence
    value = AnsibleSequence()

# Generated at 2022-06-20 23:41:09.759243
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    yaml_node = [
        ('tag:yaml.org,2002:str', 'str'),
        ('!unsafe', 'str'),
        ('tag:yaml.org,2002:str', 'str'),
        ('!yaml.org,2002:python/unicode', 'str'),
        ('tag:yaml.org,2002:str', 'str'),
    ]
    result = [
        u'str',
        wrap_var(u'str'),
        u'str',
        u'str',
        u'str'
    ]
    for ind, item in enumerate(yaml_node):
        ansible_constructor.construct_yaml_unsafe(item) == result[ind]

# Generated at 2022-06-20 23:41:17.744915
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    from yaml import load
    import io

    stream = io.StringIO("""
data:
  b:
    - 1
    - 2
  a: 3
  c: 4
""")
    data = load(stream, Loader=AnsibleConstructor)

    assert data['data']['a'] == 3
    assert data['data']['b'] == [ 1, 2 ]
    assert data['data']['c'] == 4

# Generated at 2022-06-20 23:41:30.699788
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import pytest
    import textwrap
    import yaml


# Generated at 2022-06-20 23:41:43.557722
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils.six import PY3

    yaml_data = '''
    ---
      - hosts: 127.0.0.1
        tasks:
        - raw: !unsafe '/bin/echo {{ ansible_hostname }}'
    '''

    yaml_obj = yaml.load(yaml_data, Loader=AnsibleConstructor)

    assert yaml_obj is not None
    assert yaml_obj[0]['tasks'][0]['raw'] is not None

    assert not isinstance(yaml_obj[0]['tasks'][0]['raw'], AnsibleUnicode)

    assert isinstance(yaml_obj[0]['tasks'][0]['raw'], AnsibleUnicode)

# Generated at 2022-06-20 23:41:55.377717
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Output: ''
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class test_class1(AnsibleBaseYAMLObject):
        yaml_loader = AnsibleConstructor

    yaml.load("[1,2,3]", Loader=yaml.CLoader)
    # Output: ''
    test_class1.yaml_loader.add_constructor(
        u'tag:yaml.org,2002:str',
        test_class1.yaml_loader.construct_yaml_str)
    # Output: ''
    yaml.load("[1,2,3]", Loader=yaml.CLoader)
    # Output: ''

# Generated at 2022-06-20 23:42:02.675283
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    construct_yaml_seq = AnsibleConstructor.construct_yaml_seq

    import yaml

    yaml_code = """
- item1
- item2
"""

    result = construct_yaml_seq(yaml.nodes.SequenceNode(
        yaml_code, None, None, True, None, None, None, None, None, None, None, None, None, None, None, None, None, True
    ))

    assert True == isinstance(result, list)
    result = list(result)[0]

    assert True == isinstance(result, AnsibleSequence)
    assert [u'item1', u'item2'] == result



# Generated at 2022-06-20 23:42:12.796420
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    construct_yaml_seq(node)
    AnsibleConstructor class method

    Return a new instance of AnsibleSequence.
    """
    a = AnsibleConstructor()

    assert isinstance(a.construct_yaml_seq(MappingNode()), AnsibleSequence)


# Generated at 2022-06-20 23:42:14.323635
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import tests
    tests.run_unittests(__file__)

# Generated at 2022-06-20 23:42:22.538589
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    file_name = 'test_file_name.yml'
    vault_secrets = ['a_secret']
    ac = AnsibleConstructor(file_name, vault_secrets)
    node = {'start_mark': 'a_start_mark',
            'id': 'a_id'}

    yaml_seq = ac.construct_yaml_seq(node)
    assert isinstance(yaml_seq, AnsibleSequence)
    assert yaml_seq.ansible_pos == ('test_file_name.yml', 1, 2)

# Generated at 2022-06-20 23:42:34.887866
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    '''
    Create an AnsibleConstructor and test whether it can handle the 'construct_yaml_unsafe' method of the class
    '''

    # Creating an AnsibleConstructor object
    ansible_constructor = AnsibleConstructor()

    # Creating a node as would be passed to construct_yaml_unsafe
    class node:
        id = 'object'

        def constructor(node, deep=False):
            return node

    # Creating an object that can be assigned to id of node object
    class object:
        pass
    node.id = object
    node.constructor = AnsibleConstructor.construct_object

    # Testing for construct_yaml_unsafe method of class AnsibleConstructor
    ansible_constructor.construct_yaml_unsafe(node)

# Generated at 2022-06-20 23:42:48.051714
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test encoding for Unicode.
    assert AnsibleConstructor.construct_yaml_str('u:\"test\"') == u"test"
    assert AnsibleConstructor.construct_yaml_str('u:\"\\\\xE0\"') == u"\xe0"
    assert AnsibleConstructor.construct_yaml_str('u:\"\\\\xE0\\\\xB4\\\\x81\"') == u"\xe0\xb4\x81"
    assert AnsibleConstructor.construct_yaml_str('u:\"\\\"\"') == u"\""
    assert AnsibleConstructor.construct_yaml_str('u:\"\\\\\"') == u"\\"

# Generated at 2022-06-20 23:42:56.831561
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # pylint: disable=unused-variable
    node = object()

    class ConcreteAnsibleConstructor(AnsibleConstructor):
        def construct_scalar(self, node2):
            assert node2 is node
            return 'foo bar'

    constructor = ConcreteAnsibleConstructor()
    value = constructor.construct_yaml_str(node)
    assert isinstance(value, AnsibleUnicode)
    assert str(value) == 'foo bar'



# Generated at 2022-06-20 23:43:07.310050
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.utils.unsafe_proxy import UnsafeProxy

    ac = AnsibleConstructor()

    class Node(object):
        id = 'object_with_proxy'

        def start_mark(self):
            return ''

    def construct_object_with_proxy(proxy_node):
        return UnsafeProxy(type(proxy_node), 'proxy')

    ac.construct_object_with_proxy = construct_object_with_proxy
    node = Node()

    ret = ac.construct_yaml_unsafe(node)
    assert type(ret) == UnsafeProxy
    assert ret.obj == Node
    assert ret.name == 'proxy'

# Generated at 2022-06-20 23:43:08.359088
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-20 23:43:16.373854
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.plugins.loader import module_loader
    from ansible.vars.unsafe_proxy import wrap_var
    import ansible.parsing.yaml.dumper
    import sys


# Generated at 2022-06-20 23:43:26.033652
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import io
    import ansible.parsing.yaml.objects as o
    test_yaml_str = u"{test: 1, test: 2}"
    stream = io.StringIO(test_yaml_str)
    r = AnsibleConstructor().construct_yaml_map(stream)
    assert isinstance(r, o.AnsibleMapping)
    assert r == {'test': 2}
    assert r.ansible_pos == ('<unicode string>', 1, 1)

# Generated at 2022-06-20 23:43:40.922785
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor

# Generated at 2022-06-20 23:43:54.051058
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()


# Generated at 2022-06-20 23:44:02.822655
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    def test_vault(self, password):
        return self

    def unencrypt(self, data):
        return "value_from_decryption"

    vault = VaultLib()
    vault.secrets = ['secret_id']
    vault.__class__.encrypt = test_vault
    vault.__class__.decrypt = unencrypt

    constructor = AnsibleConstructor()
    constructor._vaults['default'] = vault


# Generated at 2022-06-20 23:44:13.825269
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    text = u"\u00fc" #unicode string
    if sys.version < '3':
        text = text.encode("utf-8")
    stream = StringIO(text)
    ac = AnsibleConstructor(stream)

    expected_output = AnsibleUnsafeText(text)
    output = ac.construct_yaml_unsafe(stream)

    assert output.decode("utf-8") == expected_output

# Generated at 2022-06-20 23:44:23.416620
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    '''Test the ability of AnsibleConstructor to decrypt a vault-encrypted token'''

    # The vault-encrypted token below is produced by the following command
    # ansible-vault encrypt_string 'This is a really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really long test string'


# Generated at 2022-06-20 23:44:35.500362
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode

    test_snippet_1 = '''
        normal_string: this is a normal string
        unicode_string: "\uc5ec\uae30\ub294 \uc720\ub2c8\ucf54\ub4dc \uc5b4\ub5a4 \uc5b8\uc5b4\uc77c\uae4c"
    '''

    test_dict_1 = yaml.safe_load(test_snippet_1)
    assert isinstance(test_dict_1['normal_string'], str)
    assert isinstance(test_dict_1['unicode_string'], str)


# Generated at 2022-06-20 23:44:40.124533
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Tests for Python 2 and Python 3
    import sys
    if sys.version_info[0] < 3:
        expected = 'foo'
    else:
        expected = 'foo'
    actual = AnsibleConstructor.construct_yaml_str(None, 'foo')
    assert expected == actual

# Generated at 2022-06-20 23:44:48.709705
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Check if a duplicated key triggers a warning if DUPLICATE_YAML_DICT_KEY is warn,
    debug if DUPLICATE_YAML_DICT_KEY is ignore, and raises a ConstructorError if
    DUPLICATE_YAML_DICT_KEY is error.
    :return:
    """
    global display
    import mock

    def _mock_debug(text):
        assert text == 'While constructing a mapping from {0}, line {1}, column {2}, found a duplicate dict key (key). Using last defined value only.'.format('<string>', 0, 0)


# Generated at 2022-06-20 23:44:59.959142
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Examples of strings converted to AnsibleUnicode Objects
    assert isinstance(AnsibleConstructor(file_name=None).construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(AnsibleConstructor(file_name=None).construct_yaml_str('a'), AnsibleUnicode)
    assert isinstance(AnsibleConstructor(file_name=None).construct_yaml_str('[]'), AnsibleUnicode)
    assert isinstance(AnsibleConstructor(file_name=None).construct_yaml_str('[foo, bar]'), AnsibleUnicode)
    assert isinstance(AnsibleConstructor(file_name=None).construct_yaml_str('{}'), AnsibleUnicode)

# Generated at 2022-06-20 23:45:07.218118
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    import time
    import os
    import types

    test_data = AnsibleConstructor()
    test_data.construct_yaml_seq(yaml.compose(u'[1,2,3,4]').value)
    data = test_data.construct_yaml_seq(yaml.compose(u'[1,2,3,4]').value).next()
    assert isinstance(data, types.GeneratorType)
    assert list(data) == [1,2,3,4]
    assert data.ansible_pos == ('<memory>', 1, 1)
    data = test_data.construct_yaml_seq(yaml.compose(u'[1,2,3,4]').value).next()
    assert isinstance(data, types.GeneratorType)


# Generated at 2022-06-20 23:45:25.375058
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # ConstructorError
    assert AnsibleConstructor.construct_mapping.__name__ == "construct_mapping"

    # Test normal case:
    node = MappingNode('tag:yaml.org,2002:map', [])
    deep = False
    try:
        AnsibleConstructor.construct_mapping(node, deep)
        assert True
    except ConstructorError:
        assert False

    # Test unexpected case:
    node = 'foo'
    deep = False
    try:
        AnsibleConstructor.construct_mapping(node, deep)
        assert False
    except ConstructorError:
        assert True



# Generated at 2022-06-20 23:45:31.865313
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    '''
    Test for AnsibleConstructor
    '''
    from ansible.parsing.yaml.loader import AnsibleLoader

    sample = '''
        [{foo: bar}, baz]
        {foo: {bar: baz}}
        foo: "{{ foo }}"
        foo: !unsafe "{{ foo }}"
    '''

    data = AnsibleLoader(sample).get_single_data()
    assert type(data[0]) == AnsibleSequence
    assert type(data[1]) == AnsibleMapping
    assert type(data[2]) == AnsibleMapping
    assert type(data[3]) == AnsibleMapping

# Generated at 2022-06-20 23:45:43.741431
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import dump, load, scanner

    # Note: since there are many exceptions raised in yaml.scanner, the
    # test function using exceptions is not recommended, use try..except instead..
    yaml_str = """
---

# comments
key1: "value1"
key2: "value2"
key3: "value3"
key4:
  - "123"  # trailing comments
...
"""
    try:
        yaml_data = load(yaml_str, Loader=AnsibleConstructor)
    except scanner.ScannerError as e:
        print(e)
        print(dump(load(yaml_str)))
    except ConstructorError as e:
        print(e)
        print(dump(load(yaml_str)))

# Generated at 2022-06-20 23:45:46.373244
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = {'foo': 'bar'}
    c = AnsibleConstructor()
    assert type(c.construct_mapping(node)) == type(node)



# Generated at 2022-06-20 23:45:50.344815
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = AnsibleConstructor('').construct_yaml_map(yaml.composer.MappingNode(u'tag:yaml.org,2002:map', [], [], [], None, None))
    assert isinstance(data, AnsibleMapping)


# Generated at 2022-06-20 23:45:57.857830
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node_value = [
        ('key1', 'value1'),
        ('key2', 'value2'),
        ('key3', 'value3'),
        ('key1', 'value4'),
        ('key2', 'value5')
    ]
    mapping_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=node_value, flow_style=False)

    yaml_constructor = AnsibleConstructor()
    data = yaml_constructor.construct_yaml_map(mapping_node)

    ansible_mapping = data.next()
    assert ansible_mapping == {'key1': 'value4', 'key2': 'value5', 'key3': 'value3'}



# Generated at 2022-06-20 23:46:10.176829
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    # initialize necessary arguments for method construct_vault_encrypted_unicode
    # of class AnsibleConstructor
    vault_secrets = ['test-vault-secrets']
    vault_passwords_file = 'test-vault-passwords-file'
    file_name = 'test-file-name'

    # create an instance of AnsibleConstructor
    construct = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)

    # create a vault encrypted string for testing
    plain_text_str = 'this is a vault secret'

# Generated at 2022-06-20 23:46:18.974588
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
	from yaml.nodes import SequenceNode
	from yaml.nodes import MappingNode
	from yaml.nodes import ScalarNode

	const = AnsibleConstructor()

	# Test when a sequence node contains one scalar node
	test_node = SequenceNode('tag:yaml.org,2002:seq', [ScalarNode('tag:yaml.org,2002:str', 'foo', (1, 0), (1, 4))], (1, 0), (1, 4))
	for tmp in const.construct_yaml_seq(test_node) :
		assert isinstance(tmp, AnsibleSequence)
		assert len(tmp) == 1
		assert tmp[0] == 'foo'

	# Test when a sequence node contains one sequence node
	# 1_scalar -> 1_scalar


# Generated at 2022-06-20 23:46:26.355101
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    temp = AnsibleConstructor()

    # test node
    class MockNode(object):
        def __init__(self):
            self.start_mark = None

    # test constructor error
    node = MockNode()
    try:
        temp.construct_vault_encrypted_unicode(node)
        assert False
    except:
        assert True

    # test value
    node.start_mark = "Hello World"
    assert temp.construct_vault_encrypted_unicode(node) is not None


# Generated at 2022-06-20 23:46:30.716973
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor._node_position_info(u'node') == ('<string>', 1, 1)
    assert isinstance(ansible_constructor.construct_mapping(u'test_construct_mapping'), AnsibleMapping)

# Generated at 2022-06-20 23:47:00.726400
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from yaml.compat import StringIO
    from ansible.compat.tests import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        yaml_text = """
        list:
            - item1
            - item2
        """

        def setUp(self):
            self.yaml_dict = yaml.load(StringIO(self.yaml_text), Loader=AnsibleLoader)

        def test_instantiate_AnsibleConstructor(self):
            self.assertTrue(isinstance(self.yaml_dict, dict))

        def test_AnsibleConstructor_value_type(self):
            self.assertTrue(isinstance(self.yaml_dict['list'], list))

# Generated at 2022-06-20 23:47:01.191441
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    pass

# Generated at 2022-06-20 23:47:09.265085
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    c = AnsibleConstructor()
    node = c.construct_yaml_str('something')
    c._vaults['default'] = VaultLib([])
    result = c.construct_vault_encrypted_unicode(node)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault == c._vaults['default']
    assert isinstance(result.vault_secrets, list)
    assert len(result.vault_secrets) == 0

# Generated at 2022-06-20 23:47:21.502189
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with dictionary with duplicate keys
    d1 = {'key1': 'val1', 'key2': 'val2', 'key1': 'val1'}
    yaml_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[('key1', 'val1'), ('key2', 'val2'), ('key1', 'val1')])
    # Assign the dictionary d1 to the attribute value of the node
    yaml_node.value = list(d1.items())
    # Assign the value of the attribute ansible_pos to the attribute start_mark of the node
    yaml_node.start_mark = d1.ansible_pos
    # Construct the mapping from the node
    result = AnsibleConstructor.construct_mapping(yaml_node)

# Generated at 2022-06-20 23:47:23.572079
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    res = AnsibleConstructor(file_name=None, vault_secrets=None).construct_yaml_unsafe(None)
    assert res is None

# Generated at 2022-06-20 23:47:32.393107
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Arrange
    import collections
    mapping = collections.OrderedDict()
    mapping[1] = "one"
    mapping[2] = "two"
    mapping[3] = "three"
    mapping[1] = "other"
    mapping[2] = "other"
    mapping[3] = "other"

    node = AnsibleMapping()
    node.value = mapping.items()
    node.start_mark = AnsibleMapping()
    node.start_mark.name = "test"
    node.start_mark.line = 0

    # Act
    contructor = AnsibleConstructor()
    result = contructor.construct_mapping(node)

    # Assert
    assert mapping == result

# Generated at 2022-06-20 23:47:39.318316
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import mock
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    with mock.patch.object(VaultLib, 'decrypt') as vault_decrypt_mock:
        vault_decrypt_mock.side_effect = ["test", "test2", "test3"]

# Generated at 2022-06-20 23:47:51.373593
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    class TestYAMLSafeLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None):
            super(TestYAMLSafeLoader, self).__init__(stream, file_name=file_name)

            self.add_constructor(
                u'tag:yaml.org,2002:map',
                type(self).construct_yaml_map)

            self.add_constructor(
                u'tag:yaml.org,2002:python/dict',
                type(self).construct_yaml_map)


# Generated at 2022-06-20 23:47:57.709364
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping = [('a', 1), ('b', 3), ('d', 4), ('a', 2)]
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=mapping,
                       flow_style=False, start_mark=None, end_mark=None)
    ctor = AnsibleConstructor()
    assert ctor.construct_mapping(node) == {'a': 2, 'b': 3, 'd': 4}
    ctor.DUPLICATE_YAML_DICT_KEY = 'error'
    try:
        ctor.construct_mapping(node)
    except ConstructorError as ve:
        assert ve.problem == 'found a duplicate dict key (a)'
        assert ve.problem_mark.line == 1
        assert ve.problem_mark.column == 5

# Generated at 2022-06-20 23:48:05.200811
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = u"""
    ---
    foo: !unsafe
        - 1
        - 2
        - 3
    """
    data = AnsibleLoader(yaml_str)
    assert isinstance(data.get_single_data(), AnsibleUnsafe)
    assert data.get_single_data().value == [1, 2, 3]

# Generated at 2022-06-20 23:48:28.573052
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # test empty seq
    yaml_data = u'''
test:
-
'''
    myansi_constr = AnsibleConstructor()
    obj = myansi_constr.construct_yaml(yaml_data)
    assert isinstance(obj['test'], list)
    assert len(obj['test']) == 1
    assert isinstance(obj['test'][0], list)
    assert len(obj['test'][0]) == 0

    # test single scalar
    yaml_data = u'''
test:
- foo
'''
    myansi_constr = AnsibleConstructor()
    obj = myansi_constr.construct_yaml(yaml_data)
    assert isinstance(obj['test'], list)
    assert len(obj['test']) == 1


# Generated at 2022-06-20 23:48:38.617339
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print("testing AnsibleConstructor_construct_yaml_map")
    constructor = AnsibleConstructor()

    # simple case 1
    map_result = constructor.construct_yaml_map({"key1": "value1", "key2": "value2"})
    assert isinstance(map_result, dict)
    assert "key1" in map_result.keys()
    assert map_result["key1"] == "value1"
    assert "key2" in map_result.keys()
    assert map_result["key2"] == "value2"

    # simple case 2
    map_result = constructor.construct_yaml_map({"key1": "value1", "key2": "value2"})
    assert isinstance(map_result, dict)
    assert "key1" in map_result.keys()
   

# Generated at 2022-06-20 23:48:45.333886
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test = u'key1: value1\nkey1: value2'

    yaml = YAML()
    yaml.Constructor = AnsibleConstructor
    data = yaml.load(test)
    assert isinstance(data, AnsibleMapping)
    assert data['key1'] == 'value2'
    assert data.ansible_pos == ('<unicode string>', 1, 0)

# Generated at 2022-06-20 23:48:56.796539
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    _test_text = """
---
a_map_with_scalars:
    scalar: 123
    nested1:
        a_scalar: 567
    nested2:
        a_scalar: 345
        a_map:
            a_scalar: 567
"""
    _expected_result = {
        'a_map_with_scalars': {
            'nested1': {
                'a_scalar': 567,
            },
            'nested2': {
                'a_scalar': 345,
                'a_map': {
                    'a_scalar': 567
                }
            },
            'scalar': 123,
        }
    }

    _loader = AnsibleConstructor(file_name='fake_file_name')
   

# Generated at 2022-06-20 23:49:04.065561
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import re
    from ansible.parsing.yaml.loader import AnsibleLoader
    matches = []

# Generated at 2022-06-20 23:49:15.339066
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    plaintext_text = 'plaintext'
    ciphertext_text = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\n36353066633963623265626337613035663337656665666635663465393362303636333061396237\n32626462343966633064626633356236636235626262393631656166303761323863623733303561\ngiFyTn2/x/xEb14/R8zYWQ==\n')

# Generated at 2022-06-20 23:49:20.824867
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_data = '''
a: !unsafe |
  foo
b: 1
'''
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(data['a'], AnsibleUnicode)
    assert isinstance(data['b'], int)

# Generated at 2022-06-20 23:49:28.162072
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.parsing.yaml.loader as loadr

    loader = loadr.Loader(AnsibleConstructor)

    # test1: duplicate dict keys, ignore
    yaml_snippet = '''
    key1: 1
    key2: 2
    key1: 3
    '''
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    data = loader.get_single_data(yaml_snippet)
    assert data == {'key1': 3, 'key2': 2}

    # test2: duplicate dict keys, warn
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    data = loader.get_single_data(yaml_snippet)

# Generated at 2022-06-20 23:49:39.096903
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with empty dict
    constructor = AnsibleConstructor()
    result = constructor.construct_mapping(MappingNode(None, []))
    assert {} == result

    # Test with empty dict, with duplicate key warning
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    constructor = AnsibleConstructor()
    result = constructor.construct_mapping(MappingNode(None, []))
    assert {} == result

    # Test with single key (non-dupe)
    constructor = AnsibleConstructor()
    result = constructor.construct_mapping(MappingNode(None, [('somekey', 'somevalue')]))
    assert {'somekey': 'somevalue'} == result

    # Test with single key (dupe), warning
    C.DUPLICATE_YAML_DICT

# Generated at 2022-06-20 23:49:48.177733
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io

    if sys.version_info >= (2, 7):
        from unittest import TestCase
    else:
        from ansible.compat.tests import TestCase

    yaml_src = u"""
    a: 1
    b: 2
    c: 3
    d: 2
    """
    yaml_src_dup = u"""
    a: 1
    b: 2
    c: 3
    d: 2
    d: 1
    """
    yaml_src_error = u"""
    a: 1
    b: 2
    c: 3
    c: 1
    """

    class TestAnsibleConstructor(TestCase):
        def setUp(self):
            if sys.version_info >= (2, 7):
                self.unicode_class = unicode