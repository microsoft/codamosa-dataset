

# Generated at 2022-06-20 23:40:30.330205
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import load

    # SafeConstructor
    # from yaml.constructor import SafeConstructor

    # class AnsibleConstructor(SafeConstructor):
    #   """
    #   This is a customized version of the yaml load constructor (SafeConstructor)
    #   that makes loading more strict and allows more configuration.
    #   """
    #
    #   def __init__(self, file_name=None):
    #       super(AnsibleConstructor, self).__init__()
    #       self._ansible_file_name = file_name

    # def construct_yaml_map(self, node):
    #   data = AnsibleMapping()
    #   yield data
    #   value = self.construct_mapping(node)
    #   data.update(value)
    #   data.

# Generated at 2022-06-20 23:40:36.741997
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    obj = AnsibleConstructor()
    node = type('Node', (object,), {'start_mark': type('', (object,), {'name': 'test.yml', 'line': 1, 'column': 0})})()
    assert isinstance(obj.construct_yaml_str(node), AnsibleUnicode)

# Generated at 2022-06-20 23:40:43.321886
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ["vault_secret_1", "vault_secret_2"]
    vault_obj = VaultLib(secrets=vault_secrets)
    obj = AnsibleConstructor(vault_secrets=vault_secrets)

    # Using default vault
    obj._vaults['default'] = vault_obj
    obj._ansible_file_name = "test_file_name"
    ret = obj.construct_vault_encrypted_unicode(MappingNode(None, None, None))

    assert isinstance(ret, AnsibleVaultEncryptedUnicode)
    assert ret.ansible_pos == ('test_file_name', 1, 1)
    assert ret.vault == vault_obj

    # Using a non default vault
    obj._vaults['other'] = vault_obj

# Generated at 2022-06-20 23:40:53.509983
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    a = AnsibleConstructor()
    d = AnsibleDumper()

    assert wrap_var('foo') == a.construct_yaml_unsafe(d.represent_str('foo'))
    assert wrap_var(0) == a.construct_yaml_unsafe(d.represent_int('0'))
    assert wrap_var(1.0) == a.construct_yaml_unsafe(d.represent_float('1.0'))
    assert wrap_var([1, 2, 3]) == a.construct_yaml_unsafe(d.represent_list([1, 2, 3]))

# Generated at 2022-06-20 23:40:58.034426
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = AnsibleConstructor.construct_yaml_seq(None, None)
    assert hasattr(node, '_ansible_pos')
    assert hasattr(node, 'extend')
    assert hasattr(node, 'ansible_pos')



# Generated at 2022-06-20 23:41:10.399953
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os.path
    import yaml
    yaml.add_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, 'data/yaml', 'constructor_unsafe_01.yaml')) as f:
        data = yaml.load(f)
    assert data == {'testkey': ['testsub1', 'testsub2']}
    with open(os.path.join(here, 'data/yaml', 'constructor_unsafe_02.yaml')) as f:
        data = yaml.load(f)
    assert data == ['testsub1', 'testsub2']

# Generated at 2022-06-20 23:41:24.217641
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import ansible.parsing.yaml.loader

    yaml_obj = open('/tmp/test.yml', 'w')
    yaml_obj.write("""
    - name: Test 1
      value: 1
    - name: Test 2
      value: 2
    - name: Test 3
      value: 3
    """)
    yaml_obj.close()

    data = ansible.parsing.yaml.loader.load_from_file('/tmp/test.yml')

    for i in range(len(data)):
        print(data[i])

    print(data[0])
    print(data[0]['name'])
    print(data[0]['value'])

if __name__ == '__main__':
    test_AnsibleConstructor_construct_y

# Generated at 2022-06-20 23:41:33.541859
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    # Test if the returnd object is an unicode string
    # --
    # Test: /home/jenkins/workspace/ansible_ansible/test/unit/parsing/yaml/parser/test_constructor.py:test_AnsibleConstructor_construct_yaml_str:11
    #
    # Description:
    #     Test if the returnd object is an unicode string
    #
    # Success:
    #     Return value is an unicode string
    #
    # Failure:
    #     Return value is not an unicode string
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml
    class_ = AnsibleConstructor
    obj = AnsibleUnicode(u"just an example")
    yaml_node = yaml.nodes

# Generated at 2022-06-20 23:41:45.397198
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # pylint: disable=missing-docstring
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """
        foo: bar
        baz: "{{ biz }}"
        """
    data = yaml.load(yaml_str, Loader=AnsibleLoader)

    assert 'foo' in data
    assert 'baz' in data

    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['baz'], AnsibleUnicode)

    assert data['foo'].endswith(u'bar')
    assert data['baz'].endswith(u'{{ biz }}')



# Generated at 2022-06-20 23:41:53.151344
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from collections import namedtuple
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import sys
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    class MyArgs:
        vault_password_file = [sys.argv[1]]
        vault_ids = ['vault']
        vault_identity_list = None
        verbosity = None
        offline = None
        inventory = None
        inventory_ignore = None
        inventory_ignore_extensions = []
        inventory_sources = []
        inventory_loader = None
        connection = None
        timeout = None
        remote_user = None
        remote_pass = None


# Generated at 2022-06-20 23:42:07.919409
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = AnsibleMapping()
    yield data
    value = self.construct_mapping(node)
    data.update(value)
    data.ansible_pos = self._node_position_info(node)

# Generated at 2022-06-20 23:42:14.868872
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    if sys.version_info[0] >= 3:
        class Foo: pass
        foo = Foo()
        foo.__class__ = str
        instance = AnsibleConstructor(object_pairs_hook=AnsibleMapping)
        ret = wrap_var(foo)
        assert ret == "Foo", "AnsibleConstructor.construct_yaml_unsafe: unexpected value '%s'" % ret

# Generated at 2022-06-20 23:42:20.986400
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    import types

    # Test Unicode string
    yaml_str = "test_str"
    loader = AnsibleLoader(yaml_str)
    ret = loader.get_single_data()

    assert isinstance(ret, AnsibleUnicode)
    assert ret == "test_str"

    # Test non-Unicode string
    yaml_str = "{a: 1, b: 2, c: 3}"
    loader = AnsibleLoader(yaml_str)
    ret = loader.get_single_data()

    # unlike assertTrue(isinstance(ret, dict)), assertIsInstance(ret, dict)
    # will test "assert isinstance(ret, dict)"

# Generated at 2022-06-20 23:42:29.972366
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """This Unit Test is to test construct_mapping of class AnsibleConstructor,
    It's to test if the construct_mapping can add extra information, ansible_pos, to all the elements in the dict,
    and also to test if it can raise the right error when it meets a duplicated key in a yaml file.
    """
    import io
    import os

    from ansible.parsing.yaml.loader import AnsibleLoader

    file_path = os.path.join(os.path.dirname(__file__), 'data/yaml_constructor_test.yml')
    assert os.path.exists(file_path)
    with open(file_path) as f:
        file_data = f.read()
    # test for a non-duplicated yaml file:
    file_content = Ans

# Generated at 2022-06-20 23:42:41.954179
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    #  test without ansible_pos
    test_data = "---\n- a\n- b\n"
    ticket_7699_test_data = "---\n- {{ 'a' | d() }}\n"
    test_data_with_ansible_pos = "---\n- a\n\n- b\n"
    # Since asserts doesn't raise an error, instead it prints an error, which will fail the TravisCi build,
    # I was modifying my test code to try/except, which was raising the AssertionError properly and was
    # failing the test case, but still TravisCI was not treating it as a failure.

    # After looking up I found that should raise an error, so added raise to the assert, so that it would
    # properly fail the test case.

# Generated at 2022-06-20 23:42:55.441241
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    vault = VaultLib(secrets=[u'pwd1'])
    b_ciphertext_data = vault.encrypt(u'hi')
    b_yaml = yaml.dump(b_ciphertext_data, default_style='|').encode('utf-8')
    constructor = AnsibleConstructor()
    b_vault_encrypted_unicode = constructor.construct_vault_encrypted_unicode(yaml.composer.Composer(yaml.reader.Reader(b_yaml)).check_node())
    assert isinstance(b_vault_encrypted_unicode, AnsibleVaultEncryptedUnicode)
    assert b_vault_encrypted_unicode.vault == vault
    assert b_vault_encrypted_unicode.decrypted_data == u'hi'


# Generated at 2022-06-20 23:43:08.226899
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import json

    # Need to remove 'ansible.parsing.yaml.loader' from sys.modules
    # to be able to test the method construct_yaml_unsafe()
    # (Hint: see PEP 302 for details)
    if 'ansible.parsing.yaml.loader' in sys.modules:
        del sys.modules['ansible.parsing.yaml.loader']

    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-20 23:43:14.130243
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_map = yaml.dump({'k1': 'v1', 'k2': 'v2'}, Dumper=AnsibleDumper,
                         default_flow_style=False)

    assert isinstance(yaml.load(yaml_map, Loader=AnsibleConstructor), AnsibleMapping)

# Generated at 2022-06-20 23:43:15.827664
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    display.display('Nothing to test in class AnsibleConstructor')

# Generated at 2022-06-20 23:43:22.803792
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    Ensure we get an AnsibleUnicode object back.
    """
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_str("a string")
    assert isinstance(result, AnsibleUnicode)
    assert not isinstance(result, unicode)
    assert isinstance(result, unicode)
    assert result == u"a string"

# Generated at 2022-06-20 23:43:32.818615
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    c = AnsibleConstructor()
    assert isinstance(c.construct_yaml_map({}), AnsibleMapping)

# Generated at 2022-06-20 23:43:42.754895
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    class DummyStream:
        pass

    class DummyNode:
        def __init__(self, tag, value, start_mark, end_mark):
            self.tag = tag
            self.value = value
            self.start_mark = start_mark
            self.end_mark = end_mark

    class DummyMark:
        def __init__(self, name, index, line, column, buffer, pointer):
            self.name = name
            self.index = index
            self.line = line
            self.column = column
            self.buffer = buffer
            self.pointer = pointer

    test_stream = DummyStream()
    test_stream.name = "test_file"

# Generated at 2022-06-20 23:43:47.753724
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:43:58.717581
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:44:09.977451
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    class MyDumper(yaml.SafeDumper):
        def increase_indent(self, flow=False, indentless=False):
            return super(MyDumper, self).increase_indent(flow, False)

        def represent_data(self, data):
            node = super(MyDumper, self).represent_data(data)
            if isinstance(data, dict) and data.get('__unsafe__'):
                node.tag = u'!unsafe'
            return node
    yaml.add_representer(dict, MyDumper.represent_data)

    import types
    import unittest


# Generated at 2022-06-20 23:44:20.674511
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os
    import sys
    import unittest

    from ansible.parsing.yaml.objects import AnsibleMapping

    from units.mock.loader import DictDataLoader

    class TestAnsibleConstructor_construct_mapping(unittest.TestCase):

        def setUp(self):
            # Setup a Fake AnsibleVault object
            mock_dict = {'default': None}
            self._vaults = mock_dict
            self.vault_secrets = None
            self._ansible_file_name = None

            self.file_paths = ['test_vars.yaml', 'test_vars.yaml']
            self.valid_nodes = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
            self.file_cont

# Generated at 2022-06-20 23:44:31.738703
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib, VaultSecret

    vault_secrets = [VaultSecret(b'abc123')]
    loader = AnsibleLoader(vault_secrets=vault_secrets)

    # Try to decrypt vault encrypted unicode

# Generated at 2022-06-20 23:44:40.390193
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test when initial string is unicode
    input = u'a unicode string ä'
    ansibleconstructor = AnsibleConstructor()
    output_1 = ansibleconstructor.construct_yaml_str(input)
    assert isinstance(output_1, AnsibleUnicode)

    # Test when initial string is str
    input = 'a str string'
    output_2 = ansibleconstructor.construct_yaml_str(input)
    assert isinstance(output_2, AnsibleUnicode)


# Generated at 2022-06-20 23:44:43.435667
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()
    node = to_bytes("!!str 'foo'")
    result = constructor.construct_yaml_str(node)

    assert result == "foo"



# Generated at 2022-06-20 23:44:55.390876
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import json
    import yaml

    class TestClass:
        def __init__(self):
            self.a = 100

    test_obj = TestClass()
    test_json = json.dumps(test_obj.__dict__)
    test_str = 'asdf'
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_int = 100

    assert AnsibleConstructor().construct_yaml_unsafe(yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:str', value=test_json)) == test_obj.__dict__
    assert AnsibleConstructor().construct_yaml_unsafe(yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:str', value=test_str)) == test

# Generated at 2022-06-20 23:45:21.557361
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    data = '''
- {hash1: A, hash2: 1}
- {hash2: B, hash1: 2}
- {hash3: C, hash4: 3}
'''
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)

    assert yaml_obj[0].ansible_pos == ('<string>', 1, 1)
    assert yaml_obj[1].ansible_pos == ('<string>', 2, 1)
    assert yaml_obj[2].ansible_pos == ('<string>', 3, 1)

# Generated at 2022-06-20 23:45:29.801041
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    This is a unit test for method construct_yaml_seq of class AnsibleConstructor. 
    This is used to test default sequences are now AnsibleSequence.
    
     Usage:
     python3 test_ansible_constuctor_construct_yaml_seq.py
     
     Return:
     N/A
    """
    yaml_str = '[1,2,3]'
    constructor = AnsibleConstructor()
    c_yaml = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(c_yaml, AnsibleSequence)
    print('The test result of method construct_yaml_seq of class AnsibleConstructor for default sequences is passed!')

# Generated at 2022-06-20 23:45:40.814519
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # use a string which contains the exact number of spaces
    # that the unicode string takes
    test_data = (u'{"foo": !unsafe "\\u00ab"}\n')
    test_data = to_bytes(test_data)

    # use the custom loader to load the data
    test_data_loaded = AnsibleLoader(test_data).get_single_data()

    # ensure that .load() ran without any errors
    assert (test_data_loaded is not None)

    # extract the first element from the loaded data
    test_data_element = list(test_data_loaded)[0]

    # ensure that the extracted string is unicode
    assert (isinstance(test_data_element, unicode))

# Generated at 2022-06-20 23:45:51.859399
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import ansible.constants as C
    ansible_vault_password_file = 'some_file_path'
    ansible_vault_password = 'some_password'
    C.ANSIBLE_VAULT_PASSWORD_FILE = ansible_vault_password_file
    C.DEFAULT_VAULT_PASSWORD = ansible_vault_password

    ansible_constructor = AnsibleConstructor()

    # test to pass when file is present

    def mock_exists(file_path):
        return True

    import os
    old_exists = os.path.exists
    os.path.exists = mock_exists

# Generated at 2022-06-20 23:45:58.695237
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """Construct an object from a sequence of nodes in the tree.
    """
    # We use the following example:
    #    ---
    #    - Salt
    #    - Pepper
    #    - Garlic
    from io import StringIO

    string_IO = StringIO("""
- Salt
- Pepper
- Garlic
""")
    # Expected result is: ['Salt', 'Pepper', 'Garlic']

    # We create the AnsibleConstructor object for construct_yaml_seq
    ansible_constructor = AnsibleConstructor()

    # We use the following YAML string:
    #    ---
    #    - Salt
    #    - Pepper
    #    - Garlic
    from yaml import load, MappingNode

    mapping = load(string_IO)
    yaml_str = mapping[0]



# Generated at 2022-06-20 23:46:04.606578
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = """
a: hello
"""
    import yaml
    from io import StringIO
    data_in = StringIO(yaml_str)
    data_out = yaml.load(data_in, Loader=AnsibleConstructor)
    assert data_out["a"].startswith("hello")

# Generated at 2022-06-20 23:46:15.267098
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from collections import namedtuple
    from ansible.parsing import vault
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedText
    from io import BytesIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import yaml

    # test construct_vault_encrypted_unicode
    vault_password = "secret"
    secret = VaultSecret(password=vault_password)
    vault_secrets = [secret]
    vault_id = vault.generate_vault_id()

# Generated at 2022-06-20 23:46:26.741002
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types, PY3

    vault_secrets = ['vault_password']
    c = AnsibleConstructor(vault_secrets=vault_secrets)
    v = VaultLib(secrets=vault_secrets)

    # construct_vault_encrypted_unicode()

# Generated at 2022-06-20 23:46:35.377011
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ansible_constructor = AnsibleConstructor()
    assert isinstance(ansible_constructor.construct_yaml_map({}), AnsibleMapping)

    assert isinstance(ansible_constructor.construct_vault_encrypted_unicode({}), AnsibleVaultEncryptedUnicode)
    assert isinstance(ansible_constructor._vaults['default'], VaultLib)

# Generated at 2022-06-20 23:46:36.310640
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Enter your code here
    pass


# Generated at 2022-06-20 23:47:13.308809
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_constructor = AnsibleConstructor()
    yaml_constructor.construct_yaml_seq([])


# Generated at 2022-06-20 23:47:14.176558
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert True

# Generated at 2022-06-20 23:47:20.021322
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Creating object
    import yaml
    AnsiConst = AnsibleConstructor()

    # Creating a data structure
    data = '''
    - item1
    - item2
    - item3
    '''
    data = yaml.load(data, Loader=AnsibleLoader)

    # Assertion
    assert data == ['item1', 'item2', 'item3']

# Generated at 2022-06-20 23:47:29.601500
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['vault_secret']
    vault = VaultLib(vault_secrets)
    vault_text = to_bytes(vault.encrypt('secret'))
    node = AnsibleMapping({'vault': VaultLib.ENCRYPTED_STRING_PREFIX + vault_text})
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_constructor.construct_object(node)

    assert node == AnsibleMapping({'vault': AnsibleVaultEncryptedUnicode(vault_text)})

# Generated at 2022-06-20 23:47:38.896461
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    file_name = "test_AnsibleConstructor_construct_yaml_seq"
    vault_secrets = ["vault_secret1", "vault_secret2"]
    constructor = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)

    assert isinstance(constructor, SafeConstructor)
    assert isinstance(constructor, AnsibleConstructor)

    assert hasattr(constructor, "construct_yaml_map")
    assert hasattr(constructor, "construct_mapping")
    assert hasattr(constructor, "construct_yaml_str")
    assert hasattr(constructor, "construct_vault_encrypted_unicode")
    assert hasattr(constructor, "construct_yaml_seq")

# Generated at 2022-06-20 23:47:51.039392
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    try:
        from yaml import CLoader
    except:
        return

    import os

    vault_string = '$ANSIBLE_VAULT;1.1;AES256\n34646537613062393261363830666433353037393236616362613239306335333839353064373835\n37393739303564646637643839366438346461323164313332643066626634626233363662363566\n3366653635373631393365373535303438323231633963326666393830386333303339303537\n'

    # 32 characters is what had been used in v1.4 and below, decrypt is supported

# Generated at 2022-06-20 23:47:54.457672
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    value = c.construct_mapping(node)
    assert isinstance(value, AnsibleMapping)
    assert value.ansible_pos == ('<unicode string>', 1, 0)

# Generated at 2022-06-20 23:47:55.689086
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # TODO: Add tests for method construct_yaml_map of class AnsibleConstructor
    pass

# Generated at 2022-06-20 23:48:07.908411
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    test_dict = dict(
        test_dict_key='test_dict_value',
        bool_true=True,
        bool_false=False,
    )

    def _get_MappingNode(d):
        import yaml
        yaml_data = yaml.serialize(d)
        stream = yaml.Stream(yaml_data)
        return stream.next()

    node = _get_MappingNode(test_dict)

    ac = AnsibleConstructor()
    ac._ansible_file_name = 'SomeFile'

    result = ac.construct_yaml_map(node)

    assert isinstance(result, AnsibleMapping)
    assert result.items() == test_dict.items()
    assert result.ansible_pos == ('SomeFile', 1, 1)

    node = _get_

# Generated at 2022-06-20 23:48:11.673977
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = AnsibleSequence()
    data.extend(['first', 'second'])
    assert len(data) == 2
    assert data[0] == 'first'
    assert data[1] == 'second'

# Generated at 2022-06-20 23:49:26.260862
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = "---\n" + \
                "test_dict:\n" + \
                "  key1: value1\n" + \
                "  key1: valueX\n" + \
                "  key2: value2\n"
    construct = AnsibleConstructor(file_name="<string>")
    try:
        construct.construct_mapping(construct.compose_document(yaml_data))
        msg = "Yaml document with duplicate keys should throw a ConstructorError, but it doesn't."
        assert False, msg
    except ConstructorError as e:
        assert True

# Generated at 2022-06-20 23:49:37.212361
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import ScalarNode, SequenceNode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    node_data = ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foo')
    node = SequenceNode(tag=u'tag:yaml.org,2002:seq', value=[
        node_data,
    ])

    loader = AnsibleLoader(node, None)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 1
    assert 'foo' == data[0]


# Generated at 2022-06-20 23:49:43.654380
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    assert isinstance(AnsibleConstructor.construct_yaml_unsafe(None, None), AnsibleUnsafeText)

# Some older Ansible YAML files may still have a !safe tag in them, so we need
# to define a !safe tag that can be translated to a str() so that these
# files still load.
AnsibleConstructor.add_constructor(u'!safe', AnsibleConstructor.construct_str)



# Generated at 2022-06-20 23:49:50.785030
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.host import Host
    from ansible.parsing.vault import VaultLib
    data = '''
    - hosts: group1
    - hosts: group2
    '''
    loader = AnsibleLoader(data, file_name='data')
    loader.vault_secrets = VaultLib(secrets=['secret']).secrets
    blocks = list(loader.get_single_data())
    assert blocks[0].blocks[0].get_group_vars() == {}
    assert blocks[0].blocks[0]['hosts'] == 'group1'
    assert blocks[0].blocks[1]['hosts'] == 'group2'
    assert blocks[0].blocks[0] == Host(name='group1')


# Generated at 2022-06-20 23:49:55.737930
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    yaml_str = """
        one: two
        three: four
        five: six
        five: seven
    """
    loaded_yaml = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert loaded_yaml == {'one': 'two', 'three': 'four', 'five': 'seven'}


# Generated at 2022-06-20 23:50:06.506513
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import types
    class MyAnsibleConstructor(AnsibleConstructor):
        def __init__(self, vault_secrets=None):
            super(MyAnsibleConstructor, self).__init__()
            self._vaults = {}
            self.vault_secrets = vault_secrets or []
            self._vaults['default'] = VaultLib(secrets=self.vault_secrets)
    # Make the vault secret accessible in the unit test
    vault_secrets = [ u'S3CUReS3CR3T' ]
    my_constructor = MyAnsibleConstructor(vault_secrets=vault_secrets)
    # Prepare the test MappingNode
    from yaml.nodes import ScalarNode, MappingNode, SequenceNode
    from yaml.events import MappingEndEvent

# Generated at 2022-06-20 23:50:14.847520
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    input_map = [{'foo': 'bar'}, {'dup': '1st'}, {'dup': '2nd'}, {'dup': '3rd'}]
    # test default setting
    test_const = AnsibleConstructor()
    assert test_const.construct_mapping(input_map) == {'foo': 'bar', 'dup': '3rd'}
    # test warn setting
    test_const = AnsibleConstructor(vault_secrets=['foo'])
    test_const.vault_secrets = ['foo']
    assert test_const.construct_mapping(input_map) == {'foo': 'bar', 'dup': '3rd'}
    # test error setting
    test_const = AnsibleConstructor(vault_secrets=['foo'])
   