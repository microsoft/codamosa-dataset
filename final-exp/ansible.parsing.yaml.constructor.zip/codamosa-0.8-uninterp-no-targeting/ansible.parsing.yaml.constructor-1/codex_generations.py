

# Generated at 2022-06-20 23:40:33.156442
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert isinstance(AnsibleConstructor().construct_yaml_seq('data'), AnsibleSequence)
    assert isinstance(AnsibleConstructor().construct_yaml_str('data'), AnsibleUnicode)
    assert isinstance(AnsibleConstructor().construct_yaml_map('data'), AnsibleMapping)

    assert not isinstance(AnsibleConstructor().construct_yaml_seq('data'), AnsibleMapping)
    assert not isinstance(AnsibleConstructor().construct_yaml_str('data'), AnsibleMapping)
    assert not isinstance(AnsibleConstructor().construct_yaml_map('data'), AnsibleSequence)

    assert not isinstance(AnsibleConstructor().construct_yaml_seq('data'), AnsibleUnicode)

# Generated at 2022-06-20 23:40:40.523499
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None, flow_style=None)
    mapping = constructor.construct_mapping(node)

    assert isinstance(mapping, AnsibleMapping)
    assert isinstance(mapping.ansible_pos, tuple)

# Generated at 2022-06-20 23:40:50.608607
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from _ruamel import yaml

    yaml_obj = yaml.YAML(typ='unsafe')
    yaml_obj.default_flow_style = False

    test_cases = [
        {'tag': u'!unsafe', 'input': {u'a': u'foo'}, 'expected_output': {u'a': u'foo'}},
        {'tag': u'!unsafe', 'input': {u'b': [True, False], u'a': {u'foo': u'bar'}}, 'expected_output': {u'b': [True, False], u'a': {u'foo': u'bar'}}}
    ]


# Generated at 2022-06-20 23:41:00.679489
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml.scanner import ScannerError
    # By default, the yaml loader will use the standard lib constructors for python lists and dictionaries
    # in order to preserve ordered dictionaries.  This first test validates that those will throw exceptions
    # for duplicate keys
    test_yaml = u'---\nmydict:\n  id: 1\n  id: 2\n'
    try:
        from yaml import load
    except ImportError:
        # yaml isn't available
        return
    # Load standard lib type
    try:
        load(test_yaml)
    except ScannerError:
        # We expect this to error out
        pass

    test_yaml = u'---\nmydict:\n  id: 1\n  id: 2\n'
    # Use our custom constructor

# Generated at 2022-06-20 23:41:01.503012
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass



# Generated at 2022-06-20 23:41:07.969563
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    sample_yaml = """
    -
        a:
          -
            - 1
            - 2
            - 3
          -
            - 4
            - 5
  """
    data = yaml.load(sample_yaml, Loader=AnsibleConstructor)
    assert data == [{u'a': [[1, 2, 3], [4, 5]]}]

# Generated at 2022-06-20 23:41:20.711531
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    display.debug('test_AnsibleConstructor_construct_vault_encrypted_unicode() called')
    vault_password = 'changeme'
    vault_secrets = [ vault_password ]
    vault = VaultLib(vault_secrets)

    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)

    expected = AnsibleVaultEncryptedUnicode(ciphertext['data'])
    expected.vault = vault
    expected.ansible_pos = ('/dev/null', 1, 1)

    # actual
    node = object()
    c = AnsibleConstructor(vault_secrets=vault_secrets)
    actual = c.construct_vault_encrypted_unicode(node)

    assert actual.vault == expected.vault
    assert actual.ansible_

# Generated at 2022-06-20 23:41:29.808272
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest, os, tempfile, yaml

    # This test should pass when executed with the environment variable
    # ANSIBLE_VAULT_PASSWORD_FILE pointing to a file containing the vault's password
    # This file must be readable by the user executing the test and must contain only
    # the vault's password and nothing else (not even new line characters)

    test_file_passwords_list = dict(os.environ).get('ANSIBLE_VAULT_PASSWORD_LIST', [])
    if isinstance(test_file_passwords_list, six.string_types):
        test_file_passwords_list = test_file_passwords_list.split(',')
    test_file_passwords_list = [ x.strip() for x in test_file_passwords_list if x.strip() != '' ]

# Generated at 2022-06-20 23:41:33.701717
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.constructor import ConstructorError
    import difflib


    ans_constructor_ins = AnsibleConstructor('somedatafile')
    #with pytest.raises(ConstructorError):
    #    ans_constructor_ins.construct_yaml_map()
    # TODO: finish this

# Generated at 2022-06-20 23:41:46.120112
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create the vault lib
    vault = VaultLib(secrets=['ansible'])
    # encrypt the text
    ciphertext = vault.encrypt('test')
    # Create the AnsibleConstructor instance
    yaml = AnsibleConstructor()
    yaml.vault_secrets = ['ansible']
    decrypted = yaml.construct_vault_encrypted_unicode(ciphertext)
    assert decrypted == 'test'
    # Test a different vault lib
    # This will fail until we figure out how to have a vault lib factory in the ansible code
    #vault2 = VaultLib(secrets=['ansible2'])
    #ciphertext2 = vault2.encrypt('test2')
    #decrypted2 = yaml.construct_vault_encrypted_unicode(ciphertext2)
    #

# Generated at 2022-06-20 23:41:54.968036
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml_obj = {'foo': 'bar'}
    result = AnsibleConstructor.construct_yaml_unsafe(yaml_obj)
    assert type(result) == type
    assert result._full_data == yaml_obj

# Generated at 2022-06-20 23:42:02.985943
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.errors import AnsibleParserError

    def test_fun(duplicate_yaml_dict_key, error_type=AssertionError):
        C.DUPLICATE_YAML_DICT_KEY = duplicate_yaml_dict_key

# Generated at 2022-06-20 23:42:05.166004
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert AnsibleConstructor.construct_yaml_seq(['one', 'two', 'three']) == AnsibleSequence(['one', 'two', 'three'])


# Generated at 2022-06-20 23:42:08.989889
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    display.debug('Testing AnsibleConstructor.construct_mapping()')
    assert AnsibleConstructor.construct_mapping({1: 1})[1] == 1



# Generated at 2022-06-20 23:42:10.788694
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    a = AnsibleConstructor()
    n = a.construct_yaml_unsafe()

# Generated at 2022-06-20 23:42:22.630477
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import json

    from six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    c = AnsibleConstructor(file_name='fakefile')
    io = StringIO()
    io.write(u"---\n")
    io.write(u"foo: !unsafe python/object/apply: json.dumps([1,2,3])\n")
    io.write(u"bar: !vault |\n")
    io.write(u"          $ANSIBLE_VAULT;1.2;AES256;blahblah\n")

# Generated at 2022-06-20 23:42:31.096760
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    s = """
---
key1: value1
key2: value2
key3: value3
"""
    c = AnsibleConstructor()
    a = AnsibleLoader(s, c)
    map = a.get_single_data()

    assert isinstance(map, AnsibleMapping)
    assert 3 == len(map)
    assert "value1" == map["key1"]
    assert "value2" == map["key2"]
    assert "value3" == map["key3"]

    assert "<string>" == map.ansible_pos[0]
    assert 1 == map.ansible_pos[1]

# Generated at 2022-06-20 23:42:43.666315
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()
    assert constructor.construct_yaml_unsafe(None) is None
    assert constructor.construct_yaml_unsafe(1) == 1
    assert constructor.construct_yaml_unsafe(1.0) == 1.0
    assert constructor.construct_yaml_unsafe(True) is True
    assert constructor.construct_yaml_unsafe(False) is False
    assert constructor.construct_yaml_unsafe(['a']) == ['a']
    assert constructor.construct_yaml_unsafe(('a', 'b')) == ('a', 'b')
    assert constructor.construct_yaml_unsafe({'a': 'b'}) == {'a': 'b'}
    assert constructor.construct_yaml_unsafe(AnsibleSequence('a')) == Ansible

# Generated at 2022-06-20 23:42:47.300470
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_unsafe("123"), AnsibleUnsafeText)

# Generated at 2022-06-20 23:42:52.931476
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = """
    aws_secret_key: This is a test
    """
    loader = AnsibleLoader(data)
    loader.set_cipher()
    assert (list(loader.load(data))[0]['aws_secret_key'] == 'This is a test')

# Generated at 2022-06-20 23:43:09.107781
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # construct the vault password
    vault_password = 'secret'

    # construct data for the yaml file
    mydata = [{'name': 'test', 'val': '1234'}]
    mydata[0]['secret'] = AnsibleVaultEncryptedUnicode(value=b"hello world", vault=VaultLib(password=vault_password))
    mydata[0]['nested'] = {'key1': 'val1'}
    mydata[0]['nested2'] = {'key2': 'val2'}
    mydata[0]['nested2']['secret'] = AnsibleVaultEncryptedUnicode(value=b"hello world", vault=VaultLib(password=vault_password))

# Generated at 2022-06-20 23:43:12.706304
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    string = {'foo': 'bar'}
    yaml_string = yaml.dump(string)
    assert isinstance(yaml.load(yaml_string, Loader=AnsibleConstructor), dict)

# Generated at 2022-06-20 23:43:21.870788
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    yaml_str = '''
a:
  b: 1
  c: 2
  d: 3
'''
    nodes = yaml.compose(yaml_str)
    assert(AnsibleConstructor.construct_mapping(nodes) ==
           {
               'a': {
                   'b': 1,
                   'c': 2,
                   'd': 3
               }
           })

# Generated at 2022-06-20 23:43:34.412666
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test dict with no duplication
    node = u'tag:yaml.org,2002:map'
    d = AnsibleConstructor()
    val = d.construct_yaml_map(node)
    assert(isinstance(val, AnsibleMapping))
    assert(len(val) == 0)

    # Test dict with duplicate key
    yaml_val = u'foo: 1\nfoo: 2'
    node = yaml.compose(yaml_val)
    d = AnsibleConstructor()
    val = d.construct_yaml_map(node)
    assert(val['foo'] == 2)

    # Test dict with duplicate key and trigger exception
    yaml_val = u'foo: 1\nfoo: 2'
    node = yaml.compose(yaml_val)
    d = Ansible

# Generated at 2022-06-20 23:43:37.952945
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
  a = AnsibleConstructor()
  r = a.construct_yaml_unsafe(u'tag:yaml.org,2002:str')
  assert isinstance(r, AnsibleUnicode)

# Generated at 2022-06-20 23:43:45.165763
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys

    # '0'means a block style, '1' means a flow style
    data = """\
- - a
  - b
- - c
  - d
  - e
- - [f, g]
  - h
    - i
    - j
- - k
  - [l, m]
- - n
  - n
"""
    stream = AnsibleConstructor.construct_yaml_stream(data)
    assert isinstance(stream, AnsibleSequence)
    assert len(stream) == 5

    seq1 = stream[0]
    assert isinstance(seq1, AnsibleSequence)
    assert len(seq1) == 2
    assert seq1[0] == 'a'
    assert seq1[1] == 'b'

    seq2 = stream[1]

# Generated at 2022-06-20 23:43:53.422942
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    yaml_str = """
- name: myhost.example.org
  state: started
- name: otherhost.example.org
  state: stopped
    """
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    print(data)

if __name__ == '__main__':
    test_AnsibleConstructor_construct_yaml_seq()

# Generated at 2022-06-20 23:43:55.408916
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Tests that the constructor raises the right exception when the object is not a MappingNode
    with pytest.raises(AnsibleConstructor.ConstructorError) as excinfo:
        constructor = AnsibleConstructor()
        constructor.construct_yaml_str('test')
    assert 'expected a mapping node, but found scalar' in str(excinfo.value)


# Generated at 2022-06-20 23:44:03.452884
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    import sys

    if sys.version_info[0] < 3:
        reload(sys)
        sys.setdefaultencoding('utf8')

    from ansible.parsing.yaml.loader import AnsibleLoader
    ansibleLoader = AnsibleLoader(None, None)

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            super(TestAnsibleConstructor, self).__init__(file_name, vault_secrets)

        def construct_yaml_seq(self, node):
            return node.value

    # From https://stackoverflow.com/questions/6665715/is-there-a-way-to-specify-order-in-a-python-dictionary
    sequence_test_

# Generated at 2022-06-20 23:44:08.533971
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert AnsibleConstructor().construct_yaml_str(123) == u'123'
    assert AnsibleConstructor().construct_yaml_str(u'123') == u'123'
    assert AnsibleConstructor().construct_yaml_str('123') == u'123'


# Generated at 2022-06-20 23:44:23.948297
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultSecret
    import yaml
    secrets = VaultSecret([VaultSecret.new_secret()])
    constructor = AnsibleConstructor(vault_secrets=secrets)
    data = yaml.load('''
---
foo:
  - !unsafe "{{ dangerous_var }}"
''', Loader=constructor.__class__)
    assert data.get("foo")[0] == "{{ dangerous_var }}"
    from ansible.vars.unsafe_proxy import wrap_var
    assert isinstance(data.get("foo")[0], wrap_var)

test_AnsibleConstructor_construct_yaml_unsafe()

# Generated at 2022-06-20 23:44:29.974378
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = MappingNode(None, None)
    node.value = [
        (MappingNode(None, None), MappingNode(None, None))
    ]
    ansible_constructor = AnsibleConstructor()
    result = ansible_constructor.construct_yaml_seq(node)
    assert isinstance(result, AnsibleSequence)
    assert isinstance(result[0], AnsibleMapping)

# Generated at 2022-06-20 23:44:41.978078
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor

# Generated at 2022-06-20 23:44:47.774798
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import yaml

    yaml.add_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)
    answer = """
hello: !unsafe "{{ my_password }}"
"""
    data = yaml.load(answer)
    assert isinstance(data['hello'], AnsibleUnsafeText)
    assert data['hello'] == '{{ my_password }}'
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-20 23:44:59.472828
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ANSIBLE_CONSTRUCTOR = AnsibleConstructor()
    constructor_mapping = ANSIBLE_CONSTRUCTOR.construct_mapping
    node_mapping = {
        'key': 'value',
        }
    deep = False
    node = {
        'value': [
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ('key', 'value'),
            ],
        }
    mapping = constructor_mapping(node, deep)

# Generated at 2022-06-20 23:45:02.672335
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    class TestConstructor(object):
        pass

    try:
        AnsibleConstructor.construct_yaml_unsafe(TestConstructor())
    except AttributeError as e:
        raise AssertionError("AnsibleConstructor method construct_yaml_unsafe is not working as expected")

# Generated at 2022-06-20 23:45:13.834938
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader

    tests = [
        ("{k1: v1}", {'k1': 'v1'}),
        ("{k1: v1, k2: v2}", {'k1': 'v1', 'k2': 'v2'}),
        ("{k1: v1, k2: v2, k1: v3}", {'k1': 'v3', 'k2': 'v2'}),
    ]

    for d1, d2 in tests:
        b_d1 = to_bytes(d1)

        data = AnsibleLoader(b_d1).get_single_data()

        assert len(data) == len(d2)

# Generated at 2022-06-20 23:45:25.513463
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import types
    import ansible.utils.unsafe_proxy
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleVaultEncryptedUnicode

    constructor = AnsibleConstructor()

    # test a dict
    node_a_yaml = "a: some_value"
    node_a = yaml.load(node_a_yaml)

    data_a = constructor.construct_mapping(node_a, deep=True)
    assert isinstance(data_a, AnsibleMapping)
    assert data_a == {u'a': u'some_value'}

    # test a dict with sub dict
    node_b_yaml = "a: {b: some_value}"

# Generated at 2022-06-20 23:45:34.862778
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    '''
    Test the AnsibleConstructor constructor when id == map

    Construct a YAML document with a map and subclass
    AnsibleConstructor to use the _ansible_file_name() method
    '''

    yaml_doc = '''
    key1: value1
    key2: value2
    key3: value3
    '''

    # Create a subclass of AnsibleConstructor that overrides
    # the _ansible_file_name() method
    class myConstructor(AnsibleConstructor):

        def __init__(self, file_name=None, vault_secrets=None):
            AnsibleConstructor.__init__(self, file_name, vault_secrets)

        def _ansible_file_name(self):
            return '<string>'

    # Get a reference to the construct

# Generated at 2022-06-20 23:45:46.550729
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-20 23:46:14.067002
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    ansible_constructor = AnsibleConstructor()
    data = """---
        a: 1.0
        b: 2.0
        c: string
        d:
          - 1
          - 2
          - 3
        e:
          - a: 1.0
            b: 2.0
            c: string
            d:
              - 1
              - 2
              - 3
          - a: 1.0
            b: 2.0
            c: string
            d:
              - 1
              - 2
              - 3
"""
    print('data = ' + data)
    mapping = yaml.load(data, Loader=AnsibleConstructor)
    for key in mapping:
        print('key = ' + str(key) + 'value = ' + str(mapping[key]))

# Generated at 2022-06-20 23:46:20.952101
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    instance = AnsibleConstructor()

    # Test a byte string
    b_str = b'foo'
    yaml_str_node = instance.construct_yaml_str(b_str)
    assert isinstance(yaml_str_node, AnsibleUnicode)
    assert isinstance(yaml_str_node, str)
    assert yaml_str_node == b_str.decode()

    # Test a string
    unicode_str = u'foo'
    yaml_str_node = instance.construct_yaml_str(unicode_str)
    assert isinstance(yaml_str_node, AnsibleUnicode)
    assert isinstance(yaml_str_node, str)
    assert yaml_str_node == unicode_str



# Generated at 2022-06-20 23:46:31.663854
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_text = u'---\n- foo\n- bar\n'

    # Read in yaml using the AnsibleConstructor and dump it right back out
    # to get yaml text with objects converted to native python strings
    yaml_loader = yaml.Loader(yaml_text)
    yaml_loader.check_node()
    yaml_data = yaml_loader.get_single_data()
    yaml_out = yaml.dump(yaml_data, default_style='', default_flow_style=False)

    # Dump original yaml to get yaml text with objects converted to native python strings
    yaml_loader = yaml.Loader(yaml_text)
    yaml_loader.check_node()
    yaml_data = yaml_loader.get_single_data()
    native

# Generated at 2022-06-20 23:46:42.468286
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_yaml = '''
k:
- 1
- 2
'''

    test_yaml_list = [
        {u'k': [1, 2]}
    ]

    test_yaml_list_Ansible = [
        {u'k': [1, 2]}
    ]

    test_yaml_list_Ansible_seq = [
        {u'k': AnsibleSequence([1, 2])}
    ]

    test_yaml_list_bak = test_yaml_list
    test_yaml_list_Ansible_bak = test_yaml_list_Ansible
    test_yaml_list_Ansible_seq_bak = test_yaml_list_Ans

# Generated at 2022-06-20 23:46:50.689028
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    obj = AnsibleConstructor().construct_yaml_unsafe('foo')
    if obj.__class__ is not AnsibleUnsafeText:
        raise AssertionError("expected an AnsibleUnsafeText object, but got %s" % obj.__class__)
    if obj.ansible_unsafe_value is not u'foo':
        raise AssertionError("expected an value of 'foo', but got '%s'" % obj.ansible_unsafe_value)

# Generated at 2022-06-20 23:46:55.890287
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from test.support.yaml_helper import YamlTestUtils
    from ansible.tests.unit.test_utils import ANSIBALLZ_VARS_DATA

    # GIVEN:
    data = dict(
        a=u'b',
        c=u'd',
        e=dict(
            f=dict(
                g=u'h'
            )
        ),
    )

    # WHEN:
    stream = yaml.dump(data, Dumper=AnsibleDumper)

# Generated at 2022-06-20 23:47:02.018734
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible import release
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import wrap_var
    import ansible.errors

    ansible_version = release.__version__

    test_obj1 = {'a': 'b', 'c': 'd'}

    test_obj2 = {}
    test_obj2['foo'] = test_obj1
    test_obj2['bar'] = test_obj1

    test_obj3 = [{'a': 'b', 'c': 'd'}, {'a': 'b', 'c': 'd'}]

    # Test that duplicate keys are treated as a problem
    test_obj4 = {"a":1, "b":2, "c":3, "a":4}

    test_obj5

# Generated at 2022-06-20 23:47:07.578209
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor()
    assert isinstance(c.construct_mapping(None), dict)
    assert isinstance(c.construct_mapping(MappingNode(tag='tag:yaml.org,2002:map')), dict)
    assert isinstance(c.construct_mapping(MappingNode(tag='tag:yaml.org,2002:map', value=[('a', 'b')])), dict)

# Generated at 2022-06-20 23:47:18.892299
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Test when type is something we expect
    # NOTE: the reason we use a dict here and not a dict subclass is that
    #       pyyaml will call us back with the same object (i.e.: the dict)
    #       which means that if we return a subclass, we will be called back
    #       with a dict, which will raise a TypeError as 'isinstance(node, dict)' fails
    test_data = {'foo': 'bar'}
    ac = AnsibleConstructor()
    ret = ac.construct_yaml_unsafe(test_data)
    assert isinstance(ret, dict)
    assert ret.__class__.__name__ == 'dict'
    assert ret['foo'] == 'bar'

    # Test when type is something we do not expect
    test_data = 'hello'
    ac = AnsibleConstruct

# Generated at 2022-06-20 23:47:24.038799
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_obj = AnsibleConstructor()
    source = b'{one: 1, two: 2, three: 3}.yaml'
    node = yaml.composer.Composer(yaml.reader.Reader(source)).get_single_node()
    assert isinstance(next(test_obj.construct_yaml_map(node)), AnsibleMapping)

# Generated at 2022-06-20 23:48:05.251582
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml_data = """
    - hosts: localhost
      tasks:
        - name: test yaml
          script: test.sh
          environment: "{{ lookup('env', 'JAVA_HOME') | quote }}"
    """
    import yaml
    constructor = AnsibleConstructor()
    data = yaml.load(yaml_data, Loader=yaml.Loader)
    assert data[0]['environment'] == '"/usr/local/java"'

# Generated at 2022-06-20 23:48:15.537492
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml


# Generated at 2022-06-20 23:48:27.719704
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class Node():
        pass

    node = Node()
    node.start_mark = Node()
    node.start_mark.column = 0
    node.start_mark.line = 0
    node.start_mark.name = "test.yml"
    node.id = "vault"

# Generated at 2022-06-20 23:48:32.407340
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    test_yaml = '''
    ---
    - !unsafe "{{ foo }}"
    ...
    '''
    data = yaml.load(test_yaml, Loader=AnsibleConstructor)
    assert len(data) == 1

# Generated at 2022-06-20 23:48:40.641671
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    :avocado: tags=requires_ansible_v2_3
    """
    import ansible.parsing.vault
    import tempfile
    import yaml
    file_name = tempfile.NamedTemporaryFile(delete=False)
    file_name.write(b"a: b\nc: d\ne: {f: g}\nh: i\nk: l\nl: m\nl: n\n")
    file_name.seek(0)
    vault_secrets = ['1', '2', '3']
    temp_vault_id = ansible.parsing.vault.VaultLib.get_vault_password(password_files=vault_secrets)

# Generated at 2022-06-20 23:48:52.685971
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = u'my_vault_password'
    vault_secrets = [ vault_password ]

# Generated at 2022-06-20 23:49:02.116326
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.resolver import Resolver
    from ansible.parsing.vault import VaultLib as Vault
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.hashing import secure_hash
    from ansible.utils.unsafe_proxy import wrap_var

    # Test data
    plain_text = 'Ansible is Awesome!'
    passwords = 'ansible'

    # Create Vault object
    vault_obj = Vault(secrets=[passwords])

    # Encryption
    version, ciphertext_data = vault_obj.encrypt(plain_text)

    # Construct yaml node (tag is

# Generated at 2022-06-20 23:49:13.621915
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # pylint: disable=unused-variable,unused-argument
    from ansible.parsing.yaml._yaml import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnicode, AnsibleSequence, AnsibleVaultEncryptedUnicode

    def test_constructor(loader, node):
        obj = AnsibleBaseYAMLObject.__new__(AnsibleBaseYAMLObject)
        obj.ansible_pos = node.start_mark
        obj.my_attribute = 42
        return obj

    def test_constructor_with_value(loader, node, value1=None, value2=None):
        obj = AnsibleBaseYAMLObject.__new__(AnsibleBaseYAMLObject)
        obj.ans

# Generated at 2022-06-20 23:49:20.640655
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Assign some test values to the method parameters
    node = object()
    vault_secrets = [b'hello']
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = vault_secrets

    # Invoke method
    ansible_constructor.construct_vault_encrypted_unicode(node)

    # Confirm that the vault has been initialized
    assert ansible_constructor._vaults['default'].secrets == vault_secrets

# Generated at 2022-06-20 23:49:28.052955
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    real_yaml_seq = AnsibleConstructor.construct_yaml_seq

    def mock_construct_yaml_seq(self_object, node):
        return real_yaml_seq(self_object, node)

    AnsibleConstructor.construct_yaml_seq = mock_construct_yaml_seq
