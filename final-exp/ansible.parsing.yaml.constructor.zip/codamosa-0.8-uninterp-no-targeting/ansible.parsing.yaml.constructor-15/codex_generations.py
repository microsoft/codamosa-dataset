

# Generated at 2022-06-20 23:40:28.213075
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    mapping = AnsibleConstructor.construct_mapping(node, deep=False)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping

# Generated at 2022-06-20 23:40:35.829595
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Test if method construct_yaml_map of class AnsibleConstructor
    successfully returns a dict with a tuple as key.
    """
    loader = AnsibleConstructor()
    node = '{(1, 1): bar, foo: bar}'
    parsed_yaml = loader.construct_yaml(node)
    expected = {(1, 1): 'bar', 'foo': 'bar'}
    assert parsed_yaml == expected

# Generated at 2022-06-20 23:40:48.604415
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    input = [
        {'value': 'some-command', 'id': 'str'},
        {'value': 'some-command', 'id': 'str', 'anchor': 'foo'}
    ]

    expected_output = [
        u"ansible.module_utils.unsafe_proxy.AnsibleUnsafeText('some-command')",
        u"ansible.module_utils.unsafe_proxy.AnsibleUnsafeText('some-command')"
    ]

    constructor = AnsibleConstructor()

    output = [constructor._construct_yaml_unsafe(dict_item) for dict_item in input]
    assert [repr(item) for item in output] == expected_output


# Generated at 2022-06-20 23:40:57.325436
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """Test the behavior of construct_yaml_map for objects of class AnsibleConstructor"""
    from yaml.nodes import MappingNode
    from yaml.reader import Reader
    import io

    yaml_data = '{ a: 1 }'
    node = MappingNode([], yaml_data)

    # yaml.constructor.BaseConstructor._reader.peek() reads the next character in the input stream
    # and returns an integer representing that character's value as defined by Unicode
    # (for example, the character 'a' is represented by the integer 97).
    # So the following loop will advance the stream to the character 'a'
    while (node.start_mark.pointer - 1) != ord(yaml_data[0]):
        Reader._reader.peek()

    c = AnsibleConstructor()

# Generated at 2022-06-20 23:41:09.963260
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:41:21.613051
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_text = u"""
- name: foo
  bar:
     name: baz
  bam:
     name: not_baz
   """

    (data, errors) = load(yaml_text)
    assert 'foo' == data[0]['name']
    assert 'bar' in data[0]
    assert 'name' in data[0]['bar']
    assert 'baz' == data[0]['bar']['name']
    assert 'bam' in data[0]
    assert 'name' in data[0]['bam']
    assert 'not_baz' == data[0]['bam']['name']
    assert errors is None or len(errors) == 0

# Generated at 2022-06-20 23:41:33.662514
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml.nodes as yaml_nodes
    import yaml.constructor as yaml_constructor
    import yaml.reader as yaml_reader
    import yaml.scanner as yaml_scanner
    import yaml.parser as yaml_parser

    test_file = "test_1.yml"
    constructor = AnsibleConstructor(file_name=test_file)

    # Test dictionary with one item
    input_dict = {'key1':'value1'}
    node_list = list()
    for key, val in input_dict.items():
        key_node = yaml_nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=key)

# Generated at 2022-06-20 23:41:46.107951
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import unittest
    import yaml

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self._constructor = AnsibleConstructor()

        def tearDown(self):
            pass

        def test_construct_yaml_map(self):
            node = yaml.nodes.MappingNode(tag='tag:yaml.org,2002:map', value=[])
            obj = self._constructor.construct_yaml_map(node)
            self.assertIsInstance(obj, AnsibleMapping, "construct_yaml_map is not creating AnsibleMapping object")

        def test_construct_mapping(self):
            node = yaml.nodes.MappingNode(tag='tag:yaml.org,2002:map', value=[])
            obj = self._

# Generated at 2022-06-20 23:41:58.516526
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # This test is a placeholder.  It is not intended to cover the full
    # functionality.  It is just to test the ability to overload the
    # yaml.constructor.SafeConstructor.
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from collections import defaultdict

    class TestNode:
        id = u'test'

        def __init__(self, start_mark=None, end_mark=None):
            self.start_mark = start_mark
            self.end_mark = end_mark

    class TestMark:
        def __init__(self, name=None, line=None, column=None):
            self.name = name
            self.line = line
            self.column = column


# Generated at 2022-06-20 23:42:11.733633
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestYAMLObject(AnsibleBaseYAMLObject):
        '''
        This class tests the ability of AnsibleConstructor to handle
        instances of class AnsibleBaseYAMLObject.
        '''
        yaml_loader = AnsibleConstructor
        yaml_dumper = AnsibleDumper

        def __init__(self, a, b):
            self.a = a
            self.b = b

        @staticmethod
        def to_yaml(representer, node):
            return representer.represent_dict(dict(a=node.a, b=node.b))


# Generated at 2022-06-20 23:42:20.866226
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert AnsibleConstructor.construct_yaml_seq(['foo', 'bar']) == ['foo', 'bar']

# Generated at 2022-06-20 23:42:29.915671
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import ansible.parsing.yaml.objects
    import json
    ac = AnsibleConstructor()
    # This is a python dict that contains a nested dict with a single key
    # The value of the key is 'foo bar', and the value is quoted
    yaml_str = '''{'test': {'test': "foo bar"}}'''
    python_data = json.loads(yaml_str)
    ansible_data = ac.construct_yaml_map(yaml_str)
    assert isinstance(ansible_data, ansible.parsing.yaml.objects.AnsibleBaseYAMLObject)
    assert ansible_data.ansible_type == 'dict'

# Generated at 2022-06-20 23:42:41.902446
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    class DumpLoader(yaml.SafeLoader):
        pass

    DumpLoader.add_constructor(u'tag:yaml.org,2002:map', AnsibleConstructor.construct_yaml_map)

    from io import StringIO
    class StringIOWrapper(StringIO):
        @property
        def name(self):
            return '<file.yml>'

    the_str = ''
    the_str += 'a: 1\n'
    the_str += 'b: 2\n'
    the_str += 'c: 3\n'

    # Positive tests (should not raise an exception)
    s = StringIOWrapper(the_str)
    data = yaml.load(s, Loader=DumpLoader)
    assert data["a"] == 1

# Generated at 2022-06-20 23:42:55.260877
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    # construct a plain string
    data = yaml.load(u'foo', Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleUnicode)
    assert data == u'foo'

    # construct a plain string with non-ascii characters
    data = yaml.load(u'\u2665', Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleUnicode)
    assert data == u'\u2665'

    # construct a plain string with a unicode tag
    data = yaml.load(u'!python/unicode \u2665', Loader=AnsibleConstructor)

# Generated at 2022-06-20 23:43:08.132561
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import textwrap
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    data = textwrap.dedent("""\
        foo: bar
        foo: baz
        - {a: b}""")

    # value from first key-value pair
    first_value = 'bar'

    # value from second key-value pair
    second_value = 'baz'

    # default behavior 'warn' level
    c = AnsibleConstructor()
    m = c.construct_yaml(data)
    assert isinstance(m, list)
    assert isinstance(m[0], AnsibleMapping)

    values = list(m[0].values())
    assert first_value in values
    assert second_value in values
    assert first_value != values[1]
    assert first

# Generated at 2022-06-20 23:43:16.835921
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import tempfile

    # Create a temporary file
    tmp = None
    tmp_name = None

# Generated at 2022-06-20 23:43:30.866218
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    data = {
        'name': 'John Doe',
        'age': 23,
        'foods': [u'banana', u'orange', u'apple']
    }

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    dumper = AnsibleDumper(width=1000)
    yaml = dumper.dump(data)

    import io
    stream = io.StringIO(yaml)
    loader = AnsibleLoader(stream)

    data2 = loader.get_single_data()

    assert data2
    assert isinstance(data2, dict)
    assert isinstance(data2['name'], AnsibleUnicode)
    assert isinstance(data2['age'], int)

# Generated at 2022-06-20 23:43:40.698318
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-20 23:43:53.902348
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    print(__file__)
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(AnsibleConstructorTester('test_construct_yaml_map'))
    suite.addTest(AnsibleConstructorTester('test_construct_mapping'))
    suite.addTest(AnsibleConstructorTester('test_construct_yaml_str'))
    suite.addTest(AnsibleConstructorTester('test_construct_yaml_seq'))
    suite.addTest(AnsibleConstructorTester('test_node_position_info'))
    unittest.TextTestRunner(verbosity=2).run(suite)

ALIAS_KEY = u'!ALIAS-SOME_RANDOM_KEY'

# Generated at 2022-06-20 23:44:00.731982
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self):
            self._ansible_file_name = ""
            self._vaults = {}

    test_yaml = """
---
- hosts: localhost
- hosts: cloud_servers
  remote_user: "root"
  run_once: True
"""

    load_yaml = yaml.load(test_yaml, Loader=TestAnsibleConstructor)
    assert load_yaml[1].hosts == 'cloud_servers'

# Generated at 2022-06-20 23:44:20.245441
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    if sys.version_info < (2, 7):
        # Test skipped because of the missing Lib/ast.py path
        # Test skipped because of the missing Lib/ast.py path
        return
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ast import literal_eval

    s = 'pwd'
    data = AnsibleLoader(s).get_single_data()
    assert isinstance(data, AnsibleUnsafe)
    assert literal_eval(repr(data)) == s
    assert str(data) == s
    assert to_native(data) == s

# Generated at 2022-06-20 23:44:31.345859
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    def test_construct_yaml_map(self):
        ansible = AnsibleConstructor()
        data = ansible.construct_yaml_map({'key': 'value'})
        assert data.get('key') == 'value'

    def test_construct_yaml_seq(self):
        ansible = AnsibleConstructor()
        data = ansible.construct_yaml_seq({'key': 'value'})
        assert data.get('key') == 'value'

    def test_construct_yaml_str(self):
        ansible = AnsibleConstructor()
        data = ansible.construct_yaml_str({'key': 'value'})
        assert data.get('key') == 'value'

    def test_construct_yaml_unsafe(self):
        ansible = AnsibleConstructor()


# Generated at 2022-06-20 23:44:43.151151
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    yaml_str = """
    ---
        # This is a list
        - name: foo
          # This is a dictionary
          foo:
            someval: value
            unsafe: !unsafe |
              This is some unsafe data
    """


# Generated at 2022-06-20 23:44:50.318303
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    def test_as_expected(node, expect):
        assert AnsibleConstructor().construct_yaml_str(node) == expect
    try:
        test_as_expected(None, '')
    except TypeError as e:
        if "None" in str(e):
            pass

    test_as_expected(u'value', u'value')
    test_as_expected(u'value\n', u'value\n')
    test_as_expected(u'value\r\n', u'value\r\n')
    test_as_expected(u'value\r', u'value\r')
    test_as_expected(u'value\t', u'value\t')
    test_as_expected(u'value\u2028', u'value\u2028')
    test_as_

# Generated at 2022-06-20 23:45:01.070555
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    import unittest

    DATA = b"""
a : 1
b :
 - 1
 - 2
c :
  1 : b
  2 : d
"""

    class TestConstructor(unittest.TestCase):
        def test(self):
            data = AnsibleLoader(DATA, file_name=os.path.join(os.path.dirname(__file__), os.path.basename(__file__))).get_single_data()
            assert data == {
                u'a': 1,
                u'b': [1, 2],
                u'c': {
                    1: u'b',
                    2: u'd',
                },
            }

    unittest.main()

# Generated at 2022-06-20 23:45:11.801587
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    from yaml import load
    import copy

    input_data = """
    - &CENTER {x: 1, y: 2}
    - &LEFT {x: 0, y: 2}
    - &BIG {r: 10}
    - &SMALL {r: 1}

    # All the following maps are equal:

    - # Explicit keys
      x: 1
      y: 2
      r: 10
      label: center/big

    - # Merge one map
      << : *CENTER
      r: 10
      label: center/big

    - # Merge multiple maps
      << : [ *CENTER, *BIG ]
      label: center/big

    - # Override
      << : [ *BIG, *LEFT, *SMALL ]
      x: 1
      label: center/big
    """



# Generated at 2022-06-20 23:45:13.155948
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = 0
    with pytest.raises(ConstructorError, match='expected a mapping node, but found scalar'):
        AnsibleConstructor().construct_yaml_map(node)


# Generated at 2022-06-20 23:45:24.884068
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    class Node:
        def __init__(self, v):
            self.v = v

        def id(self):
            return self.v

    AC = AnsibleConstructor()
    AC.construct_object = lambda x, y=None: 'python/' + x.v

    # Basic test
    x = Node('unicode')
    y = AC.construct_yaml_unsafe(x)
    assert y == wrap_var('python/unicode')

    # Test that .id method is called
    AC.construct_object = lambda x, y=None: 'python/' + x.id()
    x = Node('unicode')
    y = AC.construct_yaml_unsafe(x)
    assert y == wrap_var('python/unicode')

    # Test that the method is called even if
    # the

# Generated at 2022-06-20 23:45:25.474024
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    pass

# Generated at 2022-06-20 23:45:30.898444
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    a_constructor = AnsibleConstructor(file_name=None)

    a_loader = AnsibleLoader(a_constructor, loader=loader)

    string = to_bytes('Hello world')
    a_loader.construct_yaml_str(string)

    assert isinstance(a_loader.get_single_data(), AnsibleUnicode)

# Generated at 2022-06-20 23:45:42.955708
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    my_constructor = AnsibleConstructor()
    my_constructor.construct_yaml_map()
    my_constructor.construct_mapping()
    my_constructor.construct_yaml_str()
    my_constructor.construct_vault_encrypted_unicode()
    my_constructor.construct_yaml_seq()
    my_constructor.construct_yaml_unsafe()
    my_constructor.construct_vault_encrypted_unicode()

# Generated at 2022-06-20 23:45:53.426583
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_source = '''
        one:
          one: 1
        two:
          two: 2
    '''
    fake_file_name = 'foo'
    constructor = AnsibleConstructor(file_name=fake_file_name)
    from yaml import load
    from ansible.module_utils._text import to_text
    data = load(to_text(yaml_source), Loader=constructor)
    assert data.get('one').ansible_pos == ('foo', 3, 1)
    assert data.get('two').ansible_pos == ('foo', 7, 1)
    assert data.get('three') is None
    assert data.ansible_pos == ('foo', 1, 1)
    assert data.get('one').ansible_line_number == 3

# Generated at 2022-06-20 23:46:05.029498
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.parsing.yaml.objects
    yaml_map = ansible.parsing.yaml.objects.AnsibleMapping()

    class MockNode(object):
        def __init__(self, value=None):
            self.value = value

    class MockValueNode(object):
        def __init__(self, value=None):
            self.start_mark = 1
            self.id = value

    class MockKeyNode(object):
        def __init__(self, value=None):
            self.start_mark = 1
            self.id = value

    # Test case: construct_mapping when constructor.flatten_mapping(node) call raises error
    class MockConstructor(object):
        def flatten_mapping(self, node):
            raise Exception()

    constructor = Ansible

# Generated at 2022-06-20 23:46:15.624520
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor(file_name='test_AnsibleConstructor_construct_mapping')
    from yaml.nodes import SequenceNode, ScalarNode

# Generated at 2022-06-20 23:46:27.121366
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    the_str = 'sloppy str'
    the_dict = {u'a': 1, u'b': 2}

    # test a few scenarios
    for x in [the_str, the_dict]:
        loader = AnsibleLoader(x)

        assert isinstance(loader.get_single_data(), AnsibleUnicode)

    # test a few scenarios
    for x_bytes in [to_bytes(the_str), to_bytes(the_dict)]:
        loader = AnsibleLoader(x_bytes)

        assert isinstance(loader.get_single_data(), AnsibleUnicode)

    # test an AnsibleMapping
   

# Generated at 2022-06-20 23:46:38.265602
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.parser import Parser
    from yaml.scanner import Scanner

    content = b"""
    abc: 123
    def: [456,789]
    """
    # Read through the YAML content and check that the line and column
    # information matches what we expect

    loader = AnsibleConstructor(file_name='/foo/bar')

    parser = Parser(Scanner(content))
    docs = list(parser.get_documents())
    parsed = loader.construct_document(docs[0])
    assert parsed.ansible_pos == ('/foo/bar', 1, 0)

    parser = Parser(Scanner(content))
    docs = list(parser.get_documents())
    parsed = loader.construct_document(docs[1])

# Generated at 2022-06-20 23:46:44.240066
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    yaml_str = '''
-
  one: 1
  two: 2
-
  three: 3
  four: 4
'''
    data = yaml.load(yaml_str)
    assert data[0]['one'] == 1
    assert data[0]['two'] == 2
    assert data[1]['three'] == 3
    assert data[1]['four'] == 4
    assert data[0].ansible_pos == ('<unicode string>', 1, 1)

# Generated at 2022-06-20 23:46:56.999493
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    class AnsibleConstructor(SafeConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            self._ansible_file_name = file_name
            super(AnsibleConstructor, self).__init__()
            self._vaults = {}
            self.vault_secrets = vault_secrets or []
            self._vaults['default'] = VaultLib(secrets=self.vault_secrets)

        def construct_yaml_map(self, node):
            data = AnsibleMapping()
            yield data
            value = self.construct_mapping(node)
            data.update(value)
            data.ansible_pos = self._node_position_info(node)


# Generated at 2022-06-20 23:47:09.276964
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()
    class YAMLNode:
        pass
    node = YAMLNode()
    node.value = ""
    node.tag = u'!foo'
    node.start_mark = YAMLNode()
    node.start_mark.index = 0
    node.start_mark.line = 1
    node.start_mark.column = 0
    node.start_mark.buffer = ""
    node.start_mark.name = ""
    node.end_mark = YAMLNode()
    node.end_mark.index = 0
    node.end_mark.line = 1
    node.end_mark.column = 0
    node.end_mark.buffer = ""
    node.end_mark.name = ""
    node.id = None
    constructed = constructor.construct_yaml

# Generated at 2022-06-20 23:47:21.494603
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    '''
    Make sure unsafe objects get wrapped properly.
    '''
    import sys
    import re

    # The string in the YAML file below that triggers the
    # construct_yaml_unsafe method.
    class_name = "!unsafe "

    code = '''
    - name: test constructor
      debug:
        msg: !unsafe { { "__builtins__": "test" } }
    '''

    # Wrap the code using the YAML class.
    yaml_obj = yaml.load(code)

    # Find the string in the serialized YAML object.
    object_str = yaml.dump(yaml_obj)
    m = re.search(class_name + "(.*)", object_str)

    # Make sure the string was found.
    assert m is not None



# Generated at 2022-06-20 23:47:43.388187
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.unsafe_proxy import wrap_var
    test_string = u"!!python/unicode 'hello'"
    c = AnsibleConstructor()
    wrapped_test_string = wrap_var(test_string)
    assert wrapped_test_string == c.construct_yaml_unsafe(c.construct_yaml_str(test_string))
    assert isinstance(wrapped_test_string, AnsibleUnsafeText)

# Generated at 2022-06-20 23:47:53.391677
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # case 1:
    # test if ansible_pos will be returned while the node has no position info
    node = AnsibleMapping()
    ac = AnsibleConstructor(file_name=None, vault_secrets=None)
    seq = ac.construct_yaml_seq(node)
    assert seq.ansible_pos == (None, None, None)

    # case 2:
    # test if ansible_pos will be returned while the node has position info
    node.start_mark.column = 10
    node.start_mark.line = 10
    node.start_mark.name = "ansible_test"
    seq = ac.construct_yaml_seq(node)
    assert seq.ansible_pos == ("ansible_test", 11, 11)



# Generated at 2022-06-20 23:48:04.634648
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml import AnsibleLoader
    class Test(object):
        pass

    loader = AnsibleLoader(None)
    constructor = AnsibleConstructor(None, None)
    yaml = ("---\n"
            "key: value\n"
            "key2: value2\n"
            "key: value3\n"
            "key2: value4\n")
    cfg = Test()
    setattr(cfg, "test", yaml)

    data = loader.load(cfg)

    # Use the constructor to return our data (it will call construct_mapping)
    constructor.constructor_data = {}
    constructor.construct(data)
    assert constructor.constructor_data['test']['key'] == 'value4'

# Generated at 2022-06-20 23:48:07.908097
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    d = AnsibleConstructor().construct_mapping(MappingNode())
    assert d
    assert isinstance(d, AnsibleMapping)
    assert isinstance(d, dict)

# Generated at 2022-06-20 23:48:16.635970
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml_data = '''
    a: b
    c:
      d: !unsafe 123
      f: !unsafe "abc"
    '''
    yaml_obj = yaml.load(yaml_data, AnsibleConstructor)
    assert set(yaml_obj.keys()) == set(['a', 'c'])
    assert yaml_obj['a'] == 'b'
    assert isinstance(yaml_obj['c'], AnsibleMapping)
    assert set(yaml_obj['c'].keys()) == set(['d', 'f'])
    assert yaml_obj['c']['d'] == 123
    assert yaml_obj['c']['f'] == "abc"

# Generated at 2022-06-20 23:48:28.633498
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Empty yaml mapping
    expected_yaml_list = [{}]
    for yaml_list in expected_yaml_list:
        # Dump yaml_list to string
        yaml_str = yaml.dump(yaml_list, default_flow_style=None)
        # Load string to object
        yaml_object = yaml.load(yaml_str, Loader=AnsibleConstructor)
        # Check if test is pass
        assert yaml_object == yaml_list

    # Non-empty yaml mapping

# Generated at 2022-06-20 23:48:31.853933
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[],
                       flow_style=False, start_mark=None, end_mark=None)

# Generated at 2022-06-20 23:48:35.625789
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    value = to_bytes('{"item1": "value1", "item2": "value2"}')
    yaml = '{{ value }}'
    node = yaml.safe_load(yaml)
    ac = AnsibleConstructor()
    ac.construct_yaml_str(node)

# Generated at 2022-06-20 23:48:42.278512
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultSecret
    password = VaultSecret('password')
    vault_password_secrets = [password]
    construct_vault_encrypted_unicode = AnsibleConstructor(vault_secrets=vault_password_secrets).construct_vault_encrypted_unicode
    # result should be an AnsibleVaultEncryptedUnicode object
    result = construct_vault_encrypted_unicode
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    # and wrap_var(result) should be
    assert isinstance(wrap_var(result), AnsibleVaultEncryptedUnicode)
    # but the call itself should throw an exception because there is no vault password

# Generated at 2022-06-20 23:48:51.337671
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Assigning parameters for unit test of method construct_yaml_seq of class AnsibleConstructor
    file_name = None
    vault_secrets = None

    # Obtaining the target method for unit test
    target_method = getattr(AnsibleConstructor, 'construct_yaml_seq')

    # Calling the method with arguments
    target = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    node = C
    result = target_method(target, node)
    assert result is None



# Generated at 2022-06-20 23:49:16.127970
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import load
    import io

    import pdb; pdb.set_trace()

    io_obj = io.StringIO(u"""
    - aaa
    - bbb
    - ccc
    """)
    data = load(io_obj, Loader=AnsibleConstructor)
    import pdb; pdb.set_trace()


# Generated at 2022-06-20 23:49:22.278091
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    the_yaml_in = u'!unsafe 123'
    the_yaml_out = wrap_var(123)
    the_constructor = AnsibleConstructor()
    the_constructor.construct_yaml_unsafe(yaml.nodes.ScalarNode(u'tag:yaml.org,2002:int', u'123', None, None, None)) == the_yaml_out

# Generated at 2022-06-20 23:49:28.983258
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    value = [
        {
            'name': 'test1',
            'key': 'value1',
        },
        {
            'name': 'test2',
            'key': 'value2',
        }
    ]

    # dump the value, then load into AnsibleConstructor
    constructor = AnsibleConstructor()
    yaml = AnsibleDumper().dump(value)
    data = constructor.get_single_data(yaml)

    # verify that data is an AnsibleSequence
    assert isinstance(data, AnsibleSequence), 'data is not an AnsibleSequence'

    # verify that the value of the AnsibleSequence matches the expected value

# Generated at 2022-06-20 23:49:38.777847
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_data = {}
    test_data['a'] = 'b'
    test_data['a1'] = 'b1'
    test_data['a'] = 'c'
    test_data['a'] = 'd'
    test_data['a'] = 'e'

    yaml_str_data = '{a: b, a1: b1, a: c, a: d, a: e}'
    yaml_data = yaml.load(yaml_str_data)
    assert test_data != yaml_data

    yaml_data1 = AnsibleConstructor.construct_mapping(yaml_data, deep=False)
    assert test_data == yaml_data1

# Generated at 2022-06-20 23:49:43.269299
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = u'testval: 1'
    data = AnsibleConstructor().construct_yaml_map(yaml.compose(yaml_data))
    assert isinstance(data, AnsibleMapping)
    assert list(data.keys()).pop() == 'testval'
    assert list(data.values()).pop() == 1

# Generated at 2022-06-20 23:49:45.932666
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    loader = AnsibleConstructor()
    data = loader.construct_yaml_seq([1, 2, 3])
    assert list(data) == [1, 2, 3]



# Generated at 2022-06-20 23:49:46.483840
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

# Generated at 2022-06-20 23:49:51.193855
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner

    ac = AnsibleConstructor()

    def _s(s):
        return to_bytes(s)

    def _getval(s):
        parser = Parser(Reader(_s(s)))
        scanner = Scanner(parser)
        composer = Composer(scanner)
        return ac.construct_yaml_str(composer.get_single_node())

    assert _getval("test") == to_bytes("test")

# Generated at 2022-06-20 23:49:57.801671
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from collections import OrderedDict
    orderedDict = OrderedDict()
    orderedDict['a'] = 'b'
    orderedDict['c'] = 'd'
    orderedDict['e'] = 'f'
    result = yaml.load(yaml.dump(orderedDict, default_flow_style=False, Dumper=yaml.SafeDumper), Loader=yaml.SafeLoader)
    assert(result == orderedDict)

# Generated at 2022-06-20 23:49:59.764770
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    assert AnsibleConstructor().construct_yaml_unsafe({"id": "object"}) == {"id": "object"}