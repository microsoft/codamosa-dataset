

# Generated at 2022-06-20 23:40:33.122952
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # mock a yaml node
    class MockNode():
        def __init__(self):
            self.value = []
            self.start_mark = None
        def dump(self, dumper):
            return u''

    # build a node with duplicate keys
    my_node = MockNode()
    my_node.value.append((MockNode(), MockNode()))
    my_node.value.append((MockNode(), MockNode()))
    my_node.value[0][0].value = 'key'
    my_node.value[0][1].value = 'value'
    my_node.value[1][0].value = 'key'
    my

# Generated at 2022-06-20 23:40:38.400865
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Set it up first
    from ansible.parsing.yaml.loader import AnsibleLoader
    ldr = AnsibleLoader(None, None)
    # Test the constructor does not raise an exception
    ldr.get_constructor()

if __name__ == '__main__':
    test_AnsibleConstructor()

# Generated at 2022-06-20 23:40:40.798156
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    if sys.version_info[0] > 2:
        assert issubclass(AnsibleConstructor, SafeConstructor)
    else:
        assert issubclass(AnsibleConstructor, SafeConstructor)

# Generated at 2022-06-20 23:40:46.752950
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import yaml
    obj = yaml.load('{"a": 1, "b": 2, "a": 3}', Loader=AnsibleConstructor)
    assert obj.ansible_pos[0] == '<unicode string>'
    assert obj.get('a') == 3
    assert obj.get('b') == 2


# Generated at 2022-06-20 23:40:58.578131
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    data = """
---
# this will be ignored
---
# this will be ignored
- a
- b
# this will be ignored
...
# this will be ignored
__gaia__: should be ignored
ansible_pos:
- file1
- 1
- 1
c:
- 2
- d
ansible_pos:
- file2
- 2
- 1
e:
ansible_pos:
- file3
- 3
- 1
  f:
  - 3.1
  - 3.2
  - 3.3
ansible_pos:
- file4
- 4
- 1
  g:
  - 4.1
  - 4.2
  - 4.3
  ansible_pos:
  - file5
  - 5
  - 1
  """
   

# Generated at 2022-06-20 23:41:10.656686
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # SETUP
    vault = VaultLib(secrets=['testpassword'])
    vault.encrypted_data = '$ANSIBLE_VAULT;1.1;AES256\n61646d696e61726b206d792077696c6c2063616e63656c6c20746865726520616e6420616e\n63696e6f2063616e206265207265616c20616e636f6d65206e6f6d652e0a\n'
    # TEST
    ansible_c_u = AnsibleConstructor()
    ansible_c_u._vaults['test'] = vault
    ansible_c_u.vault_secrets = ['testpassword']
    # Add constructor

# Generated at 2022-06-20 23:41:24.519193
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    from ansible.parsing.vault import VaultLib

    yaml_text = "---\n" \
                "- 1\n" \
                "- 2\n" \
                "- 3\n" \
                "...\n"

    data = yaml.load(yaml_text, Loader=AnsibleLoader)
    assert isinstance(data, list)
    assert data == [1, 2, 3]

    yaml_text = "---\n" \
                "foo:\n" \
                "  - 1\n" \
                "  - 2\n" \
                "  - 3\n" \
                "...\n"


# Generated at 2022-06-20 23:41:35.046332
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import ScalarNode, MappingNode
    from yaml.composer import Composer

    class DummyComposer(Composer):
        def compose_document(self):
            node = self.get_node()
            # A mapping node with two key-value pairs
            node.value = [DummyNode(key='key1', value='val1'),
                          DummyNode(key='key2', value='val2')]
            return node
    class DummyNode(object):
        def __init__(self, key, value):
            self.key_node = ScalarNode(tag=u'tag:yaml.org,2002:str', value=key)
            self.value_node = ScalarNode(tag=u'tag:yaml.org,2002:str', value=value)



# Generated at 2022-06-20 23:41:40.228936
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(u'tag:yaml.org,2002:map', None)
    a = AnsibleConstructor()
    res = a.construct_yaml_map(node)
    assert res.__class__ == AnsibleMapping


# Generated at 2022-06-20 23:41:46.922110
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    a = AnsibleConstructor()
    import yaml
    yaml_snippet = """
- foo
- bar
    """
    data = yaml.load(yaml_snippet, Loader=AnsibleConstructor)
    assert data[0] == u"foo"
    assert data[1] == u"bar"
    assert isinstance(data, AnsibleSequence)
    assert isinstance(data[0], AnsibleUnicode)
    assert isinstance(data[1], AnsibleUnicode)



# Generated at 2022-06-20 23:42:01.876375
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # this test only works if run in the 'lib/ansible' directory  (not tests/unit/parsing)
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_text = '''---
                     - hosts: 127.0.0.1
                       gather_facts: false
                       tasks:
                         - name: Attempt to create a file with an empty string for content.
                           file:
                             path: "/tmp/test"
                             state: touch
                             content: !unsafe ''
                           tags: always
                       '''

    results = AnsibleLoader(yaml_text, file_name='/test.yml').get_single_data()
    assert results['tasks'][0].get('content') == ''

# Generated at 2022-06-20 23:42:02.754586
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    ac.construct_yaml_str('abcdef')

# Generated at 2022-06-20 23:42:15.310397
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # class AnsibleMapping(collections.MutableMapping, object):
    #     def __init__(self, data=None):
    #         self.ansible_pos = None
    #         self._data = data or {}
    from collections import MutableMapping
    class DummyAnsibleMapping(MutableMapping, object):
        """ A dummy class for AnsibleMapping. We only care about its type information. """

        def __init__(self):
            self.ansible_pos = None

    # Test with a valid node
    test_node = DummyAnsibleMapping()
    test_node.ansible_pos = (u'<string>', 1, 1) # (datasource, line, column)

# Generated at 2022-06-20 23:42:26.374957
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-20 23:42:39.309407
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    ansible_constructor = AnsibleConstructor()

    # Test 1: if the input argument is not a ScalarNode, then we should receive a ConstructorError
    with pytest.raises(ConstructorError):
        ansible_constructor.construct_yaml_str("not a ScalarNode")

    # Test 2: If the input value is a string, then we should receive an object of class AnsibleUnicode
    str_input = "test string"
    assert isinstance(ansible_constructor.construct_yaml_str(str_input), AnsibleUnicode)
    assert ansible_constructor.construct_yaml_str(str_input).__repr__() == "AnsibleUnicode('test string')"

    # Test 3: If the input value is an integer, then we should receive an object of class Ansible

# Generated at 2022-06-20 23:42:48.152642
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor()
    constructor.vault_secrets = ['testsecret']
    vault = VaultLib(secrets=['testsecret'])
    plaintext = 'foo bar'
    ciphertext = vault.encrypt(to_bytes(plaintext))
    node = u'!vault |\n  ' + ciphertext.decode('utf-8')
    encrypted_unicode_object = constructor.construct_vault_encrypted_unicode(node)
    assert(str(encrypted_unicode_object) == plaintext)

# Generated at 2022-06-20 23:42:59.739120
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode

    buf = StringIO(u'[foo, bar, baz]')
    node = yaml.parse(buf)

    obj = AnsibleConstructor.construct_yaml_seq(node)
    assert isinstance(obj, AnsibleSequence)
    assert len(obj) == 3
    assert obj[0] == AnsibleUnicode(u'foo')
    assert obj[1] == AnsibleUnicode(u'bar')
    assert obj[2] == AnsibleUnicode(u'baz')

# Generated at 2022-06-20 23:43:10.510804
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import io


# Generated at 2022-06-20 23:43:18.009805
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import random

    b_ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n353964653934643662316336373336643330346635343462393630376433643861666364303766\n396634303561316463336234326134636231356334303266623635376626313531653137376231\n66636536\n'
    b_plaintext = b'hello world'
    b_password = b'password'
    b_password2 = b'wrong password'
    b_password3 = b'wrong password'
    vault = VaultLib(b_password)

# Generated at 2022-06-20 23:43:29.245040
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader

    constructor_object = AnsibleConstructor()
    test_value = "test_value"
    result_item = 1
    result_value = "test_test"
    test_list = [{test_value:result_value}]

    loader_value = AnsibleLoader(test_list, constructor=constructor_object).get_single_data()
    result = loader_value[result_item]

    assert isinstance(loader_value, tuple)
    assert isinstance(result, dict)
    assert result[test_value] == result_value


# Generated at 2022-06-20 23:43:41.198191
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from collections import namedtuple
    test_data = namedtuple('test_data', ['in_yaml', 'out_unicode'])
    test_datas = [
        test_data(('foo\n'
                   '\n'
                   'bar\n'
                   '\n'
                   '\n'
                   ''),
                  'foo\n\nbar\n\n\n'),
        test_data(('{"a": "b"}\n'
                   '\n'
                   '{"c": "d"}\n'
                   '\n'
                   '\n'
                   ''),
                  '{"a": "b"}\n\n{"c": "d"}\n\n\n'),
    ]

    for test_data in test_datas:
        in_yaml = test_data

# Generated at 2022-06-20 23:43:54.198069
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml.parser import Parser

    # Empty string
    sample = ""
    parser = Parser(sample)
    doc = parser.get_single_node()
    con = AnsibleConstructor()
    con.construct_document(doc)

    # Single line comment
    sample = "# a comment"
    parser = Parser(sample)
    doc = parser.get_single_node()
    con = AnsibleConstructor()
    con.construct_document(doc)

    # String
    sample = "string: 'string'"
    parser = Parser(sample)
    doc = parser.get_single_node()
    con = AnsibleConstructor()
    con.construct_document(doc)

    # Int
    sample = "integer: 10"
    parser = Parser(sample)
    doc = parser.get_single_

# Generated at 2022-06-20 23:44:02.909561
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import tempfile
    import yaml

    from ansible.compat.tests import unittest
    from ansible.parsing.yaml.loader import AnsibleLoader

    display.verbosity = 3

    class TestAnsibleConstructor(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(None, None)

        def test_duplicate_yaml_dict_key_warn(self):
            filename = tempfile.mktemp()
            f = open(filename, 'w+')
            f.write('{a: A, b: B, a: Duplicate}')
            f.seek(0)
            yaml.load(f, Loader=self.loader)

# Generated at 2022-06-20 23:44:15.429553
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class FakeNode(object):
        def __init__(self, line, column, length, value):
            class FakeMark(object):
                def __init__(self, line, column, length, value):
                    self.line = line
                    self.column = column
                    self.length = length
                    self.value = value
            self.start_mark = FakeMark(line, column, length, value)

    class FakeLoader(object):
        def __init__(self, seq):
            self.seq = seq
        def construct_sequence(self, node):
            return self.seq

    data = [4, 8, 15, 16, 23, 42]
    seq_node = FakeNode(50, 0, 0, None)
    loader = FakeLoader(data)
    ret = AnsibleConstructor(loader).construct_yaml_seq

# Generated at 2022-06-20 23:44:23.761840
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    if sys.version_info[0] < 3:
        import StringIO as io
    else:
        import io
    cc = AnsibleConstructor(file_name='filename')

    # test construct_mapping with simple yaml
    yaml_map = u'{key: value}\n'
    yaml_seq = u'- key2\n- key1\n'
    node = cc.compose_document(yaml_map)
    mapping = cc.construct_mapping(node)
    assert u'key' in mapping.keys()
    assert mapping[u'key'] == u'value'

    # test construct_mapping with duplicate dict keys
    for key in (u'warn', u'error', u'ignore'):
        C.DUPLICATE_YAML_DICT_KEY = key

# Generated at 2022-06-20 23:44:30.579569
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml import load
    doc = '''
    key0: value0
    key1:
      - value1
      - value2
    '''
    data = load(doc, AnsibleConstructor)
    assert len(data) == 2
    assert data['key1'].ansible_pos == ('<unicode string>', 1, 11)
    assert list(data) == ['key0', 'key1']


# Generated at 2022-06-20 23:44:42.582233
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    a, b, c = AnsibleUnsafeText(b'foo'), AnsibleUnsafeText(b'bar'), AnsibleUnsafeText(b'com')
    obj = AnsibleMapping()
    obj.update({a: b})
    obj.update({b: c})
    obj.update({c: a})
    dumper = AnsibleDumper(indent=2, width=80)
    data = dumper.represent_dict(obj)
    values = yaml.load(data, Loader=AnsibleConstructor)
    assert len(values.keys()) == 3
    assert values.keys()[0] == a

# Generated at 2022-06-20 23:44:46.231934
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = yaml.load('''
    - foo
    - bar
    ''', Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert data[0] == 'foo'
    assert data[1] == 'bar'



# Generated at 2022-06-20 23:44:52.364782
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml import load
    from io import StringIO
    s = StringIO("[{'a': 'b'}, {'c': 'd'}]")
    test_obj = load(s, Loader=AnsibleLoader)
    assert test_obj[1].ansible_pos == ('<unicode>', 1, 17)

# Generated at 2022-06-20 23:44:55.228309
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = AnsibleMapping()
    node = None

    ac = AnsibleConstructor()
    ac.construct_yaml_map(node) == data

# Generated at 2022-06-20 23:45:18.064692
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    # if the node argument does not have an 'id' attribute (for instance, if it is a scalar node)
    # it will fall back to calling it's parent ('construct_object') which will do the right thing
    # by returning the string representation of the node
    node = {}
    ac = AnsibleConstructor()
    assert isinstance(ac.construct_yaml_unsafe(node), AnsibleUnsafeText)

    # if the node argument has an 'id' attribute, it will attempt to call
    # the constructor function named 'construct_<node.id>'.
    # To fail gracefully, we set the node.id to an invalid function name
    node = {}

# Generated at 2022-06-20 23:45:23.416201
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test handling of vault constructor with encrypted data
    # where the vault is not registered but the vault constructor is used.
    assert_raises(ConstructorError, AnsibleConstructor(file_name=None, vault_secrets=[]).construct_vault_encrypted_unicode, 'foo')

# Generated at 2022-06-20 23:45:25.559139
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    node = None
    result = ansible_constructor.construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)

# Generated at 2022-06-20 23:45:27.216048
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.constructor import AnsibleConstructor


# Generated at 2022-06-20 23:45:35.936339
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import ansible.parsing.yaml.objects
    yaml = '''
    foo: bar
    baz:
        foobar: hello
        foobaz: goodbye
    '''
    expected_result = ansible.parsing.yaml.objects.AnsibleMapping({u'foo': u'bar', u'baz': ansible.parsing.yaml.objects.AnsibleMapping({u'foobaz': u'goodbye', u'foobar': u'hello'})})
    assert AnsibleConstructor.construct_yaml_map.im_func(AnsibleConstructor(), None) == expected_result


# Generated at 2022-06-20 23:45:47.362029
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class TestClass(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            super(TestClass, self).__init__(file_name, vault_secrets)
        def _node_position_info(self, node):
            return None

    # Class is a subclass of AnsibleConstructor
    assert issubclass(TestClass, AnsibleConstructor)

    test_obj = TestClass()
    test_str = 'test str'

    ret = test_obj.construct_yaml_str(test_str)
    assert ret == 'test str'

    ret = test_obj.construct_yaml_str(test_str)
    assert isinstance(ret, AnsibleUnicode)
    assert ret == u'test str'

    ret = test_obj.construct

# Generated at 2022-06-20 23:45:56.411322
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

# Generated at 2022-06-20 23:46:08.598317
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from unittest import TestCase
    from yaml import dump

    class TestAnsibleConstructor_construct_yaml_seq(TestCase):
        """AnsibleConstructor class using yaml.constructor.SafeConstructor class for constructing yaml map object"""

        def setUp(self):
            self.safe_constructor = AnsibleConstructor()

        def test_AnsibleConstructor_construct_yaml_seq_with_short_notation(self):
            yaml_code = '''
            - a
            - b
            - c
            '''
            yaml_code = dump(yaml_code)
            yaml_code = yaml_code.replace('|-', '-')
            yaml_code = yaml_code.replace('|', '')
            yaml_data = self.safe_construct

# Generated at 2022-06-20 23:46:18.012097
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class FakeNode(object):
        def __init__(self, line, column, value):
            self.start_mark = FakeNode.FakeMark(line, column)
            self.value = value
        class FakeMark(object):
            def __init__(self, line, column):
                self.line = line
                self.column = column

# Generated at 2022-06-20 23:46:29.361370
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """Test construct_yaml_map method of class AnsibleConstructor
    """
    # Arrange
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Act
    yaml_data = AnsibleLoader(None, {'DUPLICATE_YAML_DICT_KEY': 'error'}).load('''
    foo: bar
    bar: baz
    foo: bar
    bam: baz
    ''')

    # Assert
    if yaml_data is None or not isinstance(yaml_data, dict):
        raise AssertionError('yaml_data should not be empty')
    if 'foo' not in yaml_data:
        raise AssertionError('foo key should be present in data')

# Generated at 2022-06-20 23:46:45.622502
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    assert AnsibleUnicode(u'10') == ac.construct_yaml_str(ac.construct_yaml_str.__name__)
    assert AnsibleUnicode(u'10') == ac.construct_yaml_str(b'10')
    assert AnsibleUnicode(u'10') == ac.construct_yaml_str(10)
    assert AnsibleUnicode(u'abc') == ac.construct_yaml_str(u'abc')

# Generated at 2022-06-20 23:46:49.768114
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    s = "string"
    node = AnsibleUnicode(s)
    obj = AnsibleConstructor('test_file').construct_yaml_str(node)
    assert isinstance(obj, AnsibleUnicode)
    assert obj == s

# Generated at 2022-06-20 23:47:02.072148
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import collections
    import json
    from datetime import datetime as dt
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    data = u'[1, 2, 3, {"key": "value", "key2": "value2"}]\n'
    yaml_data = AnsibleLoader(data).get_single_data()
    ansible_yaml_data = AnsibleConstructor().construct_yaml_unsafe(yaml_data)
    assert isinstance(ansible_yaml_data, collections.Sequence)
    assert isinstance(ansible_yaml_data[3], collections.Mapping)

# Generated at 2022-06-20 23:47:12.222097
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    '''
    Test AnsibleConstructor.construct_mapping()
    '''
    from collections import OrderedDict
    from yaml.nodes import MappingNode
    from yaml.constructor import ConstructorError
    from yaml.parser import ParserError

    # Test the basic case
    mapping_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    ac = AnsibleConstructor()
    ret = ac.construct_mapping(mapping_node)
    assert isinstance(ret, AnsibleMapping)
    assert isinstance(ret, OrderedDict)
    assert ret == {}

    # Test the basic case with a deep=True

# Generated at 2022-06-20 23:47:23.868286
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    b_ciphertext = b'$ANSIBLE_VAULT;1.1;AES256;travis@macbook-air.c.gentoo-playground.internal\n3634383038363961633861633265323935343331386332313137366462396266666661623361640a316561396632333036333738356566383237323934656666663030356665393938373735\n'
    constructor = AnsibleConstructor()
    constructor.vault_secrets = ['secret']
    vault_encrypted_unicode = constructor.construct_vault_encrypted_unicode(b_ciphertext)
    assert isinstance(vault_encrypted_unicode, AnsibleVaultEncryptedUnicode)
    assert vault_encrypted_unicode.v

# Generated at 2022-06-20 23:47:33.273735
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-20 23:47:37.374267
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    AnsibleConstructor.construct_yaml_seq is tested by the
    PyYAML test suite, so we do not need to test it here.

    The method is implemented by using YAML's own methods
    to construct a sequence and then extend the returned object.
    """
    pass


# Generated at 2022-06-20 23:47:40.870361
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    obj = AnsibleConstructor()
    assert isinstance(obj.construct_yaml_str(""), AnsibleUnicode)
    assert isinstance(obj.construct_yaml_str("hello"), AnsibleUnicode)

# Generated at 2022-06-20 23:47:52.642255
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.six import PY2

    class AnsibleVaultEncryptedUnicode_test(AnsibleVaultEncryptedUnicode):
        def __init__(self, data=None, vault_secret=None):
            self.vault = VaultLib(secrets=vault_secret)
            self.data = data

        def __str__(self):
            return self.decrypt()

    vault_secrets = ["ansible"]

    ac = AnsibleConstructor(vault_secrets=vault_secrets)
    ac.add_constructor(u'!vault', ac.construct_vault_encrypted_unicode)

    # test unicode string in yaml

# Generated at 2022-06-20 23:47:53.690877
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    assert AnsibleConstructor().construct_yaml_unsafe(None) is None

# Generated at 2022-06-20 23:48:15.465823
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = """
    -  hello
    -  world
    """
    data = yaml.load(yaml_data, AnsibleConstructor)
    # Assert that data is an instance of list.
    assert isinstance(data, list)
    # Assert that data contains two elements.
    assert len(data) == 2
    # Assert that the first element of data is an instance of AnsibleUnicode.
    assert isinstance(data[0], AnsibleUnicode)
    # Assert that the value of the first element of data is 'hello'.
    assert data[0] == u'hello'
    # Assert that the second element of data is an instance of AnsibleUnicode.
    assert isinstance(data[1], AnsibleUnicode)
    # Assert that the value of the first element of

# Generated at 2022-06-20 23:48:27.620441
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    import sys
    import unittest

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self.constructor = AnsibleConstructor.construct_yaml_map
            self.construct_yaml_map = AnsibleConstructor.construct_yaml_map
            self.construct_yaml_str = AnsibleConstructor.construct_yaml_str
            self.construct_yaml_unsafe = AnsibleConstructor.construct_yaml_unsafe

        def test_empty_map(self):
            stream = '''\
--- {}'''
            node = yaml.compose(stream)
            mapping = self.construct_yaml_

# Generated at 2022-06-20 23:48:35.446696
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import yaml
    yaml_str = '{"foo": "bar"}'
    yaml_data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(yaml_data['foo'], UnsafeProxy)
    assert wrap_var(yaml_data['foo']) == 'bar'

# Generated at 2022-06-20 23:48:41.807828
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_dict = {'key1': 'value1', 'key2': 'value2'}
    yaml_dict_data = yaml.dump(yaml_dict)
    yaml_dict_hash = yaml.load(yaml_dict_data, Loader=AnsibleConstructor)
    assert yaml_dict_hash.ansible_pos is not None
    assert yaml_dict_hash.ansible_pos[0] == '<string>'
    assert yaml_dict_hash.ansible_pos[2] == 0
    assert yaml_dict_hash == {'key1': 'value1', 'key2': 'value2'}
    assert isinstance(yaml_dict_hash, AnsibleMapping)

# Generated at 2022-06-20 23:48:53.999399
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    yaml = b'!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  61333237356638373066333138353460626533353262346339616230366538373231346366643937\n  37613064366238613339623464373835643336363539613638333837343539346333613466643862\n  33366432626363653938356432333161326530353163326431623662656439663633306261623366\n  37\n'

    vault_secrets = [b'12345']
    filename = None

# Generated at 2022-06-20 23:49:02.752955
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class A:
        pass

    data = {
        u'tag:yaml.org,2002:str': u'foo',
        1: 2,
        'tag:yaml.org,2002:float': 3.0,
    }

    ac = AnsibleConstructor()

    # Test standard mapping
    node = MappingNode(u'', data)
    result = ac.construct_mapping(node)
    assert(isinstance(result, dict))
    assert(result[u'foo'] == 2)
    assert(result[1] == 2)
    assert(result[3.0] == 2)

    # Test mapping with duplicate keys
    node = MappingNode(u'', data)
    result = ac.construct_mapping(node)
    assert(isinstance(result, dict))

# Generated at 2022-06-20 23:49:14.305086
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def test_method(data, expected):
        module = AnsibleModule(argument_spec=dict(a=dict(required=True)))
        module.params['a'] = data
        module.debug('a=' + str(module.params['a']))
        assert type(module.params['a']) == type(expected)
        assert module.params['a'] == expected

    # The following strings should be interpreted as AnsibleUnsafeText
    # instead of str or unicode

# Generated at 2022-06-20 23:49:24.234287
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = [AESVaultLib(id="secret01",
                                                     secret='$ANSIBLE_VAULT;1.1;AES256;' \
                                                     '3132333435363738393031323334353637383930313233343536373839303132333435363738393031323334353637383930')]


# Generated at 2022-06-20 23:49:29.926618
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    file_name = 'construct_yaml_seq_test'
    node = u"test_node"
    seq = list(range(5))

    def construct_mock(self, node):
        return seq

    construct_mock.__name__ = node

    yaml_constructor = AnsibleConstructor(file_name)
    setattr(yaml_constructor, construct_mock.__name__, construct_mock)
    yaml_constructor.add_constructor(node, construct_mock)

    ansible_seq = list(yaml_constructor.construct_yaml_seq(u"test_node"))
    assert len(ansible_seq) == 1
    assert isinstance(ansible_seq[0], AnsibleSequence)

# Generated at 2022-06-20 23:49:40.589123
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    root = globals()
    root.__dict__.update(locals())
    import ansible.module_utils.yaml_loader
    if not hasattr(ansible.module_utils.yaml_loader, 'AnsibleConstructor'):
        ansible.module_utils.yaml_loader.AnsibleConstructor = AnsibleConstructor
        ansible.module_utils.yaml_loader.__dict__.update(locals())

    import sys
    if sys.version_info.major == 2:
        import yaml2
        sys.modules['yaml'] = yaml2

    import unittest2 as unittest
    import yaml


# Generated at 2022-06-20 23:50:01.727741
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    class DummyConstructor(object):
        def __call__(self, node):
            return node.value

    test = {'a': 1, 'b': 2, 'c': 3}
    data = """
        a: test1
        b: test2
        c: test3
        """
    node = yaml.compose(data)
    m = AnsibleConstructor.construct_mapping(DummyConstructor(), node)
    assert type(m) == AnsibleMapping
    assert m['a'] == 'test1'
    assert m['b'] == 'test2'
    assert m['c'] == 'test3'
    assert len(m) == 3


# Generated at 2022-06-20 23:50:11.650499
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Test code using an ANSI color code to indicate the class of the value.
    #     \x1b[31m = red    -> dict
    #     \x1b[32m = green  -> list
    #     \x1b[33m = yellow -> unicode
    #     \x1b[34m = blue   -> AnsibleVaultEncryptedUnicode

    display.display(u'\nTest AnsibleMapping')
    yaml_text = u'\n'.join([u'a: 1',
                            u'b: 2',
                            u'c: 3'])
    data = AnsibleLoader(yaml_text).get_single

# Generated at 2022-06-20 23:50:18.040513
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ac = AnsibleConstructor()

    errors_yaml = '''
# Example of errors
- name: example of unqualified key
  action: test
- name: example of duplicate key
  action: test
  become: yes
  become: no
'''
    errors = ac.construct_yaml(errors_yaml)

    assert 'unqualified' in errors[0]['action']
    assert 'duplicate' in errors[1]['become']

    no_errors_yaml = '''
# Example of no errors
- name: example1
  action: test
- name: example2
  action: test
  become: yes
'''
    no_errors = ac.construct_yaml(no_errors_yaml)

    assert errors[0]['action'] != no_errors[0]['action']
   