

# Generated at 2022-06-20 23:40:33.121219
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import io
    import yaml

    yaml_str = io.StringIO("""
        foo: bar
        baz:
          - 12
          - 14
        """)

    constructor = AnsibleConstructor(file_name='<string>', vault_secrets=['vaultpassword'])
    data = yaml.load(yaml_str, Loader=yaml.Loader)
    data2 = constructor.construct_yaml_map(data)
    assert(data2.ansible_pos[0], '<string>')
    assert(data2['foo'].ansible_pos[0], '<string>')
    assert(len(data2['baz']) == 2)
    # nested object
    assert(data2['baz'].ansible_pos[0], '<string>')


# Generated at 2022-06-20 23:40:42.019315
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    class yaml_str_node():
        # Fake class for mocking a yaml str node

        def __init__(self, value):
            self.value = value

    class yaml_node():
        # Fake class for mocking a yaml node

        def __init__(self, value):
            self.value = value

    class yaml_mark():
        # Fake class for mocking a yaml mark

        def __init__(self, name, line, column):
            self.name = name
            self.line = line
            self.column = column

    # this tests the case where we've set the ansible file name and
    # passed it to the YAML constructor, in which case that filename
    # should override any default datasource in the YAML node mark

    r = AnsibleConstructor('/fake-file', [])
   

# Generated at 2022-06-20 23:40:47.024317
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(stream="[1,2,3]", file_name='test_AnsibleConstructor_construct_yaml_seq')
    assert loader.get_single_data() == [1,2,3]


# Generated at 2022-06-20 23:40:50.978630
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    node = 'some_string'
    assert ansible_constructor.construct_yaml_str(node) == u'some_string'

# Generated at 2022-06-20 23:40:56.188083
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = "value"
    constructor = AnsibleConstructor()
    constructor.construct_yaml_str(node)
    assert constructor.construct_yaml_str(node) == u"value"
    assert isinstance(constructor.construct_yaml_str(node), AnsibleUnicode)

# Generated at 2022-06-20 23:41:09.507707
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test with sequence that contains special AnsibleMapping and AnsibleUnicode objects
    # As opposed to just plain Python dicts, lists and strings
    class Test(object):
        def __init__(self, data):
            self.data = data
    import sys
    import io
    if sys.version_info[0] == 2:
        mystring = unicode('hi, there!')
    else:
        mystring = str('hi, there!')
    mydict = dict(x=2, y=3)
    mylist = list(range(5))
    test_data = AnsibleSequence([AnsibleMapping(mydict),
                                AnsibleUnicode(mystring),
                                AnsibleSequence(mylist),
                                Test(mydict)])
    test_seq_string = io.String

# Generated at 2022-06-20 23:41:22.305605
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    from yaml.nodes import ScalarNode
    class MockYamlNodes:
        @staticmethod
        def construct_yaml_seq(self, node):
            data = AnsibleSequence()
            yield data
            data.extend(self.construct_sequence(node))
            data.ansible_pos = self._node_position_info(node)


# Generated at 2022-06-20 23:41:34.247685
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """ Testing construct_yaml_map function of AnsibleConstructor """
    def get_node_object():
        ''' This function is used to get the node object which is used to test construct_yaml_map function '''
        import os
        import sys
        from yaml.composer import Composer
        from yaml.parser import Parser
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.resolver import Resolver
        from ansible import constants as C
        class FakeNode(object):
            '''Fake node object'''
            id = None
            start_mark = None
            value = None
            def __init__(self):
                self.start_mark = FakeNode()
                self.start_mark.name = 'fake_file_path'
                self.start_

# Generated at 2022-06-20 23:41:43.462543
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    secret = "hunter2"
    vault = VaultLib([secret])
    encrypted_data = vault.encrypt(b"Hello World")
    # Don't run the following code when encrypted_data is not encrypted by vault
    if vault.is_encrypted(encrypted_data):
        constructor = AnsibleConstructor()
        ret = constructor.construct_vault_encrypted_unicode(encrypted_data)
        assert ret.vault is vault
        assert ret.encoded_data == encrypted_data

# Generated at 2022-06-20 23:41:47.175888
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_string = '''
a:
  b: 2
  c: 3
'''
    am = yaml.load(yaml_string, AnsibleConstructor)
    assert isinstance(am, AnsibleMapping)
    assert am == {'a': {'b': 2, 'c': 3}}

# Generated at 2022-06-20 23:41:59.589076
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'string')
    loader = AnsibleLoader(yaml.nodes.MappingNode(None, None))
    construct = AnsibleConstructor(loader)

    unicode_str = construct.construct_yaml_str(node)
    assert isinstance(unicode_str, AnsibleUnicode)
    assert unicode_str == u'string'


# Generated at 2022-06-20 23:42:12.796419
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Constructor requires a secret file and a vault id
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    # Load vault secrets
    secrets = []
    secrets.append(loader.load_file_common_secure('/home/stack/.ansible-secrets'))

    # For now, we assume the vault id is 'default'
    vault = VaultLib(secrets=secrets)

    # Test AnsibleUnicode.__str__ method,
    # which will show the encrypted text if the text is encrypted
    # otherwise, it will show the original text
    uni = AnsibleUnicode("xyz")
    assert str(uni) == 'xyz'

    # Test AnsibleUnicode.

# Generated at 2022-06-20 23:42:24.129719
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    yamlstr = u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          626337636663346437383563636639373735313361373364326335316139316461323532653166633d0a\n          33623436393962633938656435666264643365313166353337646566306166353131633538353261\n          61633d0a'
    file_name = u'filename'
    vault_secrets = ['vault_password']
    env_vault_pass = u'/home/username/.vault_pass.txt'
    cave_env = '/home/username/.ansible_vault_password.txt'

# Generated at 2022-06-20 23:42:32.640057
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from yaml.nodes import ScalarNode
    import yaml

    def mock_ansible_vault_decrypt(self, value):
        return "foo"

    vault_password = VaultLib(secrets=["foo"])


# Generated at 2022-06-20 23:42:33.291913
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert True

# Generated at 2022-06-20 23:42:34.730131
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert issubclass(AnsibleConstructor, SafeConstructor)

# Generated at 2022-06-20 23:42:41.206955
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.vault import VaultLib
    yaml_str = """
- foo
- bar
- baz
"""
    ansible_constructor = AnsibleConstructor()
    result = list(ansible_constructor.construct_yaml_seq(yaml_str))
    assert result == ['foo', 'bar', 'baz']


# Generated at 2022-06-20 23:42:54.175786
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import unittest
    import yaml

    my_file = io.StringIO(u'foo: bar\nbar: foo\nbar: blah')

    class MyTestCase(unittest.TestCase):
        def test_00(self):
            data = yaml.safe_load(my_file)
            expected = {'foo': 'bar', 'bar': 'blah'}
            self.assertEqual(data, expected)

    loader = unittest.TestLoader().loadTestsFromTestCase(MyTestCase)
    suite = unittest.TestSuite(loader)

    runner = unittest.TextTestRunner(verbosity=2)
    results = runner.run(suite)

    sys.exit(0 if results.wasSuccessful() else 1)

# Generated at 2022-06-20 23:43:07.531605
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars import VariableManager

    data = dict(a="{{a}}")
    constructor = AnsibleConstructor()
    dumper = AnsibleDumper()

    var_manager = VariableManager()
    var_manager.set_host_variable('localhost', 'a', 'test')

    wrapped_data = constructor.construct_yaml_unsafe(constructor.construct_mapping(dumper.represent_mapping(u'tag:yaml.org,2002:map', data)))

    assert var_manager._get_value(host='localhost', varname='a') == 'test'

    assert var_manager._get_value(None, 'a', wrapped_data) == 'test'

# Generated at 2022-06-20 23:43:15.889662
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from unittest.mock import patch
    import io
    import ansible.parsing.vault as vault

    # create instance of class AnsibleConstructor
    file_name = '/root/testfile.yaml'
    vault_secrets = ['/root/vault.pwd']
    constructor = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    # create instance of class VaultLib for testing
    vault_instance = vault.VaultLib(secrets=vault_secrets)

    # create node element to contain encrypted data
    node = object()
    node.start_mark = object()
    node.start_mark.column = 5
    node.start_mark.line = 10
    node.start_mark.name = file_name

    # create dummy encrypted data

# Generated at 2022-06-20 23:43:33.734472
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Test constructing an ansible mapping
    ansible_constructor = AnsibleConstructor()
    yaml_node = MappingNode([], [], [], False, line=1, column=1, tag="tag:yaml.org,2002:map")
    ansible_mapping = ansible_constructor.construct_yaml_map(yaml_node)
    assert isinstance(ansible_mapping, AnsibleMapping)
    assert ansible_mapping.ansible_pos == ('<string>', 1, 1)

    # Test constructing an ansible string
    ansible_constructor = AnsibleConstructor()
    yaml_node = MappingNode([], [], [], False, line=1, column=1, tag="tag:yaml.org,2002:str")
    ansible_mapping = ansible_construct

# Generated at 2022-06-20 23:43:37.415138
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    unsafe_str = '!unsafe foo'
    ansible_constructor = AnsibleConstructor()
    data = yaml.load(unsafe_str, Loader=AnsibleConstructor)
    assert(data.__unsafe__)
    assert(data.__unicode__() == 'foo')



# Generated at 2022-06-20 23:43:40.525632
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.module_utils.six import StringIO

    yaml_str = StringIO(u'[1, 2, 3]')
    yaml_node = getattr(yaml_str, 'name', '<unknown>')
    ret = AnsibleConstructor(yaml_node).get_single_data()
    assert ret == [1, 2, 3]

# Generated at 2022-06-20 23:43:44.253578
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test play.yml in folder test/units/parsing/dataloader
    filename = 'test/units/parsing/dataloade/play.yml'
    yamlfile = open(filename, 'r')
    docs = yaml.load_all(yamlfile, Loader=AnsibleConstructor)
    for doc in docs:
        print(doc)

# Generated at 2022-06-20 23:43:46.804919
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    c = AnsibleConstructor()
    assert isinstance(c.construct_yaml_map({}), AnsibleMapping)


# Generated at 2022-06-20 23:43:58.227066
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from collections import OrderedDict
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class DumpData(object):
        pass

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(host_list=[]))
    loader = DictDataLoader({u'test.yml': u'key: value'})
    variable_manager.set_loader(loader)

    dummy = DumpData()
    dummy.hostvars = variable_manager.get_vars(host=None)
    dummy.skip_values = frozenset([u'VARIABLE_IS_NOT_DEFINED'])

    dumpdata = AnsibleDumper(None, None, None).represent_data

# Generated at 2022-06-20 23:44:08.727111
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = '''
        foo: abc123
        bar:
            - this
            - is
            - a
            - list
        bam:
            name: Joe
            state: FL
            pets: false
    '''
    test_data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(test_data['foo'], AnsibleUnicode)
    assert isinstance(test_data['bar'], AnsibleSequence)
    assert isinstance(test_data['bar'][1], AnsibleUnicode)
    assert isinstance(test_data['bam'], AnsibleMapping)
    assert isinstance(test_data['bam']['name'], AnsibleUnicode)

# Generated at 2022-06-20 23:44:20.164390
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os
    import sys
    import time
    import shutil
    import yaml

    def test_file_name():
        return 'test_AnsibleConstructor_construct_mapping_%s.yml' % time.time()

    def _check_mapping(mapping):
        # Check that:
        #  - the mapping contains the correct items.
        #  - the mapping contains a 'ansible_pos' key
        #  - the mapping ansible_pos key is formatted correctly

        assert len(mapping) == 1
        assert isinstance(mapping, AnsibleMapping)
        assert 'ansible_pos' in mapping
        assert isinstance(mapping['ansible_pos'], tuple)
        assert len(mapping['ansible_pos']) == 3

# Generated at 2022-06-20 23:44:31.246866
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    import yaml

    filename = None
    # use the fixture vault password
    vault_secrets = [ b'$ANSIBLE_VAULT;1.1;AES256']
    data_loader  = DataLoader()
    vault_secret = data_loader._get_vault_secret(filename, vault_secrets)
    vault_lib = VaultLib(vault_secret)

    # create encrypted data
    plain_data = {
        'foo': 'bar',
    }
    plain_data_as_bytes = yaml.safe_dump(plain_data, default_flow_style=False, encoding='utf-8', allow_unicode=True)
    plain_data_as_text = to

# Generated at 2022-06-20 23:44:43.108558
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_lib = VaultLib(secrets=['vault-password'])
    b_secret = to_bytes('my secret')
    b_password = to_bytes('vault-password')
    b_ciphertext = vault_lib.encrypt(b_password, b_secret)
    b_ciphertext_data = (b'$ANSIBLE_VAULT;1.1;AES256\n' + b_ciphertext).replace(b'\n', b'\r\n')
    yaml_data = b'!vault |\r\n' + b_ciphertext_data
    node = yaml.compose(yaml_data)
    constructor = AnsibleConstructor(file_name=None, vault_secrets=['vault-password'])
    vault_obj = constructor.construct_v

# Generated at 2022-06-20 23:45:01.071373
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import load
    import io
    import sys
    import time

    if sys.version_info < (2, 7):
        raise unittest.SkipTest('AnsibleConstructor not tested on older versions of python')

    # NOTE:  The following tests are meant to test the output of the constructs only,
    # and do not necessarily reflect the behavior of the actual YAML dev, which has slightly
    # different output for some of these.  This is because we are parsing with non-default
    # parameters, which override the core YAML devs, and are not intended to change them.


# Generated at 2022-06-20 23:45:11.801709
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import types

    if sys.version_info[0] < 3:
        from types import ClassType

    conv = AnsibleConstructor()

    class Foo(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class Fiz(object):
        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    class Foo1(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b


# Generated at 2022-06-20 23:45:16.515667
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    constructor = AnsibleConstructor()

    assert isinstance(constructor.construct_yaml_unsafe(u'tag:yaml.org,2002:int', ansible_pos=(None, None, 0)), int)
    assert isinstance(constructor.construct_yaml_unsafe(u'tag:yaml.org,2002:float', ansible_pos=(None, None, 0)), float)
    assert isinstance(constructor.construct_yaml_unsafe(u'tag:yaml.org,2002:bool', ansible_pos=(None, None, 0)), bool)

# Generated at 2022-06-20 23:45:24.883844
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    cstr = AnsibleConstructor(file_name='/etc/ansible/roles/foo')
    actual = cstr.construct_yaml_str("ansible")
    assert isinstance(actual, AnsibleUnicode)
    assert actual == "ansible"
    assert actual.ansible_pos == ('/etc/ansible/roles/foo', 1, 0)

# Generated at 2022-06-20 23:45:26.922243
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    value = ansible_constructor.construct_yaml_unsafe
    assert value is not None


# Generated at 2022-06-20 23:45:33.764834
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import io

    # Test that we get a warning when duplicate dict keys are found
    data = u'{foo: bar, foo: baz}'
    file_name = u'TestConstructor_construct_mapping_1'
    y = io.StringIO(data)
    display.display = lambda x, *args, **kwargs: x
    display.verbosity = 2
    constructor = AnsibleConstructor(file_name=file_name)
    try:
        with display.override_verbosity(2):
            assert constructor.construct_yaml_map(y)
    except SystemExit:
        pass
    assert display.display.call_count == 1

# Generated at 2022-06-20 23:45:45.630020
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    yaml.add_constructor(u'!vault', AnsibleConstructor.construct_vault_encrypted_unicode)

# Generated at 2022-06-20 23:45:55.345991
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # When value is not a string, raise an error
    constructor = AnsibleConstructor()
    class Node:
        id = "ScalarNode"

        @staticmethod
        def value():
            pass

        start_mark = "start_mark"

    try:
        constructor.construct_yaml_str(Node)
    except:
        # Raise an error when value is not a string
        pass
    else:
        # Not raise an error when value is a string
        raise AssertionError("Raise an error when string is not a string")

    class Node:
        id = "ScalarNode"

        @staticmethod
        def value():
            return 10

        start_mark = "start_mark"


# Generated at 2022-06-20 23:46:07.276519
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import ScalarNode, MappingNode
    from yaml.composer import Composer
    from yaml.resolver import Resolver

    mapping = MappingNode(u'tag:yaml.org,2002:map', [])
    composer = Composer(Resolver())
    # setup_yaml_parser uses old style classes, so no super call here
    AnsibleConstructor.setup_yaml_parser(composer)
    # Add two (key, value) pairs to the mapping node

# Generated at 2022-06-20 23:46:17.158827
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    str1 = 'test'
    unsafe_str1 = AnsibleUnsafeText(str1)
    unsafe_str1_expected = '!unsafe \'{}\''.format(str1)

    yaml_unsafe_str1 = yaml.dump(unsafe_str1, Dumper=AnsibleDumper, default_flow_style=False)
    assert yaml_unsafe_str1 == unsafe_str1_expected + '\n...\n'

    yaml_unsafe_str1_loaded = yaml.load(yaml_unsafe_str1, Loader=AnsibleConstructor)
    assert yaml_unsafe

# Generated at 2022-06-20 23:46:42.467964
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import ansible.constants as C
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text

    loader = AnsibleLoader(None, None)

    # Test the construct_yaml_unsafe() method of the AnsibleConstructor class

    # Test for class AnsibleConstructor
    construct_yaml_unsafe = AnsibleConstructor.construct_yaml_unsafe
    data = "!unsafe 'a'\n"
    entity = loader.get_single_data(data)
    result = construct_yaml_unsafe(entity)
    assert result == 'a'

    # Test for class AnsibleConstructor
    construct_yaml_unsafe = AnsibleConstructor.construct_yaml_unsafe

# Generated at 2022-06-20 23:46:55.307179
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-20 23:47:06.583304
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.parser import ParserError
    import os

    # pretend to read this file
    this_filename = os.path.basename(__file__)
    test_filename = os.path.join(os.path.dirname(__file__), '..', 'yaml', 'unsafe_tests.yaml')
    a = AnsibleConstructor(file_name=this_filename)

# Generated at 2022-06-20 23:47:18.147097
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    import base64

    class FakeConstructor:
        def construct_scalar(self, node):
            return node.value

    constructor = FakeConstructor()

    secret = VaultSecret(hmac_key=b'test_hmac_key', encryption_key=b'test_encryption_key')
    vault_lib = VaultLib(secrets=[secret])
    # actually encrypted data (with the default vault id: 'default')
    plaintext_data = b'{ "key": "value" }'
    data = vault_lib

# Generated at 2022-06-20 23:47:18.803018
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

# Generated at 2022-06-20 23:47:29.332863
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    class UnitTestAnsibleConstructor(AnsibleConstructor):
        def __init__(self):
            super(UnitTestAnsibleConstructor, self).__init__()
            self.call_args = []

        # When a test calls SafeConstructor(), it results in __init__() method
        # being called. To allow this add this dummy init method.
        def __init__(self):
            pass

        def construct_mapping(self, node, deep=False):
            self.call_args.append((node, deep))
            return super(UnitTestAnsibleConstructor, self).construct_mapping(node, deep)

        def construct_yaml_map(self, node):
            self.call_args.append((node,))
            return super(UnitTestAnsibleConstructor, self).construct_yaml_

# Generated at 2022-06-20 23:47:36.533484
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.composer import Composer
    from yaml.scanner import Scanner

    data = '---\n - !unsafe a\n'
    s = Scanner()
    assert s.check_token(data).__class__.__name__ == 'StreamStartToken'
    c = Composer(s)
    assert c.get_node().__class__.__name__ == 'DocumentStartToken'
    ac = AnsibleConstructor()
    node = c.get_node()
    assert ac._node_position_info(node) == ('<unicode string>', 2, 1)
    v = ac.construct_yaml_str(node)
    assert v == u'a'

# Generated at 2022-06-20 23:47:49.075524
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

    # FIXME: use a temporary vault password file
    vault_passwords_file = os.path.join(tmpdir, 'vault_pass.txt')
    with open(vault_passwords_file, 'wt') as f:
        f.write('vault_password')

    vault_secrets = ['vault_pass.txt']
    construct = AnsibleConstructor(vault_secrets=vault_secrets)

    # The following test takes an example from ansible-playbook --vault-id id@vault_pass.txt vault.yml
    # and checks that the vault password is correctly decrypted


# Generated at 2022-06-20 23:47:50.153800
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-20 23:47:57.230384
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    yaml.add_constructor('tag:yaml.org,2002:str', AnsibleConstructor.construct_yaml_str)
    assert yaml.load(u"{'a': 1, 'a': 2}", Loader=yaml.SafeLoader) == {u'a': 2}
    assert yaml.load(u"{'a': 1, 'a': 2}", Loader=AnsibleConstructor) == {u'a': 2}
    assert yaml.load(u"{'a': 1, 'a': 2}", Loader=AnsibleConstructor) == {u'a': 2}

    # test the legacy warning behavior when the key is not a string (i.e. a VaultSecret)

# Generated at 2022-06-20 23:48:16.974481
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    test_string = "abc\n123"
    node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=test_string)
    string = AnsibleConstructor.construct_yaml_str(AnsibleConstructor(), node)
    assert isinstance(string, AnsibleUnicode)
    assert string == test_string
    assert string.ansible_pos == (None, 1, 1)



# Generated at 2022-06-20 23:48:22.003773
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansibleConstructor = AnsibleConstructor()
    data = AnsibleMapping()
    data.update({"key1": "value1", "key2": "value2"})
    data.ansible_pos = (u'<string>', 1, 1)
    assert ansibleConstructor.construct_yaml_map(data) == data

# Generated at 2022-06-20 23:48:22.658003
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-20 23:48:32.115125
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    # test construction of dict
    yaml_str = "!unsafe {'foo': 'stuff'}"
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert not isinstance(data, dict)
    # test construction of list
    yaml_str = "!unsafe ['foo', 'bar']"
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert not isinstance(data, list)

# Generated at 2022-06-20 23:48:40.473671
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # TODO: add a test that no MappingNode is passed
    # TODO: add a test that the value is not an instance of AnsibleMapping
    # TODO: add a test that the key is not hashable (TypeError)
    # TODO: add a test that a duplicate value is passed (with different settings of DUPLICATE_YAML_DICT_KEY)

    # Initialize a construct_mapping
    data = AnsibleMapping()
    data.update({'a': 1, 'b': 2, 'c': 3})
    data.ansible_pos = (1, 2, 3)
    test = AnsibleConstructor()
    mapping = test.construct_mapping(data, deep=False)

    # Assert that the constructor constructed a AnsibleMapping
    assert isinstance(mapping, AnsibleMapping)

# Generated at 2022-06-20 23:48:46.655475
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    sys.path.append('../test')
    from ansible_test_utils import assert_equal

    node = 'abcdefg'
    expected = AnsibleUnicode('abcdefg')
    actual = AnsibleConstructor.construct_yaml_str(AnsibleConstructor(), node)
    assert_equal(expected, actual)



# Generated at 2022-06-20 23:48:54.779422
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = """
foo: [ 'bar' , 'baz' ]
"""
    expected_data = { "foo": ['bar', 'baz'] }

    from yaml import load

    import sys
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 4:
        import importlib
        importlib.reload(sys)

    data = load(data, Loader=AnsibleConstructor)
    assert data == expected_data


# Generated at 2022-06-20 23:49:01.854592
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.nodes import ScalarNode
    from yaml.scanner import Mark

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def test_construct_vault_encrypted_unicode(vault_id,
                                               ciphertext_data,
                                               vault_secrets,
                                               expected_result):
        ac = AnsibleConstructor(vault_secrets=vault_secrets)
        node = ScalarNode(tag=u'!vault',
                          value=u'7373637274323131',
                          start_mark=Mark(0),
                          end_mark=Mark(0))
        node.id = vault_id
        node.ciphertext_data = ciphertext_data
        result = ac.construct_vault

# Generated at 2022-06-20 23:49:11.568083
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    assert AnsibleConstructor.construct_yaml_unsafe('a').value == b'a'
    assert isinstance(AnsibleConstructor.construct_yaml_unsafe(b'a'), AnsibleUnsafeText)
    assert isinstance(AnsibleConstructor.construct_yaml_unsafe(u'a'), AnsibleUnsafeText)
    assert isinstance(AnsibleConstructor.construct_yaml_unsafe([1]), AnsibleUnsafeText)
    assert isinstance(AnsibleConstructor.construct_yaml_unsafe({}), AnsibleUnsafeText)


# Generated at 2022-06-20 23:49:22.151529
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    node = object()
    object.__setattr__(node, 'id', 'scalar')
    object.__setattr__(node, 'value', b'unicode')
    object.__setattr__(node, 'start_mark', object())
    object.__setattr__(node, 'end_mark', object())

    SafeConstructor.__setattr__(node.start_mark, 'column', 0)
    SafeConstructor.__setattr__(node.start_mark, 'line', 0)
    SafeConstructor.__setattr__(node.end_mark, 'column', 0)
    SafeConstructor.__setattr__(node.end_mark, 'line', 0)

    asc = AnsibleConstructor()


# Generated at 2022-06-20 23:50:02.234941
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import load, dump
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    secret = 'secret'
    vault = VaultLib(secrets=[secret])
    ciphertext = vault.encrypt(secret)
    test_obj = {'abc': 123,
                'def': 456,
                secret: ciphertext,
                'ghi': [secret, secret],
                'jkl': {secret: secret}}

    yaml_str = dump(test_obj)
    ansible_constructor = AnsibleConstructor(vault_secrets=[secret])
    # We are only testing the behaviour of the construct_yaml_str method of the
    # AnsibleConstructor class.
    ansible_constructor.construct_object = Ans

# Generated at 2022-06-20 23:50:11.120789
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import io
    import six

    def test(value, expected):
        value = to_bytes(value)
        if six.PY2:
            fh = io.BytesIO(value)
        else:
            fh = io.StringIO(value)
        node = yaml.load(fh, Loader=AnsibleConstructor)
        assert node == expected

    test(
        "foo",
        AnsibleUnicode("foo")
    )

    test(
        "\x01",
        AnsibleUnicode("\x01")
    )

    test(
        "\x00\x01",
        AnsibleUnicode("\x00\x01")
    )

# Generated at 2022-06-20 23:50:22.465650
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    input_data = {'key1': 'value1'}
    input_yaml = yaml.dump(input_data, default_flow_style=True)

    # yaml.load() uses the default yaml SafeLoader which does not load !unsafe
    # tags, so we need to use the AnsibleConstructor to load the data in.
    obj = yaml.load(input_yaml, Loader=AnsibleConstructor)

    assert obj == input_data
    assert type(obj) == AnsibleMapping

    output_data = {'key2': 'value2'}
    data = AnsibleMapping()
    data.update(output_data)
    obj = yaml.dump(data, default_flow_style=True, Dumper=yaml.SafeDumper)
