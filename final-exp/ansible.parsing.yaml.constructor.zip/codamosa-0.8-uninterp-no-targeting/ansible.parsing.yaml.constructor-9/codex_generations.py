

# Generated at 2022-06-20 23:40:27.366545
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str_1 = u'''\
    test_data_1:
        test_data_1.1: test_data_1.1.1
        test_data_1.2: test_data_1.2.1
    '''
    yaml_str_2 = u'''\
    test_data_2:
        test_data_2.1: test_data_2.1.1
        test_data_2.2: test_data_2.2.1
    '''
    yaml_str_3 = u'''\
    test_data_3:
        test_data_3.1: test_data_3.1.1
    test_data_4:
        test_data_4.1: test_data_4.1.1
    '''

# Generated at 2022-06-20 23:40:35.646967
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # test construct_yaml_map
    obj = {
        "a": 1,
        "b": 2,
    }
    data = AnsibleMapping(obj)
    assert data == obj

    # test construct_mapping
    obj = {"a": 1, "a": 2}
    data = AnsibleMapping(obj)
    assert data == {"a": 2}

    # test construct_yaml_str
    obj = "str"
    data = AnsibleUnicode(obj)
    assert data == obj

    # test construct_yaml_seq
    obj = [1, 2, 3]
    data = AnsibleSequence(obj)
    assert data == obj

    # test construct_mapping:raise exception
    obj = {"a": 1, "a": 2}

# Generated at 2022-06-20 23:40:42.899457
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    mystr = """
    foo:
        bar: hello
        bam:
            - 1
            - 2
            - 3
    """
    mydict = AnsibleLoader(mystr).get_single_data()
    assert mydict == dict(foo=dict(bar=u"hello", bam=[1, 2, 3]))
    assert isinstance(mydict['foo']['bar'], AnsibleUnicode)
    assert isinstance(mydict['foo']['bam'], AnsibleSequence)
    assert isinstance(mydict['foo'], AnsibleMapping)
    assert mydict.ansible_pos == ('<unicode string>', 1, 0)


# Generated at 2022-06-20 23:40:55.855011
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # Load the test sample data
    test_data = load_fixture('vault_encryption_test.yml')

    # Check we have the expected element in the data
    assert test_data.get('encrypted_variables') is not None

    # Get the mapping node
    mapping_node = test_data.get('encrypted_variables')

    # Instantiate our AnsibleConstructor()
    ac = AnsibleConstructor(file_name='test', vault_secrets=['test_pwd'])

    # Call the method
    ansible_vault = ac.construct_vault_encrypted_unicode(mapping_node)

    # Check it's the correct type
    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)

    # Check it's encrypted

# Generated at 2022-06-20 23:41:01.197959
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    yaml_str = u'test'
    expected_ret = AnsibleUnicode(yaml_str)
    yaml_snippet = u'{0}\n'.format(yaml_str)

    constructor = AnsibleConstructor()
    for loader, node in yaml.load_all(yaml_snippet, Loader=yaml.SafeLoader):
        ret = constructor.construct_yaml_str(node)
        assert ret == expected_ret



# Generated at 2022-06-20 23:41:12.384654
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:41:25.911138
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # AnsibleConstructor.construct_yaml_map() returns an iterator, with the
    # actual data to be loaded being the first and only item in that iterator
    loaded_data = AnsibleLoader(None).construct_yaml_map('''
    a: value a
    b: value b
    c: value c
    ''').next()

    # Since this is just a regular mapping, converting it back to yaml should
    # work fine
    dumped_data = to_bytes(AnsibleDumper().represent_data(loaded_data))

# Generated at 2022-06-20 23:41:34.133389
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    # pylint: disable=protected-access
    yaml_node = object
    yaml_node.id = "tag:yaml.org,2002:map"
    yaml_node.start_mark = object
    yaml_node.start_mark.line = 0
    yaml_node.start_mark.column = 0
    yaml_node.start_mark.name = None
    value = ansible_constructor.construct_yaml_map(yaml_node)
    assert isinstance(value, AnsibleMapping)

# Generated at 2022-06-20 23:41:46.146720
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib
    yaml_str = '{"a": 1, "b": 2, "c": 1, "d": {"a": 1}}'
    constructor = AnsibleConstructor()
    constructor.vault_secrets = []
    constructor._vaults['default'] = VaultLib(secrets=constructor.vault_secrets)
    data = yaml.load(yaml_str, Loader=constructor)
    assert isinstance(data, dict), 'data type is not dict'
    assert data['a'] == 1, 'key a != 1'
    assert data['b'] == 2, 'key b != 2'
    assert data['c'] == 1, 'key c != 1'

# Generated at 2022-06-20 23:41:54.794571
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['vaultpass1']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)


# Generated at 2022-06-20 23:42:05.402219
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    yaml_str = u'''---
- list
- of
- strings
'''
    ansible_seq = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(ansible_seq, AnsibleSequence)
    assert ansible_seq == ['list', 'of', 'strings']

# Generated at 2022-06-20 23:42:16.099283
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml

    input_string = """
a: b
c: d
"""

    input_string = """
a: b
c: d
"""
    yaml_obj = yaml.load(input_string, Loader=AnsibleConstructor)
    assert type(yaml_obj) == AnsibleMapping
    assert yaml_obj['a'] == 'b'
    assert yaml_obj['c'] == 'd'

    # check that the ansible_pos attribute works
    assert yaml_obj.ansible_pos == (None, 1, 0)


# Generated at 2022-06-20 23:42:22.157897
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    c = AnsibleConstructor()
    n = type('MockNode', (object,), {'value': [1, 2, 3], 'start_mark': type('MockMark', (object,), {})})
    seq = c.construct_yaml_seq(n)
    assert next(seq) == []  # the seq is an iterator with a single value, and we consume it
    assert seq.ansible_pos == (None, 1, 0)

# Generated at 2022-06-20 23:42:35.201080
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

# Generated at 2022-06-20 23:42:41.315278
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    node_mapping = MappingNode(None, None, data=[])
    node_mapping.start_mark = 'mark_start'
    node_mapping.end_mark = 'mark_end'
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_yaml_map(node_mapping) is not None

# Generated at 2022-06-20 23:42:54.265823
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    def test_key_duplication_settings(key_duplication, expected_call_count):
        AnsibleLoader.add_multi_implementation("!include", "!include")
        data = AnsibleLoader("""
            a: 1
            a: 2
            a: 3
            a: 4
            a: 5
        """, file_name="foobar.yml", vault_secrets=[], key_duplication=key_duplication).get_single_data()

        assert isinstance(data, AnsibleMapping)
        assert isinstance(data["a"], AnsibleSequence)
        assert len(data["a"]) == 5



# Generated at 2022-06-20 23:43:04.330832
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test AnsibleConstructor.construct_yaml_seq method by simulating
    # the code path of AnsibleConstructor.construct_yaml_map method
    # for AnsibleSequence objects.
    seq = AnsibleConstructor.construct_yaml_seq(
        AnsibleConstructor(),
        MappingNode(tag='tag:yaml.org,2002:map', value=[], flow_style=False)
    )
    seq.next()
    assert isinstance(seq.send([]), AnsibleSequence)
    try:
        seq.close()
    except StopIteration:
        pass

# Generated at 2022-06-20 23:43:08.461010
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = '0123456789ABCDEF'
    sut = AnsibleConstructor('testfilename', vault_secrets='testpassword')
    assert sut.construct_vault_encrypted_unicode(node) == '0123456789ABCDEF'

# Generated at 2022-06-20 23:43:17.085306
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    from yaml.nodes import ScalarNode


# Generated at 2022-06-20 23:43:17.725558
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    pass

# Generated at 2022-06-20 23:43:23.779286
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print('not implemented')



# Generated at 2022-06-20 23:43:30.083632
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Define an input value that is a sequence of dicts
    input = u'[{key1: value1}, {key2: value2}, {key3: value3}]'

    # Convert the input sequence of dicts to a data structure
    data = yaml.load(input, Loader=AnsibleConstructor)

    # Verify that the input sequence of dicts was converted to a data structure
    # that is a sequence of AnsibleMapping objects
    assert isinstance(data, AnsibleSequence)
    assert isinstance(data[0], AnsibleMapping)
    assert isinstance(data[1], AnsibleMapping)
    assert isinstance(data[2], AnsibleMapping)



# Generated at 2022-06-20 23:43:36.445255
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a = AnsibleConstructor()
    map_node = MappingNode()
    map_node.value = [('a', '1'), ('a', '2'), ('b', '3')]
    m = a.construct_mapping(map_node, deep=False)
    assert isinstance(m, AnsibleMapping)
    assert len(m) == 2
    assert m['a'] == '2'
    assert m['b'] == '3'
    assert 'a' in m
    assert 'c' not in m

# Generated at 2022-06-20 23:43:40.748937
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_dict = {
        'this': 'that',
        'test': 'value'
    }
    node = MappingNode('tag:yaml.org,2002:map', test_dict.items(), start_mark=None, end_mark=None)

    ansible_constructor = AnsibleConstructor()
    ansible_mapping = ansible_constructor.construct_yaml_map(node)

    assert isinstance(ansible_mapping, AnsibleMapping)
    assert ansible_mapping.get('this', None) == 'that'

# Generated at 2022-06-20 23:43:44.197516
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    data = 'foo: !unsafe "bar"'
    loader = AnsibleLoader(data, None)
    result = loader.get_single_data()
    assert isinstance(result['foo'], AnsibleUnsafeText)

# Generated at 2022-06-20 23:43:50.987272
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    from ansible.parsing.yaml.objects import AnsibleSequence

    # arrange
    node = SequenceNode(u'tag:yaml.org,2002:str', None, None, None)
    data = AnsibleSequence()
    ac = AnsibleConstructor()

    # act
    data.extend(ac.construct_sequence(node))

    # assert
    assert len(data) == 0

# Generated at 2022-06-20 23:44:01.037867
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import pytest

    # MapNode with key_node.value not hashable

# Generated at 2022-06-20 23:44:13.088242
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import unittest

    from ansible.parsing.yaml.loader import AnsibleLoader

    if sys.version_info[0] < 3:
        class TestAnsibleConstructor(unittest.TestCase):

            def setUp(self):
                self.yaml_str = u"""
                a: 1
                b: 2
                c:
                    a: 3
                    b: 4
                """

                self.yaml_str_unsafe = u"""
                a: !unsafe 1
                b: !unsafe 2
                c:
                    a: !unsafe 3
                    b: !unsafe 4
                """


# Generated at 2022-06-20 23:44:23.416558
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    # The vault password is 'ASDF'

# Generated at 2022-06-20 23:44:27.137108
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    input_value = dict(key=dict(a="b"))
    ac = AnsibleConstructor()

    actual_value = ac.construct_yaml_unsafe(input_value['key'])
    assert actual_value == dict(a="b")

# Generated at 2022-06-20 23:44:45.151042
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
   c = AnsibleConstructor()
   m = MappingNode(None, None, True, None)
   n = AnsibleSequence()
   n.ansible_pos = 'test'
   x = c.construct_yaml_seq(m)
   y = x.next()
   y.extend(n)
   assert y.ansible_pos == 'test'

# Generated at 2022-06-20 23:44:56.990328
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    display.columns = 80
    # tests that the method returns a `AnsibleMapping` object of the type `dict`
    # currently fails on:
    #     self.assertTrue(isinstance(data, dict))
    # cause `data` is a `generator` object instead of a `dict` object
    # so the `assertTrue` fails

    sample_dict = {'foo': 'bar'}
    node = None

    ansible_constructor = AnsibleConstructor()
    data = ansible_constructor.construct_yaml_map(node)
    assert(isinstance(data, generator))
    # self.assertTrue(isinstance(data, dict))
    assert isinstance(data, generator)

    ansible_constructor = AnsibleConstructor(file_name="foo.bar")
    data = ansible_

# Generated at 2022-06-20 23:44:59.424641
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    assert AnsibleConstructor.construct_vault_encrypted_unicode('hello world').data == 'hello world'


__all__ = ['AnsibleConstructor']

# Generated at 2022-06-20 23:45:06.901193
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = MappingNode(tag=u"tag:yaml.org,2002:str", value=[], start_mark=None, end_mark=None)
    node.id = 'vault'

# Generated at 2022-06-20 23:45:07.880572
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-20 23:45:19.349095
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    yaml_str = """
    - hosts: localhost
      gather_facts: no

      tasks:
      - name: test1
        shell: /bin/false
        when: False
      - name: test2
        shell: /bin/false
        when: False
      - name: test3
        shell: /bin/false
        when: False
      - name: test4
        shell: /bin/false
        when: False
"""

    ac = AnsibleConstructor()
    data = yaml.load(yaml_str, Loader=yaml.Loader)
    assert isinstance(data, list)
    for item in data:
        assert isinstance(item, AnsibleMapping)
        assert item.ansible

# Generated at 2022-06-20 23:45:29.527338
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with a no value
    node = MappingNode(tag='tag:yaml.org,2002:map', value=None, flow_style=True)
    sec_constructor = AnsibleConstructor()
    result = sec_constructor.construct_vault_encrypted_unicode(node)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault.secrets == None
    assert result.ansible_pos == ('<string>', 1, 1)
    assert result.data == None

    # Test with a invalid value
    node = MappingNode(tag='tag:yaml.org,2002:map', value=['test', 'test'], flow_style=True)

# Generated at 2022-06-20 23:45:40.359868
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    x = AnsibleLoader(u'[foo, bar]').get_single_data()
    assert isinstance(x[0], AnsibleUnsafeText)
    assert isinstance(x[1], AnsibleUnsafeText)

    y = AnsibleLoader(u'[foo, {a: bar}]', unsafe=True).get_single_data()
    assert isinstance(y[0], AnsibleUnsafeText)
    assert isinstance(y[1], AnsibleMapping)

    z = AnsibleLoader(u'foo: bar', unsafe=True).get_single_data()
    assert isinstance(z, AnsibleMapping)
    assert u'foo' in z

# Generated at 2022-06-20 23:45:51.488175
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    imp = get_import_manager()
    imp.install('pycrypto')
    from ansible.parsing.yaml.objects import VaultEncrypted

    # create ciphertext data with hmac and iv
    vault = VaultLib([])
    data = 'test'
    ciphertext = vault.encrypt(data)
    # the ciphertext should now contain the hmac and the iv

    # first, create the ciphertext data in the old format
    ciphertext2 = '$ANSIBLE_VAULT;0.1;' + vault._get_cipher().cipher.hexlify(to_bytes(data)).decode('ascii')

    node1 = AnsibleMapping()
    node1.value = [ciphertext]

    node2 = AnsibleMapping()
    node2.value = [ciphertext2]

   

# Generated at 2022-06-20 23:45:58.543560
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    def check_elements_of_list(list_to_check, expected_list):
        for item in expected_list:
            assert item in list_to_check


# Generated at 2022-06-20 23:46:22.420820
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = {
        "a": 1,
        "b": 2,
        "c": 3,
    }
    yaml_str = to_bytes(u'''
a: 1
b: 2
aaaa: 4
b: 3
''')
    data_from_yaml = yaml.load(yaml_str, AnsibleConstructor)
    assert data == data_from_yaml, "construct_mapping() method of AnsibleConstructor failed."

# Generated at 2022-06-20 23:46:33.146841
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from yaml import load, dump
    from yaml.nodes import SequenceNode
    from ansible.parsing.yaml.objects import AnsibleUnicode

    ansible_data = load('[str, int, str]', Loader=AnsibleConstructor)

    # assert ansible_data is instance of AnsibleSequence
    assert(isinstance(ansible_data, list))
    assert(isinstance(ansible_data, AnsibleSequence))

    # assert ansible_data[0] is instance of AnsibleUnicode
    assert(isinstance(ansible_data[0], AnsibleUnicode))

    # assert ansible_data.ans

# Generated at 2022-06-20 23:46:40.120320
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data_in = """
- 1
- 2
- 3
"""
    loader = AnsibleLoader(data_in, file_name=None, vault_secrets=None)
    # ansible-playbook asserts that the sequence returned by the load function is of type AnsibleSequence
    # and will raise an exception if it is not
    assert isinstance(loader.get_single_data(), AnsibleSequence) == True

# Generated at 2022-06-20 23:46:43.428145
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    yaml_obj = yaml.load("[1, 2]", Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleSequence)
    assert yaml_obj == [1, 2]


# Generated at 2022-06-20 23:46:56.220471
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class TestConstructor(AnsibleConstructor):
        duplicate_warnings = []
        duplicate_errors = []

        def warning(self, msg):
            self.duplicate_warnings.append(msg)

        def error(self, msg):
            self.duplicate_errors.append(msg)

    # Tests for warning and error for duplicate keys

# Generated at 2022-06-20 23:47:06.949105
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml = "---\n{a: {b: 3, c: 4}, d: 5}\n"
    data = yaml_load(yaml)

    assert(data == {'a': {'b': 3, 'c': 4}, 'd': 5})
    assert(data.ansible_pos == ('<string>', 1, 0))
    assert(data['a'].ansible_pos == ('<string>', 1, 1))
    assert(data['a']['b'].ansible_pos == ('<string>', 1, 4))
    assert(data['a']['c'].ansible_pos == ('<string>', 1, 8))
    assert(data['d'].ansible_pos == ('<string>', 1, 12))

# Generated at 2022-06-20 23:47:18.449126
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    class TestConstructor(yaml.SafeConstructor):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            value = self.construct_scalar(node)
            return AnsibleUnicode(value)

    # Note that this test verifies the behavior of construct_yaml_str,
    # and not construct_yaml_str, whose output is a string
    # See http://pyyaml.org/ticket/90 for more details.
    yaml_str = "foo: bar"
    yaml_data = yaml.load(yaml_str, Loader=TestConstructor)
    assert isinstance(yaml_data, dict)

# Generated at 2022-06-20 23:47:23.015866
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    AnsibleConstructor_ = AnsibleConstructor(None)

    expected = AnsibleMapping()
    expected.ansible_pos = (None, 0, 0)
    result = AnsibleConstructor_.construct_yaml_map(MappingNode(None, None, True, None, None))

    assert result == expected


# Generated at 2022-06-20 23:47:27.293139
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    ac = AnsibleConstructor('/path/to/filename')
    assert ac._ansible_file_name == '/path/to/filename'
    assert '!unsafe' in ac.yaml_constructors
    assert '!vault' in ac.yaml_constructors


# Generated at 2022-06-20 23:47:33.608484
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data='''---
- hosts: cloudm
  tasks:
    - debug: msg="hello world."
'''
    loaded_data=yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert(loaded_data[0]['ansible_pos'] == ('<unicode string>', 1, 0))
    assert(loaded_data[0]['hosts'] == u'cloudm')
    assert(loaded_data[0]['tasks'][0]['debug']['msg'] == u'hello world.')


# Generated at 2022-06-20 23:48:16.327742
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import os
    import io
    import yaml
    ans_constructor = AnsibleConstructor(file_name='file_name')
    test_data = ['a','b','c','d']
    for test_line_no, test_item in enumerate(test_data):
        test_line_no += 1
        # Generate test line number
        test_code = '\n'.join([test_item]*test_line_no)
        file_name = 'file_name'
        line_no = test_line_no
        column = 0
        test_code = u'%s:\n%s' % (file_name, test_code)
        test_code = io.StringIO(test_code).read().replace('\n', '\r\n')
        # Generate test node


# Generated at 2022-06-20 23:48:28.588338
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml

# Generated at 2022-06-20 23:48:38.344754
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = """- bar
- baz
- one: two
- three: four
"""

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, AnsibleSequence), "construct_yaml_seq did not return an AnsibleSequence"

    yaml_str_compare = AnsibleDumper(data, Dumper=AnsibleDumper).get_single_data()
    assert yaml_str == yaml_str_compare, "Did not correctly dump sequence"

# Generated at 2022-06-20 23:48:49.669696
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(u'!test', [], [])
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_mapping(node)

    try:
        ansible_constructor.construct_mapping(1)
    except ConstructorError:
        pass
    else:
        raise Exception("constructor should have failed")

    # Check if adding new member to dict raise proper exception
    node2 = MappingNode(u'!test', [], [['key', 'value'], ['key', 'value']])
    try:
        ansible_constructor.construct_mapping(node2)
    except ConstructorError:
        pass
    else:
        raise Exception("constructor should have failed")

# Generated at 2022-06-20 23:48:54.780206
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    tmp_node = MappingNode(None, None, None, None, None)
    tmp_obj = AnsibleConstructor(None)
    tmp_ret = tmp_obj.construct_mapping(tmp_node)
    assert isinstance(tmp_ret, AnsibleMapping)


# Generated at 2022-06-20 23:49:01.854910
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml
    ansible_constructor = AnsibleConstructor()
    # Case 1
    v = yaml.load("{key1: '1'}", Loader=yaml.Loader)
    assert isinstance(v, AnsibleMapping)
    assert not v.ansible_pos
    w = ansible_constructor.construct_yaml_map(yaml.nodes.MappingNode('test', []))
    assert next(w) == v
    # Case 2
    ansible_constructor.__init__('test')
    v = yaml.load("{key1: '1'}", Loader=yaml.Loader)
    assert not v.ansible_pos
    w = ansible_constructor.construct_yaml

# Generated at 2022-06-20 23:49:13.356460
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Example YAML and Python data structures for testing
    yaml_data = """
        foo:
            bar: 1
            baz: 2
        """
    expected_python_data = {
        'foo': {
            'bar': 1,
            'baz': 2
        }
    }
    # test with no duplicate keys
    python_data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert python_data == expected_python_data
    # test with one duplicate key
    yaml_data_with_dupe = yaml_data + "\n    foo: 3"
    # when 'ignore'
    python_data_with_dupe = yaml.load(yaml_data_with_dupe, Loader=AnsibleConstructor)
    assert python_data_

# Generated at 2022-06-20 23:49:23.426382
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    try:
        import yaml
    except ImportError:
        raise SkipTest("No pyyaml installed")
    import copy
    import sys

    constructors = copy.deepcopy(yaml.constructor.SafeConstructor.yaml_constructors)
    constructors[u'tag:yaml.org,2002:seq'] = AnsibleConstructor.construct_yaml_seq
    yaml.add_constructor(u'tag:yaml.org,2002:seq', AnsibleConstructor.construct_yaml_seq,
                         Loader=yaml.SafeLoader)

    # check for https://github.com/ansible/ansible/issues/17386
    test = """
---
- "string"
- - "list"
  - - "of"
    - "lists"
"""

# Generated at 2022-06-20 23:49:25.264621
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    a = AnsibleConstructor()
    node = "a"
    b = a.construct_yaml_unsafe(node)
    assert b == 'a'
    assert isinstance(b, wrap_var)

# Generated at 2022-06-20 23:49:37.084001
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    test_vault_secrets_file = {'default': '/home/user/.vault_pass.txt'}
    test_file_name = '/home/user/file.yml'
    test_vault_id = 'test_secret_id'

    instance = AnsibleConstructor(file_name=test_file_name, vault_secrets=test_vault_secrets_file)
    test_map_node = MappingNode(None, None, None)
    test_map_node.start_mark = None
    test_map_node.end_mark = None
    test_map_value = instance.construct_mapping(test_map_node, False)

    assert isinstance(test_map_value, AnsibleMapping)
    assert len(test_map_value.ansible_pos) == 3



# Generated at 2022-06-20 23:50:17.000766
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    try:
        from yaml.representer import RepresenterError
    except ImportError:
        from yaml.representer import RepresenterError

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = {'key': 'value'}