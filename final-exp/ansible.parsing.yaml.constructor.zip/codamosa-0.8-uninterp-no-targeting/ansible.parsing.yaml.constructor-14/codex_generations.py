

# Generated at 2022-06-20 23:40:30.743152
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Testing if the method construct_yaml_map returns a AnsibleMapping object
    a = "---\n{A: 1, B: 2}\n"
    a_map = yaml.load(a, Loader=AnsibleConstructor).next()
    assert isinstance(a_map, AnsibleMapping)
    assert a_map[u'A'] == 1
    assert a_map[u'B'] == 2
    assert a_map.ansible_pos == ("<string>", 1, 0)


# Generated at 2022-06-20 23:40:37.966364
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = b'[apples,bananas,pears]'
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_obj = AnsibleLoader(data, file_name='memory').get_single_data()
    assert type(yaml_obj) == list  # This can be either a list or a tuple
    assert yaml_obj == ['apples', 'bananas', 'pears']

# Generated at 2022-06-20 23:40:43.869411
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import load

    data = 'foo: !vault |\n'
    data += '          $ANSIBLE_VAULT;1.1;AES256\n'
    data += '          31396463353530393261333362653536346466326134373337323732633431366134613731376334\n'
    data += '          653631386565353338666530626663373232336630363163386138610a3237353963633661666561\n'
    data += '          64303537313833343164643635383362613232316265363832373831376334363130346238316563\n'

# Generated at 2022-06-20 23:40:53.509932
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    a = '''
    - 1
    - 2
'''
    b = yaml.load(a, Loader=AnsibleConstructor)
    assert b[0] == 1
    assert b[1] == 2
    assert isinstance(b, AnsibleSequence)
    assert isinstance(b[0], int)
    assert isinstance(b[1], int)
    assert b.ansible_pos == (None, 1, 1)
    assert b[0].ansible_pos == (None, 2, 1)
    assert b[1].ansible_pos == (None, 3, 1)


# Generated at 2022-06-20 23:41:02.768943
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import os
    import sys
    import tempfile
    import pytest

    # Setup
    tmp = tempfile.NamedTemporaryFile(mode='w+t', delete=False)
    tmp.write('- hello\n- world\n')
    tmp.close()

    va = AnsibleConstructor(file_name=tmp.name)

    os.environ['ANSIBLE_FORCE_COLOR'] = "1"
    os.environ['ANSIBLE_NOCOLOR'] = "0"
    os.environ['ANSIBLE_HOST_PATTERN_MISMATCH'] = 'error'
    os.environ['ANSIBLE_ERROR_ON_UNDEFINED_VARS'] = 'True'

# Generated at 2022-06-20 23:41:05.931361
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert False, 'This test needs to be filled out'  # remove this line and fill out the rest of this test


# Generated at 2022-06-20 23:41:18.096087
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from yaml.emitter import Emitter
    from yaml.serializer import Serializer
    from yaml.representer import Representer

    yaml_str = '''
- foo: bar
- baz: qux
- quux: corge
'''

    class FakeLoader(object):
        def __init__(self):
            pass

    class FakeStream(object):
        def __init__(self):
            pass

    class FakeNode(object):
        def __init__(self):
            self.tag = u'tag:yaml.org,2002:seq'
            self.start_mark = FakeNodeMark()
            self.end_mark = FakeNodeMark()

# Generated at 2022-06-20 23:41:31.054052
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    # set C.ANSIBLE_VAULT_PASSWORD_FILE as an environment variable
    import os

# Generated at 2022-06-20 23:41:37.823464
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text

    import yaml

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            super(TestAnsibleConstructor, self).__init__(file_name, vault_secrets)
            self._nodes = []

        def construct_yaml_str(self, node):
            self._nodes.append(node)
            return super(TestAnsibleConstructor, self).construct_yaml_str(node)

        def construct_yaml_seq(self, node):
            self._nodes.append(node)
            return super(TestAnsibleConstructor, self).construct_y

# Generated at 2022-06-20 23:41:46.517780
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ####################################################################
    # Test for when a dict key isn't hashable
    ####################################################################
    # A dict with an unhashable key
    context = [{(0, 1): 0, (1, 0): 1}]
    # A node that should contain the dict
    node = MappingNode(None, None, True, None, None)
    # A constructor to test
    constructor = AnsibleConstructor()

    # If the key is unhashable, construct_mapping should raise an error
    # of type ConstructorError
    try:
        constructor.construct_mapping(node)
    except ConstructorError as error:
        assert error
    else:
        assert False

# Generated at 2022-06-20 23:41:58.713180
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    test_string = '12345'
    test_yaml_str = """test_str: {0}""".format(test_string)
    import yaml
    yaml_dict = yaml.load(test_yaml_str, Loader=AnsibleConstructor)

    assert type(yaml_dict['test_str']) == AnsibleUnicode
    assert yaml_dict['test_str'] == test_string

# Unit tests for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-20 23:42:01.843143
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ac = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

    assert isinstance(ac.construct_yaml_map(node), AnsibleMapping)



# Generated at 2022-06-20 23:42:09.896860
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    input = """
- foo: bar
- foo: baz
"""
    loader = AnsibleLoader(input, 'non-existent-filename')
    (data) = loader.get_single_data()
    assert data[0]['foo'] == 'bar'
    assert data[1]['foo'] == 'baz'
    assert isinstance(data, AnsibleSequence)


# Generated at 2022-06-20 23:42:21.812895
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """Unit test for AnsibleConstructor.construct_yaml_seq()
    """
    import yaml
    class Node():
        def __init__(self, value, tag, *args):
            self.value = value
            self.tag = tag
            self.start_mark = self.end_mark = None
            for a in args:
                if a.startswith('start_mark'):
                    self.start_mark = a[12:]
                elif a.startswith('end_mark'):
                    self.end_mark = a[10:]

    # dict
    node = Node([('a', 1)], 'tag:yaml.org,2002:map', u'start_mark=None, end_mark=None')
    ac = AnsibleConstructor()

# Generated at 2022-06-20 23:42:30.435042
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml import AnsibleSafeDumper

    # Test that duplicate keys are not allowed when
    # ansible.cfg:duplicate_yaml_dict_key = error
    test_yaml = '''
a:
  - key1: value1
  - key2: value2
a:
  - key1: value_overwritten
    key2: value_not_overwritten
'''
    AnsibleConstructor.add_constructor(u'tag:yaml.org,2002:str', AnsibleConstructor.construct_yaml_str)
    AnsibleConstructor.add_constructor(u'!vault', AnsibleConstructor.construct_vault_encrypted_unicode)


# Generated at 2022-06-20 23:42:36.370263
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    data = """
      test:
      - str1
      - str2
    """
    constructor = AnsibleConstructor()
    ansible_constant = AnsibleUnicode('test')
    yaml_constant = yaml.loader.SafeLoader.construct_yaml_str(constructor, ansible_constant)
    assert isinstance(yaml_constant, AnsibleUnicode)



# Generated at 2022-06-20 23:42:48.684038
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """ test_AnsibleConstructor_construct_yaml_seq """
    yaml_data = """
    foo:
      - name: test_1
      - name: test_2
      - name: test_3
      - name: test_4
      - test_5
    """

    obj = yaml.load(yaml_data, Loader=AnsibleLoader)

    if obj != {u'foo': [{u'name': u'test_1'}, {u'name': u'test_2'}, {u'name': u'test_3'}, {u'name': u'test_4'}, u'test_5']}:
        raise AssertionError('Failed to convert yaml data to AnsibleSequence')

# Generated at 2022-06-20 23:42:55.288209
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # we don't want to use a real vault lib here
    vault_secrets = ['']
    ac = AnsibleConstructor(vault_secrets=vault_secrets)
    """
    Constructor Stuff:
    """
    obj = 'helloworld'
    yaml_str = '''
        helloworld:
            test: test
      '''
    yaml_obj = ac.construct_yaml(io.StringIO(yaml_str))
    assert obj + '.test' in yaml_obj
    obj = 'test_construct_yaml_map'
    yaml_str = '''
        test_construct_yaml_map: {test:test}
     '''
    yaml_obj = ac.construct_yaml(io.StringIO(yaml_str))
    assert obj in y

# Generated at 2022-06-20 23:42:59.922510
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    obj = AnsibleConstructor()
    test_token = {'test_token': 'test_value'}
    result = obj.construct_yaml_seq(test_token)
    assert result



# Generated at 2022-06-20 23:43:10.593299
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create a AnsibleConstructor object
    ansible_constructor_obj = AnsibleConstructor(file_name='test_AnsibleConstructor_construct_vault_encrypted_unicode')
    # create vault secrets

# Generated at 2022-06-20 23:43:33.581461
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    tc = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'test_data')
    tc.value = 'test_data'
    # ansible_constructor.vault_secrets is set to [] so the given data is not
    # decrypted; it is just stored in AnsibleVaultEncryptedUnicode
    ret = ansible_constructor.construct_vault_encrypted_unicode(tc)
    assert ret._ciphertext_data == 'test_data'
    ansible_constructor.vault_secrets = ['test_data']
    vault = ansible_constructor._vaults['default']
    # This is the call that is tested
    ret = ansible_constructor.construct_vault_encrypted_unicode

# Generated at 2022-06-20 23:43:40.599322
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import YAML
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256Engine
    from ansible.parsing.vault import VaultAES256Cipher

    # vault_secret must be set if vault_secrets is
    # Note: vault_secrets is a list of tuples
    vault_secret = u'vault_test_password'
    vault_secrets = [(vault_secret, VaultSecret.SHA1Type)]

# Generated at 2022-06-20 23:43:53.852335
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    """This is a test of the AnsibleConstructor class.
    """
    a_constructor = AnsibleConstructor()

    # Test the YAML constructor
    a_yaml_map = a_constructor.construct_yaml_map(MappingNode)

    # Test the Ansible Mapping constructor
    a_mapping = a_constructor.construct_mapping(MappingNode)

    # Test the string constructor
    a_string = a_constructor.construct_yaml_str(MappingNode)

    # Test the sequence constructor
    a_seq = a_constructor.construct_yaml_seq(MappingNode)

    # Test the unsafe constructor
    a_unsafe = a_constructor.construct_yaml_unsafe(MappingNode)

    assert a_yaml_map is not None
    assert a

# Generated at 2022-06-20 23:44:02.699604
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self):
            self.mapping_data = None
            super(TestAnsibleConstructor, self).__init__()

        def construct_yaml_map(self, node):
            data = AnsibleMapping()
            yield data
            self.mapping_data = self.construct_mapping(node)
            data.update(self.mapping_data)

    yaml_str = u"this:\n  is:\n    a:\n      map:\n        of:\n          stuff"
    result = TestAnsibleConstructor.to_yaml(yaml_str)
    assert isinstance(result, AnsibleMapping)
    assert result.ansible_pos == (u'<unicode string>', 1, 0)
   

# Generated at 2022-06-20 23:44:12.789927
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from collections import OrderedDict

    yaml_str = """
key1: val1
key2: val2
key1: val3
    """

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)

    assert isinstance(data, dict)
    assert len(data) == 3
    # when 'ignore', the value is not updated (verify that key1: val3 is ignored)
    assert OrderedDict(data) == OrderedDict([('key1', 'val1'), ('key2', 'val2'), ('key1', 'val3')])


# Generated at 2022-06-20 23:44:20.640295
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [u'asdf', u'qwer']
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    vault_secrets_result = constructor.vault_secrets
    assert vault_secrets == vault_secrets_result

    string_value = u'test_string'
    string_node = u'!vault test_string'
    vault_encrypted_unicode = constructor.construct_vault_encrypted_unicode(string_node)
    assert isinstance(vault_encrypted_unicode, unicode)
    assert vault_encrypted_unicode == string_value

# Generated at 2022-06-20 23:44:31.691917
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml.parser import Parser
    from yaml.scanner import Scanner
    from io import StringIO


# Generated at 2022-06-20 23:44:39.564610
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    constructor = AnsibleConstructor()

    class MyMapping(AnsibleMapping):
        pass

    node = MyMapping()
    result = constructor.construct_yaml_map(node)

    assert isinstance(result, generator)
    assert next(result) is node
    assert isinstance(next(result), MyMapping)

    try:
        next(result)
    except StopIteration:
        pass
    else:
        assert False

# Generated at 2022-06-20 23:44:45.546899
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    # Note: All of following is a "safe" constructor.
    #  - unsafe attribute is not exposed by the yaml module
    #  - the default constructor AnsibleConstructor.construct_object
    #    can be called safely by other constructor
    yaml_data = """
        - 1
        - 2
        - "hello!"
        - !unsafe '"hello!"'
        """
    yaml.load(yaml_data, Loader=AnsibleConstructor)

# Generated at 2022-06-20 23:44:57.436356
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

# Generated at 2022-06-20 23:45:24.625204
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils.six import text_type

    yaml_text = u'--- !unsafe "!foo"\n'
    yaml_instance = AnsibleConstructor(None)
    result = yaml_instance.construct_yaml_unsafe(yaml_instance.construct_yaml_unsafe.__name__, yaml_text)

    assert isinstance(result, text_type)
    assert result == u'!foo'

# Generated at 2022-06-20 23:45:31.513660
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple dict
    data_dict = {
        "key": "value",
        "key2": "value2",
    }
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(data_dict) is None
    # Test with a nested dict
    data_dict = {
        "key": "value",
        "key2": {
            "key3": "value3",
            "key4": "value4",
        }
    }
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(data_dict) is None


# Generated at 2022-06-20 23:45:39.103490
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    CONSTRUCTOR = AnsibleConstructor()
    line, column = 3, 7
    node = MappingNode('tag:yaml.org,2002:map', [], None, None, None, None)
    node.start_mark.line = line
    node.start_mark.column = column
    data = CONSTRUCTOR.construct_yaml_seq(node)
    assert isinstance(data, AnsibleSequence)
    assert data.ansible_pos == ('<string>', line + 1, column + 1)

# Generated at 2022-06-20 23:45:50.293089
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import sys
    print(sys.version)
    print(sys.version_info)

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultSecret

    # define a test yaml
    yaml_str = """
        a:
            b:
                - 1
                - 2
            c: "Hello World"
    """

    # define the vault secrete
    vault_secret = VaultSecret(['test'])
    # construct the yaml constructor
    yaml_constructor = AnsibleConstructor(vault_secrets=vault_secret)
    # construct the yaml loader with yaml_constructor

# Generated at 2022-06-20 23:45:58.009511
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # This is what a typical yaml document looks like
    yaml_data = '''\
- hosts: all
  vars:
    ansible_user: root
  tasks:
    - name: return the ansible_user variable
      debug:
        msg: "{{ ansible_user }}"
'''

    # Expected result

# Generated at 2022-06-20 23:46:10.275485
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import os
    import tempfile
    import yaml
    from ansible.parsing.vault import VaultLib

    temp_dir = tempfile.mkdtemp()
    file_name = os.path.join(temp_dir, 'file.yaml')
    vault_file_name = os.path.join(temp_dir, 'vault.key')

    # Create an encrypted file

# Generated at 2022-06-20 23:46:13.874112
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    node.value = [('name', MappingNode(u'tag:yaml.org,2002:str', []))]
    node.start_mark = node.end_mark = None
    constructor = AnsibleConstructor()
    constructor.construct_yaml_seq(node)

# Generated at 2022-06-20 23:46:18.359177
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    AC = AnsibleConstructor()
    r_yaml = b"""!unsafe "a string without quotes" """
    data_unsafe = AC.construct_yaml_unsafe(r_yaml)
    assert isinstance(data_unsafe, AnsibleUnsafeText)
    assert data_unsafe == b"a string without quotes"

# Generated at 2022-06-20 23:46:29.274772
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    yaml_str=u"""
nested1:
   nested2:
      nested3: 1234
      nested4:
         - fred
         - jane
      nested5:
         nested6: "hello world"
"""

    aconstructor = AnsibleConstructor()

    data = aconstructor.construct_yaml(yaml_str)

    assert data == {
        u"nested1": {
            u"nested2": {
                u"nested3": 1234,
                u"nested4": [
                    u"fred",
                    u"jane"
                ],
                u"nested5": {
                    u"nested6": u"hello world"
                }
            }
        }
    }

# Generated at 2022-06-20 23:46:40.342737
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_mapping = {'m1': 'm1_value', 'm2': 'm2_value', 'm3': 'm3_value'}

    # construct_mapping() return the AnsibleMapping object
    ac = AnsibleConstructor(file_name='example.yaml')
    yaml_mapping = AcYamlMapping(test_mapping, deep=True, constructor=ac)
    ret = ac.construct_mapping(yaml_mapping)
    assert isinstance(ret, AnsibleMapping)
    assert ret == test_mapping

    # construct_mapping() add ansible_pos property to constructed object
    ac = AnsibleConstructor(file_name='example.yaml')
    yaml_mapping = AcYamlMapping(test_mapping, deep=True, constructor=ac)

# Generated at 2022-06-20 23:47:10.426634
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils._text import to_bytes
    # For DES3 we need at least 24 chars secret
    secret = 'dummy-test-vault-secret-777'
    vault = VaultLib([secret], [], 1)

# Generated at 2022-06-20 23:47:22.662985
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO

    data = '''
    - foo
    - bar
    '''
    def test_method(data, loader_class, verbose=False):
        import yaml

        yaml_data = yaml.load(data, loader_class)
        assert(isinstance(yaml_data, list) is True)

        for item in yaml_data:
            assert(isinstance(item, AnsibleUnicode) is True)

        if verbose:
            print("yaml_data: %s" % yaml_data)

    # Manually invoke the constructor
    test_method(data, AnsibleConstructor)

    # Use the loader class
    test_method(data, AnsibleLoader)

    # Load the data from

# Generated at 2022-06-20 23:47:28.481782
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(tag="!<tag:yaml.org,2002:map>", value=[], flow_style=True)
    asc = AnsibleConstructor()
    expected = {'ansible_pos': (None, None, None)}
    actual = asc.construct_yaml_map(node)

    assert isinstance(actual, AnsibleConstructor.construct_yaml_map)
    assert next(actual)._data == expected



# Generated at 2022-06-20 23:47:30.805070
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    obj = AnsibleConstructor()
    result = obj.construct_yaml_map('name')
    assert isinstance(result,AnsibleMapping)



# Generated at 2022-06-20 23:47:37.640584
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    """
    AnsibleConstructor:

    If a user has a playbook or role with a reserved word used as a variable,
    ensure that we are not getting the value of the reserved word rather than
    the variable itself.
    """

    from ansible.parsing.yaml.loader import AnsibleLoader

    class Foo(object):
        def __unicode__(self):
            return u'Foo'

        def __repr__(self):
            return u'Foo'

        def __getattr__(self, name):
            return Foo()

    foo = Foo()

    for key, value in {
        'Foo': foo,
        'bar': 'baz',
        'bam': foo,
    }.items():
        # Check that the constructor works on unicode and str data.
        input_data = to_

# Generated at 2022-06-20 23:47:44.967837
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    # Test AnsibleUnicode as string converted to dict
    a = dict()
    a['unicode'] = AnsibleUnicode('a string')
    a['date'] = AnsibleUnicode(datetime.datetime.now())
    x = AnsibleConstructor().construct_yaml_unsafe(a)

    assert x['date'] == datetime.datetime.now()

# Generated at 2022-06-20 23:47:54.619084
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.constructors import AnsibleConstructor
    from collections import namedtuple
    from yaml.nodes import MappingNode
    from yaml.constructor import ConstructorError

    Position = namedtuple('Position', ['datasource', 'line', 'column'])

    def test_construct_yaml_seq(node, ansible_seq):
        assert node.id == 'tag:yaml.org,2002:seq'
        data = AnsibleMapping()
        constructor = AnsibleConstructor()
        constructor.construct_yaml_seq(node)
        assert data.ansible_seq == ansible_seq


# Generated at 2022-06-20 23:47:59.195697
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    c = AnsibleConstructor()
    import datetime
    try:
        c.construct_yaml_unsafe(datetime.datetime.now())
    except ValueError as e:
        if 'could not determine a constructor for the tag' in to_native(e):
            return
    raise AssertionError('AnsibleConstructor.construct_yaml_unsafe should raise ValueError')

# Generated at 2022-06-20 23:48:12.173183
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # FIXME: This is too simple, add more tests
    #        This test should be added to AnsibleConstructorTest
    import os
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    basedir = os.path.join(os.path.dirname(__file__), 'test_yaml_mapping')
    for filename in ('duplicate_key_warning.yaml', 'duplicate_key_error.yaml', 'duplicate_key_ignore.yaml'):
        path = os.path.join(basedir, filename)
        with open(path, 'r') as f:
            data = f.read()
        obj = AnsibleLoader(data, file_name=path).get_

# Generated at 2022-06-20 23:48:16.088328
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping

    data = {'x': 1}

    # Load data into AnsibleConstructor
    obj = AnsibleConstructor(file_name='test').construct_yaml_map(node=data)

    # Test that AnsibleConstructor is equal to AnsibleMapping
    assert(isinstance(obj, AnsibleMapping))

# Generated at 2022-06-20 23:48:49.159037
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.playbook.play import Play
    c = AnsibleConstructor()

# Generated at 2022-06-20 23:48:59.200582
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.playbook.play_context import PlayContext
    from io import BytesIO, StringIO
    x = """
    aiida:
        test: 1
        test: 2
    """
    a = AnsibleConstructor(file_name='test.yml')
    # aiida:
    #     test: 1
    assert a.construct_yaml_seq(yaml.compose(x))
    x = """
    aiida:
        test: 1
        test: 2
    """
    a = AnsibleConstructor(file_name='test.yml')
    # aiida:
    #     test: 1
    assert a.construct_yaml_map(yaml.compose(x))

# Generated at 2022-06-20 23:49:09.922028
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # import needed method
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    test_yaml = """
a: 1
b: !b [2, 3]
c:
  - 1
  - 2
  - 3
d:
  1: d1
  2: d2
  3: d3
fault: "fault"
"""

    yaml_obj = AnsibleLoader(test_yaml, file_name='test_AnsibleConstructor').get_single_data()

    # check the type of objects
    assert isinstance(yaml_obj, dict)
    assert isinstance(yaml_obj['a'], AnsibleUnicode)

# Generated at 2022-06-20 23:49:20.826127
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_passwords = ['test_password']

# Generated at 2022-06-20 23:49:27.995926
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    assert hasattr(yaml, 'CSafeLoader')
    assert hasattr(yaml, 'CSafeDumper')
    assert not hasattr(yaml, 'SafeLoader')
    assert not hasattr(yaml, 'SafeDumper')

    # Make sure we're actually testing what we think we're testing
    assert isinstance(AnsibleConstructor, type(yaml.CSafeLoader))

    loader = AnsibleConstructor()
    assert isinstance(loader, type(yaml.CSafeLoader))

    # We should still be able to load old-style YAML

# Generated at 2022-06-20 23:49:38.939452
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class MockVaultLib(object):

        def __init__(self, secrets=None):
            self.secrets = secrets

    yaml_map = {'name': {'last': 'doe', 'first': 'john'},
                'age': '42',
                'dependencies': ['ansible', 'python']}
    yaml_string = to_bytes(u'---\nname:\n    last: doe\n    first: john\nage: 42\ndependencies:\n    - ansible\n    - python\n')

    class MockNode(object):
        """
        A mock class to represent a YAML node from the PyYAML library.
        """
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-20 23:49:48.031460
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_case = [
        {
            'input': '''
            - 1
            - 2
            - 3
            ''',
            'expected_output': [1, 2, 3],
            'expected_output_type': AnsibleSequence,
        },
        {
            'input': '''
            - 1
            - 2
            - 3
            ''',
            'expected_output': [1, 2, 3],
            'expected_output_type': AnsibleSequence,
        },
    ]
    for tc in test_case:
        ac = AnsibleConstructor()
        result = ac.construct_yaml_seq(tc['input'])
        for r in result:
            assert isinstance(r, tc['expected_output_type'])
            assert r == tc['expected_output']

# Generated at 2022-06-20 23:49:51.506439
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = '''
---
- hosts: localhost
  tasks:
    - name: test
      debug: msg="Hello World!"
'''
    try:
        AnsibleLoader(data)
    except ConstructorError:
        pass

# Generated at 2022-06-20 23:50:02.012983
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-20 23:50:11.881534
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from yaml import BaseLoader

    ansible_constructor = AnsibleConstructor()

    # Test case: Construct an empty list
    input_str = u'[]'
    output = yaml.load(input_str, Loader=BaseLoader)
    expected_output = list()
    assert output == expected_output

    # Test case: Construct a list with one element
    input_str = u'[1]'
    output = yaml.load(input_str, Loader=BaseLoader)
    expected_output = [1]
    assert output == expected_output

    # Test case: Construct a list with two elements
    input_str = u'[1, 2]'
    output = yaml.load(input_str, Loader=BaseLoader)
    expected_output = [1, 2]