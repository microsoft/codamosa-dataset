

# Generated at 2022-06-20 23:40:33.159100
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    
    vault_password = 'secret'
    vault_secrets = [VaultSecret('default', vault_password)]
    
    # Create vault with password
    vault = VaultLib(secrets=vault_secrets)
    
    # Create ciphertext
    vault_text = vault.encrypt(b'MySecret')
    
    # Create AnsibleConstructor object
    ac = AnsibleConstructor(vault_secrets=vault_secrets)
    
    # Create node
    node = dict()
    node['tag'] = 'tag:yaml.org,2002:str'
    node['start_mark'] = dict()
    node['start_mark']['column'] = 0
    node

# Generated at 2022-06-20 23:40:45.577124
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    '''test_AnsibleConstructor_construct_vault_encrypted_unicode'''
    # The vault password used by Ansible to encrypt the encrypted data
    vault_secret = 'test_vault_secret'
    # The vault secret in a list is necessary when secret is used to construct
    # the VaultLib, which is then used by AnsibleConstructor.
    vault_secrets = [vault_secret]
    # The ciphertext for the clear text of "test_clear_text" encrypted by Ansible
    # (The vault password used to encrypt is "test_vault_secret")

# Generated at 2022-06-20 23:40:54.677777
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib
    my_res = VaultLib()
    secret = 'ansible'
    try:
        my_res.decrypt(secret)
    except TypeError:
        secret = [secret]
    my_res.secrets = []
    my_res.secrets.append(secret)

# Generated at 2022-06-20 23:41:02.247930
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader

    try:
        import json
    except ImportError:
        import simplejson as json

    data = {'a': 'test'}
    value = json.dumps(data)
    yaml_data = ("!!python/object/apply:"
                 "json.loads [ '{0}' ]").format(value)
    ansible_constructor = AnsibleConstructor()
    loaded_data = AnsibleLoader(yaml_data, ansible_constructor).get_single_data()
    assert loaded_data == data, 'Expected %s, got %s' % (data, loaded_data)

# Generated at 2022-06-20 23:41:03.909427
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # TODO: test AnsibleConstructor
    pass

# Generated at 2022-06-20 23:41:16.265674
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    """
    Test AnsibleConstructor.construct_vault_encrypted_unicode() method
    The text length is 18(bytes) and it is in the middle of ciphertext
    length 32(bytes)
    """
    import textwrap
    import yaml
    import ansible.constants
    ansible.constants.DUPLICATE_YAML_DICT_KEY = 'ignore'
    ansible.constants.DEFAULT_VAULT_ID_MATCH = r'^[A-Za-z0-9]{8}$'

# Generated at 2022-06-20 23:41:28.133032
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    constructer = AnsibleConstructor()
    test_yaml = '''
    - name: "hey"
      id: 1
      id: 2
      bool_var: True
      float_var: 0.05
      "key with space": "value with space"
    '''
    test_data = constructer.construct_yaml(test_yaml)
    assert isinstance(test_data, list) is True
    assert isinstance(test_data[0],AnsibleMapping) is True
    assert test_data[0]["bool_var"] == True
    assert test_data[0]["float_var"] == 0.05
    assert test_data[0]["key with space"] == "value with space"

# Generated at 2022-06-20 23:41:36.578675
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create a SafeConstructor to test against
    sc = SafeConstructor()
    sc.add_constructor(u'tag:yaml.org,2002:map', sc.construct_yaml_map)
    sc.add_constructor(u'tag:yaml.org,2002:str', sc.construct_yaml_str)

    # Create a test node
    node = {
        'a': 'b',
        'c': 'd'
    }

    sc_ret = sc.construct_yaml_map(node)
    ac_ret = AnsibleConstructor.construct_yaml_map(node)

    assert isinstance(sc_ret, type(sc))
    assert isinstance(ac_ret, AnsibleMapping)
    assert ac_ret.ansible_pos == (None, None, None)

# Generated at 2022-06-20 23:41:47.439902
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import yaml
    secret_data = '$ANSIBLE_VAULT;1.1;AES256\n3452345234523452345234523452345234523452345234523452345234523452\n'
    secret_data += '225234523452345234523452345234523452345234523452345234523452345234523452\n'

# Generated at 2022-06-20 23:41:59.219623
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    """
    Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
    """

    # This variable will be populated with the instance of AnsibleConstructor
    ansibleConstructor = None

    try:
        # Create an instance of AnsibleConstructor
        ansibleConstructor = AnsibleConstructor()
    except Exception as e:
        raise Exception("Unable to create an instance of class AnsibleConstructor, aborting")

    # This variable will be populated with the ciphertext data which will be used in the unit tests
    ciphertext_data = None


# Generated at 2022-06-20 23:42:18.633199
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from yaml.nodes import MappingNode
    from yaml.constructor import ConstructorError

    ansible_constructor = AnsibleConstructor()
    yaml_str = '''
    test_ok:
      name: test1
    test_multi_dict_keys:
      name: test2
      name: test3
    test_duplicate_keys:
      - name: test4
      - name: test5
    '''
    yaml_obj = yaml.load(yaml_str, Loader=yaml.Loader)
    yaml_map = yaml.dump(yaml_obj, Dumper=yaml.Dumper)
    assert isinstance(yaml_obj, dict) is True, "yaml_obj should be a dict"

# Generated at 2022-06-20 23:42:28.604956
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    class TestVaultLib(VaultLib):
        def update(self, filename, text, password=None, vault_id=None):
            print(filename)
            print(text)
            print(password)
            print(vault_id)
            pass

    class TestConstructor(AnsibleConstructor):
        def construct_vault_encrypted_unicode(self, node):
            print(self.vault_secrets)
            pass

    node = lambda:None

# Generated at 2022-06-20 23:42:32.845976
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert AnsibleConstructor._vaults == {}
    assert AnsibleConstructor.vault_secrets == []

    # FIXME: how do we test this part?
    #def construct_yaml_map(self, node):
    #def construct_yaml_seq(self, node):

    # FIXME: how do we test this part?
    #def construct_vault_encrypted_unicode(self, node):

# Generated at 2022-06-20 23:42:45.995787
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    bytes = 'test'.encode('utf-8')
    chars = bytes.decode('utf-8')
    # test with default vault
    vault = VaultLib()
    vault.secrets = ['test']
    vault.chunk_size = 4
    crypt_text = vault.encrypt(bytes)
    expected = AnsibleVaultEncryptedUnicode(crypt_text)
    expected.vault = vault
    # test with vault object
    actual = AnsibleConstructor(vault_secrets=['test']).construct_vault_encrypted_unicode(
        AnsibleDumper().represent_data(crypt_text))
    assert actual == expected
    # test round trip
    assert chars == actual.vault.decrypt(actual)
   

# Generated at 2022-06-20 23:42:48.352492
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    my_constructor = AnsibleConstructor()
    my_constructor.construct_mapping([('scalar', 'value')])


# Generated at 2022-06-20 23:43:02.253886
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    yaml_str = """
        d0:
            d1:
                key: 0
                key: 1
                key: 2
                key: 3
            d2:
                key: 0
                key: 1
                key: 2
                key: 3
        """
    data = yaml.load(yaml_str, Loader=yaml.Loader)
    assert data == {'d0': {'d1': {'key': 3}, 'd2': {'key': 3}}}
    print(data)
    for key, values in data.items():
        print(key)
        for k, v in values.items():
            print(k)
            print(v)

if __name__ == '__main__':
    test_AnsibleConstructor_construct_yaml_map()

# Generated at 2022-06-20 23:43:12.395016
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test cases for function construct_yaml_map
    #
    # Test case function name is of the form "test_<test-case-number>_<optional-description>"
    # Test case class name is TestAnsibleConstructor

    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import YAMLLoader

    class DummyYamlConstructor(AnsibleConstructor):
        pass

    # Test case 1
    # Test case data
    tc1_yaml_data = '''\
        key1:
          nestedkey1: test_value
          nestedkey2: another_value
        key2:
          nestedkey1: test_value
          nestedkey2: another_value
    '''

    tc

# Generated at 2022-06-20 23:43:19.312515
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    import unit_test_utils.unit_test_utils as unit_test_utils

    # Construct the AnsibleConstructor with vault_secrets passed in.
    # Set up a vault object named "default" without any secrets on it.
    # Run method construct_vault_encrypted_unicode using a node object to test the logic.
    # Confirm that the method raises an error.

# Generated at 2022-06-20 23:43:32.037439
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml = """
    foo: bar
    bar: foo
    """
    data = AnsibleConstructor().construct_mapping(
        AnsibleConstructor().construct_yaml_map(
            yaml_parse(yaml)).__getstate__()['data']
    )
    assert data['foo'] == 'bar'
    assert data['bar'] == 'foo'

    yaml = """
    foo: bar
    foo: foo
    """
    data = AnsibleConstructor().construct_mapping(
        AnsibleConstructor().construct_yaml_map(
            yaml_parse(yaml)).__getstate__()['data']
    )
    assert data['foo'] == 'foo'

# Generated at 2022-06-20 23:43:42.086593
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # TODO: This should be in a test module
    class MockParser():
        def __init__(self, filename, data, vault_secrets):
            self._data = data
            self._filename = filename
            self._ansible_file_name = filename
            self._vault_secrets = vault_secrets

        def items(self):
            for item in self._data:
                # Make it look like it was parsed from the YAML
                # to keep positional information correct
                yield item

    class MockModule():
        def __init__(self):
            self.params = dict()


# Generated at 2022-06-20 23:43:57.823088
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test that we can get the same result as before when using AnsibleConstructor and AnsibleSequence
    yaml_str = """
    ---
    - one: 2
    - three: four
    """
    ansible_extend_constructor_flag = True
    ansible_yaml_constructor = AnsibleConstructor(file_name="test_file", vault_secrets=['secret_vault_password'])
    ansible_safe_load(yaml_str, ansible_yaml_constructor, ansible_extend_constructor_flag, 'test_file')



# Generated at 2022-06-20 23:44:08.440143
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = b"""\
a: 1
b: 2
"""
    yaml_data = to_bytes(yaml_data)

    yaml_data_with_duplicate_key = b"""\
a: 1
a: 2
"""
    yaml_data_with_duplicate_key = to_bytes(yaml_data_with_duplicate_key)

    yaml_data_with_ignore = b"""\
a: 1
a: 2
"""
    yaml_data_with_ignore = to_bytes(yaml_data_with_ignore)

    yaml_data_with_error = b"""\
a: 1
a: 2
"""
    yaml_data_with_error = to_bytes(yaml_data_with_error)

    yaml_data_complex

# Generated at 2022-06-20 23:44:13.976958
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = {'foo': 'bar', 'baz': 42}
    ansible_map = AnsibleConstructor().construct_yaml_map(node)
    assert isinstance(ansible_map, AnsibleMapping)
    assert ansible_map.ansible_pos == (None, None, None)



# Generated at 2022-06-20 23:44:21.347874
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import UnsafeText
    c = AnsibleConstructor()
    assert isinstance(c.construct_yaml_unsafe('foo'), UnsafeText)
    assert isinstance(c.construct_yaml_unsafe(u'foo'), UnsafeText)
    assert isinstance(c.construct_yaml_unsafe('foo'.encode()), UnsafeText)
    assert isinstance(c.construct_yaml_unsafe(AnsibleUnicode('foo')), UnsafeText)

# Generated at 2022-06-20 23:44:32.591734
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.parsing.vault as vault
    import yaml
    import os
    from mock import patch
    import tempfile
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class test_node():
        start_mark = None

    # create temporary yaml file
    test_yaml_file = tempfile.NamedTemporaryFile(delete=False)
    test_yaml_file.close()

    def _test_method(args, expected_results):
        # get current directory
        old_cwd = os.getcwd()
        # change to tempfile directory

# Generated at 2022-06-20 23:44:39.158969
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    class MockNode(object):
        pass

    class MockConstructor(object):
        def construct_object(self, node):
            return(node)

    constructor = AnsibleConstructor()
    constructor.construct_object = MockConstructor.construct_object

    actual = constructor.construct_yaml_unsafe(MockNode())
    expected = wrap_var(MockNode())
    assert actual == expected


# Generated at 2022-06-20 23:44:48.331675
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_text = '''
- hosts: all
  tasks:
    - debug:
        msg: "test"
    - shell: "echo 'test'"
    - shell: "echo 'test'"
'''

    try:
        from ansible.plugins.loader import PluginLoader
        from ansible.plugins.loader import look_for_plugins
        from ansible.plugins.task.normal import TaskModule
        from ansible.module_utils.six import PY3
    except ImportError:
        pytest.skip('Unable to import ansible plugins')

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a fake plugins directory
    # We need the following structure:
    # * plugins/action
    # ** plugins/action/__init__.py
    #

# Generated at 2022-06-20 23:44:56.898288
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode

    assert isinstance(AnsibleLoader(None).construct_yaml_map({}), AnsibleMapping)
    assert isinstance(AnsibleLoader(None).construct_yaml_str({}), AnsibleUnicode)
    assert isinstance(AnsibleLoader(None).construct_yaml_seq({}), AnsibleSequence)

# Generated at 2022-06-20 23:45:02.984368
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_yaml_seq = '- { key: val }\n- key: val'
    test_yaml_seq_expected_value = AnsibleSequence([AnsibleMapping({'key': 'val'}), AnsibleMapping({'key': 'val'})])

    ac = AnsibleConstructor()
    test_yaml_seq_value = ac.construct_yaml_seq(load(test_yaml_seq))
    assert test_yaml_seq_value == test_yaml_seq_expected_value

# Generated at 2022-06-20 23:45:05.998254
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_constructor = AnsibleConstructor()
    yaml_seq = yaml_constructor.construct_yaml_seq(None)
    assert yaml_seq is not None



# Generated at 2022-06-20 23:45:23.985527
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # This is a mapping whose keys have 'unsafe' tags.
    test_yaml_str = StringIO("""
        foo: !unsafe false
        bar: !unsafe true
        baz: !unsafe {a: 1, b: 2}""")

    # Check the unsafe tag was removed and keys were converted to strings
    test_dict = {'foo': False, 'bar': True, 'baz': {'a': 1, 'b': 2}}

    # The only unsafe tag we support is 'False'
    test_yaml_str_bad = StringIO("""
        foo: !unsafe bar""")

    ansible_constructor = AnsibleConstructor(None)
    assert ansible

# Generated at 2022-06-20 23:45:32.188003
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    import ansible.constants as C
    ansible_file_name = "test_file.yml"
    yaml_input_obj = """
    a: 1
    b: 2
    c:
        d: 4
        e: 5
    """
    import copy
    original_flag = copy.deepcopy(C.DUPLICATE_YAML_DICT_KEY)  # Make a copy so that we can restore it later

# Generated at 2022-06-20 23:45:32.994526
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    pass

# Generated at 2022-06-20 23:45:43.108855
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    #__import__('pdb').set_trace()
    #import ipdb as pdb; pdb.set_trace()
    a = AnsibleConstructor(file_name='/tmp/test_file')
    import yaml
    b =yaml.load("""
    - 1 
    - 2
    - 3
    - 4
    - 5
    """, Loader=AnsibleConstructor)
    assert len(b) == 5

    c  =yaml.load("""
    - 1 
    - 2
    - 3
    - 4
    - 5
    """, Loader=AnsibleConstructor)
    assert len(b) == 5
    return b

# Generated at 2022-06-20 23:45:49.709015
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    expected = u"\nfoo: bar\n"

    ac = AnsibleConstructor()
    # construct yaml document parse tree
    node = ac.compose_node(None, (0, 0))
    for char in expected:
        token = ac.compose_document(char)
        node.value.append(token)
        break

    # assert we can construct this document
    actual = ac.construct_yaml_str(node)

    assert actual == expected

# Generated at 2022-06-20 23:45:57.649152
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    yaml.warnings({'YAMLLoadWarning': False})
    vault_secrets = [('default', 'secret')]
    yaml.add_constructor(u'!vault', AnsibleConstructor(vault_secrets=vault_secrets).construct_vault_encrypted_unicode)
    yaml.add_constructor(u'!vault-encrypted', AnsibleConstructor(vault_secrets=vault_secrets).construct_vault_encrypted_unicode)


# Generated at 2022-06-20 23:46:09.978925
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import random
    import string

    display.verbosity = 3
    try:
        from yaml import CSafeDumper as SafeDumper
        from yaml import CSafeLoader as SafeLoader
    except ImportError:
        from yaml import SafeDumper
        from yaml import SafeLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def fake_vault(vault_id=None, vault_secret=None):
        return VaultLib(vault_id=vault_id, secrets=[vault_secret])

    # Test constructor without vault secrets
    yaml = AnsibleConstructor()
    data = yaml.construct_yaml_map(yaml.construct_yaml_str(u'[{key: value}]'))[0]
    assert data

# Generated at 2022-06-20 23:46:12.170587
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    x = AnsibleConstructor()
    y = x.construct_yaml_unsafe(None)
    assert y is None



# Generated at 2022-06-20 23:46:16.463292
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()
    node = {}
    node['id'] = 'int'
    node['start_mark'] = ''
    node['value'] = '0o777'
    result = constructor.construct_yaml_unsafe(node)
    assert result == 0o777
    assert type(result) == int



# Generated at 2022-06-20 23:46:25.767315
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    file_name = "testfile"
    ac = AnsibleConstructor(file_name=file_name)
    assert ac is not None, "Failed to initialize AnsibleConstructor"
    class FakeNode:
        def __init__(self):
            self.start_mark = type("FakeMark", (), {})
            self.id = 'str'
        def construct_scalar(self):
            return 'TestConstructStr'
    node = FakeNode()
    ret = ac.construct_yaml_str(node)
    assert ret == 'TestConstructStr'
    assert ret.ansible_pos == (file_name, 1, 1)

# Generated at 2022-06-20 23:46:42.511443
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Duplicate key errors are hard to trigger and reproduce in AnsibleConstructor.
    This method provides a quick way to test this method.
    """
    constructor = AnsibleConstructor()
    # Use an !unsafe tag to force a MappingNode
    data = {'key': 'value'}
    node = constructor.represent_mapping('!unsafe', data)

# Generated at 2022-06-20 23:46:49.020303
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode

    value = u'string'
    node = ScalarNode(tag=u'tag:yaml.org,2002:str', value=value)
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_str(node)
    assert isinstance(result, AnsibleUnicode)
    assert result == value



# Generated at 2022-06-20 23:46:56.639818
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['testsecret']
    vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-20 23:47:02.796407
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = {}
    data_node = MappingNode(u'tag:yaml.org,2002:map',
                            value=[],
                            flow_style=True,
                            start_mark=None,
                            end_mark=None)
    data_instance = AnsibleConstructor.construct_yaml_map(data_node)
    assert isinstance(data_instance, AnsibleMapping)



# Generated at 2022-06-20 23:47:09.264612
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    # Check if ansible-constructor can be used as a yaml constructor
    # Try to construct a scalar as ansible-unicode
    yaml.load('abc', Loader=AnsibleConstructor)
    # Try to construct a list as ansible-sequence
    yaml.load('[abc, def]', Loader=AnsibleConstructor)
    # Try to construct a dict as ansible-mapping
    yaml.load('{abc: def}', Loader=AnsibleConstructor)

# Generated at 2022-06-20 23:47:23.384109
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    def test_constructor(data, expected):
        class TestAnsibleConstructor(AnsibleConstructor):
            def construct_yaml_str(self, node):
                return '{}'.format(self.construct_scalar(node))

            def construct_scalar(self, node):
                if isinstance(node, ScalarNode) and isinstance(node.value, (str, text_type)):
                    return node.value.upper()
                return super(TestAnsibleConstructor, self).construct_scalar(node)

            def construct_yaml_seq(self, node):
                data = AnsibleSequence()
                yield data
               

# Generated at 2022-06-20 23:47:32.858703
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = """
---
hosts:
  - localhost
  - secondhost
vars:
  my_var: 123
  my_var: 456
other_var: 'something'
  """

    # If we set DUPLICATE_YAML_DICT_KEY to 'ignore', this should not raise
    # an exception
    prev_behavior = C.DUPLICATE_YAML_DICT_KEY
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    AnsibleConstructor().construct_yaml_map(yaml.compose(data))
    C.DUPLICATE_YAML_DICT_KEY = prev_behavior


# pylint: disable=protected-access
if not hasattr(yaml, 'CSafeLoader'):
    yaml.CS

# Generated at 2022-06-20 23:47:41.632460
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class _AnsibleConstructor(AnsibleConstructor):
        def _node_position_info(self, node):
            return (None, None, None)

    _map = _AnsibleConstructor().construct_mapping({
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key1': 'value4'
    })

    assert len(_map) == 3
    assert _map.get('key1', None) == 'value4'
    assert _map.get('key2', None) == 'value2'
    assert _map.get('key3', None) == 'value3'

# Generated at 2022-06-20 23:47:53.443619
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # yaml.load calls constructor.construct_yaml_map,
    # which calls super(AnsibleConstructor, self).construct_mapping
    # which calls self.construct_mapping
    # which calls self.flatten_mapping
    # which recursively calls self.construct_mapping
    # (this is also true of construct_yaml_seq)

    def get_constructor(stream):
        c = AnsibleConstructor()
        c.construct_document(yaml.compose(stream))

    stream = u'a: 1\nb: 2\n'
    get_constructor(stream)

    stream = u'a: 1\nb: 2\nc: 2\n'
    with pytest.raises(ConstructorError):
        get_constructor(stream)


# Generated at 2022-06-20 23:47:58.903964
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    yaml_str = '''
---
a: !unsafe 'b'
    '''
    data = AnsibleLoader(yaml_str, 'test_AnsibleConstructor_construct_yaml_unsafe.yaml').get_single_data()
    assert data.get('a') == AnsibleUnsafeText('b')

# Generated at 2022-06-20 23:48:15.064236
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class MockYamlNode(object):
        def __init__(self, value, start_mark=None, end_mark=None, end_col=None, end_line=None):
            self.value = value
            self.start_mark = start_mark
            self.end_mark = end_mark
            self.end_col = end_col
            self.end_line = end_line

    import yaml

    start_mark = yaml.Mark(None, 0, 0, 0, None, None)
    end_mark = yaml.Mark(None, 0, 1, 2, None, None)

    value = ["a", "b", "c"]

    node = MockYamlNode(value, start_mark, end_mark)

    ansible_constructor = AnsibleConstructor()
    ret = ansible_construct

# Generated at 2022-06-20 23:48:15.699619
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

# Generated at 2022-06-20 23:48:27.871028
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    # Test construct_yaml_map
    test_node = MappingNode(None, None, None, tag='tag:yaml.org,2002:map')
    test_obj = AnsibleConstructor()
    assert test_obj.construct_yaml_map(test_node) == {}, 'construct_yaml_map should return {}'

    # Test construct_yaml_str
    test_node = SafeConstructor()
    test_obj = AnsibleConstructor()
    assert isinstance(test_obj.construct_yaml_str(test_node), unicode), 'construct_yaml_str should return unicode object {}'.format(test_obj.construct_yaml_str(test_node))

    # Test ansible_pos
    test_obj = AnsibleConstructor()

# Generated at 2022-06-20 23:48:36.410738
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    class TestAnsibleConstructor(AnsibleConstructor):
        '''
        This class is only used for unit testing. It provides a way of
        subverting the super constructors.
        '''

        def __init__(self, vault_secrets=None):
            super(TestAnsibleConstructor, self).__init__()
            self._vaults = {}

    # Create a simple test case
    node = MappingNode(key=None, value=None)
    node.start_mark = None

    test = TestAnsibleConstructor()
    test.construct_yaml_seq(node)

# Generated at 2022-06-20 23:48:48.443597
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ac = AnsibleConstructor(file_name=None)

    test_results = [
        (u'[1, 2, 3]', [1, 2, 3]),
        (u'{"one": 1, "two": 2, "three": 3}', {u"one": 1, u"two": 2, u"three": 3}),
        (u'"string"', u"string"),
        (u'"1"', u"1"),
        (u'"True"', u"True"),
        (u'1', 1),
        (u'True', True),
    ]

    for test_input, expected_result in test_results:
        result = ac.construct_yaml_unsafe(test_input)

        assert result == expected_result

# Generated at 2022-06-20 23:48:51.715292
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml import nodes
    from ansible.parsing.yaml.objects import AnsibleMapping

    node = nodes.Node()
    obj = AnsibleConstructor()
    cls = obj.construct_yaml_map(node)
    assert isinstance(next(cls), AnsibleMapping)



# Generated at 2022-06-20 23:48:53.467757
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    AnsibleConstructor(file_name=None).__init__()

# Generated at 2022-06-20 23:49:02.474262
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Test that AnsibleConstructor._node_position_info returns the correct values.
    """
    yaml_data = """
    foo:
        bar: 1
    """
    yaml_loader = YAMLLoader(yaml_data)
    yaml_loader.get_single_data()

    yaml_data2 = """
    foo: 2
    """
    yaml_loader2 = YAMLLoader(yaml_data2)
    yaml_loader2.get_single_data()

    assert yaml_loader._node_position_info(yaml_loader.composer.anchors['foo']) == (None, 1, 5)

# Generated at 2022-06-20 23:49:11.026087
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ac = AnsibleConstructor("/tmp/test.yml")
    construct_yaml_map = ac.construct_yaml_map
    node = MappingNode("tag:yaml.org,2002:map", [], [] , False, None, None)
    # The type of the return value should be AnsibleMapping
    assert isinstance(construct_yaml_map(node).__anext__(), AnsibleMapping)
    # The return value should be generator
    assert isinstance(construct_yaml_map(node), types.GeneratorType)


# Generated at 2022-06-20 23:49:21.708599
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['secret1', 'secret2']
    vault_secret_zero = vault_secrets[0]
    vault_password = VaultLib(vault_secret_zero).encrypt(vault_secret_zero)
    sample = '$ANSIBLE_VAULT;%s;%s' % (vault_secret_zero, vault_password)
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(sample)
    assert encrypted_unicode.vault
    assert encrypted_unicode.vault.secrets
    assert ansible_constructor.construct_vault_encrypted_unicode(vault_password) == vault_password
    assert ansible_constructor.construct_v

# Generated at 2022-06-20 23:49:44.059312
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import StringIO
    fake_yaml = StringIO.StringIO("""
a: a
b:
    - b1
    - b2
c:
  - "c1"
  - "c2"
""")
    # test a basic mapping returned by construct_yaml_map()
    data = yaml.load(fake_yaml, AnsibleConstructor)
    assert isinstance(data, dict)
    assert len(data) == 3
    assert data['a'] == 'a'
    assert isinstance(data['b'], list)
    assert len(data['b']) == 2
    assert data['b'][0] == 'b1'
    assert data['c'] == ['c1', 'c2']


# Generated at 2022-06-20 23:49:51.037592
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Example of an unsafe: ansible/hacking/test-module/lib/ansible/module_utils/easy_install.py
    # Example of a safe: ansible/lib/ansible/modules/system/ping.py
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts import ansible_local

    assert hasattr(ansible_facts, '__safe_for_unpickle__') and not getattr(ansible_facts, '__safe_for_unpickle__', False)
    assert hasattr(ansible_local, '__safe_for_unpickle__') and not getattr(ansible_local, '__safe_for_unpickle__', False)


# Generated at 2022-06-20 23:49:55.641824
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml = AnsibleConstructor()
    with open("tests/playbooks/yaml_seq.yaml") as f:
        data = yaml.construct_yaml_seq(yaml.compose_node(None, None, f))
        assert data.ansible_pos == ('yaml_seq.yaml', 1, 0)

# Generated at 2022-06-20 23:49:59.160511
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """ construct_yaml_seq: just for coverage, no assert """
    ret = AnsibleConstructor(file_name='none')
    ret.construct_yaml_seq(None)

# Generated at 2022-06-20 23:50:01.907010
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    test_obj = AnsibleConstructor()

    # Test type error
    value = 'test'
    node = object()
    if not isinstance(node, MappingNode):
        raise ConstructorError(None, None,
                               "expected a mapping node, but found %s" % node.id,
                               node.start_mark)

    ansible_str = test_obj.construct_yaml_str(node)

    assert ansible_str.data == value
    assert ansible_str.ansible_pos == test_obj._node_position_info(node)



# Generated at 2022-06-20 23:50:11.807534
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    # Test 1: create a vault encrypted string and confirm the type of the constructed result
    # is AnsibleVaultEncryptedUnicode
    # Test 2: create a vault encrypted string and confirm the vault attribute is correctly
    # set to the vault object
    # Test 3: ensure that adding !vault! at the beginning of a line is skipped
    # Test 4: ensure that adding !vault! at the end of a line is skipped
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-20 23:50:21.395125
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    import sys

    yaml_src = """
key1: value1
key2: value2
    """

    data = yaml.safe_load(yaml_src)
    assert data['key1'] == "value1"
    assert data['key2'] == "value2"
    assert isinstance(data['key1'], unicode)
    assert isinstance(data['key2'], unicode)

    if sys.version_info >= (3, 0):
        assert isinstance(data['key1'], str)
        assert isinstance(data['key2'], str)