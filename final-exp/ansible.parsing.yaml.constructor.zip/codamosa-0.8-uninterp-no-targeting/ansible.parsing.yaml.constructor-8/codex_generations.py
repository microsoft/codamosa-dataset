

# Generated at 2022-06-20 23:40:31.643832
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import os
    import tempfile
    from io import StringIO

    sys.path.insert(0, 'lib')

    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.compat import PY3

    # Create a simple file to read
    if PY3:
        fd, test_file_name = tempfile.mkstemp(text=True)
    else:
        fd, test_file_name = tempfile.mkstemp()


# Generated at 2022-06-20 23:40:40.672485
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_yaml_string = """
---
- 'a'
- 'b'
"""

    test_yaml_string_result = ['a', 'b']

    import yaml

    yaml_obj = yaml.load(test_yaml_string, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, list)
    assert isinstance(yaml_obj[0], AnsibleUnicode)
    assert isinstance(yaml_obj[1], AnsibleUnicode)
    assert yaml_obj[0] == test_yaml_string_result[0]
    assert yaml_obj[1] == test_yaml_string_result[1]

# Generated at 2022-06-20 23:40:50.680793
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:41:00.716427
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # For the following tests, we need a node with a single key-value pair
    # "key1: value1"
    from yaml.nodes import ScalarNode, MappingNode
    from ansible.vars.unsafe_proxy import wrap_var
    import types

    value = 'value1'
    # Construct ScalarNode for "value1"
    class KVNode(ScalarNode):
        id = 'kv'
    value_node = KVNode('kv', value)
    # Construct ScalarNode with position info for "key1"
    class KeyNode(ScalarNode):
        id = 'key'
        start_mark = object()
        end_mark = object()
    key_node = KeyNode('key', 'key1')
    # Construct MappingNode with position info

# Generated at 2022-06-20 23:41:09.758912
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test 1:
    str_node = "string"
    ac = AnsibleConstructor()
    constructed_str_1 = ac.construct_yaml_str(str_node)
    assert constructed_str_1 == u"string"

    # Test 2:
    int_node = 5
    constructed_str_2 = ac.construct_yaml_str(int_node)
    assert constructed_str_2 == u"5"

    # Test 3:
    def function():
        pass
    constructed_str_3 = ac.construct_yaml_str(function)
    assert constructed_str_3 == u"<function>"

# Generated at 2022-06-20 23:41:22.632325
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # The following test is adapted from:
    # http://pyyaml.org/browser/pyyaml/trunk/lib/yaml/constructor.py
    # http://pyyaml.org/browser/pyyaml/trunk/lib/yaml/error.py
    # http://pyyaml.org/browser/pyyaml/trunk/lib/yaml/nodes.py
    # http://pyyaml.org/browser/pyyaml/trunk/lib/yaml/scanner.py
    # http://pyyaml.org/browser/pyyaml/trunk/lib/yaml/token.py

    from yaml.error import Mark
    from yaml.scanner import Scanner
    from yaml.token import Token


# Generated at 2022-06-20 23:41:25.203452
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = AnsibleConstructor.construct_yaml_map(None)
    assert data == {}

# Generated at 2022-06-20 23:41:33.940370
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.compat.tests import unittest

    DATA = u"""
- 1
-
  - 2
- 3
"""

    class TestAnsibleConstructor(unittest.TestCase):
        def test_AnsibleConstructor_construct_yaml_seq(self):
            obj = yaml.load(DATA, AnsibleConstructor())
            self.assertEqual(obj[0], 1)
            self.assertEqual(obj[1][0], 2)
            self.assertEqual(obj[2], 3)

    unittest.main()

# Generated at 2022-06-20 23:41:46.146013
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:41:58.244821
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Note: the following tests only check for the correctness of the function.
    # It does not check the display warning/error messages.
    ac = AnsibleConstructor()
    bad_inputs = [
        {'test': 1, 'dup': 2, 'dup': 3},
        {'test': 1, 'dup': 2, 'dup': 3, 'dup': 4},
        {'test': 1, 'dup': 2, 'dup': 3, 'dup': 4, 'dup': 5}
    ]
    for value in bad_inputs:
        node = MappingNode(u'tag:yaml.org,2002:map', value, None, None)
        result = ac.construct_yaml_map(node)
        assert isinstance(result, AnsibleMapping)

# Generated at 2022-06-20 23:42:11.371500
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    y = AnsibleConstructor(file_name="somefile.yaml")

    x = AnsibleUnicode(u"abc")
    x.ansible_pos = None

    node = x
    value = u"abc"

    ret = y.construct_yaml_str(node)

    assert ret == value
    assert ret.ansible_pos == None

# Generated at 2022-06-20 23:42:23.063913
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultSecret
    import os

    # Create the secret needed for vault decryption
    vault_secret = VaultSecret(b'password')

    # Create a constructor that can decrypt vault data
    constructor = AnsibleConstructor(
        file_name=os.path.join(os.path.dirname(__file__), 'vault_test_data.yml'),
        vault_secrets=[vault_secret]
    )

    # Create the loader with the constructor
    loader = AnsibleLoader(constructor)

    # Load the vault test data

# Generated at 2022-06-20 23:42:35.458119
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['testsecret']

    vault_loader = AnsibleLoader(vault_secrets=vault_secrets)

    b_ciphertext_data = to_bytes('$ANSIBLE_VAULT;1.1;AES256\nblablablablablablablablablablablablablablablablablablablablablablablablablablablablablablabla\nblablablablablablablablablablablablablablablablablablablablablablablablablablablablablabla')
    yaml_data = u'!vault |\n'

# Generated at 2022-06-20 23:42:48.683854
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser, ParserError
    from yaml.composer import Composer
    from yaml.resolver import Resolver
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Make sure the AnsibleConstructor works
    ansible_constructor = AnsibleConstructor()

    # Make sure the _node_position_info function works. This is a private function, so we have
    # to test it directly rather than through the public AnsibleConstructor class.
    reader = Reader(line_buffering=True)

# Generated at 2022-06-20 23:42:49.605106
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # TODO
    assert False

# Generated at 2022-06-20 23:43:03.555847
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml import objects
    import types

    class FakeYamlNode(object):
        start_mark = None

        def __init__(self, id):
            self.id = id

    # Base case
    ret = AnsibleConstructor.construct_yaml_str(None, FakeYamlNode("str"))
    assert isinstance(ret, objects.AnsibleUnicode)
    assert ret.data == u""

    # Test with a non-empty string
    ret = AnsibleConstructor.construct_yaml_str(None, FakeYamlNode("str"))
    ret_2 = AnsibleConstructor.construct_yaml_str(None, FakeYamlNode("str"))
    assert isinstance(ret, objects.AnsibleUnicode)
    assert ret.data == u""

# Generated at 2022-06-20 23:43:09.107828
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_safe_constructor = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
                       flow_style=None)
    result = test_safe_constructor.construct_mapping(node)
    assert AnsibleMapping == type(result)
    assert result.ansible_pos == (None, None, None)

# Generated at 2022-06-20 23:43:11.409702
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    c = AnsibleConstructor()

    # TODO make this not possible to create the object
    assert c.construct_yaml_seq(None)

# Generated at 2022-06-20 23:43:17.728253
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    import sys

    # yaml_snippet.yml file
    yaml_snippet = 'test_dict: {1: first_dict, 2: second_dict}'
    yaml_snippet_dup_dict = 'test_dict: {1: first_dict, 2: second_dict, 1: dup_first_dict}'
    yaml_snippet_dup_dict_warn = '---\n' 'test_dict:\n' '    1: first_dict\n' '    2: second_dict\n' '    1: dup_first_dict'

    # Test without the duplicate dict keys
    my_dict = yaml.load(yaml_snippet, Loader=AnsibleConstructor)

# Generated at 2022-06-20 23:43:32.298420
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from pprint import pprint
    from ansible.parsing.vault import VaultSecret

    # Create a vault secret for the AnsibleLoader ctor below

# Generated at 2022-06-20 23:43:54.150554
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    def test_construct_yaml_str(string, expected):
        yaml_doc = u"---\nstr: %s\n" % string
        ansible_constructor = AnsibleConstructor()
        data = yaml.load(yaml_doc, Loader=AnsibleLoader)
        assert isinstance(data['str'], AnsibleUnicode)
        assert data['str'] == expected

    test_construct_yaml_str('test', u'test')
    test_construct_yaml_str('unicode: ü', u'unicode: ü')
    test_construct_yaml_str('bytes: abc', u'bytes: abc')

# Generated at 2022-06-20 23:44:02.880455
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml

    test1 = "[{foo: [bar, baz]}]\n"
    data1 = yaml.load(test1, Loader=AnsibleConstructor)
    assert isinstance(data1, list)
    assert isinstance(data1[0], AnsibleMapping)

    test2 = "{foo: [bar, baz]}\n"
    data2 = yaml.load(test2, Loader=AnsibleConstructor)
    assert isinstance(data2, AnsibleMapping)

# Generated at 2022-06-20 23:44:15.386931
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.module_utils._text import to_text
    from yaml.loader import SafeLoader
    from yaml import YAMLError

    yaml_data_obj = None
    try:
        yaml_data_obj = """"
        foo: bar
        wrong_key: wrong_value
        foo: legit_data_for_foo
        """
        yaml_data = yaml_data_obj.encode('utf-8')
        yaml_data_obj = to_text(yaml_data_obj)
        loader = SafeLoader(yaml_data)
        construct_mapping_output = AnsibleConstructor.construct_mapping(loader)
        assert construct_mapping_output.get('foo') == 'legit_data_for_foo'
    except Exception:
        raise AssertionError

# Generated at 2022-06-20 23:44:23.840454
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    data = '''
        a: 1
        a: 2
        a: 3
        # in the case of 'warn', you should see a warning
        # in the case of 'ignore', you should see a debug message
        # in the case of 'error', you should see an exception
    '''
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    AnsibleConstructor().construct_yaml_map(yaml.compose(data))
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    AnsibleConstructor().construct_yaml_map(yaml.compose(data))
    C.DUPLICATE_YAML_DICT_KEY = 'error'
    with pytest.raises(yaml.constructor.ConstructorError):
        Ans

# Generated at 2022-06-20 23:44:27.670831
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # ansible_constructor = AnsibleConstructor()
    # input_value = None
    raise NotImplementedError
    # output_value = ansible_constructor.construct_yaml_str(input_value)



# Generated at 2022-06-20 23:44:33.083108
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # Test no duplicate keys
    try:
        yaml.load('foo: 1\nfoo: 2', Loader=AnsibleConstructor)
        assert False, "Should have raised error"
    except ConstructorError:
        pass

    # Test duplicate keys
    yaml.load('foo: 1\nfoo: 2', Loader=AnsibleConstructor)

# Generated at 2022-06-20 23:44:39.564254
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    x = AnsibleConstructor()

    assert x.construct_object is not None
    assert x.construct_yaml_map is not None
    assert x.construct_yaml_str is not None
    assert x.construct_yaml_seq is not None
    assert x.construct_yaml_unsafe is not None

# Generated at 2022-06-20 23:44:43.437202
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml = """
    - !unsafe
      foo: bar
    """
    expected_result = [ { 'foo': 'bar' } ]

    assert(AnsibleConstructor.construct_yaml_unsafe(
           yaml) == expected_result)


# Generated at 2022-06-20 23:44:55.336816
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-20 23:45:04.199282
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os
    import copy
    import yaml

    yaml_data = """
    a: one
    b: two
    c: three
    """

    yaml_data_dup = """
    a: one
    b: two
    c: three
    a: one
    """

    yaml_data_deep = """
    a:
      b: one
      c: two
      d: three
    """

    yaml_data_deep_dup = """
    a:
      b: one
      c: two
      d: three
      b: one
    """

    yaml_data_deep_dup_list = """
    a:
      - one
      - two
      - three
      - one
    """


# Generated at 2022-06-20 23:45:24.535579
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    ansible_constructor = AnsibleConstructor()
    test_b_ciphertext_data = b'$ANSIBLE_VAULT;1.1;AES256\n6331366433656637393066363335633933323731616535366563376235326633333935633062313065\n3564363933623137613365323364643237323563313738630a39356466383964663635643936373065\n6463316534316661383838613537643665626135386137346466313866466238613164383064383266\n6133323337336233\n'

# Generated at 2022-06-20 23:45:26.580940
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    AnsiConst = AnsibleConstructor()
    assert not AnsiConst.construct_yaml_unsafe({"value" : ["bar","baz"]})

# Generated at 2022-06-20 23:45:31.734415
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import random
    import string

    random.seed(0)
    m = dict((x, "".join(random.choices(string.ascii_uppercase + string.digits, k=20)))
             for x in range(50))
    m2 = yaml.load(yaml.dump(m, Dumper=AnsibleDumper), Loader=AnsibleConstructor())
    assert m == m2

# Generated at 2022-06-20 23:45:43.566420
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import ansible.constants as C
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    yaml_string = u'---\n' + \
                  u'foo: 1\n' + \
                  u'bar: 1\n' + \
                  u'foobar: 1\n' + \
                  u'barfoo: 1\n' + \
                  u'bar: 1'
    original_duplicate_dict_key = C.DUPLICATE_YAML_DICT_KEY
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    data = AnsibleLoader(None).load(yaml_string)
    assert isinstance(data, AnsibleMapping) and data.keys()

# Generated at 2022-06-20 23:45:45.925588
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor()
    assert a.construct_yaml_map([3, 2]) == [3, 2]



# Generated at 2022-06-20 23:45:51.486725
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = [u'tag:yaml.org,2002:str', 'foo']
    ansible_constructor = AnsibleConstructor()
    ansible_object = ansible_constructor.construct_yaml_str(node)
    assert(ansible_object == AnsibleUnicode('foo'))
    assert(ansible_object.ansible_pos == ('<string>', 0, 1))

# Generated at 2022-06-20 23:45:54.712903
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_str = """
    ---
    - name: test
      value: 42
    """

    data = AnsibleConstructor().construct_yaml_seq(test_str)
    assert data == [{'name': 'test', 'value': 42}]

# Generated at 2022-06-20 23:46:03.684768
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    test_data = b"""
- test_data_1
- test_data_2
"""
    test_data_expected_result = [u'test_data_1',u'test_data_2']
    test_data_load = yaml.load(test_data, Loader=AnsibleConstructor)
    assert type(test_data_load) == AnsibleSequence
    assert type(test_data_load[0]) == unicode
    assert type(test_data_load[1]) == unicode
    assert test_data_load == test_data_expected_result


# Generated at 2022-06-20 23:46:14.533336
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode
    import os.path
    from ansible.parsing.vault import VaultLib

    text = u"somestring"

    vault_id = 'vault'
    vault = VaultLib(['password'])
    value = AnsibleVaultEncryptedUnicode(vault.encode(text), vault)

    # create the YAML
    yaml_text = yaml.safe_dump([value], default_flow_style=False)
    yaml_text = yaml_text.replace(u'!vault-encrypted', u'!vault')

    # create constructors

# Generated at 2022-06-20 23:46:26.486901
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    display.verbosity = 3
    data = """
- test_host_0
- test_host_1
- test_host_2
"""

    # Test with no duplicate keys
    loader = AnsibleLoader(data, file_name='<string>', vault_secrets=[])
    result = loader.get_single_data()
    assert isinstance(result, list)
    for host in result:
        assert isinstance(host, AnsibleUnsafeText)

    # Test with duplicate keys
    data = """
- test_host_0
- test_host_1
- test_host_0
"""

# Generated at 2022-06-20 23:46:50.471281
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_str = '''
    - foo
    - bar
    '''

    from ansible.parsing.yaml.loader import AnsibleLoader
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    print(data)
    assert data == [u'foo', u'bar']
    assert isinstance(data, list)

# Generated at 2022-06-20 23:47:02.797794
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    node = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.2;AES123;some_ciphertext\nmore ciphertext")

    # Decrypt the vault encrypted string successfully
    ret = ansible_constructor.construct_vault_encrypted_unicode(node)
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)

    # Decrypt the vault encrypted string unsuccessfully
    old_secrets = ansible_constructor.vault_secrets
    ansible_constructor.vault_secrets = []
    try:
        ansible_constructor.construct_vault_encrypted_unicode(node)
    except ConstructorError:
        pass

# Generated at 2022-06-20 23:47:11.909043
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    import yaml
    import io
    import string

    # Create a string of random bytes
    # The number of bytes should be multiple of 16. This way the ciphertext is multiple of 16.
    # This is a restriction of AES
    # Ensure the first 3 bytes are not '!v' for this test to work.
    # This prefix is used for !vault and !vault-encrypted tags
    rand = string.ascii_letters + string.digits + '+/'
    size = 16*16
    b_data = bytearray()
    for i in range(size):
        b_data.append(ord(rand[i % len(rand)]))
    b_data[0] = 78
    b_data[1] = 76
    b_data[2] = 0
    b_data[3] = 1


# Generated at 2022-06-20 23:47:23.613992
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    file_name = None
    vault_secret = "test_secret"
    vault_secrets = [vault_secret]
    a = AnsibleConstructor(file_name, vault_secrets)
    a._vaults['default'] = VaultLib(secrets=vault_secrets)
    vault = a._vaults['default']
    vault_data = vault.encrypt(b'test')
    vault_data = vault_data.startswith('$ANSIBLE_VAULT') and vault_data or vault_data.decode('utf-8')
    a._vaults['default'] = VaultLib(secrets=vault_secrets)
    h = a

# Generated at 2022-06-20 23:47:28.383379
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_text = """
- str_key: str_value
"""
    doc = yaml.load(yaml_text, Loader=AnsibleConstructor)
    assert(doc == [{u'str_key': u'str_value'}])


# vim: set et sts=4 sw=4 ts=4

# Generated at 2022-06-20 23:47:36.161170
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    text_ = '''
            ---
            key1: val1
            key2: val2
            '''
    import yaml
    class fake_file(object):
        pass
    fake_file.name = ''
    fake_stream = fake_file()
    fake_stream.name = ''
    fake_loader = yaml.Loader(fake_stream)
    ansible_constructor = AnsibleConstructor(file_name='')
    ansible_constructor.add_constructor(u'!yaml-objects/dictionary',
                                        AnsibleConstructor.construct_yaml_map)
    ansible_constructor.add_constructor(u'!yaml-objects/str',
                                        AnsibleConstructor.construct_yaml_str)

# Generated at 2022-06-20 23:47:39.249328
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    value = {"a": "b"}
    assert AnsibleConstructor.construct_yaml_map(AnsibleConstructor, value) == {"a": "b"}

# Generated at 2022-06-20 23:47:51.333487
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import safe_load
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    ansible_constructor = AnsibleConstructor()

    # test default vault
    ansible_constructor.vault_secrets = ['default']
    ansible_constructor._vaults['default'] = VaultLib()

# Generated at 2022-06-20 23:47:58.289408
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = '''
    a:
    - 1
    - 2
    - 3
    b:
    - hello
    - world
    '''
    expected_data = {'a': [1,2,3],
                     'b': ['hello', 'world']}
    data = AnsibleLoader(yaml_data).get_single_data()
    assert data == expected_data

    yaml_data = '''
    a:
    - 1
    - 2
    - 3
    a:
    - hello
    - world
    '''
    expected_

# Generated at 2022-06-20 23:48:10.231853
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
     from unittest import TestCase
     from ansible.parsing.yaml.loader import AnsibleLoader
     import yaml
     yaml_str = """
     - {name: 1, val: 10}
     - {name: 2, val: 20}
     - {name: 3, val: 30}
     - {name: 4, val: 40}
     """
     data = yaml.load(yaml_str, Loader=AnsibleLoader)
     assert data == [{u'name': 1, u'val': 10},
                     {u'name': 2, u'val': 20},
                     {u'name': 3, u'val': 30},
                     {u'name': 4, u'val': 40}]

# Generated at 2022-06-20 23:48:54.778922
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import loader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    my_list = [1, 2, 3]
    yaml_str = '''\
- 1
- 2
- 3
'''
    my_list_tag = u'tag:yaml.org,2002:python/list'
    data = loader.construct_yaml_seq(yaml_str, AnsibleLoader(yaml_str))
    assert isinstance(data, AnsibleSequence)
    assert list(data) == my_list
    assert data.tag == my_list_tag


# Generated at 2022-06-20 23:49:01.855545
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """
    Test the construct_yaml_unsafe() method of the AnsibleConstructor class
    """
    import sys
    import os
    import tempfile
    import shutil
    import stat
    import subprocess
    import atexit
    import signal

    class AnsibleConstructorTestException(Exception):
        pass

    def clean_tmp_dir(tmp_dir):
        if os.path.exists(tmp_dir):
            shutil.rmtree(tmp_dir)
    def make_tmp_dir():
        tmp_dir = tempfile.mkdtemp()
        if tmp_dir is None:
            raise AnsibleConstructorTestException(
                "Could not create tmp directory")
        atexit.register(clean_tmp_dir, tmp_dir)
        return tmp_dir


# Generated at 2022-06-20 23:49:06.820696
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    if sys.version_info[0] == 2:
        try:
            display.deprecated("assertEqual(False, u'abc' == b'abc')")
            assertEqual(False, u'abc' == b'abc')
        except:
            assertEqual(False, False)

# Generated at 2022-06-20 23:49:17.335303
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml import YAML
    import unittest
    import sys

    class TestResult(unittest.TestCase):
        if sys.version_info >= (2, 7, 0):
            def assertIsInstance(self, obj, cls, msg=None):
                if not isinstance(obj, cls):
                    self.fail(self._formatMessage(msg, "%s is not an instance of %r" % (repr(obj), cls)))

    loader = YAML(typ='safe')
    construct_yaml_str = AnsibleConstructor().construct_yaml_str
    test_result = TestResult()
    test_result.assertIsInstance(construct_yaml_str(loader.construct_scalar(u'foo')), unicode)

# Generated at 2022-06-20 23:49:23.224983
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()

    node = type('', (), {})

    def construct_scalar(self, node):
        return u'unicode'

    node.construct_scalar = construct_scalar.__get__(node, type(node))

    value = ansible_constructor.construct_yaml_str(node)

    assert isinstance(value, AnsibleUnicode)



# Generated at 2022-06-20 23:49:34.086778
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_snippet = '''
    - {
        "hosts": ["host"],
        "vars": {
          "a": "ok"
        },
        "tasks": [{
          "include_vars": "{{ host_vars_dir }}/{{ inventory_hostname }}",
          "fail": {
            "msg": "{{ some_undefined_var }}"
          }
        }]
      }
    '''
    load = AnsibleConstructor(file_name=1).construct_yaml_seq
    doc = yaml.load(yaml_snippet, Loader=load)
    seq = doc[0]
    d = seq[0]
    assert d['hosts'] == ["host"]
    assert d['vars']['a'] == 'ok'
    assert d

# Generated at 2022-06-20 23:49:43.502961
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.module_utils._text import to_text
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert isinstance(
        yaml.load("!unsafe foo", Loader=AnsibleConstructor),
        AnsibleUnsafeText)

    assert isinstance(
        yaml.load("!unsafe foo", Loader=AnsibleConstructor),
        AnsibleUnsafeText)

    assert isinstance(
        yaml.load("!unsafe foo", Loader=AnsibleConstructor),
        AnsibleUnsafeText)

    assert isinstance(
        yaml.load("!unsafe foo", Loader=AnsibleConstructor),
        AnsibleUnsafeText)


# Generated at 2022-06-20 23:49:50.712899
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml import load
    from sys import version_info

    if version_info >= (3, 0, 0):
        from io import StringIO
    else:
        from io import BytesIO

    # Ensure that AnsibleConstructor works with the AnsibleLoader (which it
    # should by default)
    yaml_str = "{foo: bar}"
    yaml_bytes = to_bytes(yaml_str, encoding='utf-8')
    data = load(yaml_bytes, Loader=AnsibleLoader)
    assert isinstance(data, AnsibleMapping)

    # Test that AnsibleConstructor uses the value returned by the pyyaml loader
    # when not an AnsibleMapping
    yaml_str = "[foo, bar]"
   

# Generated at 2022-06-20 23:49:56.076905
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from io import BytesIO
    from yaml import safe_load
    content = b'[1, 2, 3]'
    stream = BytesIO(content)
    data = safe_load(stream)
    assert isinstance(data, list)
    assert isinstance(data, AnsibleSequence)
    assert callable(data.ansible_pos)
    assert data == [1, 2, 3]



# Generated at 2022-06-20 23:50:06.870014
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # GIVEN
    fp = tempfile.NamedTemporaryFile(delete=False)
    fp.write("""
    ---
    foo: !vault |
        $ANSIBLE_VAULT;1.1;AES256
        356364373565396365363735633265363439633832376262623032653336363435303462313162656136610a
        63663539623333353232626665616433363538363830653330353333316135323234313634653336343839640a
        313865316331383631613861356263386335643937306363393365366265373966373634303530373738653830
    """)
    fp.close()