

# Generated at 2022-06-20 23:40:24.125368
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    test_obj = AnsibleConstructor()
    test_node = 'string'
    result = test_obj.construct_yaml_str(test_node)
    assert isinstance(result, AnsibleUnicode)
    assert result == 'string'


# Generated at 2022-06-20 23:40:36.777298
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_dict = {u'name1': u'value1', u'name2': u'value2'}
    mapping_node = MappingNode(u'tag:yaml.org,2002:map', [], [],
                               start_mark=None, end_mark=None)
    mapping_node.value.append((u'name1', u'value1'))
    mapping_node.value.append((u'name2', u'value2'))
    constructed_dict = AnsibleConstructor.construct_mapping(mapping_node)
    assert test_dict == constructed_dict
    assert isinstance(constructed_dict, AnsibleMapping)

    with pytest.raises(ConstructorError) as excinfo:
        AnsibleConstructor.construct_mapping(u'not a mapping node')

# Generated at 2022-06-20 23:40:49.574086
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.composer import Composer, SafeComposer
    from yaml.scanner import Scanner, SafeScanner
    from yaml.parser import Parser, SafeParser
    from yaml.resolver import Resolver
    from yaml.reader import Reader, StringReader
    from yaml.constructor import Constructor
    from yaml.representer import BaseRepresenter, SafeRepresenter
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafe


# Generated at 2022-06-20 23:40:59.866404
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultEditor
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.template import Templar


# Generated at 2022-06-20 23:41:06.304155
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import nose

    # Test case - Python 2 with ascii value
    node = u'tag:yaml.org,2002:str'
    value = AnsibleUnicode('ascii')
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_str(node)

    assert result == value

    # Test case - Python 2 with unicode value
    node = u'tag:yaml.org,2002:str'
    value = AnsibleUnicode('unicode')
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_str(node)

    assert result == value

    # Test case - Python 3 with ascii value
    node = u'tag:yaml.org,2002:str'
    value = AnsibleUnicode('ascii')
    constructor = Ansible

# Generated at 2022-06-20 23:41:14.966499
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import io
    import os
    import shutil
    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # create the temporary directory and contents
    temp_dir_path = tempfile.mkdtemp()
    temp_file_path = os.path.join(temp_dir_path, "vault.txt")

    temp_file_handle = io.open(temp_file_path, "wt", encoding="utf-8")
    temp_file_handle.write(u"123456\n")
    temp_file_handle.close()

    # encrypt the file

# Generated at 2022-06-20 23:41:26.351595
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    import sys
    if sys.version_info[0] < 3:
        import StringIO as io
    else:
        import io
    class MockedLoader(yaml.SafeLoader):
        pass
    MockedLoader.add_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)
    yaml_str = io.StringIO("""
        - script: /usr/bin/foo
          args: --option={{ lookup('pipe', 'echo BAD_CONFIG') }}
    """)
    yaml_obj = yaml.load(yaml_str, Loader=MockedLoader)
    assert yaml_obj[0]['args'] == '--option={echo BAD_CONFIG}'

# Generated at 2022-06-20 23:41:32.492239
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # pylint: disable=import-error
    try:
        from unittest import mock
    except ImportError:
        import mock

    node = mock.Mock()
    ret = AnsibleConstructor().construct_vault_encrypted_unicode(node)

    assert ret is not None
    assert node.construct_scalar.call_count == 1
    return

# Generated at 2022-06-20 23:41:42.540719
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Create an instance of AnsibleConstructor
    lazy_constructor = AnsibleConstructor()

    # Create a node object
    unsafe_node = {'tag': 'tag:yaml.org,2002:str',
                   'value': '{{ 1 + 1 }}', 'start_mark': '?',
                   'end_mark': '?'}

    # Call method construct_yaml_unsafe of class AnsibleConstructor with parameters node
    result = lazy_constructor.construct_yaml_unsafe(unsafe_node)

    # Verify the result
    assert result == wrap_var(u'{{ 1 + 1 }}')

# Generated at 2022-06-20 23:41:50.460965
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ac = AnsibleConstructor()


# Generated at 2022-06-20 23:42:13.200395
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    secret = 'meow'
    vault_secret = to_bytes(secret)
    vault_secrets = [vault_secret]

# Generated at 2022-06-20 23:42:18.063678
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    ac = AnsibleConstructor()
    ac.construct_mapping()
    ac.construct_yaml_map()
    ac.construct_yaml_str()
    ac.construct_vault_encrypted_unicode()
    ac.construct_yaml_unsafe()

# Generated at 2022-06-20 23:42:28.178778
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    with open("test_yaml_loader.yml") as test_yaml_file:
        test_yaml_str = test_yaml_file.read()
    test_yaml_str = AnsibleConstructor.construct_yaml_str(AnsibleLoader(test_yaml_str).get_single_data())
    assert isinstance(test_yaml_str,AnsibleUnicode)
    assert test_yaml_str == u'\u041f\u0440\u0438\u0432\u0435\u0442, \u041c\u0438\u0440!'
    # print("test_yaml_str =

# Generated at 2022-06-20 23:42:34.933556
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

     # construct a yaml.MappingNode
     mn = MappingNode(u'tag:yaml.org,2002:map', [], [], start_mark=None, end_mark=None)
     ac = AnsibleConstructor()
     
     # construct a map
     data = ac.construct_yaml_map(mn)

     # data should be a AnsibleMap
     assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-20 23:42:46.780811
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping
    import sys

    # construct a ansible constructer object
    file_name = 'test'
    a = AnsibleConstructor(file_name)

    # construct an object that can be used to construct a ansibleMapping object
    node = StringIO("{'b': '\u2026'}")
    input = node.readline()
    print(input)
    while input != '':
        print(input)
        input = node.readline()

    # assert that the ansibleMapping object is constructed
    # assert type(a.construct_yaml_str(node)) is AnsibleMapping

# Generated at 2022-06-20 23:43:00.577973
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    s = u'list:\n  - {name: "John", age: 28}\n  - {name: "Rick", age: 20}'
    data = AnsibleLoader(s).get_single_data()

    assert len(data['list']) == 2
    assert isinstance(data['list'][0]['name'], AnsibleUnicode)
    assert isinstance(data['list'][0]['age'], AnsibleUnicode)
    assert isinstance(data['list'][1]['name'], AnsibleUnicode)
    assert isinstance(data['list'][1]['age'], AnsibleUnicode)

# Generated at 2022-06-20 23:43:11.394960
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('password')

# Generated at 2022-06-20 23:43:18.769359
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-20 23:43:32.687636
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
  import yaml
  data1 = """
  from_yaml_str: !unsafe
    - "A String"
    - "123"
  """
  data2 = """
  from_yaml_str: !unsafe
    - A String
    - 123
  """
  for data in [data1, data2]:
    print(data)
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    print(yaml_obj)
    assert type(yaml_obj['from_yaml_str'][0]) == AnsibleUnicode
    assert type(yaml_obj['from_yaml_str'][1]) == AnsibleUnicode
    assert str(yaml_obj['from_yaml_str'][0]) == 'A String'
    assert str

# Generated at 2022-06-20 23:43:37.722040
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml import MappingNode
    from ansible.parsing.yaml.objects import AnsibleMapping

    result = AnsibleConstructor.construct_yaml_map(AnsibleConstructor(), MappingNode())

    result_list = list(result)
    assert result_list[0] == AnsibleMapping()

# Generated at 2022-06-20 23:43:53.759715
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    instance = AnsibleConstructor()
    yaml_str = """---
- [1, 2, 3]
-
  - [4, 5, 6]
..."""
    yaml_fp = loader.io.StringIO(yaml_str)
    yaml_gen = yaml.compose_all(yaml_fp)
    node = next(yaml_gen)
    assert isinstance(next(instance.construct_yaml_seq(node)), list)



# Generated at 2022-06-20 23:44:02.637453
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # This test is to make sure you can override the construct methods in PyYAML
    # so the default string handling function is always returning unicode objects.
    #
    # NOTE: I've overridden this in a rather evil way, by patching the file
    #       when running the tests. Better to monkeypatch it, but these tests
    #       are already running in a modified environment so I don't want to
    #       make it even harder to track down problems.
    import yaml
    string = "{'foo': 'bar'}"
    # NOTE: get_single_data is a function that takes a string, parses it and returns
    #       a single Python data structure.
    data = yaml.get_single_data(string)
    assert isinstance(data['foo'], str) is True
    yaml.AnsibleConstructor = Ans

# Generated at 2022-06-20 23:44:15.387338
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['testlib.secrets']
    vault_secret_file = 'testlib.secrets'
    yaml_file = 'testlib.yaml'

    # Create a simple YAML file as test data and encrypt it
    node = AnsibleUnicode('foo: bar')
    node.ansible_pos = [yaml_file, 1, 0]
    vault = VaultLib(secrets=vault_secrets)
    encrypted_data = vault.encrypt(node)

    # Now read the YAML and decrypt it
    yaml_data = u'!vault ' + to_native(encrypted_data)
    raw_yaml = to_bytes(yaml_data)

# Generated at 2022-06-20 23:44:23.811198
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    constructor = AnsibleConstructor()
    example = yaml.load('''
    - host: localhost
    - host: localhost
    - host: 
      - localhost
      - 127.0.0.1
      - {x: [{y: 1}, {y: 2}]}
    - host:
      - localhost
      - 127.0.0.1
    ''')
    import pprint
    print(example)
    pprint.pprint(example)
    pprint.pprint(example[0])
    pprint.pprint(example[1])
    pprint.pprint(example[2])
    pprint.pprint(example[3])

if __name__ == '__main__':
    test_AnsibleConstructor()

# Generated at 2022-06-20 23:44:28.073281
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    data = '!!python/object/apply:os.system ["echo hello"]'
    loader = AnsibleLoader(data, None)
    # no exception = pass


# Generated at 2022-06-20 23:44:40.124141
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.display import Display
    display = Display()


# Generated at 2022-06-20 23:44:46.194231
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    yaml_text = u'!unsafe !foo\nbar'
    assert(isinstance(yaml.load(yaml_text, Loader=AnsibleConstructor), AnsibleUnsafeText))
    yaml_text = u'!foo\nbar'
    assert(isinstance(yaml.load(yaml_text, Loader=AnsibleConstructor), AnsibleUnsafeText))

# Generated at 2022-06-20 23:44:57.866525
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    # Test the Constructor of dict
    dict_node = '''\
    dog:
      - age: 3
        name: Sparky
      - age: 7
        name: Rex
    cat:
      - age: 1
        name: Muffin
      - age: 4
        name: Fluffball
    '''
    dict_value = dict(dog=[dict(age=3, name='Sparky'), dict(age=7, name='Rex')],
                      cat=[dict(age=1, name='Muffin'), dict(age=4, name='Fluffball')])


# Generated at 2022-06-20 23:45:05.871411
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = '''
- hosts: localhost
  tasks:
  - debug: msg={{ item }}
    with_items:
    - 1
    - 2
    - 3
    - [ foo, bar, baz ]
'''
    data = AnsibleLoader(yaml_data, AnsibleConstructor).get_single_data()

# Generated at 2022-06-20 23:45:17.559345
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    c = AnsibleConstructor
    vault_txt = u'test_value'
    vault_txt_b = b'test_value'
    vault_node = AnsibleBaseYAMLObject(vault_txt_b)
    vault_node.tag = u'!vault'

    # Test1
    vault_res = c.construct_vault_encrypted_unicode(vault_node)
    assert vault_res.data == vault_txt_b
    assert isinstance(vault_res, AnsibleVaultEncryptedUnicode)
    assert isinstance(vault_res.vault, VaultLib)



# Generated at 2022-06-20 23:45:44.803583
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor()
    v = a.construct_yaml_map('abc')
    assert repr(v) == repr(AnsibleMapping())


# Generated at 2022-06-20 23:45:54.761731
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """
    :type node: yaml.nodes.Node
    """

    class FakeNode(object):
        def __init__(self):
            self.start_mark = FakeNode()
            self.start_mark.name = FakeNode()
            self.start_mark.name.value = "my fake datasource"
            self.start_mark.column = FakeNode()
            self.start_mark.column.value = 1
            self.start_mark.line = FakeNode()
            self.start_mark.line.value = 1

        id = "yaml"

    ac = AnsibleConstructor()
    node = FakeNode()
    result = ac.construct_yaml_unsafe(node)

    assert result == wrap_var("yaml")

# Generated at 2022-06-20 23:46:06.327672
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    obj = {'key-1': 'value-1', 'key-2': 'value-2', 'key-3': 'value-3'}
    obj_1 = {'key-1': 'value-1', 'key-2': 'value-2', 'key-3': 'value-3', 'key-1': 'value-3'}
    obj_2 = {'key-1': 'value-1', 'key-2': 'value-2', 'key-3': 'value-3', 'key-1': 'value-3', 'key-2': 'value-4'}

# Generated at 2022-06-20 23:46:16.702321
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:46:21.362369
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    node = u'tag:yaml.org,2002:str'

    node1 = u'hello world'

    output1 = AnsibleConstructor.construct_yaml_str(node, node1)

    assert output1 == u'hello world'



# Generated at 2022-06-20 23:46:27.516620
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Example data for this method
    data = u'foo: bar'
    vault_secrets = [dict(vault_id='default', vault_password='ansible')]
    data_as_yaml = AnsibleConstructor(vault_secrets=vault_secrets).construct_yaml_map(data)
    assert data_as_yaml
    assert isinstance(data_as_yaml, AnsibleMapping)

# Generated at 2022-06-20 23:46:38.747199
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    constructors = AnsibleConstructor.yaml_constructors
    assert constructors[u'tag:yaml.org,2002:map'] == AnsibleConstructor.construct_yaml_map
    assert constructors[u'tag:yaml.org,2002:python/dict'] == AnsibleConstructor.construct_yaml_map
    assert constructors[u'tag:yaml.org,2002:str'] == AnsibleConstructor.construct_yaml_str
    assert constructors[u'tag:yaml.org,2002:python/unicode'] == AnsibleConstructor.construct_yaml_str
    assert constructors[u'tag:yaml.org,2002:seq'] == AnsibleConstructor.construct_yaml_seq
    assert constructors[u'!unsafe'] == AnsibleConstructor.construct_yaml_unsafe

# Generated at 2022-06-20 23:46:46.735325
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Load data
    test_data = b"""---
            - name: one_dict
              key1: val1
              key2: val2
            - name: duplicate_keys
              key1: val1
              key2: val2
              key1: val3
            - name: value_is_none
              key1:
              key2:
              key3: None
    """
    AnsibleConstructor.add_constructor(u'tag:yaml.org,2002:seq', AnsibleConstructor.construct_yaml_seq)
    data = yaml.load(test_data, Loader=AnsibleConstructor)
    # Verify data
    assert data[0]['name'] == "one_dict"
    assert data[0].ansible_pos == ('<unicode string>', 2, 3)

# Generated at 2022-06-20 23:46:59.500559
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [b'ansible']
    constructor = AnsibleConstructor(None, vault_secrets)

# Generated at 2022-06-20 23:47:00.161054
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-20 23:47:47.565653
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.vars import vault
    import os
    import tempfile
    import yaml
    import shutil

    # generate a random password, we'll need it later
    test_password = os.urandom(16).encode('hex')

    # set the vault password, so that we know it in the test
    vault.__password = test_password
    # build a simple test string
    test_string = "Hello World!"

    # try to encrypt the test string
    encrypted_data = vault.encrypt(test_string, 'AES256')

    # create a temporary file, to test loading the yaml code
    test_file = tempfile.NamedTemporaryFile(delete=False)

    # write the encrypted string

# Generated at 2022-06-20 23:47:48.559025
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert False, "TODO: Test this"

# Generated at 2022-06-20 23:47:56.301869
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    with open('../../lib/ansible/parsing/yaml/tests/vault/yaml/vault-encrypted-unicode.yml', 'r') as f:
        yaml_content = f.read()
    yaml_obj = yaml.load(yaml_content, Loader=AnsibleConstructor)
    # print(yaml_obj)
    print(yaml_obj['encrypted'])
    # _vault = yaml_obj['encrypted'].vault
    # ret = _vault.decrypt(yaml_obj['encrypted'].vault_data)
    # print(ret)

if __name__ == '__main__':
    import yaml
    test_AnsibleConstructor_construct_vault_encrypted_unicode()

# Generated at 2022-06-20 23:48:06.234927
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    import datetime
    import time
    constructor = AnsibleConstructor()
    data = {'datetime': datetime.datetime.now(),
            'date': datetime.date.today(),
            'time': time.time()}

    ret = constructor.construct_yaml_unsafe(data)

    assert hasattr(ret, '__ansible_unsafe__') is True
    assert isinstance(ret, dict) is True
    assert isinstance(ret['datetime'], datetime.datetime) is True
    assert isinstance(ret['date'], datetime.date) is True
    assert isinstance(ret['time'], float) is True

# Generated at 2022-06-20 23:48:16.202474
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import os
    import json
    import subprocess

    script_dir = os.path.dirname(os.path.realpath(__file__))
    ansible_yaml = os.path.join(script_dir, '../../lib/ansible/parsing/yaml/__init__.py')
    ansible_yaml = os.path.abspath(ansible_yaml)
    ansible_unsafe_proxy = os.path.join(script_dir, '../../lib/ansible/utils/unsafe_proxy.py')
    ansible_unsafe_proxy = os.path.abspath(ansible_unsafe_proxy)

# Generated at 2022-06-20 23:48:24.292278
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Create an instance of yaml.nodes.MappingNode
    mapping_node = MappingNode('tag:yaml.org,2002:map', [], [], start_mark=None, end_mark=None, flow_style=True)

    # Create an instance of yaml.nodes.SequenceNode
    sequence_node = AnsibleConstructor.construct_yaml_seq(mapping_node)

    assert isinstance(sequence_node, AnsibleSequence) is True


# Generated at 2022-06-20 23:48:29.706099
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()
    constructor.add_constructor(u"!unsafe", constructor.construct_yaml_unsafe)
    node = yaml.nodes.ScalarNode(u"!unsafe", "abc")
    result = constructor.construct_object(node)
    assert isinstance(result, WrapUnsafe)

# Generated at 2022-06-20 23:48:36.165863
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    nodes = yaml.compose('''
    - one
    - two
    -
      - three
      - four
    ''', Loader=yaml.Loader)

    data = AnsibleConstructor().construct_yaml_seq(nodes)

    assert data.ansible_pos == [u'<unicode string>', 1, 0]
    for value in data:
        assert value == u'one'
        break



# Generated at 2022-06-20 23:48:48.560624
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import UnsafeProxy, TO_TEXT_RECURSIVE
    class TestAnsibleConstructor(unittest.TestCase):
        """
        Test class for AnsibleConstructor.
        """
        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-20 23:48:55.686270
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
