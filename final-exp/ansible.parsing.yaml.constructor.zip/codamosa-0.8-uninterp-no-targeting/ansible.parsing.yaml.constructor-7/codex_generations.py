

# Generated at 2022-06-20 23:40:30.664842
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a_map = {'a': 1, 'b': 2}
    for i in range(4, 18):
        a_map['c' + str(i)] = i
        a_map['a' + str(i)] = i
    # construct mapping by AnsibleConstructor
    yaml_node = AnsibleConstructor.construct_yaml_map(a_map)
    # construct mapping by yaml.constructor.construct_yaml_map
    yaml_node1 = yaml.constructor.construct_yaml_map(a_map)

# Generated at 2022-06-20 23:40:32.001836
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-20 23:40:37.680930
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = u'a: 1\nb: 2'
    result = AnsibleConstructor().construct_yaml_map(data)
    assert isinstance(result, dict)
    assert b'a' in result
    assert b'b' in result
    assert result[b'a'] == 1
    assert result[b'b'] == 2


# Generated at 2022-06-20 23:40:49.995087
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test data for test_AnsibleConstructor_construct_mapping()
    import sys
    import yaml
    from yaml.constructor import ConstructorError
    from yaml.nodes import MappingNode
    from yaml.parser import ParserError

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-20 23:41:00.750768
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    data = """
    hello:
      nested: !unsafe foo
    """

    unsafe_mode = AnsibleLoader.unsafe_proxy

# Generated at 2022-06-20 23:41:06.858975
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.yaml.objects
    import os

    # Wrap a boolean
    bool_node = ansible.parsing.yaml.objects.AnsibleUnsafeBoolean(True)
    bool_val = AnsibleConstructor.construct_yaml_unsafe(None, bool_node)
    assert bool_val is True

    # Wrap a string
    str_node = ansible.parsing.yaml.objects.AnsibleUnsafeText(u'hello world')
    str_val = AnsibleConstructor.construct_yaml_unsafe(None, str_node)
    assert str_val == u'hello world'
    assert isinstance(str_val, unicode)

    # Wrap a list
    list_node = ansible.parsing.yaml.objects.AnsibleUnsafe

# Generated at 2022-06-20 23:41:15.486900
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    tnode = yaml.nodes.MappingNode('testMapping')
    tnode.value.append([yaml.nodes.ScalarNode('testKey'), yaml.nodes.ScalarNode('testValue')])
    tnode.value.append([yaml.nodes.ScalarNode('testKey'), yaml.nodes.ScalarNode('testValue2')])

    ac = AnsibleConstructor()
    assert ac.construct_mapping(tnode) == {'testKey':'testValue2'}

# Generated at 2022-06-20 23:41:27.524131
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.data import data_for_tests
    constructor = AnsibleConstructor()

    # Test case 1: test AnsibleUnicode on construct_yaml_str
    # Test data : str
    # Expected result : instance of AnsibleUnicode
    result = constructor.construct_yaml_str(data_for_tests['str'])
    assert isinstance(result, AnsibleUnicode)

    # Test case 2: test AnsibleUnicode on construct_yaml_str
    # Test data : unicode
    # Expected result : instance of AnsibleUnicode
    result = constructor.construct_yaml_str(data_for_tests['unicode'])
    assert isinstance(result, AnsibleUnicode)

    # Test case 3: test AnsibleUnicode on construct

# Generated at 2022-06-20 23:41:31.372995
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    safe_constructor = SafeConstructor.construct_scalar
    unsafe_constructor = AnsibleConstructor.construct_yaml_unsafe
    assert safe_constructor is not unsafe_constructor
    assert isinstance(safe_constructor(None), str)
    assert isinstance(unsafe_constructor(None), AnsibleUnsafeText)

# Generated at 2022-06-20 23:41:35.955216
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    dummy_node = type('', (), {'start_mark':None})
    dummy_constructor = AnsibleConstructor()
    dummy_constructor.construct_vault_encrypted_unicode(dummy_node)

# Generated at 2022-06-20 23:41:48.349556
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """Testing construct_yaml_str method of class AnsibleConstructor"""
    yaml_str = 'This is a unicode string'
    yaml_str_node = 'tag:yaml.org,2002:str'
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_object(yaml_str, yaml_str_node)
    assert isinstance(yaml_str, AnsibleUnicode)


# Generated at 2022-06-20 23:41:49.681158
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    obj = AnsibleConstructor()
    assert str(obj.construct_yaml_map(object)) is None

# Generated at 2022-06-20 23:42:00.214601
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    AnsibleConstructor._vaults = {}

    # Test Sequence
    # Test case 1: Use only construct_yaml_map
    data = yaml.load("{val: '1'}", Loader=AnsibleConstructor)
    assert isinstance(data, dict)
    assert isinstance(data, AnsibleMapping)

    # Test case 2: Use only construct_yaml_seq
    data = yaml.load("[1, 2, 3]", Loader=AnsibleConstructor)
    assert isinstance(data, list)
    assert isinstance(data, AnsibleSequence)

    # Test case 3: Use only construct_yaml_str
    data = yaml.load("str", Loader=AnsibleConstructor)
    assert isinstance(data, str)

# Generated at 2022-06-20 23:42:13.148768
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    # Use a magic string to encrypt the data, so this test is deterministic
    magic_string = 'pfft42'
    test_string = 'that was easy'

# Generated at 2022-06-20 23:42:24.374604
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    display.display("***** Starting test for AnsibleConstructor *****")
    ac = AnsibleConstructor()
    # test the construct_yaml_str method
    node = {'tag': 'tag:yaml.org,2002:str', 'value': 'example'}
    ans_str = ac.construct_yaml_str(node)
    display.display("ans_str.value is : " + ans_str.value)
    assert ans_str.value == 'example'
    # test construct_yaml_map method
    display.display("***** Starting test for construct_yaml_map *****")

# Generated at 2022-06-20 23:42:36.050853
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # get a sample yaml data
    # The first line is the string of interest, the second line is a valid yaml string,
    # The third line is the expected result of AnsibleConstructor.construct_yaml_str
    test_data = u"""\
    this is a test
    'this is a string'
    this is a test
    """
    # make a node from the yaml string
    from yaml.parser import Parser
    from yaml.scanner import Scanner

    parser = Parser(Scanner(test_data))
    for node in parser.get_event():
        if isinstance(node, MappingNode):
            break

    # test the constructor
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_str(node)
    assert(result == u'this is a test')

# Generated at 2022-06-20 23:42:49.261188
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class MockVaultLib(VaultLib):
        def __init__(self):
            self.secrets = ['foo']

        def decrypt(self, ciphertext):
            return b'bar'

    class MockNode(object):
        def __init__(self, value):
            self.value = value

    class MockConstructor(AnsibleConstructor):
        def __init__(self, vault):
            self._vaults = {'default': vault}

        def construct_scalar(self, node):
            return node.value

    node = MockNode('$ANSIBLE_VAULT;1.2;AES256;somesalt\nfoo')
    vault = MockVaultLib()
    constructor = MockConstructor(vault)

    encrypted_unicode = constructor.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-20 23:42:58.049993
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    constructor = AnsibleConstructor()
    test_list = '''
    test:
        - hello
        - world
    '''
    data = yaml.load(test_list, Loader=yaml.Loader)
    assert type(data) == AnsibleMapping
    assert type(data['test']) == AnsibleMapping


# Generated at 2022-06-20 23:43:01.780654
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert isinstance(AnsibleConstructor.construct_yaml_str({'value': 'BAR'}), AnsibleUnicode)

# Generated at 2022-06-20 23:43:10.047065
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars import AnsibleVaultEncryptedUnicode

    yaml = AnsibleConstructor()
    result = yaml.construct_mapping(MappingNode(), deep=True)
    assert isinstance(result, AnsibleMapping)

    # FIXME: vault support is currently not in pytest
    # result = yaml.construct_vault_encrypted_unicode(MappingNode(), deep=True)
    # assert isinstance(result, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-20 23:43:30.228654
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode
    from yaml.constructor import ConstructorError

    data = '''
{
key1: value1
}
'''
    constructor = AnsibleConstructor()
    try:
        constructor.construct_yaml_map(data)
    except ValueError:
        assert True
    else:
        assert False, "ValueError was not raised"

    data = '''
{
key1: value1
'''
    constructor = AnsibleConstructor()
    try:
        constructor.construct_yaml_map(data)
    except ConstructorError:
        assert True
    else:
        assert False, "ConstructorError was not raised"

    node = MappingNode(u'tag:yaml.org,2002:map', [], [])
    constructor = AnsibleConstructor()

# Generated at 2022-06-20 23:43:31.953173
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    pass # TODO: Write unit test


# Generated at 2022-06-20 23:43:40.372578
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    nodes = [u'dict1.yml', u'dict2.yml', u'dict3.yml', u'sequence.yml', u'unicode.yml', u'vault.yml']
    for node in nodes:
        y = AnsibleConstructor(file_name=node)
        assert y._ansible_file_name == node
        # test the tests
        assert node == y.construct_object(node)
        assert node != 'notnode'
        assert y._vaults is not None
        assert 'default' in y._vaults
        assert isinstance(y._vaults['default'], VaultLib)

# Generated at 2022-06-20 23:43:43.232579
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    yaml_data = '''
        foo:
          - !unsafe 'bar'
    '''
    data = yaml.safe_load(yaml_data)
    assert data['foo'][0] == wrap_var('bar')



# Generated at 2022-06-20 23:43:54.297767
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    expected_result = [
        AnsibleSequence(),
        AnsibleSequence()
    ]

    test_yaml_doc_1 = """- -""".encode('utf-8')
    test_yaml_doc_2 = """-
    -""".encode('utf-8')

    import yaml
    print('Result yaml_doc_1:')
    print(yaml.dump(yaml.load(test_yaml_doc_1, Loader=AnsibleConstructor), default_flow_style=False))
    print('Result yaml_doc_2:')
    print(yaml.dump(yaml.load(test_yaml_doc_2, Loader=AnsibleConstructor), default_flow_style=False))

# Generated at 2022-06-20 23:44:02.964021
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Testing a simple list
    content = '''\
    test_list:
      - 1
      - 2
      - 3
    '''
    yml = AnsibleConstructor(content, [])
    data = yml.get_single_data()
    assert data['test_list'] == [1, 2, 3]

    # Testing a dictionary
    content = '''\
    ---
    test_dict:
      key1: value1
      key2: value2
    '''
    yml = AnsibleConstructor(content, [])
    data = yml.get_single_data()
    assert data['test_dict']['key1'] == 'value1'
    assert data['test_dict']['key2'] == 'value2'

    # Testing an unsafed variable

# Generated at 2022-06-20 23:44:15.471263
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    import sys
    from ansible.parsing import vault
    from ansible.errors import AnsibleParserError

    class test_AnsibleConstructor(unittest.TestCase):
        def setUp(self):
            self.node = vault.VaultLib(secrets=['hunter2'])


# Generated at 2022-06-20 23:44:20.713473
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = AnsibleConstructor.construct_yaml_str('str-obj')
    assert yaml_str == 'str-obj'
    assert type(yaml_str) == AnsibleUnicode
    assert isinstance(yaml_str, AnsibleUnicode)


if __name__ == '__main__':
    test_AnsibleConstructor_construct_yaml_str()

# Generated at 2022-06-20 23:44:27.382268
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class FakeMark:
        def __init__(self, name, line, column):
            self.name = name
            self.line = line
            self.column = column

    yaml_str = u"Hello world!"
    yaml_str_node = FakeMark('name',1,1)
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_str(yaml_str_node)
    assert result == AnsibleUnicode(yaml_str)

# Generated at 2022-06-20 23:44:39.158989
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = u'a: 1\nb: 2\nc: 3\n'
    data = AnsibleLoader(yaml_data).get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data.ansible_pos[0], str)
    assert isinstance(data[u'a'], int)
    assert isinstance(data[u'b'], int)
    assert isinstance(data[u'c'], int)
    assert isinstance(data[u'a'], int)
    assert isinstance(data[u'b'], int)

# Generated at 2022-06-20 23:44:53.240725
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    AnsibleConstructor.add_constructor(u'!vault-encrypted', AnsibleConstructor.construct_vault_encrypted_unicode)
    test_data = AnsibleConstructor.construct_yaml_unsafe(None)
    assert test_data == None

# Generated at 2022-06-20 23:45:03.061683
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    verbose = []
    for line in fileinput.input():
        verbose.append(line)
    #verbose = """
    #{
    #  "display_name" : "Ticket ID: {{ticket_id}}",
    #  "display_name" : "Ticket ID: {{ticket_id}}",
    #  "enabled" : true,
    #  "display_name" : "Ticket ID: {{ticket_id}}",
    #  "display_name" : "Ticket ID: {{ticket_id}}"
    #}
    #"""
    #print("verbose:", verbose)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(verbose)

if __name__ == '__main__':
    import fileinput
   

# Generated at 2022-06-20 23:45:14.333559
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # create sample ciphertext
    data = "hello"
    vault = VaultLib()
    b_ciphertext_data = vault.encrypt(data.encode('utf8'))
    ciphertext_data = b_ciphertext_data.decode('utf8')
    # create a node representing the ciphertext data
    node = yaml.nodes.ScalarNode(u'!!python/object/apply:ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode [u\''+ciphertext_data+'\']')
    # create an instance of the constructor
    myConstructor = AnsibleConstructor()
    # create an instance of VaultLib with a password
    myConstructor._vaults['default'] = VaultLib(secrets=[u"password"])
    # call the constructor function

# Generated at 2022-06-20 23:45:21.391086
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    ansible_constructor = AnsibleConstructor()
    node = yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', [], [], None, None)
    value = ansible_constructor.construct_mapping(node)
    assert type(value).__name__ == 'AnsibleMapping'
    assert value.ansible_pos == (None, None, None)

# Generated at 2022-06-20 23:45:25.756151
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    from yaml import nodes

    # Test with a valid node
    node = nodes.ScalarNode('tag:yaml.org,2002:str', 'value')
    assert AnsibleConstructor.construct_yaml_str(AnsibleConstructor(), node) == u'value'

    # Test with a invalid node
    node = nodes.SequenceNode('tag:yaml.org,2002:seq', [])
    try:
        AnsibleConstructor.construct_yaml_str(AnsibleConstructor(), node)
    except ConstructorError as e:
        assert e.args[0] == 'expected a scalar node, but found <tag:yaml.org,2002:seq>'


# Generated at 2022-06-20 23:45:30.223140
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    value = 'this.should.be.a.list'
    result = "__ansible_unsafe__this.should.be.a.list"
    ansible_const = AnsibleConstructor()
    test_node = AnsibleUnicode(value)
    test_node.tag = u'!unsafe'
    assert ansible_const.construct_yaml_unsafe(test_node) == result

# Generated at 2022-06-20 23:45:31.122949
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = AnsibleSequence()
    assert data == []

# Generated at 2022-06-20 23:45:42.955285
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test should succeed
    ansible_constructor = AnsibleConstructor()
    ret = ansible_constructor.construct_yaml_str(node)
    assert isinstance(ret, AnsibleUnicode) and ret == u"whatever"

    # Test should fail
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-20 23:45:44.286194
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    c = AnsibleConstructor()
    input_str = 'test'
    ret = c.construct_yaml_str(input_str)
    assert ret == u'test' and type(ret) is AnsibleUnicode

# Generated at 2022-06-20 23:45:49.089338
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = """
        - abc
        - xyz
    """
    instance = AnsibleConstructor()
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data[0] == u'abc'
    assert data[1] == u'xyz'


# Generated at 2022-06-20 23:46:14.624611
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = u'---\n' \
                u'foo: bar\n' \
                u'bar: foo\n' \
                u'\n' \
                u'fred: 1\n' \
                u'george: 2\n'

    loader = AnsibleLoader(yaml_data, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleMapping)



# Generated at 2022-06-20 23:46:26.487459
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = 'mypassword'
    vault_secrets = [ vault_password, '0123456789ABCDEF' ]
    vault_text = '$ANSIBLE_VAULT;1.1;AES256'

    # Test vault with invalid id
    with pytest.raises(ConstructorError) as execinfo:
        # Create the AnsibleConstructor object
        c = AnsibleConstructor(vault_secrets=vault_secrets)

        # Create the data representing the vault
        data = vault_text + '\n' + '0123456789ABCDEF' + '\n' + 'VaultEncryptedContent'
        data = to_bytes(data)

        # Create the virtual yaml node

# Generated at 2022-06-20 23:46:37.143582
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """This test checks the construct_yaml_map method of the AnsibleConstructor class"""

    import sys
    from io import StringIO
    from yaml.nodes import MappingNode
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser

    ctor = AnsibleConstructor()

    # Create a map
    node = MappingNode("tag:yaml.org,2002:map", ctor.flatten_mapping(yaml.compose("""
    - name: web1
      ip: 192.0.2.10
      roles:
        - web
        - www
    - name: db1
      ip: 192.0.2.11
      roles:
        - db
        - database""")))

    list = ctor.construct_yaml_

# Generated at 2022-06-20 23:46:43.129874
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test a case when _ansible_file_name is None
    assert(AnsibleUnicode(u"").ansible_pos == ('<unicode>', 1, 1))

    # Test a case when _ansible_file_name is not None
    assert(AnsibleUnicode(u"", file_name="dummy1.yaml").ansible_pos == ('dummy1.yaml', 1, 1))


# Generated at 2022-06-20 23:46:46.944157
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    node = _get_test_mapping_node()
    value = ansible_constructor.construct_object(node)
    assert value == {u'a': u'b'}
    assert isinstance(value[u'a'], AnsibleUnicode)
    assert value[u'a'].ansible_pos == (u'<string>', 1, 2)



# Generated at 2022-06-20 23:46:59.664359
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml import MappingNode
    from collections import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleMapping

    a_dict = OrderedDict()
    a_dict['k1'] = 1
    a_dict['k2'] = 2
    a_dict['k3'] = 3

    a_mapping_node = MappingNode(u'tag:yaml.org,2002:map', a_dict.items())

    display.verbosity = 3
    ac = AnsibleConstructor()

    result = ac.construct_mapping(a_mapping_node)
    assert isinstance(result, AnsibleMapping)
    assert len(result) == 3

    result2 = ac.construct_mapping(a_mapping_node)

# Generated at 2022-06-20 23:47:09.697198
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    '''
    Since the methods construct_mapping and _node_position_info are not introduced by pytest,
    we test the method `construct_mapping` by call the method directly.
    '''

    import yaml
    from ansible.utils.unsafe_proxy import wrap_var

    # Test the case when key is not duplicated
    sample_data = '''
    xxx:
        key1: test
        key2: [1, 2, 3]
        key3:
            key4: test
    '''
    data = yaml.load(sample_data, Loader=AnsibleConstructor)
    assert data.get('xxx').get('key1') == wrap_var('test')
    assert data.get('xxx').get('key2') == wrap_var([1, 2, 3])
    assert data

# Generated at 2022-06-20 23:47:18.399111
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    a = AnsibleConstructor()
    list_ = [1, 2, 3]

    #  class yaml.nodes.SequenceNode('tag:yaml.org,2002:seq', [], None, None, None)

    node = yaml.nodes.SequenceNode('tag:yaml.org,2002:seq', list_, None, None, None)

    data = a.construct_yaml_seq(node)

    assert next(data) == list_
    assert next(data) is None
    assert list_ == next(data)

# Generated at 2022-06-20 23:47:28.962604
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # There is no error in the code for Python 2 and Python 3
    # So, let's test this method with different cases.
    from ansible.module_utils.six import u, STRING_TYPES, text_type
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Let's take some sample data.
    data = 'data: !unsafe {0}'.format("""
            a: 3
            b: 2
            c:
              - 1
              - 2
              - 3
            #dict_val: {'a': 3, 'b': 2, 'c': [1, 2, 3]}
            """)
    # Use with AnsibleLoader to load the data in YAML format.
    data_result = AnsibleLoader(data).get_single_data()

# Generated at 2022-06-20 23:47:37.245873
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    # test when C.DUPLICATE_YAML_DICT_KEY is 'ignore'
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    ac = AnsibleConstructor()
    ac.construct_mapping(node)

    # test when C.DUPLICATE_YAML_DICT_KEY is 'warn'
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    ac = AnsibleConstructor()
    ac.construct_mapping(node)

    # test when C.DUPLICATE_YAML_DICT_KEY is 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'
   

# Generated at 2022-06-20 23:48:25.493865
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_string = u"""
    ---
    - baz:
        d: "{{ foo.bar }}"
        c: "{{ foo.bar }}"
    - foo: "{{ foo.bar }}"
    - foo: bar
    - foo:
        bar:
          bam:
            baz: bam
    - foo:
        bar:
          bam:
            baz: bam
            baz: bam
    """
    obj = AnsibleLoader(yaml_string, file_name='file_name').get_single_data()

    assert obj[0][u'baz'][u'c'] == obj[0][u'baz'][u'd']
    assert obj[1] == obj[2]

# Generated at 2022-06-20 23:48:27.466481
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass


if __name__ == '__main__':
    test_AnsibleConstructor()

# Generated at 2022-06-20 23:48:37.986824
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Create an instance of class AnsibleConstructor
    ac = AnsibleConstructor()
    # Create a DTO for node
    from ansible.parsing.yaml.dumper import AnsibleDumper
    node = AnsibleDumper.represent_unicode('unsafe', None)
    # Invoke method with valid parameters
    result = ac.construct_yaml_unsafe(node)
    # Check that result is as expected
    expected = node.value
    assert result == expected, "Invoke method construct_yaml_unsafe with valid parameters. Result does not match expected value"
    # Check that attributes match
    assert result == node.value, "Invoke method construct_yaml_unsafe with valid parameters. Attribute result does not match expected value"
    # Invoke with different parameters and check that the results are as expected
    # We can

# Generated at 2022-06-20 23:48:48.405619
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    text = '''
    ['1', '2', '3']
    '''
    yaml_data = yaml.load(text, Loader=AnsibleConstructor)
    assert 'ansible_pos' in yaml_data
    assert yaml_data.ansible_pos[0] == '<unicode string>'
    assert yaml_data.ansible_pos[1] == 2
    assert yaml_data.ansible_pos[2] == 5
    assert yaml_data[0] == '1'
    assert yaml_data[1] == '2'
    assert yaml_data[2] == '3'

# Generated at 2022-06-20 23:48:59.242523
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    s = u'\nkey1: value1\nkey2: value2\n'
    data = AnsibleLoader(s, file_name='test', vault_secrets=[VaultLib()]).get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['key1'], AnsibleUnicode)
    assert isinstance(data['key2'], AnsibleUnicode)

    s = u'\nA: B\nC: D\n'
    data = AnsibleLoader

# Generated at 2022-06-20 23:49:08.253572
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """Verify that a sequence is returned as an AnsibleSequence.

    """
    class FakeNode(object):
        def __init__(self, start_mark, end_mark):
            self.start_mark = start_mark
            self.end_mark = end_mark

    class FakeMark(object):
        def __init__(self, name, line):
            self.name = name
            self.line = line
            self.column = 4

    data = AnsibleConstructor.construct_yaml_seq(
        FakeNode(FakeMark('foo', 1), FakeMark('bar', 3)))

    assert isinstance(data, AnsibleSequence)



# Generated at 2022-06-20 23:49:12.418139
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = """
    - one: foo
    - two: bar
    """

    ac = AnsibleConstructor()
    data = yaml.load(node, Loader=AnsibleConstructor)
    assert isinstance(data[0]['one'], AnsibleUnicode)

# Generated at 2022-06-20 23:49:18.695865
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = u'--- {key: test}\n'
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj, AnsibleMapping)
    assert yaml_obj['key'] == u'test'
    assert yaml_obj.ansible_pos == (None, 1, 1)
    assert yaml_obj.ansible_line_number == 1



# Generated at 2022-06-20 23:49:25.113713
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    txt = '''
       e:
          - 1
          - 2
          - 3
       f:
          - 4
          - 5
          - 6
    '''
    test = yaml.load(txt, Loader=AnsibleConstructor)
    assert isinstance(test, dict)
    assert isinstance(test['e'], list)
    assert isinstance(test['f'], list)
    assert len(test['e']) == 3
    assert len(test['f']) == 3

# Generated at 2022-06-20 23:49:36.848115
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Test construct_yaml_map
    assert AnsibleConstructor.construct_yaml_map('node') == ['node']
    assert AnsibleConstructor.construct_yaml_map('node').pop() == 'node'
    assert AnsibleConstructor.construct_yaml_map('node').pop() is None

    # Test construct_mapping
    assert AnsibleConstructor.construct_mapping('node') == ''
    assert AnsibleConstructor.construct_mapping('node') == ''

    # Test construct_yaml_str
    assert AnsibleConstructor.construct_yaml_str('node') == ('node')

    # Test construct_vault_encrypted_unicode
    assert AnsibleConstructor.construct_vault_encrypted_unicode('node') == ('node')

    # Test construct_yaml_seq
    assert Ansible