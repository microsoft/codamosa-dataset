

# Generated at 2022-06-20 23:40:29.108356
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPasswordError

    try:
        # Create an AnsibleConstructor with a vault secret
        c = AnsibleConstructor(vault_secrets=[VaultSecret('foobar')])
    except VaultPasswordError:
        pytest.skip("Vault password is not present in environment, skipping test")

    # Assert that there is a VaultLib object in the constructor
    assert isinstance(c._vaults['default'], VaultLib)

    # The constructor is given a yaml string that is a yaml mapping node containing
    # an encrypted key:value pair. When passing the string to the constructor,
    # the !unsafe tag is omitted. The !vault tag should still be

# Generated at 2022-06-20 23:40:35.280709
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    example_yaml = """
key1: value1
key2: value2
key3: value3
"""
    # Load the YAML above into a data structure
    stream = StringIO(example_yaml)
    data = yaml.load(stream, Loader=AnsibleConstructor)

    assert isinstance(data, dict)
    assert len(data) == 3
    assert data['key1'] == 'value1'
    assert data['key2'] == 'value2'
    assert data['key3'] == 'value3'



# Generated at 2022-06-20 23:40:48.130562
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    import os
    import re
    import sys
    import tempfile
    import unittest
    import yaml

    if sys.version_info < (2, 7):
        import unittest2 as unittest

    #TODO: add test for AnsibleUnicode when the Vault class supports unicode in both Python2 and Python3


    def clean_id(val):
        return re.sub(r'[<>]', '', repr(val))


    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None
            self.constructor = AnsibleConstructor()


        def tearDown(self):
            pass



# Generated at 2022-06-20 23:40:56.041489
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    loader = AnsibleLoader(stream="""
foo: !unsafe |
  {{ var }}
""")
    data = loader.get_single_data()
    assert isinstance(data['foo'], AnsibleUnsafeText)
    assert data['foo']._obj == "{{ var }}"

# Generated at 2022-06-20 23:41:05.931808
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    class TestConstructor(AnsibleConstructor):

        def __init__(self):
            self._ansible_file_name = None

        def get_data(self):
            return "data"

    tc = TestConstructor()

    node = MappingNode(tag=u"tag:yaml.org,2002:map", value=[], start_mark=None, end_mark=None)

    m = tc.construct_mapping(node)
    assert m == AnsibleMapping()

# Generated at 2022-06-20 23:41:09.254177
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = '''
    title: test
    title: test2
    '''

    constructor = AnsibleConstructor()
    node = constructor.construct_yaml_map(constructor.construct_yaml_str(None, data))
    print(node)

# Generated at 2022-06-20 23:41:18.459504
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    orig = AnsibleConstructor(None)
    val = [1,2,3]
    node = yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', [])
    newobj = orig.construct_yaml_seq(node)
    ret = newobj.next()
    assert(isinstance(ret, AnsibleSequence))
    ret.extend(val)
    assert(ret == val)
    assert(ret.ansible_pos is None)


# Generated at 2022-06-20 23:41:22.164387
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    ansib = AnsibleConstructor()

    try:
        ansib.construct_mapping({})
    except Exception as e:
        sys.stderr.write("%s\n" % type(e))



# Generated at 2022-06-20 23:41:33.165709
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import os
    import tempfile
    import yaml

    data = """
---
- foo
- bar
- baz
"""
    path = tempfile.mkstemp()[1]
    with open(path, 'w') as f:
        f.write(data)

    constructor = AnsibleConstructor(file_name=path)
    loader = yaml.Loader(data, constructor)
    sequence = loader.get_single_data()
    assert type(sequence).__name__ == 'AnsibleSequence'
    assert sequence[0] == 'foo'
    assert sequence[1] == 'bar'
    assert sequence[2] == 'baz'
    os.unlink(path)

# Generated at 2022-06-20 23:41:37.589338
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    assert yaml.load("key: value", Loader=AnsibleConstructor) == {'key': u'value'}

# Generated at 2022-06-20 23:41:54.757396
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Verify that a AnsibleVaultEncryptedUnicode object is returned when the node.value's value is not empty.
    # GIVEN
    vault_secrets = ['secret1', 'secret2']
    node = None
    constr = AnsibleConstructor(vault_secrets)
    plaintext = 'my plaintext secret message'
    ciphertext = constr._vaults['default'].encrypt(plaintext)

    # WHEN
    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', ciphertext)

    # THEN
    assert type(constr.construct_vault_encrypted_unicode(node)) == AnsibleVaultEncryptedUnicode
    assert constr.construct_vault_encrypted_unicode(node).encode() == to_bytes(ciphertext)

# Generated at 2022-06-20 23:41:57.712751
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    ana = AnsibleConstructor("test")
    assert ana._ansible_file_name == "test"
    assert ana.vault_secrets == []
    assert ana._vaults['default'] is not None

# Generated at 2022-06-20 23:42:10.323680
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes, to_native
    for data in [to_bytes(u'Hello world!'), to_bytes(u'Hello world!')]:
        value = AnsibleLoader(data, AnsibleConstructor).get_single_data()
        assert type(value) == AnsibleUnicode
        assert value == to_bytes(u'Hello world!')
        assert AnsibleDumper().dump(value) == to_bytes(u'"Hello world!"\n')

# Generated at 2022-06-20 23:42:15.444761
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = "[{'a' : 'b', 'c' : 'd'}]"
    node = yaml.load(node)
    construct_mapping = AnsibleConstructor.construct_yaml_map(node)
    for i in construct_mapping:
        print(i)


# Generated at 2022-06-20 23:42:19.903511
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import load
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = u'---\n- a\n- b\n- c\n'
    data = load(yaml_str, Loader=AnsibleLoader)
    try:
        data == [u'a', u'b', u'c']
    except Exception as e:
        raise AssertionError(e.message)



# Generated at 2022-06-20 23:42:29.254196
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import shlex
    from ansible import constants as C
    from ansible.parsing.yaml.dumper import AnsibleDumper

    C.DEFAULT_DEBUG = False

    text = """
    ---
    - hosts: 127.0.0.1
      gather_facts: no
      tasks:
      - debug:
          msg: "{{ cmd | unsafe('shell_escape') }}"
      no_log: true
    """
    text_safe = """
    ---
    - hosts: 127.0.0.1
      gather_facts: no
      tasks:
      - debug:
          msg: "{{ cmd | to_native }}"
      no_log: true
    """

# Generated at 2022-06-20 23:42:41.539422
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor

# Generated at 2022-06-20 23:42:48.405867
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import io

    yaml_str = """
        first: line
        second: line
    """
    obj_expected = {u'first': u'line', u'second': u'line'}

    yaml_fp = io.StringIO(yaml_str)
    obj = yaml.load(yaml_str, Loader=AnsibleConstructor)

    assert obj == obj_expected

# Generated at 2022-06-20 23:43:02.301440
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    if sys.version_info[0] < 3:
        valid_types = (unicode, int, dict, list)
    else:
        valid_types = (str, int, dict, list)

    node = MappingNode('tag:yaml.org,2002:map', [], None, None, None)
    c = AnsibleConstructor(file_name='test_AnsibleConstructor_construct_mapping')
    result = c.construct_mapping(node, deep=True)
    assert(isinstance(result, dict))
    assert(isinstance(result, AnsibleMapping))
    assert(isinstance(result.ansible_pos, tuple))
    assert(len(result.ansible_pos) == 3)

# Generated at 2022-06-20 23:43:11.697647
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    lines = """
    - hosts: all
      vars:
        a: 1
        a: 2
    """
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    datastructure = yaml.load(lines, Loader=AnsibleLoader)
    assert datastructure == [{'hosts': 'all', 'vars': {'a': 2}}]

    lines = """
    - hosts: all
      vars:
        a: 1
        a: 2
    """
    datastructure = yaml.load(lines, Loader=AnsibleLoader)
    assert datastructure == [{'hosts': 'all', 'vars': {'a': 2}}]



# Generated at 2022-06-20 23:43:30.687701
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import collections

    class AnsibleMappingTest(collections.MutableMapping):
        def __init__(self, *args, **kwargs):
            self.ansible_pos = (1, 1, 1)
            self.store = dict()
            self.update(dict(*args, **kwargs))  # use the free update to set keys

        def __getitem__(self, key):
            return self.store[key]

        def __setitem__(self, key, value):
            self.store[key] = value

        def __delitem__(self, key):
            del self.store[key]

        def __iter__(self):
            return iter(self.store)

        def __len__(self):
            return len(self.store)


# Generated at 2022-06-20 23:43:40.457456
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    class TestData(yaml.YAMLObject):
        yaml_tag = u"tag:yaml.org,2002:test"
        def __init__(self, data):
            self.data = data
        def __repr__(self):
            return "%s(data=%r)" % (self.__class__.__name__, self.data)

    # define a test object
    data = TestData(42)
    # define a dict of test data
    data_dict = dict(a=1, b=2, c=3)
    # define a list of test data
    data_list = [1, 2, 3]
    # define some test data

# Generated at 2022-06-20 23:43:53.761938
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    if sys.version_info[0] == 2:
        # python2
        s = u'\u001b[31m31\u001b[0m'
        t = AnsibleUnsafeText(s)
        assert isinstance(t, AnsibleUnsafeText) and t._text == s
    else:
        # python3
        s = u'\u001b[31m31\u001b[0m'
        t = AnsibleUnsafeText(s)
        assert isinstance(t, AnsibleUnsafeText) and t._text == s

    t = AnsibleUnsafeText('test')
    assert isinstance(t, AnsibleUnsafeText) and t._text == 'test'

    t = Ansible

# Generated at 2022-06-20 23:44:02.636497
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret

    secret = get_file_vault_secret(None, 1)
    vault_secrets = [secret]

# Generated at 2022-06-20 23:44:11.976348
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from io import StringIO
    input_string = u"""
        - 'a_string'
    """

    stream = StringIO(input_string)
    loader = AnsibleLoader(stream, 'myyaml')
    sequence = loader.get_single_data()
    assert isinstance(sequence[0], AnsibleUnicode)
    assert sequence[0] == u'a_string'

# Generated at 2022-06-20 23:44:12.645787
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

# Generated at 2022-06-20 23:44:18.052409
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    unsafe_type = AnsibleConstructor.construct_yaml_unsafe

    # Valid test cases
    assert unsafe_type(object) == unsafe_type(object)

    # Invalid test cases
    assert unsafe_type(str) != unsafe_type(str)
    assert unsafe_type(int) != unsafe_type(int)
    assert unsafe_type(list) != unsafe_type(list)

# Generated at 2022-06-20 23:44:24.836146
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import io
    import sys
    import unittest
    import yaml
    if sys.version_info[0] == 3:
        unittest.TestCase.assertItemsEqual = unittest.TestCase.assertCountEqual

    class TestConstructMapping(unittest.TestCase):
        def _test_construct_mapping(self, input_yml, expected_res):
            ac = AnsibleConstructor()
            yml = yaml.load(io.StringIO(input_yml), Loader=AnsibleConstructor)
            mapping = ac.construct_mapping(yml)
            self.assertEqual(mapping, expected_res)

        def test_empty_dict(self):
            input_yml = """
            {}
            """
            expected_res = AnsibleMapping()

           

# Generated at 2022-06-20 23:44:37.040659
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Create data to parse
    data = '''
- !unsafe 'foo'
- !unsafe
- !unsafe 'bar'
- !unsafe
- !unsafe
- !unsafe 'baz'
    '''
    # Create YAML loader of class AnsibleConstructor
    loader = AnsibleConstructor()
    # Create list to append result to
    results = []
    # Request the loader to load the data
    for item in loader.construct_yaml_seq(loader.construct_yaml_unsafe(loader.construct_document(loader.get_single_data(data)))):
        # Append the result to the list
        results.append(item)
    # Assert the result is what we expected

# Generated at 2022-06-20 23:44:44.709562
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = """
- hosts: all
  tasks:
  - name: this is a task
    command: /bin/foo
- name: this is another task
  command: /bin/bar
    """
    ansible_constructor = AnsibleConstructor(file_name="fake_filename")
    data = list(ansible_constructor.construct_yaml_seq(yaml_data))
    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert isinstance(data[1], dict)


# Generated at 2022-06-20 23:45:00.218280
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    if sys.version_info[0] == 2:
        # Python 2
        from StringIO import StringIO
    else:
        # Python 3
        from io import StringIO

    yaml_src = StringIO("""
key1: val1
key2:
  key2.1: val2.1
  key2.2: val2.2
key3:
  - item
key4:
  key4.1: item
""")

    ansible_constructor = AnsibleConstructor(file_name=None)
    for node in yaml_src:
        print("node: {}".format(node))
        data = ansible_constructor.construct_mapping(node)
        print("data: {}".format(data))
        assert type(data) is AnsibleMapping

# Generated at 2022-06-20 23:45:02.589065
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    constructor = AnsibleConstructor()
    assert hasattr(constructor, 'construct_python_unicode')
    assert hasattr(constructor, 'construct_yaml_unsafe')

# Generated at 2022-06-20 23:45:10.429322
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test function construct_yaml_map of class AnsibleConstructor to cover
    #  all paths through the code, including the default case
    test_input = """
        ---
        key:
          - host
          - {role: web, country: us}
        """
    yaml_data = yaml.load(test_input, Loader=AnsibleConstructor)
    assert yaml_data.ansible_pos == ('<unicode string>', 1, 1)
    assert yaml_data['key'].ansible_pos == ('<unicode string>', 3, 3)

# Generated at 2022-06-20 23:45:14.382475
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node = object()
    list = []
    list.append(ansible_constructor.construct_yaml_seq(node))
    assert (isinstance(list[0], AnsibleSequence))

# Generated at 2022-06-20 23:45:25.911546
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import traceback
    import yaml

    def pytest_funcarg__AnsibleConstructor(request):
        return AnsibleConstructor

    def test_construction(AnsibleConstructor):
        def test_cont(test_value):
            test_cont.test_value = test_value
            test_cont.test_value.ansible_pos = None
            test_cont.test_value.vault = None

        test_cont(AnsibleConstructor())

        # Check instantiation of class AnsibleConstructor

# Generated at 2022-06-20 23:45:33.219267
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml

    test_data = yaml.load('''
---
- !unsafe foo
- !unsafe [1,2,3]
- !unsafe {a: b}
    ''')
    from ansible.utils.unsafe_proxy import wrap_var, UnsafeVariableWarning

    with warnings.catch_warnings(record=True) as w:
        assert 'foo' == test_data[0].value
        assert isinstance(test_data[0], wrap_var)
        assert test_data[0].__class__.__name__ == 'UnsafeProxy'
        assert isinstance(w[0].message, UnsafeVariableWarning)

        assert [1,2,3] == test_data[1].value
        assert isinstance(test_data[1], wrap_var)
        assert test_data

# Generated at 2022-06-20 23:45:45.118804
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    # this test is not ideal.  The issue is that there is no
    # easy way to hook in and validate the type of an object
    # when it is constructed by pyyaml or to see whether or not
    # our kludge actually worked

    test_str = "Hello World"

    # check to see if the string was of type "unicode"
    output = yaml.dump({'test': test_str})
    assert 'unicode' in output
    output = yaml.dump({'test': '%s' % (test_str)})
    assert 'unicode' in output
    output = yaml.dump({'test': '{{ test_str }}'})
    assert 'unicode' in output
    output = yaml.dump({'test': '{{ test_str | string }}'})

# Generated at 2022-06-20 23:45:55.006247
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys, os
    sys.path.append(os.path.abspath('lib'))

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    yaml_data = """
        key: value
        key_list:
          - key_a
          - key_b
          - key_c
        key_dict:
            sub_key1: sub_val1
            sub_key2: sub_val2
        """

    data = yaml.load(yaml_data, Loader=AnsibleLoader)

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['key_list'], AnsibleSequence)

# Generated at 2022-06-20 23:46:00.139082
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """Play around with a string which will be parsed with AnsibleConstructor."""
    s = """
    a: hello
    b: world
    """
    ymap = AnsibleConstructor(file_name="test").construct_yaml_map(yaml.compose(s))
    assert ymap["a"] == "hello"
    assert ymap["b"] == "world"

# Generated at 2022-06-20 23:46:12.218794
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os
    import sys

    import yaml

    test_data_path = os.path.join(os.path.dirname(__file__), 'test_data', 'construct_mapping')
    # this is just a normal yaml mapping that we'll use as the ground truth
    with open(os.path.join(test_data_path, 'test_mapping.yml'), 'rb') as ground_truth_fd:
        ground_truth_data = yaml.safe_load(ground_truth_fd.read())

    # for each of the test yaml files we have, load each
    # as a MappingNode and feed them to the construct_mapping method

# Generated at 2022-06-20 23:46:31.416355
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    # basic test for constructor of class AnsibleConstructor object
    a = AnsibleConstructor()
    assert type(a) == AnsibleConstructor
    assert type(a.construct_scalar) == type(SafeConstructor.construct_scalar)
    assert type(a.construct_mapping) == type(SafeConstructor.construct_mapping)
    assert type(a.construct_yaml_map) == type(AnsibleConstructor.construct_yaml_map)
    assert type(a.construct_yaml_str) == type(AnsibleConstructor.construct_yaml_str)
    assert type(a.construct_yaml_seq) == type(AnsibleConstructor.construct_yaml_seq)

# Generated at 2022-06-20 23:46:40.513224
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ac = AnsibleConstructor()
    from yaml import nodes
    from yaml.parser import Parser
    from yaml.reader import Reader
    from io import StringIO

    text = u'{a: 1, b: 2, a: 3}'
    reader = Reader(text, StringIO(text))
    parser = Parser(reader)
    node = parser.get_node()
    assert isinstance(node, nodes.MappingNode)
    mapping = ac.construct_mapping(node)
    assert isinstance(mapping, dict)
    assert mapping['a'] == 3
    assert mapping['b'] == 2


# Generated at 2022-06-20 23:46:47.507288
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_data = {
        # test data
        'duplicate_keys': {'a': 'b', 'a': 'c'},
        'duplicate_keys_nested': {'a': {'b': {'c': 'd'}, 'b': {'c': 'd'}}},
        'no_duplicate_keys': {'a': 'b', 'A': 'c', 'b': 'c', 'd': 'e'},
        'no_duplicate_keys_nested': {'a': {'b': {'c': 'd'}, 'B': {'c': 'd'}}, 'b': {'c': 'd'}, 'd': {'e': 'f'}},
    }


# Generated at 2022-06-20 23:47:00.100844
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    AnsibleConstructor.add_constructor(
        u'!unsafe',
        AnsibleConstructor.construct_yaml_unsafe)

    # test boolean
    node = u'!unsafe true'
    obj = AnsibleConstructor.construct_yaml_unsafe(node)
    assert obj.__class__ == u'bool'

    # test int
    node = u'!unsafe 12'
    obj = AnsibleConstructor.construct_yaml_unsafe(node)
    assert obj.__class__ == u'int'

    # test float
    node = u'!unsafe 12.0'
    obj = AnsibleConstructor.construct_yaml_unsafe(node)
    assert obj.__class__ == u'float'

    # test string
    node = u'!unsafe "str"'
   

# Generated at 2022-06-20 23:47:09.984668
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from yaml.parser import ParserError


# Generated at 2022-06-20 23:47:22.322675
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml = """
---
key:
    subkey: value
    subsubkey: other value
"""
    data = yaml_load(yaml)
    assert hasattr(data, 'ansible_pos')
    assert 1 == data.ansible_pos[1]
    assert 1 == data.ansible_pos[2]
    assert '<string>' == data.ansible_pos[0]
    assert len(data) == 1
    assert 'key' in data
    subdata = data['key']
    assert hasattr(subdata, 'ansible_pos')
    assert 2 == subdata.ansible_pos[1]
    assert 3 == subdata.ansible_pos[2]
    assert '<string>' == subdata.ansible_pos[0]
    assert len(subdata) == 2


# Generated at 2022-06-20 23:47:26.918338
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # test with duplicated keys in a map
    node = MappingNode(u'foo', [(u'a', None), (u'a', None)], False)
    constructor = AnsibleConstructor()
    data = AnsibleMapping()
    data.update(constructor.construct_mapping(node))
    assert data



# Generated at 2022-06-20 23:47:35.306068
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import json
    import copy
    import collections
    import platform

    # Test the parsing of python objects which are not able to be run through json.load
    # This is to ensure that the parsing of these objects is not breaking.
    c = AnsibleConstructor()

# Generated at 2022-06-20 23:47:36.193436
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert(True)

# Generated at 2022-06-20 23:47:48.691211
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMutableSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    try:
        # Python 2
        unicode  # noqa
    except NameError:
        # Python 3
        basestring = str

    # Test Success Case
    test_input_1 = (b'{ "ab": { "cd": { "ef": [ "g", "h" ] } }, "ij": [ "k", "l", "m" ] }')  # noqa
    test_output_1 = {'ab': {'cd': {'ef': ['g', 'h']}}, 'ij': ['k', 'l', 'm']}

    # Test a case that duplicate dict keys shoud warn
    test_input_

# Generated at 2022-06-20 23:48:12.556980
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    # Makes sure that the !unsafe tag is set on the data
    data = """---
- !unsafe '{"a": true}'
- !unsafe '{"b": true}'
"""
    try:
        yaml.load(data, AnsibleConstructor)
    except NotImplementedError:
        return

    assert data == yaml.safe_dump(yaml.load(data, AnsibleConstructor))



# Generated at 2022-06-20 23:48:18.252932
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secret = "vault_secret\n"
    secrets = [vault_secret]
    ansible_constructor = AnsibleConstructor(vault_secrets=secrets)
    mock_node = type('MockNode', (object,), {'start_mark': type('MockMark', (object,), {})})
    ansible_constructor.construct_scalar = lambda node: 'vaulted_value'
    result = ansible_constructor.construct_vault_encrypted_unicode(mock_node)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.decrypt() == 'vaulted_value'

# Generated at 2022-06-20 23:48:22.392149
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    foo = AnsibleConstructor()
    class Y(object):
        id = 'mapping'
    class X(object):
        start_mark = Y()
        value = []

    assert foo.construct_mapping(X())


AnsibleSafeConstructor = AnsibleConstructor

# Generated at 2022-06-20 23:48:34.275445
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.errors import AnsibleParserError
    from types import GeneratorType

    yaml.add_constructor(u'tag:yaml.org,2002:seq', AnsibleConstructor.construct_yaml_seq)
    assert_equal(yaml.load('- 1\n- 2\n', Loader=AnsibleLoader), [1, 2])
    assert isinstance(yaml.load('- 1\n- 2', Loader=AnsibleLoader), list)
    assert isinstance(yaml.load(u'- 1\n- 2', Loader=AnsibleLoader), list)
    assert isinstance(yaml.load('[1, 2]', Loader=AnsibleLoader), list)
    assert isinstance(yaml.load('[]', Loader=AnsibleLoader), list)

# Generated at 2022-06-20 23:48:45.499474
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.module_utils.common.collections import ImmutableDict
    sample_yaml = ImmutableDict(
        {
            "foo": "bar",
            "ansible_pos": ("bar.yml", 1, 1),
            "sam": "ple",
            "example": "dict"
        }
    )
    yaml_node = MappingNode("tag:yaml.org,2002:map", items=[("foo", "bar"), ("sam", "ple"), ("example", "dict")], anchor=None)

    tester = AnsibleConstructor("bar.yml")
    assert tester.construct_mapping(yaml_node) == sample_yaml

    # Encrypted data
    import ansible.parsing.vault as vault

# Generated at 2022-06-20 23:48:57.003462
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    class MyAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            super(MyAnsibleConstructor, self).__init__(file_name, vault_secrets)

        def construct_yaml_map(self, node):
            data = AnsibleMapping()
            yield data
            value = self.construct_mapping(node)
            data.update(value)

        def construct_yaml_seq(self, node):
            data = AnsibleSequence()
            yield data
            data.extend(self.construct_sequence(node))


# Generated at 2022-06-20 23:49:04.157503
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    obj = AnsibleLoader(None).construct_yaml_map({'key1': 'value1', 'key2': 'value2'})
    assert obj == {'key1': 'value1', 'key2': 'value2'}
    assert type(obj['key1']) is str
    assert type(obj['key2']) is str
    assert obj.__class__ == AnsibleMapping
    assert obj.ansible_pos == ('<string>', 1, 0)
    obj = AnsibleLoader(None).construct_yaml_map(yaml.safe_load('key1: value1'))
    assert obj == {'key1': 'value1'}

# Generated at 2022-06-20 23:49:06.217610
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ac = AnsibleConstructor()
    assert ac.construct_yaml_map('') is not None  # required for coverage

# Generated at 2022-06-20 23:49:17.088857
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from yaml.error import MarkedYAMLError
    from yaml.nodes import ScalarNode
    from yaml.parser import ParserError

    data = '''
        - one
        - two
        - 3
    '''

    expected = [
        ScalarNode(u'one', (1, 8)),
        ScalarNode(u'two', (2, 8)),
        ScalarNode(u'3', (3, 8))
    ]

    class TestAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_seq(self, node):
            self.yaml_data.append(node.value)
            return super(TestAnsibleConstructor, self).construct_yaml_seq(node)

    constructor = TestAnsibleConstructor()
    constructor

# Generated at 2022-06-20 23:49:25.160767
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    print('Trying to check the constructor of class AnsibleConstructor')
    import yaml
    yaml_str = """
    groups:
      - hosts:
          - 127.0.0.1
          - testhost
        vars:
          standard_var: 123
          dict_var:
            var_one: one
            var_two: two
          list_var:
            - one
            - two
        children:
          - child_group
    """
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    print(data.keys())

if __name__ == "__main__":
    test_AnsibleConstructor()

# Generated at 2022-06-20 23:50:06.313228
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.compat.tests import unittest
    from ansible.parsing.yaml.objects import AnsibleUnicode

    c = AnsibleConstructor()

    s = "foo"
    node = c.construct_yaml_str(s)
    assert isinstance(node, AnsibleUnicode)
    assert node == "foo"

    s = "foo bar"
    node = c.construct_yaml_str(s)
    assert isinstance(node, AnsibleUnicode)
    assert node == "foo bar"

# Generated at 2022-06-20 23:50:14.757081
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import os
    import tempfile
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.scanner import Scanner
    from yaml.reader import Reader
    from ansible.parsing.vault import VaultLib
    from six.moves import StringIO

    def pos_info(filename, line, col):
        return filename, line + 1, col

    # The following testcase will make sure vaulted string is constructed
    # correctly for the following yaml
    # ---
    # "\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\x02\