

# Generated at 2022-06-20 23:40:33.187997
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.yaml.loader
    ansible.parsing.yaml.loader.AnsibleConstructor = AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    # The presence of !unsafe tag in the input string triggers the call of method construct_yaml_unsafe of class AnsibleConstructor.
    input_string=(
"""
- hosts: localhost
  tasks:
  - name: test_construct_yaml_unsafe
    raw: echo '1+1' > /tmp/ansible_test_output.txt; cat /tmp/ansible_test_output.txt
    register: result
"""
    )
    # Expected output from the call of method construct_yaml_unsafe of class AnsibleConstructor.

# Generated at 2022-06-20 23:40:35.738802
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = AnsibleConstructor()
    node_test = 'test'
    assert node.construct_yaml_seq(node_test) == AnsibleSequence()



# Generated at 2022-06-20 23:40:48.526737
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    c = AnsibleConstructor()
    assert c.construct_yaml_str(node=None) is None

    c = AnsibleConstructor()
    assert c.construct_yaml_str(node=False) is None

    c = AnsibleConstructor()
    assert c.construct_yaml_str(node=True) is None

    c = AnsibleConstructor()
    assert c.construct_yaml_str(node=0) is None

    c = AnsibleConstructor()
    assert c.construct_yaml_str(node=1) is None

    c = AnsibleConstructor()
    assert c.construct_yaml_str(node='foo') == AnsibleUnicode('foo')

    c = AnsibleConstructor()
    assert c.construct_yaml_str(node=list()) is None


# Generated at 2022-06-20 23:40:57.178043
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from six import StringIO

    display.verbosity = 3
    vault_password = 'asdf'

    def ex_vault_password(prompt=None, confirm=False, new_vault_id=None):
        return vault_password

    def file_vault_password(prompt=None, confirm=False, new_vault_id=None):
        return open(vault_password)

    constructor = AnsibleConstructor(vault_secrets=[ex_vault_password])


# Generated at 2022-06-20 23:41:09.910990
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_lib_mock = Mock()
    vault_lib_mock.decrypt.return_value = b'unencrypted_value'
    vault_lib_mock.secrets = None
    ac = AnsibleConstructor(vault_secrets=['a_secret'])
    ac._vaults['default'] = vault_lib_mock
    node = Mock()
    node.start_mark.line = 0
    node.start_mark.column = 0
    node.start_mark.name = 'mock_file_name'
    node.start_mark.buffer = None
    node.start_mark.pointer = None
    node.start_mark.line_offset = 0
    node.start_mark.buffer_offset = 0

# Generated at 2022-06-20 23:41:23.005802
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultSecret

    from io import StringIO

    yaml_data = u"""
a: '1'
b:
  c: 3
  d: 4
"""
    secret = VaultSecret(b'\xfe6U\x0b\x0b\x1d\x81~\x9f\xbd\x8e\x7f\x1d\x1d\xa8\x8a\x13\x9f\xc5')
    vault_password = 'ansible'
    vault_password_bytes = to_bytes(vault_password, errors='surrogate_or_strict')

# Generated at 2022-06-20 23:41:34.489929
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # test for function: construct_vault_encrypted_unicode
    # the following should all be True
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ac = AnsibleConstructor()
    iv, salt, ciphertext = 'test_AnsibleConstructor_construct_vault_encrypted_unicode', 'salt', 'ciphertext'
    vault = '$ANSIBLE_VAULT;1.1;AES256;{0}\n{1}\n{2}\n'.format(iv, salt, ciphertext)
    yamlobj = ac.construct_vault_encrypted_unicode(vault)
    assert isinstance(yamlobj, AnsibleVaultEncryptedUnicode)
    assert yamlobj.vault.secrets == []

# Generated at 2022-06-20 23:41:40.828697
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    parent = AnsibleConstructor()
    this = AnsibleUnsafeText(u'!unsafe foo')
    actual = parent.construct_yaml_unsafe(this)
    expected = wrap_var(u'foo')
    assert actual == expected

# Generated at 2022-06-20 23:41:53.228922
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Test with both a string and unicode objects
    yaml_str = '--- !unsafe "&lt;script&gt;alert(&quot;hi&quot;)&lt;/script&gt;"'
    yaml_unicode = u'--- !unsafe "&lt;script&gt;alert(&quot;hi&quot;)&lt;/script&gt;"'

    # Make sure the method can handle test data as bytes or unicode
    if C.DEFAULT_CONFIG_FILE_CONTENT_TYPE == 'auto':
        for my_data in (yaml_str, yaml_unicode):
            constructor = AnsibleConstructor()
            node = list(constructor.compose_node(None, constructor.construct_yaml_unsafe(my_data)))[0]
            assert node.tag == u

# Generated at 2022-06-20 23:42:01.822465
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    # yaml.add_constructor is only available for SafeConstructor in pyyaml
    # so we need to use a custom class to override the default Python
    # list constructors
    class ExtendedAnsibleConstructor(AnsibleConstructor):
        def __init__(self):
            super(ExtendedAnsibleConstructor, self).__init__()

            for t in ('tag:yaml.org,2002:map', 'tag:yaml.org,2002:python/dict', 'tag:yaml.org,2002:seq', 'tag:yaml.org,2002:python/list'):
                self.add_constructor(t, self.construct_yaml_seq)


# Generated at 2022-06-20 23:42:19.723789
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    import sys
    import os
    import shutil
    import datetime
    import yaml
    from ansible.errors import AnsibleError

    # example of using the class from a test, creates some data.yml file
    # in the current directory and then reads it back in using the Ansible
    # constructor from ansible.parsing.yaml.objects to help catch any
    # regressions of code that might eventually allow for an unsafe object
    # to bleed through the safe_load function.

    # overrides the python 'open' builtin, since we do open(..., 'U')
    # this basically emulates Universal newline support, which was
    # removed in python3
    class MyOpener(object):
        def __init__(self, filename):
            self.filename = filename

        def __enter__(self):
            self

# Generated at 2022-06-20 23:42:27.375124
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_data = {'a': 1, 'b': 2, 'c': 3}
    test_yaml = '{"a": 1, "b": 2, "c": 3}'
    new_map = AnsibleLoader(test_yaml, file_name='test_AnsibleConstructor_construct_yaml_map').get_single_data()
    assert isinstance(new_map, AnsibleMapping)
    assert new_map == test_data

# Generated at 2022-06-20 23:42:30.200319
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    assert AnsibleConstructor().construct_yaml_unsafe(1) == wrap_var(1)

# Generated at 2022-06-20 23:42:42.132504
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    yaml.add_constructor(u'!vault-encrypted', AnsibleConstructor.construct_vault_encrypted_unicode)
    yaml.add_constructor(u'!vault', AnsibleConstructor.construct_vault_encrypted_unicode)
    yaml.add_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)
    yaml.add_constructor(
        u'tag:yaml.org,2002:map',
        AnsibleConstructor.construct_yaml_map)
    yaml.add_constructor(u'tag:yaml.org,2002:python/dict', AnsibleConstructor.construct_yaml_map)

# Generated at 2022-06-20 23:42:49.305968
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    ansible_constructor = AnsibleConstructor(file_name='some_yaml_file.yml', vault_secrets=['secret1', 'secret2'])
    node = None
    assert isinstance(ansible_constructor.construct_vault_encrypted_unicode(node), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-20 23:43:02.056588
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    node = AnsibleUnicode("foo: bar")
    constructor = AnsibleConstructor('test_file_name')
    sequence = constructor.construct_yaml_seq(node)
    # construct_yaml_seq yields a generator, but AnsibleConstructor.construct_yaml_seq always yields only one object
    # So we pull the object from the generator
    obj = None
    for _ in sequence:
        obj = _
    # construct_yaml_seq should yield a AnsibleSequence instance whose value is 'foo: bar'
    assert isinstance(obj, AnsibleSequence)
    assert obj[0] == "foo: bar"

# Generated at 2022-06-20 23:43:12.924894
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    def _construct(obj, params={}):
        yaml = YAML()
        yaml.indent(mapping=2, sequence=4, offset=2)
        yaml.constructor = AnsibleConstructor
        return yaml.load(yaml.dump(obj, default_flow_style=False))

    def _get_object_attributes(obj):
        return [attr for attr in dir(obj) if not attr.startswith('_')]

    def objects_equal(obj1, obj2):

        # Do not use the == operator for 'dict' and 'list' types
        # It does not work as expected with objects
        if (obj1 is obj2):
            return True
        if type(obj1) != type(obj2):
            return False

        # Ignore Ansible module call

# Generated at 2022-06-20 23:43:15.189381
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert (True)
    # TODO

# Generated at 2022-06-20 23:43:29.154192
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor()
    constructor.vault_secrets=['password']

# Generated at 2022-06-20 23:43:38.519201
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultEditor
    from base64 import b64encode

    test_key = '0123456789abcdef'
    test_text = 'test-text'
    vault = VaultLib(password=[test_key])
    ciphertext = vault.encrypt(test_text)
    vault_encoded = vault.encode(ciphertext)
    vault_encoded.strip()


# Generated at 2022-06-20 23:43:53.422942
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    test_data = u"\n".join([
        u'---',
        u'foo: bar',
        u'baz:',
        u'  - 1',
        u'  - 2',
        u'  - 3',
        u'...',
        u''
    ])

    test_data = to_bytes(test_data)
    import yaml
    print(yaml.load(test_data, Loader=AnsibleConstructor))

if __name__ == "__main__":
    test_AnsibleConstructor()

# Generated at 2022-06-20 23:44:02.392281
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = """roles:
  - name: web
    tasks:
      - name: task1
        yum:
          name: ansible
  - name: dbs
    tasks:
      - name: task2
        yum:
          name: ansible
    handlers:
      - name: task2
        yum:
          name: ansible

"""
    loader = AnsibleLoader(yaml_str, file_name='/tmp/playbook.yml')
    data = loader.get_single_data()

# Generated at 2022-06-20 23:44:12.543055
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    a = {
        'list': [
            'list_item_with_no_vars',
            'list_item_with_vars_{{ var1 }}',
            'list_item_with_vars_{{ var2 }}',
            'list_item_with_vars_{{ var3 }}'
        ]
    }

    import io
    import yaml

    with io.StringIO() as f:
        yaml.dump(a, f)

        f.seek(0)
        yaml.load(f, Loader=AnsibleConstructor)


# Generated at 2022-06-20 23:44:22.188410
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_native
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader


    yaml_str = '''
        foo:
          - bar
          - name: baz
            val: test
        other:
          - foo
          - bar
    '''

    # Load the data with AnsibleConstructor
    yaml_data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()

    # Check that the node id is as expected
    assert yaml_data.ansible_pos == ('<string>', 1, 1)

    # Make sure that the yaml_data is

# Generated at 2022-06-20 23:44:33.181949
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # write a vault key to a file
    (fd, vault_key_filename) = tempfile.mkstemp(prefix='ansible_test_vault_key_')
    with os.fdopen(fd, 'w') as f:
        f.write('test_password')

    # write a vault ciphertext to a file
    (fd, vault_ciphertext_filename) = tempfile.mkstemp(prefix='ansible_test_vault_ciphertext_')

# Generated at 2022-06-20 23:44:40.180267
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import Loader
    from yaml.nodes import ScalarNode

    yaml = u"""
        'foobar'
    """
    node = Loader(yaml).get_single_node()
    data = AnsibleConstructor().construct_yaml_str(node)
    assert isinstance(data, AnsibleUnicode)
    assert data == u"foobar"



# Generated at 2022-06-20 23:44:48.739785
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeText
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    c = AnsibleConstructor()
    l = AnsibleLoader(c)
    # Basic case
    a_mapping = l.get_single_data("""
            ---
            a: 1
            b: 2
            c: 3
        """)
    assert type(a_mapping) == AnsibleMapping
    assert len(a_mapping) == 3
    # duplicate key in a mapping

# Generated at 2022-06-20 23:44:58.517310
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml

# Generated at 2022-06-20 23:44:59.830794
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert AnsibleConstructor.construct_yaml_map(None) == AnsibleMapping()

# Generated at 2022-06-20 23:45:07.175048
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = {'a_list': [1, 2, 3], 'a_dict': {'one': 'foo', 'two': 'bar'}, 'a_str': 'hello world'}
    yaml_str = AnsibleDumper().dump(data)
    yaml_str = yaml_str.replace('- 1', '!unsafe 1').replace('- 2', '!unsafe 2').replace('- 3', '!unsafe 3')
    yaml_str = yaml_str.replace("one: foo", "one: !unsafe 'foo'")

# Generated at 2022-06-20 23:45:25.561585
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import unittest
    from yaml import load, dump, safe_load
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self.yaml_str = '''
    - name: Key test
      key: 'key'
    - name: Key test
      key: 'key'
            '''
            self.obj = None
            self.yaml_result = "".join((
                "- name: Key test\n",
                "  key: 'key'\n",
                "- name: Key test\n",
                "  key: 'key'\n"
                ))
            self.yaml_dict

# Generated at 2022-06-20 23:45:28.513592
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Constructor's sequece
    def construct_yaml_seq(obj):
        ansible_seq = AnsibleSequence()
        ansible_seq.extend(obj)
        return ansible_seq

    assert AnsibleConstructor.construct_yaml_seq == construct_yaml_seq

# Generated at 2022-06-20 23:45:39.702830
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from io import StringIO

    class MyAnsibleConstructor(AnsibleConstructor):
        def _node_position_info(self, node):
            return (None, None, None)

    a = MyAnsibleConstructor()
    s = StringIO('{key: value}')
    m = a.construct_yaml_map(a.construct_yaml_stream(s))
    if m['key'] != 'value':
        raise Exception('AnsibleConstructor.construct_mapping() failed')

    d = dict(key='value')
    s = StringIO('{key: value}')
    m = a.construct_yaml_map(a.construct_yaml_stream(s))
    if m['key'] != 'value':
        raise Exception('AnsibleConstructor.construct_mapping() failed')

# Generated at 2022-06-20 23:45:50.892862
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import SafeText

    dummy_vault = VaultLib(['password'])
    # Create a YAML document with vault encrypted data representing a single
    # variable named 'v' with value string 'value'.
    encrypted_var_with_single_vaulted_value = '$ANSIBLE_VAULT;1.1;AES256\nvU6q5u6PXeJzNs0vUCSeLBdz3q+H8fZW\n1514656955484850642967351715174263257209\n'

# Generated at 2022-06-20 23:45:56.293566
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test: Import AnsibleConstructor
    try:
        from ansible.parsing.yaml.loader import AnsibleConstructor
    except ImportError:
        assert False

    # Test: Initialize object of class AnsibleConstructor
    try:
        cls = AnsibleConstructor()
    except:
        assert False

    # Test: Execute function construct_yaml_str of object cls
    try:
        v = cls.construct_yaml_str(node = None)
    except:
        assert False

# Generated at 2022-06-20 23:46:01.678120
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    node = None
    class TestClass:
        pass
    instance = TestClass()
    instance.id = "object"
    instance.construct_object = lambda x: x
    constructor = AnsibleConstructor()
    constructor.construct_object = lambda x: x
    assert constructor.construct_yaml_unsafe(instance) == instance



# Generated at 2022-06-20 23:46:13.121874
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    import sys
    class MockNode:
        def __init__(self, tag, value):
            self.tag = tag
            self.value = value
            class MockMark:
                def __init__(self, name=None, line=None, column=None):
                    self.name = name
                    self.line = line
                    self.column = column
            self.start_mark = MockMark(name=None, line=None, column=None)
            self.end_mark = None
            self.anchor = None
            self.tag = tag
            self.value = value
            self.implicit = False

    class MockLoader:
        class MockLoaderConstructor:
            def __init__(self):
                self.construct_scalar = lambda node: node.value
        loader_constructor = MockLoaderConstructor()
       

# Generated at 2022-06-20 23:46:24.846358
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    #
    # Simple test to confirm that the basic functionality is working
    #
    import yaml
    yaml.add_constructor('!vault', AnsibleConstructor.construct_vault_encrypted_unicode)
    vault_secret = 'ididntdidnt'

# Generated at 2022-06-20 23:46:29.568360
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Variable which will be imported
    constructor = AnsibleConstructor()
    # Hash of AnsibleUnicode
    safe_dict = {u'asc': AnsibleUnicode('aaa'), u'asd': AnsibleUnicode('bbb')}
    # Generating node object to pass it to AnsibleConstructor
    node = yaml.MappingNode(u'tag:yaml.org,2002:python/dict', safe_dict.iteritems(), deep=True)
    # Getting the value of variable which is imported from YAML
    value = constructor.construct_yaml_unsafe(node)
    # Result of value have to be AnsibleUnicode
    assert isinstance(value, AnsibleUnicode)



# Generated at 2022-06-20 23:46:33.588829
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.yaml.loader
    loader = ansible.parsing.yaml.loader.BaseLoader
    construct_yaml_unsafe = loader.construct_unsafe
    assert construct_yaml_unsafe is AnsibleConstructor.construct_yaml_unsafe

# Generated at 2022-06-20 23:46:47.191759
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    d1 = {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3',
          u'key4': {u'key5': u'value5'}, u'key6': u'value6'}
    d2 = {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3',
          u'key4': {u'key5': u'value5'}, u'key6': u'value6'}
    d1[u'key4'][u'key7'] = u'value7'
    d2[u'key4'][u'key7'] = u'value7'
    assert d1 == d2

# Generated at 2022-06-20 23:46:59.939014
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    # Test with no secrets, it should raise ConstructorError
    assert(AnsibleConstructor(file_name=None, vault_secrets=None))
    try:
        _a = AnsibleConstructor(file_name=None, vault_secrets=None)
        _a.construct_vault_encrypted_unicode(MappingNode(tag=u'tag:yaml.org,2002:str', value={}))
        assert(False)
    except ConstructorError as e:
        assert(True)
    except Exception as e:
        assert(False)

    # Test with empty secrets, it should raise ConstructorError

# Generated at 2022-06-20 23:47:08.771507
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    fake_node = object()
    fake_node.ansible_pos = ('test_file.yml', 20, 0)

    # Test with simple string without quotes
    value = 'my test string'
    ac = AnsibleConstructor(file_name='test_file.yml')
    actual_value = ac.construct_yaml_str(fake_node)
    assert actual_value == value
    # Positional info must be set
    assert actual_value.ansible_pos == ('test_file.yml', 20, 0)

    # Test with string in single quotes
    value = 'my test string'
    ac = AnsibleConstructor(file_name='test_file.yml')
    actual_value = ac.construct_yaml_str(fake_node)
    assert actual_value == value
    # Positional info

# Generated at 2022-06-20 23:47:18.044915
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.nodes import ScalarNode
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ansible_constructor = AnsibleConstructor()

    node = ScalarNode('!vault', 'foo', 0, 0, None)
    obj = ansible_constructor.construct_vault_encrypted_unicode(node)

    assert isinstance(obj, AnsibleVaultEncryptedUnicode)
    assert obj.vault == ansible_constructor._vaults['default']



# Generated at 2022-06-20 23:47:22.579496
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode
    node.id = 'map'
    node.value = None
    node.start_mark = None
    node.end_mark = None
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_map(node)) == AnsibleMapping

# Generated at 2022-06-20 23:47:32.151913
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:47:38.424805
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml import YAMLError

    # Test methods which should return an AnsibleUnsafe object
    for test_method in [
        'construct_yaml_unsafe',
        'construct_python_name',
        'construct_python_module',
        'construct_python_object',
        'construct_python_object_apply',
        'construct_python_object_with_bases',
        'construct_python_object_with_bases_apply',
    ]:
        node = YAMLError()
        value = getattr(AnsibleConstructor, test_method)(AnsibleConstructor(file_name=None), node)

# Generated at 2022-06-20 23:47:50.504410
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import io
    import sys

    # construct a stream for the YAML parser to read from
    test_input = """
    one: 1
    two: 2
    three: 3
    four: 4
    five: 5

    six: 6
    seven: 7
    eight: 8
    nine: {ansible_yaml_head: "hello", ansible_yaml_tail: "world"}
    """

    stream = io.StringIO(test_input)

    # capture stderr during the test
    stderr = sys.stderr
    sys.stderr = io.StringIO()


# Generated at 2022-06-20 23:47:57.223739
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    from test.unit.vars.test_vars import get_complex_dictionary
    import yaml
    data = '''
            key1:
                 - test1
                 - test2
            key2:
                 - test1
                 - test2
            '''
    complex_dict = get_complex_dictionary()

    for _ in yaml.load_all(data, Loader=AnsibleConstructor):
        pass

    for _ in yaml.load_all(yaml.dump(complex_dict), Loader=AnsibleConstructor):
        pass

# Generated at 2022-06-20 23:48:09.727138
# Unit test for method construct_yaml_str of class AnsibleConstructor

# Generated at 2022-06-20 23:48:26.465989
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import os

    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_yaml_file = os.path.join(current_dir, 'constructor_test.yml')
    try:
        with open(test_yaml_file) as test_yaml_file_handle:
            test_yaml_file_data = test_yaml_file_handle.read()
    except IOError:
        print("Unable to open file %s" % test_yaml_file)
        quit(1)



# Generated at 2022-06-20 23:48:37.269524
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # yaml represents JSON float as float (not in string)
    test_yaml_float = """
      float:
        - 1.0
        - 2.3
        - !unsafe 3.4
        - 4.5
        - !unsafe "5.6"
    """

    # it will ignore yaml tokens after !unsafe
    test_yaml_bad = """
      bad:
        - !unsafe "{{ foo | bar }}"
        - !unsafe {{ foo | bar }}
        - !unsafe ['foo', 'bar']
        - !unsafe { foo: 'bar' }
        - !unsafe integer
        - !unsafe "integer"
        - !unsafe
        - !unsafe 3.4
        - !unsafe
        - !unsafe
    """

    # !unsafe becomes a

# Generated at 2022-06-20 23:48:48.245375
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.plugins.loader import get_plugin_class

    class Unsafe:
        pass

    class Module(object):
        pass

    class MyModule(get_plugin_class('modules', 'echo')):
        def __init__(self, runner=None):
            self.runner = runner

        def run(self, tmp=None, task_vars=None):
            return tmp

    mymodule = MyModule(runner=Module())
    u = AnsibleUnsafe(to_bytes(mymodule))
    assert u.value == mymodule

# Generated at 2022-06-20 23:48:59.114014
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    import yaml
    from ansible.parsing.vault import VaultLib

    ansible_constructor = AnsibleConstructor()
    vault_secrets = ['secret1', 'secret2']
    vault_password_files = ['.vault_pass1', '.vault_pass2']
    vault_ids = ['1', '2']

    ## Ensure correct construction of AnsibleVaultEncryptedUnicode
    # string node with valid vault ciphertext

# Generated at 2022-06-20 23:49:00.799279
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    c = AnsibleConstructor()
    assert isinstance(c.construct_yaml_str(None), AnsibleUnicode)



# Generated at 2022-06-20 23:49:12.142095
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    try:
        import yaml
    except ImportError:
        print('SKIPPING UNITTEST MODULE FOR yaml. Parser not available')
        return

    import re
    import collections

    # The following patterns are not allowed in object representation
    # of unsafe objects. If the patterns are found, constructor errors
    # are raised.
    pattern_type = re.compile(r'ansible.module_utils.unsafe_proxy.AnsibleUnsafeText\(type\)')
    pattern_class = re.compile(r'ansible.module_utils.unsafe_proxy.AnsibleUnsafeText\(class\)')
    pattern_module = re.compile(r'ansible.module_utils.unsafe_proxy.AnsibleUnsafeText\(module\)')

# Generated at 2022-06-20 23:49:22.586172
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml


# Generated at 2022-06-20 23:49:30.526115
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import ruamel.yaml as yaml
    from collections import OrderedDict
    yaml_str = '''\
foo: {bar: 'baz', baz: 'zab'}
spam: ham
'''
    yaml_obj = yaml.load(yaml_str, Loader=yaml.Loader)
    assert isinstance(yaml_obj, OrderedDict)
    assert len(yaml_obj) == 2
    assert yaml_obj['foo']['bar'] == 'baz'
    assert yaml_obj['foo']['baz'] == 'zab'
    assert yaml_obj['spam'] == 'ham'



# Generated at 2022-06-20 23:49:32.739989
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [ 'my_secret' ]
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    assert constructor
    vault = VaultLib(secrets=vault_secrets)
    ciphertext = vault.encrypt(b'my_secret')
    result = constructor.construct_vault_encrypted_unicode(ciphertext)
    assert result.decrypt() == b'my_secret'

# Generated at 2022-06-20 23:49:42.823138
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.resolver import Resolver
    from yaml.scanner import Scanner

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self):
            AnsibleConstructor.__init__(self)
            self.empty_idx = 0
            self.seq_idx = 0
            self.map_idx = 0

        def construct_yaml_seq(self, node):
            self.seq_idx += 1
            return AnsibleConstructor.construct_yaml_seq(self, node)

        def construct_yaml_map(self, node):
            self.map_idx += 1
            return AnsibleConstructor.construct_yaml_map(self, node)

   

# Generated at 2022-06-20 23:50:02.881230
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ac = AnsibleConstructor()

    # Test that the method constructs an AnsibleMapping
    test_mapping_node = MappingNode(None, [], None, None, None)
    assert isinstance(ac.construct_mapping(test_mapping_node), AnsibleMapping)

    # Test that the method constructs a mapping
    assert isinstance(ac.construct_mapping(test_mapping_node, deep=True), dict)

    # Test that the method raises the exception ConstructorError when a mapping node is not provided
    import yaml
    test_scalar_node = yaml.ScalarNode('tag:yaml.org,2002:str', 'test', None, None, None)
    try:
        ac.construct_mapping(test_scalar_node)
    except ConstructorError:
        pass

# Generated at 2022-06-20 23:50:05.730182
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yamlstring = u"{a: 1, b: 2}"
    AnsibleConstructor(file_name='/path/to/testfile').construct_yaml_map(yamlstring)

# Generated at 2022-06-20 23:50:10.102110
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # test with an empty mapping to check
    # if the ansible_pos attribute is set
    # to the provided position
    pos = (u'<unicode>', 1, 1)

    data = u'{}'

    ret = construct(data, pos)

    assert ret.ansible_pos == pos



# Generated at 2022-06-20 23:50:17.286058
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode

    map_node = u'tag:yaml.org,2002:python/unicode'
    seq_node = u'tag:yaml.org,2002:seq'

    import ruamel.yaml
    yaml = ruamel.yaml.YAML(typ='rt')

    yaml_str = """
a: hello world
b:
  - foo
  - bar
"""

    data = yaml.load(yaml_str)

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['a'], AnsibleUnicode)
    assert isinstance(data['b'], AnsibleSequence)