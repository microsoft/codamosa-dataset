

# Generated at 2022-06-20 23:40:22.428209
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert AnsibleConstructor.construct_yaml_map(AnsibleConstructor(), node=MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None))



# Generated at 2022-06-20 23:40:33.157622
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml


# Generated at 2022-06-20 23:40:45.576969
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile

    from ansible.parsing.yaml.objects import AnsibleUnicode

    # build simple test data
    data = dict(
        a="value of a",
        b=dict(
            c="value of c",
            d=dict(
                e="value of e",
                f="value of f",
            ),
        ),
        g=dict(
            h=dict(
                i="value of i",
                j="value of j",
            ),
        ),
        k="value of k",
    )

    # convert data dict to YAML
    from collections import OrderedDict
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = Ordered

# Generated at 2022-06-20 23:40:57.468236
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    '''
    Test that the construct_yaml_seq method of the AnsibleConstructor class
    creates an AnsibleSequence object.
    '''
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test that the method creates an AnsibleSequence object.
    yaml_data = '''
    - item1
    - item2
    '''
    document = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert type(document) is AnsibleSequence
    assert document.ansible_pos == ('<string>', 1, 0)
    assert document[0] == 'item1'
    assert document[1] == 'item2'

    # Test that the method raises an exception if the input is not a SequenceNode
    # object

# Generated at 2022-06-20 23:41:10.050239
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    yamlstring = '''
    --- {
    "vault_password": "asdf",
    "b_ciphertext_data": "!vault-encrypted $ANSIBLE_VAULT;1.2;AES256;ansible\n333937643561346361636433376634306466336163366138313337626131636532663965653134\n6138653033363934663132063033663565383438336539386538333935636433"
    }
    '''
    _vault_lib = VaultLib(secrets=['asdf'])
    results = _vault_lib.decrypt(yamlstring)
    assert results['b_ciphertext_data'] == 'secure_value'

# Generated at 2022-06-20 23:41:23.281700
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    arg1 = 'arg1'
    arg2 = 1
    arg3 = 2
    yaml_str = """
    key1: {arg1}
    key2: {arg2}
    key3: {arg3}
    """.format(arg1 = arg1, arg2 = arg2, arg3 = arg3)

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping

    dumper = AnsibleDumper()
    dumped = dumper.dump(yaml_str)

    ansible_constructor = AnsibleConstructor()
    data = AnsibleLoader(stream=dumped, constructor=ansible_constructor).get_single_data

# Generated at 2022-06-20 23:41:32.706256
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    twirl = AnsibleBaseYAMLObject()
    twirl.data = ['a', 'b', 'c']
    twirl.ansible_pos = [None]
    expected = AnsibleSequence()
    expected.extend(['a', 'b', 'c'])
    expected.ansible_pos = [None]
    ac = AnsibleConstructor()
    actual = ac.construct_yaml_seq(twirl)
    assert next(actual).ansible_pos == expected.ansible_pos



# Generated at 2022-06-20 23:41:45.357370
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import wrap_var

    loader = AnsibleLoader(None, vault_secrets=[b'ansible_is_cool'])
    key_1 = 'first_key'
    value_1 = 'first_value'
    key_2 = 'second_key'
    value_2 = 'second_value'
    input_string = [key_1, value_1, key_2, value_2]
    yaml_string = loader.dump(input_string)
    data = loader.load(yaml_string)
    assert isinstance(wrap_var(data), AnsibleSequence)



# Generated at 2022-06-20 23:41:53.113482
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # NOTE: Many unsafe objects fail to serialize in yaml
    #   As we are not testing serialization, we will limit testing to objects that
    #   we know we can serialize
    import datetime
    import os
    import time
    import types
    import pytz


# Generated at 2022-06-20 23:42:01.741467
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping_node = MappingNode(u'tag:yaml.org,2002:map', [], start_mark=None, end_mark=None)
    mapping_node.value.append((
        ScalarNode(u'tag:yaml.org,2002:str', u'key', start_mark=None, end_mark=None),
        ScalarNode(u'tag:yaml.org,2002:str', u'value', start_mark=None, end_mark=None)))
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=None)
    mapping = ansible_constructor.construct_mapping(mapping_node)
    assert mapping['key'] == 'value'
    assert mapping.ansible_pos == ('<string>', 1, 0)

# Generated at 2022-06-20 23:42:14.321686
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    # When construct_yaml_unsafe is called on a mapping node
    node = yaml.MappingNode(tag='tag:yaml.org,2002:map', value=[], flow_style=False)
    result = AnsibleConstructor.construct_yaml_unsafe(node)

    # Then the result should be a wrapped AnsibleUnsafeMapping
    assert result == wrap_var(AnsibleUnsafeMapping())


# Generated at 2022-06-20 23:42:14.862245
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass


# Generated at 2022-06-20 23:42:20.985863
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    import yaml
    yaml.warnings({'YAMLLoadWarning': False})

    # ensure that yaml.warnings() worked
    with open(__file__) as f:
        try:
            yaml.load(f, Loader=yaml.Loader)
        except yaml.YAMLLoadWarning:
            raise AssertionError

    # Check that pyyaml is willing to overwrite keys
    m1 = {"a": 1, "a": 2}
    m2 = yaml.load("a: 1\na: 2", Loader=yaml.Loader)
    assert dict(m1) == dict(m2)

    # Check that AnsibleConstructor warns when keys are overwritten
    fname = '/dev/null'

# Generated at 2022-06-20 23:42:34.705202
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    yaml_str = """---
- 1
- hello
- world
- '!unsafe 1+1'
- '!unsafe "hello world"'
-
  - 2
  - 1
  - '!unsafe 2+2'
  - 1
- 3
"""

    yaml_str_dump = """---
- 1
- hello
- world
- '!unsafe 1+1'
- '!unsafe "hello world"'
-
  - 2
  - 1
  - '!unsafe 2+2'
  - 1
- 3
"""

    yaml_str

# Generated at 2022-06-20 23:42:44.915587
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    c = AnsibleConstructor()

    f1 = c.construct_yaml_unsafe({u'tag': u'tag:yaml.org,2002:str', u'value': u'foo'})
    assert isinstance(f1, wrap_var)
    assert f1.value == u'foo'

    f2 = c.construct_yaml_unsafe({u'tag': u'tag:yaml.org,2002:int', u'value': u'123'})
    assert isinstance(f2, wrap_var)
    assert f2.value == 123

# Generated at 2022-06-20 23:42:55.487847
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    y = AnsibleConstructor()
    data_1 = ["a", "b", "c"]
    data_2 = ["a", ["b", "c"], "d"]
    data_3 = [["a", "b"], ["c", "d"]]
    assert data_1 == y.construct_yaml_seq(y.construct_yaml_seq(data_1).next()).next()
    assert data_2 == y.construct_yaml_seq(y.construct_yaml_seq(data_2).next()).next()
    assert data_3 == y.construct_yaml_seq(y.construct_yaml_seq(data_3).next()).next()

# Generated at 2022-06-20 23:43:08.255825
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.representer import Representer
    from yaml.resolver import Resolver

    resolver = Resolver()
    representer = Representer()
    representer.add_representer(AnsibleMapping, representer.represent_dict)
    representer.add_multi_representer(AnsibleUnicode, representer.represent_unicode)
    representer.add_multi_representer(AnsibleVaultEncryptedUnicode, representer.represent_unicode)
    representer.add_representer(AnsibleSequence, representer.represent_list)

    constructor = AnsibleConstructor()

    # Construct mapping with duplicate keys
    source = '''
        - key: value
          key: value
        '''

    load = yaml.load(source, Loader=AnsibleLoader)


# Generated at 2022-06-20 23:43:16.924879
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-20 23:43:31.251856
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class MockNode(object):
        start_mark = None
        end_mark = None
        anchor = None
        tag = None
        value = None
        class MockMark(object):
            def __init__(self, name, line, col):
                self.name = name
                self.line = line
                self.column = col

        def set_start(self, name, line, col):
            self.start_mark = self.MockMark(name, line, col)

        def set_end(self, name, line, col):
            self.end_mark = self.MockMark(name, line, col)

        def set_tag(self, tag):
            self.tag = tag

        def set_value(self, value):
            self.value = value

    node = MockNode()
    node.set_

# Generated at 2022-06-20 23:43:41.035203
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            super(AnsibleConstructor, self).__init__()
            self._ansible_file_name = file_name
            self._vaults = {}
            self.vault_secrets = vault_secrets or []
            self._vaults['default'] = VaultLib(secrets=self.vault_secrets)

    def construct_yaml_map(self, node):
        data = AnsibleMapping()
        yield data
        value = self.construct_mapping(node)
        data.update(value)

# Generated at 2022-06-20 23:43:56.496214
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml

    yaml_str = '''
    a: 1
      b: 2
      c: 3
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert data.ansible_pos == ('<unicode string>', 1, 1)
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3

    # Duplicate dict test - issue #18762

    # ignore behavior
    yaml_str = '''
    a: 1
      b: 2
      b: 3
    '''

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert data.ansible_pos == ('<unicode string>', 1, 1)
    assert data['a'] == 1

# Generated at 2022-06-20 23:44:01.497888
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    testdata = u"""
- 1: a
- 2: b
- 3: c
- 1: d
"""
    result = list(yaml.compose(testdata))
    equal([(1, u'a'), (2, u'b'), (3, u'c'), (1, u'd')], constructor.construct_mapping(result[0]))

# Generated at 2022-06-20 23:44:13.977054
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from yaml.loader import SafeLoader
    from yaml.composer import Composer
    from yaml.scanner import Scanner


# Generated at 2022-06-20 23:44:21.310154
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    testconstructor = AnsibleConstructor()
    testdata = AnsibleMapping()
    testdata['first'] = "1"
    testdata['second'] = "2"
    testdata['third'] = 3
    testdata['fourth'] = "4"
    testdata['fifth'] = "4"
    testdata['sixth'] = "4"
    assert testconstructor.construct_yaml_map(testdata) == \
        "'first': 1\n'second': 2\n'third': 3\n'fourth': 4\n'fifth': 4\n'sixth': 4\n"

# Generated at 2022-06-20 23:44:24.588770
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ret = AnsibleConstructor.construct_yaml_seq({'value': [1, 2, 3]})
    assert isinstance(ret, list)
    assert ret == [1, 2, 3]

# Generated at 2022-06-20 23:44:36.798547
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultEditor
    from io import StringIO
    import codecs
    import sys
    import yaml

    # Test data generated by:
    #
    # $ ansible-vault encrypt_string "Hello world!" --vault-password-file vault_secret
    # $ printf "%s" "$ANSIBLE_VAULT" | od -c
    # 0000000   !   v   a   u   l   t
    #          \0  \0  \0  \0  \0  \0
    #       \n           037            0   0   0   0   0   0   0   0   0   0   0   0  \n
    #       047            0   0   0   0

# Generated at 2022-06-20 23:44:42.627248
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_str = u"""
- 1  # 1st line, comment
- 2
"""
    yaml_str_expected = u"""[1, 2]"""
    yaml_str_res = yaml.dump(yaml.load(yaml_str, Loader=AnsibleConstructor), default_flow_style=False)

    assert yaml_str_res == yaml_str_expected

# Generated at 2022-06-20 23:44:55.735908
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import UnsupportedVaultVersion

    text = """
---
- 1
- 2
- 3
"""
    fake_file = StringIO.StringIO(text)
    loader = AnsibleLoader(fake_file, 'filename.yml')


# Generated at 2022-06-20 23:44:58.883118
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    c = AnsibleConstructor(file_name='/tmp/test.yaml')
    node = MappingNode('tag:yaml.org,2002:map',
                       [1, 2],
                       [1, 2],
                       [],
                       start_mark=None,
                       end_mark=None)

    assert isinstance(c.construct_yaml_map(node), AnsibleMapping)



# Generated at 2022-06-20 23:45:08.423106
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.vault_secrets is None
    data = {u'foo': u'bar'}  # Use OrderedDict() for python2.6

    node = MappingNode(
        u'tag:yaml.org,2002:python/dict', data,
        start_mark=None, end_mark=None, flow_style=True)
    constructed_data = ansible_constructor.construct_yaml_map(node)
    assert isinstance(constructed_data, AnsibleMapping)
    assert isinstance(constructed_data, dict)
    assert constructed_data.keys() == [u'foo']
    assert constructed_data[u'foo'] == u'bar'


# Generated at 2022-06-20 23:45:23.839729
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys

    vault_password = "foo"


# Generated at 2022-06-20 23:45:32.130273
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    # setup
    nodes = '[1,2,3,4]'
    vault_secret_id = 'vault-test'

    # execute
    vault_secrets = {vault_secret_id: 'test'}
    vault = VaultLib(secrets=vault_secrets)
    loader = AnsibleLoader(nodes, vault_secrets=vault_secrets)
    result = loader.get_single_data()

    # verify
    assert result == [1,2,3,4]
    assert isinstance(result, AnsibleSequence)
    assert isinstance(result, list)
    assert result.ansible_pos == ('(memory)', 1, 0)

# Generated at 2022-06-20 23:45:44.161217
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import find_plugin

    # A dict with unsafe values
    test_data = {
        "str_key": to_text("str_value"),
        "list_key": [1, 2, 3],
        "dict_key": { "k1": "v1", "k2": [2, 3, 4] }
    }

    # Test without unsafe proxy wrapper
    test_obj = AnsibleConstructor()
    # Transform the data into a yaml string
    data_transformed = yaml.dump(test_data, Dumper=yaml.SafeDumper, width=1000, allow_unicode=True)
    # Parse the yaml string


# Generated at 2022-06-20 23:45:54.299713
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Test construct mapping function
    """
    class MyNode(object):
        id = None
        start_mark = None
        value = None

        def __init__(self, id, value, start_mark):
            self.id = id
            self.start_mark = start_mark
            self.value = value

        def __repr__(self):
            return self.id

    class MyMark(object):
        name = None
        index = None
        line = None
        column = None

        def __init__(self, name, index, line, column):
            self.name = name
            self.index = index
            self.line = line
            self.column = column

        def __repr__(self):
            return self.name


# Generated at 2022-06-20 23:46:06.070114
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import types

    yaml = YAML(typ='unsafe')

    class ModuleTest(object):
        _test = 'test'

        def test_function(self):
            __tracebackhide__ = True
            pass

    def test_function_2():
        __tracebackhide__ = True
        pass

    module_test = ModuleTest()
    module_test.a = types.MethodType(ModuleTest.test_function, module_test)
    module_test.b = test_function_2
    module_test.c = YAML()
    module_test.d = module_test
    module_test.e = sys.modules['__builtin__']


# Generated at 2022-06-20 23:46:16.453940
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    class MyAnsibleConstructor(AnsibleConstructor):
        pass

    yaml_str = b"""---
- name: test1
  hosts: localhost
  tasks:
  - debug:
      msg: "{{ testjoin1 | join('@') }}"
    vars:
      testjoin1: !unsafe '["test1","test2","test3"]'
"""

    ret = MyAnsibleConstructor.construct_yaml_unsafe(yaml.compose(yaml_str))
    assert ret == ['test1', 'test2', 'test3']



# Generated at 2022-06-20 23:46:18.039018
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert bool(AnsibleConstructor.construct_yaml_str(None).strip())

# Generated at 2022-06-20 23:46:29.360837
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # test empty data
    data = u'''
    {
    }
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert yaml_obj == {}
    # assert data == yaml.dump(yaml_obj, default_flow_style=False)

    # test duplicate keys
    data = u'''
    {
        "key": 1,
        "key": 2
    }
    '''
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert yaml_obj == {"key": 2}
    # assert data == yaml.dump(yaml_obj, default_flow_style=False)

    # test duplicate keys in string data

# Generated at 2022-06-20 23:46:35.035321
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # pylint: disable=missing-docstring,no-self-use
    node = MappingNode()
    value_data = {'key': 'value'}
    ret = AnsibleConstructor._AnsibleConstructor__construct_yaml_map(node)
    ret.send(None)
    ret.send(value_data)
    return ret.send(None)


# Generated at 2022-06-20 23:46:44.892320
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    # Verify that unsafe isn't wrapped when wrap_var is False
    with C.WRAP_VARS:
        assert isinstance(C.WRAP_VARS.wrap_var, AnsibleUnicode)

    with C.WRAP_VARS:
        C.WRAP_VARS.wrap_var = False
        assert not isinstance(C.WRAP_VARS.wrap_var, AnsibleUnicode)

    # Verify class AnsibleConstructor
    def _test_AnsibleConstructor_construct_yaml_unsafe(o, expect_wrapped):
        assert isinstance(o, AnsibleUnicode) == expect_wrapped

    c = AnsibleConstructor()
    c.construct_yaml_unsafe(None)
    # (yaml_data, expect_wrapped)

# Generated at 2022-06-20 23:47:00.941520
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from yaml.nodes import MappingNode


# Generated at 2022-06-20 23:47:10.458619
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import ansible.parsing.dataloader as dl
    from ansible.parsing.yaml.dumper import AnsibleDumper

    loader = dl.DataLoader()

    # create a round trip from a data structure to ansible yaml
    # and back to a data structure and ensure it matches

    # ensure that in-memory data structures stay the same
    # when simply yaml dumped and yaml loaded

# Generated at 2022-06-20 23:47:14.434087
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    constructor = AnsibleConstructor()
    test_map_node = MappingNode('tag:yaml.org,2002:map', [])
    map_node_test(test_map_node, constructor)



# Generated at 2022-06-20 23:47:17.727053
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    data = '!unsafe {}'
    result = yaml.load(data, Loader=AnsibleConstructor)
    assert result == wrap_var({})

# Generated at 2022-06-20 23:47:28.284292
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Testing only for Python 3.x - 'construct_yaml_str' is supposed to return a Unicode object (and should fail on Python 2)
    if hasattr(to_bytes(""), 'decode'):
        # str class is used to represent Unicode string
        # In Python 3, str is the same as unicode
        ansible_constructor = AnsibleConstructor()
        ansible_constructor.construct_yaml_str("simple string")
        ansible_constructor.construct_yaml_str(u"simple unicode string")
        ansible_constructor.construct_yaml_str(u"\u2192 unicode string")
        ansible_constructor.construct_yaml_str(u"\U0001F60D unicode string")

# Generated at 2022-06-20 23:47:36.104729
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    text = 'foo'
    vault = VaultLib(secrets=['bar'])
    data = AnsibleVaultEncryptedUnicode(to_bytes(text), vault=vault)
    encrypted_str = data.vault.encrypt(text)
    # also make sure that we are using the correct encoding
    assert encrypted_str == vault.encrypt(text).encode('ascii', 'surrogateescape')

    # make sure that we're not decoding when encrypting - for example, if we
    # are encrypting the ansibe_become_* vars, we don't want to decode the
    # passwords if they are already unicode

# Generated at 2022-06-20 23:47:48.603042
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import os
    import sys
    import tempfile
    import io

    # Create test data.
    test_dict = {'a': 1,
                 'b': 'two',
                 'c': [1, 2, 3],
                 'd': {'three': 3}}
    expected_result = b"""---
a: 1
b: two
c:
- 1
- 2
- 3
d:
  three: 3
"""

    # Get indent level
    indent = AnsibleDumper.default_style['indent']

    # Write to file
    (fd, filename) = tempfile.mkstemp()
    os.close(fd)
    with open(filename, 'wb') as f:
        f.write(expected_result)

# Generated at 2022-06-20 23:47:54.973739
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.reader import AnsibleIterator
    from ansible.parsing.yaml.scanner import AnsibleScanner

    scanner = AnsibleScanner()

    test_yaml = u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35343165393734303335373661333534386631326164306533356434353661646333616231373730\n          373034396466313161656632626161320a336534373965363536313865633035616635373138353338\n          3739663262363561376133393237616139386438376532343561656335306339320a'


# Generated at 2022-06-20 23:47:56.494350
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # FIXME: this unit test needs to be converted to pytest
    print("FIXME: this unit test needs to be converted to pytest")


# Generated at 2022-06-20 23:48:09.199775
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    c = AnsibleConstructor(file_name='test_AnsibleConstructor_construct_yaml_unsafe')
    val = u'xx'
    node = c.construct_scalar(node=val)
    ret = c.construct_yaml_unsafe(node=node)
    assert ret == AnsibleUnsafeText(to_bytes(val))

    val = u'!unsafe xx'
    node = c.construct_scalar(node=val)
    ret = c.construct_yaml_unsafe(node=node)
    assert ret == AnsibleUnsafeText(to_bytes(val))

    val = u'!unsafe xx'
    node = c.construct_scalar(node=val)
    node

# Generated at 2022-06-20 23:48:22.278141
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    yaml_str = '''---
a:
  - 1
  - 2
  - 3
'''
    am = AnsibleMapping(a=[1, 2, 3])
    data = AnsibleConstructor(None, None).construct_yaml(yaml_str)
    assert data == am

# Generated at 2022-06-20 23:48:34.175613
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    print("TESTING construct_vault_encrypted_unicode")

    print("TESTING DEFAULT HANDLING: NO VAULT PASSWORD PROVIDED")
    con = AnsibleConstructor()
    try:
        result = con.construct_vault_encrypted_unicode("ciphertext goes here")
        print("ERROR: Vault password error not thrown")
        exit()
    except ConstructorError:
        print("CORRECT: Vault password error thrown")

    print("TESTING CORRECT HANDLING: SINGLE VAULT PASSWORD PROVIDED")
    con = AnsibleConstructor(vault_secrets=[b"mypassword"])
    result = con.construct_vault_encrypted_unicode("ciphertext goes here")

# Generated at 2022-06-20 23:48:41.556536
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleConstructor, self).__init__()
            self.args = args
            self.kwargs = kwargs

        def construct_yaml_seq(self, node):
            self.construct_yaml_seq_called = True
            return super(TestAnsibleConstructor, self).construct_yaml_seq(node)

    test_data = b'[ "test", "value" ]'

    loader = AnsibleLoader(TestAnsibleConstructor, vault_secrets=VaultLib().secrets)
    loader.set_

# Generated at 2022-06-20 23:48:53.800172
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode
    from yaml.constructor import ConstructorError
    from yaml.error import YAMLError
    from ansible.parsing.yaml import DataLoader

    yaml_str = """
a:
  b: 1
  b: 2
  b: 3
"""

    try:
        AnsibleConstructor(file_name='foobar').construct_yaml_map(DataLoader().get_single_data(yaml_str))
    except ConstructorError as e:
        assert e.problem == 'while constructing a mapping', 'invalid exception message: {0}'.format(e.problem)
        assert e.context == 'found duplicate dict key (b)', 'invalid exception context: {0}'.format(e.context)

# Generated at 2022-06-20 23:49:02.671853
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    from collections import namedtuple
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    from textwrap import dedent

    class Prefix(str):
        pass

    data = dict(a = 1,
                b = dict(c = 3, d = 4),
                e = 'e',
                f = namedtuple('x', ['g', 'h'])(g = 5, h = 6))
    loader = AnsibleLoader(None, data, None)
    value = loader.get_single_data()

    Result = namedtuple('Result', ['yaml', 'value', 'prefix'])

# Generated at 2022-06-20 23:49:06.118287
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    data = ansible_constructor.construct_yaml_map("")
    assert isinstance(data, AnsibleMapping)


# Generated at 2022-06-20 23:49:17.088784
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    import unittest
    import yaml

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib

    class TestAnsibleConstructor_construct_mapping(unittest.TestCase):
        def setUp(self):
            self.vault_password = VaultLib(secrets=['secret1', 'secret2'])
            self.constructor = AnsibleConstructor(vault_secrets=self.vault_password)
            self.data = '''
            key1: value1
            key2: value2
            testkey:
                - item1
                - item2
            '''
            self.yaml_doc = yaml.load(self.data, Loader=yaml.Loader)


# Generated at 2022-06-20 23:49:26.259958
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-20 23:49:39.274310
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import io
    from ansible.parsing.yaml.loader import AnsibleLoader

    # On Python 2, stdin, stdout and stderr are str by default, but
    # AnsibleLoader would expect them to be bytes.
    if sys.version_info[0] < 3:
        sys.stdin = io.BytesIO()
        sys.stdout = io.BytesIO()
        sys.stderr = io.BytesIO()

    # construct_scalar returns bytes on Python 2, unicode on Python 3.
    # But on Python 2, the type of the builtin str() is the same as
    # the type of bytes, so there is no need to test that the type of
    # the returned instance is str.
    c = AnsibleConstructor()

    # Test with a str instance
    value

# Generated at 2022-06-20 23:49:45.882257
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    str_constructor = AnsibleConstructor.construct_yaml_str
    assert type(str_constructor(None)) == AnsibleUnicode
    assert str_constructor(None).__str__() == ''
    assert type(str_constructor('')) == AnsibleUnicode
    assert str_constructor('').__str__() == ''
    assert type(str_constructor('a')) == AnsibleUnicode
    assert str_constructor('a').__str__() == 'a'


# Generated at 2022-06-20 23:49:58.748285
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Unit test for method construct_yaml_map of class AnsibleConstructor
    """

    filename = "myfile"
    vault_pwd = ['mock_yaml']
    constructor = AnsibleConstructor(file_name=filename, vault_secrets=vault_pwd)

    assert constructor.construct_yaml_map


# Generated at 2022-06-20 23:50:09.728155
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml import objects

    ansible_const = AnsibleConstructor()
    yaml_str = 'foobar'
    expected_ansible_unicode_obj = objects.AnsibleUnicode(yaml_str)
    ansible_unicode_obj = ansible_const.construct_yaml_str(yaml_str)
    assert ansible_unicode_obj == expected_ansible_unicode_obj
    assert isinstance(ansible_unicode_obj, objects.AnsibleUnicode)

    # Assert that the default behavior of the parent class
    # returns a string rather than an AnsibleUnicode
    yaml_cons = SafeConstructor()
    expected_yaml_str = 'foobar'
    yaml_str = yaml_cons.construct_yaml

# Generated at 2022-06-20 23:50:19.823833
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml = '''
- name: duplicate_yaml_dict_key=ignore
  hosts: localhost
  vars:
    a: 1
  tasks:
  - name: show values
    debug: msg="a={{ a }}"

- name: duplicate_yaml_dict_key=warn
  hosts: localhost
  vars:
    a: 1
    a: 2
  tasks:
  - name: show values
    debug: msg="a={{ a }}"

- name: duplicate_yaml_dict_key=error
  hosts: localhost
  vars:
    a: 1
    a: 2
  tasks:
  - name: show values
    debug: msg="a={{ a }}"
'''
    import sys
    import tempfile
