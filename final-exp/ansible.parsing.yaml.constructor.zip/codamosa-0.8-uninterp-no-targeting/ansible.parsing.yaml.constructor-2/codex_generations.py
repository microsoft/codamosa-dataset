

# Generated at 2022-06-20 23:40:26.449736
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = b'''
    key1: value1
    key2: value2
    '''

    data_node = yaml.compose(data)

    value_node = data_node.value[0]

    ansible_constructor = AnsibleConstructor()

    ansible_map = ansible_constructor.construct_yaml_map(value_node)

    dict_map = dict(ansible_map)

    assert(isinstance(dict_map, dict))
    assert(dict_map['key1'] == 'value1')
    assert(dict_map['key2'] == 'value2')


# Generated at 2022-06-20 23:40:34.732543
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    output = StringIO()
    x = ('key1', 'key2', 'key3')
    y = [{x[0]: x[1]}, {x[1]: x[2]}, {x[2]: x[0]}]
    dumper = AnsibleDumper(output, default_flow_style=False)
    dumper.open()
    dumper.represent(y)
    dumper.close()
    yaml_string = output.getvalue()
    yaml_obj = yaml.load(yaml_string, Loader=AnsibleConstructor)

# Generated at 2022-06-20 23:40:42.620459
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    constructor = AnsibleConstructor()
    node = yaml.nodes.SequenceNode(u'tag:yaml.org,2002:seq', [], None, None)
    assert constructor.construct_yaml_seq(node).ansible_pos == None

    node = yaml.nodes.SequenceNode(u'tag:yaml.org,2002:seq', [], None, node.start_mark)
    assert constructor.construct_yaml_seq(node).ansible_pos == ('<string>', 1, 0)

    node = yaml.nodes.SequenceNode(u'tag:yaml.org,2002:seq', [], None, node.start_mark)
    assert constructor.construct_yaml_seq(node).ansible_pos == ('<string>', 1, 0)


# Generated at 2022-06-20 23:40:43.999123
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # TODO: implement unit test for class AnsibleConstructor
    pass

# Generated at 2022-06-20 23:40:51.431320
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    x = AnsibleConstructor()
    yaml = '''
dict1:
  key1: value1
  key2: value2
dict2:
  key1: value1
  key1: value2
'''
    value = yaml.load(yaml, Loader=AnsibleConstructor)
    assert value['dict1']['key1'] == 'value1'
    assert value['dict1']['key2'] == 'value2'
    assert value['dict2']['key1'] == 'value1'
    assert value['dict2']['key1'] == 'value2'

# Generated at 2022-06-20 23:41:01.360629
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secret = [u'secret']
    ac = AnsibleConstructor(vault_secrets=vault_secret)
    initial_value = u'U2FsdGVkX1+GQF1ULJY9ZhgSiKj+x0xJmHwcOyb0+3qNzRa5k5N5XJ0Z/f+5RtNS/' \
                    u'JGkcHuRTJxzL+A8EKpGpZlCf1ttzJlg2+PdY9nLJtGslLrsMwfj1y+e1Jn5b5F5P'
    value_node = ac.construct_yaml_str(initial_value)
    ret_value = ac.construct_vault_encrypted_unic

# Generated at 2022-06-20 23:41:12.568837
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.reader import AnsibleReader
    from io import StringIO

    yaml_data = StringIO(
        '''---
        a: 1
        b: 2
        '''
    )

    yaml_data_reader = StringIO(
        '''---
        a: 1
        b: 2
        '''
    )

    data = AnsibleReader(yaml_data).get_single_data()
    yaml_data_reader.seek(0)
    data_reader = AnsibleConstructor(AnsibleReader(yaml_data_reader)).construct_yaml_map(data)
    _data = next

# Generated at 2022-06-20 23:41:17.491683
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    ac = AnsibleConstructor()
    assert ac.construct_yaml_map(node) is not None


# Generated at 2022-06-20 23:41:30.466122
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml


# Generated at 2022-06-20 23:41:37.291144
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Make sure it creates an AnsibleUnsafeText
    data = 'Hello, World!'
    constructor = AnsibleConstructor()
    node = constructor.construct_yaml_unsafe(data)
    assert isinstance(node, AnsibleUnsafeText)
    assert node == 'Hello, World!'

    # Make sure it wraps data
    data = AnsibleUnsafeText('Hello, World!')
    constructor = AnsibleConstructor()
    node = constructor.construct_yaml_unsafe(data)
    assert isinstance(node, AnsibleUnsafeText)
    assert node == 'Hello, World!'

    # Make sure it loads from unsafe text
    data = 'Hello, World!'
   

# Generated at 2022-06-20 23:41:47.814328
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foo')
    ac = AnsibleConstructor()
    result = ac.construct_yaml_str(node)
    assert result.ansible_pos == (None, 1, 1)

# Generated at 2022-06-20 23:41:59.417218
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-20 23:42:02.975894
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = u'foo'
    assert AnsibleConstructor.construct_yaml_str(node) == 'foo'



# Generated at 2022-06-20 23:42:04.956250
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    Constructor = AnsibleConstructor()
    assert Constructor.construct_yaml_seq() == AnsibleConstructor.construct_yaml_seq()

# Generated at 2022-06-20 23:42:18.206502
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.yaml.objects

    class FakeNode(object):
        pass

    fake_node = FakeNode()
    fake_node.id = "my_test_constructor"

    data = dict()
    data['construct_my_test_constructor'] = True

    class FakeContext(object):
        pass

    fake_context = FakeContext()
    fake_context.data = data

    class FakeConstructor(AnsibleConstructor):
        def __init__(self):
            pass

    fake_constructor = FakeConstructor()
    assert not hasattr(fake_constructor, 'construct_my_test_constructor')

    # If the method is not available, the initial value of the node is returned
    assert fake_node == fake_constructor.construct_yaml_unsafe(fake_node)

# Generated at 2022-06-20 23:42:21.163819
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    # Test construction of AnsibleConstructor
    c = AnsibleConstructor()
    assert isinstance(c, AnsibleConstructor)
    assert isinstance(c, SafeConstructor)

# Generated at 2022-06-20 23:42:24.251763
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml_unicode_node = SafeConstructor.construct_yaml_str(AnsibleConstructor(None, None), '!unsafe test')
    assert type(yaml_unicode_node).__name__ == 'wrap_var'


# Generated at 2022-06-20 23:42:35.957616
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class MockNode:
        def __init__(self, lines):
            self._lines = lines

        def start_mark(self):
            return MockMark(1)

        def __next__(self):
            if self._lines:
                l = self._lines[0]
                self._lines = self._lines[1:]
                return l
            else:
                raise StopIteration

    class MockMark:
        def __init__(self, line):
            self.name = 'mock_filename'
            self.line = line
            self.column = 1

    # Test simple seq
    node = MockNode([1, 2, 3])
    constructor = AnsibleConstructor()
    seq = constructor.construct_yaml_seq(node)
    assert next(seq) == [1, 2, 3]

    # Test seq of

# Generated at 2022-06-20 23:42:49.173572
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-20 23:42:50.572451
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    AnsibleConstructor().construct_yaml_seq(None)

# Generated at 2022-06-20 23:43:10.859722
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Arrange
    test_constructor = AnsibleConstructor()
    test_scalar_node = object()
    test_scalar_node.start_mark = object()
    test_scalar_node.start_mark.line = 1
    test_scalar_node.start_mark.column = 2
    test_scalar_node.start_mark.name = 'test.yml'

    # Act
    result = test_constructor.construct_yaml_str(test_scalar_node)

    # Assert
    assert result.ansible_pos == ('test.yml', 2, 3)

# Generated at 2022-06-20 23:43:18.457409
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.resolver import Resolver

    class FakeAnsibleConstructor(AnsibleConstructor):
        def __init__(self, **kwargs):
            pass

        def construct_yaml_seq(self, node):
            super(FakeAnsibleConstructor, self).construct_yaml_seq(node)
            self.construct_yaml_seq_node = node

        def construct_sequence(self, node):
            self.construct_sequence_node = node

    string = u"[1, 2.0, foo, [3.0, 4]]"
    reader = Reader(string)
    reader.filename = u'<string>'


# Generated at 2022-06-20 23:43:32.580659
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml

# Generated at 2022-06-20 23:43:41.163846
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    from ansible.module_utils._text import to_text
    secrets = ['mysecret']
    constructor = AnsibleConstructor(vault_secrets=secrets)
    vault = VaultLib(secrets=secrets)
    ciphertext = vault.encrypt(to_bytes(u'my-string'))
    b64_ciphertext = to_text(base64.b64encode(ciphertext))
    node = None
    result = constructor.construct_vault_encrypted_unicode(node=node, data=b64_ciphertext)
    assert result == u'my-string'

# Generated at 2022-06-20 23:43:54.197933
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # test case for a single byte of plaintext
    plaintext = u"\u0001"
    sc = AnsibleConstructor(file_name=None, vault_secrets=[u"bar"])
    sc._vaults['default'].secrets = [u"bar"]
    sc._vaults['default'].set_format(u'AES256')
    sc._vaults['default'].set_salt(u'DyCAjwzPHdJk2QOzZmOk')
    sc._vaults['default'].set_iv(u'crkN29fNhjtYG0tbq3a/dQ==')

# Generated at 2022-06-20 23:44:02.909589
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from mock import patch
    from tempfile import NamedTemporaryFile

    text = '''---

- hosts: localhost
  gather_facts: no
  tasks:
    - user:
        name: test1
    - user:
        name: test2

'''
    with open(NamedTemporaryFile().name, 'w') as fh:
        fh.write(text)
    a = AnsibleConstructor()
    with patch.object(a, '_ansible_file_name', return_value=fh.name) as m:
        data = yaml.load(text, Loader=AnsibleConstructor)
        # Check the first line of the result
        first_line = data[0]['tasks'][0]
        print(first_line)
        assert first_

# Generated at 2022-06-20 23:44:15.430266
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import os
    import warnings
    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Disable warnings from AnsibleConstructor.flatten_mapping,
    # which is called in ctor.construct_mapping
    warn_filters = warnings.filters[:]
    warnings.filterwarnings("ignore", category=DeprecationWarning,
                            module='ansible.parsing.yaml.constructor')

    class Foo:
        pass

    ctor = AnsibleConstructor()
    retval = ctor.construct_yaml_str(Foo)
    if not isinstance(retval, AnsibleUnicode):
        raise AssertionError

# Generated at 2022-06-20 23:44:23.840479
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml

    class MyConstructor(AnsibleConstructor):
        pass

    display.verbosity = 1
    cc = MyConstructor()
    data = '''
a_mapping:
  key: value
'''

    data2 = '''
a_mapping:
  key1: value
  key2: value
'''

    data3 = '''
a_mapping:
  key: value
  key: value
'''


# Generated at 2022-06-20 23:44:35.999138
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import time
    import datetime

# Generated at 2022-06-20 23:44:46.084274
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Assign
    node = {}
    setattr(node, 'id', 'vault')

# Generated at 2022-06-20 23:45:07.377667
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Test a basic AnsibleConstructor.construct_yaml_seq call
    """
    import yaml
    import sys

    # file_name passed to constructor to be used in ansible_pos
    # attribute of AnsibleUnicode and AnsibleMapping objects
    c = AnsibleConstructor(file_name='test_AnsibleConstructor')

    # ASCII test
    input = "- first\n  - second"
    list_of_unicode = yaml.load(input, Loader=AnsibleLoader)
    assert type(list_of_unicode) is list
    for item in list_of_unicode:
        assert type(item) is AnsibleUnicode

    # Unicode test
    input = u"- \u6d77\n  - \u6d0b"

# Generated at 2022-06-20 23:45:13.982440
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    const = AnsibleConstructor()

    class MockNode:
        class MockMark:
            line = 1
            column = 2

        start_mark = MockMark()

    node = MockNode()
    node.id = None
    ret = const.construct_yaml_str(node)
    assert isinstance(ret, AnsibleUnicode)
    assert ret.ansible_pos == ('<unicode string>', 2, 3)



# Generated at 2022-06-20 23:45:14.804102
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-20 23:45:21.340494
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    data = '''
    foo:
      - 1
      - 2
      - 3
    '''
    construct = AnsibleConstructor()
    mapping = yaml.compose(data, Loader=yaml.BaseLoader)
    mapping.set_flow_style(True)
    yaml.load(yaml.serialize(mapping), Loader=AnsibleConstructor)

# Generated at 2022-06-20 23:45:30.597079
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.utils import ansible_safe_dump
    doc = """
    k1: v1
    k2: v2
    k3: v3
    """
    data = AnsibleLoader(doc).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data.keys()) == 3
    assert data['k1'] == 'v1'
    assert data['k2'] == 'v2'
    assert data['k3'] == 'v3'

    # In Python 3, we need to set the default_

# Generated at 2022-06-20 23:45:36.741680
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = MappingNode(tag='tag:yaml.org,2002:str', value='my_value', start_mark=None, end_mark=None, flow_style=None)
    ansible_str = AnsibleConstructor().construct_yaml_str(node)
    assert ansible_str == 'my_value', "AnsibleConstructor.construct_yaml_str does not return expected result"

# Generated at 2022-06-20 23:45:45.119279
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    from yaml.error import MarkedYAMLError
    from ansible.parsing.yaml.loader import AnsibleLoader
    import ansible.constants as C

    data = u'test-data'
    yaml = u'{0}'.format(data)
    loader = AnsibleLoader(StringIO(yaml), file_name='<test_file>')
    ret = loader.get_single_data()
    assert isinstance(ret, AnsibleUnicode)
    assert ret == data


# Generated at 2022-06-20 23:45:46.589674
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert AnsibleConstructor.construct_yaml_str('foo') == u'foo'

# Generated at 2022-06-20 23:45:51.808502
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    class Loader(object):
        def save(self):
            pass

    l = Loader()
    c = AnsibleConstructor(l)

    # Verify that AnsibleUnsafeText is returned
    assert isinstance(c.construct_yaml_unsafe(None), AnsibleUnsafeText)

# Generated at 2022-06-20 23:45:58.681482
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    import sys

    # Ensure we have sane version of PyYAML
    if sys.version_info < (2, 7, 0):
        # Python 2.6.x and earlier supported PyYAML 3.10
        # and PyYAML 3.10 did not have YAML constructors
        pyyaml_version = yaml.__version__
        if pyyaml_version != '3.10':
            raise AssertionError('Expected PyYAML version 3.10, found %s' % pyyaml_version)
        return

    import yaml

    # Test for duplicate dict keys
    test_text = """
        - hosts: all
          vars:
            foo: bar
            foo: notbar
    """

    # Test for handling of duplicate dict keys

# Generated at 2022-06-20 23:46:24.824654
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    file_name = None
    vault_secrets = None
    ansible_constructor = AnsibleConstructor(file_name, vault_secrets)
    assert ansible_constructor != None

# Generated at 2022-06-20 23:46:31.968854
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_sequence = AnsibleConstructor.construct_yaml_seq('hoge')

    f = open('test1.yaml', 'w')
    f.write('- 1\n')
    f.write('- 2\n')
    f.write('- 3\n')
    f.write('- 4\n')
    f.close()

    f = open('test1.yaml', 'r')
    data = yaml.load(f)
    f.close()

    assert test_sequence == data


# Generated at 2022-06-20 23:46:42.720103
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = """
- "&asterisk;": some plain old string
- foo: bar
- "{{ item.name }}"
- ""
- "&asterisk;": baz
- foo: !!str baz
"""
    yaml_data = yaml.load(data, Loader=AnsibleLoader)
    assert yaml_data[0] == '*'
    assert isinstance(yaml_data[0], AnsibleUnicode)
    assert yaml_data[1] == {'foo': 'bar'}
    assert yaml_data[2] == ''

# Generated at 2022-06-20 23:46:55.186793
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class FakeConstructor(AnsibleConstructor):
        def flatten_mapping(self, node):
            if not isinstance(node, MappingNode):
                return None
            self.node = node
            self.node.start_mark = 'start'

    node_value_list = [('key1', 'value1'), ('key2', 'value2')]
    node_value_list2 = [('key2', 'value2'), ('key1', 'value1'), ('key1', 'value3')]
    node = MappingNode('tag:yaml.org,2002:map', node_value_list, start_mark='start')
    node2 = MappingNode('tag:yaml.org,2002:map', node_value_list2, start_mark='start')
    test_constructor = FakeConstructor()


# Generated at 2022-06-20 23:46:59.716517
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = """
- a
- b
- c
"""

    import yaml

    ac_obj = AnsibleConstructor()
    result = yaml.load(data, Loader=yaml.SafeLoader)
    assert result == ['a', 'b', 'c']

# Generated at 2022-06-20 23:47:09.099097
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = """
        - this_is_a_string: !unsafe "string"
        - this_is_not_a_string: !unsafe "{{ lookup('password', '/etc/passwd') }}"
    """
    data = AnsibleLoader(data).get_single_data()
    assert isinstance(data, list)
    assert isinstance(data[0]['this_is_a_string'], AnsibleUnicode)
    assert not isinstance(data[1]['this_is_not_a_string'], AnsibleUnicode)


# Generated at 2022-06-20 23:47:13.458980
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_yaml_map({}) == {}
    assert ansible_constructor.construct_yaml_str({}) == {}
    assert ansible_constructor.construct_yaml_seq({}) == {}

# Generated at 2022-06-20 23:47:23.383989
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_text = """
a: 1
b: 2
c: 3
"""
    try:
        import yaml
    except ImportError:
        print("************************************************************")
        print("You need to install PyYAML in order to run unit tests")
        print("************************************************************")
        sys.exit(1)

    data = yaml.load(yaml_text, Loader=AnsibleConstructor)

    assert data is not None
    assert 'a' in data
    assert data['a'] == 1
    assert 'b' in data
    assert data['b'] == 2
    assert 'c' in data
    assert data['c'] == 3



# Generated at 2022-06-20 23:47:24.850575
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert AnsibleConstructor



# Generated at 2022-06-20 23:47:33.824401
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data="""
        {
            "name": "test",
            "value": "test",
            "value": "test2",
            "foo": {
                "bar": "baz"
            }
        }
    """

    import yaml
    yaml_object = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert yaml_object['value'] == 'test2'
    assert yaml_object['foo']['bar'] == 'baz'
    assert isinstance(yaml_object, AnsibleMapping)
    assert isinstance(yaml_object['foo'], AnsibleMapping)
    assert yaml_object['value'].ansible_pos == ('<unicode string>', 4, 18)


# Generated at 2022-06-20 23:48:25.806776
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    c = AnsibleConstructor()
    m = c.construct_yaml_map(c.construct_yaml_str('class_name'))
    assert isinstance(m, AnsibleMapping)
    assert isinstance(c.construct_yaml_str('string'), AnsibleUnicode)

# Generated at 2022-06-20 23:48:36.078549
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # given
    an_unsafe_node = {
        "id":"unsafe",
        "value":"foo",
        "style":None,
        "start_mark": {
            "index":0,
            "line":1,
            "column":0
        },
        "end_mark": {
            "index":4,
            "line":1,
            "column":4
        }
    }

    # when
    ac = AnsibleConstructor()
    unsafe_var = ac.construct_yaml_unsafe(an_unsafe_node)

    # then
    assert unsafe_var.__class__.__name__ == "UnsafeProxy"
    assert unsafe_var.value == "foo"



# Generated at 2022-06-20 23:48:48.561319
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    """
    Test that the ansible constructor is assigning the correct file name,
    line and column number information to all data structures.
    """
    # Create some input data. We use a sequence as it will test the line
    # number tracking in a deeply nested, complex data structure.
    # Note we always use the unicode string type, as the constructor will
    # coerce this to the correct type.
    input_data = u"""\
- key1:
    name: 'Thomas'
    age: 30
  key2:
    name: 'Alice'
    age: 21
- key1:
    name: 'John'
    age: 40
  key2:
    name: 'Lucy'
    age: 45
"""

    import io
    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-20 23:48:51.076968
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = get_node()

    c = AnsibleConstructor()
    result = c.construct_yaml_str(node)

    assert isinstance(result, AnsibleUnicode)


# Factory function for a yaml.nodes.Node object

# Generated at 2022-06-20 23:48:53.879270
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = "---\nint: 1\nfloat: 1.0\n"
    results = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert results == {'int': 1, 'float': 1.0}



# Generated at 2022-06-20 23:49:02.700576
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import unittest
    from ansible.module_utils.six.moves import StringIO

    test_construct_mapping_data = {
        'input': """
            a: 1
            b: 2
            c: 3
            d: 4
            e: 5
            c: 6
        """.lstrip(),
        'output': {'a': 1, 'b': 2, 'c': 6, 'd': 4, 'e': 5},
        'message': 'test_AnsibleConstructor_construct_mapping',
        'e': 5,
        'mode': 'error',
    }
    class test_AnsibleConstructor_construct_mapping(unittest.TestCase):
        def setUp(self):
            self.constructor = AnsibleConstructor()
            self.constructor.construct_mapping

# Generated at 2022-06-20 23:49:05.765817
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    c = AnsibleConstructor()
    info = (__file__, 5, 6)
    assert c._node_position_info(None) == info



# Generated at 2022-06-20 23:49:11.917608
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = """
        name: abc
        msg: xyz
        name: pqr
        name: mno
    """
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert yaml_obj == dict(name='mno', msg='xyz')

    assert yaml_obj.ansible_pos == ('<string>', 1, 0)

# Generated at 2022-06-20 23:49:22.386455
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import os
    import sys

    dirname = os.path.dirname(os.path.abspath(__file__))
    test_data = open(os.path.join(dirname, 'data', 'test_constructor.yml')).read()
    my_constructor = AnsibleConstructor(file_name='/test_constructor.yml')
    data = my_constructor.construct_yaml(test_data)
    assert data['key'] == 'value'
    assert data['dict']['key'] == 'value'
    assert data['dict']['key2'] == 'value2'
    assert data['list'][1] == 'item1'
    assert data['list'][2] == 'item2'

# Generated at 2022-06-20 23:49:29.024549
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import json

    class AnsibleUnsafe:
        def __init__(self,data):
            self.data = data

        def __str__(self):
            return self.data

        def __repr__(self):
            return self.data

    class AnsibleUnsafeLoad:
        def __init__(self,data):
            self.data = data

        def __call__(self):
            return self.data

    class AnsibleUnsafeDump:
        def __init__(self,data):
            self.data = data

        def __call__(self,data):
            return self.data

    class AnsibleUnsafeDumpAll:
        def __init__(self,data):
            self.data = data

        def __call__(self,data):
            return self.data

   