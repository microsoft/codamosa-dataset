

# Generated at 2022-06-23 05:21:35.556780
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible import constants, errors
    import yaml

    yaml_str = "---\n'{{ foo }}'"

# Generated at 2022-06-23 05:21:40.396789
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    string = AnsibleUnicode('test string')
    assert string.startswith(u'test string')
    assert string.endswith(u'tring')
    assert len(string) == 11
    # Test if string is a unicode object
    assert isinstance(string, unicode)

# Generated at 2022-06-23 05:21:50.100739
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml import Loader, YAMLError, MarkedYAMLError
    from yaml.nodes import Node, ScalarNode
    from yaml.nodes import SequenceNode, MappingNode

    # 1. Successfull key sequence
    node_value = [SequenceNode('tag:yaml.org,2002:seq', [
        ScalarNode('tag:yaml.org,2002:str', '1')],
        start_mark=Mark(0, 0), end_mark=Mark(0, 0)),
        SequenceNode('tag:yaml.org,2002:seq', [
            ScalarNode('tag:yaml.org,2002:str', '2')],
            start_mark=Mark(0, 0), end_mark=Mark(0, 0))]

# Generated at 2022-06-23 05:21:54.284641
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = yaml.load('["1", "2"]', Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)
    assert data[0] == "1"
    assert data[1] == "2"
    assert data.ansible_pos == ('<string>', 0, 1)



# Generated at 2022-06-23 05:22:02.951888
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from yaml import dump

    node = ScalarNode(u'tag:yaml.org,2002:str', u"foobar")
    aconstructor = AnsibleConstructor()
    ansible_unicode = aconstructor.construct_yaml_str(node)
    assert type(ansible_unicode) == AnsibleUnicode
    assert ansible_unicode == "foobar"

    # Ensure it is still possible to serialise the constructed object
    # back to yaml

    yaml_str = dump(ansible_unicode)
    assert yaml_str == u"'foobar'\n"



# Generated at 2022-06-23 05:22:04.811802
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    c = AnsibleConstructor()
    n = c.construct_yaml_str(None)
    assert isinstance(n, AnsibleUnicode)

# Generated at 2022-06-23 05:22:17.749517
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test vars
    test_password = b'$ecret'
    test_dict = dict(a=1, b=2, c=3, d=4)
    test_list = ['this', 'is', 'a', 'test']
    secret_dict = {'secret_value': 'password'}

# Generated at 2022-06-23 05:22:29.349665
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.nodes import ScalarNode
    from yaml.compat import unicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    password = b"mypassword"
    vault = VaultLib(password)
    vault_secrets = [password]
    # 10 random characters encoded as unicode
    # Ahoy world
    value = unicode(u'\U00022b0c\U00027f6a\U00028d71\U00021977\U00023d10\U00023a01\U00022e8c\U0002db70\U00028c5a\U0002f541Ahoy world')
    # Blow it up (crypt

# Generated at 2022-06-23 05:22:40.116752
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test empty mapping
    node = MappingNode(None, None, [])
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), node) == {}

    # Test with one mapping
    node = MappingNode(None, None, [[ScalarNode(None), ScalarNode(None)]])
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), node) == {}

    # Test with two mapping
    node = MappingNode(None, None, [[ScalarNode(None), ScalarNode(None)],
                                    [ScalarNode(None), ScalarNode(None)]])
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), node) == {}



# Generated at 2022-06-23 05:22:47.037604
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    AnsibleConstructor: Test method construct_yaml_str of class AnsibleConstructor.
    """
    import yaml

    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'foo', (0, 0))
    construct_yaml_str = AnsibleConstructor.construct_yaml_str
    assert isinstance(construct_yaml_str(node), AnsibleUnicode)



# Generated at 2022-06-23 05:22:49.184872
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    data = AnsibleUnsafeText("Hello World!")
    assert AnsibleConstructor.construct_yaml_unsafe(None, None) == wrap_var(data)

# Generated at 2022-06-23 05:22:54.619360
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test if the method construct_mapping of class AnsibleConstructor returns an AnsibleMapping instance
    random_user_dict = {"a": 1, "b": 2}
    ansible_constructor = AnsibleConstructor()

    ansible_mapping = ansible_constructor.construct_mapping(random_user_dict)

    assert isinstance(ansible_mapping, AnsibleMapping)


# Generated at 2022-06-23 05:23:02.844349
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper

    dumper = AnsibleDumper()

    data_list = [1, 2, 3]
    yaml_list = yaml.load(yaml.dump(data_list, Dumper=dumper), Loader=AnsibleConstructor)

    assert isinstance(yaml_list, AnsibleSequence)

    assert type(yaml_list) == type(data_list)

    assert len(yaml_list) == len(data_list)
    assert yaml_list[0] == data_list[0]
    assert yaml_list[1] == data_list[1]
    assert yaml_list[2] == data_list[2]


# Generated at 2022-06-23 05:23:12.912359
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = "my_secret"
    vault_id = "my_id"
    vault_secret_key = "my_secret_key"
    vault_encoded_data = "1234567890"
    vault_secrets_list = []

    vault_secrets_list.append(vault_secrets)
    vault_secret_key_list = []
    vault_secret_key_list.append(vault_secret_key)

    ac = AnsibleConstructor(vault_secrets=vault_secrets_list)
    vault_node = "!vault |\n          " + vault_encoded_data
    vault_node_str = to_bytes(vault_node)
    node = yaml.compose(vault_node_str)

# Generated at 2022-06-23 05:23:23.378195
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode, ScalarNode, SequenceNode
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader

    string = u'key1: value1\nkey2: value2\nkey3: value3\nkey2: value2'
    stream = StringIO(string)
    reader = Reader(stream)
    parser = Parser(reader)
    composer = Composer()

    doc_no = 0
    while parser.check_event(composer):
        doc_no += 1
        if composer.check_node():
            node = composer.get_node()
            # We are checking only document 1

# Generated at 2022-06-23 05:23:29.844832
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    node = yaml.compose('''
    foo: 1
    bar:
      baz: 2
    ''')

    safe_constructor = AnsibleConstructor()

    mapping = safe_constructor.construct_yaml_map(node)
    assert mapping['foo'] == 1
    assert mapping['bar']['baz'] == 2



# Generated at 2022-06-23 05:23:37.174798
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    yaml_str = '''
- item1
- item2
- a:
    - b
    - c

- item3
'''
    doc_list = list(yaml.load_all(yaml_str, Loader=AnsibleConstructor))
    assert(type(doc_list[0]) == list)
    assert(len(doc_list) == 1)
    assert(doc_list[0][0] == 'item1')
    assert(doc_list[0][1] == 'item2')



# Generated at 2022-06-23 05:23:41.083164
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    a = AnsibleConstructor()
    # TODO: Should this return AnsibleUnicode, or an ascii encoded bytes object?
    assert isinstance(a.construct_yaml_str("test"), AnsibleUnicode)
    assert isinstance(a.construct_yaml_str("test"), str)

# Generated at 2022-06-23 05:23:51.436823
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    import yaml

    class TestConstructYamlStr(unittest.TestCase):
        def setUp(self):
            self.constructor = AnsibleConstructor()

        def tearDown(self):
            pass

        def test_plain_str(self):
            self.assertEqual(self.constructor.construct_yaml_str(yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', u"hello world")),
                             u"hello world")


# Generated at 2022-06-23 05:23:53.997307
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    # Initialization
    # <insert code here>

    # Execution
    # <insert code here>

    # Verification
    # <insert code here>
    assert True

# Generated at 2022-06-23 05:23:56.106391
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # pyyaml will silently overwrite duplicates, so we need to make sure that
    # our AnsibleConstructor raises
    pass

# Generated at 2022-06-23 05:24:06.632805
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys

    class FakeNode(object):
        def __init__(self, id_):
            self.id = id_

    # Test a valid mapping node
    construct_mapping = AnsibleConstructor.construct_mapping
    mapping_node = FakeNode(MappingNode)
    mapping = construct_mapping(mapping_node)
    assert len(mapping) == 0
    assert isinstance(mapping, AnsibleMapping)
    assert len(mapping.ansible_pos) == 3

    # Test a non-mapping node
    fake_node = FakeNode('a_node')
    try:
        construct_mapping(fake_node)
    except ConstructorError as e:
        # Expected exception
        assert to_native(e) == 'expected a mapping node, but found a_node'
        pass

# Generated at 2022-06-23 05:24:15.092838
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:24:20.732123
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = '''\
- test
- this
- out
'''
    try:
        yaml.load(data, AnsibleConstructor)
    except ConstructorError as e:
        assert False, 'Could not load AnsibleConstructor YAML sequence'



# Generated at 2022-06-23 05:24:30.560452
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    for data in [
        ['a', 'b', 'c'],
        {'name': 'data', 'value': ['a', 'b', 'c']},
        ['a', 'b', {'name': 'data', 'value': ['a', 'b', 'c']}],
    ]:
        r1 = AnsibleConstructor.construct_yaml_seq(
            AnsibleConstructor(),
            AnsibleDumper().represent_data(data)
        ).next()
        r2 = AnsibleConstructor.construct_yaml_seq(
            AnsibleConstructor(),
            AnsibleDumper().represent_data(r1)
        ).next()
        assert r1 == r2

# Generated at 2022-06-23 05:24:40.999417
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    content = '''---
name: test
value: {
    key1: value1
    key2: value2
  }
'''
    loader = AnsibleLoader(content, file_name='sample_playbook_1.yml', vault_secrets=[])
    for ds in loader.get_single_data():
        assert isinstance(ds, dict)
        assert type(ds['value']) is dict
        assert 'key1' in ds['value']
        assert 'key2' in ds['value']

    # YAML Syntax error will raise exception

# Generated at 2022-06-23 05:24:49.520914
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    safeConstructor = AnsibleConstructor()
    node = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=None)
    data = AnsibleMapping()
    for key in range(3):
        key_node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=str(key), style=None)
        value_node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=str(key), style=None)
        mapping_node = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map', value=[(key_node, value_node)], flow_style=None)

# Generated at 2022-06-23 05:24:59.153576
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # test method AnsibleConstructor.construct_vault_encrypted_unicode with the following data
    args=None
    node=None
    # end of test data
    # Unit test code
    display.vvv(u'Processing test for method AnsibleConstructor.construct_vault_encrypted_unicode')
    display.vvv(u'Arguments are: %s' % args)
    display.vvv(u'node is: %s' % node)

    obj=AnsibleConstructor()
    ret=obj.construct_vault_encrypted_unicode(node)
    display.vvv(u'ret is: %s' % ret)
    assert ret is not None


# Generated at 2022-06-23 05:25:13.925861
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    s = """
#
#comment
#
#
#
#
not_a_comment:
    #
    # line comment
    #
    subkey:  # other comment
    #another_comment
    - 1
    - 2
    - 3
    #
    # line comment
    #
    subsubkey:
        #
        # line comment
        #
        subsubsubkey: value
    #
    # line comment
    #
    subsubkey2:
        subsubsubkey2:
        - 1
        - 2
        - 3
    #
    # line comment
    #
    subsubkey3: value
    subsubkey4: true
    subsubkey5: false
    subsubkey6: null
"""

# Generated at 2022-06-23 05:25:23.179605
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    data = """
foo: 'bar'
baz: 1
qux:
  - a
  - b
  - c
"""

    pdict = yaml.load(data, Loader=AnsibleLoader)
    assert isinstance(pdict, AnsibleMapping)

    s = yaml.dump(pdict, Dumper=AnsibleDumper, default_flow_style=False)
    ndict = yaml.load(s, Loader=AnsibleLoader)
    assert isinstance(ndict, AnsibleMapping)
    assert pdict == ndict


if __name__ == '__main__':
    test_Ans

# Generated at 2022-06-23 05:25:30.792661
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import ansible.constants as C
    import ansible.parsing.yaml.loader as yaml_loader
    import yaml

    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    yaml_str = '''
        ---
        foo:
          - 1
        foo:
          - 2
    '''
    data = yaml.load(yaml_str, Loader=yaml_loader.AnsibleLoader)

    assert len(data) == 1
    assert data['foo'] == [2]

# Generated at 2022-06-23 05:25:42.953269
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    from yaml.nodes import ScalarNode

    fake_data_list = ['first_element', 'second_element']

    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq(SequenceNode(tag='tag:yaml.org,2002:str', value=[ScalarNode(tag='tag:yaml.org,2002:str', value='first_element'), ScalarNode(tag='tag:yaml.org,2002:str', value='second_element')], start_mark=None, end_mark=None))

    #assert ansible_constructor.construct_yaml_seq(SequenceNode(tag='tag:yaml.org,2002:str', value=[ScalarNode(tag='tag:yaml.org,2002:

# Generated at 2022-06-23 05:25:49.425028
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    a_constructor = AnsibleConstructor()
    a_node = object()
    a_node.start_mark = object()
    a_node.start_mark.column = 2
    a_node.start_mark.line = 1
    a_node.start_mark.name = 'main.yml'
    a_node.start_mark.buffer = 'main.yml'
    a_node.start_mark.pointer = 5
    assert a_constructor._node_position_info(a_node) == ('main.yml', 2, 3)

    assert a_constructor.construct_vault_encrypted_unicode(a_node) == 'AES256'

# Generated at 2022-06-23 05:25:57.892659
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    dict_to_test = dict(a=1, b=2, c=3)
    class FakeLoader:
        def __init__(self, x):
            self.data = x
            self.yaml = AnsibleConstructor(file_name="test_filename")
        def get_single_data(self):
            return self.data
    loader = FakeLoader(dict_to_test)
    actual_returned_dict = loader.yaml.get_single_data()
    assert dict_to_test == actual_returned_dict

# Generated at 2022-06-23 05:26:09.332103
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.reader import Reader
    from yaml.parser import Parser
    from yaml.scanner import Scanner
    from yaml.composer import Composer

    class Loader(Reader, Scanner, Parser, Composer, AnsibleConstructor):
        def __init__(self, stream):
            Reader.__init__(self, stream)
            Scanner.__init__(self)
            Parser.__init__(self)
            Composer.__init__(self)
            AnsibleConstructor.__init__(self)

    def load(stream):
        loader = Loader(stream)
        try:
            node = loader.get_single_node()
        finally:
            loader.dispose()
        return loader.construct_object(node)


# Generated at 2022-06-23 05:26:15.768057
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import load
    from yaml.nodes import ScalarNode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    sut = AnsibleConstructor()

    # test value
    src = u"test_value"
    node = ScalarNode(u"test_tag", src)

    result = sut.construct_yaml_str(node)

    assert isinstance(result, AnsibleUnicode)
    assert result == src
    assert result.ansible_pos == (None, None, None)



# Generated at 2022-06-23 05:26:25.176650
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestConfig:
        DUPLICATE_YAML_DICT_KEY = 'ignore'

    o_config = C
    C = TestConfig()

    test_data = u'''
---
# test list
- name: test
  - this
  - is
  - a
  - list
- name: multiline
    test: hello
    world
- name: multiline-indented
    test: |
      hello
      world
'''

    data = AnsibleLoader(test_data).get_single_data()

    C = o_config

    assert isinstance(data[0], AnsibleMapping), "data[0] type is not AnsibleMapping"

# Generated at 2022-06-23 05:26:29.340790
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml

    yaml_str = '!unsafe [1,2,3]'

    ans_const = AnsibleConstructor()
    result = yaml.load(yaml_str, Loader=yaml.Loader, Loader=yaml.Loader)
    assert result == [1, 2, 3]

# Generated at 2022-06-23 05:26:31.713841
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    try:
        AnsibleConstructor("filename")
    except Exception:
        raise AssertionError("AnsibleConstructor failed to initialized")

# Generated at 2022-06-23 05:26:41.107766
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # create a yaml node which represents a vault encrypted value
    class SomeMappingNode(MappingNode):
        id = 'tag:yaml.org,2002:map'
        def __init__(self, value, tag, start_mark, end_mark, flow_style=None):
            self.tag = tag
            self.value = value
            self.start_mark = start_mark
            self.end_mark = end_mark
            self.flow_style = flow_style
    
    class SomeKeyNode(object):
        def __init__(self, value):
            self.value = value

    class SomeValueNode(object):
        def __init__(self, tag, value, start_mark, end_mark):
            self.tag = tag
            self.value = value
            self.start_mark = start_mark

# Generated at 2022-06-23 05:26:52.244339
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from yaml.events import ScalarEvent
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ac = AnsibleConstructor()

# Generated at 2022-06-23 05:27:02.329487
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # test python expression
    assert AnsibleConstructor.construct_yaml_unsafe('!unsafe "abcd"') == 'abcd'
    assert AnsibleConstructor.construct_yaml_unsafe('!unsafe null') == None
    assert AnsibleConstructor.construct_yaml_unsafe('!unsafe True') == True
    assert AnsibleConstructor.construct_yaml_unsafe('!unsafe False') == False
    assert AnsibleConstructor.construct_yaml_unsafe('!unsafe 0') == 0
    assert AnsibleConstructor.construct_yaml_unsafe('!unsafe 0.1') == 0.1
    assert AnsibleConstructor.construct_yaml_unsafe('!unsafe 47') == 47

# Generated at 2022-06-23 05:27:14.174246
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    yaml = AnsibleDumper()
    yaml.add_representer(AnsibleUnsafeText, yaml.represent_str)
    yaml.add_multi_representer(unicode, yaml.represent_str)

    ansible_constructor = AnsibleConstructor()
    ansible_constructor.add_constructor(
        u'!unsafe',
        ansible_constructor.construct_yaml_unsafe)

    data_in = dict(a=['test string', dict(b='string 2')], c=dict(d='string 3', e=['string 4']))

# Generated at 2022-06-23 05:27:24.809120
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import yaml
    import unittest

    doc = '''
a:
  b:
    c: d
  # The following dict key will be overwritten.
  b:
    d: e
    e: f
  e: f
    '''

    class ConstructorTest(unittest.TestCase):
        def setUp(self):
            self.constructor = AnsibleConstructor()

        def test_basic(self):
            data = yaml.load(doc, Loader=self.constructor)
            self.assertIsInstance(data, AnsibleMapping)
            self.assertIsInstance(data.get('a'), AnsibleMapping)
            self.assertIsInstance(data.get('a').get('e'), AnsibleUnicode)

# Generated at 2022-06-23 05:27:35.608596
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    test_data = {
        u'a': u'AAA',
        u'b': u'BBB',
        u'c': {
            u'c1': u'CCC1',
            u'c2': u'CCC2',
            u'c3': {
                u'c3a': u'CCC3a',
                u'c3b': u'CCC3b',
            }
        },
        u'sequence': [
            u'seq0',
            u'seq1',
            u'seq2'
        ]
    }

    # yaml.load breaks when it receives AnsibleUnicode instead of regular unicode
    # we test this here so it can be caught

    from yaml import load, dump

# Generated at 2022-06-23 05:27:44.110935
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ac = AnsibleConstructor()
    # A valid vault ciphertext starts with $ANSIBLE_VAULT; it is safe to
    # assume that any string that does not begin with that prefix is
    # not a valid ciphertext. The data object passed here to
    # AnsibleConstructor is a dict with a single key called 'vault',
    # mapping to a string (the ciphertext).
    assert isinstance(ac.construct_vault_encrypted_unicode({'vault':'foo'}), AnsibleVaultEncryptedUnicode)
    try:
        ac.construct_vault_encrypted_unicode({'vault':'foo'})
    except ValueError as e:
        print('Something went horribly wrong: failed to decrypt non-vault data')

# Generated at 2022-06-23 05:27:54.713483
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()

# Generated at 2022-06-23 05:27:58.732139
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml

    data = yaml.load("""
        a: 1
        b: 2
        c: 3
    """, Loader=AnsibleConstructor)

    assert data.ansible_pos == ('<string>', 1, 0)



# Generated at 2022-06-23 05:28:09.445809
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    class FakeYamlNode(object):
        def __init__(self, start_mark, value):
            self.start_mark = start_mark
            self.value = value

        def __repr__(self):
            return 'FakeYamlNode(%s, %s)' % (self.start_mark, self.value)

    class FakeMark(object):
        def __init__(self, name, line, column):
            self.name = name
            self.line = line
            self.column = column

    mock_construct_scalar = lambda self, node: node.value
    class FakeAnsibleConstructor(AnsibleConstructor):
        construct_scalar = mock_construct_scalar

    node = FakeYamlNode(FakeMark('abc', 1, 1), 'test')
    ansible_str

# Generated at 2022-06-23 05:28:19.759605
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    obj = yaml.load(u"{ 1: 2, 3: 4, 1: 5 }", Loader=AnsibleConstructor)
    assert isinstance(obj, dict)
    assert obj == {1: 5, 3: 4}

    with C.DUPLICATE_YAML_DICT_KEY as d:
        obj = yaml.load(u"{ 1: 2, 3: 4, 1: 5 }", Loader=AnsibleConstructor)
        assert isinstance(obj, dict)
        if d == 'error':
            assert obj is None
        elif d == 'warn':
            assert obj == {1: 5, 3: 4}
        elif d == 'ignore':
            assert obj == {1: 5, 3: 4}

# Generated at 2022-06-23 05:28:30.520486
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, vault_secrets):
            AnsibleConstructor.__init__(self)
            self.vault_secrets = vault_secrets

    test_sample = AnsibleUnsafeText("{")

    test_vault_secrets = ["testsecret1", "testsecret2"]
    test_vault = VaultLib(secrets=test_vault_secrets)

    test_constructor = TestAnsibleConstructor(test_vault_secrets)

    test_result = test_constructor.construct_yaml_unsafe(test_sample)

    assert test_result.get

# Generated at 2022-06-23 05:28:41.381876
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Simple vault edit will succeed
    secrets = VaultLib(
        secrets=[
            VaultSecret('password'),
        ],
    )
    vault = VaultEditor(
        filename='/tmp/vault',
        vault_secrets=secrets,
    )
    assert vault.is_encrypted_data('$ANSIBLE_VAULT;1.1;AES256')

    # Simple vault with no secrets will fail
    secrets = VaultLib(
        secrets=[],
    )
    vault = VaultEditor(
        filename='/tmp/vault',
        vault_secrets=secrets,
    )

# Generated at 2022-06-23 05:28:49.501961
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # This test verifies the functionality of the AnsibleConstructor.construct_yaml_unsafe method
    # by testing that it can detect unsafe objects in a yaml file and wrap them.
    # The test works by parsing a yaml file containing strings, integers and a complex object.
    # Then, the method is called to wrap the complex object and the list is compared to the
    # original list. The original list contains the complex object in its native form, which
    # is a list of lists with strings, integers, and a natively represented set. The list returned
    # by the method should therefore contain a list of lists with strings and integers, and a
    # AnsibleUnsafeNativeSet.

    import yaml


# Generated at 2022-06-23 05:28:58.499286
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    val = u'[1, 2, 3]'
    node = yaml.nodes.MappingNode(
        u'tag:yaml.org,2002:int',
        yaml.nodes.SequenceNode(
            u'tag:yaml.org,2002:python/tuple',
            [
                yaml.nodes.ScalarNode(
                    u'tag:yaml.org,2002:str',
                    u'1'
                )
            ]
        ),
        yaml.nodes.ScalarNode(
            u'tag:yaml.org,2002:str',
            u'1'
        )
    )

    ac = AnsibleConstructor()

    ret = ac.construct_yaml_unsafe(node)


# Generated at 2022-06-23 05:28:59.182949
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert 1 == 1

# Generated at 2022-06-23 05:29:08.851610
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from yaml.scanner import ScannerError
    import yaml

    # Assume no vault secrets exist
    vault_secrets = []
    # The ciphertext is valid

# Generated at 2022-06-23 05:29:19.702662
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import random
    import types
    import copy
    # Note: the following code is only run when the yaml test file is explicitly run.
    # This could be modified to run when the yaml.py module is imported, but that would require a different way
    # to load the yaml file, since the loaders would not be set up yet.
    #
    # This code is run to verify that the method construct_yaml_unsafe returns objects that can be used
    # to run commands, as well as recursively check all of the objects in a nested structure.
    # Note that this test does not verify that the wrapped object is still usable for the intended purpose
    # for that we need to be able to execute arbitrary code, which would be a security vulnerability.
    #
    # The structure of the yaml file is designed to test both simple types and nested

# Generated at 2022-06-23 05:29:28.601008
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO

    yaml = '''
        - str1: !unsafe "&str"
        - unicode1: !unsafe "&unicode"
    '''
    res = {}
    try:
        res = yaml.load(StringIO(yaml))
    except Exception as e:
        print(e)

    assert(res[0][u'str1'].__class__ == str)
    assert(res[1][u'unicode1'].__class__ == str)
    # TODO Add test for bad tag
    # TODO Add test for bad class

# Generated at 2022-06-23 05:29:31.636770
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class_ = AnsibleConstructor
    constructor = class_()
    node = u'tag:yaml.org,2002:map'
    assert constructor.construct_yaml_map(node) != None

# Generated at 2022-06-23 05:29:39.849340
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test 1: checking the datatype of returned value

    # set up the input
    id = u'!vault'
    # create a MappingNode object
    node = MappingNode(tag=id, value=[])
    node.start_mark.column = 1
    node.start_mark.line = 1
    node.start_mark.name = 'source'

    # create an AnsibleConstructor object
    ac = AnsibleConstructor()

    # run the method
    ret = ac.construct_vault_encrypted_unicode(node)

    # check the datatype
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)

    # Test 2: checking if the returned value is empty

    # create an AnsibleConstructor object
    ac = AnsibleConstructor()

    # run the method
    ret

# Generated at 2022-06-23 05:29:50.296874
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import wrap_var

    class FakeVaultSecret(object):
        def __init__(self, secret):
            self.secret = secret

    vault_secret = FakeVaultSecret('')
    vault_secrets = [vault_secret]
    yaml_text = '{foo: bar}'
    loader = AnsibleLoader(yaml_text, file_name='', vault_secrets=vault_secrets)
    data = loader.get_single_data()
    assert data == {'foo': 'bar'}

    # Test with vault secret

# Generated at 2022-06-23 05:29:55.564783
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[], flow_style=False)
    data = AnsibleConstructor()
    mapping = data.construct_mapping(node)
    assert isinstance(mapping, AnsibleMapping)

# Generated at 2022-06-23 05:30:05.079565
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import io
    import sys
    import unittest

    from yaml.composer import Composer
    from yaml.scanner import Scanner
    from yaml.parser import Parser

    class UnitTestAnsibleConstructor(unittest.TestCase):
        def setUp(self):
            self.constructor = AnsibleConstructor()

        def construct_mapping(self, node):
            from ansible.parsing.yaml.constructor import AnsibleConstructor
            return AnsibleConstructor.construct_mapping(self.constructor, node)

        def test_construct_mapping(self):
            # test of construct_mapping method with normal input
            with open('./testrig.yaml', 'r') as testrig:
                testrig_lines = testrig.readlines()
                testrig_

# Generated at 2022-06-23 05:30:15.456426
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    class TestClass:
        def __init__(self, value):
            self.value = value

    result = AnsibleLoader(None, vault_secrets=[]).get_single_data("test: 'ascii string'")
    assert result == {"test": "ascii string"}

    result = AnsibleLoader(None, vault_secrets=[]).get_single_data("test: 'unicode string'")
    assert result == {"test": u'unicode string'}

    result = AnsibleLoader(None, vault_secrets=[]).get_single_data("test: '\"'")
    assert result == {"test": u'"'}


# Generated at 2022-06-23 05:30:17.765885
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    c = AnsibleConstructor()
    l = c.construct_yaml_seq(None)
    assert l.__next__() == []


# Generated at 2022-06-23 05:30:26.935035
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 05:30:34.885299
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys
    import os

    # Initialize Ansible Constructor for yaml.load()
    AnsibleConstructor.add_to_loader_class(AnsibleLoader)

    # Initialize variable values
    ansible_constructor = AnsibleConstructor()
    value = 'value'
    node = 'node'

    # Execute method
    result = ansible_constructor.construct_yaml_unsafe(value, node)

    assert result



# Generated at 2022-06-23 05:30:47.202083
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import ansible.parsing.yaml.loader
    ansible.parsing.yaml.loader.AnsibleLoader.add_constructor(
        u'tag:yaml.org,2002:map',
        AnsibleConstructor.construct_yaml_map)
    ansible.parsing.yaml.loader.AnsibleLoader.add_constructor(
        u'tag:yaml.org,2002:python/dict',
        AnsibleConstructor.construct_yaml_map)
    yaml_data = '''
        foo:
          -  1
          -  2
    '''
    data = ansible.parsing.yaml.loader.load(yaml_data)
    assert isinstance (data, dict)
    assert isinstance (data['foo'], list)


# Generated at 2022-06-23 05:30:55.144848
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    c = AnsibleConstructor()
    
    from yaml.nodes import SequenceNode
    from ansible.parsing.yaml.objects import AnsibleSequence
    n1 = SequenceNode(tag=u'tag:yaml.org,2002:int', value=[258])
    n2 = SequenceNode(tag=u'tag:yaml.org,2002:int', value=[259])
    n3 = SequenceNode(tag=u'tag:yaml.org,2002:int', value=[260])
    
    n = SequenceNode(tag=u'tag:yaml.org,2002:seq', value=[n1, n2, n3])
    s = c.construct_yaml_seq(n)
    
    assert isinstance(s, AnsibleSequence)
    assert s == [258, 259, 260]



# Generated at 2022-06-23 05:31:07.045158
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:31:17.247029
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible import context
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault.cli import VaultCLI

    display = Display()

    # Test with empty vault id
    display.display("Testing with empty vault id", color='blue')
    assert AnsibleConstructor().construct_vault_encrypted_unicode(None) is None

    # Test with empty vault secret
    display.display("Testing with empty vault secret", color='blue')
    assert AnsibleConstructor().construct_vault_encrypted_unicode(VaultCLI.EncryptedUnicode(u'!vault |', u'')) is None

    vault_secret = [u'password']
    vault_secrets = [vault_secret]

    # Test with vault secret on secret storage

# Generated at 2022-06-23 05:31:29.370227
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os
    import io
    import yaml
    import unittest
    import ansible.parsing.yaml.constructor

    class TestAnsibleConstructor_construct_yaml_map(unittest.TestCase):

        def test_construct_yaml_map_default(self):
            with io.open(os.path.join(os.path.dirname(__file__), 'data', 'hostvars.yml'), 'rt') as f:
                data = yaml.load(stream=f.read(), Loader=ansible.parsing.yaml.constructor.AnsibleConstructor)
                self.assertIsInstance(data, dict)
                for key, value in data.items():
                    self.assertIsInstance(value, dict)
                    self.assertIsInstance(key, unicode)

# Generated at 2022-06-23 05:31:39.440117
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    class AnsibleAsDict(dict):
        pass
    class AnsibleAsList(list):
        pass
    import yaml
    yaml_dict = AnsibleAsDict()
    yaml_dict['yaml_dict_key_1'] = 1
    yaml_dict['yaml_dict_key_2'] = 2

    yaml_list = AnsibleAsList()
    yaml_list.append(1)
    yaml_list.append(2)
    yaml_list.append(3)

    # Update legacy yaml constructors
    yaml.add_constructor(u'tag:yaml.org,2002:python/dict', AnsibleConstructor.construct_yaml_map)