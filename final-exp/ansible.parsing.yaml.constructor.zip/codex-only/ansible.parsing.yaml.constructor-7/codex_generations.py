

# Generated at 2022-06-23 05:21:43.873371
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    source = """
test_mapping:
    test_duplicate_key: value1
    test_duplicate_key: value2
    test_duplicate_key: value3
"""
    warnings = []
    def warning(msg):
        warnings.append(msg)
    display.warning = warning

    c = AnsibleConstructor()
    d = yaml.load(source, Loader=yaml.SafeLoader)
    assert len(warnings) == 2
    assert warnings[0] == u"While constructing a mapping from <string>, line 3, column 5, found a duplicate dict key ('test_duplicate_key'). Using last defined value only."

# Generated at 2022-06-23 05:21:51.293456
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = AnsibleMapping()
    assert (data.ansible_pos == None)
    data.update({'name': 'Bob', 'age': '40'})
    assert (data['name'] == 'Bob')
    assert (data['age'] == '40')
    # valid positions
    data.ansible_pos = ('<string>', 1, 1)
    assert (data.ansible_pos == ('<string>', 1, 1))
    data.ansible_pos = ('/tmp/test.yml', 3, 2)
    assert (data.ansible_pos == ('/tmp/test.yml', 3, 2))
    # invalid position: datasource < 1 character
    data.ansible_pos = ('', 3, 2)
    assert (data.ansible_pos == ('', 3, 2))
    #

# Generated at 2022-06-23 05:21:58.714913
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.scanner import Scanner
    from yaml.reader import Reader

    reader = Reader('')
    scanner = Scanner(reader)
    composer = Composer(scanner)
    parser = Parser(scanner)
    construct_yaml_str = AnsibleConstructor.construct_yaml_str
    construct_scalar = AnsibleConstructor.construct_scalar

    yaml_str = 'test_AnsibleConstructor_construct_yaml_str'

    # Case: empty anchor, tag and empty string
    anchor = 'test_AnsibleConstructor_construct_yaml_str'
    tag = 'test_AnsibleConstructor_construct_yaml_str'
    node = composer.compose

# Generated at 2022-06-23 05:22:09.573746
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # base case
    # Load string with  '!unsafe' tag using AnsibleConstructor
    # Expect to get a AnsibleUnsafeText
    # Expect to get the original string
    # Except to get the original string type
    test_str = 'test string !unsafe'
    test_str_get = 'test string !unsafe'
    test_str_get_type = 'test string !unsafe'
    test_Init = AnsibleConstructor(None)
    test_yaml_dict = yaml.load(test_str, Loader=AnsibleConstructor)
    assert isinstance(test_yaml_dict, AnsibleUnsafeText)
    assert test_yaml_dict == test_str_get
    assert type(test_yaml_dict) == type(test_str_get_type)

    # Test

# Generated at 2022-06-23 05:22:20.364270
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()

    # Test that iterator produces the right number of items
    node = MappingNode(u'', [], [], start_mark=None, end_mark=None)
    mapping = constructor.construct_mapping(node)
    assert isinstance(mapping, AnsibleMapping)
    assert len(mapping.items()) == 0

    # Test that iterator has the right items
    node = MappingNode(u'', [], [], start_mark=None, end_mark=None)
    node.value.append((u'foo', u'bar'))
    mapping = constructor.construct_mapping(node)
    assert isinstance(mapping, AnsibleMapping)
    assert len(mapping.items()) == 1
    assert mapping[u'foo'] == u'bar'

    # Test that iterator

# Generated at 2022-06-23 05:22:31.435919
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Setup
    node = __import__('yaml').nodes.ScalarNode(None, None, None, None)
    value = '!vault |\n  $ANSIBLE_VAULT;1.2;AES256;foo123\n32432423jksalsfklsdfjklsdfklsdfjklsdfjksdfjklsdfjklsdfjklsdfjksdfjklsdfjksdfjklsdfjksdfjklsdf\n'
    node.value = value
    constructor = AnsibleConstructor(vault_secrets=['foo123'])
    # Exercise and verify
    encrypted_unicode_object = constructor.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-23 05:22:43.021944
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

# Generated at 2022-06-23 05:22:47.242860
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Call function
    ansible_constructor = AnsibleConstructor()

    node = MappingNode('tag:yaml.org,2002:map', [], None, None)
    ansible_constructor.construct_yaml_map(node)



# Generated at 2022-06-23 05:22:57.510610
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import uuid
    import yaml
    import inspect
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var

    filename = str(uuid.uuid4())
    f = open(filename, 'w')

    # prepare yaml string
    yaml_str = '''
- a: hola

- b: mundo

-   c: 3
    d: 4
    '''

    # write yaml string to file
    f.write(yaml_str)
    f.close()

    # load yaml string as python object
    python_obj = AnsibleConstructor(filename, vault_secrets='password').get_

# Generated at 2022-06-23 05:23:10.716820
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """ AnsibleConstructor: Test construct_yaml_unsafe method """

    # Create a VaultLib object
    vault_password_file = None
    vault_secrets = None
    if vault_password_file:
        vault_secrets = VaultLib.secrets_from_file(vault_password_file)
    vault = VaultLib(secrets=vault_secrets)

    # Load an encrypted string from a yaml file
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultEditor
    from ansible.utils.encrypt import do_encrypt
    from tempfile import NamedTemporaryFile


# Generated at 2022-06-23 05:23:12.798285
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    data = 'test'
    assert AnsibleConstructor.construct_yaml_unsafe(data) == data

# Generated at 2022-06-23 05:23:23.258427
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    import sys

    # an empty list
    text='''---
# This is a comment
-
# This is the first element, a string
- string
# This is the second element, a nested list
- [ a, b, c ]
# This is the third element, a nested dict
- { a: 1, b: 2 }
'''
    c = AnsibleConstructor.construct_yaml_seq(yaml.compose(text))
    assert next(c) == []
    assert next(c) == ['string']
    assert next(c) == ['a', 'b', 'c']
    assert next(c) == dict(a=1, b=2)
    assert len(list(c)) == 0

# Generated at 2022-06-23 05:23:33.095056
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # AnsibleConstructor inherits from yaml.constructor.SafeConstructor,
    # and SafeConstructor defines the construct_yaml_seq method,
    # so we can use the following syntax to retrieve it
    super_construct_yaml_seq = SafeConstructor.construct_yaml_seq

    # Without defining our own construct_yaml_seq method, calling this
    # method would return a normal Python sequence.
    test_string = """key:
- value1
- value2"""
    test_result = super_construct_yaml_seq(AnsibleConstructor, test_string)
    assert isinstance(test_result, list)
    assert test_result == [u'value1', u'value2']

    # With our own construct_yaml_seq method, we now return an
    # AnsibleSequence, which is

# Generated at 2022-06-23 05:23:42.772358
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # pylint: disable=too-many-locals
    yaml_doc = """
        key1:
            subkey1: value1
            subkey2: value2
        key2:
            subkey1: value1
            subkey2: value2
        """
    yaml_data = yaml.load(yaml_doc, Loader=AnsibleConstructor)
    assert isinstance(yaml_data, AnsibleMapping)
    assert isinstance(yaml_data['key1'], AnsibleMapping)
    assert isinstance(yaml_data['key1']['subkey1'], AnsibleUnicode)
    assert isinstance(yaml_data['key1']['subkey2'], AnsibleUnicode)

# Generated at 2022-06-23 05:23:50.136929
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.yaml.loader
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    import tempfile
    import yaml

    (tmpfd, tmpfile) = tempfile.mkstemp()
    os.write(tmpfd, "#!/usr/bin/python\nprint 'contents'\n")
    os.close(tmpfd)

    # setup
    unsafe_yaml_text = "{'file_content': !unsafe '%s'}" % tmpfile
    result = yaml.load(textwrap.dedent(unsafe_yaml_text), Loader=ansible.parsing.yaml.loader.AnsibleLoader)

    # result verification
    assert isinstance(result['file_content'], AnsibleUnsafe) is True

# Generated at 2022-06-23 05:23:59.902396
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    class FakeClass(object):
        def __init__(self):
            self.value = []
            self.ansible_pos = None

        def extend(self, value):
            self.value.extend(value)

    class FakeNode(object):
        def __init__(self, values):
            self.value = values

    fake_node = FakeNode([1, 2])
    fake_class = FakeClass()
    ansible_constructor = AnsibleConstructor("/path/to/file")
    result = ansible_constructor.construct_yaml_seq(fake_node)
    try:
        next(result)
        result.send(fake_class)
    except StopIteration:
        pass

    assert fake_class.value == [1, 2]



# Generated at 2022-06-23 05:24:07.137559
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    c = AnsibleConstructor()

    import yaml

    s = '{test: value}'
    n = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=s)
    o = c.construct_yaml_str(n)

    assert isinstance(o, AnsibleUnicode)
    assert o.ansible_pos == (None, 1, 0)

# Generated at 2022-06-23 05:24:08.654031
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    #TODO: Test AnsibleConstructor
    assert False, "Test AnsibleConstructor"

# Generated at 2022-06-23 05:24:17.238780
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    encryptor = VaultLib()

    encryptor.secrets = [
        '1',
    ]

    constructor = AnsibleConstructor()

    constructor._vaults['default'] = encryptor;


# Generated at 2022-06-23 05:24:26.046269
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = '''
    aaa: &ref
      - 1
      - 2
      - 3
    bbb: *ref
    ccc: *ref
    '''
    # The construct_yaml_seq method of class AnsibleConstructor returns a list of 3 elements, two of which are references to the same list.
    # We have to ensure that the equality test below does not fail due to the references being different.
    from ansible.parsing.yaml import load
    data = load(yaml_data)
    ref_list = [1, 2, 3]
    assert data['aaa'] == ref_list
    assert data['bbb'] == ref_list
    assert data['ccc'] == ref_list

# Generated at 2022-06-23 05:24:37.026959
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class Node(object):
        def __init__(self, value):
            self.value = value
            self.start_mark = object()

    ac = AnsibleConstructor()

    # Test the case if the key is in mapping
    key_node = Node(value=1)
    value_node = Node(value=1)
    node = Node(value=[(key_node, value_node)])
    ac.construct_mapping(node, deep=False)

    # Test the case if the key is not in mapping
    key_node = Node(value=1)
    value_node = Node(value=1)
    node = Node(value=[(key_node, value_node), (key_node, value_node)])

    # case C.DUPLICATE_YAML_DICT_KEY == 'ignore'

# Generated at 2022-06-23 05:24:44.900282
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Test the method construct_yaml_seq of class AnsibleConstructor
    """

    # Create a sample YAML sequence and a mock object to call the method construct_yaml_seq
    yaml_seq_sample = "[1,2,3]"
    method_obj = AnsibleConstructor()

    # Call the method construct_yaml_seq
    ret_val = list(method_obj.construct_yaml_seq(yaml_seq_sample))

    # Check if the sample YAML sequence is correctly returned
    assert ret_val == [1, 2, 3]


# Generated at 2022-06-23 05:24:54.489759
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils.six import StringIO


# Generated at 2022-06-23 05:24:59.596340
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    data = {'foo' : 'bar', 'baz' : 42}
    node = ansible_constructor.construct_yaml_map(data)
    assert isinstance(node, AnsibleMapping)
    assert node['foo'] == 'bar'
    assert node['baz'] == 42

# Generated at 2022-06-23 05:25:10.461940
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import json
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import datetime

    class A(AnsibleBaseYAMLObject):
        yaml_tag = u'tag:yaml.org,2002:int'
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return '!!python/int %s' % self.value
        def __int__(self):
            return self.value

    class B(AnsibleBaseYAMLObject):
        yaml_tag = u'tag:cliffano.com,2008:datetime'
        def __init__(self, value):
            self.value = value

# Generated at 2022-06-23 05:25:19.154660
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    value = "test string"
    file_name = "test_file"
    vault_secrets = ["test_secret"]

    constructor = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    loader = AnsibleLoader(file_name, vault_secrets=vault_secrets)
    loader.add_constructor(u'tag:yaml.org,2002:str', constructor.construct_yaml_str)

    result = loader.construct_yaml_str(value)
    assert isinstance(result, AnsibleUnicode)
    assert result == "test string"

# Generated at 2022-06-23 05:25:31.117572
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = [
        b'k1: value1\nk2: value2\nk3: value3\n',
        b'k4: value4\nk5: value5\nk6: value6\n'
    ]
    args = [None, None]
    kwargs = {'file_name': 'test', 'vault_secrets': []}
    ansible_constructor = AnsibleConstructor(*args, **kwargs)
    node = MappingNode(None, None, False, True)
    Actual = ansible_constructor.construct_yaml_map(node)
    Expected = AnsibleMapping()
    # Actual.next() will return the AnsibleMapping object
    # pylint: disable=maybe-no-member

# Generated at 2022-06-23 05:25:43.170313
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from collections import Mapping, Sequence

    # fake file name
    file = 'my_file'
    # load data
    # with open("test_playbook.yaml", 'r') as stream:
    with open("/home/hyk/ansible/lib/ansible/playbooks/ansible/test.yml", 'r') as stream:
        data = stream.read()
    # initialize loader
    loader = AnsibleLoader(data, file_name=file)
    # load data
    data = loader.get_single_data()
    # Convert data to dict
   

# Generated at 2022-06-23 05:25:54.286950
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # need to test the 'warning' and 'error' cases. This will require
    # us to patch a few things and make this test a little more complex
    test_loader = AnsibleConstructor()
    # test with yaml.org,2002:map tag
    from yaml.representer import SafeRepresenter
    test_yaml_org_2002_map_node = SafeRepresenter.represent_dict(test_loader, {'a': 'b', 'c': 'd'})
    test_yaml_org_2002_map_node.tag = u'tag:yaml.org,2002:map'
    result_to_test_with_yaml_org_2002_map = next(test_loader.construct_yaml_map(test_yaml_org_2002_map_node))
    assert result_to_test_with_

# Generated at 2022-06-23 05:26:04.954545
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    data = """
    foo: one
    foo: two
    """

    # Test case: ignore duplicate keys
    yaml.add_constructor(u'tag:yaml.org,2002:map', AnsibleConstructor.construct_mapping)
    yaml.add_constructor(u'tag:yaml.org,2002:python/dict', AnsibleConstructor.construct_mapping)
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    result = yaml.load(data, Loader=AnsibleLoader)
    assert result == {'foo': 'two'}

    # Test case: warn duplicate keys

# Generated at 2022-06-23 05:26:11.205949
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    def check_construct(constructor, node_string, expected):
        node = yaml.parse(node_string).contents[0]
        actual = constructor.construct_yaml_str(node)
        assert actual == expected, \
            u'%r != %r for: %s' % (actual, expected, node_string)

    # Case: Default.
    # Expectations:
    # - unicode object is returned
    # - ansible_pos of returned object is set
    # - ansible_pos of returned object is same as expected
    expected = u'a string'
    node_string = u'---\n%r' % expected
    constructor = AnsibleConstructor()
    check_construct(constructor, node_string, expected)

    # Case: No implicit resolver.
    # Expectations:
    # -

# Generated at 2022-06-23 05:26:22.248225
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import zipfile
    import base64
    import json
    import yaml

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    # We generate a small file for testing (used by unit tests for AnsibleConstructor)
    #   1) generate random keys for our vault and MacOS's built-in zip encryption
    tmp_dir = tempfile.mkdtemp()
    vaultkey = os.urandom(16)
    key = os.urandom(16)
    iv = os.urandom(8)

    #   2) write our test file
    # The test file is a YAML file with our vault data, due to be written to vaultkey.yml
    # Note, it has a single field, 'foo', which is the string 'bar'

# Generated at 2022-06-23 05:26:29.154450
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = u"This is a test"
    node = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', yaml_str)
    obj = AnsibleConstructor().construct_yaml_str(node)
    assert isinstance(obj, AnsibleUnicode)
    assert obj.ansible_pos == (None, 1, 1)
    assert obj == yaml_str

# Generated at 2022-06-23 05:26:39.251751
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-23 05:26:40.091265
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert AnsibleConstructor

# Generated at 2022-06-23 05:26:50.201672
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import io
    # Fixture
    node = None
    # Tests
    ac = AnsibleConstructor()
    assert type(ac) == AnsibleConstructor
    # a dictionary representing an ansible playbook
    playbook = {
        'hosts': 'all',
        'roles': ['role1', 'role2', 'role3'],
        'tasks': [
            {'name': 'task1', 'action': 'action1'},
            {'name': 'task2', 'action': 'action2'},
            {'name': 'task3', 'action': 'action3'},
        ]
    }
    # a yaml string representation of the playbook

# Generated at 2022-06-23 05:26:54.640403
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    test_dict = {'a_list': ['1','2','3']}
    test_yaml = yaml.dump(test_dict)
    assert '- 1\n- 2\n- 3' in test_yaml
    assert 'a_list' in test_yaml


# Generated at 2022-06-23 05:26:59.827682
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = None
    ac = AnsibleConstructor(None, vault_secrets)
    try:
        ac.construct_vault_encrypted_unicode("ciphertext")
        assert False
    except:
        assert True

    vault_secrets = "abcd"
    ac = AnsibleConstructor(None, vault_secrets)
    try:
        ac.construct_vault_encrypted_unicode("ciphertext")
        assert False
    except:
        assert True

# Generated at 2022-06-23 05:27:10.199131
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    # Fake method for testing
    def fake_construct_sequence(self, node):
        # Test of default value
        return None

    # Init class
    ansible_constructor = AnsibleConstructor()

    # Imitate a node object
    Node = type('Node', (), {})
    node = Node()

    # Test with default value
    ansible_constructor.construct_sequence = fake_construct_sequence  # Fake method
    generated_seeq = ansible_constructor.construct_yaml_seq(node)
    expected_seeq = AnsibleSequence()
    assert next(generated_seeq) == expected_seeq
    assert expected_seeq == []



# Generated at 2022-06-23 05:27:21.423665
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode, to_text
    class FakeNode:
        def __init__(self, text):
            self.text = text
            self.start_mark = None
        def __repr__(self):
            return 'FakeNode(%r)' % self.text
    c = AnsibleConstructor()
    assert c.construct_yaml_str(FakeNode('hello')) == to_text('hello')
    assert c.construct_yaml_str(FakeNode(u'héllö')) == to_text(u'héllö')
    assert issubclass(type(c.construct_yaml_str(FakeNode('hello'))), AnsibleUnicode)

# Generated at 2022-06-23 05:27:29.903621
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_text

    data = to_text(u'''[1, 2, 3, 4, 5]''')
    ans_loader = AnsibleLoader(data, 'memory')
    my_seq = ans_loader.get_single_data()

    assert isinstance(my_seq, AnsibleSequence)
    assert my_seq == [1, 2, 3, 4, 5]

    data = to_text('''[1, 2, 3, 4, 5]''')
    ans_loader = AnsibleLoader(data, 'memory')
    my_seq = ans_loader.get_single_data()



# Generated at 2022-06-23 05:27:38.590094
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    yaml_data = '!unsafe 1'
    loader = yaml.Loader(yaml_data)
    data = loader.get_single_data()
    assert 1 == data   # data is int and not unsafe_proxy

    yaml_data = '!unsafe [1, 2]'
    loader = yaml.Loader(yaml_data)
    data = loader.get_single_data()
    assert [1,2] == data

    yaml_data = '!unsafe {a: 1, b: 2}'
    loader = yaml.Loader(yaml_data)
    data = loader.get_single_data()
    assert {'a':1, 'b':2} == data

    yaml_data = '!unsafe {1: a, 2: b}'

# Generated at 2022-06-23 05:27:41.153597
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    y_str = AnsibleConstructor.construct_yaml_str('test')
    assert type(y_str) == AnsibleUnicode


# Generated at 2022-06-23 05:27:42.865545
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    obj = AnsibleConstructor()
    assert isinstance(obj.construct_yaml_unsafe(0), wrap_var)

# Generated at 2022-06-23 05:27:54.108644
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(u'tag:yaml.org,2002:map', [], [])
    node.start_mark = 0
    node.end_mark = 0
    obj = AnsibleConstructor().construct_yaml_map(node)
    assert len(obj.ansible_pos) == 3
    assert obj.ansible_pos[0] == None
    assert obj.ansible_pos[1] == 1
    assert obj.ansible_pos[2] == 1

    # Test that a _ansible_file_name is used as the data source
    node = MappingNode(u'tag:yaml.org,2002:map', [], [])
    node.start_mark = 0
    node.end_mark = 0
    obj = AnsibleConstructor("/path/to/test.yaml").construct_

# Generated at 2022-06-23 05:28:04.472692
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    input_dict = {
        'name': 'image name',
        'url': 'image url',
    }

    node = yaml.compose('{}', {})
    node.tag = u'tag:yaml.org,2002:map'
    node.value = [
        (yaml.ScalarNode(u'tag:yaml.org,2002:str', 'name'), yaml.ScalarNode(u'tag:yaml.org,2002:str', 'image name')),
        (yaml.ScalarNode(u'tag:yaml.org,2002:str', 'url'), yaml.ScalarNode(u'tag:yaml.org,2002:str', 'image url')),
    ]

    ac = AnsibleConstructor()

# Generated at 2022-06-23 05:28:14.158905
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test first case of method, which is when duplicate keys are allowed
    C.DUPLICATE_YAML_DICT_KEY='allow'
    yaml_dict=AnsibleConstructor().construct_mapping(dict(a=2, b=3))
    assert len(yaml_dict) == 2
    assert yaml_dict['a'] == 2
    assert yaml_dict['b'] == 3

    C.DUPLICATE_YAML_DICT_KEY='error'
    yaml_dict=AnsibleConstructor().construct_mapping(dict(a=2, b=3))
    assert len(yaml_dict) == 2
    assert yaml_dict['a'] == 2
    assert yaml_dict['b'] == 3

    C.DUPLICATE_YAML_DICT_

# Generated at 2022-06-23 05:28:24.109223
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import logging
    import sys
    import unittest
    import yaml
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var

    class AnsibleConstructorTestCase(unittest.TestCase):

        def setUp(self):
            self.constructor = AnsibleConstructor()

        def tearDown(self):
            pass

        def test_construct_vault_encrypted_unicode_obj(self):
            logger = logging.getLogger('AnsibleConstructorTestCase')
            logger.debug('Test construct_vault_encrypted_unicode_obj()')
            # Create a constructor
            constructor = AnsibleConstructor()
            # Read the vault password for testing
            vault_password = 'test/ansible/parsing/vault/test_vault_password.txt'
           

# Generated at 2022-06-23 05:28:32.390057
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import UNSAFE_PROXY_VERSION
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars import VariableManager
    from six import string_types

    vars = VariableManager()
    filename = 'test_yaml_constructor_file.yml'
    data1 = dict(
        key1='value1',
        key2='value2',
        key3='value3',
        key4=dict(
            subkey1='subvalue1',
            subkey2='subvalue2',
        )
    )

# Generated at 2022-06-23 05:28:34.852582
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    pass
    # print(AnsibleConstructor.construct_mapping)


# Generated at 2022-06-23 05:28:42.799449
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import pytest
    import os
    import sys
    import yaml
    ansible_constructor = AnsibleConstructor()
    ansible_constructor2 = AnsibleConstructor(file_name='test.yml')
    print(yaml.dump({'foo': 'bar'}, Dumper=yaml.SafeDumper, width=50, default_flow_style=False))

if __name__ == '__main__':
    test_AnsibleConstructor()

# Generated at 2022-06-23 05:28:53.512224
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    '''
    UnitTest: test the method construct_yaml_unsafe of class AnsibleConstructor.
    '''

    construct_yaml_unsafe_output = AnsibleConstructor.construct_yaml_unsafe(
        {'tag': 'tag:yaml.org,2002:python/unicode',
         'value': 'tag:yaml.org,2002:python/unicode'})
    if construct_yaml_unsafe_output == 'tag:yaml.org,2002:python/unicode':
        print('PASSING: Test for method construct_yaml_unsafe passing!')
        return 0
    else:
        print('FAILING: Test for method construct_yaml_unsafe failing!')
        return 1

# Generated at 2022-06-23 05:29:03.960602
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # generate random text data to encrypt
    random_data = os.urandom(16)
    random_data_str = base64.b64encode(random_data)

    # create a VaultLib class
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    vault_encryped_data = vault.encrypt(random_data_str)
    vault_encryped_data_str = base64.b64encode(vault_encryped_data)

    # create yaml node
    from yaml.nodes import ScalarNode
    from ansible.parsing.yaml.nodes import VaultEncryptedUnicode
    node = ScalarNode(tag='!vault', value=vault_encryped_data_str, plain=False, formatted=True)

# Generated at 2022-06-23 05:29:11.609816
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with ansible.constants.DEFAULT_VAULT_ID for vault_id
    vault = VaultLib(secrets=['vault'])
    constructor = AnsibleConstructor(vault_secrets=['vault'])
    node = None
    ret = constructor.construct_vault_encrypted_unicode(node)
    assert ret.vault == vault

#Test with a custom vault_id

# Generated at 2022-06-23 05:29:21.765933
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import os
    import sys
    import tempfile
    import unittest
    import yaml

    # Class to test the AnsibleConstructor class.

# Generated at 2022-06-23 05:29:22.844257
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert 0,"TODO: Write Me."

# Generated at 2022-06-23 05:29:28.292535
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # the argument node is not used, just return an empty container
    y = AnsibleConstructor()
    class node(object):
        def __init__(self):
            self.value = 'node'

    assert isinstance(y.construct_yaml_map(node()), dict)
    assert isinstance(y.construct_yaml_map(node()), AnsibleMapping)

# Generated at 2022-06-23 05:29:37.559759
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    class MyTestConstructor(AnsibleConstructor):
        def _node_position_info(self, node):
            return (None, None, None)

    k1 = 'key1'
    k2 = 'key2'
    k3 = 'key1'
    v1 = 'value1'
    v2 = 'value2'
    v3 = 'value3'

    mapping_node = MappingNode(None, None, None)
    mapping_node.value = [(k1, v1), (k2, v2), (k3, v3)]

    test_constructor = MyTestConstructor()
    mapping = test_constructor.construct_mapping(mapping_node, False)


# Generated at 2022-06-23 05:29:44.731998
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = u'This is my text!'
    node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=yaml_str)
    ansible_constructor = AnsibleConstructor()
    ansible_str = ansible_constructor.construct_yaml_str(node)

    assert isinstance(ansible_str, AnsibleUnicode)
    assert ansible_str == yaml_str
    assert ansible_str.ansible_pos == (u'<unicode>', 1, 0)



# Generated at 2022-06-23 05:29:53.262307
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from ansible.utils.unicode import to_unicode

    # We use this for the load function for our constructor
    from yaml import Loader
    loader = Loader(AnsibleConstructor)

    for input_, expected in (
            # inputs as ascii
            (b'this is a string', u'this is a string'),
            (b'!unsafe "this is a string"', u'this is a string'),
            # inputs in unicode
            (u'this is a string', u'this is a string'),
            (u'!unsafe "this is a string"', u'this is a string'),
    ):
        # inputs are either byte strings or unicode strings
        assert isinstance(input_, tuple(basestring))
        # Assert that unic

# Generated at 2022-06-23 05:30:03.994013
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    yaml_text = '''
test:
  test: test
  test2: test2
  test3:
    test4: test4
  test5: test5
'''
    obj = yaml.load(yaml_text, Loader=AnsibleConstructor)
    assert isinstance(obj, dict)
    assert obj['test'].ansible_pos == ('/dev/null', 1, 0)
    assert isinstance(obj['test'], dict)
    assert isinstance(obj['test']['test3'], dict)
    assert obj['test']['test3']['test4'] == 'test4'
    assert obj['test'].ansible_pos == ('/dev/null', 1, 0)


# Generated at 2022-06-23 05:30:14.175432
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    instance = AnsibleConstructor()
    input_data = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35356537383430633533656665353232633138353730396431643362313337636364383637656130\n          393230393835373766643266363333396666383530366230643734353062303364383136666431\n          3631613464323831663061363162386230303162326131633665\n          "
    expected_value = 'ansible'
    output_data = instance.construct_vault_encrypted_unicode(input_data)
    assert output_data == expected_value



# Generated at 2022-06-23 05:30:20.864131
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml import objects
    import yaml

    expected = [1, 2, 3]
    node = yaml.nodes.SequenceNode(tag=u'tag:yaml.org,2002:seq', value=expected, flow_style=False)

    actual = AnsibleConstructor().construct_yaml_seq(node)
    assert isinstance(actual, objects.AnsibleSequence)
    assert expected == actual

# Generated at 2022-06-23 05:30:29.041856
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    This testcase checks the method construct_mapping of class AnsibleConstructor.
    The method should raise ConstructorError when it gets duplicate dict keys.
    """
    yaml_str1 = """
        - hosts: all
          gather_facts: yes
          tasks:
            - name: Run a command
              shell: "echo {{ test_var }}"
              register: result
            - debug:
                var: result
        """

    yaml_str2 = """
        - hosts: all
          gather_facts: yes
          tasks:
            - name: Run a command
              shell: "echo {{ test_var }}"
              register: result
              register: result
            - debug:
                var: result
        """


# Generated at 2022-06-23 05:30:41.081065
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([b'abc123'])
    b_plaintext = b'plaintext'
    b_ciphertext_data = vault.encrypt(b_plaintext)
    b_yaml_unicode_node = b'!unsafe !vault-encrypted\n' + b_ciphertext_data
    b_yaml_mapping_node = b'example:\n' + b_yaml_unicode_node
    mapping = yaml.load(b_yaml_mapping_node, Loader=AnsibleConstructor, vault_secrets=[b'abc123'])
    assert isinstance(mapping, dict)

# Generated at 2022-06-23 05:30:50.689728
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    from yaml.nodes import ScalarNode
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    class Node(object):
        def __init__(self, plaintext):
            self.plaintext = to_bytes(plaintext)

        def __eq__(self, other):
            return self.plaintext == other.plaintext

        def __ne__(self, other):
            return not self.__eq__(other)

        def __repr__(self):
            return "<Node: '{}'>".format(self.plaintext)


# Generated at 2022-06-23 05:31:00.538353
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

    ansible_node = "!vault-encrypted $ANSIBLE_VAULT;1.1;AES256\n tpfdxo5ooIw5zGwyAl1Q2iAg5DvIHIeDY9Xn6UUMGgUxzwQ2he6q3rC1804r07rG\ngcFn6U9M4y0a1x4vRdAe0w==\n"
    ansible_vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(ansible_node)

# Generated at 2022-06-23 05:31:02.298664
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    a = AnsibleConstructor()

# Generated at 2022-06-23 05:31:04.740812
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert AnsibleConstructor

if __name__ == '__main__':
    test_AnsibleConstructor()

# Generated at 2022-06-23 05:31:12.340808
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    construct_yaml_str = AnsibleConstructor.construct_yaml_str
    node = type("Node", (object,), {"start_mark": type("Mark", (object,), {"line": 1, "column": 1, "name": "source"}),
                                    "start_mark.line": 1,
                                    "start_mark.column": 1,
                                    "start_mark.name": "source",
                                    "value": "value"})
    assert type(construct_yaml_str(node)) == AnsibleUnicode

# Generated at 2022-06-23 05:31:21.249227
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    import ansible
    from ansible.parsing.yaml.constructor import AnsibleConstructor as A_C
    from ansible.constants import DEFAULT_VAULT_SECRET_PATH

    class Test_construct_vault_encrypted_unicode(unittest.TestCase):

        def setUp(self):
            self.secret_path = DEFAULT_VAULT_SECRET_PATH
            self.constructor = A_C(vault_secrets=[self.secret_path])


# Generated at 2022-06-23 05:31:26.922864
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ans_const = AnsibleConstructor()
    ans_const.construct_scalar = lambda node: str(node)
    ans_const.construct_yaml_str = AnsibleConstructor.construct_yaml_str
    read_value = ans_const.construct_yaml_str(None)
    assert isinstance(read_value, AnsibleUnicode)



# Generated at 2022-06-23 05:31:37.856060
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    import yaml

    def test(value, expected_result, **kwargs):
        actual_result = yaml.load(value, Loader=AnsibleConstructor, **kwargs)
        assert actual_result == expected_result

    value = """
        foo: bar
        foo: baz
    """

    expected_result = {u'foo': u'baz'}
    test(value, expected_result, allow_duplicate_keys=True)

    expected_result = {u'foo': u'bar'}
    test(value, expected_result, allow_duplicate_keys=False)

    expected_result = {u'foo': u'baz'}
    test(value, expected_result, allow_duplicate_keys='warn')
