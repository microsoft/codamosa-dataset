

# Generated at 2022-06-23 05:21:44.432773
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    a = AnsibleConstructor("test_ansible_constructor.yml")
    b = a.construct_yaml_map("test_ansible_constructor.yml")
    c = AnsibleConstructor("test_ansible_constructor.yml")
    d = c.construct_yaml_map("test_ansible_constructor.yml")
    print(a)
    print(b)
    print(c)
    print(d)
    print(a == c)
    print(b == d)
    print(a == d)
    print(b == c)


if __name__ == '__main__':
    test_AnsibleConstructor()

# Generated at 2022-06-23 05:21:53.962919
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # test the method with valid data
    constructor = AnsibleConstructor()
    node = "test"
    wrap_test = constructor.construct_yaml_unsafe(node)
    assert wrap_test == wrap_var("test")
    assert isinstance(wrap_test, unicode)
    assert wrap_test == u"test"
    assert type(wrap_test) == unicode

    # test the method with invalid data
    constructor = AnsibleConstructor()
    node = None
    wrap_test = constructor.construct_yaml_unsafe(node)
    assert wrap_test == wrap_var(None)
    assert isinstance(wrap_test, unicode)
    assert wrap_test == u"None"
    assert type(wrap_test) == unicode

# Generated at 2022-06-23 05:21:58.956288
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = u'\u00e9'
    ansible_constructor = AnsibleConstructor()
    assert isinstance(ansible_constructor.construct_yaml_str(node), AnsibleUnicode)
    assert node == ansible_constructor.construct_yaml_str(node)

# Generated at 2022-06-23 05:22:09.763964
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import unittest
    import sys
    import os

    class TestBase(unittest.TestCase):

        def setUp(self):
            self.currdir = os.path.join(os.getcwd(), os.path.dirname(__file__))
            fh = open(os.path.join(self.currdir, 'yaml_constructor.yml'), 'r')
            self.data = fh.read()
            fh.close()

    class TestAnsibleConstructor(TestBase):

        def test_construct(self):
            from ansible.errors import AnsibleParserError
            from ansible.parsing.dataloader import DataLoader
            from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

            loader = DataLoader()
           

# Generated at 2022-06-23 05:22:20.513443
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import sys
    try:
        from yaml import CSafeLoader as Loader, CSafeDumper as Dumper
    except ImportError:
        from yaml import SafeLoader as Loader, SafeDumper as Dumper

    data = """\
key: !unsafe !!python/unicode 'I am string'
key2: !unsafe !!python/unicode 'I am string'
"""

    data2 = """\
key: I am string
key2: I am string
"""
    old_stdout = sys.stdout
    string_io = StringIO()
    sys.stdout = string_io

# Generated at 2022-06-23 05:22:29.295381
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib

    # Encrypt our password
    vault = VaultLib()
    vault_pass = 'mypass'
    vault.secrets = [vault_pass]
    text = vault.encrypt('mysecret')
    constructor = AnsibleConstructor()
    constructor.vault_secrets = ['mypass']
    node = constructor.construct_yaml_str(None)
    result = constructor.construct_yaml_unsafe(node)
    assert constructor.vault_secrets == ['mypass']
    assert result._decrypted_text == 'mysecret'

# Generated at 2022-06-23 05:22:30.040215
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-23 05:22:41.557388
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import textwrap

    # Given a string with yaml format
    yaml_str = textwrap.dedent('''
    ---
      - name: 'this is a test'
        value: "{{ test_val }}"
    ''').strip()

    # when create a constructor of class AnsibleConstructor
    constructor = AnsibleConstructor()

    # then the constructor can construct an AnsibleMapping,
    # AnsibleUnicode or AnsibleVaultEncryptedUnicode
    result = constructor.construct_yaml_map(constructor.construct_document(yaml_str)[0])
    assert isinstance(result, AnsibleMapping)

    result = constructor.construct_yaml_seq(constructor.construct_document(yaml_str)[0])

# Generated at 2022-06-23 05:22:53.882387
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from sys import version_info

    if version_info.major == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    class Test(object):
        pass

    obj = Test()
    obj.test = 42
    obj.attr = 'attr'
    obj.method = lambda x: x * 2
    obj.int_method = lambda: 42

    yaml_str = '!unsafe %s' % obj

    yaml_obj = yaml.load(StringIO(yaml_str), Loader=AnsibleLoader)

    assert isinstance(yaml_obj, AnsibleUnsafeText)
    assert yaml_obj.value is obj
    assert yaml_obj.stdout is yaml_obj

# Generated at 2022-06-23 05:23:01.881057
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(dir='/tmp', prefix='unsafe_test_') as f:
        fname = f.name
        f.write(b'---\nfoo: !unsafe "V3RS10N"')
        f.flush()
        os.fsync(f.fileno())
        with open(fname) as f:
            yaml_data = f.read()
        ac = AnsibleConstructor()
        yaml_obj = ac.construct_yaml(yaml_data)
        assert yaml_obj == {'foo': 'V3RS10N'}

# Generated at 2022-06-23 05:23:09.194502
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import yaml

    try:
        from yaml import CLoader as Loader, CDumper as Dumper
    except ImportError:
        from yaml import Loader, Dumper

    data = """
a:
  b: 12
  c:
    - "d"
    - "e"
    - "f"
    - "12"
    - "g"
"""

    obj = yaml.load(data, Loader=Loader)
    assert obj['a']['c'][3] == "12"

    assert 'ansible_pos' in obj
    assert obj['ansible_pos'] == ('<string>', 1, 1)

    assert 'ansible_pos' in obj['a']
    assert obj['a']['ansible_pos'] == ('<string>', 2, 1)

# Generated at 2022-06-23 05:23:13.290584
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    test_data = 'foo: !nonesuch "bar"'
    test_obj = yaml.load(test_data, Loader=AnsibleConstructor)
    assert test_obj == {u'foo': None}

# Generated at 2022-06-23 05:23:18.674417
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test case 1
    test_data = ['foo', 'bar', 'baz', 'boo']
    result = AnsibleConstructor.construct_yaml_seq(test_data)
    assert result == [(AnsibleSequence(['foo', 'bar', 'baz', 'boo'])),
                          {'ansible_pos': None}]


# Generated at 2022-06-23 05:23:23.708740
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node_map = {'age': '50', 'name': 'John Smith'}
    data = {}
    for key_node, value_node in node_map.items():
        key = AnsibleUnicode(key_node)
        value = AnsibleUnicode(value_node)
        data[key] = value
    assert data



# Generated at 2022-06-23 05:23:32.750492
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import ScalarNode
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Setup fixture
    class TestAnsibleConstructor(AnsibleConstructor):
        def _node_position_info(self, node):
            return ('test', 0, 0)

    class TestAnsibleYamlObject(AnsibleBaseYAMLObject):
        yaml_loader = TestAnsibleConstructor

    class TestDummyNode(object):
        id = 'map'
        start_mark = None


# Generated at 2022-06-23 05:23:42.636787
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
              start_mark=None, end_mark=None, flow_style=None)
    mapping = AnsibleConstructor(file_name='test1', vault_secrets=None).construct_mapping(node=node)
    assert isinstance(mapping, AnsibleMapping) and mapping.ansible_pos == ('test1', 1, 1)

    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
              start_mark=None, end_mark=None, flow_style=None)
    with Display().on():
        mapping = AnsibleConstructor(file_name='test2', vault_secrets=None).construct_mapping(node=node)

# Generated at 2022-06-23 05:23:48.417733
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    '''
    class AnsibleConstructor
      func construct_yaml_map
      func construct_mapping
      func construct_yaml_str
      func construct_vault_encrypted_unicode
      func construct_yaml_seq
      func construct_yaml_unsafe
      func _node_position_info
    '''

    # TODO(zqfan): Need unittest for AnsibleConstructor
    assert True

# Generated at 2022-06-23 05:23:52.967616
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = ['foo']
    encrypted = ansible_constructor.construct_scalar('123')
    expected = b'123'
    assert encrypted == expected

# Generated at 2022-06-23 05:23:55.852771
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor()
    ret = c.construct_mapping({"key1": "value1"})
    assert isinstance(ret, AnsibleMapping)

# Generated at 2022-06-23 05:23:56.576045
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    pass

# Generated at 2022-06-23 05:24:08.710953
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test case #1: yaml document with vault-encrypted string

# Generated at 2022-06-23 05:24:13.933292
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_input = """
    a:
     - 1
     - 2
     - 3
    b:
     - 4
     - 5
     - 6
    """

    yaml_obj = yaml.load(yaml_input, AnsibleConstructor)
    assert yaml_obj == {u'a': [1, 2, 3], u'b': [4, 5, 6]}

# Generated at 2022-06-23 05:24:21.156899
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create an instance of AnsibleConstructor
    ansible_constructor = AnsibleConstructor()

    # Create a mapping node for testing
    mapping_node = MappingNode(u'tag:yaml.org,2002:map', [], None, None, None)

    # Create a mapping object to used in testing construct_yaml_map
    mapping = {}

    # Call construct_yaml_map
    mapping_returned = ansible_constructor.construct_yaml_map(mapping_node)

    # Test whether construct_yaml_map return the expected value
    assert mapping == mapping_returned


# Generated at 2022-06-23 05:24:29.859041
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    constructor = AnsibleConstructor()
    node1 = SafeConstructor()
    node1.construct_sequence = lambda node: [1,2]
    node2 = SafeConstructor()
    node2.iterencode = lambda: [3]
    data = constructor.construct_yaml_seq(node1)
    assert isinstance(data, ansible.parsing.yaml.objects.AnsibleSequence)
    assert data == [1, 2]
    data = constructor.construct_yaml_seq(node2)
    assert isinstance(data, ansible.parsing.yaml.objects.AnsibleSequence)
    assert data == [3]

# Generated at 2022-06-23 05:24:40.874174
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    loader = AnsibleConstructor()
    import yaml
    yml_test = """
    ---
    this is a test:
        - is:
            - a
            - b
    ...
    """

    result = yaml.load(yml_test, loader=loader)
    assert isinstance(result, dict)
    assert isinstance(result, AnsibleMapping)
    assert isinstance(result['this is a test'], list)
    assert isinstance(result['this is a test'], AnsibleSequence)
    for item in result['this is a test']:
        assert isinstance(item, dict)
        assert isinstance(item, AnsibleMapping)
        assert isinstance(item['is'], list)
        assert isinstance(item['is'], AnsibleSequence)

# Generated at 2022-06-23 05:24:50.991863
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    a = AnsibleConstructor(None)
    b = yaml.composer.Composer(yaml.parser.Parser(a), yaml.resolver.Resolver())
    b.loadOneEvent()

    # Use an empty mapping node because the node class is not public
    node = yaml.nodes.MappingNode('tag:yaml.org,2002:str', [])
    assert isinstance(a.construct_yaml_str(node), AnsibleUnicode)

    b.loadOneEvent()
    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'a')
    assert isinstance(a.construct_yaml_str(node), AnsibleUnicode)


# Generated at 2022-06-23 05:25:01.424421
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    # Test without filename
    value = 'test\n'
    node = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', value, (None, None), (None, None))
    constructor = AnsibleConstructor()
    obj = constructor.construct_yaml_str(node)

    assert isinstance(obj, AnsibleUnicode)
    assert obj == value
    assert obj.ansible_pos == ('<unicode string>', 1, 0)

    # Test with filename
    filename = 'test.yml'
    node = yaml.nodes.ScalarNode(u'tag:yaml.org,2002:str', value, (None, None), (None, None))
    constructor = AnsibleConstructor(filename)
    obj = constructor.construct_

# Generated at 2022-06-23 05:25:11.810891
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test when node has end_mark
    data = AnsibleUnicode('test')
    node = yaml.nodes.scalarstring(u'test',u'test', 1, 2, 3, 4, None)
    node.end_mark = yaml.nodes.Mark('',2, 3, None, None, None)
    yaml_str = AnsibleConstructor()
    ret = yaml_str.construct_yaml_str(node)
    assert ret == data, "%s != %s" %(ret, data)

    # Test when node doesn't have end_mark
    data = AnsibleUnicode('test')
    node = yaml.nodes.scalarstring(u'test',u'test', 1, 2, 3, None)
    yaml_str = AnsibleConstructor()
   

# Generated at 2022-06-23 05:25:21.840306
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import ansible.parsing.yaml.loader

    ansible_constructor = AnsibleConstructor()

    # create node

# Generated at 2022-06-23 05:25:32.229448
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import os
    import sys
    import pytest

    from ansible.module_utils.six import BytesIO
    from ansible.plugins import module_loader
    from ansible.parsing.yaml import load

    ansible_constructor = AnsibleConstructor()
    assert isinstance(ansible_constructor, ansible_constructor.__class__)
    assert isinstance(ansible_constructor, SafeConstructor)

    # to test the ability to construct_safe_mapping

# Generated at 2022-06-23 05:25:36.056191
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert isinstance(AnsibleConstructor().construct_yaml_str(None), AnsibleUnicode)



# Generated at 2022-06-23 05:25:46.081966
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    # ansible_constuctor_test contains a number of test cases written
    # in the form of pairs of yaml documents, where the first document
    # is the input to the SafeConstructor and the second document is
    # the expected output of the SafeConstructor
    import ansible_constuctor_test
    import yaml

    # iterate through all the test cases and compare the output
    # of the SafeConstructor to the expected output.
    for test in ansible_constuctor_test.test_unsafe_yaml_constructor:
        # use the SafeConstructor to load the test input
        # and then compare the result to the expected output
        yaml_test_input = yaml.load(test[0], AnsibleConstructor)

# Generated at 2022-06-23 05:25:55.527938
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import custom_constructor
    # =========================================================================
    # WARNING: This test is specifically for the method construct_yaml_map of
    # the class AnsibleConstructor.
    # If the method is ever moved to or replaced by another class, this test
    # will not work.
    # A message will be printed to let you know that the test is skipped.
    # =========================================================================
    import inspect
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # The lines below are for checking that all classes inherit from the right
    # parent class.

# Generated at 2022-06-23 05:26:07.386183
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner

    class Event:
        def __init__(self, value=None, implicit=None, tag=None, start_mark=None,
                     end_mark=None, comment=None, anchor=None):
            self.value = value
            self.implicit = implicit
            self.tag = tag
            self.start_mark = start_mark
            self.end_mark = end_mark
            self.comment = comment
            self.anchor = anchor

    def construct_init():
        """
        Create a new instance of the AnsibleConstructor class, as if it was just returned from a yaml.load() call.
        """

# Generated at 2022-06-23 05:26:12.689780
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class TestAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            return self.construct_scalar(node)
    node = "vaulted string"
    result = TestAnsibleConstructor().construct_vault_encrypted_unicode(node)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:26:14.062030
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
	pass


# Generated at 2022-06-23 05:26:18.714439
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    a = AnsibleConstructor()

    s = a.construct_yaml_str(AnsibleDumper().represent_str(u'Ansible', u'!str'))
    assert isinstance(s, AnsibleUnicode)

# Generated at 2022-06-23 05:26:26.664564
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    import os
    import binascii
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import ConstructorError
    from ansible.utils.unsafe_proxy import wrap_var

    class RawTest(unittest.TestCase):

        def setUp(self):
            self.secret_password = os.urandom(16)
            self.plaintext_string = u"test"
            self.plaintext_bytes = b"test"

        def _encrypt_string(self, plaintext_string=None):
            self.assertIsInstance(plaintext_string, str)
            vault = VaultLib(self.secret_password)
            return vault.encrypt(plaintext_string)


# Generated at 2022-06-23 05:26:34.285559
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['pass']
    ciphertext_data = VaultLib(secrets=vault_secrets).encrypt('test')
    display.display(ciphertext_data)
    data = '{0}\n'.format(ciphertext_data)
    data = to_bytes(data)
    import yaml
    from yaml.constructor import ConstructorError

    try:
        yaml.load(data, Loader=AnsibleConstructor)
    except ConstructorError as ex:
        display.display(ex)
        assert False == True


# Generated at 2022-06-23 05:26:34.909235
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert AnsibleConstructor

# Generated at 2022-06-23 05:26:44.551531
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_data = """
    ---
    {
        a: 1
    }
    """

    # When deep is false
    am = AnsibleConstructor(file_name='none').construct_mapping(yaml_data)
    assert isinstance(am, AnsibleMapping)
    assert am['a'] == 1

    # When deep is true
    am = AnsibleConstructor(file_name='none').construct_mapping(yaml_data, deep=True)
    assert isinstance(am, AnsibleMapping)
    assert am['a'] == 1



# Generated at 2022-06-23 05:26:54.984889
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    raw_data = dict(a='{{ 1 + 1 }}', b='{{ 2 + 2 }}', c='{{ 3 + 3 }}')
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(raw_data.items(), AnsibleConstructor)
    data = loader.get_single_data()

    assert isinstance(data.get('a'), AnsibleUnicode)
    assert data.get('a') == u"{{ 1 + 1 }}"
    assert str(data.get('a')) == "{{ 1 + 1 }}"

    assert isinstance(data.get('b'), AnsibleUnicode)
    assert data.get('b') == u"{{ 2 + 2 }}"
    assert str(data.get('b')) == "{{ 2 + 2 }}"

# Generated at 2022-06-23 05:26:59.497912
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from nose.tools import assert_equal

    constructor = AnsibleConstructor()
    constructor.construct_scalar = lambda x: 'foo'
    ret = constructor.construct_yaml_str(None)
    assert_equal(ret.__class__, AnsibleUnicode)
    assert_equal(ret, u'foo')



# Generated at 2022-06-23 05:27:02.964032
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    data = "hello"
    node = AnsibleConstructor.construct_yaml_str(ac, node=data)
    assert node == AnsibleUnicode("hello")

# Generated at 2022-06-23 05:27:09.611023
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml
    import re


# Generated at 2022-06-23 05:27:13.595498
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    input = u'!unsafe "&foo"'
    data = yaml.load(input, Loader=AnsibleConstructor)
    assert data == u'&foo'
    assert 'AnsibleUnsafeText' in str(type(data))

# Generated at 2022-06-23 05:27:24.395819
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-23 05:27:35.375486
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    class AnsibleConstructor(SafeConstructor):
        def construct_vault_encrypted_unicode(self, node):
            value = self.construct_scalar(node)
            b_ciphertext_data = to_bytes(value)
            # could pass in a key id here to choose the vault to associate with
            vault = VaultLib()
            if not vault.secrets:
                raise ConstructorError(context=None, context_mark=None,
                                       problem="found !vault but no vault password provided",
                                       problem_mark=node.start_mark,
                                       note=None)
            ret = AnsibleVaultEncryptedUnsafeUnicode(b_ciphertext_data)
            ret.vault = vault
            return ret


# Generated at 2022-06-23 05:27:46.432257
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.vault import VaultSecret

    # All valid data structures should be parsed and successfully turned into
    # an AnsibleMap object.

# Generated at 2022-06-23 05:27:51.703982
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'test')
    ansible_constructor = AnsibleConstructor(file_name='file')
    result = ansible_constructor.construct_yaml_str(node)
    assert result == u'test'



# Generated at 2022-06-23 05:28:02.745222
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import load
    import sys
    import io

    if sys.version_info < (3,):
        test_yaml_unicode_data = "s\xf8ren"
    else:
        test_yaml_unicode_data = "søren"

    test_yaml = """
# sample yaml with unicode values
one:
    two: %s
    three: 3
""" % test_yaml_unicode_data

    test_yaml_stream = io.StringIO(test_yaml)
    data1 = load(test_yaml_stream, Loader=AnsibleConstructor)
    assert isinstance(data1, dict)
    assert data1.get('one').get('two') == test_yaml_unicode_data

    data2 = load(test_yaml)

# Generated at 2022-06-23 05:28:07.174721
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    c = AnsibleConstructor()
    for x in c.construct_yaml_seq(node):
        assert x

# Generated at 2022-06-23 05:28:11.022104
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = '''
foo: bar
baz:
  - name: qux
    value: quux
'''
    res = yaml.safe_load(data)

    assert res['baz'][0]['value'] == 'quux'



# Generated at 2022-06-23 05:28:17.986159
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    c = AnsibleConstructor()
    ansible = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n31376630313461316162323239343262626134303965393164356666656630636361326565336\n353266626439666533353039653438396161643064646166393336353332313266656432623163\n383864383335396631643465313962333965303231386566356538326361383365356434393764\n31383037646439343664373831313566\n")

# Generated at 2022-06-23 05:28:25.140982
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ac = AnsibleConstructor()
    d = ac.construct_mapping([(u'key1', 'val1'), ('key2', 'val2')])
    assert d == {u'key1': 'val1', 'key2': 'val2'}

    d = ac.construct_mapping([(u'key1', 'val1'), (u'key1', 'val2')])
    assert d == {u'key1': 'val2'}, "Expect the last value for 'key1' to be used"

# Generated at 2022-06-23 05:28:33.177670
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # test warnings
    # 'warn' is the default, but set it explicitly
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    with open('test_data/yaml_duplicate_dict_key_warn.yml', 'r') as f:
        try:
            AnsibleConstructor().construct_mapping(yaml.compose(f.read()))
        except ConstructorError as e:
            assert False, ('AnsibleConstructor should not have '
                           'thrown a ConstructorError')

    # test errors
    C.DUPLICATE_YAML_DICT_KEY = 'error'

# Generated at 2022-06-23 05:28:43.487447
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    import yaml

    x = AnsibleConstructor(vault_secrets=[{'encryption_key': "foo"}])
    x.add_multi_constructor(u'tag:yaml.org,2002:str', x.construct_yaml_str)
    x.add_multi_constructor(u'!vault', x.construct_vault_encrypted_unicode)
    y = x.construct_yaml_map(yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', [], [], []))
    # manual swap of values
    # test

# Generated at 2022-06-23 05:28:55.224652
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    constructor_sample = {'a': 10, 'b': [1, 2, 3], 'c': {'1': '2', '2': '3'}, 'd': 'dict'}
    constructor_AnsibleConstructor = AnsibleConstructor()
    assert constructor_AnsibleConstructor.construct_yaml_map(constructor_sample) == constructor_sample
    assert constructor_AnsibleConstructor.construct_mapping(constructor_sample) == constructor_sample
    assert constructor_AnsibleConstructor.construct_yaml_str(constructor_sample) == constructor_sample
    assert constructor_AnsibleConstructor.construct_yaml_seq(constructor_sample) == constructor_sample
    assert constructor_AnsibleConstructor.construct_yaml_unsafe(constructor_sample) == constructor_sample
    assert constructor_

# Generated at 2022-06-23 05:29:04.638393
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = '''
welcome: hello world!
hosts:
  - 192.168.1.1
  - 192.169.1.2
'''

    from yaml import BaseLoader, load_all
    import yaml
    yaml_data = load_all(yaml_str, Loader=BaseLoader)
    for yaml_node in yaml_data:
        ac = AnsibleConstructor()
        # Test for yaml.MappingNode
        ansible_data = ac.construct_mapping(yaml_node)
        assert type(ansible_data) == AnsibleMapping
        position = getattr(ansible_data, 'ansible_pos', None)
        assert type(position) == tuple
        assert position[0] is None
        assert position[1] == 1
        assert position

# Generated at 2022-06-23 05:29:05.752433
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    assert AnsibleConstructor.construct_yaml_unsafe(None) is None

# Generated at 2022-06-23 05:29:13.845000
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    nodes = [1,2,3]
    # Construct a node that is a list of python integers
    node = {'tag':'tag:yaml.org,2002:seq', 'value':nodes}
    
    yaml = AnsibleConstructor()
    # Construct a data structure that contains the integers 1,2,3
    data = yaml.construct_yaml_seq(node)
    # The data structure is a generator which can only be iterated once
    array = []
    for item in data:
        array.append(item)
    # The array contains an object with the expected integers
    assert set(array[0]) == set(nodes)

# Generated at 2022-06-23 05:29:24.169149
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os

    print(sys.executable)
    print(os.path.dirname(sys.executable))

    import yaml
    yaml.AnsibleConstructor = AnsibleConstructor


# Generated at 2022-06-23 05:29:34.432585
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import yaml

    # -------------------------------------------------------------------
    # Test AnsibleMapping
    str1 = '''
a: 1
b:
  c: 3
'''

    str2 = '''
a: 1
a: 2
b:
  c: 3
'''

    print('---TEST ANSIBLE MAPPING---')
    print('---')
    print(yaml.dump(yaml.load(str1, Loader=AnsibleConstructor), default_flow_style=False, encoding='utf-8'))
    print('---')
    print(yaml.dump(yaml.load(str2, Loader=AnsibleConstructor), default_flow_style=False, encoding='utf-8'))
    print('---')

    # -------------------------------------------------------------------
    # Test AnsibleSequence
   

# Generated at 2022-06-23 05:29:44.120435
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    from ansible.parsing.vault import VaultLib
    from ansible import constants as C

    vault_password = '$2a$06$.3qY5M6Yi4xE4Geb4yho8u.iB4atrGaX9d/zrZ8IFYowlNKNnu/Ty2'
    vault = VaultLib(vault_password)

    # Only show on ansible-log
    # vault.ansible_log = 'yaml.log'

    my_vars = {
        'a': 'foo',
        'b': 'bar',
        'c': [1, 2, 3],
        'd': {
            'aa': 'foo',
            'bb': [1, 2, 3],
            'cc': 'bar',
        }
    }

    my_v

# Generated at 2022-06-23 05:29:50.709120
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str1 = '''
    a: b
    b: c
    '''

    yaml_str2 = '''
    {a: b, b: c}
    '''

    obj1 = yaml.load(yaml_str1, Loader=AnsibleConstructor)
    obj2 = yaml.load(yaml_str2, Loader=AnsibleConstructor)
    assert obj1 == obj2
    assert type(obj1) == AnsibleMapping

# Generated at 2022-06-23 05:29:58.505885
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import yaml

    C = AnsibleConstructor(file_name="file.yml")
    d = yaml.load(u'foo_bar: hello world', Loader=C)
    assert isinstance(d['foo_bar'], AnsibleUnicode)
    assert d['foo_bar'] == u'hello world'
    assert d['foo_bar'].ansible_pos == ("file.yml", 1, 10)



# Generated at 2022-06-23 05:30:07.089339
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = ansible_constructor.construct_yaml_map(MappingNode(node_id=None, tag=None, value=[], start_mark=None, end_mark=None))
    assert type(ansible_mapping) is AnsibleMapping
    # No check for the value of parameter ansible_pos is done because there is no way to create a MappingNode without
    # setting its attributes start_mark and end_mark.
    assert type(ansible_mapping.ansible_pos) is tuple
    assert len(ansible_mapping.ansible_pos) == 3

# Generated at 2022-06-23 05:30:16.639671
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible_collections.michael.dehaan.the_michael_dehaan_collection.plugins.module_utils.misc.textformatters import FormattedItem
    import yaml

    # the purpose of this test is to make sure that the
    # logic in AnsibleConstructor.construct_yaml_map is kept
    # in sync with the logic in AnsibleConstructor.construct_mapping
    # since they're duplicated, we have to make sure they're kept in sync


# Generated at 2022-06-23 05:30:25.292797
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:30:35.192719
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    import copy
    import sys

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    a_map = [u'name:', u' Duplicate Key']
    good_map = [u'name:', u' Duplicate Key', u'key:', u' value']
    bad_map = [u'key1:', u' value', u'key1:', u' other value']

    out = StringIO()
    sys.stdout = out

    ac = AnsibleConstructor()
    res = ac.construct_mapping(Node(a_map))

    assert res == {u'name': u' Duplicate Key'}

    res = ac.construct_mapping(Node(good_map))

# Generated at 2022-06-23 05:30:47.426512
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    from yaml.compat import ordereddict as OD
    import yaml

    # test for basic sequence value
    value = sequence_value = [0, 1, 2, 3, 4, 5]
    node = SequenceNode("tag:yaml.org,2002:seq", value)

    assert isinstance(value, list) is True
    assert isinstance(node, SequenceNode) is True

    # test for invalid value
    invalid_node = OD([(1,2), (3,4)])
    with pytest.raises(AssertionError):
        test = AnsibleConstructor.construct_yaml_seq(invalid_node)

    # test for invalid node
    with pytest.raises(AssertionError):
        test = AnsibleConstructor.construct_yaml_seq

# Generated at 2022-06-23 05:30:51.440169
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """It parses a list."""
    yaml_str = '''- 1
- 2
- 3
- 4
- 5'''
    yaml_list = list(yaml.load_all(yaml_str, Loader=AnsibleLoader))
    assert [1, 2, 3, 4, 5] == yaml_list[0]

# Generated at 2022-06-23 05:31:03.404698
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = """
        - hawaii:
            Honolulu
        - utah:
            Salt Lake City
    """
    errors = []
    file_name = '<string>'
    vault_secrets = []
    ansible_constructor = AnsibleConstructor(file_name, vault_secrets)
    data = ansible_constructor.construct_yaml_map(yaml_str)

    if isinstance(data, AnsibleMapping) == False:
        errors.append('construct_yaml_map method should return an AnsibleMapping object')
    if data['hawaii'] != 'Honolulu':
        errors.append('Expected value of "hawaii" key is "Honolulu" but found {0}'.format(data['hawaii']))

# Generated at 2022-06-23 05:31:14.491762
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import unittest
    import yaml
    import os
    import sys

    # AnsibleConstructor.construct_yaml_seq() assumes that the input stream is a list of objects.
    # It aggregates the list of objects and returns the results as an AnsibleSequence.
    #
    # The following method is a simple test for AnsibleConstructor.construct_yaml_seq().
    # It takes a list of objects as input and returns the result of
    # AnsibleConstructor.construct_yaml_seq() as output.

    def tester(inp):
      import yaml
      from io import StringIO
      from ansible.parsing.yaml.objects import AnsibleConstructor
      yaml_str = yaml.dump(inp)
      yaml_fp = StringIO(yaml_str)

# Generated at 2022-06-23 05:31:20.462572
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode
    from collections import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    str_stream = StringIO(u"key1: value1\nkey2: value2\n")
    ans_yaml_loader = AnsibleLoader(str_stream, file_name="<string>")
    node = ans_yaml_loader.get_single_data()
    assert isinstance(node, MappingNode)
    assert node.id == u'tag:yaml.org,2002:map'
    yaml_obj = AnsibleConstructor.construct_yaml_map(AnsibleConstructor(), node)
    assert isinstance

# Generated at 2022-06-23 05:31:21.072734
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-23 05:31:31.619924
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml

    yaml_text = '''
ansible_facts:
  key1:
    - a
    - b
  key2:
    - a
    - b
  key3:
    - a
    - b
'''
    yaml_text_duplicate_keys = '''
ansible_facts:
  key1:
    - a
    - b
  key1:
    - a
    - b
'''

    # run test without duplicate keys (should pass)
    data = yaml.load(yaml_text, Loader=AnsibleConstructor)
    assert type(data) is dict
    assert 'ansible_facts' in data

    # run test with duplicate keys (should fail)

# Generated at 2022-06-23 05:31:35.841950
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Instantiate object of AnsibleConstructor class
    ansible_constructor = AnsibleConstructor()

    # Tests whether the construct_yaml_map method is returning proper mapping data
    assert ansible_constructor.construct_yaml_map(
        {'key': 'value'}) == {'key': 'value'}