

# Generated at 2022-06-23 05:21:44.004262
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import re
    from ansible.parsing.yaml.loader import AnsibleLoader

    # First test against a duplicate dict key
    test_file_name = None
    test_data = '''
    key: value
    key: other
    '''
    test_data = to_bytes(test_data)

    loader = AnsibleLoader(test_data, file_name=test_file_name, vault_secrets=None)
    data = loader.get_single_data()
    assert(data == dict(key='other'))

    # Now test against duplicate keys at different levels in the hierarchy
    test_data = '''
    key: value
    key2:
      key: other
    '''
    test_data = to_bytes(test_data)


# Generated at 2022-06-23 05:21:52.410230
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.unsafe_proxy import wrap_var

    ac = AnsibleConstructor()

    if PY3:
        assert ac.construct_yaml_unsafe(AnsibleDumper.represent_None(None)) is None
        assert ac.construct_yaml_unsafe(AnsibleDumper.represent_bool(True)) is True
        assert ac.construct_yaml_unsafe(AnsibleDumper.represent_int(42)) == 42
    else:
        assert ac.construct_yaml_unsafe(AnsibleDumper.represent_None(None)) is None

# Generated at 2022-06-23 05:22:03.703902
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import unittest
    import yaml

    from ansible.module_utils.six import StringIO

    from ansible.utils.unsafe_proxy import wrap_var, AnsibleUnsafeText

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None
            self.old_stdout = sys.stdout
            self.out = sys.stdout = StringIO()

        def tearDown(self):
            sys.stdout = self.old_stdout


# Generated at 2022-06-23 05:22:11.861130
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    display.display('Testing match: construct_yaml_str')

    # Test 1
    # Setup
    display.display('Test 1 setup')
    my_ansible_constructor = AnsibleConstructor()

    display.display('Test 1 input')
    my_node = u'tag:yaml.org,2002:str'

    display.display('Test 1 expect')
    my_node_expect = u'tag:yaml.org,2002:unicode'

    # Test
    display.display('Test 1')
    my_result = my_ansible_constructor.construct_yaml_str(my_node)
    if my_result != my_node_expect:
        display.display('Test 1 failed')
        display.display('Test 1 result')
        display.display(my_result)

# Generated at 2022-06-23 05:22:21.167676
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import unittest
    # Retrieve the code object representing the body of the constructor
    # for the vault-encrypted tags
    func_obj = AnsibleConstructor.construct_vault_encrypted_unicode.__code__
    # Create a mock vault object and insert it into the local symbol table
    mock_vault = unittest.mock.MagicMock()
    mock_vault.decrypted = True
    # This class is defined within the AnsibleConstructor class itself,
    # so we must access the class object directly to insert the mock vault
    # object into the local symbol table of the class
    AnsibleConstructor._AnsibleConstructor__vaults['default'] = mock_vault
    # Execute the constructor method
    func_obj.__globals__['self'].construct_vault_encrypted_unic

# Generated at 2022-06-23 05:22:32.085947
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [b'$ANSIBLE_VAULT;1.1;AES256\n6333616439353336313533366436356635313536343335623634323961613564373263366665\n3936373464333635363435313132313365326566656235393137356431633337643166636432\n3737646532306437303165376532646563343038353937336262636563336164393533363135\n3336643635663531353634333562363432396161356437326336666539363734643336353634\n3531313231336532656665623539313735643163333764316663643237623035\n']
    vault_

# Generated at 2022-06-23 05:22:39.653235
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from os import path
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
        foo: !unsafe
          - shell: "echo 'hello'"
          - raw: echo 'hi'
    '''
    loader = AnsibleLoader(data, file_name='<test>')
    for node in loader:
        print(node)

if __name__ == '__main__':
    test_AnsibleConstructor_construct_yaml_unsafe()

# Generated at 2022-06-23 05:22:50.405989
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import types
    import re

    import ansible.parsing.yaml.loader as y_l

    yaml_fact='''---
a: !unsafe 1
b: !unsafe
    - 1
    - 2
    - 3
c: !unsafe
    d: 1
    e: 2
'''
    loader = y_l.UnsafeLoader
    data = loader.get_single_data(yaml_fact)
    assert type(data) is AnsibleMapping
    assert type(data["a"]) is types.IntType
    assert type(data["b"]) is AnsibleSequence
    assert type(data["c"]) is AnsibleUnsafeText

    # Now for a trickier example

    # data["c"] should now be a string, which is good so that it can
    # be passed

# Generated at 2022-06-23 05:22:51.852460
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor()
    assert a.construct_yaml_map()

# Generated at 2022-06-23 05:23:00.441203
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.utils.yaml import from_yaml

    fixture = """
foo:
  bar:
    - abc
    - def
    - 123
    - 456
  baz:
    - abc
    - def
bar:
  foo:
    - abc
    - def
    - 123
    - 456
  baz:
    - abc
    - def
"""

    constructor = AnsibleConstructor()
    data = from_yaml(fixture, string_to_bytes=True, constructor=constructor)
    assert data == yaml.safe_load(fixture)
    assert data.ansible_pos == (u'<unicode>', 2, 0)

# Generated at 2022-06-23 05:23:11.865124
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    old_value_DUPLICATE_YAML_DICT_KEY = C.DUPLICATE_YAML_DICT_KEY

# Generated at 2022-06-23 05:23:22.737747
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    """Constructor test."""
    from ansible.parsing.yaml.data import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_secret = "password"

# Generated at 2022-06-23 05:23:28.567324
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode('tag:yaml.org,2002:map', [], [0, 0], False)
    node.value = [(1,2), (3,4)]
    m = AnsibleConstructor().construct_mapping(node)
    assert m == {1: 2, 3: 4}

# Generated at 2022-06-23 05:23:32.125170
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    yaml.load("""
    # Example from YAML spec
    - Hesperiidae
    - Papilionidae
    - Apollo
    """, AnsibleConstructor)


# Generated at 2022-06-23 05:23:36.223491
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    c = AnsibleConstructor()
    mock_node = type('mock_node', (object,), {
        # TODO: test all the parameter of the node
    })()
    assert c.construct_yaml_unsafe(mock_node) is mock_node



# Generated at 2022-06-23 05:23:45.066654
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleError
    config_manager = ConfigManager()
    vault_passwords = [u'secret']
    config_manager.set_value('defaults', 'vault_password', vault_passwords, origin=u"unit test")
    config_manager.set_value('defaults', 'log_path', None, origin=u"unit test")
    config_manager.set_value('defaults', 'debug', 2, origin=u"unit test")
    config_manager.set_value('defaults', 'stdout_callback', u'yaml', origin=u"unit test")
    config_manager.set_value('defaults', 'bin_ansible_callbacks', False, origin=u"unit test")

# Generated at 2022-06-23 05:23:53.537489
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
        string_io = StringIO
    else:
        from StringIO import StringIO
        string_io = StringIO

    # Create a dict that contains unicode strings
    # Construct dict to string and reconstuct dict from string
    source_dict = {u'a': {u'b': u'c'}, u'd': u'e'}
    source_dict[u'f'] = source_dict[u'a']
    output = StringIO()
    AnsibleDumper(output, default_flow_style=False).dump(source_dict)
    result = output.getvalue()

    output2 = string_io()
    AnsibleDumper

# Generated at 2022-06-23 05:24:02.854717
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime

    obj = {"date": datetime.datetime.utcnow()}

    class PkgInfo(object):

        class metadata(object):
            # notice the name starts with an underscore
            # this is to mimic the metadata in pkg_resources
            # which has the same name but starts with an underscore
            def __init__(self, version):
                self._version = version

            def version(self):
                return self._version

    wrap_var(obj)
    result = wrap_var(PkgInfo.metadata(u"1.2.3"))

    assert isinstance(result, PkgInfo.metadata) is True
    assert result._version == u"1.2.3"


if __name__ == '__main__':
    import pytest
    pytest.main('-v')

# Generated at 2022-06-23 05:24:09.861645
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleMapping
    a = AnsibleConstructor()
    am = a.construct_yaml_map(MappingNode(tag='tag:yaml.org,2002:map', value=[], flow_style=True))
    assert isinstance(am, AnsibleMapping)
    assert isinstance(am, OrderedDict)
    assert am is not None

# Generated at 2022-06-23 05:24:20.889234
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import load
    from yaml.nodes import ScalarNode

    data = [
        # check unicode
        (u'Hallo', u'Hallo'),

        # check conversion of different encoding
        ('H\xc3\xa4llo', u'H\u00E4llo'),
    ]

    for test, result in data:
        # mock object (e.g. Unicode node)
        obj = ScalarNode('tag:yaml.org,2002:str', test)

        # create instance of AnsibleConstructor
        yaml_loader = AnsibleConstructor()

        # call method to test
        ansible_obj = yaml_loader.construct_yaml_str(obj)

        # check result
        assert isinstance(ansible_obj, AnsibleUnicode), "is AnsibleUnicode"


# Generated at 2022-06-23 05:24:30.800059
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with a basic mapping, checking to see if the method returns a dict
    test_node = MappingNode(tag=u'tag:yaml.org,2002:python/dict',
                            value=[],
                            start_mark=None,
                            end_mark=None)
    test_constructor = AnsibleConstructor()
    res = test_constructor.construct_mapping(test_node)
    assert isinstance(res, dict)

    # Test with a mapping that has duplicate keys, checking to see if the method returns a dict

# Generated at 2022-06-23 05:24:37.773589
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import nodes

    test_string = "test_string"
    filename = __file__
    
    c = AnsibleConstructor(file_name=filename)
    result = c.construct_yaml_str(nodes.ScalarNode(
        tag='tag:yaml.org,2002:str',
        value=test_string,
        start_mark=None,
        end_mark=None,
        style=None))

    assert result == test_string
    assert result.ansible_pos == (filename, None, None)

# Generated at 2022-06-23 05:24:48.251777
# Unit test for method construct_yaml_str of class AnsibleConstructor

# Generated at 2022-06-23 05:24:59.596310
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultLib

    vault_pass = '$ANSIBLE_VAULT;1.2;AES256;test'
    ciphertext = "!vault |\n  $ANSIBLE_VAULT;1.2;AES256;test\n  636261373961356436333234396533663836326439653038363461346137636538326461376330\n  636638663839386635643432333236393237356431313665643738356464343763346661616437\n  63313734656264643065636262636634333133373733393961"
    expected = u'foo bar'

    # Test encrypted string

# Generated at 2022-06-23 05:25:10.462271
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    # Test with multiple types of strings
    test_cases = [{'val': 'hello', 'expected_val': b'hello', 'expected_type': AnsibleUnicode},
                  {'val': 'hello\nworld', 'expected_val': b'hello\nworld', 'expected_type': AnsibleUnicode},
                  {'val': '"hello world"', 'expected_val': b'hello world', 'expected_type': AnsibleUnicode},
                  {'val': "'hello world'", 'expected_val': b'hello world', 'expected_type': AnsibleUnicode}]

    for test_case in test_cases:
        val = test_case['val']
        node = SafeConstructor.construct_scalar(val)
        ansible = AnsibleConstructor.construct_yaml_str(node)

# Generated at 2022-06-23 05:25:20.610533
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ac = AnsibleConstructor(vault_secrets=["secret"])
    test_node = SafeConstructor().get_yaml_document(b'!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  6262346130356639616232303630613436333132613561346132313331616564663937343332656330\n  30633937336431653135340a613535386165373833386565656338303466616663343661633936393035\n  653436393265616361316534306431656139333034623463380a\n')
    ret = ac.construct_vault_encrypted_unicode(test_node)

# Generated at 2022-06-23 05:25:31.843950
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    # The following line is needed to load the 'unsafe' tag.
    yaml.add_multi_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)

    # test that the value returned is wrapped as an unsafe value
    # In this test, the unsafe wrapper is AnsibleUnsafeText
    x = yaml.load("""
    - !unsafe |
      this is unsafe
      so don't trust it
    """, Loader=AnsibleConstructor)
    assert x == [u'this is unsafe\nso don\'t trust it\n']
    assert x[0].__class__.__name__ == 'AnsibleUnsafeText'

    # test that the unsafe wrapper, which may be ansible.utils.unsafe_proxy,
    # is retained even through a

# Generated at 2022-06-23 05:25:43.565861
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import yaml
    vault_password = 'secret'
    plaintext = 'to be encrypted'
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt(plaintext)
    escaped_ciphertext = ciphertext.replace('\n', '\\n')
    yaml_doc = """
    foo: !vault |
        %s
    """ % escaped_ciphertext
    ansible_constructor = AnsibleConstructor(vault_secrets=[vault_password])
    yaml_dict = yaml.load(yaml_doc, Loader=yaml.SafeLoader)
    assert yaml_dict['foo'].vault == vault
    assert yaml_dict['foo'] == plaintext
    # test for alias !vault-encrypted
    yaml

# Generated at 2022-06-23 05:25:46.833329
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    str_obj = AnsibleConstructor().construct_yaml_str(None)
    assert isinstance(str_obj, AnsibleUnicode)



# Generated at 2022-06-23 05:25:55.802217
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Note:
    #   Since this is a class based unit test, the following code is not
    #   compatible with Ansible.
    #   To run this test, execute the following commands:
    #   $ cd /path/to/ansible
    #   $ PYTHONPATH=lib nosetests -v test/units/test_AnsibleConstructor.py

    # Import the module
    import sys
    sys.path.append('lib')
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Create a YAML string
    yaml_str = '''
- this
- that
- the other thing
'''
    # Create a AnsibleData object from the YAML string
    # Note:


# Generated at 2022-06-23 05:26:06.196160
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import pytest

# Generated at 2022-06-23 05:26:13.220554
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    import yaml
    node = yaml.nodes.MappingNode()
    # Retrieve the actual class of the method
    cls = constructor.construct_mapping.__self__.__class__
    # Retrieve the actual function (unbound method)
    func = cls.construct_mapping
    # Bind the function so that it is no more an unbound method
    bound_func = func.__get__(constructor, cls)
    bound_func(node)

# Generated at 2022-06-23 05:26:21.890458
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    method : construct_mapping of class AnsibleConstructor
    ======================================================

    This method test the method construct_mapping of class AnsibleConstructor.
    verify that if the user uses a duplicate key in a dictionary, it raises an exception.

    """
    class a():
        value = []
    node = a()
    node.value = [([], []), ([], [])]
    deep = False
    b = AnsibleConstructor()
    try:
        b.construct_mapping(node, deep)
    except ConstructorError as e:
        assert e.problem == "found unacceptable key (unhashable type: 'list')"

# Generated at 2022-06-23 05:26:33.618307
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    """
    Tests constructor of class AnsibleConstructor

    Returns:
        None
    """
    # Test data
    data1 = 'datasource'
    data2 = None
    data3 = 'column+1'
    data4 = 'line+1'
    data5 = 'node.start_mark.line+1'
    data6 = 'node.start_mark.column+1'
    data7 = 'self._ansible_file_name'
    # Test
    obj = AnsibleConstructor()
    assert obj is not None
    assert data1 == obj._ansible_file_name

    # Test values for AnsibleConstructor class methods
    assert data2 == obj.construct_yaml_map()
    assert data3 == obj.construct_mapping()
    assert data4 == obj.construct_yaml_str()

# Generated at 2022-06-23 05:26:42.498785
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    stream = '''
    foo: |
      ansible-playbook requires some text
      to go over multiple lines
      and to include a list:
      - and
      - some
      - meaningful
      - examples
      to test out this code
    '''
    data = yaml.load(stream, Loader=AnsibleConstructor)
    assert isinstance(data, dict)
    assert data['foo'] == 'ansible-playbook requires some text\nto go over multiple lines\nand to include a list:\n- and\n- some\n- meaningful\n- examples\nto test out this code\n'

    # Test that we can pass an optional file name to the constructor

# Generated at 2022-06-23 05:26:47.687874
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_str_input = r"""
    ---
    - 1
    - 2
    - 3
    """
    yaml_str_expected_output = [1, 2, 3]
    yaml_str_output = AnsibleConstructor().construct_yaml_str(yaml_str_input)
    assert yaml_str_expected_output == yaml_str_output

# Generated at 2022-06-23 05:26:51.768229
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    assert isinstance(AnsibleConstructor.construct_yaml_seq(AnsibleConstructor(), None),
                      AnsibleBaseYAMLObject)

# Generated at 2022-06-23 05:27:01.680528
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    test_string = '''
---
foo:
  bar:
    - 123
    - [123, "foo", "bar"]
    - 123
- 123
'''
    import sys
    from collections import namedtuple

    def fake_fail(msg):
        raise RuntimeError(msg)

    def fake_warn(msg):
        raise RuntimeError(msg)


# Generated at 2022-06-23 05:27:11.458549
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    '''
    Test the construct_mapping method of the AnsibleConstructor.
    '''
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    c = AnsibleConstructor()

    collection = AnsibleMapping()
    collection['a'] = 'b'
    collection['a'] = 'c'
    collection.ansible_pos = ('/test/file', 1, 1)

    result = c.construct_mapping(collection)

    assert result['a'] == 'c'
    assert result.ansible_pos == ('/test/file', 1, 1)



# Generated at 2022-06-23 05:27:22.651797
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3

    def make_node(value):
        from yaml.nodes import ScalarNode
        from yaml.nodes import SequenceNode
        from yaml.nodes import MappingNode
        from yaml.compat import unicode

        if isinstance(value, (unicode, bytes)):
            return ScalarNode(tag=u'tag:yaml.org,2002:str', value=value)
        elif isinstance(value, (list, tuple)):
            return SequenceNode(tag=u'tag:yaml.org,2002:seq', value=[make_node(v) for v in value])

# Generated at 2022-06-23 05:27:26.708625
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # todo: add a test here
    # http://docs.pytest.org/en/2.8.7/example/parametrize.html
    pass

# Generated at 2022-06-23 05:27:32.242323
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    node = ''
    result = ansible_constructor.construct_yaml_str(node)
    assert isinstance(result, AnsibleUnicode)
    assert len(result) == 0


# Generated at 2022-06-23 05:27:42.022720
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    c = AnsibleConstructor()

    node1 = c.construct_yaml_int('0')
    node2 = c.construct_yaml_int('1')
    m = c.construct_mapping(
        c.construct_yaml_map(
            c.construct_mapping(node1,node2)))

    node1 = c.construct_yaml_int('0')
    node2 = c.construct_yaml_int('1')
    s = c.construct_yaml_seq(
        c.construct_sequence(
            c.construct_sequence(node1,node2)))

    s = c.construct_yaml_seq(
        c.construct_sequence(
            c.construct_mapping(node1,node2)))


# Generated at 2022-06-23 05:27:53.276300
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.display import Display
    display = Display()
    from ansible.parsing.yaml.loader import AnsibleLoader
    file_name = '/Users/lihui/repos/ansible/lib/ansible/plugins/callback/default.py'
    vault_secrets = None
    constructor_cls = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)

# Generated at 2022-06-23 05:28:04.040353
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    def _get_yaml_node(value):
        from yaml.nodes import ScalarNode
        node = ScalarNode(u'tag:yaml.org,2002:str', value)
        return node

    value = 'test string'
    ac = AnsibleConstructor()
    ansible_unicode = ac.construct_yaml_str(_get_yaml_node(value))
    assert(ansible_unicode == 'test string')
    assert(type(ansible_unicode) == AnsibleUnicode)
    assert(ansible_unicode.ansible_pos[0] == '<unicode string>')
    assert(ansible_unicode.ansible_pos[1] == 1)
    assert(ansible_unicode.ansible_pos[2] == 0)

# Generated at 2022-06-23 05:28:08.076081
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    value = '{{ lookup("foo") }}'
    data = yaml.load(value, Loader=AnsibleConstructor)
    assert data.strip() == value, "The original value should be preserved as a Jinja2 expression"

# Generated at 2022-06-23 05:28:16.459706
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.vars.unsafe_proxy import wrap_var

    # basic usage
    ac = AnsibleConstructor()
    obj = ac.construct_yaml_unsafe({ 'id': 'python/none' })
    assert (obj is None), 'failed: expected None as result'

    # what about a real python object like a string ?
    obj = ac.construct_yaml_unsafe({ 'id': 'python/str', 'value': 'bob' })
    assert (obj == 'bob'), 'failed: expected "bob" as result'

    # what about a string that should be parsed to a boolean ?
    obj = ac.construct_yaml_unsafe({ 'id': 'python/bool', 'value': 'True' })
    assert (obj is True), 'failed: expected True as result'

    # what about a

# Generated at 2022-06-23 05:28:27.681488
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    my_vars = [{'foo ': 'bar'}, {'list1': [1,2,3], 'list2': [4,5,6,7]}, 'first ', 'second']
    content = AnsibleLoader(my_vars).get_single_data()

    def _evaluated_nodes(content):
        content_as_list = []
        for node in content:
            content_as_list.append(node)
        return content_as_list

    assert _evaluated_nodes(content) == [{'foo ': 'bar'}, {'list1': [1, 2, 3], 'list2': [4, 5, 6, 7]}, 'first ', 'second']

# Generated at 2022-06-23 05:28:34.480938
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    yaml_str = '---\n- hosts: localhost\n  gather_facts: false\n  tasks:\n    - name: Will be marked as changed when checked\n      ping: data=!unsafe { { test: "ok" } }\n'
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data[0]['tasks'][0]['ping']['data']._unsafe == dict(data=dict(test='ok'))

# Generated at 2022-06-23 05:28:45.905932
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class FakeNode(object):
        def __init__(self, value):
            self.value = value

    class FakeConstructor(object):
        def construct_mapping(self, node, deep=False):
            return node.value

    # Empty dict
    expected_value = {}
    node = FakeNode(expected_value)
    constructor = FakeConstructor()
    actual_value = AnsibleConstructor.construct_mapping(constructor, node)
    assert expected_value == actual_value

    # Single dict item
    expected_value = {
        'key1': 'value1'
    }
    node = FakeNode(expected_value)
    constructor = FakeConstructor()
    actual_value = AnsibleConstructor.construct_mapping(constructor, node)
    assert expected_value == actual_value

    # Multiple dict

# Generated at 2022-06-23 05:28:55.403947
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    x = AnsibleConstructor()

# Generated at 2022-06-23 05:28:55.856085
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

# Generated at 2022-06-23 05:28:59.724814
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_data = u"foo"
    ac = AnsibleConstructor()
    auc = ac.construct_object(yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=yaml_data))
    assert isinstance(auc, AnsibleUnicode)
    assert yaml_data == auc

# Generated at 2022-06-23 05:29:09.209815
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    for s in ('{"test_dict_1": "1"}', '["test_list_1", "1"]', '"test_string_1"', 'test_string_2', '1',
              '1.1', '1.1+1.1j'):
        yaml_str = '''
        - {}
        '''.format(s)
        ansible_constructor = AnsibleConstructor()
        result = ansible_constructor.construct_yaml_str(yaml_str)
        assert isinstance(result, AnsibleUnicode)
        assert result.ansible_pos == ('<string>', 2, 3)
        assert str(result) == s

    # test for constrctor 'construct_scalar'

# Generated at 2022-06-23 05:29:16.690159
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_data = ['a', 'b', 'c']
    test_node = object()
    ansible_constructor = AnsibleConstructor(file_name='test')
    ansible_constructor.construct_sequence = lambda node: test_data
    result = next(ansible_constructor.construct_yaml_seq(test_node))
    assert isinstance(result, AnsibleSequence)
    assert result == test_data
    assert result.ansible_pos == ('test', 1, 1)



# Generated at 2022-06-23 05:29:25.017718
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    class TestConstructor(AnsibleConstructor):
        def construct_python_module(self, node):
            return self.construct_scalar(node)

    dc = TestConstructor()
    dc.add_constructor(u'!module', dc.construct_python_module)

    doc_yaml = """
---
module: test
short_description: testing
notes:
    - This is a note.
options:
    test1:
        description: testing
    test2:
        description: testing
"""
    data = read_docstring(doc_yaml)
    assert type(data['options']['test1']['description']) == AnsibleUn

# Generated at 2022-06-23 05:29:33.571389
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import ansible.constants as C
    import ansible.parsing.yaml.objects as ya
    from ansible.parsing.yaml.dumper import AnsibleDumper
    y = AnsibleConstructor()
    seq_value = [{'a': 123}, 'b', u'c']
    seq_value_ansible_pos = (u'<unicode>', 1, 0)
    node = y.construct_yaml_seq(None)
    assert isinstance(node, ya.AnsibleSequence)
    assert node.ansible_pos == seq_value_ansible_pos



# Generated at 2022-06-23 05:29:39.778113
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = [1,2,3,4,5]
    node = yaml.nodes.SequenceNode(u'tag:yaml.org,2002:seq', data, start_mark=None, end_mark=None, flow_style=None)
    ac = AnsibleConstructor()
    gen = ac.construct_yaml_seq(node)
    seq = next(gen)
    print(seq)
    assert seq == [1, 2, 3, 4, 5]

if __name__ == '__main__':
    import yaml
    test_AnsibleConstructor_construct_yaml_seq()

# Generated at 2022-06-23 05:29:50.212961
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib([VaultSecret('placeholder')])
    constructor = AnsibleConstructor(vault_secrets=vault.secrets)

    # Test with both a vault secret and a non-vault secret

# Generated at 2022-06-23 05:30:02.093950
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Most of this copied from unit test code of class AnsibleConstructor
    from io import BytesIO

    yaml_data = '''
    a:
       b: &c [1,1]
       d: *c
    '''

    # First parse the code with safe_load
    import yaml
    data = yaml.safe_load(yaml_data)
    # Then parse the code with our custom constructor
    data2 = yaml.load(yaml_data, Loader=AnsibleConstructor)

    # Now ensure they're the same!
    import pprint
    # print 'safe_load:'
    # pprint.pprint(data)
    # print 'custom constructor:'
    # pprint.pprint(data2)
    assert data['a'] == data2['a']

# Generated at 2022-06-23 05:30:09.222748
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with plain string
    node = AnsibleConstructor.construct_yaml_str(u'Forty-two')
    assert node == AnsibleUnicode(u'Forty-two')

    # Test with unicode string
    node = AnsibleConstructor.construct_yaml_str(u'\xb5'.decode('latin-1'))
    assert node == AnsibleUnicode(u'\xb5'.decode('latin-1'))


# Generated at 2022-06-23 05:30:19.295694
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    def test_data(text, expected):
        yaml_obj = yaml.load(text, Loader=AnsibleConstructor)
        assert yaml_obj == expected

    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    test_data('{ansible: 1}', dict(ansible=1))
    test_data('{ansible: {unsafe: 1}}', dict(ansible=wrap_var(1)))
    test_data('{ansible: {unsafe: {read: 1}}}', dict(ansible=wrap_var(dict(read=1))))

# Generated at 2022-06-23 05:30:28.206866
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from yaml import Node
    from yaml.representer import Representer
    import sys

    test_string = repr(object())

    class TestUnsafeObject(object):
        ansible_forbidden = True
        def __repr__(self):
            return test_string

    def represent_TestUnsafeObject(representer, data):
        return representer.represent_scalar(u'!unsafe', test_string)

    Representer.add_representer(TestUnsafeObject, represent_TestUnsafeObject)

    # The class TestUnsafeObject is a 'forbidden' class because its
    # attribute ansible_forbidden is set to True:
    node = Representer.represent_data(TestUnsafeObject())

# Generated at 2022-06-23 05:30:31.381877
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    node = ['a', 'b', 'c']
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_seq(node)
    assert list(result) == node

# Generated at 2022-06-23 05:30:43.040424
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import tempfile
    import os

    vault_password_file = tempfile.NamedTemporaryFile()


# Generated at 2022-06-23 05:30:46.103961
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    yaml_str = """
- { foo: 1, bar: 2 }
- { foo: 3, bar: 4 }
"""
    assert ac.construct_yaml_str(yaml_str) is not None

# Generated at 2022-06-23 05:30:53.817222
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    vault_password = 'VaultPassword'

# Generated at 2022-06-23 05:31:00.531266
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ac = AnsibleConstructor(file_name='file1')

    node = MappingNode(None, 0)
    value = node.value
    # adding a fake value node
    value.append((1, 2))
    data = ac.construct_yaml_map(node)
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos == (u'file1', 1, 1)


# Generated at 2022-06-23 05:31:07.349621
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode

    ansible_constructor = AnsibleConstructor()
    node = MappingNode('test_tag', [('test_key', 'test_value')], start_mark=None, end_mark=None, flow_style=None)
    result = {'test_key': 'test_value'}

    assert result == ansible_constructor.construct_mapping(node)

# Generated at 2022-06-23 05:31:15.456392
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str="""
a:
- 1
- 2
- 3
b:
- 4
- 5
- 6
"""
    try:
        import yaml
    except ImportError as e:
        raise AssertionError("No yaml library present")

    try:
        result = yaml.load(yaml_str, Loader=AnsibleConstructor)
    except Exception as e:
        assert False, "Unable to read yaml string - %s"%(e)

    # Verify expected result
    assert result['b'][0]==4, "Unexpected value for b[0] - %s"%(result['b'][0])
    assert result['b'][2]==6, "Unexpected value for b[2] - %s"%(result['b'][2])

# Generated at 2022-06-23 05:31:25.228222
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = b'abc123'

# Generated at 2022-06-23 05:31:33.451601
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Testing with a different file name to check if ansible_pos is correct
    file_name = 'example.yml'
    myConstructor = AnsibleConstructor(file_name)
    node = yaml.MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=False)
    result = myConstructor.construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)
    assert result.ansible_pos == (file_name, 1, 1)


# Generated at 2022-06-23 05:31:39.561214
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    '''
    Test the construct_yaml_str method of class AnsibleConstructor
    '''
    import yaml
    yaml_string = u'ansible: leuven'
    yaml_constructor = AnsibleConstructor()
    data = yaml.load(yaml_string, Loader=yaml.Loader)
    assert isinstance(data['ansible'], AnsibleUnicode)