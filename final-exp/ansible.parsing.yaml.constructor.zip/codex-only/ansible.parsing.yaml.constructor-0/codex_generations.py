

# Generated at 2022-06-23 05:21:47.039692
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    test_data = "!vault |\n" +\
                "          $ANSIBLE_VAULT;1.1;AES256\n" +\
                "          3330386436616465353637396465636230663965336665306463313239653732653361313836313334\n" +\
                "          34343664663730666335613534396133353238633438343638630a\n" +\
                "          6232666133336566373465353236316335336430343636393734373033383133663238643933346331\n" +\
                "          653331613263366234613361323734613738303633343939343130"


# Generated at 2022-06-23 05:21:55.865119
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml import objects
    import json

    loader = AnsibleLoader(None, True)

    obj = loader.load('''
    key:
      - a_string
      - a_number: 1
      - a_float: 1.25
    ''')
    assert type(obj) is objects.AnsibleMapping
    assert type(obj['key']) is objects.AnsibleSequence
    assert type(obj['key'][0]) is objects.AnsibleUnicode
    assert type(obj['key'][1]) is objects.AnsibleMapping
    assert type(obj['key'][2]) is objects.AnsibleMapping


# Generated at 2022-06-23 05:22:01.774899
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    loader = yaml.Loader
    loader.add_constructor('!test_constructor', AnsibleConstructor.construct_yaml_str)
    dat = '''\
- !test_constructor "test of constructor"
'''
    data = yaml.load(dat, loader)
    assert 'test of constructor' == data[0]

# Generated at 2022-06-23 05:22:12.491118
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    # We are particularly testing our ability to override the pyyaml
    # constructor method, to include our own special types, so we
    # can't actually use the AnsibleLoader here.
    # We also can't use capture=True because pyyaml doesn't allow
    # constructors to return non-strings (and we want to return
    # unicode() objects)
    constructor = AnsibleConstructor()

# Generated at 2022-06-23 05:22:22.188779
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    import inspect
    import unittest

    import yaml

    from ansible.parsing.dataloader import DataLoader

    sources = [{
        u'a': u'hello',
        u'b': u'world',
        u'c': [1, 2, 3],
        u'd': {
            u'e': u'f'
        }
    }]

    for source in sources:

        class TestConstructYamlMap(unittest.TestCase):

            def setUp(self):

                self.loader = DataLoader()

            def test_construct_yaml_map(self):

                result = yaml.load(source, Loader=AnsibleConstructor)

                self.assertIsInstance(result, AnsibleMapping)

# Generated at 2022-06-23 05:22:34.753366
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    # this represent a variable reference to the hostname variable.
    # not the host variable itself
    data = yaml.load("""!unsafe "{{ hostvars[inventory_hostname]['hostname'] }}" """)

    # without !unsafe prefix, this would be a string "{{ hostvars[inventory_hostname]['hostname'] }}"
    assert data.__class__.__name__ == 'UnsafeProxy'
    # FIXME: if I remove host.hostname, we can remove this test
    # this ensures that we are casting it back to a string in and that
    # no further yaml parsing is performed.
    assert str(data) == "{{ hostvars[inventory_hostname]['hostname'] }}"




# Generated at 2022-06-23 05:22:38.084338
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = dict(a=1, b=2, c=3)
    construct_yaml_map(data)
    assert data == dict(a=1, b=2, c=3)


# Generated at 2022-06-23 05:22:43.608633
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # This is a dict as yaml input
    mapping = u'\n\n---\n\nname: myhost\nhosts: localhost\nconnection: local\ngather_facts: false\ntasks:\n  -\n    name: test\n    debug: msg=success!!!\n'

    # Calling construct_mapping()
    AnsibleConstructor().construct_mapping(mapping)



# Generated at 2022-06-23 05:22:51.954995
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Class: AnsibleConstructor
    Method: construct_mapping
    Unit test of method construct_mapping of AnsibleConstructor class
    """
    import pytest
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
        a: 1
        b: 2
        c: 3
        a: 4
    """

    obj = AnsibleLoader(data).get_single_data()
    assert type(obj) is AnsibleMapping

# Generated at 2022-06-23 05:23:01.941524
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    data = '''
- default:
    dept: R&D
    name: Geert
- default:
    dept: R&D
    name: John
- default:
    dept: R&D
    name: Nick
'''

    data2 = '''
- dict1:
    dept: R&D
    name: Geert
- dict1:
    dept: R&D
    name: John
- dict1:
    dept: R&D
    name: Nick
'''

    ac = AnsibleConstructor()

# Generated at 2022-06-23 05:23:09.225094
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    myAnsibleConstructor = AnsibleConstructor()
    myUnicode = u'a unicode string'
    yaml_str = b"a yaml str"
    utf_8_encoded = u'a unicode string'.encode('utf-8')
    utf_8_encapsulated = u"!!python/unicode '" + utf_8_encoded + b"'"
    if b"'" in utf_8_encapsulated:
        # Verify that we are working with a unicode string
        assert(isinstance(utf_8_encapsulated, type(u'')))
    assert(myAnsibleConstructor.construct_yaml_str(utf_8_encoded) == myUnicode)

# Generated at 2022-06-23 05:23:11.499816
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    a = AnsibleConstructor()
    a.construct_vault_encrypted_unicode('foo')

# Generated at 2022-06-23 05:23:22.409256
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    #encrypted string
    yaml_input = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35393965376466393933383765393034333962393963373531653663313764343230643637323033\n          39393064343132633164343064396566333661306465313365633536306537663365623630393735\n          3662663663393532\n"
    yaml_output = yaml.load(yaml_input, Loader=AnsibleConstructor)
    assert yaml_output.vault.secrets == ["default"]
    assert isinstance(yaml_output, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:23:31.239540
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
   ansibleConstructor = AnsibleConstructor()
   param_node = '''
---
- name: test node
  hosts: test host
  become: true
  become_user: test_user
  become_method: su
  gather_facts: no
  vars:
    - var1: val1
    - var2:
        - subvar1: val2
        - subvar2: val3
  tasks:
    - name: test task
      debug:
        msg: This is a test debug message
'''
   data = ansibleConstructor.construct_yaml_map(param_node)
   assert data



# Generated at 2022-06-23 05:23:37.037115
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    class MockNode:
        def __init__(self, my_id):
            self.id = my_id

    test_obj = AnsibleConstructor()
    assert to_bytes('_raw_params') == test_obj.construct_yaml_unsafe(MockNode('_raw_params')).data

# Generated at 2022-06-23 05:23:44.241348
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Construct a string with an embedded AnsibleUnicode Obj
    test_string = u"Hello World!\u263A"

    # Load it with AnsibleOptionalLoader
    test_string_loaded = AnsibleLoader(test_string, file_name='<test_string>', vault_secrets=[]).get_single_data()

    # Confirm it is an AnsibleUnicode Obj
    assert isinstance(test_string_loaded, AnsibleUnicode)

    # Confirm the data is the same
    assert test_string == test_string_loaded

# Generated at 2022-06-23 05:23:50.315086
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    if not HAS_RUAMEL:
        return
    import ruamel.yaml as yaml
    obj = yaml.load("""
    !unsafe 'hello'
""", Loader=yaml.SafeLoader)
    assert str(obj) == 'hello'
    obj = yaml.load("""
    !unsafe hello
""", Loader=yaml.SafeLoader)
    assert str(obj) == 'hello'

# Generated at 2022-06-23 05:24:00.000226
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Dummy constructor
    class Dummy():
        pass

    # Dummy node object
    node = Dummy()

    # Dummy unsafe object
    class Dummy_Unsafe():
        def __init__(self, arg):
            self.value = arg

    constructor = AnsibleConstructor()

    # Test id of node 'object'
    node.id = 'object'
    node.constructor = Dummy_Unsafe
    ret = constructor.construct_yaml_unsafe(node)
    assert len(ret.names) == 1
    assert ret.names[0] == 'object'
    assert ret.value is not None

    # Test id of node 'map'
    node.id = 'map'
    node.constructor = Dummy_Unsafe
    ret = constructor.construct_yaml_unsafe(node)


# Generated at 2022-06-23 05:24:11.806811
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import io
    import textwrap
    import yaml
    import string
    import random

    EXAMPLE_STR = u'{ foo : bar }'
    EXAMPLE_DATA = [string.ascii_lowercase, string.ascii_uppercase, string.digits]
    VAULT_START = u'$ANSIBLE_VAULT;'

    # test _node_position_info
    node = yaml.nodes.Node(tag=u'tag:yaml.org,2002:map')
    node.start_mark = yaml.Mark(index=0, line=1, column=1, buffer=EXAMPLE_STR, pointer=0)


# Generated at 2022-06-23 05:24:15.570825
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_map = list(ansible_constructor.construct_yaml_map('node'))[0]
    assert isinstance(ansible_map, AnsibleMapping)
    assert getattr(ansible_map, 'ansible_pos') == ('<unicode string>', 1, 0)


# Generated at 2022-06-23 05:24:25.652783
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class FakeNode(object):
        def __init__(self, value):
            self.value = value

    class FakeConstructor():
        def construct_mapping(self, value):
            return value

    fake_constructor = FakeConstructor()
    fake_constructor.construct_yaml_map = AnsibleConstructor.construct_yaml_map.__get__(fake_constructor)

    # call the function with a node with a value
    result = fake_constructor.construct_yaml_map(FakeNode(4))
    assert isinstance(result, AnsibleMapping)

    # call the function with a wrong value
    fake_constructor.construct_mapping = lambda x: None

# Generated at 2022-06-23 05:24:29.822760
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ac = AnsibleConstructor()
    node = u'{foo: [1, 2, 3]}'
    value = ac.construct_yaml_unsafe(node)
    assert value.as_safe_yaml() == node


# Generated at 2022-06-23 05:24:36.724820
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = """
        test_key: value
        test_key2:
          - value2
    """
    loader = AnsibleConstructor()
    d = loader.get_single_data(yaml_str)
    error = d["test_key"] == "value"
    expected = d["test_key2"][0] == "value2"
    assert error and expected



# Generated at 2022-06-23 05:24:44.918023
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(secrets=[])
    vault.secrets = [u'foo']
    nodes = []
    ansible_constructor = AnsibleConstructor(vault_secrets=vault.secrets)
    ansible_constructor._vaults['default'] = vault

    if True:
        ansible_constructor.construct_yaml_map(nodes)
        ansible_constructor.construct_mapping(nodes)
        ansible_constructor.construct_yaml_str(nodes)
        ansible_constructor.construct_vault_encrypted_unicode(nodes)
        ansible_constructor.construct_yaml_seq(nodes)
        ansible_constructor.construct_yaml_unsafe(nodes)

   

# Generated at 2022-06-23 05:24:51.680291
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.module_utils.six import PY2
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader

    test_string = (u'dict_key: &id001\n'
                   u'  name: value\n'
                   u'  name: value\n'
                   u'\n'
                   u'dict_key:\n'
                   u'  <<: *id001\n')

    # test_string2 is a sample data that has 1 duplicate key.
    # When DUPLICATE_YAML_DICT_KEY is set to 'ignore',
    # the following 2 construct_mapping() calls will return
    # different dicts.
    # If DUPLICATE_YAML_DICT_

# Generated at 2022-06-23 05:25:01.840433
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    # prepare for test data: all_yaml_tags.yml, exclude !vault

# Generated at 2022-06-23 05:25:12.240737
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    content = '''
        foo:
          value1:
            - 1
            - 2
          value2:
            - 3
            - 4
        bar:
          value3:
            - 5
            - 6
          value4:
            - 7
            - 8
    '''
    expected_object = {
        'foo': {
            'value1': [1, 2],
            'value2': [3, 4]
        },
        'bar': {
            'value3': [5, 6],
            'value4': [7, 8]
        }
    }
    expected_line_num = 1
    expected_column_num = 1
    expected_datasource = '<string>'
    from ansible.parsing.yaml.loader import AnsibleLoader
    ansible_constructor = Ans

# Generated at 2022-06-23 05:25:22.099483
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    class TestClass(object):
        def __init__(self, value):
            self.value = value

    font = "\x1b[1;31m%s\x1b[0m"
    values = [
        {'value': u"unicode"},
        {'value': "hello"},
        {'value': b"hello"},
        {'value': TestClass("hello")}
    ]
    for test_val in values:
        test_val = test_val['value']
        print("\n-------------------------------")
        print("value: " + font % type(test_val))
        obj = AnsibleConstructor()
        node = AnsibleConstructor.construct_yaml_str(obj, test_val)
        print("node: " + font % type(node))

# Generated at 2022-06-23 05:25:30.528018
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ac = AnsibleConstructor()
    mapping_node = MappingNode(None, [], None)
    mapping_node.value = [
        [
            "_id", Node(None, [], None)
        ],
        [
            "_set", Node(None, [], None)
        ],
        [
            "_set", Node(None, [], None)
        ]
    ]
    mapping = ac.construct_mapping(mapping_node)
    assert(mapping['_id'])

test_AnsibleConstructor_construct_mapping()

# Generated at 2022-06-23 05:25:42.840056
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import unittest
    import yaml

    from ansible.parsing.yaml import objects

    # Have to use this special dummy class when doing unit test.
    # Why? Because class VaultLib need some private function of class AnsibleBaseYAMLObject
    class AnsibleBaseYAMLObject_test(objects.AnsibleBaseYAMLObject):
        @property
        def vault(self):
            return vault

        @vault.setter
        def vault(self, value):
            pass
            # vault = value

    objects.AnsibleBaseYAMLObject = AnsibleBaseYAMLObject_test

    class TestAnsibleConstructor(unittest.TestCase):
        def setUp(self):
            self.unicode_secret = u"unicode_secret"
            self.unicode

# Generated at 2022-06-23 05:25:50.259752
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = '''
---
junk:
  - '1'
  - '2'
  - '3'
'''
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, dict)
    assert isinstance(data['junk'][0], AnsibleUnicode)

# Generated at 2022-06-23 05:26:01.957889
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    ac = AnsibleConstructor()
    test_value_list = [1, 2, 3, 4, 5]

    class FakeNode(object):
        def __init__(self, start_mark, end_mark, value):
            self.id = None
            self.start_mark = start_mark
            self.end_mark = end_mark
            self.value = value

    class FakeMark(object):
        def __init__(self, name, index, line, column, buffer, pointer):
            self.name = name
            self.index = index
            self.line = line
            self.column = column
            self.buffer = buffer
            self.pointer = pointer


# Generated at 2022-06-23 05:26:07.785316
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    filename = "test_file"
    vault_secrets = ['test_vault_secret']

    # Passing in 'filename' and 'vault_secrets' parameters
    c = AnsibleConstructor(filename, vault_secrets)

    # Make sure that the filename and vault_secrets attributes were correctly assigned
    assert c._ansible_file_name == filename
    assert c.vault_secrets == vault_secrets

# Generated at 2022-06-23 05:26:17.668963
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    import textwrap

    data1 = yaml.load(textwrap.dedent('''
    test_dict1:
      value1: value1
      value2: value2
      value3: value3
    '''), Loader=yaml.Loader)

    data2 = yaml.load(textwrap.dedent('''
    test_dict1:
      value1: value1
      value2: value2
      value3: value3
      value1: value1
    '''), Loader=yaml.Loader)


# Generated at 2022-06-23 05:26:24.765212
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    test_mapping_node = MappingNode(None, None)
    test_mapping_node.value = [
        (
            ScalarNode(None, None, None),
            ScalarNode(None, None, None),
        ),
        (
            ScalarNode(None, None, None),
            ScalarNode(None, None, None),
        ),
    ]
    assert ansible_constructor.construct_mapping(test_mapping_node) == {None: None, None: None}

# Generated at 2022-06-23 05:26:35.094910
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    import yaml

    vault_key_id = '935388c6-629b-462b-b969-cb5bb5df5f5a'

# Generated at 2022-06-23 05:26:39.089711
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_str = to_bytes(
        '''
            ''')
    test_str_obj = yaml.load(test_str, Loader=AnsibleConstructor)
    return_str_obj = test_str_obj.object
    assert isinstance(return_str_obj, dict)

# Generated at 2022-06-23 05:26:50.612720
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Checking cases that should be successfully converted to AnsibleUnicode
    value_str = AnsibleConstructor().construct_yaml_str(u'hello_world')
    assert isinstance(value_str, AnsibleUnicode)
    assert value_str == u'hello_world'

    value_int = AnsibleConstructor().construct_yaml_str(42)
    assert isinstance(value_int, AnsibleUnicode)
    assert value_int == u'42'

    # Checking cases that should fail
    try:
        AnsibleConstructor().construct_yaml_str(None)
    except ConstructorError:
        pass
    except Exception:
        raise AssertionError('Wrong exception being raised')
    else:
        raise AssertionError('Exception not raised')


# Generated at 2022-06-23 05:26:59.913551
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:27:11.945920
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        class Loader(object):
            def construct_yaml_map(self, node):
                return dict()
        def setUp(self):
            self.loader = TestAnsibleConstructor.Loader()
            self.constructor = AnsibleConstructor()
        def test__node_position_info(self):
            from yaml.nodes import MappingNode
            pos = self.constructor._node_position_info(MappingNode())
            self.assertEqual(len(pos), 3)

# Generated at 2022-06-23 05:27:13.190213
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert False, "Not implemented"


# Generated at 2022-06-23 05:27:22.528304
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import inspect
    import copy
    from ansible.errors import AnsibleUndefinedVarsError
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader

    def update_containers(container):
        for v in container.itervalues():
            if isinstance(v, objects.AnsibleBaseYAMLObject):
                v.ansible_pos = None
                update_containers(v)

    # Save original constructors
    _OrgConstructMapping_AnsibleConstructor = copy.deepcopy(
        AnsibleConstructor.construct_mapping)
    _OrgConstructSequence_AnsibleConstructor = copy.deepcopy(
        AnsibleConstructor.construct_sequence)

# Generated at 2022-06-23 05:27:34.385655
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    from yaml import load
    from yaml.scanner import ScannerError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib
    from contextlib import contextmanager
    import os

    # yaml.scanner.ScannerError is an alias for `yaml.reader.ReaderError` (and
    # the latter is not always defined).  We use this exception to check if
    # the parsing failed.
    #
    # Note that `ansible.parsing.yaml.loader.AnsibleLoader` can handle a
    # `ScannerError`, but `pyyaml.load` cannot.  If we pass an empty string to
    # AnsibleLoader, it will raise `

# Generated at 2022-06-23 05:27:45.222925
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test for construct_vault_encrypted_unicode method of class AnsibleConstructor
    # Without a vault secret

    from ansible import context

    # Setup
    ansible_constructor = AnsibleConstructor(vault_secrets=None)
    node = 'FAKE_NODE'

    # Test
    with pytest.raises(ConstructorError) as error:
        ansible_constructor.construct_vault_encrypted_unicode(node)

    # Assertions
    assert(error.value.problem == 'found !vault but no vault password provided')

    # Change filename to 'ansible.cfg' to test adding vault_password_file option if not already existing

    context.CLIARGS = {'vault_password_files': None}

# Generated at 2022-06-23 05:27:55.161582
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from io import BytesIO as StringIO
    from io import BytesIO
    from ansible.parsing.yaml import load
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # Test a cut and paste from here
    # http://docs.ansible.com/ansible/YAMLSyntax.html#flow-style-vs-block-style-nodes
    # should return the value presented

# Generated at 2022-06-23 05:28:05.666871
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Duplicate dict keys are allowed by yaml, but should warn users
    # Note: yaml will use the last value for duplicate dict keys

    # List of dicts with duplicate dict keys
    duplicate_dict_keys_list = [
        {'name': 'Alice', 'age': '29', 'city': 'SF', 'name': 'Alice'},
        {'name': 'Alice', 'age': '29', 'city': 'SF', 'name': 'Alice'},
        {'name': 'Alice', 'age': '29', 'city': 'SF', 'name': 'Alice'},
    ]

    # Treat duplicate dict keys as errors, so an exception should be raised
    C.DUPLICATE_YAML_DICT_KEY = 'error'

# Generated at 2022-06-23 05:28:10.100815
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    constructor = AnsibleConstructor()
    for stream in [
            'foo.bar: baz',
            'foo.bar:\n  baz']:
        data = yaml.load(stream, Loader=yaml.Loader)
        assert data == {'foo': {'bar': 'baz'}}, data

# Generated at 2022-06-23 05:28:20.525901
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    a = AnsibleConstructor()

    # test for valid yaml
    yaml_valid = u"""
    - '1'
    - '2'
    - '3'
    """
    result = a.construct_yaml_seq(yaml.compose(yaml_valid))
    assert result.__class__.__name__ == 'generator'
    result = next(result)
    assert result == [u'1', u'2', u'3']

    # test for invalid yaml
    yaml_invalid = u"""
    - '1'
    - '2'
    """
    with pytest.raises(ConstructorError) as execinfo:
        result = a.construct_yaml_seq(yaml.compose(yaml_invalid))

# Generated at 2022-06-23 05:28:31.246415
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    data = '''
    test:
    - 1
    - 2
    - 3
    foo: bar
    baz:
      biz: baz
    '''
    ds = 'dsname'
    y = AnsibleConstructor(ds)
    yaml = y.construct_yaml_map(y.construct_yaml(data))
    assert isinstance(yaml, dict)
    assert isinstance(yaml.get('test'), list)
    assert isinstance(yaml.get('foo'), str)
    assert isinstance(yaml.get('baz'), dict)
    assert isinstance(yaml.get('baz').get('biz'), str)

# Generated at 2022-06-23 05:28:36.509807
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_input = u'bogus: !unsafe "{{ lookup(\'foo\') }}"'
    constructor = AnsibleConstructor()
    data = yaml.load(yaml_input, Loader=AnsibleConstructor)
    assert data['bogus'] == '{{ lookup(\'foo\') }}'

# Generated at 2022-06-23 05:28:39.700836
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(tag=u'tag:yaml.org,2002:map')
    a_constructor = AnsibleConstructor()
    data = a_constructor.construct_yaml_map()
    assert isinstance(data, object)

# Generated at 2022-06-23 05:28:47.540218
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = AnsibleConstructor().construct_yaml_map(MappingNode(None, [], [], None, None))
    assert isinstance(yaml_data, AnsibleMapping)
    assert not hasattr(yaml_data, 'ansible_pos')

    # make sure a duplicate key warning will be generated
    data = u'{a: 1, a: 2}'
    try:
        AnsibleConstructor().construct_yaml(data)
    except ConstructorError as e:
        assert 'found a duplicate dict' in e.problem



# Generated at 2022-06-23 05:28:53.700062
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    yaml_str = '''
    - key1: val1
    - key2: val2
    '''

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == [{'key1': 'val1'}, {'key2': 'val2'}]
    for each in data:
        for k in each:
            assert isinstance(k, unicode)
            assert isinstance(each[k], unicode)

# Generated at 2022-06-23 05:28:55.584862
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    for name in dir(AnsibleConstructor):
        print(name)

# This function tests whether a given string is unicode or byte string.

# Generated at 2022-06-23 05:29:02.934699
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.parser import Parser

    def check(source, expected):
        parser = Parser(source)
        loader = AnsibleConstructor()
        loaded = loader.construct_document(parser.get_event())
        assert loaded == expected

    check(b'foo', b'foo')
    check(b'"foo"', b'foo')

    check(u'foo', u'foo')
    check(u'"foo"', u'foo')
    check(u"'foo'", u'foo')
    check(u"'foo\\n'", u'foo\n')

    # raw python unicode string
    check(u'!python/unicode foo', u'foo')
    check(u'!python/unicode "foo"', u'foo')

# Generated at 2022-06-23 05:29:09.856745
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    # valid
    data = '''
- one
- two
    '''
    expected_result = [u'one', u'two']
    result = yaml.load(data, Loader=AnsibleConstructor)
    assert result == expected_result

    # invalid
    data = '''
- one
- two
-
- three
    '''
    try:
        result = yaml.load(data, Loader=AnsibleConstructor)
        assert result != expected_result
    except yaml.YAMLError as e:
        # this is the expected result
        assert e
        pass

# Generated at 2022-06-23 05:29:20.556492
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import wrap_var

    vault_password = 'passw0rd'
    test_string = "test"

# Generated at 2022-06-23 05:29:25.293017
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import io, yaml
    yaml_str = '''\
---
a
b
c
...'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    # this should raise an exception
    yaml.dump(data, stream=io.StringIO())

# Generated at 2022-06-23 05:29:33.710434
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    Check construct_yaml_str method of AnsibleConstructor class.
    """

    class DummyNode:
        def __init__(self, value):
            self.value = value
            self.start_mark = 1
        def __str__(self):
            return "DummyNode({})".format(self.value)

    node = DummyNode("data")
    ret = AnsibleConstructor().construct_yaml_str(node)

    assert isinstance(ret, AnsibleUnicode)
    assert ret == "data"
    assert ret.ansible_pos == (1, 1, 2)


# Generated at 2022-06-23 05:29:42.945350
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils.six import PY2
    import datetime

    if not PY2:
        timestamp = datetime.datetime(2016, 1, 1, 12, 9, 0)
        import json

        yaml_string = "{ %s: '%s' }\n" % (u"!unsafe", timestamp)
        obj = yaml.load(yaml_string, Loader=AnsibleConstructor)
        assert obj == {u"!unsafe": timestamp}, obj
        json_string = json.dumps(obj)
        assert json_string == u'{"!unsafe": "2016-01-01T12:09:00"}'

        yaml_string = "{ %s: [%s, %s] }\n" % (u"!unsafe", timestamp, timestamp)

# Generated at 2022-06-23 05:29:44.667036
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # This is a placeholder for future testing
    # for the moment, it just passes the unit test
    pass

# Generated at 2022-06-23 05:29:52.930928
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.tests import yaml_loader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 05:29:54.462945
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # TODO: write a unit test
    pass

# Generated at 2022-06-23 05:30:04.629341
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # If no duplicates keys are found
    my_constructor = AnsibleConstructor()
    my_node = MappingNode('tag:yaml.org,2002:map', [], [], None, None)
    my_node.value.append((u'key1', u'value1'))
    my_node.value.append((u'key2', u'value2'))
    my_mapping = AnsibleMapping()
    for obj in my_constructor.construct_yaml_map(my_node):
        my_mapping = obj
    my_dict = dict([(u'key1', u'value1'), (u'key2', u'value2')])
    assert(my_mapping == my_dict)

    # If duplicates keys are found, the warning can be ignored
    my_dict = dict

# Generated at 2022-06-23 05:30:14.719539
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Setup test objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # This is the encrypted data

# Generated at 2022-06-23 05:30:23.488832
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test with a simple Yaml file
    ans_cons = AnsibleConstructor()
    yaml_data = """
        a:
            - 1
            - 2
            - 3
        b:
            - 4
            - 5
            - 6
        c:
            - 7
            - 8
            - 9
        """
    yaml_data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert(yaml_data == {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]})



# Generated at 2022-06-23 05:30:34.565751
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    from ansible.parsing.vault import VaultLib
    # Create an instance of AnsibleConstructor
    vault_secrets = ['the_first_vault_secret', 'the_second_vault_secret']
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_constructor._vaults = {}
    vault = VaultLib(secrets=vault_secrets)
    ansible_constructor._vaults['default'] = vault
    # Encrypt a sample string using vault.
    encrypted_string = vault.encrypt('cisco')
    # Encode the encrypted_string in base64.
    encoded_string = base64.b64encode(encrypted_string.encode('raw_unicode_escape'))
    # Set the value of

# Generated at 2022-06-23 05:30:47.012422
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    '''
    unit test for constructor of class AnsibleConstructor
    '''
    from collections import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    import os

    vault_obj = VaultLib(secrets=[b'hush'])
    data_file_name = os.path.join(os.path.dirname(__file__), 'data', 'alice.yml')
    with open(data_file_name, 'rb') as f:
        data = AnsibleConstructor(data_file_name).get_single_data(f)


# Generated at 2022-06-23 05:30:58.258466
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    from ansible.parsing.yaml.loader import AnsibleLoader

    constructor = AnsibleConstructor(file_name='<string>')

    yaml_str = """
        root_key:
          subkey: value_a
          subkey: value_b
          subkey: value_c
    """
    expected_dict = {
        'root_key': {
            'subkey': 'value_c'
        }
    }


# Generated at 2022-06-23 05:31:03.059884
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import io
    import yaml
    yaml_str = u'''
-
  name: just for test
  value: 1
-
  name: just for test
  value: 2
'''
    input = io.StringIO(yaml_str)
    output = yaml.load(input, AnsibleConstructor)
    assert isinstance(output, list)
    assert 2 == len(output)



# Generated at 2022-06-23 05:31:14.145154
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    #Vault password is foo
    vault_password = '$ANSIBLE_VAULT;1.1;AES256\n36373061346335613161323663396333393231373539336337373465333536343834636632616562320a626133386637643430376236653737316635333833363433316666366266376230373262343131610a316635393635653534653362363335396565336561633665626462343361383134323165303339\n'

    #Data

# Generated at 2022-06-23 05:31:20.191174
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class DummyConstructorError(ConstructorError):
        """Dummy class to be used instead of ConstructorError during tests."""
        pass
        
    test_file_name = 'test_AnsibleConstructor'
    test_vault_secrets = ['test_vault_secret']
    
    # Initialize object to be tested
    ac = AnsibleConstructor(file_name=test_file_name, vault_secrets=test_vault_secrets)
    # Replace ConstructorError with DummyConstructorError to ease testing
    ac.ConstructorError = DummyConstructorError
    
    # Patch the following functions to avoid unwanted side-effects

# Generated at 2022-06-23 05:31:29.233110
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Build up a some test values to pass to the method
    node = "node"
    deep = True
    node_value = [['key', 'value'], ['key2', 'value2']]

    # The actual call
    ansible_constructor = AnsibleConstructor()
    actual_result = ansible_constructor.construct_mapping(node, deep)

    # The expected result
    expected_result = AnsibleMapping()
    expected_result.update({'key': 'value', 'key2': 'value2'})

    # Check if result of the call is what we expect
    assert actual_result == expected_result

# Generated at 2022-06-23 05:31:39.321067
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    file_name = 'fake_filename'
    vault_secrets = [u'plaintext_vault_password']
    first_value = u'$ANSIBLE_VAULT;1.1;AES256;ec2-user\n3361343464336630653361623261346132356561656332396262316238343866376565326161303165\n3939373630663934366265343837383538313333306265353763306233396234353637653833366566\n3737303336653430'