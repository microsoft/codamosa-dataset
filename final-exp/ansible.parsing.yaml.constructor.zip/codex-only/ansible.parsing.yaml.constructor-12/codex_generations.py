

# Generated at 2022-06-23 05:21:46.209385
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import load, dump
    yaml_str = '''
    a: 1
    b:
      c: 3
      d: 4
    '''

    # We should get back an instance of AnsibleMapping for the mapping,
    # and AnsibleSequence for the sequence.
    data = load(yaml_str, Loader=AnsibleConstructor)

    assert(isinstance(data, AnsibleMapping))
    assert(isinstance(data['b'], AnsibleMapping))
    assert(isinstance(data['b']['c'], AnsibleUnicode))
    assert(data['b']['c'] == '3')
    assert(data['b']['d'] == '4')

# Generated at 2022-06-23 05:21:55.360576
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # create object AnsibleConstructor
    import yaml
    yaml_obj = yaml.load(u'!vault-encrypted $ANSIBLE_VAULT;1.1;AES256 \n'
                         u' 61396336656361333362313264623764383239366438646238633535626633383632626539663864\n',
                         Loader=AnsibleConstructor)

    # convert returned object to dict
    d = dict(yaml_obj.value)

    # create object AnsibleVaultEncryptedUnicode
    av_obj = AnsibleVaultEncryptedUnicode(d['!vault-encrypted']['$ANSIBLE_VAULT;1.1;AES256'])

    # test returned object

# Generated at 2022-06-23 05:22:01.173419
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    constructor = AnsibleConstructor()
    class MyObject(object):
        pass

    o = MyObject()
    w = constructor.construct_yaml_unsafe(o)
    assert isinstance(w, AnsibleUnsafe)
    assert w._obj is o



# Generated at 2022-06-23 05:22:12.080536
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.constants import VAULT_VERSION_1, VAULT_VERSION_2, DEFAULT_VAULT_ID
    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    # generate random secret
    secret = VaultSecret('test', 1)

    # make a sample vault object with a secret
    vault = VaultLib([secret])

    # encode data
    data = vault.encode(to_bytes('test'), DEFAULT_VAULT_ID)

    # create node
    node = AnsibleLoader(data, vault_secrets=[secret]).get_single_data()

    # create AnsibleConstructor

# Generated at 2022-06-23 05:22:21.267810
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeTextWrapper
    # Test whether the AnsibleConstructor.construct_yaml_unsafe function can
    # convert the yaml document to the corresponding object reasonably.
    # Test case 1: yaml document contains yaml unsafe string
    # Test case 2: yaml document contains yaml unicode string
    document_list = [
        u'!unsafe "string_1"',
        u'!safe "string_2"',
        u'!unsafe "string_3"',
        u'!unsafe "string_4"']
    document = u'\n'.join(document_list)
    Ansible

# Generated at 2022-06-23 05:22:27.702518
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test with a simple YAML list
    data = "['a', 'b', 'c']"
    result = list(AnsibleConstructor().construct_yaml_seq(yaml.nodes.SequenceNode.from_yaml(yaml.composer.Composer(data), yaml.resolver.Resolver(), data)))
    assert result == ['a', 'b', 'c']

    # Test with a list that contains an alias
    data = "['a', &test_alias 'b', 'c', *test_alias]"
    result = list(AnsibleConstructor().construct_yaml_seq(yaml.nodes.SequenceNode.from_yaml(yaml.composer.Composer(data), yaml.resolver.Resolver(), data)))

# Generated at 2022-06-23 05:22:28.385869
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-23 05:22:37.249815
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from io import StringIO
    yaml_str = """
    ansible_host: 
        ansible_port: 5985
        ansible_user: user
        ansible_password: Pass@word1
        ansible_connection: winrm
        ansible_winrm_server_cert_validation: ignore
    """
    stream = StringIO(yaml_str)
    loader = AnsibleConstructor(file_name="yaml_str")
    data = loader.get_single_data(stream)
    assert isinstance(data, dict)
    assert data['ansible_host']['ansible_connection'] == 'winrm'
    assert isinstance(data['ansible_host']['ansible_connection'], str)

# Generated at 2022-06-23 05:22:44.434897
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    stream = StringIO("""
- test1
- test2
""")
    loader = AnsibleLoader(stream, file_name='<string>')
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

# Generated at 2022-06-23 05:22:55.280579
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import unittest
    import yaml

    from ansible.compat.tests.mock import patch
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-23 05:23:04.550328
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Set some default values
    import os
    import sys
    import unittest

    # For testing, we will create a class that can act as a file-like object
    # but that just contains the string we have in the 'input' variable

# Generated at 2022-06-23 05:23:13.395168
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Predefined constructors.
    yaml_constructor = AnsibleConstructor()
    # Override the default string handling function
    # to always return unicode objects
    yaml_constructor.add_constructor(u'tag:yaml.org,2002:str',
                                     yaml_constructor.construct_yaml_str)
    # to always return unsafe objects
    yaml_constructor.add_constructor(u'!unsafe',
                                     yaml_constructor.construct_yaml_unsafe)
    # to always return vault objects
    yaml_constructor.add_constructor(u'!vault',
                                     yaml_constructor.construct_vault_encrypted_unicode)

    obj = {'test': '123', 'test2': '456'}

# Generated at 2022-06-23 05:23:17.901715
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = """
a:
  b:
    c: test
    c: test2
    d: test3
"""
    construct = AnsibleConstructor(file_name="foo.yaml")
    parsed_data = yaml.load(yaml_data, Loader=construct.construct_yaml_map)
    assert parsed_data['a']['b']['c'] == 'test2'


# Generated at 2022-06-23 05:23:22.183445
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor()
    assert c.construct_mapping('', deep=True) == AnsibleMapping()
    assert c.construct_mapping(None, deep=True) == AnsibleMapping()
    assert c.construct_mapping([], deep=True) == AnsibleMapping()

# Generated at 2022-06-23 05:23:31.541486
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.nodes import ScalarNode
    import json
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO as StringIO
    else:
        from StringIO import StringIO

    s = StringIO("""
---
- hosts: localhost
  tasks:
    - name: a fact that is undocumented
      debug:
        msg: "{{ lookup('pipe', 'echo foo') }}"
    - name: a fact that is documented
      debug:
        msg: "{{ ansible_eth0.ipv4.address }}"
""")
    d = AnsibleConstructor(file_name='default.yaml')
    node = ScalarNode('tag:yaml.org,2002:str', 'foo', None, None, None)

    # ansible_eth0

# Generated at 2022-06-23 05:23:34.434319
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Simply verify the constructed object is a subclass of unicode.
    assert issubclass(AnsibleConstructor().construct_yaml_str(None), unicode)

# Generated at 2022-06-23 05:23:35.765641
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass



# Generated at 2022-06-23 05:23:44.848417
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib

    # Create a temp file for the vault lib
    import tempfile
    temp = tempfile.NamedTemporaryFile(delete=False)
    temp.close()
    vault_lib = VaultLib(filename=temp.name)
    password = b'password'
    vault_lib.update(password)
    encrypted = vault_lib.encrypt('Hello, World!')
    vault_lib.decrypt(encrypted)
    # Create the constructor
    ac = AnsibleConstructor(vault_secrets=[password])
    # Set the ansible_pos of the node
    node = AnsibleUnicode(u'Hello, World!')
    node.ansible_pos = ('<string>', 1, 1)
    # Construct the ansible unicode object
    ansible_str

# Generated at 2022-06-23 05:23:50.385927
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    value = 'some_string'
    yaml = '{0}'.format(value)

    data = AnsibleLoader(yaml, '<string>').get_single_data()
    
    assert isinstance(data, AnsibleUnicode)
    assert data == value


# Generated at 2022-06-23 05:24:00.064376
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # Arrange
    vault_passwords = [u'ansible']
    filepath = u'test.yml'
    value = u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3537366332316332386236335316232653661353135313831643739393037376264663034353736\n          6332316332386236335316232653661353135313831643739393037376264663034356565'
    node = MappingNode(u'tag:yaml.org,2002:vault-encrypted-unicode', [], [], None, None, False)
    node.value = to_bytes(value)

    # Act

# Generated at 2022-06-23 05:24:04.158843
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constr = AnsibleConstructor()

    mapping = constr.construct_mapping(MappingNode(Tag=u'tag:yaml.org,2002:map', start_mark=None, end_mark=None, value=[]))

    assert isinstance(mapping, AnsibleMapping)

# Generated at 2022-06-23 05:24:07.437699
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Test the constructor
    assert AnsibleConstructor(file_name="test-file")
    assert AnsibleConstructor(file_name="test-file2", vault_secrets=['vault1', 'vault2'])

# Generated at 2022-06-23 05:24:17.142056
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml = '''
        ---
        - block:
            - debug:
                msg: "This is a debug message, with {{a_very_long_variable_here}} inside"

    '''
    from ansible.parsing.vault import VaultLib, VaultEditor
    from ansible.parsing.yaml.loader import AnsibleLoader
    vault_secret = VaultLib.generate_key()
    vault = VaultLib(secrets=vault_secret)
    encrypted = vault.encrypt(yaml)
    editor = VaultEditor(vault, encrypted)
    data = editor.decrypt()
    loader = AnsibleLoader(data, None)
    the_data = loader.get_single_data()
    assert isinstance(the_data[0], dict)

# Generated at 2022-06-23 05:24:27.047228
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Python 2.6 tests
    if sys.version_info < (2, 7):
        result = AnsibleConstructor().construct_yaml_str(u'\xAA')
        assert isinstance(result, AnsibleUnicode)
        assert isinstance(result, unicode)
        assert result == u'\xAA'

        result = AnsibleConstructor().construct_yaml_str(u'\xAA'.encode('utf-8'))
        assert isinstance(result, AnsibleUnicode)
        assert isinstance(result, unicode)
        assert result == u'\xAA'

        result = AnsibleConstructor().construct_yaml_str(u'\xAA'.encode('latin-1'))
        assert isinstance(result, AnsibleUnicode)

# Generated at 2022-06-23 05:24:37.476830
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultEditor

    # !unsafe is used to support the deprecated ansible vault format
    # the only valid use of this is to create an ansible vault editor object
    # which must be an instance of AnsibleVaultEditor or a derived class
    # the object must also be an instance of AnsibleBaseYAMLObject

    # these are the only two valid use cases
    # !unsafe: !vault
    # !unsafe: !vault-encrypted

    # these are the only two valid cases
    # !unsafe ansible.parsing.vault.VaultEditor
    # !unsafe ansible.parsing.vault.AnsibleVaultEncryptedUnicode

    # the following

# Generated at 2022-06-23 05:24:48.007543
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import io
    import sys
    import tempfile

    # define a dummy file that contains the text
    file_desc, file_name = tempfile.mkstemp()
    file_obj = io.open(file_desc, mode='wt', encoding='utf-8')
    file_obj.write(u'{ a: b }')
    file_obj.close()

    # read the file
    file_obj = open(file_name, 'rt')
    file_contents = file_obj.read()
    file_obj.close()

    # now test the code
    orig_stdout = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-23 05:24:59.546079
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    from ansible.parsing.yaml.data import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    # Create a temporary encrypted file
    fd, filename = tempfile.mkstemp()
    vault = VaultLib(['secret_password'])
    vault.encrypt_data('test_value', filename=filename)

    # Load data
    data = open(filename, 'r').read()
    data_node = yaml.nodes.ScalarNode(tag=u'!vault', value=data)
    value = AnsibleConstructor(vault_secrets=['secret_password']).construct_vault_encrypted_unicode(data_node)
    assert value.vault is not None
    assert value

# Generated at 2022-06-23 05:25:06.994016
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode

    node = MappingNode(u'tag:yaml.org,2002:map')
    obj = AnsibleConstructor().construct_yaml_map(node)

    assert isinstance(obj, AnsibleMapping)


# Generated at 2022-06-23 05:25:09.931031
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    assert AnsibleConstructor.construct_yaml_unsafe(None) is None

# Generated at 2022-06-23 05:25:18.917323
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ''' test_AnsibleConstructor_construct_yaml_str '''
    # test string
    value = 'this is a test string'
    # test yaml node
    node = '!<tag:yaml.org,2002:str>\nthis is a test string'
    # instance var
    ansible_constructor = AnsibleConstructor()
    # expected result
    result = ansible_constructor.construct_yaml_str(node)

    output = {'ansible_pos': (None, 1, 1), u'test_string': u'this is a test string'}

    # test
    assert result == value


# Generated at 2022-06-23 05:25:30.905292
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test without vault
    test_str1 = u'{"a" : "b", "a" : "c"}'
    test_str1_loaded = AnsibleLoader(test_str1).get_single_data()
    assert isinstance(test_str1_loaded, AnsibleMapping)
    assert test_str1_loaded == {"a":"c"}

    # dump and reload, so that the warning is triggered again
    test_str1_dumped = AnsibleDumper().dump(test_str1_loaded)

# Generated at 2022-06-23 05:25:42.990210
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test case 1
    # input_mapping: {"key1": "val1"}
    # expected_mapping: {"key1": "val1"}
    input_mapping = {"key1": "val1"}
    expected_mapping = {"key1": "val1"}

    # create a node of type MappingNode to mock the input argument to construct_mapping method
    class constructor_mapping_node():
        def __init__(self):
            self.start_mark = None
            self.end_mark = None

        def value(self):
            return input_mapping.items()

    construct_mapping_node = constructor_mapping_node()

    # mock the yaml.error.Mark() class to pass as start_mark attribute

# Generated at 2022-06-23 05:25:54.253306
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.scanner import Scanner
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import wrap_var
    test_path = os.path.join(os.path.dirname(__file__), 'yaml_test_files/test2.yml')
    stream = file(test_path, 'r')
    loader = AnsibleLoader(stream, 'test.yml', None)
    ret = loader.get_single_data()

# Generated at 2022-06-23 05:26:06.423446
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with byte string
    byte_input = b'a byte string'
    byte_input_node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str',
                                            value=byte_input)
    constructor = AnsibleConstructor(file_name='/dev/null')
    assert isinstance(constructor.construct_yaml_str(byte_input_node),
                      AnsibleUnicode)
    assert constructor.construct_yaml_str(byte_input_node) == u'a byte string'

    # Test with unicode string
    unicode_input = u'a unicode string'

# Generated at 2022-06-23 05:26:08.881653
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # TODO: Mock SafeConstructor.construct_yaml_seq to check the data
    #       is passed to it.
    pass


# Generated at 2022-06-23 05:26:13.322349
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
                       flow_style=None)
    a = AnsibleConstructor()
    assert isinstance(a.construct_mapping(node), AnsibleMapping)

# Generated at 2022-06-23 05:26:23.441957
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """ ansible.parsing.yaml.objects Test construct_yaml_map method of class AnsibleConstructor """


# Generated at 2022-06-23 05:26:33.460371
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from io import StringIO
    import yaml

    # create a vault
    vault = VaultLib([u'hello'])
    vault.encrypt(u'secret string')

    # create a string and write the vault to it.
    data = StringIO()
    yaml.dump(vault, data, Dumper=yaml.Dumper,
              explicit_start=True, explicit_end=True,
              default_flow_style=False)

    # parse the string with the AnsibleConstructor
    node = yaml.compose(data.getvalue())
    test_constructor = AnsibleConstructor()
    result = test_constructor.construct_vault_

# Generated at 2022-06-23 05:26:39.084492
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ac = AnsibleConstructor()
    # test basic values
    assert ac.construct_yaml_unsafe("abcdef") == "abcdef"
    assert ac.construct_yaml_unsafe(1) == 1
    # test objects
    assert type(ac.construct_yaml_unsafe(dict())) == AnsibleUnsafeText
    assert type(ac.construct_yaml_unsafe([])) == AnsibleUnsafeText



# Generated at 2022-06-23 05:26:50.614153
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create an instance of AnsibleConstructor
    constructor = AnsibleConstructor()

    # Create a MappingNode
    class nodeMock():
        def __init__(self):
            self.start_mark = None
            self.end_mark = None
    node = nodeMock()

    # Initialize value with a valid cipher text data

# Generated at 2022-06-23 05:26:58.376113
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # tests that we have access to ansible_pos attribute.

    test_yaml_str = """
        - hosts: all
          tasks:
            name: this is a test.
    """
    yaml_fragment = yaml.load(test_yaml_str, Loader=AnsibleConstructor)
    assert yaml_fragment[0]['hosts'].ansible_pos == ('<unicode str>', 1, 16)
    for task in yaml_fragment[0]['tasks']:
        assert task.ansible_pos == ('<unicode str>', 3, 17)
        assert task['name'].ansible_pos == ('<unicode str>', 4, 18)

# Generated at 2022-06-23 05:27:10.661639
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import unittest
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    class FakeNode:
        """this is a fake node class to be used by the unit test. It's
        attributes are overwritten by the unit test so the class itself
        doesn't have to be subclassed
        """
        pass

    class FakeSelf:
        """this is a fake class to be used by the unit test. It's
        attributes are overwritten by the unit test so the class itself
        doesn't have to be subclassed
        """
        def construct_object(self, node):
            return node


# Generated at 2022-06-23 05:27:21.829975
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    loader = DataLoader()

# Generated at 2022-06-23 05:27:30.133185
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultSecret
    import textwrap
    import os
    import tempfile
    import yaml
    import yaml.safe_dump as sd
    import yaml.safe_load as sl

    # create a temp file and fill it with some vault secrets
    tmpfd, tmpname = tempfile.mkstemp()
    with os.fdopen(tmpfd, 'w') as fp:
        passphrases = [ 'foo', 'bar' ]
        for passphrase in passphrases:
            fp.write(passphrase + '\n')

    # read the file
    vault_secrets = VaultSecret()
    vault_secrets.read(tmpname)

    # construct a yaml node with encrypted string

# Generated at 2022-06-23 05:27:31.822014
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert issubclass(AnsibleConstructor, SafeConstructor)

# Generated at 2022-06-23 05:27:41.610695
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Setup vault credentials
    vault_secrets = [b'vaultsecret']

    # Setup example yaml document
    yaml_str = u'_vault_encrypted: !vault $ANSIBLE_VAULT;1.1;AES256\n66413161323563376262633065643337306163633536616337313462640a37353337313965643337616632366536393538346465333964663762380a3263306263666634633039623139633365326532626461333266393764\n'

# Generated at 2022-06-23 05:27:44.464912
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    node = MappingNode(tag='tag:yaml.org,2002:map', value=None,
                       start_mark=None, end_mark=None)
    constructor.construct_mapping(node)

# Generated at 2022-06-23 05:27:54.876938
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib
    import os
    import tempfile
    import unittest
    import yaml

    class TestAnsibleConstructor(unittest.TestCase):

        def setUp(self):

            # create the file we'll read from
            (fd, self.file_name) = tempfile.mkstemp()

            # write some data to the file
            os.write(fd, b'''
foo:
  hi: world
bar:
  - "{{ x | y }}"
  - "{{ x ^ y }}"
''')

            # close the temp file and remove it from the filesystem before
            # the test executes
            os.close(fd)

        def tearDown(self):
            os.unlink(self.file_name)


# Generated at 2022-06-23 05:28:05.394729
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    origin_loder = AnsibleLoader
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

# Generated at 2022-06-23 05:28:09.140385
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    node = yaml.compose("""\
    key1: value1
    key2: value2
    """)
    c = AnsibleConstructor()
    c.construct_yaml_map(node)

# Generated at 2022-06-23 05:28:19.758095
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import ansible.module_utils.basic

    # Test with list
    dummy_list = ["a", ["b", "c"]]
    test_list = ansible.module_utils.basic._AnsibleModule__set_default_vars_to_unsafe(dummy_list)
    assert test_list == dummy_list

    # Test with dict
    dummy_dict = { "a": "b" }
    test_dict = ansible.module_utils.basic._AnsibleModule__set_default_vars_to_unsafe(dummy_dict)
    assert test_dict == dummy_dict

    # Test with str
    ansible_constructor = AnsibleConstructor()
    dummy_node = dict(start_mark=dict(line=1, column=2), value="dummy")

# Generated at 2022-06-23 05:28:30.521041
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    def check_wrap_var(value):
        ac = AnsibleConstructor()
        wrapped = ac.construct_yaml_unsafe(value)
        assert wrapped == wrap_var(value)

    # let's check if the function wrap_var works correctly
    # otherwise all tests would fail
    import re, random
    _string_output = re.compile(r"[uU]?'([^']*)'")
    _unicode_output = re.compile(r"u'([^']*)'")
    _letter_digits_dot_output = re.compile(r"([\w\.]+)")
    _float_output = re.compile(r"([\d.]+)")

    import sys

# Generated at 2022-06-23 05:28:41.380982
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    unsafe = "*&$"

    # Create a dummy class to represent unsafe data
    class DummyYAMLObject(AnsibleBaseYAMLObject):
        yaml_loader = AnsibleConstructor
        yaml_dumper = AnsibleDumper
        yaml_tag = u'!unsafe'
        def __init__(self, value):
            self.value = value
    obj = DummyYAMLObject(unsafe)

    # Convert the object to yaml
    yaml_data = AnsibleDumper.dump(obj)

    # Then load it back and verify the data is unchanged
    data = AnsibleConstructor.get_single_

# Generated at 2022-06-23 05:28:52.311713
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var
    from ansible.vars.unsafe_proxy import wrap_var as wrap_unsafe_var

    # test if the unsafe flag is set
    data = """
    - hosts: localhost
      tasks:
      - debug:
          msg: !unsafe "{{ mypassword }}"
    """
    manager = VariableManager()
    loader = AnsibleLoader(data, variable_manager=manager)
    inventory = loader.get_single_data()
    # the returned item should be wrapped in an UnsafeProxy
    assert isinstance(inventory, AnsibleUnsafeText)

# Generated at 2022-06-23 05:28:56.668805
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    actual = AnsibleConstructor.construct_yaml_map({'foo': 'bar'})
    assert isinstance(actual, dict)
    assert len(actual) == 1
    assert 'foo' in actual
    assert actual['foo'] == 'bar'



# Generated at 2022-06-23 05:29:05.717497
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Check the case of defining a variable to something that is not a
    # dictionary of strings.
    value = """
- hosts: all
  tasks:
    - shell: /usr/bin/foo
      register: shell_out
    - debug: msg="{{ shell_out.stdout }}"
    - debug: var=shell_out.stdout.rc
"""


# Generated at 2022-06-23 05:29:15.213320
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import os
    import sys
    import yaml
    import yaml.composer
    yaml.composer.Composer.ensure_node_class = None
    construct_yaml_str = AnsibleConstructor().construct_yaml_str
    f = os.path.dirname(os.path.abspath(__file__)) + os.sep + 'construct_yaml_str.yml'
    p = yaml.Parser()
    p.check_event = None
    p.parser.check_event = None
    p.parser.parser.check_event = None
    print(yaml.__version__)
    if yaml.__version__ >= '5.1':
        p.parser.parser.parser.check_event = None
        print()

# Generated at 2022-06-23 05:29:17.946523
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader

    print(AnsibleLoader('').get_constructor().construct_yaml_map(''))

# Generated at 2022-06-23 05:29:19.946117
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert isinstance(AnsibleConstructor().construct_yaml_str(None), AnsibleUnicode)


# Generated at 2022-06-23 05:29:29.824449
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode, AnsibleSequence
    a = AnsibleUnicode('foo')
    b = AnsibleMapping()
    c = AnsibleSequence()
    d = AnsibleUnicode('foo')

    # Test equality
    assert a == d

    # Test inequality
    assert a != b
    assert a != c
    assert b != c

    # Test hash
    assert hash(a) == hash(d)

    assert isinstance(a, AnsibleUnicode)
    assert isinstance(b, AnsibleMapping)
    assert isinstance(c, AnsibleSequence)

# Generated at 2022-06-23 05:29:32.166519
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor()
    assert a.construct_yaml_map(MappingNode) == AnsibleMapping()

# Generated at 2022-06-23 05:29:41.986804
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # pylint: disable=too-many-locals

    import yaml

    testobj = {
        'yaml_unsafe': yaml.unsafe_load("!unsafe {test_unsafe_var: 'test', test_var: 'test'}"),
        'test_var': 'test',
        'test_var2': 'test',
        'test_var3': 'test',
        'test_var4': 'test4',
        'test_var6': 'test6',
        'test_var7': 'test7',
        'test_var8': 'test8',
    }


# Generated at 2022-06-23 05:29:47.958504
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_str='''
- {'ip': u'10.10.10.1', 'group': 'all', 'user': 'root', 'passwd': 'xxxxx'}
- {'ip': u'10.10.10.2', 'group': 'all', 'user': 'root', 'passwd': 'xxxxx'}
'''
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import yaml
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, list)

# Generated at 2022-06-23 05:30:01.099019
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import datetime
    import yaml
    from ansible.parsing.utils.addresses import parse_address

    data = """
---
    # This is a simple example of the kinds of things we want to test.
    my_obj:
        name: myname
        age: 30
        address: localhost
        pingable: False
        date: 2011-01-01
        list:
            - a
            - 2
            - foo: 1
              bar: 3
            - [b,2,"foo"]
    ...
    """
    for load in [yaml.load, yaml.safe_load]:
        tp = load(data)
        assert tp['my_obj']['name'] == 'myname'
        assert tp['my_obj']['age'] == 30

# Generated at 2022-06-23 05:30:04.913089
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # We are testing a private method, pylint: disable=protected-access
    construct_yaml_map = AnsibleConstructor().construct_yaml_map
    assert isinstance(list(construct_yaml_map(None))[0], AnsibleMapping)



# Generated at 2022-06-23 05:30:15.315782
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # construct_yaml_unsafe should wrap the value in an AnsibleUnsafeText object

    class AnsibleConstructor_testConstruct(AnsibleConstructor):
        def construct_vault_encrypted_unicode(self, node):
            return self.construct_yaml_unsafe(node)

    c = AnsibleConstructor_testConstruct()
    c.construct_yaml_unsafe(c.construct_scalar(u'RGVhbCBJdCBJdA=='))
    value = u'RGVhbCBJdCBJdA=='
    # AnsibleUnsafeText objects should have this attribute
    assert hasattr(value, 'ansible_unsafe')


# Generated at 2022-06-23 05:30:23.360933
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_tag = u'tag:yaml.org,2002:map'
    test_map = {u'dupkey': u'hello world', u'key1': u'value1', u'key2': u'value2', u'dupkey': u'hello galaxy'}
    sorted_map = sorted(test_map.items(), key=lambda t: t[0])
    constructor = AnsibleConstructor()
    node = AnsibleConstructor.construct_mapping(constructor, test_map, deep=False)
    assert node.tag == yaml_tag
    assert node.value == sorted_map

# Generated at 2022-06-23 05:30:34.493516
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    '''
    Test _AnsibleClass_construct_yaml_map
    '''
    yaml_string = '''
test_key: test_value
test_key2: test_value2
test_key3: test_value3
test_key4: test_value4
'''
    yfile = io.BytesIO(to_bytes(yaml_string))
    constructed_dict = yaml.load(yfile)
    assert isinstance(constructed_dict, AnsibleMapping)


# Verify that we are actually testing the class we think we are testing

# Generated at 2022-06-23 05:30:46.969732
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    import unittest
    import yaml
    from os.path import dirname, join
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    class TestConstructVaultEncryptedUnicode(unittest.TestCase):

        def setUp(self):
            self.tests_dir = dirname(__file__)
            self.password = 'testpass'

# Generated at 2022-06-23 05:30:57.734297
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    marker = namedtuple("Mark", "index")

    value = "value"
    node = namedtuple("Node", "index,start_mark")(value, marker("59"))
    # with py2.6, reduce() is not in __builtins__
    if 'reduce' in globals():
        constructor = AnsibleConstructor.construct_yaml_str
    else:
        constructor = AnsibleLoader.construct_yaml_str

    ansible_unicode_test = constructor(node)

    assert ansible_unicode_test == AnsibleUnicode(value)

# Generated at 2022-06-23 05:31:09.030998
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test cases to be tested
    # 1. data is empty
    # 2. construct_sequence return empty value
    # 3. normal case
    # 1. data is empty
    # construct_yaml_seq will return AnsibleUnicode instance
    data = AnsibleSequence()
    instance = AnsibleConstructor()
    assert id(data) == id(instance.construct_yaml_seq(data))
    # 2. construct_sequence return empty value
    node = AnsibleSequence()
    node.id = 'seq'
    instance.construct_yaml_seq = 'construct_yaml_seq'
    ret = instance.construct_sequence(node)
    # construct_yaml_seq will return AnsibleUnicode instance
    assert ret == data
    # 3. normal case
    data = ['hello', 'world']
   

# Generated at 2022-06-23 05:31:18.608364
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # check the instances of unicode, int, float and str
    # unicode
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_str(u"ekansh")) is AnsibleUnicode
    # str
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_str(u"ekansh")) is AnsibleUnicode
    # int
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_str(123)) is AnsibleUnicode
    # float
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_str(123.123)) is AnsibleUnicode

# Generated at 2022-06-23 05:31:25.789360
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-23 05:31:37.083837
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader

    datastring = """\
        a: 1
        b: 2
        """
    data = AnsibleMapping(ansible_pos=(None, None, None))
    data.update({'a': 1, 'b': 2})

    yaml = AnsibleLoader(datastring, file_name='filename', vault_secrets=['vault_secret']).get_single_data()
    assert yaml == data
    assert yaml.ansible_pos == data.ansible_pos

    datastring = """\
        foo:
            a: 1
            b: 2
        bar:
            a: 1
            b: 2
        """
    data = AnsibleMapping(ansible_pos=(None, None, None))
    data.update