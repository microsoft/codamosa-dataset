

# Generated at 2022-06-23 05:21:39.158039
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Tests the method construct_yaml_str of the class AnsibleConstructor
    # with a string argument
    s = 'string'
    node = 'node'
    ansible_constructor = AnsibleConstructor(s, 'dummy_vaultsecrets')
    assert ansible_constructor.construct_yaml_str(node) == 'string'


# Generated at 2022-06-23 05:21:49.325636
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    data = """
    foo: !unsafe |-
       #!/bin/sh
       echo 'hello, world'
    """
    result, imports = AnsibleConstructor(data).get_single_data()
    assert 'foo' in result
    assert result['foo'].__class__.__name__ == 'str'

    # We can safely check whether this is correct by ensuring that
    # a shell interprets this as a script
    import subprocess
    try:
        p = subprocess.Popen(['/bin/sh', '-c', result['foo']], stdout=subprocess.PIPE)
    except TypeError:
        p = subprocess.Popen(['/bin/sh', '-c', result['foo'].encode('utf-8')], stdout=subprocess.PIPE)

    stdout

# Generated at 2022-06-23 05:21:57.410322
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_data_dir = 'data/ansible-vault/'
    import os
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test yaml file
    test_yaml = 'test_construct_mapping_assert.yml'
    test_yaml_file = os.path.join(test_data_dir, test_yaml)
    vault_secrets = ['12345']
    ansible_constructor = AnsibleConstructor(file_name=test_yaml_file, vault_secrets=vault_secrets)
    ansible_constructor._vaults['default'].secrets = vault_secrets


# Generated at 2022-06-23 05:22:05.546294
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    yaml = YAML()
    yaml.constructor = AnsibleConstructor

    string = "{'str': 'string value'}"
    assert {'str': 'string value'} == yaml.load(string)

    # Currently doesn't work with the python-yaml library
    if C.YAML_VERSION >= '5.1':
        string = "{'str': !unsafe 'string value'}"
        assert {'str': AnsibleUnsafeText('string value')} == yaml.load(string)

# Generated at 2022-06-23 05:22:17.836696
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    from tempfile import mkdtemp
    from yaml import load, dump
    from shutil import rmtree
    from ansible.module_utils.common.collections import is_sequence

    # Test string
    text = u"""---
    - hosts: all
      gather_facts: no
      ignore_errors: yes
      tasks:
        - name: "Test command"
          command: "{{item}}"
          register: foo
          with_items:
            - command_one
            - "command_two"
          unsafe:
            id: "The id keyword"
            class: "The class keyword"
            unknown: "An unknown keyword"
            attr: "An attribute"
    """

    # Load the string

# Generated at 2022-06-23 05:22:29.450894
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import os
    import tempfile
    if sys.version_info >= (3,):
        from importlib import reload

    import yaml

    xml_name = tempfile.NamedTemporaryFile()
    xml_name.write(b"""
test_a:
  - item: a1
    path: "/a/1"
  - item: a2
    path: "/a/2"
test_b:
  - item: b1
    path: "/b/1"
  - item: b2
    path: "/b/2"
""")
    xml_name.flush()
    xml_name.seek(0)


    # Get the path of the yaml file in the format the module expects

# Generated at 2022-06-23 05:22:32.442021
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode
    node = MappingNode()
    AnsibleConstructor(None, None).construct_mapping(node)
    return

# Generated at 2022-06-23 05:22:44.171781
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO


# Generated at 2022-06-23 05:22:55.018648
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.playbook.play_context as play_context
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    # Test case:
    # 1. On a normal dictionary object
    # 2. On a ansible-vault encrypted object
    # 3. On a dict object encoded as json data type

    # Test case 1:
    text1 = u'''{ simple: variable }'''
    loader1 = AnsibleLoader(text1)
    loader1.vault_secrets = []
    data1 = loader1.get_single_data()
    assert isinstance(data1, AnsibleMapping)
    assert isinstance(data1['simple'], AnsibleUnicode)
    assert data1._ansible_safe is False
    #

# Generated at 2022-06-23 05:23:04.367078
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml

# Generated at 2022-06-23 05:23:13.319720
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import to_safe_object
    import yaml
    for unsafe_dict in (dict(a=1, b=2, c=3), dict(a=1, b=2, c=3, d=4)):
        node = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=False)

# Generated at 2022-06-23 05:23:21.085758
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = """
        !!python/unicode '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3066616663636630663539333566646131346630643366343239393930643336306237346538\n          636334353338623162626562346664653362333337343664383365623164306564393734356330\n          326664333230343732346161623338636431326432383232653562313766633862626661303365\n          333735396466336530336262346164333630373533376663626133\n          '"""
    vault = VaultLib(secrets=['dummy_password'])
   

# Generated at 2022-06-23 05:23:31.790510
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    input_ = '{a: 1, b: 2, b: 3}'
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.resolver import Resolver
    parser = Parser(Reader(input_))
    scanner = Scanner(parser=parser)
    composer = Composer(scanner=scanner, resolver=Resolver())
    output = constructor.construct_mapping(composer.get_single_node())
    assert type(output) == dict
    assert output['a'] == 1
    assert output['b'] == 3



# Generated at 2022-06-23 05:23:42.032726
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    import yaml
    from yaml.nodes import ScalarNode

    # Make a mock node for use in AnsibleConstructor.construct_vault_encrypted_unicode
    ciphertext_data = "ciphertext"
    mock_node = ScalarNode(tag=u'!vault', value=ciphertext_data,
                           style='', start_mark=None, end_mark=None)

    # Call AnsibleConstructor.construct_vault_encrypted_unicode
    constructed_unicode = ansible_constructor.construct_vault_encrypted_unicode(mock_node)

    # Verify the constructed_unicode is an AnsibleVaultEncryptedUnicode
    assert isinstance(constructed_unicode, AnsibleVaultEncryptedUnicode)

   

# Generated at 2022-06-23 05:23:46.546552
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_ = AnsibleConstructor()
    ansible_constructor_.construct_yaml_map()


# Generated at 2022-06-23 05:23:58.596931
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    Test to make sure explicit strings are unicode strings
    """
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml import YAMLError
    from yaml import Mark
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultLib

    secret_val = 'foo'
    vault = VaultLib(secrets=[secret_val])
    value = vault.encode(secret_val)

    test_string =  u"""
    not_explicit_string: 'this is a string'
    explicit_string: !unsafe 'this is a string'
    vault_string: !vault-encrypted '%s'
    """ % value

# Generated at 2022-06-23 05:24:10.191920
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import shutil
    import tempfile
    import yaml


# Generated at 2022-06-23 05:24:21.378061
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os
    import sys
    import shutil
    import tempfile

    yaml_constructor = AnsibleConstructor

    td = tempfile.mkdtemp()

# Generated at 2022-06-23 05:24:31.387270
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class unit(object):
        def __init__(self):
            self.file_name = 'test_file'
            self._vaults = {'default': VaultLib(secrets=['test_vault_password'])}

    unit_instance = unit()
    load = AnsibleConstructor(file_name=unit_instance.file_name, vault_secrets=['test_vault_password']).construct_yaml_map
    try:
        result = load(None)
        assert False
    except TypeError as exc:
        assert to_native(exc) == 'construct_yaml_map() takes exactly 2 arguments (1 given)'

# Generated at 2022-06-23 05:24:33.798583
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    c = AnsibleConstructor()
    res = c.construct_yaml_map("some text")
    assert res == "some text"


# Generated at 2022-06-23 05:24:42.878539
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    import os
    import json
    from ansible.parsing.yaml.loader import AnsibleLoader

    # 1. get the data from test file
    local_file = os.path.join(os.path.dirname(__file__), 'construct_vault_encrpyted_unicode_test.yaml')
    with file(local_file, 'rb') as f:
        data = f.read()

    # 2. get the vault secret
    key_file = os.path.join(os.path.dirname(__file__), '../lib/ansible/parsing/vault/test_vault.key')
    vault_secret = VaultLib(secrets=[key_file],
                            pwhash=None,
                            )._

# Generated at 2022-06-23 05:24:51.365419
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    yaml.constructor.BaseConstructor = AnsibleConstructor
    yaml.constructor.SafeConstructor = AnsibleConstructor
    ansible_constructor = AnsibleConstructor()

    yaml_str = """
foo:
  baz:
    - item1
    - item2
    - 3
"""
    data = yaml.load(yaml_str)
    assert data['foo']['baz'][2] == 3
    #assert data['foo']['baz'][2] is int



# Generated at 2022-06-23 05:25:01.799803
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ''' test method construct_yaml_unsafe

        AnsibleConstructor.construct_yaml_unsafe(node) -> object

        # @param object node The Yaml node to construct.

        # @return object An object tree of native Python objects.
    '''
    import __builtin__
    import yaml

    # Test with basic types as 'node'

# Generated at 2022-06-23 05:25:10.044804
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # see http://stackoverflow.com/questions/2447353/get-args-parameters-within-a-python-class-init
    class MockConstructor:
        def construct_mapping(self, node, deep=False):
            return node.value

    constructor = AnsibleConstructor()
    constructor.construct_mapping = MockConstructor.construct_mapping
    assert constructor.construct_yaml_map({'value': [['key1', 'value1'], ['key2', 'value2']]}) == {'key1': 'value1', 'key2': 'value2'}


# Generated at 2022-06-23 05:25:20.341984
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # prepare input for tested method
    yaml_data = to_bytes("""
        one: 1
        two: 2
        three: 3
    """)
    node_value = [
        [u'one', u'1'],
        [u'two', u'2'],
        [u'three', u'3']
    ]
    node_mapping = MappingNode(tag=u'tag:yaml.org,2002:map', value=node_value, start_mark=None, end_mark=None)

    # test method construct_mapping for duplicated key
    # expected output:
    #   - return error

# Generated at 2022-06-23 05:25:25.009768
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    assert isinstance(AnsibleConstructor().construct_yaml_unsafe("hi"), AnsibleUnsafeText)

# Generated at 2022-06-23 05:25:33.350090
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode, AnsibleVaultEncryptedUnicode
    from collections import namedtuple
    from ansible.parsing import vault
    # plaintext, ciphertext, vault_id, vault_secret, key_id
    _VaultEncryptionTest = namedtuple('_VaultEncryptionTest', 'plaintext ciphertext vault_id vault_secret key_id')

    def _create_vault_test_data(plaintext, key_id='_'):
        vault_id = None
        vault_secret = None
        ciphertext = None
        if key_id not in (None, '_'):
            vault_id = 'default'
            vault_secret = 'default-vault-secret'
            vault_lib = vault.Vault

# Generated at 2022-06-23 05:25:37.637289
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    constructor = AnsibleConstructor()
    data = AnsibleSequence()
    node = AnsibleMapping()
    data.extend(constructor.construct_sequence(node))
    data.ansible_pos = constructor._node_position_info(node)


# Generated at 2022-06-23 05:25:38.297613
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
  assert True

# Generated at 2022-06-23 05:25:47.558654
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from io import StringIO
    from ansible.module_utils.six import PY3

    yaml_str = """
---
key1: value1
key2: 2
key3: 3
key4:
    subkey1: value1
    subkey2: 2
    subkey3:
        subsubkey1: value1
        subsubkey2: 2
"""
    stream = StringIO(yaml_str)
    c = AnsibleConstructor(file_name='filename')
    d = yaml.load(stream, Loader=yaml.Loader)
    assert d['key1'] == 'value1'
    assert d['key2'] == 2
    assert d['key3'] == 3
    assert d['key4']['subkey1'] == 'value1'

# Generated at 2022-06-23 05:25:53.095954
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.constants as C
    config_data = """
    normal_key: simple string
    unsafe_key: !unsafe None
    """
    config = yaml.load(config_data, Loader=AnsibleConstructor)
    assert config['normal_key'] == "simple string"
    assert config['unsafe_key'] == C.DEFAULT_UNSAFE_BYTES_VALUE

# Generated at 2022-06-23 05:26:03.980200
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml
    yaml_data = """
    - !unsafe '{{ foo }}'
    - !unsafe '{{ bar }}'
    - !unsafe ['foo', 'bar', 'baz']
    - !unsafe ['foo', '{{ bar }}', 'baz']
    - !unsafe {foo: bar, bar: '{{ foo }}'}
    - !unsafe {foo: bar, bar: ['{{ foo }}', 'baz']}
    - !unsafe {foo: bar, bar: {baz: '{{ foo }}'}}
    """
    yaml_obj = yaml.load(yaml_data, Loader=AnsibleLoader)
    assert isinstance(yaml_obj, list)

# Generated at 2022-06-23 05:26:07.182094
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    t = "test"
    #TODO/FIXME: add a couple of unit tests here like python's yaml.loader test
    assert AnsibleConstructor.construct_yaml_str(t) is not None

# Generated at 2022-06-23 05:26:17.201164
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    class TestVaultLib:
        def __init__(self, secrets=None):
            self.secrets = secrets

        def _AsymmetricVault__get_secret(self, secret_id):
            return self.secrets.get(secret_id)

    test_vault_secrets = [
        {'secret_id': 'vault1', 'secret': 'vault1secret'},
        {'secret_id': 'vault2', 'secret': 'vault2secret'}
    ]
    test_vault_lib = TestVaultLib(secrets={'vault1': 'vault1secret', 'vault2': 'vault2secret'})
    constructor = AnsibleConstructor(file_name='unit-test', vault_secrets=test_vault_secrets)

# Generated at 2022-06-23 05:26:26.114400
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Given
    a_file_name = 'my_file.yml'
    a_vault_secrets = ['vault_secret_1', 'vault_secret_2']
    a_node = MappingNode()
    a_node.tag = 'tag:yaml.org,2002:map'
    a_node.start_mark = 'start_mark'
    a_node.end_mark = 'end_mark'
    a_node.flow_style = 'flow_style'
    a_node.anchor = 'anchor'
    a_node.implicit = True
    a_node.value = [('a_key','an_value'), ('another_key','another_value')]
    a_deep = True
    # When

# Generated at 2022-06-23 05:26:28.323528
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Test constructor with only file name given
    test_obj1 = AnsibleConstructor(file_name='test/network.yml')
    assert test_obj1._ansible_file_name == 'test/network.yml'

# Generated at 2022-06-23 05:26:36.864701
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.module_utils.six import StringIO, PY3


# Generated at 2022-06-23 05:26:44.820954
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import io

    # Create test data
    node = u'[a,b,c]\n'

    # Create stream
    stream = io.StringIO(node)

    # Assign sys.stdout to stream, so all print output will directed to stream
    sys.stdout = stream

    # Create AnsibleConstructor instance, and construct data
    construct = AnsibleConstructor()
    # The following statement will output the following, which is the
    # reference output:
    # data = AnsibleSequence()
    # yield data
    # data.extend(self.construct_sequence(node))
    # data.ansible_pos = self._node_position_info(node)
    construct.construct_yaml_seq(node)

    # Restore sys.stdout to its normal value (the console)

# Generated at 2022-06-23 05:26:48.950312
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    AnsConstruct=AnsibleConstructor()
    assert AnsConstruct.construct_yaml_seq([2]) == [[2], '2']
    assert AnsConstruct.construct_yaml_seq(['a', 'b', 'c']) == [['a', 'b', 'c'], 'a']

# Generated at 2022-06-23 05:26:53.722119
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    ansible_constructor = AnsibleConstructor()
    node = AnsibleMapping()
    node.ansible_pos = (None, None, None)
    result = ansible_constructor.construct_yaml_map(node)
    assert result == node

# Generated at 2022-06-23 05:27:03.634420
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import datetime
    if sys.version_info >= (3, 0):
        import io
        StringIO = io.StringIO
    else:
        import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['secret1']
    vault = VaultLib(vault_secrets)

    loader = AnsibleLoader(StringIO("abc"), file_name="(test)", vault_secrets=vault_secrets)
    loader.vaults['vault'] = vault
    loader.vaults['myvault'] = vault
    # no vault in play
    loader.vaults['_'] = vault

    string_node = loader.get_single_node()
    # default no vault in play, should

# Generated at 2022-06-23 05:27:15.331673
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import ansible.constants as C
    import ansible.parsing.yaml.data_loaders as loaders
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode

    # Ensure parameters for testing are not set in ansible.cfg
    del C.DEFAULT_VAULT_PASSWORD_FILE[:]

    # Create an AnsibleConstructor and set the vault_secrets
    ac = loaders.DataLoader()._constructor
    ac.vault_secrets = [ b'encryptedpassword' ] # bytes

    # Create a node object
    class Node(object):
        start_mark = ''
    node = Node()

    # Test vault encrypted string

# Generated at 2022-06-23 05:27:23.830983
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    import yaml

    class TestAnsibleConstructor(unittest.TestCase):
        def test_construct_yaml_unsafe(self):
            yaml_src = '''
            ---
            - hosts: localhost
              gather_facts: false
              tasks:
                - name: run the whoami command
                  win_shell: "!unsafe cmd.exe /c whoami"
                  delegate_to: localhost
            '''

            # ensure we're using our own custom Ansible constructor
            yaml.Loader = AnsibleConstructor

            # load the yaml, which will fail without the fix for this issue

# Generated at 2022-06-23 05:27:34.874998
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = '''\
        test:
            key: value\
        '''

    # mostly interested in seeing if this actually raises an error,
    # as it will if we don't squelch the exception properly
    from ansible.parsing.yaml.loader import AnsibleLoader
    doc = AnsibleLoader(data, file_name='(string)').get_single_data()
    assert doc['test']['key'] == 'value'

    # test duplicates
    data = '''\
        test:
            key: value
            key: value2
        '''
    doc = AnsibleLoader(data, file_name='(string)').get_single_data()
    assert doc['test']['key'] == 'value2'


# Generated at 2022-06-23 05:27:46.163580
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys

    construct = AnsibleConstructor()

    # this is a string
    data = construct.construct_yaml_map(MappingNode(None, None, True))
    assert type(data) is AnsibleMapping
    assert data.ansible_pos == ('<unicode string>', 1, 0)

    # this is a string in python 3
    if sys.version_info >= (3, 0):
        data = construct.construct_yaml_map(MappingNode(None, None, False))
        assert type(data) is AnsibleMapping
        assert data.ansible_pos == ('<unicode string>', 1, 0)

    # this is a file
    data = construct.construct_yaml_map(MappingNode(None, None, None, None, 'thisfile.txt'))
    assert type

# Generated at 2022-06-23 05:27:56.409221
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Test method AnsibleConstructor.construct_yaml_seq
    """

    import random
    import string
    import inspect

    import yaml

    module = 'test_lib_parsing_yaml_constructor'

    mark = yaml.Mark('', None, None, None, None, None)


# Generated at 2022-06-23 05:28:07.713820
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import tempfile
    yaml_data = """
---
test:
  test_1: value1
  test_2: value2
  test_3: value3
    """
    tmp_f = tempfile.NamedTemporaryFile(delete=False)
    tmp_fname = tmp_f.name
    tmp_f.close()
    with open(tmp_fname, 'w') as yaml_fd:
        yaml_fd.write(yaml_data)
    constructor=AnsibleConstructor(tmp_fname)
    data = constructor.get_single_data()
    if 'test' not in data:
        sys.stderr.write("test_AnsibleConstructor_construct_yaml_map failed, could not find test in data")
        sys.exit(1)


# Generated at 2022-06-23 05:28:13.245956
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    byte_literal = b"test"
    c = AnsibleConstructor()
    res = c.construct_yaml_str(yaml.nodes.ScalarNode(None, byte_literal, (0,0), (0,0), None))
    assert isinstance(res, AnsibleUnicode)
    assert res == u"test"

# Generated at 2022-06-23 05:28:23.355246
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()

    assert(type(ansible_constructor.construct_yaml_unsafe(u"tag:yaml.org,2002:str", u"string")) == AnsibleUnicode)
    assert(type(ansible_constructor.construct_yaml_unsafe(u"tag:yaml.org,2002:python/unicode", u"string")) == AnsibleUnicode)
    assert(type(ansible_constructor.construct_yaml_unsafe(u"tag:yaml.org,2002:python/bytes", b"string")) == bytes)
    assert(type(ansible_constructor.construct_yaml_unsafe(u"tag:yaml.org,2002:python/int", 123)) == int)

# Generated at 2022-06-23 05:28:33.595548
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultEditor
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser

    with open("example.yaml", 'r') as stream:
        src = stream.read()
    # construct vault password
    vault_pass = VaultEditor('/tmp/example.yaml', vault_secrets=['pass1'])
    # construct composer
    reader = Reader(src)
    scanner = Scanner(reader)
    parser = Parser(scanner)
    composer = Composer(parser, AnsibleConstructor('/tmp/example.yaml', vault_pass))
    # construct document:
    document = composer.get_single_node()
    # test result

# Generated at 2022-06-23 05:28:39.614361
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # initial setup
    yaml_str = u'foobar'
    node = object()
    ac = AnsibleConstructor()

    # call the method
    result = ac.construct_yaml_str(node)

    assert isinstance(result, AnsibleUnicode)
    assert result == yaml_str
    assert result.ansible_pos == (None, None, None)

# Generated at 2022-06-23 05:28:47.980713
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    ac = AnsibleConstructor()
    result = ac.construct_yaml_map(MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None))
    assert isinstance(result, AnsibleMapping)
    result = ac.construct_yaml_str(MappingNode(tag=u'tag:yaml.org,2002:str', value=[], start_mark=None, end_mark=None))
    assert isinstance(result, AnsibleUnicode)
    result = ac.construct_yaml_seq(MappingNode(tag=u'tag:yaml.org,2002:seq', value=[], start_mark=None, end_mark=None))
    assert isinstance(result, AnsibleSequence)

# Generated at 2022-06-23 05:28:59.550692
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    secrets = ['hunter2']
    c = AnsibleConstructor(vault_secrets=secrets)

    # If a valid vault item is parsed, and there's a password provided,
    # the ciphertext should be decrypted.
    value = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          39373665363865383966323666626631323139623735393764313231623262383339376232316164\n          35353439386261323136656331666237616233396433383934396366396133383162363966663133\n          36316139623634393935363438643833613037623163636633661\n          "
    expected_value = 'my secret'

# Generated at 2022-06-23 05:29:10.891436
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Make a constructor
    ac = AnsibleConstructor()

    # Make a test string
    test_data = b"---\nnum: 123\nmyStr: abc\nmyList: [1,2,3]\nmyDict: {key: value, key2: value2}\n"

    # Test for yaml_map
    assert ac.construct_yaml_map(test_data) == {u'num': 123, u'myStr': u'abc', u'myList': [1, 2, 3], u'myDict': {u'key2': u'value2', u'key': u'value'}}

    # Test for yaml_seq

# Generated at 2022-06-23 05:29:21.342486
# Unit test for constructor of class AnsibleConstructor

# Generated at 2022-06-23 05:29:26.455865
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_obj = AnsibleConstructor(file_name='/path/to/filename')
    value = yaml_obj.construct_yaml_str(None)
    assert isinstance(value, AnsibleUnicode)
    assert value.ansible_pos == ('/path/to/filename', 0, 0)


# Generated at 2022-06-23 05:29:34.303581
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    data = """
---
- {a: 1, b: 2}
- [ 10, 15, 20 ]
- "a string"
- "!unsafe {'a': '1' }"
...
"""
    ac = AnsibleConstructor()
    seq = ac.construct_yaml(data)
    assert isinstance(seq[0], AnsibleMapping)
    assert isinstance(seq[1], AnsibleSequence)
    assert isinstance(seq[2], AnsibleUnicode)
    assert isinstance(seq[3], AnsibleUnicode)
    assert seq[3] == "!unsafe {'a': '1' }"

# Generated at 2022-06-23 05:29:43.011207
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    src = u"""---
- name: test1
  dict2:
    key: value
  dict:
    key: value
  list:
  - 1
  - 2
  - 3
- name: test2
  dict2:
    key: value
  dict:
    key: value
  list:
  - 1
  - 2
  - 3
"""

    mappings = yaml.load(src, AnsibleConstructor)
    for item in mappings:
        assert 'ansible_pos' in item
        assert type(item) == AnsibleMapping
        for value in item['dict'].values():
            assert type(value) == AnsibleUnicode


# Generated at 2022-06-23 05:29:52.099597
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import os
    from vars import VarsModule
    loader = VarsModule()
    data = '''
    ---
    a:
        b:
            c: 1
            d: 2
    e:
        f: 3
        g: 4
        h:
            i: 5
            j:
                k: 6
                l: 7
    '''
    ansible_constructor = AnsibleConstructor()

    ret_yaml = ansible_constructor.construct_yaml_map(loader.load(data))
    ret_safe = ansible_constructor.construct_yaml_map(loader.load(data))

    assert ret_yaml == ret_safe


# Generated at 2022-06-23 05:29:57.508961
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    data = """
        a: 1
        b: 2
    """
    ac = AnsibleConstructor()
    d = ac.construct_document(data)
    assert d == {'a': 1, 'b': 2, 'ansible_pos': (u'<unicode string>', 1, 0)}

# Generated at 2022-06-23 05:30:06.206051
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor()
    vault_password = 'secret'
    constructor.vault_secrets = [vault_password]
    encrypted_text = b'$ANSIBLE_VAULT;1.2;AES256;stephen\n633263306465663739356663643035626433633064333134376436363064393664326465343932\n393163373236633439346538623064356463376466633830333537326632333739363537653966\n656163633136646232306366626630346635353262323430'
    unsafe = constructor.construct_vault_encrypted_unicode(None, encrypted_text)

# Generated at 2022-06-23 05:30:15.951062
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class YmlFile:
        def __init__(self, name, contents):
            self.name = name
            self.contents = contents

    class Node:
        def __init__(self, start_mark, value):
            self.start_mark = start_mark
            self.value = value

    class Mark:
        def __init__(self, name='testcase', line=0, column=0):
            self.name = name
            self.line = line
            self.column = column

    ac = AnsibleConstructor()
    # can't test with an empty vault secrets list, so we pass in an old password
    # for testing
    ac.vault_secrets = [ 'ansible' ]

# Generated at 2022-06-23 05:30:24.233289
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Create a yaml sequence node to pass to AnsibleConstructor.construct_yaml_seq
    import yaml
    node = yaml.nodes.SequenceNode(tag=u'tag:yaml.org,2002:seq',
                                   value=[],
                                   start_mark=None,
                                   end_mark=None,
                                   flow_style=True)
    # Create a AnsibleConstructor
    # Use a default vault_secrets which is [], as that is already tested in
    # test_VaultLib_decrypt_vault_data
    ansible_constructor = AnsibleConstructor(vault_secrets=[])
    ansible_constructor.construct_yaml_seq(node)
    assert isinstance(ansible_constructor, AnsibleConstructor)

# Generated at 2022-06-23 05:30:34.702618
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test if constructor detects duplicate keys
    # while constructing a mapping and throws appropriate error/warning

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    # Create an object for AnsibleConstructor class and construct a mapping
    obj = AnsibleConstructor()

    # Test if constructor throws ConstructorError when
    # duplicate keys are found and DUPLICATE_YAML_DICT_KEY set to 'error'
    C.DUPLICATE_YAML_DICT_KEY = 'error'
    # Create mapping node
    node1 = AnsibleMapping()
    node1.ansible_pos = ('hello',1,1)
    # Append a new key-value pair

# Generated at 2022-06-23 05:30:45.115435
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Create a node of type MappingNode with the key and the value
    node = AnsibleConstructor.construct_mapping(node, deep=False)
    # Create an AnsibleSequence object
    data = AnsibleSequence()
    # Verify that the data.ansible_pos is not set
    assert data.ansible_pos is None
    # Construct a sequence using the construct_yaml_seq method
    constructed_sequence = AnsibleConstructor.construct_yaml_seq(node)
    # Verify that constructed_sequence is an AnsibleSequence object
    assert isinstance(constructed_sequence, AnsibleSequence)
    # Verify that constructed_sequence.ansible_pos is not None
    assert constructed_sequence.ansible_pos is not None

# Generated at 2022-06-23 05:30:52.952491
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from collections import namedtuple
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    import os

    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # Setup for testing
    # the data we need to pass to the constructor of AnsibleConstructor
    fake_file_name = 'not_a_file'
    vault = None
    vault_secrets = []
    unsafe_test_one = 'tag:yaml.org,2002:python/object:collections.namedtuple'
    node_one = namedtuple('node', 'tag id start_mark end_mark value')
    node_one.tag = unsafe_test_one
    node_one.id = 'object'
    node_

# Generated at 2022-06-23 05:30:59.654749
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    mapping_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
                               start_mark=None, end_mark=None, flow_style=False)
    constructed = ansible_constructor.construct_yaml_map(mapping_node)
    assert isinstance(list(constructed)[0], AnsibleMapping)



# Generated at 2022-06-23 05:31:08.590771
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    This is a unit test for AnsibleConstructor.construct_yaml_seq
    """
    class SimpleNode(yaml.Node):
        def __init__(self, value):
            self.value = value
    node = SimpleNode([1,2,3])
    data = AnsibleConstructor.construct_yaml_seq(AnsibleConstructor, node)
    seq = next(data)
    assert isinstance(seq, AnsibleSequence)
    assert seq == [1,2,3]


# Generated at 2022-06-23 05:31:09.707477
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # ignore for now
    pass


# Generated at 2022-06-23 05:31:16.266244
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    yaml_src = '''
    test_unsafe: !unsafe
    '''

    data = yaml.load(yaml_src, Loader=AnsibleLoader)
    assert data['test_unsafe'].__class__.__name__ == 'ansible_unsafe'
    assert data['test_unsafe'].__class__.__module__ == 'ansible.utils.unsafe_proxy'

# Generated at 2022-06-23 05:31:21.200618
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    yaml_str = '''
                b: foo
                a: bar
                '''
    data = AnsibleConstructor().construct_yaml(yaml_str)
    print(data)


# Generated at 2022-06-23 05:31:30.199022
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()
    str1 = u'test'
    str2 = 'test'
    str3 = b'test'

    result = constructor.construct_yaml_str(str1)
    assert isinstance(result, AnsibleUnicode)
    assert result.data == str1

    result = constructor.construct_yaml_str(str2)
    assert isinstance(result, AnsibleUnicode)
    assert result.data == str2

    result = constructor.construct_yaml_str(str3)
    assert isinstance(result, AnsibleUnicode)
    assert result.data == str3

# Generated at 2022-06-23 05:31:40.111928
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # This will fail if the class AnsibleConstructor does not have
    # the methods/constructors added for AnsibleMapping, AnsibleSequence,
    # and AnsibleUnicode.
    import yaml

    check_constructor(yaml, AnsibleConstructor, "!vault", AnsibleVaultEncryptedUnicode)
    check_constructor(yaml, AnsibleConstructor, "!vault-encrypted", AnsibleVaultEncryptedUnicode)
    check_constructor(yaml, AnsibleConstructor, "tag:yaml.org,2002:map", AnsibleMapping)
    check_constructor(yaml, AnsibleConstructor, "tag:yaml.org,2002:str", AnsibleUnicode)