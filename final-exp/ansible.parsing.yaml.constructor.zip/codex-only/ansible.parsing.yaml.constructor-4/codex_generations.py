

# Generated at 2022-06-23 05:21:44.795566
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    c = AnsibleConstructor()
    a = yaml.load(StringIO.StringIO('string'), Loader=c)
    assert isinstance(a, AnsibleUnicode)
    assert a == AnsibleUnicode(u'string')
    b = yaml.load(StringIO.StringIO('\nstring'), Loader=c)
    assert isinstance(b, AnsibleUnicode)
    assert b == AnsibleUnicode(u'string')
    c = yaml.load(StringIO.StringIO('\nstring\n'), Loader=c)
    assert isinstance(c, AnsibleUnicode)

# Generated at 2022-06-23 05:21:50.658289
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yamlobj = AnsibleConstructor()
    node = "test"
    # The method AnsibleConstructor.construct_yaml_seq(self, node)
    # needs a node, so this test is not very useful
    assert_raises(TypeError, yamlobj.construct_yaml_seq, node)
    assert_raises(TypeError, yamlobj.construct_yaml_seq, None)
    assert_raises(NotImplementedError, yamlobj.construct_yaml_seq)

# Generated at 2022-06-23 05:22:00.285824
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # ARANGE
    import yaml

    yaml.add_constructor(u'tag:yaml.org,2002:seq', AnsibleConstructor.construct_yaml_seq)
    value = [1, 2, 3, 4]
    test_yaml = yaml.safe_dump(value, encoding='utf-8', allow_unicode=True)

    # ACT
    loader = yaml.Loader(test_yaml)
    result = loader.get_single_data()

    # ASSERT
    assert len(result) == len(value)
    assert result[0] == value[0]
    assert result[-1] == value[-1]



# Generated at 2022-06-23 05:22:11.354011
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import tempfile
    import shutil
    import yaml
    import unittest

    # We need a temporary directory to store our test yaml files
    temp_directory = tempfile.mkdtemp()

    # Now we add a set of test files to this directory
    # We need to create a temp file.  This can't be a named temp file
    # because we may be running as a regular user and not root,
    # so we can't write to the /etc/ansible directory
    (file_descriptor, yaml_file_name) = tempfile.mkstemp(dir=temp_directory)


# Generated at 2022-06-23 05:22:18.946662
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    test_content = """\
a: aaaa
b: bbbb
c:
  c1: c111
  c2: c222
d: ddd
"""

    expected_result = {
        u'a': u'aaaa',
        u'b': u'bbbb',
        u'c': {u'c1': u'c111', u'c2': u'c222'},
        u'd': u'ddd',
    }
    result = yaml.load(test_content, Loader=AnsibleConstructor)
    assert result == expected_result



# Generated at 2022-06-23 05:22:30.298203
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.utils import context_objects as co
    from ansible.parsing.yaml.objects import AnsibleMapping
    res = AnsibleConstructor().construct_mapping(MappingNode(None, None, False))
    assert isinstance(res, AnsibleMapping)
    assert isinstance(res._data, co.AnsibleContext)
    assert len(res._data) == 0
    assert res.ansible_pos == ("<unicode string>", 1, 0)

    res2 = AnsibleConstructor("foobar.yml").construct_mapping(MappingNode(None, None, False))
    assert isinstance(res2, AnsibleMapping)
    assert isinstance(res2._data, co.AnsibleContext)
    assert len(res2._data) == 0
    assert res2.ans

# Generated at 2022-06-23 05:22:41.792153
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_passwd = "abcd1234"
    user_vars = "[default]\n"
    user_vars += "%svault_password_file = %s\n" % (C.DEFAULT_VAULT_IDENTITY_LIST, vault_passwd)
    user_vars_in_file = False
    vault_identity_list = [{"vault_password_file": "abcd1234"}]
    vault_secrets = [{"password": "abcd1234"}]

    # With vault_identity_list set
    ac = AnsibleConstructor(vault_secrets=vault_secrets)
    value = ac._vaults['default'].encrypt(u"foo")
    node = dict()
    node['value'] = value
    node['start_mark'] = dict()
    node

# Generated at 2022-06-23 05:22:43.495614
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    pass

# Generated at 2022-06-23 05:22:54.579910
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    import io

    class ConcatenatingArguments(object):
        def __init__(self, *args, **kwargs):

            # We need to do this because Ansible 2.9 sees the last argument as a boolean value, which isn't supported for Constructor init
            if type(args[-1]) is bool:
                args = args[:-1]

            self.args = args
            self.kwargs = kwargs

            self.ansible_pos = None

        def __repr__(self):
            return str((self.args, self.kwargs))

    yaml.SafeLoader.add_constructor(u'!join', ConcatenatingArguments)


# Generated at 2022-06-23 05:23:04.036883
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import load
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-23 05:23:13.156677
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(stream=None, file_name='dummy_file_name')
    ansible_constructor = AnsibleConstructor(file_name=loader._stream_file_name, vault_secrets=[])
    yaml_node = {'tag': u'tag:yaml.org,2002:seq', 'start_mark': {'line': 1, 'column': 1, 'buffer': None, 'pointer': 0}, 'end_mark': {'line': 1, 'column': 1, 'buffer': None, 'pointer': 0}, 'style': None, 'value': []}
    result = ansible_constructor.construct_yaml_seq(yaml_node)
    assert result == []

# Generated at 2022-06-23 05:23:24.962837
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    print("Test AnsibleConstructor")
    test_yaml = AnsibleConstructor("test_yaml.yaml")
    print("Testing Construct_yaml_map function")
    test_map = test_yaml.construct_yaml_map("test_map.yaml")
    test_map_result = {"key1": "value1",
                       "key2": "value2"}
    assert test_map == test_map_result
    print("Testing Construct_yaml_str function")
    test_str = test_yaml.construct_yaml_str("test_str.yaml")
    test_str_result = b"test_str.yaml"
    assert test_str == test_str_result
    print("Testing Construct_yaml_seq function")
    test_seq = test_yaml.construct_y

# Generated at 2022-06-23 05:23:29.731838
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from yaml import Loader

    node = ScalarNode(u'tag:yaml.org,2002:str', u'test')
    loader = Loader(node)
    loader.construct_yaml_str(node)

# Generated at 2022-06-23 05:23:40.547716
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var

    ansible_constructor = AnsibleConstructor()
    scalar_node = ScalarNode('tag:yaml.org,2002:str','blah','value','None','None')
    value = ansible_constructor.construct_yaml_str(scalar_node)
    assert isinstance(value, AnsibleUnicode)
    assert value.strip() == 'blah'
    assert value.strip() == unicode(value)
    assert value.get_unicode() == 'blah'
    assert value.get_safe_text().strip() == 'blah'


# Generated at 2022-06-23 05:23:51.067783
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible.parsing.yaml.loader as yaml_loader
    node = MappingNode(None, None, [], [], [], True)
    a = AnsibleConstructor(file_name=None, vault_secrets=None)
    assert isinstance(a.construct_mapping(node), dict)
    assert isinstance(a.construct_mapping(node), AnsibleMapping)

    # Test case with duplicate dict key and DUPLICATE_YAML_DICT_KEY = ignore
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    key_node = yaml_loader.AnsibleLoader('').construct_object(node=21)
    value_node = yaml_loader.AnsibleLoader('').construct_object(node=42)
    node.value

# Generated at 2022-06-23 05:23:55.948162
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml = """
    - a
    - b
    - c
    """
    assert [u'a', u'b', u'c'] == AnsibleLoader(yaml).get_single_data()


# Generated at 2022-06-23 05:24:08.187691
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml

    # Test that when a file is parsed with the AnsibleConstructor, the
    # position output for each element in the AnsibleMapping is correct
    test_data = """
- hosts: all
  gather_facts: true
  tasks:
    - debug:
        msg: "{{ ansible_all_ipv4_addresses }}"
    - debug:
        var: item
      with_items:
        - 1
        - 2
        - 3
    - debug:
        msg: "test"
"""

    def my_yaml_process(stream):
        """
        Mocks out the yaml.load function and then calls the real yaml.load function
        so that we have a reference to the original yaml parser
        """

# Generated at 2022-06-23 05:24:14.853188
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault = VaultLib(password="hello")
    value = AnsibleVaultEncryptedUnicode(vault.encrypt("world"))
    node = AnsibleDumper.represent_yaml_unsafe(value)

    # Ensure that AnsibleConstructor.construct_yaml_unsafe will cast the constructed
    # node back to an AnsibleVaultEncryptedUnicode object
    constructed_value = AnsibleConstructor.construct_yaml_unsafe(node)

    assert constructed_value == value

# Generated at 2022-06-23 05:24:25.812694
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from io import StringIO
    from ansible.utils import context_objects as co

    if not co.HAS_ATTRIBUTES:
        return

    yaml_str = '''
            foo: "bar"
            '''

    yaml_reader = Reader(StringIO(yaml_str))
    yaml_parser = Parser(yaml_reader)
    yaml_scanner = Scanner(yaml_parser)
    yaml_composer = Composer(yaml_scanner)
    yaml_constructor = AnsibleConstructor()

    yaml_document = yaml_composer.get_single_node()


# Generated at 2022-06-23 05:24:31.212870
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    constructor = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', start_mark=None, end_mark=None, value=None)
    data = constructor.construct_yaml_map(node)
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 0

# Generated at 2022-06-23 05:24:34.052312
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    test_string = 'test_string'
    test_node = AnsibleUnicode(test_string)
    assert(test_string == test_node)


# Generated at 2022-06-23 05:24:43.064105
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:24:48.126036
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test data
    data = '''
---
- foo
- bar
'''
    assert isinstance(AnsibleLoader(data).get_single_data(), list)

# Generated at 2022-06-23 05:24:53.085935
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    A = AnsibleConstructor()
    node = yaml.nodes.SequenceNode(u'sequence', [], None, False, None)
    data = A.construct_yaml_seq(node)
    assert isinstance(data, AnsibleSequence)

# Generated at 2022-06-23 05:25:02.839378
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    "Test AnsibleConstructor.construct_mapping()"
    import ansible.parsing.yaml.objects
    # Setup data
    node = {}
    node['value'] = []
    key1 = {}
    key1['value'] = u"key1"
    val1 = {}
    val1['value'] = u"val1"
    key2 = {}
    key2['value'] = u"key2"
    val2 = {}
    val2['value'] = u"val2"
    node['value'].append((key1, val1))
    node['value'].append((key2, val2))
    # Expected result
    exp_mapping = ansible.parsing.yaml.objects.AnsibleMapping()
    exp_mapping['key1'] = u"val1"

# Generated at 2022-06-23 05:25:10.046749
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = """
a: 1
b:
  - 1
  - 2
"""
    ansible_constructor = AnsibleConstructor()
    loader = AnsibleLoader(data, ansible_constructor)
    d = loader.get_single_data()
    assert isinstance(d, AnsibleMapping)
    assert isinstance(d['b'], AnsibleSequence)
    assert isinstance(d['a'], AnsibleUnicode)

# Generated at 2022-06-23 05:25:16.872130
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import ScalarNode
    from yaml.serializer import Serializer
    from yaml.representer import Representer
    serializer = Serializer()
    representer = Representer()
    value = 'my-string'
    tag = u'tag:yaml.org,2002:str'
    node = ScalarNode(tag, value)
    myobject = representer.represent_scalar(tag, value)
    myobject = AnsibleConstructor.construct_yaml_str(node)
    assert isinstance(myobject, AnsibleUnicode), myobject

# Generated at 2022-06-23 05:25:25.473513
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import os
    import tempfile
    import yaml

    (fd1, fname1) = tempfile.mkstemp()

    yaml_data = '---\n - name: AnsibleConstructor class\n'
    yaml_data += '   test: !vault |\n     $ANSIBLE_VAULT;1.1;AES256\n'
    yaml_data += '     63316139616462366163396237656264303737383332303534663930316165383530663833376663\n'
    yaml_data += '     363930653263653735383234623632626137613731610a3430666138353830383563366336393436\n'

# Generated at 2022-06-23 05:25:33.565655
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """Testing method construct_yaml_seq of class AnsibleConstructor"""

    # testing that construct_yaml_seq() successfully construct a list
    # by calling the ansible.parsing.yaml.objects.AnsibleConstructor.construct_yaml_seq()
    # function

    # create a instance of class AnsibleConstructor
    ansibleConstructor = AnsibleConstructor()

    # get the currnet path where the test is running
    import os
    current_path = os.path.abspath(os.getcwd())

    # get the path where the test file is
    test_file_path = os.path.abspath(os.path.join(__file__, os.pardir))

    # create a YAML node
    # this block of code is based on the solution provided here
    # https

# Generated at 2022-06-23 05:25:41.824635
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    ansible_str = '''
        key: "value"
    '''
    yaml_str = yaml.load(ansible_str, Loader=AnsibleConstructor)
    assert(yaml_str['key'] == "value")
    assert(type(yaml_str['key']) is AnsibleUnicode)
    assert(hasattr(yaml_str['key'], 'ansible_pos'))
    assert(yaml_str['key'].ansible_pos == ('<unicode string>', 1, 8))


# Generated at 2022-06-23 05:25:49.614396
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    class MockReflectiveObject(object):
        def __init__(self, constructor, node):
            self.constructor = constructor
            self.node = node

        def __iter__(self):
            yield self

    construct_yaml_map = AnsibleConstructor.construct_yaml_map
    construct_mapping = AnsibleConstructor.construct_mapping

    with patch.object(AnsibleConstructor, 'construct_mapping') as mock_cm:
        constructor = AnsibleConstructor()
        constructor._vaults = MagicMock()
        node = sentinel.node

        result = construct_yaml_map(constructor, node)
        assert isinstance(result, MockReflectiveObject)

        # Test that it is calling the function construct_mapping with the
        # constructor, node and the value True for a deep copy

# Generated at 2022-06-23 05:26:01.289897
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    class FakeVault(object):
        def __init__(self, secrets=None):
            self.secrets = secrets

        def unwrap(self, ciphertext_data, secret=None):
            return 'unwrapped_value_with_no_extraneous_spaces'

    secrets = ['test', 'secret']

    class FakeNode(object):
        start_mark = FakeMark()

    class FakeMark(object):
        def __init__(self):
            self.column = 1
            self.line = 1
            self.name = 'tests/unittests/test_ansible_constructor.py'

    constructor = AnsibleConstructor(file_name=None, vault_secrets=secrets)
    constructor.__class__._vaults = {'default': FakeVault(secrets=secrets)}

    node

# Generated at 2022-06-23 05:26:10.758859
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    yaml_str = '''
a: !unsafe "pw1"
b: !unsafe "pw2"
'''
    # validate loader returns safe strings for passwords
    result = AnsibleLoader(StringIO(yaml_str), file_name='<string>', vault_secrets=[]).get_single_data()
    assert result['a'] == 'pw1'
    assert result['b'] == 'pw2'

    # validate loader returns !vault objects for encrypted passwords
    vault = VaultLib(secrets=['myvaultpassword'])
    result = AnsibleLoader(StringIO(yaml_str), file_name='<string>', vault_secrets=['myvaultpassword']).get_

# Generated at 2022-06-23 05:26:12.290673
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    """Unit test for constructor of class AnsibleConstructor."""
    assert AnsibleConstructor()

# Generated at 2022-06-23 05:26:22.941472
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    ac = AnsibleConstructor()
    assert isinstance(ac, SafeConstructor)
    # Test yaml_map
    result = ac.construct_yaml_map(MappingNode('tag:yaml.org,2002:map'))
    assert isinstance(result, AnsibleMapping)
    # Test construct_mapping
    result = ac.construct_mapping(MappingNode('tag:yaml.org,2002:map'))
    assert isinstance(result, AnsibleMapping)
    # Test construct_yaml_str
    result = ac.construct_yaml_str(MappingNode('tag:yaml.org,2002:str'))
    assert isinstance(result, AnsibleUnicode)
    # Test construct_vault_encrypted_unicode
    result = ac.construct_vault_encrypted_unicode

# Generated at 2022-06-23 05:26:34.070493
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os

    sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/../../../lib/'))
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.collections import ImmutableDict, is_dict_like

    def test_that_construct_mapping_can_handle_good_dict_input():
        test_constructor = AnsibleConstructor(None, None)
        test_constructor.construct_mapping({})

    def test_that_construct_mapping_returns_an_immutable_dict():
        test_constructor = AnsibleConstructor(None, None)
        test_result = test_constructor.construct_mapping({})

# Generated at 2022-06-23 05:26:36.295808
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    x = AnsibleConstructor()
    assert x.construct_mapping(MappingNode("testnode", [])) == {}



# Generated at 2022-06-23 05:26:47.302803
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = u'secret'
    vault = VaultLib(vault_password)
    secrets = [vault_password]

    test_string = u'test'
    encrypted_string = u'$ANSIBLE_VAULT;1.1;AES256\n653038633961353064353035316361346564396165663538363364343066356564626664353362\n6135313535313333316538316239616466356434663132326665620a6634303630636439343730\n323565656233313737363762323265306663643766353934383437373335363836373564303334\n65343762333432326162396365\n'
    test_data

# Generated at 2022-06-23 05:26:58.343208
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    class AnsibleConstructorMock(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=[u'123']):
            self._ansible_file_name = file_name
            super(AnsibleConstructor, self).__init__()
            self._vaults = {}
            self.vault_secrets = vault_secrets or []
            self._vaults['default'] = VaultLib(secrets=self.vault_secrets)

    yaml_constructor = AnsibleConstructorMock()

    # Errors
    construct_scalar_result = u'$ANSIBLE_VAULT;1.1;AES256;\ndata\n'

# Generated at 2022-06-23 05:27:05.385151
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = u"---\n- name: '{{inventory_hostname}}'\n  auto_del_keys: 'True'\n"
    expected = {"auto_del_keys": True, "name": "{{inventory_hostname}}"}
    ans = AnsibleConstructor()
    js = yaml.load(data, Loader=yaml.Loader)
    res = dict(js)
    assert res == expected

# Generated at 2022-06-23 05:27:16.715917
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test that construct_yaml_str() returns a AnsibleUnicode object with the input string
    #   and the position information.
    test_str = u'TEST_STRING'
    node = AnsibleConstructor.construct_scalar(test_str)
    test_obj = AnsibleUnicode(test_str, pos=(node.start_mark.name, node.start_mark.line + 1, node.start_mark.column + 1))
    AnsibleConstructor.construct_vault_encrypted_unicode(node)
    obj = AnsibleConstructor.construct_yaml_str(node)
    test_vault = VaultLib()
    vault = AnsibleVaultEncryptedUnicode(to_bytes('$ANSIBLE_VAULT;1.1;TEST_VAULT'))
    vault.v

# Generated at 2022-06-23 05:27:23.379687
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Removed function doc, generated with:
    # python -m pydoc -w ansible.parsing.yaml.objects
    # Then manually edited to remove useless part and re-indent
    def construct_yaml_map(self, node):
        data = AnsibleMapping()
        yield data
        value = self.construct_mapping(node)
        data.update(value)
        data.ansible_pos = self._node_position_info(node)
    return

# Generated at 2022-06-23 05:27:32.968957
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = """
    foo: bar
    baz: qux
    """

    data = AnsibleConstructor().construct_yaml_map(yaml.compose(yaml_data))

    assert isinstance(data, AnsibleMapping)
    assert "foo" in data
    assert "bar" in data.values()
    assert "baz" in data
    assert "qux" in data.values()

    # test AnsibleMapping.ansible_pos attibute:
    assert data.ansible_pos == ('<unicode string>', 1, 1)


# Generated at 2022-06-23 05:27:40.077779
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Create a test node
    test_node_value = [("key", "value")]
    test_node = MappingNode("tag:yaml.org,2002:map", test_node_value, 1, 1)

    # Call the function to test
    test_result = AnsibleConstructor().construct_mapping(test_node, deep=False)

    # Verify result
    assert isinstance(test_result, AnsibleMapping)
    assert 'key' in test_result
    assert test_result['key'] == 'value'



# Generated at 2022-06-23 05:27:48.755277
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    import sys

    # create a vault password file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    vault_secret_file = os.path.join(script_dir, "vault_secret_file")
    vault_password = "secret"
    with open(vault_secret_file, 'w') as f:
        f.write(vault_password)

    # create a sample yaml file
    yaml_test_dir = os.path.dirname(os.path.abspath(__file__))
    yaml_file = os.path.join(yaml_test_dir, "test_yaml_file.yaml")

# Generated at 2022-06-23 05:27:58.301616
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    lines = [
        u'$ANSIBLE_VAULT;1.1;AES256\n'                                       
        u'63633131613661653764623334336538303935326561306337303630616662316332656237396134\n'
        u'33303830396330653963633239663532666439393133626337616136636334340a643436386439\n'
        u'363265306463306465316262653464613661346166623832386464343037333633643437633764\n'
        u'643335376466386264396137303861666339636534\n'
    ]
    file_name = 'foo'
    vault_secrets

# Generated at 2022-06-23 05:28:09.056281
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    try:
        # pyyaml yaml.load() does not support passing a string
        import yaml
        yaml.load("---\n- 1\n", Loader=AnsibleConstructor)
    except TypeError:
        pass

    assert isinstance(AnsibleConstructor("test").construct_yaml_str("str"), AnsibleUnicode)

    assert isinstance(AnsibleConstructor("test").construct_vault_encrypted_unicode("str"), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:28:13.355113
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    constructor = AnsibleConstructor()
    result = constructor.construct_yaml_unsafe(None)
    assert isinstance(result, AnsibleUnsafeText)

# Generated at 2022-06-23 05:28:23.490238
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node_1 = MappingNode(tag='tag:yaml.org,2002:map', value=[], flow_style=False)
    mapping = AnsibleConstructor.construct_mapping(AnsibleConstructor, node_1)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping == {}

    node_2 = MappingNode(tag='tag:yaml.org,2002:map', value=[], flow_style=False)
    mapping = AnsibleConstructor.construct_mapping(AnsibleConstructor, node_2, deep=True)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping == {}

    node_3 = MappingNode(tag='tag:yaml.org,2002:python/dict', value=[], flow_style=False)
    mapping = AnsibleConstructor.construct

# Generated at 2022-06-23 05:28:33.372424
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    a = AnsibleConstructor()

    # testing whether a is an object of class AnsibleConstructor
    assert isinstance(a, AnsibleConstructor)

    # testing whether a is an object of type SafeConstructor
    assert isinstance(a, SafeConstructor)

    # testing whether construct_yaml_seq is an attribute of a
    assert hasattr(a, 'construct_yaml_seq')

    # testing whether construct_yaml_seq is a method of AnsibleConstructor class
    assert callable(getattr(a, 'construct_yaml_seq'))

    # testing whether construct_yaml_seq raises AttributeError, when the yaml contains a list
    try:
        a.construct_yaml_seq('node')
    except AttributeError:
        pass


# Generated at 2022-06-23 05:28:34.316179
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

# Generated at 2022-06-23 05:28:44.360438
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.vault import VaultLib

    # Setup
    vault_pass = VaultLib(secrets=[u'default_pw'])

# Generated at 2022-06-23 05:28:55.924189
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # A YAML mapping node (to be passed as parameter to construct_mapping)
    # containing duplicate keys and other nodes.
    class MappingNode:
        def __init__(self, value):
            self.value = value

    # A key node to be inserted in keys of map_node.value
    class KeyNode:
        def __init__(self, value):
            self.value = value

    # A value node to be inserted in values of map_node.value
    class ValueNode:
        def __init__(self, value):
            self.value = value

    # A node as key of a mapping
    key1_node = KeyNode('key1')

    # A node as value of a mapping
    value1_node = ValueNode('value1')
    value2_node = ValueNode('value2')

    #

# Generated at 2022-06-23 05:29:00.333541
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = yaml.load("""---

- 1
- 2
- 3
- 4
- 5

""", Loader=AnsibleConstructor)
    assert hasattr(data, 'ansible_pos')
    assert data.ansible_pos[0] == "<string>"
    assert data.ansible_pos[1] == 2
    assert data.ansible_pos[2] == 0



# Generated at 2022-06-23 05:29:09.550166
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    from yaml import load
    from io import StringIO

    # Since we're not passing in an actual stream,
    # make it look like it came from a stream
    fake_stream_name = "ansible://playbook.yml"

    data1 = {'key1': 'value1', 'key2': 'value2'}
    data2 = {'key3': 'value3', 'key4': 'value4'}
    data3 = {'key5': 'value5', 'key6': 'value6'}

    yaml_str = '---\n'
    yaml_str += 'key1: value1\n'
    yaml_str += 'key2: value2\n'

# Generated at 2022-06-23 05:29:19.577246
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping

    yaml_str = """
key:
  - value1
  - value2
"""
    ansible_constructor = AnsibleConstructor()

    context = yaml.load(yaml_str, Loader=yaml.Loader)

    # Test the context is correctly built
    assert isinstance(context, AnsibleMapping)
    assert context['key'][0] == "value1"

    context = yaml.load(yaml_str, Loader=yaml.Loader)

    # Test the context is correctly built (second time)
    assert isinstance(context, AnsibleMapping)
    assert context['key'][0] == "value1"

# Generated at 2022-06-23 05:29:27.456882
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    constructor = AnsibleConstructor()
    constructor.add_constructor(u'tag:yaml.org,2002:seq', constructor.construct_yaml_seq)
    test_sequence = """
    - test_item_1
    - test_item_2
    """

    data = yaml.load(test_sequence, Loader=yaml.SafeLoader)
    assert isinstance(data, AnsibleSequence)
    assert isinstance(data, list)
    assert data == ['test_item_1', 'test_item_2']

# Generated at 2022-06-23 05:29:34.147755
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping = {'a': 1, 'b': 2, 'c': 3}
    ac = AnsibleConstructor()

    mapping_node = MappingNode(tag='tag:yaml.org,2002:map', value=[])
    for key in mapping.keys():
        mapping_node.value.append((key, mapping[key]))

    result = ac.construct_mapping(mapping_node)
    assert result == mapping
    result_ansible_pos = result.ansible_pos
    assert result_ansible_pos == ('<string>', 1, 1)


# Generated at 2022-06-23 05:29:40.995144
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = ("foo: {bar: {a: 1, b: 2 }, baz: {a: 1, b: 2 } }\n"
                "foo: {bar: foo, baz: bar }")
    data = AnsibleLoader(yaml_str, file_name='<string>').get_single_data()
    assert data == dict(foo=dict(bar='foo', baz='bar'), ansible_pos=('<string>', 1, 1))

# Generated at 2022-06-23 05:29:45.233558
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    a = AnsibleConstructor()

    # Test if the return value is an AnsibleUnicode object
    value = a.construct_yaml_str(None)
    assert isinstance(value, AnsibleUnicode)



# Generated at 2022-06-23 05:29:51.906228
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    list_of_values = [
        'this is a string',
        '1234',
        '"1234"',
        'the quick brown fox jumped over the lazy dog',
        r'\n\n\n\n',
        r'\\n\n\n\n'
    ]
    for value in list_of_values:
        yaml_snippet = "%s\n" % value
        tmp_results = yaml.load(yaml_snippet, Loader=AnsibleConstructor)
        assert isinstance(tmp_results, AnsibleUnicode)
        assert tmp_results == value



# Generated at 2022-06-23 05:30:03.186028
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    class TestClass(object):
        def __init__(self):
            self.test_variable = None

    # Create AnsibleConstructor object
    obj = AnsibleConstructor(file_name='test.yaml')

    # Test AnsibleConstructor.construct_object(node, deep=False)
    # Test with mapping node
    dict = {'test': 1,
            'test1': 2}

    ret = obj.construct_object(dict)
    assert ret['test'] == 1
    assert ret['test1'] == 2

    # Test with sequence node
    list = [1, 2, 3, 4]

    ret = obj.construct_object(list)
    assert ret[0] == 1
    assert ret[1] == 2
    assert ret[2] == 3
    assert ret[3] == 4

    # Test

# Generated at 2022-06-23 05:30:13.921463
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-23 05:30:24.486328
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ac = AnsibleConstructor()
    vault_data = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;\n          6132386433326335363132386538323561623965303362306662396132353239376361313034373563\n          386534666439376562323363306437366239353933353266313730613263363433326335363132386538\n          323561623965303362306662396132353239376361313034373536346336616633376639396462356164\n          6331393964623035643633346439343564373363643837663939646235616463313939632\n          "

   

# Generated at 2022-06-23 05:30:32.956932
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    construct_mapping = AnsibleConstructor(file_name="./testfile").construct_mapping

    # Test case: construct_mapping with node.value being an empty list
    node_emtpy_list = MappingNode(tag=u'tag:yaml.org,2002:map',
                                  value=[],
                                  start_mark=None,
                                  end_mark=None,
                                  flow_style=False)
    assert {} == construct_mapping(node_emtpy_list)

    # Test case: construct_mapping with node.value being None
    node_none = MappingNode(tag=u'tag:yaml.org,2002:map',
                            value=None,
                            start_mark=None,
                            end_mark=None,
                            flow_style=False)
   

# Generated at 2022-06-23 05:30:42.039205
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import os
    import shutil
    import yaml

    vault_password = 'secret123'
    test_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'vault_fixtures'
    )
    test_vault_file = os.path.join(test_dir, 'vault_test.yml')
    test_result_file = os.path.join(test_dir, 'vault_result.yml')
    assert os.path.exists(test_vault_file)

    test_result = AnsibleConstructor(file_name=test_vault_file, vault_secrets=[vault_password]).get_single_data()


# Generated at 2022-06-23 05:30:51.361589
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import os
    import sys
    import yaml
    from io import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper

    orig_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    yaml.dump([1, 2, 3, 4, 5], Dumper=AnsibleDumper, default_flow_style=False)
    sys.stdout = orig_stdout
    # mystdout.seek(0)
    # print("mystdout.getvalue()=", mystdout.getvalue())
    # initialize class
    # ac = AnsibleConstructor("dummy.yml", ["dummy.yml"])

    # yaml.load(data, Loader=AnsibleLoader)
    # test_AnsibleConstructor_

# Generated at 2022-06-23 05:31:03.352984
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import pytest

    # testing with lineno of first key is 0, to cover condition where it is > 0
    yaml_data = """
---
key_0: value_0
key_1: value_1
key_0: last_value_0
"""
    m = AnsibleConstructor(file_name='<string>', vault_secrets=[])
    nodes = m.construct_yaml_map(m.compose_document(yaml_data))
    nodes_keys = nodes.keys()

    assert len(nodes_keys) == 2
    assert nodes_keys[0] == 'key_0'
    assert nodes_keys[1] == 'key_1'

    assert nodes['key_1'] == 'value_1'
    assert nodes['key_0'] == 'last_value_0'

# Generated at 2022-06-23 05:31:14.444653
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault = VaultLib(secrets=['testspassword'])

# Generated at 2022-06-23 05:31:20.410940
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['vault1']
    ansible_constructor = AnsibleConstructor(file_name='my_file', vault_secrets=vault_secrets)
    fname = 'sample_vault_file.yml'
    with open(fname, 'r') as f:
        sample_vault_file = f.read()

    sample_vault_file_yaml = ansible_constructor.construct_yaml_str(sample_vault_file)

# Generated at 2022-06-23 05:31:31.068468
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    import yaml
    json_string = [
        '{',
        '  "key1": "value1",',
        '  "key1": "value2"',
        '}'
    ]

    try:
        yaml_str = yaml.dump(yaml.load('\n'.join(json_string)), default_flow_style=False)
    except Exception as e:
        raise AssertionError("YAML cannot be loaded")
    else:
        try:
            AnsibleConstructor().construct_mapping(yaml.compose(yaml_str))
        except ConstructorError as e:
            actual_msg = str(e)
            expected_msg = 'While constructing a mapping from None, line 1, column 3, found a duplicate dict key'

# Generated at 2022-06-23 05:31:42.441809
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing import vault
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['decryptme']

    expected_value = {'a': [1, 2], 'c': [3, 4]}
    expected_string = u'---\n# - a: [1, 2]\n# - c: [3, 4]\n'

    ac = AnsibleConstructor(vault_secrets=vault_secrets)
    loader = vault.VaultLib(secrets=vault_secrets)
    ciphertext_data = loader.encrypt(expected_string)
    ciphertext_data = to_bytes(ciphertext_data)

    encrypted_str = Ansible