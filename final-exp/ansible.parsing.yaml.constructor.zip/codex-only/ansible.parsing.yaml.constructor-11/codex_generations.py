

# Generated at 2022-06-23 05:21:46.358107
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml.nodes import ScalarNode, MappingNode
    import tempfile
    import os

    (handle, path) = tempfile.mkstemp(text=True)

    f = os.fdopen(handle, 'w')
    f.write("""
      test_int: !unsafe/int 1
      test_str: !unsafe/str 1
      test_float: !unsafe/float 1.0
    """)

    f.close()

    loader = AnsibleLoader(path, None)
    data = loader.get_single_data()

    assert type(data) == dict
    assert type(data['test_int']) == int
    assert type(data['test_float']) == float

# Generated at 2022-06-23 05:21:50.510720
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    constructor = AnsibleConstructor()
    dumper = AnsibleDumper()
    ansible_dict = AnsibleMapping()
    ansible_dict['key1'] = 'value1'
    ansible_dict['key2'] = 'value2'
    yaml_data = dumper.dump(ansible_dict)
    data = list(yaml.load_all(yaml_data, Loader=yaml.SafeLoader))
    ansible_dict2 = constructor.construct_yaml_map(data[0])
    assert ansible_dict2 == ansible_dict



# Generated at 2022-06-23 05:21:58.225103
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    obj = AnsibleLoader(None, None).get_single_data(u'''
    - !unsafe {a: b}
    - !unsafe [1, 2]
    - !unsafe "foo"
    ''')

    # obj should be equal to the list below
    assert obj == [
        wrap_var({u'a': u'b'}),
        wrap_var([1, 2]),
        wrap_var(u'foo')
    ], '''
    obj should be equal to the list below:
    [
        wrap_var({a: b}),
        wrap_var([1, 2]),
        wrap_var('foo')
    ]
    '''

    # obj[0].__class__ should be

# Generated at 2022-06-23 05:22:09.343325
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing import yaml
    from ansible.module_utils.common.collections import is_sequence

    # Test mapping
    test_mapping = '''
    test: "{{ ansible_facts }}"
    '''
    test_mapping_obj = yaml.safe_load(test_mapping)
    assert isinstance(test_mapping_obj.get('test'), wrap_var)
    assert not is_sequence(test_mapping_obj.get('test'))

    # Test sequence
    test_sequence = '''
    - "{{ ansible_facts }}"
    '''
    test_sequence_obj = yaml.safe_load(test_sequence)
    assert isinstance(test_sequence_obj[0], wrap_var)

# Generated at 2022-06-23 05:22:16.106532
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(None, None, [(u'a', {'line': 1, 'column': 1, 'index': 0}), (u'b', {'line': 2, 'column': 1, 'index': 1})], None, None)

    ac = AnsibleConstructor()
    ansible_mapping = ac.construct_mapping(node)

    assert isinstance(ansible_mapping, AnsibleMapping)

# Generated at 2022-06-23 05:22:27.965583
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    value = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          656636396633346435363038313166656435333166326438626564353466653634663634613035\n          316431303530396534376331633931656234616166633536366637333766333133653636616233\n          626165623966373331373766633162633034363966656130363863646635393765333064333537\n          30666237353764383332\n          '
    vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(value)

# Generated at 2022-06-23 05:22:37.432515
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    yaml.add_multi_constructor(u'tag:yaml.org,2002:seq', AnsibleConstructor.construct_yaml_seq)
    yaml.add_constructor(u'!test', AnsibleBaseYAMLObject)
    data = '''
        - !test
          a: A
        - !test
          a: B
    '''
    data = yaml.load(data)
    assert data[0]['a'] == 'A'
    assert data[1]['a'] == 'B'

# Generated at 2022-06-23 05:22:49.497120
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:22:59.479489
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import pytest

    # This fixture will create a simple sample file
    @pytest.fixture()
    def sample_file(tmpdir):
        import json
        import os
        import yaml
        test_data = {
            'foo': [1, 2],
            'bar': {'baz': 3}
        }
        test_file = tmpdir.join("my_test_file.yaml")
        stream = file(str(test_file), 'w')
        yaml.dump(test_data, stream)
        stream.close()

        stream = file(str(test_file), 'r')
        test_yaml = yaml.load(stream)
        stream.close()

        return test_file, test_data, test_yaml

    # Test that method works with a file

# Generated at 2022-06-23 05:23:09.447297
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml import objects

    import textwrap
    test_data = textwrap.dedent("""\
        - key1: value1
          key2: value2
          key3: value3
        - key1: value1
          key2: value2
          key3: value4""")

    data = objects.AnsibleMapping()

    for d in yaml.load(test_data):
        data.update(d)

    assert data == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

# Generated at 2022-06-23 05:23:12.082982
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    assert (True)

if __name__ == '__main__':
    test_AnsibleConstructor_construct_vault_encrypted_unicode()

# Generated at 2022-06-23 05:23:22.573232
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = """
key1:
- key11
- key12
key2:
- key21
- key22
    """
    dc = AnsibleConstructor()
    yaml_dict = dc.construct_yaml_map(dc.construct_yaml_seq(dc.construct_document(yaml_str))[0]._yaml_base_class)
    assert isinstance(yaml_dict, AnsibleMapping)
    assert len(yaml_dict.keys()) == 2
    assert "key1" in yaml_dict.keys()
    assert isinstance(yaml_dict["key1"], list)
    assert "key2" in yaml_dict.keys()
    assert isinstance(yaml_dict["key2"], list)


# Generated at 2022-06-23 05:23:31.633414
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    d = AnsibleConstructor()
    assert d.construct_yaml_map({}) == {}
    assert d.construct_yaml_map({'a': 1}) == {'a': 1}
    assert d.construct_yaml_map({'a': {'b': 1}}) == {'a': {'b': 1}}
    assert d.construct_yaml_map({'a': {'b': 1}, 'c': 2}) == {'a': {'b': 1}, 'c': 2}
    # duplicated key should be overwritten
    assert d.construct_yaml_map({'a': 1, 'a': 2}) == {'a': 2}


# Generated at 2022-06-23 05:23:36.517466
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Unsafe constructor should create wrapped proxy object
    # of specified type with given value
    unsafe_proxy = AnsibleConstructor(file_name=None).construct_yaml_unsafe(None)
    assert unsafe_proxy.proxy_class == "AnsibleUnsafeText"
    assert str(unsafe_proxy) == "AnsibleUnsafeText"

# Generated at 2022-06-23 05:23:45.321860
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import objects
    import sys

    test_obj = {'test_key': 'test_val', 'test_key2': 'test_val2', 'test_obj': {'test_key': 'test_val', 'test_key2': 'test_val2'}}
    test_obj_loaded = objects.AnsibleMapping(test_obj)

    # Mocking the load method from yaml.safe_load
    class Mock_yaml_load_safe(object):
        def __init__(self, data, file_name, vault_secrets):
            self.data = data
            self.file_name = file_name
            self.vault_secrets = vault_secrets

        def load(self):
            return self.data


# Generated at 2022-06-23 05:23:53.764099
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = []
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    assert constructor.vault_secrets == vault_secrets
    node = None

# Generated at 2022-06-23 05:24:03.033106
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import yaml
    if sys.version_info >= (3, 0):
        unicode_type = str
        repr_type = repr
    else:
        unicode_type = unicode
        repr_type = repr

    result = AnsibleConstructor().construct_mapping(yaml.nodes.MappingNode('tag:yaml.org,2002:map', [], True,
                                                                           yaml.nodes.MappingNode.FLOW_STYLE),
                                                    deep=False)
    assert isinstance(result, AnsibleMapping)
    assert isinstance(result, dict)
    assert len(result) == 0
    assert result.ansible_pos == (u'<unicode string>', 1, 0)


# Generated at 2022-06-23 05:24:13.662104
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # construct an AnsibleConstructor and node for testing 
    node = MappingNode(tag=u'!unsafe', value=[])
    ac = AnsibleConstructor()

    # test for all valid tag:yaml.org,2002:* nodes

# Generated at 2022-06-23 05:24:16.007813
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    test = u"test123"
    ac = AnsibleConstructor()
    assert type(ac.construct_yaml_str(test)) == AnsibleUnicode

# Generated at 2022-06-23 05:24:26.200924
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data_map = '''
        key1:
            key2: val2
            key3: val3
            key4: val4
    '''
    yaml_data_map_with_duplicate_key = '''
        key1:
            key2: val2
            key3: val3
            key3: val3_1
    '''

    yaml_data_map_with_duplicate_key_default = '''
        key1:
            key2: val2
            key3: val3
            key3: val3_1
    '''
    for key in ['warn', 'error', 'ignore']:
        C.DUPLICATE_YAML_DICT_KEY =key
        constructor = AnsibleConstructor()

# Generated at 2022-06-23 05:24:37.027245
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    datas = [
        ('!!python/object/new:yaml.YAML', 'yaml.YAML'),
        ('!!python/object/new:yaml.constructor.ConstructorError', 'yaml.constructor.ConstructorError'),
        ('!!python/object/new:yaml.loader.Loader', 'yaml.loader.Loader'),
        ('!!python/object/new:yaml.reader.Reader', 'yaml.reader.Reader'),
        ('!!python/object/new:yaml.scanner.Scanner', 'yaml.scanner.Scanner'),
        ('!!python/object/apply:foo', 'foo'),
    ]
    for data, expected_result in datas:
        ac = AnsibleConstructor('')
        result = ac.construct_yaml_unsafe(data)
        assert get

# Generated at 2022-06-23 05:24:41.676180
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml import AnsibleLoader
    import io
    b_yaml_list = io.BytesIO(b'''
        - 2
        - 2
        ''')
    AnsibleLoader(b_yaml_list).get_single_data()
    #assert False, "Test unfinished"

# Generated at 2022-06-23 05:24:44.381449
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence

    assert AnsibleConstructor().construct_yaml_seq(None) == AnsibleSequence()

# Generated at 2022-06-23 05:24:54.071828
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """Unit test for method construct_yaml_map of class AnsibleConstructor."""
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleMapping
    from yaml import load

    Pos = namedtuple('Pos', ['datasource', 'line', 'column'])
    Test = namedtuple('Test', ['text', 'expected', 'vault_secrets'])

# Generated at 2022-06-23 05:24:58.747198
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = '''
---
        "key_one": 1
        "key_two": 2
        "key_one": 3
        "key_four": 4
        "key_five": 5
'''
    node = yaml.compose(data)
    c = AnsibleConstructor()
    c.construct_yaml_map(node)

# Generated at 2022-06-23 05:25:06.780190
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    a = [{'foo': 'bar'}]
    data = yaml.dump(a)
    b = yaml.load(data, Loader=AnsibleConstructor)
    assert a == b
    assert u'foo' in b[0]

# Generated at 2022-06-23 05:25:18.095198
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from os import urandom

    from ansible.plugins.vars.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib(b'1')
    data = urandom(8)
    ciphertext = vault.encrypt(data)
    # Ciphertext is stored in a scalar, so it is represented as a str in the tree
    ciphertext = ciphertext.decode('utf8')
    node = {'tag': u'tag:yaml.org,2002:str', 'value': ciphertext}
    value = AnsibleConstructor().construct_vault_encrypted_unicode(node)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    decrypted_data = vault.decrypt(value.vault_data)

# Generated at 2022-06-23 05:25:27.151286
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    cons = AnsibleConstructor()
    vault_secrets = [b"llama0"]
    cons.vault_secrets = vault_secrets

# Generated at 2022-06-23 05:25:31.154210
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    oc = AnsibleConstructor()
    u_str = '{"unsafe": "unsafe"}'
    ansible_dict = oc.construct_yaml_unsafe(yaml.compose(u_str))
    assert ansible_dict == {u'!unsafe': {u'unsafe': u'unsafe'}}, ansible_dict

# Generated at 2022-06-23 05:25:43.170303
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml
    # Constructor tests for test_constructor_vault_encrypted_unicode

    def test_constructor_vault_encrypted_unicode(self):
        value = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n\....'
        b_ciphertext_data = to_bytes(value)
        # Test normal vault entry
        vault = self._vaults['default']
        if vault.secrets is None:
            raise ConstructorError(context=None, context_mark=None,
                                   problem="found !vault but no vault password provided",
                                   problem_mark=node.start_mark,
                                   note=None)
        ret = AnsibleV

# Generated at 2022-06-23 05:25:54.252672
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    constructor = AnsibleConstructor()
    code = ("""
---
a: b
c:
  d: e
""")
    obj = yaml.load(code, Loader=AnsibleLoader)

    # no duplicates:
    assert obj == {u'a': u'b', u'c': {u'd': u'e'}}
    # one dup:
    code = ("""
---
a: b
c:
  d: e
c:
  d: f
""")
    obj = yaml.load(code, Loader=AnsibleLoader)
    assert obj == {u'a': u'b', u'c': {u'd': u'f'}}
    # several dups:

# Generated at 2022-06-23 05:25:58.436586
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    
    yaml = """
        - hosts: all
          gather_facts: true
          roles:
            - some-role"""
    root = yaml.load(yaml)
    print(root)

# Generated at 2022-06-23 05:26:09.718089
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import unittest

    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    yaml_str = u'test: !unsafe |\n  abc\n  def'
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == {u'test': AnsibleUnsafeText(u'abc\ndef')}

    # make sure we also work with old-style YAML (which is what ansible-playbook
    # would have dumped)
    yaml_str = u'test: !unsafe abc\ndef\n'
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)

# Generated at 2022-06-23 05:26:21.040412
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    t = '''
    - foo
    - bar
    - baz
    '''

    yaml_str = to_bytes(t)
    yaml_str_lines = yaml_str.splitlines()

    # Test with a string where the start_mark.column is not zero
    node_str = to_bytes(t[1:])
    node = yaml.compose(node_str)
    node.start_mark = node.start_mark._replace(column=1)
    assert isinstance(node, yaml.SequenceNode)
    assert isinstance(node.value[0], yaml.ScalarNode)
    assert to_bytes(node.value[0].value) == to_bytes('foo')
    assert node

# Generated at 2022-06-23 05:26:33.065989
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_native

    vault = VaultLib(secrets=[b'abc'])
    yaml_str = b"""
key1: 1
key2: 2
"""
    node = yaml.compose(yaml_str)
    node.tag = u'!vault'

    ansibleConstructor = AnsibleConstructor(vault_secrets=[b'abc'])
    ansibleConstructor.construct_yaml_map(node)
    obj = ansibleConstructor.construct_yaml_map(node)
    ansibleMapping = next(obj)

    assert isinstance(ansibleMapping, AnsibleMapping)

# Generated at 2022-06-23 05:26:37.236926
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Test 'construct_yaml_map' method.
    """

    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=False)
    ac = AnsibleConstructor()
    ac.construct_yaml_map(node)

# Generated at 2022-06-23 05:26:43.457989
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader

    a = """\
- hosts: localhost
  tasks:
  - command: "echo {{ test_variable }}"
"""

    l = AnsibleLoader(a)
    d = l.get_single_data()
    assert d[0]['tasks'][0]['command'] == u"echo {{ test_variable }}"

# Generated at 2022-06-23 05:26:44.171841
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert True

# Generated at 2022-06-23 05:26:53.258537
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import unittest
    import yaml
    class Test_Constructor(unittest.TestCase):
        def test_construct_vault_encrypted_unicode(self):
            import ansible.parsing.yaml.objects
            constructor = AnsibleConstructor()
            node = yaml.nodes.ScalarNode(tag='!vault', value='$ANSIBLE_VAULT;1.1;AES256')
            res = constructor.construct_vault_encrypted_unicode(node)
            assert (isinstance(res, ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode))
    unittest.main()

# Generated at 2022-06-23 05:27:01.715526
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['foo', 'bar']
    my_vault = VaultLib(secrets=vault_secrets)

# Generated at 2022-06-23 05:27:13.350257
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    # load yaml text at once using constructor of class AnsibleConstructor
    loader = AnsibleLoader(None, None, AnsibleConstructor)
    yaml_data = loader.load('''
        ---
        test1:
          - key1: value1
          - key2: value2
        test2:
          key1: value1
          key2: value2
          key3:
            - subkey1: subvalue1
            - subkey2: subvalue2
        test3:
          - key1: value1
          - key1: value2
    ''')

    assert isinstance(yaml_data, dict)
    assert isinstance(yaml_data.get('test1'), AnsibleSequence)

# Generated at 2022-06-23 05:27:24.227679
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None, vault_password='test')
    data = loader.get_single_data()

    data['testkey'] = "hello world"
    data[u'testkey2'] = u"\N{SNOWMAN}"

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data[u'testkey'], AnsibleUnicode)
    assert isinstance(data['testkey2'], AnsibleUnicode)
    assert data['testkey'] == u"hello world"
    assert data[u'testkey2'] == u"\u2603"


# Generated at 2022-06-23 05:27:35.330953
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.vault import VaultLib

    vault_file = open('test/vault_test.yml')
    vault_data = vault_file.read()
    vault_data = vault_data.replace("\n", "\r\n")
    vault_file.close()

    # test for !vault
    constructor = AnsibleConstructor()
    vault = VaultLib([u'1111'])
    vault_obj = vault.decrypt(vault_data)
    vault_obj = load(vault_data, Loader=AnsibleConstructor)
    assert vault_obj.vault == constructor._vaults['default']

    # test for !vault-encrypted
    constructor = AnsibleConstructor()
    vault_obj = load(vault_data, Loader=AnsibleConstructor)
   

# Generated at 2022-06-23 05:27:46.431743
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class TestMapping(AnsibleMapping):
        def __init__(self, data=None, **kwargs):
            self.data = data
            self.kwargs = kwargs
            super(TestMapping, self).__init__(**kwargs)

        def update(self, value):
            if isinstance(value, MappingNode):
                self.data = value.value
            else:
                raise Exception('Invalid mapping type: %s' % type(value))

    ac = AnsibleConstructor()
    tm = TestMapping()

    ac.construct_mapping(MappingNode(None, [1, 2]), deep=False)

    ac.construct_mapping(MappingNode(None, [1, 2]))

    ac.construct_mapping(MappingNode(None, [])).ansible_

# Generated at 2022-06-23 05:27:50.565649
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()
    node = u'tag:yaml.org,2002:str'

    value = constructor.construct_yaml_str(node)
    assert value == u'tag:yaml.org,2002:str'

# Generated at 2022-06-23 05:28:01.386464
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    '''
    Unit test for AnsibleConstructor.construct_yaml_map()
    '''
    yamlstr = '\n.\n.\n.\n'
    yamlstr += 'foo:\n'
    yamlstr += '  bar: baz\n'
    yamlstr += '  baz: baz\n'
    yamlstr += '  baz: baz\n'
    yamlstr += '  baz: baz\n'
    yamlstr += '  baz: baz\n'
    yamlstr += '  baz: baz\n'
    yamlstr += '  baz: baz\n'
    yamlstr += '  baz: baz\n'
    yamlstr += '  baz: baz\n'
   

# Generated at 2022-06-23 05:28:05.615506
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = AnsibleConstructor().construct_mapping([(':', 'a'), ('a', 'b'), ('a', 'c')])

    assert(len(data) == 1)
    assert('a' in data)
    assert(data['a'] == 'c')

# Generated at 2022-06-23 05:28:11.167132
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_obj = '''---
- 1
- 2
- 3
...
'''
    yaml_list = list(yaml.load_all(yaml_obj, Loader=AnsibleConstructor))
    assert(yaml_list[0].ansible_pos == (node.start_mark.name, line, column))
    assert(yaml_list[0][0] == 1)
    assert(yaml_list[0][1] == 2)
    assert(yaml_list[0][2] == 3)


# Generated at 2022-06-23 05:28:16.434060
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleMapping

    ansible_constructor = AnsibleConstructor()
    node1 = {u'value': []}
    ret = ansible_constructor.construct_yaml_seq(**node1)
    assert type(ret) == type(iter([]))

    node2 = {u'value': [1, 2]}
    ret = ansible_constructor.construct_yaml_seq(**node2)
    assert type(ret) == type(iter([]))

    node3 = {u'value': [1, AnsibleMapping(a=2)]}
    ret = ansible_constructor.construct_yaml_seq(**node3)
    assert type(ret) == type(iter([]))



# Generated at 2022-06-23 05:28:22.597176
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # returns a generator
    constructor = AnsibleConstructor.construct_yaml_seq
    assert constructor

    # extract the generator
    constructor = next(constructor)
    assert constructor

    # return value of the generator
    assert constructor.__class__ is AnsibleSequence

    # NOTE: the default constructor method "construct_yaml_seq" is not callable
    # hence, it can't be tested

# Generated at 2022-06-23 05:28:32.887423
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 05:28:43.295674
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    ---
    num: !unsafe 123
    str: !unsafe abc
    bool_true: !unsafe true
    bool_false: !unsafe false
    null: !unsafe null
    dict: !unsafe {foo: bar, baz: foo}
    list: !unsafe [foo, bar, baz]
    datetime: !unsafe 2013-01-28 00:00:00.000000
    '''
    loader = AnsibleLoader(data, str('mydata'), None, None)
    results = loader.get_single_data()

    assert isinstance(results['num'], int)
    assert isinstance(results['str'], str)

# Generated at 2022-06-23 05:28:47.057329
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    node = "test"
    try:
        ansible_constructor.construct_vault_encrypted_unicode(node)
        assert False, "ConstructorError did not occur."
    except ConstructorError:
        assert True

# Generated at 2022-06-23 05:28:48.062047
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
  '''
  None
  '''
  pass

# Generated at 2022-06-23 05:28:59.593109
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import io
    import sys

    import pytest

    from yaml import load

    # Create a string IO object and use it as stdin in the test
    stdin = io.StringIO('- [1, 2, 3]')
    sys.stdin = stdin
    no_vault_secrets = []
    result = load(stdin, Loader=AnsibleConstructor, vault_secrets=no_vault_secrets)
    sys.stdin = sys.__stdin__

    assert isinstance(result, list)
    assert isinstance(result, AnsibleSequence)
    assert result.ansible_pos == (None, 1, 0)

    assert isinstance(result[0], list)
    assert isinstance(result[0], AnsibleSequence)

# Generated at 2022-06-23 05:29:02.029573
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor('/tmp/fakefile')
    assert isinstance(constructor.construct_yaml_str('foo'), AnsibleUnicode)

# Generated at 2022-06-23 05:29:07.527768
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=[])
    test_constructor = ansible_constructor.construct_yaml_map

    data = {"test_key": "test_value"}
    node = MappingNode.from_yaml(data, loader=ansible_constructor)
    value = test_constructor(node)
    assert next(value) == data


# Generated at 2022-06-23 05:29:18.987310
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import io
    import warnings
    import pytest

    def get_bom_data():
        # construct a byte-order-mark followed by a dictionary
        # This dictionary should be loaded without error and without
        # the first line containing the BOM, even if the user is
        # running some version of Python that adds the BOM to
        # a .readline() call
        data = io.BytesIO(u'\uFEFFname: Joe\nage: 28'.encode('utf-8'))
        bytes_data = data.read()
        str_data = bytes_data.decode('utf-8')
        dict_data = yaml.load(str_data)
        return dict_data

    # Make sure the test works with both Python 2 and Python 3
    # by re-loading the yaml class with the

# Generated at 2022-06-23 05:29:23.099270
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    class TestConstructor:
        def __init__(self, *args, **kwargs):
            pass

        def __repr__(self):
            return 'TestConstructor instance'

    yaml_str = "---\n- !unsafe datetime\n- !unsafe TestConstructor\n- !unsafe str\n- !unsafe int\n- !unsafe dict\n"
    data = yaml.load(to_bytes(yaml_str), Loader=AnsibleLoader)
    assert data[0] == datetime.datetime
    assert data[1] == TestConstructor
    assert data[2] == str
    assert data[3] == int
    assert data[4] == dict

    data

# Generated at 2022-06-23 05:29:27.603624
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_data = '''
a: b
c: d
'''

    in_data = yaml.load(test_data, Loader=AnsibleConstructor)
    assert in_data['a'] == 'b'
    assert in_data['c'] == 'd'



# Generated at 2022-06-23 05:29:36.493114
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    testdata = '''
    - testdata
    - {key1: "value1", key2: "value2", key3: "value3"}
    -
      - item1
      - item2
      - {subkey1: "subvalue1", subkey2: "subvalue2"}
    '''
    import yaml
    from collections import OrderedDict

    constructor = AnsibleConstructor()
    for data in yaml.load_all(testdata, Loader=yaml.SafeLoader):
        assert isinstance(data, list)
        assert data[0] == "testdata"
        # assert that key order is maintained
        assert isinstance(data[1], OrderedDict)
        assert data[1]['key2'] == "value2"
        assert isinstance(data[2], list)

# Generated at 2022-06-23 05:29:45.919237
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import load, dump, from_yaml
    from ansible.module_utils.common._collections_compat import SafeText, MutableMapping, MutableSequence
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes

    for data in [SafeText(u"hello"), SafeText(u"world"), b"test", u"test"]:
        unsafe_data = AnsibleUnsafeText(data)
        assert data == from_yaml(dump(unsafe_data))


# Generated at 2022-06-23 05:29:50.416791
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    my_constructor = AnsibleConstructor()
    obj = {'name': "nad", 'age': 31, 'cities': {"first": "sfo", "second": "nyc"}, "animals" : ["dog", "cat", "bird"]}
    my_constructor.construct_yaml_seq(obj)
    assert type(obj['animals']) is list


# Generated at 2022-06-23 05:29:58.241266
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    yaml_test = ('- { foo: bar, baz: blah }\n\n'
                 '- { foo: bar, baz: blah }\n')
    yaml_test_loaded = AnsibleConstructor(file_name='/fake/file.yml').get_single_data(yaml_test)

    assert yaml_test_loaded[0]['foo'] == 'bar'
    assert yaml_test_loaded[0]['baz'] == 'blah'

# Generated at 2022-06-23 05:30:08.163785
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    doc="""
    test:
    - 1
    - 2
    - 3
    - 4
    - !unsafe 'abc'
    - &id1 !unsafe '123'
    - *id1
    """
    data = yaml.load(doc, Loader=AnsibleConstructor)
    assert data['test'][4] == 'abc'
    assert data['test'][5] == '123'
    assert data['test'][6] == '123'
    assert data['test'][4] is data['test'][5]
    assert data['test'][4] is data['test'][6]
    assert data['test'][5] is data['test'][6]

# Generated at 2022-06-23 05:30:17.547198
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    def _construct_yaml_str(text):
        yaml_str = AnsibleConstructor(file_name="some/file").construct_yaml_str(text)
        assert isinstance(yaml_str, AnsibleUnicode)
        assert yaml_str == u'hello'
        assert yaml_str.ansible_pos == ('some/file', 1, 0)

    _construct_yaml_str(u'hello')
    _construct_yaml_str(u'hello\n')
    _construct_yaml_str(u'hello\n\n')
    _construct_yaml_str(u'hello\r\n')
    _construct_yaml_str(u'hello\r\n\r\n')
    _construct_yaml_str(u'hello\r')
    _

# Generated at 2022-06-23 05:30:26.696663
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import os
    import ast

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from units.compat import unittest

    class TestAnsibleConstructor(unittest.TestCase):

        def test_list_to_dict(self):
            # the below dict definition is not a dict
            # definition.  it actually is a list definition,
            # but loaded with SafeConstructor via the
            # yaml.load(..., Loader=SafeConstructor) will
            # pass through it safely and map its dict
            # definition as dictionary definition
            yaml_str = '''
            - name: a.txt
              state: touch
            - name: b.txt
              state: touch
            '''
            data = yaml.load

# Generated at 2022-06-23 05:30:32.685681
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence

    custom_constructor = AnsibleConstructor()

    ansible_sequence = custom_constructor.construct_yaml_seq(MappingNode('tag:yaml.org,2002:seq', [], (0, 0), (0, 0)))
    assert isinstance(ansible_sequence, AnsibleSequence)

# Generated at 2022-06-23 05:30:44.200276
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    from io import StringIO
    from yaml import load
    from yaml import YAMLError

    test_str = u"""
- a
- b
"""

    test_str_expected = """
- a
- b
"""
    test_stream = StringIO(test_str)
    test_yaml = load(test_stream)
    assert test_str_expected == test_yaml[0].to_yaml()

    # Now make sure it works with an empty list
    test_str = u"""[]"""
    test_str_expected = """[]"""
    test_stream = StringIO(test_str)
    test_yaml = load(test_stream)
    assert test_str_expected == test_yaml[0].to_yaml()

    # Now make sure it works with

# Generated at 2022-06-23 05:30:46.546853
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    c = AnsibleConstructor()
    node = c.construct_yaml_map(yaml.nodes.MappingNode())
    assert c.construct_yaml_unsafe(node) == node

# Generated at 2022-06-23 05:30:51.481518
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()

    # the default type is str, which we want to change to unicode
    expected = to_bytes('Hello world')
    actual = constructor.construct_yaml_str(expected)

    assert isinstance(actual.value, AnsibleUnicode)
    assert actual.value == expected

    # should make no difference if we call again
    actual = constructor.construct_yaml_str(expected)
    assert actual.value == expected


# Generated at 2022-06-23 05:31:03.458172
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # When we construct a mapping and the dict is empty, we want to return an
    # AnsibleMapping instead of a dict, so that we get the right methods
    ansible_constructor = AnsibleConstructor()
    temp = ansible_constructor.construct_python_map([])
    assert isinstance(temp, AnsibleMapping)

    # When the dict has a key, we expect to get an AnsibleMapping back
    ansible_constructor = AnsibleConstructor()
    temp = ansible_constructor.construct_python_map([
        ('key', 'value'),
    ])
    assert isinstance(temp, AnsibleMapping)

    # If the dict has a duplicate key, we should get an error
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-23 05:31:07.941265
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    a_map = yaml.load(
        """
            {foo: hello, bar: world}
        """, Loader = AnsibleConstructor)
    assert a_map == {'foo': 'hello', 'bar': 'world'}



# Generated at 2022-06-23 05:31:11.474669
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    test_str = "!unsafe ''"
    test_node = yaml.compose(test_str)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_unsafe(test_node)

# Generated at 2022-06-23 05:31:20.599787
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # set up object
    y = AnsibleConstructor()

    # construct arguments
    node = {u'tag:yaml.org,2002:map': [{u'tag:yaml.org,2002:str': u'first'}, {u'tag:yaml.org,2002:str': u'1'}]}

    # set up mock values
    mock_key = u'first'
    mock_value = 1
    mock_deep = False
    mock_key_node = {u'tag:yaml.org,2002:str': u'first'}
    mock_value_node = {u'tag:yaml.org,2002:str': u'1'}
    mock_construct_object = y.construct_object
    y.construct_object = MagicMock(name='construct_object')
    y.construct_

# Generated at 2022-06-23 05:31:31.257553
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test happy path with constructor
    vault_secret = b'$ANSIBLE_VAULT;1.1;AES256\nJVAzbAK+GvyDmOz8X6vhU+IkU6mOoZh8dwvJ2ahxuvOpJ6aDy6X8k6U9kecst\nIoocWZ5gPv5zpwnilB5n5Rg\n'
    _vault_constructor = AnsibleConstructor(vault_secrets=[vault_secret])

# Generated at 2022-06-23 05:31:40.691836
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    ansible_map = AnsibleMapping()
    ansible_map['space invasion'] = {'numbers': [1, 2, 3]}
    ansible_map['space invasion']['letters'] = ['I', 'II', 'III']

    assert_equals(ansible_map, AnsibleConstructor.construct_yaml_map(None, '''space invasion:
  numbers: [1, 2, 3]
  letters: [I, II, III]'''))