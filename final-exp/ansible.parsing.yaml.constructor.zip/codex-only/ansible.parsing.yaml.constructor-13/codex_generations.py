

# Generated at 2022-06-23 05:21:44.281191
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    try:
        from yaml import CSafeLoader
    except ImportError:
        from yaml import SafeLoader as CSafeLoader
    # test with valid vault string
    const = AnsibleConstructor()
    const.vault_secrets = [b'vaultpw']
    c = CSafeLoader(const)

# Generated at 2022-06-23 05:21:52.588988
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import os
    import datetime
    import time
    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
    test_data = '''
    - name: test for tpgroup_vars
      hosts: tpgroup
      serial: 2
      strategy: free
      tasks:
      - name: first play
        shell: echo "hello world"
      - name: second play
        shell: echo "test for tpgroup"
    '''
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(yaml.scan(test_data, Loader=AnsibleConstructor))
    loader.construct_mapping()
    print(loader.get_single_data())

# Generated at 2022-06-23 05:22:03.786854
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.parser import ParserError
    from yaml.scanner import ScannerError

    File = u'[1, 2, three, 4]'
    Quoted = u'" [1, 2, three, 4] "'
    expected = [1, 2, u'three', 4]

    with open('/tmp/AnsibleConstructor_construct_yaml_seq.yml', 'w') as File_fd:
        File_fd.write(File)
    with open('/tmp/AnsibleConstructor_construct_yaml_seq.yml', 'r') as File_fd:
        assert AnsibleConstructor().construct_yaml_seq(yaml.parser.Parser(File_fd).get_single_node()).next() == expected


# Generated at 2022-06-23 05:22:11.926544
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode(u'tag:yaml.org,2002:map', [], start_mark=None, end_mark=None)

    node.value = [
        (
            ScalarNode(u'tag:yaml.org,2002:str', u'leaving-cert', (1, 0), (1, 13)),
            ScalarNode(u'tag:yaml.org,2002:str', u'certificate', (1, 15), (1, 26))
        ),
        (
            ScalarNode(u'tag:yaml.org,2002:str', u'leaving-cert', (2, 0), (2, 13)),
            ScalarNode(u'tag:yaml.org,2002:str', u'certificate', (2, 15), (2, 26))
        )
    ]

    ac

# Generated at 2022-06-23 05:22:21.202404
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    assert AnsibleConstructor.construct_vault_encrypted_unicode == AnsibleConstructor._construct_funcs['!vault']
    vault_secrets = ['testsecret1', 'testsecret2']
    AnsibleConstructor_test = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_vault_encrypted_unicode = AnsibleConstructor_test.construct_vault_encrypted_unicode

    # using the real AnsibleVaultEncryptedUnicode class rather than the mock class PlaceHolder as it's used in many other tests.
    #This test case is only for this class.
    ret = ansible_vault_encrypted_unicode(MappingNode(None, None, None, False, []))
    assert ret is None


# Generated at 2022-06-23 05:22:27.653760
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.parser import Parser

    constructor = AnsibleConstructor()

    test_data = u"""
foo:
 - bar
 - baz
"""
    stream = Parser(test_data).get_event_stream()
    constructed_data = constructor.get_single_data(stream)

    assert constructed_data == {'foo': ['bar', 'baz']}

    assert constructed_data['foo'].ansible_pos == ('<unicode string>', 1, 1)

    assert constructed_data.ansible_pos == ('<unicode string>', 1, 1)

    # Make sure we got an object of the right type
    assert isinstance(constructed_data, AnsibleMapping)
    assert isinstance(constructed_data['foo'], AnsibleSequence)


# Generated at 2022-06-23 05:22:32.127659
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # FIXME: Implement a test unit as in test_AnsibleConstructor_construct_yaml_unsafe
    # FIXME: Helper function to test YAML parse tree visit and depth-first traversing
    # FIXME: or use a library or other method to test the YAML document tree traversal
    pass



# Generated at 2022-06-23 05:22:38.410630
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    import yaml
    if not sys.version_info[0] <= 2:
        return

    yaml_ast = yaml.compose(u'foo: bar')
    constructor = AnsibleConstructor()
    constructor.__init__()
    value = constructor.construct_yaml_str(yaml_ast.value[0].key)
    assert isinstance(value, AnsibleUnicode)

# Generated at 2022-06-23 05:22:47.237567
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import io
    from ansible.parsing.yaml.loader import AnsibleLoader
    input = '''
- simple
- string
- of
- strings
'''
    input_bytes = to_bytes(input)
    stream = io.BytesIO(input_bytes)
    loader = AnsibleLoader(stream, file_name='<string>')
    obj = loader.get_single_data()
    assert obj == [u'simple', u'string', u'of', u'strings']



# Generated at 2022-06-23 05:22:57.487258
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import ansible.constants as C
    import sys
    sys.modules['ansible'] = type('ansible', (), {})
    sys.modules['ansible'].constants = C

    # Install custom behavior
    def _variable_processor(self, key, value):
        # Returns the value of a variable.
        return value
    from ansible.vars import VariableManager
    VariableManager._variable_processor = _variable_processor

    # Create variables
    variables = AnsibleUnsafeText("{{ssn}}")

    # Create constructer
    constructer = AnsibleConstructor()

    # Create node
    class node(object):
        pass
    node.id = 'object'
    # Create subnode

# Generated at 2022-06-23 05:23:08.042107
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Test default AnsibleConstructor.construct_mapping()
    yaml_data = {
        "first": 1,
        "second": "2",
    }
    data = yaml.load(yaml.dump(yaml_data))
    assert data == yaml_data

    # Test AnsibleConstructor.construct_mapping()
    data = AnsibleConstructor.construct_mapping(None, yaml_data)
    assert data == yaml_data


# Test default AnsibleConstructor.construct_mapping()

# Generated at 2022-06-23 05:23:17.201532
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.data import DataLoader

    yaml_text = '''
    - command: echo hello
      args:
        _raw_params: "{{unsafe_text}}"
    '''
    try:
        loader = DataLoader()
        unsafe_text = '" | tee /tmp/ansible_test'
        data = loader.load(yaml_text)
        task = data['tasks'][0]
        assert task['args']['_raw_params'] == unsafe_text
    except Exception as e:
        assert False, to_text(e)


# If you want to build the YAML from a python object and load it afterwards, you can use the
# following steps:
#
#

# Generated at 2022-06-23 05:23:19.328800
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ac = AnsibleConstructor()
    assert ac.construct_yaml_seq is ansible_yaml_seq_with_ordered_load


# Generated at 2022-06-23 05:23:29.229448
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
- a: !unsafe "{{ lookup('file', '/etc/hostname') }}"
- b: !unsafe "{{ lookup('file', '/etc/hostname') }}"
'''

    # Show that the !unsafe tag causes the string to be wrapped in a AnsibleUnsafeText Object
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert isinstance(data[0]['a'], AnsibleUnsafeText)
    assert isinstance(data[1]['b'], AnsibleUnsafeText)
   

# Generated at 2022-06-23 05:23:40.217892
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_constructor = AnsibleConstructor()
    # Create a mapping node to pass to construct_vault_encrypted_unicode
    # for testing.
    test_mapping_node = MappingNode(None, None, True, None, [], [], None, None)
    test_data = "AES256 encrypted bytes"
    test_scalar = test_constructor.construct_scalar(test_data)
    test_mapping_node.value = [("value", test_scalar)]
    # Create VaultLib object for AnsibleVaultEncryptedUnicode to use.
    test_vault = VaultLib(
        password='ansible',
        secrets=[b'ansible'],
    )
    # Create an AnsibleVaultEncryptedUnicode object and compare it to the one
    # created with the

# Generated at 2022-06-23 05:23:50.602771
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml.nodes import ScalarNode
    import copy

    node_data = {
        'version': '0.0.1',
        'project': 'foo',
        'fullname': 'bar',
    }

    def node_test_factory(name, value, pos, node_type=ScalarNode):
        node = node_type(tag=u'tag:yaml.org,2002:str', value=value)
        node.name = name
        node.line = pos[1]
        node.column = pos[2]
        node.start_mark = copy.deepcopy(node)
        node.start_mark.name = pos[0]
        node.end_mark = node.start_mark
        return node

    nodes = {}

# Generated at 2022-06-23 05:24:00.186369
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys, os
    
    test_cases = [
    {
        'input' : '''\
            a: b
            c:
              - d
        ''',                    # yaml input
        'output' : {             # expected output
            'a': 'b',
            'c': [
                'd',
                ],
            },
        'ansible_pos' : ('<unicode string>', 1, 1),
        }
    ]

    for test_case in test_cases:
        c = AnsibleConstructor()
        map = c.construct_yaml_map(c.construct_yaml_str(test_case['input']))
        assert test_case['output'] == map, 'expected: {0}, actual: {1}'.format(test_case['output'], map)
        assert test_

# Generated at 2022-06-23 05:24:11.752668
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    valid = """
a: b
  c: d
    e: f
      g: h
        i: j
          k: l
""".strip()
    doc = yaml.load(valid, Loader=AnsibleConstructor)
    assert valid == yaml.dump(doc, Dumper=yaml.SafeDumper, default_flow_style=False)

    invalid = """
a: b
  c: d
    e: f
      g: h
        i: j
          k: l
""".strip()
    doc = yaml.load(invalid, Loader=AnsibleConstructor)
    assert invalid == yaml.dump(doc, Dumper=yaml.SafeDumper, default_flow_style=False)


# Generated at 2022-06-23 05:24:16.848612
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    str_value = 'string'
    test_value = AnsibleUnicode('string')

    node = None
    instance = AnsibleConstructor(None, None)

    #test
    result = instance.construct_yaml_str(node)
    assert result.__str__() == test_value.__str__() # equal AnsibleUnicode objects

    # cleanup
    del instance


# Generated at 2022-06-23 05:24:27.128323
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import load
    data = """
- name: test_AnsibleConstructor
  dict:
    has_duplicate_key: hello
    has_duplicate_key: world
  list:
    - list_entry_one
    - list_entry_two
  illegal_unsafe_key: !unsafe "This is an illegal key"
    """
    c = AnsibleConstructor()
    ret = load(data, Loader=c)
    assert isinstance(ret[0]['dict'], AnsibleMapping)
    assert isinstance(ret[0]['list'], AnsibleSequence)
    assert ret[0]['dict']['has_duplicate_key'] == "world"
    assert ret[0]['list'][1] == "list_entry_two"

# Generated at 2022-06-23 05:24:37.575959
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader

    class MockNode:
        pass

    class MockMark:
        column = 0
        line = 1
        buffer = None
        pointer = 0

        def __init__(self, data):
            self.buffer = to_bytes(data)

        def get_snippet(self, indent=0, max_length=75):
            return "test"

    assert isinstance(AnsibleLoader(MockNode()).construct_object(MockNode()), dict)

    mock_node = MockNode()
    mock_node.value = [(MockNode(), MockNode())]

    mock_node.start_mark = MockMark("test_string")


# Generated at 2022-06-23 05:24:39.488241
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert AnsibleConstructor().construct_yaml_seq("foo") == "foo"


# Generated at 2022-06-23 05:24:43.874526
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_obj = AnsibleSequence()
    yaml_obj.extend([1, 2, 3])
    yaml_obj.ansible_pos = ('test_file', 2, 15)
    assert yaml_obj == AnsibleConstructor()._yaml_construct_seq(None, None, yaml_obj)

# Generated at 2022-06-23 05:24:53.542779
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_data = '''
- host: localhost
  tasks:
  - name: hello world
    set_fact:
      var: "{{ var }} and an inline {{ lookup('template', 'template.j2') }}"
'''

    data = AnsibleLoader(yaml_data).get_single_data()
    assert data == [{'host': 'localhost',
                     'tasks': [{'name': 'hello world',
                                'set_fact': {'var': AnsibleUnicode('{{ var }} and an inline {{ lookup(\'template\', \'template.j2\') }}')}}]}], data

# Generated at 2022-06-23 05:25:00.516636
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    a = AnsibleConstructor(file_name="test_AnsibleConstructor")
    node = MappingNode(tag="tag:yaml.org,2002:python/dict", value=[], start_mark=None, end_mark=None, flow_style=None)
    # with self.assertRaisesRegexp(ConstructorError, "expected a mapping node, but found scalar"):
    #    a.construct_yaml_map(node)
    assert {} == a.construct_yaml_map(node).value



# Generated at 2022-06-23 05:25:13.305257
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
---
- one
- two
- three
'''

    loader = AnsibleLoader(data, file_name=__file__)
    #loader = BaseLoader(data)
    #loader.constructor = AnsibleConstructor()
    data = loader.get_single_data()
    assert len(data) == 3
    assert data[0] == 'one'
    assert data[1] == 'two'
    assert data[2] == 'three'

if __name__ == '__main__':
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-23 05:25:22.725186
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    yaml.add_constructor(u'tag:yaml.org,2002:map', AnsibleConstructor.construct_yaml_map)
    yaml.add_constructor(u'tag:yaml.org,2002:str', AnsibleConstructor.construct_yaml_str)
    yaml.add_constructor(u'tag:yaml.org,2002:seq', AnsibleConstructor.construct_yaml_seq)
    yaml.add_representer(AnsibleMapping, AnsibleDumper.represent_ansible_mapping)
    yaml.add_representer(AnsibleSequence, AnsibleDumper.represent_ansible_sequence)

# Generated at 2022-06-23 05:25:32.588967
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import unittest
    import yaml

    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_types(self):
            data = yaml.load('''
- [hostname,
   key_path,
   port,
   username]
''', Loader=AnsibleConstructor)
            self.assertIsInstance(data, list)
            self.assertIsInstance(data[0], list)

        def test_markers(self):
            data = yaml.load('''
            - [hostname,
               key_path,
               port,
               username]
            ''', Loader=AnsibleConstructor)
            self.assertEqual(data[0].ansible_pos, ('<string>', 2, 1))

   

# Generated at 2022-06-23 05:25:43.152213
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var, AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml

    vault_secrets = ['vault_secret_test']
    vault = VaultLib(secrets=vault_secrets)

    vault_yaml_text = vault.encrypt(b'abcdefghijklmnop')

    yaml_text = \
        u'''
        vault_test: !vault |
            {0}
        unsafe_test: !unsafe
            |
            abcdefghijklmnop
        '''.format(vault_yaml_text)


# Generated at 2022-06-23 05:25:54.252487
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import load
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 05:26:04.909542
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    # Set up objects needed for constructor to function
    file_name = 'test_file_name'
    vault_secrets = ['test_vault_secret', 'test_vault_secret_2']
    a_constructor = AnsibleConstructor(file_name, vault_secrets)

    # Test AnsibleConstructor.__init__()
    assert a_constructor._ansible_file_name == 'test_file_name'
    assert a_constructor._vaults['default'] == VaultLib(vault_secrets)
    assert a_constructor.vault_secrets == ['test_vault_secret', 'test_vault_secret_2']

    # Test AnsibleConstructor.construct_yaml_map()
    test_node = MappingNode(tag='test tag', value=[])

# Generated at 2022-06-23 05:26:07.128521
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    yaml_str = u'{"key": "value"}'
    data = yaml.load(yaml_str, AnsibleConstructor)
    assert data.ansible_pos == (None, 1, 1)


# Generated at 2022-06-23 05:26:17.121726
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from yaml.nodes import MappingNode

    dump_data = dict(
        a = dict(
            b = dict(
                c = dict(
                    c = dict(
                        a = 1,
                        b = 2
                    )
                )
            )
        )
    )

    # Create test yaml file
    filename = "/tmp/test_AnsibleConstructor.yml"
    with open(filename, "w") as yaml_file:
        yaml_file.write(yaml.dump(dump_data, default_flow_style=False))

    # Create yaml loader
    loader = yaml.BaseLoader(yaml_file)
    yaml_file.seek(0)
    first_event = loader.peek_event()

# Generated at 2022-06-23 05:26:27.609381
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # First test a plaintext string
    value = 'this is plaintext'
    node = AnsibleUnicode(value)
    data_from_constructor = AnsibleConstructor(vault_secrets=['plaintext']).construct_vault_encrypted_unicode(node)

    assert to_bytes(value) == data_from_constructor.unvault(data_from_constructor.vault)

    # Now test a vaulted string

# Generated at 2022-06-23 05:26:36.442879
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    yaml_str = """
key1: value1
key2: value2
"""

    # try with C.DUPLICATE_YAML_DICT_KEY set to ignore
    # expect: no error
    #         key1 overwritten by key2
    old_C_DUP = C.DUPLICATE_YAML_DICT_KEY
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    constructor = AnsibleConstructor()
    obj = constructor.construct_yaml_map(yaml_str)
    assert obj == {'key1': 'value2', 'key2': 'value2'}
    C.DUPLICATE_YAML_DICT_KEY = old_C_

# Generated at 2022-06-23 05:26:47.428676
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    _temp_dir = "/tmp/test_AnsibleConstructor_construct_vault_encrypted_unicode"
    _ansible_file_name = os.path.join(_temp_dir, "ansible.yml")
    _vault_password_file = os.path.join(_temp_dir, "vault.key")
    _vault_password = "vault"

    # Create temporary directory for test
    try:
        if os.path.exists(_temp_dir):
            os.remove(_temp_dir)
        os.mkdir(_temp_dir)
    except OSError:
        print ("Creation of the directory %s failed" % _temp_dir)
        return

    # Create temporary ansible.yml and vault.key files for test

# Generated at 2022-06-23 05:26:53.486761
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    data = 'foo: bar'
    loader = yaml.Loader(data)
    loader.add_constructor(u'tag:yaml.org,2002:str', lambda loader, node: AnsibleConstructor.construct_yaml_str(loader, node))
    obj = loader.get_single_data()

    assert isinstance(obj['foo'], AnsibleUnicode)

# Generated at 2022-06-23 05:27:03.433466
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    Tests that AnsibleConstructor.construct_yaml_map has the expected behavior
    """

    dump_str = '''
    [
      {
        "foo": "bar",
        "baz": "qux",
        "quux": {
          "corge": "grault",
          "garply": "waldo",
          "fred": "plugh"
        }
      }
    ]
    '''

    input_data = StringIO(dump_str)

    reader = Reader(input_data)

    # Load data by calling the ``.read()`` method.
    loader = Loader(reader)
    stream = loader.get_single_node()

    # Get the first document from the stream
    doc = stream.documents[0]

    # Get the first node from the document

# Generated at 2022-06-23 05:27:15.140032
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    def test_method(self, node):
        data = AnsibleSequence()
        yield data
        data.extend(self.construct_sequence(node))
        data.ansible_pos = self._node_position_info(node)

    # test case 1:
    test_yaml = {'test': 'test_value'}
    test_yaml_copy = test_yaml.copy()

    # test case 2:
    test_yaml_seq = '- test_1\n- test_2\n- test_3'
    expected_result_2 = ['test_1', 'test_2', 'test_3']

    # test case 3:
    test_yaml_seq_3 = '[1, 2, 3]'

    # test case 4:

# Generated at 2022-06-23 05:27:16.155718
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    print("Untested: AnsibleConstructor test not implemented")

# Generated at 2022-06-23 05:27:24.453592
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """ Test that the AnsibleConstructor.construct_yaml_unsafe method
    is able to create unsafe identifiers.
    """

    # Test method for strings
    unsafe_constructor = AnsibleConstructor()
    node = 'test'
    ret = unsafe_constructor.construct_yaml_unsafe(node)
    assert ret == "test"

    # Test method for lists
    unsafe_constructor = AnsibleConstructor()
    node = [['test']]
    ret = unsafe_constructor.construct_yaml_unsafe(node)
    assert ret == [['test']]

    # Test method for dicts
    unsafe_constructor = AnsibleConstructor()
    node = {'test': 'value'}
    ret = unsafe_constructor.construct_yaml_unsafe(node)

# Generated at 2022-06-23 05:27:35.411186
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class FakeSafeConstructor(object):
        def construct_mapping(self, node):
            return node.value
    # ansible_constructor = AnsibleConstructor(None)
    fake_constructor = FakeSafeConstructor()

    # first node is true
    node = MappingNode('tag:yaml.org,2002:map', [('key1', 'value1'), ('key2', 'value2')], start_mark=None, end_mark=None, flow_style=None)
    assert fake_constructor.construct_mapping(node) == [('key1', 'value1'), ('key2', 'value2')]

    # first node is false

# Generated at 2022-06-23 05:27:42.988860
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_data = '''
        a:
          - str: "{{ foo }}"
    '''
    data = AnsibleLoader(yaml_data).get_single_data()
    assert type(data['a'][0]['str']) == AnsibleUnicode
    assert data['a'][0]['str'] == u"{{ foo }}"

# Generated at 2022-06-23 05:27:48.444250
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    occ = AnsibleConstructor()

    m = occ.construct_yaml_map("abc")

    assert m == {'ansible_pos': 'abc'}

# Generated at 2022-06-23 05:27:54.469808
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test for construct_vault_encrypted_unicode on new line, with
    # a space before the '!vault' and no space after it
    node = MappingNode(tag=u'tag:yaml.org,2002:str')
    node.start_mark.line = 1
    node.start_mark.column = 1

    ac = AnsibleConstructor()
    ac.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-23 05:28:04.920287
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = '''
      hosts:
      - host_name: a.foo.com
        host_vars:
          host_var: host_var_value
        group_names:
          - group_b
          - group_a
      - host_name: b.foo.com
        group_names:
          - group_a
          - group_b
    '''
    class DummyClass:
        pass
    construct_mapping_util = DummyClass()
    construct_mapping_util.construct_yaml_str = AnsibleConstructor.construct_yaml_str
    construct_mapping_util.construct_yaml_map = AnsibleConstructor.construct_yaml_map
    construct_mapping_util.construct_yaml_seq = AnsibleConstructor.construct_yaml_seq



# Generated at 2022-06-23 05:28:11.094659
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import load, loader

    text = """
    - { role: generic, log_dir: '/var/log/%(hostname)s/my_role' }
    """
    yaml_obj = load(text, Loader=loader.Loader)
    actual = yaml_obj[0]
    expected = {u'role': u'generic', u'log_dir': u'/var/log/%(hostname)s/my_role'}

    assert expected == actual

# Generated at 2022-06-23 05:28:21.018920
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import six
    test_data = 'a: 1\nb: 2\n'
    mapping = next(yaml_safe_load(test_data))
    assert isinstance(mapping, dict)
    assert isinstance(mapping, AnsibleMapping)
    assert mapping['a'] == 1
    assert mapping['b'] == 2

    # check line and column numbering for 'a'
    assert mapping.ansible_pos[0] == '<string>'
    assert mapping.ansible_pos[1] == 1
    assert mapping.ansible_pos[2] == 1

    # check line and column numbering for 'b'
    assert mapping['b'].ansible_pos[0] == '<string>'
    assert mapping['b'].ansible_pos[1] == 2
    assert mapping['b'].ansible_

# Generated at 2022-06-23 05:28:29.317175
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import wrap_var

    sample_yaml = """
    a: test
    b:
      c: str
      d:
        f: str
        g:
          - str1
          - str2
        h:
          - str3
          - str4
      e: 1
    """
    # Store original _constructor
    original_constructor = AnsibleConstructor.construct_mapping

# Generated at 2022-06-23 05:28:38.476801
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = '''
- this
- is
- a
- list
'''
    yaml_obj = AnsibleConstructor.construct_yaml_seq(yaml.nodes.SequenceNode(u'tag:yaml.org,2002:seq', [], None, None))
    yaml_obj.extend([AnsibleUnicode(u'this'), AnsibleUnicode(u'is'), AnsibleUnicode(u'a'), AnsibleUnicode(u'list')])

# Generated at 2022-06-23 05:28:47.969972
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    try:
        import yaml
    except ImportError:
        # ImportError when 'yaml' is not installed
        # we just return here and do not run the test case
        return

    yaml_str = """\
-
  - name: test
  - src: /tmp/test
  - dest: /etc/a/remote-copy\
"""

    class FakeNode(object):
        node = yaml.Composer._compose_node(yaml.composer.Composer(yaml_str), None)
        id = node.id
        value = node.value
        tag = node.tag
        start_mark = node.start_mark

    fake_node = FakeNode()
    assert fake_node.id == u'tag:yaml.org,2002:seq'

    yaml_obj = Ans

# Generated at 2022-06-23 05:28:52.884753
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = u'hi: there'
    ret = AnsibleLoader(yaml_str, file_name='test').get_single_data()

    assert isinstance(ret, dict)
    assert isinstance(ret[u'hi'], AnsibleUnicode)
    assert ret[u'hi'] == u'there'

# Generated at 2022-06-23 05:28:57.384876
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    s = '[1, 2, 3]'
    result = yaml.load(s, Loader=AnsibleConstructor)
    assert result == [1, 2, 3]
    assert result.__class__.__name__ == 'AnsibleSequence'



# Generated at 2022-06-23 05:29:07.490332
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    obj = ('a', 'b', 'c')
    s = "a: valueA\nb: valueB\nc: valueC\n"
    yaml_obj = yaml.load(s, Loader=AnsibleConstructor)
    assert yaml_obj == dict(zip(obj, obj))

    s = "a: valueA\nb: valueB1\nb: valueB2\nc: valueC\n"
    yaml_obj = yaml.load(s, Loader=AnsibleConstructor)
    assert yaml_obj == dict(a='valueA', b='valueB2', c='valueC')
    s = "a: valueA\n: valueB\nc: valueC\n"
    yaml_obj = yaml.load(s, Loader=AnsibleConstructor)

# Generated at 2022-06-23 05:29:18.944231
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.constructor import construct_yaml_map

    # file-name:
    #
    #   one: 1
    #   two: 2
    #
    # We expect the following return value(s):
    #   [{'ansible_pos': ('file-name', 1, 0), 'one': 1, 'two': 2}]
    #
    # We expect the following exception(s):
    #   None

    yaml_data = u'one: 1\ntwo: 2\n'
    yaml_file_name = u'file-name'

    expected_results = [{u'ansible_pos': (u'file-name', 1, 0), u'one': 1, u'two': 2}]


# Generated at 2022-06-23 05:29:20.836030
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert AnsibleConstructor.construct_yaml_seq is not None


# Generated at 2022-06-23 05:29:31.721412
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    raw_yaml = """
            a: !!python/object/apply:os.system ["echo hi"]
            b: !!python/object/apply:os.system ["echo "hi""]
            c: !!python/object/apply:os.system ["echo 'hi'"]
            """
    # Following is equivalent to a Python dictionary. These are the expected results of parsing the raw_yaml above.

# Generated at 2022-06-23 05:29:33.947976
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ret = AnsibleConstructor.construct_yaml_str(None)
    assert ret == {}
    assert ret.__class__.__name__ == "AnsibleUnicode"

# Generated at 2022-06-23 05:29:43.191769
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    class DummyObject(object):

        def __init__(self):
            self.number = 1
            self.string = "string"
            self.boolean = True
            self.dictionary = {
                "key1": 1,
                "key2": 2,
                "key3": 3,
            }
            self.list = [1, 2, 3, 4, 5]
            self.unsafe = wrap_var(self)

        def __repr__(self):
            return 'DummyObject(number=%r, string=%r, boolean=%r, dictionary=%r, list=%r, unsafe=%r' \
                   % (self.number, self.string, self.boolean, self.dictionary, self.list, self.unsafe)


# Generated at 2022-06-23 05:29:52.734066
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml import objects
    yaml.constructor.SafeConstructor.add_constructor(
        u'tag:yaml.org,2002:str',
        yaml.constructor.SafeConstructor.construct_scalar)
    yaml.constructor.SafeConstructor.add_constructor(
        u'tag:yaml.org,2002:python/unicode',
        yaml.constructor.SafeConstructor.construct_scalar)

    yaml_str = u'unicode string !@#$%^&*()'
    yaml_seq = [yaml_str]

    # use the "safe" constructor to create the wanted object
    yaml_object = yaml.safe_load(yaml.dump(yaml_seq))

# Generated at 2022-06-23 05:30:03.797271
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import unittest
    from yaml.nodes import ScalarNode, MappingNode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class TestAnsibleConstructor(unittest.TestCase):

        def test_construct_yaml_map(self):
            construct_yaml_map = AnsibleConstructor.construct_yaml_map
            construct_yaml_map._annavoid_ = None
            construct_yaml_map._fullname_ = None
            construct_yaml_map._name_ = 'construct_yaml_map'
            construct_yaml_map._class_ = AnsibleConstructor
            construct_yaml_map._self_ = AnsibleConstructor


# Generated at 2022-06-23 05:30:07.744577
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml = '''
    - test1
    - test2
    '''
    data = yaml.load(yaml)
    assert data[0] == 'test1'
    assert data[1] == 'test2'


# Generated at 2022-06-23 05:30:14.957242
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, file_name='mock')
    mapping_node = MappingNode([('key1', 1), ('key2', 2), ('key1', 3)])
    mapping_list = [('key1', 1), ('key2', 2), ('key1', 3)]
    mapping = loader.construct_mapping(mapping_node)
    assert mapping == {u'key2': 2, u'key1': 3}
    assert mapping.ansible_pos == ('mock', 1, 1)

# Generated at 2022-06-23 05:30:21.121002
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with an AnsibleVaultEncryptedUnicode string
    file_name = 'dummy'
    vault_secrets = ['dummy']
    constructor = AnsibleConstructor(file_name, vault_secrets)

    data = '$ANSIBLE_VAULT;1.1;AES256;dummy\n61343562623665636163343233366135623161396131633631336639313733623961366166356266620a301666316266336163313231336134613961356337616332333466356562623164653039623530620a'
    node = AnsibleConstructor.construct_yaml_str(constructor, data)
    assert type(node) == AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:30:27.628176
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    vault = VaultLib()
    secret = vault.encrypt('test_password')
    b_secret = to_bytes(secret)
    b_secret_encoded = base64.b64encode(b_secret)
    secret_yaml = u"!vault |{0}\n".format(to_native(b_secret_encoded))
    node = yaml.compose(secret_yaml)
    assert isinstance(node, yaml.nodes.ScalarNode)
    assert secret == AnsibleConstructor.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-23 05:30:39.584718
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a = AnsibleConstructor()

    # Check that duplicate keys are ignored
    assert a.construct_mapping(MappingNode(None, [], None), deep=False) == {}
    assert a.construct_mapping(MappingNode(None, [], None), deep=True) == {}

    assert a.construct_mapping(MappingNode(None, [], None), deep=False) == {}
    assert a.construct_mapping(MappingNode(None, [], None), deep=True) == {}

    assert a.construct_mapping(MappingNode(None, [], None), deep=False) == {}
    assert a.construct_mapping(MappingNode(None, [], None), deep=True) == {}

    assert a.construct_mapping(MappingNode(None, [], None), deep=False) == {}

# Generated at 2022-06-23 05:30:49.570004
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode
    from yaml.composer import Composer
    from yaml.parser import Parser, ParserError
    from yaml.scanner import Scanner
    from yaml.reader import Reader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import io
    stream = io.StringIO(u"foo: bar\n")
    reader = Reader(stream)
    scanner = Scanner(reader)
    parser = Parser(scanner)
    composer = Composer(parser)
    data = {}
    constructor = AnsibleConstructor()
    node = composer.compose_document()
    str(constructor.construct_yaml_map(node))
    assert isinstance(constructor.construct_yaml_map(node), dict)

# Generated at 2022-06-23 05:30:59.976644
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.dataloader import DataLoader

    # Test password is 'foobar'.

# Generated at 2022-06-23 05:31:11.932181
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    display.verbosity = 4
    vault_password_file = os.path.join(os.path.dirname(__file__), 'vault_password')
    vault_lib = VaultLib()
    vault_lib.load(vault_password_file)
    c = AnsibleConstructor(vault_secrets=[vault_lib])


# Generated at 2022-06-23 05:31:12.433618
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

# Generated at 2022-06-23 05:31:18.656624
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.objects import AnsibleSequence

    list_as_string = "[1, 2, 3]"
    data = AnsibleSequence()
    data.extend([1, 2, 3])

    assert(data == AnsibleConstructor().construct_yaml_seq(list_as_string))



# Generated at 2022-06-23 05:31:29.497967
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    class MockVault(VaultLib):

        def unprotect_data(self, vault_data):
            return b'unprotected data'

    def test_data_type(data):
        """Check that constructed data is of the correct type."""
        assert isinstance(data, AnsibleUnsafe)

    def test_wrapped_data(data):
        """Check that AnsibleUnsafe wraps the appropriate object."""
        wrapped_data = data._wrapped

        assert isinstance(wrapped_data, AnsibleBaseYAMLObject)

# Generated at 2022-06-23 05:31:41.113832
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test case if a mapping node is passed
    test_node = MappingNode(None, None, "test_mapping_node")
    test_deep = False
    obj = AnsibleConstructor()
    result = obj.construct_mapping(test_node, test_deep)
    assert type(result) == dict

    # Test case if a non mapping node is passed
    test_node = "test_node"
    test_deep = False
    obj = AnsibleConstructor()
    result = obj.construct_mapping(test_node, test_deep)
    assert type(result) == dict

    # Test case if dummy key is passed
    test_node = MappingNode(None, None, "test_mapping_node")
    test_deep = False
    obj = AnsibleConstructor()
    result = obj.construct_