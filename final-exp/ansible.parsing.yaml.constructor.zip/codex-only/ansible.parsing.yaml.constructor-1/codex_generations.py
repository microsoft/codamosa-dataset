

# Generated at 2022-06-23 05:21:46.949570
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # this is an example of the values that the yaml dump of an encrypted_text
    # may take
    test_string_1 = "{AES256}c3RlbGxhbnRpY3VzdGx5aW5zZXJ0ZWQK"

# Generated at 2022-06-23 05:21:55.793113
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    if sys.version_info < (2, 7):
        # no need to test AnsibleConstructor on python2.6
        return
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    data = DataLoader()
    data.set_basedir(os.path.join(os.path.dirname(__file__), '../../../test/'))
    raw_data = '''
    a: 1
    b: 2
    c: 3
    '''
    data_obj = data.load(raw_data)
    assert isinstance(data_obj, AnsibleMapping), 'Failed to construct Ansible mapping'

# Generated at 2022-06-23 05:22:06.887510
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    import tempfile
    import os

    class YAMLObject:
        def __init__(self, value):
            self.value = value
        def __hash__(self):
            return hash(self.value)
        def __eq__(self, other):
            return self.value == other.value

    class YAMLSequence:
        def __init__(self, value):
            self.value = value
        def __getitem__(self, index):
            return self.value[index]
        def __len__(self):
            return len(self.value)
        def __eq__(self, other):
            return self.value == other.value

    class YAMLMap:
        def __init__(self, mapping):
            self.mapping = mapping

# Generated at 2022-06-23 05:22:16.784611
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = """
                - test:
                    name: foo
                    bar:
                        - 1
                        - 2
                        - 3
                    baz:
                        - a
                        - b
                        - c
                """
    # yaml.load can't handle data with leading newlines
    yaml_data = [x.strip() for x in yaml_data.split('\n') if x.strip()]
    yaml_data = '\n'.join(yaml_data)
    mapping = AnsibleConstructor().construct_yaml_map(yaml.compose(yaml_data))
    assert mapping['test']['bar'] == [1, 2, 3]

# Generated at 2022-06-23 05:22:18.346080
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert AnsibleConstructor().construct_yaml_str(None) == ""

# Generated at 2022-06-23 05:22:29.905000
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

# Generated at 2022-06-23 05:22:41.410954
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class TestConstructor(AnsibleConstructor):
        def __init__(self):
            self.datasource = '<test_constructor_source>'
            self.list_of_sequences = []
            super(TestConstructor, self).__init__()

        def construct_yaml_seq(self, node):
            # Add the list to a class attribute for testing
            self.list_of_sequences.append(self.construct_sequence(node))
            return self.construct_sequence(node)

    test_constructor = TestConstructor()
    data = '''
    - - foo
      - bar
    - - baz
      - qux
    '''
    test_constructor.construct_yaml(data)

# Generated at 2022-06-23 05:22:51.892851
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping

    # testing a simple mapping
    node = yaml.compose('''
            A: B
            C: D
            E: F
            ''')

    mapping1 = AnsibleLoader(node).get_single_data()
    mapping2 = AnsibleConstructor.construct_mapping(None, node, deep=False)
    assert isinstance(mapping1, AnsibleMapping)
    assert isinstance(mapping2, AnsibleMapping)
    assert mapping1 == mapping2

    # testing a simple mapping with duplicated keys
    node = yaml.compose('''
            A: B
            A: D
            E: F
            ''')
    mapping

# Generated at 2022-06-23 05:23:01.849451
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import unittest2 as unittest
    from io import BytesIO

    try:
        import yaml
    except ImportError:
        raise unittest.SkipTest("No yaml module, skipping test_AnsibleConstructor_construct_yaml_seq")

    class TestConstructor(unittest.TestCase):

        def test_construct_yaml_seq(self):
            data = '''
            - 1
            - 2
            - 3
            '''
            data_yaml = yaml.load(BytesIO(data), Loader=AnsibleConstructor)

            self.assertEqual(data_yaml.pop(),3)
            self.assertEqual(data_yaml.pop(),2)
            self.assertEqual(data_yaml.pop(),1)

# Generated at 2022-06-23 05:23:12.573651
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data=dict(a=1, b=2)
    node=dict(start_mark=dict(line=1, column=1), id='map', value=[dict(key=dict(start_mark=dict(line=1, column=1), id='str', value='a'), value=dict(start_mark=dict(line=1, column=1), id='int', value=1)), dict(key=dict(start_mark=dict(line=1, column=1), id='str', value='b'), value=dict(start_mark=dict(line=1, column=1), id='int', value=2))])
    from ansible.parsing.yaml.data import AnsibleVaultEncryptedUnicode
    assert AnsibleConstructor(file_name='file.yml').construct_yaml_map(node).y

# Generated at 2022-06-23 05:23:20.204465
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Check for duplicate dict keys, C.DUPLICATE_YAML_DICT_KEY is set to 'ignore' and warn in unit test
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    raw_data = """
    - hosts: localhost
      vars:
        a: 1
        a: 2
    """
    data = AnsibleLoader(None).load(raw_data)
    assert data[0] == {
        u'hosts': u'localhost',
        u'vars': wrap_var({u'a': 2}),
        u'vars_files': [{u'a': u'1'}]}


# Generated at 2022-06-23 05:23:26.477418
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=None)
    print(ansible_constructor.construct_mapping({'server1': '192.168.0.1', 'server2': '192.168.0.2'}))
    print(ansible_constructor.construct_mapping({'server1': '192.168.0.1', 'server1': '192.168.0.2'}))

# Generated at 2022-06-23 05:23:37.610036
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = dict(
        a=1,
        b=2,
    )
    yaml_data = AnsibleLoader(data, file_name="").get_single_data()

    # test the default "!object" (no tag)
    assert yaml_data['a'] == 1

    # test a tag that isn't "!unsafe"
    assert isinstance(yaml_data['b'], AnsibleUnicode)
    assert yaml_data['b'] == u'2'

    # test a tag of "!unsafe"
    # TODO: code to test this

# Generated at 2022-06-23 05:23:45.212242
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Given
    my_constructor = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    node.start_mark.line = 10
    node.start_mark.column = 11
    node.start_mark.index = 12
    node.start_mark.name = "file.yml"

    # When
    my_constructor.construct_yaml_map(node)

    # Then
    assert hasattr(my_constructor, "construct_yaml_map")
    assert my_constructor.construct_yaml_map(node)

test_AnsibleConstructor_construct_yaml_map()

# Generated at 2022-06-23 05:23:53.704526
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import load

    # To replicate the bug ansible/ansible#17043
    # With python3, the constructors are not replaced because they are
    # wrappers around the original yaml constructors.
    # These wrappers are guarding the methods by calling the 'super'
    # method, which means that the original constructor will be called after
    # the ansible constructor.
    # This means that when the duplicate dict key error is raised, it will
    # be raised in the original constructor, not in the ansible constructor.
    # Here we're using a custom constructor, which is used to call the
    # ansible constructor.
    class CustomAnsibleConstructor(SafeConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            self._ansible_file_name = file_name
           

# Generated at 2022-06-23 05:24:02.961801
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import os.path
    import sys
    import unittest

    class AnsibleConstructor_construct_mapping_TestCase(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.constructor = AnsibleConstructor()
            self.construct_mapping = self.constructor.construct_mapping

        def tearDown(self):
            del self.Constructor
            del self.construct_mapping

        def test_overwriting(self):
            data = u"""foo: bar
                foo: baz"""
            warnings = []
            WARNING = "Duplicate dictionary key found on line 3: foo.  Using last defined value only."
            class TestWarn(object):
                def __init__(self, message):
                    warnings.append(message)
            self.constructor.construct

# Generated at 2022-06-23 05:24:10.803720
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    doc = b'{first: {a: 1, b: 2, c: 3}, second: {d: 4, e: 5, f: {g: 6, h: [7, 8, 9]}}}'
    node = yaml.compose(doc)
    func = AnsibleConstructor()
    res = func.construct_mapping(node)
    assert res['first']['a'] == 1

# import yaml
# print yaml.dump(res)

# Generated at 2022-06-23 05:24:18.980988
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # This function is a simple unit test written to help verify
    # the correct behavior of the AnsibleConstructor class.

    # Create a constructer for the yaml file
    AC = AnsibleConstructor()

    # Create an example yaml file and pass it to the AnsibleConstructor.construct_yaml_map() method
    # NOTE: This is the same yaml file used in the example in AnsibleConstructor.construct_yaml_map()
    #       The goal is to ensure that the same output is generated both when the method is called
    #       from the yaml parser and when it is called directly

# Generated at 2022-06-23 05:24:29.465555
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    code = '''
    a:
      b: 1
      c: 2
    d:
      e: 3
      f: 4
    '''
    yaml_obj = yaml.load(code, Loader=AnsibleConstructor)
    assert type(yaml_obj) == AnsibleMapping
    assert type(yaml_obj['a']) == AnsibleMapping
    assert type(yaml_obj['a']['b']) == AnsibleUnicode
    assert type(yaml_obj['d']) == AnsibleMapping
    assert type(yaml_obj['a']['c']) == AnsibleUnicode
    assert type(yaml_obj['d']['e'])

# Generated at 2022-06-23 05:24:39.569163
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import ansible.parsing.vault as vault_mod

    v = vault_mod.VaultLib(secrets=['test'])
    vault_text = '$ANSIBLE_VAULT;1.2;AES256;test_test\n34350233380a66393139653630643338393130343030616130653638646563383730623865366339\n65366661306433383931303430306161306536386465633837306238653663396536666635a'
    encrypted_value = v.encrypt(vault_text)

# Generated at 2022-06-23 05:24:44.663517
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """---
-  - 1
-  - 2
-  - 3
-  - 4">
...
"""
    doc = AnsibleLoader(yaml_str).get_single_data()
    assert [1, 2, 3, 4] == doc


# Generated at 2022-06-23 05:24:54.302978
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import shutil
    import tempfile
    import yaml

    vault_file_path = os.path.join(tempfile.mkdtemp(), "myvault_construct_vault_encrypted_unicode.yaml")

# Generated at 2022-06-23 05:25:03.704427
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
foo:
  - bar
  - bam
    baz: [1, 2, 3]
    bam:
      - one
      - two
"""
    yaml_obj = AnsibleLoader(data).get_single_data()
    assert yaml_obj['foo'].ansible_pos == ('<string>', 2, 1)
    # This is a quirk of the yaml parser. It parses
    #  - bar
    #  - bam
    #    baz: [1, 2, 3]
    #    bam:
    #      - one
    #      - two
    #
    # into `[{'bam': {'baz': [1, 2, 3], 'bam': ['

# Generated at 2022-06-23 05:25:14.419139
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import yaml
    data = """---
    - !unsafe 'a'
    - !unsafe [1,2,3]
    - !unsafe {a: 1, b: 2}
    """
    yaml_data = yaml.load(data, Loader=AnsibleConstructor)
    assert yaml_data[0] == 'a'
    assert isinstance(yaml_data[0], AnsibleUnsafeText)
    assert yaml_data[1] == [1,2,3]
    assert isinstance(yaml_data[1], AnsibleUnsafeText)
    assert yaml_data[2] == {'a': 1, 'b': 2}

# Generated at 2022-06-23 05:25:23.498883
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # ConstructorError should be raised if found a duplicate dict.
    # ConstructorError should contain the appropriate problem.
    # Duplicate dict should not be retained.

    data = """
  foo: bar
  foo: bar
"""

    duplicate_dict_key_config = 'error'
    # "warning", "error", "ignore"

    ansible_constructor = AnsibleConstructor()

    try:
        constructed_data = yaml.load(data, Loader=AnsibleConstructor)
    except ConstructorError as ce:
        if 'duplicate dict key' in ce.problem:
            print('duplicate dict key found')
        else:
            print('expected a ConstructorError')
            assert False

        if duplicate_dict_key_config == 'error':
            print('duplicate dict key error')
        el

# Generated at 2022-06-23 05:25:30.363224
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    AnsibleConstructor.add_constructor(
        u'tag:yaml.org,2002:str',
        AnsibleConstructor.construct_yaml_str)
    test_yaml = "key: test"
    loaded_yaml = yaml.load(test_yaml, Loader=AnsibleConstructor)
    assert isinstance(loaded_yaml["key"], AnsibleUnicode)
    assert loaded_yaml["key"] == "test"

# Generated at 2022-06-23 05:25:33.438740
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert AnsibleConstructor._safe_constructor.construct_mapping({}, deep=True) == {}

# Generated at 2022-06-23 05:25:44.256456
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib

    vault_secrets = [
        'ansible',
        'hacker',
    ]

    c = AnsibleConstructor(vault_secrets=vault_secrets)


# Generated at 2022-06-23 05:25:49.168152
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # verify that AnsibleConstructor does not complain about duplicate keys.
    # See bug: https://github.com/ansible/ansible/issues/34148
    import yaml
    yaml_string = '''
---
key: value
key: secondvalue # need to include this key a second time to test the behavior
'''
    result = yaml.load(yaml_string, Loader=AnsibleConstructor)
    assert 'key' in result
    assert result['key'] == 'secondvalue'

# Generated at 2022-06-23 05:26:00.710916
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    object_ = yaml.load('''
        plainString: "test"
        stringWithNewLines: |
          line 1
          line 2
          line 3
        stringWithBlankLines: |
          line 1

          line 2

          line 3

        stringWithNewlinesAndTabs: |
          line one
            tab one
            tab two
          line two
          line three

        stringWithQuotes: "quotes" "embedded"
        ''')

    assert object_.get("plainString").start_mark.line == 1
    assert object_.get("plainString").start_mark.column == 8
    assert object_.get("plainString").end_mark.line == 1
    assert object_.get("plainString").end_mark.column == 13

    assert object_.get("stringWithNewLines").start

# Generated at 2022-06-23 05:26:03.189500
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert isinstance(AnsibleConstructor(file_name=None).construct_yaml_str(None), AnsibleUnicode)


# Generated at 2022-06-23 05:26:13.972508
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['secret1', 'secret2']
    obj = AnsibleConstructor(file_name='/tmp/test.yml', vault_secrets=vault_secrets)

    # Need to create nodes for the AnsibleConstructor to process
    class Node():
        def __init__(self, start_mark, string):
            self.start_mark = start_mark
            self.value = string
    class StartMark():
        def __init__(self):
            self.line = 2
            self.column = 5
            self.name = 'test.yml'
    node = Node(start_mark=StartMark(), string="AAECAm8vB5LlOZfXQdjsJW8UPvYlOFU4w6Ufd3qUOY8=")

    actual = obj.construct

# Generated at 2022-06-23 05:26:18.213926
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    print('Test AnsibleConstructor')
    data = "name: '123'"
    ast = yaml.load(data, Loader=AnsibleConstructor)
    print('ast = {}'.format(ast))
    assert ast == {'name': '123'}


# Generated at 2022-06-23 05:26:23.234952
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class MockNode(object):
        def __init__(self, pos):
            self.value = pos
            self.start_mark = pos

    ac = AnsibleConstructor()
    node = MockNode((1, 1, 1))
    mapping = ac.construct_mapping(node)
    assert mapping.ansible_pos == (1, 1, 1)



# Generated at 2022-06-23 05:26:29.440312
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = "str"
    node = yaml.nodes.ScalarNode(tag=yaml.resolver.BaseResolver.DEFAULT_SCALAR_TAG, value=yaml_str)
    ac = AnsibleConstructor()
    expect_result = AnsibleUnicode(yaml_str)
    assert ac.construct_yaml_str(node) == expect_result


# Generated at 2022-06-23 05:26:38.415915
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = '''
    - 1
    - 2
    - 3
    '''
    sequence_list = AnsibleLoader(yaml_str, file_name='test_AnsibleConstructor_construct_yaml_seq').get_single_data()
    assert(isinstance(sequence_list, AnsibleSequence))
    assert(isinstance(sequence_list, list))
    assert(len(sequence_list) == 3)
    assert(sequence_list[0] == 1)
    assert(sequence_list[1] == 2)
    assert(sequence_list[2] == 3)



# Generated at 2022-06-23 05:26:48.827253
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:26:59.359777
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = '''
foo:
  bar: 1
  baz:
    - 2
    - 3
  quux:
    -
      v1: 1
      v2: 2
    -
      v3: 3
      v4: 4
'''

    import yaml
    ansible_constructor = AnsibleConstructor()
    data = yaml.load(yaml_str, Loader=yaml.Loader)
    assert ansible_constructor.construct_mapping(data) == {'foo': {'bar': 1, 'baz': [2, 3], 'quux': [{'v1': 1, 'v2': 2}, {'v3': 3, 'v4': 4}]}}

# vim:set noet ts=4 sts=4 sw=4 sta filetype=python

# Generated at 2022-06-23 05:27:07.254131
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    mock_node = type('MockNode', (object, ), {'start_mark': type('MockNode', (object, ), {'line': 2}), 'end_mark': type('MockNode', (object, ), {'line': 5}), '_nodes':['nodeA', 'nodeB'], 'id': 'seq', 'value': [1, 2]})
    ac = AnsibleConstructor()
    ac.construct_yaml_seq(mock_node)


# Generated at 2022-06-23 05:27:19.100010
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class MockAnsibleConstructor(AnsibleConstructor):
        def __init__(self, secrets=None):
            super(MockAnsibleConstructor, self).__init__(vault_secrets=set(secrets or []))

    file_name = 'test_file'

    # Case 1. Secrets provided
    mock_constructor = MockAnsibleConstructor(secrets=['secret_A', 'secret_B'])
    new_node = mock_constructor.construct_vault_encrypted_unicode(file_name, '', '', [])

    assert new_node.vault == mock_constructor._vaults['default']

    # Case 2. No Secrets provided
    mock_constructor = MockAnsibleConstructor(secrets=None)
    new_node = mock_constructor.construct_v

# Generated at 2022-06-23 05:27:27.688229
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test ansible_pos as part of the return object.
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from yaml import safe_load, dump
    text = u"fobarfoobar: !unsafe 'not safe!'\n"
    stream = StringIO(text)
    try:
        obj = safe_load(stream)
    except:
        # an exception should not happen
        return False
    else:
        if isinstance(obj, dict):
            if isinstance(obj[u'fobarfoobar'], AnsibleUnicode):
                if obj[u'fobarfoobar'].ansible_pos:
                    return True
    return False


# Generated at 2022-06-23 05:27:37.324460
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml import AnsibleLoader

    data = '''
    - foo
    - bar
    - baz
    - name: mylist
      value:
        - one
        - two
        - three
    '''

    loader = AnsibleLoader(data)
    results = loader.get_single_data()
    assert isinstance(results, list)
    assert len(results) == 4
    assert results[0] == 'foo'
    assert results[1] == 'bar'
    assert results[2] == 'baz'
    assert results[3] == {'name': 'mylist', 'value': ['one', 'two', 'three']}

# Generated at 2022-06-23 05:27:43.427253
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', 'val')
    val = AnsibleConstructor().construct_yaml_str(node)
    assert type(val) is AnsibleUnicode

# Generated at 2022-06-23 05:27:54.601472
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.vault import VaultLib

    vault_secrets = [u'default_password']

# Generated at 2022-06-23 05:28:05.060131
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Test with a scalar
    value = AnsibleConstructor(file_name=None, vault_secrets=None).construct_yaml_unsafe(u'hello')
    assert value.__str__() == u"hello"

    # Test with a dict
    value = AnsibleConstructor(file_name=None, vault_secrets=None).construct_yaml_unsafe(
        {'key1': 'value1', 'key2': 'value2'})
    assert value.__str__() == u"{u'key2': u'value2', u'key1': u'value1'}"

    # Test with a list
    value = AnsibleConstructor(file_name=None, vault_secrets=None).construct_yaml_unsafe(['value1', 'value2'])
    assert value.__str

# Generated at 2022-06-23 05:28:14.521546
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # ctor (via load) calls construct_vault_encrypted_unicode with a scalar
    # value in node.value and node.tag == u'tag:yaml.org,2002:str'
    node = object()
    node.tag = u'tag:yaml.org,2002:str'

# Generated at 2022-06-23 05:28:22.742822
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # create a new instance of ansible constructor
    ac = AnsibleConstructor()

    # set a scalar
    test_scalar = '12345'

    # construct a node
    test_node = yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:str', value=test_scalar)

    # construct
    value = ac.construct_yaml_unsafe(test_node)

    # test that the constructed value is equal to the original scalar
    assert value == test_scalar, "The constructed value must be equal to the original scalar"

# Generated at 2022-06-23 05:28:31.254087
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    f = AnsibleConstructor()

    assert f.construct_yaml_map({'key': 'value'}) == {'key': 'value'}

    node = {'key': 'value'}
    data = [key for key in f.construct_yaml_map(node)][0]
    assert data == {'key': 'value'}
    assert data.ansible_pos[0] is None
    assert data.ansible_pos[1] == 0
    assert data.ansible_pos[2] == 0

    node = {'key': 'value', 'key2': 'value2'}
    data = [key for key in f.construct_yaml_map(node)][0]
    assert data == {'key': 'value', 'key2': 'value2'}


# Generated at 2022-06-23 05:28:35.788219
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    obj = AnsibleConstructor()
    ans_seq = obj.construct_yaml_seq(MappingNode(u'tag:yaml.org,2002:map', [], True))
    assert isinstance(next(ans_seq), AnsibleSequence)

# Generated at 2022-06-23 05:28:47.161312
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    yaml_str = """
- one_thing
- another_thing
- a_third_thing
"""
    seq = None
    try:
        seq = AnsibleLoader(yaml_str).get_single_data()
    except:
        pass
    assert isinstance(seq, AnsibleSequence)
    assert seq == ['one_thing','another_thing','a_third_thing'], "Expected ['one_thing','another_thing','a_third_thing']; instead got " + str(seq)


# Generated at 2022-06-23 05:28:56.408457
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    # pylint: disable=protected-access
    vault = VaultLib(secrets=[b'1234'])
    vault_constructor = AnsibleConstructor(vault_secrets=[b'1234'])
    data = vault.encrypt('secret')
    vault_encoded_data = vault._vault_encode(data)
    vault_encoded_data = to_bytes(vault_encoded_data)
    value_node = vault_constructor.construct_yaml_str(vault_encoded_data)
    if sys.version_info >= (3,):
        vault_encoded_data = to_bytes(vault_encoded_data, errors='surrogate_or_strict')
    vault_encoded_data = to_bytes(vault_encoded_data)


# Generated at 2022-06-23 05:29:06.348359
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-23 05:29:18.043825
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os

    vault_id = 'default'
    vault_pass = 'secret'

    # create vault
    vault = AnsibleConstructor._vaults[vault_id]

    # create ciphertext
    plaintext = 'secret message'
    ciphertext = vault.encrypt(plaintext.encode('utf-8'))
    ciphertext = ciphertext.decode('utf-8')

    # create nodes
    key_node = 'test'
    value_node = '!vault |\n          ' + ciphertext

    # create mapping
    dictionary = {'test': '!vault |\n          ' + ciphertext}

    # create constructor
    constructor = AnsibleConstructor()
    with constructor as c:
        # set vault
        c._vaults[vault_id] = vault

        # run test
       

# Generated at 2022-06-23 05:29:21.955090
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ac = AnsibleConstructor()
    import yaml
    node = yaml.nodes.SequenceNode("tag:yaml.org,2002:seq", [], None, None, None)
    data = ac.construct_yaml_seq(node)
    assert type(data) == AnsibleSequence
    next(data)

# Generated at 2022-06-23 05:29:32.041756
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import nodes
    node = nodes.Node('', '', start_mark='', end_mark='', flow_style=True)
    node.value = [[nodes.Node('', '', start_mark='', end_mark='', flow_style=True),
                   nodes.Node('', '', start_mark='', end_mark='', flow_style=True)]]
    node.start_mark = nodes.Mark('', 0, 1, 1, None, None)
    node.end_mark = nodes.Mark('', 1, 2, 2, None, None)
    cons = AnsibleConstructor()
    data = list(cons.construct_yaml_seq(node))
    assert data == [1, 2], data



# Generated at 2022-06-23 05:29:41.846643
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import copy
    import sys
    import pprint
    import yaml

    yaml_str = '''
        key1:
            key2:
                - one
                - two
                - three
            key3:
                key4: I am a value
        key5:
            - one
            - two
            - three
    '''

    print('Python %s.%s.%s' % sys.version_info[:3])
    print('PyYAML %s' % yaml.__version__)

    print('\n---- From text ----')

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    pprint.pprint(data)

    assert data['key1']['key3']['key4'] == 'I am a value'


# Generated at 2022-06-23 05:29:47.896861
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.dumper import AnsibleDumper

    text_seq = '''
    - key0: value0
    - key1: value1
    '''
    # construct yaml object and dump it
    yaml_obj = yaml.load(text_seq, Loader=AnsibleLoader)
    text_seq_out = yaml.dump(yaml_obj, Dumper=AnsibleDumper)
    assert text_seq_out == text_seq

    text_dict = '''
    { key0: value0, key1: value1 }
    '''
    yaml_obj = yaml.load(text_dict, Loader=AnsibleLoader)

# Generated at 2022-06-23 05:30:00.996261
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import os
    import yaml

    yaml_data = """
- hosts:
  - localhost
  vars:
    - var_1: 7
    - var_2: 7
    - var_3: 7
    - var_4: 7
    - var_5: 7
    - var_6: 7
"""
    data_dict = dict(yaml.load(yaml_data, Loader=AnsibleConstructor))

    assert 'hosts' in data_dict, "There is no 'hosts' in data_dict"
    assert data_dict['hosts'][0] == 'localhost', "There is no 'localhost' in 'hosts'"
    assert 'vars' in data_dict, "There is no 'vars' in data_dict"

# Generated at 2022-06-23 05:30:09.397423
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml_text = "---\n!unsafe 'foo'\n"
    yaml_obj = yaml.load(yaml_text, AnsibleConstructor)
    assert yaml_obj == 'foo'
    assert isinstance(yaml_obj, UNSAFE_PYTYPE)

    yaml_text = "---\n!unsafe\n- 1\n- 2\n- 3\n"
    yaml_obj = yaml.load(yaml_text, AnsibleConstructor)
    assert yaml_obj == [1, 2, 3]
    assert isinstance(yaml_obj, UNSAFE_PYTYPE)


# Generated at 2022-06-23 05:30:18.527212
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault = VaultLib(secrets=['test_secret'])
    vault_text = "$ANSIBLE_VAULT;1.1;AES256\n396261356530383134623331656435376361623637336661623137303265663364633766623034\n3835346530363565383565393834353065653263373861633166\n"
    vault_text_unicode = vault_text.decode('utf-8')
    node = vault_text_unicode
    a = AnsibleConstructor(vault_secrets=['test_secret'])
    result = a.construct_vault_encrypted_unicode(node)
    b_expected_result = "test_data\n"
    assert result == b_expected_result

# Generated at 2022-06-23 05:30:24.777731
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    yaml_src = '''
- a: b
  c: d
- e: f
  g: h
'''
    yaml_obj = yaml.load(yaml_src, Loader=AnsibleConstructor)
    assert yaml_obj == [{'a': 'b', 'c': 'd'}, {'e': 'f', 'g': 'h'}]
    assert isinstance(yaml_obj[0]['a'], AnsibleUnicode)
    assert isinstance(yaml_obj, AnsibleSequence)

# Generated at 2022-06-23 05:30:34.871014
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import tempfile
    import shutil

    from yaml.error import Mark
    from yaml.parser import Parser
    from yaml.scanner import Scanner

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    secrets = ['dummy']
    vault_password_file = 'dummy'

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 05:30:45.902771
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Position Info for YAML nodes are stored in a tuple containing the following items:
    #  1. the full path to the file from which the data was read, if the data was read from a file
    #  2. the line number where the previous token has ended (plus empty lines)
    #  3. the column number where the previous token has ended (plus empty lines)
    #  4. the line number in the input stream where the current token begins
    #  5. the column number in the input stream where the current token begins
    #  6. the index of the first character in the input stream where the current token begins
    #  7. the index of the first character in the input stream following the current token

    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-23 05:30:54.280041
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml

    # create instance of an AnsibleConstructor
    constructor = AnsibleConstructor()

    # test custom constructors for map and str
    map_yaml = yaml.load(u'{"key": "value"}', Loader=yaml.SafeLoader)
    assert(isinstance(map_yaml, dict))
    map_ansible = yaml.load(u'{"key": "value"}', Loader=constructor)
    assert(isinstance(map_ansible, AnsibleMapping))
    assert(isinstance(map_ansible['key'], AnsibleUnicode))

    # test custom constructors for seq
    seq_yaml = yaml.load(u'["value1", "value2"]', Loader=yaml.SafeLoader)
    assert(isinstance(seq_yaml, list))

# Generated at 2022-06-23 05:30:59.490323
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping = '''
        name: hari
        age: 26
        job: developer
        city: "banglore"
        state: "karnataka"
        country: india
        '''
    mapping_node = yaml.compose_all(mapping)
    AnsibleConstructor.construct_mapping(mapping_node)

# Generated at 2022-06-23 05:31:04.908465
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    string_node = 'test string node'
    constructor = AnsibleConstructor()
    ret = constructor.construct_yaml_str(string_node)
    assert ret.ansible_pos == (None, None, None)
    assert isinstance(ret, AnsibleUnicode)

# Generated at 2022-06-23 05:31:15.649729
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = """
        - a
        - b
        - c
    """
    obj = AnsibleConstructor(file_name='filename')

# Generated at 2022-06-23 05:31:20.072933
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    x = AnsibleConstructor(file_name='fake_filename')
    assert x.construct_yaml_unsafe(u'!unsafe true') is True

# Generated at 2022-06-23 05:31:28.409511
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_str = u"""---
- hosts: localhost
  tasks:
   - debug:
       msg: hello
    """
    AnsibleConstructor.add_constructor(u'!testme', AnsibleConstructor.construct_yaml_str)
    da = AnsibleLoader(yaml_str).get_single_data()

    assert da[0]['hosts'] == 'localhost'

    assert da[0]['tasks'][0]['debug']['msg'] == 'hello'

# Generated at 2022-06-23 05:31:38.516609
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_key_1 = 'test key 1'
    test_key_2 = 'test key 2'
    test_dict_1 = dict({test_key_1:test_key_2})
    test_dict_2 = dict({test_key_1:test_key_1})
    test_dict_3 = dict({test_key_2:test_key_1})
    test_mapping_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    test_mapping_node.value.append((test_key_1, test_dict_1))
    test_mapping_node.value.append((test_key_2, test_dict_2))
    test_mapping_node.value.append((test_key_1, test_dict_3))
   