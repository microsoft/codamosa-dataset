

# Generated at 2022-06-23 05:21:44.989121
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import json

    # Setup
    node_info = """
    os_version: 7.4
    file_path: /etc/hosts
    host_group: this_host_group
    ip_address: 10.1.1.30
    """

    node = {'anchor': None, 'tag': u'tag:yaml.org,2002:map', 'value': [], 'flow_style': False}

    def construct_object(self, node):
        return node.value

    safe_constructor = AnsibleConstructor()
    safe_constructor.construct_object = construct_object

    # Exercise
    ret = safe_constructor.construct_mapping(node)

    # Verify
    assert isinstance(ret, dict) is True
    assert ret == node

    # Cleanup
    # N/A



# Generated at 2022-06-23 05:21:54.772814
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    import yaml

    basic_mapping = '''
    test:
        name: one
        value: two
    '''

    duplicate_mapping_error = '''
    test:
        name: one
        value: two
        value: three
    '''

    duplicate_mapping_warn = '''
    test:
        name: one
        value: two
        value: three
        value: four
    '''

    duplicate_mapping_ignore = '''
    test:
        name: one
        value: two
        value: three
        value: four
        value: five
    '''

    data = yaml.load(basic_mapping, Loader=AnsibleConstructor)
    assert data['test']['name'] == 'one'

# Generated at 2022-06-23 05:22:03.413006
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    data = '''
    foo: bar
    baz: 1
    '''
    data = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)

    if sys.version_info.major < 3:
        assert isinstance(list(data.keys())[0], unicode)
        assert isinstance(list(data.values())[0], unicode)
    else:
        assert isinstance(list(data.keys())[0], str)
        assert isinstance(list(data.values())[0], str)


# Generated at 2022-06-23 05:22:13.646406
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    print('#' * 80)
    print('Unit test of AnsibleConstructor')
    print('#' * 80)
    yaml_str = '''
# Employee record
-  name: Alex Smith
   job:   Developer
   skill: Elite
-  name: Mary Johnson
   job:   Developer
   skill: Novice'''
    print('The yaml string is:\n{}\n'.format(yaml_str))
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleLoader)
    print('The yaml object is:\n{}'.format(yaml_obj))

# Generated at 2022-06-23 05:22:22.088946
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.vault import VaultLib
    vault_secrets = ['secret1', 'secret2']
    vault = VaultLib(secrets=vault_secrets)
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

    value = ['foo', 'bar', 'baz']
    node = '[foo, bar, baz]\n'
    node_obj = vault._get_yaml_loader()(node).get_single_node()

    ret = constructor.construct_yaml_seq(node_obj)
    value_obj = next(ret)

    assert len(value) == len(value_obj)
    assert value == value_obj
    assert value_obj.ansible_pos == (None, 1, 1)



# Generated at 2022-06-23 05:22:32.830979
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    target = ['hello', 'world']
    data = dict(foo=dict(bar=target))
    data_with_unsafe = dict(foo=dict(bar=AnsibleUnsafeText(target[0])))

    # Test deserialization
    obj_without_unsafe = list(AnsibleConstructor(file_name='test').construct_yaml_seq(AnsibleDumper(data).represent_list(target)))
    obj_with_unsafe = list(AnsibleConstructor(file_name='test').construct_yaml_seq(AnsibleDumper(data_with_unsafe).represent_list(target)))


# Generated at 2022-06-23 05:22:42.874601
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    f = open('./test/units/vault.yml')
    text = f.read()
    f.close()
    vaultpassword = 'VaultSecret'
    vault = VaultLib(password=vaultpassword)
    b_ciphertext_data = vault.encrypt(to_bytes(text))
    plaintext = vault.decrypt(b_ciphertext_data)
    assert AnsibleConstructor.construct_vault_encrypted_unicode(b_ciphertext_data) == plaintext
    # test for tag
    assert AnsibleConstructor.construct_vault_encrypted_unicode(u'!vault') == u'!vault'

# Generated at 2022-06-23 05:22:47.499883
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    constructor = AnsibleConstructor()
    # The first param is not used in function
    str_node = constructor.construct_yaml_str(0)
    assert isinstance(str_node, AnsibleUnicode)
    assert not hasattr(str_node, 'ansible_pos')



# Generated at 2022-06-23 05:22:53.663755
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
    --- !unsafe
    foo: bar
    '''

    yaml_obj = AnsibleLoader(data, file_name='<string>').get_single_data()
    assert yaml_obj == {u'foo': u'bar'}

# Generated at 2022-06-23 05:23:03.332802
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    def check_function():
        import os
        import sys
        from ansible.module_utils._text import to_native
        from ansible.parsing.yaml import objects
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText

        config_file = os.path.join(os.path.dirname(__file__), 'test-constructor.yml')
        with open(config_file) as f:
            data = AnsibleLoader(f, file_name=config_file).get_single_data()
        assert isinstance(data, dict)
        assert isinstance(data['k1'], objects.AnsibleUnicode)
        assert isinstance(data['k1'], AnsibleUnsafeText)

# Generated at 2022-06-23 05:23:07.056224
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    yaml_data = AnsibleConstructor(file_name="foo.yaml").construct_yaml_unsafe(None)
    assert isinstance(yaml_data, AnsibleUnsafeText)


# Unit tests for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-23 05:23:16.497564
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Check if constructor correctly raise an Exception
    if user uses duplicate dict keys
    """
    import sys
    import StringIO
    import pytest
    import yaml
    yml = '''
    test_dict:
        foo: bar
        foo: bar2
    '''
    yaml1 = yaml.YAML()
    yaml1.default_flow_style = False
    ansible_yaml_obj = yaml1.load(yml)
    assert len(ansible_yaml_obj['test_dict']) == 1
    assert ansible_yaml_obj['test_dict']['foo'] == 'bar2'
    # Save stdout
    out = sys.stdout
    # Redirect stdout
    sys.stdout = StringIO.StringIO()

# Generated at 2022-06-23 05:23:26.971501
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import AnsibleLoader

    ciphertext = '''\
$ANSIBLE_VAULT;1.1;AES256
66426132336565336566306333356231653662353638393332373534656237636331656237340a6133356165316464
32323336613239343039373630313730643833356536373465363365663264663733656636620a3137386534356130
3633393035363462336530616430356434333161663135663939346530353063356530653638
'''
    vault_pass = 'ansible'

    loader = AnsibleLoader(ciphertext, None, vault_secrets=[vault_pass])


# Generated at 2022-06-23 05:23:32.185969
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    class Test(object):
        def __init__(self, **kwargs):
            self.mapping = dict(**kwargs)

    yaml_doc = '{a: 1, b: 2, c: 3}'
    data = AnsibleLoader(yaml_doc).get_single_data()
    assert isinstance(data, Test)
    assert data.mapping == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-23 05:23:42.395733
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with string that should return an AnsibleUnicode object
    ansible_str = b'value'
    ansible_str_node = yaml.scalarstring.PlainScalarString(ansible_str, None, None)
    constructor = AnsibleConstructor()
    ret = constructor.construct_yaml_str(ansible_str_node)
    assert isinstance(ret, AnsibleUnicode)
    assert ret == 'value'

    # Test with string that should return an AnsibleUnicode object
    ansible_int = b'42'
    ansible_int_node = yaml.scalarstring.PlainScalarString(ansible_int, None, None)
    constructor = AnsibleConstructor()
    ret = constructor.construct_yaml_str(ansible_int_node)

# Generated at 2022-06-23 05:23:52.909211
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Test for construct_yaml_str
    source = '''
---
- yaml_str:
  - this_is_a_str
  - !!str 123
    '''
    yaml_obj1 = AnsibleLoader(source).get_single_data()
    yaml_obj2 = AnsibleLoader(source, file_name='testfile').get_single_data()

    assert isinstance(yaml_obj1[0]['yaml_str'][0], AnsibleUnicode)
    assert isinstance(yaml_obj1[0]['yaml_str'][1], AnsibleUnicode)


# Generated at 2022-06-23 05:23:59.935316
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import sys
    import os

    # This is an AnsibleUnsafeText object representing the string '$PATH'
    result = AnsibleConstructor.construct_yaml_unsafe(None, None, None)
    assert(isinstance(result[0], AnsibleUnsafeText))

    if sys.version_info < (2, 7):
        assert(str(result[0]) == '$PATH')
    else:
        assert(str(result[0]) == os.environ.get('PATH'))

# Generated at 2022-06-23 05:24:11.769840
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import _fixture
    import yaml

    # Empty string
    unsafe_node = yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:str', value='')
    c = AnsibleConstructor()
    assert c.construct_yaml_unsafe(unsafe_node) == u''

    # Strings
    unsafe_node = yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:str', value='simple string')
    c = AnsibleConstructor()
    assert c.construct_yaml_unsafe(unsafe_node) == u'simple string'

    unsafe_node = yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:str', value='\xe6\xb5\xb7')

# Generated at 2022-06-23 05:24:18.982703
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Test for function construct_yaml_seq of module AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_data = '''
[
  1,
  2,
  3,
  "hello",
  "world"
]
    '''

    ansible_loader = AnsibleLoader(yaml_data, file_name='fake.yml')
    data = ansible_loader.get_single_data()

    # Additional verification that the data loaded correctly
    assert isinstance(data, list)
    assert data == [1, 2, 3, "hello", "world"]

    # Test the output of dumpers (since we override the str dumper)

# Generated at 2022-06-23 05:24:22.884439
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    data = yaml.load(u'---\n- good\n- bad', Loader=AnsibleConstructor)
    assert type(data) == AnsibleSequence
    assert data[0] == u'good'
    assert data[1] == u'bad'



# Generated at 2022-06-23 05:24:32.668880
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import nodes
    from yaml.parser import Parser
    from io import StringIO
    from ansible.parsing.yaml import DataLoader
    r = StringIO("[1, 2, 3]")
    data = DataLoader().get_data(r)
    p = Parser(data)
    p.parser.parser.syntax_table.quoted_strings = False
    event = next(p.parser.parser._lex_analyze_flow_node())
    assert(isinstance(event, nodes.SequenceStartToken))
    seq = AnsibleConstructor.construct_yaml_seq(AnsibleConstructor, event)
    assert(isinstance(seq, AnsibleSequence))
    assert(len(seq) == 3)
    assert(seq[0] is 1)

# Generated at 2022-06-23 05:24:42.044164
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.doc_fragments.ansible_defaults import DEFAULT_HASH_BEHAVIOUR
    import sys

    # test non-duplicate keys
    duplicate_key_test_data = [u'foo: bar\n',
                               u'foo: bar\nfoo: bar\n',
                               u'foo: bar\nfoo: bar\n\n',
                               u'foo: bar\nfoo: {bar: baz}\n']

    for data in duplicate_key_test_data:
        test_loader = AnsibleLoader(data, file_name='non-duplicate-key-test.yml', vault_secrets=['secret'])

# Generated at 2022-06-23 05:24:49.643399
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    source = """
- hosts: test
  gather_facts: yes
  tasks:
   - command: echo
     register: out
   - shell: echo
     register: out
    """
    import io
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    stream = io.StringIO(source)
    loader = AnsibleLoader(stream, file_name='<string>')
    data = loader.get_single_data()
    dumper = AnsibleDumper()
    output = dumper.dump(data, Dumper=AnsibleDumper)
    print(output)
    return data, output



# Generated at 2022-06-23 05:24:57.207179
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml import objects
    a = AnsibleConstructor()
    assert(isinstance(a.construct_yaml_map(None), objects.AnsibleMapping))
    assert(isinstance(a.construct_yaml_str(None), objects.AnsibleUnicode))
    assert(isinstance(a.construct_yaml_seq(None), objects.AnsibleSequence))
    assert(isinstance(a.construct_yaml_unsafe(None), objects.AnsibleUnsafeText))

# Generated at 2022-06-23 05:25:05.021983
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mdict = {}
    mdict['key1'] = True
    mdict['key2'] = 'value2'
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[('key1', 'value1'), ('key2', True)], flow_style=True)
    ac = AnsibleConstructor()
    assert ac.construct_mapping(node) == mdict
    assert ac.construct_mapping(node) != {}
    assert ac.construct_mapping(node) != [('key1', 'value1'), ('key2', True)]
    assert ac.construct_mapping(node) != 'value1'
    assert ac.construct_mapping(node) != 'value'
    assert ac.construct_mapping(node) != 'true'
    assert ac.construct_mapping(node)

# Generated at 2022-06-23 05:25:09.528898
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_as_string = '''
---
- a: 1
  b: 2
'''
    a_constructor = AnsibleConstructor()
    data = yaml.load(yaml_as_string, Loader=a_constructor)
    assert data[0]['a'] == 1
    assert data[0]['b'] == 2

# Generated at 2022-06-23 05:25:18.871568
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault_secret = '$ANSIBLE_VAULT;1.1;AES256\n353135313933653662353266643061323333656135643034666433386664303737643431333931323632623\n6613333834666335366635333562636263366265383335333131663339336238646265373033323733623000\n\n'
    # Encode as UTF-8 since PyYaml is smart enough to decode things itself, but
    # not smart enough to know that the string is already UTF

# Generated at 2022-06-23 05:25:30.869855
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # ensure we construct a ciphertext without a vault key
    ac = AnsibleConstructor()
    data = u'!vault-encrypted |\n          $ANSIBLE_VAULT;1.1;AES256\n          636162393532343733363463623135373366623231356532613665383135383766333262333831636\n          0a613264643533646663663665326635383430656664643732646430346133343536376334333065\n          3038\n'
    ret = ac.construct_yaml_str(data)
    assert(isinstance(ret, AnsibleVaultEncryptedUnicode))
    ret = ac.construct_vault_encrypted_unicode(data)

# Generated at 2022-06-23 05:25:42.989922
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = """
a: 1
b:
  c: 3
    """

    # Create an AnsibleConstructor
    # There is no proper way to test the __init__ method of AnsibleConstructor
    # because it is not possible to call it separately, outside the class
    # So, the best way is to create a normal yaml.BaseLoader first, and then
    # to use our AnsibleConstructor instead of SafeConstructor inside
    # the method get_single_data()
    loader = yaml.BaseLoader(data, AnsibleConstructor)
    try:
        data = loader.get_single_data()
    except AttributeError:
        data = loader.get_data()

    # Check if the data is an AnsibleMapping
    # as it

# Generated at 2022-06-23 05:25:44.260422
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass


# Generated at 2022-06-23 05:25:51.134338
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(secrets=['vault_secret'])
    a = AnsibleConstructor()
    a._vaults['default'] = vault
    print(a)
    print(a.construct_vault_encrypted_unicode(None))

# Testing for AnsibleConstructor.construct_vault_encrypted_unicode

# Generated at 2022-06-23 05:26:02.688949
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    from ansible.module_utils.six import PY3

    # yaml gives us a dict
    # we want an AnsibleMapping instead
    # assert that is what we get

    # for py2, the dict will be a Python dict
    # for py3, the dict will be an OrderedDict

    if PY3:
        from collections import OrderedDict
        dict_cls = OrderedDict
    else:
        dict_cls = dict

    pc = AnsibleConstructor()
    node = pc.construct_yaml_map(MappingNode(None, None, True)) # start_mark,end_mark,flow_style
    o = node.__next__()
    assert isinstance(o, AnsibleMapping)

    # even though yaml provides us a dict, we want an Ans

# Generated at 2022-06-23 05:26:09.035472
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml = u'["#", " #", "# "]'
    seq = AnsibleConstructor().construct_yaml_seq(yaml)
    assert seq[0] == seq[1] == seq[2]
    assert seq[0] == u'#'
    assert seq[1] == u' #'
    assert seq[2] == u'# '
    assert isinstance(seq[0], AnsibleUnicode)


# Generated at 2022-06-23 05:26:18.462581
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = "vault_password"

    filename = "/tmp/test_AnsibleConstructor_construct_yaml_unsafe.yaml"
    with open(filename, 'w') as f:
        data = {'var1': 'test1', 'var2': 'test2', 'var3': 'test3'}
        yaml.dump(data, f)

    with open(filename, 'r') as f:
        assert f.read() == "{var1: test1, var2: test2, var3: test3}\n"

    vault = VaultLib([vault_password])

    plaintext_file = "/tmp/test_AnsibleConstructor_construct_yaml_unsafe_plain.yaml"

# Generated at 2022-06-23 05:26:25.196504
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Note that this example is a simplified version of what was originally in
    # the ticket (https://github.com/ansible/ansible/issues/5659)
    source = u'''
    foo: bar
    foo: baz
    '''
    data = AnsibleConstructor().construct_yaml_map(AnsibleConstructor.construct_yaml_map(source))
    assert data.get('foo') == 'baz', 'Expected value of foo should be "baz" but it\'s "%s"' % data.get('foo')

# Generated at 2022-06-23 05:26:31.470321
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create a test yaml node
    class MapNode:
        tag = u'tag:yaml.org,2002:map'
        id = u'tag:yaml.org,2002:map'
        start_mark = None

    # Create an Ansible Constructor
    test_constructor = AnsibleConstructor()
    # Call the super constructor
    test_constructor.construct_yaml_map(MapNode)



# Generated at 2022-06-23 05:26:39.409013
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Creating a yaml node
    data = {}
    data['kind'] = "list"
    data['value'] = []
    data['value'].append({'kind': 'scalar', 'value': "to append"})

    # Creating the fake node
    class Fake_yaml_node(object):
        pass

    fake_node = Fake_yaml_node()
    fake_node.id = "seq"
    fake_node.value = data

    # Defining the test for the method
    assert AnsibleConstructor.construct_yaml_unsafe(fake_node) == [u"to append"]



# Generated at 2022-06-23 05:26:51.218170
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Input data for tests
    import json
    import yaml
    input_data = {
        'image': None,
        'alienvault': {u'image': {u'name': u'alienvault/tao-server:1.0', u'registry': u'registry.alienvault.cloud:5001'}},
        'kong': {u'image': u'kong:0.10.1'},
    }
    # Build the yaml file to be tested
    yaml_file = yaml.dump(input_data)

    # Test the method we are testing: construct_yaml_unsafe
    yaml_data = yaml.load(yaml_file, Loader=AnsibleConstructor)

    # Assert the result

# Generated at 2022-06-23 05:26:55.276091
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=True)
    data = AnsibleConstructor().construct_yaml_map(node)
    assert isinstance(data, AnsibleMapping)



# Generated at 2022-06-23 05:27:04.592197
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    yaml.add_multi_constructor(u'tag:yaml.org,2002:seq', AnsibleConstructor.construct_yaml_seq)

    class Foo(AnsibleBaseYAMLObject):
        yaml_tag = u'tag:yaml.org,2002:foo'
        def __init__(self, bar):
            self.bar = bar

    def foo_constructor(loader, node):
        value = loader.construct_yaml_seq(node)
        return Foo(value)

    yaml.add_constructor(u'tag:yaml.org,2002:foo', foo_constructor)


# Generated at 2022-06-23 05:27:16.156177
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

# Generated at 2022-06-23 05:27:25.658144
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    import ansible.parsing.dataloader as DataLoader

    data = {'var': '{{ value }}', 'val': '{% code %}'}
    d = DataLoader()
    yaml_data = d.load_from_file(filename=None, data=data)[0]

    unsafe = yaml_data.get('var')
    assert unsafe is not None
    assert unsafe.raw == data.get('var')
    assert unsafe.value == data.get('var')
    assert unsafe.safe == False

    unsafe = yaml_data.get('val')
    assert unsafe is not None
    assert unsafe.raw == data.get('val')
    assert unsafe.value == data.get('val')
    assert unsafe.safe == False

# Generated at 2022-06-23 05:27:35.978903
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class TestClass:
        def __eq__(self, other):
            return True

        def __hash__(self):
            return hash('foo')

    for value in [TestClass(), "duplicate"]:
        constructor = AnsibleConstructor()
        constructor.warnings = []

# Generated at 2022-06-23 05:27:39.834219
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # setup
    input_record = ["- c", "- d"]
    expected_record = AnsibleSequence(["c", "d"])

    # test
    actual_record = AnsibleConstructor.construct_yaml_seq(input_record)

    # verify
    assert actual_record == expected_record


# Generated at 2022-06-23 05:27:48.090360
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # _AnsibleConstructor_construct_mapping() is private method
    # so, we need to get it using magic
    import types
    import inspect
    import pytest

    with pytest.raises(TypeError):
        AnsibleConstructor.construct_mapping('node', deep=False)

    import yaml
    m = yaml.MappingNode(u'tag:yaml.org,2002:map', [], None, None)
    assert isinstance(m, yaml.MappingNode)
    assert AnsibleConstructor.construct_mapping(m, deep=False) == {}

    m = yaml.MappingNode(u'tag:yaml.org,2002:dict', [], None, None)
    assert isinstance(m, yaml.MappingNode)
    assert AnsibleConstructor.construct_m

# Generated at 2022-06-23 05:27:54.969415
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    constructor = AnsibleConstructor(file_name='ansible-yaml')
    node = MappingNode(tag=u'tag:yaml.org,2002:seq',
                       value=[('one', '1'), ('two', '2'), ('three', '3')],
                       start_mark=None, end_mark=None, style=None)

    data = constructor.construct_yaml_seq(node)
    assert data[0].ansible_pos == ('ansible-yaml', 1, 1)



# Generated at 2022-06-23 05:28:00.226199
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    assert isinstance(yaml.load("""'foo'""", AnsibleConstructor), AnsibleUnicode)
    assert isinstance(yaml.load("""'foo'""", AnsibleConstructor), AnsibleUnicode)
    assert isinstance(yaml.load("""'foo'""", AnsibleConstructor), AnsibleUnicode)

# Generated at 2022-06-23 05:28:05.290964
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import codecs

    s = codecs.getreader('utf-16')(codecs.getwriter('utf-8')(open(__file__, 'r')))
    res = list(AnsibleConstructor(file_name=__file__).get_single_data(s))[0]
    assert res.ansible_pos == (__file__, 1, 0)

# Generated at 2022-06-23 05:28:12.955998
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    sample = '''
    a:
      key: val
    b:
      - 1
      - 2
      - 3
    '''

    # Initialize a VaultLib
    vault_secrets = [VaultSecret('secret')]
    vault = VaultLib(secrets=vault_secrets)

    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    data = yaml.load(sample, Loader=AnsibleLoader)

    # Test AnsibleMapping
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-23 05:28:13.601385
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    return True

# Generated at 2022-06-23 05:28:23.706677
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    display.verbosity = 4
    ansible_constructor = AnsibleConstructor()

    # 3.6 - 3.6.12 do not support f-strings
    if hasattr(__builtins__, '__dict__') and 'f' in __builtins__.__dict__:
        ansible_map = {u'foo': u'bar'}
        ansible_str = ("datasource: {datasource}, line: {line}, column: {column}, "
                       "map: {map}".format(datasource=__file__, line=9, column=15,
                                           map=ansible_map))
    else:
        ansible_map = {u'foo': u'bar'}
        ans

# Generated at 2022-06-23 05:28:32.044130
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import sys
    import StringIO
    construct_yaml_map_test_input = '''
    a: 1
    b: 2
    c: 3
    '''
    construct_yaml_map_test_output = '''
    {0: {'a': 1, 'c': 3, 'b': 2}}
    '''
    construct_yaml_map_test_expected_output = '''
    {0: {'a': 1, 'b': 2, 'c': 3}}
    '''
    captured_output = StringIO.StringIO()
    sys.stdout = captured_output
    test_AnsibleConstructor = AnsibleConstructor(file_name=None, vault_secrets=None)

# Generated at 2022-06-23 05:28:39.736554
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    test_data = dict(
        dict_1 = dict(
            key_1 = 'value_1'
        ),
        dict_2 = dict(
            key_2 = 'value_2'
        )
    )

    constructor = AnsibleConstructor()
    # Returned value is AnsibleMapping instance
    result = constructor.construct_mapping(test_data)
    assert isinstance(result, AnsibleMapping)
    assert result == test_data



# Generated at 2022-06-23 05:28:50.754008
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    # Test for a yaml file with a list
    yaml_text_list = '''
# This is a comment
---
# This is a list
- foo
- bar
'''

    yaml_text_dict = '''
# This is a comment
---
# This is a dict
{
    # key 1
    a: value1,
    # key 2
    b: value2,
    "c": [ value1, value2 ],
    "d" : { "a": value1, "b": value2 }
}
'''

    yaml_text_unsafe = '''
---
!unsafe password
'''

   

# Generated at 2022-06-23 05:28:59.413241
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:29:04.476817
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    safe = """
---
foo: bar
this: that
"""
    unsafe = """
---
foo: bar
this:
  - "{{ variable }}"
"""


AnsibleConstructor.add_constructor(
    u'tag:yaml.org,2002:python/tuple',
    AnsibleConstructor.construct_yaml_seq)

# Generated at 2022-06-23 05:29:06.893102
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    text = u"""-
    foo:
      bar: 1
      baz: 2
    """
    yaml_obj = yaml.load(text, AnsibleConstructor)
    assert yaml_obj[0]['foo']['bar'] == 1

# Generated at 2022-06-23 05:29:13.776112
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_str = """
a:
  - b: test string
  - c: 3
    d: 4
    e:
      - 5
      - 6
    f:
      - g: 7
        h: 8
  - 9
"""

    # No exception is expected
    AnsibleConstructor.construct_yaml_str(yaml.compose(yaml_str))
    # Exception case
    # TODO: Fix it

# Generated at 2022-06-23 05:29:24.024830
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    test_node = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          393866386631386562343430353733323836353763633839313232316538306566653639663130\n          333835373035323033633936313838313765623265393432666661666231373163663562333961\n          386364396463376330356366306639396435326432663438613662393561316665623261393936\n          336665353561376531613639653261\n          "

    test_node_decrypted = "foobar"


# Generated at 2022-06-23 05:29:34.314517
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    my_constructor = AnsibleConstructor()
    import yaml
    from collections import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleMutableSequence

    # Test loading of basic custom nodes
    data = yaml.load("""
a: 1
b:
  c: true
  d: !unsafe 'unsafe'
  e: 3
""", my_constructor)

    assert isinstance(data, OrderedDict)
    assert len(data) == 2
    assert isinstance(data[u'a'], int)
    assert data[u'a'] == 1
    assert isinstance(data[u'b'], AnsibleMutableSequence)
    assert len(data[u'b']) == 3

# Generated at 2022-06-23 05:29:38.543097
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    node = 'abc'
    ret = ac.construct_yaml_str(node)
    assert isinstance(ret, AnsibleUnicode)
    assert ret == 'abc'
    assert ret.__class__.__name__ == 'AnsibleUnicode'

# Generated at 2022-06-23 05:29:47.349734
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class FakeVault:
        def __call__(self, ciphertext_data, *args, **kwargs):
            assert(ciphertext_data == b_ciphertext_data)
            return u'plaintext data'

    vault = FakeVault()
    ac = AnsibleConstructor(vault_secrets=[vault])

# Generated at 2022-06-23 05:30:00.481503
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    """
    tested method: construct_vault_encrypted_unicode
    """
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = ['test']

# Generated at 2022-06-23 05:30:10.222944
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader
    import six
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultEditor

    src = '''
name: foobar
languages:
  - python
  - ruby
'''

    test_value = VaultLib()
    test_value.secrets = ['test_pass']
    if C.DEFAULT_VAULT_ID_MATCH == '^Vault':
        # This is the default, so we can leave this if statement out,
        # it really only tests the other branches of the if statement
        pass
    else:
        vault_re = VaultEditor

# Generated at 2022-06-23 05:30:14.877455
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml

    yaml_str = '''
        - a: 1
          b: 2
        - c: 3
          d: 4
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data, list)
    for idx in data:
        assert isinstance(idx, AnsibleMapping)

# Generated at 2022-06-23 05:30:23.568972
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml import dump
    from yaml import load
    from tempfile import NamedTemporaryFile

    test_array = [{'foo': 'foo_value'}, {'bar': 'bar_value'}]
    yaml_str = dump(test_array)
    try:
        with NamedTemporaryFile() as tf:
            tf.write(to_bytes(yaml_str))
            tf.seek(0)
            obj = load(tf, Loader=AnsibleLoader)
            assert isinstance(obj, list)
            assert len(obj) == len(test_array)
            obj_keys = set(obj[0].keys())
            arr_keys = set(test_array[0].keys())
            assert obj_keys == arr_keys
    finally:
        tf.close()

# Generated at 2022-06-23 05:30:34.577672
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    yaml_src = u'''\
        - foo: {1: one, 2: two}
        - bar: [1, 2]
        - baz: text
        - foo: {3: three}
        - foo: {4: four}
        - bar: [3, 4]
        - baz: text
    '''
    yaml_data = AnsibleLoader(yaml_src, file_name='<test_data>').get_single_data()

    assert isinstance(yaml_data, AnsibleSequence)
    assert len(yaml_data) == 7
    assert 'ansible_pos' in yaml_data



# Generated at 2022-06-23 05:30:45.698340
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    test_mapping = {'foo': {'bar': 'test_test'}}
    test_mapping_result = AnsibleConstructor.construct_yaml_unsafe(test_mapping)
    assert test_mapping_result == test_mapping

    test_list = ['test_test', {'test_test': 'test_test2'}]
    test_list_result = AnsibleConstructor.construct_yaml_unsafe(test_list)
    assert test_list_result == test_list

    test_str = 'test_test'
    test_str_result = AnsibleConstructor.construct_yaml_unsafe(test_str)
    assert test_str_result == test_str

    test_int = 1

# Generated at 2022-06-23 05:30:48.805326
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = "hello world"
    check = AnsibleUnicode(data)
    result = AnsibleLoader(data).get_single_data()
    assert result == check

# Generated at 2022-06-23 05:30:59.479982
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import from_yaml
    from ansible.module_utils.six import PY3

    if PY3:
        import sys
        import _frozen_importlib
        _frozen_importlib.ModuleSpec.__setattr__ = lambda self, name, value: setattr(self, name, value)
        sys.modules["_frozen_importlib"] = _frozen_importlib
        sys.modules["_frozen_importlib_external"] = _frozen_importlib


# Generated at 2022-06-23 05:31:06.389873
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # given
    yaml_str = '''
        a: 1
        b: 2
    '''
    ac = AnsibleConstructor()

    # when
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)

    # then
    assert isinstance(yaml_obj, AnsibleMapping)


# Generated at 2022-06-23 05:31:13.783330
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    loader = AnsibleConstructor()

    yaml_data = """
    #!/usr/bin/env python
    print(1+1)
    """
    from yaml.composer import Composer
    from yaml.scanner import Scanner

    for token in Scanner(yaml_data):
        data = Composer.compose_document(Scanner(yaml_data), loader, None)
    print(loader.construct_yaml_unsafe(data))

# unit test for method construct_yaml_str of class AnsibleConstructor

# Generated at 2022-06-23 05:31:16.896549
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    yaml.add_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)
    assert isinstance(yaml.load(u'!unsafe 42'), AnsibleUnsafeText)

# vim: set et ts=4 sw=4:

# Generated at 2022-06-23 05:31:24.783005
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Generate data for test, dict with duplicate values
    data = dict()
    data['foo'] = 'bar'
    data['foo'] = 'baz'
    data['fuzz'] = 'buzz'

    # Generate input data for test, AnsibleMapping with duplicate values
    mapping = AnsibleMapping()
    mapping.update(data)

    # Generate expected result, dict without duplicate values
    expected = dict()
    expected['foo'] = 'baz'
    expected['fuzz'] = 'buzz'

    # Generate result
    result = AnsibleConstructor.construct_yaml_map(mapping)

    # Check result
    assert expected == result


# Generated at 2022-06-23 05:31:36.478488
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ''' test_AnsibleConstructor_construct_yaml_str '''
    class Node():
        ''' dummy class Node '''
        def __init__(self, start_mark, end_mark):
            ''' dummy constructor '''
            self.start_mark = start_mark
            self.end_mark = end_mark
        def __getattr__(self, attr):
            return getattr(self, attr)

    node = Node(1, 1)
    # pylint: disable=protected-access
    aconstructor = AnsibleConstructor()
    aconstructor.construct_scalar = lambda a: 'constructor_str'
    aconstructor._node_position_info = lambda a: (1, 1, 1)