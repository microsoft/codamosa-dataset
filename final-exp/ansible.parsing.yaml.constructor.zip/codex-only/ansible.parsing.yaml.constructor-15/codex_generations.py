

# Generated at 2022-06-23 05:21:45.393406
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Create test case
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode

    src = u'test'
    data = AnsibleLoader(src).get_single_data()
    assert isinstance(data, AnsibleUnicode)
    assert data == src

    src = u'\u0000'
    data = AnsibleLoader(src).get_single_data()
    assert isinstance(data, AnsibleUnicode)
    assert data == src

    src = u'\r\n'
    data = AnsibleLoader(src).get_single_data()
    assert isinstance(data, AnsibleUnicode)
    assert data == src


# Generated at 2022-06-23 05:21:53.222278
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Test that the correct order is maintained when passing
    a mapping to construct_mapping
    """
    from yaml.nodes import MappingNode, ScalarNode, SequenceNode, MappingNode
    from yaml.parser import Parser
    from yaml.constructor import SafeConstructor
    import ansible.parsing.yaml

    # Prepare a yaml node to be passed to the functio
    mapping = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    # Create a parser
    stream = ansible.parsing.yaml.string_to_stream(str(mapping))
    parser = Parser(stream)

    # Parse the YAML document into a node tree
    node_tree = parser.get_single_node()
    collection

# Generated at 2022-06-23 05:22:00.404328
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode
    from ansible.parsing.yaml.objects import AnsibleMapping

    def test_construct_mapping():
        data = AnsibleMapping()
        yield data

    def construct_mapping(node, deep=False):
        return data

    constructor = AnsibleConstructor()
    constructor.construct_mapping = construct_mapping
    constructor.construct_yaml_map(MappingNode(None, None))



# Generated at 2022-06-23 05:22:11.439241
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    a_constructor = AnsibleConstructor()
    a_tag_map = {
        u'!unsafe/python/dict': a_constructor.construct_yaml_unsafe,
        u'!unsafe/python/unicode': a_constructor.construct_yaml_unsafe,
        u'!unsafe/python/str': a_constructor.construct_yaml_unsafe,
        u'!unsafe/python/int': a_constructor.construct_yaml_unsafe,
        u'!unsafe/python/long': a_constructor.construct_yaml_unsafe,
        u'!unsafe/python/bool': a_constructor.construct_yaml_unsafe,
        u'!unsafe/python/float': a_constructor.construct_yaml_unsafe
    }



# Generated at 2022-06-23 05:22:16.247240
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    a = {'a': 1, 'b': [2, 3], 'c': 4}
    assert a == yaml.load(yaml.dump(a, Dumper=AnsibleDumper), Loader=AnsibleConstructor)

# Generated at 2022-06-23 05:22:28.072514
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    def my_class_constructor(node):
        return node.value

    import ansible.parsing.yaml.loader
    import yaml
    test_yaml = b'''
- !unsafe "AnsibleUnicode"
- !unsafe "AnsibleUnicode"
- !unsafe "AnsibleUnicode"
'''

    # Create a constructor with a custom class constructor
    ac = AnsibleConstructor(my_class_constructor)
    # Create a loader with a custom constructor
    al = ansible.parsing.yaml.loader.AnsibleLoader(ac)
    data = al.get_single_data(test_yaml)

    print(data)


if __name__ == '__main__':
    test_AnsibleConstructor_construct_yaml_uns

# Generated at 2022-06-23 05:22:37.093474
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    node = {"start_mark": {"column": 5, "name": "test_file", "line": 1}, "end_mark": {"column": 6, "name": "test_file", "line": 1}}
    node['tag'] = u'tag:yaml.org,2002:str'
    asc = AnsibleConstructor(file_name="test_file")
    ret = asc.construct_yaml_str(node)

    assert isinstance(ret, AnsibleUnicode)
    assert ret.ansible_pos == ("test_file", 1, 5)



# Generated at 2022-06-23 05:22:47.115076
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    from ansible.parsing.vault import VaultEditor

    # The tag !vault-encrypted is being used in the fixture file and that
    # requires the following vault string to decrypt the encrypted variable.
    vault_string = '$ANSIBLE_VAULT;1.2;AES256;test3897364975'
    vault_string += '\n6365663837306534303366373334613235653164646362356313039366365306566363533326336'
    vault_string += '\n30633462393833386531376234326265326566303466333534623137303537626462313761316230'

# Generated at 2022-06-23 05:22:57.408059
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import nodes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    # Setup and populate objects needed for constructing the node
    vm = VariableManager()
    hv = HostVars(inventory=InventoryManager(loader=DataLoader(), sources='localhost,'), hostname='localhost')
    ret = AnsibleUnicode(variable_manager=vm, hostvars=hv, attr_name='test')
    # Test one of the base cases

# Generated at 2022-06-23 05:23:10.306399
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    "Unit test for method construct_mapping of class AnsibleConstructor"
    m = AnsibleMapping()
    m['a'] = 'b'
    m['a'] = 'c'
    assert m['a'] == 'c', "Overwriting dict should be allowed"
    assert m.ansible_pos is None, "New AnsibleMapping should have ansible_pos None"
    try:
        m = AnsibleConstructor().construct_mapping(None)
    except Exception as e:
        assert type(e) == ConstructorError, "construct_mapping should raise error for non-mapping nodes"
    m = AnsibleConstructor().construct_mapping(None, True)
    assert m.ansible_pos is None, "construct_mapping should return ansible_pos None for None"

# Generated at 2022-06-23 05:23:14.673854
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # It is not possible to call a constructor using its name because the registry
    # is an attribute of the class and methods can be added to the class without
    # the registry being updated.
    #
    # To test this method, we will have to use its name as a string.
    assert True

# Generated at 2022-06-23 05:23:24.723023
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var, AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text

    ac = AnsibleConstructor()

    data = AnsibleMapping()

    # Test unsafe str and unicode
    s = AnsibleUnsafeText(u"unsafe string")
    assert wrap_var(s) == s

    # Test vault
    data['vault'] = AnsibleVaultEncryptedUnicode(to_bytes('data', errors='surrogate_then_replace'))
    data['vault'].vault = VaultLib(secrets=['secret'])
    assert data

# Generated at 2022-06-23 05:23:33.540161
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # setup
    # mock data
    vault_password_file = 'password_file.txt'
    password = b'vault_password'
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n6338626566303739333062343261346236383963613161323463617563396238613434366166663138\n3965303130333631346366333633636632316166343262386466393335663065616466383162626261\n3534666637316638646235363063376434363236656236396633\n'

    # setup mocks
    mock_VaultLib_instance = MagicMock(name='VaultLib_instance')

# Generated at 2022-06-23 05:23:44.050023
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import StringIO
    import yaml
    import sys
    text = StringIO.StringIO("""\
!foo
""")
    loader = yaml.CLoader(text)

# Generated at 2022-06-23 05:23:51.301120
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = dict(key1='value1', key2='value2', key3='value3')
    test_node = MappingNode(u'tag:yaml.org,2002:map', [(scalar_node_for_data(k), scalar_node_for_data(v)) for k, v in data.items()])
    test_node.start_mark = None
    test_node.end_mark = None
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_mapping(test_node)



# Generated at 2022-06-23 05:23:57.514022
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = '''
key1: value1
key2: value2
key2: value2.2
key3: value3
'''
    import yaml
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert (yaml_obj == {'key1': 'value1', 'key2': 'value2.2', 'key3': 'value3'})

# Generated at 2022-06-23 05:24:08.077650
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import unittest
    from ansible.parsing.yaml.objects import AnsibleSequence

    class TestAnsibleConstructor_construct_yaml_seq(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_yaml_seq_constructor_returns_ansible_sequence(self):
            data = AnsibleSequence()
            yaml_file_name = "ansible.yml"
            yaml_node = "YAML-NODE"
            vault_secrets = []
            ansible_constructor = AnsibleConstructor(yaml_file_name, vault_secrets)
            ansible_sequence = ansible_constructor.construct_yaml_seq(yaml_node)

# Generated at 2022-06-23 05:24:16.250107
# Unit test for constructor of class AnsibleConstructor

# Generated at 2022-06-23 05:24:22.689482
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import unittest.mock as mock
    import yaml

    # given
    yaml_str = '[1, 2, 3]'

    # when
    load = yaml.load(yaml_str, Loader=AnsibleConstructor)

    # then
    assert isinstance(load, list)
    assert len(load) == 3
    assert load[0] == 1
    assert load[1] == 2
    assert load[2] == 3


# Generated at 2022-06-23 05:24:32.530092
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml

# Generated at 2022-06-23 05:24:36.359751
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    yaml_data = '''
---
foo:
- 1
- 2
value:
  with.dot: 1
  key: value
'''
    data = yaml.load(yaml_data, Loader=AnsibleConstructor)
    assert data['value']['key'] == 'value'
    assert data['value']['with.dot'] == 1
    assert data['foo'][0] == 1
    assert data['foo'][1] == 2



# Generated at 2022-06-23 05:24:46.165322
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    cc = AnsibleConstructor(object)

    node1 = object()
    assert cc.construct_yaml_unsafe(node1) == node1

    node2 = ['a', 'b', 'c']
    assert cc.construct_yaml_unsafe(node2) == node2

    node3 = {'a': 'b', 'c': 'd'}
    assert cc.construct_yaml_unsafe(node3) == node3

    node4 = u'Pipo'
    assert cc.construct_yaml_unsafe(node4) == 'Pipo'

    node5 = u'!unsafe'
    assert cc.construct_yaml_unsafe(node5) == '!unsafe'

# Generated at 2022-06-23 05:24:55.970085
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import BytesIO
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructor(unittest.TestCase):

        def _check_constructor(self, text, expected_type, expected_value, expected_post="", vault_key=None):
            yaml = YAML(typ=expected_type)
            yaml.vault_secrets = [vault_key] if vault_key else []
            dummy_stream = BytesIO(text)
            ansible_constructor = AnsibleConstructor(file_name='<testdata>')
            yaml.version = '1.1'

# Generated at 2022-06-23 05:25:03.827579
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # The constructor
    constructor = AnsibleConstructor()
    # The data

# Generated at 2022-06-23 05:25:06.347558
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Test to see if the constructor class compiles
    ansible_constructor = AnsibleConstructor()
    assert(ansible_constructor is not None)



# Generated at 2022-06-23 05:25:19.315098
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from collections import OrderedDict
    data = OrderedDict([('key', 'value'), ('Bravo', OrderedDict([('key', 'value')])),
                        ('delta', {'one': 'two', 'three': 'four'}),
                        ('epsilon', [{'one': 'two'}, {'three': 'four'}])])
    text = yaml.dump(data, Dumper=yaml.SafeDumper, default_flow_style=False, encoding='utf-8')
    text = to_bytes(text)
    yaml_data = yaml.load(text, Loader=AnsibleConstructor)
    assert yaml_data == data


# Test construct_yaml_map, construct_mapping, construct_yaml_str, construct_object

# Generated at 2022-06-23 05:25:31.289186
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import tempfile
    import yaml

    tmpf = tempfile.NamedTemporaryFile(mode='w', delete=False)
    tmpf.write("""---
- hosts: localhost
  gather_facts: false
  vars:
    count:
      - one
      - two
  tasks:
    - debug: msg="{{ item }}"
      with_items: count
""")
    tmpf.close()
    data = yaml.load(open(tmpf.name, 'r'), Loader=AnsibleConstructor)
    assert isinstance(data, list)
    assert data[0]['hosts'] == "localhost"
    assert isinstance(data[0]['vars']['count'], list)
    assert data[0]['vars']['count'][0] == "one"

# Generated at 2022-06-23 05:25:43.265016
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Tests construct_yaml_seq by using construct_object
    # Successful call of construct_object should return 
    # a list containing integers 1, 2, and 3.
    data1 = """
- 1
- 2
- 3
"""
    fakefile = StringIO.StringIO(data1)
    loader1 = AnsibleLoader(fakefile)
    data1 = loader1.get_single_data()
    assert data1 == [1,2,3]

    # Tests construct_yaml_seq by using construct_object
    # Successful call of construct_object should return 
    # a list containing an empty dictionary.

# Generated at 2022-06-23 05:25:53.491022
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Just to confirm code coverage by pytest-cov
    """
    class TestNode(object):
        def __init__(self):
            self.id = None
        def __repr__(self):
            return ''
    class TestItem(object):
        def __init__(self):
            self.start_mark = None
        def __repr__(self):
            return ''

    node = TestNode()
    item = TestItem()
    item.start_mark = item
    node.value = [item, item]
    node.start_mark = item

    retval = AnsibleConstructor('test').construct_mapping(node)
    assert isinstance(retval, dict)

# Generated at 2022-06-23 05:26:04.227410
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # construct_vault_encrypted_unicode should raise an exception when vault password is not provided
    yaml_string = "{FAKE_ENCRYPTED}"
    try:
        AnsibleConstructor().construct_vault_encrypted_unicode(MappingNode('', [], yaml_string, yaml_string, 1))
        assert False
    except ConstructorError:
        assert True

    # construct_vault_encrypted_unicode should correctly decrypt a simple secret
    yaml_string = "{7cf945c2377ee06a44b0c7d7a67c6924}"
    ansible_constructor = AnsibleConstructor(vault_secrets=["pass"])

# Generated at 2022-06-23 05:26:05.774601
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    obj = AnsibleConstructor()
    assert obj is not None

# Generated at 2022-06-23 05:26:15.399785
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.module_utils.six import StringIO
    yaml_doc = StringIO(u'{ foo: !!unsafe !!python/object/new:time.strptime [strptime, ["%Y-%m-%d %H:%M:%S", "2017-07-25 19:40:49"]] }')
    loader = AnsibleConstructor(file_name='<string>')
    data = yaml.load(yaml_doc, Loader=loader)
    assert 'foo' in data
    expected_time = time.strptime('2017-07-25 19:40:49', '%Y-%m-%d %H:%M:%S')
    assert data['foo'] == expected_time


# Generated at 2022-06-23 05:26:24.957870
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.module_utils.six import string_types
    from ansible.vars.unsafe_proxy import wrap_var
    from collections import Mapping
    from yaml.nodes import MappingNode
    yaml_str = u"""
key1: value1
key2: value2
"""
    class MockNode(object):
        def __init__(self, v):
            self.value = v
    mappings = yaml.load(yaml_str, Loader=AnsibleConstructor)

    assert isinstance(mappings, Mapping)
    assert isinstance(mappings.ansible_pos, tuple)
    assert len(mappings.ansible_pos) == 3
    assert isinstance(mappings.ansible_pos[0], string_types)

# Generated at 2022-06-23 05:26:35.244162
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import inspect
    import random

    script_dir = os.path.dirname(inspect.getfile(inspect.currentframe()))
    exp_path = os.path.join(script_dir, 'data/result-ansible-constructor.yml')
    with io.open(exp_path, encoding='utf-8') as f:
        exp_result = yaml.load(f, Loader=AnsibleConstructor)

    act_result = yaml.load(exp_result[0].to_yaml(), Loader=AnsibleConstructor)

    # The test is very simple. It is not intended to test the correctness of
    # the output of 'to_yaml()' method. It is just to check that the '!unsafe'
    # tag is correctly handled.

# Generated at 2022-06-23 05:26:41.158704
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    yaml_input = '''
        - one
        - two
        - three
        '''
    yaml_data = yaml.load(yaml_input, Loader=AnsibleConstructor)

    assert yaml_data == [u'one', u'two', u'three']
    assert isinstance(yaml_data, AnsibleSequence)



# Generated at 2022-06-23 05:26:44.228170
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Initializing a Node object before invoking the constructor
    # with a suitable tag name
    node = u'hello, world'
    ret = AnsibleConstructor.construct_yaml_str(node)

    assert ret == u'hello, world'
    # Add your own tests here



# Generated at 2022-06-23 05:26:52.626087
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from StringIO import StringIO
    node = StringIO("- one\n- two\n- three\n")
    fake_node = {'start_mark':node}
    result = AnsibleConstructor.construct_yaml_seq(AnsibleConstructor(),fake_node)

    assert type(result) == AnsibleSequence
    assert len(result) == 3
    assert result.ansible_pos == ('<string>', 1, 0)
    assert result == [u'one', u'two', u'three']

# Generated at 2022-06-23 05:26:55.060488
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    constructor = AnsibleConstructor()
    assert constructor.construct_yaml_seq == AnsibleConstructor.construct_yaml_seq

# Generated at 2022-06-23 05:27:01.873903
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    data = [
        (b"abc", AnsibleUnicode(u"abc")),
        (b"a\x00b", AnsibleUnicode(u"a\x00b")),
    ]
    l = data
    c = AnsibleConstructor()
    for i in range(0, len(data)):
        node = SafeConstructor().construct_yaml_str(l[i][1])
        ret = c.construct_yaml_str(node)
        assert ret == l[i][0]


# Generated at 2022-06-23 05:27:05.586929
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    cstr = AnsibleConstructor()
    # FIXME we need an object that has a "deep" attribute to test this
    #cstr.construct_yaml_seq(deep=True)



# Generated at 2022-06-23 05:27:12.245476
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    constructor = AnsibleConstructor()

    # given
    node = type('TagNode', (object,), {
        'id': 'object',
    })()
    try:
        # when
        value = constructor.construct_yaml_unsafe(node)

        # then
        assert value is None
    except AttributeError:
        # then
        raise AssertionError('AnsibleConstructor should have unsupported constructor \'construct_object\'')

# Generated at 2022-06-23 05:27:23.427963
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    c = AnsibleConstructor()

    # "test" is decoded to python unicode object
    test_str = c.construct_yaml_str(node=u'test')
    assert type(test_str) is AnsibleUnicode
    assert test_str ==  u'test'

    # "test" is decoded to python unicode object
    test_str = c.construct_yaml_str(node=u' test ')
    assert type(test_str) is AnsibleUnicode
    assert test_str ==  u' test '

    # "test" is decoded to python unicode object
    test_str = c.construct_yaml_str(node=u' "test" ')

# Generated at 2022-06-23 05:27:35.168399
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [ VaultLib.decrypt_vault_secret('YlY4YzYxOTg5NjVmZWM0NzRhMjgxNTRkNjBkOTZlNzRhZWQ2ZWEwMw==') ]
    ac = AnsibleConstructor(vault_secrets=vault_secrets)
    import yaml

# Generated at 2022-06-23 05:27:42.226395
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import re

    data = "hello world"
    match = re.match(r'!unsafe (.*)', data)
    result = AnsibleConstructor.construct_yaml_unsafe(match)
    assert isinstance(result, AnsibleUnsafeText)
    assert result.data == "hello world"

# Generated at 2022-06-23 05:27:53.479393
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible import constants
    import yaml

    constants.DEFAULT_VAULT_SECRET_ONLY = False
    constants.DEFAULT_VAULT_IDENTITY = None
    node = yaml.compose('''
        !vault |
          $ANSIBLE_VAULT;1.1;AES256
          63316137336162333131613263653735396362386165633866376534623733353766326462356636
          36323761396261656135383038343861306364316662323638616332303933643463633664653036
          64336131633333643562396436366665623732623164636164353563613231323564
          ''')


# Generated at 2022-06-23 05:28:04.227353
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    # we are using the safe_load(yaml) method, so the !vault string will be replaced by
    # a base64 encoded string.
    # With the following dict we are testing that the decode method works correctly
    vault_encoded = u"!vault |2 "+u"\n"
    vault_encoded += u"      $ANSIBLE_VAULT;"+u"\n"
    vault_encoded += u"      123456"
    
    # The follow dict is used to test the case when the text is not base64 encoded
    # the result should be the same as using the raw YAML string !vault
    not_encoded = u"!vault"
    
    not_encoded_result = AnsibleVaultEncryptedUnicode(u"!vault").decode()
    assert not_enc

# Generated at 2022-06-23 05:28:13.971883
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_data = """
        ---
        foo:
          - one
          - two
          - null
          - 12
        """
    data = AnsibleLoader(yaml_data, file_name='test_AnsibleConstructor').get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleSequence)
    assert len(data['foo']) == 4
    assert data['foo'][0] == u'one'
    assert data['foo'][1] == u'two'
    assert data['foo'][2] is None
    assert data['foo'][3] == 12
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-23 05:28:18.645769
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ac = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    data = ac.construct_mapping(node)
    assert isinstance(data, dict)

# Generated at 2022-06-23 05:28:29.620348
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    my_list = [
        {'key_one': 'value_one', 'key_seven': 'value_seven'},
        {'key_one': 'value_one', 'key_seven': 'value_seven', 'key_nine': 'value_nine'},
        {'key_one': 'value_one'},
        {'key_one': 'value_one', 'key_two': 'value_two', 'key_six': 'value_six'}
    ]
    my_list = AnsibleConstructor.construct_yaml_seq(my_list)

# Generated at 2022-06-23 05:28:37.780308
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import os
    import tempfile
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    (fd, path) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write((u'---\n'
                 u'#!unsafe\n'
                 u'hello: world\n'
                 u'a: "b"\n'))

    with open(path, 'r') as f:
        data = AnsibleLoader(f).get_single_data()

    assert data == wrap_var({'hello': 'world', 'a': 'b'})
    os.unlink(path)


# Generated at 2022-06-23 05:28:41.821051
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import load
    from yaml import ScannerError

    data = '''
        ansible: {
            name: demo
            system: redhat
        }
    '''
    test_yaml = load(data, Loader=AnsibleConstructor)
    assert test_yaml['ansible']['system'] == 'redhat'

# Generated at 2022-06-23 05:28:45.477812
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    def construct_yaml_unsafe(self, node):
        assert(isinstance(node, str))
        return(1)
    assert(construct_yaml_unsafe(None, 1) == 1)

# Generated at 2022-06-23 05:28:55.030777
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import copy
    import unittest
    from yaml import MappingNode, ScalarNode

    class TestMe(unittest.TestCase):

        def setUp(self):
            self.constructor = AnsibleConstructor()
            self.mark = 1
            self.mapping = MappingNode(u'tag:yaml.org,2002:map', [], None, None, None)

        def test_id_added_to_AnsibleMapping(self):
            val = AnsibleMapping()
            val['a'] = 1
            self.assertEqual(val['a'], 1)
            self.assertEqual(val.ansible_pos, (None, None, None))


# Generated at 2022-06-23 05:29:01.495269
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    yaml_str = """
      - 'item1'
      - 'item2'
    """

    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert isinstance(data[0], AnsibleUnicode), 'First element in YAML structure is not an AnsibleUnicode object.'
    assert isinstance(data[1], AnsibleUnicode), 'Second element in YAML structure is not an AnsibleUnicode object.'

# Generated at 2022-06-23 05:29:06.574594
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import from_yaml
    from io import StringIO
    src = StringIO(u"""
    - test: !unsafe 'value'
    - test: !unsafe value
    """)
    data = from_yaml(src, AnsibleConstructor, file_name='<string>')
    assert len(data) == 2
    assert data[0]['test'].is_safe_value is True
    assert data[1]['test'].is_safe_value is True

# Generated at 2022-06-23 05:29:18.189402
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class MockNode(object):
        id = "vault"
        start_mark = None

    mock_node = MockNode()
    vault_secrets = [u"my_password"]
    constructor = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-23 05:29:29.964504
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # In order to successfully run unit test, ansible/test/lib/ansible/parsing/yaml/data/empty_dict.yml
    # needs to be used
    from ansible.parsing.yaml.loader import AnsibleLoader

    data_str = '''
        !vault
          $ANSIBLE_VAULT;1.1;AES256
          7477685506635430784664565673172794c34636463346b6c627277476f733d396c39456b794f6f66
          3468656a6d534e6837436b4836344b664f3348344e4d6467494e6d33333348
        '''

    data = AnsibleLoader(data_str, file_name='test').get_single_data()

# Generated at 2022-06-23 05:29:38.349899
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml

    constructor_test = '''
    ---
    test1: !unsafe 'test value 1'
    test2: !unsafe 'test value 2'
    '''
    data = yaml.load(constructor_test, AnsibleConstructor)
    assert isinstance(data, dict)
    assert isinstance(data['test1'], AnsibleUnicode) and data['test1'] == 'test value 1'
    assert isinstance(data['test2'], AnsibleUnicode) and data['test2'] == 'test value 2'

# Generated at 2022-06-23 05:29:47.376509
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    import unittest

    class TestAnsibleConstructor(unittest.TestCase):
        ''' Test class for AnsibleConstructor_construct_yaml_str '''
        def setUp(self):
            ''' Set up method for module '''
            self.constructor = AnsibleConstructor()

        def tearDown(self):
            ''' Tear down method for module '''
            self.constructor = None

        def test_construct_yaml_str(self):
            ''' Test method construct_yaml_str '''

            data = ""
            node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', data)

            ret = self.constructor.construct_yaml_str(node)

# Generated at 2022-06-23 05:29:56.249751
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    class FakeNode(object):
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return "FakeNode(%r)" % (self.value,)
    value = ["Foo", "Bar"]
    fake_node = FakeNode(value)
    assert list(AnsibleConstructor.construct_yaml_seq(AnsibleConstructor(), fake_node)) == [["Foo", "Bar"]]


# Generated at 2022-06-23 05:30:05.479830
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import sys
    import io
    import sys
    from io import StringIO
    from yaml import load
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var


    # yaml.load(stream, Loader=AnsibleLoader) will return data object
    # the assertion is to verify the object returned is of type AnsibleSequence
    data = load(StringIO('- 1'), Loader=AnsibleConstructor)
    if sys.version_info[0] >= 3:
        assert isinstance(data, list)
    else:
        assert isinstance(data, AnsibleSequence)
    assert data[0] is 1

    data = load(StringIO('- - 1'), Loader=AnsibleConstructor)

# Generated at 2022-06-23 05:30:15.345899
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), node=None) == AnsibleMapping()
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), node=None, deep=True) == AnsibleMapping()

    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None, flow_style=True)
    assert AnsibleConstructor.construct_mapping(AnsibleConstructor(), node=node) == AnsibleMapping()

# Generated at 2022-06-23 05:30:23.874876
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    constructor = AnsibleConstructor(file_name=None, vault_secrets=[])

# Generated at 2022-06-23 05:30:26.327771
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    yaml.load('---\nfoo: bar', Loader=AnsibleConstructor)

# Generated at 2022-06-23 05:30:32.619594
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Test when passing a list
    unsafe_constructor = AnsibleConstructor()
    l = [1, 2, 3]
    output = unsafe_constructor.construct_yaml_unsafe(l)
    assert output == wrap_var(l)

    # Test when passing a module
    import pwd
    output = unsafe_constructor.construct_yaml_unsafe('pwd')
    assert output == wrap_var(pwd)

# Generated at 2022-06-23 05:30:44.108952
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['vault_secret_here']
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=vault_secrets)
    node = MappingNode(tag=u'vault-encrypted', value=[], start_mark=None, end_mark=None, flow_style=False)
    output_ansiblevault_encryptedunicode = ansible_constructor.construct_vault_encrypted_unicode(node)
    expected_ansiblevault_encryptedunicode = AnsibleVaultEncryptedUnicode(b'')
    expected_ansiblevault_encryptedunicode.vault = ansible_constructor._vaults['default']
    assert output_ansiblevault_encryptedunicode.__dict__ == expected_ansiblevault_encryptedunicode.__dict__

# Generated at 2022-06-23 05:30:54.559471
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    from yaml.constructor import SafeConstructor
    from yaml.nodes import SequenceNode
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode

    class TestAnsibleConstructor(AnsibleConstructor):
        def construct_yaml_seq(self, node):
            data = AnsibleSequence()
            yield data
            data.extend(self.construct_sequence(node))
            data.ansible_pos = self._node_position_info(node)

    stream = yaml.compose(u'[0, 1, 2]', Loader=TestAnsibleConstructor)
    sequence = list(stream)
    assert len(sequence) == 1
    assert isinstance(sequence[0], AnsibleSequence)

# Generated at 2022-06-23 05:31:06.547207
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import textwrap
    import unittest

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestAnsibleConstructor(unittest.TestCase):
        def test_construct_yaml_unsafe(self):
            yaml = textwrap.dedent("""\
            ---
            - !unsafe
            - !unsafe foo
            - foo: !unsafe
            - foo:
                - !unsafe
                - !unsafe bar
                - baz: !unsafe
            - foo: [!unsafe bar, !unsafe baz]
            """)


# Generated at 2022-06-23 05:31:16.880499
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = "secret"
    vault_secrets = [ vault_password, ]

    vault_constructor = AnsibleConstructor(file_name=None, vault_secrets=vault_secrets)

    ciphertext_data = b"$ANSIBLE_VAULT;1.1;AES256\n33353133366164316438353736663338613562396537343139613933613834383463333062333966\n3539396437373132623135356135383135363865666564363639656531353335343663336264396638\n666437343561333437\n"

    re = vault_constructor.construct_vault_encrypted_unicode(ciphertext_data)


# Generated at 2022-06-23 05:31:28.173709
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_seq = "[{hosts: all},{remote_user:'reigndeer'},{mysql_user: 'root',mysql_db: 'testdb'}]"
    list_of_ansible_dict = AnsibleConstructor.construct_yaml_seq(yaml_seq)
    assert list_of_ansible_dict[0] == {u'hosts': u'all'}
    assert list_of_ansible_dict[1] == {u'remote_user': u'reigndeer'}
    assert list_of_ansible_dict[2] == {u'mysql_user': u'root', u'mysql_db': u'testdb'}


# Generated at 2022-06-23 05:31:33.167014
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    data = u"foo"
    node = yaml.nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=data)

    ac = AnsibleConstructor()
    result = ac.construct_yaml_str(node)

    assert isinstance(result, AnsibleUnicode)
    assert result == data

# Generated at 2022-06-23 05:31:42.082676
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor