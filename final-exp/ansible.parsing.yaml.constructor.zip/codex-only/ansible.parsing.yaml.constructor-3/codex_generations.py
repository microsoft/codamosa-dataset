

# Generated at 2022-06-23 05:21:46.677314
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.utils.yaml import from_yaml
    yaml_data = """
        a: 1
        b: 2
        c:
            d: banana
            e: orange
        f:
            - apple
            - pear
            - peach
    """

    # Test multiple construction of yaml documents
    for _ in range(4):
        data = from_yaml(yaml_data)
        assert isinstance(data, AnsibleMapping)
        assert data['a'] == 1
        assert data['b'] == 2
        assert isinstance(data['c'], AnsibleMapping)
        assert data['c']['d'] == 'banana'
        assert data['c']['e'] == 'orange'
        assert isinstance(data['f'], AnsibleSequence)

# Generated at 2022-06-23 05:21:55.615726
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3

    block = '''
        ---
        this:
            - is: a
            - test:
                of: 
                    - the
                    - constructor
        and:
            - this: should be a dict
    '''

    results = AnsibleLoader(block).get_single_data()
    assert len(results.keys()) == 2
    assert u"this" in results
    assert u"and" in results
    assert results[u"this"] == [{u"is": u"a"}, {u"test": {u"of": [u"the", u"constructor"]}}]
    if PY3:
        assert type(results[u"this"]) is list

# Generated at 2022-06-23 05:22:01.114448
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

    try:
        vault = VaultLib(secrets=['123'])
        plaintext = "secret"
        ciphertext_data = vault.encrypt(plaintext)
        value = yaml.load('!vault |' + ciphertext_data, Loader=AnsibleConstructor)
        assert value == plaintext
    except:
        assert False, "Failed construct_vault_encrypted_unicode test"

# Generated at 2022-06-23 05:22:09.853529
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    # Create the constructor
    loader = AnsibleLoader(None, None)

    # Add the constructor to the YAML loader
    loader.add_constructor(u'tag:yaml.org,2002:map', AnsibleConstructor)

    # Get the data from stdin
    data = sys.stdin.read()

    # Load the data from YAML
    results = loader.get_single_data(data)
    print(results)


if __name__ == '__main__':
    # Run the unit test
    test_AnsibleConstructor()

# Generated at 2022-06-23 05:22:16.577781
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    data = {'key1': 'val1', 'key2': 'val2'}
    node = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map', value=[])

    ret = AnsibleConstructor.construct_yaml_unsafe(data, node)

    assert ret == wrap_var(data)


# Generated at 2022-06-23 05:22:21.475194
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import ansible.parsing.yaml.loader
    a = AnsibleConstructor.construct_yaml_str(ansible.parsing.yaml.loader.AnsibleLoader.construct_yaml_str, 'test')
    assert(a.__class__.__name__ == 'AnsibleUnicode')

# Generated at 2022-06-23 05:22:27.839604
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import os
    import tempfile
    import yaml

    # Set up tempfile
    (fd, temp_path) = tempfile.mkstemp()
    os.close(fd)
    os.remove(temp_path)

    # Write test file
    with open(temp_path, 'w') as f:
        f.write("""\
---
key1: value1
key2: value2
key3: value3
""")

    # Read test file and construct an AnsibleMapping
    with open(temp_path, 'r') as f:
        data = yaml.load(f, Loader=AnsibleConstructor)

    # Check value
    assert data == {u'key1': u'value1', u'key2': u'value2', 'key3': 'value3'}

# Generated at 2022-06-23 05:22:32.297228
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Given a YAML string
    yaml_string = u'!unsafe "user_input"'

    # The safe_load method should return the same string
    string = yaml.load(yaml_string, Loader=AnsibleConstructor)
    assert(isinstance(string, str))
    assert(string == u'user_input')

# Generated at 2022-06-23 05:22:43.526184
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    if C.DUPLICATE_YAML_DICT_KEY == 'ignore':
        # this test is only useful with the default behaviour which displays warnings
        return

    test_yaml = """
    test:
      a: 1
      b: not overriden
      c:
        c1: override c1
        c2: not overiddenc
      d:
        - d1
        - d2
    """
    test_yaml_duplicate_keys = test_yaml + """
    test:
      b: overriden
      c:
        c1: override c1 again
    """

# Generated at 2022-06-23 05:22:54.584896
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import unittest2
    import yaml

    yaml.add_multi_constructor(u'!unsafe', AnsibleConstructor.construct_yaml_unsafe)

    class TestAnsibleConstructor(unittest2.TestCase):

        def test_AnsibleConstructor(self):
            text = "Safe value: {unknown_value}"
            result = yaml.safe_load(text)
            self.assertIsInstance(result, AnsibleUnicode)
            self.assertEqual(result, text)
            text = "Unsafe value: {unknown_value}"
            result = yaml.load(text)
            self.assertIsInstance(result, AnsibleUnicode)
            text = "Unsafe value: {unknown_value}"
            result = yaml.load(text)
            self.assertIs

# Generated at 2022-06-23 05:23:04.079750
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    vault = VaultLib()
    vault.secrets = ['test']


# Generated at 2022-06-23 05:23:07.892970
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    testcases = [
        [
            "a\n- a\n- b",
            ['a', 'a', 'b'],
        ],
        [
            "a\n- a\n- b\n",
            ['a', 'a', 'b'],
        ],
    ]
    for loader in [AnsibleConstructor]:
        for testcase in testcases:
            assert testcase[1] == loader(testcase[0]).get_single_data()



# Generated at 2022-06-23 05:23:14.443719
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    node = MappingNode()
    data = constructor.construct_mapping(node)
    data['foo'] = 1
    assert data['foo'] == 1
    data['foo'] = 2
    assert data['foo'] == 2
    node = MappingNode()
    data = constructor.construct_mapping(node, deep=True)
    data['foo'] = 1
    assert data['foo'] == 1
    data['foo'] = 2
    assert data['foo'] == 2

# Generated at 2022-06-23 05:23:21.898065
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_src = '''
---
- name: test
  test: 1
  test: 2
  test: 3
  test: 4
'''
    ansible_constructor = AnsibleConstructor()
    from yaml import load
    data = load(yaml_src, Loader=ansible_constructor)
    assert type(data[0]) is AnsibleMapping
    assert data[0]['test'] == 4
    assert data[0].ansible_pos == ('<unicode string>', 1, 1)

# Generated at 2022-06-23 05:23:32.307188
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_doc = '''
    a: b
    c: d
    '''


# Generated at 2022-06-23 05:23:37.659209
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = yaml.load("""
- 1
- 2
- 3
        """, Loader=AnsibleConstructor)
    expected = [1, 2, 3]
    assert data == expected, 'AnsibleConstructor.construct_yaml_seq() test failed!'
    print('AnsibleConstructor.construct_yaml_seq() test passed!')

# Generated at 2022-06-23 05:23:40.110875
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # str
    value = 'str'
    obj = AnsibleConstructor().construct_yaml_str(value)
    assert obj == value
    


# Generated at 2022-06-23 05:23:42.442111
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    obj = AnsibleConstructor()
    assert obj.construct_yaml_map(None) is not None

# Generated at 2022-06-23 05:23:52.906511
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import io
    from ansible.parsing.yaml import objects

    text = u'''
        foo: bar
        baz: bang
        # a comment
        bing

        foo: bar
        baz: bang
        bing
    '''

    import sys
    stream = io.StringIO(text)
    stream.name = 'memstream'

    class Loader(AnsibleConstructor):
        def __init__(self):
            super(Loader, self).__init__()

    # Initialize Loader object
    loader = Loader()

    # Read and construct the YAML file
    yaml = loader.get_single_data(stream)
    # yaml is now a python dict containing the values from the yaml file
    # with the duplicate key foo receiving last value only

# Generated at 2022-06-23 05:23:58.357586
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vaultsecrets = ['vaultpassword']
    ac = AnsibleConstructor("somefile", vault_secrets=vaultsecrets)
    ret = ac.construct_vault_encrypted_unicode("!vault test")
    assert ret.ansible_pos == ("somefile", 0, 0)
    assert ret.vault.secrets == ['vaultpassword']

# Generated at 2022-06-23 05:24:10.009535
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.vault import VaultSecret
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class DictSubclass(dict):
        pass

    # using "mapping" to make sure we test the right class method
    constructor = AnsibleConstructor('mapping')
    # mock node used for testing
    node = MappingNode(None, None, None, flow_style=False)
    # test with dict and dict subclass
    data = {'a': 1, 'b': 2, 'c': 3}
    res = constructor.construct_mapping(node, deep=False)
    assert isinstance(res, AnsibleMapping)
    assert res == data
    res = constructor.construct_mapping(node, deep=True)

# Generated at 2022-06-23 05:24:21.151510
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.nodes import ScalarNode

# Generated at 2022-06-23 05:24:31.217364
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.vars import unsafe_proxy
    from ansible.parsing.vault import VaultLib
    import base64
    # Get a sample ciphertext
    password = 'secret'
    vault = VaultLib([password])
    plaintext = 'Hello World!'
    ciphertext = vault.encrypt(to_bytes(plaintext))
    b64_ciphertext = base64.b64encode(ciphertext)

    # Get the constructor
    ac = AnsibleConstructor()
    ac._vaults = dict()
    ac._vaults['default'] = vault

    # Do the test
    node = object()
    node.id = 'str'
    node.start_mark = ''
    node.value = b64_ciphertext
    aveu = ac.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-23 05:24:37.099057
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor

# Generated at 2022-06-23 05:24:44.196377
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import pprint

    constructor = AnsibleConstructor()

    test_string = "{a: 1, b: 2, c: { a: 1, b: 2}}"
    test_data = constructor.construct_yaml(test_string)
    assert not isinstance(test_data, AnsibleUnicode)
    pprint.pprint(test_data)
    assert test_data == {u'a': 1, u'b': 2, u'c': {u'a': 1, u'b': 2}}

# Generated at 2022-06-23 05:24:54.745421
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.parser import ParserError


# Generated at 2022-06-23 05:25:00.867495
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml
    s = """\
- {a: !!unsafe "b"}
"""
    safe = "c"
    data = yaml.load(s, Loader=AnsibleConstructor)
    assert data == [{'a': u'b'}]
    assert isinstance(data[0]['a'], AnsibleUnsafeText)
    assert "c" == safe

# Generated at 2022-06-23 05:25:06.864289
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Setup mocks
    file_name = '/etc/ansible/hosts'
    vault_secrets = ['dummy_vault_secret']

    # Execute method under test
    ansible_constructor = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    ansible_constructor.construct_mapping(None, deep=False)

    # Should not reach here if AttributeError is raised correctly
    assert False

# Generated at 2022-06-23 05:25:18.141018
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    yaml_str_duplicate ="""
a: 1
a: 2
    """.strip()
    yaml_str_orig ="""
a: 1
b: 2
    """.strip()
    yaml_str_empty ="""
      """.strip()
    yaml_num ="""
c: 1
    """.strip()
    test_config = 'ansible.cfg'
    vault_password = 'hello'

    def test_init():
        ansible_constructor = AnsibleConstructor(test_config, vault_secrets=[vault_password])
        assert ansible_constructor.vault_secrets is not None

    def test_dictionary():
        ansible_constructor = AnsibleConstructor(test_config, vault_secrets=[vault_password])
        yaml

# Generated at 2022-06-23 05:25:27.198437
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['secrets_test'])
    loader = AnsibleLoader(vault)

# Generated at 2022-06-23 05:25:35.329878
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import re

    nodes = [
        {
            "key1": "value1",
            "key2": "value2",
            "key3": {
                "key31": "value31"
            }
        },
        {
            "key1": "value1",
            "key2": "value2",
            "key3": {
                "key31": "value31"
            }
        },
        {
            "key1": "value1",
            "key2": "value2",
            "key2": "value2"
        }
    ]
    ansible_constructor = AnsibleConstructor()
    for mapping_node in nodes:
        mapping = ansible_constructor.construct_mapping(mapping_node)
        # test whether keys are all unicode

# Generated at 2022-06-23 05:25:45.765835
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    filename = '/tmp/testfile'
    vault_lib = VaultLib(
        secrets=[b'password'],
        vault_ids=['test_vault']
    )

    # test unicode
    loader = AnsibleLoader(vault_lib)
    ansible_constructor = AnsibleConstructor(filename, vault_secrets=vault_lib.secrets)
    ret = ansible_constructor.construct_yaml_str(loader.context.create_scalar_node('string', 'value'))
    assert isinstance(ret, AnsibleUnicode)
    assert ret == u'value'
    assert ret.ansible_pos == (filename, 1, 1)

   

# Generated at 2022-06-23 05:25:51.712016
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import copy

    def test_construct_yaml_unsafe(node, klass, value, **kwargs):
        my_node = copy.deepcopy(node)
        my_node.id = klass

        const = AnsibleConstructor()
        assert const.construct_yaml_unsafe(my_node) == value

    # test with different types of scalars
    node = yaml.nodes.Node('tag:yaml.org,2002:str', 1, 1, 1)
    node.value = "abcd"
    node.tag = u'tag:yaml.org,2002:str'

    node_int = yaml.nodes.Node('tag:yaml.org,2002:int', 1, 1, 1)
    node_int.value = 23
    node_int.tag = u

# Generated at 2022-06-23 05:25:54.182670
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    mapping = {'a': 1, 'b': 2, 'c': 3}
    constructor = AnsibleConstructor()
    constructor.construct_yaml_map(id(mapping))
    


# Generated at 2022-06-23 05:26:04.864864
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class EmptyVault():
        def __init__(self):
            self.secrets = []
    class EmptyAnsibleConstructor(AnsibleConstructor):
        _vaults = {'default': EmptyVault()}
    from yaml.nodes import ScalarNode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-23 05:26:11.071456
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    display = Display()
    # test case:
    # - hosts: all
    #   gather_facts: no
    #   tasks:
    #   - debug:
    #       msg: "{{ <%= value %> }}"
    # with the input value:
    # {
    #   "value": "`/bin/rm -rf /`"
    # }
    value = {u'hosts': u'all', u'gather_facts': False, u'tasks': [{u'debug': {u'msg': u"{{ <%= value %> }}"}}]}
    ansible_constructor = AnsibleConstructor()
    unsafe_value = ansible_constructor.construct_yaml_unsafe(value)
    display.display(unsafe_value)

# Generated at 2022-06-23 05:26:21.801361
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    mapping = constructor.construct_mapping({'first-key': 1, 'first-key': 2})
    assert mapping == {'first-key': 2}

    mapping = constructor.construct_mapping({'first-key': 1, 'second-key': 2})
    assert mapping == {'first-key': 1, 'second-key': 2}

    if C.DUPLICATE_YAML_DICT_KEY in ('warn', 'error'):
        try:
            mapping = constructor.construct_mapping({'first-key': 1, 'first-key': 2})
            raise AssertionError('should not come here')
        except ConstructorError as e:
            assert "found a duplicate dict key" in to_native(e)



# Generated at 2022-06-23 05:26:33.568459
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    expected_data = AnsibleMapping()
    expected_data.update({'key1': 'value1', 'key2': 'value2'})
    expected_data.ansible_pos = ('<unicode>', 1, 4)

# Generated at 2022-06-23 05:26:35.799494
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = ''
    data = AnsibleConstructor.construct_yaml_map(node)
    expected = ''
    assert data == expected


# Generated at 2022-06-23 05:26:46.844783
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import yaml
    class mock_node:
        def __init__(self, value):
            self.value = value
        def __getattribute__(self, name):
            if name == 'id':
                return 'str'
            else:
                return object.__getattribute__(self, name)

    secrets = os.path.join(
        os.path.dirname(C.DEFAULT_LOCAL_TMP),
        C.DEFAULT_VAULT_PASSWORD_FILE)
    with open(secrets, 'rb') as f:
        key = f.read()
    vault_secrets = [key]
    c = AnsibleConstructor(file_name=None, vault_secrets=vault_secrets)
    with open(secrets, 'rb') as f:
        b_

# Generated at 2022-06-23 05:26:52.525332
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    s = """
        a: b
        b: c
        c: d
        """
    a = AnsibleConstructor(file_name='test')
    yaml_map = a.construct_yaml_map(yaml.compose(s))
    print(yaml_map)
test_AnsibleConstructor_construct_yaml_map()

# Generated at 2022-06-23 05:27:02.575001
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    # mock of class Node
    class Node:
        def __init__(self, line=1, column=1, data=''):
            self.start_mark = self

            self.end_mark = self

            self.data = data

            self.line = line

            self.column = column


    # mock of class AnsibleVaultEncryptedUnicode
    class AnsibleVaultEncryptedUnicode:
        def __init__(self, data):
            self.data = data

        def __bytes__(self):
            return self.data

    # create a sample vault_secrets variable to pass to AnsibleConstructor
    vault_secrets = ['secret1', 'secret2']

# Generated at 2022-06-23 05:27:14.281382
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Note: This test requires that you have "pip install pytest pytest-cov" installed on your machine
    #  before running pytest in your /test directory.
    # See: http://pytest.org/latest/getting-started.html#getstarted
    import pytest
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.errors import AnsibleError

    # A few test vectors from the vault spec

# Generated at 2022-06-23 05:27:22.284545
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_str({'value': '123'})) == AnsibleUnicode
    assert type(ansible_constructor.construct_yaml_str({'value': '123'}).ansible_pos) == tuple
    assert ansible_constructor.construct_yaml_str({'value': '123'}).ansible_pos == (None, None, None)
    assert ansible_constructor.construct_yaml_str({'value': '123', 'start_mark': {'line': 1, 'column': 1}}).ansible_pos == (None, 2, 2)



# Generated at 2022-06-23 05:27:34.263954
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader

    construct_yaml_map = AnsibleConstructor.construct_yaml_map
    construct_yaml_str = AnsibleConstructor.construct_yaml_str

    data1 = '''
        a:
            x: 1
            y: 2
        b:
            w: abc
            z: def
    '''
    data1_keywords = ['a', 'b']
    yaml_data1 = AnsibleLoader(StringIO(data1)).get_single_data()

    ansible_constructor = AnsibleConstructor('string')
    ansible_map1 = ansible_constructor.construct_yaml_map(yaml_data1)

# Generated at 2022-06-23 05:27:45.166558
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    vault_secrets = ['secret1', 'secret2']
    data_loader = DataLoader()
    file_name = 'test-file'
    test_loader = AnsibleLoader(data_loader, file_name, vault_secrets)

    # test legacy vault format

# Generated at 2022-06-23 05:27:52.222782
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import sys
    import os
    import pytest
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    if os.path.isdir(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))+'/lib/ansible/plugins/cache'):
        plugin_cache = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))+'/lib/ansible/plugins/cache'

# Generated at 2022-06-23 05:28:02.447635
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    class AnsibleConstructorTest():

        def __init__(self, node):
            self._node = node

        def construct_mapping(self, node, deep=False):
            # Most of this is from yaml.constructor.SafeConstructor.  We replicate
            # it here so that we can warn users when they have duplicate dict keys
            # (pyyaml silently allows overwriting keys)
            if not isinstance(node, MappingNode):
                raise ConstructorError(None, None,
                                       "expected a mapping node, but found %s" % node.id,
                                       node.start_mark)
            self.flatten_mapping(node)
            mapping = AnsibleMapping()


# Generated at 2022-06-23 05:28:07.277162
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    class FakeNode:
        def __init__(self):
            self.start_mark = None
            self.end_mark = None

    node = FakeNode()
    ac = AnsibleConstructor()
    result = ac.construct_yaml_map(node)
    assert type(result) == AnsibleMapping

# Generated at 2022-06-23 05:28:15.333550
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.vault import VaultLib

    test_cases = [
        {
            'yaml': '''
a:
  b: 1
  c: 2
''',
            'expected': {'a': {'b': 1, 'c': 2}}
        },
        {
            'yaml': '''
a: 1
a: 2
''',
            'expected': {'a': 2}
        },
    ]
    for test_case in test_cases:
        yaml_data = yaml.load(test_case['yaml'], Loader=AnsibleConstructor)
        assert yaml_data == test_case['expected']

# Generated at 2022-06-23 05:28:17.090744
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # FIXME: There's no unit test for AnsibleConstructor
    pass

# Generated at 2022-06-23 05:28:28.034965
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from yaml import dump, load
    from yaml import SafeDumper as Dumper
    from yaml import SafeLoader as Loader

    dumper = Dumper
    dumper.ignore_aliases = lambda self, data: True
    string = dump(dict(a='b', b='c'), Dumper=dumper, default_flow_style=False)
    # The way this test is currently written, it fails if 'c: b' comes before
    # 'a: b' in the output string, which it does in Python 3.5. This is an
    # implementation detail of the dict object in Python 3.5, so we don't
    # support it. However, this test will pass on all other versions of Python
    # (including 2.7), and it will pass on all versions of Python once this
    # issue is fixed: https://bugs.python

# Generated at 2022-06-23 05:28:30.707244
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    a = AnsibleConstructor()
    assert a.construct_yaml_str("str") == u"str"

# Generated at 2022-06-23 05:28:41.512886
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-23 05:28:46.625756
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    A = AnsibleConstructor()

    ansible_map = A.construct_yaml_map(yaml.nodes.MappingNode('tag:yaml.org,2002:map', [], []))
    ansible_map['key1'] = 'value1'
    ansible_map['key2'] = 'value2'

    assert(ansible_map['key1'] == 'value1')
    a

# Generated at 2022-06-23 05:28:53.824312
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_string = u'{foo: bar, bar: baz, baz: {' + u'foo: bar, bar: baz, baz: {' * 10 + u'foo: bar, bar: baz' + u'}' * 10 + u'}}'
    test_yaml_dict = yaml.load(test_string)
    test_ansible_dict = AnsibleLoader(test_string).get_single_data()

    assert test_ansible_dict == test_ansible_dict

# Generated at 2022-06-23 05:29:03.620880
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml
    yaml_str = """
logging:
  version: 1
  formatters:
    default:
      format: "%(asctime)s %(name)s %(process)d %(message)s"
      datefmt: "%Y-%m-%d %H:%M:%S %z"
  handlers:
    console:
      class: logging.StreamHandler
      formatter: default
      stream: ext://sys.stdout
  root:
    level: INFO
    handlers: [console]
  extra: !unsafe {'something': 1}
"""
    data = yaml.load(yaml_str, AnsibleConstructor)

    assert(isinstance(data, dict))
    assert(isinstance(data['logging']['extra'], AnsibleUnsafeText))



# Generated at 2022-06-23 05:29:07.427074
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    # We need the node to be callable, so we wrap a string into a closure
    node = lambda: 'Hello World'
    node.id = 'str'

    # The expected and actual result
    expected_result = 'Hello World'

    ac = AnsibleConstructor()

    # Execute the code to test
    actual_result = ac.construct_yaml_unsafe(node)

    # Verify the result
    assert actual_result == expected_result

# Generated at 2022-06-23 05:29:18.896657
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_text
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import sys

    if sys.version_info >= (3, 0):
        unicode = str

    input_data = b'''
    # Construct a simple list
    - item1
    - item2

    # Construct a list of dictionaries
    - key1: val1
      key2: val2
    - key1: val3
      key2: val4
    '''


# Generated at 2022-06-23 05:29:22.131748
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = """---
- key: value
  key: newvalue
"""

    myconstructor = AnsibleConstructor()
    myconstructor.construct_document(data)



# Generated at 2022-06-23 05:29:32.805037
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import importlib
    import sys

    # We need to use a dynamic import here to avoid a dependency cycle
    # AnsibleYAMLDataLoader -> AnsibleConstructor -> imp -> AnsibleModule -> AnsibleYAMLDataLoader
    sys.modules['ansible'].ansible_module_utils.basic = importlib.import_module('ansible.module_utils.basic')

    from ansible.module_utils.basic import AnsibleModule

    # Instantiate a AnsibleModule object
    module = AnsibleModule(argument_spec={})

    class test_AnsibleConstructor_construct_yaml_unsafe_SafeConstructor(AnsibleConstructor):
        def construct_yaml_unsafe(self, node):
            # Ensure that a AnsibleModule object has been passed to the constructor.
            return module

    from yaml import Scanner

# Generated at 2022-06-23 05:29:41.828552
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    vault_password = 'baz'
    vault_secrets = [ vault_password ]
    vault_instance = VaultLib(vault_secrets)

# Generated at 2022-06-23 05:29:48.402328
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    # Given
    string_for_yaml = u"this is a string"
    input_string = "!str " +  string_for_yaml
    yaml_obj = yaml.load(input_string, Loader=AnsibleConstructor)

    # Then
    assert(isinstance(yaml_obj, AnsibleUnicode))
    assert(yaml_obj == string_for_yaml)

# Generated at 2022-06-23 05:30:01.518784
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import yaml


# Generated at 2022-06-23 05:30:11.019067
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test for custom tag !vault-encrypted
    vault_password = 'vault_password'

    # Test for custom vault tag
    # Test for creating normal AnsibleVaultEncryptedUnicode object
    vaultLib = VaultLib(vault_secret=vault_password)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults['default'] = vaultLib

# Generated at 2022-06-23 05:30:18.206813
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml

    string = 'YAML string'
    safe_constructor = AnsibleConstructor()
    node = yaml.nodes.ScalarNode(tag = u'tag:yaml.org,2002:str', value = string)

    ansible_string = safe_constructor.construct_yaml_str(node)

    assert ansible_string == string
    assert isinstance(ansible_string, AnsibleUnicode)

# Generated at 2022-06-23 05:30:23.946459
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    c = AnsibleConstructor()

    # "mystring" will be the input string
    test_node = u"mystring"

    # perform the test
    output = c.construct_yaml_str(test_node)

    # output should be class AnsibleUnicode
    assert isinstance(output, AnsibleUnicode)

    # output should be an AnsibleUnicode with its data being "mystring"
    assert output.data == u"mystring"



# Generated at 2022-06-23 05:30:32.376425
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import json
    import tempfile
    import shutil
    import time

    script_dir = os.path.dirname(__file__)
    test_data_dir = os.path.join(script_dir, '../../test_data')
    yaml_data = """
    date: !unsafe '11/13/19'
    """
    y = AnsibleConstructor()
    d = y.construct_yaml(yaml_data)
    # convert yaml to json and then load it back to compare
    with tempfile.NamedTemporaryFile(delete=False) as t_yaml:
        t_yaml.write(yaml_data)

# Generated at 2022-06-23 05:30:43.925597
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from io import StringIO
    from yaml import load

    # Test case with following YAML format
    # - key1: value1
    #   key2: value2
    # - key3: value3
    #   key4: value4
    yaml_str = u'''
    - key1: value1
      key2: value2
    - key3: value3
      key4: value4
    '''

    fh = StringIO(yaml_str)
    data = load(fh, Loader=AnsibleConstructor)

    assert data[0].ansible_pos == ('<unicode string>', 2, 3)
    assert data[0]['key1'].ansible_pos == ('<unicode string>', 2, 4)
    assert data[0]['key2'].ans

# Generated at 2022-06-23 05:30:50.829285
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    ansible_int = AnsibleUnsafeText(u'ansible')
    data = dict(ansible=ansible_int)
    yaml_str = u"ansible: !unsafe 'ansible'"
    data_loaded = AnsibleLoader(yaml_str).get_single_data()
    assert data == data_loaded

# Generated at 2022-06-23 05:31:00.632765
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Instantiate a VaultLib object with a VaultSecret
    base64_secret = b'12345678901234567890'
    vault_secrets = [('key',base64_secret)]
    vault = VaultLib(secrets=vault_secrets)
    assert vault.secrets

    # Instantiate an AnsibleConstructor object
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)

    # Encrypt some data to be decrypted later
    plaintext_data = b'Hello World!'
    b_ciphertext_data = vault.encrypt(plaintext_data)
    ciphertext_data = to_native(b_ciphertext_data)
    ciphertext_with_header = to_native("$ANSIBLE_VAULT;1.1;AES256") + cipher

# Generated at 2022-06-23 05:31:02.813807
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert AnsibleConstructor.construct_yaml_map('node') == AnsibleMapping

# Generated at 2022-06-23 05:31:13.887281
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create a test class derived from AnsibleConstructor
    class YAMLTestConstructor(AnsibleConstructor):
        def _node_position_info(self, node):
            return ('.', 0, 0)
    yaml_test_constructor = YAMLTestConstructor()
    # Run AnsibleConstructor.construct_vault_encrypted_unicode method
    # This is a workaround of https://github.com/yaml/pyyaml/issues/268
    # PyYAML 5.1.2 doesn't support MappingNode constructor
    class MappingNodeFake:
        def __init__(self):
            self.value = []
        def start_mark(self):
            return '.'
    # Create a test node
    node = MappingNodeFake()
    # Create a test string
    value = to_bytes

# Generated at 2022-06-23 05:31:24.137695
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # !!!! Don't change the password and expected values below !!!!
    # They are hardcoded and used by the unittest.
    test_password = 'hello'

# Generated at 2022-06-23 05:31:31.724618
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data = '''
key1: value1
key2: value2
key3: value3
    '''
    expected_data = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    ansible_constructor = AnsibleConstructor()
    data = ansible_constructor.construct_yaml_map(yaml_data)
    assert data == expected_data



# Generated at 2022-06-23 05:31:36.393018
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    x = yaml.safe_load('''
---
- test_host
- test_host2
''')
    assert x[0] == u'test_host'
    assert x[1] == u'test_host2'
    assert x.__class__ == AnsibleSequence
