

# Generated at 2022-06-23 05:21:46.260225
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # The following is a ciphertext string produced by:
    #   vault.write_encrypted_file(self.vault_password, 'test data')
    # where vault_password is 'test'
    ciphertext = u'$ANSIBLE_VAULT;1.1;AES256\n32396335643165623339623038646664613931623235636563666436313934623966363762366562\n63366464653465313235323531656535343066383538663561306637636236633030656431313833\n34646261313439646530643539333564663064623130316564333937313961316632656633626130\nc2F5MjRGOWE5Ng==\n'
   

# Generated at 2022-06-23 05:21:50.522254
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import sys
    import StringIO
    old_stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    from yaml.constructor import ConstructorError
    ansible_constructor = AnsibleConstructor()
    try:
        ansible_constructor.construct_mapping(1)
        assert False, 'should have raised'
    except ConstructorError:
        pass
    sys.stdout = old_stdout

# Generated at 2022-06-23 05:21:56.299169
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    import sys
    from ansible.parsing.yaml.dumper import AnsibleDumper

    if sys.version_info < (3, 3):
        print("SKIPPED: 'construct_yaml_unsafe' requires pyyaml >= 3.10")
        return

    # use default unsafe_proxy_override
    orig_override_setting = C.DEFAULT_UNSAFE_PROXY_OVERRIDE
    C.DEFAULT_UNSAFE_PROXY_OVERRIDE = True

    # load from YAML string
    to_load = u'!!python/object/new:os.path !!python/tuple ["abc", "def"]'
    loader = AnsibleConstructor()
    data = loader.get_single_data(to_load)

    # test data was loaded

# Generated at 2022-06-23 05:21:57.068724
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    pass

# Generated at 2022-06-23 05:22:06.747043
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    file_name = 'test/ansible/parsing/vault_test.yml'
    vault_secrets = ['vaultsecret']
    test_parser = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    reader = open(file_name, 'r')
    raw_data = reader.read()
    node = test_parser.get_single_node(raw_data)
    ret = test_parser.construct_yaml_map(node)
    expected_value = {'name': 'test', 'is_encrypted': True}
    assert next(ret) == expected_value
    assert len(next(ret)) == 2
    reader.close()

# Generated at 2022-06-23 05:22:17.359191
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import io
    import sys
    import unittest

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    yaml_data = """
- hosts: localhost
  connection: local
  gather_facts: false
  tasks:
    - name: test
      debug: var=test_var
"""
    yaml_objects = AnsibleLoader(io.StringIO(yaml_data), vault_secrets=[VaultLib()]).get_single_data()

    assert isinstance(yaml_objects, list)
    assert len(yaml_objects) == 1
    assert isinstance(yaml_objects[0], dict)



# Generated at 2022-06-23 05:22:28.985095
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import os
    import json

    # FIXME: this is a temporary yaml file with a string containing newlines
    data = '{"foo": "a string\\n  that spans\\n  multiple lines"}'

    # FIXME: this is a temporary output file
    output = 'ansible_yaml_unsafe_test_output.txt'

    # FIXME: We have to ensure to have a tmpfile which contains a string
    # containing newlines in order to get a proper test
    with open(output, 'w') as f:
        f.write(data)

    # FIXME: if the original file exists, we can't expect to get the right
    # result in the end, so we delete it
    if os.path.exists(output):
        os.unlink(output)

    # FIXME: run the

# Generated at 2022-06-23 05:22:40.862727
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleConstructorConstructYAMLMap(unittest.TestCase):
        def test_construct_yaml_map(self):
            data = """
            a: 1
            b:
              foo: bar
            """
            loader = AnsibleLoader(data, file_name="<string>")
            loader.compose_document()
            ansible_map = loader.get_single_data()
            self.assertEqual(
                ansible_map.__class__.__name__,
                "AnsibleMapping"
            )

# Generated at 2022-06-23 05:22:51.213236
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # Complex example
    ac = AnsibleConstructor()
    data = ac.construct_yaml_map({'foo': 1, 'bar': 2, 'baz': 3})
    assert data == {'foo': 1, 'bar': 2, 'baz': 3}

    # Simple example
    ac = AnsibleConstructor()
    data = ac.construct_yaml_map(
        {'foo': 1})
    assert data == {'foo': 1}

    # AnsibleUnicode example
    ac = AnsibleConstructor()
    data = ac.construct_yaml_str('new_value')
    data = data.encode('utf-8')
    assert data == 'new_value'

    # AnsibleVaultEncrypted example
    ac = AnsibleConstructor()
    original_string = 'example'
    vault

# Generated at 2022-06-23 05:22:52.764554
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-23 05:23:02.682083
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # test with ansible_pos info
    loader = AnsibleConstructor(file_name='/foo/bar/baz.yml')
    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str',
                                 u'some-value',
                                 'file:/foo/bar/baz.yml, line: 2, column: 2')
    a_str = loader.construct_yaml_str(node)
    assert isinstance(a_str, AnsibleUnicode)
    assert a_str == 'some-value'
    assert a_str.ansible_pos == ('/foo/bar/baz.yml', 2, 2)

    # test with ansible_pos info, using a different line/column

# Generated at 2022-06-23 05:23:11.787593
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    fake_node = type('obj', (object,), {'start_mark': type('obj', (object,), {'line': 1, 'column': 0, 'name': 'test'})})
    ansible_data = ansible_constructor.construct_yaml_map(fake_node)
    assert isinstance(ansible_data, AnsibleMapping)

    ansible_data = ansible_constructor.construct_yaml_map(fake_node)
    assert isinstance(ansible_data, AnsibleMapping)
    assert ansible_data.ansible_pos == ('test', 2, 1)

# Generated at 2022-06-23 05:23:18.629251
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_text = '''
    a: 1
    b: 2
    '''

    yaml_obj = yaml.load(
        yaml_text,
        Loader=AnsibleConstructor)

    assert 'a' in yaml_obj
    assert 'b' in yaml_obj

    obj_type = type(yaml_obj)
    assert issubclass(obj_type, dict)
    assert issubclass(obj_type, AnsibleMapping)

# Generated at 2022-06-23 05:23:24.131908
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = "df4bh4tgf4g"
    ansible_constructor = AnsibleConstructor()
    # test construct_vault_encrypted_unicode method of class AnsibleConstructor
    test_ret = ansible_constructor.construct_vault_encrypted_unicode(node)
    # assert that the returned object is of class AnsibleVaultEncryptedUnicode
    assert type(test_ret) == AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:23:32.478570
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    src1 = u'{a: 1, b: 2}'
    doc1 = yaml.load(src1, Loader=AnsibleLoader)
    assert isinstance(doc1, dict)
    assert isinstance(doc1, AnsibleMapping)
    assert doc1 == {u'a': 1, u'b': 2}

    src2 = u'{1: [1, 2], 2: [3, 4]}'
    doc2 = yaml.load(src2, Loader=AnsibleLoader)
    assert isinstance(doc2, dict)
    assert isinstance(doc2, AnsibleMapping)
    assert doc2 == {1: [1, 2], 2: [3, 4]}



# Generated at 2022-06-23 05:23:42.534438
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import nodes as yaml_nodes
    from yaml.scanner import ScannerError
    from yaml import loader
    import sys

    if sys.version_info[0] == 2:
        assert u"foobar" == loader.construct_yaml_str(loader.AnsibleConstructor(), yaml_nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foobar', start_mark=None, end_mark=None))
    else:
        assert "foobar" == loader.construct_yaml_str(loader.AnsibleConstructor(), yaml_nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'foobar', start_mark=None, end_mark=None))


# Generated at 2022-06-23 05:23:52.905577
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # This unit test tests if the method construct_mapping of the class
    # AnsibleConstructor will raise a ConstructorError if a duplicate dict key is
    # found in a dict
    node = MappingNode(tag="tag:yaml.org,2002:map", value=[], start_mark=None, end_mark=None, flow_style=False)
    ac = AnsibleConstructor()
    # first, let's make sure the method will raise the error
    # with the correct yaml node
    try:
        ac.construct_mapping(node)
    except ConstructorError as err:
        assert err.problem_mark.line == node.start_mark.line + 1
        assert err.problem_mark.column == node.start_mark.column + 1
    else:
        assert False
    # now, let's test if the

# Generated at 2022-06-23 05:24:02.364437
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import StringIO

    plaintext = StringIO.StringIO("""
    ---
    foo: bar
    baz:
    - biz
    - biy
    """)
    vault_secret = StringIO.StringIO("secret\n")
    vault_secret.name = "fake_filename"
    vault_secret.close()

    plaintext_no_dupe = StringIO.StringIO("""
    ---
    foo: bar
    foo: baz
    """)

    loader = AnsibleLoader(plaintext, vault_secrets=[vault_secret])
    data = loader.get_single_data()
    assert(data == dict(foo='bar', baz=['biz', 'biy']))

    loader.stream = plaintext_no

# Generated at 2022-06-23 05:24:12.988025
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from pprint import pprint
    from yaml import load
    from ansible.parsing.yaml import Loader, dumper
    import sys

    # check if the constructor is called
    orig = AnsibleConstructor.construct_yaml_map
    def mock(self, node):
        print('construct_yaml_map called')
        pprint(node)
        ret = orig(self, node)
        print('ret', ret)
        # return a generator object
        return iter(ret)
    AnsibleConstructor.construct_yaml_map = mock

    # test data
    data = '''
k1:
  k2: v2
  k3: v3
    '''

    # run
    loader = Loader(data)
    l = list(loader.get_single_data())

# Generated at 2022-06-23 05:24:16.624446
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml = """
    one:
    - 1
    - 2
    - 3
    """
    a = AnsibleConstructor()
    b = a.construct_yaml_seq(a.construct_yaml_map(a.construct_document(a.compose_node(None, yaml))))
    assert list(b)[0]['one'][0] == 1

# Generated at 2022-06-23 05:24:22.665307
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    '''Test AnsibleConstructor.construct_yaml_str().

    This tests the data type returned by construct_yaml_str().
    '''
    s = b'test'
    node = yaml.nodes.ScalarNode(tag='tag:yaml.org,2002:str', value=s)
    a = AnsibleConstructor()
    assert type(a.construct_yaml_str(node)) is AnsibleUnicode


# Generated at 2022-06-23 05:24:32.494628
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    from io import StringIO, BytesIO

    # test mapping
    data = yaml.load('''
a: 1
b: 2
''', Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos == (None, 1, 0)
    assert data['a'].ansible_pos == (None, 1, 2)
    assert data['b'].ansible_pos == (None, 2, 2)

    # test sequence
    data = yaml.load('''
- a
- b
''', Loader=AnsibleConstructor)
    assert isinstance(data, AnsibleSequence)

# Generated at 2022-06-23 05:24:40.029967
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_object = """
---
-
  name: hello
  value: world
  in: list
  testing: duplicates
  testing: duplicates
"""
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = AnsibleLoader(yaml_object).get_single_data()
    for item in data:
        assert isinstance(item, AnsibleMapping)
        assert 'name' in item
        assert 'value' in item
        assert 'in' in item
        assert 'testing' in item
        assert 'test_test' not in item


# Generated at 2022-06-23 05:24:50.574784
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = """
---
foo:
  baz: 12
  qux: 16
"""
    # test default constructor
    doc = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(doc, AnsibleMapping)
    assert isinstance(doc.get('foo'), AnsibleMapping)
    assert isinstance(doc.get('foo').get('baz'), int)
    assert isinstance(doc.get('foo').get('qux'), int)

    # test constructor specifying a filename

# Generated at 2022-06-23 05:24:55.665689
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
  constructor = AnsibleConstructor()
  node = MappingNode(tag=u'tag:yaml.org,2002:map', value = [], start_mark = None, end_mark = None, flow_style = False)
  data = constructor.construct_yaml_map(node).next()
  assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-23 05:25:01.726078
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    dict_value = dict(a=1, b=2)
    construct_yaml_unsafe = AnsibleConstructor.construct_yaml_unsafe
    assert construct_yaml_unsafe(dict_value) == dict_value
    list_value = [1, 2, 3]
    assert construct_yaml_unsafe(list_value) == list_value
    str_value = u'test string'
    assert construct_yaml_unsafe(str_value) == str_value
    int_value = 42
    assert construct_yaml_unsafe(int_value) == int_value

# Generated at 2022-06-23 05:25:09.346044
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import objects

    from ansible.vars.unsafe_proxy import wrap_var, UnsafeProxy

    # Test if the constructed object is of type UnsafeProxy
    assert isinstance(AnsibleConstructor.construct_yaml_unsafe(objects.AnsibleUnicode("value")), UnsafeProxy)

    # Test if the constructed object is equal to the one created using wrap_var
    assert AnsibleConstructor.construct_yaml_unsafe(objects.AnsibleUnicode("value")) == wrap_var("value")

# Generated at 2022-06-23 05:25:09.986245
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass

# Generated at 2022-06-23 05:25:20.311305
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class AnsibleConstructorTester(AnsibleConstructor):
        def __init__(self):
            pass

    tester = AnsibleConstructorTester()
    import ruamel.yaml as yaml
    yamlLoader = yaml.Loader
    class YAMLNode(yamlLoader.NODE):
        pass

    yamlLoader.NODE = YAMLNode
    yamlLoader.add_constructor("!vault", tester.construct_vault_encrypted_unicode)
    yamlLoader.add_constructor("!vault-encrypted", tester.construct_vault_encrypted_unicode)


# Generated at 2022-06-23 05:25:31.678133
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib

    class FakeLoader:
        def __init__(self, node):
            self.node = node

        def get_data(self):
            return self.node

    yaml.SafeLoader.add_constructor('!vault', FakeLoader)

    class FakeSecret:
        def __init__(self, password):
            self.password = password

        def __eq__(self, other):
            return self.password == other.password

    class FakeVaultLib(VaultLib):
        def __init__(self, secrets):
            self.secrets = secrets


# Generated at 2022-06-23 05:25:39.322173
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # Create an instance of AnsibleConstructor
    ans_constr = AnsibleConstructor()

    # Create a node for testing
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
                       anchor=None, style=None)

    # This is a method so we need to call it
    ans_constr.construct_yaml_map(node)


test_AnsibleConstructor_construct_yaml_map()

# Generated at 2022-06-23 05:25:48.981324
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.vault
    ansible.parsing.vault.__vault = None

    assert AnsibleConstructor(vault_secrets=['secret1', 'secret2']).construct_yaml_unsafe(None) == wrap_var(None)
    assert AnsibleConstructor(vault_secrets=['secret1', 'secret2']).construct_yaml_unsafe(1) == wrap_var(1)
    assert AnsibleConstructor(vault_secrets=['secret1', 'secret2']).construct_yaml_unsafe('a') == wrap_var('a')
    assert AnsibleConstructor(vault_secrets=['secret1', 'secret2']).construct_yaml_unsafe({'a': 'b'}) == wrap_var({'a': 'b'})


# Generated at 2022-06-23 05:25:56.458723
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Initialization
    ansible_constructor = AnsibleConstructor()
    result_dict = dict()
    # Get values for testing
    node = type('', (), {'start_mark': type('', (), {'column': 0, 'line': 0, 'name': 'filename'})})()
    mock_value = 'value'
    node.value = mock_value
    # Call method
    result = ansible_constructor.construct_vault_encrypted_unicode(node)
    # Check result
    b_ciphertext_data = to_bytes(mock_value)
    vault = ansible_constructor._vaults['default']
    ret = AnsibleVaultEncryptedUnicode(b_ciphertext_data)
    ret.vault = vault
    result_dict[ret.ansible_pos[0]]

# Generated at 2022-06-23 05:26:06.423375
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    node = """
    a: foo
    a: bar
    """
    constructor = AnsibleConstructor()
    mapping = constructor.construct_yaml_map(node)
    assert mapping == {'a': AnsibleUnicode('bar')}

    node = """
    a: foo
    b: bar
    c: foo
    """
    constructor = AnsibleConstructor()
    mapping = constructor.construct_yaml_map(node)
    assert mapping == {'a': AnsibleUnicode('foo'), 'b': AnsibleUnicode('bar'), 'c': AnsibleUnicode('foo')}

# Generated at 2022-06-23 05:26:16.607594
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 05:26:27.116263
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """Ensure that AnsibleConstructor.construct_yaml_seq properly handles list
    elements with multiple yaml tags.
    """
    class MockLoader(object):

        def __init__(self, data=None):
            self._data = data
            self._completed_tasks = []

        def get_single_data(self):
            return self._data

    data = [{'yaml': 'value1', 'yml': 'value2'}]
    loader = MockLoader(data)
    ac = AnsibleConstructor(loader)
    # ac returns a generator which we can iterate to obtain our result
    result = next(ac.construct_yaml_seq(Mock(value=data)))
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0]['yaml']

# Generated at 2022-06-23 05:26:34.904621
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ac = AnsibleConstructor()
    class TestNode:
        def __init__(self):
            self.id = 'str'
        def start_mark(self):
            class TestMark:
                def __init__(self):
                    self.line = 1
                    self.column = 1
                    self.name = '<string>'
                def __repr__(self):
                    return '<TestMark>'
            return TestMark()
    node = TestNode()

    result = ac.construct_yaml_str(node)
    assert repr(result) == '<AnsibleUnicode>'
    assert result.ansible_pos == ('<string>', 1, 1)

# Generated at 2022-06-23 05:26:41.109372
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import string_types

    value = AnsibleConstructor(file_name=None).construct_yaml_unsafe(
        AnsibleLoader({'mem': '0x7fffffff'}, None).get_single_data()
    )
    assert isinstance(value, string_types), "value is not a string"
    assert isinstance(value, wrap_var), "value is not a wrapped variable"
    assert value == '0x7fffffff'

# Generated at 2022-06-23 05:26:50.052527
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # construct the Vault secret
    vault_object = VaultLib(secrets=[(b'asdf', b'asdf'), (b'fdsa', b'fdsa')])
    vault_password = b'asdf'

    # encrypt a test string
    plaintext_data = b'this is a test string'
    ciphertext_data = vault_object.encrypt(plaintext_data, vault_password)

    # create an AnsibleVaultEncryptedUnicode object
    ansible_vault_encrypted_unicode = AnsibleConstructor().construct_vault_encrypted_unicode(ciphertext_data)

    # the actual test
    assert plaintext_data == ansible_vault_encrypted_unicode

# Generated at 2022-06-23 05:27:00.452532
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml import loader

# Generated at 2022-06-23 05:27:02.893779
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    try:
        #assert ansible.parsing.yaml.constructor.AnsibleConstructor.construct_vault_encrypted_unicode("node")
        assert False
    except NotImplementedError as e:
        assert True


# Generated at 2022-06-23 05:27:13.492841
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml import from_yaml

    a = from_yaml("test: !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  663730316561366132613665623961613863336332373037666630633539356237633162303561\n  3065346636373665376233316132626331643238\n  626439346265643465633131663766643637636532323766363935336431633761656363306437\n", AnsibleConstructor)
    assert a['test'].data == {'vault_password': '12345'}

# Generated at 2022-06-23 05:27:15.522761
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # TODO: write test code
    #assert False, "Test if this is really a AnsibleConstructor instance"
    pass

# Generated at 2022-06-23 05:27:24.849982
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = r"""
-   one
-   two
-   three
"""

    seq = AnsibleLoader(data, file_name='test_file').get_single_data()

    assert isinstance(seq, list)

    assert seq[0].ansible_pos == ('test_file', 2, 5)
    assert seq[1].ansible_pos == ('test_file', 3, 5)
    assert seq[2].ansible_pos == ('test_file', 4, 5)

    assert seq[0] == 'one'
    assert seq[1] == 'two'
    assert seq[2] == 'three'


# Generated at 2022-06-23 05:27:35.660758
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

# Generated at 2022-06-23 05:27:39.231151
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = '''\
key1: myvalue1
key2: myvalue2
key3: myvalue3
'''

    loader = AnsibleConstructor()
    result = loader.get_single_data(data)
    assert result.ansible_pos == ("<string>", 1, 1)



# Generated at 2022-06-23 05:27:47.373670
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ''' Unit test for method construct_yaml_seq of class AnsibleConstructor '''

    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Set YAML document to test
    #
    # This YAML document is a simple list, with comments above and below each entry in the list
    # This should test the case where each individual YAML node is processed
    data = '''
# A list of dog names
- Rex
- Bobo
# Another list of dog names
- Buddy
- Jack
'''

    # Call the method to test
    stream = yaml.load(data, Loader=AnsibleLoader)

    num_entries = len(stream)

    assert num_entries == 4

# Generated at 2022-06-23 05:27:56.917564
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = {'a_key': 'a_value', 'another_key': 'another_value'}
    data_to_test = yaml.dump(data)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(yaml.compose(data_to_test))
    data_to_test = yaml.load(data_to_test)
    assert isinstance(data_to_test['a_key'], AnsibleUnicode)
    assert isinstance(data_to_test['another_key'], AnsibleUnicode)


# Generated at 2022-06-23 05:28:08.444453
# Unit test for method construct_yaml_str of class AnsibleConstructor

# Generated at 2022-06-23 05:28:19.374765
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    from yaml.nodes import MappingNode

    # We will be constructing a dictionary, so we need a MappingNode
    mapping = MappingNode(u'tag:yaml.org,2002:map')

    # Add a key
    key = u'key'

    # Add a value
    value = u'value'

    # Add the node to the mapping
    mapping.value = [(key, value)]

    # Instantiate the class
    constructor = AnsibleConstructor()

    # Invoke the method construct_yaml_unsafe
    result = constructor.construct_yaml_unsafe(mapping)

    # We expect that the result will be a dictionary
    assert isinstance(result, dict) is True

    # The key of the dictionary should be 'key'
    assert result.keys()[0] == key

    # The value of

# Generated at 2022-06-23 05:28:30.126079
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.composer import Composer
    from yaml.constructor import Constructor
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.resolver import Resolver
    from yaml.scanner import Scanner

    yaml = '''
    - !unsafe |-
          <html>
              <body>
                  <h1>Hello, world!</h1>
              </body>
          </html>
    '''

    stream = Reader(yaml)
    parser = Parser(stream)
    composer = Composer(parser)
    constructor = AnsibleConstructor()
    resolver = Resolver(constructor)
    scanner = Scanner(stream, resolver)
    constructor.scanner = scanner

# Generated at 2022-06-23 05:28:38.977896
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    def _get_constructor_class(constructor):
        import inspect
        return inspect.getmro(constructor.__class__)[0]

    # get an instance of AnsibleConstructor
    import yaml
    loader = yaml.Loader('')
    constructor = loader.constructor
    assert constructor
    # validate that the class of constructor is AnsibleConstructor
    assert _get_constructor_class(constructor) == AnsibleConstructor
    # validate that the class of constructor is BaseConstructor
    assert _get_constructor_class(constructor._baseconstructor) == yaml.constructor.BaseConstructor

# Generated at 2022-06-23 05:28:47.718693
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    data = """
a:
  b:
    c:
      d: 1
      e: 2
      f: 3
  b:
    c:
      g: 1
      h: 2
      i: 3
"""
    yaml_obj = yaml.load(data, Loader=AnsibleConstructor)

    assert yaml_obj == {
        'a': {
            'b': {
                'c': {
                    'g': 1,
                    'h': 2,
                    'i': 3
                }
            }
        }
    }
    
    #raise Exception(dir(yaml_obj))
    #assert yaml_obj.ansible_pos == (None, 1, 1)

# Generated at 2022-06-23 05:28:56.955192
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Setup the test data
    test_data = StringIO.StringIO('mystring: hello   \nmylist: [1,2,3,4]\n')
    test_ansible_constructor = AnsibleConstructor()

    # Test for the mapping node
    # Test for the constructor error
    try:
        test_ansible_constructor.construct_mapping('test')
        assert False
    except ConstructorError as e:
        assert True

    # Test for the normal flow
    expected_result = AnsibleMapping({u'mystring': u'hello', u'mylist': [1, 2, 3, 4]})
    result = test_ansible_constructor.construct_mapping(test_data)
   

# Generated at 2022-06-23 05:29:06.880117
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import datetime
    # ansible_unsafe is False by default
    load = get_loader('!unsafe')
    dump = get_dumper()
    assert isinstance(
        load([datetime.datetime.min])[0],
        AnsibleConstructor.construct_yaml_unsafe(load.yaml_loader.constructor.construct_undefined(None))
    )
    assert isinstance(
        load([datetime.datetime.min])[0],
        dump(AnsibleConstructor.construct_yaml_unsafe(load.yaml_loader.constructor.construct_undefined(None)), Dumper=AnsibleDumper)[0]
    )

# Generated at 2022-06-23 05:29:18.325746
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import textwrap


# Generated at 2022-06-23 05:29:19.697758
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    a = AnsibleConstructor()



# Generated at 2022-06-23 05:29:31.100608
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import StringIO

    # Construct a mock sys.modules dictionary
    m_modules = {}
    if 'ansible.parsing.yaml.objects' in sys.modules:
        m_modules['ansible.parsing.yaml.objects'] = sys.modules['ansible.parsing.yaml.objects']
    if 'ansible.parsing.vault' in sys.modules:
        m_modules['ansible.parsing.vault'] = sys.modules['ansible.parsing.vault']
    if 'ansible.parsing.yaml.loader' in sys.modules:
        m_modules['ansible.parsing.yaml.loader'] = sys.modules['ansible.parsing.yaml.loader']

# Generated at 2022-06-23 05:29:31.941788
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    assert 0

# Generated at 2022-06-23 05:29:38.349373
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    c = AnsibleConstructor(file_name='hello')
    testMappingNode = MappingNode(u'tag:yaml.org,2002:map', [])
    testMappingNode.start_mark.line = 9
    testMappingNode.start_mark.column = 8
    data = c.construct_yaml_map(testMappingNode)
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos == ('hello', 10, 9)


# Generated at 2022-06-23 05:29:47.100775
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Loading data
    input_file = r'C:\Users\santosh.sai\Documents\GitHub\ansible-pratice\yaml\test_AnsibleConstructor_construct_yaml_seq.yml'
    #input_file = 'test_AnsibleConstructor_construct_yaml_seq.yml'
    file = open(input_file, 'r').read()
    # printing the original data
    print("The original data is : ", file)
    # opening a saved ansible_construct object
    data_dict = yaml.load(file, Loader=yaml.FullLoader)
    # printing the original data
    print("The new data is : ", data_dict)
    # printing all the keys and values of the data_dict
    print("The keys and values are : ")
   

# Generated at 2022-06-23 05:29:48.981975
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    # TODO: add in some tests for AnsibleConstructor and AnsibleUnicode
    pass

# Generated at 2022-06-23 05:30:01.102656
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    AnsibleConstructor = AnsibleLoader(vault_secrets=None)
    # Test unicode string
    node_unicode = AnsibleUnicode('ascii')
    ansible_constructor = AnsibleConstructor.construct_yaml_str(node_unicode)
    assert ansible_constructor == 'ascii'
    # Test empty string
    node_unicode = AnsibleUnicode('')
    ansible_constructor = AnsibleConstructor.construct_yaml_str(node_unicode)
    assert ansible_constructor == ''

# Generated at 2022-06-23 05:30:10.732046
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = '''
boolean: true
list:
  - item1
  - item2
map:
  key-a: value-a
  key-b:
    nested-key-a: value-a
    nested-key-b: value-b
multiple_value:
  - value1
  - value2
string: a string
'''
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = ansible_constructor.construct_yaml_map(yaml.compose(data))
    # Test if the return value of method construct_yaml_map is an instance of AnsibleMapping
    assert isinstance(ansible_mapping, AnsibleMapping)
    # Test if the return value of method construct_yaml_map is a mapping

# Generated at 2022-06-23 05:30:21.927415
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # If a vault password is provided, then !vault-encrypted message should be decrypted and returned
    vaultLib = TestVaultLib("password123")

# Generated at 2022-06-23 05:30:28.817271
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    # Test safe constructor
    parser = AnsibleConstructor(file_name=None, vault_secrets=None)
    node_data = '!unsafe \'$var=true\''
    unsafe_var = parser.construct_yaml_unsafe(node_data)

    assert unsafe_var['__ansible_unsafe'] == True
    assert isinstance(unsafe_var, dict)

# Test parsing of vault file

# Generated at 2022-06-23 05:30:40.793862
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = u'%YAML 1.1\n---\n!!python/unicode "Hello: \u263a\\n"\n'
    yaml_str_bom = u'\uFEFF%YAML 1.1\n---\n!!python/unicode "Hello: \u263a\\n"\n'
    raw_value = 'Hello: \u263a\n'
    obj = AnsibleConstructor()

    actual_result = obj.construct_yaml_str(yaml_str)
    assert isinstance(actual_result, AnsibleUnicode), 'AnsibleConstructor().construct_yaml_str does not returned an AnsibleUnicode object'

# Generated at 2022-06-23 05:30:50.489523
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    """
    Unit test for AnsibleConstructor class
    """
    from ansible.parsing.yaml.loader import AnsibleLoader

    class FakeVaultSecret(object):
        def __init__(self, passwd):
            self.password = passwd

    unittest.TestCase.maxDiff = None
    # pylint: disable=bad-whitespace

# Generated at 2022-06-23 05:31:00.438930
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    import sys
    import unittest
    from ansible.compat.tests import mock
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    class TestVaultLib(VaultLib):
        def __init__(self, secrets=None):
            super(TestVaultLib, self).__init__(secrets=secrets)
        def decrypt(self, bytes_data):
            return bytes_data


# Generated at 2022-06-23 05:31:12.240600
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test the condition when node is not a MappingNode
    node = "AnsibleConstructor"
    ac = AnsibleConstructor()
    ex = None
    try:
        ac.construct_yaml_map(node)
    except Exception as e:
        ex = e
    assert hasattr(ex, 'problem')
    assert ex.problem == "expected a mapping node, but found " + "AnsibleConstructor"

    # Test the condition when key is hashable
    node = MappingNode("tag:yaml.org,2002:map", [], True, None, None, None)
    ac = AnsibleConstructor()
    ex = None
    try:
        ac.construct_yaml_map(node)
    except Exception as e:
        ex = e
    assert not hasattr(ex, 'problem')

   

# Generated at 2022-06-23 05:31:21.212088
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    #  Basic test with no duplicate keys
    node = MappingNode(
        'tag:yaml.org,2002:map',
        [
            (
                ScalarNode(
                    'tag:yaml.org,2002:str',
                    u'name'),
                ScalarNode(
                    'tag:yaml.org,2002:str',
                    u'storage')),
            (
                ScalarNode(
                    'tag:yaml.org,2002:str',
                    u'rid'),
                ScalarNode(
                    'tag:yaml.org,2002:int',
                    u'0'))
        ])
    res = AnsibleConstructor().construct_mapping(node)
    #  Ensuring the order of the result doesn't matter

# Generated at 2022-06-23 05:31:31.722608
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # first test: don't have a duplicate dict key
    s = "---\n" \
        "foo: 'bar'\n" \
        "test: 'hello'\n"
    result = AnsibleLoader(s).get_single_data()
    assert result['foo'] == u'bar'
    assert result['test'] == u'hello'

    # second test: have duplicate dict key.
    s = "---\n" \
        "foo: 'bar'\n" \
        "foo: 'hello'\n"
    result = AnsibleLoader(s).get_single_data()
    assert result['foo'] == u'hello'

    # second test: have duplicate dict key.

# Generated at 2022-06-23 05:31:38.476449
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    class Node:
        def __init__(self, id, start_mark):
            self.id = id
            self.start_mark = start_mark

    class Mark:
        def __init__(self, column, line, name):
            self.column = column
            self.line = line
            self.name = name

    node = Node(u'object', Mark(0, 0, u'<file>'))
    ac = AnsibleConstructor()

    assert ac.construct_yaml_unsafe(node) == 42