

# Generated at 2022-06-23 05:21:44.843786
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [ 'secret1' ]
    string_to_encrypt = 'password'
    vault = VaultLib(vault_secrets)
    encrypted_string = vault.encrypt(string_to_encrypt)
    ascii_encrypted_string = encrypted_string.encode('ascii')
    node = YAML().compose(ascii_encrypted_string)
    ansibleConstructor = AnsibleConstructor(file_name=None, vault_secrets=vault_secrets)
    encrypted_unicode = ansibleConstructor.construct_vault_encrypted_unicode(node)
    decrypted_string = encrypted_unicode.vault.decrypt(encrypted_unicode)
    assert decrypted_string == string_to_encrypt



# Generated at 2022-06-23 05:21:52.907029
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_yaml_no_warning = "test_key1: value1\ntest_key2: value2\ntest_key3: value3\n"
    test_yaml_warning = "test_key1: value1\ntest_key2: value2\ntest_key3: value3\n" \
                        "test_key2: value5\n"
    test_yaml_error = "test_key1: value1\ntest_key2: value2\ntest_key3: value3\n" \
                      "test_key2: value5\n" \
                      "test_key2: value6\n"

# Generated at 2022-06-23 05:22:03.909369
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.dataloader import DataLoader
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test input/output
    yaml_unsafe_input = b'foo: !unsafe 1\nbar: !unsafe test'
    yaml_unsafe_output = {u'foo': 1, u'bar': u'test'}

    # check if output is valid
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(yaml_unsafe_input)
    tmp_file.close()

    data = DataLoader().load_from_file(tmp_file.name)
    assert data == yaml_unsafe_output

    # remove temp file
   

# Generated at 2022-06-23 05:22:12.026750
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    import tempfile
    import os
    fd, fname = tempfile.mkstemp()
    os.write(fd, b"tests: |\n" + b"  !encrypt this is the data")
    os.close(fd)
    with open(fname) as testf:
        rdata = yaml.load(testf, Loader=AnsibleConstructor)
    os.unlink(fname)
    assert isinstance(rdata['tests'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:22:16.048714
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constr = AnsibleConstructor()
    assert 'test' in constr.construct_mapping({'test': 'value'})

# Generated at 2022-06-23 05:22:26.247144
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import io
    data = """
    ---
    - config:
      - key1: value1
      - key2: value2
      - key3: value3
    """
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._ansible_file_name = "blank"
    import yaml
    yaml_object = yaml.load(data, Loader=yaml.loader.BaseLoader)
    assert yaml_object[0]['config'] == [
        {'key1': 'value1'},
        {'key2': 'value2'},
        {'key3': 'value3'}
    ]


# Generated at 2022-06-23 05:22:32.042297
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import collections
    import yaml
    ansible_constructor = AnsibleConstructor()
    ret = ansible_constructor.construct_yaml_seq(yaml.nodes.SequenceNode('seq',[]))
    assert isinstance(ret, collections.Iterator)
    ansible_sequence = next(ret)
    assert isinstance(ansible_sequence, AnsibleSequence)
    assert len(ansible_sequence) == 0


# Generated at 2022-06-23 05:22:43.309054
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import sys
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch


# Generated at 2022-06-23 05:22:54.379525
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    class MyYAMLObject(AnsibleBaseYAMLObject):
        pass
    import shutil
    import tempfile
    basedir = tempfile.mkdtemp()
    tmpfile = tempfile.mkstemp(dir=basedir)
    shutil.copyfile('test/sanity/test_yaml_constructor.yaml', tmpfile[1])
    with open(tmpfile[1]) as f:
        data = AnsibleLoader(f, file_name=tmpfile[1]).get_single_data()
    # test that normal data returns as AnsibleUnicode

# Generated at 2022-06-23 05:23:01.178592
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    const = AnsibleConstructor()
    # str
    node = (yield str)
    # unicode
    node = (yield u'unicode')
    # AnsibleUnicode
    node = (yield AnsibleUnicode(u'AnsibleUnicode1'))
    # AnsibleUnicode
    node = (yield AnsibleUnicode(u'AnsibleUnicode2'))
    assert isinstance(node, AnsibleUnicode)
    assert node == u'AnsibleUnicode2'

# Generated at 2022-06-23 05:23:12.319576
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Creating object of class AnsibleConstructor to test method construct_vault_encrypted_unicode
    AnsibleConstructor_object = AnsibleConstructor()
    # Creating object of class MappingNode to call the construct_object method of class AnsibleConstructor
    node = MappingNode()
    # Calling the method construct_scalar of class AnsibleConstructor
    value = AnsibleConstructor_object.construct_scalar(node)
    # Converting value to bytes format
    b_ciphertext_data = to_bytes(value)
    # Could pass in a key id here to choose the vault to associate with
    # TODO/FIXME: plugin vault selector
    vault = AnsibleConstructor_object._vaults['default']
    # Checking if vault secrets are provided or not
    if vault.secrets is None:
        raise Constructor

# Generated at 2022-06-23 05:23:20.083395
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml import objects
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes, to_text

    class FakeSafeConstructor(AnsibleConstructor):
        object = object()

        def construct_object(self, node):
            return FakeSafeConstructor.object

        def construct_scalar(self, node):
            return to_text(FakeSafeConstructor.object)

    vault_lib = VaultLib(secrets=[u"test"])
    encrypted_vault_node_value = objects.VaultEncryptedUnicode(vault_lib.encrypt(u"test"))
    ciphertext_data = encrypted_vault_node_value.c

# Generated at 2022-06-23 05:23:25.212391
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    constructed_object = None
    ansible_constructor = AnsibleConstructor()
    node = None
    # the following should throw no exceptions
    constructed_object = ansible_constructor.construct_yaml_seq(node)

    assert constructed_object is not None, "construct_yaml_seq did not return anything"
    # TODO: how to test that the expected attribute ansible_pos is set on constructed_object.



# Generated at 2022-06-23 05:23:33.903454
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os

    class mock_node:

        def __init__(self):
            from mock import Mock
            self.construct_scalar = Mock(return_value="test_construct_scalar")
            self.start_mark = Mock(name="test_start_mark_name", line=123, column=456)
            self.id = Mock(return_value="test_id")

    class mock_Secret():
        def __init__(self, password, salt=None, hmac_salt=None, iterations=None):
            self.password = password

    ac = AnsibleConstructor(file_name="test_AnsibleConstructor_construct_vault_encrypted_unicode.yaml",
                            vault_secrets=[mock_Secret("test_vault_password")])
    cn = mock

# Generated at 2022-06-23 05:23:43.337925
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import io
    import sys
    import yaml
    from yaml.parser import ParserError

    display.verbosity = 3
    display.deprecated_warning = True
    display.deprecated_import_warning = True
    display.deprecated_assert_warning = True
    display.deprecated_always_warn = True
    display.always_custom_warnings = False

    # Run tests for class AnsibleConstructor, method construct_yaml_seq
    # AnsibleConstructor.construct_yaml_seq()
    # We first check if each test works on its own and that subsequent tests,
    # which may depend on earlier tests, do not break.

    # Test 1:
    # Test a list containing a dictionary where the dictionary contains two keys,
    # "key1" and "key2", which are mapped to different values.

# Generated at 2022-06-23 05:23:44.327772
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    pass



# Generated at 2022-06-23 05:23:50.088114
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_src = '''
one:
  - 2
  - 3
'''
    yaml_obj = yaml.load(yaml_src, Loader=AnsibleConstructor)
    assert isinstance(yaml_obj['one'][0], AnsibleUnicode)
    assert isinstance(yaml_obj['one'][1], AnsibleUnicode)


# Generated at 2022-06-23 05:23:59.867837
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml import Loader, nodes
    from ansible.parsing.yaml import objects
    import sys
    class FakeLoader(Loader):
        def __init__(self, stream):
            Loader.__init__(self, stream)
            self._root_id_placer_holder = None
            self._is_python_2 = sys.version_info < (3, 0)
        def get_root_id_placer(self):
            return self._root_id_placer_holder
        def set_root_id_placer(self, value):
            self._root_id_placer_holder = value

    class FakeNode(nodes.ScalarNode):
        def __init__(self, value, tag=u'tag:yaml.org,2002:str'):
            nodes.Scalar

# Generated at 2022-06-23 05:24:07.086174
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # test variable declarations
    testValue = dict()
    testValue["key_1"] = "value_1"
    testValue["key_2"] = "value_2"

    # test method call
    data = AnsibleConstructor.construct_yaml_map(AnsibleConstructor(), None)
    # test result
    assert(isinstance(data, dict) == True)
    assert(data == dict())



# Generated at 2022-06-23 05:24:15.365548
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    # Python 2 and 3 compatibility
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    src = {'key': 'value', 'list': [1, 2, 3], 'dict': {'foo': 'bar'}}

    # Convert using AnsibleDumper
    sio = BytesIO()
    AnsibleDumper(sio, default_flow_style=False).dump(src)
    data = sio.getvalue()

    # Wrap vars using unsafe

# Generated at 2022-06-23 05:24:18.535734
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Test that the AnsibleConstructor class can be instatiated and used
    """
    constructor = AnsibleConstructor()
    constructor_dict = constructor.construct_mapping(None)
    assert isinstance(constructor_dict, AnsibleMapping)

# Generated at 2022-06-23 05:24:29.047686
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib

    yaml_str = "{test1: yes, test2: no, test3: {test4: 3, test5: 4}}"

    ac = AnsibleConstructor()
    data = ac.construct_yaml(yaml_str)
    assert isinstance(data, AnsibleMapping)
    assert data.get("test2") == "no"
    assert isinstance(data.get("test3"), AnsibleMapping)
    assert data.get("test3").get("test5") == "4"
    assert data.ansible_pos == (None, 1, 1)
    assert data.get("test3").ans

# Generated at 2022-06-23 05:24:38.170150
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class FakeConstructor(AnsibleConstructor):
        def construct_scalar(self, node):
            return AnsibleUnicode('test')

    s = '''
- 0
- 1
  - 2
- 3
    '''
    data = AnsibleLoader(StringIO(s), FakeConstructor).get_single_data()

    assert data[0] == 'test'
    assert data[1] == 'test'
    assert data[2][0] == 'test'
    assert data[3] == 'test'

# Generated at 2022-06-23 05:24:48.791376
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import yaml
    yaml_str = '''
a:
  - 1
  - 2
'''
    yaml_seq = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert(isinstance(yaml_seq, AnsibleBaseYAMLObject))
    assert(len(yaml_seq) == 1)
    yaml_seq_item = yaml_seq.popitem()
    assert(yaml_seq_item[0] == 'a')
    assert(len(yaml_seq_item[1]) == 2)

# Generated at 2022-06-23 05:24:57.946992
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import sys
    import os
    import unittest
    import yaml

    lib_paths = [ '../..' ]
    for path in lib_paths:
        full_path = os.path.abspath(os.path.expanduser(path))
        sys.path.append(full_path)

    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-23 05:25:02.416918
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    yaml_str = '''
        - 1
        - 2
    '''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data == [1, 2], "Invalid result: {}".format(data)
    assert type(data) == AnsibleSequence
    assert data.ansible_pos == ('<string>', 1, 0)



# Generated at 2022-06-23 05:25:12.952563
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class Helpers(object):
        def __init__(self):
            self.__class__ = type(self).__class__
            self.helpers = dict()
    vault = VaultLib(secrets=['test'])
    params = dict()
    params['vault'] = vault
    params['helpers'] = Helpers()
    params['file_name'] = None
    ansible_constructor = AnsibleConstructor(**params)

# Generated at 2022-06-23 05:25:22.649650
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import datetime
    from collections import namedtuple

    data = {
        'bool': True,
        'none': None,
        'int': 1,
        'float': 1.0,
        'complex': 1.2-3.4j,
        'text': 'string',
        'time': datetime.datetime.now(),
        'tuple': (1, 2, 3),
        'list': ['a', 'b', 'c'],
        'dict': {'key': 'value'},
        'obj': namedtuple('obj', ['x', 'y'])(1, 2),
    }
    for d in data.items():
        assert AnsibleConstructor.construct_yaml_unsafe(d).obj == d[1]


# class AnsibleConstructorTestCase(unittest.TestCase):

# Generated at 2022-06-23 05:25:26.704837
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    file_name = '/path/to/my/ansible/file'
    c = AnsibleConstructor(file_name)

    assert c._ansible_file_name == file_name


# Generated at 2022-06-23 05:25:34.813715
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    try:
        from ansible.parsing.yaml.loader import AnsibleLoader
        from ansible.parsing.yaml.dumper import AnsibleDumper
        from ansible.parsing.yaml.position import Position
    except ImportError:
        # skip test if yaml library is not available
        return

    dumper = AnsibleDumper(width=50)
    dumper.ignore_aliases = lambda *args: True
    yaml = """
    ---
    a_mapping:
        key: value
        the_answer: 42
        enabled: true
        amount: 3
        nested:
            a: '123'
            b: '456'
    """
    obj = AnsibleLoader(yaml, file_name='<string>').get_single_data()

# Generated at 2022-06-23 05:25:43.349473
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    map = """\
        a: 1
        b: 2
    """
    ansible_constructor = AnsibleConstructor()
    nodelist = list(yaml.compose(map, Loader=yaml.Loader))
    # result is a generator object, we need to make a list out of it
    result = list(ansible_constructor.construct_yaml_map(nodelist[0]))
    assert isinstance(result[0], dict)
    assert len(result[0]) == 2
    assert result[0]['a'] == 1
    assert result[0]['b'] == 2


# Generated at 2022-06-23 05:25:51.940955
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    class AnsibleConstructorTestCase(unittest.TestCase):

        def test_construct_yaml_map(self):

            # Testing with string
            test_data = "a"
            result = AnsibleConstructor.construct_yaml_map(test_data)
            self.assertEqual(result, "a")

        def test_construct_mapping(self):

            # Testing with string
            test_data = "a"
            result = AnsibleConstructor.construct_mapping(test_data)
            self.assertEqual(result, "a")

        def test_construct_yaml_str(self):

            # Testing with string
            test_data = "a"
            result = AnsibleConstructor.construct_yaml_str(test_data)
            self.assertEqual(result, "a")



# Generated at 2022-06-23 05:26:03.190347
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test the construct_yaml_unsafe method of class AnsibleConstructor
    # First test the default case
    assert AnsibleConstructor().construct_yaml_unsafe("foo") == "foo"

    # Test for the case when the yaml data is a list
    yaml_data = """
        - ['foo']
    """
    data = AnsibleLoader(yaml_data, file_name=None).get_single_data()
    assert data == ['foo']

    # Test for the case when the yaml data is a dict
    yaml_data = """
        {'foo':'bar'}
    """
    data = AnsibleLoader(yaml_data, file_name=None).get_single_data()

# Generated at 2022-06-23 05:26:08.468323
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import warnings

    class FakeUnsafe:
        def __call__(self, *args, **kwargs):
            return self

        def get(self, *args, **kwargs):
            return self

    constructor = AnsibleConstructor()
    node = FakeUnsafe()
    unsafe = constructor.construct_yaml_unsafe(node)

    assert unsafe.__class__.__name__ == 'AnsibleUnsafeText'
    assert unsafe.value is node

# Generated at 2022-06-23 05:26:18.053220
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-23 05:26:28.546832
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    from ansible.parsing.yaml.objects import AnsibleSequence

    cls = AnsibleConstructor(file_name="test", vault_secrets=['mysecrets'])

    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:int', '1')
    data = cls.construct_yaml_int(node)
    assert isinstance(data, int)
    assert data == 1

    node = yaml.nodes.MappingNode()
    data = cls.construct_yaml_map(node)
    assert isinstance(data, AnsibleMapping)
    assert data.ansible_pos == ('test', 1, 0)

    node = yaml.nodes.ScalarNode('tag:yaml.org,2002:str', '1')

# Generated at 2022-06-23 05:26:36.197649
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    f = open('/tmp/test_dump.yml', 'w')
    f.write('''
        - Test_Dict_1:
                Test_Dict_2:
                    Test_Dict_3: Test_Value_3
                    Test_Dict_4: Test_Value_4
                Test_Dict_5: Test_Value_6
            Test_Dict_6: Test_Value_6
        - Test_Dict_7: Test_Value_7
    ''')
    f.close()

    import yaml
    data = yaml.load(open('/tmp/test_dump.yml'), Loader=AnsibleConstructor)
    print(data)
    assert True

# Generated at 2022-06-23 05:26:47.221209
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    class MockVaultLib(object):
        def __init__(self, secrets=None):
            self.secrets = secrets

    class MockNode(object):
        def __init__(self, value, start_mark):
            self.value = value
            self.start_mark = start_mark

    class MockVaultNode(object):
        def __init__(self, value, start_mark):
            self.value = value
            self.start_mark = start_mark
            self.id = 'vault-encrypted'

    class MockNodeValue(object):
        def __init__(self, value):
            self.value = value

    class MockStartMark(object):
        def __init__(self, name, line, column):
            self.name = name
            self.line = line
            self.column = column



# Generated at 2022-06-23 05:26:51.766830
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    yaml_obj = yaml.load('''
[
    'test_key'
]
    ''', Loader=AnsibleConstructor)

    assert isinstance(yaml_obj[0], AnsibleUnicode)


# Generated at 2022-06-23 05:26:53.969147
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Some logic in this method can be tested only with interaction.
    # Can not call it directly because it is a generator.
    pass

# Generated at 2022-06-23 05:27:03.828948
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    import yaml
    from ansible.parsing.yaml import objects

    test_unicode_str = u'ÿøû'
    test_unicode_str_copy = '\xc3\xbf\xc3\xb8\xc3\xbb'
    test_unicode_str_copy = to_bytes(test_unicode_str_copy, encoding='utf-8')

    test_dict = dict(a=u'Iñtërnâtiônàlizætiøn',
                     b=test_unicode_str,
                     c=[test_unicode_str, test_unicode_str])


# Generated at 2022-06-23 05:27:04.969428
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    AnsibleConstructor.construct_yaml_unsafe()

# Generated at 2022-06-23 05:27:16.484304
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    class MockNode(object):
        def __init__(self, start_mark):
            self.start_mark = start_mark


# Generated at 2022-06-23 05:27:22.391967
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    b = to_bytes(u'[1, 2, 3]')
    a = AnsibleConstructor(file_name=None, vault_secrets=["password"])
    n = a.construct_yaml_node(a.get_parser(b).get_single_node())
    assert isinstance(n, AnsibleSequence)
    assert list(n) == [1, 2, 3]

# Generated at 2022-06-23 05:27:34.251394
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yamlobj = AnsibleConstructor()

    # yaml.org,2002:str
    class TestString(object):
        def __init__(self):
            self.tag = u'tag:yaml.org,2002:str'

    string = u'test'
    value = yamlobj.construct_yaml_str(TestString())
    assert len(value) == 4
    for x in range(4):
        assert value[x] == string[x]

    # yaml.org,2002:python/unicode
    class TestUnicode(object):
        def __init__(self):
            self.tag = u'tag:yaml.org,2002:str'

    unicode = u'\u00A9'
    value = yamlobj.construct_yaml_str(TestUnicode())


# Generated at 2022-06-23 05:27:36.528784
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_mapping is not None

# Generated at 2022-06-23 05:27:38.392207
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Call method
    node = u'[1, 2]'
    assert node == AnsibleConstructor().construct_yaml_seq(node)

# Generated at 2022-06-23 05:27:45.251439
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    test_str = u'myteststr'
    node = 1
    node.start_mark = 1
    node.start_mark.line = 1
    node.start_mark.column = 1
    node.start_mark.name = '/tmp/file.yml'
    test = AnsibleConstructor('/tmp/file.yml')
    result = test.construct_yaml_str(node)
    assert result == test_str
    assert result.ansible_pos == ('/tmp/file.yml', 2, 2)



# Generated at 2022-06-23 05:27:49.856427
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():

    import yaml

    ansible_yaml_str = """
    foo: !unsafe
      - !!python/object/apply:os.system
        - ls -al
    """

    data = yaml.load(ansible_yaml_str, Loader=AnsibleConstructor)

    assert isinstance(data, dict)
    assert isinstance(data['foo'], list)
    assert isinstance(data['foo'][0], wrap_var)

# Generated at 2022-06-23 05:28:00.693864
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
  yaml_seq = u"\n".join([
    u"- {a: 1}",
    u"- {b: 2}",
    u""])
  yaml_seq1 = u"\n".join([
    u"- {a: 1}",
    u"- {b: 2}"])
  yaml_seq2 = u"\n".join([
    u"-",
    u"-"])
  yaml_seq3 = u"".join([
    u"-",
    u"-"])
  yaml_seq4 = u"- 1\n"
  yaml_seqs = [yaml_seq1, yaml_seq2, yaml_seq3, yaml_seq4] 
  yaml_bad_seq = u"- a"

# Generated at 2022-06-23 05:28:11.120642
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.errors import AnsibleParserError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # The vault-encrypted data is created using a !vault line, not
    # a !vault-encrypted line.  So this is not the best test function.
    # https://github.com/ansible/ansible/issues/18897

    aconstructor = AnsibleConstructor()
    vault_password = 'password'


# Generated at 2022-06-23 05:28:15.129754
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert isinstance(AnsibleConstructor.construct_yaml_str(AnsibleConstructor, None), AnsibleUnicode)



# Generated at 2022-06-23 05:28:18.339273
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert AnsibleConstructor.construct_yaml_str(u'tag:yaml.org,2002:str', u'hello') == u'hello'



# Generated at 2022-06-23 05:28:22.223345
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml import AnsibleLoader
    obj = AnsibleLoader("{[0]}", file_name="/tmp/a").get_single_data()
    assert len(obj) == 1 and obj[0] == 0

# Generated at 2022-06-23 05:28:30.910793
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
	import sys
	import unittest
	import io

	if sys.version_info[:2] < (2, 7):
		import unittest2 as unittest
		from StringIO import StringIO
	else:
		from io import StringIO

	# This encryption key is the real one. Don't use for encrypted files!!!
	password = '3714f2ef4c4feb1d12f8f9e51e9d9ce4'

	class TestAnsibleConstructor(unittest.TestCase):
		def setUp(self):
			self.constructor = AnsibleConstructor()

		def test_AnsibleConstructor_construct_vault_encrypted_unicode(self):
			# encrypted string 'test'
			self.constructor.vault_

# Generated at 2022-06-23 05:28:38.514976
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # For example, a list of dict is not allowed.
    s = u"[{'a':1, 'b':2}, {'a':3, 'b':4}]"
    c = AnsibleConstructor(file_name="test_construct_mapping")
    # The exception is expected.
    try:
        c.construct_yaml_str(s)
    except ConstructorError:
        # The exception is expected.
        pass
    else:
        # The exception is expected.
        assert False

# Generated at 2022-06-23 05:28:47.988756
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Scenario 1: duplicate keys are ignored
    scenario1_node = [MappingNode(None, None, True, None, 20, None)]
    scenario1_node[0].value = [[MappingNode(None, None, True, None, 20, None), MappingNode(None, None, True, None, 20, None)],
                               [MappingNode(None, None, True, None, 20, None), MappingNode(None, None, True, None, 20, None)]
                               ]
    obj = AnsibleConstructor()
    obj.construct_mapping(scenario1_node)

    # Scenario 2: duplicate keys are warned
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    scenario2_node = [MappingNode(None, None, True, None, 20, None)]

# Generated at 2022-06-23 05:28:51.347037
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml
    data = '''---
- 1
- 2
- 3
    '''
    data_obj = yaml.load(data, Loader=AnsibleConstructor)
    assert isinstance(data_obj, list)
    assert data_obj == [1,2,3]

# Generated at 2022-06-23 05:28:59.863109
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml

    # Test with no vault_secrets
    loader = AnsibleLoader(None, False, vault_secrets=None)
    res = loader.construct_yaml_map(None)
    assert res.vault is None, 'res.vault should be None when no vault secrets are provided'

    vault_secrets = [{'key': 'my-secret'}]
    loader = AnsibleLoader(None, False, vault_secrets=vault_secrets)
    res = loader.construct_yaml_map(None)
    assert res.vault is not None, 'res.vault should not be None when vault secrets are provided'

    # Test encoding param


# Generated at 2022-06-23 05:29:09.031914
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # "ansible_pos" must be set in the constructed object
    from yaml.parser import Parser
    from yaml.scanner import Scanner

    test_data = u'# Test YAML\n- foo: bar\n  baz: qux'
    test_parser = Parser(Scanner(test_data))
    test_node = test_parser.get_single_node()

    test_constructor = AnsibleConstructor()
    test_object = test_constructor.construct_yaml_seq(test_node)
    assert test_object.ansible_pos == ('<unicode string>', 1, 0)
    assert next(test_object) == {}
    assert test_object.ansible_pos == ('<unicode string>', 1, 0)

# Generated at 2022-06-23 05:29:17.706016
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode(u'tag:yaml.org,2002:python/dict', [u'!vault'])
    node.start_mark = None
    node.end_mark = None
    node.value = [[u'password', u'password'], [u'password', u'password']]
    ansible_constructor._vaults['default'].secrets = u'password'
    password = ansible_constructor.construct_vault_encrypted_unicode(node)
    assert password == u'password'



# Generated at 2022-06-23 05:29:29.297377
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # create a test instance of AnsibleBaseYAMLObject
    class TestYamlObject(AnsibleBaseYAMLObject):
        pass

    test_yaml_obj_1 = TestYamlObject()
    test_yaml_obj_1.data = 'test_str_1'
    test_yaml_obj_1_anchor = 'test_yaml_obj_1'
    test_yaml_obj_2 = TestYamlObject()

# Generated at 2022-06-23 05:29:35.882892
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    a = AnsibleConstructor()
    # Test with an empty string
    n = a.construct_yaml_str(u'')
    assert(n == u''), 'Constructor returned unexpected value'
    # Test with a normal string
    n = a.construct_yaml_str(u'hello')
    assert(n == u'hello'), 'Constructor returned unexpected value'
    # Test with an integer
    try:
        n = a.construct_yaml_str(1)
    except ConstructorError:
        pass
    else:
        assert False, 'Constructor did not raise error for integer'

# Generated at 2022-06-23 05:29:41.616139
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ns = AnsibleConstructor()
    assert(isinstance(ns.construct_yaml_str(None), AnsibleUnicode))
# end of test_AnsibleConstructor_construct_yaml_str

# Generated at 2022-06-23 05:29:51.625178
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Create data for tests
    yaml_str = """
      - key: !unsafe 'value'
    """

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data[0], AnsibleMapping)
    assert isinstance(data[0][u'key'], AnsibleUnsafeText)

    # Ensure that a yaml node without an associated constructor, (or with a
    # constructor that doesn't call a super class), falls back to calling the
    # constructor for a generic yaml object


# Generated at 2022-06-23 05:29:54.007798
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    pass

if __name__ == '__main__':
    test_AnsibleConstructor()

# Generated at 2022-06-23 05:30:04.387394
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with no duplicate keys
    test_data = 'key1: value1\nkey2: value2'
    mapping = AnsibleConstructor.construct_yaml_map(test_data)
    assert mapping is not None
    assert mapping['key1'] == 'value1'
    assert mapping['key2'] == 'value2'

    # Test with duplicate keys
    orig_behavior = C.DUPLICATE_YAML_DICT_KEY

# Generated at 2022-06-23 05:30:08.271503
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # set up
    input = AnsibleConstructor()

    # function test
    # _node_position_info
    result1 = input._node_position_info(u'tag:yaml.org,2002:str')
    assert result1 == (None, 1, 0)

# Generated at 2022-06-23 05:30:10.592840
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    node = 'hello'
    value = AnsibleConstructor().construct_yaml_unsafe(node)
    assert value == wrap_var('hello')

# Generated at 2022-06-23 05:30:21.892763
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import tempfile
    import os.path

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, mode='w', delete=False)
    filename = tmpfile.name

    # Generate ciphertext
    vault = VaultLib(secrets=['secret'])
    test_string = u'unicode test data'
    ciphertext = vault.encrypt(test_string)
    tmpfile.write(u"!vault |\n  {0}".format(ciphertext.decode('utf-8')))
    tmpfile.close()

    # Parse file

# Generated at 2022-06-23 05:30:33.440864
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault = VaultLib()
    vault.secrets = ['123456']

# Generated at 2022-06-23 05:30:44.822917
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_data = """
        ---
        : this is a string
        : and so is this
        : and this: is " a string"
        : This is a multiline string
          that goes on for multiple lines
        : 'This is a string with a quote (\') and another quote (\') inside it'
        : "This is a string with a quote (') and an escaped quote (\\') inside it"
        : "This is a string with a quote (') and another quote (') inside it"
        : |-
          This is a string that contains
            multiple lines
          and some values
          such as:
            - value1
            - value2
    """


# Generated at 2022-06-23 05:30:53.478817
# Unit test for constructor of class AnsibleConstructor
def test_AnsibleConstructor():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.six import text_type
    from ansible.module_utils._text import to_native

    from io import StringIO

    class Vault(yaml.YAMLObject):
        yaml_loader = '!vault'
        yaml_tag = u'!vault'

        def __init__(self, ciphertext_data):
            super(Vault, self).__init__()
            self.ciphertext_data = ciphertext_data

        def __repr__(self):
            return 'Vault(ciphertext_data={0})'.format(to_native(self.ciphertext_data))


# Generated at 2022-06-23 05:31:05.585701
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import ansible.parsing.yaml.objects
    ansible.parsing.yaml.objects.AnsibleUnsafeText = AnsibleUnsafeText
    testdata = {'a': '{{ foo }}', 'b': 'bar'}
    testdata_as_yaml = u'---\na: {{ foo }}\nb: bar'
    if sys.version_info[0] > 2:
        testdata_as_yaml = testdata_as_yaml.encode('utf-8')
    testdata_as_yaml_unsafe = u'---\na: !unsafe "{{ foo }}"\nb: bar'
    if sys.version_info[0] > 2:
        testdata_as_yaml_unsafe = testdata_as_yaml_unsafe.encode

# Generated at 2022-06-23 05:31:16.225055
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    def test_construct_mapping(self):
        # using load rather than loads as in the actual code
        # so that we can pass an actual file handle to it
        node = yaml.load(test_data)
        ret = self.construct_mapping(node)
        assert_equal(ret['key3']['key4'], 'val4')
        assert_equal(ret['key3']['key5'], 'val5')

    class TestedConstructor(AnsibleConstructor):
        def _node_position_info(self, node):
            return ('myfile.yml', 1, 1)

    test_data = """key1: val1
key2: val2
key3:
  key4: val4
  key5: val5
"""

    from nose.tools import assert_equal

# Generated at 2022-06-23 05:31:29.324677
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    data = b'$ANSIBLE_VAULT;1.1;AES256\n3633316132306236633064646239326266616232323635643337336434363664306164383537393\n38393935653266373066323065333632363630323863323538643162626363336565326236316464\n3163376630376266643839'
    vault_secrets = ['faketestsecret']
    vc = AnsibleConstructor(None, vault_secrets)
    # with MappingNode
    node = MappingNode()
    node.value = []
    node.tag = u'!vault'
    node.start_mark = object()
    node.end_mark = object()
    ret = vc.construct_

# Generated at 2022-06-23 05:31:31.768951
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    assert AnsibleConstructor.construct_vault_encrypted_unicode == AnsibleConstructor.construct_vault_encrypted_unicode

# Generated at 2022-06-23 05:31:41.101618
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = u"""
---
foo: bar
baz:
- bar
- baz
- foo
bar:
  - baz
  - foo
  - bar
"""
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    yaml_obj = AnsibleBaseYAMLObject(yaml_data)

    yaml_data = u"""
---
foo: bar
bar:
  - baz
  - foo
  - bar
baz:
- bar
- baz
- foo
"""
    # Try to find out if using different order of keys will
    # change the position of the error.