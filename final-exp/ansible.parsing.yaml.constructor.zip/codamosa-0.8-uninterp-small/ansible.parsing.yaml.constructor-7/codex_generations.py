

# Generated at 2022-06-25 04:21:46.385435
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    obj = AnsibleConstructor()
    obj.construct_yaml_unsafe()


# Generated at 2022-06-25 04:21:58.083010
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml import objects
    from ansible.module_utils._text import to_bytes, to_text
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:21:58.984512
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_case_0()


# Generated at 2022-06-25 04:22:00.080540
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_case_0()


# Generated at 2022-06-25 04:22:05.337744
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Decode the same string as in ansible.parsing.yaml.objects.__init__
    # with pyyaml 3 and 4.
    s = '{key1: val1, key2: val2}'
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping({}, node=s)

# Generated at 2022-06-25 04:22:12.625804
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    my_vault_data = """$ANSIBLE_VAULT;1.1;AES192
636339376463303564303537663739316563306332346263656262373165656631643764646335
386130623265373937613461366337623366373436393336
"""
    import yaml
    nodelist = list(yaml.compose(my_vault_data))
    assert len(nodelist) == 1
    my_node = nodelist[0]
    my_ret = ansible_constructor_0.construct_vault_encrypted_unicode(my_node)
    assert isinstance(my_ret, AnsibleVaultEncryptedUnicode)
    import ansible

# Generated at 2022-06-25 04:22:16.088423
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_case_0()


# Generated at 2022-06-25 04:22:23.426451
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    arg = type('Args', (object,), {'value': type('Value', (object,), {'id': 'value', 'start_mark': type('StartMark', (object,), {'line': 2, 'column': 3, 'name': 'name'}), 'value': list})})()
    result = ansible_constructor.construct_yaml_map(arg)
    assert True



# Generated at 2022-06-25 04:22:33.771761
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = "secret"
    test_case = """$ANSIBLE_VAULT;1.1;AES256
6534306465363864386636346237633730313661316262623163396266376164616437353531636436
3464393234313233613939356562653865303835336334316164626535613039663430346639383366
31356161
"""
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = [ vault_password ]
    vault_encrypted_unicode_instance = ansible_constructor_0.construct_vault_encrypted_unicode( test_case )

# Generated at 2022-06-25 04:22:35.047546
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    yaml_data = u"{'group_vars/all': ['hosts']}\n"
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_unsafe(yaml_data)

# Generated at 2022-06-25 04:22:45.971316
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:22:51.140775
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    node = object()
    deep = object()
    ansible_constructor.construct_mapping(node, deep)

# Generated at 2022-06-25 04:23:00.761485
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    with pytest.raises(ConstructorError) as exc_info:
        ansible_constructor_1 = AnsibleConstructor()
        value = 'secret_text'
        b_ciphertext_data = b'secret_text'
        node = 'node'
        ansible_constructor_1.construct_vault_encrypted_unicode(node)
    assert exc_info.value.args[0] == 'found !vault but no vault password provided'
    assert exc_info.value.args[1] == 'node'
    assert exc_info.value.args[2] == 'node'
    assert exc_info.value.args[3] == None
    assert exc_info.value.args[4] == None



# Generated at 2022-06-25 04:23:05.424971
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0.construct_mapping(MappingNode()), AnsibleMapping)


# Generated at 2022-06-25 04:23:10.459889
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    str_node_0 = AnsibleUnicode("This is sample text.")
    assert_equal(ansible_constructor_0.construct_yaml_str(str_node_0), "This is sample text.")

# Generated at 2022-06-25 04:23:14.442116
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    #First test
    data_1 = AnsibleMapping()
    ansible_constructor_1 = AnsibleConstructor()
    node_1 = MappingNode("foo", "bar", None, None)
    value_1 = ansible_constructor_1.construct_mapping(node_1)
    data_1.update(value_1)
    data_1.ansible_pos = ansible_constructor_1._node_position_info(node_1)
    assert data_1 == {}


# Generated at 2022-06-25 04:23:16.460839
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode
    m = MappingNode("test", [], [], None)
    actual = AnsibleConstructor().construct_yaml_map(m)
    assert list(actual) == [{}]


# Generated at 2022-06-25 04:23:17.643527
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_yaml_unsafe()

# Generated at 2022-06-25 04:23:18.054495
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    pass

# Generated at 2022-06-25 04:23:19.737011
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    result = ansible_constructor_0.construct_mapping()
    assert result is None


# Generated at 2022-06-25 04:23:28.473099
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_case_0()

# Generated at 2022-06-25 04:23:30.511442
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node = AnsibleConstructor.construct_yaml_seq(ansible_constructor, "test_node")


# Generated at 2022-06-25 04:23:36.401522
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    extra = { 'ansible_pos': ('myfile', 1, 1) }
    mapping = ansible_constructor.construct_mapping(MappingNode(1, 1, []), extra)
    assert mapping.ansible_pos == ('myfile', 1, 1)


# Generated at 2022-06-25 04:23:44.067681
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    AnsibleMapping.yaml_base_tag = u'tag:yaml.org,2002:map'
    AnsibleMapping.yaml_tag = u'tag:yaml.org,2002:map'
    AnsibleMapping.yaml_loader = u'FullLoader'
    AnsibleMapping.yaml_dumper = u'Dumper'
    node = AnsibleMapping()
    result = ansible_constructor_0.construct_yaml_seq(node)
    assert result is not None


# Generated at 2022-06-25 04:23:47.151502
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node = AnsibleConstructor.construct_yaml_seq()
    # assert that the methods returns the correct value
    assert ansible_constructor.construct_yaml_seq(node) == ansible_constructor.construct_yaml_seq()


# Generated at 2022-06-25 04:23:54.611678
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_node = AnsibleConstructor.construct_yaml_map()
    ansible_vaults = {'default': VaultLib(secrets=None)}
    ansible_constructor = AnsibleConstructor(vault_secrets=None)
    ansible_constructor._vaults = ansible_vaults
    assert_raises(ConstructorError, ansible_constructor.construct_vault_encrypted_unicode, ansible_node)

# Generated at 2022-06-25 04:24:00.464519
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    ansible_constructor_1 = AnsibleConstructor()

    assert ansible_constructor_1 is not None
    assert isinstance(ansible_constructor_1, AnsibleConstructor)

    mapping_node_1 = MappingNode(value=[])

    ansible_mapping_1 = ansible_constructor_1.construct_mapping(mapping_node_1, deep=False)




# Generated at 2022-06-25 04:24:03.263791
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    ansible_constructor_1 = AnsibleConstructor()
    data = dict()
    with pytest.raises(ConstructorError):
        ansible_constructor_1.construct_yaml_seq(data)


# Generated at 2022-06-25 04:24:09.161626
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.add_vault_secret('invalid_secret')
    try:
        ansible_constructor.construct_vault_encrypted_unicode('C:123:!@#$:')
    except ConstructorError as e:
        assert e.problem == 'found !vault but no vault password provided'


# Generated at 2022-06-25 04:24:15.226487
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = {
        "foo": [
            "one"
        ],
        "bar": [
            "apple",
            "banana",
            "cherry"
        ]
    }

    loaded_data = AnsibleConstructor.construct_yaml_seq(yaml_data)
    assert isinstance(loaded_data, AnsibleSequence)
    for item in loaded_data:
        assert isinstance(item, AnsibleUnicode)


# Generated at 2022-06-25 04:24:25.946505
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:24:35.681375
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """
    Test that unsafe constructions work as expected, e.g. that we get back
    the node object, not a proxy.
    """
    ansible_constructor_1 = AnsibleConstructor()

    # Create some mock node objects to use for testing.  The node objects
    # (e.g. 'node_1') are passed in as the 'node' parameter to the
    # AnsibleConstructor.construct_yaml_unsafe method.

    # The construct_yaml_unsafe method returns whatever object is in the node
    # object's 'value' property.  So, we need to create a node object that
    # has a 'value' property containing the various objects we want to test.
    # For example, a node object with a value of a string, a node object with
    # a value that is a list, etc.

   

# Generated at 2022-06-25 04:24:41.573448
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_mapping(node=None, deep=None)


# Generated at 2022-06-25 04:24:52.901126
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()

    # Test with a valid vault passowrd
    vault_password = "This is my Vault password!"
    ansible_constructor_1.vault_secrets = [vault_password, ]
    # The following was generated with vault_id 'ansible-vault-test' and content 'This is test content!'

# Generated at 2022-06-25 04:24:54.391924
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq(1)


# Generated at 2022-06-25 04:24:58.456706
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    result = ansible_constructor.construct_yaml_str(node = '')
    assert isinstance(result, AnsibleUnicode) == True


# Generated at 2022-06-25 04:25:00.808355
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode()
    assert ansible_constructor.construct_yaml_map(node)



# Generated at 2022-06-25 04:25:08.783453
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

    vault_secrets = ['test_secret']

    # Assert that calling construct_vault_encrypted_unicode with None argument raises
    # TypeError exception
    with pytest.raises(TypeError):
        ansible_constructor.construct_vault_encrypted_unicode(None)
#
# def test_case_1():
#     ansible_constructor_1 = AnsibleConstructor('test_file_name')
#
# # Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
# def test_AnsibleConstructor_construct_vault_encrypted_unicode():
#     ansible_constructor = AnsibleConstructor('test_file_name')
#
#     vault_secrets = ['test_secret']
#
#

# Generated at 2022-06-25 04:25:19.213165
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Set up test data
    ansible_constructor_0 = AnsibleConstructor()
    node = {
        'start_mark': 'start_mark_1',
        'end_mark': 'end_mark_2',
        'type': 'mapping',
        'id': 'tag:yaml.org,2002:map',
        'value': [
            ['key_node_0', 'value_node_0'],
            ['key_node_1', 'value_node_1'],
            ['key_node_2', 'value_node_2'],
            ['key_node_3', 'value_node_3']
        ]
    }
    deep = 'deep_1'
    # Invoke method
    ansible_constructor_0.construct_yaml_map(node)



# Generated at 2022-06-25 04:25:25.356902
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    ansible_constructor_1 = AnsibleConstructor()
    node = MappingNode(u'tag:yaml.org,2002:map', [], start_mark=None, end_mark=None)
    data = ansible_constructor_1.construct_yaml_seq(node)
    assert data is not None


# Generated at 2022-06-25 04:25:53.226560
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_node_0=MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=Mark(index=0, line=1, column=0, buffer=u'', pointer=0), end_mark=Mark(index=0, line=1, column=1, buffer=u'', pointer=1))
    ansible_mapping_0 = ansible_constructor_0.construct_mapping(node=ansible_node_0)

    assert ansible_mapping_0 == AnsibleMapping()


# Generated at 2022-06-25 04:25:56.253483
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_str(arg=AnsibleUnicode("any string"))


# Generated at 2022-06-25 04:26:00.115457
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()


if __name__ == '__main__':
    test_case_0()
    test_AnsibleConstructor_construct_vault_encrypted_unicode()

# Generated at 2022-06-25 04:26:11.005317
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_01 = AnsibleConstructor()

    # These tests are for array data
    # This is a test for an empty array
    empty_seq = [A_Constructor_Data_Object(), u'tag:yaml.org,2002:seq', u'[]', {}, None]
    ret_seq = ansible_constructor_01.construct_yaml_seq(empty_seq[0])
    assert ret_seq is not None

    # This is a test for a non-empty array
    non_empty_seq = [A_Constructor_Data_Object(), u'tag:yaml.org,2002:seq', u'[a, b, c]', {}, None]
    ret_seq = ansible_constructor_01.construct_yaml_seq(non_empty_seq[0])
    assert ret_

# Generated at 2022-06-25 04:26:11.919072
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:26:23.962823
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Create the object for which we will be testing
    ansible_constructor_0 = AnsibleConstructor()

    # Create the necessary input variables
    ansible_constructor_0._node_position_info = lambda x: (u'', 0, 0)
    node = dict()
    # The following line will be uncommented when the method being tested is
    # 'construct_mapping'. It will be commented out when the method being tested
    # is not 'construct_mapping'.
    # deep = False

    # Call the method that is being tested
    result = ansible_constructor_0.construct_mapping(node, deep=False)

    # Test if the method being tested returns a value as expected
    assert type(result) == dict


# Generated at 2022-06-25 04:26:33.400561
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_obj_0 = AnsibleConstructor()
    ansible_constructor_obj_0._ansible_file_name = None
    ansible_constructor_obj_0.vault_secrets = list([])
    ansible_constructor_obj_0._vaults = dict({})
    ansible_constructor_obj_0._vaults['default'] = VaultLib(secrets=list([]))
    ansible_constructor_obj_0.vault_secrets = list([])
    
    import yaml
    ansible_constructor_obj_0._vaults['default'] = VaultLib(secrets=list([]))
    ansible_constructor_obj_0._ansible_file_name = None

# Generated at 2022-06-25 04:26:38.618044
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    s = u"some data"
    ret = ansible_constructor_1.construct_vault_encrypted_unicode(s)
    assert isinstance(ret, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 04:26:41.454034
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    node = 10
    expected = wrap_var(10)
    result = ansible_constructor.construct_yaml_unsafe(node)
    assert result == expected

# Generated at 2022-06-25 04:26:43.987742
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    assert isinstance(ansible_constructor.construct_mapping({}), AnsibleMapping)


# Generated at 2022-06-25 04:27:29.546865
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Test to ensure that mapping is constructed correctly.
    This test will test a number of error conditions
    """
    # Valid test case
    node_0 = {}
    deep_0 = False
    ansible_constructor_0 = AnsibleConstructor()

    mapping_0 = ansible_constructor_0.construct_mapping(node_0, deep_0)

    # Invalid test case
    node_1 = {}
    deep_1 = False
    ansible_constructor_1 = AnsibleConstructor()

    with pytest.raises(ConstructorError) as err_info:
        mapping_1 = ansible_constructor_1.construct_mapping(node_1, deep_1)

# Generated at 2022-06-25 04:27:32.277133
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # We only use the safe_constructor
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map()


# Generated at 2022-06-25 04:27:34.255149
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    assert(not hasattr(ansible_constructor, 'safe_constructors'))


# Generated at 2022-06-25 04:27:37.445966
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_vault_encrypted_unicode(node) == AnsibleVaultEncryptedUnicode(ciphertext_data)

# Generated at 2022-06-25 04:27:46.096870
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-25 04:27:50.849676
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_0 = AnsibleConstructor()
    node = None
    data = test_0.construct_yaml_seq(node)
    assert data is None



# Generated at 2022-06-25 04:27:59.518637
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_mapping_1 = {'bar': 'baz'}
    ansible_mapping_2 = {'bar': 'baz', 'foo': 'bar'}
    mapped_1 = ansible_constructor_1.construct_mapping(MappingNode(None, None, None, [('bar', 'baz')]), deep=True)
    mapped_2 = ansible_constructor_1.construct_mapping(MappingNode(None, None, None, [('bar', 'baz'), ('foo', 'bar')]), deep=True)

    assert type(mapped_1) is type(ansible_mapping_1)
    assert type(mapped_2) is type(ansible_mapping_2)

# Generated at 2022-06-25 04:28:00.391771
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    pass


# Generated at 2022-06-25 04:28:03.836935
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(str())
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_str(str())


# Generated at 2022-06-25 04:28:04.922373
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()



# Generated at 2022-06-25 04:28:48.976085
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import base64
    import yaml
    vault_id = 'test_vault'
    vault_secret = 'test_secret'
    ansible_constructor = AnsibleConstructor(file_name='test_file_name')
    ansible_constructor._vaults = {vault_id: VaultLib(secrets=[vault_secret])}
    (vault_dict, vault_line) = ({'!vault': '$ANSIBLE_VAULT;7.7;AES256'}, '!vault')
    vault_yaml = [vault_line, vault_dict]
    vault_yaml_string = '\n'.join(yaml.dump(vault_yaml, Dumper=yaml.SafeDumper, canonical=True, indent=4).split('\n')[1:])
    vault_

# Generated at 2022-06-25 04:28:50.174283
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert 1 == 1



# Generated at 2022-06-25 04:29:01.130201
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    source = "key: value"
    node = ansible_constructor_1.construct_document(source)
    assert isinstance(node, dict)
    assert node == {'key': 'value'}
    source = "key1: value1\nkey2: value2"
    node = ansible_constructor_1.construct_document(source)
    assert isinstance(node, dict)
    assert node == {'key1': 'value1', 'key2': 'value2'}
    source = "key\n  key1: value1\n  key2: value2"
    node = ansible_constructor_1.construct_document(source)
    assert isinstance(node, dict)

# Generated at 2022-06-25 04:29:06.955718
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Setup
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    ansible_constructor_0._vaults = {}
    ansible_constructor_0._vaults['default'] = VaultLib(secrets=[])

    # Test
    # Exception: ConstructorError: while constructing an encrypted unicode object:
    # found !vault but no vault password provided

    ansible_constructor_0.construct_vault_encrypted_unicode(node)


# Generated at 2022-06-25 04:29:11.031965
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_content = '''
- test:
    key: value
    key2: value
    '''

    yaml_content_bytes = to_bytes(yaml_content)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map(node=yaml_content_bytes)

    # print(ansible_constructor._vaults.keys())


# Generated at 2022-06-25 04:29:15.735296
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode(None, None, None)
    ansible_constructor.construct_mapping(node)

# Generated at 2022-06-25 04:29:23.296262
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    vault_contents = "TEST_DATA"
    vault_secrets = ['test_secret']
    vault_lib = VaultLib(vault_secrets)
    encrypted_data = vault_lib.encrypt(vault_contents)
    b_ciphertext = to_bytes(encrypted_data)
    ret = ansible_constructor_0.construct_vault_encrypted_unicode(b_ciphertext)
    assert ret == vault_contents

# Generated at 2022-06-25 04:29:31.806562
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    data = []
    data.append(1)
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=data,
                       start_mark=None, end_mark=None, flow_style=None)
    retval = ansible_constructor_0.construct_yaml_seq(node)
    retval = list(retval)
    assert retval[0] == []



# Generated at 2022-06-25 04:29:33.202089
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:29:35.342786
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_unsafe(MappingNode) == 'dict'


# Generated at 2022-06-25 04:30:18.616814
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    construct_yaml_map_2 = ansible_constructor_1.construct_yaml_map(MappingNode('tag:yaml.org,2002:map', [], start_mark=None, end_mark=None))
    construct_yaml_map_2 = iter(construct_yaml_map_2)
    next(construct_yaml_map_2)
    assert construct_yaml_map_2.next() == AnsibleMapping()


# Generated at 2022-06-25 04:30:21.638989
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

    class DummyMappingNode(object):
        value = [
                   (
                    'foo', 'bar'),
                   (
                    'bar', 'foo')]
        start_mark = ''

    dummy_mapping_node_0 = DummyMappingNode()
    ansible_constructor_0.construct_mapping(dummy_mapping_node_0)



# Generated at 2022-06-25 04:30:25.931455
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    ansible_constructor_1 = AnsibleConstructor("/path/to/file.yml", vault_secrets=[])

    # Set up test case values
    node_2 = {"id": "scalar"}

    vault_encrypted_unicode_3 = "my vault-encrypted"

    ansible_constructor_1.construct_vault_encrypted_unicode(node_2)
    try:
        pass
        # expected exception
    except ConstructorError:
        pass

# Generated at 2022-06-25 04:30:29.703163
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # initialize
    ansible_constructor_0 = AnsibleConstructor()
    node = None

    #Test case with no Vault password provided
    ansible_constructor_0.construct_vault_encrypted_unicode(node)
    #Test case with Vault password provided
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(secrets=['vault1', 'vault2'])
    ansible_constructor_0._vaults['default'] = vault
    ansible_constructor_0.construct_vault_encrypted_unicode(node)
    #Test case with Vault password provided
    #TODO:
    # node = vault.encrypt('abcd')
    #ansible_constructor_0.construct_vault_encrypted_unicode(node)

#Unit test for method construct

# Generated at 2022-06-25 04:30:32.347941
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # TODO: add test case
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(None)


# Generated at 2022-06-25 04:30:35.609038
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor({})
    try:
        ansible_constructor_1.construct_yaml_map(node_1='node_1')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:30:43.806636
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    string_0 = 'duplicate_yaml_dict_key: error'
    string_1 = '!unsafe \'\'\''
    ansible_constructor_0 = AnsibleConstructor()
    seq = ansible_constructor_0.construct_yaml_map(string_0)
    assert(ansible_constructor_0.construct_yaml_map(seq) == ansible_constructor_0.construct_yaml_map(string_0))
    assert(ansible_constructor_0.construct_yaml_map(seq) != ansible_constructor_0.construct_yaml_map(string_1))

# Generated at 2022-06-25 04:30:45.663520
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()

    # TODO: Add further test cases for the above method here
    #
    #
    #
    #


# Generated at 2022-06-25 04:30:47.553649
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    node = AnsibleMapping()
    deep = False
    assert ansible_constructor_0.construct_mapping(node, deep) == {}


# Generated at 2022-06-25 04:30:54.153964
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = object
    result_0 = ansible_constructor_0.construct_yaml_unsafe(node_0)
    assert type(result_0) == UnsafeWrapper
    assert result_0.value == node_0


# Generated at 2022-06-25 04:31:41.146266
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    test_case = """
# Use a dict comprehension to set the value of foo to a dict
# with keys that are the integers 0-7 and values that are
# double the key
- hosts: localhost
  tasks:
    - set_fact:
        foo: { { key: 2*key for key in range(0, 8) } }
    - debug:
        msg: "{{ foo }}"
"""
    ansible_constructor = AnsibleConstructor()
    data = ansible_constructor.construct_unsafe_yaml(test_case)
    assert data[0]['tasks'][0]['set_fact'] == {'foo': {'0': 0, '1': 2, '2': 4, '3': 6, '4': 8, '5': 10, '6': 12, '7': 14}}

#