

# Generated at 2022-06-25 04:21:58.182681
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-25 04:22:06.849340
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b'\xb3\x1f\xc5\xeb\x97\xec\xed\x19\x13\x17\x97\xe6q\xdf\x14\xaa\xa8\xed\x85\x1b\xf5'
    bytes_1 = b"\xac\xaf\x82\xa4'\xf4\xad\x1d\x8c\x9e\xbf\xd6\x07\xe6\x99\x95\x06\xed\x86\x9f\xdd"

# Generated at 2022-06-25 04:22:11.892722
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create an instance of class AnsibleConstructor
    ansible_constructor_0 = AnsibleConstructor()

    # Create an instance of class Tag
    tag_0 = yaml.Tag


# Generated at 2022-06-25 04:22:20.678490
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    call_function = lambda node: AnsibleConstructor.construct_vault_encrypted_unicode(node)
    node = None
    assert call_function(node) is None

    if C.DEFAULT_VAULT_SECRET_ADDRESS is None:
        C.DEFAULT_VAULT_SECRET_ADDRESS = "default"

    if C.DEFAULT_VAULT_IDENTITY is None:
        C.DEFAULT_VAULT_IDENTITY = "default"
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:22:25.778925
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping = AnsibleMapping()
    mapping['ansible_pos'] = (u'my_file', 2, 3)
    mapping['key'] = u'value'
    # TODO: implement it
    assert True



# Generated at 2022-06-25 04:22:26.366946
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    assert True

# Generated at 2022-06-25 04:22:35.624220
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    with pytest.raises(ConstructorError) as pytest_wrapped_e:
        bytes_0 = b'\xd6\x03\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99'
        ansible_constructor_0 = AnsibleConstructor()
        ansible_constructor_0.construct_vault_encrypted_unicode(bytes_0)
    assert pytest_wrapped_e.type == ConstructorError
    assert pytest_wrapped_e.value.context is None
    assert pytest_wrapped_e.value.context_mark is None
    assert pytest_wrapped_e.value.problem == 'found !vault but no vault password provided'


# Generated at 2022-06-25 04:22:42.515158
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node_0 = MappingNode(None, None, True, None, None, None)
    my_AnsibleConstructor_0 = AnsibleConstructor('/etc/ansible/hosts', None)
    assert my_AnsibleConstructor_0._ansible_file_name == '/etc/ansible/hosts'
    my_AnsibleConstructor_0.construct_yaml_map(node_0)
    # TODO: create a test here that checks the output of construct_yaml_map
    # against a hardcoded value.


# Generated at 2022-06-25 04:22:50.583335
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test case-0 of AnsibleConstructor.construct_yaml_str()
    # Positive test case with yaml "int" type scalar
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    
    ansible_constructor_0.construct_yaml_str(bytes_0)


# Generated at 2022-06-25 04:22:59.686939
# Unit test for method construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-25 04:23:15.082611
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = AnsibleMapping()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map(node)


# Generated at 2022-06-25 04:23:22.671639
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    load_0 = load_0 = load
    str_0 = str
    bytes_0 = bytes
    unicode_0 = unicode
    int_0 = int

    AnsibleConstructor.set_yaml_loader(load_0)

    object_0 = object
    yaml_str_0 = yaml_str
    bool_0 = bool
    yaml_str_1 = yaml_str
    bool_1 = bool
    yaml_str_2 = yaml_str
    bool_2 = bool
    yaml_str_3 = yaml_str
    bool_3 = bool
    yaml_str_4 = yaml_str
    bool_4 = bool
    yaml_str_5 = yaml_str
    bool_5 = bool
    yaml_str_6 = yaml_str


# Generated at 2022-06-25 04:23:28.969189
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    ansible_vault_encrypted_unicode_0 = ansible_constructor_0.construct_vault_encrypted_unicode('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          663930366133663232326365633639353637633239623663623432633931623230653761333863613\n          0\n          '.encode('utf-8'))
    assert ansible_vault_encrypted_unicode_0

# Generated at 2022-06-25 04:23:32.442311
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    bytes_0 = b'\x14\x86R\x94\xbd\xec\x10\xa7V\x82\x1a\xda9\xab\xd4\x83\xc4\x93\xe2\x17\x99\xeb'
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:23:37.080452
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor.construct_vault_encrypted_unicode(bytes_0)

# Generated at 2022-06-25 04:23:42.076749
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():

    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe(bytes_0)
    ansible_constructor_0.construct_yaml_unsafe("")


# Generated at 2022-06-25 04:23:43.523772
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
  test_case_0()

# Generated at 2022-06-25 04:23:44.914296
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_case_0()
    print('Mock:  AnsibleConstructor.construct_vault_encrypted_unicode()')


# Generated at 2022-06-25 04:23:48.087141
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    #assert ansible_constructor_0.construct_vault_encrypted_unicode(node_0) == ansible_vault_encrypted_unicode_0
    pass


# Generated at 2022-06-25 04:24:02.890740
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    bytes_0 = b'\x00\x00\x00\x00'
    ansible_constructor_0 = AnsibleConstructor()
    str_1 = '!unsafe'
    ansible_constructor_0.add_constructor(str_1, ansible_constructor_0.construct_yaml_unsafe)
    ansible_constructor_0.add_constructor(u'!ansible', ansible_constructor_0.construct_yaml_unsafe)
    ansible_constructor_0.add_constructor(u'!ansible.builtin', ansible_constructor_0.construct_yaml_unsafe)

# Generated at 2022-06-25 04:24:13.912220
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Test that a map is returned as an AnsibleMapping
    yaml_dict = {}
    yaml_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None, flow_style=True)
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = ansible_constructor.construct_yaml_map(yaml_node)
    assert isinstance(ansible_mapping, AnsibleMapping)



# Generated at 2022-06-25 04:24:22.315844
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    constructor_retval_0 = ansible_constructor_0.construct_yaml_unsafe(bytes_0)
    assert constructor_retval_0 is not None
    assert isinstance(constructor_retval_0, AnsibleUnsafeText), constructor_retval_0

# Generated at 2022-06-25 04:24:29.753308
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml.resolver
    ansible_constructor_0 = AnsibleConstructor()

    # Input
    node_0 = yaml.resolver.Resolver.DEFAULT_MAPPING_TAG

    # Output
    wrapped_input_0 = ansible_constructor_0.construct_yaml_unsafe(node_0)
    assert(isinstance(wrapped_input_0, AnsibleVaultEncryptedUnicode))

# Generated at 2022-06-25 04:24:38.233300
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_1 = AnsibleMapping()
    # Test for failure in construct_yaml_seq with value of parameter node
    # being of type AnsibleMapping for testing failure in
    # construct_yaml_seq with value of parameter node being of type AnsibleMapping
    ansible_list_0 = ansible_constructor_0.construct_yaml_seq(ansible_mapping_1)


# Generated at 2022-06-25 04:24:43.349803
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:24:52.451116
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    # check return type of AnsibleConstructor.construct_vault_encrypted_unicode
    assert isinstance(ansible_constructor_0.construct_vault_encrypted_unicode("some_node"), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 04:24:53.195829
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass


# Generated at 2022-06-25 04:24:58.447175
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()

    assert_equal(ansible_constructor_0.construct_vault_encrypted_unicode(bytes_0), None)

# Generated at 2022-06-25 04:25:02.830837
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    bytes_0 = b'\x08\xec\x19\x86\xa1\x99W'
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:25:06.675774
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    string_0 = "t\x00e\x00s\x00t\x00"
    ansible_constructor_0 = AnsibleConstructor()
    with pytest.raises(ConstructorError):
        ansible_constructor_0.construct_yaml_unsafe(string_0)


# Generated at 2022-06-25 04:25:20.370403
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    print(ansible_constructor_0.construct_yaml_str(bytes_0))


# Generated at 2022-06-25 04:25:26.240404
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map(bytes_0)


# Generated at 2022-06-25 04:25:27.604781
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    error = None
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:25:30.590698
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    node = 0
    deep = 0
    ret = ansible_constructor.construct_mapping(node, deep)
    assert ret is None

# Generated at 2022-06-25 04:25:36.650298
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Init class instance.
    ansible_constructor_1 = AnsibleConstructor()

    # Store the expected result of calling ansible_constructor_0.construct_yaml_seq() here
    res_0 = None

    # Implement your test here.
    raise NotImplementedError()



# Generated at 2022-06-25 04:25:41.247371
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    src_0_raw = '!unsafe &id001 >\n'
    src_0 = '\n'.join(['---', src_0_raw])
    ansible_constructor_0 = AnsibleConstructor()
    yaml_0 = ansible_constructor_0.get_single_data(src_0)
    assert ansible_constructor_0._vaults['default'].type == 'AG'

# Generated at 2022-06-25 04:25:44.580296
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()

    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0.construct_yaml_str(bytes_0)


# Generated at 2022-06-25 04:25:46.044599
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
  # TODO: Implement this test
  assert False



# Generated at 2022-06-25 04:25:50.261560
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    This test is going to fail because the method is protected but i dont know how to fix it yet
    """
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str("test")


# Generated at 2022-06-25 04:25:57.504995
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    bytes_0 = b'\x00\x00\x00\x00'
    bytes_1 = b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:20.817921
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    mapping_node_0 = AnsibleMapping()
    mapping_node_0.value = []
    mapping_0 = ansible_constructor_0.construct_yaml_map(mapping_node_0)


# Generated at 2022-06-25 04:26:27.440871
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:26:36.691059
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    bytes_1 = b"\x1f\xee\x82\x01\x8e\x92\r.\xf3\x97\x8c*\xca\x1e\xa3\x93\x8d\xbe\x80\x87\x95\x8f\x0e\x0f\x93"
    ansible_vault_encrypted_unicode_0 = ansible_construc

# Generated at 2022-06-25 04:26:45.400058
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-25 04:26:55.966352
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-25 04:26:59.072336
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = AnsibleSequence()
    data.extend(AnsibleConstructor.construct_sequence(node))
    data.ansible_pos = AnsibleConstructor._node_position_info(node)


# Generated at 2022-06-25 04:27:10.374092
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_map_0 = {'z': {}, 'y': {}, 'x': {}}
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping(yaml_map_0)
    assert_equal(ansible_constructor_0.construct_yaml_map(yaml_map_0), ansible_mapping_0)

    yaml_map_1 = {'a': {'s': 'b'}}
    ansible_constructor_1 = AnsibleConstructor()
    ansible_mapping_1 = AnsibleMapping(yaml_map_1)
    assert_equal(ansible_constructor_1.construct_yaml_map(yaml_map_1), ansible_mapping_1)


# Generated at 2022-06-25 04:27:12.954844
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    ansible_constructor_0 = AnsibleConstructor(file_name=None, vault_secrets=None)

    vault_encrypted_unicode_0 = ansible_constructor_0.construct_vault_encrypted_unicode(node=None)

    assert vault_encrypted_unicode_0.vault is None

# Generated at 2022-06-25 04:27:22.848888
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()

    ansible_constructor_0.construct_yaml_map(MappingNode(
        tag=u'tag:yaml.org,2002:map',
        value=[],
        start_mark=0,
        end_mark=0))
    ansible_constructor_0.construct_yaml_str(MappingNode(
        tag=u'tag:yaml.org,2002:map',
        value=[],
        start_mark=0,
        end_mark=0))
    ansible_constructor_

# Generated at 2022-06-25 04:27:31.780307
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:28:15.927249
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    try:
        from yaml.nodes import ScalarNode
        from ansible.parsing.vault import VaultLib
    except Exception:
        pass

    print("\n\nTESTING construct_vault_encrypted_unicode\n\n")

# Generated at 2022-06-25 04:28:17.679338
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert True

# Generated at 2022-06-25 04:28:19.669358
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    obj = AnsibleConstructor
    # We cannot test here as this method is abstract
    pass


# Generated at 2022-06-25 04:28:27.233023
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.constructor import ConstructorError
    from yaml.parser import ParserError
    from yaml.reader import ReaderError
    from yaml.scanner import ScannerError

    try:
        ansible_constructor_0 = AnsibleConstructor()
        mapping_node_0 = None
        ansible_constructor_0.construct_mapping(mapping_node_0)
    except (TypeError, ValueError) as error_0:
        print(str(error_0))
    except (ScannerError, ReaderError, ParserError, ConstructorError) as error_1:
        print(str(error_1))
    except Exception as error_2:
        print(str(error_2))


# Generated at 2022-06-25 04:28:32.974871
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.nodes import MappingNode
    ret_val = AnsibleMapping()
    assert isinstance(ret_val, AnsibleMapping)
    # TODO: Add tests for other method arguments


# Generated at 2022-06-25 04:28:42.171772
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    mapping_node_0 = MappingNode(None, None, True, False)
    ansible_mapping_0 = ansible_constructor_0.construct_mapping(mapping_node_0)
    assert isinstance(ansible_mapping_0, AnsibleMapping) == True


# Generated at 2022-06-25 04:28:45.395296
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    obj_0 = AnsibleConstructor()
    value = obj_0.construct_yaml_str({'value': ''})
    ansible_unicode_0 = AnsibleUnicode()
    assert value == ansible_unicode_0



# Generated at 2022-06-25 04:28:50.536630
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:28:56.077215
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = wrap_var(bytes_0)
    ansible_constructor_0.construct_yaml_unsafe(node_0)


# Generated at 2022-06-25 04:29:02.426392
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._node_position_info()


# Generated at 2022-06-25 04:30:19.684627
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    bytes_0 = b'\xc4\x9a\xee\xb4\x04\xba\x8f\x02\x94\xc4\xbd\xa9\x9c\xc4\x9b\xbe\xb5\xfd\xc4\x86\xc5\x9e\xdf\x9f'
    bytes_1 = b'\xc3\xbd\xc3\xbf'
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe(bytes_0, bytes_1)


# Generated at 2022-06-25 04:30:27.533956
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    node = MappingNode(tag=u'tag:yaml.org,2002:str',
                           value=[],
                           flow_style=False
                       )
    assert(test_case_0.ansible_constructor_0.construct_vault_encrypted_unicode(node) ==
           u"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99")

# Generated at 2022-06-25 04:30:39.022029
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test for duplicate key
    bytes_0 = b"'ansible1'"
    mapping_node_0 = MappingNode(None, [(ScalarNode(None, bytes_0), ScalarNode(None, bytes_0))], deep=True)
    ansible_constructor_0 = AnsibleConstructor()
    try:
        ansible_constructor_0.construct_mapping(mapping_node_0)
        assert False, "expected a ConstructorError"
    except ConstructorError:
        pass
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(mapping_node_0)

# Generated at 2022-06-25 04:30:43.505578
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # ConstructorError should be raised if not isinstance(node, MappingNode)
    node_0 = None
    ansible_constructor_0 = AnsibleConstructor()
    try:
        ansible_constructor_0.construct_yaml_map(node_0)
    except ConstructorError as e:
        assert e.problem == u"expected a mapping node, but found None"


# Generated at 2022-06-25 04:30:49.283237
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
#

# Generated at 2022-06-25 04:30:55.428705
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test with two duplicate keys, expecting one of the two to be overwritten
    AnsibleConstructor_construct_mapping_0 = AnsibleConstructor()
    AnsibleConstructor_construct_mapping_0_value = AnsibleConstructor_construct_mapping_0.construct_mapping(None)
    assert AnsibleConstructor_construct_mapping_0_value == {}



# Generated at 2022-06-25 04:30:59.583562
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    bytes_0 = b'C\x00\x00\x00'
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq()

# Generated at 2022-06-25 04:31:07.103791
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    bytes_0 = b'\x8f\x7f'
    ansible_constructor_0 = AnsibleConstructor()
    bytes_1 = b'\x8fB'
    ansible_constructor_1 = AnsibleConstructor()
    bytes_2 = b'\x8f\x7f'
    ansible_constructor_2 = AnsibleConstructor()
    bytes_3 = b'gK='
    ansible_constructor_3 = AnsibleConstructor()
    bytes_4 = b'\xa3\x07'
    ansible_constructor_4 = AnsibleConstructor()
    bytes_5 = b'\xa3\x07'
    ansible_constructor_5 = AnsibleConstructor()
    bytes_6 = b'\xa3\x07'
    ansible_construct

# Generated at 2022-06-25 04:31:12.044493
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()


test_case_0()

# Generated at 2022-06-25 04:31:16.523282
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b"'\xd63\xee\x80\xf1\xd6\x07\xe6q\xdfd\xee\xab\xf8\xec\x19\x86\xa1\x99"
    ansible_constructor_0 = AnsibleConstructor()
