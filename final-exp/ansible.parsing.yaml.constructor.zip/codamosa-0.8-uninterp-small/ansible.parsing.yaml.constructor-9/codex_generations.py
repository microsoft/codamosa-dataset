

# Generated at 2022-06-25 04:21:48.792647
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    # TODO: implement test_case_0()
    raise Exception('test_case_0() not yet implemented')



# Generated at 2022-06-25 04:21:50.602434
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_map_0 = ansible_constructor_0.construct_yaml_map()


# Generated at 2022-06-25 04:21:56.041069
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Unit test for method construct_yaml_seq of class AnsibleConstructor,
    which is called from yaml when loading all files
    """
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode(tag='tag:yaml.org,2002:python/dict', value=[])
    ansible_constructor_0.construct_yaml_seq(node)


# Generated at 2022-06-25 04:22:01.720359
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    vault_secrets2 = ['vault1', 'vault2', 'vault3']
    ansible_constructor_1 = AnsibleConstructor(vault_secrets=vault_secrets2)
    node_0 = 0
    try:
        value = ansible_constructor_1.construct_vault_encrypted_unicode(node_0)
        print('value:', value)
    except ConstructorError as e:
        print('e:', e)
        raise e


# Generated at 2022-06-25 04:22:03.978382
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map()


# Generated at 2022-06-25 04:22:06.738610
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = object()
    assert ansible_constructor_0.construct_yaml_seq(yaml_node_0) is not None


# Generated at 2022-06-25 04:22:09.662087
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map()

# Generated at 2022-06-25 04:22:11.912041
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:22:13.230180
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map("abcdef")


# Generated at 2022-06-25 04:22:21.663927
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.vault import VaultLib

    # the !unsafe tag is shorthand for !python/object
    ansible_constructor_1 = AnsibleConstructor()
    assert isinstance(ansible_constructor_1.construct_yaml_unsafe(node=None), object)

    # The !unsafe tag is shorthand for !python/object
    ansible_constructor_2 = AnsibleConstructor()
    assert isinstance(ansible_constructor_2.construct_yaml_unsafe(node=None), object)

    # The !vault tag is shorthand for !python/object
    ansible_constructor_3 = AnsibleConstructor()
    vault_lib = VaultLib([b"hunter2"])

# Generated at 2022-06-25 04:22:29.557310
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:22:37.561136
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    seq_node = [1, 2, 3]
    ansible_seq = ansible_constructor.construct_yaml_seq(seq_node)
    ansible_seq_list = list(ansible_seq)
    assert len(ansible_seq_list) == 1
    assert isinstance(ansible_seq_list[0], AnsibleSequence)
    construct_yaml_seq_list = ansible_seq_list[0]  # get the actual AnsibleSequence
    assert len(construct_yaml_seq_list) == 3
    item0 = construct_yaml_seq_list[0]
    assert isinstance(item0, int)
    assert item0 == 1
    item1 = construct_yaml_seq_list[1]
    assert isinstance

# Generated at 2022-06-25 04:22:41.563663
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode('tag:yaml.org,2002:map', [])
    ret_0 = ansible_constructor_0.construct_mapping(node_0, deep=False)
    assert isinstance(ret_0, AnsibleMapping)



# Generated at 2022-06-25 04:22:51.911728
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    fname = "/etc/ansible/roles/role_under_test/defaults/main.yml"
    node = "[{u'boolean': {u'default': True}}, {u'boolean_key': {u'default': u'{{boolean}}'}}, {u'boolean': {u'default': False}}]"
    result = ansible_constructor_0.construct_yaml_seq(node)
    assert result == "[{u'boolean': {u'default': True}}, {u'boolean_key': {u'default': u'{{boolean}}'}}, {u'boolean': {u'default': False}}]"


# Generated at 2022-06-25 04:22:53.746087
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert isinstance(ansible_constructor_1.construct_yaml_map(node_1), AnsibleMapping)



# Generated at 2022-06-25 04:23:04.397111
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor(None, None)
    # self.flatten_mapping(node)
    # mapping = AnsibleMapping()
    # node.value = [('key1', 'value1'), ('key2', 'value2')]
    # for key_node, value_node in node.value:
    #     key = self.construct_object(key_node, deep=deep)
    #     try:
    #         hash(key)
    #     except TypeError as exc:
    #         raise ConstructorError("while constructing a mapping", node.start_mark,
    #                                "found unacceptable key (%s)" % exc, key_node.start_mark)
    #     if key in mapping:
    #         msg = (u'While constructing a mapping from {1}, line {2},

# Generated at 2022-06-25 04:23:11.512966
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ans = AnsibleConstructor()
    test_map = ans.construct_mapping(MappingNode(tag=u'tag:yaml.org,2002:map', value=[],
                                                 start_mark=None, end_mark=None))
    assert isinstance(test_map, AnsibleMapping)
    test_map['ans'] = 'ible'
    assert test_map['ans'] == 'ible'



# Generated at 2022-06-25 04:23:13.185182
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    t = AnsibleConstructor()
    assert t.construct_yaml_seq(["one", "two", "three"]) == AnsibleSequence(["one", "two", "three"])


# Generated at 2022-06-25 04:23:21.776955
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test fixture
    class TestFixture(object):

        def test_func(self, arg1, arg2, arg3):
            return "%s %s %s" % (arg1, arg2, arg3)

    # Test object
    yaml_str = u'foo bar baz'
    str_obj = TestFixture().test_func('foo', 'bar', 'baz')

    # Construct the YAML string to compare the results.
    yaml_str_obj = AnsibleUnicode(yaml_str)

    # Convert all expected values to unicode.
    assert str(type(yaml_str)) == str(type(yaml_str_obj.value))
    assert str(yaml_str) == str(yaml_str_obj.value)

# Generated at 2022-06-25 04:23:26.374829
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node_1 = AnsibleUnicode('test_value_2')
    ansible_constructor_0.construct_yaml_str(node_1)


# Generated at 2022-06-25 04:23:35.671033
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Calling the method construct_yaml_map of the class AnsibleConstructor
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map()


# Generated at 2022-06-25 04:23:42.708059
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_obj = AnsibleConstructor()
    # Test when no argument is passed
    try:
        ansible_constructor_obj.construct_yaml_map()
    except TypeError:
        pass
    # Test with node as argument
    ansible_constructor_obj.construct_yaml_map(node)
    # Test with node and deep as arguments
    ansible_constructor_obj.construct_yaml_map(node, deep)


# Generated at 2022-06-25 04:23:45.962302
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_unsafe(None) is None
# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 04:23:53.072528
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_vault_encrypted_unicode(node='')


# Generated at 2022-06-25 04:23:54.705189
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor(file_name=None, vault_secrets=None)
    mapping = ansible_constructor_0.construct_mapping()
    assert mapping == None

# Generated at 2022-06-25 04:24:01.570008
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = load(u'foo')
    yaml_node_0.id = u'scalar'
    yaml_node_0.start_mark = 1, 1, 2
    yaml_node_0.end_mark = 1, 1, 2
    assert isinstance(ansible_constructor_0.construct_yaml_str(yaml_node_0), AnsibleUnicode)


# Generated at 2022-06-25 04:24:07.188528
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    # TODO: Do we need to do anything special when a parameter is already instantiated?
    # assert ansible_constructor_1.construct_yaml_str(value) == "hello"


# Generated at 2022-06-25 04:24:08.726638
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    assert isinstance(ansible_constructor, AnsibleConstructor)

# Generated at 2022-06-25 04:24:12.506735
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    assert isinstance(ansible_constructor_1, AnsibleConstructor)


# Generated at 2022-06-25 04:24:21.625319
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    display = Display()
    display.reset()
    args = [{}]
    if len(args) == 1 and isinstance(args[0], dict):
        kwargs = args[0]
    else:
        kwargs = {}

    ansible_constructor._ansible_file_name = kwargs.get('file_name', None)
    ansible_constructor._vaults = kwargs.get('vault_secrets', None)

    assert ansible_constructor._ansible_file_name is None
    assert ansible_constructor._vaults is None
    assert isinstance(ansible_constructor, AnsibleConstructor)

# Generated at 2022-06-25 04:24:35.544564
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print("test_AnsibleConstructor_construct_yaml_map")
    ansible_constructor_construct_yaml_map_0 = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_1 = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_2 = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_3 = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_4 = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_5 = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_6 = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_7 = AnsibleConstructor()
    ansible_

# Generated at 2022-06-25 04:24:43.018889
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode()
    deep = False
    result = AnsibleConstructor().construct_mapping(node, deep)
    assert result
    assert isinstance(result, AnsibleMapping)

# Unit tests for methods construct_yaml_map and construct_yaml_seq of class AnsibleConstructor

# Generated at 2022-06-25 04:24:47.451975
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map(node_0)
    ansible_constructor_0.construct_yaml_map(node_0)


# Generated at 2022-06-25 04:24:52.520890
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.type_tokens = {}
    node_2 = {}
    deep_3 = []
    ret_4 = ansible_constructor_1.construct_mapping(node_2, deep_3)
    assert ret_4 is not None


# Generated at 2022-06-25 04:24:53.582722
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()



# Generated at 2022-06-25 04:24:59.973980
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = "vault_password"
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = [vault_password]
    ciphertext = ansible_constructor._vaults['default'].encode("my_secret")
    node = MappingNode(tag=u'tag:yaml.org,2002:str', value=ciphertext, start_mark=None, end_mark=None)
    ret = ansible_constructor.construct_vault_encrypted_unicode(node)
    decrypted_secret = ret.unwrap()
    assert decrypted_secret == "my_secret"

# Generated at 2022-06-25 04:25:12.974184
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    ansible_constructor_0 = AnsibleConstructor(file_name="test_servers.yml")
    assert (ansible_constructor_0._ansible_file_name == "test_servers.yml")

    # tests:

    print("Test AnsibleConstructor.construct_yaml_str()")

    ansible_constructor_0 = AnsibleConstructor()

    class MockNode:
        def __init__(self):
            self.value = "test string"
            self.id = "test"
            self.start_mark = "test"

    mock_node = MockNode()

    ansible_constructor_0.construct_scalar = Mock()

    ansible_constructor_0.construct_yaml_str(mock_node)

# Generated at 2022-06-25 04:25:19.133711
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None, flow_style=None)
    result = ansible_constructor_0.construct_yaml_map(node)
    assert isinstance(result, AnsibleMapping)
    assert result.ansible_pos == (None, 1, 0)



# Generated at 2022-06-25 04:25:27.219057
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Initialize an AnsibleConstructor Object
    ansible_constructor_0 = AnsibleConstructor()

    # Create an instance of  yaml.nodes.ScalarNode
    scalar_node_0 = ScalarNode('!vault-encrypted', '!vault-encrypted')
    # Create an instance of  yaml.constructor.SafeConstructor
    safe_constructor_0 = SafeConstructor()

    # Use the following for mock testing classes defined in the constructor attribute
    with patch.object(SafeConstructor, 'construct_object', autospec=True) as mocked_construct_object:

        # Define return values of method construct_object
        mocked_construct_object.return_value = scalar_node_0
        # Execute the method under test
        ansible_constructor_0.construct_vault_encrypted_unic

# Generated at 2022-06-25 04:25:28.004075
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    pass


# Generated at 2022-06-25 04:25:36.513958
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    # Test with argument 'node' set to None
    with pytest.raises(TypeError):
        ansible_constructor_0.construct_yaml_map(None)


# Generated at 2022-06-25 04:25:44.162107
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor(vault_secrets=[b'password'])
    vault = ansible_constructor._vaults['default']
    plaintext = b'We should get this back'
    ciphertext = vault.encrypt(plaintext, b"5")

    node = yaml.nodes.ScalarNode("tag:yaml.org,2002:str", ciphertext, '', '', '')
    result = ansible_constructor.construct_vault_encrypted_unicode(node)
    assert result.vault == vault
    assert result.ciphertext == ciphertext
    assert result.plaintext == plaintext


# Generated at 2022-06-25 04:25:44.999176
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_case_0()

# Generated at 2022-06-25 04:25:52.771590
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str = """
    firstname: &a 'James'
    lastname: &b 'Bond'
    occupation: &c
        - *a
        - *b
    """
    yaml_dict = {'firstname': 'James', 'lastname': 'Bond', 'occupation': ['James', 'Bond']}

    ansible_constructor = AnsibleConstructor()
    root = ansible_constructor.get_single_data(yaml_str)
    assert root == yaml_dict


# Generated at 2022-06-25 04:25:55.750270
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe('foo')


# Generated at 2022-06-25 04:26:05.613991
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_unsafe(node)

    # test cases from ansible/test/units/plugins/parsers/json/test_json.py:test_json_unsafe_filter
    class FakeNode(object):
        def __init__(self, id):
            self.id = id
            self.start_mark = None
    # test case 1
    node = FakeNode('int')
    assert ansible_constructor_1.construct_yaml_unsafe(node) == 123
    # test case 2
    node = FakeNode('list')
    assert ansible_constructor_1.construct_yaml_unsafe(node) == [1, 2, 3]
    # test case 3

# Generated at 2022-06-25 04:26:09.980544
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_case = AnsibleConstructor()
    # There is no return value for AnsibleConstructor.construct_mapping, so test for no exception being thrown
    try:
        test_case.construct_mapping()
    except:
        assert False


# Generated at 2022-06-25 04:26:20.304973
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    # Replace AnsibleConstructor._node_position_info with mock
    ansible_constructor.construct_yaml_str.__code__ = (lambda node: ("data.yaml", 0, 0)).__code__
    # Replace AnsibleConstructor.construct_scalar with mock
    ansible_constructor.construct_scalar.__code__ = (lambda node: "test_string").__code__

    # Check expected behavior
    assert isinstance(ansible_constructor.construct_yaml_str("mock_node"), AnsibleUnicode)

    # Check if the returned object is an instance of AnsibleUnicode
    # ansible_constructor.construct_yaml_str() should return a AnsibleUnicode object

# Generated at 2022-06-25 04:26:22.247981
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node = AnsibleNode(1342457286880)
    ansible_constructor_0.construct_yaml_str(node)

# Generated at 2022-06-25 04:26:27.825040
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    safe_load = AnsibleConstructor.construct_yaml_unsafe
    assert safe_load('value') == 'value'


# Generated at 2022-06-25 04:26:36.171967
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    vault_node_1 = '!vault'
    try:
        ansible_constructor_1.construct_vault_encrypted_unicode(vault_node_1)
    except Exception as e:
        assert False, 'AnsibleConstructor.construct_vault_encrypted_unicode raised Exception: ' + str(e)

# Generated at 2022-06-25 04:26:40.139366
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Initialize class
    ansible_constructor = AnsibleConstructor()

    # Define test data
    node = MappingNode()

    # Invoke method
    result = ansible_constructor.construct_mapping(node)

    # Check result
    assert type(result) is dict


# Generated at 2022-06-25 04:26:40.964710
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    assert True


# Generated at 2022-06-25 04:26:44.133426
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    value = 42
    result = ansible_constructor_0.construct_yaml_unsafe(value)
    assert(result._ansible == 42)


# Generated at 2022-06-25 04:26:45.751998
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:26:52.072512
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    string = to_bytes("{'fghij': 'klmno'}")
    yaml = to_bytes("!unsafe {'fghij': 'klmno'}")

    # calling construct_yaml_unsafe with arguments
    # string and yaml
    ansible_constructor.construct_yaml_unsafe(string, yaml)

# Generated at 2022-06-25 04:26:56.293042
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    args = AnsibleMapping()
    kwargs = {}
    kwargs['node'] = []
    kwargs['deep'] = []

    ansible_constructor_0 = AnsibleConstructor()
    try:
        ansible_constructor_0.construct_mapping(**kwargs)
    except ConstructorError:
        pass


# Generated at 2022-06-25 04:26:57.888179
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    

# Generated at 2022-06-25 04:27:04.780003
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    node_2 = create_MappingNode(None, None)
    data_3 = AnsibleMapping()
    value_4 = ansible_constructor_1.construct_mapping(node_2)
    data_3.update(value_4)
    data_3.ansible_pos = ansible_constructor_1._node_position_info(node_2)


# Generated at 2022-06-25 04:27:13.243123
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    # safe_constructor = yaml.constructor.SafeConstructor()
    # https://stackoverflow.com/questions/27782229/python-yaml-load-dict-key-error
    # assert ansible_constructor_1.construct_yaml_map(MappingNode(tag='tag:yaml.org,2002:map', value=[(ScalarNode(tag='tag:yaml.org,2002:str', value='key1'), ScalarNode(tag='tag:yaml.org,2002:str', value='value1')), (ScalarNode(tag='tag:yaml.org,2002:str', value='key2'), ScalarNode(tag='tag:yaml.org,2002:str', value='value2'))])) == {

# Generated at 2022-06-25 04:27:28.852907
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    # tag:yaml.org,2002:map
    # tag:yaml.org,2002:python/dict
    ansible_constructor_1 = AnsibleConstructor()
    mapping = AnsibleMapping()
    mapping['foo'] = 'bar'
    mapping['baz'] = 'qux'
    mapping.ansible_pos = ('dan', 1, 1)
    a = ansible_constructor_1.construct_object(mapping)
    print(a)

    # tag:yaml.org,2002:map
    # tag:yaml.org,2002:python/dict
    ansible_constructor_2 = AnsibleConstructor()
    mapping = AnsibleMapping()
    mapping.ansible_pos = ('dan', 1, 1)
   

# Generated at 2022-06-25 04:27:40.936459
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = """
       - foo: bar
         bacon: spam
       - bar: baz
         bacon: spam
         foo: bar
    """

    # This is the generated node list from testing data above

# Generated at 2022-06-25 04:27:52.448496
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml

# Generated at 2022-06-25 04:28:01.254836
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    b_data = to_bytes('#!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62353736656232643330346632653437363133306434623637336630396565383231656630653566\n          31340a35666233633936306433663431313732376366376139353434666435386633396361643236\n          3939386465303330623834623431643862306461633866350a')
    ret = ansible_constructor_0.construct_vault_encrypted_unicode(b_data)

# Generated at 2022-06-25 04:28:04.801142
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node = None
    assert AnsibleConstructor.construct_yaml_seq(ansible_constructor, node) is None


# Generated at 2022-06-25 04:28:07.740177
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode(None, None, None, None, None, None, None)
    expected = AnsibleMapping()
    actual = ansible_constructor_0.construct_mapping(node)
    assert actual == expected


# Generated at 2022-06-25 04:28:16.000350
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    # tripple-quoted string should raise SyntaxError
    node_1 = u'''[ufoo, ubar, u'{{foo}}']'''

    with pytest.raises(ConstructorError) as error:
        ansible_constructor_1.construct_yaml_seq(node_1)
    assert error.value.problem == 'did not find expected \':\' while scanning a simple key'

    # value with spaces should raise SyntaxError
    node_2 = '''[ufoo, ubar, u'{{ foo }}']'''

    with pytest.raises(ConstructorError) as error:
        ansible_constructor_1.construct_yaml_seq(node_2)

# Generated at 2022-06-25 04:28:20.042047
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    class_ = ansible_constructor.construct_yaml_seq.__self__.__class__
    assert class_ == AnsibleConstructor


# Generated at 2022-06-25 04:28:23.312399
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_1 = AnsibleMapping()
    ansible_constructor_0.construct_yaml_map(ansible_mapping_1)


# Generated at 2022-06-25 04:28:28.461954
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    # Test do-nothing case of adding vault password to constructor with no vault passwords
    ansible_constructor.construct_vault_encrypted_unicode(None)


# Generated at 2022-06-25 04:28:47.506463
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-25 04:28:52.966615
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Simply making sure this method runs without error.
    # Nothing we can verify as expected result.
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_vault_encrypted_unicode(None)
# <<<<<<< HEAD
# =======
# >>>>>>> ca47d69a44e7a2e9f5c78846d86d521ba3ce3bc3

# Generated at 2022-06-25 04:28:59.871987
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_constructor_0 = yaml.constructor.SafeConstructor()
    yaml_map_0 = yaml_constructor_0.construct_yaml_map(yaml_map_0)
    ansible_constructor_0 = AnsibleConstructor()
    ansible_map = ansible_constructor_0.construct_yaml_map(ansible_map)
    assert ansible_map  == yaml_map_0


# Generated at 2022-06-25 04:29:10.712985
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """Test construct_yaml_str method of AnsibleConstructor"""

    # Setup AnsibleConstructor
    ansible_constructor_1 = AnsibleConstructor()

    # Setup the yaml node
    from yaml import nodes
    yaml_node_1 = nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'value')

    # Call the method
    ansible_constructor_1.construct_yaml_str(yaml_node_1)

    # Setup AnsibleConstructor
    ansible_constructor_2 = AnsibleConstructor()

    # Setup the yaml node
    from yaml import nodes
    yaml_node_2 = nodes.ScalarNode(tag=u'tag:yaml.org,2002:str', value=u'value')

    #

# Generated at 2022-06-25 04:29:15.178038
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    ansible_constructor_0 = AnsibleConstructor()

    ansible_constructor_0.construct_yaml_seq('node')

# Generated at 2022-06-25 04:29:20.833032
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    ansible_constructor_1.construct_mapping(ansible_mapping_0)

# Generated at 2022-06-25 04:29:24.381526
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor(file_name=None, vault_secrets=None)


# Generated at 2022-06-25 04:29:27.488497
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    value = ansible_constructor_0.construct_yaml_map()
    assert value is not None


# Generated at 2022-06-25 04:29:31.446571
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # instantiating the class with no arguments
    ansible_constructor_0 = AnsibleConstructor()

    # TODO check the actual return value
    #ansible_constructor_0.construct_yaml_map()
    pass



# Generated at 2022-06-25 04:29:33.435776
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map()


# Generated at 2022-06-25 04:29:54.312201
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:30:00.039762
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # obj = AnsibleConstructor()
    pass
#
# def test_AnsibleConstructor_construct_vault_encrypted_unicode():
#     assert False
#
# def test_AnsibleConstructor_construct_yaml_map():
#     assert False
#
# def test_AnsibleConstructor_construct_yaml_seq():
#     assert False
#
# def test_AnsibleConstructor_construct_yaml_str():
#     assert False
#
# def test_AnsibleConstructor_construct_yaml_unsafe():
#     assert False
#
# def test_AnsibleConstructor_init():
#     assert False

# obj = AnsibleConstructor()

# ansible_constructor_0 = AnsibleConstructor()
# ansible_constructor_0.construct_

# Generated at 2022-06-25 04:30:10.503678
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with no vault_secrets
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = '!vault |\n          $ANSIBLE_VAULT;1.2;AES256;my_hostname\n          3131333430366265653534363530663431636362306264373430356461633236656630346133316137\n          3964626635343136636339636338636235656562316263363131643737303938373566353762326362\n          63643066333039383362313538\n          '
    # NOTE: The above string is the encrypted vault password, 'abcdef'
    # In the future, if this test needs to be repeated, create a new
    # encrypted password.

   

# Generated at 2022-06-25 04:30:16.593955
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=None)
    ansible_constructor.construct_mapping(node=None, deep=None)


# Generated at 2022-06-25 04:30:24.144992
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.to_unicode = lambda x: x
    ansible_constructor_1.construct_scalar = lambda x: 'get: ok'
    ansible_constructor_1._node_position_info = lambda x: ('test', 1, 2)
    ansible_constructor_1.construct_yaml_str(1)


# Generated at 2022-06-25 04:30:25.262809
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_vault_encrypted_unicode(node_0)


# Generated at 2022-06-25 04:30:27.061468
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(ansible_constructor_0, ansible_constructor_0)


# Generated at 2022-06-25 04:30:31.156595
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import os
    filename = os.path.dirname(os.path.abspath(__file__)) + "/../../../lib/ansible/parsing/yaml/constructor.py"
    filename = os.path.abspath(os.path.realpath(filename))
    ansible_constructor_0 = AnsibleConstructor(filename)


if __name__ == '__main__':
  test_case_0()
  test_AnsibleConstructor_construct_vault_encrypted_unicode()

# Generated at 2022-06-25 04:30:41.923354
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = node()
    # This is a String node

# Generated at 2022-06-25 04:30:44.439462
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    class YAMLNode_0(object):
        def __init__(self):
            self.start_mark = None


# Generated at 2022-06-25 04:31:02.560422
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print('unit test for AnsibleConstructor.construct_yaml_map')
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:31:06.419890
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    class AnsibleConstructor_construct_vault_encrypted_unicode_arguments:

        def __init__(self, node):
            self.node = node
    ansible_constructor_0.construct_vault_encrypted_unicode(AnsibleConstructor_construct_vault_encrypted_unicode_arguments(node=None))


# Generated at 2022-06-25 04:31:11.470516
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = [ 'random_secret' ]
    ansible_constructor.construct_vault_encrypted_unicode()


# Generated at 2022-06-25 04:31:15.477496
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    obj = AnsibleConstructor()
    out = obj.construct_yaml_unsafe(node=[])
    if isinstance(out, AnsibleUnicode) is True:
        raise AssertionError("[1] Expected False but got %s" % out)


# Generated at 2022-06-25 04:31:22.393271
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    ansible_constructor = AnsibleConstructor()

    # Test case with duplicated keys


# Generated at 2022-06-25 04:31:30.945574
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map({})
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_2.construct_yaml_map({u'key1': u'value1', u'key2': u'value2'})
    ansible_constructor_3 = AnsibleConstructor()
    ansible_constructor_3.construct_yaml_map({u'key1': u'value1', u'key2': u'value2', u'key3': [u'value3']})


# Generated at 2022-06-25 04:31:35.496906
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    c = AnsibleConstructor()
    with open('tests/yaml_data/test_vault.yaml', 'r') as f:
        data = f.read()
    vault_pass = 'secret'
    c.vault_secrets.append(vault_pass)
    safe_constructor = AnsibleConstructor(vault_secrets=c.vault_secrets)
    safe_constructor.construct_document(yaml.compose(data))

# Generated at 2022-06-25 04:31:42.303845
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()