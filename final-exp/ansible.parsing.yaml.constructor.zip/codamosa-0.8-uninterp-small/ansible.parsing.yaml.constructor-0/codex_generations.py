

# Generated at 2022-06-25 04:21:58.051914
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    bytes_0 = b'\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00(\x02\x00\x01\x00\x80\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00'
    ansible_constructor_0 = AnsibleConstructor(bytes_0)

# Generated at 2022-06-25 04:22:06.702003
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    data = b"""
    - one: 1
      two: 2
    - three: 3
      four: 4
    """
    yaml = YAML(typ='safe')
    content = yaml.load(data)
    assert content == [{u'four': 4, u'three': 3}, {u'one': 1, u'two': 2}]

    # make sure we get an exception when we have duplicate keys
    data = b"""
    - one: 1
      two: 2
    - three: 3
      two: 4
    """
    yaml = YAML(typ='safe')
    try:
        content = yaml.load(data)
    except ConstructorError:
        pass
    else:
        assert False, "Expected error for duplicate key"



# Generated at 2022-06-25 04:22:12.859289
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Initialization
    bytes_0 = b"\xf0\x11'\xf2\xf1\x7f\r\xe8fP"
    ansible_constructor = AnsibleConstructor(bytes_0)
    # Execution
    ansible_constructor.construct_mapping()


# Generated at 2022-06-25 04:22:23.126749
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    bytes_0 = b"\xf0\x11'\xf2\xf1\x7f\r\xe8fP"
    ansible_constructor_0 = AnsibleConstructor(bytes_0)
    ansible_constructor_1 = AnsibleConstructor(bytes_0)
    ansible_constructor_2 = AnsibleConstructor(bytes_0)
    ansible_constructor_3 = AnsibleConstructor(bytes_0)
    mapping_node_0 = MappingNode(ansible_constructor_0, ansible_constructor_1, ansible_constructor_2, ansible_constructor_3)
    ansible_constructor_4 = AnsibleConstructor(bytes_0)
    ansible_constructor_5 = AnsibleConstructor(bytes_0)
    ansible_constructor_6

# Generated at 2022-06-25 04:22:30.924973
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    bytes_0 = b"\xf0\x11'\xf2\xf1\x7f\r\xe8fP"
    ansible_constructor_0 = AnsibleConstructor(bytes_0)

    yaml_node_0 = None
    ansible_mapping_0 = AnsibleMapping()
    ansible_dict_0 = ansible_constructor_0.construct_yaml_map(yaml_node_0)
    assert isinstance(ansible_dict_0, AnsibleMapping)



# Generated at 2022-06-25 04:22:42.876920
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
  bytes_0 = b"\xf0\x11'\xf2\xf1\x7f\r\xe8fP"
  bytes_1 = b"\xf0\x11'\xf2\xf1\x7f\r\xe8fP"
  str_0 = "b@I\x1a\xe2\xec\x15\x17\x0b\x83\xb5\x98\x07\x1e\x1a\x10\xe9\xcc\x18\xc4"
  str_1 = "b@I\x1a\xe2\xec\x15\x17\x0b\x83\xb5\x98\x07\x1e\x1a\x10\xe9\xcc\x18\xc4"
 

# Generated at 2022-06-25 04:22:53.276924
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test with a single empty string
    bytes_0 = b'""'
    ansible_constructor_0 = AnsibleConstructor(bytes_0)

    # Test with a single non-empty string
    bytes_1 = b'"a"'
    ansible_constructor_1 = AnsibleConstructor(bytes_1)

    # Test with a single non-empty string containing a single quote
    bytes_2 = b"''"
    ansible_constructor_2 = AnsibleConstructor(bytes_2)

    # Test with a single non-empty string containing a single quote
    bytes_3 = b"'a'"
    ansible_constructor_3 = AnsibleConstructor(bytes_3)

    # Test with a single non-empty string containing a double quote
    bytes_4 = b'"a"'
    ansible_constructor_4

# Generated at 2022-06-25 04:22:57.066572
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._load_all_data()



# Generated at 2022-06-25 04:23:07.726209
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # init data
    file_name_0 = 'file.yml'
    vault_secret_0 = 'password'
    ansible_constructor_0 = AnsibleConstructor(file_name_0, vault_secret_0)

# Generated at 2022-06-25 04:23:18.129732
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # Test with correct, expected arguments
    bytes_0 = b"L\x98\x99i\x92c"
    ansible_constructor_0 = AnsibleConstructor(bytes_0)
    mapping_node_0 = MappingNode()
    ansible_mapping_0 = ansible_constructor_0.construct_yaml_map(mapping_node_0)

    # Test with invalid arguments
    bytes_1 = b"\x0e\x14w\x1f\x14\xdb\x1c%\xfe4"
    ansible_constructor_1 = AnsibleConstructor(bytes_1)

    with pytest.raises(ConstructorError):
        ansible_constructor_1.construct_yaml_map(mapping_node_0)


# Generated at 2022-06-25 04:23:28.109256
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
# No parameter testcase for method construct_yaml_str of class AnsibleConstructor

# No return value testcase for method construct_yaml_str of class AnsibleConstructor

# No exception testcase for method construct_yaml_str of class AnsibleConstructor


# Generated at 2022-06-25 04:23:29.122745
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # TODO: implement unit test
    pass


# Generated at 2022-06-25 04:23:35.614777
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    value = '''\
    { 
        key0: value0
        key1: value1
        key2: value2
        key3: value3
        key4: value4
        key5: value5
    }'''
    node = yaml_0.load(value)
    actual_value = ansible_constructor_0.construct_mapping(node)
    expected_value = '''\
    { 
        key0: value0
        key1: value1
        key2: value2
        key3: value3
        key4: value4
        key5: value5
    }'''
    assert actual_value == expected_value


# Generated at 2022-06-25 04:23:45.158959
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    yaml_data = {"0": "!vault |\n      $ANSIBLE_VAULT;1.1;AES256\n      61323133363862343730326564353262333761366563376361623831666430363364633062356234\n      33623234363266353430656635366136316537\n      393635383037373536336433633832356465346530393264316164666433373564613030313772\n      613931633238633631343762363031663831\n      616361343238633861326263613035323532323461643837383136653261666532313665\n"}

# Generated at 2022-06-25 04:23:47.176244
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_unsafe == None


# Generated at 2022-06-25 04:23:53.424739
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    with pytest.raises(Exception) as excinfo:
        ansible_constructor_0.construct_yaml_seq(node)
    assert excinfo.value.args[0] == "Unresolvable node"


# Generated at 2022-06-25 04:23:57.922489
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

    # Test for method construct_mapping (1/1)
    test_object = ansible_constructor_0.construct_mapping()
    assert isinstance(test_object, dict) is True


# Generated at 2022-06-25 04:24:03.853135
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # set up valid input
    yaml_data = '''
        foo: "bar"
        ansible_pos:
            datasource: "example"
            line: 1
            column: 1
        '''

    # call function under test
    yaml_loaded = AnsibleConstructor().construct_mapping(yaml_data)

    # check results
    assert yaml_loaded['foo'] == 'bar'
    assert yaml_loaded.ansible_pos == ('example', 1, 1)

# Generated at 2022-06-25 04:24:10.785210
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = '[ 1, 2, 3 ]'
    loader = AnsibleLoader(yaml_data)
    yaml_data_0 = loader.get_single_data()
    ansible_constructor_0 = AnsibleConstructor()
    expected_0 = [1, 2, 3]
    value_0 = ansible_constructor_0.construct_yaml_seq(yaml_data_0)
    assert value_0.ansible_pos == (None, 0, 0)
    assert value_0 == expected_0


# Generated at 2022-06-25 04:24:16.356399
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    testyaml = '''
- name: test data
  value: some data
  data:
    - 1
    - 2
    - 3
    - 4
'''
    ansible_constructor = AnsibleConstructor()
    x = ansible_constructor.get_single_data(testyaml)
    assert x.get('name') == 'test data'
    assert x.get('value') == 'some data'
    assert x.get('data') == [1, 2, 3, 4]


# Generated at 2022-06-25 04:24:33.867320
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    node = MappingNode('tag:yaml.org,2002:map', [], {}, [])
    node.value = "test"
    node.level = "test"
    node.index = "test"
    node.line = 7
    node.column = 8
    node.tag = "tag:yaml.org,2002:map"
    node.id = "tag:yaml.org,2002:map"
    node.value = "test"
    node.start_mark = "test"
    node.end_mark = "test"
    node.flow_style = "test"
    ansible_constructor_1.construct_yaml_map(node)


# Generated at 2022-06-25 04:24:38.711058
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = None
    deep = False

    print("Testing with node=", node)
    print("Testing with deep=", deep)

    ansible_constructor_0 = AnsibleConstructor()

    ## Docstring example
    ansible_constructor_0.construct_mapping(node, deep)



# Generated at 2022-06-25 04:24:42.670925
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test with minimum required parameters.
    ansible_constructor_s = AnsibleConstructor()
    ansible_constructor_s.construct_vault_encrypted_unicode()


# Generated at 2022-06-25 04:24:45.625834
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq()



# Generated at 2022-06-25 04:24:49.562995
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_yaml_unsafe('test_value') == "test_value"


# Generated at 2022-06-25 04:25:00.907927
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    ansible_constructor_0 = AnsibleConstructor()

    ansible_constructor_0.construct_yaml_seq(MappingNode(tag='tag:yaml.org,2002:map', value=[],
                                                           flow_style=False))


# Generated at 2022-06-25 04:25:02.541196
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(MappingNode())


# Generated at 2022-06-25 04:25:04.965739
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq()


# Generated at 2022-06-25 04:25:13.749842
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_

# Generated at 2022-06-25 04:25:22.653761
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()

# Generated at 2022-06-25 04:25:33.330185
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    pass  # TODO: implement your test here



# Generated at 2022-06-25 04:25:37.203721
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    # Testing if an exception is raised for wrong parameter types
    with pytest.raises(TypeError):
        ansible_constructor_0.construct_yaml_map(1)

# Generated at 2022-06-25 04:25:40.386765
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode(u'tag:yaml.org,2002:map', [], [], [], flow_style=False)
    ansible_constructor.construct_yaml_seq(node)


# Generated at 2022-06-25 04:25:44.875402
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

    construct_mapping_0 = ansible_constructor_0.construct_mapping(mapping=MappingNode())

    assert isinstance(construct_mapping_0, AnsibleMapping)


# Generated at 2022-06-25 04:25:47.782787
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    # TODO
    assert ansible_constructor_0.construct_mapping(node) == AnsibleMapping()


# Generated at 2022-06-25 04:25:57.570151
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    i, j = ansible_constructor_0.construct_yaml_str(node)
    assert i == "" and j == False, "Test 1: expected (\"\", False), got ({}, {})".format(i, j)
    i, j = ansible_constructor_0.construct_yaml_str(node)
    assert i == "" and j == False, "Test 2: expected (\"\", False), got ({}, {})".format(i, j)
    i, j = ansible_constructor_0.construct_yaml_str(node)
    assert i == "" and j == False, "Test 3: expected (\"\", False), got ({}, {})".format(i, j)
    i, j = ansible_constructor_0.construct_y

# Generated at 2022-06-25 04:26:06.205092
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = [ 'secret1' ]

    test_cases = [
        '''
            - name: testcase0
              debug: msg="testcase0"
              tags:
                - testcase0
        '''
    ]

    for testcase in test_cases:
        ansible_sequence = yaml.load(testcase)
        assert type(ansible_sequence) is AnsibleSequence
        assert ansible_sequence.ansible_pos == ('<unicode string>', 1, 0)
        an0 = ansible_sequence[0]
        assert an0.ansible_pos == ('<unicode string>', 2, 10)
        assert an0['name'] == 'testcase0'

# Generated at 2022-06-25 04:26:09.976311
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    vault_dict = {}
    ciphertext_data = "test"
    ansible_constructor.construct_vault_encrypted_unicode(vault_dict, ciphertext_data)


# Generated at 2022-06-25 04:26:11.417837
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor is not None


# Generated at 2022-06-25 04:26:18.651923
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node = "node"
    data = ansible_constructor_0.construct_yaml_seq(node)
    assert type(data) == GeneratorType
    assert len(data) == 2
    ansible_constructor_1 = AnsibleConstructor()
    node = "node"
    data = ansible_constructor_1.construct_yaml_seq(node)
    assert type(data) == GeneratorType
    assert len(data) == 2

## Unit test for method construct_yaml_map of class AnsibleConstructor
# def test_AnsibleConstructor_construct_yaml_map():
#     ansible_constructor_0 = AnsibleConstructor()
#     node = "node"
#     data = ansible_constructor_0.construct_

# Generated at 2022-06-25 04:26:42.062491
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor_construct_yaml_seq_0 = ansible_constructor.construct_yaml_seq()
    ansible_constructor_construct_yaml_seq_1 = ansible_constructor.construct_yaml_seq(node=node_0)


# Generated at 2022-06-25 04:26:42.974586
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    assert 1 == 1

# Generated at 2022-06-25 04:26:48.393275
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    obj = AnsibleConstructor()
    node = u'tag:yaml.org,2002:map'
    ansible_constructor_mock = get_ansible_constructor_mock()
    ansible_constructor_mock.construct_yaml_map = Mock(return_value='ansible_constructor_mock.construct_yaml_map')
    ansible_constructor_mock.add_constructor = Mock(return_value='ansible_constructor_mock.add_constructor')
    ansible_constructor_mock.construct_unsafe = Mock(return_value='ansible_constructor_mock.construct_unsafe')
    ansible_constructor_mock._vaults = {'default': 'ansible_constructor_mock._vaults.default'}
    ansible_construct

# Generated at 2022-06-25 04:26:55.246801
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor('/home/strahlex/ansible/hacking/test/units/parsing/yaml/data/yaml_constructor_data_0.txt')

    # Construct a scalar node
    constructor_1 = ansible_constructor_1.construct_scalar

    # Construct a sequence node
    constructor_2 = ansible_constructor_1.construct_yaml_seq

    # Construct a mapping node
    constructor_3 = ansible_constructor_1.construct_yaml_map

    return



# Generated at 2022-06-25 04:26:58.558948
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    node = MappingNode(u'tag:yaml.org,2002:map', [1, 2], False, {}, node_class=MappingNode)
    obj = AnsibleConstructor()
    ansible_constructor_return_value = obj.construct_yaml_map(node)
    assert isinstance(ansible_constructor_return_value, AnsibleMapping)


# Generated at 2022-06-25 04:27:02.528249
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = 'str'
    assert isinstance(ansible_constructor_0.construct_yaml_str(node_0), AnsibleUnicode)


# Generated at 2022-06-25 04:27:07.163772
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    value_1 = 'hello'
    node_1 = ansible_constructor_1.construct_yaml_str(node=value_1)
    result_1 = ansible_constructor_1.construct_yaml_unsafe(node=node_1)
    assert result_1 == wrap_var('hello')

# Generated at 2022-06-25 04:27:11.589598
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    ansible_constructor_1 = AnsibleConstructor()
    value_list_1 = [1,2,3]
    result_1 = ansible_constructor_1.construct_yaml_seq(value_list_1)

    assert_equal(result_1, value_list_1)



# Generated at 2022-06-25 04:27:18.563009
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()

    ansible_constructor_0.vault_secrets = ['abcdefghijklmnopqrstuvwxyz']
    ansible_constructor_0.vault_secrets = ['abcdefghijklmnopqrstuvwxyz']

    ansible_constructor_0.vault_secrets = ['abcdefghijklmnopqrstuvwxyz']
    ansible_constructor_0.vault_secrets = ['abcdefghijklmnopqrstuvwxyz']

    ansible_constructor_0.vault_secrets = ['abcdefghijklmnopqrstuvwxyz']

# Generated at 2022-06-25 04:27:25.568827
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    yaml_nodes_MappingNode_2 = MappingNode(tag='tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    import six
    with six.assertRaisesRegex(AssertionError, ""):
        ansible_constructor_1.construct_yaml_map(yaml_nodes_MappingNode_2)



# Generated at 2022-06-25 04:27:57.743604
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:28:03.512529
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # FIXME: add unit test for AnsibleConstructor.construct_vault_encrypted_unicode
    
    # assert True
    pass





# Generated at 2022-06-25 04:28:06.402951
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    keys = ['a', 'b', 'c']
    values = ['d', 'e', 'f']
    print(ansible_constructor_1.construct_mapping(keys, values))


# Generated at 2022-06-25 04:28:08.957386
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Testing if an unicode object is always returned
    yaml_str = 'Hello'

    ret_obj = AnsibleConstructor.construct_yaml_str(yaml_str)
    assert ret_obj == 'Hello'
    assert isinstance(ret_obj, AnsibleUnicode) is True


# Generated at 2022-06-25 04:28:12.415694
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()

    # TODO: maybe use a real yaml node instead of one that just prints its id
    assert wrap_var(u'!yaml_node') == ansible_constructor_0.construct_yaml_unsafe(u'!yaml_node')


# Generated at 2022-06-25 04:28:15.046811
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()

    data = {}
    node = {}
    assert_equals(ansible_constructor.construct_yaml_seq(node), data)


# Generated at 2022-06-25 04:28:23.828085
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node = AnsibleUnicode()
    # Node must be of type ScalarNode, not AnsibleUnicode
    try:
        ansible_constructor_0.construct_yaml_str(node)
    except TypeError as e:
        assert( e == 'expected a yaml.nodes.ScalarNode, but found <class \'ansible.parsing.yaml.objects.AnsibleUnicode\'>')
    except:
        print ('Expected TypeError')


# Generated at 2022-06-25 04:28:32.612264
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()

    # Test using strings
    # Test using strings - characters : and '
    data = []
    data.append({u'k1': u'v1'})
    ansible_constructor.construct_yaml_seq(data)

    # Test using strings - characters : and "
    data = []
    data.append({u'k1': u'v1'})
    ansible_constructor.construct_yaml_seq(data)

    # Test using strings - characters : and ""
    data = []
    data.append({u'k1': u'v1'})
    ansible_constructor.construct_yaml_seq(data)

    #Test using strings - characters : and """
    data = []

# Generated at 2022-06-25 04:28:35.239657
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    node = {}
    ansible_constructor_1.construct_yaml_seq(node)


# Generated at 2022-06-25 04:28:39.113769
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Make instance of parser
    ansible_constructor_0 = AnsibleConstructor()
    # Create value to pass to constructor
    node_0 = parse_yaml('!unsafe')
    # Call method using instance
    ansible_constructor_0.construct_yaml_unsafe(node_0)


# Generated at 2022-06-25 04:30:46.534595
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Data structure tests
    def test_construct_mapping_0_p1():
        input_node = {}
        mapping = AnsibleMapping()
        mapping.ansible_pos = None
        assert(ansible_constructor_0.construct_mapping(input_node) == mapping)

    def test_construct_mapping_0_p2():
        input_node = {}
        mapping = AnsibleMapping()
        assert(ansible_constructor_0.construct_mapping(input_node) != mapping)

    def test_construct_mapping_1_p1():
        input_node = {}
        mapping = AnsibleMapping()
        mapping.ansible_pos = None
        assert(ansible_constructor_0.construct_mapping(input_node) == mapping)


# Generated at 2022-06-25 04:30:56.424954
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-25 04:31:04.339916
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_doc = """
            foo: bar
            baz:
            - some
            - list
            - of
            - items
        """
    ans_vault_secret = 'DUMMY-ANSIBLE-VAULT-SECRET'
    ans_constructor = AnsibleConstructor(vault_secrets=[ans_vault_secret])
    ans_result = yaml.load(yaml_doc, Loader=yaml.Loader)
    print (ans_result)
    print(ans_result['foo'])
    print(ans_result['baz'])

test_case_0()
test_AnsibleConstructor_construct_yaml_map()

# Generated at 2022-06-25 04:31:13.670800
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    # Testing if TypeError raised when 'node' is of incorrect type
    try:
        ansible_constructor_0.construct_vault_encrypted_unicode('node')
    except TypeError as err:
        assert type(err) == TypeError
    else:
        raise AssertionError('TypeError not raised')


# Generated at 2022-06-25 04:31:15.071702
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map()


# Generated at 2022-06-25 04:31:16.967667
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_yaml_seq(None) == None

# Generated at 2022-06-25 04:31:20.907394
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    param_1 = None
    try:
        ansible_constructor_1.construct_yaml_unsafe(param_1)
    except TypeError as exc:
        assert exc.args == ("construct_yaml_unsafe() missing 1 required positional argument: 'node'",)


test_case_0()
#test_AnsibleConstructor_construct_yaml_unsafe()

# Generated at 2022-06-25 04:31:23.276660
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    obj = AnsibleConstructor()
    # No exceptions should be thrown

# Generated at 2022-06-25 04:31:34.144705
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    yaml_document = '\n foo: bar'
    from yaml import Loader, Scanner
    from yaml.nodes import ScalarNode
    scalar_node = ScalarNode(tag='tag:yaml.org,2002:python/unicode',
                             value='bar',
                             start_mark=None,
                             end_mark=None,
                             style=None)
    mapping_node = MappingNode(tag='tag:yaml.org,2002:map',
                               value=[('foo', scalar_node)],
                               start_mark=None,
                               end_mark=None,
                               flow_style=True)
    ansible_mapping = ansible_constructor.construct_mapping(mapping_node)
    print

# Generated at 2022-06-25 04:31:36.432588
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ret = ansible_constructor_0.construct_mapping(node='node')
    assert ret is None
