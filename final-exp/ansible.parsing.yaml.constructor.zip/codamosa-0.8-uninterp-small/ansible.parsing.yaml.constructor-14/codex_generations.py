

# Generated at 2022-06-25 04:21:52.568616
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Test case 1
    # Construct a mapping with duplicate keys.
    yaml_0 = """
 - name: test_dup_dict
   debug:
     msg: '1'
   debug:
     msg: '2'
"""
    safe_load = AnsibleConstructor.add_multi_constructor(u'tag:yaml.org,2002:python/dict', AnsibleConstructor.construct_mapping)
    data = yaml.load(yaml_0, Loader=safe_load)
    assert data == [{'debug': {'msg': '2'}, 'name': 'test_dup_dict'}]

    # Test case 2
    # Construct a mapping with duplicate keys.

# Generated at 2022-06-25 04:21:58.575014
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor= AnsibleConstructor(file_name='/Users/vagrant/code/ansible/test/units/modules/utils/test_yaml.py')
    node = object()
    try:
        constructor = getattr(node, 'id', 'object')
        if constructor is not None:
            constructor = getattr(ansible_constructor, 'construct_%s' % constructor)
    except AttributeError:
        constructor = ansible_constructor.construct_object
    value = constructor(node)
    relay = wrap_var(value)


# Generated at 2022-06-25 04:22:02.290100
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = object()
    assert ansible_constructor_0.construct_yaml_map(node) is not None


# Generated at 2022-06-25 04:22:03.940244
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:22:06.987414
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    class Node:
        id = 'mapping'
        start_mark = 1
        value = [('key', 'value')]
    ansible_constructor_1.construct_mapping(Node)



# Generated at 2022-06-25 04:22:08.007613
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_case_0()

# Generated at 2022-06-25 04:22:19.287571
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    test_unicode_0 = 'password'
    test_univode_1 = 'admin'

    vault_secrets = [
        test_unicode_0,
        test_univode_1,
    ]

    ansible_constructor_0 = AnsibleConstructor(vault_secrets=vault_secrets)

    # Initialize test_mapping_0
    test_mapping_0 = AnsibleMapping()
    test_mapping_0['password'] = 'password'
    test_mapping_0['admin'] = 'admin'

    # Initialize test_ansible_vault_encrypted_unicode_0
    test_ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)

# Generated at 2022-06-25 04:22:20.897872
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = object()

    data = ansible_constructor_0.construct_yaml_seq(node_0)

    try:
        data.next()
    except StopIteration:
        pass



# Generated at 2022-06-25 04:22:28.220693
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    assert AnsibleConstructor().construct_yaml_str(u'Aladdin') == u'Aladdin'
    assert AnsibleConstructor().construct_yaml_str(u'open sesame') == u'open sesame'
    assert AnsibleConstructor().construct_yaml_str(u'') == u''
    assert AnsibleConstructor().construct_yaml_str(u'The Cask of Amontillado') == u'The Cask of Amontillado'


# Generated at 2022-06-25 04:22:31.509029
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    o = AnsibleConstructor()
    node = True
    deep = True
    result = o.construct_yaml_map(node, deep)
    assert type(result) is AnsibleMapping

# Generated at 2022-06-25 04:22:40.538243
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_obj0 = AnsibleConstructor()
    node_obj0 = AnsibleUnicode('tag:yaml.org,2002:str')
    ansible_constructor_obj0.construct_yaml_str(node_obj0)


# Generated at 2022-06-25 04:22:41.863707
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:22:46.290102
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    # test for success
    assert True


# Generated at 2022-06-25 04:22:49.539502
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = u"foo: bar\n\n"
    ansible_constructor_1 = AnsibleConstructor()
    dict_2 = ansible_constructor_1.construct_mapping(yaml_data)


# Generated at 2022-06-25 04:22:58.394205
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[])

    # testing when node is not a MappingNode
    # node = SequenceNode(tag='tag:yaml.org,2002:seq', value=[])
    # assert_raises(ConstructorError, ansible_constructor.construct_mapping, node)

    # testing when key is not hashable
    node.value.append([ScalarNode(tag=u'tag:yaml.org,2002:str', value='foo'), ScalarNode(tag=u'tag:yaml.org,2002:str', value='bar')])

# Generated at 2022-06-25 04:23:00.663451
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map()


# Generated at 2022-06-25 04:23:03.651907
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    node = {}
    ansible_constructor_0.construct_yaml_unsafe(node)


# Generated at 2022-06-25 04:23:15.547497
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Checking construct_mapping of AnsibleConstructor when
    # DUPLICATE_YAML_DICT_KEY: fail
    ansible_const_0 = AnsibleConstructor()
    C.DUPLICATE_YAML_DICT_KEY = 'fail'
    try:
        ansible_const_0.construct_mapping({})
    except ConstructorError:
        pass
    else:
        assert False, "Failed to raise ConstructorError"

    # Checking construct_mapping of AnsibleConstructor when
    # DUPLICATE_YAML_DICT_KEY: warn
    ansible_const_1 = AnsibleConstructor()
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    ansible_mapp_0 = ansible_const_1.construct_mapping

# Generated at 2022-06-25 04:23:19.712548
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()

# Generated at 2022-06-25 04:23:24.767606
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    yaml_data_1 = None
    deep = False
    result = ansible_constructor_1.construct_mapping(yaml_data_1, deep)
    assert 'mapping' in result, "Failed to return any data from construct_mapping"



# Generated at 2022-06-25 04:23:32.903169
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = [ 'foo','bar','dog','cat' ]
    ansible_constructor.construct_vault_encrypted_unicode(None)


# Generated at 2022-06-25 04:23:36.010682
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    key_node_1 = 'map'
    value_node_1 = 'value'
    deep_1 = 'deep'
    ansible_constructor_1.construct_mapping(key_node_1, value_node_1, deep_1)


# Generated at 2022-06-25 04:23:38.747250
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:23:40.533742
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    # Test cases may be needed here



# Generated at 2022-06-25 04:23:45.522703
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import yaml

    yaml_str = u'''
a: 1
b: !unsafe '2'
c: !unsafe 3
d: &d 4
   e: !unsafe *d
'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data[u'a'] == 1
    assert data[u'b'] == 2
    assert data[u'c'] == 3
    assert data[u'd'] == 4
    assert data[u'e'] == 4



# Generated at 2022-06-25 04:23:48.742977
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor()
    node = MappingNode('tag:yaml.org,2002:map', [], [], start_mark=None, end_mark=None)
    d = c.construct_mapping(node)
    assert d == {}, d


# Generated at 2022-06-25 04:24:01.935850
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()

    # Test with str as input
    node = "str"
    expected = AnsibleUnicode("str")
    assert (ansible_constructor.construct_yaml_str(node) == expected)

    # Test with AnsibleUnicode as input
    node = AnsibleUnicode("unicode")
    expected = AnsibleUnicode("unicode")
    assert (ansible_constructor.construct_yaml_str(node) == expected)

    # Test with int as input
    node = 123
    expected = AnsibleUnicode("123")
    assert (ansible_constructor.construct_yaml_str(node) == expected)


# Generated at 2022-06-25 04:24:05.651976
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_map_0 = AnsibleConstructor.construct_yaml_map()
    assert yaml_map_0 is not None


# Generated at 2022-06-25 04:24:08.470081
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    t = MappingNode('tag:yaml.org,2002:map', [],
        start_mark=None, end_mark=None)
    d = AnsibleConstructor.construct_yaml_map(t)

# Generated at 2022-06-25 04:24:16.727620
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    map_str = "var:\n  foo:\n    - name: 'John'\n    - value: 'John'\n" + \
              "another_var:\n  foo:\n    - name: 'John'\n    - value: 'John'\n"

    yaml_parent = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=False)
    node = MappingNode(tag=u'tag:yaml.org,2002:str', value=[], flow_style=False)
    node.start_mark = node.end_mark = node.key_mark = node.value_mark = None

# Generated at 2022-06-25 04:24:28.361762
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = AnsibleConstructor.construct_yaml_str(ansible_constructor_0, 'x')


    # check for attribute ansible_pos
    try:
        ansible_constructor_0.ansible_pos
    except AttributeError:
        pass
    else:
        raise AssertionError("Expected AttributeError")



# Generated at 2022-06-25 04:24:31.064815
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode()
    ansible_constructor_0.node_to_yaml(node_0)


# Generated at 2022-06-25 04:24:32.361688
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:24:33.908545
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:24:38.509179
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = AnsibleMapping()
    construct_yaml_unsafe_0 = ansible_constructor_0.construct_yaml_unsafe(yaml_node_0)


# Generated at 2022-06-25 04:24:47.610173
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ["testVaultPassword"]
    vault_secrets_repr = ["testVaultPassword"]
    ansible_constructor_0 = AnsibleConstructor("file_name", vault_secrets)
    ansible_constructor_0._vaults.clear()
    ansible_constructor_0._vaults["default"] = VaultLib(secrets=vault_secrets)
    ansible_constructor_0._vaults["default"].secrets = vault_secrets_repr
    ansible_constructor_1 = AnsibleConstructor("file_name", vault_secrets)
    ansible_constructor_1._vaults.clear()
    ansible_constructor_1._vaults["default"] = VaultLib(secrets=vault_secrets)
    ansible_constructor_1._v

# Generated at 2022-06-25 04:24:56.255865
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults['default'] = VaultLib(secrets=['my_vault_password'])
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n51e121b9ec9f91370dfe7284c0735a0c7a873856e42a7a4f4f4f4f4f4f4f4f4f\n'
    yaml_str_node = {'value': ciphertext, 'start_mark': {'name': 'str', 'line': 4, 'column': 2},
                     'end_mark': {'name': 'str', 'line': 4, 'column': 52}, 'tag': u'tag:yaml.org,2002:str'}
    value = ans

# Generated at 2022-06-25 04:25:03.006502
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    test_string = 'val1'
    result = ansible_constructor_0.construct_yaml_str(test_string)
    assert result is not None


# Generated at 2022-06-25 04:25:13.089818
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1._vaults = {u'default': VaultLib(secrets=None)}
    ansible_constructor_1.vault_secrets = []

# Generated at 2022-06-25 04:25:15.070488
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_str()


# Generated at 2022-06-25 04:25:21.867785
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    x = ansible_constructor_0.construct_yaml_unsafe(u'a')
    assert x == u'a'

# Generated at 2022-06-25 04:25:23.318746
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ans_con = AnsibleConstructor()
    ans_con.construct_yaml_str('node')

# Generated at 2022-06-25 04:25:32.569071
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # yaml is both imported and used in the function, so disable pylint warning:
    # pylint: disable=import-error,unused-variable,no-name-in-module
    import yaml

    yaml_data = """
- 1
- 2
- 3
"""

    data = AnsibleSequence()
    data.append(1)
    data.append(2)
    data.append(3)

    assert data == yaml.load(yaml_data, Loader=AnsibleConstructor)


# Generated at 2022-06-25 04:25:40.377995
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_unsafe(0)
    ansible_constructor.construct_yaml_unsafe('0')
    ansible_constructor.construct_yaml_unsafe(['0'])
    ansible_constructor.construct_yaml_unsafe({'0': '0'})
    ansible_constructor.construct_yaml_unsafe({'0': ['0']})


# Generated at 2022-06-25 04:25:45.175924
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    #
    # This code will be executed after the test, so we need to create a new object
    ansible_constructor_1 = AnsibleConstructor()
    #
    # The following line is just to silence PyCharm warnings
    dummy_1 = ansible_constructor_1


# Generated at 2022-06-25 04:25:55.312441
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-25 04:26:04.835412
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    # Mock object node:
    class node:
        start_mark = None
        id = None
    # Mock object value_node:
    class value_node:
        start_mark = None
        id = None
    value = 'Test string'
    ansible_constructor_0.construct_scalar = MagicMock(return_value = value)
    ansible_constructor_0._node_position_info = MagicMock(return_value = (None, None, None))
    ansible_constructor_0.construct_yaml_str(value_node)
    ansible_constructor_0._node_position_info.assert_called_with(value_node)



# Generated at 2022-06-25 04:26:13.802615
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

    ansible_constructor._vaults['default'] = VaultLib(secrets=['test'])

    class Test_node:
        def __init__(self):
            self.value = 'test'
            class Test_start_mark:
                def __init__(self):
                    self.column = 1
                    self.line = 1
                    self.name = None
            self.start_mark = Test_start_mark()
            self.id = 'vault'

        def __str__(self):
            return 'Test_node'

    test_node = Test_node()

    ret = ansible_constructor.construct_vault_encrypted_unicode(test_node)



# Generated at 2022-06-25 04:26:25.770012
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    obj1 = AnsibleConstructor()
    voice_text = 'a'*32
    ciphertext_data = obj1._vaults['default'].encrypt(voice_text)
    vaulted = '$ANSIBLE_VAULT;%s;%s' % ("", ciphertext_data.decode('utf-8'))
    secret = 'sekiro'
    obj2 = AnsibleConstructor(vault_secrets=[secret])
    encrypted_unicode_object = obj2.construct_vault_encrypted_unicode(MappingNode(u'tag:yaml.org,2002:str', [],
                                                                                 start_mark=None,
                                                                                 end_mark=None,
                                                                                 value=vaulted))

# Generated at 2022-06-25 04:26:32.410348
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    vault_secrets_0 = []

    # Test for vault_secrets == []
    ansible_constructor_0._vaults['default'] = VaultLib(secrets=vault_secrets_0)
    try:
        ansible_constructor_0.construct_vault_encrypted_unicode(node)
        # Should throw exception if vault_secrets == [], but not throw
    except ConstructorError:
        pass
    except Exception:
        raise Exception('Failure to check for ConstructorError when vault_secrets == []')

    # Test for vault_secrets != []
    ansible_constructor_0._vaults['default'] = VaultLib(secrets=['password1', 'password2'])

# Generated at 2022-06-25 04:26:42.212161
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """
    :rtype: void
    """
    ansible_constructor = AnsibleConstructor(file_name='/home/ansible/ansible/lib/ansible/parsing/yaml/loader.py')
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[])
    ansible_constructor.construct_yaml_map(node)


# Generated at 2022-06-25 04:26:53.721904
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_s = '''
{
    '1': '1',
    '2': '2'
}
'''
    yaml_no = '''
{
    '1': '1',
    '1': '2'
}
'''
    yaml_no1 = '''
{
    '1': '1',
    '2': '1'
}
'''
    print('test case 0')
    print('test_AnsibleConstructor_construct_mapping')
    # ansible_mapping, ansible_pos = AnsibleConstructor().construct_mapping(yaml_s, deep=False)
    ansible_mapping, ansible_pos = AnsibleConstructor().construct_mapping(yaml_s)
    # print('ansible_mapping = %s, ansible_

# Generated at 2022-06-25 04:26:54.542301
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass



# Generated at 2022-06-25 04:26:58.818082
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0.construct_yaml_seq(node=None), types.GeneratorType)


# Generated at 2022-06-25 04:27:05.645913
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = u'YAML string test'
    node = Mock()
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_scalar = Mock(return_value=yaml_str)

    ansible_unicode = ansible_constructor.construct_yaml_str(node)

    ansible_constructor.construct_scalar.assert_called_with(node)
    assert type(ansible_unicode) is AnsibleUnicode
    assert ansible_unicode == yaml_str


# Generated at 2022-06-25 04:27:08.522460
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.load({u'a': u'a', u'b': u'b'})


# Generated at 2022-06-25 04:27:15.190874
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[],
                       flow_style=None)
    ansible_constructor.construct_yaml_map(node)


# Generated at 2022-06-25 04:27:25.846141
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # NOTE: this is not a complete test, but does cover the basic case.
    from yaml.nodes import MappingNode
    test_data = """
- hosts: localhost
"""
    from ansible.parsing.yaml.loader import AnsibleLoader
    test_obj = AnsibleLoader(test_data)
    node = test_obj.get_single_data()

    key_node = node.value[0].key
    value_node = node.value[0].value

    test_obj = AnsibleConstructor()
    try:
        test_obj.construct_mapping(node)
    except ConstructorError:
        pass

    try:
        test_obj.construct_mapping(None)
    except ConstructorError:
        pass


# Generated at 2022-06-25 04:27:36.854543
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = [ b'X' * 22 ]
    ansible_constructor_1 = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_constructor_2 = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_constructor_3 = AnsibleConstructor(vault_secrets=vault_secrets)
    ansible_constructor_4 = AnsibleConstructor(vault_secrets=vault_secrets)

    # Try with broken ciphertext

# Generated at 2022-06-25 04:27:40.042799
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ret = ansible_constructor_0.construct_yaml_unsafe(None)
    assert(ret is None)



# Generated at 2022-06-25 04:27:53.274443
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.constructor import SafeConstructor
    from yaml.nodes import MappingNode
    from yaml.error import ConstructorError
    from ansible.parsing.yaml.objects import AnsibleMapping
    a = AnsibleConstructor()
    assert isinstance(a, SafeConstructor)
    node0 = MappingNode(None, None, True, None, None)
    assert node0.id == 'mapping'
    expected_msg = "expected a mapping node, but found mapping"
    try:
        a.construct_mapping(node0)
    except ConstructorError as err:
        assert expected_msg == err.problem
    assert a.construct_mapping(node0, deep=True) == AnsibleMapping()

# Generated at 2022-06-25 04:27:57.037472
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_str('an_args')


# Generated at 2022-06-25 04:28:08.364011
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test AnsibleConstructor._vaults exists
    ansible_constructor_1_vaults = AnsibleConstructor()._vaults
    # Test AnsibleConstructor._vaults['default'] exists
    ansible_constructor_1_vaults_default = ansible_constructor_1_vaults['default']

    # Test 'secrets' is not None
    secrets = ansible_constructor_1_vaults_default.secrets
    # Test 'secrets' is empty
    len(secrets) == 0

    # Set self.secrets
    ansible_constructor_1_vaults_default.secrets = ['pass']

    # Invoke method
    ansible_constructor_1_yaml_node = "ansible_constructor_1_yaml_node"
    ansible_constructor_1_construct

# Generated at 2022-06-25 04:28:10.118188
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_str('foo') == AnsibleUnicode(u'foo')


# Generated at 2022-06-25 04:28:18.029601
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    # test_AnsibleConstructor_construct_vault_encrypted_unicode
    #  test_AnsibleConstructor_construct_vault_encrypted_unicode
    #  test_AnsibleConstructor_construct_vault_encrypted_unicode

# Generated at 2022-06-25 04:28:22.638793
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    source_mapping = {'test': 'unit'}
    # Dummy node to pass to the constructor
    class DummyNode(object):
        id=u'tag:yaml.org,2002:map'
        def __init__(self, value):
            self.start_mark=value
            self.end_mark=value
        value=source_mapping
    node = DummyNode('dummy')
    # Initialize the constructor
    ansible_constructor_0 = AnsibleConstructor()
    # Call the method
    ansible_mapping_0 = next(ansible_constructor_0.construct_yaml_map(node) )
    # Check if the result is as expected
    assert ansible_mapping_0['test'] == 'unit'


# Generated at 2022-06-25 04:28:29.806829
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
   ansible_constructor_1 = AnsibleConstructor()
   test_vault_secrets = ['test_vault_secrets1']
   ansible_constructor_1 = AnsibleConstructor(vault_secrets=test_vault_secrets)
   test_node_1 = 'node1'
   ansible_constructor_1.construct_vault_encrypted_unicode(test_node_1)

# Generated at 2022-06-25 04:28:38.181096
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node = AnsibleUnicode('[1, 2, 3]')
    assert ansible_constructor_0.construct_yaml_seq(node) == [1, 2, 3]


# Generated at 2022-06-25 04:28:48.374745
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml__data_0 = """
foo: a
bar: b
baz: c
"""
    yaml__data_1 = """
foo: a
bar: b
baz: c
"""
    ansible_constructor_0 = AnsibleConstructor()
    yaml__data_2 = """foo: a
bar: b
baz: c
"""
    ansible__mapping_0 = AnsibleMapping()
    ansible__mapping_1 = AnsibleMapping()
    ansible__mapping_1.ansible_pos = ('<unicode string>', 1, 0)
    yaml__data_3 = """foo: a
bar: b
baz: c
"""
    ansible__mapping_2 = AnsibleMapping()

# Generated at 2022-06-25 04:28:58.096469
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    a = AnsibleConstructor()

    class Node():
        pass

    n = Node()
    n.start_mark = Node()
    n.start_mark.column = 0
    n.start_mark.line = 0
    n.start_mark.name = "<string>"

    # Change the definition of construct_scalar
    global construct_scalar
    def construct_scalar(node):
        return '$ANSIBLE_VAULT;1.2;AES256;1234567890qwertyuiopasdfghjklzxcvbnm'

    # Make the call
    val = a.construct_vault_encrypted_unicode(n)
    assert isinstance(val, AnsibleVaultEncryptedUnicode)
    assert val.vault is not None

# Generated at 2022-06-25 04:29:09.929270
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    assert_type(ansible_constructor_0, AnsibleConstructor)



# Generated at 2022-06-25 04:29:11.485266
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    try:
        test_case_0()
    except Exception as e:
        print(e)

test_AnsibleConstructor_construct_yaml_unsafe()
print('success')

# Generated at 2022-06-25 04:29:17.480303
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    display.display('Method test_AnsibleConstructor_construct_mapping ...')
    ansible_constructor = AnsibleConstructor()
    node = [{"a":1}, {"a":2}]
    deep = False
    ansible_constructor.construct_mapping(node, deep)
    pass



# Generated at 2022-06-25 04:29:20.055627
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    assert isinstance(ansible_constructor.construct_mapping(node=MappingNode(), deep=False), AnsibleMapping)


# Generated at 2022-06-25 04:29:21.371449
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    print('construct_yaml_seq')


# Generated at 2022-06-25 04:29:25.031502
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = '''
    - 1
    - 2
    - 3
    '''

    ansible_constructor = AnsibleConstructor()
    try:
        data_list = list(ansible_constructor.construct_yaml_seq(yaml.compose(data)))
    except Exception as excep:
        print('test_AnsibleConstructor_construct_yaml_seq: Exception : ' + str(excep))
        return None

    return data_list


# Generated at 2022-06-25 04:29:30.168185
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    list_0 = []
    node_0 = None
    ansible_constructor_0.construct_sequence(node_0)
    ansible_constructor_0.construct_yaml_seq(node_0)

# Generated at 2022-06-25 04:29:39.648623
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor("file_name")
    class Mock_scalar(object):
        def __init__(self):
            self.id = "python/unicode"
            self.start_mark = "start"
    mock_node = Mock_scalar()

    ret_val_1 = ansible_constructor_1.construct_yaml_str(mock_node)
    assert isinstance(ret_val_1, AnsibleUnicode), \
            "return value for construct_yaml_str() should be of type AnsibleUnicode"
    assert hasattr(ret_val_1, "ansible_pos"), \
            "return value for construct_yaml_str() should have attribute ansible_pos"


# Generated at 2022-06-25 04:29:41.812524
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map(): 
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:29:46.298299
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor(file_name=None, vault_secrets=None)

    node = MappingNode(None, None, False, True)
    data = ansible_constructor_1.construct_yaml_map(node)
    if not isinstance(data, collections.Iterator):
        raise AssertionError('data is not an Iterator')


# Generated at 2022-06-25 04:30:09.580875
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    # Test with a bad node type.
    # Test with a bad node type.
    try:
        output = ansible_constructor_1.construct_mapping(None)
    except ConstructorError:
        pass


# Generated at 2022-06-25 04:30:16.121290
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    assert(ansible_constructor_1.construct_yaml_map() == NotImplemented)


# Generated at 2022-06-25 04:30:21.636993
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    value_0 = 'str'
    # Line below raises exception
    ansible_constructor_0.construct_yaml_str(value_0)

# Generated at 2022-06-25 04:30:24.944095
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_case_0()


# Generated at 2022-06-25 04:30:31.396161
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor("file_name_0", [])
    yaml_map_0 = MappingNode(
        u'tag:yaml.org,2002:map',
        ((ScalarNode(u'tag:yaml.org,2002:str', u'key_0'), ScalarNode(u'tag:yaml.org,2002:str', u'value_0')), (ScalarNode(u'tag:yaml.org,2002:str', u'key_1'), ScalarNode(u'tag:yaml.org,2002:str', u'value_1')))
    )
    ansible_map_0 = ansible_constructor_0.construct_yaml_map(yaml_map_0)

# Generated at 2022-06-25 04:30:33.964906
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    # tests the call construct_yaml_map() of class AnsibleConstructor
    pass

# Generated at 2022-06-25 04:30:43.734153
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.vault_secrets = []
    ansible_constructor_1._vaults['default'] = VaultLib(secrets=None)
    try:
        ansible_constructor_1.construct_vault_encrypted_unicode()
        assert False, "Expected Exception"
    except Exception as e:
        assert True
    ansible_constructor_2 = AnsibleConstructor()

# Generated at 2022-06-25 04:30:48.164795
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()

    ans_yaml_seq_1 = AnsibleSequence()


# Generated at 2022-06-25 04:30:57.993462
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    # Case 1

# Generated at 2022-06-25 04:31:00.367312
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    try:
        ansible_constructor_1 = AnsibleConstructor()
        ansible_constructor_1.construct_yaml_str(node=None)
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == 'construct_yaml_str() takes exactly 2 arguments (1 given)'

