

# Generated at 2022-06-25 04:21:53.723933
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()



if __name__ == '__main__':
    test_case_0()
    test_AnsibleConstructor_construct_yaml_seq()

# Generated at 2022-06-25 04:21:56.285389
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_yaml_map = AnsibleConstructor.construct_yaml_map


# Generated at 2022-06-25 04:21:57.382686
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:22:05.852312
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_3 = AnsibleConstructor()
    ansible_constructor_4 = AnsibleConstructor()
    ansible_constructor_5 = AnsibleConstructor()
    ansible_constructor_6 = AnsibleConstructor()
    ansible_constructor_7 = AnsibleConstructor()
    ansible_constructor_8 = AnsibleConstructor()
    ansible_constructor_9 = AnsibleConstructor()
    ansible_constructor_10 = AnsibleConstructor()
    ansible_constructor_11 = AnsibleConstructor()
    ansible_constructor_12 = AnsibleConstructor()
    ansible_

# Generated at 2022-06-25 04:22:11.363616
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    value = ansible_constructor_0.construct_yaml_map(node)
    assert value == None


# Generated at 2022-06-25 04:22:14.193962
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansibleConstructor = AnsibleConstructor()
    # construct_yaml_unsafe method takes a yaml node as argument
    node = None
    ansibleConstructor.construct_yaml_unsafe(node)

# Generated at 2022-06-25 04:22:15.041395
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_case_0()

# Generated at 2022-06-25 04:22:16.179995
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:22:22.578336
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    mapping = dict()
    mapping['key1'] = 'value1'
    mapping['key2'] = 'value2'
    yaml_document = mapping
    result = ansible_constructor_0.construct_yaml_map(yaml_document)
    assert result == NotImplementedError


# Generated at 2022-06-25 04:22:32.216333
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    data = """\
# myfile.yaml
- hosts: all
  gather_facts: yes
  pre_tasks:
    - setup:
"""

    with open("./myfile.yaml", "w") as filep:
        filep.write(data)

    ansible_test = AnsibleConstructor(file_name="./myfile.yaml")

    yaml_unistr_0 = """\
- hosts: all
  gather_facts: yes
  pre_tasks:
    - setup:"""

    unistr_0 = yaml.load(yaml_unistr_0, Loader=ansible_test.__class__)

    assert isinstance(unistr_0, list)
    assert len(unistr_0) == 1

# check that ansible_pos

# Generated at 2022-06-25 04:22:40.179349
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:22:49.811070
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    ansible_node = 'hello world'
    ansible_result = ansible_constructor.construct_yaml_str(ansible_node)
    assert type(ansible_result) is AnsibleUnicode
    assert ansible_result == u'hello world'

    ansible_constructor = AnsibleConstructor()
    ansible_node = 'hello world'
    ansible_result = ansible_constructor.construct_yaml_str(ansible_node)
    assert type(ansible_result) is AnsibleUnicode
    assert ansible_result == u'hello world'


# Generated at 2022-06-25 04:22:53.413244
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    pass # TODO


# Generated at 2022-06-25 04:22:56.203529
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:23:04.810473
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    test_node_0 = MappingNode(u'tag:yaml.org,2002:map', data=[(u'key1', u'value1'), (u'key2', u'value2')])
    value = ansible_constructor_0.construct_yaml_map(test_node_0)
    exp_value_0 = {u'ansible_pos': (u'<string>', 1, 1), u'key1': u'value1', u'key2': u'value2'}
    assert value == exp_value_0, "Return value of AnsibleConstructor.construct_yaml_map() is unexpected, got {}, expected {}".format(value, exp_value_0)


# Generated at 2022-06-25 04:23:16.342941
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml import objects
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    mapping_node = objects.mapping_node_1
    ansible_constructor_mapping = AnsibleConstructor()
    # When
    result = ansible_constructor_mapping.construct_mapping(mapping_node, deep=False)
    # Then
    assert isinstance(result, AnsibleMapping)
    assert result == {'red_hat_enterprise_linux': ansible_constructor_mapping.construct_yaml_map}
    assert result.ansible_pos == ('data/inventory_hosts', 1, 0)



# Generated at 2022-06-25 04:23:23.327669
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # from ansible.parsing.yaml.objects import AnsibleMapping
    value = AnsibleMapping()
    data = AnsibleMapping()
    data = value
    assert data == value, "Return value of AnsibleConstructor.construct_yaml_map() is not equal to value."


# Generated at 2022-06-25 04:23:27.174075
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    str_2 = ""
    node_3 = ansible_constructor_0.construct_yaml_str(str_2)
    assert node_3 is not None


# Generated at 2022-06-25 04:23:33.815869
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._vaults['default'] = VaultLib(secrets=['tmp', 'tmp'])
    ansible_constructor_0._vaults['default'].decrypt('$ANSIBLE_VAULT;1.1;AES256\n333832613431383236653737343761326539656634653063383837336665363935383435333334363\n61303461623531316239613639626336643865303863633333643135313265643961653235326630\n')

# Generated at 2022-06-25 04:23:43.059812
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    Test construct_yaml_str()

    Test the method construct_yaml_str() of class AnsibleConstructor()
    """
    ansible_constructor_1 = AnsibleConstructor()

    ansible_constructor_1.construct_object = Mock(return_value="foo")
    assert ansible_constructor_1.construct_yaml_str("node_1") == "foo"
    ansible_constructor_1.construct_object.assert_called_once_with("node_1")


# Generated at 2022-06-25 04:23:50.998107
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    """
    Test to make sure we override the default string handling function
        to always return unicode objects.
    """
    ansible_constructor = AnsibleConstructor(file_name='', vault_secrets=['password'])
    node = "TestConstructor"
    ret = ansible_constructor.construct_yaml_str(node)
    assert isinstance(ret, AnsibleUnicode)

# Generated at 2022-06-25 04:23:59.017376
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    my_str = "this is a string"

    # this is a string
    ansible_constructor_1 = AnsibleConstructor()

    # TEST CASE: Create instance of AnsibleConstructor
    ansible_constructor_0 = AnsibleConstructor()

    # TEST CASE: Create instance of AnsibleConstructor
    ansible_constructor_2 = AnsibleConstructor()

    ansible_constructor_1.construct_yaml_seq(my_str)
    ansible_constructor_0.construct_yaml_seq(my_str)
    ansible_constructor_2.construct_yaml_seq(my_str)


# Generated at 2022-06-25 04:24:01.692356
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    seq = ["_value1", "_value2"]
    node = "node"
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq(node)


# Generated at 2022-06-25 04:24:05.391585
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_mapping()

# Generated at 2022-06-25 04:24:09.821524
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
	ansible_constructor_1 = AnsibleConstructor()
	ansible_constructor_2 = AnsibleConstructor()
	ansible_constructor_3 = AnsibleConstructor()
	ansible_constructor_4 = AnsibleConstructor()
	ansible_constructor_5 = AnsibleConstructor()
	assert True # TODO: implement your test here


# Generated at 2022-06-25 04:24:12.830619
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    try:
        output = ansible_constructor_1.construct_vault_encrypted_unicode(__input_data_0)
    except Exception:
        output = None
    print(output)



# Generated at 2022-06-25 04:24:17.859950
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map() #TODO


# Generated at 2022-06-25 04:24:22.528394
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    assert True == isinstance(ansible_constructor, object)

# Generated at 2022-06-25 04:24:29.836719
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Test with a value that only requires a special kwarg
    ansible_constructor_0 = AnsibleConstructor()
    obj_0 = ansible_constructor_0.construct_yaml_unsafe()

    # Test with a value that requires a different constructor type
    ansible_constructor_1 = AnsibleConstructor()
    obj_1 = ansible_constructor_1.construct_yaml_unsafe()



# Generated at 2022-06-25 04:24:38.214709
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    value = {'hello': 'chris'}
    node = MappingNode(u'tag:yaml.org,2002:python/dict', value)
    ansible_mapping = ansible_constructor_0.construct_yaml_map(node)
    value_0 = {'chris': 'hello'}
    node_0 = MappingNode(u'tag:yaml.org,2002:python/dict', value_0)
    ansible_mapping_0 = ansible_constructor_0.construct_yaml_map(node_0)
    value_1 = {'hello': 'chris'}
    node_1 = MappingNode(u'tag:yaml.org,2002:python/dict', value_1)
    ansible_

# Generated at 2022-06-25 04:24:54.124378
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_file = "test_sample.yml"
    vault_file = 'test_vault.yml'
    vault_password_file = 'test_vault_password.yml'
    ansible_constructor = AnsibleConstructor(file_name=yaml_file)

    # TODO: Add more tests for all possible cases
    dict_in = {u'variable_name1': u'value', 'variable_name2': 'value', 'variable_name3': 'value'}
    node = MappingNode(u'tag:yaml.org,2002:map', dict_in.items())
    ansible_constructor.construct_mapping(node)



# Generated at 2022-06-25 04:24:57.422300
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    constructor = AnsibleConstructor()
    # TODO check return type and arguments
    # TODO write test cases



# Generated at 2022-06-25 04:25:02.217292
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    # No test code will be generated for this module yet


# Generated at 2022-06-25 04:25:08.771696
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_1 = AnsibleMapping()
    ansible_mapping_1['foo'] = 'bar'
    ansible_mapping_0['foo'] = ansible_mapping_1
    ansible_mapping_2 = AnsibleMapping()
    ansible_mapping_2.ansible_pos = ('<string>', 2, 1)
    assert ansible_constructor_1.construct_yaml_map(ansible_mapping_2) == ansible_mapping_2


# Generated at 2022-06-25 04:25:16.140036
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    obj_0 = AnsibleUnicode("P@ssw0rd")
    ansible_constructor_0._vaults['default'].secrets = ["P@ssw0rd"]
    ansible_constructor_0._ansible_file_name = "test_AnsibleConstructor_construct_yaml_unsafe.yaml"
    ansible_constructor_0.construct_vault_encrypted_unicode(obj_0)

# Generated at 2022-06-25 04:25:21.221757
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
# #     ansible_constructor_2 = AnsibleConstructor()
# #     ansible_constructor_2.value = AnsibleSequence()
    ansible_yaml_seq_0 = ansible_constructor_1.construct_yaml_seq(ansible_yaml_seq_0)
    assert ansible_yaml_seq_0 == ansible_yaml_seq_0


# Generated at 2022-06-25 04:25:32.872478
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    node = {
        'tag': 'tag:yaml.org,2002:str',
        'anchor': None,
        'implicit': None,
        'value': '192.0.2.1',
        'start_mark': {
            'column': 8,
            'line': 0,
            'buffer': '',
            'pointer': 8,
            'name': '<unicode string>',
            'index': 8
        },
        'end_mark': {
            'column': 20,
            'line': 0,
            'buffer': '',
            'pointer': 20,
            'name': '<unicode string>',
            'index': 20
        },
        'style': None
    }
    assert ansible_constructor.construct_y

# Generated at 2022-06-25 04:25:34.102839
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:25:37.331041
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    assert isinstance(ansible_constructor_1.construct_mapping(None), dict)


# Generated at 2022-06-25 04:25:39.677276
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_vault_encrypted_unicode(None) is None


# Generated at 2022-06-25 04:25:58.025252
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    seq = None
    ansible_constructor_1.construct_yaml_seq(seq)


# Generated at 2022-06-25 04:26:06.547628
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    #
    # Set up mock objects
    #
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._ansible_file_name = 'ansible_file_name'
    ansible_constructor_0.vault_secrets = [Mock()]
    ansible_mapping_1 = AnsibleMapping()
    ansible_mapping_1.ansible_pos = (Mock(), Mock(), Mock())
    ansible_constructor_0.safe_construct = Mock(return_value=ansible_mapping_1)
    ansible_constructor_0.construct_mapping = Mock()
    node_2 = Mock()
    node_2.id = 'map'

# Generated at 2022-06-25 04:26:14.227610
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    data = AnsibleMapping()
    node = MappingNode(tag=u'', value=[], start_mark=None, end_mark=None)
    ansible_constructor.construct_mapping(node, deep=None)
    data.update(value)
    data.ansible_pos = ansible_constructor._node_position_info(node)
    ansible_constructor.construct_yaml_map(node)


# Generated at 2022-06-25 04:26:25.970212
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()

    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    # Test with correct arguments
    pass

# Generated at 2022-06-25 04:26:29.419763
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map(node=None)


# Generated at 2022-06-25 04:26:32.988164
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    value_0 = ansible_constructor_0.construct_yaml_unsafe(node=None)
    assert (value_0 is None)


# Generated at 2022-06-25 04:26:39.814825
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    with open("test/yaml_constructor_test/ansible_constructor_test_case_0.txt", 'r') as myfile:
        data = myfile.read()
    node = yaml.parser.Parser().parse(data)

    assert(type(ansible_constructor_0.construct_vault_encrypted_unicode(node)) == AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 04:26:45.200670
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Create test object
    my_const_0 = AnsibleConstructor()
    # Define arguments
    data = 'yaml-test-vault-encrypted-value'
    tag = 'tag:yaml.org,2002:str'

    # Call method
    res = my_const_0.construct_yaml_str(data, tag)

    # Asserts
    assert isinstance(res, AnsibleUnicode)
    assert res == 'yaml-test-vault-encrypted-value'



# Generated at 2022-06-25 04:26:47.461825
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:55.178290
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    instance = AnsibleConstructor()
    deep = False
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map(node=ansible_constructor_2)
    ansible_constructor_0 = AnsibleConstructor(file_name=ansible_constructor_1, vault_secrets=ansible_constructor_1)
    ansible_constructor_0.construct_mapping(node=ansible_constructor_1, deep=deep)
# No exception

# Generated at 2022-06-25 04:27:14.910944
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_construct_yaml_seq_0 = AnsibleConstructor()
    node = None
    assert not (ansible_constructor_construct_yaml_seq_0.construct_yaml_seq(node))


# Generated at 2022-06-25 04:27:25.569117
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # test with a valid vault value(encrypted using ansible-vault)
    ansible_constructor_0 = AnsibleConstructor(vault_secrets=['dummy_password'])
    dummy_ciphertext = b'$ANSIBLE_VAULT;1.2;AES256;laptop;dummy_value_using_dummy_password\n63313065336661356262366163336532356135343730316536363964616134643631346630373966\n34663034666335623337356436366362346332626338623266346565643938306465366562623761\n3262316130363062346230356436653734663034646633\n'
    expected_ret_value = AnsibleV

# Generated at 2022-06-25 04:27:30.246256
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    print("Testing AnsibleConstructor_construct_vault_encrypted_unicode")
    ansible_constructor_0.construct_vault_encrypted_unicode(["!vault", "!vault!somesecretkey!somesecretvalue!"])

# Generated at 2022-06-25 04:27:34.775330
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    data = 'ansible_constructor_data'
    node = ''
    value = ansible_constructor.construct_scalar(node)
    ret = AnsibleUnicode(value)

    assert ret
    assert ret is not None



# Generated at 2022-06-25 04:27:38.176680
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    expected = AnsibleConstructor.construct_yaml_map
    actual = ansible_constructor.construct_yaml_map
    assert actual == expected



# Generated at 2022-06-25 04:27:40.418857
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq(node=None)


# Generated at 2022-06-25 04:27:44.586447
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    ansible_constructor_0.construct_yaml_str(node)


# Generated at 2022-06-25 04:27:49.459566
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    node = {'id': 'str'}
    result = ansible_constructor.construct_yaml_str(node)
    assert result == False


# Generated at 2022-06-25 04:27:51.738628
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping('construct_mapping')


# Generated at 2022-06-25 04:27:59.711515
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_3 = AnsibleConstructor()
    ansible_constructor_4 = AnsibleConstructor()
    ansible_constructor_5 = AnsibleConstructor()
    ansible_constructor_6 = AnsibleConstructor()
    ansible_constructor_7 = AnsibleConstructor()
    ansible_constructor_8 = AnsibleConstructor()
    ansible_constructor_9 = AnsibleConstructor()
    ansible_constructor_10 = AnsibleConstructor()
    ansible_constructor_11 = AnsibleConstructor()
    ansible_constructor_12 = AnsibleConstructor()
    ansible_

# Generated at 2022-06-25 04:28:34.231419
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._vaults['default'] = VaultLib(secrets=['test_AnsibleConstructor_construct_vault_encrypted_unicode'])
    assert isinstance(ansible_constructor_0.construct_vault_encrypted_unicode(0), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 04:28:40.722192
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode

    dummy_file_name = 'test_AnsibleConstructor_test_case_0_file_name'
    ansible_constructor_0 = AnsibleConstructor(dummy_file_name)

    dummy_node = SequenceNode('', [], None, None, None)
    dummy_deep = False
    test_case_0_AnsibleConstructor_construct_yaml_seq = ansible_constructor_0.construct_yaml_seq(dummy_node, dummy_deep)


# Generated at 2022-06-25 04:28:44.056157
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    mapping_node_0 = MappingNode()
    mapping_node_0.value.append((1, 2))
    mapping_node_0.value.append((3, 4))
    mapping_0 = ansible_constructor_0.construct_mapping(mapping_node_0)
    assert mapping_0[1] == 2
    assert mapping_0[3] == 4


# Generated at 2022-06-25 04:28:48.758034
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    yaml_node_2 = None
    assert isinstance(ansible_constructor_1.construct_yaml_map(yaml_node_2), GeneratorType)


# Generated at 2022-06-25 04:28:58.554972
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()

    # Test with a AnsibleSequence object
    ansible_sequence_0 = AnsibleSequence()
    ansible_sequence_0.append(7)
    ansible_constructor_0.construct_yaml_seq(ansible_sequence_0)

    # Test with a AnsibleConstructor object
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_seq(ansible_constructor_0)

    # Test with a MappingNode object
    mapping_node_0 = MappingNode(node=MappingNode(node=MappingNode(node=None)), value=AnsibleSequence())
    mapping_node_0.tag = 'tag:yaml.org,2002:map'
    mapping_

# Generated at 2022-06-25 04:29:10.662918
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    # Create an instance of class 'AnsibleConstructor'
    ansible_constructor = AnsibleConstructor()

    # Create a mock object of class 'AnsibleSequence'
    mock_ansible_sequence = mock.create_autospec(AnsibleSequence)
    mock_ansible_sequence.extend = mock.Mock(return_value=None)

    # Create a mock object of class 'AnsibleConstructor'
    mock_ansible_constructor_construct_sequence = mock.create_autospec(AnsibleConstructor.construct_sequence)
    mock_ansible_constructor_construct_sequence.return_value = mock_ansible_sequence

    # Set the 'construct_sequence' method of 'ansible_constructor' to 'mock_ansible_constructor_construct_sequence'

# Generated at 2022-06-25 04:29:15.366147
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_str(node) == 'unicode'


# Generated at 2022-06-25 04:29:18.989269
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass


# Generated at 2022-06-25 04:29:20.077577
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:29:24.630253
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansibleConstructor = AnsibleConstructor()
    node = 'ABCD'
    ret = ansibleConstructor.construct_yaml_str(node)
    assert ret == u'ABCD'

# Generated at 2022-06-25 04:29:55.153866
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_unsafe()

# Generated at 2022-06-25 04:30:04.183499
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    # TypeError: 'NoneType' object is not iterable
    # unit test to verify AnsibleConstructor.construct_yaml_unsafe() throws exception
    with pytest.raises(ConstructorError) as excinfo:
        ansible_constructor_0.construct_yaml_unsafe(node)

# Generated at 2022-06-25 04:30:07.908380
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    obj = AnsibleConstructor()
    assert(obj.construct_yaml_seq('node') is not None)


# Generated at 2022-06-25 04:30:10.376753
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_objects_0 = {'ansible_pos': ("test_case_0", 1, 0), 'some_key': 'some_value'}
    ansible_constructor_0.construct_yaml_unsafe(yaml_objects_0)

# Generated at 2022-06-25 04:30:16.193908
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_unsafe(None)


# Generated at 2022-06-25 04:30:21.721653
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a0 = AnsibleConstructor()
    node0 = MappingNode(None, None)
    assert a0.construct_mapping(node0) == AnsibleMapping()
#

# Generated at 2022-06-25 04:30:30.307722
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
  data = '''
    foo: !vault |
          $ANSIBLE_VAULT;1.2;AES256;macbook.local
          3132333435363738393031323334353637383930393139323033353736383930313233343536373839
          3039313932303335373638393031323334353637383930393139323033353736383930313233343536
          37383930393139323033353736383930
'''
  from ansible.plugins.loader import get_all_plugin_loaders
  # expected = get_all_plugin_loaders()
  from ansible.utils.unsafe_proxy import AnsibleUnsafeText
  # expected = AnsibleUnsafeText(u'123456789

# Generated at 2022-06-25 04:30:38.094675
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    mapping = ansible_constructor.construct_mapping({
        'value': [
            ['key', 'value'],
            ['another_key', 'another_value'],
            ['a_key', 'a_value'],
        ]
    })

    assert isinstance(mapping, dict)
    assert mapping == {
        'another_key': 'another_value',
        'a_key': 'a_value',
        'key': 'value',
    }



# Generated at 2022-06-25 04:30:40.240270
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq()


# Generated at 2022-06-25 04:30:44.849473
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    string_ = '''{key: value}'''
    ansible_mapping = ansible_constructor.construct_yaml_map(string_)
    assert isinstance(ansible_mapping, AnsibleMapping)
    assert isinstance(ansible_mapping['key'], AnsibleUnicode)
    assert ansible_mapping['key'] == 'value'


# Generated at 2022-06-25 04:31:32.727088
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_vault_encrypted_unicode() == None

# Generated at 2022-06-25 04:31:35.847807
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe()


# Generated at 2022-06-25 04:31:40.197829
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0._vaults, dict)
    assert isinstance(ansible_constructor_0.vault_secrets, list)
    node_0 = object()
    ret_0 = ansible_constructor_0.construct_vault_encrypted_unicode(node_0)
    assert isinstance(ret_0, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 04:31:46.571967
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    data = {}
    node = {}
    actual_output = ansible_constructor_0.construct_yaml_seq(node)
    expected_output = data
    if actual_output != expected_output:
        raise AssertionError(actual_output)
