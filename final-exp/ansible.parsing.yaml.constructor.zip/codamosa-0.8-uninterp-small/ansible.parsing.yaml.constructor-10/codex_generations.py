

# Generated at 2022-06-25 04:21:48.902446
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # initialize
    ansible_constructor_0 = AnsibleConstructor()
    # testcode - no assert
    ansible_constructor_0.construct_vault_encrypted_unicode(None)



# Generated at 2022-06-25 04:21:57.235879
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
  value="key"
  ansible_constructor_1 = AnsibleConstructor()
  ansible_mapping_1 = AnsibleMapping()
  ansible_mapping_2 = AnsibleMapping()
  ansible_mapping_1[value] = ansible_mapping_2
  ansible_mapping_1.ansible_pos = "ansible_pos"
  ansible_mapping_2["ansible_pos"] = "ansible_pos"
  ansible_mapping_2.ansible_pos = "ansible_pos"
  ansible_constructor_1.construct_mapping(ansible_mapping_1)
  

# Generated at 2022-06-25 04:22:00.230065
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_data = [{'a': 1, 'b': 2, 'c': 3, 'a':4}]
    for node in test_data:
        mapping = AnsibleConstructor().construct_mapping(node)
        keys = mapping.keys()
        for key in keys:
            assert mapping[key] == 4

# Generated at 2022-06-25 04:22:04.712560
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
        ansible_constructor = AnsibleConstructor()
        ansible_constructor.vault_secrets = ['password1', 'password2']
        ansible_constructor._vaults = {'default': VaultLib(secrets=ansible_constructor.vault_secrets)}
        ansible_constructor.construct_vault_encrypted_unicode(None)

# Generated at 2022-06-25 04:22:06.848923
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()


if __name__ == '__main__':
    import pytest
    pytest.main(['-qq', __file__])

# Generated at 2022-06-25 04:22:10.123323
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str


# Generated at 2022-06-25 04:22:18.831403
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    ansible_constructor_0 = AnsibleConstructor()
    data = '''
- 1
- 2
- 3
'''
    data = '\n'.join([s.lstrip() for s in data.splitlines()])
    # verify the results
    ansible_loader_0 = AnsibleLoader(data, None)
    assert isinstance(ansible_loader_0.get_single_data(), AnsibleSequence)



# Generated at 2022-06-25 04:22:21.808397
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    # I'm not sure how to set-up node and deep to test, so right now just create an object and return it
    assert isinstance(ansible_constructor_0.construct_yaml_seq(None), AnsibleSequence)


# Generated at 2022-06-25 04:22:24.246558
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_data = '''{"name": "test"}'''
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq(yaml_data)


# Generated at 2022-06-25 04:22:34.062292
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    str_0 = 'foo'
    str_1 = 'bar'
    str_2 = 'baz'
    str_3 = 'quux'
    str_4 = 'asdf'
    str_5 = 'foo'
    str_6 = 'bar'
    str_7 = 'baz'
    str_8 = 'quux'
    str_9 = 'asdf'
    str_10 = 'foo'
    str_11 = 'bar'
    str_12 = 'baz'
    str_13 = 'quux'
    str_14 = 'asdf'
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_0.__init__(str_0)
    ansible_unicode

# Generated at 2022-06-25 04:22:44.915944
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    node = None

    # Call method
    try:
        ansible_constructor_0.construct_vault_encrypted_unicode(node)
    except Exception as e:
        # Verify expected call
        assert False

    assert True


# Generated at 2022-06-25 04:22:50.788322
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq('node')



# Generated at 2022-06-25 04:22:52.018120
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()

    ansible_constructor_1.construct_mapping()


# Generated at 2022-06-25 04:22:55.852865
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping()
    try:
        ansible_constructor_0.construct_mapping()
    except ConstructorError:
        pass



# Generated at 2022-06-25 04:23:04.954762
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    # Secret!
    secret = ansible_constructor.construct_vault_encrypted_unicode('secret', 'password')
    # When using yaml.load(str)
    # secret = ansible_constructor.construct_vault_encrypted_unicode(str, str)
    # When using yaml.load(str)
    # secret = AnsibleConstructor.construct_yaml_str(str, str)
    assert secret == 'secret'
    # When using yaml.load(str)
    # vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(str, str)
    # When using yaml.load(str)
    # vault_encrypted_unicode = AnsibleConstructor.construct_yaml_str(str, str

# Generated at 2022-06-25 04:23:13.252435
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    str_2 = 'This is a sample string'
    str_3 = 'This is a sample string'
    node_4 = to_text(str_2)
    node_5 = to_text(str_2)
    node_6 = to_text(str_3)

    # Test with paramters node_4, node_5 and node_6.

    ansible_constructor_1.construct_yaml_seq(node_4, node_5, node_6)


# Generated at 2022-06-25 04:23:15.548069
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert True


# Generated at 2022-06-25 04:23:27.463663
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Load data from a string
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.vault_secrets = ["ansible"]

# Generated at 2022-06-25 04:23:34.289775
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_constructor_1.construct_vault_encrypted_unicode(ansible_vault_encrypted_unicode_1)

# Generated at 2022-06-25 04:23:43.427106
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_construct_mapping_obj = AnsibleConstructor()
    ansible_constructor_construct_mapping_map_node = {}
    ansible_constructor_construct_mapping_deep = False
    ansible_constructor_construct_mapping_ret = ansible_constructor_construct_mapping_obj.construct_mapping(ansible_constructor_construct_mapping_map_node, ansible_constructor_construct_mapping_deep)
    assert ansible_constructor_construct_mapping_ret is None


# Generated at 2022-06-25 04:23:53.450561
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_case_0()


# Generated at 2022-06-25 04:24:03.682562
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Test with a single item
    node = MappingNode(None, None)
    knode = list(node.value)[0][0]
    vnode = list(node.value)[0][1]
    knode.value = 'key1'
    vnode.value = 'value1'

    mapping = AnsibleConstructor.construct_mapping(node)
    assert mapping == {'key1': 'value1'}

    # Test with a two items
    node = MappingNode(None, None)
    knode = list(node.value)[0][0]
    vnode = list(node.value)[0][1]
    knode.value = 'key1'
    vnode.value = 'value1'
    knode = list(node.value)[1][0]

# Generated at 2022-06-25 04:24:13.271320
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = ['ansible']

# Generated at 2022-06-25 04:24:20.012304
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode(None, None, False, True, None)
    try:
        assert isinstance(ansible_constructor_0.construct_yaml_map(node_0), Iterable)
    except AssertionError:
        display.display("Exception in test_AnsibleConstructor_construct_yaml_map")
        raise


# Generated at 2022-06-25 04:24:21.487407
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    # yaml_map is not supported
    assert False



# Generated at 2022-06-25 04:24:25.173719
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    assert False # TODO test something:
    # ansible_constructor = AnsibleConstructor()
    # ansible_constructor.construct_vault_encrypted_unicode()



# Generated at 2022-06-25 04:24:27.710579
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    result = AnsibleConstructor().construct_yaml_str('str')
    assert result == u'str'


# Generated at 2022-06-25 04:24:32.632713
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    file_name = ''
    vault_secrets = []
    ansible_constructor_1 = AnsibleConstructor(file_name, vault_secrets)
    node = None

# Generated at 2022-06-25 04:24:40.229831
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
	import yaml
	# `!vault |` and `!vault-encrypted |` are decoded to AnsibleVaultEncryptedUnicode object
	# `!vault` and `!vault-encrypted` are decoded to AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-25 04:24:49.129595
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    # We need a reasonable node to test this.
    # If we create a reasonable node, we can"t create the
    # dummy data we need, so we are stuck with this nonsense.
    # This probably needs to be fixed if we want to use this in
    # testing.
    data = "test_value"
    obj = ansible_constructor_0.construct_yaml_map(data)
    assert isinstance(obj, GeneratorType) == True


# Generated at 2022-06-25 04:25:02.093632
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = ['']



# Generated at 2022-06-25 04:25:07.794227
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # Test default value

    ansible_constructor_0 = AnsibleConstructor()

    node = ""
    expected_result = ""
    result = ansible_constructor_0.construct_yaml_str(node)

    assert result == expected_result


# Generated at 2022-06-25 04:25:18.820586
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor(file_name=None)

    class node_0:
        start_mark = None

    class node_1:
        start_mark = None

    class node_2:
        start_mark = None

    try:
        ansible_constructor_0.construct_mapping(value=None, deep=False)
    except TypeError:
        assert True
    else:
        assert False
    try:
        ansible_constructor_0.construct_mapping(value=node_0, deep=False)
    except ConstructorError:
        assert True
    else:
        assert False
    try:
        ansible_constructor_0.construct_mapping(value=node_1, deep=False)
    except ConstructorError:
        assert True

# Generated at 2022-06-25 04:25:22.274734
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.__init__()


# Generated at 2022-06-25 04:25:24.877402
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    print("Test case for AnsibleConstructor method construct_yaml_seq")
    #ansible_constructor_1.construct_yaml_seq(node)


# Generated at 2022-06-25 04:25:26.989480
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq(None)


# Generated at 2022-06-25 04:25:31.419524
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_yaml_seq_0 = ansible_constructor_0._ansible_file_name

    # Test for the value of name
    assert to_native(ansible_constructor_0._ansible_file_name) == ansible_constructor_0._ansible_file_name
    return ansible_yaml_seq_0

# Generated at 2022-06-25 04:25:34.343851
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    with pytest.raises(Exception):
        ansible_constructor_0.construct_yaml_seq(None)


# Generated at 2022-06-25 04:25:36.861370
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = Node()


# Generated at 2022-06-25 04:25:39.565191
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0.construct_yaml_seq(node = 'node'), types.GeneratorType)


# Generated at 2022-06-25 04:25:53.368355
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_construct_yaml_map_obj = AnsibleConstructor()
    test_node = 'test node'
    ansible_constructor_construct_yaml_map_obj.construct_yaml_map(node=test_node)



# Generated at 2022-06-25 04:25:56.278090
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    print ('AnsibleConstructor.construct_mapping() test...')
    ansible_constructor_0.construct_yaml_map()

# Generated at 2022-06-25 04:26:02.776548
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor(file_name=None, vault_secrets=None)
    mapping_node_2 = MappingNode(tag=None, value=[], start_mark=None, end_mark=None, flow_style=None)
    deep_3 = None
    ret_4 = ansible_constructor_1.construct_mapping(mapping_node_2, deep_3)
    assert ret_4 is None


# Generated at 2022-06-25 04:26:08.028293
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    
    # Test File: data/unicode_yaml_seq_scalar.yml
    try:
        ansible_constructor_0.construct_yaml_seq(data)
    except Exception as e:
        print(e)
    else:
        print(ansible_constructor_0._ansible_file_name)



# Generated at 2022-06-25 04:26:10.188255
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe(None)


# Generated at 2022-06-25 04:26:11.312933
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:14.668892
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    # Test with no args
    data_1 = AnsibleMapping()

    # Test with args
    with MockingOfSysout():
        ansible_constructor_1.construct_yaml_map(node=None)


# Generated at 2022-06-25 04:26:25.911240
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    temp_node_1 = MappingNode('tag:yaml.org,2002:map', [])
    temp_node_1.start_mark = 'test.yaml, line 1, column 1'
    temp_node_1.end_mark = 'test.yaml, line 1, column 1'
    temp_node_1.value = []
    temp_node_1.flow_style = False
    temp_node_1.tag = u'tag:yaml.org,2002:map'
    temp_node_1.anchors = {}
    ret_2 = ansible_constructor_1.construct_yaml_seq(temp_node_1)
    assert ret_2 is not None


# Generated at 2022-06-25 04:26:30.244688
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = AnsibleMapping()
    key = 'key'
    value = 'value'
    ansible_mapping[key] = value
    assert ansible_constructor.construct_yaml_map(None) == ansible_mapping


# Generated at 2022-06-25 04:26:32.812171
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_str("string")


# Generated at 2022-06-25 04:26:53.639526
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq(["tag:yaml.org,2002:seq"])


# Generated at 2022-06-25 04:27:02.809767
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    data = AnsibleMapping()
    value = {1: 1}
    data.update(value)
    data.ansible_pos = (None, None, None)
    node = {1: 1}
    try:
        ansible_constructor_0.construct_yaml_map(node)
        assert True
    except NameError as e:
        assert False
    except Exception as e:
        assert False


# Generated at 2022-06-25 04:27:10.692638
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.nodes import ScalarNode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    ansible_constructor_0 = AnsibleConstructor()

    # Call method
    node = ScalarNode(tag="tag:yaml.org,2002:str", value="value")
    vault_secrets = [b"secret"]
    ansible_constructor_0.vault_secrets = vault_secrets
    ansible_constructor_0.construct_vault_encrypted_unicode(node)


# Generated at 2022-06-25 04:27:11.226241
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-25 04:27:16.117552
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # FIXME:
    # This test does not pass when run from the 'ansible-test sanity'
    # command due to how it is called from the top-level Makefile.
    # Need to investigate how to fix.
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:str')
    ansible_constructor_0.construct_vault_encrypted_unicode(node=node)


# Generated at 2022-06-25 04:27:20.683879
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    # Create an instance of class AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ansible_constructor = AnsibleConstructor()

    # Test the method construct_yaml_seq
    # FIXME: not sure what to test yet
    #assert False  # TODO: implement your test here


# Generated at 2022-06-25 04:27:28.054355
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    obj = wrap_var(1)

    result = ansible_constructor_0.construct_yaml_unsafe(obj)

    assert obj is result


# Generated at 2022-06-25 04:27:40.264091
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_input = '''
test_inventory:
  hosts:
   - localhost
   - 127.0.0.1'''
    data = AnsibleMapping()
    data.update({'hosts': ['localhost', '127.0.0.1']})
    data.ansible_pos = ('<unicode string>', 1, 0)
    ansible_constructor = AnsibleConstructor()
    for expected_result in [data]:
        actual_result = ansible_constructor.construct_yaml_map(yaml_input)
        assert actual_result == expected_result, 'Expected {0} but got {1}'.format(expected_result, actual_result)


# Generated at 2022-06-25 04:27:46.765878
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    node = ""
    deep = ""
    ansible_constructor.construct_mapping(node, deep)


# Generated at 2022-06-25 04:27:51.223722
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = """"""
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_mapping(yaml_data) == None
    yaml_data = """"""
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_mapping(yaml_data) == None


# Generated at 2022-06-25 04:28:29.486828
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # This test intentionally causes an exception in the fixture to ensure
    # that the exception handling is working
    ansible_constructor = AnsibleConstructor()
    data = {'a': 'A'}
    node = None
    deep = False
    ansible_constructor.construct_mapping(node, deep)

# Generated at 2022-06-25 04:28:35.578920
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    assert ansible_constructor_1.construct_yaml_unsafe.__class__.__name__ == 'method'

# Generated at 2022-06-25 04:28:40.683592
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    testdict = u'{"key1": "value1"}'
    testnode = ansible_constructor.construct_yaml_map(testdict)
    testarray = ansible_constructor.construct_yaml_seq(testdict)
    teststr = ansible_constructor.construct_yaml_str(testdict)
    testunsafe = ansible_constructor.construct_yaml_unsafe(testdict)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleConstructor_construct_yaml_unsafe()

# Generated at 2022-06-25 04:28:44.727449
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create an instance of AnsibleConstructor
    ansible_constructor_0 = AnsibleConstructor()
    # Create a yaml node with a "tag:yaml.org,2002:map" tag
    yaml_node_0 = yaml.nodes.MappingNode('tag:yaml.org,2002:map', [])
    # Call method construct_yaml_map with parameter yaml_node_0
    ansible_constructor_0.construct_yaml_map(yaml_node_0)

#Unit test for method construct_yaml_str of class AnsibleConstructor

# Generated at 2022-06-25 04:28:48.400268
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    yaml_str = ansible_constructor_0.construct_yaml_str(yaml_str)


# Generated at 2022-06-25 04:28:51.201840
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_0['test'] = 'test'
    ansible_mapping_0['test'] = 'test2'


# Generated at 2022-06-25 04:28:55.518611
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
        import yaml
        ansible_constructor = AnsibleConstructor()
        yaml_doc = yaml.load("""
- b: hello
- c: world
        """)
        yaml_doc2 = yaml.load("""
- foo
- bar
        """)
        assert yaml_doc == yaml_doc2


# Generated at 2022-06-25 04:28:57.933907
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    ansible_map = ansible_constructor.construct_mapping(node=None, deep=None)
    return ansible_map

# Generated at 2022-06-25 04:29:02.645590
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    node = "Node"
    with pytest.raises(ConstructorError):
        ansible_constructor_0.construct_yaml_unsafe(node)



# Generated at 2022-06-25 04:29:06.040301
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    obj = AnsibleConstructor()
    node = MappingNode(tag=None, value=[], start_mark=None, end_mark=None)
    obj.construct_yaml_seq(node)
    obj.construct_mapping(node)

# Generated at 2022-06-25 04:29:46.244232
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_mapping_0 = AnsibleMapping({'a': 1, 'b': 2})

    constructor_0 = AnsibleConstructor(file_name=None, vault_secrets=[])
    mapping = constructor_0.construct_mapping(None)
    assert mapping == ansible_mapping_0



# Generated at 2022-06-25 04:29:51.584160
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor_construct_vault_encrypted_unicode_var_0 = ansible_constructor.construct_vault_encrypted_unicode()


# Generated at 2022-06-25 04:29:53.827153
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode(u'tag:yaml.org,2002:map', [])
    ansible_constructor_0.construct_mapping(node_0, deep=True)

# Generated at 2022-06-25 04:29:56.164691
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor("test_file_name_0", ["vault_secret_0"])
    node = None
    ansible_constructor_0.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-25 04:30:06.410172
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_doc_0 = """
- hosts: localhost
  gather_facts: no
  tasks:
  - debug:
      msg: 'Hello World'
"""
    ansible_constructor_0 = AnsibleConstructor()
    stream_0 = AnsibleFileLoader(yaml_doc_0)
    data_0 = stream_0.get_single_data()
    ansible_constructor_0.construct_yaml_seq(data_0)


# Generated at 2022-06-25 04:30:08.709379
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    data = {}
    ansible_constructor.construct_yaml_map(data)


# Generated at 2022-06-25 04:30:11.375756
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_0 = ansible_constructor.construct_yaml_map()
    ansible_constructor_construct_yaml_map_1 = ansible_constructor.construct_yaml_map()


# Generated at 2022-06-25 04:30:16.487060
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.scanner import ScannerError
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_unsafe("foo")



# Generated at 2022-06-25 04:30:26.768542
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Create a dictionary for the yaml node's 'value' property
    test_value = {}

    # Create a yaml node with a value
    node = MappingNode(1, test_value)

    # Create a testing object
    ansible_constructor_0 = AnsibleConstructor()

    # Call the method with the node and no deep
    result = ansible_constructor_0.construct_mapping(node)

    # If deep is False, the result should be an AnsibleMapping instance
    assert isinstance(result, AnsibleMapping) == True

    # Call the method with the node and deep
    result = ansible_constructor_0.construct_mapping(node, True)

    # If deep is True, the result should be an AnsibleMapping instance
    assert isinstance(result, AnsibleMapping) == True


# Generated at 2022-06-25 04:30:32.592232
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    # example from string loader test case

# Generated at 2022-06-25 04:31:12.042587
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node = AnsibleUnicode()
    assert isinstance(ansible_constructor_0.construct_yaml_str(node), AnsibleUnicode)


# Generated at 2022-06-25 04:31:15.509455
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    try:
        ansible_constructor_0.construct_mapping(None)
    except ConstructorError:
        pass



# Generated at 2022-06-25 04:31:18.163094
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    assert ansible_constructor_1.vault_secrets is None


# Generated at 2022-06-25 04:31:21.672968
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    import yaml

    test_case_9 = """
- 1
- 2
- 3
- 4
- 5
- 6
- 7
- 8
- 9
- 10
"""
    my_data_9 = yaml.load(test_case_9, Loader=AnsibleConstructor)
    assert list(my_data_9) == [1,2,3,4,5,6,7,8,9,10]


# Generated at 2022-06-25 04:31:24.771713
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_str(node=unicode)) == AnsibleUnicode


# Generated at 2022-06-25 04:31:28.538531
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node = "}r""e"
    assert_equal(ansible_constructor_0.construct_yaml_seq(node), "}r""e")


# Generated at 2022-06-25 04:31:30.684454
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Remove this line on the next code change.
    raise NotImplementedError()


# Generated at 2022-06-25 04:31:33.605735
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
# Creation of object 'node'
    node_0 = object()
    ansible_constructor_0.construct_yaml_seq(node_0)


# Generated at 2022-06-25 04:31:36.506797
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

    yaml_node_0 = {}
    ansible_constructor_0.construct_mapping(yaml_node_0)


# Generated at 2022-06-25 04:31:37.856756
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    display.display(ansible_constructor_1)