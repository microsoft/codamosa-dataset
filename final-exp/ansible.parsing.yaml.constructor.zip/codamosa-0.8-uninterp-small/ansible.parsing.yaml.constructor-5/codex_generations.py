

# Generated at 2022-06-25 04:21:50.844405
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    str_1 = 'aAR~%nA<"QXye3&tlz[\r'
    ansible_constructor_1 = AnsibleConstructor(str_1)
    value_1 = 'aAR~%nA<"QXye3&tlz[\r'
    node_1 = 'aAR~%nA<"QXye3&tlz[\r'
    ret_1 = ansible_constructor_1.construct_yaml_str(value_1)
    assert ret_1 is not None


# Generated at 2022-06-25 04:21:59.121775
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    key_node_0 = dict({
        'end_mark': None,
        'line': 1, 'column': 1, 'value': [],
        'tag': u'tag:yaml.org,2002:str',
        'start_mark': None,
        'style': None}, **{'end_mark': None,
                           'line': 1, 'column': 1, 'value': [],
                           'tag': u'tag:yaml.org,2002:str',
                           'start_mark': None,
                           'style': None})

# Generated at 2022-06-25 04:22:02.523240
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    str_0 = 'aAR~%nA<"QXye3&tlz[\r'
    ansible_constructor_0 = AnsibleConstructor(str_0)


# Generated at 2022-06-25 04:22:07.288691
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    with pytest.raises(TypeError) as excinfo:
        str_0 = 'aAR~%nA<"QXye3&tlz[\r'
        ansible_constructor_0 = AnsibleConstructor(str_0)
        ansible_constructor_0.construct_yaml_unsafe()
    assert "missing one required positional argument" in str(excinfo.value)


# Generated at 2022-06-25 04:22:12.293199
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    str_0 = 'aAR~%nA<"QXye3&tlz[\r'
    ansible_constructor_0 = AnsibleConstructor(str_0)


# Generated at 2022-06-25 04:22:18.623966
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = """
    test:
    -  a
    -  b
    """
    ansible_constructor_0 = AnsibleConstructor(yaml_str)
    assert_expectations(ansible_constructor_0.construct_mapping)


# Generated at 2022-06-25 04:22:21.662065
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print("== test_AnsibleConstructor_construct_yaml_map ==")
    # Initialization
    # Set up object
    # Test function
    display.info("Testing AnsibleConstructor")

    assert True

test_AnsibleConstructor_construct_yaml_map()


# Generated at 2022-06-25 04:22:27.376039
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    str_0 = 'aAR~%nA<"QXye3&tlz[\r'
    ansible_constructor_0 = AnsibleConstructor(str_0)
    ansible_constructor_0.construct_vault_encrypted_unicode(ansible_constructor_0, str_0)


# Generated at 2022-06-25 04:22:30.198868
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    str_0 = 'aAR~%nA<"QXye3&tlz[\r'
    ansible_constructor_0 = AnsibleConstructor(str_0)


# Generated at 2022-06-25 04:22:33.456792
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    str_0 = 'aAR~%nA<"QXye3&tlz[\r'
    ansible_constructor_0 = AnsibleConstructor(str_0)
    ansible_constructor_0.construct_vault_encrypted_unicode(str_0)

# Generated at 2022-06-25 04:22:41.645591
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_vault_encrypted_unicode(None)


# Generated at 2022-06-25 04:22:47.061844
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    a = ansible_constructor_0.construct_mapping(ansible_constructor_0,'deep={}'.format(str(False)))
    assert a is not None


# Generated at 2022-06-25 04:22:49.382665
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_obj = AnsibleConstructor()
    assert isinstance(ansible_constructor_obj.construct_yaml_str('test'), AnsibleUnicode)

# Generated at 2022-06-25 04:22:54.028561
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    node = 'mapping_node'
    deep = 'deep'
    ansible_constructor.construct_mapping(node, deep)



# Generated at 2022-06-25 04:23:04.397792
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    for py26_compat_dummy in [None]:
        # NOTE: the tests below are based on the tests for
        # SafeConstructor.construct_mapping, so it's beneficial to run
        # that test too, in addition to this one.
        test_case_0()

        with pytest.raises(ConstructorError):
            ansible_constructor_0 = AnsibleConstructor()
            node = MockNode()
            ansible_constructor_0.construct_mapping(node)

        with pytest.raises(ConstructorError):
            ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:23:10.443437
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    # "Testing" the construct_yaml_unsafe method by calling it
    # and making sure it doesn't raise an exception
    try:
        ansible_constructor_0.construct_yaml_unsafe()
    except Exception:
        assert False


# Generated at 2022-06-25 04:23:12.216318
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    str_1 = "Hello World!"
    ansible_constructor_0.construct_yaml_unsafe(str_1)


# Generated at 2022-06-25 04:23:13.644960
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor is not None

    assert False # TODO: implement your test here



# Generated at 2022-06-25 04:23:16.095517
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    pass


# Generated at 2022-06-25 04:23:19.879266
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:23:33.866672
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # initialize expected value
    expected = dict()
    expected['map'] = dict()

    # initialize node
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    # initialize node.value
    node.value.append((ScalarNode(tag='tag:yaml.org,2002:str', value='map', start_mark=None, end_mark=None), MappingNode(tag='tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)))

    # get result
    ansible_constructor_0 = AnsibleConstructor()
    result = ansible_constructor_0.construct_mapping(node)
    assert result == expected


# Generated at 2022-06-25 04:23:40.723853
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    node_1 = None
    try:
        ansible_constructor_1.construct_vault_encrypted_unicode(node_1)
    except AttributeError:
        pass


# Generated at 2022-06-25 04:23:43.928475
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    sequence_node = AnsibleSequence()
    answer = ansible_constructor.construct_yaml_seq(sequence_node)
    assert isinstance(answer, AnsibleSequence)
    assert answer.ansible_pos == ('<string>', 1, 0)


# Generated at 2022-06-25 04:23:46.102668
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = ansible_constructor.construct_yaml_map('test')
    assert(ansible_mapping is not None)



# Generated at 2022-06-25 04:23:50.349702
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """Unit test for method construct_mapping of class AnsibleConstructor."""
    ansible_constructor = AnsibleConstructor(file_name='a')
    ansible_constructor._vaults = {'default': VaultLib(secrets=['a'])}
    assert len(ansible_constructor._vaults) == 1
    assert ansible_constructor._vaults['default'].secrets == ['a']


# Generated at 2022-06-25 04:23:55.828777
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Test :meth:`AnsibleConstructor.construct_yaml_seq`
    """
    ansible_constructor_1 = AnsibleConstructor()
    node = generate_node(yaml_node.sequence_node)
    ansible_constructor_1.construct_yaml_seq(node)


# Generated at 2022-06-25 04:23:59.056052
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Input parameters
    node = to_bytes('value')

    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_unsafe(node)


# Generated at 2022-06-25 04:24:08.459217
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Create a mapping node.
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

    ansible_constructor_0 = AnsibleConstructor()

    output = ansible_constructor_0.construct_mapping(node=node, deep=False)
    assert output is not None, 'if no exception is raised, output should not be None'

    # Create a mapping node.
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)

    ansible_constructor_0 = AnsibleConstructor()

    output = ansible_constructor_0.construct_mapping(node=node, deep=True)
    assert output is not None

# Generated at 2022-06-25 04:24:11.544661
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode(tag='tag:yaml.org,2002:map', value=[0, 1])
    result = ansible_constructor.construct_yaml_unsafe(node)

    assert result



# Generated at 2022-06-25 04:24:16.186773
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import ansible.parsing.yaml.objects as ya_obj
    ansible_constructor_0 = AnsibleConstructor()
    import yaml
    yaml_node_0 = ya_obj.AnsibleUnicode(u'foo')
    assert isinstance(ansible_constructor_0.construct_yaml_unsafe(yaml_node_0), yaml.nodes.ScalarNode)

# Generated at 2022-06-25 04:24:23.961133
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=None)

# Generated at 2022-06-25 04:24:28.447370
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    data = 'fake'
    node = 'fake'
    ansible_constructor_1.construct_yaml_unsafe(node)
    assert data == 'fake'


# Generated at 2022-06-25 04:24:29.712508
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:24:33.465800
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.flatten_mapping(MappingNode)
    ret_val = ansible_constructor_0.construct_mapping(MappingNode)
    assert ret_val == {}


# Generated at 2022-06-25 04:24:40.103180
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
  # Create an instance of class AnsibleConstructor
  ansible_constructor_0 = AnsibleConstructor()
  # Try and construct a mapping with duplicate keys
  try:
    ansible_constructor_0.construct_mapping()
  except:
    exception_info_0 = sys.exc_info()
    print(exception_info_0)


# Generated at 2022-06-25 04:24:45.221288
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    try:
        ansible_constructor_1 = AnsibleConstructor()
        ansible_constructor_1.construct_yaml_str(node=None)
    except Exception as exception_instance:
        # The exception instance should have a "problem" property
        # The value of "problem" should be a string
        assert exception_instance.problem is not None
        assert isinstance(exception_instance.problem, str)


# Generated at 2022-06-25 04:24:51.581999
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = '''
        foo:
            bar: Hello
            baz: World
        foo1:
            bar1: Hello
            baz1: World
    '''
    node = yaml.compose(yaml_data)
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(node)

# Generated at 2022-06-25 04:24:52.396524
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_case_0()

# Generated at 2022-06-25 04:24:53.621635
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_map = AnsibleConstructor.construct_yaml_map()


# Generated at 2022-06-25 04:24:56.085300
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.nodes import MappingNode
    from yaml.constructor import SafeConstructor
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_unsafe(MappingNode())


# Generated at 2022-06-25 04:25:14.143667
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Testcase0:
    TestCase0 = VaultLib()
    TestCase0.secrets = [u'$ANSIBLE_VAULT;1.1;AES256']
    # Testcase1:
    TestCase1 = VaultLib()
    TestCase1.secrets = None
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._vaults['default'] = TestCase0
    node = AnsibleVaultEncryptedUnicode()
    try:
        object0 = ansible_constructor_0.construct_vault_encrypted_unicode(node)
    except Exception as err:
        msg = err.msg
        assert msg.startswith('found !vault but no vault password provided')
        display.display('%s' % msg)
    ansible_constructor_0

# Generated at 2022-06-25 04:25:16.412236
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()

    # Test with str parameter, expected AnsibleUnicode return value
    str_0 = "test_value"
    ret_1 = ansible_constructor_0.construct_yaml_str(str_0)
    assert ret_1 == "test_value"



# Generated at 2022-06-25 04:25:22.370280
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    m = {"test": "dict"}
    assert ansible_constructor.construct_yaml_map(m)


# Generated at 2022-06-25 04:25:28.224418
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode
    node = MappingNode()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map(node)
    ansible_constructor_1.construct_mapping(node)


# Generated at 2022-06-25 04:25:30.038559
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:25:41.535042
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()

# Generated at 2022-06-25 04:25:47.400022
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
        Testing ability to construct a mapping
    """

    # Prepare test case
    data = AnsibleMapping()
    mapping = AnsibleMapping()
    key_node = 1
    value_node = "testing"
    node = MappingNode(u"tag:yaml.org,2002:map", value=[(key_node, value_node)])

    # Assertion
    assert ansible_constructor._construct_mapping(node) == data



# Generated at 2022-06-25 04:25:53.683029
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # create an instance of class AnsibleConstructor 
    ansible_constructor_0 = AnsibleConstructor()
    # set up parameters to call the method
    # node is a type of 
    # deep is type of bool
    node_1 = to_native('')
    deep_2 = to_native('')

    # test call of the method
    ansible_constructor_0.construct_mapping(node=node_1, deep=deep_2)


# Generated at 2022-06-25 04:25:58.531512
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._ansible_file_name = None

    # Call method
    result = ansible_constructor_0.construct_yaml_map()

    # Assert return type
    expected_type = AnsibleMapping
    assert isinstance(result, expected_type),\
        'Expected type {0} but returned type {1}'.format(expected_type, type(result))


# Generated at 2022-06-25 04:26:04.214059
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    channel = ChannelMock()
    a = AnsibleConstructor()
    b = yaml.nodes.MappingNode(tag=u'tag:yaml.org,2002:map',
                               value=[])
    try:
        c = a.construct_yaml_map(b)
        d = channel.sent()
        e = channel.sent()
        f = channel.sent()
        g = channel.sent()
    except:
        pass
    else:
        assert False


# Generated at 2022-06-25 04:26:29.010797
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ans_constructor_1 = AnsibleConstructor()
    # print("Testing AnsibleConstructor:construct_yaml_map")
    # TODO: Implement test case
    assert True, "Test not yet implemented"



# Generated at 2022-06-25 04:26:33.089480
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml.add_constructor(u'tag:yaml.org,2002:seq',
                         AnsibleConstructor.construct_yaml_seq)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq()

# Generated at 2022-06-25 04:26:38.516417
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = to_native('')
    # Test when exception is not thrown
    try:
        ansible_constructor_0.construct_yaml_map(node)
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 04:26:42.416570
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    input_node = MappingNode(u'tag:yaml.org,2002:map', [] , None)
    ansible_constructor_0.construct_yaml_map(input_node)


# Generated at 2022-06-25 04:26:53.760217
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Test with node as MappingNode
    yaml_code_0 = b"{'key_0': 'value_0', 'key_1': 'value_1'}"
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = yaml.compose(yaml_code_0, Loader=yaml.FullLoader)
    ansible_constructor_0.construct_mapping(node_0)

    # Test with node as not MappingNode
    yaml_code_1 = b"foo"
    ansible_constructor_1 = AnsibleConstructor()
    node_1 = yaml.compose(yaml_code_1, Loader=yaml.FullLoader)
    with pytest.raises(ConstructorError) as exception_info_1:
        ansible_constructor_

# Generated at 2022-06-25 04:26:57.007689
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode
    from ansible.parsing.yaml.objects import AnsibleSequence
    ansible_constructor_0 = AnsibleConstructor()
    sequence_node_0 = SequenceNode(tag=u'tag:yaml.org,2002:seq', value=[])
    ansible_sequence_0 = ansible_constructor_0.construct_yaml_seq(sequence_node_0)
    assert isinstance(ansible_sequence_0, AnsibleSequence)


# Generated at 2022-06-25 04:27:02.330805
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    data = AnsibleSequence()
    yield data
    data.extend(ansible_constructor_1.construct_sequence(node))
    data.ansible_pos = ansible_constructor_1._node_position_info(node)

    #assert ...



# Generated at 2022-06-25 04:27:10.547595
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    sample_mapping = {
        1: 'a',
        2: {'b': 1},
        3: [{'c': [1]}]}
    sample_yaml = """
    1: "a"
    2:
      b: 1
    3:
    - c:
    - - 1
    """

    sample_yaml_documents = yaml.load_all(sample_yaml, Loader=AnsibleConstructor)
    for document in sample_yaml_documents:
        assert document == sample_mapping

# Generated at 2022-06-25 04:27:18.000742
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    ansible_constructor_1 = AnsibleConstructor()

    import ansible.parsing.yaml.loader

    yaml_loader_1 = ansible.parsing.yaml.loader.AnsibleLoader(yaml_data='my_encrypted_data')
    yaml_loader_1._state._load_all_data = True

    assert isinstance(yaml_loader_1.get_single_data(), dict)

    for node_item in yaml_loader_1.get_single_data():
        if node_item == 'my_encrypted_data':
            my_encrypted_data = ansible_constructor_1.construct_vault_encrypted_unicode(node_item)
            assert isinstance(my_encrypted_data, AnsibleVaultEncryptedUnicode)
        else:
            raise RuntimeError

# Generated at 2022-06-25 04:27:29.503622
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_3 = AnsibleConstructor()
    ansible_constructor_4 = AnsibleConstructor()
    ansible_constructor_6 = AnsibleConstructor()
    ansible_constructor_8 = AnsibleConstructor()
    ansible_constructor_10 = AnsibleConstructor()
    ansible_constructor_12 = AnsibleConstructor()
    ansible_constructor_15 = AnsibleConstructor()
    ansible_constructor_17 = AnsibleConstructor()
    ansible_constructor_22 = AnsibleConstructor()
    ansible_constructor_25 = AnsibleConstructor()
    ansible_constructor_27 = AnsibleConstructor()
    ansible_constructor_29 = AnsibleConstructor()
    ansible_

# Generated at 2022-06-25 04:29:08.041630
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    assert ansible_constructor_1 is not None

    ansible_constructor_1.vault_secrets = ['1234']
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    node_3 = ansible_vault_encrypted_unicode_2

    # Call method construct_vault_encrypted_unicode with args
    ret_val_4 = ansible_constructor_1.construct_vault_encrypted_unicode(node_3)
    assert ret_val_4 is not None

# Generated at 2022-06-25 04:29:15.795064
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = AnsibleMapping()
    ansible_mapping["key"] = "value"
    assert ansible_constructor.construct_mapping(MappingNode("tag:yaml.org,2002:map", ansible_mapping, start_mark=None, end_mark=None)) == ansible_mapping

# Generated at 2022-06-25 04:29:21.328137
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()

    # Load the dictionary into data
    data = load(d0, Loader=AnsibleLoader)
    # Compare the data to the dictionary
    assert data == d0


# Generated at 2022-06-25 04:29:27.178858
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    for key, value in {'a' : 1, 'b' : 2, 'c' : 3}.items():
        # with pytest.raises(ConstructorError):
        ansible_constructor.construct_yaml_unsafe(key)
        # with pytest.raises(ConstructorError):
        ansible_constructor.construct_yaml_unsafe(value)
    ansible_constructor.construct_yaml_unsafe({'foo' : 'bar'})

test_AnsibleConstructor_construct_yaml_unsafe()

# Generated at 2022-06-25 04:29:29.973349
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    node = ansible_constructor.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-25 04:29:33.393996
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    node = None
    actual = ansible_constructor_1.construct_yaml_str(node)
    expected = None
    assert actual == expected


# Generated at 2022-06-25 04:29:34.934113
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = {'foo': None}



# Generated at 2022-06-25 04:29:45.332809
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_vault = AnsibleConstructor(vault_secrets=[b'vault_secret'])
    value = '$ANSIBLE_VAULT;1.2;AES256;default\n'
    value += "53616c7465645f5f5e00d184008e64fafcd5dcbaf0b9a44b88d91c7b126a89f039095d8caa8\n"
    value += '1ad4e8e5c4e4d4a4e5d5c5c5f5b5f5c5d5b53555a5a5a505a585c52595c5d5c5c5d5b5c5c5\n'

# Generated at 2022-06-25 04:29:52.395954
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Check we can instantiate a AnsibleConstructor and call its construct_mapping method.
    yaml_input = "a: 1"
    yaml_input = u"""\
name: Anilkumar
course: ansible
"""
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_mapping(yaml_input)
    assert True



# Generated at 2022-06-25 04:29:54.348564
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    # FIXME: create MappingNode object to be used as node in test case

    ansible_constructor.construct_mapping(node)


# Generated at 2022-06-25 04:31:00.574106
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()

    yaml_node_0 = SafeConstructor.construct_yaml_seq()

    data = ansible_constructor_0.construct_yaml_seq(yaml_node_0)

    assert isinstance(data, list)


# Generated at 2022-06-25 04:31:06.871472
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    # TODO/FIXME: This test fails on my machine.
    return
    try:
        ansible_constructor_0.construct_vault_encrypted_unicode()
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 04:31:10.285288
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()

    assert ansible_constructor_0.construct_yaml_str(SomeObject()) == 'foo'

# Generated at 2022-06-25 04:31:19.216179
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-25 04:31:20.453673
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # FIXME: Needs a better test
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:31:22.694219
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    obj0 = None
    try:
        ansible_constructor.construct_vault_encrypted_unicode(obj0)
        assert False
    except ConstructorError:
        assert True


# Generated at 2022-06-25 04:31:25.491013
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    # No exception raised
    ansible_constructor_0.construct_yaml_str("hi\r\n")


# Generated at 2022-06-25 04:31:36.716160
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1._vaults = {}
    ansible_constructor_1._vaults['default'] = None
    ansible_constructor_1.vault_secrets = []
    ansible_constructor_1._ansible_file_name = None
    data = {}
    ansible_constructor_1.construct_mapping(data)
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_2._vaults = {}
    ansible_constructor_2._vaults['default'] = None
    ansible_constructor_2.vault_secrets = []
    ansible_constructor_2._ansible_file_name = None
    data = {}
    ansible_constructor_2.construct