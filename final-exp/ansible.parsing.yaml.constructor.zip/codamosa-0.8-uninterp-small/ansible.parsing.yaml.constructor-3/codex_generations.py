

# Generated at 2022-06-25 04:21:54.217365
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._ansible_file_name = None
    ansible_constructor._vaults = {'default': VaultLib()}
    node = None
    ansible_mapping = ansible_constructor.construct_yaml_map(node)
    assert isinstance(ansible_mapping, AnsibleMapping)


# Generated at 2022-06-25 04:21:57.676729
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    node = {'ansible_pos': ('/etc/ansible/hosts', 2, 4), 'tags': ['ansible', 'python']}
    ansible_constructor.construct_yaml_unsafe(node)

# Generated at 2022-06-25 04:22:01.650477
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.secrets = dict()
    node = dict()
    node['id'] = 'object'
    assert isinstance(ansible_constructor_0.construct_yaml_unsafe(node), (AnsibleUnicode, AnsibleVaultEncryptedUnicode))


# Generated at 2022-06-25 04:22:04.206287
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map(dict())
    # assert
    assert True



# Generated at 2022-06-25 04:22:12.287537
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    config = {
        'hosts': ['web1', 'web2', 'web3'],
        'roles': ['common', 'apache', 'nginx'],
        'vars': {
            'port': 80,
            'user': 'apache',
            'tomcat_base': '/opt/tomcat',
            'catalina_base': '/opt/tomcat/current'
        }
    }

    yaml_text = '''
# this is a test config
hosts:
    - web1
    - web2
    - web3
roles:
    - common
    - apache
    - nginx
vars:
    port: 80
    user: apache
    tomcat_base: /opt/tomcat
    catalina_base: /opt/tomcat/current
'''

   

# Generated at 2022-06-25 04:22:13.749977
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    pass



# Generated at 2022-06-25 04:22:17.083213
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    # From /usr/lib/python2.7/site-packages/yaml/constructor.py:126:
    SafeConstructor.add_constructor(
        u'tag:yaml.org,2002:seq',
        SafeConstructor.construct_yaml_seq)


# Generated at 2022-06-25 04:22:19.681628
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    ansible_constructor_0.construct_yaml_map(node)


# Generated at 2022-06-25 04:22:22.391699
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    obj = AnsibleConstructor()
    obj.construction_exception = False
    try:
        obj.construct_mapping(node = object)
    except:
        obj.construction_exception = True
    assert obj.construction_exception


# Generated at 2022-06-25 04:22:26.277662
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    seq = {}
    # value = ansible_constructor_0.construct_yaml_seq(seq)
    # assert value == 0


# Generated at 2022-06-25 04:22:35.093273
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map()


# Generated at 2022-06-25 04:22:37.203764
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    # TODO: Add test of actual file to test case
    assert True  # TODO: implement your test here



# Generated at 2022-06-25 04:22:47.545650
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Create a YAML sequence node
    node = MappingNode(u'tag:yaml.org,2002:map', [])
    # Create an instance of class AnsibleConstructor
    ansible_constructor = AnsibleConstructor()

    # Test ansible constructor object is constructed
    assert ansible_constructor

    # Test ansible constructor object is instance of AnsibleConstructor class
    assert isinstance(ansible_constructor, AnsibleConstructor)

    # Test node is instance of MappingNode class
    assert isinstance(node, MappingNode)

    # Test ansible constructor method construct_mapping return value is instance of AnsibleMapping class
    assert isinstance(ansible_constructor.construct_mapping(node), AnsibleMapping)

# Generated at 2022-06-25 04:22:49.848606
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    ansible_constructor_0.construct_yaml_seq(node)


# Generated at 2022-06-25 04:22:53.040314
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ret_1 = ansible_constructor_0.construct_yaml_unsafe(u'foo')
    assert isinstance(ret_1, AnsibleUnicode)
    assert ret_1 == u"foo"

# Generated at 2022-06-25 04:22:58.899690
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # Construct a bogus node to be used in the function call
    node = 'a bogus node'

    # Construct the object to be tested
    ansible_constructor_0 = AnsibleConstructor()

    # Call the function to be tested
    ansible_constructor_0.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-25 04:23:06.330879
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    args = dict(node=None)

    ansible_constructor_0 = AnsibleConstructor()

    testcases = [
        # (expected_result, inputs_dict)
        (None, dict(node=None, deep=None)),
        (None, dict(node=None, deep=False)),
        (None, dict(node=None, deep=True)),
    ]

    for expected_result, inputs_dict in testcases:
        inputs_dict.update(args)

        try:
            result = ansible_constructor_0.construct_mapping(**inputs_dict)
        except Exception as exception:
            print('Exception:', repr(exception))
        else:
            if result == expected_result:
                print('PASS: test_case_0')

# Generated at 2022-06-25 04:23:11.887632
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor(file_name='t.yml', vault_secrets=[])
    node = {'start_mark': {'line': 0, 'column': 0}, 'id': 'EncryptedUnicode'}
    ansible_constructor_0.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-25 04:23:15.590286
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    # assert_equal does not take a msg parameter
    # assert_equal(node.id, 'str')


# Generated at 2022-06-25 04:23:26.287602
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # yaml constructor is expected to be a SafeConstructor

    test_case_0()

    ansible_constructor_1 = AnsibleConstructor(file_name=u'test/constructor/test_file.yaml')

    try:
        ansible_constructor_1.construct_vault_encrypted_unicode()
    except NotImplementedError as exc:
        assert_exception(exc, 'TODO/FIXME: plugin vault selector', 'AnsibleConstructor.construct_vault_encrypted_unicode()', 'test/module_utils/ansible_galaxy/api/__init__.py', 64)



# Generated at 2022-06-25 04:23:37.048440
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    obj = AnsibleSequence()
    value = [1, 2, 3]
    ansible_constructor.construct_yaml_seq(obj)
    ansible_constructor.construct_sequence()
    ansible_constructor.extend(value)
    return


# Generated at 2022-06-25 04:23:42.073922
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Normal case
    # Constructing got_sth via construct_yaml_map
    ansible_constructor_0 = AnsibleConstructor()
    got_sth = ansible_constructor_0.construct_yaml_map()
    assert got_sth == None
    # Constructing got_sth via construct_mapping
    ansible_constructor_0 = AnsibleConstructor()
    got_sth = ansible_constructor_0.construct_mapping()
    assert got_sth == None


# Generated at 2022-06-25 04:23:45.298052
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(node=ansible_constructor_0)



# Generated at 2022-06-25 04:23:46.973631
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    data = 'test'
    result = AnsibleConstructor.construct_yaml_str(data)
    assert result == u'test'


# Generated at 2022-06-25 04:23:54.699120
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode(tag=u'tag:yaml.org,2002:map', value=[])
    ansible_constructor_0.construct_yaml_map(node_0)


# Generated at 2022-06-25 04:23:59.100520
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq(
            to_bytes('line1:1\nline2:2:2:2\nline3:3:3')
    )

# Generated at 2022-06-25 04:24:09.671108
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._vaults = {}
    ansible_constructor_0.vault_secrets = []
    ansible_constructor_0._vaults['default'] = VaultLib(secrets=ansible_constructor_0.vault_secrets)
    ansible_constructor_0._ansible_file_name = 'ansible_file_name'
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_0.ansible_pos = (u'ansible_file_name', 1, 2)
    ansible_mapping_0[u'key'] = u'value'
    ansible_constructor_0.construct_mapping(ansible_constructor_0, true)

# Unit test

# Generated at 2022-06-25 04:24:12.981873
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    str_0 = 'some text'
    node_0 = str_0
    ret_0 = ansible_constructor_1.construct_yaml_str(node_0)
    assert ret_0 == 'some text'


# Generated at 2022-06-25 04:24:19.767829
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Load test yaml
    yaml_data_filepath = os.path.join("/Users/user/Documents/", "yaml_0.yml")
    with open(yaml_data_filepath, "r") as stream:
        test_yaml_data = yaml.load(stream=stream, Loader=AnsibleConstructor)
    # Test AnsibleConstructor.construct_yaml_seq
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_seq(yaml.nodes.SequenceNode()) == (test_yaml_data), "Method 'construct_yaml_seq' does not return the expected value"


# Generated at 2022-06-25 04:24:24.143244
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    node = object()
    ansible_constructor.construct_unsafe = lambda x: 'construct_unsafe'
    node.id = 'unsafe'
    ret = ansible_constructor.construct_yaml_unsafe(node)
    assert ret == 'construct_unsafe'


# Generated at 2022-06-25 04:24:31.404343
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    node = None
    ansible_constructor.construct_yaml_unsafe(node)


# Generated at 2022-06-25 04:24:32.646825
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    assert(ansible_constructor)

# Generated at 2022-06-25 04:24:39.840197
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    testYaml = """
- hosts: all
  roles:
    - role1
    - role2
  tasks:
    - debug: msg=\"Hello World\"
"""
    import yaml
    d = yaml.load(testYaml, Loader=AnsibleConstructor)
    for k, v in d.items():
        print("{}: {}".format(k, v))
    print("'hosts' in d: {}".format("hosts" in d))
    print("d['hosts']: {}".format(d['hosts']))
    print("'tasks' in d: {}".format("tasks" in d))
    print("d['tasks']: {}".format(d['tasks']))


# Generated at 2022-06-25 04:24:51.493536
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    ansible_constructor_0 = AnsibleConstructor()

    ### Possible duplicate key check ####

    # Testing with check
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    node = MappingNode(None, None, None)
    # first key
    key_node_1 = ansible_constructor_0.construct_scalar(None)
    value_node_1 = ansible_constructor_0.construct_scalar(None)
    node.value = [(key_node_1,value_node_1)]
    ansible_constructor_0.construct_mapping(node)

    # second key
    key_node_2 = ansible_constructor_0.construct_scalar(None)
    value_node_2 = ansible_constructor_0.construct

# Generated at 2022-06-25 04:24:52.818938
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    # Add your test here
    assert True


# Generated at 2022-06-25 04:24:55.735833
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    print('Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor... ')
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = ['password']
    ansible_constructor.construct_vault_encrypted_unicode('!vault $ANSIBLE_VAULT;1.1;AES256\n')


# Generated at 2022-06-25 04:24:59.593732
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    yaml_map = MappingNode()
    constructed_object = ansible_constructor.construct_yaml_map(yaml_map)


# Generated at 2022-06-25 04:25:02.615922
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(node=AnsibleUnicode())


# Generated at 2022-06-25 04:25:04.123495
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_object_0 = AnsibleMapping()
    ansible_constructor_1 = AnsibleConstructor()
    with pytest.raises(ConstructorError):
        ansible_constructor_1.construct_yaml_map(yaml_object_0)



# Generated at 2022-06-25 04:25:05.745686
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor
    # FIXME add test
    pass

# Generated at 2022-06-25 04:25:14.897856
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    str_0 = ansible_constructor_0.construct_yaml_str('The quick brown fox jumps over the lazy dog')
    assert str_0 == AnsibleUnicode('The quick brown fox jumps over the lazy dog')


# Generated at 2022-06-25 04:25:24.564422
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    str_tuple_0 = ()
    str_tuple_1 = ()
    # Setting up mock objects
    node_Mock_0 = Mock()
    node_Mock_0.start_mark = str_tuple_0
    # Setting up mock objects
    node_Mock_1 = Mock()
    node_Mock_1.start_mark = str_tuple_1
    str_tuple_2 = ()
    # Setting up mock objects
    node_Mock_2 = Mock()
    node_Mock_2.start_mark = str_tuple_2
    str_tuple_3 = ()
    # Setting up mock objects
    node_Mock_3 = Mock()
    node_Mock_3.start_mark = str_t

# Generated at 2022-06-25 04:25:34.733820
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import yaml
    a_dict = {'a':1, 'b':2, 'c':3}
    a_yaml_str = yaml.dump(a_dict)
    yaml_obj = yaml.load(a_yaml_str, Loader=AnsibleConstructor)
    # Test that the object returned by yaml.load is an AnsibleMapping instance
    assert isinstance(yaml_obj, AnsibleMapping)
    # Test that the object returned by yaml.load has the same value as the original dict
    assert a_dict == yaml_obj
    # Test that the object returned by yaml.load has a value for ansible_pos
    assert isinstance(yaml_obj.ansible_pos, tuple)
    # Test that the object returned by yaml.load has a value for ansible_

# Generated at 2022-06-25 04:25:43.858802
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    # Test with "vault_password_file" not set in ansible.cfg and VAULT_PASSWORD_FILE env variable not set
    try:
        ansible_constructor.construct_vault_encrypted_unicode("")
    except ConstructorError as e:
        assert e.problem == "found !vault but no vault password provided"

    # Test with "vault_password_file" not set in ansible.cfg but VAULT_PASSWORD_FILE env variable set
    import os
    os.environ["VAULT_PASSWORD_FILE"] = "vault_pass_file"

# Generated at 2022-06-25 04:25:45.380258
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Calling method construct_yaml_seq of AnsibleConstructor
    test_case_0()

# Generated at 2022-06-25 04:25:46.981918
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:25:55.792019
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    # check to make sure that duplicate keys fail
    yaml_wrap_0 = AnsibleConstructor()
    yaml_wrap_0._ansible_file_name = 'foo'
    yaml_wrap_1 = AnsibleConstructor()
    yaml_wrap_1._ansible_file_name = 'foo'
    node_map_0 = [MappingNode(tag=u'tag:yaml.org,2002:map', value=[])]
    node_wrap_0 = yaml_wrap_0.construct_mapping(node_map_0)
    node_wrap_1 = yaml_wrap_1.construct_mapping(node_map_0)

# Generated at 2022-06-25 04:26:02.058006
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    '''test_AnsibleConstructor_construct_yaml_seq()
    Unit test for `AnsibleConstructor.construct_yaml_seq`
    '''

    ansible_constructor_0 = AnsibleConstructor()
    parameter_1 = None

    # Test normal operation
    try:
        ansible_constructor_0.construct_yaml_seq(parameter_1)
    except:
        pass



# Generated at 2022-06-25 04:26:10.962740
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_construct_yaml_map = AnsibleConstructor()
    node = MappingNode('tag:yaml.org,2002:map', [('key', 'value')], start_mark=None, end_mark=None)
    data = AnsibleMapping()
    yield data
    value = ansible_constructor_construct_yaml_map.construct_mapping(node)
    data.update(value)
    data.ansible_pos = ansible_constructor_construct_yaml_map._node_position_info(node)


# Generated at 2022-06-25 04:26:15.258207
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    assert ansible_constructor_1.construct_mapping is not None



# Generated at 2022-06-25 04:26:27.010658
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:30.108558
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    yaml_seq = [1,2,3]
    ansible_constructor.construct_yaml_seq(yaml_seq)


# Generated at 2022-06-25 04:26:32.502246
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_vault_encrypted_unicode() != None

# Generated at 2022-06-25 04:26:38.554337
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    custom_constructor = AnsibleConstructor()
    custom_constructor.construct_yaml_map()
    aaa = AnsibleConstructor()
    aaa.construct_yaml_map()
    aaa.add_multi_constructor(u'!include', aaa.construct_include)
    aaa._ansible_yaml_base_class = AnsibleConstructor
    bbb = AnsibleConstructor()
    bbb._ansible_yaml_base_class = aaa
    ddd = AnsibleConstructor()
    ddd._ansible_yaml_base_class = bbb
    eee = AnsibleConstructor()
    eee._ansible_yaml_base_class = ddd
    eee._vaults = {}
    # TODO/

# Generated at 2022-06-25 04:26:40.139240
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:42.335735
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(None)



# Generated at 2022-06-25 04:26:47.044530
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    test_node_1 = MappingNode()
    assert isinstance(ansible_constructor_1.construct_yaml_seq(test_node_1), AnsibleSequence)


# Generated at 2022-06-25 04:26:48.834409
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:50.701706
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # FIXME: Create a test_case or test_case_set
    test_case_0()

# Generated at 2022-06-25 04:26:54.619345
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    node_0 = MappingNode()
    ansible_constructor_0.construct_mapping(node_0, deep=False)
    ansible_mapping_0.ansible_pos

# Generated at 2022-06-25 04:27:17.992029
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansibleconstructor = AnsibleConstructor()
    node = MappingNode(None, None, True, None, None)
    deep = False
    # Test with no context
    result = ansibleconstructor.construct_mapping(node, deep)
    assert result is not None


# Generated at 2022-06-25 04:27:19.982467
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping("node")


# Generated at 2022-06-25 04:27:29.845658
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    test_str = "test string"
    ansible_constructor_str = AnsibleConstructor()
    ansible_constructor_int = AnsibleConstructor()

    # Testing when data is a string
    ret_str = ansible_constructor_str.construct_yaml_str(test_str)
    assert(ret_str.__class__ is AnsibleUnicode)
    assert(ret_str.ansible_pos == ('<string>', 1, 1))


# Generated at 2022-06-25 04:27:37.069760
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    ansible_constructor_0 = AnsibleConstructor('<unicode string>')
    ansible_loader_0 = AnsibleLoader(ansible_constructor_0)
    data = ansible_loader_0.load("---\n- !unsafe 'hello'\n")
    assert id(data[0]) == id(AnsibleUnsafeText('hello'))


# Generated at 2022-06-25 04:27:39.924676
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    # TODO: add test for method construct_yaml_seq of class AnsibleConstructor
    assert True



# Generated at 2022-06-25 04:27:53.020127
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode(u'tag:yaml.org,2002:map', [(ScalarNode(u'tag:yaml.org,2002:str', u'name'),
                                                     ScalarNode(u'tag:yaml.org,2002:str', u'name')),
                                                    (ScalarNode(u'tag:yaml.org,2002:str', u'password'),
                                                     ScalarNode(u'tag:yaml.org,2002:str', u'password'))],
                                                     start_mark=Mark(None, None, [], None, None, None),
                                                     end_mark=Mark(None, None, [], None, None, None))

# Generated at 2022-06-25 04:27:57.322372
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_2 = AnsibleConstructor('/etc/ansible/hosts')
    ansible_constructor_3 = AnsibleConstructor(None)


# Generated at 2022-06-25 04:28:00.344125
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:28:07.912526
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:28:09.482451
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    ansible_constructor_0.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-25 04:28:51.784766
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    with pytest.raises(ConstructorError):
        ansible_constructor_0 = AnsibleConstructor()
        ansible_constructor_0.construct_mapping(u'hi')


# Generated at 2022-06-25 04:29:02.748255
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # If a dict key is defined more than once, the last value overwrites the previous values
    # Therefore, the duplicate dict key should throw an error
    ansible_constructor = AnsibleConstructor()

    yaml_node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], flow_style=False)
    # Data to be used in constructing the mapping node
    key = u'foo'
    value1 = to_bytes(u'bar')
    value2 = to_bytes(u'fiz')
    item1 = (key, value1)
    item2 = (key, value2)
    yaml_node.value = [item1, item2]

    # Determine if the construct_mapping raises an error when a duplicate dict key is provided

# Generated at 2022-06-25 04:29:10.579459
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    # Initialize the class variable
    ansible_constructor._ansible_file_name = "test_string"
    ansible_constructor._vaults = {}
    ansible_constructor.vault_secrets = [None]
    class constructor_object:
        def __init__(self, file_name=None, vault_secrets=None):
            pass
        def add_constructor(tag, constructor):
            pass
    ansible_constructor.constructor = constructor_object()
    ansible_constructor.constructor.getattr = constructor_object()
    ansible_constructor.constructor.getattr.return_value = "object"
    ansible_constructor.constructor.getattr.return_value = None
    ansible_constructor.constructor

# Generated at 2022-06-25 04:29:14.713963
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    import ansible
    import ansible.parsing.yaml.objects
    import yaml
    yaml_1 = u'---\nfoo: hello\n'
    ansible_file_name_0 = 'AnsibleConstructor'
    ansible_constructor_0 = AnsibleConstructor(ansible_file_name_0)
    node_list_0 = yaml.compose_all(yaml.parse(yaml_1))
    node_0 = node_list_0[0]
    try:
        ansible_dict_0 = ansible_constructor_0.construct_mapping(node_0)
    except ConstructorError as error:
        ansible_dict_0 = exception(error)


# Generated at 2022-06-25 04:29:24.806007
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor_construct_yaml_seq_mock_0 = {
        'ansible_pos': {},
        'class': 'AnsibleConstructor',
        'obj': 'ansible_constructor_construct_yaml_seq_mock_0',
        'vault_secrets': [],
    }
    ansible_constructor_construct_yaml_seq_mock_1 = None
    with pytest.raises(AnsibleParserError) as ansible_constructor_construct_yaml_seq_mock_2:
        ansible_constructor.construct_yaml_seq()

# Generated at 2022-06-25 04:29:26.612201
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # test with the first parameter of type MappingNode
    assert(True == True)

# Generated at 2022-06-25 04:29:36.543111
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:29:44.390082
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    print("\n***** Running Test Case for AnsibleConstructor.construct_yaml_seq *****")
    ansible_constructor_0 = AnsibleConstructor()
    data = AnsibleSequence()
    print("\n***** Created AnsibleSequence object *****")
    ansible_constructor_0.construct_yaml_seq(data)
    print("\n***** Created AnsibleConstructor Object using created AnsibleSequence object. *****")
    print("\n***** End Test Case for AnsibleConstructor.construct_yaml_seq *****")


# Generated at 2022-06-25 04:29:45.172195
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_case_0()

# Generated at 2022-06-25 04:29:47.047955
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    assert ansible_constructor_1 is not None


# Generated at 2022-06-25 04:30:37.252517
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Set up test data
    self = AnsibleConstructor()
    self.flatten_mapping = lambda node: None
    node = MappingNode()
    node.value = (
        [
            MappingNode(),
            MappingNode()
        ],
        [
            MappingNode(),
            MappingNode()
        ]
    )
    self.construct_object = lambda node, deep=False: map(MappingNode, node)
    deep = 0

    # Invoke method
    ret = self.construct_mapping(node, deep)

    # Check result
    assert ret == AnsibleMapping(), "Incorrect result returned"


# Generated at 2022-06-25 04:30:38.443041
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # TODO: add tests for construct_mapping
    return


# Generated at 2022-06-25 04:30:46.493433
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    yaml_data = '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  306362323331333739363466313533386533373138613565653037323662386364666637343932\n  3461646564633565393437333435303531353334376438690a3264363437353966363232336332\n  643833386438356564323138396435636236613962666361383664653161316132643663346337\n  38636466383938356163630a33353666363830643138356435613465383331303233346500'
    import yaml

# Generated at 2022-06-25 04:30:48.660453
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = {}
    result = ansible_constructor_0.construct_yaml_map(node)
    assert 'AnsibleMapping' in repr(result)


# Generated at 2022-06-25 04:30:58.004897
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._vaults = {'default': VaultLib(secrets=['vault_pass_test'])}

# Generated at 2022-06-25 04:31:00.202663
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    data = ansible_constructor_0.construct_yaml_map()
    data.next()
    data.send(3)
    try:
        data.send(3)
    except StopIteration:
        pass


# Generated at 2022-06-25 04:31:07.436297
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ciphertext = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          643539366136363061343966316334623234303766363631666335623234633163613462633862330a\n          3932653762373232636661666665376632393237643935313432626133313561396363303064313938\n          350a\n'

# Generated at 2022-06-25 04:31:17.611472
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_mapping_2 = AnsibleMapping()
    ansible_mapping_2['a'] = 'b'
    ansible_mapping_2['c'] = 'd'
    ansible_mapping_2['e'] = 'f'
    ansible_mapping_2['g'] = 'f'
    ansible_mapping_2['h'] = 'i'

    ansible_mapping_3 = AnsibleMapping()
    ansible_mapping_3['a'] = 'b'
    ansible_mapping_3['c'] = 'd'
    ansible_mapping_3['e'] = 'f'
    ansible_mapping_3['g'] = 'f'

# Generated at 2022-06-25 04:31:18.675816
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:31:22.343988
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = yaml.nodes.Node()
    list_0 = ansible_constructor_0.construct_yaml_seq(yaml_node_0)
    assert list_0 == ansible_constructor_0.construct_yaml_seq(yaml_node_0), "The expected return value does not match the returned value"

