

# Generated at 2022-06-25 04:21:57.286142
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Testing a simple dict
    doc = '''
    # Just a dict
    test:
      name: value
    '''
    ansible_constructor_0 = AnsibleConstructor()
    root_node_0 = yaml.compose(doc)
    # The output of compose is a list of the top-level nodes of the YAML document
    assert len(root_node_0) == 1
    root_node_0 = root_node_0[0]
    assert isinstance(root_node_0, MappingNode)
    root_value_0 = ansible_constructor_0.construct_object(root_node_0)
    assert isinstance(root_value_0, dict)
    expected_root_value_0 = {'test': {'name': 'value'}}
    assert root_value_0

# Generated at 2022-06-25 04:22:02.091487
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = '123456'
    ansible_constructor_0 = AnsibleConstructor(vault_secrets=[vault_password])
    yaml_node = u'vault-encrypted'
    value = 'value'
    value_out = ansible_constructor_0.construct_vault_encrypted_unicode(yaml_node=yaml_node)
    assert value == value_out.vault._decrypt_text(value_out.ciphertext_bytes)

# Generated at 2022-06-25 04:22:07.931114
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1__construct_mapping = AnsibleConstructor().construct_mapping

    ansible_constructor_1__construct_mapping_int = ansible_constructor_1__construct_mapping(MappingNode('tag:yaml.org,2002:map', [], True), True)

    ansible_constructor_1__construct_mapping_other = ansible_constructor_1__construct_mapping(MappingNode('tag:yaml.org,2002:something', [], True), True)


# Generated at 2022-06-25 04:22:19.251144
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Source data
    data = u'!unsafe ["echo","bubu"]'

    # Reading test data
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()

    # Expected result
    ansible_constructor_0_expected = wrap_var(['echo', 'bubu'])
    ansible_constructor_1_expected = wrap_var(['echo', 'bubu'])

    # Actual result
    ansible_constructor_0_actual = ansible_constructor_0.construct_yaml_unsafe(data)
    ansible_constructor_1_actual = ansible_constructor_1.construct_yaml_unsafe(data)

    # Verification
    assert ansible_constructor_0_actual == ansible_constructor_

# Generated at 2022-06-25 04:22:21.691885
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    node = "not a valid node"
    deep_0 = False
    assert not isinstance(ansible_constructor.construct_mapping(node, deep_0), dict)


# Generated at 2022-06-25 04:22:23.449113
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

# Generated at 2022-06-25 04:22:32.236597
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    node_0_0 = MappingNode(None, None)
    node_0_0.id = None
    mapping_node_0_0_0 = MappingNode(None, None)
    mapping_node_0_0_0.id = None
    mapping_node_0_0_0.value = None
    node_0_0.tag = u'tag:yaml.org,2002:map'
    node_0_0.value = [(mapping_node_0_0_0, mapping_node_0_0_0)]
    mapping_node_0_0_0.tag = u'tag:yaml.org,2002:map'
    mapping_node_0_0_0.value = None
    mapping_node_0_0_0

# Generated at 2022-06-25 04:22:34.034557
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_vault_encrypted_unicode('node')

# Generated at 2022-06-25 04:22:36.848009
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_mapping()


# Generated at 2022-06-25 04:22:43.744978
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = node()
    data_0 = YAML.load(open('examples.yaml', 'r'), Loader=ansible_constructor_0.construct_yaml_map)
    data_1 = YAML.load(open('examples.yaml', 'r'), Loader=ansible_constructor_0.construct_yaml_map)


# Generated at 2022-06-25 04:22:53.618549
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    obj = AnsibleConstructor()
    node = 'foo'
    result = obj.construct_yaml_unsafe(node)


# Generated at 2022-06-25 04:22:57.349023
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_yaml_unsafe('test') == 'test'

# Generated at 2022-06-25 04:22:58.898283
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:23:01.839539
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    # TODO: understand what this does and how to unit test it
    ansible_constructor.construct_mapping()


# Generated at 2022-06-25 04:23:13.355857
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    assert (isinstance(ansible_constructor_1, AnsibleConstructor))

    vault_secret = [u'This is a secret']
    ansible_constructor_2 = AnsibleConstructor(vault_secrets=vault_secret)
    assert (isinstance(ansible_constructor_2, AnsibleConstructor))

    ansible_constructor_0 = AnsibleConstructor(vault_secrets=vault_secret)
    assert (isinstance(ansible_constructor_0, AnsibleConstructor))


# Generated at 2022-06-25 04:23:18.225094
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    # A
    ansible_constructor_0.vault_secrets = [u'YwFoY2k6YWFhYWE=']
    ret = ansible_constructor_0.construct_vault_encrypted_unicode(node)
    assert ret == u'hi'

# Generated at 2022-06-25 04:23:20.247861
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    assert callable(ansible_constructor_1.construct_mapping)


# Generated at 2022-06-25 04:23:26.034390
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
  # Create an object of the class under test
  ansible_constructor_0 = AnsibleConstructor()

  # Test the constructor
  assert ansible_constructor_0 is not None

  # Create objects for testing

  # Invoke the method under test
  # assert_raises(self, 'ansible_constructor_0.construct_yaml_map(node)', globals(), locals(), [], None)



# Generated at 2022-06-25 04:23:33.245099
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    fixture_0 = [
        '---',
        '# this is a comment',
        '- name: one',
        '  foo: !unsafe [0,1,2]',
        '  baz: !unsafe { a: 2, b: 3 }',
        '  bar: !unsafe true',
        '- name: two',
        '  baz: !unsafe 42',
        '  bar: !unsafe false',
        ''
    ]
    fixture_0 = '\n'.join(fixture_0)

    yaml = YAML()

    ansible_constructor_0 = AnsibleConstructor()
    yaml.constructor = ansible_constructor_0
    data = yaml.load(fixture_0)
    assert len(data) == 2



# Generated at 2022-06-25 04:23:35.213746
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor_construct_yaml_map = ansible_constructor.construct_yaml_map()


# Generated at 2022-06-25 04:23:48.155633
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_secrets = ['secret']
    ansible_constructor_0 = AnsibleConstructor(vault_secrets=vault_secrets)

# Generated at 2022-06-25 04:23:56.549287
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor(
        file_name='/opt/ansible/shippable/testresults/ansible_collections/ansible/builtin/tests/unit/test_parser_yaml_fixtures/test.yml',
        vault_secrets=[])

# Generated at 2022-06-25 04:24:03.914340
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # The method called construct_yaml_seq is defined on line 82 of parse/yaml/loader.py
    # It uses the python function construct_yaml_seq defined above
    test_AnsibleConstructor = AnsibleConstructor()

    # The following is an example of input that would be given to the class AnsibleConstructor
    # Node(tag="tag:yaml.org,2002:str", value="test_value_1")
    node = MappingNode(tag, value, start_mark, end_mark, flow_style=None)


# test_case_0()
test_AnsibleConstructor_construct_yaml_seq()

# Generated at 2022-06-25 04:24:04.827551
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()



# Generated at 2022-06-25 04:24:10.945635
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # No context:
    method = AnsibleConstructor.construct_yaml_unsafe
    method._ansible_file_name = 'no_context_file'
    method._vaults = {'default': 'no_context_vault'}
    method.vault_secrets = ['no_context_vault_secret']

    # Node is empty:
    node_empty = yaml.nodes.ScalarNode('tag:yaml.org,2002:int', '', (1, 1))
    method(node_empty)


# Generated at 2022-06-25 04:24:18.974977
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = [ VaultLib(secrets=['ansible']), VaultLib(secrets=['ansible']) ]
    data = '$ANSIBLE_VAULT;1.1;AES256\n62303061623033623037346535626361343862363262373163636331653533346461613337306637\n33393938663834356431323134646539356436316633656432363464653830643431366364396566\n35643762333064393835643535306433626362363136623430313561316434396438613037343537\n39303264373562\n'

# Generated at 2022-06-25 04:24:26.849107
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_nodes_str_0 = '''- [ 'Hello', 'World', '!' ]'''
    res = None

# Generated at 2022-06-25 04:24:28.048506
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_mapping()


# Generated at 2022-06-25 04:24:36.804811
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    cipherext = b'$ANSIBLE_VAULT;1.1;AES256\n'
    cipherext += b'63313165396662633837383662333963356435633665643835346263623162363735303335356332\n'
    cipherext += b'34386536306261393739326634323661642d38353366303664633762643032636265396165633761\n'
    cipherext += b'6234613631323963\n'

# Generated at 2022-06-25 04:24:39.722421
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

    # Test when extra_value > constructed value
    extra_value = 2
    constructed_value = 1

    assert extra_value > constructed_value

# Generated at 2022-06-25 04:24:49.602136
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()

    assert(isinstance(ansible_constructor.construct_yaml_map, types.MethodType))
    # TODO: Some better tests for this method.
    ansible_constructor.construct_yaml_map('test_node')

# Generated at 2022-06-25 04:24:52.819395
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(node=None)


# Generated at 2022-06-25 04:24:57.934438
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print("Method: AnsibleConstructor.construct_yaml_map()")
    ansible_constructor_1 = AnsibleConstructor()

    with pytest.raises(ConstructorError):
        ansible_constructor_1.construct_yaml_map('Not a MappingNode')
    ansible_constructor_1._ansible_file_name = 'test.yaml'
    ansible_constructor_1.construct_yaml_str('asdf')
    assert ansible_constructor_1.construct_yaml_str('asdf') == ansible_constructor_1.construct_scalar('asdf')

# Generated at 2022-06-25 04:24:59.965769
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq()


# Generated at 2022-06-25 04:25:04.528005
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    pass  # TODO

# Generated at 2022-06-25 04:25:07.214103
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq()

# Generated at 2022-06-25 04:25:14.645542
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-25 04:25:19.055626
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    value = ansible_constructor_1.construct_vault_encrypted_unicode(node)
    ciphertext_data = value.vault.decrypt(value.ciphertext_bytes)
    assert ciphertext_data == b'hello'



# Generated at 2022-06-25 04:25:20.493541
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    """Test method construct_yaml_map of class AnsibleConstructor"""
    test_case_0()


# Generated at 2022-06-25 04:25:27.283281
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    vault_password = "abcd"
    vault_secret_0 = vault_password.encode('utf-8')
    vault_secrets_0 = [vault_secret_0]
    vault_secrets_list_0 = [vault_secrets_0]
    ansible_constructor_0.vault_secrets = vault_secrets_list_0
    scalar_node_0 = None
    try:
        ansible_constructor_0.construct_vault_encrypted_unicode(scalar_node_0)
    except:
        pass

# Generated at 2022-06-25 04:25:36.952589
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
  pass



# Generated at 2022-06-25 04:25:39.640039
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    data = MappingNode(None, None, [])
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map(data)


# Generated at 2022-06-25 04:25:43.575418
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map()


# Generated at 2022-06-25 04:25:49.396354
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(node="node")
    # no exception is a good thing


# Generated at 2022-06-25 04:25:58.753699
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from ansible.module_utils._text import to_bytes, to_unicode, to_text
    from ansible.module_utils.basic import AnsibleUnicode

    ansible_constructor_0 = AnsibleConstructor()
    scalar_node_0 = object()

    # ansible_constructor_0.construct_scalar is not mockable so
    # we use a monkey patch instead.

    def mock_construct_scalar(node):
        # The return value will be used by
        # AnsibleConstructor.construct_yaml_str as its return value
        return to_unicode(node)

    monkeypatch = None

# Generated at 2022-06-25 04:25:59.586049
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_case_0()


# Generated at 2022-06-25 04:26:02.816620
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode()
    ansible_dict_0 = ansible_constructor_0.construct_yaml_map(node)
    assert list(ansible_dict_0) == []
    return


# Generated at 2022-06-25 04:26:11.313449
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()

    # dictionary to test
    test_dict = {'key': 'value'}

    # test_node is a fake node that has no useful attributes except the value
    # attribute which has a dummy value 0
    test_node = type('', (), {'value': 0})
    test_node.value = test_dict

    # Test if the constructor correctly returns a AnsibleMapping object from
    # the function construct_yaml_map
    assert type(ansible_constructor_0.construct_yaml_map(test_node)) == AnsibleMapping


# Generated at 2022-06-25 04:26:14.127660
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = AnsibleConstructor.construct_yaml_unsafe(ansible_constructor_0, node)
    assert node_0 == wrap_var(value)



# Generated at 2022-06-25 04:26:22.190367
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Data for test.
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0 = AnsibleConstructor()
    node_1 = object()
    ecrypt_key = ansible_constructor_0.construct_vault_encrypted_unicode(node_1)

    # Check the result
    expected_result_value =  AnsibleVaultEncryptedUnicode()
    assert (expected_result_value == ecrypt_key)



# Generated at 2022-06-25 04:26:36.716851
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(node=None)


# Generated at 2022-06-25 04:26:37.491763
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:26:40.375770
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    print("Testing - AnsibleConstructor.construct_yaml_str")
    # TODO
    #raise Exception("Not implemented")


# Generated at 2022-06-25 04:26:42.576434
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str()


# Generated at 2022-06-25 04:26:44.182905
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_AnsibleConstructor_construct_yaml_map_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:55.247337
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_2 = AnsibleConstructor()

# Generated at 2022-06-25 04:27:00.608413
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Data for class constructor_map_node
    constructor_map_node_data = [
        (
            ({'key': 2},),
            0
        ),
        (
            ({'key': 3},),
            0
        ),
    ]
    # Data for class constructor_yaml_unsafe_data
    constructor_yaml_unsafe_data_data = [
        (
            ({'key': 2},),
            0
        ),
        (
            ({'key': 3},),
            0
        ),
    ]

    # Test data
    yaml_loader_data = [
        (
            ({},),
            0
        ),
    ]

# Generated at 2022-06-25 04:27:03.641385
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_construct_yaml_map = AnsibleConstructor()
    ansible_constructor_construct_yaml_map.construct_yaml_map(node)


# Generated at 2022-06-25 04:27:09.445083
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_construct_vault_encrypted_unicode = AnsibleConstructor()
    ansible_constructor_construct_vault_encrypted_unicode.vault_secrets = ['test']
    ansible_constructor_construct_vault_encrypted_unicode.construct_vault_encrypted_unicode(None)


# Generated at 2022-06-25 04:27:13.458398
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping()
    ansible_constructor_1.construct_mapping()


# Generated at 2022-06-25 04:27:40.908377
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # values that are not objects and not scalars should replace a private
    # class with a Python native one
    ansible_constructor = AnsibleConstructor()
    yaml_loader = get_yaml_loader()
    yaml_loader.add_constructor(u'!unsafe', ansible_constructor.construct_yaml_unsafe)
    yaml_loader.add_constructor(u'!vault', ansible_constructor.construct_vault_encrypted_unicode)
    assert_true(getattr(yaml_loader.construct_yaml_unsafe, 'private', False))
    assert_true(getattr(yaml_loader.construct_vault_encrypted_unicode, 'private', False))

# Generated at 2022-06-25 04:27:49.509880
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping0 = dict()
    node0 = MappingNode(tag='tag:yaml.org,2002:map', implicit=True, start_mark=None, end_mark=None, value=[(1, mapping0)])
    deep0 = False
    ansible_constructor_0 = AnsibleConstructor()
    dict0 = ansible_constructor_0.construct_mapping(node0, deep0)
    print(dict0)


# Generated at 2022-06-25 04:27:51.261220
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor._vaults['default']

# Generated at 2022-06-25 04:27:55.729011
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str()


# Generated at 2022-06-25 04:28:02.751302
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    secrets = ['foo']
    ansible_constructor.vault_secrets = secrets
    ansible_constructor._vaults['default'] = VaultLib(secrets=secrets)
    test_node = 'test node'
    ansible_constructor.construct_scalar = MagicMock(return_value='test value')
    ansible_constructor.construct_vault_encrypted_unicode(test_node)
    ansible_constructor.construct_scalar.assert_called_once_with(test_node)


# Generated at 2022-06-25 04:28:04.194552
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # >>> ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    # >>> ansible_constructor_1.construct_yaml_map(node)

# Generated at 2022-06-25 04:28:05.941415
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # FIXME: Implement unit test for method AnsibleConstructor.construct_mapping
    raise NotImplementedError()



# Generated at 2022-06-25 04:28:06.866503
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    pass


# Generated at 2022-06-25 04:28:08.245067
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe()

# Generated at 2022-06-25 04:28:09.364878
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping()

# Generated at 2022-06-25 04:28:29.585010
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    # TODO: This test is not yet implemented
    # assert ansible_constructor_0.construct_yaml_unsafe('node') == expected


# Generated at 2022-06-25 04:28:33.054696
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0.construct_vault_encrypted_unicode(''), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 04:28:44.402504
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_obj_0 = AnsibleConstructor(file_name='/home/vagrant/ansible/test/yaml/test_yaml.yml')
    ansible_constructor_obj_0.add_constructor(u'!vault', ansible_constructor_obj_0.construct_vault_encrypted_unicode)
    ansible_constructor_obj_0.add_constructor(u'!vault-encrypted', ansible_constructor_obj_0.construct_vault_encrypted_unicode)
    ansible_constructor_obj_0.vault_secrets = [{'password': '$1$TfzAKGbd$jhcRnCnF9o2M2V7DhwIFB/'}]
    ansible_constructor_obj_0._

# Generated at 2022-06-25 04:28:48.852982
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_construct_mapping_0 = AnsibleConstructor()
    node = None
    deep = None
    ansible_constructor_construct_mapping_0.construct_mapping(node, deep)

# Generated at 2022-06-25 04:28:51.402616
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_vault_encrypted_unicode()



# Generated at 2022-06-25 04:28:58.180435
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a = AnsibleConstructor()
    b = AnsibleMapping()
    # AnsibleMapping() that doesn't throw an exception for duplicate dict keys.
    # This is an example of one of the errors caught.
    c = AnsibleMapping()
    c[1] = 1
    c[1] = 2
    d = AnsibleMapping()
    e = MappingNode(None, None, True, None)
    f = False
    g = False
    result = a.construct_mapping(b, f)
    assert result is None


# Generated at 2022-06-25 04:29:04.894988
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    data = 'Test String'
    node = AnsibleConstructor.construct_yaml_str(data)

    print(node)

# Generated at 2022-06-25 04:29:10.692193
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_str_0 = u'name: "sMyQ1HISROhOoOiD0JspMfqzb3ZOd3GV"\n'
    yaml_str_hash_0 = {u'name': 'sMyQ1HISROhOoOiD0JspMfqzb3ZOd3GV'}
    try:
        ansible_constructor_0 = AnsibleConstructor()
        ansible_constructor_0.construct_yaml_map(yaml_str_hash_0)
    except TypeError as e:
        print(e)
    else:
        print('Expected TypeError')


# Generated at 2022-06-25 04:29:14.548153
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:29:21.224253
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Instantiation
    ansible_constructor_0 = AnsibleConstructor()

    node_map = AnsibleMapping()
    result = ansible_constructor_0.construct_yaml_map(node_map)
    if result is not None:
        raise AssertionError("expected None, got %r" % ( result, ))


# Generated at 2022-06-25 04:29:43.634801
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Setup the arguments
    node = MappingNode()
    deep = False

    # Execute the tested method
    result = ansible_constructor_0.construct_mapping(node, deep)

    # Check the results
    assert result is not None


# Generated at 2022-06-25 04:29:45.602120
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_case_name = "AnsibleConstructor.construct_yaml_map"
    # Get and verify arguments
    test_case_0()



# Generated at 2022-06-25 04:29:54.992031
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Build args
    node = True

    # Call method
    ansible_constructor = AnsibleConstructor()
    ret = ansible_constructor.construct_yaml_unsafe(node)

    # Assert return type
    assert isinstance(ret, wrap_var)

    # Verify other assertions
    assert ret.data == True

    # Build args
    node = list()

    # Call method
    ansible_constructor = AnsibleConstructor()
    ret = ansible_constructor.construct_yaml_unsafe(node)

    # Assert return type
    assert isinstance(ret, wrap_var)

    # Verify other assertions
    assert ret.data == list()

    # Build args
    node = dict()

    # Call method
    ansible_constructor = AnsibleConstructor()
    ret = ansible_

# Generated at 2022-06-25 04:29:59.295812
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    str_0 = 'string'


# Generated at 2022-06-25 04:30:04.305976
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    # Test for method construct_mapping of clas
    # AnsibleConstructor.assertEqual(ansible_constructor_0.construct_mapping(node
    # ), u'unit test')

# Generated at 2022-06-25 04:30:13.220307
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansibleconstructor_obj = AnsibleConstructor()
   
    # When 'ansibleconstructor_obj.vault_secrets' is 'None' and 'node.value' is 'ciphertext', this will raise an
    # ConstructorError exception
    with pytest.raises(ConstructorError, match="found !vault but no vault password provided"):
        ansibleconstructor_obj.construct_vault_encrypted_unicode(Wrapper(value='ciphertext'))
   
    ansibleconstructor_obj.vault_secrets = ['secret']
   
    # When 'node.value' is 'ciphertext', this should return a AnsibleVaultEncryptedUnicode object
    result = ansibleconstructor_obj.construct_vault_encrypted_unicode(Wrapper(value='ciphertext'))
   

# Generated at 2022-06-25 04:30:14.407135
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    # test normal case
    assert ansible_constructor.construct_vault_encrypted_unicode() == 'test'

# Generated at 2022-06-25 04:30:18.508369
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # test_case_0
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map(MappingNode('test_no_args', None, False, [], None))
    ansible_constructor_0.construct_yaml_map(MappingNode('test_args', None, False, [], None))


# Generated at 2022-06-25 04:30:28.290688
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-25 04:30:39.096915
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    #A mock version of node that can be used in the test cases
    class Node:
        def __init__(self):
            self.value = []
            self.start_mark = None
        def id(self):
            return "node"

    class ValueNode:
        def __init__(self, value):
            self.value = value
        def id(self):
            return "valueNode"

    #test 1: check that duplicates are caught and not added
    n = Node()
    n.value = [("key1","value1"),("key1","value2")]
    n.start_mark = 4
    ansible_constructor_1 = AnsibleConstructor()
    mapping = ansible_constructor_1.construct_mapping(n)
    assert mapping["key1"] == "value1"
    assert len

# Generated at 2022-06-25 04:31:21.088737
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from yaml.nodes import ScalarNode

    # Test setup
    # Setup some test data for AnsibleConstructor.construct_yaml_unsafe().
    # This insures that the test can control any AnsibleConstructor-specific
    # data, but still call the AnsibleConstructor method.
    test_data = { 'my_var': 'my_val' }
    node = ScalarNode(tag=u'tag:yaml.org,2002:str', value="my_var")

    # Call AnsibleConstructor.construct_yaml_unsafe() and test the results
    #using test_data input arguments and AnsibleConstructor-specific data
    ac = AnsibleConstructor()
    ret = ac.construct_yaml_unsafe(node=node)

    # If AnsibleConstructor.construct_yaml_unsafe()

# Generated at 2022-06-25 04:31:31.666999
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test file content
    # A test file with a single line containing two !vault tags
    vault_key = 'vault_key'
    vault_pass = 'vault_pass'
    yaml_data = b'!vault |\n          $ANSIBLE_VAULT;1.2;AES256;vault_key\n          ' + to_bytes(base64.b64encode(b'foo')) + b'\n\n' + b'!vault |\n          $ANSIBLE_VAULT;1.2;AES256;another_key\n          ' + to_bytes(base64.b64encode(b'bar')) + b'\n'

    ansible_constructor_1 = AnsibleConstructor(vault_secrets=[vault_key, vault_pass])

    #

# Generated at 2022-06-25 04:31:41.174220
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    value = u'foo'
    node = MappingNode(None, [(ScalarNode(None, value), None)])
    ansible_constructor_1.construct_scalar = MagicMock(return_value=value)
    assert ansible_constructor_1.construct_yaml_str(node) == AnsibleUnicode(value)
    ansible_constructor_1.construct_scalar.assert_called_with(node)
    p = PropertyMock(return_value=None)
    with patch.multiple(node, start_mark=p, end_mark=p):
        value = u'foo'
        node = MappingNode(None, [(ScalarNode(None, value), None)])
        ansible_constructor_1

# Generated at 2022-06-25 04:31:43.435874
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    if hasattr(ansible_constructor, 'construct_yaml_map'):
        assert callable(ansible_constructor.construct_yaml_map)
