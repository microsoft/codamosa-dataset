

# Generated at 2022-06-25 04:21:58.225429
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    string_22 = 'f\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 04:22:07.993113
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # creating a test yaml file
    out = open("test_file", "w")
    out.write("{ \n a: ~, \n b: null, \n c: false \n}")
    out.close()

    # reading in file
    data = open("test_file", "r").read()

    # creating AnsibleConstructor object
    ansible_constructor_1 = AnsibleConstructor("test_file")

    # creating the node value for the mapping node
    node_value = []
    node_value.append((u'a', u'tag:yaml.org,2002:null'))
    node_value.append((u'b', u'tag:yaml.org,2002:null'))

# Generated at 2022-06-25 04:22:18.687198
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    # Constructs a ansible_constructor.AnsibleConstructor using a float
    # parameter and assigns to float_0
    float_0 = 3285.3880200539575
    ansible_constructor_0 = AnsibleConstructor(float_0)

    # Assigns parameter to ansible_constructor_0.yaml_node
    yaml_node = None

    # Invokes method ansible_constructor.AnsibleConstructor.construct_yaml_seq
    # on object ansible_constructor_0 with parameter yaml_node, assigns to
    # ansible_constructor_0
    ansible_constructor_0 = ansible_constructor_0.construct_yaml_seq(yaml_node)



# Generated at 2022-06-25 04:22:20.936243
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    float_1 = 1423.4562
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_vault_encrypted_unicode(float_1)


# Generated at 2022-06-25 04:22:25.906075
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    data = AnsibleSequence()
    yield data
    data.extend(self.construct_sequence(node))
    data.ansible_pos = self._node_position_info(node)


# Generated at 2022-06-25 04:22:32.344046
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    float_0 = 3285.3880200539575
    ansible_constructor_0 = AnsibleConstructor(float_0)
    node_0 = AnsibleMapping()
    data_0 = ansible_constructor_0.construct_yaml_seq(node_0)
    data_0.__class__ = AnsibleSequence
    assert data_0.ansible_pos == (None, 0, 1)
    assert data_0 == []


# Generated at 2022-06-25 04:22:35.417284
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    float_0 = 3285.3880200539575
    ansible_constructor_0 = AnsibleConstructor(float_0)
    data_1 = AnsibleMapping()
    value_0 = ansible_constructor_0.construct_yaml_map(data_1)


# Generated at 2022-06-25 04:22:37.901444
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create test AnsibleConstructor object
    test_AnsibleConstructor = AnsibleConstructor()
    assert(test_AnsibleConstructor != None)
    assert(test_AnsibleConstructor.construct_vault_encrypted_unicode != None)

# Generated at 2022-06-25 04:22:42.684826
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping_node_0 = {}
    ansible_constructor_0 = AnsibleConstructor(mapping_node_0)
    ansible_constructor_0.construct_mapping(mapping_node_0)


# Generated at 2022-06-25 04:22:53.242384
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    float_0 = 0.8356290497253036
    ansible_constructor_0 = AnsibleConstructor(float_0)
    ansible_sequence_0 = AnsibleSequence()
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_1 = AnsibleMapping()
    ansible_sequence_1 = AnsibleSequence()
    ansible_sequence_1.extend([5, 7, 1, 6, 10, 4, 0, 11, 8, 9, 2, 3, ansible_mapping_0])
    ansible_mapping_1.update({3: ansible_sequence_1})
    ansible_mapping_2 = AnsibleMapping()
    ansible_mapping_2.update({2: ansible_mapping_1})
    ansible_sequence

# Generated at 2022-06-25 04:23:01.291574
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = object()
    ansible_constructor_0.construct_yaml_map(node)


# Generated at 2022-06-25 04:23:05.588552
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # args
    file_name = None
    vault_secrets = None
    # AnsibleConstructor instance
    ansible_constructor_0 = AnsibleConstructor(file_name, vault_secrets)


# Generated at 2022-06-25 04:23:11.551876
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_a = AnsibleConstructor()
    node_a = MappingNode(None, True, False)
    ret_a = ansible_constructor_a.construct_yaml_map(node_a)
    ret_b = isinstance(ret_a, AnsibleMapping)
    ret_b = ret_b and isinstance(ret_a, dict)

# Generated at 2022-06-25 04:23:18.066927
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    # Test with ansible_constructor.construct_object(node)
    # Test with "node.id" is None
    # Test with constructor is not None
    # Test with constructor is None
    # Test with constructor is "construct_%s" % constructor
    # Test with constructor is "construct_%s" % constructor
    # Test with constructor is None
    # Test with constructor is None
    ansible_constructor.construct_yaml_unsafe(None)



# Generated at 2022-06-25 04:23:24.347080
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._ansible_file_name = 'test_case_0.yml'
    ansible_constructor_0._vaults = {'default': VaultLib('password', 1)}
    ansible_constructor_0.construct_vault_encrypted_unicode('junk')

# Generated at 2022-06-25 04:23:30.609775
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    node_2 = test_case_0()
    try:
        ansible_constructor_1.construct_yaml_seq(type=node_2)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 04:23:35.057068
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map(MappingNode)



# Generated at 2022-06-25 04:23:40.545951
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_mappings = AnsibleConstructor('ansible_constructor_mappings', ['ansible_constructor_vault'])
    node_0 = AnsibleMapping()
    yield node_0


# Generated at 2022-06-25 04:23:45.236702
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():

    # Parameters
    node = MappingNode([], [], [])

    # Statement
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map(node)
    ansible_constructor_1.construct_mapping(node)
    ansible_constructor_1.construct_mapping(node, False)
    # verify the result


# Generated at 2022-06-25 04:23:50.603731
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor(None)
    class unit_test_yaml_node_0:
        def __init__(self):
            self.start_mark = None
        def __init__(self):
            self.start_mark = None
        start_mark = None
        id = 'str'

    expected_0 = '{0}'
    actual_0 = ansible_constructor_0.construct_yaml_str(unit_test_yaml_node_0())
    assert expected_0 == actual_0
    return


# Generated at 2022-06-25 04:24:06.091962
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_3 = AnsibleConstructor()
    ansible_constructor_4 = AnsibleConstructor()
    ansible_constructor_5 = AnsibleConstructor()
    ansible_constructor_6 = AnsibleConstructor()
    ansible_constructor_7 = AnsibleConstructor()
    ansible_constructor_8 = AnsibleConstructor()
    ansible_constructor_9 = AnsibleConstructor()
    ansible_constructor_10 = AnsibleConstructor()
    ansible_constructor_11 = AnsibleConstructor()
    ansible_constructor_12 = AnsibleConstructor()
    ansible_

# Generated at 2022-06-25 04:24:09.201559
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_nodes_0 = []
    ansible_constructor_0.construct_yaml_seq(yaml_nodes_0)


# Generated at 2022-06-25 04:24:19.782654
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    print("\n# Unit test for construct_mapping() method")
    ansible_constructor = AnsibleConstructor()
    print("\n## Test with a non-mapping node")
    try:
        ansible_constructor.construct_mapping(None)
        raise Exception("Expected raise ConstructorError")
    except ConstructorError as e:
        assert isinstance(e, ConstructorError)
    print("\n## Test with a mapping node")
    print("Test when 'DUPLICATE_YAML_DICT_KEY' is 'warn'")
    C.DUPLICATE_YAML_DICT_KEY = 'warn'
    display.display = lambda *args, **kwargs: None  # No display output
    mapping = ansible_constructor.construct_mapping(None)
    assert isinstance

# Generated at 2022-06-25 04:24:24.368083
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_obj_0 = AnsibleConstructor('C:\\Users\\Ben\\AppData\\Local\\Temp\\ansible-tmp-1506500354.89-240530253155584\\yamldir\\roles\\common\\tasks\\main.yml')
    ansible_constructor_obj_0.construct_yaml_seq()


# Generated at 2022-06-25 04:24:33.749267
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()

    with open("test/constructor_files/yaml_map.yml", "r") as yaml_file:
        yaml_example = yaml_file.read()

    import yaml
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.resolver import Resolver

    parser = Parser('')
    parser.parse(yaml_example)
    node = parser.get_event()
    ansible_constructor_0._ansible_file_name = 'test'
    ansible_constructor_0.construct_yaml_map(node)


# Generated at 2022-06-25 04:24:36.625668
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # FIXME: Test will fail from looking for the wrong path.  Fix it, then uncomment it
    # ansible_constructor = AnsibleConstructor()
    # ansible_constructor.construct_yaml_seq(node)
    raise NotImplementedError


# Generated at 2022-06-25 04:24:47.119936
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_sequence_0 = AnsibleSequence()
    ansible_constructor_0.construct_sequence(ansible_sequence_0)
    ansible_constructor_0.vault_secrets = None
    ansible_constructor_0.vault_secrets = []
    ansible_constructor_0.vault_secrets.append("JhbGciOi.JIUzI1NiJ9.")
    ansible_constructor_0._vaults['default'].secrets = None
    ansible_constructor_0._vaults['default'] = VaultLib(ansible_constructor_0.vault_secrets)
    ansible_constructor_0.construct_yaml_seq(ansible_constructor_0)

#

# Generated at 2022-06-25 04:24:50.834830
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    # TODO: not implemented; should compare some objects
    ansible_constructor.construct_mapping()



# Generated at 2022-06-25 04:24:52.885402
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    list = [1, 2, 3]
    ansible_constructor.construct_yaml_seq(list)


# Generated at 2022-06-25 04:24:54.950895
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    value = ansible_constructor_0.construct_yaml_str(node)

    assert value is None


# Generated at 2022-06-25 04:25:02.995745
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0_construct_yaml_unsafe = AnsibleConstructor()
    node = {}
    result = ansible_constructor_0_construct_yaml_unsafe.construct_yaml_unsafe(node)
    assert result is None


# Generated at 2022-06-25 04:25:09.367178
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node_0 = (u"tag:yaml.org,2002:seq", [("tag:yaml.org,2002:str", "b"), ("tag:yaml.org,2002:str", "c"), ("tag:yaml.org,2002:str", "d")])
    expected_result = AnsibleSequence()
    expected_result.extend(u"b", u"c", u"d")
    expected_result.ansible_pos = None
    actual_result = ansible_constructor.construct_yaml_seq(node_0)
    assert actual_result == expected_result


# Generated at 2022-06-25 04:25:14.387395
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    # Test this method with 1 argument (no deep)
    assert ansible_constructor.construct_mapping(node) == AnsibleMapping()
    # Test this method with 2 arguments (deep)
    assert ansible_constructor.construct_mapping(node, deep=True) == AnsibleMapping()

# Generated at 2022-06-25 04:25:21.570731
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_data = """
    foo: bar
    zap: zazzle
    """
    yaml_data2 = """
    foo: bar
    zap: zazzle
    foo: Hello World
    """
    node1 = AnsibleConstructor.construct_document(yaml_data)
    node2 = AnsibleConstructor.construct_document(yaml_data2)
    ansible_constructor_0.construct_mapping(node1)
    ansible_constructor_0.construct_mapping(node2)

# Generated at 2022-06-25 04:25:27.799764
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    if C.DEFAULT_VAULT_ID:
        v = VaultLib(secrets=[C.DEFAULT_VAULT_PASSWORD])
        find_vault = v.find_vault_id(C.DEFAULT_VAULT_ID)
        vault_password = v.get_vault_password(find_vault)
        if vault_password:
            vault_secrets = [vault_password]
            ansible_constructor_instance = AnsibleConstructor(None,vault_secrets)
        else:
            ansible_constructor_instance = AnsibleConstructor()

        # Test !vault-encrypted object
        yaml_node = '!vault-encrypted $ANSIBLE_VAULT;1.YAML;{}'.format(C.DEFAULT_VAULT_ID)
        encrypted_unicode

# Generated at 2022-06-25 04:25:30.730770
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_unsafe_0 = ansible_constructor_0.construct_yaml_unsafe()
    assert(ansible_unsafe_0 is None)

# Generated at 2022-06-25 04:25:32.995764
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    test_node_1 = {}
    test_deep_2 = {}
    assert ansible_constructor_1.construct_yaml_map(test_node_1, deep=test_deep_2) == '{\n  ansible_pos: (None, None, None)\n}'


# Generated at 2022-06-25 04:25:41.724659
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # Creating an instance of class AnsibleConstructor
    ansible_constructor_0 = AnsibleConstructor()

    # Creating a str object
    str_0 = "some_string"

    # Creating a yaml.nodes.ScalarNode object
    yaml_nodes_ScalarNode_0 = ScalarNode(str_0)

    # Call method construct_vault_encrypted_unicode with arguments (yaml_nodes_ScalarNode_0)
    ansible_constructor_0.construct_vault_encrypted_unicode(yaml_nodes_ScalarNode_0)



# Generated at 2022-06-25 04:25:44.538265
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    try:
        ansible_constructor.construct_vault_encrypted_unicode(None)
    except ConstructorError:
        pass


# Generated at 2022-06-25 04:25:52.290148
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # We don't need to load the vault for this test
    ansible_constructor_1 = AnsibleConstructor(vault_secrets=None)
    # None values for node_0 and deep
    try:
        ansible_constructor_1.construct_yaml_map()
    except TypeError as err:
        test_0_0 = str(err)
    else:
        test_0_0 = None
    assert test_0_0 == "construct_yaml_map() missing 2 required positional arguments: 'node' and 'deep'"


# Generated at 2022-06-25 04:26:10.012293
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create an instance of class AnsibleConstructor
    ansible_constructor_instance_0 = AnsibleConstructor()

    # Call method 'construct_yaml_map' of the created instance
    # and pass an empty list as the argument.
    # This ensures that a instance of class 'AnsibleMapping' is created
    # and passed to the 'yield' statement in the method.
    ansible_constructor_instance_0.construct_yaml_map([])


# Generated at 2022-06-25 04:26:13.175137
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():

    ansible_constructor_0 = AnsibleConstructor()
    # AnsibleConstructor
    # The testing framework needs a positional argument for this method
    # instead of the node keyword argument

# Generated at 2022-06-25 04:26:15.068608
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    obj = AnsibleConstructor()
    output = obj.construct_yaml_map({"k1": "v1"})
    assert(output == None)


# Generated at 2022-06-25 04:26:16.062554
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    test_case_0()


# Generated at 2022-06-25 04:26:17.039262
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    pass


# Generated at 2022-06-25 04:26:23.404852
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.string = "Dummy String"

    ansible_constructor.construct_yaml_str("Dummy String")


# Generated at 2022-06-25 04:26:26.539463
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    yaml_event = ''
    yaml_event = ansible_constructor.construct_yaml_seq(yaml_event)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleConstructor_construct_yaml_seq()

# vim: set expandtab shiftwidth=4 tabstop=4:

# Generated at 2022-06-25 04:26:32.782208
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = ["vault_password"]
    node = "!vault $ANSIBLE_VAULT;1.1;AES256\n6333333333333333333333333333333333333333333333333333333333333333333\n333333333333333333333333333333333333333333333333333333333333333333\n333333333333333333333333333333333333333333333333333333333333\n"
    ansible_constructor_0.construct_vault_encrypted_unicode(node)


# Generated at 2022-06-25 04:26:33.745828
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # TODO Write this unit test
    pass


# Generated at 2022-06-25 04:26:44.586411
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = MappingNode(pairs=
                              {'key_0': {'value': 'value_0', 'tag': 'tag:yaml.org,2002:str'},
                               'key_1': {'value': 'value_1', 'tag': 'tag:yaml.org,2002:str'}},
                              tag=u'tag:yaml.org,2002:map')
    yaml_node_0.start_mark.name = 'name_0'
    yaml_node_0.start_mark.line = 1
    yaml_node_0.start_mark.column = 1

    ansible_constructor_0.construct_yaml_map(yaml_node_0)



# Generated at 2022-06-25 04:27:13.199541
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()

    ansible_constructor_1._vaults['default'] = VaultLib(secrets=['1', '2'])

    dict_map_1 = dict()
    dict_map_1['key_1'] = 'value_1'
    dict_map_1['key_2'] = 'value_2'
    dict_map_1['key_3'] = 'value_3'

    dict_map_2 = dict()
    dict_map_2['key_1'] = 'value_1'
    dict_map_2['key_2'] = 'value_2'

    dict_map_3 = dict()
    dict_map_3['key_3'] = 'value_3'

    dict_map_4 = dict()

# Generated at 2022-06-25 04:27:19.387184
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_obj_0 = AnsibleConstructor(file_name = "None",vault_secrets = None)
    node = AnsibleUnicode("sdfsdfs")
    return_value = ansible_constructor_obj_0.construct_yaml_str(node)
    assert return_value.ansible_pos == "None", "return_value.ansible_pos == 'None'"
    assert return_value == "sdfsdfs", "return_value == 'sdfsdfs'"

# Generated at 2022-06-25 04:27:30.449104
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    my_mock = mock.Mock()
    ansible_constructor = AnsibleConstructor(file_name='my_filename.yaml', vault_secrets=['secret'])
    ansible_constructor._vaults['default'] = my_mock
    ansible_constructor._vaults['default'].secrets = ['secret']
    ansible_constructor._vaults['default'].decrypt.return_value = 'decrypted_secret'
    ansible_constructor.construct_vault_encrypted_unicode(constructor_node)




# Generated at 2022-06-25 04:27:37.194092
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # name of tested method
    method = 'construct_yaml_seq'

    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._ansible_file_name = u'hello'

    # will be called with: node
    node_0 = AnsibleSequence()

    # will be called with: self, node
    ansible_constructor_0.construct_yaml_seq(node_0)
    # assert call with: self, node
    assert True


# Generated at 2022-06-25 04:27:40.933219
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    try:
        result = ansible_constructor_0.construct_yaml_seq(node)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 04:27:47.735592
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ANSIBLE_CONSTRUCTOR = AnsibleConstructor()

    kwargs = {
        'node': 'YAML_NODE'
    }

    subject = 'VaultLib'
    subject.return_value = 'RETURN_VALUE'
    with patch.multiple(
        'ansible.parsing.yaml.constructor.AnsibleConstructor',
        construct_scalar=DEFAULT,
        _vaults=DEFAULT,
        _vaults__default=DEFAULT,
        _vaults__default__secrets=DEFAULT,
        _vaults__default__secrets=DEFAULT,
        VaultLib=DEFAULT,
    ) as required_mocks:
        required_mocks['construct_scalar'].return_value = 'RETURN_VALUE'

# Generated at 2022-06-25 04:27:52.377022
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    yaml_node_0 = AnsibleSequence()
    yaml_node_1 = AnsibleSequence()
    yaml_node_1.extend(yaml_node_0)
    ansible_constructor_1.construct_yaml_seq(yaml_node_1)


# Generated at 2022-06-25 04:27:55.243217
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # AnsibleConstructor.construct_yaml_seq()
    pass


# Generated at 2022-06-25 04:28:03.281735
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = []
    ansible_constructor_0._vaults['default'] = None
    ansible_constructor_0._ansible_file_name = None

    # Unit test for case 0:\n# Make sure we properly handle missing vault secrets.
    # Should throw an exception when vault secrets are not provided.
    node = None
    exc = None
    try:
        ansible_constructor_0.construct_vault_encrypted_unicode(node)
    except Exception as e:
        exc = e
    assert isinstance(exc, ConstructorError)

# Generated at 2022-06-25 04:28:05.940801
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = test_case_0()

    assert ansible_constructor_0.construct_yaml_map(yaml_node_0) == {}


# Generated at 2022-06-25 04:28:50.215319
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # AnsibleConstructor.construct_vault_encrypted_unicode()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 04:28:57.469426
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()

    # Test with empty input
    node_2 = {}
    ansible_constructor_1.construct_mapping(node_2)
    # Test with dict input
    node_3 = {1:2, 3:4}
    ansible_constructor_1.construct_mapping(node_3)
    # Test with AnsibleMapping input
    node_4 = AnsibleMapping(data={'key1': 'value1', 'key2': 2})
    ansible_constructor_1.construct_mapping(node_4)



# Generated at 2022-06-25 04:29:04.383158
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    value = None

    # Testing if exception is raised
    with pytest.raises(Exception):
        ansible_constructor_0.construct_mapping(value, deep=False)

    ansible_mapping_0.ansible_pos = (None, None, None)


# Generated at 2022-06-25 04:29:06.447131
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    node = object()
    ansible_constructor.construct_yaml_unsafe(node)


# Generated at 2022-06-25 04:29:12.648458
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert not hasattr(ansible_constructor, 'vault_secrets')
    assert hasattr(ansible_constructor, '_vaults')
    assert 'default' in ansible_constructor._vaults.keys()
    assert len(ansible_constructor._vaults['default'].secrets) == 0

# Generated at 2022-06-25 04:29:17.412844
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0_0 = MappingNode(u'tag:yaml.org,2002:map',
            [],
            {},
            None,
            None)
    ansible_mapping_0 = ansible_constructor_0.construct_yaml_map(yaml_node_0_0)
    assert ansible_mapping_0 == {}


# Generated at 2022-06-25 04:29:24.016946
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    try:
        ansible_constructor_1 = AnsibleConstructor()
    except Exception as e:
        display.error("Exception at line {}: {}".format(sys.exc_info()[-1].tb_lineno, e))
    try:
        test_node_0 = yaml.parser.Parser()
        ansible_constructor_1.construct_yaml_seq(test_node_0)
    except Exception as e:
        display.error("Exception at line {}: {}".format(sys.exc_info()[-1].tb_lineno, e))


# Generated at 2022-06-25 04:29:25.443635
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    test_case_0()

# Generated at 2022-06-25 04:29:31.448112
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    str_0 = 'abc\r'
    node_0 = str_0
    ret = ansible_constructor_0.construct_yaml_str(node_0)
    assert ret == to_native(u'abc\r'), 'returned value of type: %s' % type(ret)


# Generated at 2022-06-25 04:29:40.891158
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor(file_name=None, vault_secrets=None)
    my_safe_constructor_0 = SafeConstructor()
    yaml_node_0 = MappingNode('node', 'node', [('yaml_node_1', my_safe_constructor_0)], None, None)
    ansible_constructor_0.construct_vault_encrypted_unicode(yaml_node_0)
    my_safe_constructor_1 = SafeConstructor()
    yaml_node_1 = MappingNode('node', 'node', [('yaml_node_1', my_safe_constructor_1)], None, None)
    ansible_constructor_0.construct_vault_encrypted_unicode(yaml_node_1)


# Generated at 2022-06-25 04:31:06.935382
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    # Run test_case_1
    ansible_constructor_1 = AnsibleConstructor()

    # Creting the node to be passed as param to the function
    node = MappingNode(u'tag:yaml.org,2002:map', [[1, 2], [3, 4]])

    # Execution of the method
    ret_value = ansible_constructor_1.construct_mapping(node)

    # Verifying the absence of an exception in the method
    assert(ret_value is not None)

    # Run test_case_2
    ansible_constructor_2 = AnsibleConstructor()

    # Creting the node to be passed as param to the function
    node = None

    # Execution of the method
    ret_value = ansible_constructor_2.construct_mapping(node)

    # Verifying

# Generated at 2022-06-25 04:31:11.747978
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    arg = dict(
        tag=u'!vault',
    )
    node_0 = MappingNode(**arg)
    ret = ansible_constructor_0.construct_vault_encrypted_unicode(node_0)


# Generated at 2022-06-25 04:31:14.333756
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    assert isinstance(ansible_constructor_1, AnsibleConstructor)


# Generated at 2022-06-25 04:31:15.144644
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:31:18.000570
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map(MappingNode)



# Generated at 2022-06-25 04:31:19.471829
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_mapping(node=None,deep=False) is not None

# Generated at 2022-06-25 04:31:24.050971
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create a new empty object of the class
    ansible_constructor = AnsibleConstructor()
    # TODO: implement:
    # ansible_constructor.construct_vault_encrypted_unicode()


# Generated at 2022-06-25 04:31:25.765696
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = None
# Input parameters:
#   node
# Expected return value:
    return_value_construct_yaml_seq = None


# Generated at 2022-06-25 04:31:28.295757
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_vault_encrypted_unicode(None) is None


# Generated at 2022-06-25 04:31:37.585906
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()   # create object
    assert isinstance(ansible_constructor_0, AnsibleConstructor)

    # Test empty string
    node_types_0 = (u'tag:yaml.org,2002:str')  # object type for 'node'
    node_0 = node_types_0()   # create object
    assert isinstance(node_0, node_types_0)
    value_0 = ansible_constructor_0.construct_yaml_str(node_0)
    assert value_0 == u''

    # Test non-empty string
    node_types_1 = (u'tag:yaml.org,2002:str')  # object type for 'node'
    node_1 = node_types_1(u'abc')   # create object
   