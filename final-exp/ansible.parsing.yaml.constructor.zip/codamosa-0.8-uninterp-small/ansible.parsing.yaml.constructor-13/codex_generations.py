

# Generated at 2022-06-25 04:21:46.269540
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_case_0()


# Generated at 2022-06-25 04:21:53.512612
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = [
        'ANSIBLE_VAULT_Secret_1',
        'ANSIBLE_VAULT_Secret_2',
        'ANSIBLE_VAULT_Secret_3',
        'ANSIBLE_VAULT_Secret_4',
    ]
    ansible_constructor_0._vaults['default'] = VaultLib(secrets=ansible_constructor_0.vault_secrets)


# Generated at 2022-06-25 04:21:56.809495
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_str = '''
key: value
'''
    node = AnsibleConstructor.construct_yaml(yaml_str)
    print(node)


# Generated at 2022-06-25 04:22:05.216229
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    # vault secrets to be passed in
    secrets_0 = []
    secrets_0.append(b'$ANSIBLE_VAULT;1.1;AES256\n63643335643439336433336339643635646235633831653138336432623932393962383961356138\n61333339166435656639653630363537656566316430383438366337643730376536336133313237\n6633343964316533376562326564323630333937653537663461\n')

# Generated at 2022-06-25 04:22:12.555824
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from yaml.nodes import SequenceNode

    yaml_data = '[foo, bar, baz]'
    node = construct_yaml(yaml_data)

    ansible_constructor = AnsibleConstructor()
    result = ansible_constructor.construct_yaml_seq(node)

    assert isinstance(result, AnsibleSequence)
    assert node.id == 'tag:yaml.org,2002:seq'
    assert node.value[0].value == 'foo'
    assert node.value[1].value == 'bar'
    assert node.value[2].value == 'baz'
    assert isinstance(node, SequenceNode)
    assert result.get(0) == 'foo'
    assert result.get(1) == 'bar'
    assert result.get(2) == 'baz'




# Generated at 2022-06-25 04:22:19.343158
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode(tag=u'tag:yaml.org,2002:python/dict', value=[], start_mark=None, end_mark=None)
    expected = AnsibleSequence()
    actual = ansible_constructor.construct_yaml_seq(node)
    assert expected == actual


# Generated at 2022-06-25 04:22:30.267439
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-25 04:22:35.373441
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(node, deep=False)


# Generated at 2022-06-25 04:22:39.214224
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    try:
        ansible_constructor = AnsibleConstructor()
    except Exception:
        assert False, "Could not instantiate AnsibleConstructor"

    try:
        ansible_constructor.construct_yaml_map()
    except NotImplementedError:
        pass



# Generated at 2022-06-25 04:22:44.964899
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    print("Test construct mapping")
    print(ansible_constructor.construct_mapping(None))
    print("Test case 1")
    a = MappingNode(None, None)
    print(ansible_constructor.construct_mapping(a))
    print("Test case 2")

# Generated at 2022-06-25 04:22:56.845841
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test for no ansible_pos attribute
    ansible_constructor_1 = AnsibleConstructor()
    mapping_node_1 = MappingNode()
    mapping_node_1.value = set()
    mapping = ansible_constructor_1.construct_mapping(mapping_node_1)
    assert (mapping.ansible_pos == (None, None, None))


# Generated at 2022-06-25 04:22:59.791121
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor(None)
    node = None
    ansible_constructor_0.construct_yaml_seq(node)

# Generated at 2022-06-25 04:23:10.317144
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Basic example
    ansible_constructor_1 = AnsibleConstructor()

# Generated at 2022-06-25 04:23:13.195936
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    # NOTE: Due to the way the pyyaml libs are implemented, we
    #       cannot actually test construct_mapping.  It makes a
    #       call to self.construct_object, which is implemented
    #       in the base class SafeConstructor and cannot be
    #       overriden here in the AnsibleConstructor.
    pass

# Generated at 2022-06-25 04:23:16.253485
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str("null")


# Generated at 2022-06-25 04:23:21.984408
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_unsafe(object)
    # TODO: verify results


# Generated at 2022-06-25 04:23:25.999999
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    # ...
    node_0 = ...
    # ...
    data_0 = ansible_constructor_0.construct_yaml_seq(node_0)
    data_0.next()
    # ...
    data_0.send(AnsibleSequence())
    # ...


# Generated at 2022-06-25 04:23:33.169820
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    # Check num of args == 2
    # This fails if we call it with no args, since that results in two
    # positional args of None.  The second one is the one that 'deep'
    # would get assigned, and it defaults to False
    assert ansible_constructor.construct_mapping(None) is not None

    # Check num of args == 3
    # This checks that 'deep' can be overridden to True
    assert ansible_constructor.construct_mapping(None, deep=True) is not None

# Generated at 2022-06-25 04:23:36.098448
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    yaml_mapping_node = None
    deep = False
    ansible_constructor.construct_mapping(yaml_mapping_node, deep)


# Generated at 2022-06-25 04:23:37.274364
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    assert AnsibleConstructor.construct_yaml_map() == None


# Generated at 2022-06-25 04:23:44.822893
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_unsafe(None) is None


# Generated at 2022-06-25 04:23:46.065752
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:23:55.180273
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    mapping_dict = {'key1': 'value1', 'key2': 'value2'}
    constructor = AnsibleConstructor()

    # Test case
    ansible_constructor_mapping = constructor.construct_mapping(mapping_dict)
    assert(ansible_constructor_mapping.get() == mapping_dict)

# Generated at 2022-06-25 04:24:04.502449
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # yaml string to parse
    yaml = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          356234613864666532636539663762643233333361316134313961346265326334613533313566\n          363963336333626266623363363061653937376530366137356338633939343239633433666134\n          366332626332323661393131303362346531333537383433393730623334373033636631663435\n          62316530\n          "
    # init constructor
    ctor = AnsibleConstructor()
    # create a node and trigger the vault function to test
    result = ctor.construct_vault_encrypted_unicode

# Generated at 2022-06-25 04:24:10.018748
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_input =  """{test_tagged_map: value}"""
    yaml_data =  """{test_tagged_map: value}\n"""
    ansible_constructor_1 = AnsibleConstructor()
    yaml_object = yaml.load(yaml_data, Loader = AnsibleLoader)
    assert yaml_object == {u'test_tagged_map': u'value'}



# Generated at 2022-06-25 04:24:13.677344
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()

    # Call method construct_yaml_str with argument node=node_0
    x_0 = ansible_constructor_0.construct_yaml_str(node=node_0)

    # Check that x_0 equals 'foo'
    assert x_0 == 'foo'



# Generated at 2022-06-25 04:24:19.572915
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

    # testing with yaml file in yaml-directory with duplicate keys
    file_name = 'duplicate-keys-test.yml'
    yaml_loader_0 = AnsibleLoader(file_name, ansible_constructor_0)
    config = yaml_loader_0.get_single_data()

# Generated at 2022-06-25 04:24:23.520442
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    # simple test
    node_dict = {}
    node = type("", (object,), node_dict)
    ansible_constructor.construct_yaml_map(node)


# Generated at 2022-06-25 04:24:26.748389
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    value = ansible_constructor.construct_yaml_map()
    assert True


# Generated at 2022-06-25 04:24:27.901538
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = AnsibleUnicode()


# Generated at 2022-06-25 04:24:33.217133
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:24:37.884003
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    error = False
    kwargs = {"a": "b"}
    test_node = construct_yaml_node(kwargs)
    ansible_constructor_0 = AnsibleConstructor()
    ret = ansible_constructor_0.construct_mapping(test_node)
    assert ret == {"a": "b"}


# Generated at 2022-06-25 04:24:45.334131
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    mapping_node_0 = MappingNode(1, 2, '/dummy', 'dummy', 57)
    value_0 = ansible_constructor_0.construct_mapping(mapping_node_0)
    data_0 = AnsibleMapping()
    data_0.update(value_0)
    data_0.ansible_pos = (None, None, None)
    ansible_constructor_0.construct_yaml_map(mapping_node_0)


# Generated at 2022-06-25 04:24:47.310546
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # SafeConstructor.construct_yaml_map() has no tests yet.
    pass


# Generated at 2022-06-25 04:24:51.728392
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 04:24:54.758585
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode(None, None, True, None, None)
    data_0 = ansible_constructor_0.construct_yaml_map(node_0)
    #assert data_0.__class__.__name__ == 'dict'
    assert data_0.ansible_pos == (None, None, None)


# Generated at 2022-06-25 04:24:58.881314
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
  ansible_constructor = AnsibleConstructor()
  ansible_constructor_construct_yaml_map = ansible_constructor.construct_yaml_map(None)
  assert True, "TODO"

# Generated at 2022-06-25 04:25:01.425537
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    test_node_0 = None
    assert ansible_constructor_0.construct_yaml_map(test_node_0) == None


# Generated at 2022-06-25 04:25:05.964574
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map()


# Generated at 2022-06-25 04:25:07.594783
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:25:14.643720
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor(file_name=None, vault_secrets=None)
    node = MappingNode()
    val = ansible_constructor.construct_yaml_map(node)
    assert val is None

# Generated at 2022-06-25 04:25:18.399217
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    vault_encrypted_unicode = ansible_constructor.construct_vault_encrypted_unicode(MappingNode(None, None))
    print(vault_encrypted_unicode)


# Generated at 2022-06-25 04:25:29.575032
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Create a test case
    ansible_constructor_0 = AnsibleConstructor()
    # Create the argument parser
    argparse0 = argparse.ArgumentParser()
    # Assign values to the parameters of the argparse
    argparse0.add_argument("option")
    argparse0.add_argument("-k", "--value")
    # Call the parse_args method for the argparse
    parsed_args0 = argparse0.parse_args(sys.argv[1:])
    if parsed_args0.option == "AnsibleConstructor_construct_yaml_unsafe":
        ansible_constructor_0 = AnsibleConstructor()
    # Create an instance of the get_pyclass method
    get_pyclass0 = yaml.parser.Parser.get_pyclass()
    # Create a pyclass

# Generated at 2022-06-25 04:25:33.494328
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()

    class MockConstructor():
        def __init__(self):
            self.id = 'object'
            self.construct_object = Mock()

    ansible_constructor.construct_yaml_unsafe(MockConstructor())
    ansible_constructor.construct_yaml_unsafe(1)

# Generated at 2022-06-25 04:25:38.379930
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()

    # Test a variety of string types
    construct = ansible_constructor_0.construct_yaml_unsafe(None)

    assert isinstance(construct, str) or isinstance(construct, unicode)


# Generated at 2022-06-25 04:25:45.249151
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    temp_vault_secrets = None
    ansible_constructor_1 = AnsibleConstructor(vault_secrets=temp_vault_secrets)

# Generated at 2022-06-25 04:25:51.101829
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Test case where method construct_vault_encrypted_unicode is called with node = None
    ansible_constructor_1 = AnsibleConstructor()
    with pytest.raises(ConstructorError) as error_info:
        ansible_constructor_1.construct_vault_encrypted_unicode(node=None)
    assert error_info.match("expected a mapping node, but found None")



# Generated at 2022-06-25 04:26:04.368463
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_map_0 = AnsibleMapping()
    assert isinstance(ansible_map_0, dict)
    ansible_map_0['key_0'] = 'value_0'
    ansible_map_0['key_1'] = 'value_1'
    assert isinstance(ansible_map_0['key_1'], str)
    ansible_map_0['key_0'] = 'value_0'
    ansible_map_0['key_1'] = 'value_1'
    assert isinstance(ansible_map_0['key_1'], str)
    ansible_map_0['key_0'] = 'value_0'
    ansible_map_0['key_1'] = 'value_1'
   

# Generated at 2022-06-25 04:26:14.552098
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor(
        file_name='/home/dave/ansible/hacking/test/units/lib/ansible/modules/network_testing/ceos/test_ceos_config.py',
        vault_secrets=[])
    ansible_constructor_1.yaml_path_resolvers = [lambda s: s]

# Generated at 2022-06-25 04:26:15.575635
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:26:27.923189
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map()


# Generated at 2022-06-25 04:26:30.796281
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    seq_node = "\n - sequence\n - value\n"
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_seq(seq_node)


# Generated at 2022-06-25 04:26:36.674288
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_yaml_seq() == None


# Generated at 2022-06-25 04:26:40.611045
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    test_node_0 = Node(tag, value, start_mark, end_mark, style)
    assert ansible_constructor_0.construct_yaml_str(test_node_0) == 'test string'


# Generated at 2022-06-25 04:26:44.379293
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    s_node = object()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_scalar=lambda x: ''
    ansible_constructor_1.construct_vault_encrypted_unicode(s_node)


# Generated at 2022-06-25 04:26:49.130586
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

    # Case 0:
    # No args.
    # Returned value should be a dict
    ansible_constructor_0.construct_mapping()


# Generated at 2022-06-25 04:26:53.760979
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = AnsibleMapping()
    my_yaml_map = ansible_constructor_0.construct_yaml_map(node)
    output_0 = my_yaml_map.__next__()
    assert output_0 == {}


# Generated at 2022-06-25 04:26:54.890246
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()



# Generated at 2022-06-25 04:27:01.925298
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = MappingNode()
    node.value = [('a', 'test_value_1'), ('b', 'test_value_2')]
    ansible_constructor = AnsibleConstructor()
    value = ansible_constructor.construct_mapping(node)
    assert value == {'a': 'test_value_1', 'b': 'test_value_2'}


# Generated at 2022-06-25 04:27:03.136487
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:27:24.257447
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    seq_node = yaml.nodes.SequenceNode('tag:yaml.org,2002:seq', [],
                                       start_mark=None, end_mark=None)
    seq_node.end_mark = None
    seq_node.start_mark = None
    ansible_constructor_0.construct_yaml_seq(seq_node)

# Generated at 2022-06-25 04:27:29.898432
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    # ansible_constructor_0 = AnsibleConstructor(u"foo")

    ansible_constructor_0 = AnsibleConstructor(None)

    # __main__.AnsibleUnicode object at 0x7f5aef9e9ac0
    ansible_constructor_0.construct_yaml_str(u"foo")


# Generated at 2022-06-25 04:27:33.694149
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    node = None
    # Construct AnsibleSequence object
    ansible_sequence = ansible_constructor.construct_yaml_seq(node)
    print(ansible_sequence)


# Generated at 2022-06-25 04:27:39.601530
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor_construct_yaml_map_node = MappingNode(None, None, None, None)
    assert isinstance(ansible_constructor.construct_yaml_map(ansible_constructor_construct_yaml_map_node), ansible_constructor.construct_yaml_map(ansible_constructor_construct_yaml_map_node))


# Generated at 2022-06-25 04:27:46.697495
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = ansible_constructor_0.construct_yaml_map()


# Generated at 2022-06-25 04:27:50.912755
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    ansible_constructor.construct_mapping()

    assert True is True # implemented as pass


# Generated at 2022-06-25 04:27:56.470348
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    doc = AnsibleConstructor()
    ansible_constructor_construct_yaml_map = doc.construct_yaml_map
    assert ansible_constructor_construct_yaml_map is not None


# Generated at 2022-06-25 04:28:04.308598
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
#    node = instance of yaml.nodes.Node
    with pytest.raises(NotImplementedError):
        ansible_constructor.construct_yaml_seq(node)



# Generated at 2022-06-25 04:28:10.119356
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from ansible.parsing.yaml.loader import AnsibleLoader
    ansible_constructor_1 = AnsibleConstructor()
    string_0 = '''---
- {description: 'test', name: 'test'}
- {description: 'test2', name: 'test2'}
'''
    string_0_packed = '(' + string_0 + ')'
    string_0_compressed = '\x01\x00'
    string_0_unpacked = '+' + string_0
    string_0_descompressed = '{' + string_0 + '}'
    string_0_escaped = '><||' + string_0 + '||><'
    string_0_packed_escaped = '><||(' + string_0 + ')||><'
    string_0_comp

# Generated at 2022-06-25 04:28:17.519309
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.composer import Composer
    from yaml.parser import Parser
    from yaml.scanner import Scanner

    yaml_str = '''\
        - key: {name: 'joe', age: 30}
        - key: {name: 'jane', age: None}
        - key: {name: 'jason', age: 'unknown'}
        '''
    yaml_str_bytes = to_bytes(yaml_str)

    # Create a scanner and a parser and a composer.
    scanner = Scanner(yaml_str_bytes)
    parser = Parser(scanner)
    composer = Composer(parser)
    # Construct a sequence of three mapping nodes.
    node_0 = composer.compose_node(None, None)
    value_1 = ansible_constructor

# Generated at 2022-06-25 04:28:34.397516
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:28:35.610904
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    # No exception is expected
    pass

# Generated at 2022-06-25 04:28:46.363293
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    ansible_constructor_1 = AnsibleConstructor()

    ansible_constructor_1.vault_secrets = ['secret']

    # First test case
    # vault_secrets = ['secret']
    # node = '$ANSIBLE_VAULT;1.1;AES256;ansible'
    #      643138306236656635306566346537393530356665326265363032663039333062333438346631343936'
    #      313231316334336232333466'

    node = '$ANSIBLE_VAULT;1.1;AES256;ansible6431383'

    ret = ansible_constructor_1.construct_vault_encrypted_unicode(node)

    assert ret == node


# Generated at 2022-06-25 04:28:53.721276
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test if mapping is constructed properly
    ansible_constructor_0 = AnsibleConstructor()
    mapping_node = MappingNode(
        "tag:yaml.org,2002:map",
        [
            mapping_node
        ]
    )

    mapping_node_0 = MappingNode(
        "tag:yaml.org,2002:map",
        [
        ]
    )

    assert ansible_constructor_0.construct_mapping(mapping_node) == mapping_node_0



# Generated at 2022-06-25 04:29:04.938112
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from yaml.nodes import ScalarNode

    ansible_constructor = AnsibleConstructor()
    ansible_constructor.vault_secrets = ['secret']
    ansible_constructor._vaults['default'] = VaultLib(secrets=ansible_constructor.vault_secrets)


# Generated at 2022-06-25 04:29:11.592824
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    class testMappingNode:
        def __init__(self,value):
            self.value = value
        def __repr__(self):
            return repr(self.value)
    class test_node:
        def __init__(self,id,value,start_mark):
            self.id = id
            self.value = value
            self.start_mark = start_mark
        def __repr__(self):
            return repr(self.value)
    class test_key_node:
        def __init__(self,value):
            self.value = value
        def __repr__(self):
            return repr(self.value)
    class test_value_node:
        def __init__(self,value):
            self.value = value


# Generated at 2022-06-25 04:29:19.258553
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-25 04:29:25.456828
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    raw_data = {
      "debug_level": 3,
      "auth_type": "password",
      "remote_host": "my_host_name",
      "remote_user": "my_user_name",
      "remote_password": "my_password",
      "use_tls": False,
      "default_domain": "my_default_domain",
      "additional_domains": [
        {
          "domain": "first_domain",
          "username": "first_user",
          "password": "first_pass"
        },
        {
          "domain": "second_domain",
          "username": "second_user",
          "password": "second_pass"
        }
      ]
    }
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-25 04:29:30.455348
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    yamlNode = yaml.MappingNode('tag:yaml.org,2002:map', [], [], None, None, None, False, False)
    ansible_constructor.construct_mapping(yamlNode)

# Generated at 2022-06-25 04:29:32.313591
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor.construct_mapping() == None

# Generated at 2022-06-25 04:30:05.672580
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    value = ansible_constructor.construct_yaml_seq('node')
    assert (isinstance(value, iter))


# Generated at 2022-06-25 04:30:07.383071
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    yaml_str = "[1, 2, 'str_data']"
    ansible_constructor = AnsibleConstructor()
    ansible_constructor_construct_yaml_seq_result = ansible_constructor.construct_yaml_seq(yaml_str)


# Generated at 2022-06-25 04:30:09.660580
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    my_event = {}

    ansible_constructor = AnsibleConstructor()

    ansible_constructor.construct_yaml_str(my_event)


# Generated at 2022-06-25 04:30:19.700481
# Unit test for method construct_yaml_map of class AnsibleConstructor

# Generated at 2022-06-25 04:30:22.084463
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ans_cont = AnsibleConstructor()
    ans_seq = ans_cont.construct_yaml_seq()
    assert ans_seq is not None


# Generated at 2022-06-25 04:30:25.783628
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq()


# Generated at 2022-06-25 04:30:30.425525
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.vault_secrets = ['testing']
    b_ciphertext_data = to_bytes('string')
    node = type(node)()
    AnsibleVaultEncryptedUnicode = ansible_constructor_0.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-25 04:30:33.183476
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_vault_encrypted_unicode()

# Generated at 2022-06-25 04:30:35.340760
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0.construct_vault_encrypted_unicode(__name__),
        object)

# Generated at 2022-06-25 04:30:38.675328
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe('foo')
