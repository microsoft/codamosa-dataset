

# Generated at 2022-06-25 04:21:55.016221
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # TODO: Ensure that this matches the expected format
    vault_secrets = VaultLib(secrets=[b'MY VAULT PASSWORD', b'MY SECONDARY VAULT PASSWORD'])
    ansible_constructor = AnsibleConstructor(vault_secrets=vault_secrets)
    node = 'value'
    result = ansible_constructor.construct_vault_encrypted_unicode(node)
    assert result == 'value'


# Generated at 2022-06-25 04:21:57.887768
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    seq = AnsibleSequence([1, 2, 3, 4, 5])
    ansible_constructor_0.construct_yaml_seq(seq)

# Generated at 2022-06-25 04:21:59.250808
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    test_case = AnsibleConstructor()
    test_case.construct_yaml_str()

# Generated at 2022-06-25 04:22:07.756993
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    # Create mock
    mock = MappingNode(start_mark=None, end_mark=None, value=[])

    # Create bogus node
    bogus_node = SafeConstructor.construct_object(mock)

    # Create old dictionary
    old_dictionary = {}
    for item in bogus_node:
        old_dictionary[item] = bogus_node[item]

    # Create new dictionary
    new_dictionary = {}
    for item in bogus_node:
        new_dictionary[item] = bogus_node[item]

    # Create expected dictionary
    expected_dictionary = {}
    for item in bogus_node:
        expected_dictionary[item] = bogus_node[item]

    # Create ansible constructor object

# Generated at 2022-06-25 04:22:14.154483
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Verify that AnsibleConstructor.construct_yaml_seq() returns a generator
    ansible_constructor_0 = AnsibleConstructor()
    arg_0 = None
    value = ansible_constructor_0.construct_yaml_seq(arg_0)
    assert(type(value) == types.GeneratorType)


# Generated at 2022-06-25 04:22:15.001731
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    test_case_0()


# Generated at 2022-06-25 04:22:18.247606
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    try:
        ansible_constructor_0 = AnsibleConstructor()
        ansible_constructor_0.construct_yaml_map(node=None)
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-25 04:22:20.664378
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_mapping(MappingNode)


# Generated at 2022-06-25 04:22:26.406189
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    print('construct_vault_encrypted_unicode')
    ansible_constructor_1 = AnsibleConstructor()
    # TODO: Fix tests once the !vault type is implemented
    # ansible_constructor_1.construct_vault_encrypted_unicode(node_0)


# Generated at 2022-06-25 04:22:30.418445
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    vault = VaultLib
    if hasattr(vault, 'encode'):
        ansible_constructor_0.construct_vault_encrypted_unicode(vault)


# Generated at 2022-06-25 04:22:48.837717
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password_file = '/home/student/.vault_pass.txt'
    vault_pw = 'test'
    with open(vault_password_file,'w') as fd:
        fd.write(vault_pw)

    # ansible_constructor_0 is of type AnsibleConstructor
    ansible_constructor_0 = AnsibleConstructor(vault_secrets=[vault_password_file])

    # yaml_loader_0 is of type SafeLoader
    yaml_loader_0 = yaml.SafeLoader()
    yaml_loader_0.add_constructor(u'!vault', ansible_constructor_0.construct_vault_encrypted_unicode)

# Generated at 2022-06-25 04:22:57.078742
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()

# Generated at 2022-06-25 04:23:05.481796
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_5 = AnsibleConstructor()
    import yaml
    with open('fixtures/ansible/vault-encrypted-file.yml', 'r') as fp:
        yaml_dict = yaml.load(fp, Loader=AnsibleConstructor)

# Generated at 2022-06-25 04:23:11.474117
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    # Make sure that the constructor is initialized with unicode
    expected = u'abc'
    data = u'abc'
    ansible_constructor_0.construct_yaml_str(data)
    assert ansible_constructor_0.construct_yaml_str(data) == expected


# Generated at 2022-06-25 04:23:15.560994
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_vault_encrypted_unicode()


# Generated at 2022-06-25 04:23:20.133533
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    node = AnsibleUnicode()


# Generated at 2022-06-25 04:23:27.607676
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor._ansible_file_name = "test"
    class map:
        pass
    node=map()
    node.id="object"
    node.start_mark=map()
    node.start_mark.column=0
    node.start_mark.line=0
    node.start_mark.name="test"
    ansible_constructor.construct_object=lambda x: "testnode"
    ansible_constructor.construct_unsafe=ansible_constructor.construct_yaml_unsafe
    assert ansible_constructor.construct_unsafe(node) == wrap_var("testnode")

# Generated at 2022-06-25 04:23:33.977090
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_case_construct_mapping = AnsibleConstructor()

# Generated at 2022-06-25 04:23:43.365933
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Just testing that a class constructed in this module can call a method
    # of this class, as it needs to be accessible via the tag constructor
    ansible_constructor_1 = AnsibleConstructor()
    wrap_var(ansible_constructor_1)
    # A YAML object
    obj = {"value": "obj"}
    # Get a reference to the method
    method = ansible_constructor_1.construct_yaml_unsafe
    # Invoke the method and test the result
    obj2 = method(obj)
    assert wrap_var(obj) == obj2

# Generated at 2022-06-25 04:23:46.149341
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    ansible_mapping_node = MappingNode()



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 04:23:59.522373
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    result = AnsibleConstructor().construct_mapping()
    assert result == {}
    result = AnsibleConstructor().construct_mapping({'a':2,'b':[3,4]})
    assert result == {'a': 2, 'b': [3, 4]}


# Generated at 2022-06-25 04:24:10.156899
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.safe_constructor = False
    value = ansible_constructor.construct_yaml_str(None)
    assert value is None
    assert value == AnsibleUnicode('value')
    value = ansible_constructor.construct_yaml_str('value')
    assert value is None
    assert value == AnsibleUnicode('value')
    value = ansible_constructor.construct_yaml_str(u'value')
    assert value is None
    assert value == AnsibleUnicode('value')
    value = ansible_constructor.construct_yaml_str(u'\u00c3\u00bc')
    assert value is None
    assert value == AnsibleUnicode('\u00c3\u00bc')


# Generated at 2022-06-25 04:24:10.969972
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    pass


# Generated at 2022-06-25 04:24:16.186264
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor("file_name", "vault_secrets")
    ansible_constructor_0.construct_scalar = mock.MagicMock(return_value="value")
    assert ansible_constructor_0.construct_yaml_str("node") == "string"
    assert ansible_constructor_0.construct_scalar.mock_calls == [mock.call("node")]


# Generated at 2022-06-25 04:24:21.230741
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    mock_node = MappingNode(
        tag=u'tag:yaml.org,2002:map',
        value=[
        ],
        start_mark=None,
        end_mark=None,
        flow_style=None
    )
    ansible_constructor_2 = AnsibleConstructor()

    # Call method
    # The called method will set attribute _data of object ansible_constructor_2
    ansible_constructor_2.construct_yaml_map(mock_node)

    # Test attribute _data
    assert ansible_constructor_2._data == {}, 'Attribute _data should be {}'


# Generated at 2022-06-25 04:24:32.362177
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    # AnsibleConstructor.construct_mapping()

    # AnsibleConstructor.construct_mapping(node, deep=False)

    # AnsibleConstructor.construct_mapping(node=None, deep=True)

    # AnsibleConstructor.construct_mapping(node=None, deep=False)

    # AnsibleConstructor.construct_mapping(node=<yaml.nodes.MappingNode object>, deep=True)

    # AnsibleConstructor.construct_mapping(node=<yaml.nodes.MappingNode object>, deep=False)

    # AnsibleConstructor.construct_mapping(node=<yaml.nodes.MappingNode object>, deep=False)

    # AnsibleConstructor.construct_mapping(node=<yaml.n

# Generated at 2022-06-25 04:24:35.955950
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    t_AnsibleConstructor = AnsibleConstructor()
    try:
        t_AnsibleConstructor.construct_yaml_map(t_AnsibleConstructor)
    except:
        print("AnsibleConstructor_construct_yaml_map FAIL")


# Generated at 2022-06-25 04:24:37.212383
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:24:42.470332
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    self = wrap_var(ansible_constructor)
    node = wrap_var(None)
    value = ansible_constructor.construct_vault_encrypted_unicode(node)

# Generated at 2022-06-25 04:24:53.493094
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    vault_secrets = [b'foo']
    ansible_constructor.vault_secrets = vault_secrets
    ansible_constructor._vaults['default'] = VaultLib(secrets=ansible_constructor.vault_secrets)
    assert(True == isinstance(ansible_constructor._vaults['default'], VaultLib))
    # We need to create a node object for the input to this function

# Generated at 2022-06-25 04:25:07.062171
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    node = None
    value = {u'ip': u'10.1.1.1', u'hostnames': [u'hostname1', u'hostname2']}
    value_1 = wrap_var(value)
    assert value_1 == ansible_constructor_1.construct_yaml_unsafe(node)

# Generated at 2022-06-25 04:25:09.887540
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Case:
    #   Call without arguments
    # Success case
    #
    #   Verify that the method returns the correct value
    #   when called with valid parameters.
    #

    ansible_constructor = AnsibleConstructor()

    print("Test Success:  test_case_0")


# Generated at 2022-06-25 04:25:12.209247
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    mapping = ansible_constructor.construct_mapping()
    assert mapping == AnsibleMapping()

# Generated at 2022-06-25 04:25:17.161540
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    data = AnsibleMapping()
    value = ansible_constructor_0.construct_mapping('node')
    data.update(value)
    data.ansible_pos = ansible_constructor_0._node_position_info('node')


# Generated at 2022-06-25 04:25:27.137855
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test construct_mapping() with no duplicate keys
    values = [("key0", "value0"), ("key1", "value1")]
    ansible_mapping = AnsibleConstructor.construct_mapping(None, values)
    assert ansible_mapping == {'key0': 'value0', 'key1': 'value1'}

    # Test construct_mapping() with a duplicate key and ignore
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    values = [("key0", "value0"), ("key1", "value1"), ("key1", "value3")]
    ansible_mapping = AnsibleConstructor.construct_mapping(None, values)
    assert ansible_mapping == {'key0': 'value0', 'key1': 'value3'}



# Generated at 2022-06-25 04:25:30.170477
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    node = 'MappingNode'
    deep = 'True'
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_mapping(node,deep)


# Generated at 2022-06-25 04:25:36.229185
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    """
    Test case for method construct_yaml_unsafe of class AnsibleConstructor
    """
    obj = AnsibleConstructor()
    # Test for method construct_yaml_unsafe(node)
    obj.construct_yaml_unsafe()


# Generated at 2022-06-25 04:25:40.137656
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq(node=node)


# Generated at 2022-06-25 04:25:44.574730
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.construct_vault_encrypted_unicode(to_bytes('!vault').decode('utf-8')) == '!vault'

# Generated at 2022-06-25 04:25:46.864461
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_seq()


# Generated at 2022-06-25 04:26:05.683535
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    from yaml.nodes import MappingNode, ScalarNode, SequenceNode
    from yaml.constructor import ConstructorError


# Generated at 2022-06-25 04:26:08.841804
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str('node')


# Generated at 2022-06-25 04:26:15.144494
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_2 = AnsibleConstructor()
    assert ansible_constructor_2._vaults['default'] is not None

# Generated at 2022-06-25 04:26:16.914984
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map('node')



# Generated at 2022-06-25 04:26:21.850029
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    assert True

# Generated at 2022-06-25 04:26:23.648598
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    data_0 = "foo"
    ansible_constructor_1.construct_yaml_str(data_0)


# Generated at 2022-06-25 04:26:30.070235
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    yaml_data = """
a_key:
  - key1: value1
  - key2: value2
"""
    unsafe_node = ansible_constructor.construct_yaml_map(yaml_data)
    assert unsafe_node.value == 'a_key'

# Generated at 2022-06-25 04:26:37.629452
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # Make these available to the AnsibleConstructor class
    global ansible_constructor_0
    ansible_constructor_0 = AnsibleConstructor()
    global ansible_constructor_1
    ansible_constructor_1 = AnsibleConstructor()
    global ansible_constructor_2
    ansible_constructor_2 = AnsibleConstructor()
    global ansible_constructor_3
    ansible_constructor_3 = AnsibleConstructor()
    global ansible_constructor_4
    ansible_constructor_4 = AnsibleConstructor()
    global ansible_constructor_5
    ansible_constructor_5 = AnsibleConstructor()
    global ansible_constructor_6
    ansible_constructor_6 = AnsibleConstructor()
    global ansible_constructor_7
   

# Generated at 2022-06-25 04:26:40.851894
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    class_instance0 = AnsibleConstructor(file_name=None, vault_secrets=None)
    assert isinstance(class_instance0.construct_yaml_str(node=None), AnsibleUnicode)


# Generated at 2022-06-25 04:26:47.625579
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_2 = AnsibleConstructor(u'<string>')
    ansible_constructor_2._anchors = {}
    ansible_constructor_2._modules_cache = {}
    ansible_constructor_2._task_cache = {}
    ansible_constructor_2._cache = {}
    ansible_constructor_2._vaults = {}
    ansible_constructor_2._vaults['default'] = VaultLib()
    ansible_constructor_2.vault_secrets = [u'p@ssword']
    ansible_constructor_2._data = {}
    ansible_constructor_2._yaml_base_loader = None
    ansible_constructor_2._base_loader = None

    ansible_constructor_2._data = {}
    ansible_construct

# Generated at 2022-06-25 04:26:58.269899
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # FIXME: This test should be implemented
    pass


# Generated at 2022-06-25 04:27:02.610556
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    X = "'''!unsafe'"
    ansible_constructor_0 = AnsibleConstructor()
    input_0 = ansible_constructor_0.construct_yaml_unsafe(X)

    assert input_0 is not None


# Generated at 2022-06-25 04:27:12.128916
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_3 = AnsibleConstructor()
    ansible_constructor_4 = AnsibleConstructor()
    ansible_constructor_5 = AnsibleConstructor()
    ansible_constructor_6 = AnsibleConstructor()
    ansible_constructor_7 = AnsibleConstructor()

    # Expected values
    ansible_constructor_0.construct_yaml_map(node=[{}, {}])
    ansible_constructor_1.construct_yaml_map(node=[{"a": "b"}, {}])

# Generated at 2022-06-25 04:27:13.328370
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    foo = AnsibleConstructor()
    foo.construct_vault_encrypted_unicode()

# Generated at 2022-06-25 04:27:15.803529
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()

    assert issubclass(ansible_constructor_0.construct_yaml_str, unicode)


# Generated at 2022-06-25 04:27:26.455686
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    # Test default constructor
    assert ansible_constructor_0 != None, "Constructor cannot be null"
    # Test Attribute 'vault_secrets'
    assert hasattr(ansible_constructor_0, 'vault_secrets')
    vault_secrets_0 = ansible_constructor_0.vault_secrets
    assert vault_secrets_0 == [], "Attribute vault_secrets of AnsibleConstructor can't be empty"
    # Test Attribute '_vaults'
    assert hasattr(ansible_constructor_0, '_vaults')
    _vaults_0 = ansible_constructor_0._vaults

# Generated at 2022-06-25 04:27:33.873093
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    data = ansible_constructor_0.construct_yaml_map()



# Generated at 2022-06-25 04:27:36.338488
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_vault_encrypted_unicode()


# Generated at 2022-06-25 04:27:41.830368
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    # yaml_node_2 = <class 'yaml.nodes.MappingNode'>
    ansible_mapping_3 = AnsibleConstructor.construct_yaml_map(ansible_constructor_1, yaml_node_2)
    # assert type(ansible_mapping_3) is AnsibleMapping
    # assert isinstance(ansible_mapping_3, AnsibleMapping)


# Generated at 2022-06-25 04:27:47.217098
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_node_0 = None
    ansible_constructor_0.construct_yaml_map(yaml_node_0)


# Generated at 2022-06-25 04:28:15.145252
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    ansible_constructor_1 = AnsibleConstructor()
    # Test first use case
    with pytest.raises(ConstructorError) as e_1:
        ansible_constructor_1.construct_mapping(node='node')
    assert ("expected a mapping node, but found " in str(e_1.value)) is True

    ansible_constructor_2 = AnsibleConstructor()
    # Test second use case
    with pytest.raises(ConstructorError) as e_2:
        ansible_constructor_2.construct_mapping(node=MappingNode())
    assert ("while constructing a mapping" in str(e_2.value)) is True


# Generated at 2022-06-25 04:28:25.488523
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_object = lambda : 42
    # Test a success case
    res = ansible_constructor_1.construct_yaml_unsafe(None)
    assert res == wrap_var(42), "Should have returned 42"

    ansible_constructor_2 = AnsibleConstructor()
    ansible_constructor_2.construct_object = lambda : None
    # Test a success case
    res = ansible_constructor_2.construct_yaml_unsafe(None)
    assert res == wrap_var(None), "Should have returned None"

    ansible_constructor_3 = AnsibleConstructor()
    ansible_constructor_3.construct_object = lambda : 'foo'
    # Test a success case
    res

# Generated at 2022-06-25 04:28:28.583199
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    node = MappingNode(value=[(str,str)], start_mark=str, end_mark=str)
    deep = False

    assert(ansible_constructor.construct_mapping(node, deep) == dict())
    #lint:enable

# Generated at 2022-06-25 04:28:35.352627
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    value = ansible_constructor_0.construct_yaml_str("foobar")
    value.ansible_pos == None

# Generated at 2022-06-25 04:28:36.981769
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(MappingNode)



# Generated at 2022-06-25 04:28:38.839845
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():

    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str()


# Generated at 2022-06-25 04:28:44.000450
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    with pytest.raises(ConstructorError) as excinfo:
        ansible_constructor_0.construct_vault_encrypted_unicode(node)


# Generated at 2022-06-25 04:28:49.701558
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    # (test_case_0)
    # construct_yaml_map(node)
    try:
        ansible_constructor_0.construct_yaml_map(node)
    except Exception:
        pass


# Generated at 2022-06-25 04:28:51.564292
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_seq()


# Generated at 2022-06-25 04:28:54.970333
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # test arguments
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode()

    # test response
    ret = ansible_constructor_0.construct_mapping(node)
    assert not ret


# Generated at 2022-06-25 04:29:42.819676
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor

# Generated at 2022-06-25 04:29:44.885818
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    with pytest.raises(NotImplementedError):
        ansible_constructor_0.construct_yaml_str()


# Generated at 2022-06-25 04:29:47.356513
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode(None, None)
    ansible_constructor_0.construct_yaml_map(node)


# Generated at 2022-06-25 04:29:55.126444
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test case from AnsibleConstructor::__init__
    ansible_constructor_0 = AnsibleConstructor()
    # Test case from AnsibleConstructor::construct_mapping
    node_0 = _MappingNode()
    node_0.id = 'python/dict'
    node_0.start_mark = _Mark()
    node_0.start_mark.name = '<unicode string>'
    node_0.start_mark.buffer = '<unicode string>'
    node_0.start_mark.column = 0
    node_0.start_mark.line = 1
    node_0.end_mark = _Mark()
    node_0.end_mark.name = '<unicode string>'
    node_0.end_mark.buffer = '<unicode string>'
    node_

# Generated at 2022-06-25 04:30:04.663398
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_str = "key: value\n"
    test_str += "key2: value2"
    node = yaml.compose(test_str, Loader=yaml.Loader)
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_mapping(node)

#####################################################################################
# Unit tests for method construct_object of class AnsibleConstructor
#####################################################################################

# Generated at 2022-06-25 04:30:11.604977
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_target_0 = AnsibleConstructor()
    node_0 = {}
    node_map_0 = {}
    node_value_0 = {}
    ansible_constructor_target_0._node_position_info = MagicMock(side_effect=ansible_constructor_0._node_position_info)
    ansible_constructor_target_0.construct_mapping = MagicMock(side_effect=ansible_constructor_0.construct_mapping)
    ansible_constructor_0.construct_yaml_map(node_0)
    ansible_constructor_target_0.construct_mapping.assert_called_once_with(node_0)


# Generated at 2022-06-25 04:30:16.013478
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping("node_0")



# Generated at 2022-06-25 04:30:23.899546
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    yaml_node_2 = MappingNode('tag:yaml.org,2002:map', None, None, True, False, None)
    ansible_mapping_3 = ansible_constructor_1.construct_mapping(yaml_node_2)
    assert ansible_mapping_3 == {}, 'Expected {}, but got {}'.format({}, ansible_mapping_3)


# Generated at 2022-06-25 04:30:30.442809
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # Create a dummy event object to play with
    event = {}

    # Create an instance of AnsibleConstructor
    ans = AnsibleConstructor()

    # Create a dummy node object to play with
    node = MappingNode(u"tag:yaml.org,2002:map", [], [], None, None)

    # Run the test

    # Expected result: a dictionary of data defined by the node
    # Call the function
    rval = ans.construct_yaml_map(node)

    # Check the answer
    assert isinstance(rval, dict)


# Generated at 2022-06-25 04:30:34.470609
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    from yaml.nodes import MappingNode

    node = MappingNode('tag:yaml.org,2002:map', [])
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map(node)

# Generated at 2022-06-25 04:31:34.683689
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor()
    ansible_dumper_0 = AnsibleDumper()
    vault_lib_0 = VaultLib()
    vault_lib_1 = VaultLib()

# Generated at 2022-06-25 04:31:42.053943
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._ansible_file_name = "./tests/test_result.yaml"
    ansible_constructor_0._vaults = {"default": VaultLib(secrets=ansible_constructor_0.vault_secrets)}
    ansible_constructor_0._vaults["default"].secrets = [to_bytes("ansible")]
    ansible_constructor_0._vaults["default"].secrets = [to_bytes("ansible")]
    ansible_constructor_0.vault_secrets = [to_bytes("ansible")]
    ansible_constructor_0.vault_secrets = [to_bytes("ansible")]