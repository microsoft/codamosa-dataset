

# Generated at 2022-06-25 04:21:47.817923
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_str(None)


# Generated at 2022-06-25 04:21:50.664659
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = SafeConstructor.construct_yaml_seq(ansible_constructor_0, node=AnsibleSequence(start_mark, end_mark))


# Generated at 2022-06-25 04:21:59.030632
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():

    from yaml.composer import Composer
    from yaml.scanner import Scanner
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Method AnsibleConstructor::construct_vault_encrypted_unicode has a branch
    # for a 'raise' statement.
    #  It also has a branch for an 'if' statement.
    #  It also has a branch for a 'return' statement.
    # The first branch point is at line 216.

    # Set up parameters

    # Call method
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = None
    try:
        ansible_constructor_0.construct_vault_encrypted_unicode(node_0)
    except Exception as e:
        pass

    # Verify results

   

# Generated at 2022-06-25 04:22:00.120824
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # TODO: test cases
    pass

# Generated at 2022-06-25 04:22:02.423385
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_unsafe(None)


# Generated at 2022-06-25 04:22:06.047505
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    str_1 = 'just a string'
    node_1 = str_1
    assert type(ansible_constructor_1.construct_yaml_str(node_1)) == AnsibleUnicode


# Generated at 2022-06-25 04:22:07.637643
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_map()


# Generated at 2022-06-25 04:22:16.533808
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleVaultEncryptedUnicode
    f = open("test0.yaml","r")
    input = f.read()
    f.close()
    ansible_constructor_0 = AnsibleConstructor("test0.yaml")
    ansible_constructor_1 = ansible_constructor_0.get_single_data("!unsafe "+input)
    assert isinstance(ansible_constructor_1,AnsibleUnicode)


# Generated at 2022-06-25 04:22:21.420851
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
	ansible_constructor_1 = AnsibleConstructor()
	node_1 = MappingNode()
	mapping_1 = ansible_constructor_1.construct_yaml_map(node_1)
	pass


# Generated at 2022-06-25 04:22:22.832611
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    # FIXME: mock ?


# Generated at 2022-06-25 04:22:31.562835
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    data = AnsibleMapping()
    with pytest.raises(ConstructorError) as pytest_wrapped_e:
        ansible_constructor_0.construct_yaml_map(data)
    assert 'expected a mapping node' in pytest_wrapped_e.value.message


# Generated at 2022-06-25 04:22:35.510775
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:22:37.300414
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    node = MappingNode()

    try:
        ansible_constructor.construct_yaml_map(node)
    except:
        pass


# Generated at 2022-06-25 04:22:48.486048
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    if C.DUPLICATE_YAML_DICT_KEY == 'ignore':
        # Test 0: No exception
        ansible_constructor_0 = AnsibleConstructor()
        node_1 = MappingNode(tag='tag:yaml.org,2002:map', value=[('key_1', 'value_1')])
        value_1 = 'value_1'
        expected_result = {'key_1': 'value_1'}
        assert ansible_constructor_0.construct_mapping(node_1) == expected_result

    if C.DUPLICATE_YAML_DICT_KEY == 'warn':
        # Test 1: Assert warning message
        ansible_constructor_1 = AnsibleConstructor()

# Generated at 2022-06-25 04:22:51.380313
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()

if __name__ == "__main__":
    test_case_0()
    test_AnsibleConstructor_construct_vault_encrypted_unicode()

# Generated at 2022-06-25 04:22:54.093345
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    ansible_load = ansible_constructor.construct_yaml_map(MappingNode)
    assert ansible_load is not None


# Generated at 2022-06-25 04:23:04.397581
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    # doc_tests.test_AnsibleConstructor.test_AnsibleConstructor_construct_mapping
    # Test case 0
    try:
        ansible_constructor.construct_mapping(mapping_node='string', deep=False)
        assert False, "Expected an error"
    except Exception as e:
        assert "expected a mapping node" in e.args[0]
    # doc_tests.test_AnsibleConstructor.test_AnsibleConstructor_construct_mapping
    # Test case 1

# Generated at 2022-06-25 04:23:07.025403
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_vault_encrypted_unicode()

# Generated at 2022-06-25 04:23:12.039097
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test Method Instance
    ansible_constructor_0 = AnsibleConstructor()

    # Test Variables
    node = AnsibleUnicode()
    deep = False

    # Test Procedure
    ansible_constructor_0.construct_mapping(node, deep)


# Generated at 2022-06-25 04:23:12.962590
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    test_case_0()

# Generated at 2022-06-25 04:23:22.958568
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:23:29.404037
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode
    ansible_constructor = AnsibleConstructor()
    mapping_node_0 = MappingNode(anchor=None, tag=None, implicit=False, 
            value=[], start_mark=None, end_mark=None, flow_style=None)
    print(ansible_constructor.construct_mapping(mapping_node_0))


if __name__ == '__main__':
    test_AnsibleConstructor_construct_mapping()

# Generated at 2022-06-25 04:23:35.255946
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml = """\
---
key: value
"""
    obj = AnsibleConstructor().get_single_data(yaml)
    assert obj == {u'key': u'value'}



# Generated at 2022-06-25 04:23:42.930910
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode(u'tag:yaml.org,2002:map',
                       [(ScalarNode(u'tag:yaml.org,2002:str', u'foo'),
                         ScalarNode(u'tag:yaml.org,2002:str', u'bar'))],
                       None, None, None)
    ansible_constructor_0.construct_vault_encrypted_unicode(node)


# Generated at 2022-06-25 04:23:48.862163
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    # 1. Provided values
    ansible_constructor_1 = AnsibleConstructor()

    # 2. Expected values
    expected_value_ansible_constructor_1 = None
    # 3. Call the function with the arguments
    actual_value_ansible_constructor_1 = ansible_constructor_1.construct_yaml_unsafe()

    # 4. Compare actual value with expected value
    assert expected_value_ansible_constructor_1 == actual_value_ansible_constructor_1



# Generated at 2022-06-25 04:23:54.113487
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()



# Generated at 2022-06-25 04:24:03.881726
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    """
    Tests for old style entries in vault files.
    """
    from yaml import YAMLError
    from yaml.error import MarkedYAMLError
    import pytest
    ansible_constructor = AnsibleConstructor()
    mappings = {'key1_dup_key1': 'Value1', 'key1_dup_key2': 'Value2'}
    mappings_nodes = []
    for k, v in mappings.items():
        mappings_node = MappingNode(tag='tag:yaml.org,2002:str', value=[],
                                    flow_style=False, anchor=None)
        mappings_nodes.append({'key': k, 'value': v, 'node': mappings_node})
    # Case 1 - 'warn'
    # Duplicate key

# Generated at 2022-06-25 04:24:12.118987
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()

    # Test with invalid(out of range) start_mark.line
    test_AnsibleConstructor_construct_yaml_unsafe_0 = ansible_constructor_0.construct_yaml_unsafe(type)
    if isinstance(test_AnsibleConstructor_construct_yaml_unsafe_0, dict):
        pass
    else:
        # TypeError raised.
        pass



# Generated at 2022-06-25 04:24:18.048753
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()
    node = '!vault'
    ansible_constructor_1.construct_vault_encrypted_unicode(node)


# Generated at 2022-06-25 04:24:26.807613
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    assert('AnsibleConstructor' == ansible_constructor_1.__class__.__name__)

    # Test with a MappingNode
    ansible_constructor_1 = AnsibleConstructor()
    assert('AnsibleConstructor' == ansible_constructor_1.__class__.__name__)
    nodes = [{'1': '1'}, {'2': '2'}]
    mapping_node = MappingNode(nodes)

    mapping = ansible_constructor_1.construct_mapping(mapping_node)
    assert({'1': '1', '2': '2'} == mapping)

    # Test with non-MappingNode
    ansible_constructor_2 = AnsibleConstructor()

# Generated at 2022-06-25 04:25:03.342526
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str()

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 04:25:05.056395
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:25:13.801423
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # ConstructorError is not yet a public class from yaml
    from yaml.constructor import ConstructorError
    # Redefining a dummy constructor for this block for test purpose.
    class DummyConstructor(object):
        def __init__(self):
            self._vaults = {}
            self.vault_secrets = []
            self._vaults['default'] = VaultLib(secrets=self.vault_secrets)

        def construct_mapping(self, node, deep=False):
            if not isinstance(node, MappingNode):
                raise ConstructorError(None, None,
                                       "expected a mapping node, but found %s" % node.id,
                                       node.start_mark)
            return AnsibleMapping()

        def construct_yaml_seq(self, node):
            data = Ans

# Generated at 2022-06-25 04:25:18.272195
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node = None
    with pytest.raises(ConstructorError):
        data = ansible_constructor_0.construct_yaml_seq(node)
    # pyyaml.nodes.SequenceNode is expected as node argument


# Generated at 2022-06-25 04:25:25.157787
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    d = {
        'key1': 1,
        'key2': 2,
    }
    m = AnsibleConstructor.construct_mapping(
        ansible_constructor_0,
        d,
        deep=False,
    )
    assert m.ansible_pos is None, \
        "The return value of construct_mapping, " \
        "must be the same as expected."


# Generated at 2022-06-25 04:25:33.640818
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    ansible_node = "abcd"
    ansible_deep = False
    expected = "ansible_mapping"
    actual = ansible_constructor.construct_mapping(ansible_node, ansible_deep)
    assert(actual == expected),"AnsibleConstructor.construct_mapping() failed with inputs: ansible_node = '" + ansible_node + "', ansible_deep = " + str(ansible_deep) + "\nExpected: " + str(expected) + "\nActual: " + str(actual)


# Generated at 2022-06-25 04:25:36.513882
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:25:41.653111
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    yaml_data_0 = """
---
- 1
- 2
- 3
- 4
- 5
...
"""
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_1 = AnsibleConstructor(file_name='/playbooks/myplaybook.yml')
    ansible_constructor_2 = AnsibleConstructor(vault_secrets=['/secrets/vault_0'])


# Generated at 2022-06-25 04:25:46.363325
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    fake_node_0 = MagicMock()
    fake_node_0.id = 'object'

    # Call method
    result = ansible_constructor_0.construct_yaml_unsafe(fake_node_0)

    assert result is not None
    assert isinstance(result, wrap_var)


# Generated at 2022-06-25 04:25:52.506154
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    #  Scenario:Test AnsibleConstructor class for construct_vault_encrypted_unicode method
    ansible_constructor_0 = AnsibleConstructor()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_constructor_0.construct_vault_encrypted_unicode(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:26:55.178245
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor('test/fixtures/ansible_constructor_0.yaml')
    assert ansible_constructor_0.construct_yaml_map() == None


# Generated at 2022-06-25 04:26:58.557059
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(node_0__0)


# Generated at 2022-06-25 04:27:06.000325
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_seq_0 = AnsibleSequence()
    node = {'start_mark': None, 'id': 'test_id', 'end_mark': None, 'value': [{'value': 'test_value', 'start_mark': None, 'end_mark': None, 'tag': 'test_tag'}]}
    # Assign parameters
    ansible_constructor_0.construct_sequence(node)
    ansible_constructor_0.construct_yaml_seq(node)


# Generated at 2022-06-25 04:27:09.522479
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping()


# Generated at 2022-06-25 04:27:13.721499
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    assert AnsibleConstructor().construct_yaml_seq('node').next() == AnsibleSequence()
    AnsibleConstructor()._ansible_file_name = 'file'
    assert AnsibleConstructor().construct_yaml_seq('node').next() == AnsibleSequence()


# Generated at 2022-06-25 04:27:18.388301
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    yaml_data = """
    key1: 1
    key2: 2
    key3: 3
    """
    expected_result = {'key1': 1, 'key2': 2, 'key3': 3}
    assert expected_result == AnsibleConstructor().construct_yaml_map(yaml.compose(yaml_data))[0]


# Generated at 2022-06-25 04:27:22.251354
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = Node()
    __tracebackhide__ = True
    with pytest.raises(TypeError):
        ansible_constructor_0.construct_yaml_map(node_0)


# Generated at 2022-06-25 04:27:25.195637
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    pass

if __name__ == "__main__":
    test_AnsibleConstructor_construct_yaml_map()

# Generated at 2022-06-25 04:27:31.829631
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    C.DUPLICATE_YAML_DICT_KEY = 'ignore'
    data = """\
{ test1 : 1 , test2 : 2 , test1 : 3 }
"""
    yaml_loader = AnsibleConstructor()
    res = yaml_loader.construct_yaml_map(yaml_loader.construct_yaml_map(yaml_loader.construct_yaml_str(data))[0])
    assert res['test1'] == 3

# Generated at 2022-06-25 04:27:36.808885
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()

    # Test with representative value for node

    node = MappingNode(tag='tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None, flow_style=None)

    ansible_constructor.construct_yaml_unsafe(node=node)



# Generated at 2022-06-25 04:28:43.302420
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_str()


# Generated at 2022-06-25 04:28:50.381127
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    from ansible.utils.unsafe_proxy import wrap_var
    ret = ansible_constructor_0.construct_yaml_unsafe(wrap_var(u'[vautl_encrypted_data, vault_encrypted_data]'))
    assert ret == wrap_var(u'[vautl_encrypted_data, vault_encrypted_data]')


# Generated at 2022-06-25 04:29:01.412017
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    # Create a VaultLib object
    vaultlib = VaultLib()
    # Create a node
    node = 'ciphertext_data'
    # Create a dummy encrypted ciphertext_data

# Generated at 2022-06-25 04:29:02.572451
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()


# Generated at 2022-06-25 04:29:10.407930
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()

    # 1st test case:
    # try to construct an empty mapping and expect it to work
    # (we cannot create an empty mapping in Python and therefore
    # use an empty string '{}' and pass it as an object
    # to the yaml.construct_yaml_map function)
    node = '{}'
    deep = False
    expected_result = {}
    result = ansible_constructor.construct_mapping(node, deep)
    assert result == expected_result

    # 2nd test case:
    # create a more complex mapping and check its content
    # add the mapping to the node and expect it to work

# Generated at 2022-06-25 04:29:14.861468
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    from yaml.nodes import MappingNode
    ansible_constructor = AnsibleConstructor()
    node = MappingNode()
    ansible_constructor.construct_mapping(node)

# Generated at 2022-06-25 04:29:22.789499
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    def construct_scalar(node):
        val = 'abc123' 
        return val


    ansible_constructor_1.construct_scalar = construct_scalar
    node = 'node'
    ansible_constructor_1.construct_yaml_str(node)
    
    ansible_constructor_1.construct_scalar = None
    ret = ansible_constructor_1.construct_yaml_str(node)
    assert ret is None


# Generated at 2022-06-25 04:29:34.812843
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    import yaml
    yaml_input = u'!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          333462353965343030313231323034323561383933346266626431383638376431336239303361\n          313466623234313220633663663166333037336361373565663039336338363537373462633563\n          313861643163396366353664396666356436316463356631633564\n          '
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_2 = AnsibleConstructor()

    print("\n\n##### START case_0 #####\n{}".format(yaml_input))

# Generated at 2022-06-25 04:29:35.926828
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()


# Generated at 2022-06-25 04:29:38.646632
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0.construct_mapping(MappingNode()), AnsibleMapping)
