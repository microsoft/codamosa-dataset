

# Generated at 2022-06-25 04:21:50.168514
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    list_0 = []
    ansible_constructor_0 = AnsibleConstructor(list_0)

    ansible_mapping_0 = ansible_constructor_0.construct_mapping(ansible_constructor_0) 


# Generated at 2022-06-25 04:21:53.282830
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    list_0 = []
    ansible_constructor_0 = AnsibleConstructor(list_0)
    ansible_constructor_0.construct_yaml_str(list_0)



# Generated at 2022-06-25 04:21:57.568937
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    list_2 = []
    ansible_constructor_1 = AnsibleConstructor(list_2)
    with pytest.raises(AttributeError):
        ansible_constructor_1.construct_yaml_unsafe(list_2)


# Generated at 2022-06-25 04:21:58.605040
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()



# Generated at 2022-06-25 04:22:01.071672
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    node = {"start_mark": {"column": 263, "line": 2}}
    ansible_constructor_0.construct_yaml_str(node)


# Generated at 2022-06-25 04:22:03.996710
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor(file_name=None, vault_secrets=None)
    test_case_0()


# Generated at 2022-06-25 04:22:11.773409
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    obj = AnsibleConstructor()

    # testing the type of an attribute
    assert hasattr(obj, '_ansible_file_name')
    assert hasattr(obj, '_vaults')
    assert hasattr(obj, 'vault_secrets')
    assert hasattr(obj, 'construct_yaml_map')
    assert hasattr(obj, 'construct_mapping')
    assert hasattr(obj, 'construct_yaml_str')
    assert hasattr(obj, 'construct_vault_encrypted_unicode')
    assert hasattr(obj, 'construct_yaml_seq')
    assert hasattr(obj, 'construct_yaml_unsafe')
    assert hasattr(obj, '_node_position_info')

# Generated at 2022-06-25 04:22:14.884403
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    list_0 = []
    ansible_constructor_0 = AnsibleConstructor(list_0)
    list_1 = []
    ansible_constructor_0.construct_yaml_str(list_1)


# Generated at 2022-06-25 04:22:19.569006
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    list_0 = []
    ansible_constructor_0 = AnsibleConstructor(list_0)
    ansible_constructor_0_construct_yaml_str_0 = ansible_constructor_0.construct_yaml_str(list_0)
    return ansible_constructor_0_construct_yaml_str_0


# Generated at 2022-06-25 04:22:22.269807
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    list_0 = []
    ansible_constructor_0 = AnsibleConstructor(list_0)
    node_0 = list_0
    answer = ansible_constructor_0.construct_yaml_str(node_0)
    assert(not answer)


# Generated at 2022-06-25 04:22:29.601706
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor = AnsibleConstructor()
    pass


# Generated at 2022-06-25 04:22:35.144775
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert False # FIXME: implement your test here


# Generated at 2022-06-25 04:22:40.088240
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # This test case checks the handling of duplicate keys in YAML dicts. When
    # one is found there are three possible handler in AnsibleConstructor
    # * warn
    # * error
    # * ignore
    # The default handling is ignore.
    # It is expected that on error or warning the handling function sets a
    # message on display and on ignore it does not.

    # Set to WARN
    display.verbosity = 2
    C.DUPLICATE_YAML_DICT_KEY = "warn"

    ansible_constructor_0 = AnsibleConstructor()
    result_0 = ansible_constructor_0.construct_mapping(node=None, deep=False)

    # Note: The expected value of msg is dynamic !

# Generated at 2022-06-25 04:22:41.645637
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    obj = AnsibleConstructor()
    obj.construct_yaml_map(test_data_0)


# Generated at 2022-06-25 04:22:48.731942
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    yaml_node_1 = []
    actual = ansible_constructor_1.construct_yaml_map(yaml_node_1)

# Generated at 2022-06-25 04:22:52.838637
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    test_case_0()


# Generated at 2022-06-25 04:23:03.809933
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    # We want to test the default values of a mapping
    assert ansible_mapping_0.aliases == []
    assert ansible_mapping_0.final_value == None
    assert ansible_mapping_0.fqdn == ''
    assert ansible_mapping_0.host_name == ''
    assert ansible_mapping_0.ipv4 == []
    assert ansible_mapping_0.ipv6 == []
    assert ansible_mapping_0.groups == []
    assert ansible_mapping_0.network == ''

# Generated at 2022-06-25 04:23:15.883848
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()

    # Test using test fixture (data, expected result)
    data_1 = "String"
    out_1 = ansible_constructor_0.construct_yaml_str(data_1)
    assert isinstance(out_1, AnsibleUnicode)

    # Test using test fixture (data, expected result)
    data_2 = u'String'
    out_2 = ansible_constructor_0.construct_yaml_str(data_2)
    assert out_2.ansible_pos == (None, None, None)

    # Test using test fixture (data, expected result)
    data_3 = 'String'
    out_3 = ansible_constructor_0.construct_yaml_str(data_3)
    assert out_3.ans

# Generated at 2022-06-25 04:23:24.420188
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_map_0 = AnsibleMapping({'a': 'b'})
    ansible_map_1 = ansible_constructor_0.construct_mapping(None,)
    ansible_map_1.update({'a': 'b'})
    assert ansible_map_0 == ansible_map_1



# Generated at 2022-06-25 04:23:30.344829
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping = ansible_constructor_0.construct_yaml_map("node")
    assert isinstance(ansible_mapping, AnsibleMapping)


# Generated at 2022-06-25 04:23:45.357076
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():

    import yaml
    import sys

    # Case 0
    try:
        ansible_constructor_case_0 = AnsibleConstructor()
        ansible_mapping_node_case_0 = yaml.nodes.MappingNode(u'tag:yaml.org,2002:map', [], [], True)
        ansible_mapping_case_0 = ansible_constructor_case_0.construct_mapping(ansible_mapping_node_case_0)
        ansible_mapping_case_0_result = ansible_mapping_case_0.ansible_pos

    except Exception as exc:
        print(exc)
        sys.exit(1)

    # Case 1

# Generated at 2022-06-25 04:23:46.875935
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
   ansible_constructor_0 = AnsibleConstructor()
   val = ansible_constructor_0.construct_yaml_seq()
   assert val == ""


# Generated at 2022-06-25 04:23:50.920626
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    item_1 = MappingNode(tag='tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    ansible_mapping_2 = ansible_constructor_0.construct_yaml_map(item_1)
    assert isinstance(ansible_mapping_2, GeneratorType)


# Generated at 2022-06-25 04:24:00.322110
# Unit test for method construct_mapping of class AnsibleConstructor

# Generated at 2022-06-25 04:24:03.323987
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor = AnsibleConstructor()
    assert type(ansible_constructor.construct_yaml_str("string")) == AnsibleUnicode


# Generated at 2022-06-25 04:24:06.355840
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    assert ansible_constructor is not None


# Generated at 2022-06-25 04:24:08.469662
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_str()

# Generated at 2022-06-25 04:24:16.598449
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    vault_password = 'testpassword'
    test_string = 'this is a test string'
    vault = VaultLib(secrets=[vault_password])
    ciphertext = vault.encrypt(test_string)
    ciphertext = to_bytes(ciphertext)

    # test creation of a safe string
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0._vaults['default'] = vault
    param_0 = None
    ansible_constructor_0.construct_vault_encrypted_unicode(param_0)
    # test creation of safe string where data has been provided
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1._vaults['default'] = vault
    param_1 = None
    ansible_constructor_1.construct

# Generated at 2022-06-25 04:24:22.073112
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor('/etc/ansible/test_node')
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_0.ansible_pos = ('/etc/ansible/test_node', 14, 4)
    assert ansible_constructor_0.construct_mapping(None, deep=False) == ansible_mapping_0
    ansible_mapping_1 = AnsibleMapping()
    ansible_mapping_1.ansible_pos = ('/etc/ansible/test_node', 14, 4)
    assert ansible_constructor_0.construct_mapping(None, deep=True) == ansible_mapping_1


# Generated at 2022-06-25 04:24:33.671409
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    # test cases
    # test case 1 of construct_yaml_map
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    result = ansible_constructor_0.construct_yaml_map(node)
    assert type(result.next()) == AnsibleMapping
    # test case 2 of construct_yaml_map
    node = MappingNode(tag=u'tag:yaml.org,2002:map', value=[], start_mark=None, end_mark=None)
    result = ansible_constructor_0.construct_yaml_map(node)
    assert result.next() == {}
    # test case 3 of construct_yaml_map

# Generated at 2022-06-25 04:24:46.530655
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    from io import StringIO
    yaml_in = u'[1, 2, 3]\n'
    yaml_in = yaml_in.encode('utf-8')
    file_name = None
    vault_secrets = ['cauliflower']
    ansible_constructor_0 = AnsibleConstructor(file_name, vault_secrets)
    seq = yaml.load(yaml_in, Loader=AnsibleConstructor)
    assert isinstance(seq, AnsibleSequence)
    assert seq == [1, 2, 3]


# Generated at 2022-06-25 04:24:52.943830
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_1 = AnsibleConstructor()
    with open('/dev/null', 'w') as fd:
        fd.write("""
        foo: !unsafe
          bar: foo
        """)
        fd.flush()
        fd.seek(0, 0)
        assert ansible_constructor_1.construct_yaml_unsafe(AnsibleUnicode()) == AnsibleUnicode()

# Generated at 2022-06-25 04:24:57.607947
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Test for a case that should pass
    ansible_constructor_1 = AnsibleConstructor()
    node = MappingNode()
    deep = True
    result = ansible_constructor_1.construct_mapping(node, deep=deep)
    assert type(result) == AnsibleMapping



# Generated at 2022-06-25 04:25:02.410307
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    test_ansible_mapping_0 = AnsibleMapping()
    test_ansible_mapping_0.ansible_pos = (None, 1, 1)
    test_ansible_mapping_0.update({})
    assert ansible_constructor_0.construct_mapping(MappingNode(None, [])) == test_ansible_mapping_0


# Generated at 2022-06-25 04:25:09.892429
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # test default behavior of not raising an error on duplicate dict keys
    assert C.DUPLICATE_YAML_DICT_KEY == 'ignore'
    yaml_dict = '''
foo:
  - 1
  - 2
bar:
  - 3
  - 4
'''
    results = yaml.load(yaml_dict, Loader=AnsibleConstructor)
    assert results == dict(foo=[1,2], bar=[3,4])

    # test error behavior on duplicate dict keys
    with pytest.raises(yaml.constructor.ConstructorError):
        yaml_dict = '''
foo:
  - 1
  - 2
foo:
  - 3
  - 4
'''

        old_dict_key_setting = C.DUPLICATE_YAML_DICT_

# Generated at 2022-06-25 04:25:19.998263
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    # following is the string representation of 'node'
    node = {'end_mark': {'index': 3, 'buffer': 'value\n', 'line': 0, 'column': 7}, 'tag': u'tag:yaml.org,2002:str', 'start_mark': {'index': 0, 'buffer': 'value\n', 'line': 0, 'column': 0}, 'value': 'value'}
    assert ansible_constructor_0.construct_yaml_str(node) == 'value'

# Generated at 2022-06-25 04:25:23.657813
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_1 = AnsibleConstructor()
    node_2 = node()
    meth_1 = ansible_constructor_1.construct_yaml_seq(node_2)
    assert meth_1 is not None



# Generated at 2022-06-25 04:25:33.359491
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_1 = AnsibleConstructor()
    node = {"a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:y:z": "A:B:C:D:E:F:G:H:I:J:K:L:M:N:O:P:Q:R:S:T:U:V:W:X:Y:Z"}
    node_ = ansible_constructor_1.construct_mapping(node)



# Generated at 2022-06-25 04:25:43.395055
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    yaml_map_0 = YAML()
    with open('/etc/ansible/hosts', 'r') as stream:
        data_loaded = yaml_map_0.load(stream)
    yaml_map_1 = dict(data_loaded)
    for key, value in yaml_map_1.items():
        print(key, ":", value)
    ansible_dict_0 = ansible_constructor_0.construct_yaml_map(yaml_map_1)
    assert ansible_dict_0.ansible_pos == ('/etc/ansible/hosts', 1, 1)
    list_0 = list(ansible_dict_0.keys())
    assert list_0[0] == 'all'

# Generated at 2022-06-25 04:25:47.514341
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    scalar_node_0 = ScalarNode('tag:yaml.org,2002:seq', ['vault', 'unsafe'], None, None)
    ansible_constructor_0.construct_yaml_seq(scalar_node_0)


# Generated at 2022-06-25 04:25:58.248455
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    #TODO: Add unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
    assert True


# Generated at 2022-06-25 04:26:06.681748
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    import sys
    import cStringIO
    import yaml

    s = cStringIO.StringIO()
    old_stdout = sys.stdout
    sys.stdout = s
    ansible_constructor_0 = AnsibleConstructor()
    yaml_0 = yaml
    # This will give us a default empty mapping
    yaml_0.load(u'!unsafe', ansible_constructor_0)
    yaml_1 = yaml
    # This will give us a default empty mapping
    yaml_1.load(u'!unsafe', ansible_constructor_0)
    sys.stdout = old_stdout
    s.seek(0)
    out = s.readlines()
    assert out[0] == u'{}\n'

# Generated at 2022-06-25 04:26:09.605776
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0.construct_yaml_map(), AnsibleMapping)


# Generated at 2022-06-25 04:26:17.330518
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()

    # basic test
    yaml_str = '''
- this: that
- 2: 3
'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert data[0]['this'] == 'that', data
    assert data[1][2] == 3, data

    # test of duplicate key
    yaml_str = '''
- this: that
- 2: 3
- this: nope
'''
    data = yaml.load(yaml_str, Loader=AnsibleConstructor)
    assert len(data) == 3, data
    assert data[0]['this'] == 'that', data
    assert data[1][2] == 3, data

# Generated at 2022-06-25 04:26:23.145203
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()

    assert ansible_constructor_0.construct_yaml_str(node)


# Generated at 2022-06-25 04:26:28.651419
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    x = AnsibleConstructor()
    y = MappingNode('tag:yaml.org,2002:str', [])
    x.construct_yaml_seq(y)  # Should not throw exception

# Generated at 2022-06-25 04:26:31.645677
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_yaml_str(None)


# Generated at 2022-06-25 04:26:43.801997
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert ansible_constructor_0.vault_secrets is None
    assert ansible_constructor_0._vaults['default'] is not None
    assert ansible_constructor_0._vaults['default'].decrypt == VaultLib.decrypt
    assert ansible_constructor_0._vaults['default'].decrypt_file == VaultLib.decrypt_file
    assert ansible_constructor_0._vaults['default'].encrypt == VaultLib.encrypt
    assert ansible_constructor_0._vaults['default'].encrypt_file == VaultLib.encrypt_file
    assert ansible_constructor_0._vaults['default'].is_encrypted == VaultLib.is_encrypted
    assert ansible_constructor_0._vaults

# Generated at 2022-06-25 04:26:54.926247
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = ['foo','bar']
    vault_data = vault_secrets[0]
    vault = VaultLib(secrets=vault_secrets)
    vault.encrypt(data=vault_data)
    ciphertext = vault.ciphertext

    # Mocking the method call to construct_scalar which returns the ciphertext data
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_scalar = lambda x: ciphertext
    ansible_constructor_0._vaults['default'] = vault


# Generated at 2022-06-25 04:26:58.343688
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ansible_constructor_1 = AnsibleConstructor(file_name='/Users/wcaleb/projects/ansible/test/units/module_utils/parsing/yaml/aliases.py')
    # Construct fake parameter 'node'
    node_1 = {}
    # Call method
    ansible_constructor_1.construct_yaml_str(node=node_1)


# Generated at 2022-06-25 04:27:11.589773
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    """
    Cases:
      - 1: Test Case
    """
    cases = [
        {'test_case': 1}
    ]
    for c in cases:
        test_case = c['test_case']
        ansible_constructor = AnsibleConstructor()


# Generated at 2022-06-25 04:27:13.910724
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_vault_encrypted_unicode(AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 04:27:19.606082
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    print("In method AnsibleConstructor.construct_yaml_map.")
    yaml_node_0 = MappingNode(u'tag:yaml.org,2002:map',
                              [], start_mark=None, end_mark=None)
    ansible_constructor_0 = AnsibleConstructor(file_name=None,
                                         vault_secrets=None)
    ansible_constructor_0.construct_yaml_map(yaml_node_0)



# Generated at 2022-06-25 04:27:22.248715
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    # setup
    ansible_constructor_1 = AnsibleConstructor()
    ansible_constructor_1.construct_yaml_map()
    assert False # TODO: implement your test here


# Generated at 2022-06-25 04:27:32.241511
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    node = MappingNode("!vault", None, None, None, None, None)
    vault_secrets = ['1234']
    ansible_constructor_0 = AnsibleConstructor(file_name='test.yml', vault_secrets=vault_secrets)
    ansible_constructor_1 = AnsibleConstructor(file_name='test.yml')
    # try:
    ansible_constructor_0.construct_vault_encrypted_unicode(node)
    # except VaultError as e:
    assert 0, 'AnsibleConstructor.construct_vault_encrypted_unicode raised AssertionError unexpectedly!'

# Generated at 2022-06-25 04:27:41.204320
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor = AnsibleConstructor()
    import yaml
    yaml_data = """
        - name: test
          no_log: False
          become: false
        - name: test1
          no_log: false
          become: false
    """
    yaml_data_loaded = yaml.load(yaml_data, Loader=AnsibleConstructor)
    ansible_constructor.construct_yaml_map(yaml_data_loaded)
    assert yaml_data_loaded == [{u'no_log': False, u'name': u'test', u'become': False}, {u'no_log': False, u'name': u'test1', u'become': False}]


# Generated at 2022-06-25 04:27:45.128696
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    a = AnsibleConstructor()
    map = a.construct_mapping([['key', 'value']])
    assert isinstance(map, dict) is True
    assert map['key'] == 'value'
    assert map.ansible_pos == (None, 1, 1)


# Generated at 2022-06-25 04:27:51.586715
# Unit test for method construct_yaml_unsafe of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_unsafe():
    ansible_constructor_0 = AnsibleConstructor()
    safe_constructor_0 = SafeConstructor()
    ansible_constructor_0.construct_object = safe_constructor_0.construct_object
    node_0 = MappingNode(tag="tag:yaml.org,2002:str")
    ansible_constructor_0.construct_yaml_unsafe(node_0)
    

# Generated at 2022-06-25 04:27:56.722690
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor = AnsibleConstructor()
    ansible_constructor.construct_yaml_map()
    ansible_constructor.construct_yaml_str()
    ansible_constructor.construct_yaml_seq()

# Generated at 2022-06-25 04:28:02.399948
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = MappingNode()
    node_1 = MappingNode()
    node_2 = MappingNode()
    node_3 = MappingNode()
    ansible_constructor_0.construct_mapping(node_0)
    ansible_constructor_0.construct_mapping(node_1)
    ansible_constructor_0.construct_mapping(node_2)
    ansible_constructor_0.construct_mapping(node_3)

# Generated at 2022-06-25 04:28:27.930270
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_0.ansible_pos = ('', 1, 1)
    ansible_mapping_1 = AnsibleMapping()
    ansible_mapping_1.ansible_pos = ('', 1, 1)
    ansible_mapping_1['first_key'] = 'first_value'
    ansible_mapping_2 = AnsibleMapping()
    ansible_mapping_2.ansible_pos = ('', 1, 1)
    ansible_mapping_2['second_key'] = 'second_value'
    ansible_mapping_3 = AnsibleMapping()
    ansible_mapping_3.ansible_pos = ('', 1, 1)


# Generated at 2022-06-25 04:28:32.787826
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()

    # FIXME: test fails due to not being able to construct a node
    # (not actually defined)
    # assert ansible_constructor_0.construct_yaml_seq(node_0) == ansible_sequence_0
    pass


# Generated at 2022-06-25 04:28:35.688107
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0.construct_mapping(ansible_constructor_0.construct_mapping())


# Generated at 2022-06-25 04:28:37.968980
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor = AnsibleConstructor()
    ansible_mapping = AnsibleMapping()
    ansible_constructor.construct_mapping(ansible_mapping)


# Generated at 2022-06-25 04:28:48.374191
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()

# Generated at 2022-06-25 04:28:50.891005
# Unit test for method construct_yaml_str of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_str():
    ans_cons = AnsibleConstructor()
    node = SafeConstructor.construct_yaml_str(ans_cons, 't')
    AnsibleConstructor.construct_yaml_str(ans_cons, node)



# Generated at 2022-06-25 04:29:01.919718
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    c = AnsibleConstructor(file_name=u'test')

    # constructor parameter 'node' is not mocked
    # test case insufficent

    # constructor parameter 'deep' is not mocked
    # test case insufficent

    # test case 1
    class Mock_node:
        id = u'mapping'
        start_mark = u'line 17, column 10'
    mock_node = Mock_node()
    class Mock_key_node:
        id = u'scalar'
        start_mark = u'line 3, column 1'
    mock_key_node = Mock_key_node()
    class Mock_value_node:
        id = u'scalar'
        start_mark = u'line 3, column 6'
    mock_value_node = Mock_value_node()

# Generated at 2022-06-25 04:29:05.571160
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor = AnsibleConstructor()
    ansible_node = 'node'
    ret = ansible_constructor.construct_vault_encrypted_unicode(ansible_node)
    # FIXME: Add test assertions
    assert ret is not None


# Generated at 2022-06-25 04:29:12.017934
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # test that empty sequence is created
    test_yaml = """
    ---
    -
    -
    """
    ansible_constructor_0 = AnsibleConstructor()
    ansible_constructor_0 = AnsibleConstructor(file_name=None, vault_secrets=None)
    ansible_constructor_0 = AnsibleConstructor(file_name=0.5, vault_secrets=None)
    ansible_constructor_0 = AnsibleConstructor(file_name=list(), vault_secrets=None)
    ansible_constructor_0 = AnsibleConstructor(file_name=dict(), vault_secrets=None)
    ansible_constructor_0 = AnsibleConstructor(file_name="string", vault_secrets=None)
    ansible_constructor_0 = AnsibleConstructor

# Generated at 2022-06-25 04:29:16.289698
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()
    yaml_map_1 = None
    result = ansible_constructor_1.construct_yaml_map(yaml_map_1)
    assert result is None


# Generated at 2022-06-25 04:29:57.865574
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_1 = AnsibleConstructor()

# Generated at 2022-06-25 04:30:08.011797
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    ansible_constructor_0 = AnsibleConstructor()
    node_0 = AnsibleSequence()
    node_0.extend([])
    node_0.ansible_pos = None
    node_1 = AnsibleSequence()
    node_1.extend([])
    node_1.ansible_pos = None
    node_2 = AnsibleSequence()
    node_2.extend([])
    node_2.ansible_pos = None
    node_3 = AnsibleSequence()
    node_3.extend([])
    node_3.ansible_pos = None

# Generated at 2022-06-25 04:30:10.525344
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_0 = AnsibleConstructor()
    assert isinstance(ansible_constructor_0, AnsibleConstructor)
    assert ansible_constructor_0.construct_vault_encrypted_unicode(None) is None



# Generated at 2022-06-25 04:30:16.332374
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
  from test.io import StringIO
  from ruamel.yaml.constructor import ConstructorError
  from ruamel.yaml.nodes import SequenceNode
  from ruamel.yaml.nodes import MappingNode
  from ansible.parsing.yaml.loader import AnsibleLoader
  from ruamel.yaml.composer import Composer
  from ruamel.yaml.parser import Parser
  ansible_constructor = AnsibleConstructor()
  strem = StringIO(' ')
  parser = Parser(strem)
  composer = Composer(parser, AnsibleLoader)
  event = composer.get_event()
  ansible_constructor.check_event(event)
  node = parser.compose_document()
  node.start_mark = None
  ansible_constructor.construct_document

# Generated at 2022-06-25 04:30:25.515595
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    #testcase
    ansible_constructor_0 = AnsibleConstructor()
    a_list = [ 1, 2 ]
    data = AnsibleSequence()
    data.extend(ansible_constructor_0.construct_sequence(a_list))
    assert data[1] == 2, 'Expected data[1] to be 2 but got %s' % data[1]
    assert data[0] == 1, 'Expected data[0] to be 1 but got %s' % data[0]
    assert len(data) == 2, 'Expected len(data) to be 2 but got %s' % len(data)


# Generated at 2022-06-25 04:30:31.004281
# Unit test for method construct_vault_encrypted_unicode of class AnsibleConstructor
def test_AnsibleConstructor_construct_vault_encrypted_unicode():
    ansible_constructor_obj = AnsibleConstructor()

    # Constructing a node
    node_obj = None

    # Calling method
    # AnsibleConstructor.construct_vault_encrypted_unicode
    this  = ansible_constructor_obj.construct_vault_encrypted_unicode(node_obj)

    # Unit test for method construct_yaml_unsafe of class AnsibleConstructor

# Generated at 2022-06-25 04:30:41.477569
# Unit test for method construct_yaml_seq of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_seq():
    # Constructing instances of class AnsibleConstructor
    ansible_constructor_0 = AnsibleConstructor()
    # Testing method construct_yaml_seq of class AnsibleConstructor
    # Testing the return type of method construct_yaml_seq
    # Testing the return type of method construct_yaml_seq
    # Testing the return type of method construct_yaml_seq
    # Testing the return type of method construct_yaml_seq
    # Testing the return type of method construct_yaml_seq
    
    # Testing method construct_yaml_seq of class AnsibleConstructor
    # Testing the return type of method construct_yaml_seq
    # Testing the return type of method construct_yaml_seq
    # Testing the return type of method construct_yaml_seq
    # Testing the return type of method construct_yaml_seq
   

# Generated at 2022-06-25 04:30:45.376675
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    # Setup the YAML node
    node = MappingNode()
    # Call the constructor
    ret = AnsibleConstructor.construct_mapping(node)

    # Check the return value
    if ret is not None:
        raise AssertionError("construct_mapping should return None, returned " + repr(ret))



# Generated at 2022-06-25 04:30:48.665888
# Unit test for method construct_yaml_map of class AnsibleConstructor
def test_AnsibleConstructor_construct_yaml_map():
    ansible_constructor_1 = AnsibleConstructor()

    # this is just a sanity test as we don't have a good way of parsing yaml strings into
    # a node object to pass in, but this at least proves that we aren't fatally broken and
    # the signature of the method is correct

    assert isinstance(ansible_constructor_1.construct_yaml_map(None), AnsibleMapping)



# Generated at 2022-06-25 04:30:57.436501
# Unit test for method construct_mapping of class AnsibleConstructor
def test_AnsibleConstructor_construct_mapping():
    ansible_constructor_0 = AnsibleConstructor()
    # Test with a valid mapping node
    node_0 = MappingNode(tag=u'tag:yaml.org,2002:map', value=list(), start_mark=None, end_mark=None)
    assert isinstance(ansible_constructor_0.construct_mapping(node_0), AnsibleMapping)

    # Test with an invalid mapping node
    node_1 = list()
    try:
        ansible_constructor_0.construct_mapping(node_1)
    except ConstructorError as exc:
        assert exc.problem == "expected a mapping node, but found !!python/name:list"
