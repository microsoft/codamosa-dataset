

# Generated at 2022-06-18 10:13:30.191256
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].get

# Generated at 2022-06-18 10:13:32.731344
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfei/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:13:42.954208
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import unittest
    import datetime
    import time
    import pytz
    from tornado.testing import AsyncTestCase
    from tornado.testing import gen_test
    from tornado.testing import main
    from tornado.testing import ExpectLog
    from tornado.testing import LogTrapTestCase
    from tornado.testing import bind_unused_port
    from tornado.web import Application
    from tornado.web import RequestHandler
    from tornado.web import url
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import options
    from tornado.options import define
    from tornado.options import parse_command_line
    from tornado.options import parse_config_file
    from tornado.options import Error
    from tornado.options import print_help
    from tornado.options import add_parse_callback


# Generated at 2022-06-18 10:13:53.997015
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:13:57.118449
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/michael/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:00.957052
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u0698\u0627\u0646\u0648\u06cc\u0647 1"
    assert locale.format_day(date, dow=False) == "\u0698\u0627\u0646\u0648\u06cc\u0647 1"


# Generated at 2022-06-18 10:14:03.232217
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/yue/Desktop/tornado_test/test_locale')
    print(_translations)


# Generated at 2022-06-18 10:14:13.710298
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:14:18.022484
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/yuan/PycharmProjects/tornado-5.1.1/tornado/locale', 'tornado')
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:14:20.720801
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yunfei/tornado_test/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:33.357593
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyu/Documents/GitHub/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:35.965598
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/lizhitao/Documents/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:44.072055
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["unknown"]["Sign out"] == "Sign out"
    assert _translations["es_LA"]["unknown"]["Sign out"] == "Cerrar sesión"
    assert _translations["es_LA"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"
    assert _translations["es_LA"]["singular"]["%(name)s liked this"] == "A %(name)s le gustó esto"
    assert _supported_locales == frozenset(["en_US", "es_LA"])


# Generated at 2022-06-18 10:14:56.991927
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test the pgettext method of class Locale
    # This method is not implemented in the base class, so we need to
    # create a subclass that implements it
    class TestLocale(Locale):
        def pgettext(
            self,
            context: str,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            return "pgettext"

    # Create a TestLocale object
    locale = TestLocale("en")

    # Test the pgettext method
    assert locale.pgettext("context", "message") == "pgettext"
    assert locale.pgettext("context", "message", "plural_message", 1) == "pgettext"

# Generated at 2022-06-18 10:15:03.266606
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["zh_CN"].gettext("Hello") == "你好"
    assert _translations["zh_CN"].gettext("Hello %s") == "你好 %s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"

# Generated at 2022-06-18 10:15:07.847444
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:15:15.092538
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale("en").format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert Locale("en").format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    assert Locale("fa").format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale("fa").format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:15:19.109375
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/cjy/Desktop/tornado-5.1.1/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:26.046049
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/travis/build/tornadoweb/tornado/tornado/locale/", "tornado")
    assert _translations["zh_CN"] == gettext.translation("tornado", "/home/travis/build/tornadoweb/tornado/tornado/locale/", languages=["zh_CN"])
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True


# Generated at 2022-06-18 10:15:31.220012
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory='./locale', domain='tornado')
    assert _translations['zh_CN'] == gettext.translation('tornado', './locale', languages=['zh_CN'])
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True



# Generated at 2022-06-18 10:16:02.481334
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A"]) == "A"
    assert Locale.get("en").list([]) == ""
    assert Locale.get("fa").list(["A", "B", "C"]) == "A \u0648 B \u0648 C"
    assert Locale.get("fa").list(["A", "B"]) == "A \u0648 B"
    assert Locale.get("fa").list(["A"]) == "A"
    assert Locale.get("fa").list([]) == ""


# Generated at 2022-06-18 10:16:15.203227
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_MO"].gettext("Sign out") == "登出"
    assert _translations["zh_SG"].gettext("Sign out") == "登出"
    assert _translations["zh_MY"].gettext("Sign out") == "登出"

# Generated at 2022-06-18 10:16:25.192114
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:16:36.044486
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lucas/Documents/tornado-6.0.3/tornado/locale/", "tornado")
    assert _translations["pt_BR"].gettext("Sign out") == "Sair"
    assert _translations["pt_BR"].gettext("%(name)s liked this") == "A %(name)s gostou disso"
    assert _translations["pt_BR"].gettext("%(name)s liked this") == "A %(name)s gostou disso"
    assert _translations["pt_BR"].gettext("%(name)s liked this") == "A %(name)s gostou disso"

# Generated at 2022-06-18 10:16:40.802088
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:16:48.707554
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "دوشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "ژانویه 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")

# Generated at 2022-06-18 10:16:58.759062
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale("en").format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert Locale("en").format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    assert Locale("fa").format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale("fa").format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:17:08.454589
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 22)
    assert locale.format_day(date) == "Tuesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 22"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 22"
    # Test for Chinese
    locale = Locale.get("zh_CN")
   

# Generated at 2022-06-18 10:17:17.709478
# Unit test for constructor of class Locale
def test_Locale():
    Locale("en")
    Locale("en_US")
    Locale("zh_CN")
    Locale("fa")
    Locale("ar")
    Locale("he")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")
    Locale("pt_BR")


# Generated at 2022-06-18 10:17:20.888782
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yuanzheng/Documents/GitHub/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:51.803262
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/daniel/Documents/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:17:54.551173
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yue/Desktop/tornado_test/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:57.674531
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/Desktop/tornado-6.0.3/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:18:07.093321
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert Locale.get("fa").format_day(datetime.datetime(2019, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale.get("fa").format_day(datetime.datetime(2019, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:18:09.058639
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    print(_translations)


# Generated at 2022-06-18 10:18:16.718998
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:18:20.498687
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yuan/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:18:27.365307
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Test for pgettext method
    # Arrange
    code = "en"
    translations = gettext.NullTranslations()
    gettext_locale = GettextLocale(code, translations)
    context = "law"
    message = "right"
    plural_message = "rights"
    count = 2
    # Act
    result = gettext_locale.pgettext(context, message, plural_message, count)
    # Assert
    assert result == "rights"


# Generated at 2022-06-18 10:18:34.451490
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:18:42.732877
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("en_US")
    date = datetime.datetime(2019, 1, 1, 0, 0, 0)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale("fa_IR")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:19:22.538556
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import sys
    import os
    import io
    import csv
    import gettext
    import tempfile
    import shutil
    import subprocess
    import locale
    import random
    import string
    import datetime
    import time
    import tornado.escape
    import tornado.testing
    import tornado.util
    import tornado.locale
    import tornado.log
    import tornado.options
    from tornado.options import define, options
    from tornado.util import b, u
    from tornado.locale import load_translations, get_supported_locales, Locale, \
        get_closest_locale, load_gettext_translations, _default_locale, \
        _supported_locales, _translations, _use_gettext

# Generated at 2022-06-18 10:19:33.512827
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:19:35.541509
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test for method pgettext(self, context, message, plural_message=None, count=None)
    # of class Locale
    pass



# Generated at 2022-06-18 10:19:38.466107
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/peter/Documents/GitHub/tornado/tornado/_locale_data")
    print(_translations)


# Generated at 2022-06-18 10:19:50.369329
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import pytest
    from pytest import raises
    from unittest.mock import Mock
    from tornado.escape import to_unicode
    from tornado.util import ObjectDict
    from .locale import Locale
    from .locale import _translations
    from .locale import _supported_locales
    from .locale import _use_gettext
    from .locale import _default_locale
    from .locale import get_supported_locales
    from .locale import load_translations
    from .locale import load_gettext_translations
    from .locale import get_closest
    from .locale import get
    from .locale import LOCALE_NAMES
    from .locale import CSVLocale
    from .locale import GettextLocale
    from .locale import Locale


# Generated at 2022-06-18 10:20:02.350541
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:20:13.289837
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import sys
    import os
    import io
    import csv
    import gettext
    import datetime
    import locale
    import tempfile
    import shutil
    import logging
    import random
    import string
    from typing import Any, Dict, Iterable, List, Optional, Union
    from tornado.escape import to_unicode
    from tornado.util import ObjectDict
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.log import gen_log
    from tornado.options import options
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_callback

# Generated at 2022-06-18 10:20:23.817375
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 一月 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "一月 1"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:20:29.629532
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class TestGettextLocale(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            super().__init__(code)

    class TestGettextTranslations:
        def __init__(self, translations: Dict[str, Dict[str, str]]) -> None:
            self.translations = translations

        def ngettext(self, message: str, plural_message: str, count: int) -> str:
            if count != 1:
                message = plural_message

# Generated at 2022-06-18 10:20:39.798516
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class TestGettextLocale(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            super().__init__(code)

    class TestGettextTranslations(gettext.NullTranslations):
        def __init__(self, fp=None):
            super().__init__(fp)

# Generated at 2022-06-18 10:21:04.257091
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jose/Documents/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:21:10.934072
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    assert _translations["zh_CN"] == gettext.translation(domain="tornado", directory="./locale", languages=["zh_CN"])
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True
    gen_log.debug("Supported locales: %s", sorted(_supported_locales))


# Generated at 2022-06-18 10:21:16.742537
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(date) == "دوشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:21:27.158951
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import subprocess
    import tornado.locale
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.iostream
    import tornado.locks
    import tornado.log
    import tornado.escape
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.locks
    import tornado.netutil
    import tornado.options
    import tornado.process

# Generated at 2022-06-18 10:21:28.976541
# Unit test for function load_translations
def test_load_translations():
    load_translations("../../locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:21:40.516779
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # test for English
    locale = Locale.get("en")
    date = datetime.datetime(2020, 1, 1)
    assert locale.format_day(date) == "Wednesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2020, 1, 1)
    assert locale.format_day(date) == "2020\u5e741\u67081\u65e5\u661f\u671f\u4e09"
    assert locale.format_day(date, dow=False) == "2020\u5e741\u67081\u65e5"
    # test for Persian

# Generated at 2022-06-18 10:21:46.430546
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["plural"]["%(name)s liked this"] == "%(name)s liked this"
    assert _translations["es_LA"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"
    assert _translations["es_LA"]["singular"]["%(name)s liked this"] == "A %(name)s le gustó esto"
    assert _translations["es_LA"]["unknown"]["I love you"] == "Te amo"


# Generated at 2022-06-18 10:21:55.769149
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:22:05.173999
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s喜欢这个"

# Generated at 2022-06-18 10:22:07.005447
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    print(_translations)
    print(_supported_locales)
