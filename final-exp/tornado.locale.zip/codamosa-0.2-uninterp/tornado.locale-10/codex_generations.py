

# Generated at 2022-06-18 10:14:36.010691
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Load translations
    load_translations(os.path.join(os.path.dirname(__file__), "translations"))
    # Get Locale object
    locale = Locale.get("en_US")
    # Test format_date
    assert locale.format_date(datetime.datetime.utcnow()) == "just now"
    assert locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=1)) == "1 second ago"
    assert locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=2)) == "2 seconds ago"
    assert locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=59)) == "59 seconds ago"

# Generated at 2022-06-18 10:14:45.071972
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    from tornado.util import ObjectDict
    from tornado.options import options
    options.locale = 'en_US'
    load_translations(os.path.join(os.path.dirname(__file__), 'locale'))
    locale = Locale.get('en_US')
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == 'Tuesday, January 1'
    assert locale.format_day(date, dow=False) == 'January 1'
    options.locale = 'zh_CN'
    load_translations(os.path.join(os.path.dirname(__file__), 'locale'))
    locale = Locale.get('zh_CN')

# Generated at 2022-06-18 10:14:48.537530
# Unit test for function load_translations
def test_load_translations():
    load_translations("../locale")
    print(_translations)


# Generated at 2022-06-18 10:14:52.129863
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/zheng/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:02.527866
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for the case when dow is True
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1), dow=True) == "Monday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 2), dow=True) == "Tuesday, January 2"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 3), dow=True) == "Wednesday, January 3"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 4), dow=True) == "Thursday, January 4"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 5), dow=True) == "Friday, January 5"
    assert Loc

# Generated at 2022-06-18 10:15:05.840601
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jerry/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:07.711558
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)


# Generated at 2022-06-18 10:15:16.205211
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/travis/build/tornadoweb/tornado/tornado/locale", "tornado")
    assert _translations["en_US"] == gettext.translation("tornado", "/home/travis/build/tornadoweb/tornado/tornado/locale", languages=["en_US"])
    assert _translations["zh_CN"] == gettext.translation("tornado", "/home/travis/build/tornadoweb/tornado/tornado/locale", languages=["zh_CN"])
    assert _translations["zh_TW"] == gettext.translation("tornado", "/home/travis/build/tornadoweb/tornado/tornado/locale", languages=["zh_TW"])

# Generated at 2022-06-18 10:15:19.243484
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jian/Desktop/tornado_test/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:23.458778
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    assert CSVLocale("en", {}).translate("hello") == "hello"
    assert CSVLocale("en", {"unknown": {"hello": "hi"}}).translate("hello") == "hi"
    assert CSVLocale("en", {"plural": {"hello": "hi"}}).translate("hello") == "hello"
    assert CSVLocale("en", {"plural": {"hello": "hi"}}).translate("hello", "hi", 2) == "hi"
    assert CSVLocale("en", {"plural": {"hello": "hi"}}).translate("hello", "hi", 1) == "hello"
    assert CSVLocale("en", {"singular": {"hello": "hi"}}).translate("hello", "hi", 2) == "hi"

# Generated at 2022-06-18 10:16:02.739874
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/hongyanma/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:15.535088
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "دوشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "ژانویه 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")

# Generated at 2022-06-18 10:16:26.678036
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.util import _
    from tornado.locale import load_gettext_translations
    from tornado.locale import LOCALE_NAMES
    from tornado.locale import _default_locale
    from tornado.locale import _use_gettext
    from tornado.locale import _supported_locales
    from tornado.locale import _translations
    from tornado.locale import GettextLocale
    from tornado.locale import CSVLocale
    from tornado.locale import Locale
    from tornado.locale import CONTEXT_SEPARATOR
    from tornado.locale import _cache
    from tornado.locale import _
    from tornado.locale import _
    from tornado.locale import _
    from tornado.locale import _
    from tornado.locale import _
    from tornado.locale import _

# Generated at 2022-06-18 10:16:38.031623
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:16:46.908679
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:16:59.644989
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:17:09.246462
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "2018\u5e741\u67081\u65e5\u661f\u671f\u4e00"
    assert locale.format_day(date, dow=False) == "2018\u5e741\u67081\u65e5"
    # Test for Persian

# Generated at 2022-06-18 10:17:16.236435
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:17:26.156378
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 1月1日"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "1月1日"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:17:37.793195
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """
    Test format_date method of class Locale
    """
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from . import Locale
    from . import load_translations
    from . import load_gettext_translations
    import os
    import shutil
    import tempfile
    import unittest
    import zipfile
    import io

    class TestLocale(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.locale_dir = os.path.join(self.tempdir, "locale")
            os.mkdir(self.locale_dir)

# Generated at 2022-06-18 10:18:44.807750
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/joseph/Documents/GitHub/tornado/tornado/locale")
    print(_translations)

# Generated at 2022-06-18 10:18:48.328361
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yuan/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:18:58.783017
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

    assert Locale.get("en").friendly_number(1) == "1"

# Generated at 2022-06-18 10:19:02.552818
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/hongbin/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:19:06.684627
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/lz/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:19:13.147234
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class TestGettextLocale(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            super().__init__(code)

    class TestNullTranslations:
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            super().__init__(code)


# Generated at 2022-06-18 10:19:19.702661
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:19:22.529720
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhangyuan/Desktop/tornado-4.5.3/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:19:33.513177
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:19:44.895258
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:20:22.897140
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    print(_translations)


# Generated at 2022-06-18 10:20:25.351657
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:20:27.843867
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yunfei/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:20:35.569523
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A"]) == "A"
    assert Locale.get("en").list([]) == ""
    assert Locale.get("fa").list(["A", "B", "C"]) == "A \u0648 B \u0648 C"
    assert Locale.get("fa").list(["A", "B"]) == "A \u0648 B"
    assert Locale.get("fa").list(["A"]) == "A"
    assert Locale.get("fa").list([]) == ""


# Generated at 2022-06-18 10:20:37.769445
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yuan/Documents/GitHub/tornado/tornado/locale")
    print(_translations)

# Generated at 2022-06-18 10:20:40.768917
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/michael/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:51.656066
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(os.path.join(os.path.dirname(__file__), "locale"), "tornado")
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"

# Generated at 2022-06-18 10:20:53.735691
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    print(_translations)


# Generated at 2022-06-18 10:21:03.635222
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application
    from tornado.web import RequestHandler
    from tornado.web import url
    from tornado.ioloop import IOLoop
    from tornado.httpserver import HTTPServer
    from tornado.options import define
    from tornado.options import options
    from tornado.options import parse_command_line
    from tornado.options import parse_config_file
    from tornado.options import parse_command_line_and_config_file
    from tornado.options import print_help
    from tornado.options import print_configuration
    from tornado.options import Error
    from tornado.options import MissingArgumentError
    from tornado.options import UnknownOptionError
    from tornado.options import BadOptionError
    from tornado.options import BadValueError
    from tornado.options import OptionParser

# Generated at 2022-06-18 10:21:13.532838
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import get_test_image_file
    from zerver.lib.test_runner import slow
    from zerver.lib.upload import upload_message_image
    from zerver.models import get_realm, get_user_profile_by_email, UserProfile, \
        Message, Realm, Recipient, Stream, Attachment, UserMessage, \
        get_client, get_stream, get_system_bot
    from zerver.lib.actions import do_change_user_role, do_create_user
    from zerver.lib.avatar import get_avatar_url
    from zerver.lib.create_user import random_api_key

# Generated at 2022-06-18 10:22:23.689207
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), gmt_offset=5) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), gmt_offset=5, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")

# Generated at 2022-06-18 10:22:32.810260
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1), gmt_offset=5) == "Tuesday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1), gmt_offset=5, dow=False) == "January 1"
    assert Locale.get("fa").format_day(datetime.datetime(2019, 1, 1)) == "دوشنبه، ژانویه 1"
   