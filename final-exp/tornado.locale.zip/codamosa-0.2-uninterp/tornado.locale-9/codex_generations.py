

# Generated at 2022-06-18 10:13:30.143906
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import os
    import sys
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import to_unicode
    from tornado.options import options, define
    from tornado.log import app_log
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler
    from tornado.ioloop import IOLoop
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.process import fork_processes
    from tornado.util import b
    from tornado.web import HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.concurrent import Future
    from tornado.iostream import IOStream
   

# Generated at 2022-06-18 10:13:33.012126
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yuan/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:13:43.308849
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:13:45.279069
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianan/Documents/GitHub/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:13:57.120725
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(10) == "10"
    assert Locale.get("en").friendly_number(100) == "100"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(10000) == "10,000"
    assert Locale.get("en").friendly_number(100000) == "100,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(10000000) == "10,000,000"

# Generated at 2022-06-18 10:13:59.247672
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/david/Documents/GitHub/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:10.501050
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["unknown"]["Sign out"] == "Sign out"
    assert _translations["en_US"]["unknown"]["%(name)s liked this"] == "%(name)s liked this"
    assert _translations["en_US"]["plural"]["%(name)s liked this"] == "%(name)s liked this"
    assert _translations["en_US"]["singular"]["%(name)s liked this"] == "%(name)s liked this"
    assert _translations["es_LA"]["unknown"]["Sign out"] == "Salir"

# Generated at 2022-06-18 10:14:19.865006
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 1月1日"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "1月1日"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:14:31.334558
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(10) == "10"
    assert Locale.get("en").friendly_number(100) == "100"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(10000) == "10,000"
    assert Locale.get("en").friendly_number(100000) == "100,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(10000000) == "10,000,000"

# Generated at 2022-06-18 10:14:41.472161
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for locale en_US
    locale = Locale.get("en_US")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for locale zh_CN
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 1月1日"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "1月1日"
    # Test for locale fa_IR
    locale = Locale.get("fa_IR")

# Generated at 2022-06-18 10:15:04.888390
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:14.642777
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    import time
    import pytz
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.log import gen_log
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import tornado_redirected_to_list
    from zerver.lib.test_runner import slow
    from zerver.lib.timezone import get_timezone
    from zerver.lib.utils import get_subdomain
    from zerver.models import get_realm, get_user
    from zerver.views.home import home

    class LocaleTestCase(ZulipTestCase):
        def setUp(self):
            super

# Generated at 2022-06-18 10:15:26.094801
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for method format_day of class Locale
    # test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 22, 0, 0, 0)
    assert locale.format_day(date) == "Tuesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2019, 1, 22, 0, 0, 0)
    assert locale.format_day(date) == "2019\u5e741\u670822\u65e5"
    assert locale.format_day(date, dow=False) == "2019\u5e741\u670822\u65e5"
    #

# Generated at 2022-06-18 10:15:35.601556
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:15:37.153224
# Unit test for function load_translations
def test_load_translations():
    directory = "./locale"
    load_translations(directory)
    print(_translations)


# Generated at 2022-06-18 10:15:39.670012
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/hong/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:50.239500
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "دوشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"
    locale = Locale.get("zh_CN")

# Generated at 2022-06-18 10:16:02.784498
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2017, 12, 25)
    assert locale.format_day(date) == "Monday, December 25"
    assert locale.format_day(date, dow=False) == "December 25"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062f\u0631\u06cc\u0627\u0641\u062a\u0627\u062f\u06cc 25"

# Generated at 2022-06-18 10:16:15.584213
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for method format_date(self, date, gmt_offset, relative, shorter, full_format)
    # of class Locale
    import datetime
    import time
    from tornado.util import unicode_type
    from tornado.util import _time_independent_equals
    from tornado.util import utc
    from tornado.util import timedelta_seconds
    from tornado.util import timedelta_days
    from tornado.util import timedelta_microseconds
    from tornado.util import timedelta_total_seconds
    from tornado.util import timedelta_total_milliseconds
    from tornado.util import timedelta_total_minutes
    from tornado.util import timedelta_total_hours
    from tornado.util import timedelta_total_seconds
    from tornado.util import timedelta_total_seconds
    from tornado.util import timed

# Generated at 2022-06-18 10:16:26.712523
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "mydomain")
    assert _translations["en_US"].gettext("Hello") == "Hello"
    assert _translations["en_US"].gettext("Hello %s") == "Hello %s"
    assert _translations["en_US"].gettext("Hello %(name)s") == "Hello %(name)s"
    assert _translations["en_US"].gettext("Hello %(name)s") == "Hello %(name)s"
    assert _translations["en_US"].gettext("Hello %(name)s") == "Hello %(name)s"
    assert _translations["en_US"].gettext("Hello %(name)s") == "Hello %(name)s"

# Generated at 2022-06-18 10:17:36.348901
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["unknown"]["I love you"] == "I love you"
    assert _translations["en_US"]["plural"]["%(name)s liked this"] == "%(name)s liked this"
    assert _translations["en_US"]["singular"]["%(name)s liked this"] == "%(name)s liked this"
    assert _translations["es_LA"]["unknown"]["I love you"] == "Te amo"
    assert _translations["es_LA"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"

# Generated at 2022-06-18 10:17:44.528101
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:17:46.283369
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfeng/Desktop/tornado-master/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:17:56.938726
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import shutil
    import tempfile
    import unittest
    import tornado.locale
    import tornado.testing
    import tornado.util

    class GettextTestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(GettextTestCase, self).setUp()
            self.locale_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.locale_dir)
            self.domain = "tornado_test"
            self.pot_file = os.path.join(self.locale_dir, "messages.pot")
            self.po_file = os.path.join(self.locale_dir, "messages.po")

# Generated at 2022-06-18 10:18:07.560030
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "2018\u5e741\u67081\u65e5\u661f\u671f\u4e00"
    assert locale.format_day(date, dow=False) == "2018\u5e741\u67081\u65e5"



# Generated at 2022-06-18 10:18:11.535448
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yuan/Desktop/tornado-6.0.4/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:18:21.010333
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="../locale")
    assert _translations["en_US"]["plural"]["%(name)s liked this"] == "A %(name)s liked this"
    assert _translations["en_US"]["singular"]["%(name)s liked this"] == "A %(name)s liked this"
    assert _translations["es_LA"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"
    assert _translations["es_LA"]["singular"]["%(name)s liked this"] == "A %(name)s le gustó esto"
    assert _translations["es_LA"]["unknown"]["I love you"] == "Te amo"


# Generated at 2022-06-18 10:18:31.430402
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:18:37.252021
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import gettext
    import os
    import sys
    import unittest
    from tornado.util import u

    class GettextLocaleTestCase(unittest.TestCase):
        def setUp(self):
            self.locale = GettextLocale("en_US", gettext.NullTranslations())
            self.locale.translations = gettext.translation(
                "tornado",
                os.path.join(os.path.dirname(__file__), "locale"),
                languages=["en_US"],
            )

        def test_pgettext(self):
            self.assertEqual(self.locale.pgettext("law", "right"), "right")
            self.assertEqual(self.locale.pgettext("good", "right"), "right")

# Generated at 2022-06-18 10:18:40.252392
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jeff/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:20:25.447166
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    print(_translations)


# Generated at 2022-06-18 10:20:33.442700
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "چهارشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:20:35.930798
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2020, 1, 1)
    assert locale.format_day(date) == "Wednesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"


# Generated at 2022-06-18 10:20:46.668144
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(
        os.path.join(os.path.dirname(__file__), "test_data", "locale"), "tornado"
    )
    assert get("en_US").translate("Hello") == "Hello"
    assert get("pt_BR").translate("Hello") == "Ola"
    assert get("pt_BR").translate("Hello %(name)s", name="Leandro") == "Ola Leandro"
    assert get("pt_BR").translate("%(num)d dog", "%(num)d dogs", 2) == "2 cachorros"
    assert get("pt_BR").translate("%(num)d dog", "%(num)d dogs", 1) == "1 cachorro"

# Generated at 2022-06-18 10:20:57.225489
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 22"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 22"
    # test for Chinese
    locale = Locale.get("zh_CN")
   

# Generated at 2022-06-18 10:21:00.324854
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/hong/tornado-6.0.4/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:21:02.068663
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:21:12.724654
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:21:21.830028
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    from tornado.util import ObjectDict
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.timezone import get_timezone

    class TestLocale(Locale):
        def __init__(self, code: str) -> None:
            self.code = code
            self.name = LOCALE_NAMES.get(code, {}).get("name", u"Unknown")
            self.rtl = False
            for prefix in ["fa", "ar", "he"]:
                if self.code.startswith(prefix):
                    self.rtl = True
                    break

            # Initialize strings for date formatting
            _ = self.translate

# Generated at 2022-06-18 10:21:24.132442
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/jason/tornado-5.1.1/tornado/locale/', 'tornado')
