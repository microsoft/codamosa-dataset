

# Generated at 2022-06-18 10:13:31.213235
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import gettext
    import tornado.locale
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.escape
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.iostream
    import tornado.locks
    import tornado.log
    import tornado.stack_context
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.locks
    import tornado.log
    import tornado.process

# Generated at 2022-06-18 10:13:33.990681
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/mengxin/Desktop/tornado_test/locale')
    print(_translations)
    print(_supported_locales)
# test_load_translations()



# Generated at 2022-06-18 10:13:44.099074
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:13:53.725746
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:13:56.710361
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/daniel/Desktop/tornado-6.0.3/tornado/locale')
    print(_translations)


# Generated at 2022-06-18 10:14:03.521251
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en_US").friendly_number(123456789) == "123,456,789"
    assert Locale.get("fa").friendly_number(123456789) == "123456789"
    assert Locale.get("fa_IR").friendly_number(123456789) == "123456789"



# Generated at 2022-06-18 10:14:06.355883
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jason/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:07.591343
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfeng/Desktop/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:14.698831
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test with a date in the past
    date = datetime.datetime.utcnow() - datetime.timedelta(days=1)
    assert Locale.get("en").format_date(date) == "yesterday"
    assert Locale.get("en").format_date(date, full_format=True) == "yesterday"
    assert Locale.get("en").format_date(date, relative=False) == "yesterday"
    assert Locale.get("en").format_date(date, relative=False, full_format=True) == "yesterday"

    # Test with a date in the future
    date = datetime.datetime.utcnow() + datetime.timedelta(days=1)
    assert Locale.get("en").format_date(date) == "tomorrow"

# Generated at 2022-06-18 10:14:26.853369
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.util import _
    from tornado.locale import load_gettext_translations
    from tornado.locale import Locale
    from tornado.locale import GettextLocale
    from tornado.locale import _translations
    from tornado.locale import _use_gettext
    from tornado.locale import _default_locale
    from tornado.locale import _supported_locales
    from tornado.locale import _

    # Create a fake translation file
    import tempfile
    import os
    import shutil
    import gettext
    import tornado.locale
    import tornado.util
    import tornado.testing
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.options
    import tornado.escape
    import tornado.httputil
    import tornado.httpclient

# Generated at 2022-06-18 10:14:57.838264
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jiaxin/Desktop/tornado-5.1.1/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:15:08.898827
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647\u060c \u062c\u0627\u0646\u06cc\u0647 \u06f1"
    assert locale.format_day(date, dow=False) == "\u062c\u0627\u0646\u06cc\u0647 \u06f1"


# Generated at 2022-06-18 10:15:16.812543
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import subprocess
    import tornado.locale
    import tornado.testing
    import tornado.web

    class TestHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(self.locale.translate("Hello"))

    class TestLocale(tornado.testing.AsyncHTTPTestCase):
        def setUp(self):
            super(TestLocale, self).setUp()
            self.locale_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.locale_dir)
            self.domain = "tornado_test"
            self.pot_file = os.path.join(self.locale_dir, self.domain + ".pot")
            self.po_file = os

# Generated at 2022-06-18 10:15:19.198144
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfei/Desktop/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:15:29.674147
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:15:38.582474
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import shutil
    import tempfile
    import unittest
    import tornado.locale
    import tornado.testing

    class GettextTestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(GettextTestCase, self).setUp()
            self.tempdir = tempfile.mkdtemp()
            self.locale_dir = os.path.join(self.tempdir, "locale")
            os.mkdir(self.locale_dir)
            os.mkdir(os.path.join(self.locale_dir, "en_US"))
            os.mkdir(os.path.join(self.locale_dir, "en_US", "LC_MESSAGES"))

# Generated at 2022-06-18 10:15:49.714964
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
    Test for method format_day of class Locale
    """
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale

# Generated at 2022-06-18 10:16:02.306989
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:16:14.921638
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory = "./locale", domain = "tornado")
    print(get("zh_CN").translate("Sign out"))
    print(get("zh_CN").translate("%(name)s liked this", name = "陈晨"))
    print(get("zh_CN").translate("%(name)s liked this", name = "陈晨", plural = "plural"))
    print(get("zh_CN").translate("%(name)s liked this", name = "陈晨", plural = "singular"))
    print(get("zh_CN").translate("%(name)s liked this", name = "陈晨", plural = "unknown"))

# Generated at 2022-06-18 10:16:26.235857
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    from tornado.testing import AsyncTestCase
    from tornado.testing import gen_test
    from tornado.testing import main
    from tornado.testing import LogTrapTestCase
    from tornado.testing import ExpectLog
    from tornado.testing import bind_unused_port
    from tornado.web import Application
    from tornado.web import RequestHandler
    from tornado.web import asynchronous
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResp

# Generated at 2022-06-18 10:16:59.035976
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:17:04.593604
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
    Test for method format_day of class Locale
    """
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale

# Generated at 2022-06-18 10:17:15.255991
# Unit test for function load_translations
def test_load_translations():
    load_translations("./test_locale")
    assert _translations["en_US"]["unknown"]["test"] == "test"
    assert _translations["en_US"]["unknown"]["test1"] == "test1"
    assert _translations["en_US"]["unknown"]["test2"] == "test2"
    assert _translations["en_US"]["unknown"]["test3"] == "test3"
    assert _translations["en_US"]["unknown"]["test4"] == "test4"
    assert _translations["en_US"]["unknown"]["test5"] == "test5"
    assert _translations["en_US"]["unknown"]["test6"] == "test6"

# Generated at 2022-06-18 10:17:22.883836
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test_Locale_format_date_1
    # Input:
    date = datetime.datetime(2020, 1, 1, 0, 0, 0)
    gmt_offset = 0
    relative = True
    shorter = False
    full_format = False
    # Output:
    output = "January 1, 2020 at 12:00 am"
    # test_Locale_format_date_2
    # Input:
    date = datetime.datetime(2020, 1, 1, 0, 0, 0)
    gmt_offset = 0
    relative = False
    shorter = False
    full_format = False
    # Output:
    output = "January 1, 2020 at 12:00 am"
    # test_Locale_format_date_3
    # Input:

# Generated at 2022-06-18 10:17:35.033787
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:17:41.267535
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "دوشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"



# Generated at 2022-06-18 10:17:44.117626
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lucas/Documents/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:17:46.478605
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:57.139987
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import gettext
    import tornado.locale
    import tornado.testing
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.options
    import tornado.escape
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.iostream
    import tornado.log
    import tornado.gen
    import tornado.locks
    import tornado.stack_context
    import tornado.template
    import tornado.concurrent
    import tornado.ioloop
    import tornado.queues
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.iostream
    import tornado.ioloop
    import tornado.netutil
    import tornado.process
    import tornado.stack_context
   

# Generated at 2022-06-18 10:18:08.308825
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:18:33.917308
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="test")
    assert _translations["en_US"].gettext("test") == "test"
    assert _translations["zh_CN"].gettext("test") == "测试"
    assert _translations["zh_TW"].gettext("test") == "測試"
    assert _translations["zh_HK"].gettext("test") == "測試"
    assert _translations["zh_SG"].gettext("test") == "测试"
    assert _translations["zh_MO"].gettext("test") == "測試"
    assert _translations["zh_MY"].gettext("test") == "测试"

# Generated at 2022-06-18 10:18:44.313127
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:18:52.400663
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert Locale.get("en").pgettext("context", "message") == "message"
    assert Locale.get("en").pgettext("context", "message", "plural", 2) == "plural"
    assert Locale.get("en").pgettext("context", "message", "plural", 1) == "message"
    assert Locale.get("en").pgettext("context", "message", "plural", 0) == "plural"
    assert Locale.get("en").pgettext("context", "message", "plural", -1) == "plural"



# Generated at 2022-06-18 10:19:03.369820
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:19:13.625825
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:19:16.183443
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/jiaxin/Desktop/tornado-6.0.3/tornado/locale')
    print(_translations)


# Generated at 2022-06-18 10:19:18.808892
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:19:22.158683
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/zhaoyu/tornado_test/locale", "tornado_test")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:19:33.097296
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:19:42.026811
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale("en").format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert Locale("en").format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert Locale("fa").format_day(datetime.datetime(2019, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale("fa").format_day(datetime.datetime(2019, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:20:04.673341
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.util import _get_translations
    from tornado.options import options
    from tornado.log import gen_log
    from tornado.locale import GettextLocale, LOCALE_NAMES, _default_locale
    from tornado.locale import _translations, _use_gettext, _supported_locales
    from tornado.locale import CSVLocale, Locale
    from tornado.locale import CONTEXT_SEPARATOR
    import gettext
    import os
    import unittest
    import warnings
    import datetime
    import locale
    import re
    import sys
    import types
    import unittest
    import tornado.testing
    import tornado.web
    import tornado.escape
    import tornado.ioloop
    import tornado.options
    import tornado.util
    import tornado.httpserver

# Generated at 2022-06-18 10:20:07.934498
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/liang/Desktop/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:20:14.482798
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale("en").format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert Locale("en").format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"
    assert Locale("fa").format_day(datetime.datetime(2020, 1, 1)) == "چهارشنبه، ژانویه 1"
    assert Locale("fa").format_day(datetime.datetime(2020, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:20:16.074149
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)


# Generated at 2022-06-18 10:20:26.587320
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import get_test_image_file
    from zerver.lib.upload import upload_message_image
    from zerver.models import get_realm, get_user, Message, Recipient, UserProfile
    from zerver.views.messages import create_mirrored_message_users

    class TestGettextLocale(ZulipTestCase):
        def test_pgettext(self):
            # type: () -> None
            user_profile = self.example_user('hamlet')
            self.login_user(user_profile)
            realm = get_realm("zulip")
            self.assertEqual(realm.name, "Zulip")

# Generated at 2022-06-18 10:20:29.011602
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jie/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:38.925221
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(date) == "2019\u5e741\u67081\u65e5\u661f\u671f\u4e8c"
    assert locale.format_day(date, dow=False) == "2019\u5e741\u67081\u65e5"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:20:48.244898
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647\u060c \u0698\u0627\u0646\u0648\u06cc\u0647 1"
    assert locale.format_day(date, dow=False) == "\u0698\u0627\u0646\u0648\u06cc\u0647 1"


# Generated at 2022-06-18 10:20:49.745575
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/daniel/Documents/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:20:53.526441
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lixiaohu/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:21:40.724472
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), gmt_offset=1) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), gmt_offset=1, dow=False) == "January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), gmt_offset=60) == "Sunday, December 31"

# Generated at 2022-06-18 10:21:47.562633
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"

# Generated at 2022-06-18 10:21:49.562242
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yuanzheng/Desktop/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:21:59.174932
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(10) == "10"
    assert Locale.get("en").friendly_number(100) == "100"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(10000) == "10,000"
    assert Locale.get("en").friendly_number(100000) == "100,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(10000000) == "10,000,000"

# Generated at 2022-06-18 10:22:02.341408
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/david/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:22:10.500024
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo

# Generated at 2022-06-18 10:22:13.204436
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfeng/Desktop/tornado-master/tornado/locale/")
    print(_translations)

# Generated at 2022-06-18 10:22:15.113642
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/travis/build/tornadoweb/tornado/tornado/locale", "tornado")


# Generated at 2022-06-18 10:22:25.767066
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(1) == "1"
    assert Locale("en").friendly_number(12) == "12"
    assert Locale("en").friendly_number(123) == "123"
    assert Locale("en").friendly_number(1234) == "1,234"
    assert Locale("en").friendly_number(12345) == "12,345"
    assert Locale("en").friendly_number(123456) == "123,456"
    assert Locale("en").friendly_number(1234567) == "1,234,567"
    assert Locale("en").friendly_number(12345678) == "12,345,678"
    assert Locale("en").friendly_number(123456789) == "123,456,789"
    assert Locale("en").friendly

# Generated at 2022-06-18 10:22:33.930392
# Unit test for method pgettext of class Locale