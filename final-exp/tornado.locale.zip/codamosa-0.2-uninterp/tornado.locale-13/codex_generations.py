

# Generated at 2022-06-18 10:14:02.994457
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_date(datetime.datetime(2012, 1, 1)) == "January 1, 2012"
    assert locale.format_date(datetime.datetime(2012, 1, 1), full_format=True) == "January 1, 2012"
    assert locale.format_date(datetime.datetime(2012, 1, 1), relative=False) == "January 1, 2012"
    assert locale.format_date(datetime.datetime(2012, 1, 1), shorter=True) == "January 1, 2012"
    assert locale.format_date(datetime.datetime(2012, 1, 1), gmt_offset=0) == "January 1, 2012"

# Generated at 2022-06-18 10:14:13.508864
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en").friendly_number(1234567890123456789) == "1234567890123456789"
    assert Locale.get("en").friendly_number(0) == "0"
    assert Locale.get("en").friendly_number(-1) == "-1"
    assert Locale.get("en").friendly_number(-1000) == "-1,000"

# Generated at 2022-06-18 10:14:15.269956
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/joe/tornado/tornado/locale", "tornado")


# Generated at 2022-06-18 10:14:21.060603
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:14:24.102451
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/david/Desktop/tornado-6.0.3/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:35.615461
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import doctest
    import sys
    import os
    import shutil
    import tempfile
    import gettext
    from tornado.escape import utf8
    from tornado.util import u

    class LocaleTestCase(unittest.TestCase):
        def setUp(self):
            self.locale_dir = tempfile.mkdtemp()
            self.domain = "test"
            self.locale = "en_US"
            self.locale_dir_en = os.path.join(self.locale_dir, self.locale, "LC_MESSAGES")
            os.makedirs(self.locale_dir_en)
            self.po_file = os.path.join(self.locale_dir_en, self.domain + ".po")

# Generated at 2022-06-18 10:14:38.184478
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yinzhu/Desktop/tornado/tornado/locale/")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:39.825050
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:41.221191
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhangyun/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:43.479277
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jose/Documents/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:19.596544
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # Test case 1
    code = "en"
    translations = {"unknown": {"message": "message"}}
    csv_locale = CSVLocale(code, translations)
    assert csv_locale.translate("message") == "message"
    # Test case 2
    code = "en"
    translations = {"unknown": {"message": "message"}}
    csv_locale = CSVLocale(code, translations)
    assert csv_locale.translate("message", "plural_message", 2) == "plural_message"
    # Test case 3
    code = "en"
    translations = {"unknown": {"message": "message"}}
    csv_locale = CSVLocale(code, translations)

# Generated at 2022-06-18 10:15:30.042737
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:15:38.885556
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    from datetime import datetime
    from datetime import date
    from datetime import time
    from datetime import timedelta
    from datetime import tzinfo
    from datetime import timezone
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import tzinfo
    from datetime import timezone
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import tzinfo
    from datetime import timezone
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import tzinfo
    from datetime import timezone
    from datetime import time
    from datetime import datetime
    from datetime import timedelta

# Generated at 2022-06-18 10:15:49.751596
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:15:53.906725
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    assert CSVLocale("en", {}).translate("hello") == "hello"
    assert CSVLocale("en", {}).translate("hello", "hello") == "hello"
    assert CSVLocale("en", {}).translate("hello", "hello", 1) == "hello"
    assert CSVLocale("en", {}).translate("hello", "hello", 2) == "hello"
    assert CSVLocale("en", {"singular": {"hello": "hi"}}).translate("hello") == "hi"
    assert CSVLocale("en", {"singular": {"hello": "hi"}}).translate("hello", "hello") == "hi"
    assert CSVLocale("en", {"singular": {"hello": "hi"}}).translate("hello", "hello", 1) == "hi"

# Generated at 2022-06-18 10:16:05.956964
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(1) == "1"
    assert Locale("en").friendly_number(10) == "10"
    assert Locale("en").friendly_number(100) == "100"
    assert Locale("en").friendly_number(1000) == "1,000"
    assert Locale("en").friendly_number(10000) == "10,000"
    assert Locale("en").friendly_number(100000) == "100,000"
    assert Locale("en").friendly_number(1000000) == "1,000,000"
    assert Locale("en").friendly_number(10000000) == "10,000,000"
    assert Locale("en").friendly_number(100000000) == "100,000,000"
    assert Locale("en").friendly_number(1000000000)

# Generated at 2022-06-18 10:16:10.366271
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/hongbin/Documents/tornado/tornado/locale/', 'tornado')
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:16:22.647456
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:16:25.190108
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jason/Documents/GitHub/tornado/tornado/locale")
    print(_translations)

# Generated at 2022-06-18 10:16:26.520069
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yuyang/Desktop/test")
    print(_translations)

# Generated at 2022-06-18 10:16:48.868216
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/Documents/GitHub/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:17:00.676147
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A"]) == "A"
    assert Locale.get("en").list([]) == ""
    assert Locale.get("fa").list(["A", "B", "C"]) == "A \u0648 B \u0648 C"
    assert Locale.get("fa").list(["A", "B"]) == "A \u0648 B"
    assert Locale.get("fa").list(["A"]) == "A"
    assert Locale.get("fa").list([]) == ""


# Generated at 2022-06-18 10:17:10.153691
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:17:20.467571
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:17:25.908931
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:17:30.427261
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lizhitao/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:17:40.208197
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import shutil
    import tempfile
    import unittest
    import tornado.locale
    import tornado.testing

    class GettextTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(GettextTest, self).setUp()
            self.locale_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.locale_dir)
            self.domain = "tornado_test"
            self.po_file = os.path.join(self.locale_dir, "en_US.po")

# Generated at 2022-06-18 10:17:48.577352
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import json_decode
    from tornado.web import Application, RequestHandler
    from tornado.ioloop import IOLoop
    from tornado.options import options, define
    from tornado.websocket import WebSocketHandler
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import os
    import sys
    import time
    import logging
    import random
    import string
    import json
    import tornado.testing
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_http

# Generated at 2022-06-18 10:17:59.606647
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:18:10.954432
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import sys
    import os
    import io
    import csv
    import gettext
    import tempfile
    import shutil

    class TestLocale(unittest.TestCase):
        def test_pgettext(self):
            # Setup
            temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 10:18:50.119168
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:19:01.389413
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Test with plural message
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("law", "right", "rights", 2) == "rights"
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("law", "right", "rights", 1) == "right"
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("law", "right", "rights", 0) == "rights"
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("good", "right", "rights", 2) == "rights"
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("good", "right", "rights", 1) == "right"

# Generated at 2022-06-18 10:19:03.281138
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = "./locale")
    print(_translations)


# Generated at 2022-06-18 10:19:07.240248
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/kenneth/Desktop/tornado-6.0.4/tornado/locale/")
    print(_translations)


# Generated at 2022-06-18 10:19:11.117282
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yunfei/tornado_test/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:19:19.977718
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/travis/build/tornadoweb/tornado/tornado/locale/", "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_TW"].gettext("%(name)s liked this")

# Generated at 2022-06-18 10:19:23.617643
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/Users/jianqiang/Desktop/tornado/tornado/locale","tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:19:34.442912
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/ubuntu/tornado-6.0.3/tornado/locale", "tornado")
    print(get("en_US"))
    print(get("zh_CN"))
    print(get("zh_CN").translate("Sign out"))
    print(get("zh_CN").translate("%(name)s liked this", "%(name)s like this", 1))
    print(get("zh_CN").translate("%(name)s liked this", "%(name)s like this", 2))
    print(get("zh_CN").translate("%(name)s liked this", "%(name)s like this", 3))
    print(get("zh_CN").translate("%(name)s liked this", "%(name)s like this", 4))

# Generated at 2022-06-18 10:19:46.385749
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime
    from datetime import datetime

# Generated at 2022-06-18 10:19:53.693498
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import os
    import sys
    import shutil
    import tempfile
    import gettext
    import tornado.locale
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.escape
    import tornado.util
    import tornado.httputil
    import tornado.httpclient
    import tornado.gen
    import tornado.iostream
    import tornado.stack_context
    import tornado.process
    import tornado.netutil
    import tornado.locks
    import tornado.queues
    import tornado.concurrent
    import tornado.log
    import tornado.escape
    import tornado.web
    import tornado.websocket
    import tornado.httputil
    import tornado.http1connection
    import tornado.tcpserver

# Generated at 2022-06-18 10:20:31.036195
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lucas/Documents/tornado_test/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:20:33.065509
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jiajiaxu/Desktop/tornado_test/tornado_test/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:44.533702
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert Locale.get("en").pgettext("context", "message") == "message"
    assert Locale.get("en").pgettext("context", "message", count=1) == "message"
    assert Locale.get("en").pgettext("context", "message", count=2) == "message"
    assert Locale.get("en").pgettext("context", "message", "plural", count=1) == "message"
    assert Locale.get("en").pgettext("context", "message", "plural", count=2) == "plural"
    assert Locale.get("en").pgettext("context", "message", "plural", count=3) == "plural"

# Generated at 2022-06-18 10:20:55.106670
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:20:57.440022
# Unit test for function load_translations
def test_load_translations():
    directory = "./"
    encoding = "utf-8"
    load_translations(directory, encoding)
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:21:07.697854
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:21:16.366111
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"
    assert Locale.get("en").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en").friendly_number(1234567890) == "1,234,567,890"

# Generated at 2022-06-18 10:21:26.766513
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo

# Generated at 2022-06-18 10:21:37.248987
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 22)
    assert locale.format_day(date) == "Tuesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 22"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 22"



# Generated at 2022-06-18 10:21:42.004252
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"
