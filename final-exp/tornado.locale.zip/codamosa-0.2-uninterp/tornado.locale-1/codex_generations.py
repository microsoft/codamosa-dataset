

# Generated at 2022-06-18 10:13:22.424379
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jason/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)
    print(_default_locale)
# test_load_translations()



# Generated at 2022-06-18 10:13:25.392551
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "mydomain"
    load_gettext_translations(directory, domain)
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:13:34.286027
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:13:44.406876
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:13:55.904021
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:13:58.729842
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/yunfei/Desktop/tornado-6.0.4/tornado/locale')
    print(_translations)


# Generated at 2022-06-18 10:14:10.014442
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date, dow=True) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date, dow=True) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"
    locale = Locale.get("zh_CN")
    assert locale.format_day(date, dow=True) == "星期一, 1月1日"

# Generated at 2022-06-18 10:14:18.021052
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.options import options
    options.locale = "en_US"
    locale = Locale.get("en_US")
    assert locale.pgettext("law", "right") == "right"
    assert locale.pgettext("good", "right") == "right"
    assert locale.pgettext("organization", "club", "clubs", len(["club"])) == "club"
    assert locale.pgettext("organization", "club", "clubs", len(["club", "club"])) == "clubs"
    assert locale.pgettext("stick", "club", "clubs", len(["club"])) == "club"
    assert locale.pgettext("stick", "club", "clubs", len(["club", "club"])) == "clubs"



# Generated at 2022-06-18 10:14:29.380870
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo


# Generated at 2022-06-18 10:14:40.015713
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import gettext
    import tornado.locale
    import tornado.testing
    import tornado.test.util

    class GettextTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(GettextTest, self).setUp()
            self.locale_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.locale_dir)
            self.domain = "tornado_test"
            self.locale_code = "es_ES"
            self.locale_path = os.path.join(self.locale_dir, self.locale_code)
            os.makedirs(os.path.join(self.locale_path, "LC_MESSAGES"))


# Generated at 2022-06-18 10:15:01.894716
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=True) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=True) == "星期一, 一月 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "一月 1"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:15:05.267361
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jason/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:14.925314
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.web import RequestHandler
    from tornado.escape import to_unicode
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.web import Application
    from tornado.websocket import WebSocketHandler
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import bind_unused_port
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import os
    import sys
    import time
    import unittest
    import logging
    import json
    import random
    import string
    import tornado.testing

# Generated at 2022-06-18 10:15:17.445802
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./")
    print(_translations)


# Generated at 2022-06-18 10:15:20.716203
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jason/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:24.451091
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yuan/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:34.091277
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:15:40.604262
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    locale = Locale("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:15:42.875536
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test for format_date
    # test for format_day
    # test for list
    # test for friendly_number
    pass



# Generated at 2022-06-18 10:15:47.930270
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:16:17.146587
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import pytest
    from tornado.escape import to_unicode
    from tornado.util import unicode_type
    from tornado.util import _unicode
    from tornado.util import _U
    from tornado.util import _bytes_type
    from tornado.util import _str_type
    from tornado.util import _PY3
    from tornado.util import _unicode_type
    from tornado.util import _basestring_type
    from tornado.util import _unicode
    from tornado.util import _U
    from tornado.util import _bytes_type
    from tornado.util import _str_type
    from tornado.util import _PY3
    from tornado.util import _unicode_type
    from tornado.util import _basestring_type
    from tornado.util import _unicode
    from tornado.util import _U

# Generated at 2022-06-18 10:16:27.582550
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo

# Generated at 2022-06-18 10:16:39.037352
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:16:47.637923
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.locale import load_gettext_translations
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.web import Application
    from tornado.websocket import WebSocketHandler
    from tornado.ioloop import IOLoop
    import os
    import gettext
    import tornado.locale
    import tornado.web
    import tornado.websocket
    import tornado.ioloop
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:16:56.643678
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:16:58.016955
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yuan/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:17:05.693365
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:17:08.912230
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/tianyuan/tornado-6.0.3/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:17:11.300212
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/joe/tornado/tornado/locale")


# Generated at 2022-06-18 10:17:20.473989
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    import datetime
    from tornado.options import options
    options.parse_command_line()
    load_translations(os.path.join(os.path.dirname(__file__), "translations"))
    locale = Locale.get("en")
    assert locale.format_date(time.time()) == "1 second ago"
    assert locale.format_date(time.time() - 30) == "30 seconds ago"
    assert locale.format_date(time.time() - 60) == "1 minute ago"
    assert locale.format_date(time.time() - 120) == "2 minutes ago"
    assert locale.format_date(time.time() - 60 * 60) == "1 hour ago"

# Generated at 2022-06-18 10:18:31.279274
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:18:39.997839
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import datetime
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import datetime
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import datetime
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta

# Generated at 2022-06-18 10:18:51.284863
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en").friendly_number(1234567890123456789) == "1234567890123456789"
    assert Locale.get("en").friendly_number(0) == "0"
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(10) == "10"
    assert Locale.get("en").friendly_number(100) == "100"

# Generated at 2022-06-18 10:18:58.696343
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:19:07.659387
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.util import _
    from tornado.locale import load_gettext_translations, GettextLocale
    import gettext
    import os
    import tempfile
    import unittest

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create temporary files
    temp_files = []
    # Create temporary file with translations
    temp_file = tempfile.NamedTemporaryFile(
        mode="w", dir=temp_dir, suffix=".mo", delete=False
    )
    temp_files.append(temp_file)
    # Write translations to temporary file

# Generated at 2022-06-18 10:19:17.671073
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:19:23.416525
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # Test for Arabic
    locale = Locale.get("ar")
    assert locale.format_day(date) == "\u0627\u0644\u0627\u062b\u0646\u064a\u0646, \u064a\u0646\u0627\u064a\u0631 22"
    assert locale.format_day(date, dow=False) == "\u064a\u0646\u0627\u064a\u0631 22"
    # Test for

# Generated at 2022-06-18 10:19:34.236320
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import tornado.locale
    import tornado.testing
    import tornado.web
    import tornado.wsgi
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.wsgi
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.util
    import tornado.testing
    import tornado.web
    import tornado.wsgi
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.util
    import tornado.testing
    import tornado.web
    import tornado.wsgi
    import tornado.httpserver
    import tornado.ioloop
   

# Generated at 2022-06-18 10:19:45.714802
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 1月1日"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "1月1日"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:19:48.731026
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/lzj/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:56.441950
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["zh_CN"]
    assert _translations["en_US"]
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _supported_locales == frozenset(["zh_CN", "en_US"])
    assert _use_gettext == True
    assert _default_locale == "en_US"
    assert get("zh_CN").translate("Sign out") == "退出"
    assert get("en_US").translate("Sign out") == "Sign out"

# Generated at 2022-06-18 10:21:06.710617
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:21:09.576346
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/Desktop/tornado_test/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:21:11.933563
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunpeng/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:21:20.818375
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jeff/tornado-5.1.1/tornado/locale/", "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_MO"].gettext("Sign out") == "登出"
    assert _translations["zh_SG"].gettext("Sign out") == "登出"

# Generated at 2022-06-18 10:21:31.809455
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date, dow=True) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date, dow=True) == "\u0634\u0646\u0628\u0647, \u0698\u0627\u0646\u0648\u06cc\u0647 1"
    assert locale.format_day(date, dow=False) == "\u0698\u0627\u0646\u0648\u06cc\u0647 1"


# Generated at 2022-06-18 10:21:42.113559
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import json_decode
    from tornado.options import options
    from tornado.log import enable_pretty_logging
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application
    from tornado.websocket import WebSocketHandler
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import url_concat
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
   

# Generated at 2022-06-18 10:21:44.274760
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:21:47.437793
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jian/Desktop/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:21:56.775880
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """
    Test for method format_date of class Locale
    """
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale
    # Test for method format_date of class Locale