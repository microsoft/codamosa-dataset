

# Generated at 2022-06-18 10:13:09.164467
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:13:17.603352
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_MO"].gettext("Sign out") == "登出"
    assert _translations["zh_SG"].gettext("Sign out") == "登出"

# Generated at 2022-06-18 10:13:26.793242
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    csv_locale = CSVLocale(code="en", translations={})
    assert csv_locale.translate(message="test") == "test"
    assert csv_locale.translate(message="test", plural_message="tests", count=1) == "test"
    assert csv_locale.translate(message="test", plural_message="tests", count=2) == "tests"
    assert csv_locale.translate(message="test", plural_message="tests", count=0) == "tests"
    assert csv_locale.translate(message="test", plural_message="tests", count=None) == "test"
    assert csv_locale.translate(message="test", plural_message="tests") == "test"

# Generated at 2022-06-18 10:13:33.475853
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:13:43.800384
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "2019\u5e741\u67081\u65e5\u5468\u4e8c"
    assert locale.format_day(date, dow=False) == "2019\u5e741\u67081\u65e5"
    # Test for Persian
    locale = Locale.get("fa")


# Generated at 2022-06-18 10:13:54.858461
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:14:06.411028
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale.get("en")
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A and B"
    assert locale.list(["A", "B", "C"]) == "A, B and C"
    assert locale.list(["A", "B", "C", "D"]) == "A, B, C and D"
    assert locale.list(["A", "B", "C", "D", "E"]) == "A, B, C, D and E"
    assert locale.list(["A", "B", "C", "D", "E", "F"]) == "A, B, C, D, E and F"

# Generated at 2022-06-18 10:14:07.825505
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/lucas/Documents/tornado-6.0.3/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:10.597124
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/hongbin/PycharmProjects/tornado-5.1.1/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:12.772155
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:14:50.276452
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 22)) == "Monday, January 22"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 22), dow=False) == "January 22"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 22)) == "یکشنبه، ژانویه 22"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 22), dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:14:59.549171
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    from . import Locale
    Locale.load_translations(os.path.join(os.path.dirname(__file__), "translations"))
    locale = Locale.get("en")
    assert locale.pgettext("context", "message") == "message"
    assert locale.pgettext("context", "message", "plural message", 1) == "message"
    assert locale.pgettext("context", "message", "plural message", 2) == "plural message"
    assert locale.pgettext("context", "message", "plural message", 0) == "plural message"
    assert locale.pgettext("context", "message", "plural message", 5) == "plural message"
    assert locale.pgettext("context", "message", "plural message", 100) == "plural message"

# Generated at 2022-06-18 10:15:03.281684
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yue/Desktop/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:15:07.444268
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jimmy/tornado-5.1.1/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:15.065278
# Unit test for function load_translations
def test_load_translations():
    import os
    import tempfile
    import unittest
    import tornado.testing

    class LoadTranslationsTest(tornado.testing.AsyncTestCase):
        def test_load_translations(self):
            with tempfile.TemporaryDirectory() as tmpdir:
                with open(os.path.join(tmpdir, "es_LA.csv"), "w") as f:
                    f.write('"I love you","Te amo"\n')
                    f.write('"%(name)s liked this","A %(name)s les gustó esto","plural"\n')
                    f.write('"%(name)s liked this","A %(name)s le gustó esto","singular"\n')
                load_translations(tmpdir)
                es_la = get("es_LA")
                self

# Generated at 2022-06-18 10:15:26.534462
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:15:29.493871
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jiaxin/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:31.530645
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/shen/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:15:33.523492
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jose/Documents/tornado/tornado/locale/")
    print(_translations)


# Generated at 2022-06-18 10:15:36.614620
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/zhaoyu/tornado/tornado/locale/', 'tornado')
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:16:01.549861
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:16:04.388582
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jason/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:16:16.883871
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import gettext
    import tornado.locale
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.options
    import tornado.escape
    import tornado.log
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.iostream
    import tornado.stack_context
    import tornado.locks
    import tornado.gen
    import tornado.concurrent
    import tornado.queues
    import tornado.ioloop
    import tornado.iostream
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.simple_httpclient
    import tornado.curl_httpclient
    import tornado.queues
    import tornado

# Generated at 2022-06-18 10:16:19.447817
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = "./locale")
    print(_translations)


# Generated at 2022-06-18 10:16:22.596632
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfei/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:16:29.865739
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    import datetime
    from tornado.testing import AsyncTestCase, gen_test

    class TestLocale(AsyncTestCase):
        def setUp(self):
            super(TestLocale, self).setUp()
            load_translations(os.path.join(os.path.dirname(__file__), "translations"))

        @gen_test
        def test_format_date(self):
            locale = Locale.get("en")
            now = time.time()
            self.assertEqual(locale.format_date(now), "just now")
            self.assertEqual(locale.format_date(now - 1), "1 second ago")
            self.assertEqual(locale.format_date(now - 30), "30 seconds ago")

# Generated at 2022-06-18 10:16:33.324629
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:16:43.261905
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import date
    from datetime import time

# Generated at 2022-06-18 10:16:48.002436
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    assert _translations["zh_CN"] == gettext.translation(domain="tornado", languages=["zh_CN"], localedir="./locale")
    assert _supported_locales == frozenset(["zh_CN"])
    assert _use_gettext == True
    gen_log.debug("Supported locales: %s", sorted(_supported_locales))


# Generated at 2022-06-18 10:16:59.812498
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_MO"].gettext("Sign out") == "登出"
    assert _translations["zh_SG"].gettext("Sign out") == "登出"

# Generated at 2022-06-18 10:17:20.834074
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:17:22.564875
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/michael/Desktop/tornado-master/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:34.178296
# Unit test for method list of class Locale
def test_Locale_list():
    # Test for empty list
    assert Locale.get("en").list([]) == ""
    # Test for list of size 1
    assert Locale.get("en").list(["A"]) == "A"
    # Test for list of size 2
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    # Test for list of size 3
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    # Test for list of size 4
    assert Locale.get("en").list(["A", "B", "C", "D"]) == "A, B, C and D"
    # Test for list of size 5

# Generated at 2022-06-18 10:17:40.852745
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:17:43.406807
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jian/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:17:49.098425
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    import pytz
    from tornado.util import ObjectDict
    from tornado.escape import to_unicode
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import get_all_templates
    from zerver.lib.timezone import get_timezone
    from zerver.lib.timezone import get_timezone_name
    from zerver.lib.timezone import get_timezone_abbreviation
    from zerver.lib.timezone import get_timezone_offset
    from zerver.lib.timezone import get_timezone_offset_in_minutes
    from zerver.lib.timezone import get_timezone_offset_in_seconds

# Generated at 2022-06-18 10:18:00.187627
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:18:02.870771
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yue/Desktop/tornado/tornado/locale/")
    print(_translations)


# Generated at 2022-06-18 10:18:12.619293
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u0698\u0627\u0646\u0648\u06cc\u0647 1"
    assert locale.format_day(date, dow=False) == "\u0698\u0627\u0646\u0648\u06cc\u0647 1"


# Generated at 2022-06-18 10:18:14.193829
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # TODO: Add unit test for function load_gettext_translations
    pass



# Generated at 2022-06-18 10:19:01.521772
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import tornado.locale
    import tornado.testing
    import tornado.util
    import tornado.web

    class GettextTest(tornado.testing.AsyncHTTPTestCase):
        def setUp(self):
            super(GettextTest, self).setUp()
            self.locale_path = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.locale_path)
            self.domain = "tornado_test"
            self.pot_path = os.path.join(self.locale_path, "messages.pot")
            self.po_path = os.path.join(self.locale_path, "messages.po")

# Generated at 2022-06-18 10:19:08.869560
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
    Test for method format_day of class Locale
    """
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale

# Generated at 2022-06-18 10:19:18.485202
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:19:25.932138
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["unknown"]["Sign out"] == "Sign out"
    assert _translations["es_LA"]["unknown"]["Sign out"] == "Salir"
    assert _translations["es_LA"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"
    assert _translations["es_LA"]["singular"]["%(name)s liked this"] == "A %(name)s le gustó esto"


# Generated at 2022-06-18 10:19:37.245893
# Unit test for method list of class Locale
def test_Locale_list():
    # Test for empty list
    assert Locale.get("en").list([]) == ""
    # Test for list of size 1
    assert Locale.get("en").list(["A"]) == "A"
    # Test for list of size 2
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    # Test for list of size 3
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    # Test for list of size 4
    assert Locale.get("en").list(["A", "B", "C", "D"]) == "A, B, C and D"
    # Test for list of size 5

# Generated at 2022-06-18 10:19:49.262660
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test case 1
    # Input:
    #   date = datetime.datetime(2018, 7, 10, 10, 10, 10)
    #   gmt_offset = 0
    #   relative = True
    #   shorter = False
    #   full_format = False
    # Expected output:
    #   "July 10, 2018 at 10:10"
    date = datetime.datetime(2018, 7, 10, 10, 10, 10)
    gmt_offset = 0
    relative = True
    shorter = False
    full_format = False
    assert Locale.get("en").format_date(date, gmt_offset, relative, shorter, full_format) == "July 10, 2018 at 10:10"

    # Test case 2
    # Input:
    #   date = datetime.datetime(2018

# Generated at 2022-06-18 10:19:55.880108
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"


# Generated at 2022-06-18 10:20:08.109634
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:20:15.438216
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale.get("en")
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A and B"
    assert locale.list(["A", "B", "C"]) == "A, B and C"
    assert locale.list(["A", "B", "C", "D"]) == "A, B, C and D"
    assert locale.list(["A", "B", "C", "D", "E"]) == "A, B, C, D and E"

    locale = Locale.get("fa")
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A \u0648 B"

# Generated at 2022-06-18 10:20:22.898352
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _translations["zh_CN"]
    assert _translations["en_US"]
    assert _translations["zh_CN"].gettext("Tornado Server") == "Tornado 服务器"
    assert _translations["en_US"].gettext("Tornado Server") == "Tornado Server"
    assert _supported_locales == frozenset(["zh_CN", "en_US"])
    assert _use_gettext == True
