

# Generated at 2022-06-18 10:13:17.112061
# Unit test for method translate of class GettextLocale

# Generated at 2022-06-18 10:13:25.629568
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 22"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 22"


# Generated at 2022-06-18 10:13:34.541173
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for method format_date(self, date, gmt_offset, relative, shorter, full_format)
    # of class Locale
    # test for en_US
    locale = Locale.get("en_US")
    date = datetime.datetime.utcnow()
    assert locale.format_date(date) == "just now"
    assert locale.format_date(date, relative=False) == "just now"
    assert locale.format_date(date, shorter=True) == "just now"
    assert locale.format_date(date, full_format=True) == "just now"
    assert locale.format_date(date, gmt_offset=0) == "just now"
    assert locale.format_date(date, gmt_offset=0, relative=False) == "just now"

# Generated at 2022-06-18 10:13:37.304948
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/lixiaoyu/Desktop/tornado-master/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:13:39.099914
# Unit test for function load_translations
def test_load_translations():
    load_translations("../../locale")
    print(_translations)


# Generated at 2022-06-18 10:13:49.329422
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A"]) == "A"
    assert Locale.get("en").list([]) == ""
    assert Locale.get("fa").list(["A", "B", "C"]) == "A \u0648 B \u0648 C"
    assert Locale.get("fa").list(["A", "B"]) == "A \u0648 B"
    assert Locale.get("fa").list(["A"]) == "A"
    assert Locale.get("fa").list([]) == ""


# Generated at 2022-06-18 10:14:01.436387
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    # Test case 1
    # Input:
    #   message = 'test'
    #   plural_message = None
    #   count = None
    # Expected output:
    #   'test'
    assert GettextLocale('en', gettext.NullTranslations()).translate('test') == 'test'

    # Test case 2
    # Input:
    #   message = 'test'
    #   plural_message = 'tests'
    #   count = 2
    # Expected output:
    #   'tests'
    assert GettextLocale('en', gettext.NullTranslations()).translate('test', 'tests', 2) == 'tests'

    # Test case 3
    # Input:
    #   message = 'test'
    #   plural_message = 'tests'
    #   count = 1


# Generated at 2022-06-18 10:14:12.177349
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:14:13.773959
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = "./locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:19.565853
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"

    # Test for Persian
    locale = Locale.get("fa")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "یکشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"



# Generated at 2022-06-18 10:14:39.961494
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _translations["zh_CN"]
    assert _translations["en_US"]
    assert _supported_locales == frozenset(["en_US", "zh_CN"])
    assert _use_gettext == True


# Generated at 2022-06-18 10:14:47.748250
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:14:53.015810
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/michael/tornado/tornado/locale", "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"

# Generated at 2022-06-18 10:14:55.514027
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhangyun/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:00.875674
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "دوشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:15:03.918223
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/zhaoyang/tornado-5.1.1/tornado/locale/", "tornado")


# Generated at 2022-06-18 10:15:07.712801
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:16.197110
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"

# Generated at 2022-06-18 10:15:25.608516
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:15:35.169133
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """Test the format_day method of the Locale class"""
    from datetime import datetime
    from tornado.testing import AsyncTestCase
    from tornado.testing import gen_test
    from tornado.testing import main
    from tornado.testing import LogTrapTestCase

    class LocaleTest(AsyncTestCase, LogTrapTestCase):
        """Test the format_day method of the Locale class"""
        @gen_test
        def test_format_day(self):
            """Test the format_day method of the Locale class"""
            from zerver.lib.locale import Locale
            from zerver.lib.locale import LOCALE_NAMES
            from zerver.lib.locale import load_translations
            from zerver.lib.test_classes import ZulipTestCase

# Generated at 2022-06-18 10:16:01.370457
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 一月 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "一月 1"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:16:13.187899
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time

# Generated at 2022-06-18 10:16:15.770377
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    print(_translations)


# Generated at 2022-06-18 10:16:18.367078
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jiaxin/Desktop/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:28.118890
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for format_date method of class Locale
    # Test for the case that date is in the future
    date = datetime.datetime.utcnow() + datetime.timedelta(days=1)
    assert Locale.get("en").format_date(date) == "1 day from now"
    assert Locale.get("en").format_date(date, full_format=True) == "1 day from now"
    assert Locale.get("en").format_date(date, relative=False) == "1 day from now"
    assert Locale.get("en").format_date(date, shorter=True) == "1 day from now"
    assert Locale.get("en").format_date(date, gmt_offset=1) == "1 day from now"
    # Test for the case that date is in the

# Generated at 2022-06-18 10:16:30.709878
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    print(_translations)


# Generated at 2022-06-18 10:16:33.419503
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfeng/Desktop/tornado-master/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:16:36.333839
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yunfei/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:16:45.543285
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import subprocess
    import tornado.locale
    import tornado.testing
    import tornado.web

    class TestHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(self.locale.translate("Hello, world!"))

    class TestLocale(tornado.testing.AsyncHTTPTestCase):
        def setUp(self):
            super(TestLocale, self).setUp()
            self.locale_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.locale_dir)
            self.domain = "tornado_test"
            self.pot_file = os.path.join(self.locale_dir, self.domain + ".pot")
            self.po_

# Generated at 2022-06-18 10:16:57.684893
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:17:20.534290
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 赞了这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 赞了这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 赞了这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 赞了这个"

# Generated at 2022-06-18 10:17:31.650568
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="../locale", domain="tornado")
    assert _translations["zh_CN"]
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this")

# Generated at 2022-06-18 10:17:41.342030
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    from tornado.testing import AsyncTestCase, gen_test
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.options
    import tornado.escape
    import tornado.httputil
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado

# Generated at 2022-06-18 10:17:44.733173
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _translations != {}
    assert _supported_locales != {}
    assert _use_gettext == True
    assert _default_locale == "en_US"


# Generated at 2022-06-18 10:17:45.909835
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)


# Generated at 2022-06-18 10:17:48.576344
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:17:51.674673
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test for method pgettext(self, context, message, plural_message=None, count=None)
    # of class Locale
    assert True # TODO: implement your test here


# Generated at 2022-06-18 10:17:53.631890
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jason/tornado/tornado/locale", "tornado")


# Generated at 2022-06-18 10:17:57.263773
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyang/Desktop/tornado_test/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:59.969805
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/xu/Desktop/tornado-5.1.1/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:18:16.865651
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yunfei/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:18:28.296176
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/travis/build/tornadoweb/tornado/tornado/locale", "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"

# Generated at 2022-06-18 10:18:29.388112
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:18:36.752314
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:18:47.355448
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:18:49.752761
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyang/Desktop/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)



# Generated at 2022-06-18 10:18:52.306222
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/sarath/tornado/tornado/locale", "tornado")


# Generated at 2022-06-18 10:19:03.237520
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:19:14.987445
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:19:16.319595
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)


# Generated at 2022-06-18 10:19:32.639166
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yunfei/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:19:43.835660
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    from tornado.options import options
    options.locale = "en_US"
    load_translations(os.path.join(os.path.dirname(__file__), "translations"))
    locale = Locale.get("en_US")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"
    options.locale = "zh_CN"
    load_translations(os.path.join(os.path.dirname(__file__), "translations"))
    locale = Locale.get("zh_CN")

# Generated at 2022-06-18 10:19:52.295601
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2020, 1, 22)
    assert locale.format_day(date) == "Wednesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # Test for Persian
    locale = Locale.get("fa")
    date = datetime.datetime(2020, 1, 22)
    assert locale.format_day(date) == "چهارشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"



# Generated at 2022-06-18 10:20:04.294964
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:20:06.574525
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/usr/share/locale", "tornado")


# Generated at 2022-06-18 10:20:09.141737
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianan/Documents/GitHub/tornado-demo/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:11.820185
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory='/Users/jianghao/Desktop/tornado_test/locale', domain='messages')
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:20:22.711833
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_date(datetime.datetime.utcnow()) == "just now"
    assert locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=1)) == "1 second ago"
    assert locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=2)) == "2 seconds ago"
    assert locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=59)) == "59 seconds ago"
    assert locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=60)) == "1 minute ago"

# Generated at 2022-06-18 10:20:30.611549
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2020, 1, 22)
    assert locale.format_day(date) == "Wednesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "چهارشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:20:40.822853
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for the case of dow = True
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1), dow = True) == "Tuesday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 2), dow = True) == "Wednesday, January 2"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 3), dow = True) == "Thursday, January 3"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 4), dow = True) == "Friday, January 4"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 5), dow = True) == "Saturday, January 5"
    assert Loc

# Generated at 2022-06-18 10:21:21.191886
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = os.path.join(os.path.dirname(__file__), "locale")
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢了这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢了这个"

# Generated at 2022-06-18 10:21:32.816601
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:21:42.722393
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:21:44.427830
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/lizhe/Desktop/tornado/tornado/locale")
    print(_translations)

# Generated at 2022-06-18 10:21:50.976868
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2019, 5, 1)
    assert locale.format_day(date) == "Wednesday, May 1"
    assert locale.format_day(date, dow=False) == "May 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "چهارشنبه، مه 1"
    assert locale.format_day(date, dow=False) == "مه 1"


# Generated at 2022-06-18 10:22:00.297326
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # test for locale en
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # test for locale fa
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"
    # test for locale zh_CN
    locale = Locale.get("zh_CN")
    assert locale.format_day(date) == "星期一, 一月 22"

# Generated at 2022-06-18 10:22:09.073087
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import os
    import sys
    import csv
    import gettext
    import datetime
    import tornado.escape
    import tornado.util
    import tornado.options
    import tornado.log
    import tornado.locale
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.web
    import tornado.websocket
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.iostream
    import tornado.locks
    import tornado.gen
    import tornado.stack_context
    import tornado.concurrent
    import tornado.queues
    import tornado.simple_httpclient
    import tornado.curl_httpclient
    import tornado.tcpserver
    import tornado.tcpclient

# Generated at 2022-06-18 10:22:15.404731
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(os.path.join(os.path.dirname(__file__), "locale"), "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s赞了这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s赞了这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s赞了这个"

# Generated at 2022-06-18 10:22:17.214954
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    print(_translations)


# Generated at 2022-06-18 10:22:19.973265
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfei/Desktop/tornado-6.0.3/tornado/locale")
    print(_translations)
