

# Generated at 2022-06-18 10:14:12.490756
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/shen/Documents/GitHub/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:19.414603
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 12, 31)
    assert locale.format_day(date) == "Tuesday, December 31"
    assert locale.format_day(date, dow=False) == "December 31"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2019, 12, 31)
    assert locale.format_day(date) == "2019\u5e7412\u670831\u65e5"
    assert locale.format_day(date, dow=False) == "2019\u5e7412\u670831\u65e5"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:14:31.021996
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    print(get("zh_CN").translate("Sign out"))
    print(get("zh_CN").translate("%(name)s liked this", name="张三"))
    print(get("zh_CN").translate("%(name)s liked this", name="张三,李四"))
    print(get("zh_CN").translate("%(name)s liked this", name="张三,李四,王五"))
    print(get("zh_CN").translate("%(name)s liked this", name="张三,李四,王五,赵六"))

# Generated at 2022-06-18 10:14:41.130703
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import subprocess
    import tornado.locale
    import tornado.testing
    import tornado.web
    import tornado.wsgi
    import unittest

    class TestHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(self.locale.translate("Hello"))

    class TestApp(tornado.web.Application):
        def __init__(self, locale_path):
            tornado.web.Application.__init__(self, [("/", TestHandler)])
            tornado.locale.load_gettext_translations(locale_path, "tornado_test")


# Generated at 2022-06-18 10:14:48.519022
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import gettext
    import tornado.locale
    import tornado.testing

    def _make_mo(lang, msgid, msgstr):
        # type: (str, str, str) -> str
        """Generate a .mo file in a temp directory.

        Returns the path to the .mo file.
        """
        # Based on the implementation of gettext.GNUTranslations.__init__
        # (Python 2.7.5).
        import struct
        import array

        directory = tempfile.mkdtemp()

# Generated at 2022-06-18 10:14:56.172887
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:14:58.543220
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/Desktop/tornado_test/test_locale")
    print(_translations)
    print(_supported_locales)
# test_load_translations()



# Generated at 2022-06-18 10:15:09.316242
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2020, 1, 22)
    assert locale.format_day(date) == "Wednesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "Wednesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("zh_CN")
    assert locale.format_day(date) == "Wednesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"


# Generated at 2022-06-18 10:15:16.407902
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["unknown"]["Sign out"] == "Sign out"
    assert _translations["es_LA"]["unknown"]["Sign out"] == "Cerrar sesión"
    assert _translations["es_LA"]["unknown"]["%(name)s liked this"] == "A %(name)s le gustó esto"
    assert _translations["es_LA"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"
    assert _supported_locales == frozenset(["en_US", "es_LA"])


# Generated at 2022-06-18 10:15:27.300015
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test case 1
    date = datetime.datetime(2018, 1, 1)
    gmt_offset = 0
    dow = True
    locale = Locale.get("en")
    assert locale.format_day(date, gmt_offset, dow) == "Monday, January 1"
    # Test case 2
    date = datetime.datetime(2018, 1, 1)
    gmt_offset = 0
    dow = False
    locale = Locale.get("en")
    assert locale.format_day(date, gmt_offset, dow) == "January 1"
    # Test case 3
    date = datetime.datetime(2018, 1, 1)
    gmt_offset = 0
    dow = True
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:15:58.350811
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:16:10.485296
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    assert Locale.get("zh_CN").format_day(datetime.datetime(2018, 1, 1)) == "星期一, 一月 1"
    assert Locale.get("zh_CN").format_day(datetime.datetime(2018, 1, 1), dow=False) == "一月 1"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 1)) == "دوشنبه، ژانویه 1"

# Generated at 2022-06-18 10:16:22.749635
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("locale", "tornado")
    assert _translations["zh_CN"]
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s喜欢这个"

# Generated at 2022-06-18 10:16:29.909628
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import gettext
    import tornado.locale
    import tornado.testing
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.options
    import tornado.escape
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.iostream
    import tornado.log
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted

# Generated at 2022-06-18 10:16:40.210228
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import unittest
    import tornado.locale
    import tornado.testing

    class GettextTest(tornado.testing.AsyncTestCase):
        def test_gettext(self):
            tornado.locale.load_gettext_translations(
                os.path.join(os.path.dirname(__file__), "testdata"), "tornado_test"
            )
            self.assertEqual(tornado.locale.get("pt_BR").translate("Hello"), "Oi")
            self.assertEqual(tornado.locale.get("pt_BR").translate("Hello %(name)s", name="Ben"), "Oi Ben")

# Generated at 2022-06-18 10:16:48.376974
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:17:00.209868
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="../locale", domain="tornado")
    assert _translations["zh_CN"].gettext("Hello") == "你好"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"

# Generated at 2022-06-18 10:17:09.813596
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine
    from tornado.escape import to_unicode
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import tornado_redirected_to_list
    from zerver.lib.test_runner import slow
    from zerver.lib.timezone import get_timezone
    from zerver.lib.timezone import timezone_to_utc
    from zerver.lib.timezone import utc_to_timezone
    from zerver.lib.timezone import get_all_timezones
    from zerver.lib.timezone import get_all_time

# Generated at 2022-06-18 10:17:19.100373
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    import pytz
    from tornado.options import options
    options.locale = "en_US"
    load_translations("translations")
    locale = Locale.get("en_US")
    assert locale.format_date(datetime.datetime(2012, 1, 1)) == "January 1, 2012"
    assert locale.format_date(datetime.datetime(2012, 1, 1, 1, 1)) == "January 1, 2012 at 1:01am"
    assert locale.format_date(datetime.datetime(2012, 1, 1, 1, 1), full_format=True) == "January 1, 2012 at 1:01am"

# Generated at 2022-06-18 10:17:30.658350
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import tempfile
    import unittest
    import warnings
    import tornado.locale
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.wsgi
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.common
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.epoll
   

# Generated at 2022-06-18 10:18:22.714051
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "星期二, 1月1日"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "1月1日"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:18:25.716117
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfei/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:18:34.451347
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class TestGettextLocale(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
            super().__init__(code, translations)
    class TestTranslations(gettext.NullTranslations):
        def __init__(self, fp=None):
            super().__init__(fp)

# Generated at 2022-06-18 10:18:43.882849
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 1"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 1"


# Generated at 2022-06-18 10:18:54.127820
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:18:57.191099
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/jason/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:19:06.624432
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo

# Generated at 2022-06-18 10:19:16.853789
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    def test_format_date(locale_code, date, gmt_offset, relative, shorter, full_format, expected):
        locale = Locale.get(locale_code)
        result = locale.format_date(date, gmt_offset, relative, shorter, full_format)
        assert result == expected, "Locale.format_date(%s, %s, %s, %s, %s, %s) returned %s, expected %s" % (
            repr(date), gmt_offset, relative, shorter, full_format, repr(expected), repr(result), repr(expected))

    # Test cases for Locale.format_date
    test_format_date("en", datetime.datetime(2012, 1, 1, 0, 0, 0), 0, True, False, False, "January 1, 2012")
   

# Generated at 2022-06-18 10:19:19.366148
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yuanzhu/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:19:22.057144
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/david/Documents/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:20:29.166940
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/khanh/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:39.141853
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(os.path.join(os.path.dirname(__file__), "locale"), "tornado")
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"

# Generated at 2022-06-18 10:20:49.845005
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "2019年1月1日"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "2019年1月1日"
    # Test for Arabic
    locale = Locale.get("ar")

# Generated at 2022-06-18 10:20:59.573426
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(0) == "0"
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"

# Generated at 2022-06-18 10:21:09.576930
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "2018\u5e74 1\u6708 1\u65e5"
    assert locale.format_day(date, dow=False) == "2018\u5e74 1\u6708 1\u65e5"


# Generated at 2022-06-18 10:21:17.202209
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    import pytz
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import json_decode
    from tornado.options import options
    from . import main
    from . import util
    from . import test
    from . import app_log
    from . import gen_log
    from . import db
    from . import auth
    from . import model
    from . import i18n
    from . import mail
    from . import cache
    from . import rate_limit
    from . import stats
    from . import search
    from . import oauth
    from . import stripe
    from . import github
    from . import gitlab
    from . import bitbucket
    from . import twitter
   

# Generated at 2022-06-18 10:21:27.800846
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "2018\u5e741\u67081\u65e5\u5468\u4e00"
    assert locale.format_day(date, dow=False) == "2018\u5e741\u67081\u65e5"
    # Test for Arabic
    locale = Locale.get("ar")
   

# Generated at 2022-06-18 10:21:32.187436
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jason/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:21:42.431207
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert Locale.get("en").pgettext("context", "message") == "message"
    assert Locale.get("en").pgettext("context", "message", count=1) == "message"
    assert Locale.get("en").pgettext("context", "message", count=2) == "message"
    assert Locale.get("en").pgettext("context", "message", "plural", count=1) == "message"
    assert Locale.get("en").pgettext("context", "message", "plural", count=2) == "plural"
    assert Locale.get("en").pgettext("context", "message", "plural", count=3) == "plural"

# Generated at 2022-06-18 10:21:51.575408
# Unit test for method format_date of class Locale