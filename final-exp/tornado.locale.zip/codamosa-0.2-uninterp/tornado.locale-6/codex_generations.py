

# Generated at 2022-06-18 10:13:45.490830
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:13:49.268443
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyang/PycharmProjects/tornado_test/test_tornado/test_locale/test_locale_data")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:01.283613
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:14:12.041744
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:14:22.616825
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    import datetime
    import pytz
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import url_concat
    from tornado.escape import json_decode
    from tornado.options import options
    from . import util
    from .util import _
    from . import locale
    from .locale import Locale
    from .locale import get_supported_locales
    from .locale import load_translations
    from .locale import load_gettext_translations
    from .locale import get_closest_locale
    from .locale import get_closest_supported_locale
    from .locale import get_locale


# Generated at 2022-06-18 10:14:33.588578
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "2019\u5e741\u670801\u65e5"
    assert locale.format_day(date, dow=False) == "2019\u5e741\u670801\u65e5"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:14:43.519729
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:14:50.145332
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:14:59.548115
# Unit test for method translate of class CSVLocale

# Generated at 2022-06-18 10:15:03.676250
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jian/Desktop/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:16:06.529328
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2017, 1, 1)) == "Sunday, January 1"
    assert locale.format_day(datetime.datetime(2017, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2017, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2017, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:16:19.494514
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    assert Locale.get("en").format_date(datetime.datetime(2017, 1, 1)) == "January 1, 2017"
    assert Locale.get("en").format_date(datetime.datetime(2017, 1, 1), relative=False) == "January 1, 2017"
    assert Locale.get("en").format_date(datetime.datetime(2017, 1, 1), full_format=True) == "January 1, 2017"
    assert Locale.get("en").format_date(datetime.datetime(2017, 1, 1), relative=False, full_format=True) == "January 1, 2017"
    assert Locale.get("en").format_date(datetime.datetime(2017, 1, 1), shorter=True) == "January 1"
    assert Locale.get("en").format_date

# Generated at 2022-06-18 10:16:23.453278
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/jianghao/Desktop/tornado-master/tornado/locale')
    print(_translations)
    print(_supported_locales)

# test_load_translations()



# Generated at 2022-06-18 10:16:30.006561
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:16:40.299428
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:16:48.432058
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:16:50.820420
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfei/Desktop/tornado/tornado/locale/")
    print(_translations)


# Generated at 2022-06-18 10:16:52.904323
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yuan/Documents/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:17:05.106415
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:17:12.666144
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert Locale.get("zh_CN").format_day(datetime.datetime(2019, 1, 1)) == "2019\u5e741\u6708 1\u65e5"
    assert Locale.get("zh_CN").format_day(datetime.datetime(2019, 1, 1), dow=False) == "2019\u5e741\u6708 1\u65e5"


# Generated at 2022-06-18 10:18:44.218985
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyang/Desktop/tornado-6.0.4/tornado/locale/")
    print(_translations)


# Generated at 2022-06-18 10:18:54.477882
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:19:05.201409
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test for the case when the context is not present in the translation
    # dictionary
    translation_dict = {
        "context1": {
            "singular": "translation1",
            "plural": "translation2",
        },
        "context2": {
            "singular": "translation3",
            "plural": "translation4",
        },
    }
    locale = CSVLocale("en", translation_dict)
    assert locale.pgettext("context3", "singular") == "singular"
    assert locale.pgettext("context3", "singular", "plural", 1) == "singular"
    assert locale.pgettext("context3", "singular", "plural", 2) == "plural"
    # Test for the case when the context is present in the translation
    # dictionary
   

# Generated at 2022-06-18 10:19:16.274305
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:19:17.996134
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/hongbin/tornado/tornado/locale/", "tornado")
    print(get("zh_CN").translate("Sign out"))


# Generated at 2022-06-18 10:19:28.799752
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), gmt_offset=1) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), gmt_offset=1, dow=False) == "January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), gmt_offset=60) == "Tuesday, January 1"

# Generated at 2022-06-18 10:19:39.003839
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:19:50.777865
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    import pytz
    from pytz import timezone
    from pytz import utc

    # Test for the case of no timezone
    date = datetime(2018, 1, 22)
    locale = Locale.get("en")
    assert locale.format_day(date) == "Monday, January 22"

    # Test for the case of timezone
    date = datetime(2018, 1, 22, tzinfo=utc)
    locale = Locale.get("en")
    assert locale.format_day(date) == "Monday, January 22"

    # Test for the case of timezone
    date = datetime(2018, 1, 22, tzinfo=utc)
    locale = Locale.get("en")

# Generated at 2022-06-18 10:20:03.281424
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:20:13.538131
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(12345) == "12,345"
    assert Locale("en").friendly_number(123456789) == "123,456,789"
    assert Locale("en").friendly_number(12345678901234567890) == "12,345,678,901,234,567,890"
    assert Locale("en").friendly_number(0) == "0"
    assert Locale("en").friendly_number(1) == "1"
    assert Locale("en").friendly_number(10) == "10"
    assert Locale("en").friendly_number(100) == "100"
    assert Locale("en").friendly_number(1000) == "1,000"
    assert Locale("en").friendly_number(10000) == "10,000"
   

# Generated at 2022-06-18 10:21:15.157961
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:21:25.656402
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:21:37.294848
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.locale import load_gettext_translations
    from tornado.locale import _default_locale
    from tornado.locale import Locale
    from tornado.locale import _supported_locales
    from tornado.locale import _translations
    from tornado.locale import _use_gettext
    from tornado.locale import LOCALE_NAMES
    from tornado.locale import CSVLocale
    from tornado.locale import GettextLocale
    from tornado.locale import CONTEXT_SEPARATOR

    # Initialize strings for date formatting
    _ = self.translate

# Generated at 2022-06-18 10:21:43.067463
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:21:50.002697
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:21:55.827955
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en_US").friendly_number(123456789) == "123,456,789"
    assert Locale.get("zh_CN").friendly_number(123456789) == "123456789"
    assert Locale.get("fa").friendly_number(123456789) == "123456789"



# Generated at 2022-06-18 10:22:05.297135
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "دوشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2018, 1, 1)


# Generated at 2022-06-18 10:22:06.622403
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianqing/Desktop/tornado-master/tornado/locale")
    print(_translations)
    print(_supported_locales)



# Generated at 2022-06-18 10:22:13.640651
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["unknown"]["Sign out"] == "Sign out"
    assert _translations["zh_CN"]["unknown"]["Sign out"] == "登出"
    assert _translations["zh_CN"]["unknown"]["Sign in"] == "登录"
    assert _translations["zh_CN"]["unknown"]["Sign up"] == "注册"
    assert _translations["zh_CN"]["unknown"]["Home"] == "首页"
    assert _translations["zh_CN"]["unknown"]["About"] == "关于"

# Generated at 2022-06-18 10:22:23.986127
# Unit test for function load_translations
def test_load_translations():
    load_translations('../locale')
    assert _translations['en_US']['plural']['%(name)s liked this'] == '%(name)s liked this'
    assert _translations['en_US']['singular']['%(name)s liked this'] == '%(name)s liked this'
    assert _translations['en_US']['unknown']['I love you'] == 'I love you'
    assert _translations['es_LA']['plural']['%(name)s liked this'] == 'A %(name)s les gustó esto'
    assert _translations['es_LA']['singular']['%(name)s liked this'] == 'A %(name)s le gustó esto'