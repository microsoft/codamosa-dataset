

# Generated at 2022-06-18 10:13:21.722055
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale.get("en")
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A and B"
    assert locale.list(["A", "B", "C"]) == "A, B and C"
    assert locale.list(["A", "B", "C", "D"]) == "A, B, C and D"

    locale = Locale.get("fa")
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A \u0648 B"
    assert locale.list(["A", "B", "C"]) == "A, B \u0648 C"

# Generated at 2022-06-18 10:13:30.461837
# Unit test for constructor of class Locale
def test_Locale():
    assert Locale.get("en")
    assert Locale.get("en_US")
    assert Locale.get("zh_CN")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_HK")
    assert Locale.get("zh_SG")
    assert Locale.get("zh_MO")
    assert Locale.get("zh_MY")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_TW")
    assert Locale.get("zh_TW")

# Generated at 2022-06-18 10:13:32.731053
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfei/Desktop/tornado-6.0.4/tornado/locale/")
    print(_translations)


# Generated at 2022-06-18 10:13:35.193748
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/lijia/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:13:45.323952
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:13:49.758073
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/yuan/PycharmProjects/tornado_test/tornado/locale/', 'tornado')
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)
# test_load_gettext_translations()



# Generated at 2022-06-18 10:14:01.871568
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    # test for relative time
    now = datetime.datetime.utcnow()
    locale = Locale.get("en")
    assert locale.format_date(now) == "1 second ago"
    assert locale.format_date(now - datetime.timedelta(seconds=1)) == "1 second ago"
    assert locale.format_date(now - datetime.timedelta(seconds=2)) == "2 seconds ago"
    assert locale.format_date(now - datetime.timedelta(seconds=59)) == "59 seconds ago"
    assert locale.format_date(now - datetime.timedelta(minutes=1)) == "1 minute ago"
    assert locale.format_date(now - datetime.timedelta(minutes=2)) == "2 minutes ago"

# Generated at 2022-06-18 10:14:05.934422
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jia/PycharmProjects/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:14:10.061421
# Unit test for function load_translations
def test_load_translations():
    assert _translations == {}
    assert _supported_locales == frozenset([_default_locale])
    load_translations("../locale")
    assert _translations != {}
    assert _supported_locales != frozenset([_default_locale])

# Generated at 2022-06-18 10:14:19.487735
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:14:45.251068
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en_US").format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert Locale.get("en_US").format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert Locale.get("zh_CN").format_day(datetime.datetime(2019, 1, 1)) == "2019\u5e741\u67081\u65e5\u661f\u671f\u4e8c"
    assert Locale.get("zh_CN").format_day(datetime.datetime(2019, 1, 1), dow=False) == "2019\u5e741\u67081\u65e5"
    assert Locale.get("fa_IR").format_

# Generated at 2022-06-18 10:14:49.632628
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/sahil/Desktop/tornado/tornado/locale/translations")
    print(_translations)

# Generated at 2022-06-18 10:14:59.061327
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:15:09.542182
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"
    assert Locale.get("fa").format_day(datetime.datetime(2020, 1, 1)) == "چهارشنبه، ژانویه 1"
    assert Locale.get("fa").format_day(datetime.datetime(2020, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:15:12.608466
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jerry/tornado-5.1.1/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:17.348750
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yongliu/Documents/GitHub/tornado-6.0.4/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:19.062160
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = "./locale")
    print(_translations)


# Generated at 2022-06-18 10:15:22.405401
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lucas/Documents/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:15:24.962144
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/hongbin/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:15:27.954865
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/yue/PycharmProjects/tornado_test/tornado/locale')
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:51.820284
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    import pytz
    import time
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.timezone import get_timezone
    from zerver.lib.timestamp import datetime_to_timestamp
    from zerver.lib.test_helpers import get_test_image_file

    # Test for the case when the timezone is not set
    options.timezone = None
    date = datetime.datetime(year=2018, month=1, day=22, tzinfo=pytz.utc)
    self.assertEqual(Locale.get("en").format_day(date), "Monday, January 22")

    # Test for the case when the timezone is set
    options.timezone = "America/New_York"

# Generated at 2022-06-18 10:16:04.744332
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["zh_CN"]["unknown"]["Sign out"] == "退出"
    assert _translations["zh_CN"]["unknown"]["Sign in"] == "登录"
    assert _translations["zh_CN"]["unknown"]["Sign up"] == "注册"
    assert _translations["zh_CN"]["unknown"]["You are now signed in"] == "您已登录"
    assert _translations["zh_CN"]["unknown"]["You are now signed out"] == "您已退出"

# Generated at 2022-06-18 10:16:07.846014
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/hong/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:20.655404
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en")
    assert locale.friendly_number(0) == "0"
    assert locale.friendly_number(1) == "1"
    assert locale.friendly_number(10) == "10"
    assert locale.friendly_number(100) == "100"
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(10000) == "10,000"
    assert locale.friendly_number(100000) == "100,000"
    assert locale.friendly_number(1000000) == "1,000,000"
    assert locale.friendly_number(10000000) == "10,000,000"
    assert locale.friendly_number(100000000) == "100,000,000"

# Generated at 2022-06-18 10:16:24.593204
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lx/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:16:35.107307
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(date) == "2018\u5e741\u67081\u65e5\u5468\u4e00"
    assert locale.format_day(date, dow=False) == "2018\u5e741\u67081\u65e5"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:16:36.824039
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/ubuntu/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:45.998370
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.web import Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.ioloop import IOLoop
    from tornado.escape import to_unicode
    from tornado.options import options, define
    import tornado.gen
    import tornado.web
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.util
    import tornado.queues
    import tornado.locks
    import tornado.stack_context
    import tornado.concurrent
    import tornado.gen
    import tornado.escape

# Generated at 2022-06-18 10:16:51.939744
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    assert _translations["zh_CN"] == gettext.translation("tornado", "./locale", languages=["zh_CN"])
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True


# Generated at 2022-06-18 10:17:03.058958
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "چهارشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:17:21.471330
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyang/Desktop/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:32.856635
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:17:36.853931
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yuan/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:17:44.505845
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["unknown"]["Sign out"] == "Sign out"
    assert _translations["en_US"]["unknown"]["Sign in"] == "Sign in"
    assert _translations["en_US"]["unknown"]["Sign up"] == "Sign up"
    assert _translations["en_US"]["unknown"]["Home"] == "Home"
    assert _translations["en_US"]["unknown"]["About"] == "About"
    assert _translations["en_US"]["unknown"]["Contact"] == "Contact"
    assert _translations["en_US"]["unknown"]["Blog"] == "Blog"

# Generated at 2022-06-18 10:17:53.632030
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    assert _translations['en_US']['unknown']['Sign out'] == 'Sign out'
    assert _translations['es_LA']['unknown']['Sign out'] == 'Salir'
    assert _translations['es_LA']['unknown']['Sign in'] == 'Iniciar sesión'
    assert _translations['es_LA']['unknown']['Sign up'] == 'Registrarse'
    assert _translations['es_LA']['unknown']['Home'] == 'Inicio'
    assert _translations['es_LA']['unknown']['About'] == 'Acerca de'
    assert _translations['es_LA']['unknown']['Contact'] == 'Contacto'

# Generated at 2022-06-18 10:18:05.330826
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    import datetime
    import pytz
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import json_decode
    from tornado.options import options
    from tornado.log import gen_log
    from . import Locale
    from . import load_translations
    from . import load_gettext_translations
    from . import get_supported_locales
    from . import get_closest_locale
    from . import get_locale
    from . import get_timezone_abbr
    from . import get_timezone_offset
    from . import get_timezone_name
    from . import get_timezone_location
    from . import get_timezone_datetime
    from . import get

# Generated at 2022-06-18 10:18:15.405692
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    import pytz
    from pytz import timezone
    from pytz import utc
    from pytz import country_timezones
    from pytz import country_names
    from pytz import common_timezones
    from pytz import common_timezones_set
    from pytz import all_timezones
    from pytz import all_timezones_set
    from pytz import country_timezones
    from pytz import country_names
    from pytz import timezone
    from pytz import utc
    from pytz import country_timezones
    from pytz import country_names
    from pytz import common_timezones
    from pytz import common_timezones_set
    from pytz import all_timezones

# Generated at 2022-06-18 10:18:18.950942
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="locale", domain="tornado")
    assert _translations["zh_CN"] == gettext.translation(
        "tornado", "locale", languages=["zh_CN"]
    )
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True



# Generated at 2022-06-18 10:18:24.615892
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/usr/share/locale", "tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"



# Generated at 2022-06-18 10:18:27.234250
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yifan/Desktop/tornado/tornado/locale")
    print(_translations)
# test_load_translations()


# Generated at 2022-06-18 10:18:44.050526
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    print(_translations)


# Generated at 2022-06-18 10:18:52.853247
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert Locale.get("fa").format_day(datetime.datetime(2019, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale.get("fa").format_day(datetime.datetime(2019, 1, 1), dow=False) == "ژانویه 1"

# Generated at 2022-06-18 10:18:54.872007
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyang/Desktop/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:19:05.524698
# Unit test for method list of class Locale
def test_Locale_list():
    # Test for empty list
    assert Locale.get("en").list([]) == ""
    # Test for list of size 1
    assert Locale.get("en").list(["A"]) == "A"
    # Test for list of size 2
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    # Test for list of size 3
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    # Test for list of size 4
    assert Locale.get("en").list(["A", "B", "C", "D"]) == "A, B, C and D"
    # Test for list of size 5

# Generated at 2022-06-18 10:19:10.473426
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('locale', 'tornado')
    assert _translations['zh_CN']
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True


# Generated at 2022-06-18 10:19:18.690874
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 1"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 1"


# Generated at 2022-06-18 10:19:19.819980
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")


# Generated at 2022-06-18 10:19:23.482627
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yuan/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:19:34.320147
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for method format_date(self, date, gmt_offset, relative, shorter, full_format)
    # of class Locale
    # test for date in the past
    date = datetime.datetime.utcnow() - datetime.timedelta(minutes=1)
    assert Locale.get("en").format_date(date) == "1 minute ago"
    assert Locale.get("en").format_date(date, relative=False) == "1 minute ago"
    assert Locale.get("en").format_date(date, shorter=True) == "1 minute ago"
    assert Locale.get("en").format_date(date, full_format=True) == "1 minute ago"

# Generated at 2022-06-18 10:19:43.142003
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2020, 1, 22, 0, 0, 0)
    assert locale.format_day(date) == "Wednesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "چهارشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:20:21.962028
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Test for plural message
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("organization", "club", "clubs", 2) == "clubs"
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("stick", "club", "clubs", 2) == "clubs"
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("organization", "club", "clubs", 1) == "club"
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("stick", "club", "clubs", 1) == "club"
    # Test for singular message
    assert GettextLocale("en", gettext.NullTranslations()).pgettext("law", "right") == "right"

# Generated at 2022-06-18 10:20:31.830283
# Unit test for method list of class Locale
def test_Locale_list():
    # Test for empty list
    assert Locale.get("en").list([]) == ""
    # Test for list of size 1
    assert Locale.get("en").list(["A"]) == "A"
    # Test for list of size 2
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    # Test for list of size 3
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    # Test for list of size 4
    assert Locale.get("en").list(["A", "B", "C", "D"]) == "A, B, C and D"
    # Test for list of size 5

# Generated at 2022-06-18 10:20:42.363685
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """
    Test the method format_date of class Locale
    """
    # Test for the case when the date is in the future
    date = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    locale = Locale.get("en_US")
    assert locale.format_date(date) == "in about 1 hour"
    # Test for the case when the date is in the past
    date = datetime.datetime.utcnow() - datetime.timedelta(hours=1)
    locale = Locale.get("en_US")
    assert locale.format_date(date) == "about 1 hour ago"
    # Test for the case when the date is in the past and relative is False

# Generated at 2022-06-18 10:20:53.736313
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:21:03.635829
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 1月1日"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "1月1日"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:21:13.574253
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import url_concat
    from tornado.escape import json_decode
    from tornado.options import options
    import tornado.ioloop
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import os
    import sys
    import time
    import logging
    import logging.handlers
    import json
    import random
    import string
    import unittest
    import uuid
    import datetime
    import re
    import shutil
    import tempfile
    import subprocess
    import multiprocessing
    import platform
    import signal

# Generated at 2022-06-18 10:21:19.282887
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    from datetime import datetime
    from datetime import timedelta
    from datetime import date
    from datetime import time
    from datetime import tzinfo
    from datetime import timezone
    from datetime import datetime
    from datetime import timedelta
    from datetime import date
    from datetime import time
    from datetime import tzinfo
    from datetime import timezone
    from datetime import datetime
    from datetime import timedelta
    from datetime import date
    from datetime import time
    from datetime import tzinfo
    from datetime import timezone
    from datetime import datetime
    from datetime import timedelta
    from datetime import date
    from datetime import time
    from datetime import tzinfo
    from datetime import timezone
    from datetime import dat

# Generated at 2022-06-18 10:21:29.487986
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    print(get("zh_CN").translate("Hello, world"))
    print(get("en_US").translate("Hello, world"))
    print(get("zh_CN").translate("Hello, %(name)s", name="world"))
    print(get("en_US").translate("Hello, %(name)s", name="world"))
    print(get("zh_CN").translate("Hello, %(name)s", name="world"))
    print(get("en_US").translate("Hello, %(name)s", name="world"))
    print(get("zh_CN").translate("Hello, %(name)s", name="world"))

# Generated at 2022-06-18 10:21:40.841036
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # Test for method translate(self, message, plural_message=None, count=None)
    # of class CSVLocale
    # Translation of a singular message
    assert CSVLocale("en", {"unknown": {"Hello": "Hello"}}).translate("Hello") == "Hello"
    # Translation of a plural message
    assert CSVLocale("en", {"plural": {"Hello": "Hello"}}).translate("Hello", "Hello", 2) == "Hello"
    # Translation of a singular message with a count
    assert CSVLocale("en", {"singular": {"Hello": "Hello"}}).translate("Hello", "Hello", 1) == "Hello"
    # Translation of a plural message with a count

# Generated at 2022-06-18 10:21:47.637034
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import sys
    import os
    import unittest
    import tornado.locale
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.options
    import tornado.escape
    import tornado.util
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.stack_context
    import tornado.template
    import tornado.concurrent
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.iostream
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.ioloop
    import tornado.simple_httpclient
    import tornado.curl

# Generated at 2022-06-18 10:22:29.122218
# Unit test for method format_day of class Locale