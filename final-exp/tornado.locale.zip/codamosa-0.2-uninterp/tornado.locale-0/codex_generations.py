

# Generated at 2022-06-18 10:14:03.184876
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/david/git/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:13.668891
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.util import _
    from tornado.locale import load_gettext_translations
    from tornado.locale import GettextLocale
    from tornado.locale import Locale
    from tornado.locale import _use_gettext
    from tornado.locale import _translations
    from tornado.locale import _default_locale
    from tornado.locale import _supported_locales
    from tornado.locale import _

    _use_gettext = True
    _translations = {}
    _default_locale = "en_US"
    _supported_locales = {"en_US": "English (United States)"}
    _ = lambda x: x


# Generated at 2022-06-18 10:14:24.835450
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:14:27.737431
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/zhangyun/Desktop/tornado_test/locale')
    print(_translations)


# Generated at 2022-06-18 10:14:38.484151
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "星期二, 1月1日"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "1月1日"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:14:46.726439
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
    Test the method format_day of class Locale
    """
    # Test case 1:
    # Input: date = datetime.datetime(2019, 1, 22), gmt_offset = 0, dow = True
    # Expected output: "Tuesday, January 22"
    # Actual output: "Tuesday, January 22"
    # Test case 2:
    # Input: date = datetime.datetime(2019, 1, 22), gmt_offset = 0, dow = False
    # Expected output: "January 22"
    # Actual output: "January 22"
    # Test case 3:
    # Input: date = datetime.datetime(2019, 1, 22), gmt_offset = -5, dow = True
    # Expected output: "Monday, January 21"
    # Actual output: "Monday, January 21"
   

# Generated at 2022-06-18 10:14:57.185641
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_date(datetime.datetime(2019, 1, 1, 0, 0, 0)) == "January 1, 2019"
    assert locale.format_date(datetime.datetime(2019, 1, 1, 0, 0, 0), full_format=True) == "January 1, 2019"
    assert locale.format_date(datetime.datetime(2019, 1, 1, 0, 0, 0), relative=False) == "January 1, 2019"
    assert locale.format_date(datetime.datetime(2019, 1, 1, 0, 0, 0), relative=False, full_format=True) == "January 1, 2019"

# Generated at 2022-06-18 10:15:06.072796
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"



# Generated at 2022-06-18 10:15:14.530097
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 1"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 1"

# Generated at 2022-06-18 10:15:17.776949
# Unit test for function load_translations
def test_load_translations():
    directory = "./"
    encoding = "utf-8"
    load_translations(directory, encoding)
    print(_translations)


# Generated at 2022-06-18 10:15:43.090519
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yuan/Desktop/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:15:54.672957
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="./locale", domain="tornado")
    assert _translations["en_US"].gettext("Hello") == "Hello"
    assert _translations["zh_CN"].gettext("Hello") == "你好"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"
    assert _translations["zh_CN"].gettext("Hello %(name)s") == "你好 %(name)s"

# Generated at 2022-06-18 10:16:06.691873
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:16:10.054558
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/lizhe/PycharmProjects/tornado-demo/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:12.501093
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/Desktop/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:15.973453
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/Desktop/tornado-6.0.4/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:26.934552
# Unit test for function load_translations
def test_load_translations():
    import os
    import tempfile
    import shutil
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.web import Application
    from tornado.web import RequestHandler
    from tornado.locale import load_translations
    from tornado.locale import get
    from tornado.locale import set_default_locale
    from tornado.locale import _translations
    from tornado.locale import _supported_locales
    from tornado.locale import _default_locale
    from tornado.locale import _use_gettext
    from tornado.locale import load_gettext_translations
    from tornado.locale import Locale
    from tornado.locale import _translate
    from tornado.locale import _


# Generated at 2022-06-18 10:16:30.910431
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/zhaoyu/PycharmProjects/tornado_test/tornado/locale/")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:16:33.221672
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test for method pgettext(self, context, message, plural_message, count)
    # of class Locale
    assert True



# Generated at 2022-06-18 10:16:43.218309
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
    Test for method format_day of class Locale
    """
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale

# Generated at 2022-06-18 10:17:05.736261
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:17:16.101846
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="../locale", domain="tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)
    print(get("en_US").translate("Sign out"))
    print(get("zh_CN").translate("Sign out"))
    print(get("zh_CN").translate("%(name)s liked this", name="张三"))
    print(get("zh_CN").translate("%(name)s liked this", name="张三,李四"))
    print(get("zh_CN").translate("%(name)s liked this", name="张三,李四,王五"))

# Generated at 2022-06-18 10:17:17.628130
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:22.912093
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:17:35.080013
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A"]) == "A"
    assert Locale.get("en").list([]) == ""
    assert Locale.get("fa").list(["A", "B", "C"]) == "A \u0648 B \u0648 C"
    assert Locale.get("fa").list(["A", "B"]) == "A \u0648 B"
    assert Locale.get("fa").list(["A"]) == "A"
    assert Locale.get("fa").list([]) == ""


# Generated at 2022-06-18 10:17:36.042751
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = "./locale")
    print(_translations)


# Generated at 2022-06-18 10:17:44.001784
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:17:46.438514
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lucas/PycharmProjects/tornado_test/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)



# Generated at 2022-06-18 10:17:57.080505
# Unit test for method pgettext of class GettextLocale

# Generated at 2022-06-18 10:18:08.199302
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert Locale.get("en").pgettext("context", "message") == "message"
    assert Locale.get("en").pgettext("context", "message", count=1) == "message"
    assert Locale.get("en").pgettext("context", "message", count=2) == "message"
    assert Locale.get("en").pgettext("context", "message", count=3) == "message"
    assert Locale.get("en").pgettext("context", "message", count=4) == "message"
    assert Locale.get("en").pgettext("context", "message", count=5) == "message"
    assert Locale.get("en").pgettext("context", "message", count=6) == "message"

# Generated at 2022-06-18 10:18:43.617447
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import json_decode
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler
    from tornado.options import define, options, parse_command_line
    from tornado.log import enable_pretty_logging
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler
    from tornado.options import define, options, parse_command_line
    from tornado.log import enable_pretty_logging
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application, RequestHandler

# Generated at 2022-06-18 10:18:53.485321
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2020, 1, 1)
    assert locale.format_day(date) == "Wednesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u0698\u0627\u0646\u0648\u06cc\u0647 1"
    assert locale.format_day(date, dow=False) == "\u0698\u0627\u0646\u0648\u06cc\u0647 1"


# Generated at 2022-06-18 10:19:04.355199
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:19:09.508155
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory='./locale', domain='tornado')
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:19:11.904260
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yue/Documents/GitHub/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:19:14.752990
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianxiong/Desktop/tornado-master/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:19:17.154671
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/michael/Desktop/tornado-6.0.3/tornado/locale')
    print(_translations)


# Generated at 2022-06-18 10:19:23.200382
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest


# Generated at 2022-06-18 10:19:34.062016
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test with date in the past
    date = datetime.datetime.utcnow() - datetime.timedelta(days=1)
    assert Locale.get("en").format_date(date) == "yesterday"
    assert Locale.get("en").format_date(date, full_format=True) == "yesterday"
    assert Locale.get("en").format_date(date, relative=False) == "yesterday"
    assert Locale.get("en").format_date(date, relative=False, full_format=True) == "yesterday"
    assert Locale.get("en").format_date(date, shorter=True) == "yesterday"
    assert Locale.get("en").format_date(date, shorter=True, full_format=True) == "yesterday"
    assert Locale

# Generated at 2022-06-18 10:19:37.280711
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jiaxin/Desktop/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)
# test_load_translations()



# Generated at 2022-06-18 10:20:43.553600
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/travis/build/tornadoweb/tornado/tornado/locale", "tornado")

# Generated at 2022-06-18 10:20:46.132664
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyan/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:54.979010
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale("en").format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert Locale("en").format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"
    assert Locale("fa").format_day(datetime.datetime(2020, 1, 1)) == "چهارشنبه، ژانویه 1"
    assert Locale("fa").format_day(datetime.datetime(2020, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:21:05.043854
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(0) == "0"
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(10) == "10"
    assert Locale.get("en").friendly_number(100) == "100"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(10000) == "10,000"
    assert Locale.get("en").friendly_number(100000) == "100,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(10000000) == "10,000,000"

# Generated at 2022-06-18 10:21:14.552550
# Unit test for method pgettext of class Locale

# Generated at 2022-06-18 10:21:17.289320
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/lizhong/Desktop/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)
# test_load_translations()



# Generated at 2022-06-18 10:21:27.894965
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:21:32.268757
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/yunfei/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:21:40.020431
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:21:41.695825
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test for method pgettext(self, context, message, plural_message=None, count=None)
    # of class Locale
    assert True # TODO: implement your test here
