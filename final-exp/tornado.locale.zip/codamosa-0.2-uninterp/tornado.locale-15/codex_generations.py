

# Generated at 2022-06-18 10:13:13.703633
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A"]) == "A"
    assert Locale.get("en").list([]) == ""
    assert Locale.get("fa").list(["A", "B", "C"]) == "A \u0648 B \u0648 C"
    assert Locale.get("fa").list(["A", "B"]) == "A \u0648 B"
    assert Locale.get("fa").list(["A"]) == "A"
    assert Locale.get("fa").list([]) == ""


# Generated at 2022-06-18 10:13:21.106579
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
    Test for method format_day of class Locale
    """
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale
    # Test for method format_day of class Locale

# Generated at 2022-06-18 10:13:23.681744
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyang/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:13:32.261364
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["zh_CN"]
    assert _translations["zh_CN"].gettext("Sign out") == "登出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"

# Generated at 2022-06-18 10:13:42.503826
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:13:53.591536
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import time
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo

# Generated at 2022-06-18 10:13:58.637372
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/Users/yunfei/PycharmProjects/tornado_test/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)

# test_load_gettext_translations()


# Generated at 2022-06-18 10:14:09.967360
# Unit test for constructor of class Locale
def test_Locale():
    Locale.get_closest("en_US")
    Locale.get_closest("en_US", "en_GB")
    Locale.get_closest("en_US", "en_GB", "en_AU")
    Locale.get_closest("en_US", "en_GB", "en_AU", "en_CA")
    Locale.get_closest("en_US", "en_GB", "en_AU", "en_CA", "en_NZ")
    Locale.get_closest("en_US", "en_GB", "en_AU", "en_CA", "en_NZ", "en_IE")

# Generated at 2022-06-18 10:14:17.991321
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en_US")
    assert locale.friendly_number(0) == "0"
    assert locale.friendly_number(1) == "1"
    assert locale.friendly_number(10) == "10"
    assert locale.friendly_number(100) == "100"
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(10000) == "10,000"
    assert locale.friendly_number(100000) == "100,000"
    assert locale.friendly_number(1000000) == "1,000,000"
    assert locale.friendly_number(10000000) == "10,000,000"
    assert locale.friendly_number(100000000) == "100,000,000"

# Generated at 2022-06-18 10:14:29.289769
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    assert _translations["zh_CN"]
    assert _translations["zh_CN"]["plural"]["%(name)s liked this"] == "A %(name)s 喜欢这个"
    assert _translations["zh_CN"]["singular"]["%(name)s liked this"] == "A %(name)s 喜欢这个"
    assert _translations["zh_CN"]["unknown"]["I love you"] == "我爱你"
    assert _translations["zh_CN"]["unknown"]["%(name)s liked this"] == "A %(name)s 喜欢这个"
    assert _supported_locales == fro

# Generated at 2022-06-18 10:15:00.322646
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import get_test_image_file
    from zerver.lib.upload import upload_message_image
    from zerver.models import get_realm, get_user
    from zerver.lib.actions import do_change_user_role
    from zerver.lib.test_helpers import (
        get_test_image_file,
        get_test_image_upload,
        make_client,
        message_ids,
        most_recent_message,
    )

    class TestGettextLocale(ZulipTestCase):
        def test_pgettext(self):
            """
            Test pgettext method of GettextLocale class
            """
            # Create a

# Generated at 2022-06-18 10:15:10.463394
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"

    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "چهارشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:15:16.264065
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:15:19.287202
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jerry/tornado/tornado/locale", "tornado")
    print(get("zh_CN").translate("Hello"))


# Generated at 2022-06-18 10:15:29.767289
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en")
    assert locale.friendly_number(1) == "1"
    assert locale.friendly_number(10) == "10"
    assert locale.friendly_number(100) == "100"
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(10000) == "10,000"
    assert locale.friendly_number(100000) == "100,000"
    assert locale.friendly_number(1000000) == "1,000,000"
    assert locale.friendly_number(10000000) == "10,000,000"
    assert locale.friendly_number(100000000) == "100,000,000"
    assert locale.friendly_number(1000000000) == "1,000,000,000"

# Generated at 2022-06-18 10:15:38.686949
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:15:49.749964
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000) == "1,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000) == "1,000,000,000,000,000"
    assert Locale.get("en").friendly_number(1000000000000000000) == "1,000,000,000,000,000,000"

# Generated at 2022-06-18 10:16:02.307744
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="../locale", domain="tornado")
    assert _translations["en_US"].gettext("Sign out") == "Sign out"
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_TW"].gettext("Sign out") == "登出"
    assert _translations["zh_HK"].gettext("Sign out") == "登出"
    assert _translations["zh_MO"].gettext("Sign out") == "登出"
    assert _translations["zh_SG"].gettext("Sign out") == "登出"
    assert _translations["zh_MY"].gettext("Sign out") == "登出"


# Generated at 2022-06-18 10:16:03.766091
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/james/Desktop/tornado/tornado/locale")
    print(_translations)

# Generated at 2022-06-18 10:16:16.358742
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:17:09.959003
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test for method pgettext of class Locale
    # This test is not yet implemented
    pass


# Generated at 2022-06-18 10:17:20.433047
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(10) == "10"
    assert Locale.get("en").friendly_number(100) == "100"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(10000) == "10,000"
    assert Locale.get("en").friendly_number(100000) == "100,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(10000000) == "10,000,000"

# Generated at 2022-06-18 10:17:26.243225
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-18 10:17:37.863487
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(0) == "0"
    assert Locale.get("en").friendly_number(-1234567) == "-1,234,567"
    assert Locale.get("en").friendly_number(-12345) == "-12,345"
    assert Locale.get("en").friendly_number(-123) == "-123"

# Generated at 2022-06-18 10:17:39.595709
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jason/tornado-5.1.1/tornado/locale", "tornado")


# Generated at 2022-06-18 10:17:41.379637
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/david/Documents/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:17:50.356263
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import sys
    import os
    import os.path
    import tempfile
    import shutil
    import subprocess
    import re
    import gettext
    import polib
    import random
    import string
    import time
    import datetime
    import math

    class LocaleTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.locale_dir = os.path.join(self.temp_dir, "locale")
            os.mkdir(self.locale_dir)
            self.domain = "tornado"
            self.po_file = os.path.join(self.temp_dir, "tornado.po")
            self.po = polib.POFile()

# Generated at 2022-06-18 10:17:53.716600
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jason/Desktop/tornado-6.0.3/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:18:05.018922
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 1"
    assert locale.format_day(date, dow=False) == "\u062c\u0646\u0648\u0631\u06cc 1"


# Generated at 2022-06-18 10:18:08.091596
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyu/Documents/GitHub/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:19:18.649599
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tornado.testing
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.options
    import os
    import shutil
    import tempfile
    import gettext
    import subprocess
    import time
    import tornado.platform.asyncio
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    tornado.options.define("port", default=8888, help="run on the given port", type=int)
    tornado.options.parse_command_

# Generated at 2022-06-18 10:19:26.169646
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa_IR")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:19:37.374540
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for method format_date(self, date, gmt_offset=0, relative=True, shorter=False, full_format=False)
    # of class Locale
    # Testing for date in the past
    date = datetime.datetime.utcnow() - datetime.timedelta(minutes=1)
    assert Locale.get("en").format_date(date) == "1 minute ago"
    assert Locale.get("en").format_date(date, relative=False) == "today at %s" % date.strftime("%H:%M")
    assert Locale.get("en").format_date(date, shorter=True) == "today"

# Generated at 2022-06-18 10:19:49.344196
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import unittest
    import tornado.locale
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.web
    import tornado.wsgi
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform

# Generated at 2022-06-18 10:19:54.550182
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jim/tornado-5.1.1/tornado/locale", "tornado.locale")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:20:02.176939
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "یکشنبه، ژانویه 1"
    assert locale.format_day(date, dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:20:07.187518
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lizhixuan/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:20:09.563024
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "tornado")
    assert _translations["zh_CN"] is not None


# Generated at 2022-06-18 10:20:20.014181
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "Monday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2018, 1, 1)
    assert locale.format_day(date) == "2018\u5e741\u67081\u65e5\u5468\u4e00"
    assert locale.format_day(date, dow=False) == "2018\u5e741\u67081\u65e5"
    # Test for Arabic
    locale = Locale.get("ar")
   

# Generated at 2022-06-18 10:20:30.222164
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "test"
    load_gettext_translations(directory, domain)
    assert _translations["en_US"].gettext("test") == "test"
    assert _translations["zh_CN"].gettext("test") == "测试"
    assert _translations["zh_TW"].gettext("test") == "測試"
    assert _translations["zh_HK"].gettext("test") == "測試"
    assert _translations["zh_MO"].gettext("test") == "測試"
    assert _translations["zh_SG"].gettext("test") == "测试"