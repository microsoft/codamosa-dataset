

# Generated at 2022-06-18 10:13:39.709605
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jian/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:13:43.130063
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/shen/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:13:54.220946
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import gettext
    import os
    import sys
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create the translations directory structure
    locale_dir = os.path.join(temp_dir, "locale")
    os.mkdir(locale_dir)
    os.mkdir(os.path.join(locale_dir, "en"))
    os.mkdir(os.path.join(locale_dir, "en", "LC_MESSAGES"))

    # Create the translations file
    po_file = os.path.join(locale_dir, "en", "LC_MESSAGES", "messages.po")

# Generated at 2022-06-18 10:13:57.790665
# Unit test for function load_translations
def test_load_translations():
    load_translations('/home/travis/build/karthik-sankar/tornado/tornado/locale')
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:00.422953
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/xu/Desktop/tornado_test/locale")
    print(_translations)


# Generated at 2022-06-18 10:14:03.962203
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jason/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:14:06.795660
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/carlos/Documents/tornado/tornado/locale/")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:14:16.172153
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:14:27.214753
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tempfile
    import shutil
    import gettext
    import tornado.locale
    import tornado.testing
    import tornado.escape
    import tornado.log
    import tornado.util
    import tornado.web
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.stack_context
    import tornado.template
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.test.web_test
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.testing
    import tornado.test

# Generated at 2022-06-18 10:14:37.958132
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _translations["zh_CN"].gettext("Sign out") == "退出"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"
    assert _translations["zh_CN"].gettext("%(name)s liked this") == "%(name)s 喜欢这个"

# Generated at 2022-06-18 10:15:10.341407
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:15:17.681711
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:15:20.587735
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test for method pgettext(self, context, message, plural_message=None, count=None)
    # of class Locale
    # This test is not yet implemented
    pass


# Generated at 2022-06-18 10:15:29.488105
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:15:38.473821
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    csv_locale = CSVLocale("en", {})
    assert csv_locale.translate("test") == "test"
    assert csv_locale.translate("test", "tests", 1) == "test"
    assert csv_locale.translate("test", "tests", 2) == "tests"
    assert csv_locale.translate("test", "tests", 0) == "tests"
    assert csv_locale.translate("test", "tests", -1) == "tests"
    assert csv_locale.translate("test", "tests", None) == "test"
    assert csv_locale.translate("test", None, None) == "test"
    assert csv_locale.translate("test", None, 1) == "test"
    assert csv_

# Generated at 2022-06-18 10:15:49.612766
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import get_all_templates
    from zerver.lib.i18n import load_gettext_translations
    from zerver.lib.i18n import get_language_list
    from zerver.lib.i18n import get_language_name
    from zerver.lib.i18n import get_language_name_from_code
    from zerver.lib.i18n import get_language_list_for_templates
    from zerver.lib.i18n import get_language_list_for_js
    from zerver.lib.i18n import get_language_name_from_code_for_js
    from zerver.lib.i18n import get_

# Generated at 2022-06-18 10:16:00.002336
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    date = datetime.datetime(2019, 1, 22)
    assert locale.format_day(date) == "Tuesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa_IR")
    assert locale.format_day(date) == "دوشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:16:11.663525
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:16:14.730083
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/tian/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:16:24.855610
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert Locale.get("en").format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 1)) == "یکشنبه، ژانویه 1"
    assert Locale.get("fa").format_day(datetime.datetime(2018, 1, 1), dow=False) == "ژانویه 1"



# Generated at 2022-06-18 10:16:59.946068
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "2018\u5e741\u670822\u65e5\u661f\u671f\u4e00"
    assert locale.format_day(date, dow=False) == "2018\u5e741\u670822\u65e5"



# Generated at 2022-06-18 10:17:09.517781
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    from datetime import date
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time

# Generated at 2022-06-18 10:17:13.002680
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory="./locale")
    print(_translations)


# Generated at 2022-06-18 10:17:21.164642
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    from datetime import tzinfo
    from datetime import time
    import pytz
    import time
    import locale
    import os
    import sys
    import unittest
    import tornado.escape
    import tornado.locale
    import tornado.testing
    import tornado.test.util
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.httpclient
    import tornado.httputil
    import tornado.httputil
    import tornado.httpserver

# Generated at 2022-06-18 10:17:23.819701
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/xu/Desktop/tornado-6.0.3/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:36.158958
# Unit test for method format_date of class Locale

# Generated at 2022-06-18 10:17:37.906807
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/david/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:17:39.943313
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/tian/Documents/tornado/tornado/locale/")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:17:41.286566
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jianghao/Desktop/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:17:43.787798
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/jian/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:18:13.680828
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 22)
    assert locale.format_day(date) == "Tuesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("zh_CN")
    assert locale.format_day(date) == "2019\u5e741\u670822\u65e5"
    assert locale.format_day(date, dow=False) == "2019\u5e741\u670822\u65e5"
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:18:15.049762
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/lz/tornado/tornado/locale", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:18:25.452091
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import sys
    import os
    import io
    import csv
    import gettext
    import tempfile
    import shutil
    import random
    import string
    import locale
    import datetime
    import tornado.escape
    import tornado.util
    import tornado.locale
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    import tornado.web
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.web
    import tornado

# Generated at 2022-06-18 10:18:34.307466
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """Tests the method format_day of class Locale"""
    # Test 1
    locale = Locale.get("en")
    date = datetime.datetime(year=2019, month=1, day=22)
    assert locale.format_day(date) == "Tuesday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    # Test 2
    locale = Locale.get("fa")
    date = datetime.datetime(year=2019, month=1, day=22)
    assert locale.format_day(date) == "\u0634\u0646\u0628\u0647, \u062c\u0646\u0648\u0631\u06cc 22"

# Generated at 2022-06-18 10:18:44.009087
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    assert _translations["en_US"]["plural"]["%(name)s liked this"] == "%(name)s liked this"
    assert _translations["es_LA"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"
    assert _translations["es_LA"]["singular"]["%(name)s liked this"] == "A %(name)s le gustó esto"
    assert _translations["es_LA"]["unknown"]["I love you"] == "Te amo"
    assert _supported_locales == frozenset(["en_US", "es_LA"])


# Generated at 2022-06-18 10:18:45.320944
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    print(_translations)


# Generated at 2022-06-18 10:18:55.531205
# Unit test for method format_day of class Locale

# Generated at 2022-06-18 10:19:05.926586
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "Monday, January 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2018, 1, 1)) == "星期一, 一月 1"
    assert locale.format_day(datetime.datetime(2018, 1, 1), dow=False) == "一月 1"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:19:12.523006
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    date = datetime.datetime(2019, 1, 1)
    assert locale.format_day(date) == "Tuesday, January 1"
    assert locale.format_day(date, dow=False) == "January 1"
    # Test for Chinese
    locale = Locale.get("zh_CN")
    assert locale.format_day(date) == "2019\u5e741\u67081\u65e5\u661f\u671f\u4e8c"
    assert locale.format_day(date, dow=False) == "2019\u5e741\u67081\u65e5"
    # Test for Persian
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:19:15.755927
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/zhaoyang/Desktop/tornado-6.0.3/tornado/locale')
    print(_translations)
    print(_supported_locales)
# test_load_translations()



# Generated at 2022-06-18 10:20:08.284520
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime, timedelta
    from time import time
    from . import Locale
    Locale.load_translations(os.path.join(os.path.dirname(__file__), "translations"))
    locale = Locale.get("en")
    now = datetime.utcnow()
    assert locale.format_date(now) == "just now"
    assert locale.format_date(now - timedelta(seconds=1)) == "1 second ago"
    assert locale.format_date(now - timedelta(seconds=2)) == "2 seconds ago"
    assert locale.format_date(now - timedelta(seconds=59)) == "59 seconds ago"
    assert locale.format_date(now - timedelta(minutes=1)) == "1 minute ago"

# Generated at 2022-06-18 10:20:14.244487
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2018, 1, 22)
    assert locale.format_day(date) == "Monday, January 22"
    assert locale.format_day(date, dow=False) == "January 22"
    locale = Locale.get("fa")
    assert locale.format_day(date) == "دوشنبه، ژانویه 22"
    assert locale.format_day(date, dow=False) == "ژانویه 22"


# Generated at 2022-06-18 10:20:16.636645
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaoyue/Desktop/tornado/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:20:18.854261
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/yunfeng/Desktop/tornado/tornado/locale/")
    print(_translations)


# Generated at 2022-06-18 10:20:22.477653
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    assert _translations['en_US']['unknown']['Sign out'] == 'Sign out'
    assert _translations['es_LA']['unknown']['Sign out'] == 'Salir'


# Generated at 2022-06-18 10:20:32.186131
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "Wednesday, January 1"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "January 1"
    locale = Locale.get("zh_CN")
    assert locale.format_day(datetime.datetime(2020, 1, 1)) == "星期三, 1月1日"
    assert locale.format_day(datetime.datetime(2020, 1, 1), dow=False) == "1月1日"
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:20:42.706842
# Unit test for function load_translations
def test_load_translations():
    load_translations('./')
    assert _translations['en_US']['unknown']['Sign out'] == 'Sign out'
    assert _translations['es_LA']['unknown']['Sign out'] == 'Cerrar sesión'
    assert _translations['es_LA']['unknown']['Sign in'] == 'Iniciar sesión'
    assert _translations['es_LA']['unknown']['Sign in with Google'] == 'Iniciar sesión con Google'
    assert _translations['es_LA']['unknown']['Sign in with Facebook'] == 'Iniciar sesión con Facebook'
    assert _translations['es_LA']['unknown']['Sign in with Twitter'] == 'Iniciar sesión con Twitter'

# Generated at 2022-06-18 10:20:45.737070
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yuan/tornado/tornado/locale")
    print(_translations)
    print(_supported_locales)


# Generated at 2022-06-18 10:20:48.081102
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/jianyuan/Desktop/tornado-6.0.3/tornado/locale')
    print(_translations)


# Generated at 2022-06-18 10:20:51.359906
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test the method pgettext of class Locale
    # This method is not implemented in class Locale
    # So we test it in its subclasses
    pass


# Generated at 2022-06-18 10:21:42.599224
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test case 1
    date = datetime.datetime(2018, 1, 1)
    gmt_offset = 0
    dow = True
    locale = Locale.get("en")
    assert locale.format_day(date, gmt_offset, dow) == "Monday, January 1"

    # Test case 2
    date = datetime.datetime(2018, 1, 1)
    gmt_offset = 0
    dow = False
    locale = Locale.get("en")
    assert locale.format_day(date, gmt_offset, dow) == "January 1"

    # Test case 3
    date = datetime.datetime(2018, 1, 1)
    gmt_offset = 0
    dow = True
    locale = Locale.get("fa")

# Generated at 2022-06-18 10:21:44.621162
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/yue/PycharmProjects/tornado_test/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:21:53.573504
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test for English
    locale = Locale.get("en")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    # Test for Persian
    locale = Locale.get("fa")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "یکشنبه، ژانویه 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "ژانویه 1"


# Generated at 2022-06-18 10:22:02.831449
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(1) == "1"
    assert Locale("en").friendly_number(12) == "12"
    assert Locale("en").friendly_number(123) == "123"
    assert Locale("en").friendly_number(1234) == "1,234"
    assert Locale("en").friendly_number(12345) == "12,345"
    assert Locale("en").friendly_number(123456) == "123,456"
    assert Locale("en").friendly_number(1234567) == "1,234,567"
    assert Locale("en").friendly_number(12345678) == "12,345,678"
    assert Locale("en").friendly_number(123456789) == "123,456,789"
    assert Locale("en").friendly

# Generated at 2022-06-18 10:22:06.041730
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/david/Documents/tornado/tornado/locale/", "tornado")
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-18 10:22:07.367812
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/jiaxin/Desktop/tornado-6.0.3/tornado/locale")
    print(_translations)


# Generated at 2022-06-18 10:22:14.256374
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.options import options
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import get_all_templates
    from zerver.lib.i18n import load_gettext_translations
    from zerver.lib.i18n import get_language_list
    from zerver.lib.i18n import get_language_name
    from zerver.lib.i18n import get_language_list_for_templates
    from zerver.lib.i18n import get_language_name_for_templates
    from zerver.lib.i18n import get_language_list_for_js
    from zerver.lib.i18n import get_language_name_for_js
    from zerver.lib.i18n import get_language_list

# Generated at 2022-06-18 10:22:24.638915
# Unit test for function load_translations
def test_load_translations():
    load_translations("locale")